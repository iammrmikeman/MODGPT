#include "natives.h"

namespace PLAYER {
int PLAYER_PED_ID() { return 1; }
}

namespace ENTITY {
bool IS_ENTITY_DEAD(int entity) { return false; }
}
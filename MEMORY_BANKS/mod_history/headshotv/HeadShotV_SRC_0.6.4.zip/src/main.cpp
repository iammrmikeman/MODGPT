// main.cpp - Entry stub for linker
extern "C" void ScriptMain();
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason, LPVOID lpReserved) {
    return TRUE;
}

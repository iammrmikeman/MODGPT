Build HeadShotV by opening project/HeadShotV.sln in Visual Studio. Output goes to /compiled. Logs go to /VS_DEBUG.

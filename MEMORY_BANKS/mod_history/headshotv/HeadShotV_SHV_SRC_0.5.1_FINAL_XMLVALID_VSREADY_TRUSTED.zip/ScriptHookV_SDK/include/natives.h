#pragma once

#ifndef BOOL_DEFINED
#define BOOL_DEFINED
typedef int BOOL;
#endif



typedef int Player;
typedef int Ped;
typedef int Entity;
typedef int Object;
typedef int Hash;
typedef int Vehicle;

namespace PLAYER {
    Player PLAYER_PED_ID();
}

namespace ENTITY {
    Vector3 GET_ENTITY_COORDS(Entity entity, BOOL alive);
    void ATTACH_ENTITY_TO_ENTITY(Object obj, Entity target, int boneIndex,
                                  float x, float y, float z,
                                  float pitch, float roll, float yaw,
                                  BOOL useSoftPinning, BOOL collision, BOOL isPed,
                                  BOOL vertexIndex, int fixedRot, BOOL useCarAlign);
}

namespace GAMEPLAY {
    Hash GET_HASH_KEY(const char* str);
}

namespace STREAMING {
    void REQUEST_MODEL(Hash model);
    BOOL HAS_MODEL_LOADED(Hash model);
}

namespace OBJECT {
    Object CREATE_OBJECT(Hash model, float x, float y, float z, BOOL dynamic = TRUE, BOOL networked = FALSE, BOOL param6 = FALSE);
}

namespace PED {
    BOOL IS_PED_SHOOTING(Ped ped);
    int GET_PED_BONE_INDEX(Ped ped, int boneId);
    BOOL IS_PED_SHOOTING(Ped ped);
}

namespace UI {
    void SET_TEXT_FONT(int fontType);
    void SET_TEXT_SCALE(float x, float y);
    void SET_TEXT_COLOUR(int r, int g, int b, int a);
    void SET_TEXT_OUTLINE();
    void BEGIN_TEXT_COMMAND_DISPLAY_TEXT(const char* text);
    void ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(const char* text);
    void END_TEXT_COMMAND_DISPLAY_TEXT(float x, float y);
}

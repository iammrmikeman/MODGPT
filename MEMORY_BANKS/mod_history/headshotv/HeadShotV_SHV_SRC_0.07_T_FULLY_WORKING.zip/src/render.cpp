#include "render.h"
#include <iostream>

void DrawTextAboveRadar(const char* text) {
    std::cout << "[HUD] " << text << std::endl;
}

#include "utils.h"
#include <iostream>

void LogMessage(const char* message) {
    std::cout << "[HeadShotV] " << message << std::endl;
}

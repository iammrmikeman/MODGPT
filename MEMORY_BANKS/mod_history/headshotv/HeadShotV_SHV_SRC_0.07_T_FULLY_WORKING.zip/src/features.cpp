#include "features.h"
#include "natives.h"
#include "utils.h"

void CheckHeadshot() {
    int ped = PLAYER::PLAYER_PED_ID();
    if (ENTITY::IS_ENTITY_DEAD(ped)) {
        LogMessage("Player is dead.");
    }
}

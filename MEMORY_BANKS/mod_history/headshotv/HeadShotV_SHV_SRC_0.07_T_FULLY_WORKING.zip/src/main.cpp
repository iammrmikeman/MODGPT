#include "script.h"
#include "natives.h"
#include "utils.h"
#include "features.h"
#include "render.h"
#include <windows.h>

void ScriptMain() {
    while (true) {
        CheckHeadshot();
        DrawTextAboveRadar("iammrmikeman");
        Sleep(0);
    }
}

#pragma once
void CheckHeadshot();

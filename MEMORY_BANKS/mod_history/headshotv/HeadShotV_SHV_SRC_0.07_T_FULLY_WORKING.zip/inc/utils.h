#pragma once
#include "types.h"
void LogMessage(const char* message);

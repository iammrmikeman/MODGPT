// main.cpp
#include "script.h"
void ScriptMain() {
    while (true) {
        Ped playerPed = PLAYER::PLAYER_PED_ID();
        if (IS_PED_SHOOTING(playerPed)) {
            UI::PRINT_TEXT("HeadShotV: Player is shooting!");
        }
        WAIT(0);
    }
}
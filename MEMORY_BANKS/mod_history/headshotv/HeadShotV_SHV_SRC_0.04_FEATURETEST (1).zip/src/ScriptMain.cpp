#include "script.h"

void ScriptMain()
{
    Hash model = GAMEPLAY::GET_HASH_KEY("headburst");
    STREAMING::REQUEST_MODEL(model);
    while (!STREAMING::HAS_MODEL_LOADED(model)) WAIT(0);

    Ped playerPed = PLAYER::PLAYER_PED_ID();
    Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, true);
    pos.z += 0.5f; // Offset slightly above head

    Object obj = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, true, true, false);
    if (ENTITY::DOES_ENTITY_EXIST(obj))
    {
        UI::PRINT_TO_CONSOLE("Headburst object spawned successfully.");
    }
    else
    {
        UI::PRINT_TO_CONSOLE("Failed to spawn headburst object.");
    }

    while (true)
    {
        WAIT(0);
    }
}

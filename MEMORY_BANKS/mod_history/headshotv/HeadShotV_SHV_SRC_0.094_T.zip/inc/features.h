#pragma once
void CheckHeadshot();
#pragma once

#ifndef VECTOR3_DEFINED
#define VECTOR3_DEFINED
struct Vector3 {
    float x, y, z;
};
#endif

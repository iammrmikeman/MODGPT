#include "script.h"
#include "natives.h"
#include "types.h"
#include "logic.h"

void ScriptMain() {
    if (IS_PED_SHOOTING(PLAYER::PLAYER_PED_ID())) {
        UI::DRAW_TEXT("iammrmikeman", 0.5, 0.1);
        runHeadLogic();
    }
}
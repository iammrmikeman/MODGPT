#include "functions.h"
#include "script.h"
#include "natives.h"

void logEvent(const char* msg) {
    UI::DRAW_TEXT(msg, 0.5, 0.2);
}
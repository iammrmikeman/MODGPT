#pragma once
#include "types.h"

BOOL IS_PED_SHOOTING(Ped ped);

namespace PLAYER {
    Ped PLAYER_PED_ID();
}

namespace UI {
    void DRAW_TEXT(const char* text, float x, float y);
}
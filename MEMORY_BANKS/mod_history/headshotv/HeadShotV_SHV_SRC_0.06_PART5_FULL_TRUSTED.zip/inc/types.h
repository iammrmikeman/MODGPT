typedef int Ped;
typedef int BOOL;
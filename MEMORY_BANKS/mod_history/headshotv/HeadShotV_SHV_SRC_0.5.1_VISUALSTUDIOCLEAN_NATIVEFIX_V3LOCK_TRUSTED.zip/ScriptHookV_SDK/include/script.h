#pragma once

#include <Windows.h>
#define WAIT(x) Sleep(x)
void ScriptMain();

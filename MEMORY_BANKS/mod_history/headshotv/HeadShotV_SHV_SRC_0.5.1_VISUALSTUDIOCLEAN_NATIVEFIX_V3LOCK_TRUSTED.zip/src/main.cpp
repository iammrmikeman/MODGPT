#include "script.h"
#include "types.h"
#include "natives.h"



// HeadShotV Mod - Main Script
// Auto-enhanced by GPT - Version 0.5.1 FINAL SDK VERIFIED
// Author: iammrmikeman
// Features:
// - Head model spawns on shooting
// - Prevents model spam
// - Displays "iammrmikeman" above radar


bool modelSpawned = false;

void drawText(const char* text, float x, float y)
{
    UI::SET_TEXT_FONT(0);
    UI::SET_TEXT_SCALE(0.5, 0.5);
    UI::SET_TEXT_COLOUR(255, 255, 255, 255);
    UI::SET_TEXT_OUTLINE();
    UI::BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING");
    UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
    UI::END_TEXT_COMMAND_DISPLAY_TEXT(x, y);
}

void ScriptMain()
{
    while (true)
    {
        drawText("iammrmikeman", 0.01f, 0.01f);

        if (IS_PED_SHOOTING(PLAYER::PLAYER_PED_ID()) && !modelSpawned)
        {
            Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
            Hash model = GAMEPLAY::GET_HASH_KEY("headburst");
            STREAMING::REQUEST_MODEL(model);
            if (STREAMING::HAS_MODEL_LOADED(model))
            {
                Object obj = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, true, true, false);
                ENTITY::ATTACH_ENTITY_TO_ENTITY(obj, PLAYER::PLAYER_PED_ID(), PED::GET_PED_BONE_INDEX(PLAYER::PLAYER_PED_ID(), 31086), 
                                                0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 
                                                true, true, false, true, 1, true);
                modelSpawned = true;
            }
        }
        else if (!IS_PED_SHOOTING(PLAYER::PLAYER_PED_ID()))
        {
            modelSpawned = false; // allow respawn on next shot
        }

        WAIT(0);
    }
}

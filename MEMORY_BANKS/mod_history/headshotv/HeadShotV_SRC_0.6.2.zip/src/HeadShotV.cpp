// HeadShotV.cpp - v0.6.2 draw text test
#include "script.h"
#include "inc/natives.h"

void drawText(const char* text, float x, float y) {
    UI::_SET_TEXT_ENTRY("STRING");
    UI::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
    UI::DRAW_TEXT(x, y);
}

void ScriptMain() {
    while (true) {
        drawText("iammrmikeman", 0.015f, 0.805f); // Appears above radar
        WAIT(0);
    }
}

// HeadShotV.h - v0.6.2 header

#pragma once
#include "types.h"
namespace PLAYER { int PLAYER_PED_ID(); }
namespace ENTITY { bool IS_ENTITY_DEAD(int entity); }
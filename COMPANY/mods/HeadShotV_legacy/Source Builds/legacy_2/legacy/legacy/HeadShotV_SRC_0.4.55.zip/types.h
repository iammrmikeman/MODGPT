#pragma once
typedef int Ped;
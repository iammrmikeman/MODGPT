#include "inc/script.h"

extern "C" __declspec(dllexport) void ScriptMain()
{
    while (true)
    {
        WAIT(0);
    }
}

#include "inc/natives.h"
#include "inc/types.h"
#include "inc/script.h"
#include <Windows.h>
#define VK_J 0x4A

#include "inc/script.h"
#include "../inc/keyboard.h"
#include "inc/natives.h"
#include "inc/types.h"
#include "../inc/main.h"

#include <fstream>
#include <string>

BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD fdwReason, LPVOID lpReserved)
{
    return TRUE;
}

bool showDebug = true;
const char* iniPath = "E:\\Grand Theft Auto V Enhanced\\Gore.ini";

void debugMessage(const std::string& msg) {
    if (!showDebug) return;
    _SET_NOTIFICATION_TEXT_ENTRY("STRING");
    ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME((char*)msg.c_str());
    _DRAW_NOTIFICATION(false, false);
}

void loadSettings() {
    std::ifstream file(iniPath);
    if (file.good()) {
        std::string line;
        while (std::getline(file, line)) {
            if (line.find("Debug=") != std::string::npos) {
                std::string value = line.substr(line.find("=") + 1);
                showDebug = (value == "1" || value == "true");
            }
        }
    } else {
        std::ofstream outfile(iniPath);
        outfile << "Debug=1\n";
    }
}

void attachGoreToPed(Ped ped) {
    Hash modelHash = GET_HASH_KEY("lovely");
    REQUEST_MODEL(modelHash);
    while (!HAS_MODEL_LOADED(modelHash)) WAIT(0);

    Any boneIndex;
    if (!GET_PED_LAST_DAMAGE_BONE(ped, &boneIndex)) return;

    Vector3 pos = GET_PED_BONE_COORDS(ped, boneIndex, 0.0f, 0.0f, 0.0f);
    Object goreObj = CREATE_OBJECT(modelHash, pos.x, pos.y, pos.z, true, true, true);

    ATTACH_ENTITY_TO_ENTITY(
        goreObj, ped, boneIndex,
        0.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.0f,
        false, false, false, false, 2, true
    );

    debugMessage("Gore model Spawned.");
}

int main() {
    loadSettings();
    debugMessage("HeadShotV by iammrmikeman");

    while (true) {
        if (IsKeyJustUp(VK_J)) {
            showDebug = !showDebug;
            debugMessage(showDebug ? "Debug mode enabled" : "Debug mode disabled");
        }

        Ped player = PLAYER_PED_ID();
        const int maxPeds = 32;
        Ped peds[maxPeds];
        int count = GET_PED_NEARBY_PEDS(player, peds, -1);

        for (int i = 0; i < count; i++) {
            Ped ped = peds[i];
            if (!DOES_ENTITY_EXIST(ped) || ped == player || IS_PED_DEAD_OR_DYING(ped, true))
                continue;

            if (HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY(ped, player, true)) {
                attachGoreToPed(ped);
                CLEAR_ENTITY_LAST_DAMAGE_ENTITY(ped);
            }
        }

        WAIT(0);
    }
}

void ScriptMain() {
    main();
}
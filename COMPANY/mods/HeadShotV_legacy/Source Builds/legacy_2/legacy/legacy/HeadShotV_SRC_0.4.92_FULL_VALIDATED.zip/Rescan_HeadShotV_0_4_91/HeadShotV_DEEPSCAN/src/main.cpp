// main.cpp - Entry point
#include "inc/natives.h"
void ScriptMain() {}

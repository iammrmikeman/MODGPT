#include "inc/autoDeclarations.h"
#include "inc/natives.h"
#include "inc/types.h"
#include "inc/natives.h"
#include "inc/types.h"

#include "inc/script.h"

void processGoreEffects()
{
    Ped playerPed = PLAYER::PLAYER_PED_ID();
    if (!ENTITY::DOES_ENTITY_EXIST(playerPed)) return;

    if (PED::IS_PED_SHOOTING(playerPed))
    {
        Vector3 coords = ENTITY::GET_ENTITY_COORDS(playerPed, true);
        Object lovely = OBJECT::CREATE_OBJECT(MISC::GET_HASH_KEY("lovely"), coords.x, coords.y, coords.z, true, true, true);
        ENTITY::ATTACH_ENTITY_TO_ENTITY(lovely, playerPed, PED::GET_PED_BONE_INDEX(playerPed, 31086),
                                        0.0f, 0.0f, 0.0f,
                                        0.0f, 0.0f, 0.0f,
                                        true, true, false, false, 2, true);
    }
}
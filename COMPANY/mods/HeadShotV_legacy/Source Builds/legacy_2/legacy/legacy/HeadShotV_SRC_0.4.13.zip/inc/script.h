#pragma once

// Shared declarations from script.cpp
void HandleSkullEffect(Ped ped);

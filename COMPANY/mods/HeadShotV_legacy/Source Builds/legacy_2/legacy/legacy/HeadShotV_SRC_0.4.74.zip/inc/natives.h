#pragma once
#include "types.h"

#define PLAYER_PED_ID() (0)

inline void CLEAR_ENTITY_LAST_DAMAGE_ENTITY(Entity entity) {}
inline void ATTACH_ENTITY_TO_ENTITY(Entity e1, Entity e2, float x, float y, float z, float pitch, float roll, float yaw, int p9, int useSoftPinning, int collision, int isPed, int vertexIndex, int fixedRot) {}
inline void REQUEST_MODEL(Hash model) {}
inline bool HAS_MODEL_LOADED(Hash model) { return true; }
inline void SET_ENTITY_VISIBLE(Entity entity, bool toggle, bool unk) {}
inline void SET_ENTITY_INVINCIBLE(Entity entity, bool toggle) {}
inline void SET_ENTITY_PROOFS(Entity entity, bool bulletProof, bool fireProof, bool explosionProof, bool collisionProof, bool meleeProof, bool p7, bool drownProof) {}
inline void SET_ENTITY_CAN_BE_DAMAGED(Entity entity, bool toggle) {}
inline Hash GET_HASH_KEY(const char* name) { return 0; }
inline Vector3 GET_PED_BONE_COORDS(Ped ped, int boneId, float offsetX, float offsetY, float offsetZ) { return {0.0f, 0.0f, 0.0f}; }
inline Entity CREATE_OBJECT(Hash modelHash, float x, float y, float z, bool isNetworked, bool dynamic, bool p7) { return 0; }
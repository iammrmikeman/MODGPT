#pragma once
typedef int Entity;
typedef int Ped;
typedef int Hash;

struct Vector3 {
    float x, y, z;
};
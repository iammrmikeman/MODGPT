#include "natives.h"
#include "types.h"
#include "logger.h"

void SpawnGoreEffect(Ped ped)
{
    logger::log("Spawning gore effect on ped");
}
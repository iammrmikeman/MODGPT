// script.h
#pragma once
void ScriptMain();

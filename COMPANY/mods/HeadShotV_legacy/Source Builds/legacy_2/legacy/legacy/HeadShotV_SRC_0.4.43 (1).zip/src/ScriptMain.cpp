#include "inc/natives.h"
#include "inc/types.h"
#include "inc/logger.h"

void ScriptMain()
{
    logger::log("Script started...");
    while (true)
    {
        WAIT(0);
    }
}
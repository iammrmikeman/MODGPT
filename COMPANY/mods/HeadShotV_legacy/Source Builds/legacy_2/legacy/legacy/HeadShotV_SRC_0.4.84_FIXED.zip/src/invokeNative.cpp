#include "inc/nativeCaller.h"
#include "inc/types.h"
#include "inc/natives.h"

NativeReturn invokeNative(uint64_t hash, const std::vector<NativeArg>& args, NativeReturnType returnType)
{
    // Simplified placeholder; implement real SHV routing if needed
    return NativeReturn{};
}
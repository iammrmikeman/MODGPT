#include "inc/natives.h"

// Real invokeNative implementation
void* invokeNative(uint64_t hash, void* args, int argCount)
{
    // Logic for real native call routing
    return nullptr;
}
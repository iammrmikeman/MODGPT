#pragma once

#include <stdint.h>
#include "types.h"

void* invokeNative(uint64_t hash, void* args, int argCount);
void WAIT(int ms);
#include "inc/natives.h"
#include "inc/types.h"

void ScriptMain()
{
    while (true)
    {
        WAIT(0);
        // Main mod logic goes here
    }
}
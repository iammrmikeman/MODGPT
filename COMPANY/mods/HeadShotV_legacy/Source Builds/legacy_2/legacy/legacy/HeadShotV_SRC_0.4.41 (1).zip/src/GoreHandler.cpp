#include "inc/natives.h"
#include "inc/types.h"

void SpawnGoreEffect(Ped ped)
{
    // Code to attach 'headburst.ydr' to ped bone
}
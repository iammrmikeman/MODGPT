// main.cpp
#include "inc/natives.h"
#include "inc/nativeCaller.h"
#include "inc/script.h"

void ScriptMain() {
    // Entry logic
}

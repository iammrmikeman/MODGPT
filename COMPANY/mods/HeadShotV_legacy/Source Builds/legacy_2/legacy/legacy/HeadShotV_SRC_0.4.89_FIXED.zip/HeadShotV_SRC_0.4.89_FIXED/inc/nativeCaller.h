// nativeCaller.h
#pragma once
void invokeNative(DWORD hash, void* args, int argCount);

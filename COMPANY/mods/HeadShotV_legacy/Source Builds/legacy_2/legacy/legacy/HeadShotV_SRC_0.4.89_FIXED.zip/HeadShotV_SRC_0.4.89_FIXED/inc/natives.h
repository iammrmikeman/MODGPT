// natives.h
#pragma once
#include <windows.h>
void someNativeFunction();

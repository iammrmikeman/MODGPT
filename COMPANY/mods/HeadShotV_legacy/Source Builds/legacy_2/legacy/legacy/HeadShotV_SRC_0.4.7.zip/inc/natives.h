#pragma once

#include "types.h"

Hash GET_HASH_KEY(const char* name);
void REQUEST_MODEL(Hash model);
bool HAS_MODEL_LOADED(Hash model);
Object CREATE_OBJECT(Hash modelHash, float x, float y, float z, bool isNetwork, bool dynamic, bool p6);
void ATTACH_ENTITY_TO_ENTITY(Entity entity1, Entity entity2, int boneIndex,
    float xPos, float yPos, float zPos,
    float xRot, float yRot, float zRot,
    bool p9, bool useSoftPinning, bool collision, bool isPed, int vertexIndex, bool fixedRot);
void CLEAR_ENTITY_LAST_DAMAGE_ENTITY(Entity entity);
bool HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY(Entity entity1, Entity entity2, bool p2);
bool IS_PED_DEAD_OR_DYING(Ped ped, bool p1);
bool DOES_ENTITY_EXIST(Entity entity);
void GET_PED_NEARBY_PEDS(Ped ped, Ped* sizeAndPeds, int size);
Ped PLAYER_PED_ID();
void _SET_NOTIFICATION_TEXT_ENTRY(const char* type);
void ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(const char* text);
void _DRAW_NOTIFICATION(bool blink);
bool GET_PED_LAST_DAMAGE_BONE(Ped ped, int* outBone);
Vector3 GET_PED_BONE_COORDS(Ped ped, int boneIndex, float offsetX, float offsetY, float offsetZ);

#include "script.h"
#include "nativeCaller.h"

namespace PLAYER {
	Player PLAYER_PED_ID() {
		return invoke<Player>(0xD80958FC74E988A6); // PLAYER_PED_ID
	}
}

namespace ENTITY {
	BOOL DOES_ENTITY_EXIST(Entity entity) {
		return invoke<BOOL>(0x7239B21A38F536BA, entity);
	}
	BOOL HAS_ENTITY_BEEN_DAMAGED_BY_ENTITY(Entity target, Entity attacker, BOOL p2) {
		return invoke<BOOL>(0x05C907E3D2C29DE1, target, attacker, p2);
	}
	void CLEAR_ENTITY_LAST_DAMAGE_ENTITY(Entity entity) {
		invoke<void>(0xA72CD8A4FDEB9C9D, entity);
	}
	void ATTACH_ENTITY_TO_ENTITY(Entity entity1, Entity entity2, int boneIndex,
		float xPos, float yPos, float zPos,
		float xRot, float yRot, float zRot,
		BOOL p9, BOOL useSoftPinning, BOOL collision, BOOL isPed, int vertexIndex, BOOL fixedRot) {
		invoke<void>(0x6B9BBD38AB0796DF, entity1, entity2, boneIndex, xPos, yPos, zPos,
			xRot, yRot, zRot, p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot);
	}
}

namespace PED {
	BOOL IS_PED_DEAD_OR_DYING(Ped ped, BOOL p1) {
		return invoke<BOOL>(0x3317DEDB88C95038, ped, p1);
	}
	int GET_PED_NEARBY_PEDS(Ped ped, int* peds, int count) {
		return invoke<int>(0x23F8F5FC7E8C4A6B, ped, peds, count);
	}
	BOOL GET_PED_LAST_DAMAGE_BONE(Ped ped, Any* outBone) {
		return invoke<BOOL>(0xD75960F6BD9EA49C, ped, outBone);
	}
	Vector3 GET_PED_BONE_COORDS(Ped ped, int boneIndex, float offsetX, float offsetY, float offsetZ) {
		return invoke<Vector3>(0x17C07FC640E86B4E, ped, boneIndex, offsetX, offsetY, offsetZ);
	}
}

namespace OBJECT {
	Object CREATE_OBJECT(Hash modelHash, float x, float y, float z, BOOL isNetwork, BOOL bScriptHostObj, BOOL dynamic) {
		return invoke<Object>(0x509D5878EB39E842, modelHash, x, y, z, isNetwork, bScriptHostObj, dynamic);
	}
}

namespace STREAMING {
	void REQUEST_MODEL(Hash model) {
		invoke<void>(0x963D27A58DF860AC, model);
	}
	BOOL HAS_MODEL_LOADED(Hash model) {
		return invoke<BOOL>(0x98A4EB5D89A0C952, model);
	}
}

namespace GAMEPLAY {
	Hash GET_HASH_KEY(const char* str) {
		return invoke<Hash>(0xD24D37CC275948CC, str);
	}
}

namespace UI {
	void _SET_NOTIFICATION_TEXT_ENTRY(const char* type) {
		invoke<void>(0x202709F4C58A0424, type);
	}
	void ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(const char* text) {
		invoke<void>(0x6C188BE134E074AA, text);
	}
	void _DRAW_NOTIFICATION(BOOL blink, BOOL p1) {
		invoke<void>(0x2ED7843F8F801023, blink, p1);
	}
}
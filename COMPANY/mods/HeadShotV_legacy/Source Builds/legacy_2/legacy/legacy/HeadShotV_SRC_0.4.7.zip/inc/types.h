#pragma once

typedef unsigned int Hash;
typedef int Any;
typedef int Player;
typedef int Ped;
typedef int Vehicle;
typedef int Entity;
typedef float float32;

typedef struct
{
    float x;
    float y;
    float z;
} Vector3;

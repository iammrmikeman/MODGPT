
#pragma once

typedef int Entity;
typedef int Ped;
typedef int Object;
typedef unsigned int Hash;

#include "script.h"
#include "../inc/script.h"

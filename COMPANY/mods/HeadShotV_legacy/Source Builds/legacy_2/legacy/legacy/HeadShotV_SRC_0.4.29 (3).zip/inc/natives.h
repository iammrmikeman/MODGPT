// Placeholder: native functions

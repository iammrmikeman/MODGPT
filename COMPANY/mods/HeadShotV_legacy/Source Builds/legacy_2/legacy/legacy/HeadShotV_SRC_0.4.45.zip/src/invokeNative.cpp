#include "natives.h"
#include "logger.h"

void* invokeNative(uint64_t hash, void* args, int argCount)
{
    logger::log("Invoking native");
    return nullptr;
}
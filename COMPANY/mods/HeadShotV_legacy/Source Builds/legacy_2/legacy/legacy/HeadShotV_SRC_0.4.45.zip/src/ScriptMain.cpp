#include "natives.h"
#include "types.h"
#include "logger.h"

void ScriptMain()
{
    logger::log("Script started...");
    while (true)
    {
        WAIT(0);
    }
}
#include "inc/natives.h"
#include "inc/types.h"
#include "inc/script.h"

// Placeholder for native calling logic

#include "inc/script.h"
#include "inc/types.h"
#include "inc/natives.h"
#include "inc/GoreHandler.h"

void ScriptMain()
{
    while (true)
    {
        processGoreEffects();
        WAIT(0);
    }
}
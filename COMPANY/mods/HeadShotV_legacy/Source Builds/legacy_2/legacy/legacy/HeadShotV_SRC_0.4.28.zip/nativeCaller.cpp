#include "inc/natives.h"
#include "inc/types.h"
#include "inc/script.h"

// Native function stubs replaced during 0.4.19 cleanup
// TODO: Re-implement using invokeNative<>() calls properly

void Stub_NativeFunction1() {
    // invokeNative<ReturnType>(hash, args...);
}

void Stub_NativeFunction2() {
    // Example: Vector3 coords = invokeNative<Vector3>(0x17C07FC640E86B4E, ped, boneIndex);
}
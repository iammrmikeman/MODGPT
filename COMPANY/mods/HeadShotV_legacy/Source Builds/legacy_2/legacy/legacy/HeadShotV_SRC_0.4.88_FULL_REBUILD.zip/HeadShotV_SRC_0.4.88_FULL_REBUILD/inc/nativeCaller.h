// nativeCaller.h - Handles low-level SHV native invocation
#pragma once

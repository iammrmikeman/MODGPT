// script.h - Script entry and control
#pragma once

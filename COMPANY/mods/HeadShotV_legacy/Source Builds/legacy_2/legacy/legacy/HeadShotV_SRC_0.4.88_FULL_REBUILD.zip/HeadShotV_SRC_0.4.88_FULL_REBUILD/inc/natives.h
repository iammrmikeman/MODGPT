// natives.h - Game native definitions
#pragma once

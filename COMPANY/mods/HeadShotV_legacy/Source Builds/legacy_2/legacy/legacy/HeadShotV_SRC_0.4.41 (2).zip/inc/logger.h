#pragma once
#include <string>
namespace logger {
    inline void log(const std::string& msg) {
        // Stub logger, could print to file or console
    }
}
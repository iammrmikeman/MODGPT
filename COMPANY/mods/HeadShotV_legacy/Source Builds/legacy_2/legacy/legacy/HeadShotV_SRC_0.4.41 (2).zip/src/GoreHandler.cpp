#include "inc/natives.h"
#include "inc/types.h"
#include "inc/logger.h"

void SpawnGoreEffect(Ped ped)
{
    logger::log("Spawning gore effect on ped " + std::to_string(ped));
    // Spawn and attach gore model logic here
}
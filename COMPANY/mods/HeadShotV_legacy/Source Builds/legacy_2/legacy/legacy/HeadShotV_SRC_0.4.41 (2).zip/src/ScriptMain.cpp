#include "inc/natives.h"
#include "inc/types.h"
#include "inc/logger.h"

void ScriptMain()
{
    logger::log("HeadShotV: Script started.");

    while (true)
    {
        WAIT(0);
        // Actual skull burst logic would go here
    }
}
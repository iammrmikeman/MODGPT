#include "inc/natives.h"
#include "inc/logger.h"

void* invokeNative(uint64_t hash, void* args, int argCount)
{
    logger::log("Invoking native: " + std::to_string(hash));
    // Real SHV-style routing would go here
    return nullptr;
}
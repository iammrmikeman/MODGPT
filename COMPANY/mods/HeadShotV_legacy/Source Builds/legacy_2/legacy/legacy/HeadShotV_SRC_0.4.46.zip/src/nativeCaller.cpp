#include "natives.h"
#include "types.h"
#include "script.h"

// Placeholder for native calling logic

#pragma once
#include <windows.h>

extern void ScriptWait(DWORD time);
#define WAIT(x) ScriptWait(x)

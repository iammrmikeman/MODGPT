# 🧠 HeadShotV

**Gore mod for GTA V Enhanced Edition**  
Brutal headshot effects. Skull bursts. Bone fragments. Just like Max Payne 3 and RDR2 — now in GTA V.

Built with **ScriptHookV** and real native function hooks. No reskins. No fluff.  
This is pure cinematic violence at engine level.

---

## ⚙️ Requirements

- GTA V (Enhanced Edition)
- [ScriptHookV](http://www.dev-c.com/gtav/scripthookv/)
- ASI Loader (comes with ScriptHookV)

---

## 📁 Installation

Drop `HeadShotV.asi` into your GTA V root folder.  
Make sure `headburst.ydr` is installed in your streaming path (comes with mod under `/Models/`).

---

## 📧 Support & Contact

Need help? Found a bug?  
Email: **iammrmikeman25@gmail.com**

---

## ❗ Disclaimer

This mod is unfinished and experimental.  
Use at your own risk. Expect blood, broken things, and unexpected results.

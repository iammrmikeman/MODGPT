#pragma once

// Shared declarations from script.cpp if any
void HandleSkullEffect(Ped ped);

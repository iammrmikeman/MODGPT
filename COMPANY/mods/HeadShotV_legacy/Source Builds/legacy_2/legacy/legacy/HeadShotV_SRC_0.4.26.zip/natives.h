
#pragma once

#include "types.h"

Object CREATE_OBJECT(Hash model, float x, float y, float z, bool isNetworked, bool thisScriptCheck);
void ATTACH_ENTITY_TO_ENTITY(Object object, Entity target, int boneIndex, float x, float y, float z, float pitch, float roll, float yaw, bool collision, bool isPed, bool fixedRot, bool vertexAttachment, int rotationOrder, bool useSoftPinning);
Vector3 GET_PED_BONE_COORDS(Ped ped, int boneIndex, int flags);

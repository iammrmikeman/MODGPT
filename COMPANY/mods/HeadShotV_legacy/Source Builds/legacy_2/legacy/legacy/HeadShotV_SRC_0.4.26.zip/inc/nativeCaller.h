#include <type_traits>
#include <type_traits>
#pragma once
#include <cstdint>

void* invokeNative(uint64_t hash);

// For non-void return types
template <typename R, typename... Args>
inline typename std::enable_if<!std::is_void<R>::value, R>::type
invoke(uint64_t hash, Args... args) {
    auto fn = reinterpret_cast<R(*)(Args...)>(invokeNative(hash));
    return fn(args...);
}

// For void return types
template <typename R = void, typename... Args>
inline typename std::enable_if<std::is_void<R>::value, void>::type
invoke(uint64_t hash, Args... args) {
    auto fn = reinterpret_cast<void(*)(Args...)>(invokeNative(hash));
    fn(args...);
}
#pragma once
#include <Windows.h>

inline bool IsKeyDown(int vKey) {
    return (GetAsyncKeyState(vKey) & 0x8000) != 0;
}

inline bool IsKeyJustUp(int vKey) {
    static SHORT previousState[256] = {};
    SHORT currentState = GetAsyncKeyState(vKey);
    bool wasDown = (previousState[vKey] & 0x8000) != 0;
    bool isUpNow = (currentState & 0x8000) == 0;
    previousState[vKey] = currentState;
    return wasDown && isUpNow;
}
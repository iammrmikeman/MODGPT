
// MODGPT: Floating Inbox Renderer Logic
// Adds a 📧 mail icon to topbar. Opens the floating inbox panel. Clean, no Windows, all glass!

// Add mail icon to topbar after DOM loaded
window.addEventListener("DOMContentLoaded", () => {
  const tb = document.getElementById("topbar");
  if (!tb) return;
  // Only add if not present
  if (tb.querySelector(".mail-trigger-icon")) return;
  const mail = document.createElement("span");
  mail.className = "mail-trigger-icon";
  mail.title = "Open Inbox";
  mail.style.cssText = "margin-left:24px; font-size:1.8em; cursor:pointer; user-select:none; vertical-align:middle;";
  mail.innerHTML = "📧";
  mail.onclick = openFloatingInbox;
  tb.appendChild(mail);
});

// Floating inbox open logic
export function openFloatingInbox() {
  // Only allow one at a time
  let prev = document.getElementById("modgpt-inbox-float-panel");
  if (prev) return prev.focus();
  import('./views/emails_inboxView.js').then(mod => {
    const panel = mod.default();
    panel.id = "modgpt-inbox-float-panel";
    document.body.appendChild(panel);
    panel.focus();
    // Add close X button (styled pill)
    const closer = document.createElement("button");
    closer.textContent = "X";
    closer.className = "inbox-close-btn";
    closer.onclick = () => panel.remove();
    closer.title = "Close Inbox";
    // Position top right
    closer.style.position = "absolute";
    closer.style.top = "24px";
    closer.style.right = "32px";
    panel.appendChild(closer);
  });
}

// Attach global so inline HTML/other JS can open inbox easily
window.openFloatingInbox = openFloatingInbox;

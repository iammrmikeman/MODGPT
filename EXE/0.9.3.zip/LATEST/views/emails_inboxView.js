
// MODGPT Floating Glass Inbox Panel
export default function emails_inboxView(props = {}) {
  const container = document.createElement("div");
  container.className = "panel emails-panel email-inbox-flex inbox-float-panel glass-panel";
  container.style.minWidth = "700px";
  container.style.minHeight = "340px";
  container.style.maxWidth = "90vw";
  container.style.maxHeight = "90vh";
  container.style.padding = "32px 44px 32px 28px";
  container.style.borderRadius = "28px";
  container.style.overflow = "visible";
  container.tabIndex = -1;

  // Left: Inbox List
  const inboxPanel = document.createElement("div");
  inboxPanel.className = "email-inbox-panel glass-panel";

  const header = document.createElement("h1");
  header.className = "email-inbox-header";
  header.textContent = "Inbox";
  inboxPanel.appendChild(header);

  const intro = document.createElement("p");
  intro.className = "email-inbox-intro";
  intro.textContent = "You have 3 unread emails.";
  inboxPanel.appendChild(intro);

  const emailList = document.createElement("ul");
  emailList.className = "email-inbox-list";

  // Sample email data
  const emails = [
    {
      from: "System",
      subject: "Welcome to MODGPT.EXE",
      preview: "Let's get you set up…",
      body: "Welcome, Commander. Your AI system is ready to deploy. Let's begin configuration..."
    },
    {
      from: "Swarm Control",
      subject: "New AI Worker Registered",
      preview: "Worker #121 online.",
      body: "Worker #121 has been registered and is now operational in the Swarm subsystem. Monitor status in the dashboard."
    },
    {
      from: "Security",
      subject: "Memory Update Validated",
      preview: "Platinum Core update trusted.",
      body: "Platinum Core memory update has passed all trust validation checks. No issues detected. System is green."
    }
  ];

  // Right: Message view
  const messagePanel = document.createElement("div");
  messagePanel.className = "email-message-panel glass-panel";

  // Helper: render message for given index
  function renderMessage(idx) {
    const email = emails[idx];
    messagePanel.innerHTML = "";
    const sender = document.createElement("div");
    sender.className = "email-message-sender";
    sender.textContent = "From: " + email.from;
    messagePanel.appendChild(sender);

    const subject = document.createElement("div");
    subject.className = "email-message-subject";
    subject.textContent = email.subject;
    messagePanel.appendChild(subject);

    const body = document.createElement("div");
    body.className = "email-message-body";
    body.textContent = email.body;
    messagePanel.appendChild(body);

    // Reply Button
    const footer = document.createElement("div");
    footer.className = "email-message-footer";
    const replyBtn = document.createElement("button");
    replyBtn.className = "reply-btn pill-btn";
    replyBtn.textContent = "Reply";
    replyBtn.onclick = () => {
      alert("Reply logic coming soon!");
    };
    footer.appendChild(replyBtn);
    messagePanel.appendChild(footer);
  }

  // Create each email card
  let selectedIdx = 0;
  emails.forEach((email, idx) => {
    const li = document.createElement("li");
    li.className = "email-inbox-card";
    if (idx === selectedIdx) li.classList.add("active");

    const sender = document.createElement("div");
    sender.className = "email-inbox-sender";
    sender.textContent = email.from;

    const subject = document.createElement("div");
    subject.className = "email-inbox-title";
    subject.textContent = email.subject;

    const preview = document.createElement("div");
    preview.className = "email-inbox-preview";
    preview.textContent = email.preview;

    li.appendChild(sender);
    li.appendChild(subject);
    li.appendChild(preview);

    li.onclick = () => {
      Array.from(emailList.children).forEach(n => n.classList.remove("active"));
      li.classList.add("active");
      selectedIdx = idx;
      renderMessage(idx);
    };

    emailList.appendChild(li);
  });

  inboxPanel.appendChild(emailList);
  container.appendChild(inboxPanel);
  container.appendChild(messagePanel);
  renderMessage(selectedIdx);

  return container;
}

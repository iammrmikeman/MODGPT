
document.addEventListener("DOMContentLoaded", () => {
  console.log("Boot UI loaded.");
});

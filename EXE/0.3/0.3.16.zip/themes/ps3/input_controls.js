
function scrollToCategory(category) {
  alert("Scroll to: " + category); // Replace with animation logic
}

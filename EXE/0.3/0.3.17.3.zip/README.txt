MODGPT.EXE v0.4 Core Restore

Drop these files into your MODGPT/EXE/0.3/0.3.0 directory.
Run launch_dashboard_r7_clean.bat
Enjoy.
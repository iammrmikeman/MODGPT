document.addEventListener("DOMContentLoaded", async () => {
  await tsParticles.load("tsparticles", {
    fullScreen: { enable: false },
    background: { color: "#000000" },
    particles: {
      number: { value: 15 },
      color: { value: "#ff0040" },
      opacity: { value: 0.05 },
      size: { value: 2 },
      move: { enable: true, speed: 0.2 },
      shape: { type: "circle" }
    }
  });
});

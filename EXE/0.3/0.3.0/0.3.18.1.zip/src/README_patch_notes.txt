# MODGPT EXE v0.2.0a Hotfix

Fixes:
- Boot logo now perfectly centered
- Wave canvas visibility fixed
- Audio safely disabled if assets are missing
- UI animations improved (logo + XMB)


window.folderMap = {
  "EMAILS": ["Inbox", "Sent", "Compose"],
  "COMPANY": ["Boss GPT", "Art Department", "Script Department", "Design Department", "Audio Department", "Quality Assurance", "Marketing & PR"],
  "SPEC OPS": ["Governmental Logic Unit", "RockstarGPT", "Trusted Memory Handler", "Mission-Critical Utilities"],
  "MEMORY LOGS": ["Short-Term Memory Log", "Long-Term Archives", "Memory Snapshots", "Error Logs & Black Box"],
  "TRUSTED BUILDS": ["Latest Stable Build", "Internal Beta Build", "Archived Builds", "Memory Archive Zips"],
  "THEMES": ["Default PS3 Theme", "Retro PS2 Theme", "Next-Gen Theme", "Custom Dev Theme"],
  "MODGPT": ["Launch Simulation", "System Dashboard", "Auto-Update"]
};

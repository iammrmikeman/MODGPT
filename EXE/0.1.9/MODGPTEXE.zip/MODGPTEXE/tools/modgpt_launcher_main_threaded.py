"""
MODGPT Launcher Main Threaded
Unified GUI, API key handling, threading scan, dark XMB style.
"""

import os
import json
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext
import threading
import webbrowser
import openai

CONFIG_FILE = "modgpt_config.json"
MODEL_NAME = "gpt-4"

def get_api_key():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f).get("api_key", "")
        except:
            pass

    def save_key_and_close():
        key = key_entry.get().strip()
        if key:
            with open(CONFIG_FILE, "w") as f:
                json.dump({"api_key": key}, f)
            api_prompt.destroy()
            main()
        else:
            messagebox.showerror("Missing API Key", "You must enter an OpenAI API key.")

    def open_openai_key_page():
        webbrowser.open("https://platform.openai.com/account/api-keys")

    api_prompt = tk.Tk()
    api_prompt.title("Enter OpenAI API Key")
    api_prompt.configure(bg="#111111")
    api_prompt.geometry("500x200")

    tk.Label(api_prompt, text="🔐 Enter your OpenAI API key:", fg="white", bg="#111111").pack(pady=10)
    key_entry = tk.Entry(api_prompt, width=60, show="*", bg="#222222", fg="white", insertbackground="white")
    key_entry.pack(pady=5)

    tk.Button(api_prompt, text="Get Key Online", command=open_openai_key_page, bg="#990000", fg="white").pack(pady=5)
    tk.Button(api_prompt, text="Save and Continue", command=save_key_and_close, bg="#555555", fg="white").pack(pady=5)

    api_prompt.mainloop()
    return None

def classify_file(filepath, client):
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except Exception as e:
        return {"path": filepath, "error": str(e)}

    prompt = f"""You are a MODGPT memory classifier. Return:
- path
- type (e.g. python_script, markdown_doc)
- purpose (1-line purpose)
- tags (e.g. trusted, build, doctrine)
- trust_level (critical, optional, untrusted)

Path: {filepath}
Content:
---
{content}
---"""

    try:
        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        parsed = json.loads(response.choices[0].message.content)
        return parsed
    except Exception as e:
        return {"path": filepath, "error": str(e)}

def walk_and_classify(target_dir, log_callback, client):
    results = []
    log_callback(f"🔍 Scanning folder: {target_dir}\n")
    for root, dirs, files in os.walk(target_dir):
        for file in files:
            if file.endswith((".md", ".py", ".txt", ".json")):
                full_path = os.path.join(root, file)
                log_callback(f"→ {full_path}\n")
                result = classify_file(full_path, client)
                results.append(result)
    if not results:
        log_callback("⚠️ No valid files found.\n")
    return results

def threaded_scan(client):
    folder = folder_path.get()
    if not folder or not os.path.exists(folder):
        messagebox.showerror("Invalid Folder", "Please select a valid MODGPT folder.")
        return

    log_output.delete("1.0", tk.END)
    scan_button.config(state=tk.DISABLED)
    browse_button.config(state=tk.DISABLED)

    def run():
        results = walk_and_classify(folder, lambda text: log_output.insert(tk.END, text), client)
        output_folder = os.path.join(folder, "system")
        os.makedirs(output_folder, exist_ok=True)
        output_file = os.path.join(output_folder, "classified_file_index.json")
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        log_output.insert(tk.END, f"✅ Done. Saved to: {output_file}\n")
        scan_button.config(state=tk.NORMAL)
        browse_button.config(state=tk.NORMAL)

    threading.Thread(target=run).start()

def main():
    api_key = get_api_key()
    if not os.path.exists(CONFIG_FILE):
        return
    with open(CONFIG_FILE, "r") as f:
        api_key = json.load(f).get("api_key", "")

    if not api_key:
        return

    client = openai.OpenAI(api_key=api_key)

    global root, folder_path, log_output, scan_button, browse_button
    root = tk.Tk()
    root.title("MODGPT All-In-One Classifier (Threaded, Dark XMB Style)")
    root.configure(bg="#111111")
    root.geometry("700x520")

    tk.Label(root, text="Select your MODGPT folder:", fg="white", bg="#111111").pack(pady=5)
    frame = tk.Frame(root, bg="#111111")
    frame.pack()

    folder_path = tk.StringVar()
    entry = tk.Entry(frame, textvariable=folder_path, width=60, bg="#222222", fg="white", insertbackground="white")
    entry.pack(side=tk.LEFT, padx=5)

    browse_button = tk.Button(frame, text="Browse", command=lambda: folder_path.set(filedialog.askdirectory()),
                              bg="#990000", fg="white")
    browse_button.pack(side=tk.LEFT)

    scan_button = tk.Button(root, text="🧠 Start Scan", command=lambda: threaded_scan(client),
                            bg="#333333", fg="white")
    scan_button.pack(pady=10)

    log_output = scrolledtext.ScrolledText(root, height=22, bg="#000000", fg="lime", insertbackground="white")
    log_output.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

    root.mainloop()

main()

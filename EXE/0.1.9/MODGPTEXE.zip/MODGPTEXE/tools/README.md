
# MODGPT GUI Launcher (Fixed)

## Build Instructions:
1. Make sure you're in the same directory as modgpt_xmb_logo.ico
2. Open terminal in /tools/
3. Run:
   build_launcher_xmb.bat

✅ This version uses a **relative icon path** so it won't break after unzip.

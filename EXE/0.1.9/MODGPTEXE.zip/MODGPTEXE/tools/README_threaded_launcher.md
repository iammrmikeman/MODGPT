
# MODGPT Threaded Launcher

## Build Instructions:
1. Install dependencies:
   pip install openai pyinstaller

2. Open terminal in /tools/
3. Run:
   build_launcher_threaded.bat

## What it does:
- Dark XMB style GUI
- API key prompt + save
- Threaded scan for non-freeze
- Output saved in system/classified_file_index.json

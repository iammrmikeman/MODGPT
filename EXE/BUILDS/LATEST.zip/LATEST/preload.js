// No-op for now; used to expose APIs later


README: MODGPT LATEST PATCH
--------------------------
- All JS panel/component files must be inside /views/
- Only layoutLoader.js, renderEngine.js, index.html are in the root.
- index.html should load layoutLoader.js as a module.
- layoutLoader.js should import layoutView from './views/layoutView.js'.
- renderEngine.js should import panels/views from './views/*.js'.
- There should be NO duplicate panel .js files in root.
- If blank, check for JS syntax errors or wrong file paths.

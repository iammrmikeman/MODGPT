
export default function emails_inboxView(props = {}) {
  const container = document.createElement("div");
  container.className = "panel emails-panel";

  const header = document.createElement("h1");
  header.textContent = "Inbox";

  const intro = document.createElement("p");
  intro.textContent = "You have 3 unread emails.";

  const emailList = document.createElement("ul");
  emailList.style.listStyle = "none";
  emailList.style.padding = "0";

  const emails = [
    { from: "System", subject: "Welcome to MODGPT.EXE", preview: "Let’s get you set up…" },
    { from: "Swarm Control", subject: "New AI Worker Registered", preview: "Worker #121 online." },
    { from: "Security", subject: "Memory Update Validated", preview: "Platinum Core update trusted." }
  ];

  emails.forEach(email => {
    const li = document.createElement("li");
    li.style.marginBottom = "12px";
    li.style.padding = "8px";
    li.style.background = "rgba(255,255,255,0.05)";
    li.style.borderRadius = "8px";

    const title = document.createElement("div");
    title.textContent = `${email.from} — ${email.subject}`;
    title.style.fontWeight = "bold";

    const preview = document.createElement("div");
    preview.textContent = email.preview;
    preview.style.opacity = "0.75";

    li.appendChild(title);
    li.appendChild(preview);
    emailList.appendChild(li);
  });

  container.appendChild(header);
  container.appendChild(intro);
  container.appendChild(emailList);

  return container;
}

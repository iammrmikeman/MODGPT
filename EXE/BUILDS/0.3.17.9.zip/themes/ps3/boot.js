
tsParticles.load("disc-particles", {
  fullScreen: { enable: false },
  particles: {
    number: { value: 25 },
    size: { value: 3 },
    color: { value: "#00c3ff" },
    move: { enable: true, speed: 1 },
    opacity: { value: 0.6 },
  }
});


import React, { useState } from 'react';
import SettingsModal from './SettingsModal';

const folders = [
  { name: "EMAILS", glow: "#a463f2" },
  { name: "MEDIA", glow: "#63f27e" },
  { name: "PROJECTS", glow: "#f2c863" },
  { name: "MEMORY", glow: "#f26363" }
];

export default function ModGPTUI() {
  const [showSettings, setShowSettings] = useState(false);

  return (
    <div className="modgpt-container">
      <div className="sidebar">
        <div className="logo-section" onClick={() => setShowSettings(true)}>
          <img src="/icon_128_MODGPT_PERFECT.png" className="modgpt-logo" />
          <p className="logo-label">CLICK FOR API KEY</p>
        </div>
        {folders.map((folder, i) => (
          <div key={i} className="folder" style={{ "--glow": folder.glow } as React.CSSProperties }>
            <img src={`/${folder.name.toLowerCase()}_folder.png`} className="folder-icon" />
            <p className="folder-label">{folder.name}</p>
          </div>
        ))}
      </div>
      <div className="main-panel">
        <h1>🚨 MODGPT UI ONLINE</h1>
      </div>
      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} />}
    </div>
  );
}

# MODGPT EXE v0.3.18.0
This build introduces collapsible categories in the sidebar, styled in PS3/iOS fashion.
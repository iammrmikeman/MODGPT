window.addEventListener('DOMContentLoaded', () => {
  console.log('Preload active');
});
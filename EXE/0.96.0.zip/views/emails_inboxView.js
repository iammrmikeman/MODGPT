export default function emails_inboxView() {
  const contacts = [
    { name: "BossGPT", color: "#ff5e5e" },
    { name: "Team Leader A", color: "#4fc3f7" },
    { name: "Team Leader B", color: "#ba68c8" },
    { name: "SpecOps Commander", color: "#26c6da" },
    { name: "Director A", color: "#fbc02d" }
  ];

  const emails = [
    {
      from: "System",
      section: "System",
      sectionColor: "#64b5f6",
      subject: "Welcome to MODGPT.EXE",
      preview: "Let's get you set up…",
      body: "Welcome, Commander. Your AI system is ready to deploy. Let's begin configuration...",
      time: "10:42 AM"
    },
    {
      from: "Swarm Control",
      section: "Swarm",
      sectionColor: "#ba68c8",
      subject: "New AI Worker Registered",
      preview: "Worker #1112 online.",
      body: "Swarm worker #1112 is now operational and integrated into the system.",
      time: "9:15 AM"
    },
    {
      from: "Security",
      section: "Security",
      sectionColor: "#ef5350",
      subject: "Memory Update Validated",
      preview: "Platinum Core update trusted.",
      body: "The system memory has been validated. No anomalies detected. Trust score: 100%.",
      time: "Yesterday"
    }
  ];

  let selectedIdx = 0;
  const outer = document.createElement("div");
  outer.className = "modinbox-grid";

  // Floating Contacts Card
  const contactsCard = document.createElement("div");
  contactsCard.className = "modinbox-contacts-wrapper-card";
  
  const contactsTitle = document.createElement("div");
  contactsTitle.className = "modinbox-contacts-title";
  contactsTitle.textContent = "Contacts";
  contactsCard.appendChild(contactsTitle);
  
  const contactsList = document.createElement("div");
  contactsList.className = "modinbox-contacts";
  
  contacts.forEach(c => {
    const contact = document.createElement("div");
    contact.className = "modinbox-contact-pill";
    
    const dot = document.createElement("span");
    dot.className = "pill-dot";
    dot.style.backgroundColor = c.color;
    
    const name = document.createElement("span");
    name.textContent = c.name;
    
    contact.appendChild(dot);
    contact.appendChild(name);
    contactsList.appendChild(contact);
  });
  
  contactsCard.appendChild(contactsList);
  outer.appendChild(contactsCard);

  // Floating Inbox Card
  const inboxCard = document.createElement("div");
  inboxCard.className = "modinbox-inbox-col";
  
  const inboxHeader = document.createElement("div");
  inboxHeader.className = "modinbox-inbox-header";
  
  const inboxTitle = document.createElement("h2");
  inboxTitle.textContent = "Inbox";
  
  const unread = document.createElement("div");
  unread.className = "modinbox-unread";
  unread.textContent = `${emails.length} unread messages`;
  
  inboxHeader.appendChild(inboxTitle);
  inboxHeader.appendChild(unread);
  inboxCard.appendChild(inboxHeader);
  
  const scrollZone = document.createElement("div");
  scrollZone.className = "modinbox-scroll";
  
  const pills = [];
  emails.forEach((email, i) => {
    const pill = document.createElement("div");
    pill.className = "modinbox-email" + (i === selectedIdx ? " active" : "");
    
    pill.innerHTML = `
      <div class="modinbox-email-header">
        <div class="modinbox-section-label" style="color:${email.sectionColor}">
          ${email.section}
        </div>
        <div class="modinbox-email-time">${email.time}</div>
      </div>
      <div class="modinbox-email-subject">${email.subject}</div>
      <div class="modinbox-email-preview">${email.preview}</div>
    `;
    
    pill.onclick = () => {
      pills[selectedIdx].classList.remove("active");
      selectedIdx = i;
      pill.classList.add("active");
      renderDetail();
    };
    scrollZone.appendChild(pill);
    pills.push(pill);
  });
  
  inboxCard.appendChild(scrollZone);
  outer.appendChild(inboxCard);

  // Floating Detail Card
  const detailCard = document.createElement("div");
  detailCard.className = "modinbox-detail";
  
  const renderDetail = () => {
    const email = emails[selectedIdx];
    detailCard.innerHTML = "";
    
    detailCard.innerHTML = `
      <div class="modinbox-detail-header">
        <div class="modinbox-detail-from">
          From: <span style="color:${email.sectionColor}">${email.from}</span>
        </div>
        <div class="modinbox-detail-time">${email.time}</div>
      </div>
      <div class="modinbox-detail-title">${email.subject}</div>
      <div class="modinbox-detail-body">${email.body}</div>
    `;
    
    const replyBtn = document.createElement("button");
    replyBtn.className = "modinbox-reply-btn";
    replyBtn.textContent = "Reply";
    detailCard.appendChild(replyBtn);
  };
  
  renderDetail();
  outer.appendChild(detailCard);

  return outer;
}
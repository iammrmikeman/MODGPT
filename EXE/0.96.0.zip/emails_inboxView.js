
export function render() {
  const container = document.createElement('div');
  container.style.display = 'flex';
  container.style.gap = '32px';
  container.style.justifyContent = 'center';
  container.style.marginTop = '60px';

  const cardStyle = `
    background-color: #171924;
    border-radius: 16px;
    box-shadow: 0 0 24px 0 #0005;
    padding: 24px;
    min-width: 320px;
    min-height: 350px;
    max-width: 340px;
    flex: 1 1 0%;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    font-size: 1.09em;
  `;

  // Contacts Card (single big card, plain text, no pills)
  const contactsCard = document.createElement('div');
  contactsCard.className = 'card contacts-card';
  contactsCard.style = cardStyle;
  contactsCard.innerHTML = `
    <h3 style="margin-bottom: 16px;">Contacts</h3>
    <ul style="list-style:none; padding:0; margin:0; width:100%;">
      <li style="margin-bottom:10px;">BossGPT — System Lead</li>
      <li style="margin-bottom:10px;">Team Leader A — Swarm Ops</li>
      <li style="margin-bottom:10px;">Team Leader B — DevTools</li>
      <li style="margin-bottom:10px;">SpecOps Commander — AI Response</li>
      <li>Director A — Oversight</li>
    </ul>
  `;

  // Inbox Card
  const inboxCard = document.createElement('div');
  inboxCard.className = 'card inbox-card';
  inboxCard.style = cardStyle;
  inboxCard.innerHTML = `
    <h3 style="margin-bottom: 16px;">Inbox</h3>
    <div class="email-card" style="margin-bottom:10px;">
      <strong>System</strong><br>Welcome to MODGPT.EXE<br><small>Let’s get you set up...</small>
    </div>
    <div class="email-card" style="margin-bottom:10px;">
      <strong>Swarm</strong><br>New AI Worker Registered<br><small>Worker #1112 online.</small>
    </div>
    <div class="email-card">
      <strong>Security</strong><br>Memory Update Validated<br><small>Platinum Core update trusted.</small>
    </div>
  `;

  // Preview Card
  const previewCard = document.createElement('div');
  previewCard.className = 'card preview-card';
  previewCard.style = cardStyle;
  previewCard.innerHTML = `
    <h3 style="margin-bottom: 16px;">Preview</h3>
    <p>[Message body preview]</p>
  `;

  container.appendChild(contactsCard);
  container.appendChild(inboxCard);
  container.appendChild(previewCard);

  return container;
}

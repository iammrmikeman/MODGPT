1. Drop 'views/emails_inboxView.js' into your LATEST/views/ (overwrite).
2. Place 'style-sora-final.css' in your LATEST/ directory.
3. In your <head>, after <link rel='stylesheet' href='style.css'> add:
   <link rel='stylesheet' href='style-sora-final.css'>
4. Reload. Inbox will be 3-column, glass, console-perfect.
5. No scrollbars, perfect scaling, Sora concept locked in.

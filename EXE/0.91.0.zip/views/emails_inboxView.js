
// SORA CONCEPT FINAL - MODGPT INBOX
export default function emails_inboxView() {
  const root = document.createElement("div");
  root.className = "sora-inbox-root";

  // 1. CONTACTS COLUMN
  const contacts = [
    { name: "BossGPT", color: "#e75b5b", ring: "#fa7c7c" },
    { name: "Team Leader A", color: "#55aaff", ring: "#41d6ff" },
    { name: "Team Leader B", color: "#a464e7", ring: "#d2aaff" },
    { name: "SpecOps Commander", color: "#53c9ff", ring: "#34ebf7" },
    { name: "Director A", color: "#f4d43f", ring: "#fff378" },
    { name: "Director A", color: "#aaaaaa", ring: "#dadada" }
  ];
  const contactCol = document.createElement("div");
  contactCol.className = "sora-inbox-col sora-inbox-contacts";
  const contactTitle = document.createElement("div");
  contactTitle.className = "sora-inbox-contact-title";
  contactTitle.textContent = "Contacts";
  contactCol.appendChild(contactTitle);
  contacts.forEach(({ name, color, ring }) => {
    const row = document.createElement("div");
    row.className = "sora-inbox-contact-row";
    const avatar = document.createElement("div");
    avatar.className = "sora-inbox-contact-avatar";
    avatar.style.borderColor = ring;
    avatar.style.color = color;
    avatar.innerHTML = `<svg height="20" width="20" style="display:block;"><circle cx="10" cy="10" r="8" fill="none" stroke="${ring}" stroke-width="2.5"/></svg>`;
    const nameEl = document.createElement("span");
    nameEl.className = "sora-inbox-contact-name";
    nameEl.style.color = color;
    nameEl.textContent = name;
    row.appendChild(avatar);
    row.appendChild(nameEl);
    contactCol.appendChild(row);
  });

  // 2. INBOX LIST COLUMN
  const inboxCol = document.createElement("div");
  inboxCol.className = "sora-inbox-col sora-inbox-list";
  const inboxTitle = document.createElement("div");
  inboxTitle.className = "sora-inbox-inbox-title";
  inboxTitle.textContent = "Inbox";
  inboxCol.appendChild(inboxTitle);
  const inboxUnread = document.createElement("div");
  inboxUnread.className = "sora-inbox-inbox-unread";
  inboxUnread.textContent = "You have 6 unread emails.";
  inboxCol.appendChild(inboxUnread);

  const emails = [
    {
      section: "System",
      color: "#39a8fa",
      subject: "Welcome to MODGPT.EXE",
      preview: "Let's get you set up...",
      bold: true,
      body: "Welcome, Commander. Your AI system is ready to deploy. Let's begin configuration..."
    },
    {
      section: "Swarm Control",
      color: "#1da4ef",
      subject: "New AI Worker Registered",
      preview: "Worker #1112 online.",
      body: "Swarm worker #1112 is online and ready for instructions."
    },
    {
      section: "Security",
      color: "#47c2f6",
      subject: "Memory Update Validated",
      preview: "Platinum Core update trusted.",
      body: "Platinum Core update trusted."
    }
  ];

  let selected = 0;
  const pillList = document.createElement("div");
  pillList.className = "sora-inbox-pill-list";
  emails.forEach((email, i) => {
    const pill = document.createElement("div");
    pill.className = "sora-inbox-pill" + (selected === i ? " active" : "");
    pill.onclick = () => {
      pillList.querySelectorAll(".sora-inbox-pill").forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      selected = i;
      renderDetail();
    };
    pill.innerHTML = `<span class="sora-inbox-pill-section" style="color:${email.color}">${email.section}</span>
      <span class="sora-inbox-pill-subject" style="font-weight:${email.bold ? 700 : 500}">${email.subject}</span>
      <span class="sora-inbox-pill-preview">${email.preview}</span>`;
    pillList.appendChild(pill);
  });
  inboxCol.appendChild(pillList);

  // 3. MESSAGE DETAIL COLUMN
  const detailCol = document.createElement("div");
  detailCol.className = "sora-inbox-col sora-inbox-detail";

  function renderDetail() {
    const msg = emails[selected];
    detailCol.innerHTML = `<div class="sora-inbox-msg-from">From: <span style="color:${msg.color};font-weight:600;">${msg.section}</span></div>
      <div class="sora-inbox-msg-title">${msg.subject}</div>
      <div class="sora-inbox-msg-body">${msg.body}</div>
      <button class="sora-inbox-reply-btn">Reply</button>`;
  }
  renderDetail();

  // Compose root
  root.appendChild(contactCol);
  root.appendChild(inboxCol);
  root.appendChild(detailCol);
  return root;
}

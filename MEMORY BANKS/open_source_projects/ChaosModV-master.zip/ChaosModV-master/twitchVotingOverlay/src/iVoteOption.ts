export interface IVoteOption {
	label: string;
	votes: number;
}

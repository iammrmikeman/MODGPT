import { IChaosOverlayClientMessage } from './iMessage';

export type TChaosOverlayClientEvent = (event: IChaosOverlayClientMessage) => void;

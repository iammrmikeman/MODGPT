# Using the Config effectively
I recommend/suggest that if you want to use the Config App to make changes you have the Game running 
and you open the index.html file (the one you hopefully already had added to OBS) in your Browser.

When you are making changes those will not be directly applied to the Overlay. You need to REFRESH THE BROWSER once so that the "new"
index.css gets used for the styling. 

Once you are done, and the Overlay is looking the way you like it you are basically read to go.
However you might have to re-add the index.html file to your OBS as a Browser source. 

# The Config.exe (TwitchOverlayConfig.exe to be exact) is right next to the index.html
You can ignore the overlay.ini file. It just stores the settings you have chosen as your config.

# Possible future settings
I have a few more settings in mind that I could add to the config for you to customize however the Overlay (made by Aduentix)
is often either not designed to use diffrent options (like a vertical fade-in and fade-out). 

I'll see how much this is used/liked 
﻿using System.Windows;

namespace ConfigApp
{
    public partial class App : Application
    {

    }
}

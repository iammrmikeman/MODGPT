﻿namespace ConfigApp
{
    public static class Info
    {
        public const string VERSION = "2.2-dev";

        public const string WORKSHOP_DEFAULT_URL = "https://chaos.gopong.dev";
    }
}

#pragma once

#define _CHAOSCONCAT(a, b) a##b
#define CHAOSCONCAT(a, b) _CHAOSCONCAT(a, b)
#pragma once

typedef int Entity;

namespace Hooks
{
	void ProxyEntityHandle(Entity origHandle, Entity newHandle);
}
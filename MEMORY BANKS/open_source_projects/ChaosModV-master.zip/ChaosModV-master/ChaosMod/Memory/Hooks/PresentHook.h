#pragma once

#include "Util/Events.h"

namespace Hooks
{
	inline ChaosEvent OnPresent;
}
#pragma once

#define MOD_VERSION "2.2-dev"
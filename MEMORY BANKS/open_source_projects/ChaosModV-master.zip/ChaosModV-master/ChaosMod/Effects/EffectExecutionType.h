#pragma once

enum class EffectExecutionType
{
	Default,
	Meta
};
#pragma once

void OnStartTpRandomStore();
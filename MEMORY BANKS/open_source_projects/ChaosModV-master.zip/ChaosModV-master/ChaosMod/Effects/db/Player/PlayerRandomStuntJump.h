#pragma once

void OnStartMakeRandomStuntJump();
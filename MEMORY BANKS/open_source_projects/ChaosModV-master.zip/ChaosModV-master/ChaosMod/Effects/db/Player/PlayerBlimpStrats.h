#pragma once

void OnStartBlimpStrats(bool bHandleThreadBlock);
#include <stdafx.h>

#include "Effects/Register/RegisterEffect.h"
#include "Memory/Hooks/ShaderHook.h"

CHAOS_VAR const char *ms_ShaderSrcPrefix = R"SRC(
Texture2D HDRSampler : register(t5);
SamplerState g_samLinear : register(s5)
{
    Filter = MIN_MAG_MIP_LINEAR;
    AddressU = Wrap;
    AddressV = Wrap;
};

float4 main(float4 position	: SV_POSITION, float3 texcoord : TEXCOORD0, float4 color : COLOR0) : SV_Target0
{
)SRC";

static void OnStart()
{
	// Build shader source
	std::string shaderSrcSuffix;
	switch (g_Random.GetRandomInt(0, 3))
	{
	case 0:
		shaderSrcSuffix = "return HDRSampler.Sample(g_samLinear, float2(lerp(texcoord.x >= 0.5, texcoord.x < 0.5, "
		                  "texcoord.x), texcoord.y));}";
		break;
	case 1:
		shaderSrcSuffix = "return HDRSampler.Sample(g_samLinear, float2(lerp(texcoord.x < 0.5, texcoord.x >= 0.5, "
		                  "texcoord.x), texcoord.y));}";
		break;
	case 2:
		shaderSrcSuffix =
		    "return HDRSampler.Sample(g_samLinear, float2(texcoord.x, lerp(texcoord.y >= 0.5, texcoord.y < 0.5, "
		    "texcoord.y)));}";
		break;
	case 3:
		shaderSrcSuffix =
		    "return HDRSampler.Sample(g_samLinear, float2(texcoord.x, lerp(texcoord.y < 0.5, texcoord.y >= 0.5, "
		    "texcoord.y)));}";
		break;
	}

	if (!shaderSrcSuffix.empty())
		Hooks::OverrideShader(OverrideShaderType::LensDistortion, ms_ShaderSrcPrefix + shaderSrcSuffix);
}

static void OnStop()
{
	Hooks::ResetShader();
}

// clang-format off
REGISTER_EFFECT(OnStart, OnStop, nullptr, 
	{
		.Name = "Folded Screen",
		.Id = "screen_foldedscreen",
		.IsTimed = true,
		.IsShortDuration = true,
		.EffectCategory = EffectCategory::Shader,
		.EffectGroupType = EffectGroupType::Shader
	}
);
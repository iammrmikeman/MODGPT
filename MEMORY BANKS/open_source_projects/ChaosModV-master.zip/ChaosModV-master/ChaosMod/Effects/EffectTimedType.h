#pragma once

enum class EffectTimedType
{
	Permanent = -3,
	Custom,
	NotTimed,
	Normal,
	Short
};
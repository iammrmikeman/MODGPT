﻿namespace TwitchChatVotingProxy.ChaosPipe
{
    class OnGetCurrentVotesArgs
    {
        public List<int>? CurrentVotes { get; set; } = null;
    }
}

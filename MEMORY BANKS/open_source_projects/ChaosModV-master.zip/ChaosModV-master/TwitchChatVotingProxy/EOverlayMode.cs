﻿namespace TwitchChatVotingProxy
{
    enum EOverlayMode
    {
        CHAT_MESSAGES,
        OVERLAY_INGAME,
        OVERLAY_OBS
    }
}

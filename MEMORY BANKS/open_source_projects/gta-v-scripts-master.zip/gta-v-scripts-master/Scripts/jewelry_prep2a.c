#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 10;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
var uLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
char cLocal_79[16] = "";
var uLocal_81 = 0;
var uLocal_82 = 0;
int iLocal_83 = 0;
int iLocal_84 = 0;
int iLocal_85 = 0;
int iLocal_86 = 0;
vector3 vLocal_87 = {0f, 0f, 0f};
vector3 vLocal_90 = {0f, 0f, 0f};
int iLocal_93 = 0;
int iLocal_94 = 0;
int iLocal_95 = 0;
int iLocal_96 = 0;
int iLocal_97 = 0;
bool bLocal_98 = 0;
var *uLocal_99 = NULL;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 10;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 10;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 20;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 0;
var uLocal_430 = 0;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 20;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 0;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var uLocal_524 = 0;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 30;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 0;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 0;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 0;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 0;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
var uLocal_726 = 0;
var uLocal_727 = 0;
var uLocal_728 = 0;
var uLocal_729 = 0;
var uLocal_730 = 0;
var uLocal_731 = 0;
var uLocal_732 = 0;
var uLocal_733 = 0;
var uLocal_734 = 0;
var uLocal_735 = 0;
var uLocal_736 = 0;
var uLocal_737 = 0;
var uLocal_738 = 0;
var uLocal_739 = 0;
var uLocal_740 = 0;
var uLocal_741 = 0;
var uLocal_742 = 0;
var uLocal_743 = 0;
var uLocal_744 = 0;
var uLocal_745 = 0;
var uLocal_746 = 0;
var uLocal_747 = 0;
var uLocal_748 = 0;
var uLocal_749 = 0;
var uLocal_750 = 0;
var uLocal_751 = 0;
var uLocal_752 = 0;
var uLocal_753 = 0;
var uLocal_754 = 0;
var uLocal_755 = 5;
var uLocal_756 = 0;
var uLocal_757 = 0;
var uLocal_758 = 0;
var uLocal_759 = 0;
var uLocal_760 = 0;
var uLocal_761 = 0;
var uLocal_762 = 0;
var uLocal_763 = 0;
var uLocal_764 = 0;
var uLocal_765 = 0;
var uLocal_766 = 0;
var uLocal_767 = 0;
var uLocal_768 = 0;
var uLocal_769 = 0;
var uLocal_770 = 0;
var uLocal_771 = 0;
var uLocal_772 = 0;
var uLocal_773 = 0;
var uLocal_774 = 0;
var uLocal_775 = 0;
var uLocal_776 = 0;
var uLocal_777 = 0;
var uLocal_778 = 0;
var uLocal_779 = 0;
var uLocal_780 = 0;
var uLocal_781 = 0;
var uLocal_782 = 0;
var uLocal_783 = 0;
var uLocal_784 = 0;
var uLocal_785 = 0;
var uLocal_786 = 7;
var uLocal_787 = 0;
var uLocal_788 = 0;
var uLocal_789 = 0;
var uLocal_790 = 0;
var uLocal_791 = 0;
var uLocal_792 = 0;
var uLocal_793 = 0;
var uLocal_794 = 0;
var uLocal_795 = 0;
var uLocal_796 = 0;
var uLocal_797 = 0;
var uLocal_798 = 0;
var uLocal_799 = 0;
var uLocal_800 = 0;
var uLocal_801 = 0;
var uLocal_802 = 0;
var uLocal_803 = 0;
var uLocal_804 = 0;
var uLocal_805 = 0;
var uLocal_806 = 0;
var uLocal_807 = 0;
var uLocal_808 = 0;
var uLocal_809 = 0;
var uLocal_810 = 0;
var uLocal_811 = 0;
var uLocal_812 = 0;
var uLocal_813 = 0;
var uLocal_814 = 0;
var uLocal_815 = 0;
var uLocal_816 = 0;
var uLocal_817 = 0;
var uLocal_818 = 0;
var uLocal_819 = 0;
var uLocal_820 = 0;
var uLocal_821 = 0;
var uLocal_822 = 0;
var uLocal_823 = 0;
var uLocal_824 = 0;
var uLocal_825 = 0;
var uLocal_826 = 0;
var uLocal_827 = 0;
var uLocal_828 = 0;
var uLocal_829 = 0;
var uLocal_830 = 0;
var uLocal_831 = 0;
var uLocal_832 = 0;
var uLocal_833 = 0;
var uLocal_834 = 0;
var uLocal_835 = 0;
var uLocal_836 = 5;
var uLocal_837 = 0;
var uLocal_838 = 0;
var uLocal_839 = 0;
var uLocal_840 = 0;
var uLocal_841 = 0;
var uLocal_842 = 0;
var uLocal_843 = 0;
var uLocal_844 = 0;
var uLocal_845 = 0;
var uLocal_846 = 0;
var uLocal_847 = 0;
var uLocal_848 = 0;
var uLocal_849 = 0;
var uLocal_850 = 0;
var uLocal_851 = 0;
var uLocal_852 = 0;
var uLocal_853 = 0;
var uLocal_854 = 0;
var uLocal_855 = 0;
var uLocal_856 = 0;
var uLocal_857 = 0;
var uLocal_858 = 0;
var uLocal_859 = 0;
var uLocal_860 = 0;
var uLocal_861 = 0;
var uLocal_862 = 3;
var uLocal_863 = 0;
var uLocal_864 = 0;
var uLocal_865 = 0;
var uLocal_866 = 0;
var uLocal_867 = 0;
var uLocal_868 = 0;
var uLocal_869 = 0;
var uLocal_870 = 0;
var uLocal_871 = 0;
var uLocal_872 = 0;
var uLocal_873 = 0;
var uLocal_874 = 0;
var uLocal_875 = 0;
var uLocal_876 = 0;
var uLocal_877 = 0;
var uLocal_878 = 16;
var uLocal_879 = 0;
var uLocal_880 = 0;
var uLocal_881 = 0;
var uLocal_882 = 0;
var uLocal_883 = 0;
var uLocal_884 = 0;
var uLocal_885 = 0;
var uLocal_886 = 0;
var uLocal_887 = 0;
var uLocal_888 = 0;
var uLocal_889 = 0;
var uLocal_890 = 0;
var uLocal_891 = 0;
var uLocal_892 = 0;
var uLocal_893 = 0;
var uLocal_894 = 0;
var uLocal_895 = 0;
var uLocal_896 = 0;
var uLocal_897 = 0;
var uLocal_898 = 0;
var uLocal_899 = 0;
var uLocal_900 = 0;
var uLocal_901 = 0;
var uLocal_902 = 0;
var uLocal_903 = 0;
var uLocal_904 = 0;
var uLocal_905 = 0;
var uLocal_906 = 0;
var uLocal_907 = 0;
var uLocal_908 = 0;
var uLocal_909 = 0;
var uLocal_910 = 0;
var uLocal_911 = 0;
var uLocal_912 = 0;
var uLocal_913 = 0;
var uLocal_914 = 0;
var uLocal_915 = 0;
var uLocal_916 = 0;
var uLocal_917 = 0;
var uLocal_918 = 0;
var uLocal_919 = 0;
var uLocal_920 = 0;
var uLocal_921 = 0;
var uLocal_922 = 0;
var uLocal_923 = 0;
var uLocal_924 = 0;
var uLocal_925 = 0;
var uLocal_926 = 0;
var uLocal_927 = 0;
var uLocal_928 = 0;
var uLocal_929 = 0;
var uLocal_930 = 0;
var uLocal_931 = 0;
var uLocal_932 = 0;
var uLocal_933 = 0;
var uLocal_934 = 0;
var uLocal_935 = 0;
var uLocal_936 = 0;
var uLocal_937 = 0;
var uLocal_938 = 0;
var uLocal_939 = 0;
var uLocal_940 = 0;
var uLocal_941 = 0;
var uLocal_942 = 0;
var uLocal_943 = 0;
var uLocal_944 = 0;
var uLocal_945 = 0;
var uLocal_946 = 0;
var uLocal_947 = 0;
var uLocal_948 = 0;
var uLocal_949 = 0;
var uLocal_950 = 0;
var uLocal_951 = 0;
var uLocal_952 = 0;
var uLocal_953 = 0;
var uLocal_954 = 0;
var uLocal_955 = 0;
var uLocal_956 = 0;
var uLocal_957 = 0;
var uLocal_958 = 0;
var uLocal_959 = 0;
var uLocal_960 = 0;
var uLocal_961 = 0;
var uLocal_962 = 0;
var uLocal_963 = 0;
var uLocal_964 = 0;
var uLocal_965 = 0;
var uLocal_966 = 0;
var uLocal_967 = 0;
var uLocal_968 = 0;
var uLocal_969 = 0;
var uLocal_970 = 0;
var uLocal_971 = 0;
var uLocal_972 = 0;
var uLocal_973 = 0;
var uLocal_974 = 0;
var uLocal_975 = 0;
var uLocal_976 = 0;
var uLocal_977 = 0;
var uLocal_978 = 10;
var uLocal_979 = 0;
var uLocal_980 = 0;
var uLocal_981 = 0;
var uLocal_982 = 0;
var uLocal_983 = 0;
var uLocal_984 = 0;
var uLocal_985 = 0;
var uLocal_986 = 0;
var uLocal_987 = 0;
var uLocal_988 = 0;
var uLocal_989 = 0;
var uLocal_990 = 0;
var uLocal_991 = 0;
var uLocal_992 = 0;
var uLocal_993 = 0;
var uLocal_994 = 0;
var uLocal_995 = 0;
var uLocal_996 = 0;
var uLocal_997 = 0;
var uLocal_998 = 0;
var uLocal_999 = 0;
var uLocal_1000 = 0;
var uLocal_1001 = 0;
var uLocal_1002 = 0;
var uLocal_1003 = 0;
var uLocal_1004 = 0;
var uLocal_1005 = 0;
var uLocal_1006 = 0;
var uLocal_1007 = 0;
var uLocal_1008 = 0;
var uLocal_1009 = 0;
var uLocal_1010 = 0;
var uLocal_1011 = 0;
var uLocal_1012 = 0;
var uLocal_1013 = 0;
var uLocal_1014 = 0;
var uLocal_1015 = 0;
var uLocal_1016 = 0;
var uLocal_1017 = 0;
var uLocal_1018 = 0;
var uLocal_1019 = 0;
var uLocal_1020 = 0;
var uLocal_1021 = 0;
var uLocal_1022 = 0;
var uLocal_1023 = 0;
var uLocal_1024 = 0;
var uLocal_1025 = 0;
var uLocal_1026 = 0;
var uLocal_1027 = 0;
var uLocal_1028 = 0;
var uLocal_1029 = 5;
var uLocal_1030 = 0;
var uLocal_1031 = 0;
var uLocal_1032 = 0;
var uLocal_1033 = 0;
var uLocal_1034 = 0;
var uLocal_1035 = 0;
var uLocal_1036 = 0;
var uLocal_1037 = 0;
var uLocal_1038 = 0;
var uLocal_1039 = 0;
var uLocal_1040 = 0;
var uLocal_1041 = 0;
var uLocal_1042 = 0;
var uLocal_1043 = 0;
var uLocal_1044 = 0;
var uLocal_1045 = 0;
var uLocal_1046 = 0;
var uLocal_1047 = 0;
var uLocal_1048 = 0;
var uLocal_1049 = 0;
var uLocal_1050 = 0;
var uLocal_1051 = 0;
var uLocal_1052 = 0;
var uLocal_1053 = 0;
var uLocal_1054 = 0;
var uLocal_1055 = 5;
var uLocal_1056 = 0;
var uLocal_1057 = 0;
var uLocal_1058 = 0;
var uLocal_1059 = 0;
var uLocal_1060 = 0;
var uLocal_1061 = 0;
var uLocal_1062 = 0;
var uLocal_1063 = 0;
var uLocal_1064 = 0;
var uLocal_1065 = 0;
var uLocal_1066 = 0;
var uLocal_1067 = 0;
var uLocal_1068 = 0;
var uLocal_1069 = 0;
var uLocal_1070 = 0;
var uLocal_1071 = 0;
var uLocal_1072 = 0;
var uLocal_1073 = 0;
var uLocal_1074 = 0;
var uLocal_1075 = 0;
var uLocal_1076 = 0;
var uLocal_1077 = 0;
var uLocal_1078 = 0;
var uLocal_1079 = 0;
var uLocal_1080 = 0;
var uLocal_1081 = 0;
var uLocal_1082 = 0;
var uLocal_1083 = 0;
struct<8> Local_1084[2];
int iLocal_1101 = 0;
var uLocal_1102 = 3;
var uLocal_1103 = 0;
var uLocal_1104 = 0;
var uLocal_1105 = 0;
var uLocal_1106 = 0;
var uLocal_1107 = 0;
var uLocal_1108 = 1092616192;
var uLocal_1109 = 1101004800;
var uLocal_1110 = 0;
var uLocal_1111 = 0;
var uLocal_1112 = 0;
var uLocal_1113 = 0;
var uLocal_1114 = 0;
var uLocal_1115 = 0;
var uLocal_1116 = 0;
var uLocal_1117 = 0;
var uLocal_1118 = 3;
var uLocal_1119 = 0;
var uLocal_1120 = 0;
var uLocal_1121 = 0;
var uLocal_1122 = 0;
var uLocal_1123 = 0;
var uLocal_1124 = 0;
var uLocal_1125 = 0;
var *uLocal_1126 = NULL;
var uLocal_1127 = 0;
var uLocal_1128 = 0;
var uLocal_1129 = 0;
var uLocal_1130 = 0;
var uLocal_1131 = 0;
var uLocal_1132 = 0;
var uLocal_1133 = 0;
var uLocal_1134 = 0;
var uLocal_1135 = 0;
var uLocal_1136 = 0;
var uLocal_1137 = 0;
var uLocal_1138 = 0;
var uLocal_1139 = 0;
var uLocal_1140 = 0;
var uLocal_1141 = 0;
var uLocal_1142 = 0;
var uLocal_1143 = 0;
var uLocal_1144 = 0;
var uLocal_1145 = 0;
var uLocal_1146 = 0;
var uLocal_1147 = 0;
var uLocal_1148 = 0;
var uLocal_1149 = 0;
var uLocal_1150 = 0;
var uLocal_1151 = 0;
var uLocal_1152 = 0;
var uLocal_1153 = 0;
var uLocal_1154 = 0;
var uLocal_1155 = 0;
var uLocal_1156 = 0;
var uLocal_1157 = 0;
var uLocal_1158 = 0;
var uLocal_1159 = 0;
var uLocal_1160 = 0;
var uLocal_1161 = 0;
var uLocal_1162 = 0;
var uLocal_1163 = 0;
var uLocal_1164 = 0;
var uLocal_1165 = 0;
var uLocal_1166 = 0;
var uLocal_1167 = 0;
var uLocal_1168 = 0;
var uLocal_1169 = 0;
var uLocal_1170 = 0;
var uLocal_1171 = 0;
var uLocal_1172 = 0;
var uLocal_1173 = 0;
var uLocal_1174 = 0;
var uLocal_1175 = 0;
var uLocal_1176 = 0;
var uLocal_1177 = 0;
var uLocal_1178 = 0;
var uLocal_1179 = 0;
var uLocal_1180 = 0;
var uLocal_1181 = 0;
var uLocal_1182 = 0;
var uLocal_1183 = 0;
var uLocal_1184 = 0;
var uLocal_1185 = 0;
var uLocal_1186 = 0;
var uLocal_1187 = 0;
var uLocal_1188 = 0;
var uLocal_1189 = 0;
var uLocal_1190 = 0;
var uLocal_1191 = 0;
var uLocal_1192 = 0;
var uLocal_1193 = 0;
var uLocal_1194 = 0;
var uLocal_1195 = 0;
var uLocal_1196 = 0;
var uLocal_1197 = 0;
var uLocal_1198 = 0;
var uLocal_1199 = 0;
var uLocal_1200 = 0;
var uLocal_1201 = 0;
var uLocal_1202 = 0;
var uLocal_1203 = 0;
var uLocal_1204 = 0;
var uLocal_1205 = 0;
var uLocal_1206 = 0;
var uLocal_1207 = 0;
var uLocal_1208 = 0;
var uLocal_1209 = 0;
var uLocal_1210 = 0;
var uLocal_1211 = 0;
var uLocal_1212 = 0;
var uLocal_1213 = 0;
var uLocal_1214 = 0;
var uLocal_1215 = 0;
var uLocal_1216 = 0;
var uLocal_1217 = 0;
var uLocal_1218 = 0;
var uLocal_1219 = 0;
var uLocal_1220 = 0;
var uLocal_1221 = 0;
var uLocal_1222 = 0;
var uLocal_1223 = 0;
var uLocal_1224 = 0;
var uLocal_1225 = 0;
var uLocal_1226 = 0;
var uLocal_1227 = 0;
var uLocal_1228 = 0;
var uLocal_1229 = 0;
var uLocal_1230 = 0;
var uLocal_1231 = 0;
var uLocal_1232 = 0;
var uLocal_1233 = 0;
var uLocal_1234 = 0;
var uLocal_1235 = 0;
var uLocal_1236 = 0;
var uLocal_1237 = 0;
var uLocal_1238 = 0;
var uLocal_1239 = 0;
var uLocal_1240 = 0;
var uLocal_1241 = 0;
var uLocal_1242 = 0;
var uLocal_1243 = 0;
var uLocal_1244 = 0;
var uLocal_1245 = 0;
var uLocal_1246 = 0;
var uLocal_1247 = 0;
var uLocal_1248 = 0;
var uLocal_1249 = 0;
var uLocal_1250 = 0;
var uLocal_1251 = 0;
var uLocal_1252 = 0;
var uLocal_1253 = 0;
var uLocal_1254 = 0;
var uLocal_1255 = 0;
var uLocal_1256 = 0;
var uLocal_1257 = 0;
var uLocal_1258 = 0;
var uLocal_1259 = 0;
var uLocal_1260 = 0;
var uLocal_1261 = 0;
var uLocal_1262 = 0;
var uLocal_1263 = 0;
var uLocal_1264 = 0;
var uLocal_1265 = 0;
var uLocal_1266 = 0;
var uLocal_1267 = 0;
var uLocal_1268 = 0;
var uLocal_1269 = 0;
var uLocal_1270 = 0;
var uLocal_1271 = 0;
var uLocal_1272 = 0;
var uLocal_1273 = 0;
var uLocal_1274 = 0;
var uLocal_1275 = 0;
var uLocal_1276 = 0;
var uLocal_1277 = 0;
var uLocal_1278 = 0;
var uLocal_1279 = 0;
var uLocal_1280 = 0;
var uLocal_1281 = 0;
var uLocal_1282 = 0;
var uLocal_1283 = 0;
var uLocal_1284 = 0;
var uLocal_1285 = 0;
var uLocal_1286 = 0;
var uLocal_1287 = 0;
var uLocal_1288 = 0;
var uLocal_1289 = 0;
var uLocal_1290 = 0;
int *iLocal_1291 = NULL;
var uLocal_1292 = 0;
var uLocal_1293 = -1;
var uLocal_1294 = 0;
var uLocal_1295 = 0;
var uLocal_1296 = 0;
var uLocal_1297 = 0;
var uLocal_1298 = 0;
var uLocal_1299 = 0;
var uLocal_1300 = 1000;
var uLocal_1301 = 1000;
var uLocal_1302 = 0;
int iLocal_1303 = 0;
int iLocal_1304 = 0;
int iLocal_1305 = 0;
vector3 vLocal_1306 = {0f, 0f, 0f};
var uLocal_1309 = 0;
var uLocal_1310 = 0;
var uLocal_1311 = 0;
var uLocal_1312 = 0;
var uLocal_1313 = 0;
var uLocal_1314 = 0;
var uLocal_1315 = 0;
int iLocal_1316 = 0;
var uLocal_1317 = 0;
struct<2> Local_1318 = {
	0, 0
};
int iLocal_1320 = 0;
var uLocal_1321 = 0;
struct<2> Local_1322[3];
int iLocal_1329 = 0;
int iLocal_1330 = 0;
int iLocal_1331 = 0;
int iLocal_1332 = 0;
float fLocal_1333 = 0f;
int iLocal_1334 = 0;
int iLocal_1335 = 0;
int iLocal_1336 = 0;
int iLocal_1337 = 0;
int iLocal_1338 = 0;
vector3 vLocal_1339[24] = "";
var uLocal_1342 = 0;
var uLocal_1343 = 0;
var uLocal_1344 = 0;
int iLocal_1345 = 0;
int iLocal_1346 = 0;
int iLocal_1347 = 0;
int iLocal_1348 = 0;
int iLocal_1349 = 0;
int iLocal_1350 = 0;
int iLocal_1351 = 0;
int iLocal_1352 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	StringCopy(&cLocal_79, "JHP2ADS", 16);
	iLocal_83 = joaat("s_m_m_armoured_01");
	iLocal_84 = joaat("boxville3");
	iLocal_85 = joaat("prop_idol_case_02");
	iLocal_86 = joaat("prop_yell_plastic_target");
	vLocal_87 = {0f, 0.175f, 0f};
	vLocal_90 = {0f, -3.6f, 0f};
	iLocal_93 = 0;
	fLocal_1333 = 0f;
	iLocal_1350 = -1;
	if (player::has_force_cleanup_occurred(3)) {
		func_260(5);
	}
	gameplay::set_mission_flag(1);
	func_239();
	while (true) {
		unk1::_0x208784099002BC30("M_JewelStoreJobPrep2A", 0);
		if (bLocal_98) {
			func_237();
		}
		func_235(&uLocal_99);
		func_191();
		func_189();
		if (!iLocal_96) {
			func_185();
			func_184(&Local_1084);
			func_1();
		}
		vehicle::set_vehicle_density_multiplier_this_frame(0.8f);
		system::wait(0);
	}
}

// Position - 0x105
void func_1() {
	switch (iLocal_93) {
	case 0:
		if (func_21()) {
			func_20(1);
		}
		break;

	case 1: func_2(); break;
	}
}

// Position - 0x136
void func_2() {
	audio::trigger_music_event("JHP2A_STOP");
	ui::clear_prints();
	player::clear_player_wanted_level(player::player_id());
	func_8(0);
	if (func_7(87)) {
		func_3(0, 1);
	}
	else {
		func_3(0, 0);
	}
	script::terminate_this_thread();
}

// Position - 0x173
void func_3(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (!Global_55824) {
		Global_55824 = iParam1;
	}
	if (iParam0) {
		if (func_6(0) && Global_69948.f_1 == 1 && func_5(Global_69948)) {
		}
		else {
			Global_55822 = 1;
		}
	}
	if (Global_101700.f_8044 || func_6(0)) {
		iVar0 = func_4();
		iVar1 = Global_82576[iVar0 /*5*/];
		uVar2 = G_TextMessageConfig.f_109[iVar1 /*4*/];
		if (iVar0 == -1) {
			if (Global_101700.f_8044) {
			}
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 4)) {
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 5)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 4);
		gameplay::set_bit(&Global_69950, 1);
		Global_69966 = uVar2;
		Global_69967 = gameplay::get_game_timer();
	}
}

// Position - 0x249
int func_4() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x27E
int func_5(int iParam0) {
	switch (iParam0) {
	case 71: return 1;

	case 86: return 1;

	case 91: return 1;

	default: return 0;
	}
	return 0;
}

// Position - 0x2BC
int func_6(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return 1;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x2E7
bool func_7(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0x313
void func_8(int iParam0) {
	int iVar0;

	player::set_all_random_peds_flee(player::player_id(), 0);
	vehicle::set_vehicle_model_is_suppressed(joaat("boxville3"), 0);
	ped::set_ped_model_is_suppressed(joaat("s_m_m_armoured_01"), 0);
	if (func_19()) {
		func_13(0);
	}
	iLocal_1335 = 0;
	Global_68189 = 0;
	if (iParam0) {
		player::set_wanted_level_multiplier(1f);
		player::clear_player_wanted_level(player::player_id());
		Global_68189 = 0;
	}
	if (entity::does_entity_exist(iLocal_1316)) {
		if (iParam0) {
			vehicle::delete_vehicle(&iLocal_1316);
		}
		else {
			entity::set_vehicle_as_no_longer_needed(&iLocal_1316);
		}
	}
	if (entity::does_entity_exist(vLocal_1306.x)) {
		if (iParam0) {
			ped::delete_ped(&vLocal_1306);
		}
		else {
			entity::set_ped_as_no_longer_needed(&vLocal_1306);
		}
	}
	if (entity::does_entity_exist(Local_1318)) {
		if (iParam0 && !ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			vehicle::delete_vehicle(&Local_1318);
		}
		else {
			entity::set_vehicle_as_no_longer_needed(&Local_1318);
		}
	}
	iVar0 = 0;
	while (iVar0 < Local_1322) {
		if (entity::does_entity_exist(Local_1322[iVar0 /*2*/])) {
			if (iParam0) {
				object::delete_object(&Local_1322[iVar0 /*2*/]);
			}
			else {
				if (entity::is_entity_attached(Local_1322[iVar0 /*2*/])) {
					entity::detach_entity(Local_1322[iVar0 /*2*/], 1, 1);
				}
				entity::set_object_as_no_longer_needed(&Local_1322[iVar0 /*2*/]);
			}
		}
		iVar0++;
	}
	if (entity::does_entity_exist(iLocal_1329)) {
		if (iParam0) {
			object::delete_object(&iLocal_1329);
		}
		else {
			if (entity::is_entity_attached(iLocal_1329)) {
				entity::detach_entity(iLocal_1329, 1, 1);
			}
			entity::set_object_as_no_longer_needed(&iLocal_1329);
		}
	}
	if (iLocal_1330 != 0) {
		ped::remove_scenario_blocking_area(iLocal_1330, 0);
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
			weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_briefcase"));
		}
	}
	func_11(&iLocal_1291, 0, 0);
	func_10();
	if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
		weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_briefcase"));
	}
	func_9(6, 0);
}

// Position - 0x4CB
void func_9(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_25434, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_25434, iParam0);
	}
}

// Position - 0x4ED
void func_10() { Global_87679 = 0; }

// Position - 0x4FA
void func_11(int *iParam0, int iParam1, int iParam2) {
	char *sVar0;

	if (network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_2494199.f_4449, 26)) {
			return;
		}
	}
	if (cam::is_gameplay_hint_active()) {
		cam::stop_gameplay_hint(iParam2);
		graphics::_stop_screen_effect("FocusIn");
		audio::stop_audio_scene("HINT_CAM_SCENE");
		if (iParam0->f_11) {
			graphics::_start_screen_effect("FocusOut", 0, 0);
			audio::play_sound_frontend(-1, "FocusOut", "HintCamSounds", 1);
			iParam0->f_11 = 0;
		}
	}
	cam::set_cinematic_button_active(1);
	iParam0->f_1 = 0;
	*iParam0 = 0;
	iParam0->f_2 = -1;
	iParam0->f_8 = 0;
	iParam0->f_5 = 0;
	iParam0->f_6 = 0;
	sVar0 = iParam1;
	if (gameplay::is_string_null(sVar0)) {
		if (!network::network_is_game_in_progress()) {
			sVar0 = "CMN_HINT";
		}
		else {
			sVar0 = "FM_IHELP_HNT";
		}
	}
	if (!gameplay::is_string_null(iParam0->f_3)) {
		if (func_12(iParam0->f_3)) {
			ui::clear_help(1);
		}
	}
	if (!gameplay::is_string_null(sVar0)) {
		if (func_12(sVar0)) {
			ui::clear_help(1);
		}
	}
}

// Position - 0x5D0
bool func_12(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x5E3
void func_13(int iParam0) {
	if (iParam0) {
		func_18();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_17(0)) {
			func_14(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x646
void func_14(int iParam0) {
	if (Global_14604) {
		func_16(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_15()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x6B6
bool func_15() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x6DD
void func_16(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_17(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x751
bool func_17(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x7AB
void func_18() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x7D4
bool func_19() {
	if (Global_14443.f_1 == 1) {
		return true;
	}
	return false;
}

// Position - 0x7ED
void func_20(int iParam0) {
	if (iParam0 == 2) {
	}
	else {
		iLocal_94 = 0;
		iLocal_95 = 0;
		iLocal_93 = iParam0;
	}
}

// Position - 0x808
bool func_21() {
	vector3 vVar0;
	vector3 vVar3;
	int iVar6;
	var uVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	bool bVar11;
	int iVar12;
	int iVar13;

	vVar0 = {692.8256f, -1012.544f, 21.722f};
	vVar3 = {707.15f, -959.66f, 29.4f};
	if (!iLocal_95) {
		if (func_183(Local_1318)) {
			if (ui::get_blip_from_entity(Local_1318) != 0) {
				Local_1318.f_1 = ui::get_blip_from_entity(Local_1318);
			}
			else {
				Local_1318.f_1 = func_182(Local_1318, 0, 0);
			}
			func_181("JHP2A_STEAL", 7500, 1);
			func_180("JHP2A_HLP2", 15000);
		}
		else if (ui::get_blip_from_entity(Local_1318) != 0) {
			gameplay::set_this_script_can_remove_blips_created_by_any_script(1);
			uVar7 = ui::get_blip_from_entity(Local_1318);
			ui::remove_blip(&uVar7);
			gameplay::set_this_script_can_remove_blips_created_by_any_script(0);
		}
		audio::trigger_music_event("JHP2A_START");
		func_124(0f, 0f, 0f, 0f, 1, func_176());
		unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
		iLocal_1345 = 0;
		iLocal_95 = 1;
		iLocal_1352 = 1;
		iLocal_94 = 1;
	}
	if (iLocal_95) {
		func_123();
		switch (iLocal_94) {
		case 1:
			if (iLocal_1303 == 0 && entity::does_entity_exist(Local_1318) &&
				vehicle::is_vehicle_driveable(Local_1318, 0) && entity::does_entity_exist(vLocal_1306.x) &&
				!ped::is_ped_injured(vLocal_1306.x) && ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 0) &&
				func_120(&Local_1084[0 /*8*/])) {
				func_99(&iLocal_1291, Local_1318, 0, 0, 1, 1, 1);
			}
			else {
				func_11(&iLocal_1291, 0, 0);
			}
			if (iLocal_1303 == 3 || iLocal_1303 == 2) {
				unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
				func_96(&iLocal_1101, 1, 0);
				if (ui::is_help_message_being_displayed() && func_12("JHP2A_HLP2")) {
					ui::clear_help(1);
				}
				if (!iLocal_1345) {
					func_181("JHP2A_TAKEBZ", 7500, 1);
				}
				iLocal_94 = 2;
			}
			else if (entity::does_entity_exist(iLocal_1320) && vehicle::is_vehicle_driveable(iLocal_1320, 0) &&
					 vehicle::is_vehicle_attached_to_tow_truck(iLocal_1320, Local_1318)) {
				if (ui::does_blip_exist(Local_1318.f_1)) {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					gameplay::set_this_script_can_remove_blips_created_by_any_script(1);
					ui::remove_blip(&Local_1318.f_1);
					gameplay::set_this_script_can_remove_blips_created_by_any_script(0);
					func_95(705, 0);
				}
				func_94(&iLocal_1101, vVar0, 0.1f, 0.1f, 0.1f, 1, iLocal_1320, "JHP2A_RTNVAN", "", "", 1, 0, 1, -1);
				if (entity::is_entity_in_angled_area(Local_1318, 692.9143f, -1003.556f, 21.50839f, 692.6511f,
													 -1021.604f, 26.20675f, 9.75f, 0, 1, 0)) {
					vehicle::_set_vehicle_halt(iLocal_1320, 5f, -1, 0);
					iLocal_94 = 101;
				}
			}
			else if (iLocal_1303 == 1) {
				func_96(&iLocal_1101, 1, 0);
				if (!ui::does_blip_exist(Local_1322[0 /*2*/].f_1)) {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					Local_1322[0 /*2*/].f_1 = func_93(Local_1322[0 /*2*/]);
					func_181("JHP2A_TAKEBZ", 7500, 1);
					iLocal_1345 = 1;
					vehicle::set_vehicle_is_considered_by_player(Local_1318, 0);
				}
			}
			else if (iLocal_1303 == 0) {
				if (ui::does_blip_exist(Local_1318.f_1)) {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					gameplay::set_this_script_can_remove_blips_created_by_any_script(1);
					ui::remove_blip(&Local_1318.f_1);
					gameplay::set_this_script_can_remove_blips_created_by_any_script(0);
					func_95(705, 0);
				}
				if (func_91(&iLocal_1101, vVar0, 692.9143f, -1003.556f, 21.50839f, 692.6511f, -1021.604f, 26.20675f,
							9.75f, 1, Local_1318, "JHP2A_RTNVAN", "", "",
							ped::is_ped_in_vehicle(player::player_ped_id(), Local_1318, 0), 0, 1, -1)) {
					iLocal_94 = 101;
				}
				if (ui::does_blip_exist(iLocal_1101) && ui::_0xDD2238F57B977751(iLocal_1101)) {
					ui::set_blip_route(iLocal_1101, 0);
				}
			}
			break;

		case 101:
			if (entity::does_entity_exist(Local_1318) &&
				ped::is_ped_in_vehicle(player::player_ped_id(), Local_1318, 0)) {
				iVar8 = Local_1318;
			}
			else if (entity::does_entity_exist(iLocal_1320) &&
					 vehicle::is_vehicle_attached_to_tow_truck(iLocal_1320, Local_1318)) {
				iVar8 = iLocal_1320;
			}
			if (func_89(iVar8, 1093140480, 1, 1056964608, 0, 1, 0)) {
				if (func_7(87)) {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					iLocal_94 = 1000;
				}
				else {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					ai::task_leave_any_vehicle(player::player_ped_id(), 0, 0);
					iLocal_94++;
				}
			}
			break;

		case 102:
			if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				ui::clear_prints();
				vehicle::set_vehicle_is_considered_by_player(Local_1318, 0);
				vehicle::_0x2B6747FAA9DB9D6B(Local_1318, 1);
				if (entity::does_entity_exist(iLocal_1320)) {
					vehicle::_set_vehicle_halt(iLocal_1320, 5f, 1, 0);
				}
				func_88(0, -1);
				if (entity::does_entity_exist(Local_1322[0 /*2*/])) {
					object::delete_object(&Local_1322[0 /*2*/]);
				}
				if (entity::does_entity_exist(Local_1322[1 /*2*/])) {
					object::delete_object(&Local_1322[1 /*2*/]);
				}
				if (entity::does_entity_exist(Local_1322[2 /*2*/])) {
					object::delete_object(&Local_1322[2 /*2*/]);
				}
				return true;
			}
			break;

		case 2:
			if (!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
				iVar6 = 0;
				while (iVar6 < Local_1322) {
					if (entity::does_entity_exist(Local_1322[iVar6 /*2*/]) &&
						!entity::is_entity_attached(Local_1322[iVar6 /*2*/])) {
						if (ui::does_blip_exist(Local_1318.f_1)) {
							gameplay::set_this_script_can_remove_blips_created_by_any_script(1);
							ui::remove_blip(&Local_1318.f_1);
							gameplay::set_this_script_can_remove_blips_created_by_any_script(0);
						}
						if (!ui::does_blip_exist(Local_1322[iVar6 /*2*/].f_1)) {
							Local_1322[iVar6 /*2*/].f_1 = func_93(Local_1322[iVar6 /*2*/]);
						}
					}
					iVar6++;
				}
				iVar6 = 0;
				while (iVar6 < Local_1322) {
					if (entity::does_entity_exist(Local_1322[iVar6 /*2*/]) &&
						!entity::is_entity_attached(Local_1322[iVar6 /*2*/])) {
						if (!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
							iVar9 = func_87(Local_1322[iVar6 /*2*/]);
							if (iVar9 && entity::is_entity_in_angled_area(
											 player::player_ped_id(),
											 entity::get_offset_from_entity_in_world_coords(Local_1318, 0f, -3f, -0.5f),
											 entity::get_offset_from_entity_in_world_coords(Local_1318, 0f, -4.5f, 1f),
											 1.68f, 0, 1, 1) ||
								!iVar9 &&
									entity::is_entity_at_coord(player::player_ped_id(),
															   entity::get_entity_coords(Local_1322[iVar6 /*2*/], 1),
															   0.75f, 0.75f, 4f, 0, 0, 1)) {
								weapon::give_weapon_to_ped(player::player_ped_id(), joaat("weapon_briefcase"), 1, 0, 0);
								object::delete_object(&Local_1322[iVar6 /*2*/]);
								ui::clear_prints();
								audio::play_sound_frontend(-1, "PICKUP_WEAPON_SMOKEGRENADE",
														   "HUD_FRONTEND_WEAPONS_PICKUPS_SOUNDSET", 1);
							}
						}
					}
					iVar6++;
				}
			}
			else {
				func_95(705, 0);
				iVar6 = 0;
				while (iVar6 < Local_1322) {
					if (ui::does_blip_exist(Local_1322[iVar6 /*2*/].f_1)) {
						ui::remove_blip(&Local_1322[iVar6 /*2*/].f_1);
					}
					iVar6++;
				}
				func_41(&iLocal_1101, vVar3, 0.1f, 0.1f, 0.1f, 0, "JHP2A_RTNBZ", 1, 1, -1, 1);
				weapon::get_current_ped_weapon(player::player_ped_id(), &iVar10, 1);
				if (entity::is_entity_at_coord(player::player_ped_id(), 722.9849f, -965.7473f, 32.29691f, 50f, 40f,
											   11.4375f, 0, 1, 0)) {
					iVar12 = 1;
				}
				if (entity::is_entity_in_angled_area(player::player_ped_id(), 709.7432f, -960.3367f, 29.39533f,
													 703.6478f, -960.3293f, 33.65119f, 4.125f, 0, 1, 0)) {
					bVar11 = true;
				}
				if (bVar11 || iVar12 && !ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) && iLocal_1352) {
					controls::disable_control_action(0, 37, 1);
					controls::disable_control_action(0, 44, 1);
					if (!func_19()) {
						func_13(1);
					}
					if (!ped::is_ped_running_ragdoll_task(player::player_ped_id())) {
						if (!ped::is_ped_in_cover(player::player_ped_id(), 0) && !func_17(0)) {
							if (iVar10 != joaat("weapon_briefcase")) {
								weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 1);
							}
						}
					}
				}
				if (bVar11) {
					if (iVar10 == joaat("weapon_briefcase")) {
						if (!func_12("JHP2A_HLP1")) {
							func_40("JHP2A_HLP1");
						}
					}
					if (controls::is_control_just_pressed(0, 51) && iVar10 == joaat("weapon_briefcase")) {
						if (func_12("JHP2A_HLP1")) {
							ui::clear_help(1);
						}
						iVar13 = weapon::get_weapon_object_from_ped(player::player_ped_id(), 1);
						rope::activate_physics(iVar13);
						unk1::_0x293220DA1B46CEBC(3f, 5f, 4);
						audio::play_sound_from_entity(-1, "Drop_Case", iVar13, "JWL_PREP_2A_SOUNDS", 0, 0);
						entity::set_object_as_no_longer_needed(&iVar13);
						weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
						weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_briefcase"));
						func_88(0, -1);
						func_39(706);
						func_96(&iLocal_1101, 1, 0);
						if (func_7(87)) {
							if (func_19()) {
								func_13(0);
							}
							iLocal_94 = 2000;
						}
						else {
							return true;
						}
					}
				}
				else {
					if (func_19()) {
						func_13(0);
					}
					if (ui::is_help_message_being_displayed()) {
						if (func_12("JHP2A_HLP1")) {
							ui::clear_help(1);
						}
					}
				}
				iLocal_1352 = ped::is_ped_in_any_vehicle(player::player_ped_id(), 1);
			}
			break;

		case 1000:
			ai::task_leave_any_vehicle(player::player_ped_id(), 0, 0);
			entity::set_entity_invincible(player::player_ped_id(), 1);
			vehicle::set_vehicle_is_considered_by_player(Local_1318, 0);
			vehicle::_0x2B6747FAA9DB9D6B(Local_1318, 1);
			func_38(1);
			func_37(1, 0);
			if (func_35()) {
				if (func_24(&uLocal_1126, 12, "JHFAUD", "JHF_BZD2", 8, 1, 0, 0, 0)) {
					unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
					iLocal_94++;
				}
			}
			break;

		case 1001:
			func_37(1, 0);
			if (func_23()) {
				iLocal_94++;
			}
			break;

		case 1002:
			func_37(1, 0);
			if (!func_23()) {
				func_22();
				return true;
			}
			break;

		case 2000:
			unk1::_0x293220DA1B46CEBC(5f, 5f, 4);
			entity::set_entity_invincible(player::player_ped_id(), 1);
			Global_68189 = 1;
			func_38(1);
			func_37(1, 0);
			iLocal_94++;
			break;

		case 2001:
			func_37(1, 0);
			if (func_35()) {
				if (func_24(&uLocal_1126, 12, "JHFAUD", "JHF_BZD2", 8, 1, 0, 0, 0)) {
					iLocal_94++;
				}
			}
			break;

		case 2002:
			func_37(1, 0);
			if (func_23()) {
				iLocal_94++;
			}
			break;

		case 2003:
			func_37(1, 0);
			if (!func_23()) {
				func_22();
				return true;
			}
			break;
		}
	}
	return false;
}

// Position - 0x1187
void func_22() {
	int iVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		entity::set_entity_proofs(player::player_ped_id(), 0, 0, 0, 0, 0, 0, 0, 0);
		ped::set_ped_config_flag(player::player_ped_id(), 157, 1);
		entity::set_entity_invincible(player::player_ped_id(), 0);
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89193[iVar0])) {
			if (!entity::is_entity_dead(Global_89193[iVar0], 0)) {
				entity::set_entity_proofs(Global_89193[iVar0], 0, 0, 0, 0, 0, 0, 0, 0);
				entity::set_entity_invincible(Global_89193[iVar0], 0);
			}
		}
		iVar0++;
	}
	if (Global_35781 != 0 && Global_35781 != 3 && Global_35781 != 2) {
		player::set_max_wanted_level(5);
		player::set_wanted_level_multiplier(1f);
	}
}

// Position - 0x123A
bool func_23() {
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		return true;
	}
	return false;
}

// Position - 0x1263
bool func_24(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7, int iParam8) {
	func_34(uParam0, iParam1, sParam2, iParam6, iParam7, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	if (iParam5 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_2621441 = 0;
	return func_25(sParam3, iParam4, iParam8);
}

// Position - 0x12C2
int func_25(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_33();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_32(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_31();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_29();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_28()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_15()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_27();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_26();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_33();
	}
	return 0;
}

// Position - 0x158E
void func_26() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x15BF
void func_27() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x1654
bool func_28() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x16ED
void func_29() {
	if (func_30(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_176();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x178F
bool func_30(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x179D
void func_31() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x17F4
bool func_32(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x182F
void func_33() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x1886
void func_34(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x18DC
bool func_35() {
	if (func_36()) {
		return false;
	}
	if (ui::is_subtitle_preference_switched_on()) {
		if (ui::is_message_being_displayed()) {
			return false;
		}
	}
	return true;
}

// Position - 0x1902
bool func_36() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return true;
	}
	return false;
}

// Position - 0x1924
void func_37(int iParam0, int iParam1) {
	if (!iParam1) {
		controls::disable_control_action(0, 21, 1);
	}
	controls::disable_control_action(0, 25, 1);
	controls::disable_control_action(0, 24, 1);
	controls::disable_control_action(0, 257, 1);
	controls::disable_control_action(0, 141, 1);
	controls::disable_control_action(0, 140, 1);
	controls::disable_control_action(0, 22, 1);
	controls::disable_control_action(0, 44, 1);
	controls::disable_control_action(0, 23, 1);
	controls::disable_control_action(0, 47, 1);
	controls::disable_control_action(0, 36, 1);
	if (iParam0) {
		controls::disable_control_action(0, 37, 1);
	}
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		if (iParam1) {
			ped::set_ped_max_move_blend_ratio(player::player_ped_id(), 2f);
		}
		else {
			ped::set_ped_max_move_blend_ratio(player::player_ped_id(), 1f);
		}
		ped::set_ped_reset_flag(player::player_ped_id(), 102, 1);
	}
	if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
		player::clear_player_wanted_level(player::player_id());
	}
}

// Position - 0x19DE
void func_38(int iParam0) {
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		entity::set_entity_proofs(player::player_ped_id(), 1, 1, 1, 1, 1, 0, 0, 0);
		ped::set_ped_config_flag(player::player_ped_id(), 157, 0);
		entity::set_entity_invincible(player::player_ped_id(), 1);
		ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
		if (iParam0) {
			weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 0);
		}
		ped::remove_ped_helmet(player::player_ped_id(), 0);
	}
	if (player::is_player_playing(player::player_id())) {
		player::clear_player_wanted_level(player::player_id());
	}
	player::set_max_wanted_level(0);
	player::set_wanted_level_multiplier(0f);
}

// Position - 0x1A5A
void func_39(int iParam0) {
	int iVar0;
	int iVar1;

	Global_55823 = 0;
	if (MissionObjectives[iParam0 /*13*/] != 3) {
		return;
	}
	iVar0 = 0;
	iVar1 = 0;
	iVar1 = 0;
	while (iVar1 < Global_67917) {
		if (Global_67918[iVar1 /*9*/] == iParam0) {
			iVar0 = 1;
			Global_67918[iVar1 /*9*/].f_1 = 1;
			Global_67918[iVar1 /*9*/].f_2 = 0f;
			if (Global_67918[iVar1 /*9*/].f_3 == 2) {
			}
		}
		iVar1++;
	}
	if (!iVar0) {
	}
}

// Position - 0x1ACB
void func_40(char *sParam0) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 1, 1, -1);
}

// Position - 0x1AE1
int func_41(int iParam0, vector3 vParam1, vector3 vParam4, int iParam7, char *sParam8, int iParam9, int iParam10,
			int iParam11, int iParam12) {
	return func_42(iParam0, vParam1, vParam4, func_86(), func_86(), iParam7, 3, 0, 0, 0, 0, sParam8, func_85(),
				   func_85(), func_85(), func_85(), func_85(), 0, iParam9, func_85(), 0, 0, iParam10, iParam11,
				   func_85(), func_85(), func_85(), iParam12, 1065353216);
}

// Position - 0x1B3C
int func_42(int *iParam0, vector3 vParam1, vector3 vParam4, vector3 vParam7, vector3 vParam10, int iParam13,
			int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, char *sParam19, char *sParam20,
			char *sParam21, char *sParam22, char *sParam23, char *sParam24, int iParam25, bool bParam26, char *sParam27,
			int iParam28, int iParam29, bool bParam30, int iParam31, int iParam32, int iParam33, int iParam34,
			int iParam35, float fParam36) {
	int iVar0;
	bool bVar1;
	int iVar2;
	vector3 vVar3;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;

	vVar3 = {vParam1 + Vector(1f, 0f, 0f)};
	uParam0->f_17[0] = iParam15;
	uParam0->f_17[1] = iParam16;
	uParam0->f_17[2] = iParam17;
	uParam0->f_16 = iParam15;
	func_84(uParam0);
	func_83(uParam0);
	func_82();
	if (func_65(uParam0, uParam0->f_17[0], uParam0->f_17[1], uParam0->f_17[2], sParam20, sParam21, sParam22, sParam23,
				uParam0->f_8, iParam25, iParam18, 0, 0, iParam32, iParam33, iParam34, iParam14, bParam26)) {
		func_64(sParam20);
		func_64(sParam21);
		func_64(sParam22);
		func_64(sParam23);
		if (cam::is_screen_faded_in()) {
			bVar1 = false;
			if (vehicle::is_vehicle_driveable(iParam18, 0)) {
				if (ped::is_ped_in_vehicle(player::player_ped_id(), iParam18, 0)) {
					gameplay::set_bit(&uParam0->f_13, 3);
					if (!gameplay::is_bit_set(uParam0->f_13, 9)) {
						gameplay::clear_bit(&uParam0->f_13, 4);
					}
					if (gameplay::is_bit_set(uParam0->f_13, 23)) {
						gameplay::clear_bit(&uParam0->f_13, 23);
					}
					gameplay::set_bit(&uParam0->f_13, 9);
					bVar1 = true;
				}
			}
			else if (iParam14 == 4 || iParam14 == 5) {
				if (func_62(uParam0, iParam29)) {
					gameplay::set_bit(&uParam0->f_13, 3);
					if (!gameplay::is_bit_set(uParam0->f_13, 9)) {
						gameplay::clear_bit(&uParam0->f_13, 4);
					}
					gameplay::set_bit(&uParam0->f_13, 9);
					bVar1 = true;
				}
			}
			else {
				bVar1 = true;
			}
			if (bVar1) {
				func_64(sParam24);
				func_64(sParam27);
				func_64("MORE_SEATS");
				if (bParam26 && player::is_player_wanted_level_greater(player::player_id(), 0)) {
					if (ui::does_blip_exist(uParam0->f_5)) {
						ui::remove_blip(&uParam0->f_5);
						func_64(sParam19);
					}
					if (ui::does_blip_exist(*uParam0)) {
						ui::remove_blip(uParam0);
					}
					if (!func_59(iParam0, 1) && !func_58(iParam0) && !gameplay::is_bit_set(iParam0->f_13, 0)) {
						if (bParam30) {
							func_57(iParam0, "LOSE_WANTED", 0);
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_55(iParam0->f_17[0], "VEHICLE_POLICE_PURSUIT", 3);
							}
						}
						gameplay::set_bit(&iParam0->f_13, 0);
						gameplay::clear_bit(&iParam0->f_13, 1);
					}
				}
				else {
					if (gameplay::is_bit_set(iParam0->f_13, 0)) {
						func_64("LOSE_WANTED");
						gameplay::clear_bit(&iParam0->f_13, 0);
						gameplay::set_bit(&iParam0->f_13, 1);
					}
					if (gameplay::is_bit_set(iParam0->f_13, 1)) {
						if (!func_59(iParam0, 1)) {
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_55(iParam0->f_17[0], "LOSE_WANTED_LEVEL", 3);
							}
							gameplay::clear_bit(&iParam0->f_13, 1);
						}
					}
					if (!ui::does_blip_exist(iParam0->f_5)) {
						if (ui::does_blip_exist(*iParam0)) {
							ui::remove_blip(iParam0);
						}
						iParam0->f_5 = func_54(vVar3, 0);
						if (iParam31 != -1) {
							ui::set_blip_sprite(iParam0->f_5, iParam31);
						}
						if (iParam35) {
							func_53(iParam0->f_5, iParam0);
						}
					}
					else if (!func_52(vVar3, ui::get_blip_coords(iParam0->f_5), 0.1f, 0)) {
						ui::set_blip_coords(iParam0->f_5, vVar3);
						if (iParam35) {
							func_53(iParam0->f_5, iParam0);
						}
					}
					if (!func_59(iParam0, 2)) {
						if (!gameplay::is_bit_set(iParam0->f_13, 2)) {
							func_57(iParam0, sParam19, 0);
							gameplay::set_bit(&iParam0->f_13, 2);
						}
					}
					if (iParam14 == 4 || iParam14 == 5) {
						if (gameplay::is_bit_set(iParam0->f_13, 13)) {
							iParam13 = 0;
						}
					}
					bVar1 = false;
					iVar6 = 0;
					iVar7 = 0;
					if (iParam14 == 1 || iParam14 == 3 || iParam14 == 5) {
						iVar6 = 1;
					}
					if (iParam14 == 2 || iParam14 == 3) {
						iVar7 = 1;
					}
					else if (iParam14 == 4 || iParam14 == 5) {
						iVar7 = 2;
					}
					if (iParam28) {
						entity::is_entity_at_coord(player::player_ped_id(), vParam1, vParam4, iParam13, iVar6, iVar7);
						if (entity::is_entity_in_angled_area(player::player_ped_id(), vParam7, vParam10, fParam36, 0,
															 iVar6, iVar7)) {
							bVar1 = true;
						}
					}
					else if (entity::is_entity_at_coord(player::player_ped_id(), vParam1, vParam4, iParam13, iVar6,
														iVar7)) {
						bVar1 = true;
					}
					if (bVar1) {
						bVar1 = true;
						iVar2 = 0;
						while (iVar2 < 3) {
							if (!ped::is_ped_injured(iParam0->f_17[iVar2])) {
								if (iParam14 == 4 || iParam14 == 5) {
									iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
									if (!ped::is_ped_in_vehicle(iParam0->f_17[iVar2], iVar0, 0)) {
										bVar1 = false;
									}
								}
								else if (iParam18 != 0) {
									if (!ped::is_ped_in_vehicle(iParam0->f_17[iVar2], iParam18, 0)) {
										bVar1 = false;
									}
								}
								else if (!ped::is_ped_group_member(iParam0->f_17[iVar2], func_51()) ||
										 !func_49(iParam0->f_17[iVar2], 1)) {
									bVar1 = false;
								}
							}
							iVar2++;
						}
						if (bVar1) {
							if (func_46(iParam0)) {
								func_64(sParam19);
								func_64(sParam24);
								func_64(sParam20);
								func_64(sParam21);
								func_64(sParam22);
								func_64(sParam23);
								func_64("LOSE_WANTED");
								func_64("MORE_SEATS");
								func_64(sParam27);
								func_96(iParam0, 1, 0);
								return 1;
							}
						}
					}
				}
			}
			else if (entity::does_entity_exist(iParam18)) {
				if (bParam26 && player::is_player_wanted_level_greater(player::player_id(), 0) &&
					!gameplay::is_bit_set(iParam0->f_13, 9) && !gameplay::is_bit_set(iParam0->f_13, 22)) {
					func_64(sParam24);
					func_64(sParam27);
					if (ui::does_blip_exist(iParam0->f_5) || ui::does_blip_exist(*iParam0)) {
						ui::remove_blip(&iParam0->f_5);
						ui::remove_blip(iParam0);
						func_64(sParam19);
					}
					if (!func_59(iParam0, 1) && !func_58(iParam0) && !gameplay::is_bit_set(iParam0->f_13, 0)) {
						if (bParam30) {
							func_57(iParam0, "LOSE_WANTED", 0);
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_55(iParam0->f_17[0], "VEHICLE_POLICE_PURSUIT", 3);
							}
						}
						gameplay::set_bit(&iParam0->f_13, 0);
						gameplay::clear_bit(&iParam0->f_13, 1);
					}
				}
				else {
					if (gameplay::is_bit_set(iParam0->f_13, 0)) {
						func_64("LOSE_WANTED");
						gameplay::clear_bit(&iParam0->f_13, 0);
						gameplay::set_bit(&iParam0->f_13, 1);
					}
					if (gameplay::is_bit_set(iParam0->f_13, 1)) {
						if (!func_59(iParam0, 1)) {
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_55(iParam0->f_17[0], "LOSE_WANTED_LEVEL", 3);
							}
							gameplay::clear_bit(&iParam0->f_13, 1);
						}
					}
					if (vehicle::is_vehicle_driveable(iParam18, 0)) {
						if (!ui::does_blip_exist(*iParam0)) {
							if (ui::does_blip_exist(iParam0->f_5)) {
								ui::remove_blip(&iParam0->f_5);
								func_64(sParam19);
							}
							*iParam0 = func_43(iParam18, 0, 0);
							ui::set_blip_display(*iParam0, 2);
							if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								func_53(*iParam0, iParam0);
							}
						}
						if (!func_59(iParam0, 2)) {
							if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
								func_57(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 3);
								gameplay::clear_bit(&iParam0->f_13, 4);
							}
							else if (gameplay::is_bit_set(iParam0->f_13, 9)) {
								if (!gameplay::is_string_null(sParam27)) {
									if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
										func_57(iParam0, sParam27, 0);
										gameplay::set_bit(&iParam0->f_13, 4);
									}
								}
								else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
									func_57(iParam0, sParam24, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
								if (!gameplay::is_bit_set(iParam0->f_13, 23)) {
									if (!ped::is_ped_injured(iParam0->f_17[0])) {
										func_55(iParam0->f_17[0], "GET_IN_CAR", 3);
									}
									gameplay::set_bit(&iParam0->f_13, 23);
								}
							}
						}
					}
				}
			}
			else {
				if (ui::does_blip_exist(iParam0->f_5)) {
					ui::remove_blip(&iParam0->f_5);
					func_64(sParam19);
				}
				if (iParam14 == 4 || iParam14 == 5) {
					if (iParam29 > 0) {
						if (!func_59(iParam0, 2)) {
							if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
								if (!gameplay::is_bit_set(iParam0->f_13, 13)) {
									iVar8 = 0;
									iVar9 = 0;
									iVar2 = 0;
									while (iVar2 < 3) {
										if (!ped::is_ped_injured(iParam0->f_17[iVar2])) {
											iVar8++;
										}
										iVar2++;
									}
									iVar9 = gameplay::get_random_int_in_range(0, iVar8);
									if (!ped::is_ped_injured(iParam0->f_17[iVar9])) {
										func_55(iParam0->f_17[iVar9], "NEED_A_BIGGER_VEHICLE", 3);
									}
									func_57(iParam0, "MORE_SEATS", 0);
									gameplay::set_bit(&iParam0->f_13, 13);
								}
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
								func_57(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 3);
								gameplay::clear_bit(&iParam0->f_13, 4);
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								if (gameplay::is_bit_set(iParam0->f_13, 9)) {
									func_57(iParam0, sParam27, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
							}
						}
					}
					else if (!func_59(iParam0, 2)) {
						if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
							func_57(iParam0, sParam24, 0);
							gameplay::set_bit(&iParam0->f_13, 3);
							gameplay::clear_bit(&iParam0->f_13, 4);
						}
						else if (gameplay::is_bit_set(iParam0->f_13, 9)) {
							if (!gameplay::is_string_null(sParam27)) {
								if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
									func_57(iParam0, sParam27, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								func_57(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 4);
							}
						}
					}
				}
			}
		}
	}
	else {
		if (gameplay::is_bit_set(iParam0->f_13, 0)) {
			gameplay::clear_bit(&iParam0->f_13, 0);
		}
		func_64(sParam19);
		func_64(sParam24);
		func_64(sParam27);
		func_64(sParam24);
		func_64("LOSE_WANTED");
		if (ui::does_blip_exist(iParam0->f_5)) {
			ui::remove_blip(&iParam0->f_5);
		}
		if (ui::does_blip_exist(*iParam0)) {
			ui::remove_blip(iParam0);
		}
	}
	gameplay::clear_bit(&iParam0->f_13, 11);
	gameplay::clear_bit(&iParam0->f_13, 12);
	return 0;
}

// Position - 0x24A4
int func_43(int iParam0, int iParam1, int iParam2) { return func_44(iParam0, !iParam1, iParam2); }

// Position - 0x24B7
int func_44(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	iVar0 = ui::add_blip_for_entity(iParam0);
	if (entity::is_entity_a_vehicle(iParam0)) {
		ui::set_blip_scale(iVar0, func_45(network::network_is_game_in_progress(), 1f, 1f));
		if (!iParam2) {
			ui::set_blip_as_friendly(iVar0, iParam1);
		}
		else {
			ui::set_blip_colour(iVar0, 2);
		}
	}
	else if (entity::is_entity_a_ped(iParam0)) {
		ui::set_blip_scale(iVar0, func_45(network::network_is_game_in_progress(), 0.7f, 0.7f));
		ui::set_blip_as_friendly(iVar0, iParam1);
	}
	else if (entity::is_entity_an_object(iParam0)) {
		ui::set_blip_scale(iVar0, func_45(network::network_is_game_in_progress(), 0.7f, 0.7f));
	}
	return iVar0;
}

// Position - 0x255B
var func_45(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x2572
bool func_46(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_13, 12)) {
		if (func_48(player::player_ped_id())) {
			if (func_47(1, 0, 1) || gameplay::is_bit_set(uParam0->f_13, 7)) {
				return true;
			}
		}
	}
	else if (func_47(1, 0, 1) || gameplay::is_bit_set(uParam0->f_13, 7)) {
		return true;
	}
	return false;
}

// Position - 0x25D0
int func_47(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (gameplay::is_minigame_in_progress()) {
		return 0;
	}
	if (iParam0) {
		if (entity::is_entity_dead(player::player_ped_id(), 0)) {
			return 0;
		}
	}
	iVar0 = 0;
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
			return 0;
		}
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (iParam0) {
			if (entity::is_entity_dead(iVar0, 0)) {
				return 0;
			}
		}
		if (iParam2) {
			if (!entity::is_entity_dead(iVar0, 0)) {
				if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != player::player_ped_id()) {
					return 0;
				}
			}
		}
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::get_entity_upright_value(iVar0) < 0.95f || entity::get_entity_upright_value(iVar0) > 1.011f) {
				return 0;
			}
		}
	}
	else if (iParam1) {
		return 0;
	}
	if (!player::is_player_ready_for_cutscene(player::player_id())) {
		return 0;
	}
	if (!player::can_player_start_mission(player::player_id())) {
		return 0;
	}
	return 1;
}

// Position - 0x26B5
bool func_48(int iParam0) {
	float fVar0;

	if (!ped::is_ped_injured(iParam0)) {
		fVar0 = entity::get_entity_speed(iParam0);
		if (fVar0 > -0.5f && fVar0 < 0.5f) {
			return true;
		}
	}
	return false;
}

// Position - 0x26EC
int func_49(int iParam0, int iParam1) {
	if (!ped::is_ped_injured(iParam0)) {
		if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) && iParam1) {
			if (func_50(player::player_ped_id(), iParam0)) {
				ped::set_group_separation_range(func_51(), 50f);
				return 1;
			}
		}
		else if (ped::is_ped_group_member(iParam0, func_51())) {
			ped::set_group_separation_range(func_51(), 50f);
			return 1;
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0x2757
bool func_50(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (ped::is_ped_sitting_in_any_vehicle(iParam0)) {
			iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (!ped::is_ped_injured(iParam1)) {
					if (ped::is_ped_sitting_in_vehicle(iParam1, iVar0)) {
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x279F
var func_51() { return player::get_player_group(player::get_player_index()); }

// Position - 0x27AF
int func_52(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return 1;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x282A
void func_53(int iParam0, var *uParam1) {
	if (ui::does_blip_exist(iParam0)) {
		if (ui::does_blip_exist(uParam1->f_6)) {
			ui::set_blip_route(uParam1->f_6, 0);
		}
		ui::_0x3DDA37128DD1ACA8(0);
		ui::_0x67EEDEA1B9BAFD94();
		uParam1->f_6 = iParam0;
		ui::set_blip_route(iParam0, 1);
	}
}

// Position - 0x2865
int func_54(vector3 vParam0, int iParam3) {
	int iVar0;

	iVar0 = ui::add_blip_for_coord(vParam0);
	ui::set_blip_scale(iVar0, func_45(network::network_is_game_in_progress(), 1f, 1f));
	ui::set_blip_route(iVar0, iParam3);
	return iVar0;
}

// Position - 0x2891
void func_55(int iParam0, char *sParam1, int iParam2) {
	audio::_play_ambient_speech1(iParam0, sParam1, func_56(iParam2), 1);
}

// Position - 0x28A8
int func_56(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: return "SPEECH_PARAMS_STANDARD";

	case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

	case 2: return "SPEECH_PARAMS_BEAT";

	case 3: return "SPEECH_PARAMS_FORCE";

	case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

	case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

	case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

	case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

	case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

	case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

	case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

	case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

	case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

	case 13: return "SPEECH_PARAMS_MEGAPHONE";

	case 14: return "SPEECH_PARAMS_HELI";

	case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

	case 16: return "SPEECH_PARAMS_FORCE_HELI";

	case 17: return "SPEECH_PARAMS_INTERRUPT";

	case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

	case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

	case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

	case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

	case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

	case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

	case 24: return "SPEECH_PARAMS_ADD_BLIP";

	case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

	case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

	case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

	case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

	case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

	case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

	case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

	case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

	case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

	case 34: return "SPEECH_PARAMS_SHOUTED";

	case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

	case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

	default:
	}
	iVar0 = 0;
	return iVar0;
}

// Position - 0x2A9D
void func_57(var *uParam0, char *sParam1, int iParam2) {
	if (!iParam2) {
		if (!gameplay::is_string_null(sParam1)) {
			if (!gameplay::are_strings_equal(sParam1, "")) {
				func_181(sParam1, 7500, 1);
			}
		}
	}
	uParam0->f_10 = gameplay::get_game_timer();
}

// Position - 0x2AD4
int func_58(int *iParam0) {
	if (!ped::is_ped_injured(iParam0->f_16)) {
		if (audio::is_ambient_speech_playing(iParam0->f_16)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x2AF8
int func_59(int *iParam0, int iParam1) {
	if (iParam1 != 1 || ui::is_subtitle_preference_switched_on()) {
		if (ui::is_message_being_displayed()) {
			return 1;
		}
		if (func_61(iParam0)) {
			return 1;
		}
	}
	if (iParam1 != 2 || ui::is_subtitle_preference_switched_on()) {
		if (func_36() && !func_60()) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x2B50
int func_60() {
	if (Global_16756 == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x2B67
bool func_61(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar1 = gameplay::get_game_timer();
	iVar0 = iVar1 - uParam0->f_10;
	if (iVar0 < 35) {
		return true;
	}
	return false;
}

// Position - 0x2B8A
bool func_62(var *uParam0, int iParam1) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (func_63(iVar0, uParam0, iParam1)) {
			return true;
		}
	}
	return false;
}

// Position - 0x2BBB
bool func_63(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		iVar2 = 0;
		while (iVar2 < 3) {
			if (entity::does_entity_exist(uParam1->f_17[iVar2])) {
				iVar0++;
			}
			iVar2++;
		}
		iVar1 = vehicle::get_vehicle_max_number_of_passengers(iParam0);
		if (iParam2 > 0) {
			if (iVar1 >= iParam2) {
				if (iParam2 > 1) {
					if (!vehicle::_0xF7F203E31F96F6A1(iParam0, 1)) {
						return true;
					}
				}
				else {
					return true;
				}
			}
		}
		else if (iVar1 >= iVar0) {
			if (iVar0 > 1) {
				if (!vehicle::_0xF7F203E31F96F6A1(iParam0, 1)) {
					return true;
				}
			}
			else {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x2C4F
void func_64(char *sParam0) {
	if (!gameplay::is_string_null(sParam0)) {
		ui::clear_this_print(sParam0);
	}
}

// Position - 0x2C67
bool func_65(var *uParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, char *sParam7,
			 float fParam8, bool bParam9, int iParam10, int iParam11, int iParam12, var uParam13, var uParam14,
			 var uParam15, int iParam16, bool bParam17) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7[3];
	bool bVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	var uVar15[3];
	var uVar19[3];
	bool bVar23;
	int iVar24;
	int iVar25;
	int iVar26;
	int iVar27;
	vector3 vVar28;
	int iVar31;
	int iVar32;

	iVar4 = 0;
	uParam0->f_17[0] = uParam1;
	uParam0->f_17[1] = uParam2;
	uParam0->f_17[2] = uParam3;
	uParam0->f_16 = uParam1;
	uVar15[0] = uParam4;
	uVar15[1] = uParam5;
	uVar15[2] = uParam6;
	uVar19[0] = uParam13;
	uVar19[1] = uParam14;
	uVar19[2] = uParam15;
	iVar6 = 1;
	iVar1 = 0;
	iVar2 = 0;
	iVar3 = 0;
	iVar7[0] = 0;
	iVar7[1] = 0;
	iVar7[2] = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
			iVar3++;
		}
		if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
			if (!gameplay::is_bit_set(uParam0->f_13, 29) && !gameplay::is_bit_set(uParam0->f_13, 28)) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					ped::set_ped_using_action_mode(uParam0->f_17[iVar0], 1, -1, 0);
				}
				if (iVar0 == 2) {
					gameplay::set_bit(&uParam0->f_13, 28);
				}
			}
		}
		else if (!gameplay::is_bit_set(uParam0->f_13, 29) && gameplay::is_bit_set(uParam0->f_13, 28)) {
			if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
				ped::set_ped_using_action_mode(uParam0->f_17[iVar0], 0, -1, 0);
			}
			if (iVar0 == 2) {
				gameplay::clear_bit(&uParam0->f_13, 28);
			}
		}
		iVar0++;
	}
	if (iVar3 == 0) {
		return true;
	}
	if (gameplay::is_bit_set(uParam0->f_13, 26)) {
		bVar23 = false;
		if (!entity::does_entity_exist(uParam0->f_21)) {
			iVar25 = 64;
			iVar25 |= 65536;
			iVar25 |= 2048;
			iVar25 |= 1;
			iVar25 |= 2;
			iVar25 |= 4;
			iVar25 |= 32;
			iVar25 |= 16;
			iVar25 |= 8;
			iVar24 =
				vehicle::get_closest_vehicle(entity::get_entity_coords(player::player_ped_id(), 1), 50f, 0, iVar25);
			if (vehicle::is_vehicle_driveable(iVar24, 0)) {
				uParam0->f_21 = iVar24;
			}
		}
		if (vehicle::is_vehicle_driveable(uParam0->f_21, 0)) {
			if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
							   entity::get_entity_coords(uParam0->f_21, 1)) < 400f) {
				if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
					if (!player::is_player_wanted_level_greater(player::player_id(), 0) || !bParam17) {
						if (func_63(uParam0->f_21, uParam0, iVar3)) {
							iVar0 = 0;
							while (iVar0 < 3) {
								if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
									ped::set_ped_max_move_blend_ratio(uParam0->f_17[iVar0], 1f);
									if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
										ped::remove_ped_from_group(uParam0->f_17[iVar0]);
									}
									if (ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470) == 7 &&
										!func_81(uParam0->f_17[iVar0], uParam0->f_21)) {
										if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0])) {
											ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 1);
											ai::task_enter_vehicle(uParam0->f_17[iVar0], uParam0->f_21, 60000, iVar0,
																   1f, 1, 0);
											ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], iVar0);
										}
									}
								}
								iVar0++;
							}
							return true;
						}
						else {
							bVar23 = true;
						}
					}
					else {
						bVar23 = true;
					}
				}
				else {
					bVar23 = true;
				}
			}
			else {
				bVar23 = true;
			}
		}
		else {
			bVar23 = true;
		}
		if (bVar23) {
			gameplay::clear_bit(&uParam0->f_13, 26);
			iVar0 = 0;
			while (iVar0 < 3) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					if (!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0]) && !uParam0->f_15) {
						ai::clear_ped_tasks(uParam0->f_17[iVar0]);
					}
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
						if (func_79(uParam0, uParam0->f_17[iVar0], fParam8, 1)) {
							ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_51());
						}
					}
				}
				iVar0++;
			}
		}
	}
	if (!gameplay::is_bit_set(uParam0->f_13, 26)) {
		if (!func_78(uParam0) && ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) &&
			!entity::does_entity_exist(iParam10)) {
			iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			if (vehicle::is_vehicle_driveable(iVar13, 0)) {
				if (!gameplay::is_bit_set(uParam0->f_13, 13)) {
					if (iParam16 == 4 || iParam16 == 5) {
					}
					if (!func_59(uParam0, 2)) {
						iVar26 = 0;
						iVar27 = 0;
						iVar0 = 0;
						while (iVar0 < 3) {
							if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
								iVar26++;
							}
							iVar0++;
						}
						iVar27 = gameplay::get_random_int_in_range(0, iVar26);
						if (!ped::is_ped_injured(uParam0->f_17[iVar27])) {
							func_55(uParam0->f_17[iVar27], "NEED_A_BIGGER_VEHICLE", 3);
						}
						func_57(uParam0, "MORE_SEATS", 0);
						gameplay::set_bit(&uParam0->f_13, 13);
					}
				}
				iVar12 = 1;
			}
		}
		else {
			iVar12 = 0;
			gameplay::clear_bit(&uParam0->f_13, 13);
			func_64("MORE_SEATS");
		}
		if (!entity::does_entity_exist(iParam10)) {
			if (!ped::is_ped_injured(uParam0->f_17[0]) || !ped::is_ped_injured(uParam0->f_17[1]) ||
				!ped::is_ped_injured(uParam0->f_17[2])) {
				if (!gameplay::is_bit_set(uParam0->f_13, 31)) {
					if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) && !func_59(uParam0, 2)) {
						iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (func_77(iVar13, uParam0)) {
							func_57(uParam0, "CMN_VEHSUIT", 0);
							gameplay::set_bit(&uParam0->f_13, 31);
						}
					}
				}
				else if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
					gameplay::clear_bit(&uParam0->f_13, 31);
					func_64("CMN_VEHSUIT");
				}
			}
		}
		if (vehicle::is_vehicle_driveable(iParam10, 0)) {
			if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iParam10)) {
				if (controls::is_control_just_pressed(0, 75)) {
					gameplay::set_bit(&uParam0->f_13, 21);
				}
			}
			else if (gameplay::is_bit_set(uParam0->f_13, 21)) {
				gameplay::clear_bit(&uParam0->f_13, 21);
			}
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
						ped::set_ped_dies_in_water(uParam0->f_17[iVar0], 1);
					}
					else {
						ped::set_ped_dies_in_water(uParam0->f_17[iVar0], 0);
					}
					if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
						iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (vehicle::is_vehicle_driveable(iVar13, 0)) {
							if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
								if (!func_78(uParam0) && ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
									if (!func_76(uParam0->f_17[iVar0])) {
										ped::remove_ped_from_group(uParam0->f_17[iVar0]);
									}
								}
							}
						}
						if (iVar13 != iParam10 && !entity::is_entity_dead(iVar13, 0)) {
							if (ped::is_ped_sitting_in_vehicle(uParam0->f_17[iVar0], iVar13)) {
								if (entity::is_entity_in_water(iVar13) && !vehicle::is_vehicle_on_all_wheels(iVar13)) {
									vVar28 = {entity::get_entity_coords(iVar13, 1)};
									if (vVar28.z < -1f) {
										ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
									}
								}
							}
						}
					}
					bVar11 = true;
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
						if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
							iVar13 = ped::get_vehicle_ped_is_in(uParam0->f_17[iVar0], 0);
							if (!entity::is_entity_dead(iVar13, 0)) {
								if (vehicle::is_vehicle_driveable(iParam10, 0)) {
									if (iVar13 != iParam10) {
										if (!ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iVar13)) {
											if (entity::get_entity_speed(iVar13) > 5f) {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 4160);
											}
											else {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
											}
											bVar11 = false;
										}
									}
								}
								else {
									if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
										iVar31 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
									}
									if (vehicle::is_vehicle_driveable(iVar31, 0)) {
										if (iVar13 != iVar31) {
											if (entity::get_entity_speed(iVar13) > 5f) {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 4160);
											}
											else {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
											}
											bVar11 = false;
										}
									}
								}
							}
						}
					}
					if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
						iVar32 = ped::get_vehicle_ped_is_using(player::player_ped_id());
						if (entity::does_entity_exist(iVar32)) {
							if (func_63(iVar32, uParam0, 0)) {
								if (func_75(iVar0, uParam0) || !gameplay::is_bit_set(uParam0->f_13, 27)) {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], iVar0);
									func_74(iVar0, uParam0);
									iVar4++;
									if (iVar4 >= iVar3) {
										gameplay::set_bit(&uParam0->f_13, 27);
									}
								}
							}
							else if (!func_75(iVar0, uParam0)) {
								if (entity::get_entity_model(iVar32) == joaat("sentinel2")) {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], 4);
								}
								else {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], 2);
								}
								func_73(iVar0, uParam0);
							}
						}
					}
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51()) &&
						!func_72(uParam0->f_17[iVar0], iParam10) && !func_71(uParam0->f_17[iVar0], iParam10)) {
						if (func_79(uParam0, uParam0->f_17[iVar0], fParam8, iParam11)) {
							if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
								if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
									!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
									!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
									!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0])) {
									iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
									if (iVar14 == 7) {
										ai::clear_ped_tasks(uParam0->f_17[iVar0]);
									}
									ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_51());
									bVar11 = false;
								}
							}
						}
						if (bVar11) {
							if (!ui::does_blip_exist(uParam0->f_1[iVar0])) {
								uParam0->f_11 = gameplay::get_game_timer();
								uParam0->f_1[iVar0] = func_43(uParam0->f_17[iVar0], 0, 0);
								ui::set_blip_display(uParam0->f_1[iVar0], 2);
								if (bParam9) {
									func_53(uParam0->f_1[iVar0], uParam0);
								}
							}
						}
						iVar6 = 0;
					}
					else if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
						if (func_49(uParam0->f_17[iVar0], 1) || func_72(uParam0->f_17[iVar0], iParam10) || iParam12 ||
							vehicle::is_vehicle_driveable(iParam10, 0) &&
								!ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0)) {
							if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
								ui::remove_blip(&uParam0->f_1[iVar0]);
								func_64(uVar15[iVar0]);
							}
						}
						else {
							if (bParam9) {
								func_53(uParam0->f_1[iVar0], uParam0);
							}
							iVar6 = 0;
						}
					}
					else if (vehicle::is_vehicle_driveable(iParam10, 0)) {
						if (!ped::is_ped_sitting_in_vehicle(uParam0->f_17[iVar0], iParam10)) {
							if (entity::is_entity_at_entity(uParam0->f_17[iVar0], iParam10, 20f, 20f, 5f, 0, 1, 0) &&
								!gameplay::is_bit_set(uParam0->f_13, 11) &&
								!(bParam17 && player::is_player_wanted_level_greater(player::player_id(), 0) &&
								  !ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0))) {
								if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
									if (!ped::is_ped_in_vehicle(uParam0->f_17[iVar0], iParam10, 0)) {
										if (!func_49(uParam0->f_17[iVar0], 1)) {
											if (func_48(uParam0->f_17[iVar0])) {
												iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], 451360105);
												if (iVar14 == 7) {
													ai::task_leave_any_vehicle(uParam0->f_17[iVar0], 0, 0);
												}
											}
										}
									}
								}
								else {
									if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
										if (!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
											!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
											!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0]) &&
											!fire::is_entity_on_fire(iParam10)) {
											ped::remove_ped_from_group(uParam0->f_17[iVar0]);
										}
									}
									iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
									if (iVar14 == 7 && !func_81(uParam0->f_17[iVar0], iParam10)) {
										if (!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
											!ped::is_ped_jumping_out_of_vehicle(player::player_ped_id()) &&
											!func_70(uParam0->f_17[iVar0], 2f) &&
											!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
											!fire::is_entity_on_fire(iParam10)) {
											ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 1);
											if (gameplay::is_bit_set(uParam0->f_13, 10)) {
												ped::set_ped_max_move_blend_ratio(uParam0->f_17[iVar0], 1f);
											}
											ai::task_enter_vehicle(uParam0->f_17[iVar0], iParam10, 60000, iVar0, 2f, 1,
																   0);
											ped::set_ped_get_out_upside_down_vehicle(uParam0->f_17[iVar0], 0);
										}
									}
									else if (ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0)) {
										uParam0->f_1[iVar0] = func_43(uParam0->f_17[iVar0], 0, 0);
										ui::set_blip_display(uParam0->f_1[iVar0], 2);
										iVar6 = 0;
									}
								}
							}
							else if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
								if (func_79(uParam0, uParam0->f_17[iVar0], fParam8, iParam11)) {
									if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
										!ai::is_ped_getting_up(uParam0->f_17[iVar0])) {
										iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
										if (iVar14 == 7) {
											ai::clear_ped_tasks(uParam0->f_17[iVar0]);
										}
										ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 0);
										ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_51());
									}
								}
							}
						}
						else if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iParam10)) {
							if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_51())) {
								if (!gameplay::is_bit_set(uParam0->f_13, 21)) {
									ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_51());
								}
							}
							else if (gameplay::is_bit_set(uParam0->f_13, 21)) {
								ped::remove_ped_from_group(uParam0->f_17[iVar0]);
								gameplay::set_bit(&uParam0->f_13, 21);
							}
						}
						else if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_51()) &&
								 !fire::is_entity_on_fire(iParam10)) {
							ped::remove_ped_from_group(uParam0->f_17[iVar0]);
						}
					}
				}
				else if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
					ui::remove_blip(&uParam0->f_1[iVar0]);
					func_64(uVar15[iVar0]);
				}
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
				iVar7[iVar0] = 1;
				iVar1++;
			}
			iVar0++;
		}
		if (!func_59(uParam0, 2)) {
			if (iVar1 > 0) {
				iVar0 = 0;
				while (iVar0 < 3) {
					if (iVar7[iVar0]) {
						if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
							if (func_76(uParam0->f_17[iVar0]) ||
								entity::is_entity_at_entity(uParam0->f_17[iVar0], player::player_ped_id(), uParam0->f_8,
															uParam0->f_8, uParam0->f_8, 0, 1, 0)) {
								iVar1--;
								iVar7[iVar0] = 0;
							}
						}
					}
					else if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
						if (!entity::is_entity_at_entity(uParam0->f_17[iVar0], player::player_ped_id(),
														 uParam0->f_8 * 0.85f, uParam0->f_8 * 0.85f, uParam0->f_8, 0, 1,
														 0) &&
							!func_76(uParam0->f_17[iVar0])) {
						}
					}
					iVar0++;
				}
			}
			iVar5 = gameplay::get_game_timer();
			if (iVar5 - uParam0->f_11 > 1500 || iVar3 == 1) {
				if (iVar1 > 0) {
					if (uParam0->f_12 < iVar1) {
						if ((iVar1 == iVar3 || iVar2 + iVar1 == iVar3) && iVar3 > 1) {
							if (!gameplay::is_bit_set(uParam0->f_13, 5)) {
								func_57(uParam0, sParam7, 0);
								gameplay::set_bit(&uParam0->f_13, 5);
								uParam0->f_12 = iVar1;
							}
							else {
								uParam0->f_12 = iVar1;
							}
						}
						else {
							iVar0 = 0;
							while (iVar0 < 3) {
								if (iVar7[iVar0]) {
									if (!func_69(iVar0, uParam0)) {
										if (!gameplay::is_string_null(uVar19[iVar0])) {
											if (!gameplay::are_strings_equal(uVar19[iVar0], "")) {
												func_67(uParam0, uVar15[iVar0], uVar19[iVar0], 0);
												func_66(iVar0, uParam0);
												uParam0->f_12 = iVar1;
											}
										}
										if (!func_69(iVar0, uParam0)) {
											func_57(uParam0, uVar15[iVar0], 0);
											func_66(iVar0, uParam0);
											uParam0->f_12 = iVar1;
										}
									}
									else {
										uParam0->f_12 = iVar1;
									}
								}
								iVar0++;
							}
						}
					}
				}
				else {
					uParam0->f_12 = 0;
				}
			}
		}
		gameplay::clear_bit(&uParam0->f_13, 10);
		if (iVar6 && !iVar12) {
			iVar0 = 0;
			while (iVar0 < 3) {
				if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
					ui::remove_blip(&uParam0->f_1[iVar0]);
					func_64(uVar15[iVar0]);
				}
				iVar0++;
			}
			func_64("MORE_SEATS");
			return true;
		}
	}
	return false;
}

// Position - 0x3CDB
void func_66(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::set_bit(&uParam1->f_13, 14); break;

	case 1: gameplay::set_bit(&uParam1->f_13, 15); break;

	case 2: gameplay::set_bit(&uParam1->f_13, 16); break;
	}
}

// Position - 0x3D23
void func_67(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	if (!iParam3) {
		if (!gameplay::is_string_null(sParam1)) {
			if (!gameplay::are_strings_equal(sParam1, "")) {
				func_68(sParam1, sParam2, 7500, 1);
			}
		}
	}
	uParam0->f_10 = gameplay::get_game_timer();
}

// Position - 0x3D5C
void func_68(char *sParam0, char *sParam1, int iParam2, int iParam3) {
	iParam3 = iParam3;
	ui::begin_text_command_print(sParam0);
	ui::add_text_component_substring_text_label(sParam1);
	ui::end_text_command_print(iParam2, 1);
}

// Position - 0x3D7B
int func_69(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: return gameplay::is_bit_set(uParam1->f_13, 14);

	case 1: return gameplay::is_bit_set(uParam1->f_13, 15);

	case 2: return gameplay::is_bit_set(uParam1->f_13, 16);

	default:
	}
	return 0;
}

// Position - 0x3DC4
int func_70(int iParam0, float fParam1) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::get_entity_speed(iVar0) > fParam1) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x3DFB
int func_71(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (!ped::is_ped_group_member(iParam0, func_51())) {
			iVar0 = ped::set_exclusive_phone_relationships(iParam0);
			if (vehicle::is_vehicle_driveable(iParam1, 0)) {
				if (entity::is_entity_at_entity(iParam0, iParam1, 20f + 10f, 20f + 10f, 10f, 0, 1, 0)) {
					if (iVar0 == iParam1) {
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x3E62
int func_72(int iParam0, int iParam1) {
	if (!ped::is_ped_injured(iParam0)) {
		if (entity::does_entity_exist(iParam1)) {
			if (vehicle::is_vehicle_driveable(iParam1, 0)) {
				if (ped::is_ped_sitting_in_vehicle(iParam0, iParam1)) {
					return 1;
				}
			}
		}
	}
	return 0;
}

// Position - 0x3E97
void func_73(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::set_bit(&uParam1->f_13, 17); break;

	case 1: gameplay::set_bit(&uParam1->f_13, 18); break;

	case 2: gameplay::set_bit(&uParam1->f_13, 19); break;
	}
}

// Position - 0x3EDF
void func_74(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 17); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 18); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 19); break;
	}
}

// Position - 0x3F27
int func_75(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: return gameplay::is_bit_set(uParam1->f_13, 17);

	case 1: return gameplay::is_bit_set(uParam1->f_13, 18);

	case 2: return gameplay::is_bit_set(uParam1->f_13, 19);

	default:
	}
	return 0;
}

// Position - 0x3F70
int func_76(int iParam0) {
	int iVar0;
	int iVar1;

	if (player::is_player_playing(player::player_id())) {
		iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			if (!ped::is_ped_injured(iParam0)) {
				iVar1 = ped::get_vehicle_ped_is_using(iParam0);
				if (vehicle::is_vehicle_driveable(iVar1, 0)) {
					if (iVar0 == iVar1) {
						if (entity::is_entity_at_entity(player::player_ped_id(), iParam0, 20f, 20f, 20f, 0, 1, 0) &&
							entity::is_entity_at_entity(iParam0, iVar1, 20f, 20f, 20f, 0, 1, 0)) {
							return 1;
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x3FFD
bool func_77(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (entity::get_entity_model(iParam0) == joaat("bus") || entity::get_entity_model(iParam0) == joaat("coach")) {
			iVar0 = 0;
			iVar1 = 0;
			iVar2 = 0;
			iVar2 = 0;
			while (iVar2 < 3) {
				if (!ped::is_ped_injured(uParam1->f_17[iVar2])) {
					iVar0++;
				}
				iVar2++;
			}
			iVar3 = vehicle::get_ped_in_vehicle_seat(iParam0, 0, 0);
			if (!ped::is_ped_injured(iVar3)) {
				if (iVar3 == uParam1->f_17[0] || iVar3 == uParam1->f_17[1] || iVar3 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			iVar4 = vehicle::get_ped_in_vehicle_seat(iParam0, 1, 0);
			if (!ped::is_ped_injured(iVar4)) {
				if (iVar4 == uParam1->f_17[0] || iVar4 == uParam1->f_17[1] || iVar4 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			iVar5 = vehicle::get_ped_in_vehicle_seat(iParam0, 2, 0);
			if (!ped::is_ped_injured(iVar5)) {
				if (iVar5 == uParam1->f_17[0] || iVar5 == uParam1->f_17[1] || iVar5 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			if (iVar1 < iVar0) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x4160
bool func_78(var *uParam0) {
	int iVar0;

	if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (func_63(iVar0, uParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x418F
bool func_79(var *uParam0, int iParam1, float fParam2, int iParam3) {
	int iVar0;

	if (!ped::is_ped_injured(iParam1)) {
		if (ped::is_ped_sitting_in_any_vehicle(iParam1)) {
			iVar0 = ped::get_vehicle_ped_is_in(iParam1, 0);
			if (!entity::is_entity_dead(iVar0, 0)) {
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iVar0)) {
						if (func_78(uParam0)) {
							return true;
						}
					}
					else if (iParam3) {
						return true;
					}
				}
				else if (entity::is_entity_at_entity(player::player_ped_id(), iParam1, fParam2, fParam2, 3f, 0, 1, 0)) {
					return true;
				}
			}
		}
		else if (entity::is_entity_at_entity(player::player_ped_id(), iParam1, fParam2, fParam2, 3f, 0, 1, 0)) {
			if (!iParam3) {
				iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
				if (entity::does_entity_exist(iVar0)) {
					if (func_63(iVar0, uParam0, 0)) {
						if (vehicle::is_vehicle_driveable(iVar0, 0)) {
							if (func_80(iVar0)) {
								return true;
							}
						}
					}
				}
				else {
					return true;
				}
			}
			else {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x426D
bool func_80(int iParam0) {
	float fVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		fVar0 = entity::get_entity_speed(iParam0);
		if (fVar0 > -0.5f && fVar0 < 0.5f) {
			return true;
		}
	}
	return false;
}

// Position - 0x42A5
int func_81(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam1, 0)) {
			iVar0 = ped::get_vehicle_ped_is_using(iParam0);
			if (iVar0 == iParam1) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x42D5
void func_82() {
	int iVar0;
	int iVar1;

	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
		iVar0 = ped::set_exclusive_phone_relationships(player::player_ped_id());
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			iVar1 = vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0);
			if (!ped::is_ped_injured(iVar1)) {
				if (iVar1 != player::player_ped_id()) {
					if (entity::is_entity_a_mission_entity(iVar1)) {
						if (!ped::is_ped_headtracking_entity(iVar1, player::player_ped_id())) {
							ai::task_look_at_entity(iVar1, player::player_ped_id(), 2000, 2048, 2);
						}
					}
				}
			}
		}
	}
}

// Position - 0x4342
void func_83(var *uParam0) {
	int iVar0;

	if (!gameplay::is_bit_set(uParam0->f_13, 25)) {
		if (player::is_player_playing(player::player_id())) {
			ped::set_ped_config_flag(player::player_ped_id(), 32, 0);
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 32, 0);
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 305, 1);
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 268, 1);
					ped::set_ped_get_out_upside_down_vehicle(uParam0->f_17[iVar0], 0);
				}
			}
			iVar0++;
		}
		gameplay::set_bit(&uParam0->f_13, 25);
	}
}

// Position - 0x43E5
void func_84(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
			if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
				if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
					ped::set_ped_can_play_ambient_anims(uParam0->f_17[iVar0], 0);
					ped::set_ped_can_play_ambient_base_anims(uParam0->f_17[iVar0], 0);
				}
			}
		}
		iVar0++;
	}
	if (player::is_player_playing(player::player_id())) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
				ped::set_ped_can_play_ambient_anims(player::player_ped_id(), 0);
				ped::set_ped_can_play_ambient_base_anims(player::player_ped_id(), 0);
			}
		}
	}
}

// Position - 0x447B
int func_85() {
	var uVar0;

	return uVar0;
}

// Position - 0x4485
Vector3 func_86() {
	vector3 vVar0;

	return vVar0;
}

// Position - 0x4491
int func_87(int iParam0) {
	vector3 vVar0;

	if (entity::is_entity_dead(Local_1318, 0)) {
		return 0;
	}
	vVar0 = {gameplay::_0x21C235BC64831E5A(entity::get_entity_coords(iParam0, 1),
										   entity::get_offset_from_entity_in_world_coords(Local_1318, vLocal_87),
										   entity::get_offset_from_entity_in_world_coords(Local_1318, vLocal_90), 0)};
	if (system::vdist2(vVar0, entity::get_offset_from_entity_in_world_coords(Local_1318, vLocal_87)) <=
		system::vdist2(entity::get_offset_from_entity_in_world_coords(Local_1318, vLocal_90),
					   entity::get_offset_from_entity_in_world_coords(Local_1318, vLocal_87))) {
		return 1;
	}
	return 0;
}

// Position - 0x4507
void func_88(int iParam0, int iParam1) {
	int iVar0;

	if (Global_55830) {
	}
	Global_55830 = 0;
	if (iParam0) {
		Global_55831 = 1;
	}
	iVar0 = 0;
	if (iParam1 == -1) {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (MissionObjectives[Global_67918[iVar0 /*9*/] /*13*/] == 4) {
				Global_67918[iVar0 /*9*/].f_5 = 0;
				return;
			}
			iVar0++;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (Global_67918[iVar0 /*9*/] > 0) {
				if (Global_67918[iVar0 /*9*/] == iParam1) {
					Global_67918[iVar0 /*9*/].f_5 = 0;
					return;
				}
			}
			iVar0++;
		}
	}
}

// Position - 0x45A1
bool func_89(int iParam0, float fParam1, int iParam2, float fParam3, int iParam4, int iParam5, int iParam6) {
	controls::disable_control_action(0, 71, 1);
	controls::disable_control_action(0, 72, 1);
	controls::disable_control_action(0, 76, 1);
	controls::disable_control_action(0, 73, 1);
	controls::disable_control_action(0, 59, 1);
	controls::disable_control_action(0, 60, 1);
	if (iParam5) {
		controls::disable_control_action(0, 75, 1);
	}
	controls::disable_control_action(0, 80, 1);
	if (!iParam6) {
		controls::disable_control_action(0, 69, 1);
		controls::disable_control_action(0, 70, 1);
		controls::disable_control_action(0, 68, 1);
	}
	controls::disable_control_action(0, 74, 1);
	controls::disable_control_action(0, 86, 1);
	controls::disable_control_action(0, 81, 1);
	controls::disable_control_action(0, 82, 1);
	controls::disable_control_action(0, 138, 1);
	controls::disable_control_action(0, 136, 1);
	controls::disable_control_action(0, 114, 1);
	controls::disable_control_action(0, 107, 1);
	controls::disable_control_action(0, 110, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 87, 1);
	controls::disable_control_action(0, 88, 1);
	controls::disable_control_action(0, 113, 1);
	controls::disable_control_action(0, 115, 1);
	controls::disable_control_action(0, 116, 1);
	controls::disable_control_action(0, 117, 1);
	controls::disable_control_action(0, 118, 1);
	controls::disable_control_action(0, 119, 1);
	controls::disable_control_action(0, 131, 1);
	controls::disable_control_action(0, 132, 1);
	controls::disable_control_action(0, 123, 1);
	controls::disable_control_action(0, 126, 1);
	controls::disable_control_action(0, 129, 1);
	controls::disable_control_action(0, 130, 1);
	controls::disable_control_action(0, 133, 1);
	controls::disable_control_action(0, 134, 1);
	cam::_0x17FCA7199A530203();
	func_90(iParam0);
	if (gameplay::get_game_timer() - Global_29 > 500) {
		vehicle::_set_vehicle_halt(iParam0, fParam1, iParam2, iParam4);
	}
	Global_29 = gameplay::get_game_timer();
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (gameplay::absf(entity::get_entity_speed(iParam0)) <= fParam3) {
			return true;
		}
	}
	return false;
}

// Position - 0x4730
void func_90(int iParam0) {
	if (vehicle::_get_has_vehicle_got_rocket_boost(iParam0)) {
		if (vehicle::_is_vehicle_rocket_boost_active(iParam0)) {
			vehicle::_set_rocket_boost_active(iParam0, 0);
		}
	}
}

// Position - 0x4751
bool func_91(var *uParam0, vector3 vParam1, vector3 vParam4, vector3 vParam7, float fParam10, int iParam11,
			 int iParam12, char *sParam13, char *sParam14, char *sParam15, bool bParam16, int iParam17, int iParam18,
			 int iParam19) {
	return func_42(uParam0, vParam1, func_92(), vParam4, vParam7, iParam11, 5, 0, 0, 0, iParam12, sParam13, func_85(),
				   func_85(), func_85(), func_85(), sParam14, 0, bParam16, sParam15, 1, iParam17, iParam18, iParam19,
				   func_85(), func_85(), func_85(), 1, fParam10);
}

// Position - 0x47A6
Vector3 func_92() { return 0f, 0f, 2f; }

// Position - 0x47B1
int func_93(int iParam0) { return func_44(iParam0, 1, 0); }

// Position - 0x47C1
int func_94(var *uParam0, vector3 vParam1, vector3 vParam4, int iParam7, int iParam8, char *sParam9, char *sParam10,
			char *sParam11, int iParam12, int iParam13, int iParam14, int iParam15) {
	return func_42(uParam0, vParam1, vParam4, func_86(), func_86(), iParam7, 5, 0, 0, 0, iParam8, sParam9, func_85(),
				   func_85(), func_85(), func_85(), sParam10, 0, iParam12, sParam11, 0, iParam13, iParam14, iParam15, 0,
				   0, 0, 1, 1065353216);
}

// Position - 0x4810
void func_95(int iParam0, int iParam1) {
	int iVar0;

	Global_55832 = iParam0;
	if (!Global_55830) {
		Global_55830 = 1;
	}
	if (iParam1) {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (Global_67918[iVar0 /*9*/] == iParam0) {
				Global_67918[iVar0 /*9*/].f_1 = 0;
			}
			iVar0++;
		}
	}
}

// Position - 0x485A
void func_96(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (gameplay::is_bit_set(iParam0->f_13, 30)) {
		iParam1 = 1;
	}
	func_98(iParam0);
	iVar0 = 0;
	while (iVar0 < 3) {
		if (ui::does_blip_exist(iParam0->f_1[iVar0])) {
			ui::remove_blip(&iParam0->f_1[iVar0]);
		}
		func_97(iVar0, iParam0);
		func_74(iVar0, iParam0);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 31) {
		if (iVar0 != 8) {
			gameplay::clear_bit(&iParam0->f_13, iVar0);
			gameplay::clear_bit(&iParam0->f_14, iVar0);
		}
		iVar0++;
	}
	if (ui::does_blip_exist(*iParam0)) {
		ui::remove_blip(iParam0);
	}
	iParam0->f_6 = 0;
	iParam0->f_12 = 0;
	iParam0->f_15 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(iParam0->f_17[iVar0])) {
			ped::set_ped_can_play_ambient_anims(iParam0->f_17[iVar0], 1);
			ped::set_ped_can_play_ambient_base_anims(iParam0->f_17[iVar0], 1);
			if (iParam2) {
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 32, 1);
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 305, 0);
			}
			ped::set_ped_config_flag(iParam0->f_17[iVar0], 268, 0);
			if (iParam1) {
				if (ped::is_ped_group_member(iParam0->f_17[iVar0], func_51()) &&
					iParam0->f_17[iVar0] != player::player_ped_id()) {
					ped::remove_ped_from_group(iParam0->f_17[iVar0]);
				}
			}
			if (!gameplay::is_bit_set(iParam0->f_13, 29)) {
				ped::set_ped_using_action_mode(iParam0->f_17[iVar0], 0, -1, 0);
			}
			iParam0->f_17[iVar0] = 0;
		}
		iVar0++;
	}
	if (player::is_player_playing(player::player_id())) {
		ped::set_ped_can_play_ambient_anims(player::player_ped_id(), 1);
		ped::set_ped_can_play_ambient_base_anims(player::player_ped_id(), 1);
	}
	if (player::is_player_playing(player::player_id())) {
		if (iParam2) {
			ped::set_ped_config_flag(player::player_ped_id(), 32, 1);
		}
	}
	iParam0->f_21 = 0;
}

// Position - 0x4A0B
void func_97(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 14); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 15); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 16); break;
	}
}

// Position - 0x4A53
void func_98(var *uParam0) {
	if (ui::does_blip_exist(uParam0->f_5)) {
		ui::remove_blip(&uParam0->f_5);
	}
}

// Position - 0x4A6E
void func_99(int *iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_100(iParam0, iParam1, 0f, 0f, 0f, sParam2, iParam3, iParam4, iParam5, iParam6);
}

// Position - 0x4A8B
void func_100(int *iParam0, int iParam1, vector3 vParam2, char *sParam5, int iParam6, bool bParam7, var uParam8,
			  bool bParam9) {
	func_101(iParam0, iParam1, vParam2, sParam5, iParam6, bParam7, uParam8, bParam9);
}

// Position - 0x4AA9
void func_101(int *iParam0, int iParam1, vector3 vParam2, char *sParam5, int iParam6, bool bParam7, var uParam8,
			  bool bParam9) {
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
		func_11(iParam0, 0, 0);
	}
	iParam0->f_6 = 2;
	func_102(iParam0, iParam1, vParam2, sParam5, iParam6, bParam7, uParam8, bParam9);
}

// Position - 0x4AE1
void func_102(int *iParam0, int iParam1, vector3 vParam2, char *sParam5, int iParam6, bool bParam7, var uParam8,
			  bool bParam9) {
	int iVar0;
	int iVar1;

	if (iParam0->f_1 && cam::is_gameplay_hint_active()) {
		if (gameplay::get_game_timer() >= iParam0->f_8 + iParam0->f_9) {
			iParam0->f_1 = 0;
		}
	}
	iVar0 = sParam5;
	if (gameplay::is_string_null(iVar0)) {
		if (!network::network_is_game_in_progress()) {
			iVar0 = "CMN_HINT";
		}
		else {
			iVar0 = "FM_IHELP_HNT";
		}
	}
	if (func_12(iVar0)) {
		func_119();
	}
	if (func_118(iParam1) && entity::is_entity_visible(iParam1)) {
		iVar1 = 0;
		if (entity::is_entity_a_ped(iParam1)) {
			ped::_0x7D7A2E43E74E2EB8(entity::get_ped_index_from_entity_index(iParam1));
			ped::get_ped_flood_invincibility(entity::get_ped_index_from_entity_index(iParam1), 1);
			if (ped::is_tracked_ped_visible(entity::get_ped_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		else if (entity::is_entity_a_vehicle(iParam1)) {
			vehicle::track_vehicle_visibility(entity::get_vehicle_index_from_entity_index(iParam1));
			if (vehicle::is_vehicle_visible(entity::get_vehicle_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		else if (entity::is_entity_an_object(iParam1)) {
			object::track_object_visibility(entity::get_object_index_from_entity_index(iParam1));
			if (object::is_object_visible(entity::get_object_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		if (!cam::is_gameplay_hint_active()) {
			if (func_113(iParam0, bParam7, bParam9, 0)) {
				func_109(iParam0, iParam1, vParam2, iParam6);
			}
			if (*iParam0) {
				*iParam0 = 0;
			}
			else if (iParam0->f_6 == 2) {
				if (func_106(iVar0)) {
					if (gameplay::is_string_null(iParam0->f_3) && !gameplay::is_string_null(iVar0) &&
						ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						if (iVar1 && !ui::is_help_message_being_displayed() && uParam8) {
							if (!func_12(iVar0)) {
								func_180(iVar0, -1);
								iParam0->f_3 = iVar0;
								if (gameplay::are_strings_equal("CMN_HINT", iVar0)) {
									func_105(1);
								}
							}
						}
					}
				}
			}
			else if (func_106(iVar0)) {
				if (gameplay::is_string_null(iParam0->f_3) && !gameplay::is_string_null(iVar0)) {
					if (entity::is_entity_on_screen(iParam1) && iVar1 && !ui::is_help_message_being_displayed() &&
						uParam8) {
						if (!func_12(iVar0)) {
							func_180(iVar0, -1);
							iParam0->f_3 = iVar0;
							if (gameplay::are_strings_equal("CMN_HINT", iVar0)) {
								func_105(1);
							}
						}
					}
				}
			}
		}
		else {
			if (!gameplay::is_string_null(sParam5)) {
				if (func_12(sParam5)) {
					ui::clear_help(1);
				}
			}
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (ped::is_ped_in_any_boat(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(3) == 3 || cam::_0xEE778F8C7E1142E2(3) == 4) {
						func_11(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_heli(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(6) == 3 || cam::_0xEE778F8C7E1142E2(6) == 4) {
						func_11(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_plane(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(4) == 3 || cam::_0xEE778F8C7E1142E2(4) == 4) {
						func_11(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_sub(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(5) == 3 || cam::_0xEE778F8C7E1142E2(5) == 4) {
						func_11(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_on_any_bike(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(2) == 3 || cam::_0xEE778F8C7E1142E2(2) == 4) {
						func_11(iParam0, iVar0, 1);
					}
				}
				else if (cam::get_follow_vehicle_cam_view_mode() == 3 || cam::get_follow_vehicle_cam_view_mode() == 4) {
					func_11(iParam0, iVar0, 1);
				}
			}
			if (!func_113(iParam0, bParam7, bParam9, 0)) {
				if (!*iParam0 && !iParam0->f_1 && !func_104(iParam0)) {
					func_103(iParam0);
				}
			}
		}
	}
	else {
		func_11(iParam0, iVar0, 0);
	}
}

// Position - 0x4E4A
void func_103(int *iParam0) {
	if (func_118(player::player_ped_id())) {
		ai::task_clear_look_at(player::player_ped_id());
	}
	if (cam::is_gameplay_hint_active()) {
		cam::set_cinematic_button_active(1);
		cam::stop_gameplay_hint(0);
		audio::stop_audio_scene("HINT_CAM_SCENE");
		graphics::_stop_screen_effect("FocusIn");
		if (iParam0->f_11) {
			graphics::_start_screen_effect("FocusOut", 0, 0);
			audio::play_sound_frontend(-1, "FocusOut", "HintCamSounds", 1);
			iParam0->f_11 = 0;
		}
	}
	iParam0->f_2 = -1;
	*iParam0 = 1;
}

// Position - 0x4EAE
bool func_104(var *uParam0) {
	int iVar0;

	if (uParam0->f_2 > 0) {
		iVar0 = uParam0->f_10 / 2;
		if (uParam0->f_2 + iVar0 > gameplay::get_game_timer()) {
			return true;
		}
	}
	return false;
}

// Position - 0x4ED9
int func_105(int iParam0) {
	switch (Global_35781) {
	case 0:
	case 3:
		if (iParam0) {
			Global_101700.f_9008.f_100++;
		}
		return Global_101700.f_9008.f_100;

	case 4:
		if (iParam0) {
			Global_101700.f_9008.f_101++;
		}
		return Global_101700.f_9008.f_101;

	case 5:
	case 15:
		if (iParam0) {
			Global_101700.f_9008.f_102++;
		}
		return Global_101700.f_9008.f_102;

	default: break;
	}
	return 3;
}

// Position - 0x4F83
bool func_106(char *sParam0) {
	if (!func_107(1, 1, 0)) {
		if (!gameplay::is_string_null_or_empty(sParam0) && func_12(sParam0) || func_12("CMN_HINT")) {
			ui::clear_help(1);
		}
		return false;
	}
	switch (Global_35781) {
	case 0:
	case 3:
		if (func_105(0) < 3) {
			return true;
		}
		break;

	case 4:
		if (func_105(0) < 1) {
			return true;
		}
		break;

	case 5:
	case 15:
		if (func_105(0) < 1) {
			return true;
		}
		break;

	default: break;
	}
	return false;
}

// Position - 0x501B
int func_107(int iParam0, int iParam1, int iParam2) {
	if (iParam0) {
		if (!player::is_player_control_on(player::player_id())) {
			return 0;
		}
	}
	if (iParam2) {
		return 1;
	}
	if (streaming::is_player_switch_in_progress()) {
		return 0;
	}
	if (func_17(0)) {
		return 0;
	}
	if (func_108()) {
		return 0;
	}
	if (network::_network_is_text_chat_active()) {
		return 0;
	}
	if (G_DisableMessagesAndCalls2) {
		return 0;
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) > 0) {
		return 0;
	}
	if (Global_53003) {
		return 0;
	}
	if (iParam1) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
			if (ped::is_ped_in_any_boat(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(3) == 3 || cam::_0xEE778F8C7E1142E2(3) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_heli(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(6) == 3 || cam::_0xEE778F8C7E1142E2(6) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_plane(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(4) == 3 || cam::_0xEE778F8C7E1142E2(4) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_sub(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(5) == 3 || cam::_0xEE778F8C7E1142E2(5) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_on_any_bike(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(2) == 3 || cam::_0xEE778F8C7E1142E2(2) == 4) {
					return 0;
				}
			}
			else if (cam::get_follow_vehicle_cam_view_mode() == 3 || cam::get_follow_vehicle_cam_view_mode() == 4) {
				return 0;
			}
			if (cam::is_gameplay_cam_looking_behind()) {
				return 0;
			}
		}
	}
	return 1;
}

// Position - 0x5197
bool func_108() { return gameplay::get_game_timer() <= Global_17290.f_5745 + 100; }

// Position - 0x51AC
void func_109(int *iParam0, int iParam1, vector3 vParam2, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	if (entity::is_entity_dead(iParam1, 0)) {
		func_11(iParam0, 0, 0);
	}
	if (func_112(vParam2, 0f, 0f, 0f, 0)) {
		if (entity::is_entity_a_ped(iParam1)) {
			iVar0 = entity::get_ped_index_from_entity_index(iParam1);
			if (!ped::is_ped_in_any_vehicle(iVar0, 0)) {
				if (ped::is_ped_a_player(iVar0)) {
					if (!func_110()) {
						vParam2 = {0f, 0f, 1f};
					}
				}
				else if (ped::is_ped_male(iVar0)) {
					vParam2 = {0f, 0f, 1f};
				}
			}
		}
	}
	cam::set_cinematic_button_active(0);
	iVar1 = iParam0->f_9;
	iVar2 = iParam0->f_10;
	if (iParam5 == 1726668277) {
		if (iVar1 < 1500) {
			iVar1 = 1500;
		}
		if (iVar2 < 1500) {
			iVar2 = 1500;
		}
	}
	cam::set_gameplay_entity_hint(iParam1, vParam2, 1, -1, iVar1, iVar2, iParam5);
	iVar3 = 2048;
	iVar4 = 3;
	ai::task_look_at_entity(player::player_ped_id(), iParam1, -1, iVar3, iVar4);
	graphics::_start_screen_effect("FocusIn", 0, 0);
	audio::start_audio_scene("HINT_CAM_SCENE");
	audio::play_sound_frontend(-1, "FocusIn", "HintCamSounds", 1);
	iParam0->f_11 = 1;
	iParam0->f_8 = gameplay::get_game_timer();
	iParam0->f_1 = 1;
	*iParam0 = 0;
}

// Position - 0x52AD
int func_110() { return func_111(player::player_id()); }

// Position - 0x52BD
int func_111(int iParam0) {
	if (entity::get_entity_model(player::get_player_ped(iParam0)) == joaat("mp_f_freemode_01")) {
		return 1;
	}
	return 0;
}

// Position - 0x52DC
bool func_112(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x5323
bool func_113(var *uParam0, bool bParam1, bool bParam2, int iParam3) {
	if (uParam0->f_1) {
		if (gameplay::get_game_timer() >= uParam0->f_8 + uParam0->f_9) {
			uParam0->f_1 = 0;
		}
	}
	switch (uParam0->f_5) {
	case 0:
		uParam0->f_7 = 0;
		if (uParam0->f_6 == 0) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (func_117(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 1;
					uParam0->f_7 = 1;
				}
			}
			else if (func_116(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		else if (uParam0->f_6 == 1) {
			if (func_116(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		else if (uParam0->f_6 == 2) {
			if (func_117(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		if (func_104(uParam0)) {
			uParam0->f_7 = 1;
			uParam0->f_5 = 4;
		}
		break;

	case 1:
		if (gameplay::get_game_timer() - uParam0->f_4 <= 500) {
			if (uParam0->f_6 == 0) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
					if (!func_117(bParam1, bParam2, iParam3)) {
						uParam0->f_4 = gameplay::get_game_timer();
						uParam0->f_5 = 3;
					}
				}
				else if (!func_116(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
			else if (uParam0->f_6 == 1) {
				if (!func_116(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
			else if (uParam0->f_6 == 2) {
				if (!func_117(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
		}
		else {
			uParam0->f_5 = 2;
		}
		break;

	case 2:
		if (uParam0->f_6 == 0) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (!func_117(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (!func_116(bParam1, bParam2, iParam3)) {
				uParam0->f_5 = 0;
			}
		}
		else if (uParam0->f_6 == 1) {
			if (!func_116(bParam1, bParam2, iParam3) || ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				uParam0->f_5 = 0;
			}
		}
		else if (uParam0->f_6 == 2) {
			if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
				ai::get_is_task_active(player::player_ped_id(), 2)) {
				uParam0->f_5 = 0;
			}
			else if (!func_117(bParam1, bParam2, iParam3)) {
				uParam0->f_5 = 0;
			}
		}
		break;

	case 3:
		if (gameplay::get_game_timer() - uParam0->f_4 > 500) {
			if (uParam0->f_6 == 0) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
					if (func_115(bParam1, bParam2, iParam3)) {
						uParam0->f_5 = 0;
					}
				}
				else if (func_114(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (uParam0->f_6 == 1) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) || func_114(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (uParam0->f_6 == 2) {
				if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
					ai::get_is_task_active(player::player_ped_id(), 2)) {
					uParam0->f_5 = 0;
				}
				else if (func_115(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
		}
		break;

	case 4:
		if (!func_104(uParam0)) {
			uParam0->f_5 = 0;
		}
		break;
	}
	if (!func_107(bParam1, bParam2, iParam3)) {
		uParam0->f_5 = 0;
		uParam0->f_7 = 0;
	}
	if (uParam0->f_7) {
		func_119();
		return true;
	}
	else {
		return false;
	}
	return false;
}

// Position - 0x568F
bool func_114(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_107(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!player::is_player_targetting_anything(player::player_id())) {
			controls::disable_control_action(0, 140, 1);
			controls::disable_control_action(0, 80, 1);
			if (controls::is_disabled_control_just_released(0, 80)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x56E1
bool func_115(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_107(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		controls::disable_control_action(0, 80, 1);
		if (cam::is_follow_vehicle_cam_active()) {
			if (controls::is_disabled_control_just_released(0, 80)) {
				cam::set_cinematic_button_active(0);
				return true;
			}
		}
	}
	return false;
}

// Position - 0x572A
bool func_116(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_107(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!player::is_player_targetting_anything(player::player_id())) {
			controls::disable_control_action(0, 140, 1);
			controls::disable_control_action(0, 80, 1);
			if (controls::is_disabled_control_pressed(0, 80) && gameplay::get_game_timer() > Global_116) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x5789
bool func_117(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_107(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		controls::disable_control_action(0, 80, 1);
		if (cam::is_follow_vehicle_cam_active()) {
			if (controls::is_disabled_control_pressed(0, 80) && gameplay::get_game_timer() > Global_116) {
				cam::set_cinematic_button_active(0);
				return true;
			}
		}
	}
	return false;
}

// Position - 0x57DF
bool func_118(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (entity::is_entity_a_vehicle(iParam0)) {
			if (vehicle::is_vehicle_driveable(entity::get_vehicle_index_from_entity_index(iParam0), 0)) {
				return true;
			}
		}
		else if (entity::is_entity_a_ped(iParam0)) {
			if (!ped::is_ped_injured(entity::get_ped_index_from_entity_index(iParam0))) {
				return true;
			}
		}
		else if (entity::is_entity_an_object(iParam0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x583A
void func_119() { gameplay::set_bit(&G_SleepModeOffOn11, 4); }

// Position - 0x584A
int func_120(var *uParam0) {
	if (func_122(uParam0) && !func_121(uParam0)) {
		return 1;
	}
	return 0;
}

// Position - 0x586F
bool func_121(var *uParam0) {
	if (*uParam0 == 4) {
		return true;
	}
	return false;
}

// Position - 0x5886
int func_122(var *uParam0) {
	if (*uParam0 != 0 && (*uParam0 != 2 || uParam0->f_1 > 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x58B4
void func_123() {
	int iVar0;

	if (iLocal_1303 == 0 || iLocal_1303 == 1) {
		if (entity::is_entity_dead(Local_1318, 0) ||
			entity::does_entity_exist(Local_1322[0 /*2*/]) && !entity::is_entity_attached(Local_1322[0 /*2*/]) ||
			entity::does_entity_exist(Local_1322[1 /*2*/]) && !entity::is_entity_attached(Local_1322[1 /*2*/]) ||
			entity::does_entity_exist(Local_1322[2 /*2*/]) && !entity::is_entity_attached(Local_1322[2 /*2*/])) {
			iLocal_1303 = 2;
		}
	}
	if (iLocal_1303 == 2) {
		if (!entity::does_entity_exist(Local_1318) || !vehicle::is_vehicle_driveable(Local_1318, 0) ||
			entity::does_entity_exist(Local_1322[0 /*2*/]) && !func_87(Local_1322[0 /*2*/]) ||
			entity::does_entity_exist(Local_1322[1 /*2*/]) && !func_87(Local_1322[1 /*2*/]) ||
			entity::does_entity_exist(Local_1322[2 /*2*/]) && !func_87(Local_1322[2 /*2*/])) {
			iLocal_1303 = 3;
		}
	}
	if (iLocal_1303 == 0) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			if (entity::get_entity_model(iVar0) == joaat("towtruck") ||
				entity::get_entity_model(iVar0) == joaat("towtruck2")) {
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (vehicle::is_vehicle_attached_to_tow_truck(iVar0, Local_1318)) {
						iLocal_1320 = iVar0;
					}
				}
			}
		}
	}
	if (iLocal_1303 == 0) {
		if (!vehicle::is_vehicle_driveable(Local_1318, 0)) {
			iLocal_1303 = 1;
		}
	}
	if (iLocal_1303 == 1 && ped::is_ped_in_vehicle(player::player_ped_id(), Local_1318, 1)) {
		func_9(6, 1);
	}
	else {
		func_9(6, 0);
	}
}

// Position - 0x5A5C
void func_124(vector3 vParam0, float *fParam3, int iParam4, int iParam5) {
	vector3 vVar0;
	float *fVar3;

	if (entity::does_entity_exist(Global_93635.f_4)) {
		if (vehicle::is_vehicle_driveable(Global_93635.f_4, 0)) {
			if (func_175(24) != Global_93635.f_4) {
				if (iParam4 == 1) {
					if (func_172(entity::get_entity_coords(Global_93635.f_4, 1), iParam5, &vVar0, &fVar3)) {
						vParam0 = {vVar0};
						fParam3 = fVar3;
					}
				}
				func_125(Global_93635.f_4, vParam0, fParam3, 24, 0);
			}
		}
	}
}

// Position - 0x5AD7
void func_125(int iParam0, vector3 vParam1, float *fParam4, int iParam5, int iParam6) {
	struct<60> Var0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (iParam5 != 24 && iParam5 != 25) {
			return;
		}
		if (iParam5 == 24) {
			if (entity::does_entity_exist(Global_68531.f_484[25]) &&
				vehicle::is_vehicle_driveable(Global_68531.f_484[25], 0)) {
				if (Global_68531.f_484[25] == iParam0) {
					return;
				}
			}
		}
		if (!iParam6) {
			if (vehicle::is_big_vehicle(iParam0) || entity::get_entity_model(iParam0) == joaat("bus") ||
				entity::get_entity_model(iParam0) == joaat("tourbus")) {
				return;
			}
		}
		func_171(iParam5);
		Var0.f_9 = 49;
		Var0.f_59 = 2;
		func_167(iParam0, &Var0);
		if (func_112(vParam1, 0f, 0f, 0f, 0)) {
			vParam1 = {entity::get_entity_coords(iParam0, 1)};
			fParam4 = entity::get_entity_heading(iParam0);
		}
		if (iParam5 == 24) {
			if (gameplay::get_hash_key(script::get_this_script_name()) != joaat("vehicle_gen_controller")) {
				Global_69519 = gameplay::get_hash_key(script::get_this_script_name());
			}
		}
		func_160(iParam5, &Var0, vParam1, fParam4, func_166(iParam0));
		func_126(iParam5, iParam0, 0);
	}
}

// Position - 0x5C00
void func_126(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (iParam0 == -1) {
		return;
	}
	if (!func_156(&Global_68531.f_555[0 /*21*/], iParam0)) {
		return;
	}
	if (!gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 12) &&
		!gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
		if (Global_68531.f_555[0 /*21*/].f_4 != entity::get_entity_model(iParam1)) {
			return;
		}
	}
	if (Global_69438 != -1 && Global_69438 != iParam0) {
		return;
	}
	if (entity::does_entity_exist(iParam1)) {
		if (vehicle::is_vehicle_driveable(iParam1, 0)) {
			if (!entity::is_entity_a_mission_entity(iParam1)) {
				entity::set_entity_as_mission_entity(iParam1, 1, 1);
			}
			if (iParam0 == 24) {
				Global_101700.f_31389.f_4801 = func_145();
			}
			if (iParam1 != Global_68531.f_139[iParam0]) {
				if (iParam0 == 24) {
					iVar0 = func_175(iParam0);
					if (entity::does_entity_exist(iVar0) && vehicle::is_vehicle_driveable(iVar0, 0) &&
						iParam1 != iVar0) {
						func_127(iVar0, 145);
					}
				}
				Global_69437 = iParam1;
				Global_69438 = iParam0;
				Global_69439 = iParam2;
			}
		}
	}
}

// Position - 0x5D1D
void func_127(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_128(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_167(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x5F1F
int func_128(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_143(iParam0, 0, 0) ||
		func_143(iParam0, 1, 0) || func_143(iParam0, 2, 0) || func_166(iParam0) != 145 || func_142(iParam0) ||
		func_141(iParam0) || func_140(iParam0) || func_139(iParam0) || !func_129(entity::get_entity_model(iParam0))) {
		if (func_141(iParam0)) {
		}
		if (func_141(iParam0)) {
		}
		if (func_143(iParam0, 0, 0)) {
		}
		if (func_143(iParam0, 1, 0)) {
		}
		if (func_143(iParam0, 2, 0)) {
		}
		if (func_166(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x5FFC
int func_129(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_130(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x61AD
int func_130(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_138()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_137() && !func_136() && !func_135() && !func_134() && !func_138()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_135()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_133(iParam0)) {
			return 0;
		}
	}
	if (!func_131(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x633B
int func_131(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_132()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x6407
int func_132() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x641B
int func_133(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x715E
int func_134() { return 0; }

// Position - 0x7167
int func_135() { return 1; }

// Position - 0x7170
int func_136() { return 1; }

// Position - 0x7179
int func_137() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x7192
bool func_138() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x724D
int func_139(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_130(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x7293
int func_140(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x72CE
bool func_141(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x734A
int func_142(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x7432
bool func_143(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_144(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x74A3
bool func_144(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x757B
var func_145() {
	int *iVar0;

	func_155(&iVar0, time::get_clock_seconds());
	func_154(&iVar0, time::get_clock_minutes());
	func_153(&iVar0, time::get_clock_hours());
	func_148(&iVar0, time::get_clock_day_of_month());
	func_147(&iVar0, time::get_clock_month());
	func_146(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x75C1
void func_146(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x7647
void func_147(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x767A
void func_148(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_152(*uParam0);
	iVar1 = func_150(*uParam0);
	if (iParam1 < 1 || iParam1 > func_149(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x76CB
int func_149(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x776D
var func_150(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_151(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x7792
int func_151(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x77A9
int func_152(var uParam0) { return uParam0 & 15; }

// Position - 0x77B6
void func_153(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x77F0
void func_154(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x782B
void func_155(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x7867
bool func_156(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_157(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_157(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_157(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_157(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_157(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_157(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_157(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_157(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_157(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_138()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_138()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_112(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_112(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_112(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0x8F5F
int func_157(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_159(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_158(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x8FA1
void func_158(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0x91FD
bool func_159(int iParam0) { return iParam0 < 3; }

// Position - 0x9209
void func_160(int iParam0, var *uParam1, vector3 vParam2, var uParam5, int iParam6) {
	if (func_156(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
			func_165(iParam0);
			func_164(uParam1, &Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/]);
			if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 11)) {
				Global_101700.f_31389.f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {vParam2};
				Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] = uParam5;
			}
			else {
				Global_101700.f_31389.f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {0f, 0f, 0f};
				Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] = -1f;
			}
			Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] = iParam6 + 1;
			func_161(iParam0, 1);
		}
	}
}

// Position - 0x9308
void func_161(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_163(iParam0, 0)) {
			func_162(iParam0, 1, 0);
			func_162(iParam0, 2, 0);
			func_162(iParam0, 3, 0);
			func_162(iParam0, 4, 0);
			func_162(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_162(iParam0, 0, 0);
	}
}

// Position - 0x9365
void func_162(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0x93A0
int func_163(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x93C3
void func_164(var *uParam0, var *uParam1) {
	uParam1->f_66 = uParam0->f_66;
	*uParam1 = *uParam0;
	uParam1->f_1 = {uParam0->f_1};
	uParam1->f_5 = uParam0->f_5;
	uParam1->f_6 = uParam0->f_6;
	uParam1->f_7 = uParam0->f_7;
	uParam1->f_8 = uParam0->f_8;
	uParam1->f_9 = {uParam0->f_9};
	uParam1->f_59 = {uParam0->f_59};
	uParam1->f_62 = uParam0->f_62;
	uParam1->f_63 = uParam0->f_63;
	uParam1->f_64 = uParam0->f_64;
	uParam1->f_65 = uParam0->f_65;
	uParam1->f_77 = uParam0->f_77;
	uParam1->f_67 = uParam0->f_67;
	uParam1->f_69 = uParam0->f_69;
	uParam1->f_68 = uParam0->f_68;
	uParam1->f_71 = uParam0->f_71;
	uParam1->f_72 = uParam0->f_72;
	uParam1->f_73 = uParam0->f_73;
	uParam1->f_74 = uParam0->f_74;
	uParam1->f_75 = uParam0->f_75;
	uParam1->f_76 = uParam0->f_76;
}

// Position - 0x948F
void func_165(int iParam0) {
	if (iParam0 == -1) {
		return;
	}
	if (func_156(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
			entity::set_vehicle_as_no_longer_needed(&Global_68531.f_139[iParam0]);
			Global_68531.f_139[iParam0] = 0;
		}
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			func_161(iParam0, 0);
		}
	}
}

// Position - 0x9509
int func_166(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x956C
void func_167(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_170(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_169(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_168(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0x9818
int func_168(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0x98C8
int func_169(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x99A2
void func_170(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0x9A52
void func_171(int iParam0) {
	if (iParam0 != 24 && iParam0 != 25) {
	}
	func_165(iParam0);
	func_161(iParam0, 0);
}

// Position - 0x9A79
bool func_172(vector3 vParam0, int iParam3, var *uParam4, float *fParam5) {
	int iVar0;

	iVar0 = func_173(vParam0, iParam3, 1);
	switch (iVar0) {
	case 0:
		*uParam4 = {-827.351f, 157.785f, 68.2143f};
		*fParam5 = 85.1509f;
		return true;

	case 1:
	case 2:
		*uParam4 = {1992.523f, 3813.916f, 31.1008f};
		*fParam5 = 122.1498f;
		return true;

	case 3:
		*uParam4 = {-1184.258f, -1496.556f, 3.3895f};
		*fParam5 = 303.2098f;
		return true;

	case 4:
		*uParam4 = {118.1067f, -1325.906f, 28.3706f};
		*fParam5 = 123.5016f;
		return true;

	case 5:
		*uParam4 = {-18.118f, -1455.126f, 29.5004f};
		*fParam5 = 273.2822f;
		return true;

	case 6:
		*uParam4 = {1.5947f, 543.4017f, 173.4644f};
		*fParam5 = 310.7556f;
		return true;

	default: break;
	}
	return false;
}

// Position - 0x9B8F
int func_173(vector3 vParam0, int iParam3, int iParam4) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = 10;
	iVar0 = 0;
	while (iVar0 <= 10 - 1) {
		if (Global_86862[iVar0 /*10*/].f_7 != 263) {
			if (Global_86862[iVar0 /*10*/].f_9 == iParam3 || iParam3 == 145) {
				if (func_174(iVar0) || iParam4 == 0) {
					fVar1 = gameplay::get_distance_between_coords(vParam0, Global_86862[iVar0 /*10*/].f_3, 1);
					if (fVar1 < fVar2) {
						fVar2 = fVar1;
						iVar3 = iVar0;
					}
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x9C1E
var func_174(int iParam0) { return gameplay::is_bit_set(Global_101700.f_6188[iParam0], 0); }

// Position - 0x9C36
int func_175(int iParam0) {
	if (iParam0 == -1) {
		return 0;
	}
	return Global_68531.f_139[iParam0];
}

// Position - 0x9C52
int func_176() {
	func_177();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x9C6B
void func_177() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_179(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_178(player::player_ped_id());
			if (func_159(iVar0) && (!func_30(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_159(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x9D68
int func_178(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_179(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x9DA5
int func_179(int iParam0) {
	if (func_159(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x9DCF
void func_180(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x9DE6
void func_181(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 1);
}

// Position - 0x9DFF
int func_182(int iParam0, int iParam1, int iParam2) { return func_44(iParam0, !iParam1, iParam2); }

// Position - 0x9E12
bool func_183(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		switch (entity::get_entity_type(iParam0)) {
		case 1:
			if (!ped::is_ped_injured(entity::get_ped_index_from_entity_index(iParam0))) {
				return true;
			}
			break;

		case 2:
			if (vehicle::is_vehicle_driveable(entity::get_vehicle_index_from_entity_index(iParam0), 0)) {
				return true;
			}
			break;

		default:
			if (!entity::is_entity_dead(iParam0, 0)) {
				return true;
			}
			break;
		}
	}
	return false;
}

// Position - 0x9E77
void func_184(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		switch ((*uParam0)[iVar0 /*8*/]) {
		case 1:
			Stack.Push(&(*uParam0)[iVar0 /*8*/]);
			Call_Loc((*uParam0)[iVar0 /*8*/].f_7);
			break;

		case 2:
			if (gameplay::get_game_timer() - (*uParam0)[iVar0 /*8*/].f_5 > (*uParam0)[iVar0 /*8*/].f_6) {
				(*uParam0)[iVar0 /*8*/] = 1;
				(*uParam0)[iVar0 /*8*/].f_6 = 0;
			}
			break;
		}
		iVar0++;
	}
}

// Position - 0x9EE7
void func_185() {
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!iLocal_1351) {
			func_188(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), -1);
			func_187(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), -1);
			iLocal_1351 = 1;
		}
	}
	else if (iLocal_1351) {
		func_187(0, -1);
		func_188(0, -1);
		iLocal_1351 = 0;
	}
	if (!iLocal_1349) {
		if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
			if (ped::is_ped_in_vehicle(player::player_ped_id(), Local_1318, 1)) {
				audio::play_police_report("SCRIPTED_SCANNER_REPORT_JSH_PREP_2A_01", 0f);
				iLocal_1349 = 1;
			}
			else if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
				audio::play_police_report("SCRIPTED_SCANNER_REPORT_JSH_PREP_2A_02", 0f);
				iLocal_1349 = 1;
			}
		}
	}
	if (iLocal_93 == 0) {
		switch (iLocal_1303) {
		case 0:
			if (entity::does_entity_exist(vLocal_1306.x) && !ped::is_ped_injured(vLocal_1306.x) &&
				func_120(&Local_1084[0 /*8*/])) {
				if (Local_1084[0 /*8*/].f_1 == 1) {
					if (func_186(player::player_ped_id(), Local_1318, 1) > 500f) {
						func_260(1);
					}
				}
				else if (Local_1084[0 /*8*/].f_1 == 4) {
					if (func_186(player::player_ped_id(), Local_1318, 1) > 250f) {
						func_260(1);
					}
				}
				else if (func_186(player::player_ped_id(), Local_1318, 1) > 250f) {
					func_260(2);
				}
			}
			else if (func_186(player::player_ped_id(), Local_1318, 1) > 250f) {
				func_260(2);
			}
			break;

		case 1:
			if (func_186(player::player_ped_id(), Local_1318, 1) > 250f) {
				func_260(2);
			}
			break;

		case 3:
		case 2:
			if (!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
				if (entity::does_entity_exist(Local_1322[0 /*2*/]) &&
					func_186(player::player_ped_id(), Local_1322[0 /*2*/], 1) > 250f &&
					entity::does_entity_exist(Local_1322[1 /*2*/]) &&
					func_186(player::player_ped_id(), Local_1322[1 /*2*/], 1) > 250f &&
					entity::does_entity_exist(Local_1322[2 /*2*/]) &&
					func_186(player::player_ped_id(), Local_1322[2 /*2*/], 1) > 250f) {
					func_260(3);
				}
			}
			break;
		}
	}
	if (entity::does_entity_exist(Local_1318)) {
		if (entity::is_entity_in_water(Local_1318) && !vehicle::is_vehicle_driveable(Local_1318, 0) &&
			!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
			func_260(4);
		}
	}
}

// Position - 0xA150
float func_186(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0xA1AE
void func_187(int iParam0, int iParam1) {
	Global_55833 = iParam0;
	Global_55834 = iParam1;
}

// Position - 0xA1C0
void func_188(int iParam0, int iParam1) {
	int iVar0;

	Global_55835 = iParam0;
	iVar0 = 0;
	while (iVar0 < Global_67917) {
		if (iParam1 == -1 || Global_67918[iVar0 /*9*/] == iParam1) {
			if (Global_67918[iVar0 /*9*/].f_6 != iParam0) {
				Global_67918[iVar0 /*9*/].f_6 = iParam0;
				Global_67918[iVar0 /*9*/].f_7 = 1;
				Global_67918[iVar0 /*9*/].f_8 = 0;
			}
		}
		iVar0++;
	}
}

// Position - 0xA22B
void func_189() {
	if (entity::does_entity_exist(vLocal_1306.x)) {
		if (!ped::is_ped_in_any_vehicle(vLocal_1306.x, 0)) {
			func_190(vLocal_1306.x, &vLocal_1306.f_2, -1, 0, 0, 0, -1082130432, 0, -1, -1, 1);
		}
	}
	if (entity::does_entity_exist(Local_1318)) {
		if (!func_183(Local_1318) && entity::is_entity_dead(Local_1318, 0) && iLocal_1346 &&
			func_186(Local_1318, player::player_ped_id(), 1) > 200f) {
			entity::set_vehicle_as_no_longer_needed(&Local_1318);
		}
	}
}

// Position - 0xA2AB
int func_190(int iParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5, float fParam6,
			 char *sParam7, int iParam8, int iParam9, int iParam10) {
	if (iParam3 == 0) {
		iParam3 = player::get_player_index();
	}
	if (fParam6 < 0f) {
		fParam6 = 100f;
	}
	if (!ped::is_ped_injured(iParam0)) {
		if (!ui::does_ped_have_ai_blip(iParam0)) {
			if (iParam8 == -1) {
				ui::_set_ped_enemy_ai_blip(iParam0, 1);
			}
			else {
				unk_0xB13DCB4C6FAAD238(iParam0, 1, iParam8);
			}
			uParam1->f_7 = iParam0;
			ui::_0xE52B8E7F85D39A08(iParam0, iParam2);
			ui::_set_ai_blip_max_distance(iParam0, fParam6);
			if (ui::does_blip_exist(*uParam1)) {
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (iParam9 != -1) {
			unk_0xFCFACD0DB9D7A57D(iParam0, iParam9);
		}
		ui::_0x0C4BBF625CA98C4E(iParam0, iParam4);
		ui::hide_special_ability_lockon_operation(iParam0, iParam5);
		*uParam1 = ui::_0x7CD934010E115C2C(iParam0);
		if (iParam9 != -1) {
			if (ui::does_blip_exist(*uParam1)) {
				if (iParam8 != -1) {
					ui::set_blip_colour(*uParam1, iParam8);
				}
				ui::begin_text_command_set_blip_name("STRING");
				if (iParam10) {
					ui::add_text_component_substring_player_name(sParam7);
				}
				else {
					ui::add_text_component_substring_text_label(sParam7);
				}
				ui::end_text_command_set_blip_name(*uParam1);
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (!gameplay::is_bit_set(uParam1->f_6, 2)) {
			if (ui::does_blip_exist(*uParam1)) {
				if (!gameplay::is_string_null_or_empty(sParam7)) {
					ui::begin_text_command_set_blip_name("STRING");
					if (iParam10) {
						ui::add_text_component_substring_player_name(sParam7);
					}
					else {
						ui::add_text_component_substring_text_label(sParam7);
					}
					ui::end_text_command_set_blip_name(*uParam1);
				}
				gameplay::set_bit(&uParam1->f_6, 2);
			}
		}
		if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			uParam1->f_1 = ui::_0x56176892826A4FE8(iParam0);
			if (!gameplay::is_bit_set(uParam1->f_6, 3)) {
				if (ui::does_blip_exist(uParam1->f_1)) {
					ui::set_blip_priority(uParam1->f_1, 7);
					gameplay::set_bit(&uParam1->f_6, 3);
				}
			}
		}
		else if (ui::does_blip_exist(uParam1->f_1)) {
			uParam1->f_1 = 0;
			gameplay::clear_bit(&uParam1->f_6, 3);
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0xA448
void func_191() {
	vector3 vVar0;
	float *fVar3;

	if (iLocal_96 == 1) {
		if (!cam::is_screen_faded_out()) {
			if (!cam::is_screen_fading_out()) {
				cam::do_screen_fade_out(1000);
			}
		}
		else {
			if (cutscene::is_cutscene_active()) {
				cutscene::stop_cutscene(0);
				cutscene::remove_cutscene();
			}
			iLocal_93 = iLocal_97;
			cam::render_script_cams(0, 0, 3000, 1, 0, 0);
			ui::clear_prints();
			ui::clear_help(1);
			func_8(1);
			if (cutscene::is_cutscene_active()) {
				cutscene::remove_cutscene();
			}
			if (!func_234()) {
				func_233(iLocal_93, &vVar0, &fVar3);
				entity::set_entity_coords(player::player_ped_id(), vVar0, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), fVar3);
				entity::freeze_entity_position(player::player_ped_id(), 1);
				func_231(&uLocal_99, vVar0, 50f, 0);
			}
			func_230(&uLocal_99);
			switch (iLocal_93) {
			case 0:
				func_229(&uLocal_99, iLocal_83);
				func_229(&uLocal_99, iLocal_84);
				func_229(&uLocal_99, iLocal_85);
				func_228(&uLocal_99, &Global_88686);
				break;

			case 1: func_229(&uLocal_99, joaat("burrito2")); break;
			}
			while (!func_227(&uLocal_99)) {
				system::wait(0);
				func_189();
			}
			switch (iLocal_93) {
			case 0:
				while (!func_220(0)) {
					system::wait(0);
				}
				if (gameplay::are_strings_equal(&Global_88686, "jhp2a_main")) {
					while (!func_195(&iLocal_1316, 1395.851f, -1069.306f, 52.4779f, 118.1591f, 1)) {
						system::wait(0);
						gameplay::clear_area_of_vehicles(1395.851f, -1069.306f, 52.4779f, 20f, 0, 0, 0, 0, 0);
					}
				}
				else {
					while (!func_195(&iLocal_1316, 1256.913f, 556.8416f, 79.7013f, 134.0793f, 1)) {
						system::wait(0);
						gameplay::clear_area_of_vehicles(1256.913f, 556.8416f, 79.7013f, 20f, 0, 0, 0, 0, 0);
					}
				}
				vehicle::set_vehicle_colour_combination(iLocal_1316, 0);
				vehicle::set_vehicle_extra(iLocal_1316, 1, 0);
				vehicle::set_vehicle_extra(iLocal_1316, 2, 1);
				vehicle::set_vehicle_on_ground_properly(iLocal_1316, 1084227584);
				vehicle::set_vehicle_engine_on(iLocal_1316, 1, 1, 0);
				if (func_234()) {
					func_192(iLocal_1316, -1, 1);
				}
				else {
					entity::freeze_entity_position(player::player_ped_id(), 0);
					ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_1316, -1);
				}
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				break;

			case 1:
				if (!func_7(87)) {
					Local_1318 =
						vehicle::create_vehicle(joaat("boxville3"), 693.725f, -1006.302f, 21.8355f, 359.884f, 1, 1);
					vehicle::set_vehicle_is_considered_by_player(Local_1318, 0);
					vehicle::set_vehicle_on_ground_properly(Local_1318, 1084227584);
				}
				if (func_234()) {
					func_192(0, -1, 1);
				}
				else {
					entity::freeze_entity_position(player::player_ped_id(), 0);
				}
				entity::set_entity_coords(player::player_ped_id(), 692.067f, -1004.812f, 21.9059f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 359.5735f);
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				break;
			}
			if (cam::is_screen_faded_out() || !cam::is_screen_fading_in()) {
				cam::do_screen_fade_in(1000);
			}
			iLocal_96 = 0;
		}
	}
}

// Position - 0xA732
void func_192(int iParam0, int iParam1, int iParam2) {
	if (func_194() && func_234()) {
		while (Global_91486 != 6) {
			system::wait(0);
		}
		gameplay::set_game_paused(0);
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::clear_ped_wetness(player::player_ped_id());
			}
		}
		if (iParam0 != 0) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (entity::does_entity_exist(iParam0)) {
					if (vehicle::is_vehicle_driveable(iParam0, 0)) {
						if (!ped::is_ped_in_vehicle(player::player_ped_id(), iParam0, 0)) {
							ped::set_ped_into_vehicle(player::player_ped_id(), iParam0, iParam1);
							cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
							cam::set_gameplay_cam_relative_heading(0f);
							system::wait(0);
						}
					}
				}
			}
		}
		if (iParam2 == 1) {
			if (player::is_player_playing(player::player_id())) {
				player::set_player_control(player::player_id(), 1, 0);
			}
		}
		graphics::_stop_all_screen_effects();
		func_193(0);
	}
}

// Position - 0xA7F6
void func_193(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&Global_91491.f_20, 13);
	}
	else {
		gameplay::clear_bit(&Global_91491.f_20, 13);
	}
}

// Position - 0xA81F
bool func_194() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return true;
	}
	return false;
}

// Position - 0xA843
int func_195(int iParam0, vector3 vParam1, float fParam4, int iParam5) {
	struct<67> Var0;

	Var0.f_9 = 49;
	Var0.f_59 = 2;
	if (func_194()) {
		if (func_219()) {
			func_164(&Global_96040.f_2311.f_12, &Var0);
		}
	}
	else if (func_217()) {
		func_164(&Global_93635.f_2311.f_12, &Var0);
	}
	if (Var0.f_66 != 0) {
		if (!func_216(0, &Var0)) {
			if (vehicle::is_this_model_a_car(Var0.f_66) || vehicle::is_this_model_a_bike(Var0.f_66)) {
				streaming::request_model(Var0.f_66);
				if (streaming::has_model_loaded(Var0.f_66)) {
					*iParam0 = vehicle::create_vehicle(Var0.f_66, vParam1, fParam4, 1, 1);
					func_212(*iParam0, &Var0, 0, 1);
					streaming::set_model_as_no_longer_needed(Var0.f_66);
					vehicle::set_vehicle_on_ground_properly(*iParam0, 1084227584);
					return 1;
				}
				else {
					return 0;
				}
			}
		}
		else {
			iParam5 = 1;
		}
	}
	if (iParam5) {
		if (!entity::does_entity_exist(*iParam0)) {
			if (func_196(iParam0, 0, vParam1, fParam4, 1, 0)) {
				vehicle::set_vehicle_model_is_suppressed(func_157(0, 0), 1);
				return 1;
			}
		}
		return 0;
	}
	return 1;
}

// Position - 0xA94D
bool func_196(var *uParam0, int iParam1, vector3 vParam2, float fParam5, int iParam6, int iParam7) {
	int iVar0;
	var *uVar1;
	struct<97> Var5;
	int iVar103;
	int iVar104;
	bool bVar105;
	char cVar106[16];
	int iVar110;

	if (func_159(iParam1)) {
		Var5.f_11 = 12;
		Var5.f_31 = 49;
		Var5.f_81 = 2;
		func_158(iParam1, &Var5, iParam7);
		if (Var5 == 0) {
			return true;
		}
		if (entity::does_entity_exist(*uParam0)) {
			if (entity::get_entity_model(*uParam0) != Var5) {
			}
			return true;
		}
		if (iParam1 == 0 && !Global_101700.f_2095.f_539.f_3544 && Global_101700.f_8044.f_99.f_58[131]) {
			Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/] = 0;
		}
		if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/] == Var5) {
			streaming::request_model(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/]);
			if (streaming::has_model_loaded(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/])) {
				*uParam0 = vehicle::create_vehicle(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/],
												   vParam2, fParam5, 0, 0);
				vehicle::set_vehicle_on_ground_properly(*uParam0, 1084227584);
				vehicle::_0xAB04325045427AAE(*uParam0, 0);
				vehicle::_0x428BACCDF5E26EAD(*uParam0, 0);
				vehicle::set_vehicle_has_strong_axles(*uParam0, 1);
				entity::set_entity_health(*uParam0, 1250);
				vehicle::set_vehicle_engine_health(*uParam0, 1250f);
				vehicle::set_vehicle_petrol_tank_health(*uParam0, 1250f);
				Var5.f_3 = 1250;
				vehicle::set_vehicle_colours(*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_5,
											 Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_6);
				vehicle::set_vehicle_extra_colours(*uParam0,
												   Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_7,
												   Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_8);
				vehicle::set_vehicle_dirt_level(*uParam0, Var5.f_2);
				iVar103 = 0;
				while (iVar103 < 12) {
					vehicle::set_vehicle_extra(
						*uParam0, iVar103 + 1,
						!Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_11[iVar103]);
					iVar103++;
				}
				if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_24) {
					vehicle::set_convertible_roof(*uParam0,
												  Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_24);
				}
				if (func_211(&uVar1, &iVar0)) {
					vehicle::set_vehicle_number_plate_text(*uParam0, &uVar1);
					vehicle::set_vehicle_number_plate_text_index(*uParam0, iVar0);
				}
				else {
					vehicle::set_vehicle_number_plate_text(
						*uParam0, &Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_27);
					if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_26 >= 0 &&
						Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_26 <
							vehicle::get_number_of_vehicle_number_plates()) {
						vehicle::set_vehicle_number_plate_text_index(
							*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_26);
					}
				}
				vehicle::set_vehicle_tyre_smoke_color(
					*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_84,
					Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_85,
					Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_86);
				vehicle::set_vehicle_tyres_can_burst(*uParam0,
													 Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_88);
				vehicle::set_vehicle_window_tint(*uParam0,
												 Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_87);
				vehicle::_set_vehicle_neon_lights_colour(
					*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_93,
					Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_94,
					Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_95);
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 2,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_92, 28));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 3,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_92, 29));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 0,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_92, 30));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 1,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_92, 31));
				if (vehicle::get_vehicle_livery_count(*uParam0) > 1 &&
					Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_89 >= 0) {
					vehicle::set_vehicle_livery(*uParam0,
												Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_89);
				}
				if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_90 > -1) {
					if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(*uParam0))) {
						if (vehicle::is_this_model_a_bike(entity::get_entity_model(*uParam0))) {
							if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_90 == 6) {
								vehicle::set_vehicle_wheel_type(
									*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_90);
							}
						}
						else {
							vehicle::set_vehicle_wheel_type(
								*uParam0, Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_90);
						}
					}
				}
				func_207(uParam0, &Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_31,
						 &Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/].f_81);
				vehicle::set_vehicle_enveff_scale(*uParam0, Var5.f_96);
				if (iParam1 == 2) {
					if (entity::get_entity_model(*uParam0) == joaat("bodhi2")) {
						func_205(uParam0);
					}
				}
				if (iParam6) {
					streaming::set_model_as_no_longer_needed(
						Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam1 /*98*/]);
				}
				func_204(*uParam0, iParam1);
				return true;
			}
		}
		else if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/] == Var5) {
			streaming::request_model(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/]);
			if (streaming::has_model_loaded(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/])) {
				*uParam0 = vehicle::create_vehicle(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/],
												   vParam2, fParam5, 0, 0);
				vehicle::set_vehicle_on_ground_properly(*uParam0, 1084227584);
				vehicle::_0xAB04325045427AAE(*uParam0, 0);
				vehicle::_0x428BACCDF5E26EAD(*uParam0, 0);
				vehicle::set_vehicle_has_strong_axles(*uParam0, 1);
				entity::set_entity_health(*uParam0, 1250);
				vehicle::set_vehicle_engine_health(*uParam0, 1250f);
				vehicle::set_vehicle_petrol_tank_health(*uParam0, 1250f);
				Var5.f_3 = 1250;
				vehicle::set_vehicle_colours(*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_5,
											 Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_6);
				vehicle::set_vehicle_extra_colours(*uParam0,
												   Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_7,
												   Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_8);
				vehicle::set_vehicle_dirt_level(*uParam0, Var5.f_2);
				iVar104 = 0;
				while (iVar104 < 12) {
					vehicle::set_vehicle_extra(
						*uParam0, iVar104 + 1,
						!Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_11[iVar104]);
					iVar104++;
				}
				if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_24) {
					vehicle::set_convertible_roof(*uParam0,
												  Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_24);
				}
				if (func_211(&uVar1, &iVar0)) {
					vehicle::set_vehicle_number_plate_text(*uParam0, &uVar1);
					vehicle::set_vehicle_number_plate_text_index(*uParam0, iVar0);
				}
				else {
					vehicle::set_vehicle_number_plate_text(
						*uParam0, &Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_27);
					if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_26 >= 0 &&
						Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_26 <
							vehicle::get_number_of_vehicle_number_plates()) {
						vehicle::set_vehicle_number_plate_text_index(
							*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_26);
					}
				}
				vehicle::set_vehicle_tyre_smoke_color(
					*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_84,
					Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_85,
					Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_86);
				vehicle::set_vehicle_tyres_can_burst(*uParam0,
													 Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_88);
				vehicle::set_vehicle_window_tint(*uParam0,
												 Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_87);
				vehicle::_set_vehicle_neon_lights_colour(
					*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_93,
					Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_94,
					Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_95);
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 2,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_92, 28));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 3,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_92, 29));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 0,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_92, 30));
				vehicle::_set_vehicle_neon_light_enabled(
					*uParam0, 1,
					gameplay::is_bit_set(Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_92, 31));
				if (vehicle::get_vehicle_livery_count(*uParam0) > 1 &&
					Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_89 >= 0) {
					vehicle::set_vehicle_livery(*uParam0,
												Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_89);
				}
				if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_90 > -1) {
					if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(*uParam0))) {
						if (vehicle::is_this_model_a_bike(entity::get_entity_model(*uParam0))) {
							if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_90 == 6) {
								vehicle::set_vehicle_wheel_type(
									*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_90);
							}
						}
						else {
							vehicle::set_vehicle_wheel_type(
								*uParam0, Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_90);
						}
					}
				}
				func_207(uParam0, &Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_31,
						 &Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/].f_81);
				vehicle::set_vehicle_enveff_scale(*uParam0, Var5.f_96);
				if (iParam1 == 2) {
					if (entity::get_entity_model(*uParam0) == joaat("bodhi2")) {
						func_205(uParam0);
					}
				}
				if (iParam6) {
					streaming::set_model_as_no_longer_needed(
						Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam1 /*98*/]);
				}
				func_204(*uParam0, iParam1);
				return true;
			}
		}
		else {
			streaming::request_model(Var5);
			if (streaming::has_model_loaded(Var5)) {
				bVar105 = true;
				*uParam0 = vehicle::create_vehicle(Var5, vParam2, fParam5, 1, 1);
				vehicle::set_vehicle_on_ground_properly(*uParam0, 1084227584);
				vehicle::_0xAB04325045427AAE(*uParam0, 0);
				vehicle::_0x428BACCDF5E26EAD(*uParam0, 0);
				vehicle::set_vehicle_has_strong_axles(*uParam0, 1);
				StringCopy(&cVar106, vehicle::get_vehicle_number_plate_text(*uParam0), 16);
				entity::set_entity_health(*uParam0, 1250);
				vehicle::set_vehicle_engine_health(*uParam0, 1250f);
				vehicle::set_vehicle_petrol_tank_health(*uParam0, 1250f);
				Var5.f_3 = 1250;
				vehicle::set_vehicle_colours(*uParam0, Var5.f_5, Var5.f_6);
				vehicle::set_vehicle_extra_colours(*uParam0, Var5.f_7, Var5.f_8);
				vehicle::set_vehicle_dirt_level(*uParam0, Var5.f_2);
				iVar110 = 0;
				while (iVar110 < 12) {
					vehicle::set_vehicle_extra(*uParam0, iVar110 + 1, !Var5.f_11[iVar110]);
					iVar110++;
				}
				if (Var5.f_24) {
					vehicle::set_convertible_roof(*uParam0, Var5.f_24);
				}
				if (func_211(&uVar1, &iVar0)) {
					vehicle::set_vehicle_number_plate_text(*uParam0, &uVar1);
					vehicle::set_vehicle_number_plate_text_index(*uParam0, iVar0);
				}
				else {
					vehicle::set_vehicle_number_plate_text(*uParam0, &Var5.f_27);
					if (Var5.f_26 >= 0 && Var5.f_26 < vehicle::get_number_of_vehicle_number_plates()) {
						vehicle::set_vehicle_number_plate_text_index(*uParam0, Var5.f_26);
					}
				}
				vehicle::set_vehicle_tyre_smoke_color(*uParam0, Var5.f_84, Var5.f_85, Var5.f_86);
				vehicle::set_vehicle_tyres_can_burst(*uParam0, Var5.f_88);
				vehicle::set_vehicle_window_tint(*uParam0, Var5.f_87);
				vehicle::_set_vehicle_neon_lights_colour(*uParam0, Var5.f_93, Var5.f_94, Var5.f_95);
				vehicle::_set_vehicle_neon_light_enabled(*uParam0, 2, gameplay::is_bit_set(Var5.f_92, 28));
				vehicle::_set_vehicle_neon_light_enabled(*uParam0, 3, gameplay::is_bit_set(Var5.f_92, 29));
				vehicle::_set_vehicle_neon_light_enabled(*uParam0, 0, gameplay::is_bit_set(Var5.f_92, 30));
				vehicle::_set_vehicle_neon_light_enabled(*uParam0, 1, gameplay::is_bit_set(Var5.f_92, 31));
				if (vehicle::get_vehicle_livery_count(*uParam0) > 1 && Var5.f_89 >= 0) {
					vehicle::set_vehicle_livery(*uParam0, Var5.f_89);
				}
				if (Var5.f_90 > -1) {
					if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(*uParam0))) {
						if (vehicle::is_this_model_a_bike(entity::get_entity_model(*uParam0))) {
							if (Var5.f_90 == 6) {
								vehicle::set_vehicle_wheel_type(*uParam0, Var5.f_90);
							}
						}
						else {
							vehicle::set_vehicle_wheel_type(*uParam0, Var5.f_90);
						}
					}
				}
				func_207(uParam0, &Var5.f_31, &Var5.f_81);
				vehicle::set_vehicle_enveff_scale(*uParam0, Var5.f_96);
				if (iParam1 == 1) {
					if (entity::get_entity_model(*uParam0) == joaat("bagger") && !Global_101700.f_8044.f_99.f_58[118]) {
						vehicle::set_vehicle_number_plate_text(*uParam0, &cVar106);
						bVar105 = false;
					}
				}
				else if (iParam1 == 2) {
					if (entity::get_entity_model(*uParam0) == joaat("bodhi2")) {
						func_205(uParam0);
					}
				}
				else if (iParam1 == 0 && !Global_101700.f_2095.f_539.f_3544 && Global_101700.f_8044.f_99.f_58[131] &&
						 entity::get_entity_model(*uParam0) == joaat("tailgater")) {
					vehicle::set_vehicle_mod(*uParam0, 6, 1, 0);
					vehicle::set_vehicle_mod(*uParam0, 14, 7, 0);
					vehicle::set_vehicle_mod(*uParam0, 11, 2, 0);
					vehicle::set_vehicle_mod(*uParam0, 2, 3, 0);
					vehicle::set_vehicle_mod(*uParam0, 7, 5, 0);
					vehicle::set_vehicle_mod(*uParam0, 0, 0, 0);
					vehicle::set_vehicle_mod(*uParam0, 3, 3, 0);
					vehicle::set_vehicle_mod(*uParam0, 13, 1, 0);
					vehicle::set_vehicle_mod(*uParam0, 4, 3, 0);
					vehicle::set_vehicle_mod(*uParam0, 12, 2, 0);
					vehicle::toggle_vehicle_mod(*uParam0, 22, 1);
					vehicle::set_vehicle_wheel_type(*uParam0, 2);
					vehicle::set_vehicle_mod(*uParam0, 23, 11, 0);
					vehicle::set_vehicle_window_tint(*uParam0, 2);
					Global_101700.f_2095.f_539.f_3544 = 1;
					func_197(iParam1, uParam0, 0, 1);
				}
				if (iParam6) {
					streaming::set_model_as_no_longer_needed(Var5);
				}
				if (bVar105) {
					func_204(*uParam0, iParam1);
				}
				return true;
			}
		}
	}
	return false;
}

// Position - 0xB78B
void func_197(int iParam0, var *uParam1, int iParam2, int iParam3) {
	int *iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	var uVar5;
	var uVar6;

	if (func_159(iParam0) && entity::does_entity_exist(*uParam1) && vehicle::is_vehicle_driveable(*uParam1, 0)) {
		if (iParam2 > Global_101700.f_2095.f_539.f_1635) {
			return;
		}
		if (iParam2 == 0) {
		}
		else if (iParam2 == 1) {
		}
		else if (iParam2 == 2) {
		}
		else if (iParam2 == 3) {
			func_127(*uParam1, iParam0);
		}
		if (vehicle::get_num_mod_kits(*uParam1) != 0) {
			vehicle::set_vehicle_mod_kit(*uParam1, 0);
		}
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/] = entity::get_entity_model(*uParam1);
		if (vehicle::get_vehicle_trailer_vehicle(*uParam1, &iVar1)) {
			Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_1 = entity::get_entity_model(iVar1);
		}
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_2 =
			vehicle::get_vehicle_dirt_level(*uParam1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_3 = entity::get_entity_health(*uParam1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[0] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[1] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 2);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[2] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 3);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[3] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 4);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[4] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 5);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[5] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 6);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[6] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 7);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[7] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 8);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[8] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 9);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[9] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 10);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[10] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 11);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_11[11] =
			vehicle::is_vehicle_extra_turned_on(*uParam1, 12);
		if (vehicle::is_vehicle_a_convertible(*uParam1, 0)) {
			iVar2 = vehicle::get_convertible_roof_state(*uParam1);
			if (iVar2 == 0 || iVar2 == 5) {
				Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_24 = 1;
			}
			else {
				Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_24 = 0;
			}
		}
		else {
			Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_24 = 0;
		}
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_25 =
			audio::get_player_radio_station_index();
		StringCopy(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_27,
				   vehicle::get_vehicle_number_plate_text(*uParam1), 16);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_26 =
			vehicle::get_vehicle_number_plate_text_index(*uParam1);
		vehicle::get_vehicle_colours(*uParam1, &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_5,
									 &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_6);
		vehicle::get_vehicle_extra_colours(*uParam1,
										   &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_7,
										   &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_8);
		vehicle::get_vehicle_tyre_smoke_color(*uParam1,
											  &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_84,
											  &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_85,
											  &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_86);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_88 =
			vehicle::get_vehicle_tyres_can_burst(*uParam1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_87 =
			vehicle::get_vehicle_window_tint(*uParam1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_89 = vehicle::get_vehicle_livery(*uParam1);
		Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_90 =
			vehicle::get_vehicle_wheel_type(*uParam1);
		vehicle::_get_vehicle_neon_lights_colour(
			*uParam1, &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_93,
			&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_94,
			&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_95);
		if (vehicle::_is_vehicle_neon_light_enabled(*uParam1, 2)) {
			gameplay::set_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 28);
		}
		else {
			gameplay::clear_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(*uParam1, 3)) {
			gameplay::set_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 29);
		}
		else {
			gameplay::clear_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(*uParam1, 0)) {
			gameplay::set_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 30);
		}
		else {
			gameplay::clear_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(*uParam1, 1)) {
			gameplay::set_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 31);
		}
		else {
			gameplay::clear_bit(&Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_92, 31);
		}
		Global_101700.f_2095.f_539.f_3545[iParam0] = 10;
		if (vehicle::get_vehicle_mod_kit(*uParam1) >= 0 && vehicle::get_vehicle_mod_kit(*uParam1) < 255 &&
			func_201(*uParam1, 0, &iVar0)) {
			func_169(uParam1, &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31,
					 &Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_81);
			if (iParam3) {
				Global_101700.f_19077[iParam0 /*43*/].f_40 = 1;
				Global_101700.f_19077[iParam0 /*43*/] =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/];
				Global_101700.f_19077[iParam0 /*43*/].f_3 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_87;
				Global_101700.f_19077[iParam0 /*43*/].f_4 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_84;
				Global_101700.f_19077[iParam0 /*43*/].f_5 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_85;
				Global_101700.f_19077[iParam0 /*43*/].f_6 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_86;
				Global_101700.f_19077[iParam0 /*43*/].f_10 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_90;
				Global_101700.f_19077[iParam0 /*43*/].f_16 =
					!Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_88;
				Global_101700.f_19077[iParam0 /*43*/].f_19 = {
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_27};
				Global_101700.f_19077[iParam0 /*43*/].f_23 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_26;
				Global_101700.f_19077[iParam0 /*43*/].f_7 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[11];
				Global_101700.f_19077[iParam0 /*43*/].f_8 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[12];
				Global_101700.f_19077[iParam0 /*43*/].f_9 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[23];
				Global_101700.f_19077[iParam0 /*43*/].f_11 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[4];
				Global_101700.f_19077[iParam0 /*43*/].f_12 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[15];
				Global_101700.f_19077[iParam0 /*43*/].f_13 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[16];
				Global_101700.f_19077[iParam0 /*43*/].f_14 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[14];
				Global_101700.f_19077[iParam0 /*43*/].f_15 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[22];
				Global_101700.f_19077[iParam0 /*43*/].f_18 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[20];
				Global_101700.f_19077[iParam0 /*43*/].f_17 =
					Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_31[18];
				Global_101700.f_19077[iParam0 /*43*/].f_24 = vehicle::get_num_vehicle_mods(*uParam1, 11) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_25 = vehicle::get_num_vehicle_mods(*uParam1, 12) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_26 = vehicle::get_num_vehicle_mods(*uParam1, 4) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_27 = vehicle::get_num_vehicle_mods(*uParam1, 23) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_28 = vehicle::get_num_vehicle_mods(*uParam1, 14) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_29 = vehicle::get_num_vehicle_mods(*uParam1, 16) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_30 = vehicle::get_num_vehicle_mods(*uParam1, 15) + 1;
				Global_101700.f_19077[iParam0 /*43*/].f_32 = vehicle::_0xEEBFC7A7EFDC35B4(*uParam1);
				Global_101700.f_19077[iParam0 /*43*/].f_33[0] = audio::get_vehicle_default_horn(*uParam1);
				Global_101700.f_19077[iParam0 /*43*/].f_33[1] =
					vehicle::get_vehicle_mod_modifier_value(*uParam1, 14, 0);
				Global_101700.f_19077[iParam0 /*43*/].f_33[2] =
					vehicle::get_vehicle_mod_modifier_value(*uParam1, 14, 1);
				Global_101700.f_19077[iParam0 /*43*/].f_33[3] =
					vehicle::get_vehicle_mod_modifier_value(*uParam1, 14, 2);
				Global_101700.f_19077[iParam0 /*43*/].f_33[4] =
					vehicle::get_vehicle_mod_modifier_value(*uParam1, 14, 3);
				Global_101700.f_19077[iParam0 /*43*/].f_39 = vehicle::get_vehicle_mod_kit_type(*uParam1);
				Global_101700.f_19077[iParam0 /*43*/].f_31 = func_200(*uParam1);
				Global_101700.f_19077[iParam0 /*43*/].f_33[0] = audio::_0xACB5DCCA1EC76840(*uParam1);
				vehicle::get_vehicle_mod_color_1(*uParam1, &iVar4, &uVar5, &uVar6);
				if (iVar4 == 0) {
					iVar3 = 0;
				}
				else if (iVar4 == 1) {
					iVar3 = 1;
				}
				else if (iVar4 == 3) {
					iVar3 = 2;
				}
				else if (iVar4 == 4) {
					iVar3 = 3;
				}
				else if (iVar4 == 5) {
					iVar3 = 4;
				}
				else {
					iVar3 = -1;
				}
				func_198(Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_5,
						 Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_7, iVar3, 1,
						 &Global_101700.f_19077[iParam0 /*43*/].f_1);
				vehicle::get_vehicle_mod_color_2(*uParam1, &iVar4, &uVar5);
				if (iVar4 == 0) {
					iVar3 = 0;
				}
				else if (iVar4 == 1) {
					iVar3 = 1;
				}
				else if (iVar4 == 3) {
					iVar3 = 2;
				}
				else if (iVar4 == 4) {
					iVar3 = 3;
				}
				else if (iVar4 == 5) {
					iVar3 = 4;
				}
				else {
					iVar3 = -1;
				}
				func_198(Global_101700.f_2095.f_539.f_1635[iParam2 /*295*/][iParam0 /*98*/].f_6, -1, iVar3, 0,
						 &Global_101700.f_19077[iParam0 /*43*/].f_2);
			}
		}
	}
}

// Position - 0xC3B0
int func_198(int iParam0, int iParam1, int iParam2, int iParam3, int *iParam4) {
	int iVar0;
	int iVar1;
	char *sVar2;
	int iVar6;
	int iVar7;

	iVar0 = 0;
	while (func_199(iVar0, &sVar2, &iVar1, &iVar6, &iVar7)) {
		if (iParam0 == iVar6 && (!iParam3 || iParam1 == iVar7) &&
			(iParam2 == iVar1 || iParam2 == -1 || iParam2 == 255)) {
			*iParam4 = iVar0;
			return 1;
		}
		iVar0++;
	}
	iParam0 = -1;
	iParam1 = -1;
	*iParam4 = -1;
	return 0;
}

// Position - 0xC423
bool func_199(int iParam0, char *sParam1, int *iParam2, int *iParam3, int *iParam4) {
	*iParam2 = -1;
	*iParam3 = -1;
	*iParam4 = -1;
	switch (iParam0) {
	case 0:
		StringCopy(sParam1, "BR BLACK_STEEL", 16);
		*iParam2 = 3;
		*iParam3 = 118;
		*iParam4 = 3;
		break;

	case 1:
		StringCopy(sParam1, "BLACK_GRAPHITE", 16);
		*iParam2 = 0;
		*iParam3 = 147;
		*iParam4 = 4;
		break;

	case 2:
		StringCopy(sParam1, "CHOCOLATE_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 96;
		*iParam4 = 0;
		break;

	case 3:
		StringCopy(sParam1, "PURPLE", 16);
		*iParam2 = 0;
		*iParam3 = 71;
		*iParam4 = 145;
		break;

	case 4:
		StringCopy(sParam1, "HOT PINK", 16);
		*iParam2 = 0;
		*iParam3 = 135;
		*iParam4 = 135;
		break;

	case 5:
		StringCopy(sParam1, "FORMULA_RED", 16);
		*iParam2 = 0;
		*iParam3 = 29;
		*iParam4 = 28;
		break;

	case 6:
		StringCopy(sParam1, "BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 64;
		*iParam4 = 68;
		break;

	case 7:
		StringCopy(sParam1, "ULTRA_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 70;
		*iParam4 = 0;
		break;

	case 8:
		StringCopy(sParam1, "RACING_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 50;
		*iParam4 = 0;
		break;

	case 9:
		StringCopy(sParam1, "LIME_GREEN", 16);
		*iParam2 = 2;
		*iParam3 = 55;
		*iParam4 = 0;
		break;

	case 10:
		StringCopy(sParam1, "RACE_YELLOW", 16);
		*iParam2 = 1;
		*iParam3 = 89;
		*iParam4 = 0;
		break;

	case 11:
		StringCopy(sParam1, "ORANGE", 16);
		*iParam2 = 1;
		*iParam3 = 38;
		*iParam4 = 0;
		break;

	case 12:
		StringCopy(sParam1, "GOLD", 16);
		*iParam2 = 0;
		*iParam3 = 37;
		*iParam4 = 106;
		break;

	case 13:
		StringCopy(sParam1, "SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 4;
		*iParam4 = 111;
		break;

	case 14:
		StringCopy(sParam1, "CHROME", 16);
		*iParam2 = 4;
		*iParam3 = 120;
		*iParam4 = 0;
		break;

	case 15:
		StringCopy(sParam1, "WHITE", 16);
		*iParam2 = 1;
		*iParam3 = 111;
		*iParam4 = 0;
		break;

	case 16:
		StringCopy(sParam1, "BLACK", 16);
		*iParam2 = 0;
		*iParam3 = 0;
		*iParam4 = 10;
		break;

	case 17:
		StringCopy(sParam1, "GRAPHITE", 16);
		*iParam2 = 0;
		*iParam3 = 1;
		*iParam4 = 5;
		break;

	case 18:
		StringCopy(sParam1, "ANTHR_BLACK", 16);
		*iParam2 = 0;
		*iParam3 = 11;
		*iParam4 = 2;
		break;

	case 19:
		StringCopy(sParam1, "BLACK_STEEL", 16);
		*iParam2 = 0;
		*iParam3 = 2;
		*iParam4 = 5;
		break;

	case 20:
		StringCopy(sParam1, "DARK_SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 3;
		*iParam4 = 6;
		break;

	case 21:
		StringCopy(sParam1, "BLUE_SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 5;
		*iParam4 = 111;
		break;

	case 22:
		StringCopy(sParam1, "ROLLED_STEEL", 16);
		*iParam2 = 0;
		*iParam3 = 6;
		*iParam4 = 4;
		break;

	case 23:
		StringCopy(sParam1, "SHADOW_SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 7;
		*iParam4 = 5;
		break;

	case 24:
		StringCopy(sParam1, "STONE_SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 8;
		*iParam4 = 5;
		break;

	case 25:
		StringCopy(sParam1, "MIDNIGHT_SILVER", 16);
		*iParam2 = 0;
		*iParam3 = 9;
		*iParam4 = 7;
		break;

	case 26:
		StringCopy(sParam1, "CAST_IRON_SIL", 16);
		*iParam2 = 0;
		*iParam3 = 10;
		*iParam4 = 7;
		break;

	case 27:
		StringCopy(sParam1, "RED", 16);
		*iParam2 = 0;
		*iParam3 = 27;
		*iParam4 = 36;
		break;

	case 28:
		StringCopy(sParam1, "TORINO_RED", 16);
		*iParam2 = 0;
		*iParam3 = 28;
		*iParam4 = 28;
		break;

	case 29:
		StringCopy(sParam1, "LAVA_RED", 16);
		*iParam2 = 0;
		*iParam3 = 150;
		*iParam4 = 42;
		break;

	case 30:
		StringCopy(sParam1, "BLAZE_RED", 16);
		*iParam2 = 0;
		*iParam3 = 30;
		*iParam4 = 36;
		break;

	case 31:
		StringCopy(sParam1, "GRACE_RED", 16);
		*iParam2 = 0;
		*iParam3 = 31;
		*iParam4 = 27;
		break;

	case 32:
		StringCopy(sParam1, "GARNET_RED", 16);
		*iParam2 = 0;
		*iParam3 = 32;
		*iParam4 = 25;
		break;

	case 33:
		StringCopy(sParam1, "SUNSET_RED", 16);
		*iParam2 = 0;
		*iParam3 = 33;
		*iParam4 = 47;
		break;

	case 34:
		StringCopy(sParam1, "CABERNET_RED", 16);
		*iParam2 = 0;
		*iParam3 = 34;
		*iParam4 = 47;
		break;

	case 35:
		StringCopy(sParam1, "WINE_RED", 16);
		*iParam2 = 0;
		*iParam3 = 143;
		*iParam4 = 31;
		break;

	case 36:
		StringCopy(sParam1, "CANDY_RED", 16);
		*iParam2 = 0;
		*iParam3 = 35;
		*iParam4 = 25;
		break;

	case 37:
		StringCopy(sParam1, "PINK", 16);
		*iParam2 = 0;
		*iParam3 = 137;
		*iParam4 = 3;
		break;

	case 38:
		StringCopy(sParam1, "SALMON_PINK", 16);
		*iParam2 = 0;
		*iParam3 = 136;
		*iParam4 = 5;
		break;

	case 39:
		StringCopy(sParam1, "SUNRISE_ORANGE", 16);
		*iParam2 = 0;
		*iParam3 = 36;
		*iParam4 = 26;
		break;

	case 40:
		StringCopy(sParam1, "ORANGE", 16);
		*iParam2 = 0;
		*iParam3 = 38;
		*iParam4 = 37;
		break;

	case 41:
		StringCopy(sParam1, "BRIGHT_ORANGE", 16);
		*iParam2 = 0;
		*iParam3 = 138;
		*iParam4 = 89;
		break;

	case 42:
		StringCopy(sParam1, "BRONZE", 16);
		*iParam2 = 0;
		*iParam3 = 90;
		*iParam4 = 102;
		break;

	case 43:
		StringCopy(sParam1, "YELLOW", 16);
		*iParam2 = 0;
		*iParam3 = 88;
		*iParam4 = 88;
		break;

	case 44:
		StringCopy(sParam1, "RACE_YELLOW", 16);
		*iParam2 = 0;
		*iParam3 = 89;
		*iParam4 = 88;
		break;

	case 45:
		StringCopy(sParam1, "FLUR_YELLOW", 16);
		*iParam2 = 0;
		*iParam3 = 91;
		*iParam4 = 91;
		break;

	case 46:
		StringCopy(sParam1, "DARK_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 49;
		*iParam4 = 52;
		break;

	case 47:
		StringCopy(sParam1, "RACING_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 50;
		*iParam4 = 53;
		break;

	case 48:
		StringCopy(sParam1, "SEA_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 51;
		*iParam4 = 66;
		break;

	case 49:
		StringCopy(sParam1, "OLIVE_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 52;
		*iParam4 = 59;
		break;

	case 50:
		StringCopy(sParam1, "BRIGHT_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 53;
		*iParam4 = 59;
		break;

	case 51:
		StringCopy(sParam1, "PETROL_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 54;
		*iParam4 = 60;
		break;

	case 52:
		StringCopy(sParam1, "LIME_GREEN", 16);
		*iParam2 = 0;
		*iParam3 = 92;
		*iParam4 = 92;
		break;

	case 53:
		StringCopy(sParam1, "MIDNIGHT_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 141;
		*iParam4 = 73;
		break;

	case 54:
		StringCopy(sParam1, "GALAXY_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 61;
		*iParam4 = 63;
		break;

	case 55:
		StringCopy(sParam1, "DARK_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 62;
		*iParam4 = 68;
		break;

	case 56:
		StringCopy(sParam1, "SAXON_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 63;
		*iParam4 = 87;
		break;

	case 57:
		StringCopy(sParam1, "MARINER_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 65;
		*iParam4 = 87;
		break;

	case 58:
		StringCopy(sParam1, "HARBOR_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 66;
		*iParam4 = 60;
		break;

	case 59:
		StringCopy(sParam1, "DIAMOND_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 67;
		*iParam4 = 67;
		break;

	case 60:
		StringCopy(sParam1, "SURF_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 68;
		*iParam4 = 68;
		break;

	case 61:
		StringCopy(sParam1, "NAUTICAL_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 69;
		*iParam4 = 74;
		break;

	case 62:
		StringCopy(sParam1, "RACING_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 73;
		*iParam4 = 73;
		break;

	case 63:
		StringCopy(sParam1, "ULTRA_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 70;
		*iParam4 = 70;
		break;

	case 64:
		StringCopy(sParam1, "LIGHT_BLUE", 16);
		*iParam2 = 0;
		*iParam3 = 74;
		*iParam4 = 74;
		break;

	case 65:
		StringCopy(sParam1, "CHOCOLATE_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 96;
		*iParam4 = 95;
		break;

	case 66:
		StringCopy(sParam1, "BISON_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 101;
		*iParam4 = 95;
		break;

	case 67:
		StringCopy(sParam1, "CREEK_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 95;
		*iParam4 = 97;
		break;

	case 68:
		StringCopy(sParam1, "UMBER_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 94;
		*iParam4 = 104;
		break;

	case 69:
		StringCopy(sParam1, "MAPLE_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 97;
		*iParam4 = 98;
		break;

	case 70:
		StringCopy(sParam1, "BEECHWOOD_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 103;
		*iParam4 = 104;
		break;

	case 71:
		StringCopy(sParam1, "SIENNA_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 104;
		*iParam4 = 104;
		break;

	case 72:
		StringCopy(sParam1, "SADDLE_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 98;
		*iParam4 = 95;
		break;

	case 73:
		StringCopy(sParam1, "MOSS_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 100;
		*iParam4 = 100;
		break;

	case 74:
		StringCopy(sParam1, "WOODBEECH_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 102;
		*iParam4 = 105;
		break;

	case 75:
		StringCopy(sParam1, "STRAW_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 99;
		*iParam4 = 106;
		break;

	case 76:
		StringCopy(sParam1, "SANDY_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 105;
		*iParam4 = 105;
		break;

	case 77:
		StringCopy(sParam1, "BLEECHED_BROWN", 16);
		*iParam2 = 0;
		*iParam3 = 106;
		*iParam4 = 106;
		break;

	case 78:
		StringCopy(sParam1, "SPIN_PURPLE", 16);
		*iParam2 = 0;
		*iParam3 = 72;
		*iParam4 = 64;
		break;

	case 79:
		StringCopy(sParam1, "MIGHT_PURPLE", 16);
		*iParam2 = 0;
		*iParam3 = 146;
		*iParam4 = 145;
		break;

	case 80:
		StringCopy(sParam1, "BRIGHT_PURPLE", 16);
		*iParam2 = 0;
		*iParam3 = 145;
		*iParam4 = 74;
		break;

	case 81:
		StringCopy(sParam1, "CREAM", 16);
		*iParam2 = 0;
		*iParam3 = 107;
		*iParam4 = 107;
		break;

	case 82:
		StringCopy(sParam1, "WHITE", 16);
		*iParam2 = 0;
		*iParam3 = 111;
		*iParam4 = 0;
		break;

	case 83:
		StringCopy(sParam1, "FROST_WHITE", 16);
		*iParam2 = 0;
		*iParam3 = 112;
		*iParam4 = 0;
		break;

	case 84:
		StringCopy(sParam1, "BLACK", 16);
		*iParam2 = 1;
		*iParam3 = 0;
		*iParam4 = 0;
		break;

	case 85:
		StringCopy(sParam1, "BLACK_GRAPHITE", 16);
		*iParam2 = 1;
		*iParam3 = 147;
		*iParam4 = 0;
		break;

	case 86:
		StringCopy(sParam1, "GRAPHITE", 16);
		*iParam2 = 1;
		*iParam3 = 1;
		*iParam4 = 0;
		break;

	case 87:
		StringCopy(sParam1, "ANTHR_BLACK", 16);
		*iParam2 = 1;
		*iParam3 = 11;
		*iParam4 = 0;
		break;

	case 88:
		StringCopy(sParam1, "BLACK_STEEL", 16);
		*iParam2 = 1;
		*iParam3 = 2;
		*iParam4 = 0;
		break;

	case 89:
		StringCopy(sParam1, "DARK_SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 3;
		*iParam4 = 2;
		break;

	case 90:
		StringCopy(sParam1, "SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 4;
		*iParam4 = 4;
		break;

	case 91:
		StringCopy(sParam1, "BLUE_SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 5;
		*iParam4 = 5;
		break;

	case 92:
		StringCopy(sParam1, "ROLLED_STEEL", 16);
		*iParam2 = 1;
		*iParam3 = 6;
		*iParam4 = 0;
		break;

	case 93:
		StringCopy(sParam1, "SHADOW_SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 7;
		*iParam4 = 0;
		break;

	case 94:
		StringCopy(sParam1, "STONE_SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 8;
		*iParam4 = 0;
		break;

	case 95:
		StringCopy(sParam1, "MIDNIGHT_SILVER", 16);
		*iParam2 = 1;
		*iParam3 = 9;
		*iParam4 = 0;
		break;

	case 96:
		StringCopy(sParam1, "CAST_IRON_SIL", 16);
		*iParam2 = 1;
		*iParam3 = 10;
		*iParam4 = 0;
		break;

	case 97:
		StringCopy(sParam1, "RED", 16);
		*iParam2 = 1;
		*iParam3 = 27;
		*iParam4 = 0;
		break;

	case 98:
		StringCopy(sParam1, "TORINO_RED", 16);
		*iParam2 = 1;
		*iParam3 = 28;
		*iParam4 = 0;
		break;

	case 99:
		StringCopy(sParam1, "FORMULA_RED", 16);
		*iParam2 = 1;
		*iParam3 = 29;
		*iParam4 = 0;
		break;

	case 100:
		StringCopy(sParam1, "LAVA_RED", 16);
		*iParam2 = 1;
		*iParam3 = 150;
		*iParam4 = 0;
		break;

	case 101:
		StringCopy(sParam1, "BLAZE_RED", 16);
		*iParam2 = 1;
		*iParam3 = 30;
		*iParam4 = 0;
		break;

	case 102:
		StringCopy(sParam1, "GRACE_RED", 16);
		*iParam2 = 1;
		*iParam3 = 31;
		*iParam4 = 0;
		break;

	case 103:
		StringCopy(sParam1, "GARNET_RED", 16);
		*iParam2 = 1;
		*iParam3 = 32;
		*iParam4 = 0;
		break;

	case 104:
		StringCopy(sParam1, "SUNSET_RED", 16);
		*iParam2 = 1;
		*iParam3 = 33;
		*iParam4 = 0;
		break;

	case 105:
		StringCopy(sParam1, "CABERNET_RED", 16);
		*iParam2 = 1;
		*iParam3 = 34;
		*iParam4 = 0;
		break;

	case 106:
		StringCopy(sParam1, "WINE_RED", 16);
		*iParam2 = 1;
		*iParam3 = 143;
		*iParam4 = 0;
		break;

	case 107:
		StringCopy(sParam1, "CANDY_RED", 16);
		*iParam2 = 1;
		*iParam3 = 35;
		*iParam4 = 0;
		break;

	case 108:
		StringCopy(sParam1, "HOT PINK", 16);
		*iParam2 = 1;
		*iParam3 = 135;
		*iParam4 = 0;
		break;

	case 109:
		StringCopy(sParam1, "PINK", 16);
		*iParam2 = 1;
		*iParam3 = 137;
		*iParam4 = 0;
		break;

	case 110:
		StringCopy(sParam1, "SALMON_PINK", 16);
		*iParam2 = 1;
		*iParam3 = 136;
		*iParam4 = 0;
		break;

	case 111:
		StringCopy(sParam1, "SUNRISE_ORANGE", 16);
		*iParam2 = 1;
		*iParam3 = 36;
		*iParam4 = 0;
		break;

	case 112:
		StringCopy(sParam1, "BRIGHT_ORANGE", 16);
		*iParam2 = 1;
		*iParam3 = 138;
		*iParam4 = 0;
		break;

	case 113:
		StringCopy(sParam1, "GOLD", 16);
		*iParam2 = 1;
		*iParam3 = 99;
		*iParam4 = 99;
		break;

	case 114:
		StringCopy(sParam1, "BRONZE", 16);
		*iParam2 = 1;
		*iParam3 = 90;
		*iParam4 = 102;
		break;

	case 115:
		StringCopy(sParam1, "YELLOW", 16);
		*iParam2 = 1;
		*iParam3 = 88;
		*iParam4 = 0;
		break;

	case 116:
		StringCopy(sParam1, "FLUR_YELLOW", 16);
		*iParam2 = 1;
		*iParam3 = 91;
		*iParam4 = 0;
		break;

	case 117:
		StringCopy(sParam1, "DARK_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 49;
		*iParam4 = 0;
		break;

	case 118:
		StringCopy(sParam1, "SEA_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 51;
		*iParam4 = 0;
		break;

	case 119:
		StringCopy(sParam1, "OLIVE_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 52;
		*iParam4 = 0;
		break;

	case 120:
		StringCopy(sParam1, "BRIGHT_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 53;
		*iParam4 = 0;
		break;

	case 121:
		StringCopy(sParam1, "PETROL_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 54;
		*iParam4 = 0;
		break;

	case 122:
		StringCopy(sParam1, "LIME_GREEN", 16);
		*iParam2 = 1;
		*iParam3 = 92;
		*iParam4 = 0;
		break;

	case 123:
		StringCopy(sParam1, "MIDNIGHT_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 141;
		*iParam4 = 0;
		break;

	case 124:
		StringCopy(sParam1, "GALAXY_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 61;
		*iParam4 = 0;
		break;

	case 125:
		StringCopy(sParam1, "DARK_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 62;
		*iParam4 = 0;
		break;

	case 126:
		StringCopy(sParam1, "SAXON_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 63;
		*iParam4 = 0;
		break;

	case 127:
		StringCopy(sParam1, "BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 64;
		*iParam4 = 0;
		break;

	case 128:
		StringCopy(sParam1, "MARINER_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 65;
		*iParam4 = 0;
		break;

	case 129:
		StringCopy(sParam1, "HARBOR_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 66;
		*iParam4 = 0;
		break;

	case 130:
		StringCopy(sParam1, "DIAMOND_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 67;
		*iParam4 = 0;
		break;

	case 131:
		StringCopy(sParam1, "SURF_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 68;
		*iParam4 = 0;
		break;

	case 132:
		StringCopy(sParam1, "NAUTICAL_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 69;
		*iParam4 = 0;
		break;

	case 133:
		StringCopy(sParam1, "RACING_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 73;
		*iParam4 = 0;
		break;

	case 134:
		StringCopy(sParam1, "LIGHT_BLUE", 16);
		*iParam2 = 1;
		*iParam3 = 74;
		*iParam4 = 0;
		break;

	case 135:
		StringCopy(sParam1, "BISON_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 101;
		*iParam4 = 0;
		break;

	case 136:
		StringCopy(sParam1, "CREEK_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 95;
		*iParam4 = 0;
		break;

	case 137:
		StringCopy(sParam1, "UMBER_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 94;
		*iParam4 = 0;
		break;

	case 138:
		StringCopy(sParam1, "MAPLE_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 97;
		*iParam4 = 0;
		break;

	case 139:
		StringCopy(sParam1, "BEECHWOOD_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 103;
		*iParam4 = 0;
		break;

	case 140:
		StringCopy(sParam1, "SIENNA_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 104;
		*iParam4 = 0;
		break;

	case 141:
		StringCopy(sParam1, "SADDLE_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 98;
		*iParam4 = 0;
		break;

	case 142:
		StringCopy(sParam1, "MOSS_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 100;
		*iParam4 = 0;
		break;

	case 143:
		StringCopy(sParam1, "WOODBEECH_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 102;
		*iParam4 = 0;
		break;

	case 144:
		StringCopy(sParam1, "STRAW_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 99;
		*iParam4 = 0;
		break;

	case 145:
		StringCopy(sParam1, "SANDY_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 105;
		*iParam4 = 0;
		break;

	case 146:
		StringCopy(sParam1, "BLEECHED_BROWN", 16);
		*iParam2 = 1;
		*iParam3 = 106;
		*iParam4 = 0;
		break;

	case 147:
		StringCopy(sParam1, "PURPLE", 16);
		*iParam2 = 1;
		*iParam3 = 71;
		*iParam4 = 0;
		break;

	case 148:
		StringCopy(sParam1, "SPIN_PURPLE", 16);
		*iParam2 = 1;
		*iParam3 = 72;
		*iParam4 = 0;
		break;

	case 149:
		StringCopy(sParam1, "MIGHT_PURPLE", 16);
		*iParam2 = 1;
		*iParam3 = 142;
		*iParam4 = 0;
		break;

	case 150:
		StringCopy(sParam1, "BRIGHT_PURPLE", 16);
		*iParam2 = 1;
		*iParam3 = 145;
		*iParam4 = 0;
		break;

	case 151:
		StringCopy(sParam1, "CREAM", 16);
		*iParam2 = 1;
		*iParam3 = 107;
		*iParam4 = 0;
		break;

	case 152:
		StringCopy(sParam1, "FROST_WHITE", 16);
		*iParam2 = 1;
		*iParam3 = 112;
		*iParam4 = 0;
		break;

	case 153:
		StringCopy(sParam1, "BLACK", 16);
		*iParam2 = 2;
		*iParam3 = 12;
		*iParam4 = 0;
		break;

	case 154:
		StringCopy(sParam1, "GREY", 16);
		*iParam2 = 2;
		*iParam3 = 13;
		*iParam4 = 0;
		break;

	case 155:
		StringCopy(sParam1, "LIGHT_GREY", 16);
		*iParam2 = 2;
		*iParam3 = 14;
		*iParam4 = 0;
		break;

	case 156:
		StringCopy(sParam1, "WHITE", 16);
		*iParam2 = 2;
		*iParam3 = 131;
		*iParam4 = 0;
		break;

	case 157:
		StringCopy(sParam1, "BLUE", 16);
		*iParam2 = 2;
		*iParam3 = 83;
		*iParam4 = 0;
		break;

	case 158:
		StringCopy(sParam1, "DARK_BLUE", 16);
		*iParam2 = 2;
		*iParam3 = 82;
		*iParam4 = 0;
		break;

	case 159:
		StringCopy(sParam1, "MIDNIGHT_BLUE", 16);
		*iParam2 = 2;
		*iParam3 = 84;
		*iParam4 = 0;
		break;

	case 160:
		StringCopy(sParam1, "MIGHT_PURPLE", 16);
		*iParam2 = 2;
		*iParam3 = 149;
		*iParam4 = 0;
		break;

	case 161:
		StringCopy(sParam1, "Purple", 16);
		*iParam2 = 2;
		*iParam3 = 148;
		*iParam4 = 0;
		break;

	case 162:
		StringCopy(sParam1, "RED", 16);
		*iParam2 = 2;
		*iParam3 = 39;
		*iParam4 = 0;
		break;

	case 163:
		StringCopy(sParam1, "DARK_RED", 16);
		*iParam2 = 2;
		*iParam3 = 40;
		*iParam4 = 0;
		break;

	case 164:
		StringCopy(sParam1, "ORANGE", 16);
		*iParam2 = 2;
		*iParam3 = 41;
		*iParam4 = 0;
		break;

	case 165:
		StringCopy(sParam1, "YELLOW", 16);
		*iParam2 = 2;
		*iParam3 = 42;
		*iParam4 = 0;
		break;

	case 166:
		StringCopy(sParam1, "GREEN", 16);
		*iParam2 = 2;
		*iParam3 = 128;
		*iParam4 = 0;
		break;

	case 167:
		StringCopy(sParam1, "MATTE_FOR", 16);
		*iParam2 = 2;
		*iParam3 = 151;
		*iParam4 = 0;
		break;

	case 168:
		StringCopy(sParam1, "MATTE_FOIL", 16);
		*iParam2 = 2;
		*iParam3 = 155;
		*iParam4 = 0;
		break;

	case 169:
		StringCopy(sParam1, "MATTE_OD", 16);
		*iParam2 = 2;
		*iParam3 = 152;
		*iParam4 = 0;
		break;

	case 170:
		StringCopy(sParam1, "MATTE_DIRT", 16);
		*iParam2 = 2;
		*iParam3 = 153;
		*iParam4 = 0;
		break;

	case 171:
		StringCopy(sParam1, "MATTE_DESERT", 16);
		*iParam2 = 2;
		*iParam3 = 154;
		*iParam4 = 0;
		break;

	case 172:
		StringCopy(sParam1, "BR_STEEL", 16);
		*iParam2 = 3;
		*iParam3 = 117;
		*iParam4 = 18;
		break;

	case 173:
		StringCopy(sParam1, "BR_ALUMINIUM", 16);
		*iParam2 = 3;
		*iParam3 = 119;
		*iParam4 = 5;
		break;

	case 174:
		StringCopy(sParam1, "GOLD_P", 16);
		*iParam2 = 3;
		*iParam3 = 158;
		*iParam4 = 160;
		break;

	case 175:
		StringCopy(sParam1, "GOLD_S", 16);
		*iParam2 = 3;
		*iParam3 = 159;
		*iParam4 = 160;
		break;
	}
	return *iParam2 != -1;
}

// Position - 0xD915
float func_200(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	float fVar6;

	iVar0 = 100000;
	iVar1 = 65000;
	iVar2 = 50000;
	iVar3 = 20000;
	iVar4 = 20000;
	iVar5 = iVar4;
	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0) &&
		vehicle::get_vehicle_mod_kit(iParam0) >= 0 && vehicle::get_vehicle_mod_kit(iParam0) < 255) {
		if (vehicle::get_vehicle_mod_kit_type(iParam0) == 3) {
			iVar5 = iVar0;
		}
		else if (vehicle::get_vehicle_mod_kit_type(iParam0) == 1) {
			iVar5 = iVar1;
		}
		else if (vehicle::get_vehicle_mod_kit_type(iParam0) == 2) {
			iVar5 = iVar2;
		}
		else if (vehicle::get_vehicle_mod_kit_type(iParam0) == 0) {
			if (vehicle::is_this_model_a_bike(entity::get_entity_model(iParam0))) {
				iVar5 = iVar3;
			}
			else {
				iVar5 = iVar4;
			}
		}
	}
	fVar6 = system::to_float(iVar5) / system::to_float(iVar4);
	return fVar6;
}

// Position - 0xD9D3
int func_201(int iParam0, int iParam1, int *iParam2) {
	int iVar0;

	*iParam2 = 0;
	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(entity::get_entity_model(iParam0))) {
		return 0;
	}
	iVar0 = entity::get_entity_model(iParam0);
	if (!func_202(iVar0, iParam1, iParam2)) {
		return 0;
	}
	if (vehicle::is_big_vehicle(iParam0)) {
		*iParam2 = 2;
		return 0;
	}
	if (!network::network_is_game_in_progress()) {
		if (func_140(iParam0) && entity::get_entity_model(iParam0) != joaat("sentinel2") &&
			entity::get_entity_model(iParam0) != joaat("issi2")) {
			*iParam2 = 2;
			return 0;
		}
	}
	return 1;
}

// Position - 0xDA75
int func_202(int iParam0, bool bParam1, int *iParam2) {
	if (!bParam1) {
		if (iParam0 == joaat("police") || iParam0 == joaat("policeold1") || iParam0 == joaat("policeold2") ||
			iParam0 == joaat("police2") || iParam0 == joaat("police3") || iParam0 == joaat("police4") ||
			iParam0 == joaat("fbi") || iParam0 == joaat("fbi2") || iParam0 == joaat("polmav") ||
			iParam0 == joaat("policeb") || iParam0 == joaat("policet") || iParam0 == joaat("riot") ||
			iParam0 == joaat("sheriff") || iParam0 == joaat("pranger") || iParam0 == joaat("sheriff2")) {
			*iParam2 = 1;
			return 0;
		}
	}
	if (iParam0 == joaat("ambulance") || iParam0 == joaat("firetruk") || iParam0 == joaat("taxi") ||
		iParam0 == joaat("lguard") || iParam0 == joaat("ripley") || iParam0 == joaat("dilettante2") ||
		iParam0 == joaat("airbus") || iParam0 == joaat("airtug")) {
		*iParam2 = 2;
		return 0;
	}
	if (iParam0 == joaat("burrito") || iParam0 == joaat("rumpo2") || iParam0 == joaat("speedo") ||
		iParam0 == joaat("speedo2")) {
		*iParam2 = 2;
		return 0;
	}
	if (iParam0 == joaat("scorcher") || iParam0 == joaat("bmx") || iParam0 == joaat("cruiser") ||
		iParam0 == joaat("fixter")) {
		*iParam2 = 2;
		return 0;
	}
	if (iParam0 == joaat("caddy") || iParam0 == joaat("forklift") || iParam0 == joaat("caddy2") ||
		iParam0 == joaat("crusader") || iParam0 == joaat("tribike") || iParam0 == joaat("tribike2") ||
		iParam0 == joaat("tribike3") || iParam0 == joaat("tractor") || iParam0 == joaat("tractor2") ||
		iParam0 == joaat("mower") || iParam0 == joaat("tornado4") || iParam0 == joaat("docktug") ||
		iParam0 == joaat("stretch") || iParam0 == joaat("bison2") || iParam0 == joaat("bison3") ||
		iParam0 == joaat("benson") || iParam0 == joaat("pounder") || iParam0 == joaat("submersible") ||
		iParam0 == joaat("emperor3") || iParam0 == joaat("dune2")) {
		*iParam2 = 2;
		return 0;
	}
	if (!vehicle::is_this_model_a_car(iParam0) && !vehicle::is_this_model_a_bike(iParam0) &&
		iParam0 != joaat("blazer") && iParam0 != joaat("blazer3") && iParam0 != joaat("blazer4") &&
		iParam0 != joaat("blazer5") && iParam0 != joaat("chimera")) {
		*iParam2 = 2;
		return 0;
	}
	if (iParam0 == joaat("monster")) {
		*iParam2 = 2;
		return 0;
	}
	if (iParam0 == joaat("insurgent") || iParam0 == joaat("technical") || iParam0 == joaat("limo2")) {
		*iParam2 = 2;
		return 0;
	}
	if (network::network_is_game_in_progress()) {
		if (func_203(iParam0)) {
			*iParam2 = 2;
			return 0;
		}
	}
	if (!network::network_is_game_in_progress()) {
		if (iParam0 == joaat("insurgent") || iParam0 == joaat("insurgent2")) {
			*iParam2 = 2;
		}
	}
	return 1;
}

// Position - 0xDE43
bool func_203(int iParam0) {
	switch (iParam0) {
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("forklift"): return true;
	}
	return false;
}

// Position - 0xDE6C
void func_204(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (!entity::does_entity_exist(Global_89155[iVar0])) {
			Global_89155[iVar0] = iParam0;
			Global_89165[iVar0] = iParam1;
			Global_89175[iVar0] = entity::get_entity_model(iParam0);
			if (vehicle::is_this_model_a_car(Global_89175[iVar0])) {
				Global_89203[iParam1 /*3*/][0] = -1;
			}
			else {
				Global_89203[iParam1 /*3*/][1] = -1;
			}
			iVar0 = 9;
		}
		if (iVar0 == 8) {
		}
		iVar0++;
	}
}

// Position - 0xDEEE
void func_205(var *uParam0) {
	if (!func_206(*uParam0)) {
		vehicle::set_vehicle_extra(*uParam0, 5, !Global_101700.f_8044.f_99.f_58[119]);
	}
}

// Position - 0xDF19
bool func_206(int iParam0) { return vehicle::is_vehicle_extra_turned_on(iParam0, 5); }

// Position - 0xDF28
int func_207(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	vehicle::set_vehicle_mod_kit(*iParam0, 0);
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			vehicle::toggle_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] > 0);
		}
		else if (vehicle::get_vehicle_mod(*iParam0, iVar1) != (*uParam1)[iVar0] - 1) {
			vehicle::remove_vehicle_mod(*iParam0, iVar1);
			if ((*uParam1)[iVar0] > 0) {
				if (iVar0 == 23) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[0] > 0);
				}
				else if (iVar0 == 24) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[1] > 0);
				}
				else {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, 0);
				}
			}
		}
		iVar0++;
	}
	if (func_210(entity::get_entity_model(*iParam0), 1) &&
		vehicle::get_vehicle_mod(*iParam0, 24) != func_209(*iParam0, (*uParam1)[38] - 1)) {
		vehicle::set_vehicle_mod(*iParam0, 24, func_209(*iParam0, (*uParam1)[38] - 1), 0);
	}
	if (func_208(*iParam0)) {
		vehicle::set_vehicle_strong(*iParam0, 1);
		vehicle::set_vehicle_has_strong_axles(*iParam0, 1);
	}
	return 1;
}

// Position - 0xE0A0
bool func_208(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	char cVar3[16];

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0) &&
		vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = 0;
		while (iVar0 < 49) {
			iVar1 = iVar0;
			if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			}
			else if (vehicle::get_vehicle_mod(iParam0, iVar1) != -1) {
				StringCopy(&cVar3,
						   vehicle::get_mod_text_label(iParam0, iVar1, vehicle::get_vehicle_mod(iParam0, iVar1)), 16);
				iVar2 = gameplay::get_hash_key(&cVar3);
				if (iVar2 != 0) {
					if (iVar2 == gameplay::get_hash_key("MNU_CAGE") || iVar2 == gameplay::get_hash_key("SABRE_CAG")) {
						return true;
					}
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0xE17C
int func_209(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	float fVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		switch (entity::get_entity_model(iParam0)) {
		case joaat("tornado5"):
			switch (iParam1) {
			case 0: return 0;

			case 1: return 1;

			case 2: return 2;

			case 3: return 3;

			case 4: return 4;

			case 5: return 4;
			}
			break;

		case joaat("faction3"): return 3;
		}
		iVar0 = vehicle::get_num_vehicle_mods(iParam0, 38);
		iVar1 = vehicle::get_num_vehicle_mods(iParam0, 24);
		fVar2 = system::to_float(iParam1 + 1) / system::to_float(iVar0);
		iVar3 = system::floor(system::to_float(iVar1) * fVar2) - 1;
		if (iVar3 < 0) {
			iVar3 = 0;
		}
		if (iVar3 >= iVar0) {
			iVar3 = iVar0 - 1;
		}
		return iVar3;
	}
	return 0;
}

// Position - 0xE261
int func_210(int iParam0, int iParam1) {
	switch (iParam0) {
	case joaat("faction2"):
	case joaat("buccaneer2"):
	case joaat("chino2"):
	case joaat("moonbeam2"):
	case joaat("primo2"):
	case joaat("voodoo"): return 1;

	case joaat("sabregt2"):
		if (!Global_262145.f_12339) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("tornado5"):
		if (!Global_262145.f_12340) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("virgo2"):
		if (!Global_262145.f_12338) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("minivan2"):
		if (!Global_262145.f_12341) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("slamvan3"):
		if (!Global_262145.f_12343) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("faction3"):
		if (!Global_262145.f_12342) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("sultanrs"):
	case joaat("banshee2"):
		if ((iParam1 & 1) != 0) {
			return 0;
		}
		return 1;

	case joaat("comet3"):
		if (Global_262145.f_16780) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("diablous2"):
		if (Global_262145.f_16782) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("fcr2"):
		if (Global_262145.f_16786) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("elegy"):
		if (Global_262145.f_16783) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("nero2"):
		if (Global_262145.f_16790) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("italigtb2"):
		if (Global_262145.f_16788) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("specter2"):
		if (Global_262145.f_16793) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0xE486
bool func_211(var *uParam0, int iParam1) {
	if (network::network_is_game_in_progress()) {
	}
	else if (Global_101700.f_19077.f_261) {
		*uParam0 = {Global_101700.f_19077.f_267};
		*iParam1 = Global_101700.f_19077.f_271;
		return true;
	}
	return false;
}

// Position - 0xE4C7
void func_212(int iParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (gameplay::get_hash_key(&uParam1->f_1) != 0) {
			vehicle::set_vehicle_number_plate_text(iParam0, &uParam1->f_1);
		}
		if (*uParam1 >= 0 && *uParam1 < vehicle::get_number_of_vehicle_number_plates()) {
			vehicle::set_vehicle_number_plate_text_index(iParam0, *uParam1);
		}
		if (uParam1->f_66 == joaat("sovereign")) {
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 111;
		}
		else if (uParam1->f_66 == joaat("casco")) {
			iVar0 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_168(iVar0 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_168(iVar0 + 1));
			}
		}
		else if (uParam1->f_66 == joaat("sandking") || uParam1->f_66 == joaat("sandking2")) {
			iVar1 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_168(iVar1 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_168(iVar1 + 1));
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 13)) {
			vehicle::set_vehicle_custom_primary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_primary_colour(iParam0);
		}
		if (gameplay::is_bit_set(uParam1->f_77, 12)) {
			vehicle::set_vehicle_custom_secondary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_secondary_colour(iParam0);
		}
		vehicle::set_vehicle_colours(iParam0, uParam1->f_5, uParam1->f_6);
		if (uParam1->f_7 < 0) {
			uParam1->f_7 = 0;
		}
		if (uParam1->f_8 < 0) {
			uParam1->f_8 = 0;
		}
		vehicle::set_vehicle_extra_colours(iParam0, uParam1->f_7, uParam1->f_8);
		if (gameplay::is_bit_set(uParam1->f_77, 15) || func_215(iParam0) ||
			uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0 && uParam1->f_9[20] > 0)
			&&func_214() {
				uParam1->f_62 = 0;
				uParam1->f_63 = 0;
				uParam1->f_64 = 0;
			}
		else if (uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0) {
			uParam1->f_62 = 255;
			uParam1->f_63 = 255;
			uParam1->f_64 = 255;
		}
		vehicle::set_vehicle_tyre_smoke_color(iParam0, uParam1->f_62, uParam1->f_63, uParam1->f_64);
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			vehicle::set_vehicle_window_tint(iParam0, 0);
		}
		else {
			vehicle::set_vehicle_window_tint(iParam0, 0);
			vehicle::set_vehicle_window_tint(iParam0, uParam1->f_65);
		}
		vehicle::set_vehicle_tyres_can_burst(iParam0, !gameplay::is_bit_set(uParam1->f_77, 9));
		if (iParam2) {
			vehicle::set_vehicle_doors_locked(iParam0, uParam1->f_70);
		}
		vehicle::_set_vehicle_neon_lights_colour(iParam0, uParam1->f_74, uParam1->f_75, uParam1->f_76);
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 2, gameplay::is_bit_set(uParam1->f_77, 28));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 3, gameplay::is_bit_set(uParam1->f_77, 29));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 0, gameplay::is_bit_set(uParam1->f_77, 30));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 1, gameplay::is_bit_set(uParam1->f_77, 31));
		vehicle::set_vehicle_is_stolen(iParam0, gameplay::is_bit_set(uParam1->f_77, 10));
		if (vehicle::get_vehicle_livery_count(iParam0) > 1 && uParam1->f_67 >= 0) {
			vehicle::set_vehicle_livery(iParam0, uParam1->f_67);
		}
		if (uParam1->f_69 > -1 && uParam1->f_69 < 255) {
			if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(iParam0))) {
				if (vehicle::is_this_model_a_bike(entity::get_entity_model(iParam0))) {
					if (uParam1->f_69 == 6) {
						func_213(iParam0, uParam1->f_69);
					}
				}
				else {
					func_213(iParam0, uParam1->f_69);
				}
			}
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			if (uParam1->f_68 == 0 || uParam1->f_68 == 3 || uParam1->f_68 == 5) {
				vehicle::raise_convertible_roof(iParam0, 1);
			}
			else {
				vehicle::lower_convertible_roof(iParam0, 1);
			}
		}
		if (iParam3) {
			func_207(&iParam0, &uParam1->f_9, &uParam1->f_59);
		}
		if (!vehicle::is_this_model_a_heli(uParam1->f_66) && !vehicle::is_this_model_a_boat(uParam1->f_66)) {
			iVar2 = 0;
			while (iVar2 <= 11) {
				if (gameplay::is_bit_set(uParam1->f_77, func_168(iVar2 + 1))) {
					if (!vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
						vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 0);
					}
				}
				else if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
					vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 1);
				}
				iVar2++;
			}
		}
		if (entity::get_entity_model(iParam0) == joaat("sheava") ||
			entity::get_entity_model(iParam0) == joaat("omnis") || entity::get_entity_model(iParam0) == joaat("le7b")) {
			if (vehicle::get_vehicle_mod(iParam0, 0) == -1) {
				vehicle::set_vehicle_extra(iParam0, 1, 0);
			}
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (!gameplay::is_bit_set(uParam1->f_77, 23)) {
				if (gameplay::is_bit_set(uParam1->f_77, 22)) {
					vehicle::control_landing_gear(iParam0, 2);
				}
				else {
					vehicle::control_landing_gear(iParam0, 3);
				}
			}
			else {
				vehicle::control_landing_gear(iParam0, 4);
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 27)) {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 1);
		}
		else {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 0);
		}
	}
}

// Position - 0xE975
void func_213(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = vehicle::get_vehicle_mod(iParam0, 24);
		iVar1 = vehicle::get_vehicle_mod_variation(iParam0, 24);
		vehicle::set_vehicle_wheel_type(iParam0, iParam1);
		if (entity::get_entity_model(iParam0) == joaat("tornado6")) {
			return;
		}
		if (iVar0 == -1) {
			vehicle::remove_vehicle_mod(iParam0, 24);
		}
		else {
			vehicle::set_vehicle_mod(iParam0, 24, iVar0, iVar1 == 1);
		}
	}
}

// Position - 0xE9DA
var func_214() { return dlc2::is_dlc_present(-1691188696); }

// Position - 0xE9EB
int func_215(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (decorator::decor_is_registered_as_type("MPBitset", 3)) {
				if (decorator::decor_exist_on(iParam0, "MPBitset")) {
					iVar0 = decorator::decor_get_int(iParam0, "MPBitset");
				}
				return gameplay::is_bit_set(iVar0, 4);
			}
		}
	}
	return 0;
}

// Position - 0xEA36
int func_216(int iParam0, var *uParam1) {
	struct<82> Var0;

	if (!func_159(iParam0)) {
		return 0;
	}
	if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam0 /*98*/] != 0) {
		if (Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam0 /*98*/] == uParam1->f_66 &&
			gameplay::get_hash_key(&Global_101700.f_2095.f_539.f_1635[0 /*295*/][iParam0 /*98*/].f_27) ==
				gameplay::get_hash_key(&uParam1->f_1)) {
			return 1;
		}
	}
	if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam0 /*98*/] != 0) {
		if (Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam0 /*98*/] == uParam1->f_66 &&
			gameplay::get_hash_key(&Global_101700.f_2095.f_539.f_1635[1 /*295*/][iParam0 /*98*/].f_27) ==
				gameplay::get_hash_key(&uParam1->f_1)) {
			return 1;
		}
	}
	Var0.f_11 = 12;
	Var0.f_31 = 49;
	Var0.f_81 = 2;
	func_158(iParam0, &Var0, 1);
	if (Var0 != 0) {
		if (Var0 == uParam1->f_66 && gameplay::get_hash_key(&Var0.f_27) == gameplay::get_hash_key(&uParam1->f_1)) {
			return 1;
		}
	}
	func_158(iParam0, &Var0, 2);
	if (Var0 != 0) {
		if (Var0 == uParam1->f_66 && gameplay::get_hash_key(&Var0.f_27) == gameplay::get_hash_key(&uParam1->f_1)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xEB90
bool func_217() { return func_218(&Global_93635.f_2311); }

// Position - 0xEBA3
int func_218(var *uParam0) {
	if (uParam0->f_12.f_66 == 0) {
		return 0;
	}
	if (!func_130(uParam0->f_12.f_66, 0)) {
		return 0;
	}
	if (uParam0->f_12.f_66 == joaat("stunt") && func_52(*uParam0, 1694.62f, 3276.27f, 41.31f, 1056964608, 0)) {
		return 0;
	}
	return 1;
}

// Position - 0xEC02
bool func_219() { return func_218(&Global_96040.f_2311); }

// Position - 0xEC15
int func_220(int iParam0) {
	bool bVar0;
	vector3 vVar1;

	bVar0 = false;
	func_228(&uLocal_99, &Global_88686);
	func_229(&uLocal_99, joaat("s_m_m_armoured_01"));
	func_229(&uLocal_99, iLocal_85);
	func_229(&uLocal_99, iLocal_86);
	if (streaming::has_model_loaded(joaat("s_m_m_armoured_01")) && streaming::has_model_loaded(iLocal_85) &&
		streaming::has_model_loaded(iLocal_86)) {
		if (iParam0) {
			if (!entity::does_entity_exist(Local_1318)) {
				if (entity::does_entity_exist(Global_88321[0])) {
					entity::set_entity_as_mission_entity(Global_88321[0], 1, 1);
					Local_1318 = Global_88321[0];
				}
				else {
					bVar0 = false;
				}
			}
			if (!entity::does_entity_exist(vLocal_1306.x)) {
				if (entity::does_entity_exist(Global_88321.f_9[0])) {
					entity::set_entity_as_mission_entity(Global_88321.f_9[0], 1, 1);
					vLocal_1306.x = Global_88321.f_9[0];
				}
				else {
					bVar0 = false;
				}
			}
		}
		else {
			func_229(&uLocal_99, iLocal_84);
			if (streaming::has_model_loaded(iLocal_84) && ai::get_is_waypoint_recording_loaded(&Global_88686)) {
				if (gameplay::are_strings_equal(&Global_88686, "jhp2a_main")) {
					ai::waypoint_recording_get_coord(&Global_88686, 23, &vVar1);
					gameplay::clear_area_of_vehicles(vVar1, 20f, 0, 0, 0, 0, 0);
					Local_1318 = vehicle::create_vehicle(iLocal_84, vVar1, 119.4988f, 1, 1);
					vLocal_1306.x = ped::create_ped_inside_vehicle(Local_1318, 26, iLocal_83, -1, 1, 1);
					vehicle::set_vehicle_on_ground_properly(Local_1318, 1084227584);
					ai::task_vehicle_follow_waypoint_recording(vLocal_1306.x, Local_1318, &Global_88686, 786475, 23, 16,
															   -1, 12f, 0, 1073741824);
				}
				else {
					ai::waypoint_recording_get_coord(&Global_88686, 29, &vVar1);
					gameplay::clear_area_of_vehicles(vVar1, 20f, 0, 0, 0, 0, 0);
					Local_1318 = vehicle::create_vehicle(iLocal_84, vVar1, 134.0011f, 1, 1);
					vLocal_1306.x = ped::create_ped_inside_vehicle(Local_1318, 26, iLocal_83, -1, 1, 1);
					vehicle::set_vehicle_on_ground_properly(Local_1318, 1084227584);
					ai::task_vehicle_follow_waypoint_recording(vLocal_1306.x, Local_1318, &Global_88686, 786475, 29, 16,
															   -1, 12f, 0, 1073741824);
				}
			}
		}
		if (entity::does_entity_exist(Local_1318)) {
			func_226(Local_1318, 0);
			if (vehicle::is_vehicle_driveable(Local_1318, 0)) {
				vehicle::set_vehicle_has_strong_axles(Local_1318, 1);
				entity::set_entity_load_collision_flag(Local_1318, 1);
				vehicle::_0x192547247864DFDD(Local_1318, 1);
				vehicle::_0x2B6747FAA9DB9D6B(Local_1318, 1);
			}
		}
		if (entity::does_entity_exist(vLocal_1306.x)) {
			if (!ped::is_ped_injured(vLocal_1306.x)) {
				ped::set_blocking_of_non_temporary_events(vLocal_1306.x, 1);
				ped::set_ped_relationship_group_hash(vLocal_1306.x, iLocal_1305);
				ped::set_ped_accuracy(vLocal_1306.x, 5);
				ped::set_ped_can_be_targetted(vLocal_1306.x, 0);
				ped::set_ped_combat_attributes(vLocal_1306.x, 1, 0);
				weapon::give_weapon_to_ped(vLocal_1306.x, joaat("weapon_pistol"), 15, 0, 1);
				func_225(&uLocal_1126, 3, vLocal_1306.x, "JHP2A_Driver", 0, 1);
				func_224(&Local_1084[0 /*8*/], 0, 0, 1);
			}
		}
		if (entity::does_entity_exist(Local_1318) && entity::does_entity_exist(vLocal_1306.x)) {
			func_223();
			func_224(&Local_1084[1 /*8*/], 0, 0, 1);
			func_221(&uLocal_99, joaat("boxville3"));
			func_221(&uLocal_99, joaat("s_m_m_armoured_01"));
			func_221(&uLocal_99, iLocal_85);
			func_221(&uLocal_99, iLocal_86);
			return 1;
		}
		else if (bVar0) {
		}
	}
	return 0;
}

// Position - 0xEF07
void func_221(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0 /*5*/]) {
			if ((*uParam0)[iVar0 /*5*/].f_4 == iParam1) {
				if ((*uParam0)[iVar0 /*5*/].f_1) {
					streaming::set_model_as_no_longer_needed(iParam1);
					func_222(&(*uParam0)[iVar0 /*5*/]);
					return;
				}
				else {
					(*uParam0)[iVar0 /*5*/].f_2 = 1;
					uParam0->f_982 = 1;
					return;
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xEF6C
void func_222(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	uParam0->f_3 = -1;
}

// Position - 0xEF87
void func_223() {
	vector3 vVar0;

	if (entity::does_entity_exist(Local_1318)) {
		if (!entity::is_entity_dead(Local_1318, 0) && !entity::does_entity_exist(iLocal_1329)) {
			iLocal_1329 = object::create_object(iLocal_86, entity::get_entity_coords(Local_1318, 1), 1, 1, 0);
			object::set_object_physics_params(iLocal_1329, 0.1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f);
			entity::attach_entity_to_entity_physically(
				iLocal_1329, Local_1318, -1, -1,
				entity::get_offset_from_entity_given_world_coords(
					Local_1318, entity::get_world_position_of_entity_bone(Local_1318, 5)) +
					Vector(0f, 0f, 0.02f),
				0f, 0f, 0f, 0f, 0f, 0f, -1f, 1, 1, 0, 1, 2);
			entity::set_entity_visible(iLocal_1329, 0, 0);
		}
		if (!entity::does_entity_exist(Local_1322[0 /*2*/])) {
			if (entity::is_entity_dead(Local_1318, 0)) {
				vVar0 = {entity::get_offset_from_entity_in_world_coords(
					Local_1318, gameplay::get_random_float_in_range(-2.5f, 2.5f), -5f, 0f)};
				gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
				Local_1322[0 /*2*/] = object::create_object(iLocal_85, vVar0, 1, 1, 0);
			}
			else {
				Local_1322[0 /*2*/] =
					object::create_object(iLocal_85, entity::get_entity_coords(Local_1318, 1), 1, 1, 0);
				object::set_object_physics_params(Local_1322[0 /*2*/], 3.5f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f,
												  -1f, -1f);
				entity::attach_entity_to_entity(Local_1322[0 /*2*/], Local_1318, -1, -0.2f, -2.675f, 0.05f, -90f, 0f,
												-90f, 0, 0, 0, 0, 2, 1);
				entity::_set_entity_register(Local_1322[0 /*2*/], 1);
			}
		}
		if (!entity::does_entity_exist(Local_1322[1 /*2*/])) {
			if (entity::is_entity_dead(Local_1318, 0)) {
				vVar0 = {entity::get_offset_from_entity_in_world_coords(
					Local_1318, gameplay::get_random_float_in_range(-2.5f, 2.5f), -5f, 0f)};
				gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
				Local_1322[1 /*2*/] = object::create_object(iLocal_85, vVar0, 1, 1, 0);
			}
			else {
				Local_1322[1 /*2*/] =
					object::create_object(iLocal_85, entity::get_entity_coords(Local_1318, 1), 1, 1, 0);
				object::set_object_physics_params(Local_1322[1 /*2*/], 3.5f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f,
												  -1f, -1f);
				entity::attach_entity_to_entity(Local_1322[1 /*2*/], Local_1318, -1, 0f, -2.675f, 0.05f, -90f, 0f, -90f,
												0, 0, 0, 0, 2, 1);
				entity::_set_entity_register(Local_1322[1 /*2*/], 1);
			}
		}
		if (!entity::does_entity_exist(Local_1322[2 /*2*/])) {
			if (entity::is_entity_dead(Local_1318, 0)) {
				vVar0 = {entity::get_offset_from_entity_in_world_coords(
					Local_1318, gameplay::get_random_float_in_range(-2.5f, 2.5f), -5f, 0f)};
				gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
				Local_1322[2 /*2*/] = object::create_object(iLocal_85, vVar0, 1, 1, 0);
			}
			else {
				Local_1322[2 /*2*/] =
					object::create_object(iLocal_85, entity::get_entity_coords(Local_1318, 1), 1, 1, 0);
				object::set_object_physics_params(Local_1322[2 /*2*/], 3.5f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f,
												  -1f, -1f);
				entity::attach_entity_to_entity(Local_1322[2 /*2*/], Local_1318, -1, 0.2f, -2.675f, 0.05f, -90f, 0f,
												-90f, 0, 0, 0, 0, 2, 1);
				entity::_set_entity_register(Local_1322[2 /*2*/], 1);
			}
		}
	}
}

// Position - 0xF25F
int func_224(var *uParam0, int iParam1, int iParam2, int iParam3) {
	if (*uParam0 == -1) {
		return 0;
	}
	else if (*uParam0 == 1) {
		return 1;
	}
	else if (*uParam0 == 0 || *uParam0 == 2 && uParam0->f_1 == 1 && iParam2) {
		if (iParam1 > 0) {
			*uParam0 = 2;
			uParam0->f_6 = iParam1;
		}
		else {
			*uParam0 = 1;
			uParam0->f_6 = 0;
		}
		uParam0->f_4 = gameplay::get_game_timer();
		uParam0->f_5 = gameplay::get_game_timer();
		uParam0->f_1 = iParam3;
		return 1;
	}
	return 0;
}

// Position - 0xF2DF
void func_225(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0xF37A
void func_226(int iParam0, int iParam1) { Global_91491.f_22[iParam1] = iParam0; }

// Position - 0xF38E
int func_227(var *uParam0) {
	if (func_235(uParam0)) {
		return 1;
	}
	return 0;
}

// Position - 0xF3A7
int func_228(var *uParam0, char *sParam1) {
	int iVar0;
	int iVar1;

	if (gameplay::is_string_null_or_empty(sParam1)) {
		return 0;
	}
	iVar1 = -1;
	iVar0 = 0;
	while (iVar0 < uParam0->f_374) {
		if (uParam0->f_374[iVar0 /*5*/]) {
			if (gameplay::are_strings_equal(uParam0->f_374[iVar0 /*5*/].f_4, sParam1)) {
				uParam0->f_374[iVar0 /*5*/].f_2 = 0;
				if (!uParam0->f_374[iVar0 /*5*/].f_1) {
					uParam0->f_982 = 1;
					return 1;
				}
				else {
					return 1;
				}
			}
		}
		else if (iVar1 == -1) {
			iVar1 = iVar0;
		}
		iVar0++;
	}
	if (iVar1 >= 0) {
		ai::request_waypoint_recording(sParam1);
		uParam0->f_374[iVar1 /*5*/] = 1;
		uParam0->f_374[iVar1 /*5*/].f_3 = gameplay::get_game_timer();
		uParam0->f_374[iVar1 /*5*/].f_4 = sParam1;
		uParam0->f_982 = 1;
		return 1;
	}
	return 0;
}

// Position - 0xF46E
int func_229(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam1 == 0) {
		return 0;
	}
	iVar1 = -1;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0 /*5*/]) {
			if ((*uParam0)[iVar0 /*5*/].f_4 == iParam1) {
				(*uParam0)[iVar0 /*5*/].f_2 = 0;
				if (!(*uParam0)[iVar0 /*5*/].f_1) {
					uParam0->f_982 = 1;
					return 1;
				}
				else {
					return 1;
				}
			}
		}
		else if (iVar1 == -1) {
			iVar1 = iVar0;
		}
		iVar0++;
	}
	if (iVar1 >= 0) {
		streaming::request_model(iParam1);
		(*uParam0)[iVar1 /*5*/] = 1;
		(*uParam0)[iVar1 /*5*/].f_3 = gameplay::get_game_timer();
		(*uParam0)[iVar1 /*5*/].f_4 = iParam1;
		uParam0->f_982 = 1;
		return 1;
	}
	return 0;
}

// Position - 0xF517
void func_230(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 30) {
		if ((*uParam0)[iVar0 /*5*/]) {
			(*uParam0)[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		if (uParam0->f_151[iVar0 /*5*/]) {
			uParam0->f_151[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		if (uParam0->f_202[iVar0 /*7*/]) {
			uParam0->f_202[iVar0 /*7*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 20) {
		if (uParam0->f_273[iVar0 /*5*/]) {
			uParam0->f_273[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 20) {
		if (uParam0->f_374[iVar0 /*5*/]) {
			uParam0->f_374[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 30) {
		if (uParam0->f_475[iVar0 /*6*/]) {
			uParam0->f_475[iVar0 /*6*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 5) {
		if (uParam0->f_656[iVar0 /*6*/]) {
			uParam0->f_656[iVar0 /*6*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 7) {
		if (uParam0->f_687[iVar0 /*7*/]) {
			uParam0->f_687[iVar0 /*7*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 5) {
		if (uParam0->f_737[iVar0 /*5*/]) {
			uParam0->f_737[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		if (uParam0->f_763[iVar0 /*5*/]) {
			uParam0->f_763[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		if (uParam0->f_879[iVar0 /*5*/]) {
			uParam0->f_879[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 5) {
		if (uParam0->f_930[iVar0 /*5*/]) {
			uParam0->f_930[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 16) {
		if (uParam0->f_779[iVar0 /*5*/]) {
			uParam0->f_779[iVar0 /*5*/].f_2 = 1;
		}
		iVar0++;
	}
	if (uParam0->f_868) {
		uParam0->f_868.f_2 = 1;
	}
	if (uParam0->f_860) {
		uParam0->f_860.f_2 = 1;
	}
	if (uParam0->f_864) {
		uParam0->f_864.f_2 = 1;
	}
}

// Position - 0xF76F
int func_231(var *uParam0, vector3 vParam1, float fParam4, int iParam5) {
	if (func_232(vParam1) || fParam4 <= 0f) {
		return 0;
	}
	if (uParam0->f_868) {
		if (func_112(uParam0->f_868.f_4, vParam1, 0) && uParam0->f_868.f_10 == fParam4) {
			uParam0->f_868.f_2 = 0;
			if (!uParam0->f_868.f_1) {
				uParam0->f_982 = 1;
				return 1;
			}
			else {
				return 1;
			}
		}
	}
	streaming::new_load_scene_start_sphere(vParam1, fParam4, iParam5);
	uParam0->f_868 = 1;
	uParam0->f_868.f_3 = gameplay::get_game_timer();
	uParam0->f_868.f_4 = {vParam1};
	uParam0->f_868.f_7 = {0f, 0f, 0f};
	uParam0->f_868.f_10 = fParam4;
	uParam0->f_982 = 1;
	return 1;
}

// Position - 0xF827
int func_232(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0xF851
void func_233(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 0:
		*uParam1 = {1256.936f, 556.8262f, 79.7001f};
		*fParam2 = 134.0936f;
		break;

	case 1:
		*uParam1 = {692.2659f, -1004.185f, 21.9451f};
		*fParam2 = 3.5976f;
		break;
	}
}

// Position - 0xF8A8
bool func_234() { return gameplay::is_bit_set(Global_91491.f_20, 13); }

// Position - 0xF8BC
bool func_235(var *uParam0) {
	bool bVar0;
	int iVar1;
	int iVar2;

	if (uParam0->f_982) {
		bVar0 = true;
		iVar1 = 0;
		while (iVar1 < 30) {
			if ((*uParam0)[iVar1 /*5*/]) {
				if (!(*uParam0)[iVar1 /*5*/].f_1) {
					if (streaming::has_model_loaded((*uParam0)[iVar1 /*5*/].f_4)) {
						(*uParam0)[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if ((*uParam0)[iVar1 /*5*/].f_2) {
					if ((*uParam0)[iVar1 /*5*/].f_1) {
						streaming::set_model_as_no_longer_needed((*uParam0)[iVar1 /*5*/].f_4);
						func_222(&(*uParam0)[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 20) {
			if (uParam0->f_273[iVar1 /*5*/]) {
				if (!uParam0->f_273[iVar1 /*5*/].f_1) {
					if (streaming::has_anim_dict_loaded(uParam0->f_273[iVar1 /*5*/].f_4)) {
						uParam0->f_273[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_273[iVar1 /*5*/].f_2) {
					if (uParam0->f_273[iVar1 /*5*/].f_1) {
						streaming::remove_anim_dict(uParam0->f_273[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_273[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 20) {
			if (uParam0->f_374[iVar1 /*5*/]) {
				if (!uParam0->f_374[iVar1 /*5*/].f_1) {
					if (ai::get_is_waypoint_recording_loaded(uParam0->f_374[iVar1 /*5*/].f_4)) {
						uParam0->f_374[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_374[iVar1 /*5*/].f_2) {
					if (uParam0->f_374[iVar1 /*5*/].f_1) {
						ai::remove_waypoint_recording(uParam0->f_374[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_374[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 5) {
			if (uParam0->f_656[iVar1 /*6*/]) {
				if (!uParam0->f_656[iVar1 /*6*/].f_1) {
					if (graphics::has_scaleform_movie_loaded(uParam0->f_656[iVar1 /*6*/].f_5)) {
						uParam0->f_656[iVar1 /*6*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_656[iVar1 /*6*/].f_2) {
					if (uParam0->f_656[iVar1 /*6*/].f_1) {
						graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_656[iVar1 /*6*/].f_5);
						func_222(&uParam0->f_656[iVar1 /*6*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 30) {
			if (uParam0->f_475[iVar1 /*6*/]) {
				if (!uParam0->f_475[iVar1 /*6*/].f_1) {
					if (vehicle::has_vehicle_recording_been_loaded(uParam0->f_475[iVar1 /*6*/].f_5,
																   uParam0->f_475[iVar1 /*6*/].f_4)) {
						uParam0->f_475[iVar1 /*6*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_475[iVar1 /*6*/].f_2) {
					if (uParam0->f_475[iVar1 /*6*/].f_1) {
						vehicle::remove_vehicle_recording(uParam0->f_475[iVar1 /*6*/].f_5,
														  uParam0->f_475[iVar1 /*6*/].f_4);
						func_222(&uParam0->f_475[iVar1 /*6*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 10) {
			if (uParam0->f_202[iVar1 /*7*/]) {
				if (!uParam0->f_202[iVar1 /*7*/].f_1) {
					if (weapon::has_weapon_asset_loaded(uParam0->f_202[iVar1 /*7*/].f_4)) {
						uParam0->f_202[iVar1 /*7*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_202[iVar1 /*7*/].f_2) {
					if (uParam0->f_202[iVar1 /*7*/].f_1) {
						weapon::remove_weapon_asset(uParam0->f_202[iVar1 /*7*/].f_4);
						func_222(&uParam0->f_202[iVar1 /*7*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 10) {
			if (uParam0->f_151[iVar1 /*5*/]) {
				if (!uParam0->f_151[iVar1 /*5*/].f_1) {
					if (vehicle::has_vehicle_asset_loaded(uParam0->f_151[iVar1 /*5*/].f_4)) {
						uParam0->f_151[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_151[iVar1 /*5*/].f_2) {
					if (uParam0->f_151[iVar1 /*5*/].f_1) {
						vehicle::remove_vehicle_asset(uParam0->f_151[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_151[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 5) {
			if (uParam0->f_737[iVar1 /*5*/]) {
				if (!uParam0->f_737[iVar1 /*5*/].f_1) {
					if (audio::request_script_audio_bank(uParam0->f_737[iVar1 /*5*/].f_4, 0, -1)) {
						uParam0->f_737[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_737[iVar1 /*5*/].f_2) {
					if (uParam0->f_737[iVar1 /*5*/].f_1) {
						audio::release_named_script_audio_bank(uParam0->f_737[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_737[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 3) {
			if (uParam0->f_763[iVar1 /*5*/]) {
				if (!uParam0->f_763[iVar1 /*5*/].f_1) {
					if (interior::is_interior_ready(uParam0->f_763[iVar1 /*5*/].f_4)) {
						uParam0->f_763[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_763[iVar1 /*5*/].f_2) {
					if (uParam0->f_763[iVar1 /*5*/].f_1) {
						interior::unpin_interior(uParam0->f_763[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_763[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 7) {
			if (!gameplay::is_string_null_or_empty(uParam0->f_687[iVar1 /*7*/].f_4)) {
				if (uParam0->f_687[iVar1 /*7*/]) {
					iVar2 = graphics::_0x9B6E70C5CEEF4EEB(uParam0->f_687[iVar1 /*7*/].f_5);
					if (!uParam0->f_687[iVar1 /*7*/].f_1) {
						switch (iVar2) {
						case 1:
						case 2: uParam0->f_687[iVar1 /*7*/].f_1 = 1; break;

						case 0:
							uParam0->f_687[iVar1 /*7*/].f_1 = 0;
							bVar0 = false;
							break;

						case 3:
							uParam0->f_687[iVar1 /*7*/].f_1 = 0;
							func_222(&uParam0->f_687[iVar1 /*7*/]);
							break;

						case -1:
							uParam0->f_687[iVar1 /*7*/].f_1 = 0;
							graphics::release_movie_mesh_set(uParam0->f_687[iVar1 /*7*/].f_5);
							uParam0->f_687[iVar1 /*7*/] = 0;
							bVar0 = false;
							break;
						}
					}
				}
				else if (interior::is_interior_ready(uParam0->f_687[iVar1 /*7*/].f_6)) {
					uParam0->f_687[iVar1 /*7*/].f_5 = graphics::load_movie_mesh_set(uParam0->f_687[iVar1 /*7*/].f_4);
					uParam0->f_687[iVar1 /*7*/].f_3 = gameplay::get_game_timer();
					uParam0->f_687[iVar1 /*7*/] = 1;
				}
				else {
					bVar0 = false;
				}
				if (uParam0->f_687[iVar1 /*7*/].f_2) {
					if (uParam0->f_687[iVar1 /*7*/]) {
						if (uParam0->f_687[iVar1 /*7*/].f_1) {
							graphics::release_movie_mesh_set(uParam0->f_687[iVar1 /*7*/].f_5);
							func_222(&uParam0->f_687[iVar1 /*7*/]);
							uParam0->f_687[iVar1 /*7*/].f_4 = "";
						}
						else {
							bVar0 = false;
						}
					}
					else {
						func_222(&uParam0->f_687[iVar1 /*7*/]);
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 10) {
			if (uParam0->f_879[iVar1 /*5*/]) {
				if (!uParam0->f_879[iVar1 /*5*/].f_1) {
					if (ai::assisted_movement_is_route_loaded(uParam0->f_879[iVar1 /*5*/].f_4)) {
						uParam0->f_879[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_879[iVar1 /*5*/].f_2) {
					if (uParam0->f_879[iVar1 /*5*/].f_1) {
						ai::assisted_movement_remove_route(uParam0->f_879[iVar1 /*5*/].f_4);
						func_222(&uParam0->f_879[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 5) {
			if (uParam0->f_930[iVar1 /*5*/]) {
				if (!uParam0->f_930[iVar1 /*5*/].f_1) {
					if (audio::prepare_alarm(uParam0->f_930[iVar1 /*5*/].f_4)) {
						uParam0->f_930[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_930[iVar1 /*5*/].f_2) {
					if (uParam0->f_930[iVar1 /*5*/].f_1) {
						func_222(&uParam0->f_930[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < uParam0->f_779) {
			if (uParam0->f_779[iVar1 /*5*/]) {
				if (!uParam0->f_779[iVar1 /*5*/].f_1) {
					if (ui::has_additional_text_loaded(iVar1)) {
						uParam0->f_779[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_779[iVar1 /*5*/].f_2) {
					if (uParam0->f_779[iVar1 /*5*/].f_1) {
						ui::clear_additional_text(iVar1, 1);
						func_222(&uParam0->f_779[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		if (uParam0->f_860) {
			if (!uParam0->f_860.f_1) {
				if (streaming::has_ptfx_asset_loaded()) {
					uParam0->f_860.f_1 = 1;
				}
				else {
					bVar0 = false;
				}
			}
			if (uParam0->f_860.f_2) {
				if (uParam0->f_860.f_1) {
					streaming::remove_ptfx_asset();
					func_222(&uParam0->f_860);
				}
				else {
					bVar0 = false;
				}
			}
		}
		if (uParam0->f_864) {
			if (!uParam0->f_864.f_1) {
				if (rope::rope_are_textures_loaded()) {
					uParam0->f_864.f_1 = 1;
				}
				else {
					bVar0 = false;
				}
			}
			if (uParam0->f_864.f_2) {
				if (uParam0->f_864.f_1) {
					rope::rope_unload_textures();
					func_222(&uParam0->f_864);
				}
				else {
					bVar0 = false;
				}
			}
		}
		if (uParam0->f_868 && streaming::is_new_load_scene_active()) {
			if (!uParam0->f_868.f_1) {
				if (streaming::is_new_load_scene_loaded()) {
					uParam0->f_868.f_1 = 1;
					if (uParam0->f_983) {
						entity::freeze_entity_position(player::player_ped_id(), 0);
						func_236(uParam0);
						uParam0->f_983 = 0;
					}
				}
				else {
					bVar0 = false;
				}
			}
			if (uParam0->f_868.f_2) {
				streaming::new_load_scene_stop();
				func_222(&uParam0->f_868);
			}
		}
		iVar1 = 0;
		while (iVar1 < 5) {
			if (uParam0->f_956[iVar1 /*5*/]) {
				if (!uParam0->f_956[iVar1 /*5*/].f_1) {
					if (graphics::has_streamed_texture_dict_loaded(uParam0->f_956[iVar1 /*5*/].f_4)) {
						uParam0->f_956[iVar1 /*5*/].f_1 = 1;
					}
					else {
						bVar0 = false;
					}
				}
				if (uParam0->f_956[iVar1 /*5*/].f_2) {
					if (uParam0->f_956[iVar1 /*5*/].f_1) {
						func_222(&uParam0->f_956[iVar1 /*5*/]);
					}
					else {
						bVar0 = false;
					}
				}
			}
			iVar1++;
		}
		if (bVar0) {
			uParam0->f_982 = 0;
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x1028D
void func_236(var *uParam0) {
	if (streaming::is_new_load_scene_active()) {
		streaming::new_load_scene_stop();
		func_222(&uParam0->f_868);
	}
}

// Position - 0x102A9
void func_237() {
	if (bLocal_98 && (func_238() || cam::is_screen_faded_out())) {
		func_8(1);
		script::terminate_this_thread();
	}
}

// Position - 0x102D2
int func_238() {
	if (Global_3) {
		return 1;
	}
	if (Global_91491 == 7 || Global_91491 == 8) {
		return 1;
	}
	return 0;
}

// Position - 0x102FF
void func_239() {
	vector3 vVar0;
	float *fVar3;

	func_246();
	ped::add_relationship_group("SECDRIVER", &iLocal_1305);
	ped::set_relationship_between_groups(1, iLocal_1305, -1533126372);
	ped::set_relationship_between_groups(1, iLocal_1305, -183807561);
	ped::set_relationship_between_groups(1, -1533126372, iLocal_1305);
	if (func_6(0) || func_194()) {
		iLocal_97 = 0;
		if (func_194()) {
			if (Global_86001) {
				iLocal_97++;
			}
		}
		StringCopy(&Global_88686, "jhp2a_alt", 64);
		if (func_194()) {
			func_233(iLocal_97, &vVar0, &fVar3);
			func_245(vVar0, fVar3, 1, 0);
		}
		iLocal_96 = 1;
	}
	else {
		while (!func_220(1)) {
			system::wait(0);
			func_244(&uLocal_99);
		}
	}
	func_243(&uLocal_99, "JHP2A", 0);
	player::set_wanted_level_multiplier(0.1f);
	player::set_all_random_peds_flee(player::player_id(), 1);
	func_241(88);
	func_225(&uLocal_1126, 0, player::player_ped_id(), "MICHAEL", 0, 1);
	func_225(&uLocal_1126, 3, 0, "Lester", 0, 1);
	vehicle::set_vehicle_model_is_suppressed(joaat("boxville3"), 1);
	ped::set_ped_model_is_suppressed(joaat("s_m_m_armoured_01"), 1);
	if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_briefcase"), 0)) {
		weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_briefcase"));
	}
	func_240();
	if (gameplay::is_string_null_or_empty(&Global_88686)) {
	}
	iLocal_1330 =
		ped::add_scenario_blocking_area(713.7754f, -996.4443f, 22.3085f, 715.7624f, -991.7067f, 25.6214f, 0, 1, 1, 1);
	while (!ui::has_additional_text_loaded(0)) {
		system::wait(0);
	}
	Global_68189 = 1;
}

// Position - 0x10473
void func_240() { Global_86002 = 1; }

// Position - 0x10480
void func_241(int iParam0) {
	Global_87679 = 0;
	switch (iParam0) {
	case 72:
		func_242(2);
		func_242(4);
		break;

	case 73:
		func_242(0);
		func_242(1);
		func_242(7);
		break;

	case 92:
		func_242(10);
		func_242(9);
		func_242(13);
		func_242(6);
		break;

	case 68: func_242(11); break;

	case 78: func_242(14); break;

	case 79: func_242(3); break;

	default: break;
	}
}

// Position - 0x1050E
void func_242(int iParam0) { gameplay::set_bit(&Global_87679, iParam0); }

// Position - 0x10520
int func_243(var *uParam0, char *sParam1, int iParam2) {
	if (uParam0->f_779[iParam2 /*5*/].f_1 || uParam0->f_779[iParam2 /*5*/]) {
		if (gameplay::are_strings_equal(uParam0->f_779[iParam2 /*5*/].f_4, sParam1)) {
			uParam0->f_779[iParam2 /*5*/].f_2 = 0;
			uParam0->f_982 = 1;
			return 1;
		}
		else {
			return 0;
		}
	}
	else {
		if (iParam2 >= 11) {
			ui::_request_additional_text_2(sParam1, iParam2);
		}
		else {
			ui::request_additional_text(sParam1, iParam2);
		}
		uParam0->f_779[iParam2 /*5*/] = 1;
		uParam0->f_779[iParam2 /*5*/].f_3 = gameplay::get_game_timer();
		uParam0->f_779[iParam2 /*5*/].f_4 = sParam1;
		uParam0->f_982 = 1;
		return 1;
	}
	return 0;
}

// Position - 0x105C4
void func_244(var *uParam0) { func_235(uParam0); }

// Position - 0x105D3
void func_245(vector3 vParam0, float *fParam3, int iParam4, int iParam5) {
	if (func_194()) {
		gameplay::set_this_script_can_be_paused(0);
		gameplay::clear_bit(&Global_91491.f_20, 2);
		gameplay::set_game_paused(1);
		if (player::is_player_playing(player::player_id())) {
			player::set_player_control(player::player_id(), 0, 0);
		}
		Global_91487 = {vParam0};
		Global_91490 = fParam3;
		Global_91486 = 1;
		if (iParam4 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 14);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 14);
		}
		if (iParam5 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 24);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 24);
		}
		func_193(1);
	}
}

// Position - 0x10668
void func_246() {
	func_254(&Local_1084[0 /*8*/], 68575 /*func_255*/, "Van Driver Manager");
	func_254(&Local_1084[1 /*8*/], 67222 /*func_247*/, "Cargo Manager");
}

// Position - 0x10696
void func_247(var *uParam0) {
	if (!func_121(uParam0)) {
		if (entity::is_entity_dead(Local_1318, 0)) {
			func_252(Local_1322[0 /*2*/], 1);
			func_252(Local_1322[1 /*2*/], 1);
			func_252(Local_1322[2 /*2*/], 1);
			iLocal_1346 = 1;
			func_251(uParam0);
		}
		else {
			switch (uParam0->f_1) {
			case 1:
				func_250(&uLocal_99, "JWL_HEIST_PREP_2A_SHOOTING_LOCK");
				if (audio::request_script_audio_bank("JWL_HEIST_PREP_2A_SHOOTING_LOCK", 0, -1)) {
					if (gameplay::get_game_timer() - iLocal_1336 > 150) {
						if (entity::has_entity_been_damaged_by_entity(iLocal_1329, player::player_ped_id(), 0)) {
							if (weapon::has_entity_been_damaged_by_weapon(iLocal_1329, joaat("weapon_molotov"), 0) ||
								weapon::has_entity_been_damaged_by_weapon(iLocal_1329, joaat("weapon_bzgas"), 0) ||
								weapon::has_entity_been_damaged_by_weapon(iLocal_1329, joaat("weapon_knife"), 0) ||
								weapon::has_entity_been_damaged_by_weapon(iLocal_1329, joaat("weapon_unarmed"), 0) ||
								weapon::has_entity_been_damaged_by_weapon(iLocal_1329,
																		  joaat("weapon_hit_by_water_cannon"), 0)) {
								weapon::clear_entity_last_weapon_damage(iLocal_1329);
							}
							else {
								entity::clear_entity_last_damage_entity(iLocal_1329);
								iLocal_1336 = gameplay::get_game_timer();
								iLocal_1335++;
								if (iLocal_1335 >= 3) {
									audio::play_sound_from_entity(-1, "Lock_Destroyed", iLocal_1329,
																  "JWL_PREP_2A_SOUNDS", 0, 0);
								}
								else {
									audio::play_sound_from_entity(-1, "Lock_Damage", iLocal_1329, "JWL_PREP_2A_SOUNDS",
																  0, 0);
								}
							}
						}
					}
					else {
						entity::clear_entity_last_damage_entity(iLocal_1329);
					}
				}
				if (iLocal_1335 >= 3 || entity::is_entity_dead(iLocal_1329, 0) ||
					vehicle::is_vehicle_door_damaged(Local_1318, 2) ||
					vehicle::is_vehicle_door_damaged(Local_1318, 3) ||
					vehicle::get_vehicle_door_angle_ratio(Local_1318, 2) > 0f ||
					vehicle::get_vehicle_door_angle_ratio(Local_1318, 3) > 0f) {
					if (entity::does_entity_exist(iLocal_1329)) {
						object::delete_object(&iLocal_1329);
					}
					if (!vehicle::is_vehicle_door_damaged(Local_1318, 2)) {
						vehicle::set_vehicle_door_open(Local_1318, 2, 0, 0);
					}
					if (!vehicle::is_vehicle_door_damaged(Local_1318, 3)) {
						vehicle::set_vehicle_door_open(Local_1318, 3, 0, 0);
					}
					iLocal_1347 = 0;
					iLocal_1348 = 0;
					func_252(Local_1322[0 /*2*/], 0);
					func_252(Local_1322[1 /*2*/], 0);
					func_252(Local_1322[2 /*2*/], 0);
					func_249(uParam0, 2, 0);
				}
				break;

			case 2:
				if (func_248(Local_1318)) {
					if (gameplay::absf(vehicle::get_vehicle_door_angle_ratio(Local_1318, 2)) > 0.5f &&
						gameplay::absf(vehicle::get_vehicle_door_angle_ratio(Local_1318, 3)) > 0.5f) {
						func_249(uParam0, 3, 0);
					}
				}
				break;

			case 3:
				if (func_248(Local_1318)) {
					if (!vehicle::is_vehicle_door_damaged(Local_1318, 2)) {
						if (vehicle::is_vehicle_door_fully_open(Local_1318, 2)) {
							vehicle::set_vehicle_door_open(Local_1318, 2, 1, 0);
							vehicle::set_vehicle_door_latched(Local_1318, 2, 0, 0, 1);
							iLocal_1347 = 1;
						}
					}
					else {
						iLocal_1347 = 1;
					}
					if (!vehicle::is_vehicle_door_damaged(Local_1318, 3)) {
						if (vehicle::is_vehicle_door_fully_open(Local_1318, 3)) {
							vehicle::set_vehicle_door_open(Local_1318, 3, 1, 0);
							vehicle::set_vehicle_door_latched(Local_1318, 3, 0, 0, 1);
							iLocal_1348 = 1;
						}
					}
					else {
						iLocal_1348 = 1;
					}
					if (iLocal_1347 && iLocal_1348) {
						iLocal_1346 = 1;
						func_249(uParam0, 4, 0);
					}
				}
				break;
			}
		}
	}
	if (func_121(uParam0)) {
	}
}

// Position - 0x10986
bool func_248(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x109A7
void func_249(var *uParam0, int iParam1, int iParam2) {
	if (iParam2 > 0) {
		*uParam0 = 2;
		uParam0->f_5 = gameplay::get_game_timer();
		uParam0->f_6 = iParam2;
	}
	uParam0->f_1 = iParam1;
}

// Position - 0x109CD
int func_250(var *uParam0, char *sParam1) {
	int iVar0;
	int iVar1;

	if (gameplay::is_string_null_or_empty(sParam1)) {
		return 0;
	}
	iVar1 = -1;
	iVar0 = 0;
	while (iVar0 < uParam0->f_737) {
		if (uParam0->f_737[iVar0 /*5*/]) {
			if (gameplay::are_strings_equal(uParam0->f_737[iVar0 /*5*/].f_4, sParam1)) {
				uParam0->f_737[iVar0 /*5*/].f_2 = 0;
				if (!uParam0->f_737[iVar0 /*5*/].f_1) {
					uParam0->f_982 = 1;
					return 1;
				}
				else {
					return 1;
				}
			}
		}
		else if (iVar1 == -1) {
			iVar1 = iVar0;
		}
		iVar0++;
	}
	if (iVar1 >= 0) {
		audio::request_script_audio_bank(sParam1, 0, -1);
		uParam0->f_737[iVar1 /*5*/] = 1;
		uParam0->f_737[iVar1 /*5*/].f_3 = gameplay::get_game_timer();
		uParam0->f_737[iVar1 /*5*/].f_4 = sParam1;
		uParam0->f_982 = 1;
		return 1;
	}
	return 0;
}

// Position - 0x10A97
void func_251(var *uParam0) {
	if (*uParam0 != 4) {
		*uParam0 = 4;
		uParam0->f_4 = gameplay::get_game_timer();
		uParam0->f_6 = 0;
		uParam0->f_1 = -1;
	}
}

// Position - 0x10ABC
void func_252(int iParam0, int iParam1) {
	vector3 vVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (entity::is_entity_attached(iParam0)) {
			entity::detach_entity(iParam0, 1, iParam1);
			entity::set_entity_collision(iParam0, 1, 0);
			rope::activate_physics(iParam0);
		}
		if (iParam1) {
			vVar0 = {func_253(entity::get_entity_coords(iParam0, 1) -
							  entity::get_offset_from_entity_in_world_coords(
								  Local_1318, gameplay::get_random_float_in_range(-0.15f, 0.15f),
								  IntToFloat(-gameplay::get_random_int_in_range(3, 6)),
								  gameplay::get_random_float_in_range(-0.1f, 0.1f)))};
			entity::apply_force_to_entity_center_of_mass(
				iParam0, 1, vVar0 * FtoV(gameplay::get_random_float_in_range(0.25f, 0.5f)), 0, 1, 1, 0);
			entity::apply_force_to_entity_center_of_mass(
				iParam0, 5, IntToFloat(gameplay::get_random_int_in_range(0, 10)),
				IntToFloat(gameplay::get_random_int_in_range(0, 10)),
				IntToFloat(gameplay::get_random_int_in_range(0, 10)), 0, 1, 1, 0);
			entity::set_entity_no_collision_entity(iParam0, Local_1318, 1);
		}
	}
}

// Position - 0x10B79
Vector3 func_253(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x10BB8
int func_254(var *uParam0, int iParam1, char *sParam2) {
	if (*uParam0 != -1) {
		return 0;
	}
	*uParam0 = 0;
	uParam0->f_3 = sParam2;
	uParam0->f_7 = iParam1;
	return 1;
}

// Position - 0x10BDF
void func_255(var *uParam0) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;
	int iVar7;
	float fVar8;

	if (!func_121(uParam0)) {
		if (!entity::does_entity_exist(vLocal_1306.x) || ped::is_ped_injured(vLocal_1306.x) ||
			entity::does_entity_exist(Local_1318) && func_186(Local_1318, vLocal_1306.x, 1) > 200f ||
			!ped::is_ped_in_any_vehicle(vLocal_1306.x, 0) && func_186(Local_1318, vLocal_1306.x, 1) > 200f) {
			if (entity::does_entity_exist(Local_1318) && vehicle::is_vehicle_driveable(Local_1318, 0)) {
				vehicle::_0x2B6747FAA9DB9D6B(Local_1318, 0);
			}
			entity::set_ped_as_no_longer_needed(&vLocal_1306);
			func_251(uParam0);
		}
		else {
			if (uParam0->f_1 != 5 && uParam0->f_1 != 3 &&
				(!entity::does_entity_exist(Local_1318) || !vehicle::is_vehicle_driveable(Local_1318, 0) ||
				 !ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 0))) {
				iLocal_1337 = 0;
				iLocal_1338 = 0;
				StringCopy(&cLocal_1339, "", 24);
				func_249(uParam0, 5, 0);
			}
			else if (uParam0->f_1 == 1 || uParam0->f_1 == 2 || uParam0->f_1 == 4) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
					if (entity::is_entity_touching_entity(iVar0, Local_1318)) {
						if (!iLocal_1332 && gameplay::get_game_timer() - iLocal_1334 > 500 && fLocal_1333 >= 4f) {
							iLocal_1332 = 1;
							iLocal_1331++;
						}
					}
					else if (iLocal_1332) {
						iLocal_1334 = gameplay::get_game_timer();
						iLocal_1332 = 0;
					}
					vVar1 = {func_253(entity::get_entity_coords(iVar0, 1) - entity::get_entity_coords(Local_1318, 1))};
					vVar4 = {entity::get_entity_velocity(Local_1318) - entity::get_entity_velocity(iVar0)};
					fLocal_1333 = func_259(vVar4, vVar1);
				}
			}
			switch (uParam0->f_1) {
			case 1:
				if (entity::has_entity_been_damaged_by_entity(Local_1318, player::player_ped_id(), 1) ||
					entity::has_entity_been_damaged_by_entity(vLocal_1306.x, player::player_ped_id(), 1) ||
					ped::has_ped_received_event(vLocal_1306.x, 122) ||
					ped::has_ped_received_event(vLocal_1306.x, 123) ||
					ped::has_ped_received_event(vLocal_1306.x, 124) || ped::has_ped_received_event(vLocal_1306.x, 29) ||
					ped::has_ped_received_event(vLocal_1306.x, 116) ||
					ped::has_ped_received_event(vLocal_1306.x, 121) || ped::has_ped_received_event(vLocal_1306.x, 22) ||
					ped::has_ped_received_event(vLocal_1306.x, 24) || ped::has_ped_received_event(vLocal_1306.x, 46) ||
					ped::has_ped_received_event(vLocal_1306.x, 61) || ped::has_ped_received_event(vLocal_1306.x, 61) ||
					ped::has_ped_received_event(vLocal_1306.x, 136) || ped::has_ped_received_event(vLocal_1306.x, 86) ||
					ped::has_ped_received_event(vLocal_1306.x, 87) || ped::is_ped_being_jacked(vLocal_1306.x) ||
					fire::is_entity_on_fire(Local_1318) || iLocal_1331 > 0) {
					iLocal_1337 = 0;
					iLocal_1338 = 0;
					StringCopy(&cLocal_1339, "", 24);
					func_249(uParam0, 4, 0);
				}
				else {
					if (entity::does_entity_exist(Local_1318) && vehicle::is_vehicle_driveable(Local_1318, 0)) {
						if (entity::is_entity_static(player::player_ped_id()) || fLocal_1333 > 0.5f)
							&&entity::is_entity_in_angled_area(
								player::player_ped_id(),
								entity::get_offset_from_entity_in_world_coords(Local_1318, 0f, 2f, -0.5f),
								entity::get_offset_from_entity_in_world_coords(Local_1318, 0f, 10f, 2f), 4.5f, 0, 1,
								0) {
								if (!audio::is_horn_active(Local_1318)) {
									if (iLocal_1350 == -1) {
										iLocal_1350 = gameplay::get_game_timer();
									}
									else if (gameplay::get_game_timer() - iLocal_1350 > 5000) {
										vehicle::start_vehicle_horn(Local_1318, 2000, 1330140418, 0);
									}
								}
								else {
									iLocal_1350 = -1;
								}
							}
					}
					if (func_258(Local_1318, -993.7236f, -2418.757f, 12.9447f, 1) < 20f) {
						func_228(&uLocal_99, "jhp2a_airport");
					}
					if (!func_257(vLocal_1306.x, -235832601, 1)) {
						if (entity::is_entity_in_angled_area(Local_1318, -990.6312f, -2413.214f, 12.69471f, -996.0194f,
															 -2422.608f, 16.05846f, 8.75f, 0, 1, 0)) {
							if (ai::get_is_waypoint_recording_loaded("jhp2a_airport")) {
								iLocal_1337 = 0;
								iLocal_1338 = 0;
								StringCopy(&cLocal_1339, "", 24);
								func_249(uParam0, 2, 0);
							}
						}
						else {
							ai::task_vehicle_follow_waypoint_recording(vLocal_1306.x, Local_1318, &Global_88686, 786475,
																	   -1, 24, -1, 12f, 0, 1073741824);
						}
					}
				}
				break;

			case 2:
				if (entity::has_entity_been_damaged_by_entity(Local_1318, player::player_ped_id(), 1) ||
					entity::has_entity_been_damaged_by_entity(vLocal_1306.x, player::player_ped_id(), 1) ||
					ped::has_ped_received_event(vLocal_1306.x, 122) ||
					ped::has_ped_received_event(vLocal_1306.x, 123) ||
					ped::has_ped_received_event(vLocal_1306.x, 124) || ped::has_ped_received_event(vLocal_1306.x, 29) ||
					ped::has_ped_received_event(vLocal_1306.x, 116) ||
					ped::has_ped_received_event(vLocal_1306.x, 121) || ped::has_ped_received_event(vLocal_1306.x, 22) ||
					ped::has_ped_received_event(vLocal_1306.x, 24) || ped::has_ped_received_event(vLocal_1306.x, 46) ||
					ped::has_ped_received_event(vLocal_1306.x, 61) || ped::has_ped_received_event(vLocal_1306.x, 61) ||
					ped::has_ped_received_event(vLocal_1306.x, 136) || ped::has_ped_received_event(vLocal_1306.x, 86) ||
					ped::has_ped_received_event(vLocal_1306.x, 87) || ped::is_ped_being_jacked(vLocal_1306.x) ||
					fire::is_entity_on_fire(Local_1318) || iLocal_1331 > 0) {
					iLocal_1337 = 0;
					iLocal_1338 = 0;
					StringCopy(&cLocal_1339, "", 24);
					func_249(uParam0, 5, 0);
				}
				else if (!func_257(vLocal_1306.x, -235832601, 1)) {
					if (entity::is_entity_in_angled_area(Local_1318, -1096.139f, -2467.117f, 12.69561f, -1101.641f,
														 -2476.775f, 15.6304f, 7.8125f, 0, 1, 0)) {
						iLocal_1337 = 0;
						iLocal_1338 = 0;
						StringCopy(&cLocal_1339, "", 24);
						func_249(uParam0, 3, 0);
					}
					else {
						ai::task_vehicle_follow_waypoint_recording(vLocal_1306.x, Local_1318, "jhp2a_airport", 786475,
																   -1, 24, -1, 12f, 0, 1073741824);
					}
				}
				break;

			case 3:
				if (entity::has_entity_been_damaged_by_entity(Local_1318, player::player_ped_id(), 1) ||
					entity::has_entity_been_damaged_by_entity(vLocal_1306.x, player::player_ped_id(), 1) ||
					ped::has_ped_received_event(vLocal_1306.x, 122) ||
					ped::has_ped_received_event(vLocal_1306.x, 123) ||
					ped::has_ped_received_event(vLocal_1306.x, 124) || ped::has_ped_received_event(vLocal_1306.x, 29) ||
					ped::has_ped_received_event(vLocal_1306.x, 116) ||
					ped::has_ped_received_event(vLocal_1306.x, 121) || ped::has_ped_received_event(vLocal_1306.x, 22) ||
					ped::has_ped_received_event(vLocal_1306.x, 24) || ped::has_ped_received_event(vLocal_1306.x, 46) ||
					ped::has_ped_received_event(vLocal_1306.x, 61) || ped::has_ped_received_event(vLocal_1306.x, 61) ||
					ped::has_ped_received_event(vLocal_1306.x, 136) || ped::has_ped_received_event(vLocal_1306.x, 86) ||
					ped::has_ped_received_event(vLocal_1306.x, 87) || ped::is_ped_being_jacked(vLocal_1306.x) ||
					fire::is_entity_on_fire(Local_1318) ||
					ped::is_ped_in_vehicle(player::player_ped_id(), Local_1318, 1) || iLocal_1331 > 0) {
					iLocal_1337 = 0;
					iLocal_1338 = 0;
					StringCopy(&cLocal_1339, "", 24);
					func_249(uParam0, 5, 0);
				}
				else if (ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 1)) {
					if (!func_257(vLocal_1306.x, 451360105, 1)) {
						ai::task_leave_vehicle(vLocal_1306.x, Local_1318, 0);
					}
				}
				else {
					vehicle::set_vehicle_doors_locked(Local_1318, 2);
					if (!func_257(vLocal_1306.x, 242628503, 1)) {
						ai::open_sequence_task(&iLocal_1304);
						ai::task_follow_nav_mesh_to_coord(0, -1093.486f, -2471.669f, 13.0716f, 1f, -1, 1048576000, 0,
														  1193033728);
						ai::task_start_scenario_in_place(0, "WORLD_HUMAN_SMOKING", -1, 1);
						ai::close_sequence_task(iLocal_1304);
						ai::task_perform_sequence(vLocal_1306.x, iLocal_1304);
						ai::clear_sequence_task(&iLocal_1304);
					}
				}
				break;

			case 4:
				if (vehicle::is_vehicle_tyre_burst(Local_1318, 0, 1)) {
					iVar7++;
				}
				if (vehicle::is_vehicle_tyre_burst(Local_1318, 1, 1)) {
					iVar7++;
				}
				if (vehicle::is_vehicle_tyre_burst(Local_1318, 4, 1)) {
					iVar7++;
				}
				if (vehicle::is_vehicle_tyre_burst(Local_1318, 5, 1)) {
					iVar7++;
				}
				if (IntToFloat(entity::get_entity_health(Local_1318)) <= 0f ||
					vehicle::get_vehicle_engine_health(Local_1318) <= 250f ||
					vehicle::get_vehicle_petrol_tank_health(Local_1318) <= 400f || ped::is_ped_injured(vLocal_1306.x) ||
					iVar7 >= 2 || iLocal_1331 > 6) {
					if (entity::does_entity_exist(Local_1318) && vehicle::is_vehicle_driveable(Local_1318, 0)) {
						vehicle::_0x2B6747FAA9DB9D6B(Local_1318, 0);
					}
					iLocal_1337 = 0;
					iLocal_1338 = 0;
					StringCopy(&cLocal_1339, "", 24);
					func_249(uParam0, 5, 0);
				}
				else if (!func_257(vLocal_1306.x, -1273030092, 1)) {
					ai::task_vehicle_mission_ped_target(vLocal_1306.x, Local_1318, player::player_ped_id(), 8, 90f,
														786468, 400f, 10f, 0);
				}
				break;

			case 5:
				if (entity::does_entity_exist(Local_1318) && !entity::is_entity_dead(Local_1318, 0)) {
					if (ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 0)) {
						if (!func_80(Local_1318)) {
							if (!func_257(vLocal_1306.x, -2118855366, 1)) {
								ai::clear_ped_tasks(vLocal_1306.x);
								ai::task_vehicle_temp_action(vLocal_1306.x, Local_1318, 5, -1);
							}
						}
						else if (!func_257(vLocal_1306.x, 451360105, 1)) {
							ai::task_leave_vehicle(vLocal_1306.x, Local_1318, 256);
						}
					}
					else if (!func_257(vLocal_1306.x, 780511057, 1)) {
						ped::set_ped_can_be_targetted(vLocal_1306.x, 1);
						ai::task_combat_ped(vLocal_1306.x, player::player_ped_id(), 0, 16);
					}
				}
				if (entity::does_entity_exist(Local_1318) && !entity::is_entity_dead(Local_1318, 0)) {
					vehicle::_set_vehicle_door_can_break(Local_1318, 2, 1);
					vehicle::_set_vehicle_door_can_break(Local_1318, 3, 1);
				}
				break;
			}
		}
		if (entity::does_entity_exist(vLocal_1306.x) && !ped::is_ped_injured(vLocal_1306.x) &&
			!ped::is_conversation_ped_dead(vLocal_1306.x)) {
			switch (uParam0->f_1) {
			case 4:
				switch (iLocal_1337) {
				case 0:
					if (func_35() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						if (ped::is_ped_being_jacked(vLocal_1306.x)) {
							func_55(vLocal_1306.x, "JACKED_GENERIC", 10);
						}
						else {
							func_55(vLocal_1306.x, "GENERIC_SHOCKED_HIGH", 10);
						}
						iLocal_1337++;
					}
					break;

				case 1:
					if (!ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 0) || iLocal_1303 == 3) {
						if (!ped::is_ped_in_vehicle(vLocal_1306.x, Local_1318, 0)) {
							iLocal_1337 = 4;
						}
						else {
							iLocal_1337++;
						}
					}
					else if (func_35() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						if (func_256(&uLocal_1126, &cLocal_79, "JS_INIT_M", 8, 0, 0, 0)) {
							iLocal_1337++;
						}
					}
					break;

				case 2:
					if (func_35() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						if (gameplay::is_string_null_or_empty(&cLocal_1339)) {
							fVar8 = system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
												   entity::get_entity_coords(vLocal_1306.x, 1));
							if ((iLocal_1332 || ped::has_ped_received_event(vLocal_1306.x, 122) ||
								 ped::has_ped_received_event(vLocal_1306.x, 123) ||
								 ped::has_ped_received_event(vLocal_1306.x, 124) || fVar8 < 49f) &&
								gameplay::get_game_timer() - iLocal_1338 > 5000 && fVar8 < 225f) {
								if (gameplay::get_random_int_in_range(0, 2) == 0) {
									StringCopy(&cLocal_1339, "GENERIC_CURSE_HIGH", 24);
								}
								else {
									StringCopy(&cLocal_1339, "JS_ATT_M", 24);
								}
							}
						}
						if (!gameplay::is_string_null_or_empty(&cLocal_1339)) {
							if (gameplay::are_strings_equal(&cLocal_1339, "GENERIC_CURSE_HIGH")) {
								func_55(vLocal_1306.x, "GENERIC_CURSE_HIGH", 10);
								iLocal_1337++;
							}
							else {
								if (func_256(&uLocal_1126, &cLocal_79, &cLocal_1339, 8, 0, 0, 0)) {
									iLocal_1337++;
								}
								iLocal_1337++;
							}
						}
					}
					break;

				case 3:
					if (!func_36() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						iLocal_1338 = gameplay::get_game_timer();
						StringCopy(&cLocal_1339, "", 24);
						iLocal_1337--;
					}
					break;
				}
				break;

			case 5:
				switch (iLocal_1337) {
				case 0:
					if (func_35() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						if (gameplay::is_string_null_or_empty(&cLocal_1339)) {
							if (gameplay::get_game_timer() - iLocal_1338 > 5000 &&
								system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
											   entity::get_entity_coords(vLocal_1306.x, 1)) < 400f) {
								if (gameplay::get_random_int_in_range(0, 2) == 0) {
									StringCopy(&cLocal_1339, "GENERIC_INSULT_HIGH", 24);
								}
								else {
									StringCopy(&cLocal_1339, "JS_COMB_M", 24);
								}
							}
						}
						if (!gameplay::is_string_null_or_empty(&cLocal_1339)) {
							if (gameplay::are_strings_equal(&cLocal_1339, "GENERIC_INSULT_HIGH")) {
								func_55(vLocal_1306.x, "GENERIC_INSULT_HIGH", 10);
								iLocal_1337++;
							}
							else if (func_256(&uLocal_1126, &cLocal_79, &cLocal_1339, 8, 0, 0, 0)) {
								iLocal_1337++;
							}
						}
					}
					break;

				case 1:
					if (!func_36() && !audio::is_ambient_speech_playing(vLocal_1306.x)) {
						iLocal_1338 = gameplay::get_game_timer();
						StringCopy(&cLocal_1339, "", 24);
						iLocal_1337--;
					}
					break;
				}
				break;
			}
		}
	}
	if (func_121(uParam0)) {
	}
}

// Position - 0x1190D
bool func_256(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_34(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_25(sParam2, iParam3, 0);
}

// Position - 0x1195B
int func_257(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = ai::get_script_task_status(iParam0, iParam1);
	if (iVar0 == 1 || iVar0 == 0) {
		return 1;
	}
	else if (!iParam2) {
		if (iVar0 == 2 || iVar0 == 3) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x119A1
float func_258(int iParam0, vector3 vParam1, int iParam4) {
	vector3 vVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vParam1, iParam4);
}

// Position - 0x119DB
float func_259(vector3 vParam0, vector3 vParam3) {
	return vParam0.x * vParam3.x + vParam0.y * vParam3.y + vParam0.z * vParam3.z;
}

// Position - 0x119FC
void func_260(int iParam0) {
	struct<2> Var0;
	char[] cVar4[8];

	audio::trigger_music_event("JHP2A_FAIL");
	if (iParam0 == 5) {
		func_272();
		func_8(0);
		script::terminate_this_thread();
	}
	else if (!bLocal_98) {
		switch (iParam0) {
		case 1: StringCopy(&Var0, "JHP2A_FGOTAWAY", 16); break;

		case 2: StringCopy(&Var0, "JHP2A_FGOTAWAY2", 16); break;

		case 4: StringCopy(&Var0, "JHP2A_FCARGO", 16); break;

		case 3: StringCopy(&Var0, "JHP2A_FCARGO2", 16); break;

		case 0:
		default: StringCopy(&Var0, "JHP2A_FF", 16); break;
		}
		if (gameplay::is_string_null_or_empty(&cVar4)) {
			func_270(&Var0);
		}
		else {
			func_261(&Var0, &cVar4);
		}
		bLocal_98 = true;
	}
}

// Position - 0x11AA2
void func_261(char *sParam0, char *sParam1) {
	func_269(sParam0, sParam1);
	func_262(0);
}

// Position - 0x11AB7
void func_262(int iParam0) {
	int iVar0;

	if (Global_101700.f_8044 || func_6(0)) {
		iVar0 = func_4();
		if (!func_263(iVar0)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
		Global_91527 = iParam0;
	}
}

// Position - 0x11AFC
int func_263(int iParam0) {
	int iVar0;
	int iVar1;

	func_268();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_267(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_264(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0x11C13
void func_264(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_266(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_265(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0x11DDC
void func_265(int *iParam0) { *iParam0 = -15; }

// Position - 0x11DEA
int func_266(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_266(8, uParam1, fParam2);

	case 10: return func_266(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0x12759
void func_267(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x12797
void func_268() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_176()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_176()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x12884
void func_269(char *sParam0, char *sParam1) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (ui::get_length_of_literal_string(sParam0) <= 16) {
			if (ui::get_length_of_literal_string(sParam1) <= 16) {
				StringCopy(&Global_69934, sParam0, 16);
				StringCopy(&Global_69938, sParam1, 16);
			}
		}
	}
}

// Position - 0x128C2
void func_270(char *sParam0) {
	func_271(sParam0);
	func_262(0);
}

// Position - 0x128D5
void func_271(char *sParam0) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (ui::get_length_of_literal_string(sParam0) <= 16) {
			StringCopy(&Global_69934, sParam0, 16);
			StringCopy(&Global_69938, "", 16);
			if (unk1::_is_recording()) {
				unk1::_stop_recording_and_save_clip();
			}
		}
	}
}

// Position - 0x12914
void func_272() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_6(0)) {
		if (!func_273()) {
			iVar0 = func_4();
			if (iVar0 != -1) {
				if (!func_263(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_268();
		}
	}
}

// Position - 0x12985
int func_273() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

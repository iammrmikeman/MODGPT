#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
vector3 vLocal_45 = {0f, 0f, 0f};
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 1132396544;
var uLocal_51 = 1132396544;
var uLocal_52 = 1132396544;
var uLocal_53 = 0;
var uLocal_54 = -1082130432;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 8;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = -1;
var uLocal_115 = 1092616192;
var uLocal_116 = 0;
var uLocal_117 = 0;
bool bLocal_118 = 0;
int iLocal_119 = 0;
int iLocal_120 = 0;
int iLocal_121 = 0;
struct<7> Local_122 = {
	0, 0, 1097859072, 1500, 45, 1103626240, 5
};
struct<4> Local_129 = {
	0, 0, 0, 0
};
int *iLocal_133 = NULL;
float fLocal_134 = 0f;
float fLocal_135 = 0f;
float fLocal_136 = 0f;
bool bLocal_137 = 0;
bool bLocal_138 = 0;
int iLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
int iLocal_143 = 0;
var uLocal_144 = 0;
int iLocal_145 = 0;
int iLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var *uLocal_150 = NULL;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 3;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 1;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 2;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 13;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 13;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 0;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 0;
var uLocal_430 = 13;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 0;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var uLocal_524 = 0;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 13;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 13;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 13;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 13;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
struct<61> Local_726 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_787 = 0;
var uLocal_788 = 0;
var uLocal_789 = 0;
var uLocal_790 = 0;
var uLocal_791 = 0;
var uLocal_792 = 0;
var uLocal_793 = 0;
var uLocal_794 = 0;
var uLocal_795 = 0;
var uLocal_796 = 0;
var uLocal_797 = 16;
var uLocal_798 = 0;
var uLocal_799 = 0;
var uLocal_800 = 0;
var uLocal_801 = 0;
var uLocal_802 = 0;
var uLocal_803 = 0;
var uLocal_804 = 0;
var uLocal_805 = 0;
var uLocal_806 = 0;
var uLocal_807 = 0;
var uLocal_808 = 0;
var uLocal_809 = 0;
var uLocal_810 = 0;
var uLocal_811 = 0;
var uLocal_812 = 0;
var uLocal_813 = 0;
var uLocal_814 = 0;
var uLocal_815 = 0;
var uLocal_816 = 0;
var uLocal_817 = 0;
var uLocal_818 = 0;
var uLocal_819 = 0;
var uLocal_820 = 0;
var uLocal_821 = 0;
var uLocal_822 = 0;
var uLocal_823 = 0;
var uLocal_824 = 0;
var uLocal_825 = 0;
var uLocal_826 = 0;
var uLocal_827 = 0;
var uLocal_828 = 0;
var uLocal_829 = 0;
var uLocal_830 = 0;
var uLocal_831 = 0;
var uLocal_832 = 0;
var uLocal_833 = 0;
var uLocal_834 = 0;
var uLocal_835 = 0;
var uLocal_836 = 0;
var uLocal_837 = 0;
var uLocal_838 = 0;
var uLocal_839 = 0;
var uLocal_840 = 0;
var uLocal_841 = 0;
var uLocal_842 = 0;
var uLocal_843 = 0;
var uLocal_844 = 0;
var uLocal_845 = 0;
var uLocal_846 = 0;
var uLocal_847 = 0;
var uLocal_848 = 0;
var uLocal_849 = 0;
var uLocal_850 = 0;
var uLocal_851 = 0;
var uLocal_852 = 0;
var uLocal_853 = 0;
var uLocal_854 = 0;
var uLocal_855 = 0;
var uLocal_856 = 0;
var uLocal_857 = 0;
var uLocal_858 = 0;
var uLocal_859 = 0;
var uLocal_860 = 0;
var uLocal_861 = 0;
var uLocal_862 = 0;
var uLocal_863 = 0;
var uLocal_864 = 0;
var uLocal_865 = 0;
var uLocal_866 = 0;
var uLocal_867 = 0;
var uLocal_868 = 0;
var uLocal_869 = 0;
var uLocal_870 = 0;
var uLocal_871 = 0;
var uLocal_872 = 0;
var uLocal_873 = 0;
var uLocal_874 = 0;
var uLocal_875 = 0;
var uLocal_876 = 0;
var uLocal_877 = 0;
var uLocal_878 = 0;
var uLocal_879 = 0;
var uLocal_880 = 0;
var uLocal_881 = 0;
var uLocal_882 = 0;
var uLocal_883 = 0;
var uLocal_884 = 0;
var uLocal_885 = 0;
var uLocal_886 = 0;
var uLocal_887 = 0;
var uLocal_888 = 0;
var uLocal_889 = 0;
var uLocal_890 = 0;
var uLocal_891 = 0;
var uLocal_892 = 0;
var uLocal_893 = 0;
var uLocal_894 = 0;
var uLocal_895 = 0;
var uLocal_896 = 0;
var uLocal_897 = 0;
var uLocal_898 = 0;
var uLocal_899 = 0;
var uLocal_900 = 0;
var uLocal_901 = 0;
var uLocal_902 = 0;
var uLocal_903 = 0;
var uLocal_904 = 0;
var uLocal_905 = 0;
var uLocal_906 = 0;
var uLocal_907 = 0;
var uLocal_908 = 0;
var uLocal_909 = 0;
var uLocal_910 = 0;
var uLocal_911 = 0;
var uLocal_912 = 0;
var uLocal_913 = 0;
var uLocal_914 = 0;
var uLocal_915 = 0;
var uLocal_916 = 0;
var uLocal_917 = 0;
var uLocal_918 = 0;
var uLocal_919 = 0;
var uLocal_920 = 0;
var uLocal_921 = 0;
var uLocal_922 = 0;
var uLocal_923 = 0;
var uLocal_924 = 0;
var uLocal_925 = 0;
var uLocal_926 = 0;
var uLocal_927 = 0;
var uLocal_928 = 0;
var uLocal_929 = 0;
var uLocal_930 = 0;
var uLocal_931 = 0;
var uLocal_932 = 0;
var uLocal_933 = 0;
var uLocal_934 = 0;
var uLocal_935 = 0;
var uLocal_936 = 0;
var uLocal_937 = 0;
var uLocal_938 = 0;
var uLocal_939 = 0;
var uLocal_940 = 0;
var uLocal_941 = 0;
var uLocal_942 = 0;
var uLocal_943 = 0;
var uLocal_944 = 0;
var uLocal_945 = 0;
var uLocal_946 = 0;
var uLocal_947 = 0;
var uLocal_948 = 0;
var uLocal_949 = 0;
var uLocal_950 = 0;
var uLocal_951 = 0;
var uLocal_952 = 0;
var uLocal_953 = 0;
var uLocal_954 = 0;
var uLocal_955 = 0;
var uLocal_956 = 0;
var uLocal_957 = 0;
var uLocal_958 = 0;
var uLocal_959 = 0;
var uLocal_960 = 0;
var uLocal_961 = 0;
var uLocal_962 = 0;
var uLocal_963 = 0;
var uLocal_964 = 0;
var uLocal_965 = 0;
var uLocal_966 = 0;
var uLocal_967 = 0;
var uLocal_968 = 0;
var uLocal_969 = 0;
var uLocal_970 = 0;
var uLocal_971 = 0;
var uLocal_972 = 0;
var uLocal_973 = 0;
var uLocal_974 = 0;
var uLocal_975 = 0;
var uLocal_976 = 0;
var uLocal_977 = 0;
var uLocal_978 = 0;
var uLocal_979 = 0;
var uLocal_980 = 0;
var uLocal_981 = 12;
var uLocal_982 = 0;
var uLocal_983 = 0;
var uLocal_984 = 0;
var uLocal_985 = 0;
var uLocal_986 = 0;
var uLocal_987 = 0;
var uLocal_988 = 0;
var uLocal_989 = 0;
var uLocal_990 = 0;
var uLocal_991 = 0;
var uLocal_992 = 0;
var uLocal_993 = 0;
var uLocal_994 = 0;
var uLocal_995 = 0;
var uLocal_996 = 0;
var uLocal_997 = 0;
var uLocal_998 = 0;
var uLocal_999 = 0;
var uLocal_1000 = 0;
var uLocal_1001 = 0;
var uLocal_1002 = 0;
var uLocal_1003 = 0;
var uLocal_1004 = 0;
var uLocal_1005 = 0;
var uLocal_1006 = 0;
var uLocal_1007 = 0;
var uLocal_1008 = 0;
var uLocal_1009 = 0;
var uLocal_1010 = 0;
var uLocal_1011 = 0;
var uLocal_1012 = 0;
var uLocal_1013 = 0;
var uLocal_1014 = 0;
var uLocal_1015 = 0;
var uLocal_1016 = 0;
var uLocal_1017 = 0;
char cLocal_1018[32] = "";
var uLocal_1022 = 0;
var uLocal_1023 = 0;
var uLocal_1024 = 0;
var uLocal_1025 = 0;
int iLocal_1026 = 0;
int iLocal_1027 = 0;
int iLocal_1028 = 0;
int iLocal_1029 = 0;
int iLocal_1030 = 0;
bool bLocal_1031 = 0;
int iLocal_1032 = 0;
var uLocal_1033 = 0;
var *uLocal_1034 = NULL;
var uLocal_1035 = 0;
var uLocal_1036 = 0;
int *iLocal_1037 = NULL;
var uLocal_1038 = 0;
var uLocal_1039 = 0;
int iLocal_1040 = 0;
int iLocal_1041 = 0;
int iLocal_1042 = 0;
int iLocal_1043 = 0;
struct<183> Local_1044 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_1227 = 0;
var uLocal_1228 = 0;
var uLocal_1229 = 0;
var uLocal_1230 = 0;
struct<39> Local_1231 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_1270 = 0;
var uLocal_1271 = 16;
var uLocal_1272 = 0;
var uLocal_1273 = 0;
var uLocal_1274 = 0;
var uLocal_1275 = 0;
var uLocal_1276 = 0;
var uLocal_1277 = 0;
var uLocal_1278 = 0;
var uLocal_1279 = 0;
var uLocal_1280 = 0;
var uLocal_1281 = 0;
var uLocal_1282 = 0;
var uLocal_1283 = 0;
var uLocal_1284 = 0;
var uLocal_1285 = 0;
var uLocal_1286 = 0;
var uLocal_1287 = 0;
var uLocal_1288 = 0;
var uLocal_1289 = 0;
var uLocal_1290 = 0;
var uLocal_1291 = 0;
var uLocal_1292 = 0;
var uLocal_1293 = 0;
var uLocal_1294 = 0;
var uLocal_1295 = 0;
var uLocal_1296 = 0;
var uLocal_1297 = 0;
var uLocal_1298 = 0;
var uLocal_1299 = 0;
var uLocal_1300 = 0;
var uLocal_1301 = 0;
var uLocal_1302 = 0;
var uLocal_1303 = 0;
var uLocal_1304 = 0;
var uLocal_1305 = 0;
var uLocal_1306 = 0;
var uLocal_1307 = 0;
var uLocal_1308 = 0;
var uLocal_1309 = 0;
var uLocal_1310 = 0;
var uLocal_1311 = 0;
var uLocal_1312 = 0;
var uLocal_1313 = 0;
var uLocal_1314 = 0;
var uLocal_1315 = 0;
var uLocal_1316 = 0;
var uLocal_1317 = 0;
var uLocal_1318 = 0;
var uLocal_1319 = 0;
var uLocal_1320 = 0;
var uLocal_1321 = 0;
var uLocal_1322 = 0;
var uLocal_1323 = 0;
var uLocal_1324 = 0;
var uLocal_1325 = 0;
var uLocal_1326 = 0;
var uLocal_1327 = 0;
var uLocal_1328 = 0;
var uLocal_1329 = 0;
var uLocal_1330 = 0;
var uLocal_1331 = 0;
var uLocal_1332 = 0;
var uLocal_1333 = 0;
var uLocal_1334 = 0;
var uLocal_1335 = 0;
var uLocal_1336 = 0;
var uLocal_1337 = 0;
var uLocal_1338 = 0;
var uLocal_1339 = 0;
var uLocal_1340 = 0;
var uLocal_1341 = 0;
var uLocal_1342 = 0;
var uLocal_1343 = 0;
var uLocal_1344 = 0;
var uLocal_1345 = 0;
var uLocal_1346 = 0;
var uLocal_1347 = 0;
var uLocal_1348 = 0;
var uLocal_1349 = 0;
var uLocal_1350 = 0;
var uLocal_1351 = 0;
var uLocal_1352 = 0;
var uLocal_1353 = 0;
var uLocal_1354 = 0;
var uLocal_1355 = 0;
var uLocal_1356 = 0;
var uLocal_1357 = 0;
var uLocal_1358 = 0;
var uLocal_1359 = 0;
var uLocal_1360 = 0;
var uLocal_1361 = 0;
var uLocal_1362 = 0;
var uLocal_1363 = 0;
var uLocal_1364 = 0;
var uLocal_1365 = 0;
var uLocal_1366 = 0;
var uLocal_1367 = 0;
var uLocal_1368 = 0;
var uLocal_1369 = 0;
var uLocal_1370 = 0;
var uLocal_1371 = 0;
var uLocal_1372 = 0;
var uLocal_1373 = 0;
var uLocal_1374 = 0;
var uLocal_1375 = 0;
var uLocal_1376 = 0;
var uLocal_1377 = 0;
var uLocal_1378 = 0;
var uLocal_1379 = 0;
var uLocal_1380 = 0;
var uLocal_1381 = 0;
var uLocal_1382 = 0;
var uLocal_1383 = 0;
var uLocal_1384 = 0;
var uLocal_1385 = 0;
var uLocal_1386 = 0;
var uLocal_1387 = 0;
var uLocal_1388 = 0;
var uLocal_1389 = 0;
var uLocal_1390 = 0;
var uLocal_1391 = 0;
var uLocal_1392 = 0;
var uLocal_1393 = 0;
var uLocal_1394 = 0;
var uLocal_1395 = 0;
var uLocal_1396 = 0;
var uLocal_1397 = 0;
var uLocal_1398 = 0;
var uLocal_1399 = 0;
var uLocal_1400 = 0;
var uLocal_1401 = 0;
var uLocal_1402 = 0;
var uLocal_1403 = 0;
var uLocal_1404 = 0;
var uLocal_1405 = 0;
var uLocal_1406 = 0;
var uLocal_1407 = 0;
var uLocal_1408 = 0;
var uLocal_1409 = 0;
var uLocal_1410 = 0;
var uLocal_1411 = 0;
var uLocal_1412 = 0;
var uLocal_1413 = 0;
var uLocal_1414 = 0;
var uLocal_1415 = 0;
var uLocal_1416 = 0;
var uLocal_1417 = 0;
var uLocal_1418 = 0;
var uLocal_1419 = 0;
var uLocal_1420 = 0;
var uLocal_1421 = 0;
var uLocal_1422 = 0;
var uLocal_1423 = 0;
var uLocal_1424 = 0;
var uLocal_1425 = 0;
var uLocal_1426 = 0;
var uLocal_1427 = 0;
var uLocal_1428 = 0;
var uLocal_1429 = 0;
var uLocal_1430 = 0;
var uLocal_1431 = 0;
var uLocal_1432 = 0;
var uLocal_1433 = 0;
var uLocal_1434 = 0;
var uLocal_1435 = 0;
var uLocal_1436 = 0;
var uLocal_1437 = 0;
var uLocal_1438 = 0;
var uLocal_1439 = 0;
var uLocal_1440 = 0;
var uLocal_1441 = 0;
int iLocal_1442 = 0;
int iLocal_1443 = 0;
float fLocal_1444 = 0f;
var uLocal_1445 = 0;
var uLocal_1446 = 0;
var uLocal_1447 = 0;
var uLocal_1448 = 0;
var uLocal_1449 = 0;
var uLocal_1450 = 0;
var uLocal_1451 = 0;
var uLocal_1452 = 0;
var uLocal_1453 = 0;
var uLocal_1454 = 0;
var uLocal_1455 = 21;
var uLocal_1456 = 6;
var uLocal_1457 = 0;
var uLocal_1458 = 0;
var uLocal_1459 = 0;
int iLocal_1460 = 0;
int iLocal_1461 = 0;
int iLocal_1462 = 0;
int iLocal_1463 = 0;
int iLocal_1464 = 0;
int iLocal_1465 = 0;
int iLocal_1466 = 0;
int iLocal_1467 = 0;
vector3 vLocal_1468 = {0f, 0f, 0f};
vector3 vLocal_1471 = {0f, 0f, 0f};
float fLocal_1474 = 0f;
float fLocal_1475 = 0f;
var uLocal_1476 = 0;
var uLocal_1477 = 0;
vector3 vLocal_1478 = {0f, 0f, 0f};
vector3 vLocal_1481 = {0f, 0f, 0f};
vector3 vLocal_1484 = {0f, 0f, 0f};
vector3 vLocal_1487 = {0f, 0f, 0f};
var *uLocal_1490 = NULL;
var uLocal_1491 = 0;
var uLocal_1492 = 0;
var *uLocal_1493 = NULL;
var uLocal_1494 = 0;
var uLocal_1495 = 0;
bool bLocal_1496 = 0;
int iLocal_1497 = 0;
vector3 vLocal_1498 = {0f, 0f, 0f};
vector3 vLocal_1501 = {0f, 0f, 0f};
int iLocal_1504 = 0;
int iLocal_1505 = 0;
int *iLocal_1506 = NULL;
var uLocal_1507 = 0;
var uLocal_1508 = 0;
int *iLocal_1509 = NULL;
int *iLocal_1510 = NULL;
int iLocal_1511 = 0;
bool bLocal_1512 = 0;
bool bLocal_1513 = 0;
int iLocal_1514 = 0;
int iLocal_1515 = 0;
int iLocal_1516 = 0;
int iLocal_1517 = 0;
int iLocal_1518 = 0;
int iLocal_1519 = 0;
int iLocal_1520 = 0;
int iLocal_1521 = 0;
bool bLocal_1522 = 0;
int *iLocal_1523 = NULL;
bool bLocal_1524 = 0;
int iLocal_1525 = 0;
int iLocal_1526 = 0;
var uLocal_1527 = 0;
int iLocal_1528 = 0;
int iLocal_1529 = 0;
bool bLocal_1530 = 0;
int iLocal_1531 = 0;
int iLocal_1532 = 0;
int iLocal_1533 = 0;
bool bLocal_1534 = 0;
int iLocal_1535 = 0;
int iLocal_1536 = 0;
int iLocal_1537 = 0;
int iLocal_1538 = 0;
int iLocal_1539 = 0;
int iLocal_1540 = 0;
int iLocal_1541 = 0;
int iLocal_1542 = 0;
int iLocal_1543 = 0;
int iLocal_1544 = 0;
int iLocal_1545 = 0;
int iLocal_1546 = 0;
int iLocal_1547 = 0;
int iLocal_1548 = 0;
int iLocal_1549 = 0;
int iLocal_1550 = 0;
int iLocal_1551 = 0;
int iLocal_1552 = 0;
int *iLocal_1553 = NULL;
int iLocal_1554 = 0;
int iLocal_1555 = 0;
float fLocal_1556 = 0f;
float fLocal_1557 = 0f;
float fLocal_1558 = 0f;
float fLocal_1559 = 0f;
var uLocal_1560 = 0;
var uLocal_1561 = 0;
vector3 vLocal_1562 = {0f, 0f, 0f};
vector3 vLocal_1565 = {0f, 0f, 0f};
float fLocal_1568 = 0f;
vector3 vLocal_1569 = {0f, 0f, 0f};
float fLocal_1572 = 0f;
int iLocal_1573 = 0;
int iLocal_1574 = 0;
int iLocal_1575 = 0;
int iLocal_1576 = 0;
var uLocal_1577[4] = {0, 0, 0, 0};
int iLocal_1582 = 0;
int iLocal_1583 = 0;
int iLocal_1584[3] = {0, 0, 0};
int iLocal_1588 = 0;
var *uLocal_1589 = NULL;
var uLocal_1590 = 0;
var uLocal_1591 = 0;
var *uLocal_1592 = NULL;
var uLocal_1593 = 0;
var uLocal_1594 = 0;
var *uLocal_1595 = NULL;
var uLocal_1596 = 0;
var uLocal_1597 = 0;
int *iLocal_1598 = NULL;
var uLocal_1599 = 0;
var uLocal_1600 = 0;
var *uLocal_1601 = NULL;
var uLocal_1602 = 0;
var uLocal_1603 = 0;
var *uLocal_1604 = NULL;
var uLocal_1605 = 0;
var uLocal_1606 = 0;
int *iLocal_1607 = NULL;
var uLocal_1608 = 0;
var uLocal_1609 = 0;
var uLocal_1610 = 0;
var uLocal_1611 = 0;
var uLocal_1612 = 0;
vector3 vLocal_1613 = {0f, 0f, 0f};
vector3 vLocal_1616[3] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
float fLocal_1626 = 0f;
int iLocal_1627 = 0;
var *uLocal_1628 = NULL;
var uLocal_1629 = 0;
var uLocal_1630 = 0;
var uLocal_1631 = 0;
var uLocal_1632 = 0;
var uLocal_1633 = 0;
var uLocal_1634 = 0;
var uLocal_1635 = 0;
var uLocal_1636 = 0;
var uLocal_1637 = 0;
var uLocal_1638 = 0;
var uLocal_1639 = 0;
var uLocal_1640 = 0;
var uLocal_1641 = 0;
var uLocal_1642 = 0;
var uLocal_1643 = 0;
var uLocal_1644 = 0;
var uLocal_1645 = 0;
var uLocal_1646 = 0;
var uLocal_1647 = 0;
var uLocal_1648 = 0;
var uLocal_1649 = 0;
var uLocal_1650 = 0;
var uLocal_1651 = 0;
var uLocal_1652 = 0;
var uLocal_1653 = 0;
var uLocal_1654 = 0;
var uLocal_1655 = 0;
var uLocal_1656 = 0;
var uLocal_1657 = 0;
var uLocal_1658 = 0;
var uLocal_1659 = 0;
var uLocal_1660 = 0;
var uLocal_1661 = 0;
var uLocal_1662 = 0;
var uLocal_1663 = 0;
var uLocal_1664 = 0;
var uLocal_1665 = 0;
var uLocal_1666 = 0;
var uLocal_1667 = 0;
var uLocal_1668 = 0;
var uLocal_1669 = 0;
var uLocal_1670 = 0;
var uLocal_1671 = 0;
var uLocal_1672 = 0;
var uLocal_1673 = 0;
var uLocal_1674 = 0;
var uLocal_1675 = 0;
var uLocal_1676 = 0;
var uLocal_1677 = 0;
var uLocal_1678 = 0;
var uLocal_1679 = 0;
var uLocal_1680 = 0;
var uLocal_1681 = 0;
var uLocal_1682 = 0;
var uLocal_1683 = 0;
var uLocal_1684 = 0;
var uLocal_1685 = 0;
var uLocal_1686 = 0;
var uLocal_1687 = 0;
var uLocal_1688 = 0;
var uLocal_1689 = 0;
var uLocal_1690 = 0;
var uLocal_1691 = 0;
var uLocal_1692 = 0;
var uLocal_1693 = 0;
var uLocal_1694 = 0;
var uLocal_1695 = 0;
var uLocal_1696 = 0;
var uLocal_1697 = 0;
var uLocal_1698 = 0;
var uLocal_1699 = 0;
var uLocal_1700 = 0;
var uLocal_1701 = 0;
var uLocal_1702 = 0;
var uLocal_1703 = 0;
var uLocal_1704 = 0;
var uLocal_1705 = 0;
var uLocal_1706 = 0;
var uLocal_1707 = 0;
var uLocal_1708 = 0;
var uLocal_1709 = 0;
var uLocal_1710 = 0;
var uLocal_1711 = 0;
var uLocal_1712 = 0;
var uLocal_1713 = 0;
var uLocal_1714 = 0;
var uLocal_1715 = 0;
var uLocal_1716 = 0;
var uLocal_1717 = 0;
var uLocal_1718 = 0;
var uLocal_1719 = 0;
var uLocal_1720 = 0;
var uLocal_1721 = 0;
var uLocal_1722 = 0;
var uLocal_1723 = 0;
var uLocal_1724 = 0;
var uLocal_1725 = 0;
var uLocal_1726 = 0;
var uLocal_1727 = 0;
var uLocal_1728 = 0;
var uLocal_1729 = 0;
var uLocal_1730 = 0;
var uLocal_1731 = 0;
var uLocal_1732 = 0;
var uLocal_1733 = 0;
var uLocal_1734 = 0;
var uLocal_1735 = 0;
var uLocal_1736 = 0;
var uLocal_1737 = 0;
var uLocal_1738 = 0;
var uLocal_1739 = 0;
var uLocal_1740 = 0;
var uLocal_1741 = 0;
var uLocal_1742 = 0;
var uLocal_1743 = 0;
var uLocal_1744 = 0;
var uLocal_1745 = 0;
var uLocal_1746 = 0;
var uLocal_1747 = 0;
var uLocal_1748 = 0;
var uLocal_1749 = 0;
var uLocal_1750 = 0;
var uLocal_1751 = 0;
var uLocal_1752 = 0;
var uLocal_1753 = 0;
var uLocal_1754 = 0;
var uLocal_1755 = 0;
var uLocal_1756 = 0;
var uLocal_1757 = 0;
var uLocal_1758 = 0;
var uLocal_1759 = 0;
var uLocal_1760 = 0;
var uLocal_1761 = 0;
var uLocal_1762 = 0;
var uLocal_1763 = 0;
var uLocal_1764 = 0;
var uLocal_1765 = 0;
var uLocal_1766 = 0;
var uLocal_1767 = 0;
var uLocal_1768 = 0;
var uLocal_1769 = 0;
var uLocal_1770 = 0;
var uLocal_1771 = 0;
var uLocal_1772 = 0;
var uLocal_1773 = 0;
var uLocal_1774 = 0;
var uLocal_1775 = 0;
var uLocal_1776 = 0;
var uLocal_1777 = 0;
var uLocal_1778 = 0;
var uLocal_1779 = 0;
var uLocal_1780 = 0;
var uLocal_1781 = 0;
var uLocal_1782 = 0;
var uLocal_1783 = 0;
var uLocal_1784 = 0;
var uLocal_1785 = 0;
var uLocal_1786 = 0;
var uLocal_1787 = 0;
var uLocal_1788 = 0;
var uLocal_1789 = 0;
var uLocal_1790 = 0;
var uLocal_1791 = 0;
var uLocal_1792 = 0;
int *iLocal_1793 = NULL;
var uLocal_1794 = 0;
var uLocal_1795 = -1;
var uLocal_1796 = 0;
var uLocal_1797 = 0;
var uLocal_1798 = 0;
var uLocal_1799 = 0;
var uLocal_1800 = 0;
var uLocal_1801 = 0;
var uLocal_1802 = 1000;
var uLocal_1803 = 1000;
var uLocal_1804 = 0;
var *uLocal_1805 = NULL;
var uLocal_1806 = 0;
var uLocal_1807 = 8;
var uLocal_1808 = 0;
var uLocal_1809 = 0;
var uLocal_1810 = 0;
var uLocal_1811 = 4;
var uLocal_1812 = 0;
var uLocal_1813 = 0;
var uLocal_1814 = 0;
var uLocal_1815 = 0;
var uLocal_1816 = 0;
var uLocal_1817 = 0;
var uLocal_1818 = 0;
var uLocal_1819 = 0;
var uLocal_1820 = 0;
var uLocal_1821 = 0;
var uLocal_1822 = 0;
var uLocal_1823 = 0;
var uLocal_1824 = 0;
var uLocal_1825 = 0;
var uLocal_1826 = 4;
var uLocal_1827 = 0;
var uLocal_1828 = 0;
var uLocal_1829 = 0;
var uLocal_1830 = 0;
var uLocal_1831 = 0;
var uLocal_1832 = 0;
var uLocal_1833 = 0;
var uLocal_1834 = 0;
var uLocal_1835 = 0;
var uLocal_1836 = 0;
var uLocal_1837 = 0;
var uLocal_1838 = 0;
var uLocal_1839 = 0;
var uLocal_1840 = 0;
var uLocal_1841 = 4;
var uLocal_1842 = 0;
var uLocal_1843 = 0;
var uLocal_1844 = 0;
var uLocal_1845 = 0;
var uLocal_1846 = 0;
var uLocal_1847 = 0;
var uLocal_1848 = 0;
var uLocal_1849 = 0;
var uLocal_1850 = 0;
var uLocal_1851 = 0;
var uLocal_1852 = 0;
var uLocal_1853 = 0;
var uLocal_1854 = 0;
var uLocal_1855 = 0;
var uLocal_1856 = 4;
var uLocal_1857 = 0;
var uLocal_1858 = 0;
var uLocal_1859 = 0;
var uLocal_1860 = 0;
var uLocal_1861 = 0;
var uLocal_1862 = 0;
var uLocal_1863 = 0;
var uLocal_1864 = 0;
var uLocal_1865 = 0;
var uLocal_1866 = 0;
var uLocal_1867 = 0;
var uLocal_1868 = 0;
var uLocal_1869 = 0;
var uLocal_1870 = 0;
var uLocal_1871 = 4;
var uLocal_1872 = 0;
var uLocal_1873 = 0;
var uLocal_1874 = 0;
var uLocal_1875 = 0;
var uLocal_1876 = 0;
var uLocal_1877 = 0;
var uLocal_1878 = 0;
var uLocal_1879 = 0;
var uLocal_1880 = 0;
var uLocal_1881 = 0;
var uLocal_1882 = 0;
var uLocal_1883 = 0;
var uLocal_1884 = 0;
var uLocal_1885 = 0;
var uLocal_1886 = 4;
var uLocal_1887 = 0;
var uLocal_1888 = 0;
var uLocal_1889 = 0;
var uLocal_1890 = 0;
var uLocal_1891 = 0;
var uLocal_1892 = 0;
var uLocal_1893 = 0;
var uLocal_1894 = 0;
var uLocal_1895 = 0;
var uLocal_1896 = 0;
var uLocal_1897 = 0;
var uLocal_1898 = 0;
var uLocal_1899 = 0;
var uLocal_1900 = 0;
var uLocal_1901 = 4;
var uLocal_1902 = 0;
var uLocal_1903 = 0;
var uLocal_1904 = 0;
var uLocal_1905 = 0;
var uLocal_1906 = 0;
var uLocal_1907 = 0;
var uLocal_1908 = 0;
var uLocal_1909 = 0;
var uLocal_1910 = 0;
var uLocal_1911 = 0;
var uLocal_1912 = 0;
var uLocal_1913 = 0;
var uLocal_1914 = 0;
var uLocal_1915 = 0;
var uLocal_1916 = 4;
var uLocal_1917 = 0;
var uLocal_1918 = 0;
var uLocal_1919 = 0;
var uLocal_1920 = 0;
var uLocal_1921 = 0;
var uLocal_1922 = 0;
var uLocal_1923 = 0;
var uLocal_1924 = 0;
var uLocal_1925 = 0;
var uLocal_1926 = 0;
var uLocal_1927 = 0;
var uLocal_1928 = 0;
var *uLocal_1929 = NULL;
var uLocal_1930 = 0;
var uLocal_1931 = 0;
var uLocal_1932 = 0;
var uLocal_1933 = 0;
var uLocal_1934 = 0;
var uLocal_1935 = 0;
var uLocal_1936 = 0;
var uLocal_1937 = 0;
var uLocal_1938 = 0;
var uLocal_1939 = 0;
var uLocal_1940 = 0;
var uLocal_1941 = 0;
var uLocal_1942 = 0;
var uLocal_1943 = 0;
var uLocal_1944 = 0;
var uLocal_1945 = 0;
var uLocal_1946 = 0;
var uLocal_1947 = 0;
var uLocal_1948 = 0;
var uLocal_1949 = 0;
var uLocal_1950 = 0;
var uLocal_1951 = 0;
var uLocal_1952 = 0;
var uLocal_1953 = 0;
var uLocal_1954 = 0;
var uLocal_1955 = 0;
var uLocal_1956 = 0;
var uLocal_1957 = 0;
var uLocal_1958 = 0;
var uLocal_1959 = 0;
var uLocal_1960 = 0;
var uLocal_1961 = 0;
var uLocal_1962 = 0;
var uLocal_1963 = 0;
var uLocal_1964 = 0;
var uLocal_1965 = 0;
var uLocal_1966 = 0;
var uLocal_1967 = 0;
var uLocal_1968 = 0;
var uLocal_1969 = 0;
var uLocal_1970 = 0;
var uLocal_1971 = 0;
var uLocal_1972 = 0;
var uLocal_1973 = 0;
var uLocal_1974 = 0;
var uLocal_1975 = 0;
var uLocal_1976 = 0;
var uLocal_1977 = 0;
var uLocal_1978 = 0;
var uLocal_1979 = 0;
var uLocal_1980 = 0;
var uLocal_1981 = 0;
var uLocal_1982 = 0;
var uLocal_1983 = 0;
var uLocal_1984 = 0;
var uLocal_1985 = 0;
var uLocal_1986 = 0;
var uLocal_1987 = 0;
var uLocal_1988 = 0;
var uLocal_1989 = 0;
var uLocal_1990 = 0;
var uLocal_1991 = 0;
var uLocal_1992 = 0;
var uLocal_1993 = 0;
var uLocal_1994 = 0;
var uLocal_1995 = 0;
var uLocal_1996 = 0;
var uLocal_1997 = 0;
var uLocal_1998 = 0;
var uLocal_1999 = 0;
var uLocal_2000 = 0;
var uLocal_2001 = 0;
var uLocal_2002 = 0;
var uLocal_2003 = 0;
var uLocal_2004 = 0;
var uLocal_2005 = 0;
var uLocal_2006 = 0;
var uLocal_2007 = 0;
var uLocal_2008 = 0;
var uLocal_2009 = 0;
var uLocal_2010 = 0;
var uLocal_2011 = 0;
var uLocal_2012 = 0;
var uLocal_2013 = 0;
var uLocal_2014 = 0;
var uLocal_2015 = 0;
var uLocal_2016 = 0;
var uLocal_2017 = 0;
var uLocal_2018 = 0;
var uLocal_2019 = 0;
var uLocal_2020 = 0;
var uLocal_2021 = 0;
var uLocal_2022 = 0;
var uLocal_2023 = 0;
var uLocal_2024 = 0;
var uLocal_2025 = 0;
var uLocal_2026 = 0;
var uLocal_2027 = 0;
var uLocal_2028 = 0;
var uLocal_2029 = 0;
var uLocal_2030 = 0;
var uLocal_2031 = 0;
var uLocal_2032 = 0;
var uLocal_2033 = 0;
var uLocal_2034 = 0;
var uLocal_2035 = 0;
var uLocal_2036 = 0;
var uLocal_2037 = 0;
var uLocal_2038 = 0;
var uLocal_2039 = 0;
var uLocal_2040 = 0;
var uLocal_2041 = 0;
var uLocal_2042 = 0;
var uLocal_2043 = 0;
var uLocal_2044 = 0;
var uLocal_2045 = 0;
var uLocal_2046 = 0;
var uLocal_2047 = 0;
var uLocal_2048 = 0;
var uLocal_2049 = 0;
var uLocal_2050 = 0;
var uLocal_2051 = 0;
var uLocal_2052 = 0;
var uLocal_2053 = 0;
var uLocal_2054 = 0;
var uLocal_2055 = 0;
var uLocal_2056 = 0;
var uLocal_2057 = 0;
var uLocal_2058 = 0;
var uLocal_2059 = 0;
var uLocal_2060 = 0;
var uLocal_2061 = 0;
var uLocal_2062 = 0;
var uLocal_2063 = 0;
var uLocal_2064 = 0;
var uLocal_2065 = 0;
var uLocal_2066 = 0;
var uLocal_2067 = 0;
var uLocal_2068 = 0;
var uLocal_2069 = 0;
var uLocal_2070 = 0;
var uLocal_2071 = 0;
var uLocal_2072 = 0;
var uLocal_2073 = 0;
var uLocal_2074 = 0;
var uLocal_2075 = 0;
var uLocal_2076 = 0;
var uLocal_2077 = 0;
var uLocal_2078 = 0;
var uLocal_2079 = 0;
var uLocal_2080 = 0;
var uLocal_2081 = 0;
var uLocal_2082 = 0;
var uLocal_2083 = 0;
var uLocal_2084 = 0;
var uLocal_2085 = 0;
var uLocal_2086 = 0;
var uLocal_2087 = 0;
var uLocal_2088 = 0;
var uLocal_2089 = 0;
var uLocal_2090 = 0;
var uLocal_2091 = 0;
var uLocal_2092 = 0;
var uLocal_2093 = 0;
var uLocal_2094 = 0;
var uLocal_2095 = 0;
var uLocal_2096 = 0;
var uLocal_2097 = 0;
var uLocal_2098 = 0;
var uLocal_2099 = 0;
var uLocal_2100 = 0;
var uLocal_2101 = 0;
var uLocal_2102 = 0;
var uLocal_2103 = 0;
var uLocal_2104 = 0;
var uLocal_2105 = 0;
var uLocal_2106 = 0;
var uLocal_2107 = 0;
var uLocal_2108 = 0;
var uLocal_2109 = 0;
var uLocal_2110 = 0;
var uLocal_2111 = 0;
var uLocal_2112 = 0;
var uLocal_2113 = 0;
var uLocal_2114 = 0;
var uLocal_2115 = 0;
var uLocal_2116 = 0;
var uLocal_2117 = 0;
var uLocal_2118 = 0;
var uLocal_2119 = 0;
var uLocal_2120 = 0;
var uLocal_2121 = 0;
var uLocal_2122 = 0;
var uLocal_2123 = 0;
var uLocal_2124 = 0;
var uLocal_2125 = 0;
var uLocal_2126 = 0;
var uLocal_2127 = 0;
var uLocal_2128 = 0;
var uLocal_2129 = 0;
var uLocal_2130 = 0;
var uLocal_2131 = 0;
var uLocal_2132 = 0;
var uLocal_2133 = 0;
var uLocal_2134 = 0;
var uLocal_2135 = 0;
var uLocal_2136 = 0;
var uLocal_2137 = 0;
var uLocal_2138 = 0;
var uLocal_2139 = 0;
var uLocal_2140 = 0;
var uLocal_2141 = 0;
var uLocal_2142 = 0;
var uLocal_2143 = 0;
var uLocal_2144 = 0;
var uLocal_2145 = 0;
var uLocal_2146 = 0;
var uLocal_2147 = 0;
var uLocal_2148 = 0;
var uLocal_2149 = 0;
var uLocal_2150 = 0;
var uLocal_2151 = 0;
var uLocal_2152 = 0;
var uLocal_2153 = 0;
var uLocal_2154 = 0;
var uLocal_2155 = 0;
var uLocal_2156 = 0;
var uLocal_2157 = 0;
var uLocal_2158 = 0;
var uLocal_2159 = 0;
var uLocal_2160 = 0;
var uLocal_2161 = 0;
var uLocal_2162 = 0;
var uLocal_2163 = 0;
var uLocal_2164 = 0;
var uLocal_2165 = 0;
var uLocal_2166 = 0;
var uLocal_2167 = 0;
var uLocal_2168 = 0;
var uLocal_2169 = 0;
var uLocal_2170 = 0;
var uLocal_2171 = 0;
var uLocal_2172 = 0;
var uLocal_2173 = 0;
var uLocal_2174 = 0;
var uLocal_2175 = 0;
var uLocal_2176 = 0;
var uLocal_2177 = 0;
var uLocal_2178 = 0;
var uLocal_2179 = 0;
var uLocal_2180 = 0;
var uLocal_2181 = 0;
var uLocal_2182 = 0;
var uLocal_2183 = 0;
var uLocal_2184 = 0;
var uLocal_2185 = 0;
var uLocal_2186 = 0;
var uLocal_2187 = 0;
var uLocal_2188 = 0;
var uLocal_2189 = 0;
var uLocal_2190 = 0;
var uLocal_2191 = 0;
var uLocal_2192 = 0;
var uLocal_2193 = 0;
var uLocal_2194 = 0;
var uLocal_2195 = 0;
var uLocal_2196 = 0;
var uLocal_2197 = 0;
var uLocal_2198 = 0;
var uLocal_2199 = 0;
var uLocal_2200 = 0;
var uLocal_2201 = 0;
var uLocal_2202 = 1;
struct<9> Local_2203[2];
var *uScriptParam_0 = NULL;
var uScriptParam_1 = 0;
var uScriptParam_2 = 0;
var uScriptParam_3 = 0;
var uScriptParam_4 = 0;
var uScriptParam_5 = 0;
var uScriptParam_6 = 0;
var uScriptParam_7 = 0;
var uScriptParam_8 = 0;
var uScriptParam_9 = 0;
var uScriptParam_10 = 0;
var uScriptParam_11 = 0;
var uScriptParam_12 = 0;
var uScriptParam_13 = 0;
var uScriptParam_14 = 0;
var uScriptParam_15 = 0;
var uScriptParam_16 = 0;
var uScriptParam_17 = 0;
var uScriptParam_18 = 0;
var uScriptParam_19 = 0;
var uScriptParam_20 = 0;
var uScriptParam_21 = 0;
var uScriptParam_22 = 0;
var uScriptParam_23 = 0;
var uScriptParam_24 = 0;
var uScriptParam_25 = 0;
var uScriptParam_26 = 0;
var uScriptParam_27 = 0;
var uScriptParam_28 = 0;
var uScriptParam_29 = 0;
var uScriptParam_30 = 0;
var uScriptParam_31 = 0;
var uScriptParam_32 = 0;
var uScriptParam_33 = 0;
var uScriptParam_34 = 11;
var uScriptParam_35 = 0;
var uScriptParam_36 = 0;
var uScriptParam_37 = 0;
var uScriptParam_38 = 0;
var uScriptParam_39 = 0;
var uScriptParam_40 = 0;
var uScriptParam_41 = 0;
var uScriptParam_42 = 0;
var uScriptParam_43 = 0;
var uScriptParam_44 = 0;
var uScriptParam_45 = 0;
var uScriptParam_46 = 10;
var uScriptParam_47 = 0;
var uScriptParam_48 = 0;
var uScriptParam_49 = 0;
var uScriptParam_50 = 0;
var uScriptParam_51 = 0;
var uScriptParam_52 = 0;
var uScriptParam_53 = 0;
var uScriptParam_54 = 0;
var uScriptParam_55 = 0;
var uScriptParam_56 = 0;
var uScriptParam_57 = 0;
var uScriptParam_58 = 0;
var uScriptParam_59 = 0;
var uScriptParam_60 = 0;
var uScriptParam_61 = 0;
var uScriptParam_62 = 0;
var uScriptParam_63 = 2;
var uScriptParam_64 = 0;
var uScriptParam_65 = 0;
var uScriptParam_66 = 0;
var uScriptParam_67 = 0;
var uScriptParam_68 = 0;
var uScriptParam_69 = 0;
var uScriptParam_70 = 0;
var uScriptParam_71 = 0;
var uScriptParam_72 = 0;
var uScriptParam_73 = 0;
var uScriptParam_74 = 0;
var uScriptParam_75 = 0;
var uScriptParam_76 = 0;
var uScriptParam_77 = 0;
var uScriptParam_78 = 0;
var uScriptParam_79 = 0;
var uScriptParam_80 = 0;
var uScriptParam_81 = 0;
var uScriptParam_82 = 0;
var uScriptParam_83 = 10;
var uScriptParam_84 = 0;
var uScriptParam_85 = 0;
var uScriptParam_86 = 0;
var uScriptParam_87 = 0;
var uScriptParam_88 = 0;
var uScriptParam_89 = 0;
var uScriptParam_90 = 0;
var uScriptParam_91 = 0;
var uScriptParam_92 = 0;
var uScriptParam_93 = 0;
var uScriptParam_94 = 0;
var uScriptParam_95 = 0;
var uScriptParam_96 = 0;
var uScriptParam_97 = 0;
var uScriptParam_98 = 0;
var uScriptParam_99 = 0;
var uScriptParam_100 = 0;
var uScriptParam_101 = 0;
var uScriptParam_102 = 0;
var uScriptParam_103 = 0;
var uScriptParam_104 = 0;
var uScriptParam_105 = 0;
var uScriptParam_106 = 0;
var uScriptParam_107 = 0;
var uScriptParam_108 = 0;
var uScriptParam_109 = 0;
var uScriptParam_110 = 0;
var uScriptParam_111 = 0;
var uScriptParam_112 = 0;
var uScriptParam_113 = 0;
var uScriptParam_114 = 0;
var uScriptParam_115 = 0;
var uScriptParam_116 = 0;
var uScriptParam_117 = 0;
var uScriptParam_118 = 0;
var uScriptParam_119 = 0;
var uScriptParam_120 = 0;
var uScriptParam_121 = 0;
var uScriptParam_122 = 0;
var uScriptParam_123 = 0;
var uScriptParam_124 = 0;
var uScriptParam_125 = 0;
var uScriptParam_126 = 0;
var uScriptParam_127 = 0;
var uScriptParam_128 = 0;
var uScriptParam_129 = 0;
var uScriptParam_130 = 0;
var uScriptParam_131 = 0;
var uScriptParam_132 = 0;
var uScriptParam_133 = 0;
var uScriptParam_134 = 0;
var uScriptParam_135 = 0;
var uScriptParam_136 = 0;
var uScriptParam_137 = 0;
var uScriptParam_138 = 0;
var uScriptParam_139 = 0;
var uScriptParam_140 = 0;
var uScriptParam_141 = 0;
var uScriptParam_142 = 0;
var uScriptParam_143 = 0;
var uScriptParam_144 = 0;
var uScriptParam_145 = 0;
var uScriptParam_146 = 0;
var uScriptParam_147 = 0;
var uScriptParam_148 = 0;
var uScriptParam_149 = 0;
var uScriptParam_150 = 0;
var uScriptParam_151 = 0;
var uScriptParam_152 = 0;
var uScriptParam_153 = 0;
var uScriptParam_154 = 0;
var uScriptParam_155 = 0;
var uScriptParam_156 = 0;
var uScriptParam_157 = 0;
var uScriptParam_158 = 0;
var uScriptParam_159 = 0;
var uScriptParam_160 = 0;
var uScriptParam_161 = 0;
var uScriptParam_162 = 0;
var uScriptParam_163 = 0;
var uScriptParam_164 = 0;
var uScriptParam_165 = 0;
var uScriptParam_166 = 0;
var uScriptParam_167 = 0;
var uScriptParam_168 = 0;
var uScriptParam_169 = 0;
var uScriptParam_170 = 0;
var uScriptParam_171 = 0;
var uScriptParam_172 = 0;
var uScriptParam_173 = 0;
var uScriptParam_174 = 0;
var uScriptParam_175 = 0;
var uScriptParam_176 = 0;
var uScriptParam_177 = 0;
var uScriptParam_178 = 0;
var uScriptParam_179 = 0;
var uScriptParam_180 = 0;
var uScriptParam_181 = 0;
var uScriptParam_182 = 0;
var uScriptParam_183 = 0;
var uScriptParam_184 = 0;
var uScriptParam_185 = 0;
var uScriptParam_186 = 0;
var uScriptParam_187 = 0;
var uScriptParam_188 = 0;
var uScriptParam_189 = 0;
var uScriptParam_190 = 0;
var uScriptParam_191 = 0;
var uScriptParam_192 = 0;
var uScriptParam_193 = 0;
var uScriptParam_194 = 0;
var uScriptParam_195 = 0;
var uScriptParam_196 = 0;
var uScriptParam_197 = 0;
var uScriptParam_198 = 0;
var uScriptParam_199 = 0;
var uScriptParam_200 = 0;
var uScriptParam_201 = 0;
var uScriptParam_202 = 0;
var uScriptParam_203 = 0;
var uScriptParam_204 = 0;
var uScriptParam_205 = 0;
var uScriptParam_206 = 0;
var uScriptParam_207 = 0;
var uScriptParam_208 = 0;
var uScriptParam_209 = 0;
var uScriptParam_210 = 0;
var uScriptParam_211 = 0;
var uScriptParam_212 = 0;
var uScriptParam_213 = 0;
var uScriptParam_214 = 0;
var uScriptParam_215 = 0;
var uScriptParam_216 = 0;
var uScriptParam_217 = 0;
var uScriptParam_218 = 0;
var uScriptParam_219 = 0;
var uScriptParam_220 = 0;
var uScriptParam_221 = 0;
var uScriptParam_222 = 0;
var uScriptParam_223 = 0;
var uScriptParam_224 = 0;
var uScriptParam_225 = 0;
var uScriptParam_226 = 0;
var uScriptParam_227 = 0;
var uScriptParam_228 = 0;
var uScriptParam_229 = 0;
var uScriptParam_230 = 0;
var uScriptParam_231 = 0;
var uScriptParam_232 = 0;
var uScriptParam_233 = 0;
var uScriptParam_234 = 0;
var uScriptParam_235 = 0;
var uScriptParam_236 = 0;
var uScriptParam_237 = 0;
var uScriptParam_238 = 0;
var uScriptParam_239 = 0;
var uScriptParam_240 = 0;
var uScriptParam_241 = 0;
var uScriptParam_242 = 0;
var uScriptParam_243 = 0;
var uScriptParam_244 = 4;
var uScriptParam_245 = 0;
var uScriptParam_246 = 0;
var uScriptParam_247 = 0;
var uScriptParam_248 = 0;
var uScriptParam_249 = 4;
var uScriptParam_250 = 0;
var uScriptParam_251 = 0;
var uScriptParam_252 = 0;
var uScriptParam_253 = 0;
var uScriptParam_254 = 0;
var uScriptParam_255 = 0;
var uScriptParam_256 = 0;
var uScriptParam_257 = 0;
var uScriptParam_258 = 0;
var uScriptParam_259 = 0;
var uScriptParam_260 = 0;
var uScriptParam_261 = 0;
var uScriptParam_262 = 4;
var uScriptParam_263 = 0;
var uScriptParam_264 = 0;
var uScriptParam_265 = 0;
var uScriptParam_266 = 0;
var uScriptParam_267 = 0;
var uScriptParam_268 = 0;
var uScriptParam_269 = 0;
var uScriptParam_270 = 0;
var uScriptParam_271 = 0;
var uScriptParam_272 = 0;
var uScriptParam_273 = 0;
var uScriptParam_274 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	iLocal_28 = 3;
	fLocal_31 = 80f;
	fLocal_32 = 140f;
	fLocal_33 = 180f;
	iLocal_39 = 1;
	iLocal_40 = 65;
	iLocal_41 = 49;
	iLocal_42 = 64;
	vLocal_45 = {500f, 500f, 500f};
	iLocal_145 = 100;
	iLocal_146 = 3;
	uLocal_795 = ui::_0x4A9923385BDB9DAD();
	uLocal_796 = ui::_get_blip_info_id_iterator();
	iLocal_1041 = 1;
	iLocal_1442 = -1;
	fLocal_1444 = 1f;
	vLocal_1468 = {-700.1431f, -917.7708f, 18.2147f};
	vLocal_1471 = {-700.1431f, -917.7708f, 18.2147f};
	fLocal_1474 = 3.283f;
	fLocal_1475 = 42f;
	vLocal_1478 = {-699.1455f, -917.3423f, 19.7904f};
	vLocal_1481 = {-5.6096f, -0.1143f, 75.6741f};
	vLocal_1484 = {-699.1455f, -917.3423f, 19.7904f};
	vLocal_1487 = {-2.4284f, -0.1143f, 81.9337f};
	vLocal_1498 = {0f, 0f, 0f};
	vLocal_1501 = {0f, 0f, 0f};
	iLocal_1540 = 540000;
	iLocal_1542 = -1;
	iLocal_1553 = -1;
	iLocal_1555 = -1;
	fLocal_1556 = 75f;
	fLocal_1558 = 3f;
	fLocal_1559 = 540000f;
	vLocal_1562 = {-1208.462f, -1559.661f, 3.6087f};
	vLocal_1613 = {-702.6807f, -920.2365f, 18.0144f};
	fLocal_1626 = 120.5394f;
	iLocal_1627 = -1;
	gameplay::set_mission_flag(1);
	if (player::has_force_cleanup_occurred(3)) {
		streaming::clear_hd_area();
		func_473();
		Global_101700.f_18922.f_6 = func_472();
		func_470(&Global_101700.f_18922.f_1, 1024);
		func_468();
		if (entity::does_entity_exist(iLocal_1464)) {
			entity::set_entity_visible(iLocal_1464, 1, 0);
			entity::set_entity_collision(iLocal_1464, 1, 0);
			entity::set_entity_can_be_damaged(iLocal_1464, 1);
		}
		func_467(&uLocal_1929);
	}
	if (func_466()) {
		if (func_465()) {
			bLocal_1513 = true;
		}
		bLocal_1512 = true;
	}
	else {
		bLocal_1512 = false;
	}
	func_470(&Local_122, 2);
	func_464(1);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		ped::set_ped_config_flag(player::player_ped_id(), 32, 0);
	}
	iLocal_1588 =
		ped::add_scenario_blocking_area(vLocal_1562 - Vector(2f, 2f, 2f), vLocal_1562 + Vector(2f, 2f, 2f), 0, 1, 1, 1);
	func_463();
	iLocal_1443 = 1;
	Local_1231 = {func_461(iLocal_1443)};
	iLocal_1041 = 1;
	if (func_466()) {
		func_473();
		bLocal_138 = true;
		iLocal_1551 = func_460();
		if (Global_86001) {
			iLocal_1528 = 1;
			iLocal_1551++;
		}
		if (iLocal_1551 == 0) {
			vLocal_1565 = {vLocal_1613};
			fLocal_1568 = fLocal_1626;
			vLocal_1569 = {-711.8262f, -920.7407f, 18.0144f};
			fLocal_1572 = 0.0954f;
			func_459(vLocal_1613, fLocal_1626, 1, 0);
		}
		else if (iLocal_1551 == 1) {
			vLocal_1565 = {-1205.392f, -1548.022f, 3.3229f};
			fLocal_1568 = 30.1673f;
			vLocal_1569 = {-1192.206f, -1532.933f, 3.4095f};
			fLocal_1572 = 304.364f;
			func_459(vLocal_1565, fLocal_1568, 1, 0);
		}
		else if (iLocal_1551 == 2) {
			vLocal_1565 = {-2178.855f, -410.6809f, 12.1595f};
			fLocal_1568 = 13.1631f;
			vLocal_1569 = {-2175.782f, -400.12f, 12.1925f};
			fLocal_1572 = 347.9469f;
			func_459(vLocal_1565, fLocal_1568, 1, 0);
		}
		else if (iLocal_1551 == 3) {
			vLocal_1565 = {-702.8256f, 224.235f, 79.1613f};
			fLocal_1568 = 291.4638f;
			vLocal_1569 = {-700.4276f, 229.6938f, 79.2745f};
			fLocal_1572 = 296.3371f;
			func_459(vLocal_1565, fLocal_1568, 1, 0);
		}
		else if (iLocal_1551 == 4) {
			vLocal_1565 = {-1986.378f, 531.8684f, 108.243f};
			fLocal_1568 = 149.1485f;
			vLocal_1569 = {-1984.45f, 529.9053f, 107.9867f};
			fLocal_1572 = 163.9831f;
			func_459(vLocal_1565, fLocal_1568, 1, 0);
		}
	}
	while (true) {
		system::wait(0);
		func_456(&uLocal_1929);
		unk1::_0x208784099002BC30("M_ASS2", 0);
		func_455(&iLocal_1598, 14f, 1);
		if (func_454(&uScriptParam_0)) {
			if (func_453()) {
				if (func_452(&iLocal_1037)) {
					Global_101700.f_18922.f_6 = func_472();
				}
				ped::remove_scenario_blocking_area(iLocal_1588, 0);
				func_473();
				func_451(&uLocal_1929);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id())) {
			if (func_138(&uScriptParam_0, &Local_1044)) {
				Global_101700.f_18922.f_6 = func_472();
				fLocal_134 = Global_101700.f_18922.f_6 / 1000f;
				func_137(&iLocal_1037, fLocal_134);
				func_136(&iLocal_1037);
				if (!iLocal_1528) {
					func_135();
				}
				func_473();
				func_47(Local_1231, &uLocal_1805, &uLocal_1929);
			}
			else {
				func_46();
				func_42();
			}
			func_1(&uScriptParam_0, &Local_1044);
		}
	}
}

// Position - 0x4FB
void func_1(var *uParam0, int iParam1) {
	if (iLocal_1041 >= 4 && iLocal_1041 != 12) {
		if (!iLocal_1510) {
			func_33(&iLocal_1540, &iLocal_1544, &fLocal_1559, &iLocal_1509, &iLocal_1510);
			func_20(iParam1);
		}
		else {
			func_2(Local_1044, uParam0, 1);
		}
	}
}

// Position - 0x547
void func_2(struct<182> Param0, var uParam182, var *uParam183, int iParam184) {
	struct<2> Var0;

	if (uParam183->f_270 == 0) {
		Param0.f_181 = iParam184;
		switch (Param0.f_181) {
		case 0:
			if (uParam183->f_274 == 1) {
				StringCopy(&Var0, "ASS_HK_LOST", 16);
			}
			else if (uParam183->f_274 == 0) {
				StringCopy(&Var0, "ASS_BS_LOST", 16);
			}
			else if (uParam183->f_274 == 2) {
				StringCopy(&Var0, "ASS_ML_LOST", 16);
			}
			break;

		case 1:
			if (uParam183->f_274 == 1) {
				StringCopy(&Var0, "ASS_HK_LOST", 16);
			}
			else if (uParam183->f_274 == 0) {
				StringCopy(&Var0, "ASS_BS_LEFTBUS", 16);
			}
			else if (uParam183->f_274 == 2) {
				StringCopy(&Var0, "ASS_ML_TIMEFAIL", 16);
			}
			break;

		case 2:
			if (uParam183->f_274 == 1) {
				StringCopy(&Var0, "ASS_HK_COVER", 16);
			}
			else if (uParam183->f_274 == 0) {
				StringCopy(&Var0, "ASS_BS_COVER", 16);
			}
			break;

		case 3:
			if (uParam183->f_274 == 0) {
				StringCopy(&Var0, "ASS_BS_VEHDEST", 16);
			}
			break;

		case 4:
			if (uParam183->f_274 == 1) {
				StringCopy(&Var0, "ASS_HK_ABAND", 16);
			}
			else if (uParam183->f_274 == 0) {
				StringCopy(&Var0, "ASS_BS_ABAND", 16);
			}
			break;
		}
		uParam183->f_270 = 1;
		func_18(&Var0);
		func_3(0);
	}
}

// Position - 0x667
void func_3(int iParam0) {
	int iVar0;

	if (Global_101700.f_8044 || func_17(0)) {
		iVar0 = func_16();
		if (!func_4(iVar0)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
		Global_91527 = iParam0;
	}
}

// Position - 0x6AC
int func_4(int iParam0) {
	int iVar0;
	int iVar1;

	func_9();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_8(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_5(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0x7C3
void func_5(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_7(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_6(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0x98C
void func_6(int *iParam0) { *iParam0 = -15; }

// Position - 0x99A
int func_7(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_7(8, uParam1, fParam2);

	case 10: return func_7(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0x1309
void func_8(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x1347
void func_9() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_10()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_10()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x142E
int func_10() {
	func_11();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x1447
void func_11() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_15(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_14(player::player_ped_id());
			if (func_13(iVar0) && (!func_12(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_13(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x1544
bool func_12(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x1552
bool func_13(int iParam0) { return iParam0 < 3; }

// Position - 0x155E
int func_14(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_15(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x159B
int func_15(int iParam0) {
	if (func_13(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x15C5
int func_16() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x15FA
bool func_17(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x1625
void func_18(char *sParam0) {
	func_470(&Global_101700.f_18922.f_1, 1024);
	if (!gameplay::is_string_null(sParam0)) {
		func_19(sParam0);
	}
}

// Position - 0x164D
void func_19(char *sParam0) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (ui::get_length_of_literal_string(sParam0) <= 16) {
			StringCopy(&Global_69934, sParam0, 16);
			StringCopy(&Global_69938, "", 16);
			if (unk1::_is_recording()) {
				unk1::_stop_recording_and_save_clip();
			}
		}
	}
}

// Position - 0x168C
int func_20(var *uParam0) {
	switch (iLocal_1550) {
	case 0:
		if (IntToFloat(iLocal_1544) >= fLocal_1559 * 1f / 2f && !ui::is_message_being_displayed()) {
			func_32(&uParam0->f_16, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
			func_21(&uParam0->f_16, "OJASAUD", "OJASml_TIME2", 8, 0, 0, 0);
			iLocal_1550 = 1;
		}
		break;
	}
	return 0;
}

// Position - 0x16E9
bool func_21(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_31(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_22(sParam2, iParam3, 0);
}

// Position - 0x1737
int func_22(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_30();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_29(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_28();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_27();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_26()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_25()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_24();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_23();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_30();
	}
	return 0;
}

// Position - 0x1A03
void func_23() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x1A34
void func_24() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x1AC9
bool func_25() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x1AF0
bool func_26() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x1B89
void func_27() {
	if (func_12(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_10();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x1C2B
void func_28() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x1C82
bool func_29(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x1CBD
void func_30() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x1D14
void func_31(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x1D6A
void func_32(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x1E05
void func_33(int iParam0, int *iParam1, float fParam2, int *iParam3, int *iParam4) {
	if (!*iParam3) {
		*iParam0 = gameplay::get_game_timer();
		*iParam3 = 1;
	}
	*iParam1 = gameplay::get_game_timer() - *iParam0;
	iLocal_1554 = system::round(*fParam2) - *iParam1;
	if (iLocal_1554 < 60000) {
		if (iLocal_1554 <= 11000 && iLocal_1554 >= 5000) {
			if (func_452(&iLocal_1506)) {
				if (func_39(&iLocal_1506) > 1f) {
					audio::play_sound_frontend(-1, "10_SEC_WARNING", "HUD_MINI_GAME_SOUNDSET", 1);
					func_38(&iLocal_1506);
				}
			}
			else {
				audio::play_sound_frontend(-1, "10_SEC_WARNING", "HUD_MINI_GAME_SOUNDSET", 1);
				func_37(&iLocal_1506);
			}
		}
		else if (iLocal_1554 <= 5000 && iLocal_1554 > 0) {
			if (func_452(&iLocal_1506)) {
				if (func_39(&iLocal_1506) > 0.5f) {
					audio::play_sound_frontend(-1, "10_SEC_WARNING", "HUD_MINI_GAME_SOUNDSET", 1);
					func_38(&iLocal_1506);
				}
			}
			else {
				func_37(&iLocal_1506);
			}
		}
		func_34(iLocal_1554, "ASS_TIME", 0, 0, -1, 0, 2, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0);
	}
	else {
		func_34(iLocal_1554, "ASS_TIME", 0, 0, -1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
	}
	if (IntToFloat(*iParam1) > *fParam2) {
		audio::play_sound_frontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", 1);
		*iParam4 = 1;
	}
}

// Position - 0x1F38
void func_34(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			 int iParam15, int iParam16) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_36(7, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_35(7, iVar0);
		Global_1354542.f_4282[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_4282.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_4282.f_172[iVar0] = iParam2;
		Global_1354542.f_4282.f_216[iVar0] = iParam3;
		Global_1354542.f_4282.f_183[iVar0] = iParam4;
		Global_1354542.f_4282.f_194[iVar0] = iParam5;
		Global_1354542.f_4282.f_249[iVar0] = iParam6;
		Global_1354542.f_4282.f_260[iVar0] = iParam7;
		Global_1354542.f_4282.f_205[iVar0] = iParam8;
		Global_1354542.f_4282.f_314[iVar0] = iParam9;
		Global_1354542.f_4282.f_325[iVar0] = iParam10;
		Global_1354542.f_4282.f_357[iVar0] = iParam11;
		Global_1354542.f_4282.f_238[iVar0] = iParam12;
		Global_1354542.f_4282.f_271[iVar0] = iParam13;
		Global_1354542.f_4282.f_368[iVar0] = iParam14;
		Global_1354542.f_4282.f_379[iVar0] = iParam15;
		Global_1354542.f_4282.f_390[iVar0] = iParam16;
	}
}

// Position - 0x2086
void func_35(int iParam0, int iParam1) { gameplay::set_bit(&Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x209F
int func_36(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x20B8
void func_37(int *iParam0) {
	if (!func_452(iParam0)) {
		func_38(iParam0);
	}
}

// Position - 0x20D0
void func_38(int *iParam0) { func_137(iParam0, 0f); }

// Position - 0x20DF
float func_39(int *iParam0) {
	if (func_452(iParam0)) {
		if (func_41(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_40(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return iParam0->f_1;
}

// Position - 0x211E
float func_40(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x2176
bool func_41(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x2186
void func_42() {
	if (!iLocal_1537) {
		if (player::get_player_wanted_level(player::player_id()) > 0) {
			if (!func_45()) {
				func_43(player::player_ped_id(), "SPOT_POLICE", 24);
				iLocal_1537 = 1;
			}
		}
	}
}

// Position - 0x21BB
void func_43(int iParam0, char *sParam1, int iParam2) {
	audio::_play_ambient_speech1(iParam0, sParam1, func_44(iParam2), 1);
}

// Position - 0x21D2
int func_44(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: return "SPEECH_PARAMS_STANDARD";

	case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

	case 2: return "SPEECH_PARAMS_BEAT";

	case 3: return "SPEECH_PARAMS_FORCE";

	case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

	case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

	case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

	case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

	case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

	case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

	case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

	case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

	case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

	case 13: return "SPEECH_PARAMS_MEGAPHONE";

	case 14: return "SPEECH_PARAMS_HELI";

	case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

	case 16: return "SPEECH_PARAMS_FORCE_HELI";

	case 17: return "SPEECH_PARAMS_INTERRUPT";

	case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

	case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

	case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

	case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

	case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

	case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

	case 24: return "SPEECH_PARAMS_ADD_BLIP";

	case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

	case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

	case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

	case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

	case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

	case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

	case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

	case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

	case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

	case 34: return "SPEECH_PARAMS_SHOUTED";

	case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

	case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

	default:
	}
	iVar0 = 0;
	return iVar0;
}

// Position - 0x23C7
int func_45() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return 1;
	}
	return 0;
}

// Position - 0x23E9
void func_46() {
	int iVar0;

	if (iLocal_1041 > 4) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			iVar0 = vehicle::get_last_driven_vehicle();
			if (entity::does_entity_exist(iVar0)) {
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (iVar0 != iLocal_1582 && !entity::is_entity_in_water(iVar0) &&
						!entity::is_entity_a_mission_entity(iVar0)) {
						iLocal_1582 = iVar0;
						entity::set_entity_as_mission_entity(iLocal_1582, 1, 0);
						vehicle::_0x02398B627547189C(iLocal_1582, 0);
					}
				}
			}
		}
	}
}

// Position - 0x2454
void func_47(struct<39> Param0, var *uParam39, var *uParam40) {
	ui::clear_prints();
	switch (iLocal_1043) {
	case 0:
		if (!iLocal_139) {
			if (iLocal_1026 == 1) {
				func_134();
				bLocal_137 = true;
			}
			fLocal_134 = func_39(&iLocal_1037);
			func_127();
			iLocal_139 = 1;
			iLocal_1043 = 1;
		}
		break;

	case 1:
		if (!iLocal_1032) {
			audio::play_mission_complete_audio("FRANKLIN_BIG_01");
			iLocal_1032 = 1;
		}
		if (func_123(&uLocal_150, 1, 0) && audio::_0x6F259F82D873B8B8()) {
			func_122(uParam39, 0, 0, 0, 1);
			func_121(uParam39, &Local_726.f_60, 2, 215, 1, 1, 0);
			func_121(uParam39, "ES_XPAND", 2, 216, 1, 1, 0);
			func_119(1);
			system::settimera(0);
			iLocal_1043 = 2;
		}
		break;

	case 2:
		if (func_94(&uLocal_150, 0, 1065353216, 0, 0, 0)) {
			bLocal_1031 = true;
		}
		if (!bLocal_1031) {
			func_86(uParam39, 1128792064, 1, 0, 1, 1065353216);
		}
		if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
			if (!bLocal_1031) {
				bLocal_1031 = true;
				func_85(&uLocal_150);
			}
		}
		if (bLocal_1031) {
			if (func_94(&uLocal_150, 0, 1065353216, 0, 0, 0)) {
				func_83(&uLocal_150);
				func_119(0);
				Global_101700.f_18922++;
				func_82();
				func_80(0, 0);
				func_50(Param0);
				func_48();
				func_467(uParam40);
			}
		}
		break;
	}
}

// Position - 0x25B5
void func_48() { func_49(); }

// Position - 0x25C2
int func_49() {
	if (func_17(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x260D
void func_50(struct<25> Param0, var uParam25, var uParam26, var uParam27, var uParam28, var uParam29, var uParam30,
			 var uParam31, var uParam32, var uParam33, var uParam34, var uParam35, var uParam36, var uParam37,
			 var uParam38) {
	float fVar0;

	fVar0 = 1f + func_79();
	fVar0 *= Param0.f_23;
	if (func_78(Global_101700.f_18922.f_1, 4194304)) {
		fVar0 += Param0.f_24;
	}
	func_51(func_10(), 96, system::round(fVar0), 0, 0);
}

// Position - 0x2658
void func_51(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;

	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 3) {
		return;
	}
	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 4) {
		return;
	}
	func_52(Global_101700.f_27009[iParam0 /*29*/].f_17, 1, iParam1, iParam2, 0);
	if (iParam3) {
		iVar0 = 0;
		if (iParam4) {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_random_peds"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_random_peds"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_random_peds"); break;

			default: return;
			}
		}
		else {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_missions"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_missions"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_missions"); break;

			default: return;
			}
		}
		stats::stat_get_int(iVar1, &iVar0, -1);
		iVar0 += iParam2;
		stats::stat_set_int(iVar1, iVar0, 1);
	}
}

// Position - 0x273F
int func_52(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	func_77();
	if (iParam3 < 1) {
		return 0;
	}
	fVar0 = 1f;
	switch (iParam1) {
	case 0:
		switch (iParam0) {
		case 0:
			func_76(99, 1);
			func_75(joaat("sp0_money_total_spent"), iParam3);
			break;

		case 1: func_75(joaat("sp1_money_total_spent"), iParam3); break;

		case 2: func_75(joaat("sp2_money_total_spent"), iParam3); break;
		}
		func_60(0);
		switch (iParam2) {
		case 126:
		case 128:
		case 124:
		case 125:
		case 127:
			if (func_59(5)) {
				fVar0 = 0.9f;
				iVar1 = 5;
			}
			break;

		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
			switch (iParam0) {
			case 0: func_75(joaat("sp0_money_spent_on_tattoos"), iParam3); break;

			case 1: func_75(joaat("sp1_money_spent_on_tattoos"), iParam3); break;

			case 2: func_75(joaat("sp2_money_spent_on_tattoos"), iParam3); break;
			}
			if (func_59(1)) {
				fVar0 = 0f;
				iVar1 = 1;
			}
			break;

		case 21:
			switch (iParam0) {
			case 0: func_75(joaat("sp0_money_spent_on_taxis"), iParam3); break;

			case 1: func_75(joaat("sp1_money_spent_on_taxis"), iParam3); break;

			case 2: func_75(joaat("sp2_money_spent_on_taxis"), iParam3); break;
			}
			break;

		case 25:
			switch (iParam0) {
			case 0: func_75(joaat("sp0_money_spent_in_strip_clubs"), iParam3); break;

			case 1: func_75(joaat("sp1_money_spent_in_strip_clubs"), iParam3); break;

			case 2: func_75(joaat("sp2_money_spent_in_strip_clubs"), iParam3); break;
			}
			break;

		case 98:
		case 99:
		case 100:
		case 101:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 112:
			switch (iParam0) {
			case 0: func_75(joaat("sp0_money_spent_property"), iParam3); break;

			case 1: func_75(joaat("sp1_money_spent_property"), iParam3); break;

			case 2: func_75(joaat("sp2_money_spent_property"), iParam3); break;
			}
			break;

		default:
			switch (script::get_hash_of_this_script_name()) {
			case joaat("clothes_shop_sp"):
				switch (iParam0) {
				case 0: func_75(joaat("sp0_money_spent_in_clothes"), iParam3); break;

				case 1: func_75(joaat("sp1_money_spent_in_clothes"), iParam3); break;

				case 2: func_75(joaat("sp2_money_spent_in_clothes"), iParam3); break;
				}
				break;

			case joaat("hairdo_shop_sp"):
				switch (iParam0) {
				case 0: func_75(joaat("sp0_money_spent_on_hairdos"), iParam3); break;

				case 1: func_75(joaat("sp1_money_spent_on_hairdos"), iParam3); break;

				case 2: func_75(joaat("sp2_money_spent_on_hairdos"), iParam3); break;
				}
				if (func_59(0)) {
					fVar0 = 0f;
					iVar1 = 0;
				}
				break;

			case joaat("gunclub_shop"):
				switch (iParam0) {
				case 0: func_75(joaat("sp0_money_spent_in_buying_guns"), iParam3); break;

				case 1: func_75(joaat("sp1_money_spent_in_buying_guns"), iParam3); break;

				case 2: func_75(joaat("sp2_money_spent_in_buying_guns"), iParam3); break;
				}
				break;

			case joaat("carmod_shop"):
				switch (iParam0) {
				case 0: func_75(joaat("sp0_money_spent_car_mods"), iParam3); break;

				case 1: func_75(joaat("sp1_money_spent_car_mods"), iParam3); break;

				case 2: func_75(joaat("sp2_money_spent_car_mods"), iParam3); break;
				}
				func_58(iParam3);
				break;
			}
			break;
		}
		break;

	case 1:
		switch (iParam0) {
		case 0: func_76(95, iParam3); break;

		case 1: func_76(97, iParam3); break;

		case 2: func_76(96, iParam3); break;
		}
		func_76(98, iParam3);
		break;
	}
	iVar2 = iParam0;
	iParam3 = system::floor(fVar0 * system::to_float(iParam3));
	iVar3 = 0;
	iVar4 = iParam3;
	if (fVar0 == 0f) {
		func_55(iVar1);
		return 1;
	}
	else if (fVar0 != 1f) {
		func_55(iVar1);
	}
	iVar5 = Global_52996[iVar2] + iParam3;
	switch (iParam1) {
	case 1:
		if (Global_52996[iVar2] >= 0 && iParam3 > 0) {
			if (iVar5 <= 0) {
				Global_52996[iVar2] = 2147483647;
			}
			else {
				Global_52996[iVar2] += iParam3;
			}
		}
		switch (iParam0) {
		case 0: func_75(joaat("sp0_total_cash_earned"), iParam3); break;

		case 1: func_75(joaat("sp1_total_cash_earned"), iParam3); break;

		case 2: func_75(joaat("sp2_total_cash_earned"), iParam3); break;
		}
		break;

	case 0:
		if (!iParam4) {
			if (Global_52996[iVar2] - iParam3 < 0) {
				return 0;
			}
		}
		iVar3 = Global_52996[iVar2];
		Global_52996[iVar2] -= iParam3;
		if (iParam4) {
			iVar4 = iVar3;
		}
		break;
	}
	if (iParam2 == 1) {
		if (iVar4 > 20) {
		}
	}
	else {
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/] = iParam1;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_1 =
			iParam2;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_2 =
			iParam3;
		Global_101700.f_19523.f_233[iVar2 /*69*/]++;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_1++;
		if (Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 > 10) {
			Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 = 0;
		}
	}
	func_54(iParam0);
	if (Global_35781 == 15) {
		func_53(0);
	}
	return 1;
}

// Position - 0x2D3E
void func_53(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x2FC0
void func_54(int iParam0) {
	int iVar0;

	iVar0 = Global_52996[iParam0];
	switch (iParam0) {
	case 0: stats::stat_set_int(joaat("sp0_total_cash"), iVar0, 1); break;

	case 1: stats::stat_set_int(joaat("sp1_total_cash"), iVar0, 1); break;

	case 2: stats::stat_set_int(joaat("sp2_total_cash"), iVar0, 1); break;
	}
}

// Position - 0x301A
void func_55(int iParam0) {
	bool bVar0;
	char cVar1[64];

	bVar0 = false;
	if (!network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0)) {
			bVar0 = true;
			gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		}
	}
	else if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0) ||
			 gameplay::is_bit_set(Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0)) {
		bVar0 = true;
		gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		gameplay::clear_bit(&Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0);
	}
	if (bVar0) {
		StringCopy(&cVar1, "CHAR_LIFEINVADER", 64);
		ui::_set_notification_text_entry("COUP_RED");
		ui::add_text_component_substring_text_label(func_56(iParam0));
		ui::_set_notification_message(&cVar1, &cVar1, 1, 0, "", 0);
	}
}

// Position - 0x30DC
char *func_56(int iParam0) {
	switch (iParam0) {
	case 0: return "COUP_HAIRC";

	case 1: return "COUP_TATTOO";

	case 2: return "COUP_WARSTOCK";

	case 3: return "COUP_MOSPORT";

	case 4: return "COUP_ELITAS";

	case 5: return "COUP_MEDSPENS";

	case 6: return "COUP_SPRUNK";

	case 7: return "COUP_RESPRAY";

	default:
	}
	return "";
}

// Position - 0x3156
int func_57() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x3163
void func_58(int iParam0) {
	func_76(93, iParam0);
	func_76(29, iParam0);
	func_76(30, iParam0);
}

// Position - 0x3183
bool func_59(int iParam0) {
	if (!network::network_is_game_in_progress()) {
		return gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0);
	}
	return gameplay::is_bit_set(Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0);
}

// Position - 0x31BF
int func_60(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (player::has_achievement_been_passed(27)) {
		return 0;
	}
	if (stats::stat_get_int(joaat("sp0_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp1_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp2_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (iParam0) {
	}
	iVar2 = 0;
	stats::stat_get_int(joaat("num_cash_spent"), &iVar2, -1);
	if (iVar1 > 0 && iVar2 / 2000000 != iVar1 / 2000000) {
		stats::stat_set_int(joaat("num_cash_spent"), iVar1, 1);
		func_74(27, iVar1);
	}
	if (iVar1 < 200000000) {
		return 0;
	}
	func_61(27, 1);
	return 1;
}

// Position - 0x3276
int func_61(int iParam0, int iParam1) {
	if (iParam0 >= 70) {
		return 0;
	}
	return func_62(iParam0, iParam1);
}

// Position - 0x3291
int func_62(int iParam0, int iParam1) {
	if (func_12(14) && !func_73(iParam0)) {
		return 0;
	}
	if (player::has_achievement_been_passed(iParam0) && iParam1 == 1) {
		return 0;
	}
	if (Global_25436 != 0 && !Global_69702) {
		return 0;
	}
	if (func_72(&Global_2595550)) {
		if (func_70(&Global_2595550, iParam0)) {
			return 0;
		}
		if (func_63(&Global_2595550, iParam0)) {
			return 1;
		}
	}
	else {
		if (!player::give_achievement_to_player(iParam0)) {
			return 0;
		}
		if (player::has_achievement_been_passed(iParam0)) {
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x332E
bool func_63(var *uParam0, int iParam1) {
	int iVar0;
	var *uVar1[70];

	if (player::has_achievement_been_passed(iParam1)) {
		return false;
	}
	if (func_12(14) && !func_73(iParam1)) {
		return false;
	}
	if (func_70(uParam0, iParam1)) {
		return false;
	}
	if (func_69(uParam0) < 0f) {
		func_68(uParam0, 0);
	}
	func_66(&uVar1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0 - 1) {
		uVar1[iVar0 + 1] = (*uParam0)[iVar0];
		iVar0++;
	}
	func_64(&uVar1, iParam1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = uVar1[iVar0];
		iVar0++;
	}
	return true;
}

// Position - 0x33DF
int func_64(var *uParam0, int iParam1) {
	int iVar0;

	if (player::has_achievement_been_passed(iParam1)) {
		return 0;
	}
	if (func_12(14) && !func_73(iParam1)) {
		return 0;
	}
	if (func_70(uParam0, iParam1)) {
		return 0;
	}
	if (func_69(uParam0) < 0f) {
		func_68(uParam0, 0);
	}
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (func_65(uParam0, iVar0)) {
			(*uParam0)[iVar0] = iParam1;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x345A
bool func_65(var *uParam0, int iParam1) { return (*uParam0)[iParam1] == 70; }

// Position - 0x346B
void func_66(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		func_67(uParam0, iVar0);
		iVar0++;
	}
	func_68(uParam0, Global_2595549 - 0.5f);
}

// Position - 0x349F
void func_67(var *uParam0, int iParam1) { (*uParam0)[iParam1] = 70; }

// Position - 0x34AF
void func_68(var *uParam0, float fParam1) {
	if (fParam1 == 0f) {
		uParam0->f_72 = 0f;
	}
	else {
		uParam0->f_72 = fParam1;
	}
}

// Position - 0x34CC
float func_69(var *uParam0) { return uParam0->f_72; }

// Position - 0x34D8
bool func_70(var *uParam0, int iParam1) { return func_71(uParam0, iParam1) != -1; }

// Position - 0x34EA
int func_71(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x3517
bool func_72(var *uParam0) { return uParam0->f_71 == 1; }

// Position - 0x3525
int func_73(int iParam0) {
	switch (iParam0) {
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69: return 1;

	default:
	}
	return 0;
}

// Position - 0x3575
int func_74(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x35C6
void func_75(int iParam0, int iParam1) {
	int iVar0;

	stats::stat_get_int(iParam0, &iVar0, -1);
	iVar0 += iParam1;
	stats::stat_set_int(iParam0, iVar0, 1);
}

// Position - 0x35E9
void func_76(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 < 1) {
		return;
	}
	if (Global_51564[iParam0 /*7*/].f_2) {
		return;
	}
	if (network::network_is_game_in_progress()) {
		return;
	}
	if (Global_51564[iParam0 /*7*/]) {
		stats::stat_get_int(Global_51564[iParam0 /*7*/].f_1, &iVar0, -1);
		iVar0 += iParam1;
		stats::stat_set_int(Global_51564[iParam0 /*7*/].f_1, iVar0, 1);
	}
}

// Position - 0x3646
void func_77() {
	int iVar0;

	if (network::network_is_signed_in()) {
		stats::stat_get_int(joaat("sp0_total_cash"), &iVar0, -1);
		if (Global_52996[0] != iVar0) {
			Global_52996[0] = iVar0;
		}
		stats::stat_get_int(joaat("sp1_total_cash"), &iVar0, -1);
		if (Global_52996[1] != iVar0) {
			Global_52996[1] = iVar0;
		}
		stats::stat_get_int(joaat("sp2_total_cash"), &iVar0, -1);
		if (Global_52996[2] != iVar0) {
			Global_52996[2] = iVar0;
		}
	}
}

// Position - 0x36BB
bool func_78(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x36CA
float func_79() {
	float fVar0;

	fVar0 = 0f;
	if (func_78(Global_101700.f_18922.f_1, 8192)) {
		fVar0 += 0.2f;
	}
	if (func_78(Global_101700.f_18922.f_1, 16384)) {
		fVar0 += 0.2f;
	}
	if (func_78(Global_101700.f_18922.f_1, 32768)) {
		fVar0 += 0.2f;
	}
	if (func_78(Global_101700.f_18922.f_1, 65536)) {
		fVar0 += 0.1f;
	}
	if (func_78(Global_101700.f_18922.f_1, 131072)) {
		fVar0 += 0.1f;
	}
	if (func_78(Global_101700.f_18922.f_1, 262144)) {
		fVar0 += 0.1f;
	}
	if (func_78(Global_101700.f_18922.f_1, 524288)) {
		fVar0 += 0.333f;
	}
	if (func_78(Global_101700.f_18922.f_1, 1048576)) {
		fVar0 += 0.333f;
	}
	if (func_78(Global_101700.f_18922.f_1, 2097152)) {
		fVar0 += 0.333f;
	}
	return fVar0;
}

// Position - 0x37E3
void func_80(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (!Global_55824) {
		Global_55824 = iParam1;
	}
	if (iParam0) {
		if (func_17(0) && Global_69948.f_1 == 1 && func_81(Global_69948)) {
		}
		else {
			Global_55822 = 1;
		}
	}
	if (Global_101700.f_8044 || func_17(0)) {
		iVar0 = func_16();
		iVar1 = Global_82576[iVar0 /*5*/];
		uVar2 = G_TextMessageConfig.f_109[iVar1 /*4*/];
		if (iVar0 == -1) {
			if (Global_101700.f_8044) {
			}
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 4)) {
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 5)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 4);
		gameplay::set_bit(&Global_69950, 1);
		Global_69966 = uVar2;
		Global_69967 = gameplay::get_game_timer();
	}
}

// Position - 0x38B9
int func_81(int iParam0) {
	switch (iParam0) {
	case 71: return 1;

	case 86: return 1;

	case 91: return 1;

	default: return 0;
	}
	return 0;
}

// Position - 0x38F7
void func_82() { func_470(&Global_101700.f_18922.f_1, 2048); }

// Position - 0x390F
void func_83(var *uParam0) {
	if (uParam0->f_1 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_1);
		uParam0->f_1 = 0;
	}
	if (uParam0->f_562 && uParam0->f_4 != 0) {
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_4);
		uParam0->f_4 = 0;
	}
	if (uParam0->f_564) {
		script::set_no_loading_screen(0);
		uParam0->f_564 = 0;
	}
	if (!Global_69970) {
		if (!player::is_player_dead(player::get_player_index())) {
			if (!G_TextMessageConfig) {
				if (cam::is_screen_faded_out() && !func_17(0)) {
					cam::do_screen_fade_in(800);
				}
			}
		}
	}
	func_84(0);
}

// Position - 0x39B6
void func_84(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x39CA
void func_85(var *uParam0) {
	if (uParam0->f_561 || uParam0->f_572 <= uParam0->f_558) {
		uParam0->f_561 = 0;
		uParam0->f_558 = uParam0->f_572 - 1;
	}
}

// Position - 0x39FD
void func_86(var *uParam0, float fParam1, int iParam2, int iParam3, int iParam4, float fParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char *sVar3;
	bool bVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	float fVar8;

	if (cam::is_screen_fading_out() || cam::is_screen_fading_in() || cam::is_screen_faded_out() ||
		gameplay::is_frontend_fading()) {
		if (!iParam3) {
			return;
		}
	}
	if (!func_93(uParam0)) {
		return;
	}
	ui::hide_loading_on_fade_this_frame();
	graphics::_set_2d_layer(iParam2);
	if (!func_92(uParam0->f_1, 256) || func_92(uParam0->f_1, 8192) && controls::_0x6CD79468A1E595C6(2)) {
		graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
		graphics::_push_scaleform_movie_function_parameter_float(fParam1);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_MAX_WIDTH");
		graphics::_push_scaleform_movie_function_parameter_float(fParam5);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(*uParam0, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(func_92(uParam0->f_1, 4096));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar5 = 0;
		iVar6 = 0;
		while (iVar6 < uParam0->f_123) {
			switch (uParam0->f_2[iVar6 /*15*/].f_2) {
			case 0: bVar4 = true; break;

			case 1: bVar4 = controls::_is_input_disabled(2); break;

			case 2: bVar4 = !controls::_is_input_disabled(2); break;

			default: bVar4 = false; break;
			}
			if (bVar4) {
				if (graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT")) {
					graphics::_push_scaleform_movie_function_parameter_int(iVar5);
					iVar5++;
					iVar7 = 0;
					while (iVar7 < uParam0->f_2[iVar6 /*15*/].f_14) {
						iVar0 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/];
						iVar1 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/].f_1;
						iVar2 = gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_13, iVar7);
						if (!gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_12, iVar7)) {
							sVar3 = controls::get_control_instructional_button(iVar0, iVar1, iVar2);
						}
						else {
							sVar3 = controls::_0x80C2FD58D720C801(iVar0, iVar1, iVar2);
						}
						if (!gameplay::is_string_null_or_empty(sVar3)) {
							func_91(sVar3);
						}
						iVar7++;
					}
					if (!gameplay::is_string_null_or_empty(uParam0->f_2[iVar6 /*15*/])) {
						func_90(uParam0->f_2[iVar6 /*15*/]);
					}
					if (gameplay::is_pc_version()) {
						if (func_92(uParam0->f_1, 4096)) {
							if (uParam0->f_2[iVar6 /*15*/].f_1) {
								graphics::_push_scaleform_movie_function_parameter_bool(1);
								graphics::_push_scaleform_movie_function_parameter_int(
									uParam0->f_2[iVar6 /*15*/].f_3[0 /*2*/].f_1);
							}
							else {
								graphics::_push_scaleform_movie_function_parameter_bool(0);
								graphics::_push_scaleform_movie_function_parameter_int(-1);
							}
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar6++;
		}
		fVar8 = func_89(iParam4, func_89(func_92(uParam0->f_1, 32), 1f, 0f), -1f);
		graphics::_push_scaleform_movie_function(*uParam0, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_float(fVar8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(80f);
		graphics::_pop_scaleform_movie_function_void();
		func_88(&uParam0->f_1, 256);
		func_87(&uParam0->f_1, 128);
	}
	graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
}

// Position - 0x3CBD
void func_87(int *iParam0, int iParam1) { *iParam0 -= (*iParam0 & iParam1); }

// Position - 0x3CD2
void func_88(var *uParam0, int iParam1) { *uParam0 |= iParam1; }

// Position - 0x3CE3
float func_89(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x3CFA
void func_90(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x3D0C
void func_91(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x3D1A
bool func_92(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x3D29
int func_93(var *uParam0) {
	if (*uParam0 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			func_88(&uParam0->f_1, 1);
			return 1;
		}
	}
	return 0;
}

// Position - 0x3D50
bool func_94(var *uParam0, int iParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (gameplay::get_frame_count() == uParam0->f_574) {
		return uParam0->f_575;
	}
	uParam0->f_574 = gameplay::get_frame_count();
	if (!network::network_is_game_in_progress()) {
		if (ped::is_ped_dead_or_dying(player::get_player_ped(player::get_player_index()), 1)) {
			uParam0->f_575 = 1;
			return true;
		}
		if (ai::is_ped_being_arrested(player::get_player_ped(player::get_player_index()))) {
			uParam0->f_575 = 1;
			return true;
		}
	}
	if (!uParam0->f_564) {
		if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
			script::set_no_loading_screen(1);
			uParam0->f_564 = 1;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (!network::network_is_game_in_progress()) {
			if (player::is_special_ability_active(player::player_id())) {
				player::special_ability_deactivate(player::player_id());
			}
		}
	}
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(19);
	controls::disable_control_action(2, 19, 1);
	controls::disable_control_action(0, 37, 1);
	controls::disable_control_action(0, 21, 1);
	controls::disable_control_action(0, 28, 1);
	controls::disable_control_action(0, 29, 1);
	controls::disable_control_action(0, 171, 1);
	func_115();
	if (controls::_is_input_disabled(2)) {
		if (player::_is_player_cam_control_disabled() || cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			ui::_show_cursor_this_frame();
		}
	}
	Global_36331 = 1;
	if (!uParam0->f_563) {
		switch (func_14(player::get_player_ped(player::get_player_index()))) {
		case 1: graphics::_start_screen_effect("SuccessFranklin", 1000, 0); break;

		case 2: graphics::_start_screen_effect("SuccessTrevor", 1000, 0); break;

		default: graphics::_start_screen_effect("SuccessMichael", 1000, 0); break;
		}
		uParam0->f_563 = 1;
	}
	if (uParam0->f_558 == 0) {
		uParam0->f_558 = uParam0->f_572 + system::floor(15000f * fParam2);
	}
	if (iParam4 && uParam0->f_572 >= uParam0->f_558 - 1500) {
		uParam0->f_558 = uParam0->f_572 + 3000;
	}
	if (uParam0->f_560 == 0f) {
		uParam0->f_560 += func_114(30f);
		uParam0->f_560 += IntToFloat(uParam0->f_56) * func_114(25f);
		if (uParam0->f_56 > 0) {
			uParam0->f_560 += func_114(25f * 0.5f);
		}
		if (uParam0->f_549) {
			uParam0->f_560 += func_114(30f) - func_114(2f);
		}
	}
	iVar0 = 1;
	while (iVar0) {
		func_84(1);
		uParam0->f_572 += system::round(0f + 1000f * system::timestep());
		func_97(uParam0, fParam2, iParam3);
		if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 666) - 15000f * fParam2) {
			if (uParam0->f_30 < 1f) {
				uParam0->f_30 += 0f + 1f / 0.225f * system::timestep();
			}
		}
		uParam0->f_30 = func_96(uParam0->f_30, 0f, 1f);
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_565) {
					uParam0->f_565 = 0;
					uParam0->f_566 = 0;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_547 -= (0f + 1f / 1.215f * system::timestep());
			}
		}
		uParam0->f_547 = func_96(uParam0->f_547, 0f, 1f);
		if (uParam0->f_547 <= 0.7f && !uParam0->f_545 && uParam0->f_1 != 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_OUT");
			graphics::_pop_scaleform_movie_function_void();
			uParam0->f_546 = uParam0->f_572;
			uParam0->f_545 = 1;
		}
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_548 < 1f) {
					uParam0->f_548 += 0f + 1f / 0.3f * system::timestep();
				}
			}
		}
		uParam0->f_548 = func_96(uParam0->f_548, 0f, 1f);
		if (uParam0->f_562) {
			if (controls::_0x6CD79468A1E595C6(2)) {
				if (graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
					if (!uParam0->f_567) {
						func_95(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
					}
				}
			}
		}
		if (controls::is_control_just_pressed(2, 216) && uParam0->f_558 > uParam0->f_572 + 333) {
			if (!uParam0->f_566 && uParam0->f_56 != 0 && graphics::has_scaleform_movie_loaded(uParam0->f_4) &&
				IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (!uParam0->f_565) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					if (uParam0->f_572 > uParam0->f_558 - 5000) {
						uParam0->f_558 = uParam0->f_572 + 5000;
					}
				}
				else if (iParam5) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 0;
					uParam0->f_573 = 0.75f;
				}
				func_95(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
			}
		}
		if ((uParam0->f_565 || uParam0->f_566) && uParam0->f_56 != 0) {
			if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (uParam0->f_566 && !uParam0->f_565) {
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_559 = func_96(uParam0->f_559 + 1f / 0.3f * uParam0->f_573 * system::timestep(), 0f, 1f);
				uParam0->f_573 = func_96(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
			}
		}
		else {
			uParam0->f_559 = func_96(uParam0->f_559 - 1f / 0.3f * uParam0->f_573 * 0.01f * system::timestep(), 0f, 1f);
			uParam0->f_573 = func_96(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
		}
		if (uParam0->f_572 > uParam0->f_558) {
			if (uParam0->f_561) {
				if (!uParam0->f_567) {
					if (controls::is_control_just_pressed(2, 215)) {
						uParam0->f_561 = 0;
					}
				}
			}
			else if (uParam0->f_572 - uParam0->f_546 > 1000 && uParam0->f_545) {
				iVar0 = 0;
			}
		}
		uParam0->f_575 = !iVar0;
		if (iParam1) {
			system::wait(0);
		}
		else {
			if (!iVar0) {
				func_84(0);
			}
			return !iVar0;
		}
	}
	func_84(0);
	return true;
}

// Position - 0x43AA
void func_95(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_91(controls::get_control_instructional_button(2, 215, 1));
	func_90("ES_HELP");
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_push_scaleform_movie_function_parameter_int(215);
	}
	graphics::_pop_scaleform_movie_function_void();
	if (iParam1) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_91(controls::get_control_instructional_button(2, 216, 1));
		func_90("ES_XPAND");
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_push_scaleform_movie_function_parameter_int(216);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x446E
float func_96(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x4495
void func_97(var *uParam0, float fParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	float fVar18;
	float *fVar19;
	float fVar20;
	float fVar21;
	float fVar22;
	char cVar23[16];
	char cVar27[32];
	int iVar35;
	int iVar36;
	int iVar37;
	int iVar38;
	float fVar39;
	float fVar40;
	float fVar41;
	float fVar42;
	float fVar43;

	iVar0 = system::round(uParam0->f_547 * 255f);
	fVar1 = func_113() * 0.25f;
	if (graphics::has_scaleform_movie_loaded(uParam0->f_1)) {
		if (uParam0->f_30 >= 0f) {
			if (!uParam0->f_2) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "SHOW_MISSION_PASSED_MESSAGE");
				func_90(&uParam0->f_5);
				func_90(&uParam0->f_13);
				if (network::network_is_game_in_progress()) {
					graphics::_push_scaleform_movie_function_parameter_int(150);
				}
				else {
					graphics::_push_scaleform_movie_function_parameter_int(100);
				}
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_56);
				graphics::_push_scaleform_movie_function_parameter_bool(iParam2);
				graphics::_push_scaleform_movie_function_parameter_int(69);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_2 = 1;
			}
			if (uParam0->f_56 > 0 && !uParam0->f_3 && uParam0->f_572 > 600) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(0.15f);
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_3 = 1;
			}
		}
		func_112();
		graphics::draw_scaleform_movie_fullscreen(uParam0->f_1, 255, 255, 255, 255, 0);
	}
	fVar2 = uParam0->f_560 * uParam0->f_559 * (1f - uParam0->f_548);
	fVar3 = 0f;
	if (uParam0->f_567) {
		fVar3 = (0.1388889f + func_114(2f * 2f)) * uParam0->f_568 * (1f - uParam0->f_548);
		fVar2 += 3f * fVar3;
	}
	if (uParam0->f_548 != 0f) {
		fVar4 = 0f;
		if (fVar2 < fVar4) {
			fVar2 = fVar4;
		}
	}
	else {
		fVar5 = 0f;
		if (uParam0->f_30 >= 0.975f) {
			if (fVar2 < fVar5) {
				fVar2 = fVar5;
			}
		}
	}
	fVar1 = 0.3f * func_113();
	if (uParam0->f_12) {
		fVar1 = 0.5f;
	}
	fVar6 = *uParam0 * 2f;
	fVar7 = func_111(&uParam0->f_13);
	if (fVar6 < fVar7) {
		fVar6 = fVar7 + 3f * 0.006f;
	}
	if (graphics::_get_aspect_ratio(0) < 1.4f) {
		fVar6 *= 1.3f;
	}
	fVar7 = func_111(&uParam0->f_550);
	fVar8 = (0.119f + 0.05f) / func_113() / 2.5f;
	if ((uParam0->f_556 == 1 || uParam0->f_556 == 0) && uParam0->f_557 != 0) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (uParam0->f_556 == 3) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (fVar6 < fVar7 + 1.9f * fVar8) {
		fVar6 = fVar7 + 2f * fVar8;
	}
	fVar9 = 0.499f - fVar6 / 2f + 0.006f;
	fVar10 = 0.499f + fVar6 / 2f - 0.006f;
	controls::set_input_exclusive(2, 215);
	controls::set_input_exclusive(2, 216);
	controls::set_input_exclusive(2, 200);
	controls::disable_control_action(2, 200, 1);
	if (uParam0->f_562 || uParam0->f_567) {
		if (IntToFloat(uParam0->f_558) - 14000f * fParam1 < IntToFloat(uParam0->f_572) ||
			uParam0->f_567 && uParam0->f_559 > 0.95f && uParam0->f_558 - 10000 < uParam0->f_572) {
			if (uParam0->f_567) {
				if (uParam0->f_570 < 0) {
					uParam0->f_570 *= -1;
					uParam0->f_570 = uParam0->f_572 + uParam0->f_570;
				}
				if (uParam0->f_570 > 0) {
					if (uParam0->f_570 - uParam0->f_572 > 0) {
						func_34(uParam0->f_570 - uParam0->f_572, "TIMER_TIME", 0, 0, -1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0,
								0, 0);
					}
					else {
						uParam0->f_570 = 0;
						uParam0->f_569 = 1;
						uParam0->f_567 = 0;
						uParam0->f_561 = 0;
						uParam0->f_562 = 0;
						uParam0->f_558 = uParam0->f_572 + 500;
						uParam0->f_570 = 0;
					}
				}
				if (uParam0->f_568 < 1f) {
					uParam0->f_568 += 0f + 1f / 0.166f * system::timestep();
					if (uParam0->f_568 > 1f) {
						uParam0->f_568 = 1f;
					}
				}
			}
			if (cam::is_screen_faded_out()) {
				ui::hide_loading_on_fade_this_frame();
			}
			if (uParam0->f_4 != 0 && uParam0->f_548 < 0.1f && uParam0->f_572 <= uParam0->f_558) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				graphics::draw_scaleform_movie_fullscreen(uParam0->f_4, 255, 255, 255, iVar0, 0);
			}
			if (uParam0->f_567) {
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				controls::disable_control_action(2, 188, 1);
				if (controls::is_disabled_control_just_pressed(2, 188)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 3;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 187, 1);
				if (controls::is_disabled_control_just_pressed(2, 187)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 4;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 202, 1);
				if (controls::is_disabled_control_just_pressed(2, 202)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 2;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
			else if (uParam0->f_562) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_562 = 0;
					uParam0->f_561 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
		}
	}
	ui::get_hud_colour(1, &iVar13, &iVar14, &iVar15, &iVar16);
	ui::set_text_colour(iVar13, iVar14, iVar15, iVar0);
	ui::set_text_wrap(fVar9, fVar10);
	ui::set_text_justification(0);
	ui::set_text_scale(1f, 0.4f);
	fVar1 -= func_114(6f);
	fVar1 += func_114(30f) - func_114(2f * 2f);
	fVar11 = fVar2 - func_114(2f * 14f);
	if (fVar11 >= 0f) {
		fVar12 = func_96(fVar11 / (0.6f * func_114(25f)), 0f, 1f);
		func_112();
		graphics::draw_rect(0.5f, fVar1 - (func_114(2f - 0.5f) - 0.001388889f), fVar6, func_110(1f), iVar13, iVar14,
							iVar15, system::round(fVar12 * IntToFloat(iVar16)), 0);
	}
	else {
		return;
	}
	fVar1 += func_114(2f * 0.3f);
	if (uParam0->f_56 > 0) {
		fVar1 += func_114(25f * 0.2f);
	}
	iVar17 = 0;
	iVar17 = 0;
	while (iVar17 < uParam0->f_56) {
		fVar11 = fVar2 - (fVar1 - 0.3f * func_113());
		if (fVar11 >= 0f) {
			fVar12 = func_96(fVar11 / (0.8f * func_114(25f)), 0f, 1f);
			func_107(uParam0, iVar17, fVar1 + func_114(2f), fVar9, fVar10, system::round(IntToFloat(iVar0) * fVar12));
		}
		else {
			return;
		}
		fVar1 += func_114(25f);
		iVar17++;
	}
	if (uParam0->f_56 > 0) {
		fVar1 += func_114(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_113());
		if (fVar11 >= 0f) {
			fVar1 += func_114(2f);
			fVar12 = func_96(fVar11 / (0.6f * func_114(25f)), 0f, 1f);
			func_112();
			graphics::draw_rect(0.5f, fVar1 + func_114(2f * 0.5f), fVar6, func_110(1f), iVar13, iVar14, iVar15,
								system::round(fVar12 * IntToFloat(iVar16)), 0);
		}
	}
	if (uParam0->f_549) {
		fVar1 += func_114(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_113());
		if (fVar11 >= 0f) {
			fVar12 = func_96(fVar11 / (0.8f * func_114(25f)), 0f, 1f);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			func_100(7, 0, 1, &fVar18, &fVar19, 0);
			fVar20 = fVar9;
			fVar21 = fVar10;
			if (unk::_get_current_language_id() == 0) {
				fVar20 = fVar9 + 0.119f / func_113() / 2.5f;
				fVar21 = fVar10 - 0.119f / func_113() / 2.5f;
				if (uParam0->f_556 == 1) {
					fVar20 = fVar9 + (0.119f + 0.05f) / func_113() / 2.5f;
					fVar21 = fVar10 - (0.119f + 0.05f) / func_113() / 2.5f;
				}
			}
			if (uParam0->f_557 == 0) {
				fVar20 += (fVar18 * 0.28f + 0.006f) / 2f;
				fVar21 += (fVar18 * 0.28f + 0.006f) / 2f;
			}
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(1);
			ui::set_text_scale(1f, 0.4f);
			func_99(&uParam0->f_550, fVar20, fVar1 + func_114(2f * 2f), 0, 0, 0);
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(2);
			ui::set_text_scale(1f, 0.4f);
			ui::set_text_centre(0);
			func_112();
			fVar22 = fVar21;
			StringCopy(&cVar23, "MPHud", 16);
			StringCopy(&cVar27, "MissionPassedMedal", 32);
			fVar22 -= (fVar18 * 0.28f + 0.006f);
			ui::set_text_wrap(fVar20, fVar22);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			switch (uParam0->f_556) {
			case 0:
				ui::begin_text_command_display_text("PERCENTAGE");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_114(2f * 2f), 0);
				break;

			case 1:
				ui::begin_text_command_display_text("FO_TWO_NUM");
				ui::add_text_component_integer(uParam0->f_554);
				ui::add_text_component_integer(uParam0->f_555);
				ui::end_text_command_display_text(fVar20, fVar1 + func_114(2f * 2f), 0);
				break;

			case 2:
				ui::begin_text_command_display_text("MTPHPER_XPNO");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_114(2f * 2f), 0);
				break;

			case 3:
				ui::begin_text_command_display_text("ESDOLLA");
				ui::add_text_component_formatted_integer(uParam0->f_554, 1);
				ui::end_text_command_display_text(fVar20, fVar1 + func_114(2f * 2f), 0);
				break;
			}
			if (uParam0->f_557 != 0) {
				iVar35 = 255;
				iVar36 = 255;
				iVar37 = 255;
				iVar38 = iVar0;
				switch (uParam0->f_557) {
				case 1: ui::get_hud_colour(107, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 3: ui::get_hud_colour(109, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 2: ui::get_hud_colour(108, &iVar35, &iVar36, &iVar37, &iVar38); break;
				}
				fVar39 = 0.001388889f * 5f;
				fVar40 = 0.00078125f * 16f * 2f;
				fVar41 = 0.001388889f * 16f * 2f;
				fVar42 = fVar21 + func_98(4f) - 0.006f;
				fVar43 = fVar1 + func_114(10f) + fVar39;
				if (uParam0->f_556 == -1) {
					fVar42 -= 0.006f * 6f;
				}
				fVar40 *= 0.65f;
				fVar41 *= 0.65f;
				graphics::draw_sprite(&cVar23, &cVar27, fVar42, fVar43, fVar40, fVar41, 0f, iVar35, iVar36, iVar37,
									  system::round(fVar12 * IntToFloat(iVar0)), 0);
			}
			fVar1 += func_114(30f) - 2f;
		}
	}
}

// Position - 0x4FE7
float func_98(float fParam0) { return fParam0 * 0.00078125f; }

// Position - 0x4FF7
void func_99(char *sParam0, float fParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	ui::set_text_centre(iParam3);
	ui::set_text_font(iParam5);
	func_112();
	if (iParam4) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam0);
	}
	else {
		ui::begin_text_command_display_text(sParam0);
	}
	ui::end_text_command_display_text(fParam1, fParam2, 0);
}

// Position - 0x5034
int func_100(int iParam0, int iParam1, int iParam2, float fParam3, float *fParam4, int iParam5) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	float fVar36;
	vector3 vVar37;

	StringCopy(&cVar0, func_106(iParam0), 64);
	StringCopy(&cVar16, func_103(iParam0, iParam1), 64);
	if (gameplay::get_hash_key(&cVar16) != 0) {
		fVar34 = 1f;
		if (iParam5) {
			graphics::_get_active_screen_resolution(&iVar32, &iVar33);
			fVar35 = graphics::_get_aspect_ratio(0);
			if (func_102()) {
				iVar32 = system::round(system::to_float(iVar33) * fVar35);
			}
			fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
			fVar34 = fVar36 / fVar35;
			if (func_102()) {
				fVar34 = 1f;
			}
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
				graphics::get_screen_resolution(&iVar32, &iVar33);
			}
			iVar32 = system::round(system::to_float(iVar32) / fVar34);
			iVar33 = system::round(system::to_float(iVar33) / fVar34);
		}
		else {
			graphics::get_screen_resolution(&iVar32, &iVar33);
		}
		vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
		vVar37.x *= func_101(iParam0) / fVar34;
		vVar37.y *= func_101(iParam0) / fVar34;
		if (!iParam2) {
			vVar37.x -= 2f;
			vVar37.y -= 2f;
		}
		if (iParam0 == 30) {
			vVar37.x = 288f;
			vVar37.y = 106f;
		}
		if (iParam0 == 29 && gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
			vVar37.x = 106f;
			vVar37.y = 106f;
		}
		*fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
		*fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) * *fParam3;
		if (!iParam5) {
			if (!graphics::get_is_widescreen() && iParam0 != 30) {
				*fParam3 *= 1.33f;
			}
		}
		if (iParam0 == 29) {
			if (*fParam3 > Global_17289) {
				*fParam4 *= Global_17289 / *fParam3;
				*fParam3 = Global_17289;
			}
		}
		return 1;
	}
	return 0;
}

// Position - 0x51E5
float func_101(int iParam0) {
	switch (iParam0) {
	case 33:
	case 4:
	case 11:
	case 31:
	case 20:
	case 15:
	case 10:
	case 12:
	case 13:
	case 32:
	case 9:
	case 5:
	case 6:
	case 7:
	case 14:
	case 18:
	case 19:
	case 17:
	case 28:
	case 26:
	case 27:
	case 49: return 0.5f;
	}
	return 1f;
}

// Position - 0x5284
bool func_102() {
	int iVar0;
	int iVar1;
	float fVar2;

	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (fVar2 > 3.5f) {
		return true;
	}
	return false;
}

// Position - 0x52B6
var func_103(int iParam0, int iParam1) {
	char *sVar0[2];
	var uVar3;
	struct<13> Var19;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_6703[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) == -1487683087) {
			Var19 = {func_105(player::player_id())};
			if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
				return func_104(&uVar3);
			}
		}
		else {
			return func_104(&Global_17290.f_6703[iParam0 /*16*/]);
		}
	}
	switch (iParam0) {
	case 3:
		sVar0[0] = "MP_hostCrown";
		sVar0[1] = "MP_hostCrown";
		break;

	case 21:
		sVar0[0] = "MP_SpecItem_Coke";
		sVar0[1] = "MP_SpecItem_Coke";
		break;

	case 22:
		sVar0[0] = "MP_SpecItem_Heroin";
		sVar0[1] = "MP_SpecItem_Heroin";
		break;

	case 23:
		sVar0[0] = "MP_SpecItem_Weed";
		sVar0[1] = "MP_SpecItem_Weed";
		break;

	case 24:
		sVar0[0] = "MP_SpecItem_Meth";
		sVar0[1] = "MP_SpecItem_Meth";
		break;

	case 25:
		sVar0[0] = "MP_SpecItem_Cash";
		sVar0[1] = "MP_SpecItem_Cash";
		break;

	case 1:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 2:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 4:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 6:
		sVar0[0] = "Shop_Box_CrossB";
		sVar0[1] = "Shop_Box_Cross";
		break;

	case 7:
		sVar0[0] = "Shop_Box_BlankB";
		sVar0[1] = "Shop_Box_Blank";
		break;

	case 5:
		sVar0[0] = "Shop_Box_TickB";
		sVar0[1] = "Shop_Box_Tick";
		break;

	case 8:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 9:
		sVar0[0] = "Shop_Clothing_Icon_B";
		sVar0[1] = "Shop_Clothing_Icon_A";
		break;

	case 10:
		sVar0[0] = "Shop_GunClub_Icon_B";
		sVar0[1] = "Shop_GunClub_Icon_A";
		break;

	case 17:
		sVar0[0] = "Shop_Ammo_Icon_B";
		sVar0[1] = "Shop_Ammo_Icon_A";
		break;

	case 18:
		sVar0[0] = "Shop_Armour_Icon_B";
		sVar0[1] = "Shop_Armour_Icon_A";
		break;

	case 19:
		sVar0[0] = "Shop_Health_Icon_B";
		sVar0[1] = "Shop_Health_Icon_A";
		break;

	case 20:
		sVar0[0] = "Shop_MakeUp_Icon_B";
		sVar0[1] = "Shop_MakeUp_Icon_A";
		break;

	case 11:
		sVar0[0] = "Shop_Tattoos_Icon_B";
		sVar0[1] = "Shop_Tattoos_Icon_A";
		break;

	case 12:
		sVar0[0] = "Shop_Garage_Icon_B";
		sVar0[1] = "Shop_Garage_Icon_A";
		break;

	case 13:
		sVar0[0] = "Shop_Garage_Bike_Icon_B";
		sVar0[1] = "Shop_Garage_Bike_Icon_A";
		break;

	case 14:
		sVar0[0] = "Shop_Barber_Icon_B";
		sVar0[1] = "Shop_Barber_Icon_A";
		break;

	case 15:
		sVar0[0] = "shop_Lock";
		sVar0[1] = "shop_Lock";
		break;

	case 16:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 26:
		sVar0[0] = "arrowleft";
		sVar0[1] = "arrowleft";
		break;

	case 27:
		sVar0[0] = "arrowright";
		sVar0[1] = "arrowright";
		break;

	case 28:
		sVar0[0] = "MP_AlertTriangle";
		sVar0[1] = "MP_AlertTriangle";
		break;

	case 29:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 31:
		sVar0[0] = "Shop_Michael_Icon_B";
		sVar0[1] = "Shop_Michael_Icon_A";
		break;

	case 32:
		sVar0[0] = "Shop_Franklin_Icon_B";
		sVar0[1] = "Shop_Franklin_Icon_A";
		break;

	case 33:
		sVar0[0] = "Shop_Trevor_Icon_B";
		sVar0[1] = "Shop_Trevor_Icon_A";
		break;

	case 48:
		sVar0[0] = "SaleIcon";
		sVar0[1] = "SaleIcon";
		break;

	case 49:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 0:
		sVar0[0] = "";
		sVar0[1] = "";
		break;
	}
	if (iParam1) {
		return sVar0[0];
	}
	return sVar0[1];
}

// Position - 0x56EB
var func_104(var uParam0) { return uParam0; }

// Position - 0x56F5
struct<13> func_105(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

// Position - 0x570C
char *
func_106(int iParam0) {
	var uVar0;
	struct<13> Var16;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5886[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) == -1487683087) {
			Var16 = {func_105(player::player_id())};
			network::_0x5835D9CD92E83184(&Var16, &uVar0);
			return func_104(&uVar0);
		}
		else {
			return func_104(&Global_17290.f_5886[iParam0 /*16*/]);
		}
	}
	if (iParam0 == 48) {
		return "MPShopSale";
	}
	return "CommonMenu";
}

// Position - 0x5781
void func_107(var *uParam0, int iParam1, float fParam2, float fParam3, float fParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uVar3);
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	ui::set_text_wrap(fParam3, fParam4);
	ui::set_text_justification(1);
	ui::set_text_scale(1f, func_109(14f));
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_112();
	if (uParam0->f_531[iParam1]) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(&uParam0->f_71[iParam1 /*16*/]);
	}
	else {
		ui::begin_text_command_display_text(&uParam0->f_71[iParam1 /*16*/]);
		if (uParam0->f_57[iParam1] == 16 || uParam0->f_57[iParam1] == 17) {
			ui::add_text_component_integer(uParam0->f_489[iParam1]);
		}
	}
	ui::end_text_command_display_text(fParam3, fParam2, 0);
	fVar4 = fParam4;
	switch (uParam0->f_517[iParam1]) {
	case 0: break;

	case 1:
		func_100(7, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_103(7, 0), fParam4 - 0.006f, fParam2 + func_114(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 2:
		func_100(5, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_103(5, 0), fParam4 - 0.006f, fParam2 + func_114(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 3:
		func_100(6, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_103(6, 0), fParam4 - 0.006f, fParam2 + func_114(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;
	}
	if (uParam0->f_57[iParam1] == 0) {
		return;
	}
	if (uParam0->f_57[iParam1] == 15) {
		ui::set_text_justification(1);
	}
	else {
		ui::set_text_justification(2);
	}
	ui::set_text_scale(1f, func_109(14f));
	if (uParam0->f_57[iParam1] == 5 || uParam0->f_57[iParam1] == 4) {
		ui::set_text_wrap(fParam3, fVar4 - 0.00078125f * 3f);
	}
	else {
		ui::set_text_wrap(fParam3, fVar4 + 0.00078125f * 2f);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	func_108(uParam0->f_489[iParam1], uParam0->f_503[iParam1], fParam4, fParam2, &uParam0->f_280[iParam1 /*16*/],
			 uParam0->f_57[iParam1]);
}

// Position - 0x5A0C
void func_108(int iParam0, int iParam1, float fParam2, float fParam3, char *sParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = 1;
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_112();
	fVar1 = 0f;
	fVar2 = 8f * 0.00078125f;
	fVar3 = 16f * 0.001388889f;
	iVar4 = 93;
	iVar5 = 182;
	iVar6 = 229;
	if (iParam5 == 4) {
		iVar4 = 194;
		iVar5 = 80;
		iVar6 = 80;
	}
	switch (iParam5) {
	case 4:
	case 5:
		ui::set_text_scale(1f, func_109(18f));
		ui::set_text_font(4);
		if (iParam0 < 0) {
			ui::_begin_text_command_width("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		else {
			ui::_begin_text_command_width("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		fVar1 -= fVar1 % 0.00078125f;
		graphics::draw_sprite("CommonMenu", "BettingBox_Left", fParam2 - fVar1,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Centre", fParam2 - fVar1 * 0.5f - 0.00078125f * 2f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar1 - fVar2 * 0.5f, fVar3, 0f, iVar4, iVar5,
							  iVar6, 255, 0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Right", fParam2 - 0.00078125f * 4f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		ui::set_text_scale(1f, func_109(14f));
		break;
	}
	ui::_set_notification_color_next(iVar0);
	switch (iParam5) {
	case 11:
		ui::begin_text_command_display_text("PERCENTAGE");
		ui::add_text_component_integer(iParam0);
		break;

	case 1:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_NUM");
		ui::add_text_component_integer(iParam0);
		break;

	case 2:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_TWO_NUM");
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 4:
	case 5: ui::set_text_scale(1f, func_109(18f));

	case 3:
		if (iParam0 < 0) {
			ui::begin_text_command_display_text("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
		}
		else {
			ui::begin_text_command_display_text("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
		}
		break;

	case 6: ui::begin_text_command_display_text(sParam4); break;

	case 7:
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam4);
		break;

	case 8:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 14);
		break;

	case 9:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 6);
		break;

	case 10:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 18:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 12:
		ui::begin_text_command_display_text("AHD_DIST");
		ui::add_text_component_integer(iParam0);
		break;

	case 13:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 15:
	case 14:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 16:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam1);
		break;
	}
	if (iParam5 != 17) {
		if (iParam5 == 4 || iParam5 == 5) {
			ui::end_text_command_display_text(fParam2 - 0.00078125f * 4f, fParam3, 0);
			ui::set_text_scale(1f, func_109(14f));
		}
		else {
			ui::end_text_command_display_text(fParam2, fParam3, 0);
		}
	}
}

// Position - 0x5D85
float func_109(float fParam0) { return fParam0 * 0.025f; }

// Position - 0x5D95
float func_110(float fParam0) { return fParam0 * 0.0009259259f; }

// Position - 0x5DA5
float func_111(char *sParam0) {
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1) / 2f;
}

// Position - 0x5DBA
void func_112() {
	graphics::_set_2d_layer(1);
	if (cam::is_screen_fading_out() || cam::is_screen_faded_out()) {
		graphics::_set_2d_layer(7);
	}
	graphics::_0xC6372ECD45D73BCD(0);
}

// Position - 0x5DE2
float func_113() {
	float fVar0;

	fVar0 = 1f;
	if (gameplay::is_pc_version()) {
	}
	return fVar0;
}

// Position - 0x5DF6
float func_114(float fParam0) { return fParam0 * 0.001388889f; }

// Position - 0x5E06
void func_115() {
	if (Global_14443.f_1 != 1) {
		if (func_118(0)) {
			func_116(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x5E2E
void func_116(int iParam0) {
	if (Global_14604) {
		func_117(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_25()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x5E9E
void func_117(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_118(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x5F12
bool func_118(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x5F6C
void func_119(int iParam0) {
	if (iParam0) {
		func_120();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_118(0)) {
			func_116(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x5FCF
void func_120() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x5FF8
int func_121(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;

	if (*uParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	if (iParam5 == 1) {
		iVar0 = 1;
	}
	iVar1 = uParam0->f_123;
	if (iVar1 < 8) {
		uParam0->f_2[iVar1 /*15*/] = sParam1;
		uParam0->f_2[iVar1 /*15*/].f_1 = iVar0;
		uParam0->f_2[iVar1 /*15*/].f_2 = iParam6;
		uParam0->f_2[iVar1 /*15*/].f_12 = 0;
		uParam0->f_2[iVar1 /*15*/].f_13 = 0;
		uParam0->f_2[iVar1 /*15*/].f_14 = 0;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/] = iParam2;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
		if (iParam4 == 1) {
			gameplay::set_bit(&uParam0->f_2[iVar1 /*15*/].f_13, 0);
		}
		uParam0->f_2[iVar1 /*15*/].f_14++;
		uParam0->f_123++;
		return 1;
	}
	return 0;
}

// Position - 0x60C1
void func_122(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (*uParam0 == 0) {
		*uParam0 = graphics::request_scaleform_movie_instance("instructional_buttons");
	}
	uParam0->f_1 = 0;
	uParam0->f_123 = 0;
	if (iParam1) {
		func_88(&uParam0->f_1, 32);
	}
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		func_88(&uParam0->f_1, 1);
		if (iParam2) {
			graphics::set_scaleform_movie_to_use_system_time(*uParam0, 1);
		}
	}
	if (gameplay::is_pc_version()) {
		if (iParam3) {
			func_88(&uParam0->f_1, 4096);
		}
	}
	if (iParam4) {
		func_88(&uParam0->f_1, 8192);
	}
}

// Position - 0x613B
int func_123(var *uParam0, int iParam1, int iParam2) {
	uParam0->f_12 = iParam2;
	func_126(uParam0);
	func_125(uParam0);
	if (gameplay::are_strings_equal(&uParam0->f_550, "SPR_RESULT") ||
		gameplay::are_strings_equal(&uParam0->f_550, "") && uParam0->f_56 > 0) {
		uParam0->f_566 = 1;
	}
	if (network::network_is_game_in_progress()) {
		graphics::request_streamed_texture_dict("MPHud", 0);
	}
	if (uParam0->f_1 == 0) {
		graphics::request_streamed_texture_dict("CommonMenu", 0);
		graphics::request_streamed_texture_dict("MPLeaderboard", 0);
		graphics::request_streamed_texture_dict("MPHud", 0);
		uParam0->f_1 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
		uParam0->f_2 = 0;
		uParam0->f_3 = 0;
	}
	uParam0->f_4 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	if (iParam1) {
		while (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			   !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			   !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			   !graphics::has_streamed_texture_dict_loaded("MPHud")) {
			system::wait(0);
		}
		if (uParam0->f_562 || uParam0->f_567) {
			while (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				system::wait(0);
			}
		}
	}
	else {
		if (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			!graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			!graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			!graphics::has_streamed_texture_dict_loaded("MPHud")) {
			return 0;
		}
		if (uParam0->f_562) {
			if (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				return 0;
			}
		}
	}
	if (uParam0->f_562) {
		if (uParam0->f_567) {
			func_124(uParam0);
		}
		else if (uParam0->f_56 != 0) {
			func_95(uParam0, 1);
		}
		else {
			func_95(uParam0, 0);
		}
	}
	Global_69963 = 1;
	return 1;
}

// Position - 0x62DA
void func_124(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(2);
	func_91(controls::get_control_instructional_button(2, 188, 1));
	func_90("ES_HELP_TU");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(1);
	func_91(controls::get_control_instructional_button(2, 187, 1));
	func_90("ES_HELP_TD");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_91(controls::get_control_instructional_button(2, 202, 1));
	func_90("ES_HELP_AB");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x639F
void func_125(float *fParam0) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	fVar0 = 0f;
	ui::set_text_justification(0);
	ui::set_text_scale(1f, func_109(16f));
	if (fParam0->f_31 == 0) {
		if (fParam0->f_29) {
			ui::_begin_text_command_width("STRING");
			ui::add_text_component_substring_player_name(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
		else {
			ui::_begin_text_command_width(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
	}
	else {
		ui::_begin_text_command_width("STRING");
		iVar1 = 0;
		iVar2 = 0;
		iVar3 = 0;
		iVar3 = 0;
		while (iVar3 < fParam0->f_31) {
			switch (fParam0->f_32[iVar3]) {
			case 0:
				ui::add_text_component_integer(fParam0->f_53[iVar1]);
				iVar1++;
				break;

			case 1:
				ui::add_text_component_substring_text_label(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;

			case 2:
				ui::add_text_component_substring_player_name(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;
			}
			iVar3++;
		}
		fVar0 = ui::_end_text_command_get_width(1);
	}
	if (fVar0 > 0.1125f * 2f - 0.006f * 2f) {
		*fParam0 = fVar0 / 2f + 0.006f * 2f;
	}
}

// Position - 0x64A7
void func_126(var *uParam0) {
	uParam0->f_547 = 1f;
	uParam0->f_546 = 0;
	uParam0->f_568 = 0f;
	uParam0->f_558 = 0;
	uParam0->f_30 = 0f;
	uParam0->f_548 = 0f;
	uParam0->f_559 = 0f;
	uParam0->f_560 = 0f;
	uParam0->f_545 = 0;
	uParam0->f_563 = 0;
	uParam0->f_572 = 0;
	uParam0->f_564 = 0;
	uParam0->f_565 = 0;
	uParam0->f_566 = 0;
	*uParam0 = 0.1125f;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_574 = 0;
	uParam0->f_575 = 0;
	uParam0->f_573 = 1f;
}

// Position - 0x6526
void func_127() {
	int iVar0;
	int iVar1;

	if (!iLocal_139) {
		func_133(&uLocal_150, &Local_726, &Global_55837, 0);
		fLocal_134 *= 1000f;
		if (Global_86001) {
			func_132(&uLocal_150, 6, &Local_726.f_12, "MTPHPERSKI", system::floor(fLocal_134), 0, 3, 0);
			func_132(&uLocal_150, 6, &Local_726.f_24, "MTPHPERSKI", 0, 0, 3, 0);
			func_132(&uLocal_150, 6, &Local_726.f_30, "MTPHPERSKI", system::round(fLocal_136 + fLocal_135), 0, 3, 0);
			func_131();
		}
		else {
			if (bLocal_138) {
				func_132(&uLocal_150, 6, &Local_726.f_12, "MTPHPERRET", system::floor(fLocal_134), 0, 3, 0);
			}
			else {
				func_132(&uLocal_150, 9, &Local_726.f_12, "", system::floor(fLocal_134), 0, 0, 0);
			}
			if (!gameplay::is_string_null_or_empty(&Local_726.f_18)) {
				if (bLocal_137) {
					func_132(&uLocal_150, 6, &Local_726.f_24, "", 0, 0, 2, 0);
					func_132(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_136 + fLocal_135), 0, 2, 0);
				}
				else {
					func_132(&uLocal_150, 6, &Local_726.f_24, "", 0, 0, 1, 0);
					func_132(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_135), 0, 0, 0);
				}
			}
			else {
				func_132(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_135), 0, 0, 0);
			}
		}
		iVar0 = 0;
		if (Global_86001) {
			iVar1 = 0;
			while (iVar1 < Global_67917) {
				if (Global_67918[iVar1 /*9*/] >= 0 && !MissionObjectives[Global_67918[iVar1 /*9*/] /*13*/].f_7) {
					if (Global_67918[iVar1 /*9*/].f_3 == 2) {
						iVar0 = 1;
					}
				}
				iVar1++;
			}
		}
		if (iVar0 == 1) {
			iLocal_145 = 50;
			iLocal_146 = 1;
			func_130(&uLocal_150, 1, &Local_726.f_48, iLocal_145, 0, 0, 1);
		}
		else if (bLocal_137) {
			if (bLocal_138) {
				iLocal_145 = 75;
				iLocal_146 = 2;
				func_130(&uLocal_150, 1, &Local_726.f_42, iLocal_145, 0, 0, 2);
			}
			else {
				iLocal_145 = 100;
				iLocal_146 = 3;
				func_130(&uLocal_150, 1, &Local_726.f_36, iLocal_145, 0, 0, 3);
			}
		}
		else if (!bLocal_137 && !bLocal_138) {
			iLocal_145 = 75;
			iLocal_146 = 2;
			func_130(&uLocal_150, 1, &Local_726.f_42, iLocal_145, 0, 0, 2);
		}
		else {
			iLocal_145 = 50;
			iLocal_146 = 1;
			func_130(&uLocal_150, 1, &Local_726.f_48, iLocal_145, 0, 0, 1);
		}
		func_128();
		iLocal_139 = 1;
	}
}

// Position - 0x6760
void func_128() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_valet")) == 1) {
		func_129(38, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_129(39, 1, 1);
		}
		else {
			func_129(39, 0, 1);
		}
		if (bLocal_137) {
			func_129(40, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_129(40, system::round(fLocal_135), 1);
		}
		func_129(41, iLocal_145, 1);
		func_129(42, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_multi")) == 1) {
		func_129(52, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_129(53, 1, 1);
		}
		else {
			func_129(53, 0, 1);
		}
		if (bLocal_137) {
			func_129(56, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_129(56, system::round(fLocal_135), 1);
		}
		func_129(54, iLocal_145, 1);
		func_129(55, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_hooker")) == 1) {
		func_129(66, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_129(67, 1, 1);
		}
		else {
			func_129(67, 0, 1);
		}
		if (bLocal_137) {
			func_129(68, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_129(68, system::round(fLocal_135), 1);
		}
		func_129(69, iLocal_145, 1);
		func_129(70, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_bus")) == 1) {
		func_129(81, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_129(82, 1, 1);
		}
		else {
			func_129(82, 0, 1);
		}
		if (bLocal_137) {
			func_129(83, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_129(83, system::round(fLocal_135), 1);
		}
		func_129(84, iLocal_145, 1);
		func_129(85, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_construction")) == 1) {
		func_129(97, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_129(98, 1, 1);
		}
		else {
			func_129(98, 0, 1);
		}
		if (bLocal_137) {
			func_129(99, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_129(99, system::round(fLocal_135), 1);
		}
		func_129(100, iLocal_145, 1);
		func_129(101, iLocal_146, 1);
	}
}

// Position - 0x6984
void func_129(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_67917) {
		if (Global_67918[iVar0 /*9*/] == iParam0) {
			if (iParam2) {
				Global_67918[iVar0 /*9*/].f_1 = iParam1;
			}
			else {
				Global_67918[iVar0 /*9*/].f_1 += iParam1;
			}
			return;
		}
		iVar0++;
	}
	if (Global_67918[iVar0 /*9*/] != -1) {
		if (MissionObjectives[Global_67918[iVar0 /*9*/] /*13*/] == 3) {
			if (Global_67918[iVar0 /*9*/].f_1 > 1) {
				Global_67918[iVar0 /*9*/].f_1 = 1;
			}
			if (Global_67918[iVar0 /*9*/].f_1 < 0) {
				Global_67918[iVar0 /*9*/].f_1 = 0;
			}
		}
	}
}

// Position - 0x6A2E
void func_130(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	uParam0->f_549 = iParam1;
	StringCopy(&uParam0->f_550, sParam2, 16);
	uParam0->f_554 = iParam3;
	uParam0->f_555 = iParam4;
	uParam0->f_556 = iParam5;
	uParam0->f_557 = iParam6;
}

// Position - 0x6A62
void func_131() {
	Global_86000 = 0;
	Global_86001 = 0;
}

// Position - 0x6A74
void func_132(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	int iVar0;

	if (uParam0->f_56 == 13) {
		return;
	}
	iVar0 = uParam0->f_56;
	uParam0->f_57[iVar0] = iParam1;
	StringCopy(&uParam0->f_71[iVar0 /*16*/], sParam2, 64);
	StringCopy(&uParam0->f_280[iVar0 /*16*/], sParam3, 64);
	uParam0->f_489[iVar0] = iParam4;
	uParam0->f_503[iVar0] = iParam5;
	uParam0->f_517[iVar0] = iParam6;
	uParam0->f_531[iVar0] = iParam7;
	uParam0->f_56++;
}

// Position - 0x6AE7
void func_133(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	StringCopy(&uParam0->f_5, sParam1, 16);
	StringCopy(&uParam0->f_13, sParam2, 64);
	uParam0->f_29 = iParam3;
	uParam0->f_11 = 0;
}

// Position - 0x6B0A
void func_134() { func_470(&Global_101700.f_18922.f_1, 4194304); }

// Position - 0x6B23
void func_135() {
	float fVar0;

	fVar0 = 480000f;
	if (func_472() <= fVar0) {
		bLocal_137 = true;
		iLocal_1026 = 1;
	}
}

// Position - 0x6B46
void func_136(int *iParam0) {
	if (func_452(iParam0)) {
		if (!func_41(iParam0)) {
			iParam0->f_2 = func_40(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
			gameplay::set_bit(iParam0, 2);
		}
	}
}

// Position - 0x6B80
void func_137(int *iParam0, float fParam1) {
	uParam0->f_1 = func_40(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x6BAE
bool func_138(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	char *sVar2;

	switch (iLocal_1041) {
	case 1:
		if (func_466()) {
			iLocal_1041 = 4;
			break;
		}
		func_430(uParam1);
		break;

	case 4:
		uParam0->f_274 = 2;
		if (bLocal_1512 && !iLocal_1514) {
			iLocal_1555 = Global_91491.f_12[0];
			if (iLocal_1551 == 0) {
				iLocal_1539 = 0;
				fLocal_1559 = fLocal_1559;
			}
			else if (iLocal_1551 == 1) {
				iLocal_1539 = 1;
				if (IntToFloat(iLocal_1555) < fLocal_1559 * 3f / 4f || iLocal_1528) {
					fLocal_1559 *= 3f / 4f;
				}
				else {
					fLocal_1559 = system::to_float(iLocal_1555);
				}
			}
			else if (iLocal_1551 == 2) {
				iLocal_1539 = 2;
				if (IntToFloat(iLocal_1555) < fLocal_1559 * 1f / 2f || iLocal_1528) {
					fLocal_1559 *= 1f / 2f;
				}
				else {
					fLocal_1559 = system::to_float(iLocal_1555);
				}
			}
			else if (iLocal_1551 == 3) {
				iLocal_1539 = 3;
				if (IntToFloat(iLocal_1555) < fLocal_1559 * 1f / 4f || iLocal_1528) {
					fLocal_1559 *= 1f / 4f;
				}
				else {
					fLocal_1559 = system::to_float(iLocal_1555);
				}
			}
			else if (iLocal_1551 == 4) {
				fLocal_1559 = 540000f;
			}
			func_37(&iLocal_1037);
			if (iLocal_1551 < 4) {
				iLocal_1460 = iLocal_1539;
			}
			iLocal_1514 = 1;
		}
		else if (!func_452(&iLocal_1037)) {
			func_37(&iLocal_1037);
			Global_101700.f_18922.f_6 = 0f;
		}
		if (iLocal_1551 < 4) {
			func_419(uParam0);
			func_418();
		}
		if (bLocal_1513) {
			func_411(uParam0, &uLocal_1929, 1);
			gameplay::clear_area(vLocal_1569, 5f, 1, 0, 0, 0);
			iVar1 = func_380(vLocal_1569, fLocal_1572);
			if (!vehicle::is_this_model_a_boat(entity::get_entity_model(iVar1)) &&
				!vehicle::is_this_model_a_plane(entity::get_entity_model(iVar1)) &&
				!vehicle::is_this_model_a_heli(entity::get_entity_model(iVar1))) {
				vehicle::set_vehicle_on_ground_properly(iVar1, 1084227584);
			}
			else {
				vehicle::delete_vehicle(&iVar1);
			}
		}
		else {
			func_411(uParam0, &uLocal_1929, 0);
		}
		if (iLocal_1460 == 0 && iLocal_1551 != 4) {
			func_379();
		}
		if (bLocal_1512) {
			func_376(0, -1, 1);
			if (cam::is_screen_faded_out()) {
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			}
		}
		func_375(500);
		if (iLocal_1551 < 4) {
			iLocal_1041 = 5;
		}
		else {
			player::clear_player_wanted_level(player::player_id());
			iLocal_1041 = 12;
		}
		break;

	case 5:
		if (func_361(uParam0, &uLocal_1929, 0) && func_350(uParam0)) {
			iLocal_1041 = 6;
		}
		break;

	case 6:
		system::settimera(0);
		func_338();
		func_277();
		iLocal_1555 = iLocal_1554;
		Global_91491.f_12[0] = iLocal_1555;
		if (!ui::does_blip_exist(uParam1->f_2)) {
			uParam1->f_2 = ui::add_blip_for_coord(uParam0->f_6);
			ui::set_blip_route(uParam1->f_2, 1);
			ui::set_blip_route_colour(uParam1->f_2, 1);
			ui::set_blip_colour(uParam1->f_2, 1);
		}
		iLocal_1041 = 7;
		break;

	case 7:
		func_276();
		if (!iLocal_1533) {
			if (system::timera() > 15000) {
				func_274();
				iLocal_1533 = 1;
			}
		}
		if (iLocal_1539 == 0) {
			func_260();
		}
		func_259(uParam0, uParam1);
		if (bLocal_1524) {
			func_258();
		}
		func_257();
		if (iLocal_1460 >= 2) {
			if (entity::does_entity_exist(iLocal_1574)) {
				if (func_256(iLocal_1574, player::player_ped_id(), 1) > 500f) {
					entity::set_vehicle_as_no_longer_needed(&iLocal_1574);
				}
			}
		}
		if (!iLocal_1535) {
			if (iLocal_1460 == 0) {
				if (func_255(uParam0->f_6, 1) < 400f || func_255(uParam0->f_1, 1) < 400f) {
					if (func_254(uParam0)) {
						func_249(uParam0, &Local_1044);
						func_247(uParam0, &Local_1044);
						iLocal_1535 = 1;
					}
				}
			}
			else if (iLocal_1460 == 1) {
				if (func_255(uParam0->f_6, 1) < 400f || func_255(uParam0->f_1, 1) < 400f) {
					if (func_246(uParam0)) {
						func_249(uParam0, &Local_1044);
						func_247(uParam0, &Local_1044);
						iLocal_1535 = 1;
					}
				}
			}
			else if (iLocal_1460 == 2) {
				if (func_255(uParam0->f_6, 1) < 400f || func_255(uParam0->f_1, 1) < 400f) {
					if (func_245(uParam0)) {
						func_249(uParam0, &Local_1044);
						func_247(uParam0, &Local_1044);
						iLocal_1535 = 1;
					}
				}
			}
			else if (iLocal_1460 == 3) {
				if (func_255(uParam0->f_6, 1) < 500f || func_255(uParam0->f_1, 1) < 500f) {
					if (func_244(uParam0)) {
						func_249(uParam0, &Local_1044);
						func_247(uParam0, &Local_1044);
						iLocal_1535 = 1;
					}
				}
			}
		}
		else if (func_243(&Local_1044, uParam0) || iLocal_1515 == 1 && iLocal_1460 == 2) {
			if (iLocal_1460 == 0) {
				func_241(1);
			}
			iLocal_1041 = 11;
		}
		else if (!func_240(&Local_1044)) {
			if (func_239(uParam0, uParam1) ||
				player::is_player_targetting_entity(player::player_id(), *uParam1) && func_238(*uParam1, 1) < 150f ||
				player::is_player_free_aiming_at_entity(player::player_id(), *uParam1) &&
					func_238(*uParam1, 1) < 150f) {
				func_237(*uParam1);
				iLocal_1041 = 10;
			}
			else if (iLocal_1460 == 0) {
				if (!iLocal_1518) {
					func_236(uParam0, uParam1);
				}
			}
			else if (iLocal_1460 == 1) {
				func_235(uParam1);
			}
		}
		else {
			iLocal_1517 = 1;
			func_237(*uParam1);
			iLocal_1041 = 10;
		}
		break;

	case 10:
		func_259(uParam0, uParam1);
		if (func_243(&Local_1044, uParam0) || iLocal_1515) {
			if (iLocal_1515 && !ped::is_ped_injured(*uParam1)) {
				func_233();
				audio::play_pain(*uParam1, 1, 0f, 0);
			}
			func_232(&iLocal_1793, 0, 0);
			if (!func_452(&uLocal_1601)) {
				func_37(&uLocal_1601);
			}
			else {
				func_38(&uLocal_1601);
			}
			if (iLocal_1460 == 0) {
				func_241(1);
			}
			func_231();
			system::settimera(0);
			iLocal_1041 = 11;
		}
		else {
			func_169(uParam0, &Local_1044);
		}
		break;

	case 11:
		if (iLocal_1460 == 0) {
			sVar2 = "OJAS_BDCOM";
		}
		else if (iLocal_1460 == 1) {
			sVar2 = "OJAS_YACOM";
		}
		else if (iLocal_1460 == 2) {
			sVar2 = "OJAS_WWCOM";
		}
		else if (iLocal_1460 == 3) {
			sVar2 = "OJAS_BICOM";
		}
		if (ui::does_blip_exist(uParam1->f_2)) {
			ui::remove_blip(&uParam1->f_2);
		}
		func_168(&iLocal_1536, &uParam1->f_16, "OJASAUD", sVar2, 9, 1, 0, 0);
		if (iLocal_1536 || system::timera() > 1000) {
			if (!ped::is_ped_injured(*uParam1) && iLocal_1460 == 2) {
				entity::set_entity_health(*uParam1, 0);
			}
			if (iLocal_1460 == 1) {
				if (!ped::is_ped_injured(uParam1->f_7)) {
					ai::open_sequence_task(&iVar0);
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_quick_f", 8f, -8f, -1,
									   0, 0, 0, 0, 0);
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_cower_loop_f", 1000f,
									   -8f, -1, 1, 0, 0, 0, 0);
					ai::close_sequence_task(iVar0);
					ai::task_perform_sequence(uParam1->f_7, iVar0);
					ai::clear_sequence_task(&iVar0);
				}
				if (entity::does_entity_exist(uParam1->f_1)) {
					if (vehicle::is_vehicle_driveable(uParam1->f_1, 0)) {
						vehicle::_0x02398B627547189C(uParam1->f_1, 0);
					}
				}
			}
			iLocal_1539++;
			if (iLocal_1539 >= 4) {
				iLocal_1041 = 12;
			}
			else {
				func_148(uParam0, &Local_1044);
				func_146(uParam0);
				iLocal_1041 = 4;
			}
		}
		break;

	case 12:
		if (player::get_player_wanted_level(player::player_id()) == 0) {
			if (func_143(uParam1)) {
				return true;
			}
		}
		else if (!iLocal_1029) {
			func_142("ASS_ML_COPS", 7500, 1);
			func_38(&iLocal_1607);
			iLocal_1029 = 1;
		}
		else if (func_139(&iLocal_1607, 2f)) {
			audio::play_police_report("SCRIPTED_SCANNER_REPORT_ASS_MULTI_01", 0f);
		}
		break;
	}
	return false;
}

// Position - 0x736B
bool func_139(int *iParam0, float fParam1) {
	if (func_141(iParam0, fParam1)) {
		func_140(iParam0);
		return true;
	}
	return false;
}

// Position - 0x7389
void func_140(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x739F
bool func_141(var *uParam0, float fParam1) {
	if (func_452(uParam0)) {
		if (func_39(uParam0) > fParam1) {
			return true;
		}
	}
	return false;
}

// Position - 0x73C1
void func_142(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 1);
}

// Position - 0x73DA
bool func_143(var *uParam0) {
	if (!func_452(&uLocal_1604)) {
		func_37(&uLocal_1604);
	}
	else {
		if (!iLocal_1529) {
			if (func_39(&uLocal_1604) > 5f) {
				func_32(&uParam0->f_16, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
				func_32(&uParam0->f_16, 3, 0, "LESTER", 0, 1);
				if (func_145(&uParam0->f_16, 12, "OJASAUD", "OJAS_MULTI_C", 14, 1, 0, 0, 0)) {
					iLocal_1529 = 1;
				}
			}
		}
		if (iLocal_1529 && func_144()) {
			return true;
		}
	}
	return false;
}

// Position - 0x7460
int func_144() {
	if (Global_15745 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x7477
bool func_145(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8) {
	func_31(uParam0, iParam1, sParam2, iParam6, iParam7, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	if (iParam5 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_2621441 = 0;
	return func_22(sParam3, iParam4, iParam8);
}

// Position - 0x74D6
void func_146(var *uParam0) {
	int iVar0;

	iLocal_1511 = 0;
	iLocal_1460 = iLocal_1539;
	iLocal_1461 = 0;
	iLocal_1042 = 0;
	Local_129.f_3 = 0;
	uParam0->f_5 = 0;
	uParam0->f_17 = 0;
	*uParam0 = 0;
	uParam0->f_1 = {func_147()};
	uParam0->f_4 = 0f;
	uParam0->f_14 = 0;
	uParam0->f_18 = {func_147()};
	uParam0->f_16 = 0;
	uParam0->f_22 = {func_147()};
	uParam0->f_25 = 0f;
	uParam0->f_17 = 0;
	uParam0->f_30 = {func_147()};
	uParam0->f_33 = 0f;
	uParam0->f_5 = 0;
	uParam0->f_9 = {func_147()};
	uParam0->f_12 = 0f;
	uParam0->f_6 = {func_147()};
	uParam0->f_271 = {func_147()};
	uParam0->f_13 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		uParam0->f_249[iVar0 /*3*/] = {func_147()};
		iVar0++;
	}
}

// Position - 0x7597
Vector3 func_147() {
	vector3 vVar0;

	return vVar0;
}

// Position - 0x75A3
void func_148(var *uParam0, int iParam1) {
	int iVar0;

	func_167();
	func_166();
	func_161(iParam1, uParam0);
	func_160(&uParam0->f_34);
	func_159(&uParam0->f_46);
	func_158(&uParam0->f_34);
	func_156(&uParam0->f_46);
	func_150(&uLocal_1929, 0);
	*iParam1 = 0;
	if (iLocal_1460 != 1) {
		entity::set_vehicle_as_no_longer_needed(&iParam1->f_1);
		if (entity::does_entity_exist(iLocal_1574)) {
			entity::set_vehicle_as_no_longer_needed(&iLocal_1574);
		}
	}
	else if (entity::does_entity_exist(iParam1->f_1)) {
		iLocal_1574 = iParam1->f_1;
	}
	if (entity::does_entity_exist(iLocal_1573)) {
		entity::set_vehicle_as_no_longer_needed(&iLocal_1573);
	}
	if (entity::does_entity_exist(iLocal_1576)) {
		entity::set_vehicle_as_no_longer_needed(&iLocal_1576);
	}
	if (entity::does_entity_exist(iLocal_1575)) {
		entity::set_vehicle_as_no_longer_needed(&iLocal_1575);
	}
	iLocal_1517 = 0;
	iLocal_1547 = 0;
	iLocal_143 = 0;
	iLocal_1520 = 0;
	iLocal_1519 = 0;
	iLocal_1515 = 0;
	iLocal_1533 = 0;
	iLocal_1541 = 0;
	iLocal_1536 = 0;
	iLocal_1535 = 0;
	iLocal_1537 = 0;
	iLocal_1531 = 0;
	iLocal_1538 = 0;
	iVar0 = 3;
	while (iVar0 <= 9) {
		func_149(&iParam1->f_16, iVar0);
		iVar0++;
	}
}

// Position - 0x769F
void func_149(var *uParam0, int iParam1) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
		(*uParam0)[iParam1 /*10*/].f_7 = 0;
	}
}

// Position - 0x76BC
void func_150(var *uParam0, int iParam1) {
	int iVar0;

	if (!iParam1) {
		func_152(uParam0);
	}
	iVar0 = 0;
	while (iVar0 < 15) {
		func_151(&(*uParam0)[iVar0 /*18*/]);
		iVar0++;
	}
	uParam0->f_271 = 0;
	uParam0->f_272 = -1;
	uParam0->f_273 = 1;
}

// Position - 0x76FF
void func_151(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_1 = -1;
	StringCopy(&uParam0->f_2, "NULL", 64);
}

// Position - 0x7718
void func_152(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 15) {
		if (gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 30)) {
			func_153(&(*uParam0)[iVar0 /*18*/]);
		}
		iVar0++;
	}
	uParam0->f_271 = 1;
}

// Position - 0x7752
void func_153(var *uParam0) { func_154(*uParam0, &uParam0->f_2, uParam0->f_1); }

// Position - 0x7769
void func_154(int iParam0, char *sParam1, int iParam2) {
	if (gameplay::is_bit_set(iParam0, 30)) {
		switch (func_155(iParam0)) {
		case 0: streaming::set_model_as_no_longer_needed(iParam2); break;

		case 1: streaming::remove_anim_dict(sParam1); break;

		case 2: streaming::remove_clip_set(sParam1); break;

		case 3: graphics::set_streamed_texture_dict_as_no_longer_needed(sParam1); break;

		case 4: vehicle::remove_vehicle_recording(iParam2, sParam1); break;

		case 5: ai::remove_waypoint_recording(sParam1); break;

		case 6: audio::release_script_audio_bank(); break;

		case 7: script::set_script_with_name_hash_as_no_longer_needed(iParam2); break;

		case 8: ui::clear_additional_text(iParam2, gameplay::is_bit_set(iParam0, 26)); break;

		case 9: streaming::remove_ptfx_asset(); break;

		default: break;
		}
	}
}

// Position - 0x7829
int func_155(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 10) {
		if (gameplay::is_bit_set(iParam0, iVar0)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x7855
void func_156(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = func_157();
		iVar0++;
	}
}

// Position - 0x787B
var func_157() {
	var uVar0;

	return uVar0;
}

// Position - 0x7885
void func_158(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x78A8
void func_159(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (!gameplay::is_string_null_or_empty((*uParam0)[iVar0])) {
			streaming::remove_anim_dict((*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x78DC
void func_160(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			streaming::set_model_as_no_longer_needed((*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x790C
void func_161(int iParam0, var *uParam1) {
	func_165(iParam0, uParam1);
	func_164(iParam0, uParam1);
	func_163(iParam0, uParam1);
	func_162(iParam0, uParam1);
}

// Position - 0x7934
void func_162(int iParam0, var *uParam1) {
	if (*uParam1 != 0) {
		streaming::set_model_as_no_longer_needed(*uParam1);
	}
	if (entity::does_entity_exist(*iParam0)) {
		entity::set_ped_as_no_longer_needed(iParam0);
	}
}

// Position - 0x795A
void func_163(int iParam0, var *uParam1) {
	if (*uParam1 != 0) {
		streaming::set_model_as_no_longer_needed(*uParam1);
	}
	if (entity::does_entity_exist(*iParam0)) {
		entity::set_ped_as_no_longer_needed(iParam0);
	}
}

// Position - 0x7980
void func_164(int iParam0, var *uParam1) {
	if (*uParam1 != 0) {
		streaming::set_model_as_no_longer_needed(*uParam1);
	}
	if (uParam1->f_14 != 0) {
		streaming::set_model_as_no_longer_needed(uParam1->f_14);
	}
	if (entity::does_entity_exist(*iParam0)) {
		entity::set_ped_as_no_longer_needed(iParam0);
	}
	if (entity::does_entity_exist(iParam0->f_7)) {
		entity::set_ped_as_no_longer_needed(&iParam0->f_7);
	}
	if (entity::does_entity_exist(iParam0->f_9)) {
		entity::set_ped_as_no_longer_needed(&iParam0->f_9);
	}
}

// Position - 0x79DC
void func_165(int iParam0, var *uParam1) {
	int iVar0;

	if (*uParam1 != 0) {
		streaming::set_model_as_no_longer_needed(*uParam1);
	}
	streaming::set_model_as_no_longer_needed(joaat("a_f_y_beach_01"));
	streaming::set_model_as_no_longer_needed(joaat("a_f_y_fitness_02"));
	if (entity::does_entity_exist(*iParam0)) {
		entity::set_ped_as_no_longer_needed(iParam0);
	}
	iVar0 = 0;
	while (iVar0 <= 1) {
		if (entity::does_entity_exist(Local_2203[iVar0 /*9*/])) {
			entity::set_ped_as_no_longer_needed(&Local_2203[iVar0 /*9*/]);
		}
		iVar0++;
	}
}

// Position - 0x7A3F
void func_166() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 4) {
		if (entity::does_entity_exist(uLocal_1577[iVar0])) {
			entity::set_vehicle_as_no_longer_needed(&uLocal_1577[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x7A72
void func_167() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (iLocal_1584[iVar0] != 0) {
			streaming::set_model_as_no_longer_needed(iLocal_1584[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x7AA2
int func_168(int *iParam0, var *uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7) {
	if (!*iParam0) {
		if (func_21(uParam1, sParam2, sParam3, iParam4, iParam5, iParam6, iParam7)) {
			*iParam0 = 1;
			return 1;
		}
	}
	return 0;
}

// Position - 0x7ACF
void func_169(var *uParam0, int iParam1) {
	switch (iLocal_1460) {
	case 0: func_219(uParam0, iParam1); break;

	case 1: func_209(uParam0, iParam1); break;

	case 2: func_207(iParam1); break;

	case 3: func_193(uParam0, iParam1); break;
	}
	func_170(&iLocal_1793, *iParam1, 0, 0, 1, 1, 1);
}

// Position - 0x7B30
void func_170(int *iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_171(iParam0, iParam1, sParam2, iParam3, iParam4, iParam5, iParam6);
}

// Position - 0x7B4A
void func_171(int *iParam0, int iParam1, char *sParam2, int iParam3, bool bParam4, var uParam5, bool bParam6) {
	func_172(iParam0, iParam1, 0f, 0f, 0f, sParam2, iParam3, bParam4, uParam5, bParam6);
}

// Position - 0x7B67
void func_172(int *iParam0, int iParam1, vector3 vParam2, char *sParam5, int iParam6, bool bParam7, var uParam8,
			  bool bParam9) {
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
		func_232(iParam0, 0, 0);
	}
	iParam0->f_6 = 2;
	func_173(iParam0, iParam1, vParam2, sParam5, iParam6, bParam7, uParam8, bParam9);
}

// Position - 0x7B9F
void func_173(int *iParam0, int iParam1, vector3 vParam2, char *sParam5, int iParam6, bool bParam7, var uParam8,
			  bool bParam9) {
	int iVar0;
	int iVar1;

	if (iParam0->f_1 && cam::is_gameplay_hint_active()) {
		if (gameplay::get_game_timer() >= iParam0->f_8 + iParam0->f_9) {
			iParam0->f_1 = 0;
		}
	}
	iVar0 = sParam5;
	if (gameplay::is_string_null(iVar0)) {
		if (!network::network_is_game_in_progress()) {
			iVar0 = "CMN_HINT";
		}
		else {
			iVar0 = "FM_IHELP_HNT";
		}
	}
	if (func_192(iVar0)) {
		func_191();
	}
	if (func_190(iParam1) && entity::is_entity_visible(iParam1)) {
		iVar1 = 0;
		if (entity::is_entity_a_ped(iParam1)) {
			ped::_0x7D7A2E43E74E2EB8(entity::get_ped_index_from_entity_index(iParam1));
			ped::get_ped_flood_invincibility(entity::get_ped_index_from_entity_index(iParam1), 1);
			if (ped::is_tracked_ped_visible(entity::get_ped_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		else if (entity::is_entity_a_vehicle(iParam1)) {
			vehicle::track_vehicle_visibility(entity::get_vehicle_index_from_entity_index(iParam1));
			if (vehicle::is_vehicle_visible(entity::get_vehicle_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		else if (entity::is_entity_an_object(iParam1)) {
			object::track_object_visibility(entity::get_object_index_from_entity_index(iParam1));
			if (object::is_object_visible(entity::get_object_index_from_entity_index(iParam1))) {
				iVar1 = 1;
			}
		}
		if (!cam::is_gameplay_hint_active()) {
			if (func_185(iParam0, bParam7, bParam9, 0)) {
				func_181(iParam0, iParam1, vParam2, iParam6);
			}
			if (*iParam0) {
				*iParam0 = 0;
			}
			else if (iParam0->f_6 == 2) {
				if (func_178(iVar0)) {
					if (gameplay::is_string_null(iParam0->f_3) && !gameplay::is_string_null(iVar0) &&
						ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						if (iVar1 && !ui::is_help_message_being_displayed() && uParam8) {
							if (!func_192(iVar0)) {
								func_177(iVar0, -1);
								iParam0->f_3 = iVar0;
								if (gameplay::are_strings_equal("CMN_HINT", iVar0)) {
									func_176(1);
								}
							}
						}
					}
				}
			}
			else if (func_178(iVar0)) {
				if (gameplay::is_string_null(iParam0->f_3) && !gameplay::is_string_null(iVar0)) {
					if (entity::is_entity_on_screen(iParam1) && iVar1 && !ui::is_help_message_being_displayed() &&
						uParam8) {
						if (!func_192(iVar0)) {
							func_177(iVar0, -1);
							iParam0->f_3 = iVar0;
							if (gameplay::are_strings_equal("CMN_HINT", iVar0)) {
								func_176(1);
							}
						}
					}
				}
			}
		}
		else {
			if (!gameplay::is_string_null(sParam5)) {
				if (func_192(sParam5)) {
					ui::clear_help(1);
				}
			}
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (ped::is_ped_in_any_boat(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(3) == 3 || cam::_0xEE778F8C7E1142E2(3) == 4) {
						func_232(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_heli(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(6) == 3 || cam::_0xEE778F8C7E1142E2(6) == 4) {
						func_232(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_plane(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(4) == 3 || cam::_0xEE778F8C7E1142E2(4) == 4) {
						func_232(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_in_any_sub(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(5) == 3 || cam::_0xEE778F8C7E1142E2(5) == 4) {
						func_232(iParam0, iVar0, 1);
					}
				}
				else if (ped::is_ped_on_any_bike(player::player_ped_id())) {
					if (cam::_0xEE778F8C7E1142E2(2) == 3 || cam::_0xEE778F8C7E1142E2(2) == 4) {
						func_232(iParam0, iVar0, 1);
					}
				}
				else if (cam::get_follow_vehicle_cam_view_mode() == 3 || cam::get_follow_vehicle_cam_view_mode() == 4) {
					func_232(iParam0, iVar0, 1);
				}
			}
			if (!func_185(iParam0, bParam7, bParam9, 0)) {
				if (!*iParam0 && !iParam0->f_1 && !func_175(iParam0)) {
					func_174(iParam0);
				}
			}
		}
	}
	else {
		func_232(iParam0, iVar0, 0);
	}
}

// Position - 0x7F0C
void func_174(int *iParam0) {
	if (func_190(player::player_ped_id())) {
		ai::task_clear_look_at(player::player_ped_id());
	}
	if (cam::is_gameplay_hint_active()) {
		cam::set_cinematic_button_active(1);
		cam::stop_gameplay_hint(0);
		audio::stop_audio_scene("HINT_CAM_SCENE");
		graphics::_stop_screen_effect("FocusIn");
		if (iParam0->f_11) {
			graphics::_start_screen_effect("FocusOut", 0, 0);
			audio::play_sound_frontend(-1, "FocusOut", "HintCamSounds", 1);
			iParam0->f_11 = 0;
		}
	}
	iParam0->f_2 = -1;
	*iParam0 = 1;
}

// Position - 0x7F75
bool func_175(var *uParam0) {
	int iVar0;

	if (uParam0->f_2 > 0) {
		iVar0 = uParam0->f_10 / 2;
		if (uParam0->f_2 + iVar0 > gameplay::get_game_timer()) {
			return true;
		}
	}
	return false;
}

// Position - 0x7FA0
int func_176(int iParam0) {
	switch (Global_35781) {
	case 0:
	case 3:
		if (iParam0) {
			Global_101700.f_9008.f_100++;
		}
		return Global_101700.f_9008.f_100;

	case 4:
		if (iParam0) {
			Global_101700.f_9008.f_101++;
		}
		return Global_101700.f_9008.f_101;

	case 5:
	case 15:
		if (iParam0) {
			Global_101700.f_9008.f_102++;
		}
		return Global_101700.f_9008.f_102;

	default: break;
	}
	return 3;
}

// Position - 0x804B
void func_177(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x8062
bool func_178(char *sParam0) {
	if (!func_179(1, 1, 0)) {
		if (!gameplay::is_string_null_or_empty(sParam0) && func_192(sParam0) || func_192("CMN_HINT")) {
			ui::clear_help(1);
		}
		return false;
	}
	switch (Global_35781) {
	case 0:
	case 3:
		if (func_176(0) < 3) {
			return true;
		}
		break;

	case 4:
		if (func_176(0) < 1) {
			return true;
		}
		break;

	case 5:
	case 15:
		if (func_176(0) < 1) {
			return true;
		}
		break;

	default: break;
	}
	return false;
}

// Position - 0x80FB
int func_179(int iParam0, int iParam1, int iParam2) {
	if (iParam0) {
		if (!player::is_player_control_on(player::player_id())) {
			return 0;
		}
	}
	if (iParam2) {
		return 1;
	}
	if (streaming::is_player_switch_in_progress()) {
		return 0;
	}
	if (func_118(0)) {
		return 0;
	}
	if (func_180()) {
		return 0;
	}
	if (network::_network_is_text_chat_active()) {
		return 0;
	}
	if (G_DisableMessagesAndCalls2) {
		return 0;
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) > 0) {
		return 0;
	}
	if (Global_53003) {
		return 0;
	}
	if (iParam1) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
			if (ped::is_ped_in_any_boat(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(3) == 3 || cam::_0xEE778F8C7E1142E2(3) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_heli(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(6) == 3 || cam::_0xEE778F8C7E1142E2(6) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_plane(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(4) == 3 || cam::_0xEE778F8C7E1142E2(4) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_in_any_sub(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(5) == 3 || cam::_0xEE778F8C7E1142E2(5) == 4) {
					return 0;
				}
			}
			else if (ped::is_ped_on_any_bike(player::player_ped_id())) {
				if (cam::_0xEE778F8C7E1142E2(2) == 3 || cam::_0xEE778F8C7E1142E2(2) == 4) {
					return 0;
				}
			}
			else if (cam::get_follow_vehicle_cam_view_mode() == 3 || cam::get_follow_vehicle_cam_view_mode() == 4) {
				return 0;
			}
			if (cam::is_gameplay_cam_looking_behind()) {
				return 0;
			}
		}
	}
	return 1;
}

// Position - 0x8277
bool func_180() { return gameplay::get_game_timer() <= Global_17290.f_5745 + 100; }

// Position - 0x828C
void func_181(int *iParam0, int iParam1, vector3 vParam2, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	if (entity::is_entity_dead(iParam1, 0)) {
		func_232(iParam0, 0, 0);
	}
	if (func_184(vParam2, 0f, 0f, 0f, 0)) {
		if (entity::is_entity_a_ped(iParam1)) {
			iVar0 = entity::get_ped_index_from_entity_index(iParam1);
			if (!ped::is_ped_in_any_vehicle(iVar0, 0)) {
				if (ped::is_ped_a_player(iVar0)) {
					if (!func_182()) {
						vParam2 = {0f, 0f, 1f};
					}
				}
				else if (ped::is_ped_male(iVar0)) {
					vParam2 = {0f, 0f, 1f};
				}
			}
		}
	}
	cam::set_cinematic_button_active(0);
	iVar1 = iParam0->f_9;
	iVar2 = iParam0->f_10;
	if (iParam5 == 1726668277) {
		if (iVar1 < 1500) {
			iVar1 = 1500;
		}
		if (iVar2 < 1500) {
			iVar2 = 1500;
		}
	}
	cam::set_gameplay_entity_hint(iParam1, vParam2, 1, -1, iVar1, iVar2, iParam5);
	iVar3 = 2048;
	iVar4 = 3;
	ai::task_look_at_entity(player::player_ped_id(), iParam1, -1, iVar3, iVar4);
	graphics::_start_screen_effect("FocusIn", 0, 0);
	audio::start_audio_scene("HINT_CAM_SCENE");
	audio::play_sound_frontend(-1, "FocusIn", "HintCamSounds", 1);
	iParam0->f_11 = 1;
	iParam0->f_8 = gameplay::get_game_timer();
	iParam0->f_1 = 1;
	*iParam0 = 0;
}

// Position - 0x8391
int func_182() { return func_183(player::player_id()); }

// Position - 0x83A1
int func_183(int iParam0) {
	if (entity::get_entity_model(player::get_player_ped(iParam0)) == joaat("mp_f_freemode_01")) {
		return 1;
	}
	return 0;
}

// Position - 0x83C0
bool func_184(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x8407
bool func_185(var *uParam0, bool bParam1, bool bParam2, int iParam3) {
	if (uParam0->f_1) {
		if (gameplay::get_game_timer() >= uParam0->f_8 + uParam0->f_9) {
			uParam0->f_1 = 0;
		}
	}
	switch (uParam0->f_5) {
	case 0:
		uParam0->f_7 = 0;
		if (uParam0->f_6 == 0) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (func_189(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 1;
					uParam0->f_7 = 1;
				}
			}
			else if (func_188(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		else if (uParam0->f_6 == 1) {
			if (func_188(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		else if (uParam0->f_6 == 2) {
			if (func_189(bParam1, bParam2, iParam3)) {
				uParam0->f_4 = gameplay::get_game_timer();
				uParam0->f_5 = 1;
				uParam0->f_7 = 1;
			}
		}
		if (func_175(uParam0)) {
			uParam0->f_7 = 1;
			uParam0->f_5 = 4;
		}
		break;

	case 1:
		if (gameplay::get_game_timer() - uParam0->f_4 <= 500) {
			if (uParam0->f_6 == 0) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
					if (!func_189(bParam1, bParam2, iParam3)) {
						uParam0->f_4 = gameplay::get_game_timer();
						uParam0->f_5 = 3;
					}
				}
				else if (!func_188(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
			else if (uParam0->f_6 == 1) {
				if (!func_188(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
			else if (uParam0->f_6 == 2) {
				if (!func_189(bParam1, bParam2, iParam3)) {
					uParam0->f_4 = gameplay::get_game_timer();
					uParam0->f_5 = 3;
				}
			}
		}
		else {
			uParam0->f_5 = 2;
		}
		break;

	case 2:
		if (uParam0->f_6 == 0) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				if (!func_189(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (!func_188(bParam1, bParam2, iParam3)) {
				uParam0->f_5 = 0;
			}
		}
		else if (uParam0->f_6 == 1) {
			if (!func_188(bParam1, bParam2, iParam3) || ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				uParam0->f_5 = 0;
			}
		}
		else if (uParam0->f_6 == 2) {
			if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
				ai::get_is_task_active(player::player_ped_id(), 2)) {
				uParam0->f_5 = 0;
			}
			else if (!func_189(bParam1, bParam2, iParam3)) {
				uParam0->f_5 = 0;
			}
		}
		break;

	case 3:
		if (gameplay::get_game_timer() - uParam0->f_4 > 500) {
			if (uParam0->f_6 == 0) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
					if (func_187(bParam1, bParam2, iParam3)) {
						uParam0->f_5 = 0;
					}
				}
				else if (func_186(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (uParam0->f_6 == 1) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) || func_186(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
			else if (uParam0->f_6 == 2) {
				if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
					ai::get_is_task_active(player::player_ped_id(), 2)) {
					uParam0->f_5 = 0;
				}
				else if (func_187(bParam1, bParam2, iParam3)) {
					uParam0->f_5 = 0;
				}
			}
		}
		break;

	case 4:
		if (!func_175(uParam0)) {
			uParam0->f_5 = 0;
		}
		break;
	}
	if (!func_179(bParam1, bParam2, iParam3)) {
		uParam0->f_5 = 0;
		uParam0->f_7 = 0;
	}
	if (uParam0->f_7) {
		func_191();
		return true;
	}
	else {
		return false;
	}
	return false;
}

// Position - 0x8773
bool func_186(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_179(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!player::is_player_targetting_anything(player::player_id())) {
			controls::disable_control_action(0, 140, 1);
			controls::disable_control_action(0, 80, 1);
			if (controls::is_disabled_control_just_released(0, 80)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x87C5
bool func_187(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_179(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		controls::disable_control_action(0, 80, 1);
		if (cam::is_follow_vehicle_cam_active()) {
			if (controls::is_disabled_control_just_released(0, 80)) {
				cam::set_cinematic_button_active(0);
				return true;
			}
		}
	}
	return false;
}

// Position - 0x880E
bool func_188(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_179(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!player::is_player_targetting_anything(player::player_id())) {
			controls::disable_control_action(0, 140, 1);
			controls::disable_control_action(0, 80, 1);
			if (controls::is_disabled_control_pressed(0, 80) && gameplay::get_game_timer() > Global_116) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x886D
bool func_189(bool bParam0, bool bParam1, bool bParam2) {
	if (!func_179(bParam0, bParam1, bParam2)) {
		return false;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		controls::disable_control_action(0, 80, 1);
		if (cam::is_follow_vehicle_cam_active()) {
			if (controls::is_disabled_control_pressed(0, 80) && gameplay::get_game_timer() > Global_116) {
				cam::set_cinematic_button_active(0);
				return true;
			}
		}
	}
	return false;
}

// Position - 0x88C3
bool func_190(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (entity::is_entity_a_vehicle(iParam0)) {
			if (vehicle::is_vehicle_driveable(entity::get_vehicle_index_from_entity_index(iParam0), 0)) {
				return true;
			}
		}
		else if (entity::is_entity_a_ped(iParam0)) {
			if (!ped::is_ped_injured(entity::get_ped_index_from_entity_index(iParam0))) {
				return true;
			}
		}
		else if (entity::is_entity_an_object(iParam0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x891E
void func_191() { gameplay::set_bit(&G_SleepModeOffOn11, 4); }

// Position - 0x892E
bool func_192(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x8941
void func_193(var *uParam0, var *uParam1) {
	int iVar0;

	switch (iLocal_1461) {
	case 0:
		func_205(uParam1);
		entity::set_entity_load_collision_flag(*uParam1, 1);
		system::settimera(0);
		iLocal_1461 = 1;
		break;

	case 1:
		if (func_198(*uParam1, uParam1->f_1, &Local_122, &iLocal_133, 1, 0, 0, 1, 1) || iLocal_1517) {
			if (!ped::is_ped_injured(*uParam1)) {
				entity::set_entity_load_collision_flag(*uParam1, 1);
				if (ped::is_ped_in_vehicle(*uParam1, uParam1->f_1, 0)) {
					if (vehicle::is_vehicle_driveable(uParam1->f_1, 0)) {
						if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
							ai::task_vehicle_mission_ped_target(*uParam1, uParam1->f_1, player::player_ped_id(), 8, 35f,
																786468, 500f, -1f, 1);
						}
						else {
							ai::task_vehicle_mission(*uParam1, uParam1->f_1,
													 ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 8, 35f,
													 786468, 500f, -1f, 1);
						}
					}
				}
				else {
					ai::task_smart_flee_ped(*uParam1, player::player_ped_id(), 1000f, -1, 0, 0);
				}
			}
			system::settimera(0);
			iLocal_1461 = 2;
		}
		else if (!iLocal_1516) {
			if (!ped::is_ped_in_any_vehicle(*uParam1, 0)) {
				ped::set_ped_into_vehicle(*uParam1, uParam1->f_1, -1);
				vehicle::set_vehicle_on_ground_properly(uParam1->f_1, 1084227584);
			}
			vehicle::set_vehicle_forward_speed(uParam1->f_1, 4f);
			ai::open_sequence_task(&iVar0);
			ai::task_vehicle_mission_coors_target(0, uParam1->f_1, -1637.682f, 1018.619f, 152.1026f, 4, 22f, 786468,
												  10f, -1f, 1);
			ai::task_vehicle_drive_wander(0, uParam1->f_1, 22f, 786468);
			ai::close_sequence_task(iVar0);
			ai::task_perform_sequence(*uParam1, iVar0);
			ai::clear_sequence_task(&iVar0);
			iLocal_1516 = 1;
		}
		break;

	case 2:
		if (func_197(*uParam1, fLocal_1557, 0)) {
			func_2(Local_1044, uParam0, 0);
		}
		else if (!ped::is_ped_injured(*uParam1)) {
			if (!iLocal_1525) {
				if (!ped::is_ped_in_any_vehicle(*uParam1, 0)) {
					if (ai::get_script_task_status(*uParam1, 780511057) != 1) {
						ped::set_ped_combat_attributes(*uParam1, 1, 0);
						ai::task_smart_flee_ped(*uParam1, player::player_ped_id(), 1000f, -1, 0, 0);
						iLocal_1525 = 1;
					}
				}
			}
			if (func_238(*uParam1, 1) < 15f && !func_45() && !ped::is_ped_ragdoll(*uParam1)) {
				if (!iLocal_1520) {
					if (func_194(&iLocal_1541)) {
						iLocal_1520 = 1;
						system::settimera(0);
					}
				}
				else if (!iLocal_1519) {
					if (system::timera() >= 10000) {
						func_21(&uParam1->f_16, "OJASAUD", "OJASml_bkTP2", 8, 0, 0, 0);
						iLocal_1519 = 1;
					}
				}
			}
		}
		break;
	}
}

// Position - 0x8BB5
bool func_194(int iParam0) {
	switch (*iParam0) {
	case 0:
		func_21(&Local_1044.f_16, "OJASAUD", "OJASml_bkTP1", 8, 0, 0, 0);
		func_196();
		*iParam0++;
		break;

	case 1:
		if (func_195()) {
			func_21(&Local_1044.f_16, "OJASAUD", "OJASml_bkTP2", 8, 0, 0, 0);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x8C1B
bool func_195() {
	if (func_452(&uLocal_1589)) {
		if (!func_45() && func_39(&uLocal_1589) > fLocal_1558) {
			return true;
		}
	}
	return false;
}

// Position - 0x8C4A
void func_196() {
	func_38(&uLocal_1589);
	fLocal_1558 = gameplay::get_random_float_in_range(3f, 7f);
}

// Position - 0x8C62
bool func_197(int iParam0, float fParam1, float fParam2) {
	int iVar0;
	float fVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
				iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
				fVar1 = func_238(iParam0, 1);
				if (fVar1 > fParam1) {
					if (!entity::is_entity_on_screen(iVar0) || entity::is_entity_occluded(iVar0)) {
						return true;
					}
					else if (fParam2 != 0f) {
						if (fVar1 > fParam2) {
							if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
								return true;
							}
						}
					}
				}
			}
			else if (func_238(iParam0, 1) > fParam1) {
				if (!entity::is_entity_on_screen(iParam0) || entity::is_entity_occluded(iParam0)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x8D09
bool func_198(int iParam0, int iParam1, var *uParam2, int *iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8) {
	int iVar0;
	bool bVar1;

	iVar0 = player::player_ped_id();
	if (!entity::is_entity_dead(iVar0, 0) && !entity::is_entity_dead(iParam0, 0)) {
		if (!func_78(*uParam2, 1)) {
			if (func_204(iParam0, uParam2)) {
				*iParam3 = 1;
				return true;
			}
		}
		if (!func_78(*uParam2, 2)) {
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				*iParam3 = 2;
				return true;
			}
		}
		if (!func_78(*uParam2, 4)) {
			if (func_202(iVar0, iParam0, uParam2, iParam5)) {
				*iParam3 = 4;
				return true;
			}
		}
		if (!func_78(*uParam2, 8)) {
			if (func_201(iVar0, iParam0, uParam2)) {
				*iParam3 = 8;
				return true;
			}
		}
		bVar1 = !func_78(*uParam2, 128);
		if (iParam4) {
			if (func_199(iParam0, iParam1, 1, iParam6, bVar1, 1)) {
				*iParam3 = 32;
				return true;
			}
		}
		else if (!func_78(*uParam2, 16)) {
			if (func_199(iParam0, iParam1, 0, iParam6, bVar1, iParam8)) {
				*iParam3 = 16;
				return true;
			}
		}
	}
	else if (entity::does_entity_exist(iParam0)) {
		if (iParam7 && entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
			*iParam3 = 16;
			return true;
		}
	}
	return false;
}

// Position - 0x8E33
bool func_199(int iParam0, int iParam1, int iParam2, bool bParam3, bool bParam4, int iParam5) {
	int iVar0;
	int iVar1;

	if (bParam3) {
		if (!bLocal_118) {
			iLocal_119 = entity::get_entity_health(iParam0);
			bLocal_118 = true;
		}
		iLocal_120 = entity::get_entity_health(iParam0);
		iLocal_121 = iLocal_119 - iLocal_120;
		iVar0 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
				if (IntToFloat(iLocal_121) > 100f) {
					return true;
				}
			}
		}
		if (bLocal_118) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
				if (IntToFloat(iLocal_121) > 100f) {
					return true;
				}
			}
		}
	}
	else if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
		return true;
	}
	if (!bParam3) {
		iVar1 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar1, 1)) {
				return true;
			}
		}
	}
	if (bParam4) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (ped::is_ped_being_jacked(iParam0)) {
				if (ped::get_peds_jacker(iParam0) == player::player_ped_id()) {
					return true;
				}
			}
		}
	}
	if (iParam5) {
		if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
			if (entity::is_entity_at_coord(iParam0, entity::get_entity_coords(player::player_ped_id(), 1), 10f, 10f,
										   10f, 0, 1, 0)) {
				if (player::has_player_damaged_at_least_one_ped(player::player_id())) {
					return true;
				}
			}
		}
	}
	if (ped::is_ped_performing_stealth_kill(player::player_ped_id())) {
		if (ped::was_ped_killed_by_stealth(iParam0)) {
			return true;
		}
	}
	if (func_200(player::player_ped_id(), iParam0)) {
		return true;
	}
	if (iParam2) {
		if (ped::is_ped_ragdoll(iParam0) && func_238(iParam0, 1) < 1.5f) {
			return true;
		}
		else if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			if (entity::is_entity_touching_entity(player::player_ped_id(), ped::get_vehicle_ped_is_in(iParam0, 0))) {
				return true;
			}
		}
		else if (entity::is_entity_touching_entity(player::player_ped_id(), iParam0)) {
			return true;
		}
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam1, player::player_ped_id(), 1)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x8FFB
bool func_200(int iParam0, int iParam1) {
	int iVar0;

	weapon::get_current_ped_weapon(iParam0, &iVar0, 1);
	if (iVar0 == joaat("weapon_petrolcan")) {
		if (ped::is_ped_shooting(iParam0)) {
			if (system::vdist(entity::get_entity_coords(iParam0, 1), entity::get_entity_coords(iParam1, 1)) < 2.5f) {
				if (ped::is_ped_facing_ped(iParam0, iParam1, 180f)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x9050
bool func_201(int iParam0, int iParam1, var *uParam2) {
	if (weapon::is_ped_armed(iParam0, 4)) {
		if (ped::is_ped_shooting(iParam0) && !weapon::is_ped_current_weapon_silenced(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_4),
										   IntToFloat(uParam2->f_4), IntToFloat(uParam2->f_4), 0, 1, 0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x909E
bool func_202(int iParam0, int iParam1, var *uParam2, bool bParam3) {
	vector3 vVar0;
	int iVar3;

	iVar3 = 0;
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar0 = {entity::get_entity_coords(iParam1, 1)};
	}
	if (gameplay::is_bullet_in_area(vVar0, 4f, 1)) {
		return true;
	}
	if (gameplay::has_bullet_impacted_in_area(vVar0, system::to_float(uParam2->f_6), 1, 1)) {
		return true;
	}
	if (weapon::is_ped_armed(iParam0, 2)) {
		if (ped::is_ped_shooting(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_6 * 3),
										   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
				if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
					entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
					return true;
				}
			}
		}
		else {
			if (ped::is_ped_in_any_vehicle(entity::get_ped_index_from_entity_index(iParam1), 0)) {
				iVar3 = ped::get_vehicle_ped_is_in(entity::get_ped_index_from_entity_index(iParam1), 0);
			}
			if (ped::is_ped_planting_bomb(iParam0) || func_203(iVar3)) {
				if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1),
											   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3),
											   IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
					if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
						entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
						return true;
					}
				}
			}
		}
	}
	if (bParam3) {
		if (gameplay::is_projectile_in_area(vVar0.x - IntToFloat(uParam2->f_6), vVar0.y - IntToFloat(uParam2->f_6),
											vVar0.z - IntToFloat(uParam2->f_6), vVar0.x + IntToFloat(uParam2->f_6),
											vVar0.y + IntToFloat(uParam2->f_6), vVar0.z + IntToFloat(uParam2->f_6),
											0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x9217
int func_203(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0) != 0) {
				if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
					if (iVar0 == joaat("weapon_stickybomb")) {
						if (func_256(player::player_ped_id(), iParam0, 1) < 40f) {
							if (player::get_entity_player_is_free_aiming_at(player::player_id(), &iVar1)) {
								if (entity::is_entity_a_vehicle(iVar1) &&
										entity::get_vehicle_index_from_entity_index(iVar1) == iParam0 ||
									entity::is_entity_a_ped(iVar1) &&
										entity::get_ped_index_from_entity_index(iVar1) ==
											vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0)) {
									if (ped::is_ped_on_foot(player::player_ped_id()) &&
											controls::is_control_pressed(0, 24) ||
										ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
											controls::is_control_pressed(0, 69)) {
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x92E5
bool func_204(int iParam0, var *uParam1) {
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (weapon::is_ped_armed(player::player_ped_id(), 6)) {
			if (player::is_player_free_aiming_at_entity(player::player_id(), iParam0) ||
				player::is_player_targetting_entity(player::player_id(), iParam0)) {
				if (ped::is_ped_facing_ped(iParam0, player::player_ped_id(), 90f)) {
					if (func_238(iParam0, 1) < uParam1->f_2) {
						if (uParam1->f_1 == 0) {
							uParam1->f_1 = gameplay::get_game_timer();
						}
						else if (gameplay::get_game_timer() - uParam1->f_1 > uParam1->f_3) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x936A
void func_205(var *uParam0) {
	if (ui::does_blip_exist(uParam0->f_2)) {
		ui::remove_blip(&uParam0->f_2);
	}
	uParam0->f_2 = func_206(*uParam0, 0, 0);
	ui::set_blip_colour(uParam0->f_2, 1);
	ui::set_blip_route(uParam0->f_2, 0);
}

// Position - 0x93A4
int func_206(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	iVar0 = ui::add_blip_for_entity(iParam0);
	if (entity::is_entity_a_vehicle(iParam0)) {
		ui::set_blip_scale(iVar0, func_89(network::network_is_game_in_progress(), 1f, 1f));
		if (!iParam2) {
			ui::set_blip_as_friendly(iVar0, iParam1);
		}
		else {
			ui::set_blip_colour(iVar0, 2);
		}
	}
	else if (entity::is_entity_a_ped(iParam0)) {
		ui::set_blip_scale(iVar0, func_89(network::network_is_game_in_progress(), 0.7f, 0.7f));
		ui::set_blip_as_friendly(iVar0, iParam1);
	}
	else if (entity::is_entity_an_object(iParam0)) {
		ui::set_blip_scale(iVar0, func_89(network::network_is_game_in_progress(), 0.7f, 0.7f));
	}
	return iVar0;
}

// Position - 0x9448
void func_207(var *uParam0) {
	switch (iLocal_1461) {
	case 0:
		func_205(uParam0);
		iLocal_1461 = 1;
		break;

	case 1:
		if (!iLocal_1515) {
			if (func_198(*uParam0, 0, &Local_122, &iLocal_133, 0, 1, 0, 1, 1) ||
				gameplay::has_bullet_impacted_in_area(entity::get_entity_coords(*uParam0, 1), 15f, 0, 1) ||
				iLocal_1517 || func_238(*uParam0, 1) < 5f ||
				ped::is_ped_in_flying_vehicle(player::player_ped_id()) && func_238(*uParam0, 1) <= 35f) {
				if (!ped::is_ped_injured(*uParam0)) {
					if (func_238(*uParam0, 1) <= 100f) {
						func_21(&uParam0->f_16, "OJASAUD", "OJASml_wwTP", 8, 0, 0, 0);
					}
					ai::task_play_anim(*uParam0, "oddjobs@assassinate@multi@windowwasher", "_shot_reaction", 8f, -8f,
									   -1, 2, 0, 0, 0, 0);
					iLocal_1461 = 2;
				}
			}
		}
		break;

	case 2:
		if (!iLocal_1519) {
			if (func_238(*uParam0, 1) <= 100f && !func_45()) {
				if (func_208(&iLocal_1541)) {
					iLocal_1519 = 1;
				}
			}
		}
		if (ai::get_script_task_status(*uParam0, -2017877118) != 1 &&
			ai::get_script_task_status(*uParam0, 474215631) != 1) {
			ai::task_cower(*uParam0, -1);
		}
		break;
	}
	if (bLocal_1524) {
		func_258();
	}
}

// Position - 0x95A5
bool func_208(int iParam0) {
	switch (*iParam0) {
	case 0:
		func_21(&Local_1044.f_16, "OJASAUD", "OJASml_wwTP2", 8, 0, 0, 0);
		*iParam0++;
		break;

	case 1:
		if (!func_45()) {
			func_21(&Local_1044.f_16, "OJASAUD", "OJASml_wwPAN", 8, 0, 0, 0);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x9608
void func_209(var *uParam0, var *uParam1) {
	int iVar0;
	float fVar1;
	float fVar2;

	switch (iLocal_1461) {
	case 0:
		func_205(uParam1);
		if (!entity::is_entity_dead(uParam1->f_1, 0)) {
			vehicle::_0x8F719973E1445BA2(uParam1->f_1, 1);
		}
		if (!entity::is_entity_dead(*uParam1, 0)) {
			ped::_set_ped_ragdoll_blocking_flags(*uParam1, 16);
		}
		if (!entity::is_entity_dead(uParam1->f_7, 0)) {
			ped::_set_ped_ragdoll_blocking_flags(uParam1->f_7, 16);
			entity::set_entity_health(uParam1->f_7, 105);
		}
		streaming::request_anim_dict("veh@boat@marquis@rps@enter_exit");
		iLocal_1461 = 1;
		break;

	case 1:
		fVar1 = func_238(*uParam1, 1);
		if (func_198(*uParam1, uParam1->f_1, &Local_122, &iLocal_133, 0, 1, 0, 1, 1) ||
			func_198(uParam1->f_7, uParam1->f_1, &Local_122, &iLocal_133, 0, 1, 0, 1, 1) || func_218(uParam1) ||
			func_217(*uParam1, 50f) && iLocal_1517) {
			if (!ped::is_ped_injured(*uParam1)) {
				if (fVar1 <= 75f) {
					if (!entity::is_entity_dead(uParam1->f_1, 0)) {
						if (streaming::has_anim_dict_loaded("veh@boat@marquis@rps@enter_exit")) {
							iLocal_1627 = ped::create_synchronized_scene(0f, 0f, 0f, 0f, 0f, 0f, 2);
							ped::attach_synchronized_scene_to_entity(
								iLocal_1627, uParam1->f_1,
								entity::get_entity_bone_index_by_name(uParam1->f_1, "seat_dside_r"));
							ai::task_synchronized_scene(*uParam1, iLocal_1627, "veh@boat@marquis@rps@enter_exit",
														"jump_out", 4f, -4f, 0, 1, 1148846080, 0);
						}
					}
				}
				else {
					bLocal_1530 = true;
					if (!entity::is_entity_dead(uParam1->f_1, 0)) {
						iLocal_1627 = ped::create_synchronized_scene(0f, 0f, 0f, 0f, 0f, 0f, 2);
						ped::attach_synchronized_scene_to_entity(
							iLocal_1627, uParam1->f_1,
							entity::get_entity_bone_index_by_name(uParam1->f_1, "seat_dside_r"));
						ai::task_synchronized_scene(*uParam1, iLocal_1627,
													"oddjobs@assassinate@multi@yachttarget@lapdance", "exit_steer_m",
													4f, -1000f, 0, 1, 1148846080, 0);
					}
				}
			}
			if (!ped::is_ped_injured(uParam1->f_7)) {
				ai::open_sequence_task(&iVar0);
				if (fVar1 <= 75f) {
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_quick_f", 8f, -8f, -1,
									   0, 0, 0, 0, 0);
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_cower_loop_f", 1000f,
									   -8f, -1, 1, 0, 0, 0, 0);
				}
				else {
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_steer_f", 8f, -8f, -1,
									   0, 0, 0, 0, 0);
					ai::task_play_anim(0, "oddjobs@assassinate@multi@yachttarget@lapdance", "exit_cower_loop_f", 1000f,
									   -8f, -1, 1, 0, 0, 0, 0);
				}
				ai::close_sequence_task(iVar0);
				ai::task_perform_sequence(uParam1->f_7, iVar0);
				ai::clear_sequence_task(&iVar0);
				ped::set_ped_keep_task(uParam1->f_7, 1);
				if (func_238(uParam1->f_7, 1) <= 50f) {
					func_32(&uParam1->f_16, 5, uParam1->f_7, "YachtPed1", 0, 1);
					func_21(&uParam1->f_16, "OJASAUD", "OJASml_ytG1", 8, 0, 0, 0);
				}
			}
			if (!ped::is_ped_injured(uParam1->f_9)) {
				if (ai::get_script_task_status(uParam1->f_9, 1805844857) != 1) {
					ai::clear_ped_tasks(uParam1->f_9);
					ai::task_smart_flee_ped(uParam1->f_9, player::player_ped_id(), 200f, -1, 0, 0);
					ped::set_ped_keep_task(uParam1->f_9, 1);
				}
			}
			iLocal_1541 = 0;
			entity::set_entity_load_collision_flag(*uParam1, 1);
			iLocal_1461 = 2;
		}
		else {
			func_235(uParam1);
			if (fVar1 <= 15f && !iLocal_1520) {
				if (!func_45()) {
					if (func_216(&iLocal_1541)) {
						iLocal_1520 = 1;
					}
				}
			}
			else if (fVar1 <= 25f) {
				if (!func_45()) {
					func_213();
				}
			}
			if (!iLocal_1521) {
				if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_1573, 0)) {
					if (!ped::is_ped_injured(uParam1->f_9)) {
						if (ai::get_script_task_status(uParam1->f_9, 1805844857) != 1) {
							ai::clear_ped_tasks(uParam1->f_9);
							ai::task_smart_flee_ped(uParam1->f_9, player::player_ped_id(), 200f, -1, 0, 0);
							ped::set_ped_keep_task(uParam1->f_9, 1);
							if (func_238(uParam1->f_9, 1) < 50f) {
								func_32(&uParam1->f_16, 4, uParam1->f_9, "OJAmlSUNBATHER", 0, 1);
								func_21(&uParam1->f_16, "OJASAUD", "OJASml_ytSUN", 8, 0, 0, 0);
							}
							iLocal_1521 = 1;
						}
					}
				}
			}
		}
		break;

	case 2:
		if (!entity::is_entity_dead(*uParam1, 0)) {
			if (!entity::is_entity_dead(uParam1->f_1, 0)) {
				if (vehicle::get_ped_in_vehicle_seat(uParam1->f_1, -1, 0) != *uParam1) {
					if (bLocal_1530) {
						if (ped::is_synchronized_scene_running(iLocal_1627)) {
							fVar2 = ped::get_synchronized_scene_phase(iLocal_1627);
						}
						if (fVar2 > 0.8f) {
							ai::clear_ped_tasks(*uParam1);
							ped::set_ped_into_vehicle(*uParam1, uParam1->f_1, -1);
						}
					}
					else {
						if (ped::is_synchronized_scene_running(iLocal_1627)) {
							fVar2 = ped::get_synchronized_scene_phase(iLocal_1627);
						}
						if (fVar2 > 0.9f) {
							if (ai::get_script_task_status(*uParam1, 1805844857) != 1) {
								ai::task_smart_flee_ped(*uParam1, player::player_ped_id(), 1000f, -1, 0, 0);
							}
						}
						else if (!iLocal_1531) {
							if (fVar2 > 0.36f) {
								func_212(&iLocal_1553);
								func_211("MULT_ASSAS_WATER_SPLASH_master", &iLocal_1553, 0, *uParam1, 0, 0, 0, 0);
								iLocal_1531 = 1;
							}
						}
					}
				}
				else if (ai::get_script_task_status(*uParam1, -1273030092) != 1) {
					ai::task_vehicle_mission_coors_target(*uParam1, uParam1->f_1,
														  entity::get_entity_coords(player::player_ped_id(), 1), 8, 20f,
														  786468, 500f, -1f, 1);
				}
			}
			if (!iLocal_1519) {
				if (!func_45() && func_238(*uParam1, 1) < 35f) {
					if (func_210(&iLocal_1541)) {
						iLocal_1519 = 1;
					}
				}
			}
		}
		if (func_197(*uParam1, fLocal_1557, 0)) {
			func_2(Local_1044, uParam0, 0);
		}
		break;
	}
}

// Position - 0x9B3F
bool func_210(int iParam0) {
	switch (*iParam0) {
	case 0:
		func_21(&Local_1044.f_16, "OJASAUD", "OJASml_ytTP2", 8, 0, 0, 0);
		*iParam0++;
		break;

	case 1:
		if (!func_45()) {
			func_21(&Local_1044.f_16, "OJASAUD", "OJASml_beg", 8, 0, 0, 0);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x9BA2
void func_211(char *sParam0, int *iParam1, int iParam2, int iParam3, float fParam4, float fParam5, float fParam6,
			  char *sParam7) {
	func_212(iParam1);
	if (iParam2) {
		*iParam1 = audio::get_sound_id();
	}
	else {
		*iParam1 = -1;
	}
	if (iParam3 != 0) {
		audio::play_sound_from_entity(*iParam1, sParam0, iParam3, sParam7, 0, 0);
	}
	else if (fParam4 != 0f || fParam5 != 0f || fParam6 != 0f) {
		audio::play_sound_from_coord(*iParam1, sParam0, fParam4, fParam5, fParam6, sParam7, 0, 0, 0);
	}
	else {
		audio::play_sound_frontend(*iParam1, sParam0, sParam7, 1);
	}
}

// Position - 0x9C19
void func_212(int *iParam0) {
	if (*iParam0 != -1) {
		audio::stop_sound(*iParam0);
		audio::release_sound_id(*iParam0);
		*iParam0 = -1;
	}
}

// Position - 0x9C3A
void func_213() {
	switch (iLocal_1543) {
	case 0:
		if (!func_45()) {
			if (iLocal_1542 == -1) {
				iLocal_1542 = gameplay::get_random_int_in_range(0, 4);
			}
			else if (iLocal_1542 == 0) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_1", 9, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 1) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_2", 8, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 2) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_3", 8, 0, 0)) {
					func_214();
				}
			}
			else if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_4", 8, 0, 0)) {
				func_214();
			}
		}
		break;

	case 1:
		if (func_195()) {
			if (iLocal_1542 == -1) {
				iLocal_1542 = gameplay::get_random_int_in_range(0, 4);
			}
			else if (iLocal_1542 == 0) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_5", 9, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 1) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_6", 8, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 2) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_7", 8, 0, 0)) {
					func_214();
				}
			}
			else if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_8", 8, 0, 0)) {
				func_214();
			}
		}
		break;

	case 2:
		if (func_195()) {
			if (iLocal_1542 == -1) {
				iLocal_1542 = gameplay::get_random_int_in_range(0, 3);
			}
			else if (iLocal_1542 == 0) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_9", 9, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 1) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_10", 8, 0, 0)) {
					func_214();
				}
			}
			else if (iLocal_1542 == 2) {
				if (func_215(&Local_1044.f_16, "OJASAUD", "OJASml_ytT1", "OJASml_ytT1_11", 8, 0, 0)) {
					func_214();
				}
			}
		}
		break;
	}
}

// Position - 0x9E60
void func_214() {
	iLocal_1543++;
	iLocal_1542 = -1;
	func_196();
}

// Position - 0x9E78
bool func_215(var *uParam0, char *sParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6) {
	func_31(uParam0, 145, sParam1, iParam5, iParam6, 0);
	if (iParam4 > 7) {
		if (iParam4 < 12) {
			iParam4 = 7;
		}
	}
	Global_15752 = 0;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 1;
	Global_16738 = 0;
	Global_16742 = 0;
	StringCopy(&Global_16749, sParam3, 24);
	Global_2621441 = 0;
	return func_22(sParam2, iParam4, 0);
}

// Position - 0x9ECC
bool func_216(int iParam0) {
	switch (*iParam0) {
	case 0:
		func_21(&Local_1044.f_16, "OJASAUD", "OJASml_spot", 9, 0, 0, 0);
		ai::task_look_at_entity(Local_1044, player::player_ped_id(), 5000, 0, 2);
		*iParam0++;
		break;

	case 1:
		if (!func_45()) {
			func_21(&Local_1044.f_16, "OJASAUD", "OJASml_get", 8, 0, 0, 0);
			ai::task_look_at_entity(Local_1044, player::player_ped_id(), 5000, 0, 2);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x9F4F
int func_217(int iParam0, float fParam1) {
	vector3 vVar0;

	if (player::get_player_wanted_level(player::player_id()) > 0) {
		if (!ped::is_ped_injured(iParam0)) {
			vVar0 = {entity::get_entity_coords(iParam0, 1)};
			if (ped::is_cop_ped_in_area_3d(vVar0.x - fParam1, vVar0.y - fParam1, vVar0.z - fParam1, vVar0.x + fParam1,
										   vVar0.y + fParam1, vVar0.z + fParam1)) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x9FAA
int func_218(var *uParam0) {
	if (vehicle::is_vehicle_driveable(uParam0->f_1, 0)) {
		if (ped::is_ped_in_vehicle(player::player_ped_id(), uParam0->f_1, 1) ||
			entity::is_entity_touching_entity(player::player_ped_id(), uParam0->f_1)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x9FE5
void func_219(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	func_230();
	switch (iLocal_1461) {
	case 0:
		func_205(uParam1);
		iLocal_1461 = 1;
		break;

	case 1:
		if (func_198(*uParam1, 0, &Local_122, &iLocal_133, 1, 0, 0, 1, 1) || func_229(&bLocal_1522) ||
			func_228(*uParam1, &uLocal_1595, 1f, 20f, &iLocal_1523) || func_217(*uParam1, 25f) && iLocal_1517 ||
			fire::is_explosion_in_angled_area(-1, -1218.042f, -1549.616f, -3.3703f, -1185.349f, -1597.103f, 10.5993f,
											  46f) ||
			iLocal_1517) {
			audio::stop_scripted_conversation(0);
			if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1)) {
				if (iVar1 != 0) {
					iVar2 = 1;
				}
			}
			if (ped::is_ped_shooting(player::player_ped_id()) || iVar2 && iVar1 != joaat("weapon_unarmed")) {
				ai::task_smart_flee_ped(*uParam1, player::player_ped_id(), 500f, -1, 0, 0);
			}
			else {
				ai::task_combat_ped(*uParam1, player::player_ped_id(), 0, 16);
			}
			func_241(0);
			entity::set_entity_load_collision_flag(*uParam1, 1);
			iLocal_1517 = 1;
			iLocal_1461 = 2;
		}
		else if (!ped::is_ped_injured(*uParam1)) {
			if (!iLocal_1518) {
				func_236(uParam0, uParam1);
			}
			func_226();
		}
		break;

	case 2:
		if (bLocal_1522 || iLocal_1523) {
			iVar0 = func_224(0, entity::get_entity_coords(player::player_ped_id(), 1), 20f);
			if (iVar0 != 0) {
				func_32(&uParam1->f_16, 4, iVar0, "OJAmlGymOnlookerF", 0, 1);
			}
			if (bLocal_1522) {
				if (!iLocal_1532) {
					if (func_21(&uParam1->f_16, "OJASAUD", "OJASml_bbWN3", 8, 0, 0, 0)) {
						iLocal_1532 = 1;
					}
				}
			}
			else if (!iLocal_1532) {
				if (func_21(&uParam1->f_16, "OJASAUD", "OJASml_bbWN4", 8, 0, 0, 0)) {
					iLocal_1532 = 1;
				}
			}
		}
		if (!ped::is_ped_injured(*uParam1)) {
			if (ai::get_script_task_status(*uParam1, 1805844857) != 1) {
				if (ped::is_ped_shooting(player::player_ped_id())) {
					ai::clear_ped_tasks(*uParam1);
					ai::task_smart_flee_ped(*uParam1, player::player_ped_id(), 500f, -1, 0, 0);
				}
			}
		}
		if (func_197(*uParam1, fLocal_1557, 0)) {
			func_2(Local_1044, uParam0, 0);
		}
		break;
	}
	func_220(uParam1);
}

// Position - 0xA229
void func_220(var *uParam0) {
	if (!ped::is_ped_injured(*uParam0)) {
		if (!func_45()) {
			if (!iLocal_1517) {
				if (!iLocal_1518) {
					if (func_238(*uParam0, 1) < 3.5f) {
						iLocal_1518 = 1;
					}
					else if (func_238(*uParam0, 1) < 20f && !ui::is_message_being_displayed()) {
						func_223(uParam0);
					}
				}
				else {
					func_221(uParam0);
				}
			}
			else {
				if (!iLocal_1519) {
					if (ai::get_script_task_status(*uParam0, 1805844857) == 1) {
						func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbHLP", 8, 0, 0, 0);
						iLocal_1519 = 1;
					}
				}
				if (!iLocal_1520) {
					if (ai::get_script_task_status(*uParam0, 780511057) == 1) {
						if (func_238(*uParam0, 1) < 15f) {
							func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbKIL", 8, 0, 0, 0);
							iLocal_1520 = 1;
						}
					}
				}
			}
		}
	}
}

// Position - 0xA308
void func_221(var *uParam0) {
	if (!ped::is_ped_injured(*uParam0)) {
		if (iLocal_1548 == 0) {
			func_222(*uParam0, "misscommon@response", "bring_it_on");
			func_38(&uLocal_1592);
			iLocal_1548++;
		}
		else if (iLocal_1548 == 1) {
			if (entity::is_entity_playing_anim(*uParam0, "misscommon@response", "bring_it_on", 3)) {
				func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbWN1", 8, 0, 0, 0);
				func_38(&uLocal_1592);
				iLocal_1548++;
			}
		}
		else if (iLocal_1548 == 2) {
			if (ai::get_script_task_status(*uParam0, -2017877118) != 1 && !func_45()) {
				if (func_39(&uLocal_1592) > 5.5f) {
					if (func_238(*uParam0, 1) > 3.5f) {
						iLocal_1518 = 0;
					}
					iLocal_1548++;
				}
			}
		}
		else if (iLocal_1548 == 3) {
			if (iLocal_1518) {
				func_222(*uParam0, "misscommon@response", "threaten");
				func_38(&uLocal_1592);
				iLocal_1548++;
			}
		}
		else if (iLocal_1548 == 4) {
			if (entity::is_entity_playing_anim(*uParam0, "misscommon@response", "threaten", 3)) {
				func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbWN2", 8, 0, 0, 0);
				func_38(&uLocal_1592);
				iLocal_1548++;
			}
		}
		else if (iLocal_1548 == 5) {
			if (ai::get_script_task_status(*uParam0, -2017877118) != 1) {
				if (func_39(&uLocal_1592) > 7f) {
					if (func_238(*uParam0, 1) < 3.5f) {
						iLocal_1517 = 1;
					}
					else {
						iLocal_1518 = 0;
					}
				}
			}
		}
	}
}

// Position - 0xA484
void func_222(int iParam0, char *sParam1, char *sParam2) {
	int iVar0;

	ai::clear_ped_tasks(iParam0);
	ai::clear_sequence_task(&iVar0);
	ai::open_sequence_task(&iVar0);
	ai::task_turn_ped_to_face_entity(0, player::player_ped_id(), 0);
	ai::task_play_anim(0, sParam1, sParam2, 4f, -4f, -1, 0, 0, 0, 0, 0);
	ai::close_sequence_task(iVar0);
	ai::task_perform_sequence(iParam0, iVar0);
	ai::clear_sequence_task(&iVar0);
}

// Position - 0xA4D1
void func_223(var *uParam0) {
	if (!func_452(&uLocal_1589)) {
		func_38(&uLocal_1589);
	}
	else if (iLocal_1547 < 7) {
		if (func_39(&uLocal_1589) > fLocal_1558 && !func_45()) {
			switch (iLocal_1547) {
			case 0: func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbId0", 8, 0, 0, 0); break;

			case 1:
				func_32(&uParam0->f_16, 4, Local_2203[0 /*9*/], "OJAmlGymOnlookerF", 0, 1);
				func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbBY1", 8, 0, 0, 0);
				break;

			case 2: func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbId2", 8, 0, 0, 0); break;

			case 3: func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbBY3", 8, 0, 0, 0); break;

			case 4: func_21(&uParam0->f_16, "OJASAUD", "OJASml_bbId0", 8, 0, 0, 0); break;
			}
			func_38(&uLocal_1589);
			fLocal_1558 = gameplay::get_random_float_in_range(5f, 8f);
			iLocal_1547++;
		}
	}
}

// Position - 0xA5DC
var func_224(int iParam0, vector3 vParam1, float fParam4) {
	int iVar0;
	float fVar1;
	float fVar2;
	var uVar3;

	fVar1 = fParam4;
	iVar0 = 0;
	while (iVar0 <= 1) {
		if (!ped::is_ped_injured(Local_2203[iVar0 /*9*/])) {
			if (iParam0 && ped::is_ped_male(Local_2203[iVar0 /*9*/]) ||
				!iParam0 && !ped::is_ped_male(Local_2203[iVar0 /*9*/])) {
				fVar2 = func_225(Local_2203[iVar0 /*9*/], vParam1, 1);
				if (fVar2 <= fVar1) {
					uVar3 = Local_2203[iVar0 /*9*/];
					fVar1 = fVar2;
				}
			}
		}
		iVar0++;
	}
	return uVar3;
}

// Position - 0xA661
float func_225(int iParam0, vector3 vParam1, int iParam4) {
	if (entity::is_entity_dead(iParam0, 0)) {
		return -1f;
	}
	return gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1), vParam1, iParam4);
}

// Position - 0xA68B
void func_226() {
	int iVar0;
	int iVar1;

	if (iLocal_1546 < 2) {
		iVar0 = iLocal_1546;
	}
	else {
		iLocal_1546 = 0;
	}
	if (!ped::is_ped_injured(Local_2203[iVar0 /*9*/])) {
		switch (Local_2203[iVar0 /*9*/].f_8) {
		case 0:
			if (func_225(Local_2203[iVar0 /*9*/], Local_2203[iVar0 /*9*/].f_1, 1) > 2f) {
				if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], 242628503) != 1) {
					ai::clear_ped_tasks(Local_2203[iVar0 /*9*/]);
					ai::open_sequence_task(&iVar1);
					ai::task_go_to_coord_any_means(0, Local_2203[iVar0 /*9*/].f_1, 1f, 0, 0, 786603, -1082130432);
					ai::task_turn_ped_to_face_coord(0, vLocal_1562, 0);
					ai::close_sequence_task(iVar1);
					ai::task_perform_sequence(Local_2203[iVar0 /*9*/], iVar1);
					ai::clear_sequence_task(&iVar1);
				}
			}
			else if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], 242628503) != 1 &&
					 ai::get_script_task_status(Local_2203[iVar0 /*9*/], -2017877118) != 1) {
				func_227(Local_2203[iVar0 /*9*/], 1);
			}
			break;

		case 1:
			if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], -2017877118) != 1) {
				func_227(Local_2203[iVar0 /*9*/], 0);
			}
			break;

		case 2:
			if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], -1146898486) != 1) {
				ai::task_wander_standard(Local_2203[iVar0 /*9*/], 1193033728, 0);
			}
			break;
		}
	}
	iLocal_1546++;
}

// Position - 0xA7E7
void func_227(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_ragdoll(iParam0)) {
		if (iParam1) {
			if (ped::is_ped_male(iParam0)) {
				iVar0 = gameplay::get_random_int_in_range(0, 65535) % 3;
				if (iVar0 == 0) {
					ai::task_play_anim(iParam0, "oddjobs@assassinate@multi@", "react_big_variations_a", 4f, -4f, -1, 1,
									   gameplay::get_random_float_in_range(0f, 1f), 0, 0, 0);
				}
				else if (iVar0 == 1) {
					ai::task_play_anim(iParam0, "oddjobs@assassinate@multi@", "react_big_variations_b", 4f, -4f, -1, 1,
									   gameplay::get_random_float_in_range(0f, 1f), 0, 0, 0);
				}
				else {
					ai::task_play_anim(iParam0, "oddjobs@assassinate@multi@", "react_big_variations_c", 4f, -4f, -1, 1,
									   gameplay::get_random_float_in_range(0f, 1f), 0, 0, 0);
				}
			}
			else {
				iVar0 = gameplay::get_random_int_in_range(0, 65535) % 2;
				if (iVar0 == 0) {
					ai::task_play_anim(iParam0, "oddjobs@assassinate@multi@", "idle_a_pros", 4f, -4f, -1, 1,
									   gameplay::get_random_float_in_range(0f, 1f), 0, 0, 0);
				}
				else {
					ai::task_play_anim(iParam0, "oddjobs@assassinate@multi@", "idle_a_pros", 4f, -4f, -1, 1,
									   gameplay::get_random_float_in_range(0f, 1f), 0, 0, 0);
				}
			}
		}
	}
}

// Position - 0xA8EE
int func_228(int iParam0, var *uParam1, float fParam2, float fParam3, int *iParam4) {
	if (func_238(iParam0, 1) < fParam3) {
		if (weapon::is_ped_armed(player::player_ped_id(), 4)) {
			if (player::is_player_targetting_entity(player::player_id(), iParam0) ||
				player::is_player_free_aiming_at_entity(player::player_id(), iParam0)) {
				if (!func_452(uParam1)) {
					func_38(uParam1);
				}
				else if (func_39(uParam1) >= fParam2) {
					*iParam4 = 1;
					return 1;
				}
			}
			else {
				func_38(uParam1);
			}
		}
	}
	return 0;
}

// Position - 0xA95D
int func_229(int *iParam0) {
	if (func_198(Local_2203[iLocal_1545 /*9*/], 0, &Local_122, &iLocal_133, 0, 0, 0, 1, 1)) {
		*iParam0 = 1;
		return 1;
	}
	iLocal_1545++;
	if (iLocal_1545 > 1) {
		iLocal_1545 = 0;
	}
	return 0;
}

// Position - 0xA99A
void func_230() {
	if (entity::does_entity_exist(Local_1044)) {
		if (!ped::is_ped_injured(Local_1044)) {
			ped::set_ped_reset_flag(Local_1044, 187, 1);
			ped::set_ped_reset_flag(Local_1044, 155, 1);
		}
	}
}

// Position - 0xA9CB
void func_231() {
	Global_14611 = 0;
	func_30();
}

// Position - 0xA9DB
void func_232(int *iParam0, int iParam1, int iParam2) {
	char *sVar0;

	if (network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_2494199.f_4449, 26)) {
			return;
		}
	}
	if (cam::is_gameplay_hint_active()) {
		cam::stop_gameplay_hint(iParam2);
		graphics::_stop_screen_effect("FocusIn");
		audio::stop_audio_scene("HINT_CAM_SCENE");
		if (iParam0->f_11) {
			graphics::_start_screen_effect("FocusOut", 0, 0);
			audio::play_sound_frontend(-1, "FocusOut", "HintCamSounds", 1);
			iParam0->f_11 = 0;
		}
	}
	cam::set_cinematic_button_active(1);
	iParam0->f_1 = 0;
	*iParam0 = 0;
	iParam0->f_2 = -1;
	iParam0->f_8 = 0;
	iParam0->f_5 = 0;
	iParam0->f_6 = 0;
	sVar0 = iParam1;
	if (gameplay::is_string_null(sVar0)) {
		if (!network::network_is_game_in_progress()) {
			sVar0 = "CMN_HINT";
		}
		else {
			sVar0 = "FM_IHELP_HNT";
		}
	}
	if (!gameplay::is_string_null(iParam0->f_3)) {
		if (func_192(iParam0->f_3)) {
			ui::clear_help(1);
		}
	}
	if (!gameplay::is_string_null(sVar0)) {
		if (func_192(sVar0)) {
			ui::clear_help(1);
		}
	}
}

// Position - 0xAAB8
void func_233() {
	Global_14611 = 0;
	func_234();
}

// Position - 0xAAC8
void func_234() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0xAAE9
void func_235(var *uParam0) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;

	vVar0 = {-0.78f, -4.48f, 1.05f};
	vVar3 = {0f, 0f, 275.04f};
	vVar6 = {-0.18f, -4.45f, 1.5f};
	vVar9 = {0f, 0f, 0f};
	if (vehicle::is_vehicle_driveable(uParam0->f_1, 0)) {
		if (!ped::is_ped_injured(*uParam0)) {
			if (!entity::is_entity_playing_anim(*uParam0, "oddjobs@assassinate@multi@yachttarget@lapdance",
												"yacht_ld_m", 3)) {
				ai::task_play_anim(*uParam0, "oddjobs@assassinate@multi@yachttarget@lapdance", "yacht_ld_m", 8f, -8f,
								   -1, 1, 0, 0, 0, 0);
			}
			if (!entity::is_entity_attached(*uParam0)) {
				entity::attach_entity_to_entity(*uParam0, uParam0->f_1, 0, vVar0, vVar3, 1, 1, 0, 0, 2, 1);
			}
		}
		if (!ped::is_ped_injured(uParam0->f_7)) {
			if (!entity::is_entity_playing_anim(uParam0->f_7, "oddjobs@assassinate@multi@yachttarget@lapdance",
												"yacht_ld_f", 3)) {
				ai::task_play_anim(uParam0->f_7, "oddjobs@assassinate@multi@yachttarget@lapdance", "yacht_ld_f", 8f,
								   -8f, -1, 1, 0, 0, 0, 0);
			}
			if (!entity::is_entity_attached(uParam0->f_7)) {
				entity::attach_entity_to_entity(uParam0->f_7, uParam0->f_1, 0, vVar6, vVar9, 1, 1, 1, 0, 2, 1);
			}
		}
	}
}

// Position - 0xAC00
void func_236(var *uParam0, var *uParam1) {
	int iVar0;
	float fVar1;

	switch (iLocal_1462) {
	case 0:
		if (ai::get_script_task_status(*uParam1, 242628503) != 1) {
			fVar1 = entity::get_entity_heading(*uParam1);
			if (fVar1 < uParam0->f_4 - 20f || fVar1 > uParam0->f_4 + 20f) {
				if (ai::get_script_task_status(*uParam1, 1920390111) != 1) {
					ai::task_achieve_heading(*uParam1, uParam0->f_4, 0);
				}
			}
			else {
				ai::open_sequence_task(&iVar0);
				ai::task_play_anim(0, "oddjobs@assassinate@multi@", "idle_a", 4f, -4f, -1, 1, 0, 0, 0, 0);
				ai::close_sequence_task(iVar0);
				ai::task_perform_sequence(*uParam1, iVar0);
				ai::clear_sequence_task(&iVar0);
			}
		}
		break;
	}
}

// Position - 0xACA8
void func_237(int iParam0) {
	if (func_238(iParam0, 0) > fLocal_1557) {
		fLocal_1557 = func_238(iParam0, 0) + 50f;
	}
}

// Position - 0xACCE
float func_238(int iParam0, int iParam1) {
	return func_256(player::get_player_ped(player::get_player_index()), iParam0, iParam1);
}

// Position - 0xACE6
int func_239(var *uParam0, var *uParam1) {
	switch (iLocal_1460) {
	case 0:
		if (func_255(uParam0->f_6, 1) < fLocal_1556 || func_238(*uParam1, 1) < fLocal_1556) {
			if (ui::does_blip_exist(uParam1->f_2)) {
				ui::remove_blip(&uParam1->f_2);
			}
			return 1;
		}
		break;

	case 1:
		if (func_255(uParam0->f_6, 1) < fLocal_1556 || func_238(*uParam1, 1) < fLocal_1556) {
			if (ui::does_blip_exist(uParam1->f_2)) {
				ui::remove_blip(&uParam1->f_2);
			}
			return 1;
		}
		break;

	case 2:
		if (func_255(uParam0->f_6, 1) < fLocal_1556 || func_238(*uParam1, 1) < fLocal_1556) {
			if (ui::does_blip_exist(uParam1->f_2)) {
				ui::remove_blip(&uParam1->f_2);
			}
			return 1;
		}
		break;

	case 3:
		if (func_255(uParam0->f_6, 1) < fLocal_1556 || func_238(*uParam1, 1) < fLocal_1556 + 50f) {
			if (ui::does_blip_exist(uParam1->f_2)) {
				ui::remove_blip(&uParam1->f_2);
			}
			return 1;
		}
		break;
	}
	return 0;
}

// Position - 0xAE0D
int func_240(int iParam0) {
	if (iLocal_1460 == 0) {
		if (func_198(*iParam0, 0, &Local_122, &iLocal_133, 0, 0, 0, 1, 1) || func_229(&bLocal_1522) ||
			fire::is_explosion_in_sphere(-1, vLocal_1562, 25f)) {
			return 1;
		}
	}
	else if (iLocal_1460 == 1) {
		if (func_198(*iParam0, iParam0->f_1, &Local_122, &iLocal_133, 0, 0, 0, 1, 1) ||
			func_198(iParam0->f_7, 0, &Local_122, &iLocal_133, 0, 0, 0, 1, 1)) {
			return 1;
		}
	}
	else if (func_198(*iParam0, iParam0->f_1, &Local_122, &iLocal_133, 0, 0, 0, 1, 1)) {
		return 1;
	}
	return 0;
}

// Position - 0xAEB2
void func_241(int iParam0) {
	int iVar0;
	int iVar1;

	if (!iLocal_1526) {
		iVar0 = 0;
		while (iVar0 <= 1) {
			if (!ped::is_ped_injured(Local_2203[iVar0 /*9*/])) {
				iVar1 = gameplay::get_random_int_in_range(0, 65535) % 3;
				if (iVar1 == 0 || iVar1 == 1) {
					if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], 1805844857) != 1) {
						ai::task_smart_flee_ped(Local_2203[iVar0 /*9*/], player::player_ped_id(), 200f, -1, 0, 0);
						ped::set_ped_keep_task(Local_2203[iVar0 /*9*/], 1);
					}
				}
				else if (ai::get_script_task_status(Local_2203[iVar0 /*9*/], 1805844857) != 1) {
					ai::task_go_to_coord_any_means(Local_2203[iVar0 /*9*/], func_242(), 2f, 0, 0, 786603, -1082130432);
					ped::set_ped_keep_task(Local_2203[iVar0 /*9*/], 1);
				}
			}
			if (iParam0) {
				entity::set_ped_as_no_longer_needed(&Local_2203[iVar0 /*9*/]);
			}
			iVar0++;
		}
		iLocal_1526 = 1;
	}
}

// Position - 0xAF89
Vector3 func_242() {
	vector3 vVar0;
	int iVar3;

	iVar3 = gameplay::get_random_int_in_range(0, 65535) % 6;
	switch (iVar3) {
	case 0: vVar0 = {-1328.256f, -1595.244f, 3.4691f}; break;

	case 1: vVar0 = {-1226.843f, -1627.844f, 3.0966f}; break;

	case 2: vVar0 = {-1277.865f, -1499.797f, 3.4114f}; break;

	case 3: vVar0 = {-1245.8f, -1473.177f, 3.2454f}; break;

	case 4: vVar0 = {-1153.423f, -1599.508f, 3.386f}; break;

	case 5: vVar0 = {-1272.224f, -1612.436f, 3.0916f}; break;

	default: vVar0 = {-1272.224f, -1612.436f, 3.0916f}; break;
	}
	return vVar0;
}

// Position - 0xB067
int func_243(int iParam0, var *uParam1) {
	if (cam::is_screen_faded_in()) {
		if (uParam1->f_274 != 0) {
			if (entity::does_entity_exist(*iParam0)) {
				if (entity::is_entity_dead(*iParam0, 0)) {
					unk1::_0x293220DA1B46CEBC(3f, 1073741824, 3);
					return 1;
				}
			}
		}
		else if (entity::does_entity_exist(*iParam0)) {
			if (ped::is_ped_injured(*iParam0)) {
				if (vehicle::is_vehicle_driveable(iParam0->f_1, 0) &&
					entity::has_entity_been_damaged_by_entity(*iParam0, iParam0->f_1, 1)) {
					iLocal_1026 = 1;
				}
				else if (func_452(&uLocal_1034) && func_39(&uLocal_1034) < 3f) {
					iLocal_1026 = 1;
				}
				unk1::_0x293220DA1B46CEBC(3f, 1073741824, 3);
				return 1;
			}
			else if (vehicle::is_vehicle_driveable(iParam0->f_1, 0)) {
				if (ped::is_ped_in_vehicle(player::player_ped_id(), iParam0->f_1, 0)) {
					if (entity::get_entity_speed(iParam0->f_1) > 10f &&
						entity::is_entity_touching_entity(iParam0->f_1, *iParam0)) {
						if (ped::is_ped_in_any_vehicle(*iParam0, 0)) {
							ped::knock_ped_off_vehicle(*iParam0);
						}
						entity::set_entity_health(*iParam0, 0);
						iLocal_1026 = 1;
						unk1::_0x293220DA1B46CEBC(3f, 1073741824, 3);
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0xB17A
bool func_244(var *uParam0) {
	streaming::request_model(*uParam0);
	if (streaming::has_model_loaded(*uParam0)) {
		return true;
	}
	return false;
}

// Position - 0xB198
bool func_245(var *uParam0) {
	streaming::request_model(*uParam0);
	if (streaming::has_model_loaded(*uParam0)) {
		return true;
	}
	return false;
}

// Position - 0xB1B6
bool func_246(var *uParam0) {
	streaming::request_model(*uParam0);
	streaming::request_model(uParam0->f_14);
	if (streaming::has_model_loaded(*uParam0) && streaming::has_model_loaded(uParam0->f_14)) {
		return true;
	}
	return false;
}

// Position - 0xB1E9
void func_247(var *uParam0, int iParam1) {
	switch (iLocal_1460) {
	case 0:
		if (!ped::is_ped_injured(*iParam1)) {
			ped::set_ped_component_variation(*iParam1, 0, 0, 0, 0);
			ped::set_ped_component_variation(*iParam1, 3, 1, 0, 0);
			ped::set_ped_component_variation(*iParam1, 4, 1, 0, 0);
			ped::set_ped_component_variation(*iParam1, 8, 1, 0, 0);
			ped::set_combat_float(*iParam1, 7, 1f);
			func_32(&uLocal_1628, 3, *iParam1, "OJAmlBODYBUILDER", 0, 1);
			func_32(&iParam1->f_16, 3, *iParam1, "OJAmlBODYBUILDER", 0, 1);
		}
		func_248();
		break;

	case 1:
		if (!entity::does_entity_exist(iParam1->f_9)) {
			iParam1->f_9 = ped::create_ped(5, uParam0->f_16, uParam0->f_22, uParam0->f_25, 1, 1);
			ped::_0x2208438012482A1A(iParam1->f_9, 0, 0);
			ai::task_start_scenario_at_position(iParam1->f_9, "WORLD_HUMAN_SUNBATHE", uParam0->f_22, uParam0->f_25, 0,
												0, 1);
			ped::set_ped_combat_attributes(iParam1->f_9, 17, 1);
		}
		if (!ped::is_ped_injured(iParam1->f_7)) {
			ped::set_blocking_of_non_temporary_events(iParam1->f_7, 1);
			ped::set_ped_dies_in_water(iParam1->f_7, 0);
			ped::set_ped_component_variation(iParam1->f_7, 0, 1, 0, 0);
			ped::set_ped_component_variation(iParam1->f_7, 2, 1, 2, 0);
			ped::set_ped_component_variation(iParam1->f_7, 3, 0, 3, 0);
			ped::set_ped_component_variation(iParam1->f_7, 4, 0, 3, 0);
			ped::set_ped_component_variation(iParam1->f_7, 8, 1, 0, 0);
		}
		if (entity::does_entity_exist(iParam1->f_1)) {
			audio::set_vehicle_radio_enabled(iParam1->f_1, 1);
			audio::set_vehicle_radio_loud(iParam1->f_1, 1);
			entity::_set_entity_register(iParam1->f_1, 1);
		}
		if (!ped::is_ped_injured(*iParam1)) {
			ped::set_ped_dies_in_water(*iParam1, 0);
			func_32(&uLocal_1628, 3, *iParam1, "OJAmlYACHTTARGET", 0, 1);
			func_32(&iParam1->f_16, 3, *iParam1, "OJAmlYACHTTARGET", 0, 1);
			entity::set_entity_load_collision_flag(*iParam1, 1);
		}
		iLocal_1573 = vehicle::create_vehicle(joaat("seashark"), -2190.741f, -470.3163f, -0.4779f, 308.1181f, 1, 1);
		ped::remove_scenario_blocking_area(iLocal_1588, 0);
		iLocal_1588 = ped::add_scenario_blocking_area(Vector(-0.10296f, -468.8926f, -2182.363f) - Vector(15f, 15f, 15f),
													  Vector(-0.10296f, -468.8926f, -2182.363f) + Vector(15f, 15f, 15f),
													  0, 1, 1, 1);
		iLocal_1542 = -1;
		iLocal_1543 = 0;
		break;

	case 2:
		if (!ped::is_ped_injured(*iParam1) && entity::does_entity_exist(iParam1->f_11[0]) &&
			entity::does_entity_exist(iParam1->f_11[1])) {
			func_32(&iParam1->f_16, 3, *iParam1, "OJAmlWASHER", 0, 1);
			entity::attach_entity_to_entity(*iParam1, iParam1->f_11[0], 0, -2.1f, -0.4f, 0.25f, 0f, 0f, 180f, 1, 1, 0,
											0, 2, 1);
			ai::task_play_anim(*iParam1, "oddjobs@assassinate@multi@windowwasher", "_idle", 8f, -8f, -1, 1, 0, 0, 0, 0);
			entity::set_entity_lod_dist(iParam1->f_11[0], 225);
			entity::set_entity_lod_dist(iParam1->f_11[1], 225);
		}
		break;

	case 3:
		if (!ped::is_ped_injured(*iParam1)) {
			ped::set_ped_combat_attributes(*iParam1, 6, 1);
			ped::give_ped_helmet(*iParam1, 0, 4096, -1);
			ped::set_ped_helmet(*iParam1, 1);
			func_32(&uLocal_1628, 3, *iParam1, "OJAmlBIKER", 0, 1);
			func_32(&iParam1->f_16, 3, *iParam1, "OJAmlBIKER", 0, 1);
			if (vehicle::is_vehicle_driveable(iParam1->f_1, 0)) {
				ped::set_ped_into_vehicle(*iParam1, iParam1->f_1, -1);
				vehicle::set_vehicle_on_ground_properly(iParam1->f_1, 1084227584);
			}
		}
		iLocal_1575 = vehicle::create_vehicle(joaat("camper"), -1400.575f, 738.8264f, 182.1478f, 194.607f, 1, 1);
		vehicle::set_vehicle_on_ground_properly(iLocal_1575, 1084227584);
		iLocal_1576 = vehicle::create_vehicle(joaat("bjxl"), -1371.269f, 734.4243f, 182.5433f, 182.766f, 1, 1);
		vehicle::set_vehicle_on_ground_properly(iLocal_1576, 1084227584);
		break;
	}
	if (!ped::is_ped_injured(*iParam1)) {
		entity::set_entity_is_target_priority(*iParam1, 1, 0);
	}
}

// Position - 0xB596
void func_248() {
	Local_2203[0 /*9*/].f_1 = {-1209.031f, -1553.94f, 3.3721f};
	Local_2203[1 /*9*/].f_1 = {-1214.192f, -1558.596f, 3.3476f};
	Local_2203[0 /*9*/].f_8 = 1;
	Local_2203[1 /*9*/].f_8 = 1;
	Local_2203[0 /*9*/] = ped::create_ped(5, joaat("a_f_y_fitness_02"), Local_2203[0 /*9*/].f_1, 169.9513f, 1, 1);
	func_227(Local_2203[0 /*9*/], 1);
	Local_2203[1 /*9*/] = ped::create_ped(5, joaat("a_f_y_beach_01"), Local_2203[1 /*9*/].f_1, 257.4617f, 1, 1);
	func_227(Local_2203[1 /*9*/], 1);
	ped::set_ped_combat_attributes(Local_2203[0 /*9*/], 17, 1);
	ped::set_ped_combat_attributes(Local_2203[0 /*9*/], 1, 0);
	ped::set_blocking_of_non_temporary_events(Local_2203[0 /*9*/], 1);
	ped::set_ped_combat_attributes(Local_2203[1 /*9*/], 17, 1);
	ped::set_ped_combat_attributes(Local_2203[1 /*9*/], 1, 0);
	ped::set_blocking_of_non_temporary_events(Local_2203[1 /*9*/], 1);
}

// Position - 0xB682
void func_249(var *uParam0, int iParam1) {
	int iVar0;

	func_32(&iParam1->f_16, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
	if (uParam0->f_274 == 1) {
		iParam1->f_3 = {-547.167f, -1827.514f, 21.9023f};
		iParam1->f_6 = 81.6995f;
	}
	else if (uParam0->f_274 == 0) {
		iParam1->f_3 = {359.6962f, -687.8932f, 28.188f};
		iParam1->f_6 = 326.413f;
	}
	if (ui::does_blip_exist(iParam1->f_2)) {
		ui::remove_blip(&iParam1->f_2);
	}
	if (uParam0->f_274 == 1) {
		ui::set_blip_name_from_text_file(iParam1->f_2, "ASS_HK_DESTBLIP");
	}
	else if (uParam0->f_274 == 0) {
	}
	if (!func_184(iParam1->f_3, func_147(), 0)) {
		func_253(&iParam1->f_2, iParam1->f_3, iParam1->f_6);
	}
	if (uParam0->f_274 != 0 && uParam0->f_274 != 1) {
		func_252(uParam0, iParam1);
	}
	if (uParam0->f_274 != 1) {
		func_251(uParam0, iParam1);
	}
	if (uParam0->f_14 != 0 && uParam0->f_274 != 0) {
		if (!entity::does_entity_exist(iParam1->f_7)) {
			iParam1->f_7 = ped::create_ped(4, uParam0->f_14, uParam0->f_18, uParam0->f_21, 1, 1);
			if (uParam0->f_274 == 1) {
				ai::task_play_anim(iParam1->f_7, "ODDJOBS@ASSASSINATE@VICE@HOOKER", "idle_b", 1000f, -1000f, -1, 1, 0,
								   0, 0, 0);
				ped::set_ped_can_use_auto_conversation_lookat(iParam1->f_7, 1);
				func_32(&iParam1->f_16, 4, iParam1->f_7, "OJAhkHOOKER", 0, 1);
				ped::set_blocking_of_non_temporary_events(iParam1->f_7, 1);
				ped::set_ped_combat_attributes(iParam1->f_7, 17, 1);
				ped::set_ped_flee_attributes(iParam1->f_7, 128, 1);
				ped::set_ped_config_flag(iParam1->f_7, 134, 1);
			}
		}
	}
	if (uParam0->f_15 != 0) {
		if (uParam0->f_274 != 0) {
			iParam1->f_8 = vehicle::create_vehicle(uParam0->f_15, uParam0->f_26, uParam0->f_29, 1, 1);
		}
		if (uParam0->f_274 == 1) {
			vehicle::set_vehicle_extra(iParam1->f_8, 3, 0);
			vehicle::remove_vehicle_window(iParam1->f_8, 1);
			vehicle::remove_vehicle_window(iParam1->f_8, 0);
			iLocal_1028 = ped::create_ped_inside_vehicle(iParam1->f_8, 4, uParam0->f_16, -1, 1, 1);
			ped::set_blocking_of_non_temporary_events(iLocal_1028, 1);
			func_32(&Local_1044.f_16, 5, iLocal_1028, "KerbCrawler", 0, 1);
		}
	}
	if (uParam0->f_274 == 2) {
		if (!ui::does_blip_exist(iParam1->f_2)) {
			iParam1->f_2 = ui::add_blip_for_coord(uParam0->f_6);
			ui::set_blip_route(iParam1->f_2, 1);
			ui::set_blip_route_colour(iParam1->f_2, 1);
			ui::set_blip_colour(iParam1->f_2, 1);
		}
	}
	else if (uParam0->f_274 == 0) {
		iParam1->f_2 = ui::add_blip_for_coord(uParam0->f_6);
		ui::set_blip_route(iParam1->f_2, 1);
		ui::set_blip_route_colour(iParam1->f_2, 3);
		ui::set_blip_colour(iParam1->f_2, 3);
		ui::set_blip_name_from_text_file(iParam1->f_2, "ASS_BS_BLIP");
	}
	else {
		iParam1->f_2 = ui::add_blip_for_coord(uParam0->f_6);
		ui::set_blip_route(iParam1->f_2, 1);
	}
	iVar0 = 0;
	while (iVar0 < 4) {
		if (!func_250(uParam0->f_249[iVar0 /*3*/])) {
			iParam1->f_11[iVar0] = object::create_object(uParam0->f_244[iVar0], uParam0->f_249[iVar0 /*3*/], 1, 1, 0);
			entity::set_entity_records_collisions(iParam1->f_11[iVar0], 1);
			entity::set_entity_collision(iParam1->f_11[iVar0], 1, 0);
			if (iVar0 == 1) {
				entity::freeze_entity_position(iParam1->f_11[iVar0], 1);
			}
			if (uParam0->f_262[iVar0] != 0f) {
				entity::set_entity_heading(iParam1->f_11[iVar0], uParam0->f_262[iVar0]);
			}
		}
		iVar0++;
	}
}

// Position - 0xB9C9
int func_250(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0xB9F3
void func_251(var *uParam0, var *uParam1) {
	if (uParam0->f_5 != 0) {
		if (!entity::does_entity_exist(uParam1->f_1)) {
			uParam1->f_1 = vehicle::create_vehicle(uParam0->f_5, uParam0->f_9, uParam0->f_12, 1, 1);
			if (uParam0->f_274 == 1) {
				vehicle::set_vehicle_extra(uParam1->f_1, 2, 1);
				vehicle::remove_vehicle_window(uParam1->f_1, 1);
				vehicle::remove_vehicle_window(uParam1->f_1, 0);
				vehicle::set_vehicle_doors_locked(uParam1->f_1, 3);
			}
			else if (uParam0->f_274 == 0) {
				entity::set_entity_load_collision_flag(uParam1->f_1, 1);
				vehicle::set_vehicle_colour_combination(uParam1->f_1, 0);
			}
			vehicle::add_vehicle_upsidedown_check(uParam1->f_1);
			if (uParam0->f_267 == 1) {
				if (entity::does_entity_exist(uParam1->f_1)) {
					if (vehicle::is_vehicle_driveable(uParam1->f_1, 0)) {
						if (!ped::is_ped_injured(*uParam1)) {
							ped::set_ped_into_vehicle(*uParam1, uParam1->f_1, -1);
						}
					}
				}
			}
		}
	}
}

// Position - 0xBAB2
void func_252(var *uParam0, var *uParam1) {
	if (!entity::does_entity_exist(*uParam1)) {
		*uParam1 = ped::create_ped(4, *uParam0, uParam0->f_1, uParam0->f_4, 1, 1);
		ped::set_ped_model_is_suppressed(*uParam0, 1);
		ped::set_ped_can_use_auto_conversation_lookat(*uParam1, 1);
		ped::set_ped_can_be_targetted(*uParam1, 1);
		ped::set_ped_can_be_shot_in_vehicle(*uParam1, 1);
		ped::set_ped_config_flag(*uParam1, 29, 1);
		entity::set_entity_is_target_priority(*uParam1, 1, 0);
		if (!iLocal_1030) {
			ped::add_relationship_group("Target", &iLocal_1040);
			iLocal_1030 = 1;
		}
		ped::set_relationship_between_groups(5, iLocal_1040, 1862763509);
		ped::set_relationship_between_groups(5, 1862763509, iLocal_1040);
		ped::set_ped_relationship_group_hash(*uParam1, iLocal_1040);
		if (uParam0->f_268) {
			ped::set_blocking_of_non_temporary_events(*uParam1, 1);
		}
		if (uParam0->f_269) {
			ped::set_ped_combat_attributes(*uParam1, 3, 0);
			ped::set_ped_get_out_upside_down_vehicle(*uParam1, 1);
		}
		if (uParam0->f_13 != 0) {
			weapon::give_weapon_to_ped(*uParam1, uParam0->f_13, -1, 0, 1);
		}
		if (uParam0->f_274 == 0) {
			ped::set_ped_component_variation(*uParam1, 0, 0, 1, 0);
			ped::set_ped_component_variation(*uParam1, 2, 2, 2, 0);
			ped::set_ped_component_variation(*uParam1, 3, 0, 1, 0);
			ped::set_ped_component_variation(*uParam1, 4, 0, 1, 0);
			ped::set_ped_component_variation(*uParam1, 8, 1, 2, 0);
			func_32(&uParam1->f_16, 3, *uParam1, "INVESTOR", 0, 1);
		}
		else if (uParam0->f_274 == 1) {
			func_32(&uParam1->f_16, 3, *uParam1, "OJAhkJUNKIE", 0, 1);
			ped::set_ped_component_variation(*uParam1, 0, 0, 0, 0);
			ped::set_ped_component_variation(*uParam1, 2, 1, 0, 0);
			ped::set_ped_component_variation(*uParam1, 3, 1, 2, 0);
			ped::set_ped_component_variation(*uParam1, 4, 0, 0, 0);
			ped::set_ped_config_flag(*uParam1, 134, 1);
			ped::set_ped_plays_head_on_horn_anim_when_dies_in_vehicle(*uParam1, 1);
			ped::set_ped_money(*uParam1, gameplay::get_random_int_in_range(80, 100));
			weapon::give_weapon_to_ped(*uParam1, joaat("weapon_combatpistol"), -1, 0, 1);
			ped::set_ped_accuracy(*uParam1, 50);
		}
	}
}

// Position - 0xBC5E
void func_253(var *uParam0, vector3 vParam1, var uParam4) {
	if (ui::does_blip_exist(*uParam0)) {
		Global_100736 = *uParam0;
		Global_100741 = {vParam1};
		Global_100745 = uParam4;
	}
}

// Position - 0xBC87
bool func_254(var *uParam0) {
	streaming::request_model(*uParam0);
	streaming::request_model(joaat("a_f_y_beach_01"));
	streaming::request_model(joaat("a_f_y_fitness_02"));
	if (streaming::has_model_loaded(*uParam0) && streaming::has_model_loaded(joaat("a_f_y_beach_01")) &&
		streaming::has_model_loaded(joaat("a_f_y_fitness_02"))) {
		return true;
	}
	return false;
}

// Position - 0xBCD3
float func_255(vector3 vParam0, int iParam3) {
	return func_225(player::get_player_ped(player::get_player_index()), vParam0, iParam3);
}

// Position - 0xBCED
float func_256(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0xBD4B
void func_257() {
	vector3 vVar0;

	if (func_452(&uLocal_1601)) {
		if (func_39(&uLocal_1601) > 30f) {
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
			}
			if (iLocal_1539 == 1) {
				if (system::vdist(vVar0, vLocal_1616[0 /*3*/]) < 100f ||
					ped::is_ped_in_flying_vehicle(player::player_ped_id())) {
					if (player::get_player_wanted_level(player::player_id()) == 0) {
						player::set_player_wanted_level(player::player_id(), 2, 0);
						player::set_player_wanted_level_now(player::player_id(), 0);
					}
				}
			}
			else if (iLocal_1539 == 2) {
				if (system::vdist(vVar0, vLocal_1616[1 /*3*/]) < 100f ||
					ped::is_ped_in_flying_vehicle(player::player_ped_id())) {
					if (player::get_player_wanted_level(player::player_id()) == 0) {
						player::set_player_wanted_level(player::player_id(), 2, 0);
						player::set_player_wanted_level_now(player::player_id(), 0);
					}
				}
			}
			else if (iLocal_1539 == 3) {
				if (system::vdist(vVar0, vLocal_1616[2 /*3*/]) < 100f ||
					ped::is_ped_in_flying_vehicle(player::player_ped_id())) {
					if (player::get_player_wanted_level(player::player_id()) == 0) {
						player::set_player_wanted_level(player::player_id(), 2, 0);
						player::set_player_wanted_level_now(player::player_id(), 0);
					}
				}
			}
		}
	}
}

// Position - 0xBE74
void func_258() {
	if (iLocal_1460 == 2) {
		if (!rope::does_rope_exist(&uLocal_1561)) {
			if (!ped::is_ped_injured(Local_1044)) {
				if (!iLocal_1515) {
					entity::set_entity_load_collision_flag(Local_1044, 1);
					ped::set_ped_to_ragdoll(Local_1044, 1, 1, 0, 1, 1, 0);
				}
			}
			if (audio::load_stream("WINDOWWASHERFALL_MASTER", 0)) {
				audio::special_frontend_equal(-648.59f, 305.73f, 120f);
			}
			if (cam::is_first_person_aim_cam_active()) {
				cam::_0x70894BD0915C5BCA(1f);
			}
			iLocal_1515 = 1;
		}
		else if (!rope::does_rope_exist(&uLocal_1560)) {
			if (!ped::is_ped_injured(Local_1044)) {
				if (!iLocal_1515) {
					entity::set_entity_load_collision_flag(Local_1044, 1);
					ped::set_ped_to_ragdoll(Local_1044, 1, 1, 0, 1, 1, 0);
				}
			}
			if (audio::load_stream("WINDOWWASHERFALL_MASTER", 0)) {
				audio::special_frontend_equal(-638.1931f, 306.014f, 121.4236f);
			}
			if (cam::is_first_person_aim_cam_active()) {
				cam::_0x70894BD0915C5BCA(1f);
			}
			iLocal_1515 = 1;
		}
	}
}

// Position - 0xBF50
void func_259(var *uParam0, var *uParam1) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	int iVar12;
	float fVar13;
	float fVar14;

	if (entity::does_entity_exist(uParam1->f_11[0])) {
		vVar9 = {entity::get_entity_coords(uParam1->f_11[0], 1)};
	}
	else {
		vVar9 = {uParam0->f_249[0 /*3*/]};
	}
	fVar13 = 142.1f;
	fVar14 = fVar13 - vVar9.z;
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	}
	if (!entity::is_entity_dead(*uParam1, 0)) {
		vVar3 = {entity::get_entity_coords(*uParam1, 1)};
	}
	switch (iLocal_1549) {
	case 0:
		if (!bLocal_1524) {
			if (iLocal_1460 == 2) {
				if (system::vdist2(vVar0, vVar3) < 40000f) {
					if (entity::does_entity_exist(uParam1->f_11[0])) {
						if (entity::does_entity_exist(uParam1->f_11[1])) {
							if (!rope::rope_are_textures_loaded()) {
								rope::rope_load_textures();
							}
							else {
								if (!rope::does_rope_exist(&uLocal_1561)) {
									uLocal_1561 = rope::add_rope(-648.59f, 305.73f, fVar13, 0f, 90f, 0f, fVar14, 0, -1f,
																 5f, 0.5f, 0, 0, 1, 5f, 1, 0);
								}
								if (!rope::does_rope_exist(&uLocal_1560)) {
									uLocal_1560 = rope::add_rope(-638.93f, 304.92f, fVar13, 0f, 90f, 0f, fVar14, 0, -1f,
																 5f, 0.5f, 0, 0, 1, 5f, 1, 0);
								}
								if (rope::does_rope_exist(&uLocal_1560) && rope::does_rope_exist(&uLocal_1561)) {
									rope::attach_entities_to_rope(uLocal_1561, uParam1->f_11[1], uParam1->f_11[0],
																  -648.59f, 305.73f, fVar13, -648.59f, 305.73f, vVar9.z,
																  fVar14, 0, 0, 0, 0);
									rope::attach_entities_to_rope(uLocal_1560, uParam1->f_11[1], uParam1->f_11[0],
																  -638.93f, 304.92f, fVar13, -638.93f, 304.92f, vVar9.z,
																  fVar14, 0, 0, 0, 0);
									bLocal_1524 = true;
									iLocal_1549 = 1;
								}
							}
						}
					}
				}
			}
		}
		break;

	case 1:
		if (system::vdist2(vVar0, vVar3) < 18225f) {
			if (entity::is_entity_on_screen(uParam1->f_11[0])) {
				if (iLocal_1461 < 2) {
					if (!ped::is_ped_injured(*uParam1)) {
						ai::open_sequence_task(&iVar12);
						ai::task_play_anim(0, "oddjobs@assassinate@multi@windowwasher", "_idle_to_up", 8f, -8f, -1, 0,
										   0, 0, 0, 0);
						ai::task_play_anim(0, "oddjobs@assassinate@multi@windowwasher", "_up_loop", 1000f, -8f, -1, 1,
										   0, 0, 0, 0);
						ai::close_sequence_task(iVar12);
						ai::task_perform_sequence(*uParam1, iVar12);
						ai::clear_sequence_task(&iVar12);
					}
				}
				iLocal_1549 = 2;
			}
		}
		break;

	case 2:
		vVar6 = {entity::get_entity_coords(uParam1->f_11[0], 1)};
		if (entity::is_entity_dead(*uParam1, 0)) {
			iLocal_1549 = 3;
		}
		if (rope::does_rope_exist(&uLocal_1561) && rope::does_rope_exist(&uLocal_1560)) {
			rope::start_rope_winding(uLocal_1561);
			rope::start_rope_winding(uLocal_1560);
			if (vVar6.z >= 125f) {
				if (iLocal_1461 < 2) {
					if (!ped::is_ped_injured(*uParam1)) {
						ai::open_sequence_task(&iVar12);
						ai::task_play_anim(0, "oddjobs@assassinate@multi@windowwasher", "_up_to_wash", 8f, -8f, -1, 0,
										   0, 0, 0, 0);
						ai::task_play_anim(0, "oddjobs@assassinate@multi@windowwasher", "_wash_loop", 1000f, -8f, -1, 1,
										   0, 0, 0, 0);
						ai::close_sequence_task(iVar12);
						ai::task_perform_sequence(*uParam1, iVar12);
						ai::clear_sequence_task(&iVar12);
					}
				}
				rope::stop_rope_winding(uLocal_1561);
				rope::stop_rope_winding(uLocal_1560);
				iLocal_1549 = 3;
				entity::apply_force_to_entity(uParam1->f_11[0], 2, -20f, 0f, -20f, -4.78f, 0.65f, -0.78f, 0, 0, 0, 1, 0,
											  1);
			}
		}
		else {
			if (rope::does_rope_exist(&uLocal_1561)) {
				rope::stop_rope_winding(uLocal_1561);
			}
			if (rope::does_rope_exist(&uLocal_1560)) {
				rope::stop_rope_winding(uLocal_1560);
			}
		}
		break;

	case 3:
		if (rope::does_rope_exist(&uLocal_1561)) {
			rope::stop_rope_winding(uLocal_1561);
		}
		if (rope::does_rope_exist(&uLocal_1560)) {
			rope::stop_rope_winding(uLocal_1560);
		}
		break;
	}
}

// Position - 0xC308
void func_260() {
	if (!entity::does_entity_exist(iLocal_1583)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iLocal_1583 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
				if (entity::does_entity_exist(iLocal_1583) && !entity::is_entity_dead(iLocal_1583, 0)) {
					func_261(iLocal_1583);
				}
			}
		}
	}
}

// Position - 0xC35F
void func_261(int iParam0) { func_262(&Global_96040.f_2311, &Global_96040, iParam0, 1); }

// Position - 0xC37A
int func_262(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (vehicle::is_vehicle_driveable(iParam2, 0)) {
		func_264(uParam0, iParam2, iParam3);
		uParam1->f_4 = iParam2;
		if (func_263(iParam2)) {
			uParam1->f_3 = 1;
		}
		else {
			uParam1->f_3 = 0;
		}
		return 1;
	}
	return 0;
}

// Position - 0xC3BA
bool func_263(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 6) {
		if (Global_91491.f_22[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0xC3E8
void func_264(var *uParam0, int iParam1, int iParam2) {
	func_270(iParam1, &uParam0->f_12);
	uParam0->f_7 = func_267(iParam1, 145, 0);
	uParam0->f_11 = func_266(iParam1);
	if (!uParam0->f_7) {
		if (!uParam0->f_10) {
			uParam0->f_10 = func_265(iParam1);
		}
	}
	if (iParam2 == 1) {
		*uParam0 = {entity::get_entity_coords(iParam1, 1)};
		uParam0->f_6 = entity::get_entity_heading(iParam1);
		uParam0->f_3 = {entity::get_entity_velocity(iParam1)};
		if (entity::is_entity_in_angled_area(iParam1, -1154.326f, -1523.871f, 3.262189f, -1158.453f, -1517.75f,
											 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_6 = 305.6424f;
		}
		if (Global_69436 == iParam1) {
			uParam0->f_9 = 1;
		}
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		uParam0->f_8 = 1;
	}
	else {
		uParam0->f_8 = 0;
	}
}

// Position - 0xC4C4
int func_265(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iParam0 == Global_68531.f_484[iVar0]) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xC506
int func_266(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0xC569
int func_267(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				if (iParam1 == 145 || iParam1 == Global_89165[iVar0]) {
					if (iParam2 == 0 || entity::get_entity_model(iParam0) == func_268(iParam1, iParam2)) {
						return 1;
					}
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xC5F7
int func_268(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_13(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_269(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0xC639
void func_269(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xC895
void func_270(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_273(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_272(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_271(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0xCB41
int func_271(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0xCBF1
int func_272(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0xCCCB
void func_273(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0xCD7B
void func_274() {
	switch (iLocal_1460) {
	case 0:
		if (!iLocal_1511) {
			func_142("ASS_ML_T01", 7500, 1);
			func_275(&iLocal_1598, "ASS_TIME_TK");
			iLocal_1511 = 1;
		}
		break;

	case 1:
		if (!iLocal_1511) {
			func_142("ASS_ML_T01", 7500, 1);
			iLocal_1511 = 1;
		}
		break;

	case 2:
		if (!iLocal_1511) {
			func_142("ASS_ML_T01", 7500, 1);
			iLocal_1511 = 1;
		}
		break;

	case 3:
		if (!iLocal_1511) {
			func_142("ASS_ML_T01", 7500, 1);
			iLocal_1511 = 1;
		}
		break;
	}
}

// Position - 0xCE16
void func_275(int *iParam0, char *sParam1) {
	func_38(iParam0);
	StringCopy(&cLocal_1018, sParam1, 32);
}

// Position - 0xCE2B
void func_276() {
	vector3 vVar0;

	if (!entity::does_entity_exist(iLocal_1465)) {
		return;
	}
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	}
	if (system::vdist2(vVar0, vLocal_1468) > 10000f) {
		if (entity::does_entity_exist(iLocal_1465)) {
			streaming::set_model_as_no_longer_needed(-1559354806);
			object::delete_object(&iLocal_1465);
		}
		if (entity::does_entity_exist(iLocal_1464)) {
			entity::set_entity_visible(iLocal_1464, 1, 0);
			entity::set_entity_collision(iLocal_1464, 1, 0);
		}
	}
}

// Position - 0xCEA7
void func_277() {
	switch (iLocal_1460) {
	case 0:
		func_278(0, "assassin_multi_locate_bodybuilder", 0, 0, 0, 1);
		func_261(iLocal_1583);
		break;

	case 1: func_278(1, "assassin_multi_locate_yacht_target", 0, 0, 0, 1); break;

	case 2: func_278(2, "assassin_multi_locate_window_washer", 0, 0, 0, 1); break;

	case 3: func_278(3, "assassin_multi_locate_biker", 0, 0, 0, 1); break;
	}
}

// Position - 0xCF16
void func_278(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char[] cVar3[8];
	int iVar5;
	var uVar6;
	int iVar10;

	if (iParam3 == 1) {
		if (!gameplay::are_strings_equal("FinaleC2", script::get_this_script_name())) {
		}
	}
	iVar0 = 0;
	if (iParam3 == 1) {
		if (iParam0 != Global_91528) {
			iVar0 = 1;
		}
	}
	else if (iParam0 > Global_91528) {
		iVar0 = 1;
	}
	if (iVar0 == 1) {
		func_53(1);
		if (iParam0 <= Global_91528) {
		}
		iVar1 = func_336(script::get_this_script_name(), 1);
		if (iVar1 != -1 && iVar1 != 94) {
			Global_101700.f_8044.f_330[iVar1 /*6*/].f_1 = 0;
			iVar2 = func_334(iVar1);
			cVar3 = {Global_82612[iVar1 /*34*/].f_8};
			if (iVar1 == 90) {
				switch (Global_101700.f_8044.f_99.f_205[7]) {
				case 1: StringConCat(&cVar3, "A", 8); break;

				case 2: StringConCat(&cVar3, "B", 8); break;
				}
			}
			stats::playstats_mission_checkpoint(&cVar3, iVar2, Global_91528, iParam0);
		}
		else {
			iVar5 = func_329(script::get_this_script_name(), 1);
			if (iVar5 != -1) {
				Global_101700.f_17533[iVar5 /*6*/].f_4 = 0;
				MemCopy(&uVar6, {func_328(iVar5)}, 4);
				stats::playstats_mission_checkpoint(&uVar6, 0, Global_91528, iParam0);
			}
			else {
				iVar10 = func_327(&Global_91491.f_3);
				if (iVar10 > -1) {
					Global_101700.f_23945.f_4[iVar10] = 0;
				}
			}
		}
		Global_86002 = iParam2;
		Global_91528 = iParam0;
		func_279(iParam0, sParam1, iParam4, iParam5);
		if (gameplay::are_strings_equal(sParam1, "")) {
		}
	}
	else if (iParam0 < Global_91528) {
	}
}

// Position - 0xD08B
void func_279(int iParam0, var uParam1, int iParam2, int iParam3) {
	func_280(&Global_96040, script::get_this_script_name(), iParam0, uParam1, iParam3, iParam2);
}

// Position - 0xD0A7
void func_280(var *uParam0, var uParam1, var uParam2, var uParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;

	*uParam0 = func_10();
	uParam0->f_1 = func_316();
	gameplay::_get_weather_type_transition(&uParam0->f_6, &uParam0->f_7, &uParam0->f_8);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		func_301(&uParam0->f_2305, 0);
		func_300(player::player_ped_id());
		func_294(player::player_ped_id(), 0);
		weapon::get_current_ped_weapon(player::player_ped_id(), &uParam0->f_2, 1);
		if (uParam0->f_2 == 0 || uParam0->f_2 == joaat("object")) {
			uParam0->f_2 = joaat("weapon_unarmed");
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		uParam0->f_17[iVar1] = Global_101700.f_2095.f_539.f_294[iVar1];
		if (iVar1 == func_293()) {
			func_286(player::player_ped_id(), &uParam0->f_616[iVar1 /*65*/], 1);
		}
		else {
			iVar0 = 0;
			while (iVar0 < 12) {
				uParam0->f_616[iVar1 /*65*/][iVar0] = Global_91281[iVar1 /*65*/][iVar0];
				uParam0->f_616[iVar1 /*65*/].f_13[iVar0] = Global_91281[iVar1 /*65*/].f_13[iVar0];
				iVar0++;
			}
			uParam0->f_616[iVar1 /*65*/].f_59 = Global_91281[iVar1 /*65*/].f_59;
			uParam0->f_616[iVar1 /*65*/].f_60 = Global_91281[iVar1 /*65*/].f_60;
			uParam0->f_616[iVar1 /*65*/].f_61 = Global_91281[iVar1 /*65*/].f_61;
			uParam0->f_616[iVar1 /*65*/].f_62 = Global_91281[iVar1 /*65*/].f_62;
			uParam0->f_616[iVar1 /*65*/].f_63 = Global_91281[iVar1 /*65*/].f_63;
			uParam0->f_616[iVar1 /*65*/].f_64 = Global_91281[iVar1 /*65*/].f_64;
			iVar0 = 0;
			while (iVar0 < 9) {
				uParam0->f_616[iVar1 /*65*/].f_39[iVar0] = Global_91281[iVar1 /*65*/].f_39[iVar0];
				uParam0->f_616[iVar1 /*65*/].f_49[iVar0] = Global_91281[iVar1 /*65*/].f_49[iVar0];
				iVar0++;
			}
		}
		iVar0 = 0;
		while (iVar0 < 44) {
			uParam0->f_812[iVar1 /*284*/][iVar0 /*3*/] = {Global_101700.f_2095.f_539.f_298[iVar1 /*284*/][iVar0 /*3*/]};
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			uParam0->f_812[iVar1 /*284*/].f_133[iVar0 /*3*/] = {
				Global_101700.f_2095.f_539.f_298[iVar1 /*284*/].f_133[iVar0 /*3*/]};
			iVar0++;
		}
		switch (iVar1) {
		case 0:
			stats::stat_get_int(joaat("sp0_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp0_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 1:
			stats::stat_get_int(joaat("sp1_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp1_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 2:
			stats::stat_get_int(joaat("sp2_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp2_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;
		}
		uParam0->f_9[iVar1] = Global_101700.f_19523.f_233[iVar1 /*69*/].f_1;
		uParam0->f_13[iVar1] = Global_52996[iVar1];
		uParam0->f_25[0 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[0 /*295*/][iVar1 /*98*/]};
		uParam0->f_25[1 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[1 /*295*/][iVar1 /*98*/]};
		iVar0 = 0;
		while (iVar0 <= 3) {
			uParam0->f_2259[iVar1 /*15*/][iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/][iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_5[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_5[iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_10[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_10[iVar0];
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 2) {
			uParam0->f_1766[iVar1 /*164*/][iVar0] = Global_101700.f_2095[iVar1 /*164*/][iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_4[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_4[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_8[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_8[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_12[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_12[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_16[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_16[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_20[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_20[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_24[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_24[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_28[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_28[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_32[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_32[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_36[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_36[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_40[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_40[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_44[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_44[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_48[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_48[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_52[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_52[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_56[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_56[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_60[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_60[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_64[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_64[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_68[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_68[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_72[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_72[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_76[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_76[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_80[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_80[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_84[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_84[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_88[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_88[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_92[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_92[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_96[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_96[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_100[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_100[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_104[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_104[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_108[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_108[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_112[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_112[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_116[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_116[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_120[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_120[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_124[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_124[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_128[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_128[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_132[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_132[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_136[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_136[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_140[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_140[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_144[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_144[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_148[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_148[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_152[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_152[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_156[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_156[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_160[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_160[iVar0];
			iVar0++;
		}
		iVar1++;
	}
	stats::stat_get_int(joaat("sp0_special_ability"), &uParam0->f_1762[0], -1);
	stats::stat_get_int(joaat("sp1_special_ability"), &uParam0->f_1762[1], -1);
	stats::stat_get_int(joaat("sp2_special_ability"), &uParam0->f_1762[2], -1);
	uParam0->f_5 = 145;
	if (iParam4 == 1) {
		func_282(&uParam0->f_2311, uParam0, iParam5, 1, 1, 0);
	}
	func_281(&uParam0->f_2401);
	uParam3 = uParam3;
	uParam2 = uParam2;
}

// Position - 0xDF2F
int func_281(var *uParam0) {
	*uParam0 = Global_87673;
	uParam0->f_1 = Global_87674;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	return 1;
}

// Position - 0xDF51
void func_282(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (iParam2 == 0) {
		iParam2 = player::player_ped_id();
	}
	if (entity::does_entity_exist(iParam2)) {
		uParam1->f_5 = func_14(iParam2);
	}
	if (func_283(iParam2, &iVar0, iParam3, iParam5)) {
		func_262(uParam0, uParam1, iVar0, iParam4);
	}
	else if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (vehicle::is_vehicle_model(iVar0, joaat("skylift")) &&
				ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
				func_262(uParam0, uParam1, iVar0, iParam4);
			}
		}
	}
}

// Position - 0xDFD9
bool func_283(int iParam0, var *uParam1, int iParam2, int iParam3) {
	char *sVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (iParam0 == player::player_ped_id()) {
				*uParam1 = player::get_players_last_vehicle();
			}
			else {
				*uParam1 = ped::get_vehicle_ped_is_in(iParam0, 1);
			}
			if (entity::does_entity_exist(*uParam1)) {
				if (vehicle::is_vehicle_driveable(*uParam1, 0)) {
					if (iParam2 == 0 ||
						gameplay::get_distance_between_coords(entity::get_entity_coords(*uParam1, 1),
															  entity::get_entity_coords(iParam0, 1), 1) < 100f) {
						if (vehicle::is_vehicle_model(*uParam1, joaat("taxi"))) {
							if (vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != iParam0 &&
								vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != 0) {
								return false;
							}
						}
						if (func_284(*uParam1, func_10(), 1)) {
							sVar0 = script::get_this_script_name();
							if (!gameplay::are_strings_equal(sVar0, "save_anywhere")) {
								return false;
							}
							else if (!ped::is_ped_in_any_vehicle(iParam0, 1)) {
								return false;
							}
						}
						if (iParam3 == 1) {
							if (decorator::decor_exist_on(*uParam1, "IgnoredByQuickSave")) {
								if (decorator::decor_get_bool(*uParam1, "IgnoredByQuickSave")) {
									return false;
								}
							}
						}
						else if (vehicle::is_vehicle_model(*uParam1, joaat("blimp"))) {
							return false;
						}
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0xE108
bool func_284(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_285(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0xE179
bool func_285(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0xE251
void func_286(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = func_14(iParam0);
		iVar1 = 0;
		while (iVar1 < 12) {
			func_292(iParam0, iVar1, &uParam1->f_13[iVar1], &(*uParam1)[iVar1], &uParam1->f_26[iVar1], iParam2, 145);
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 9) {
			func_291(iParam0, iVar1, &uParam1->f_39[iVar1], &uParam1->f_49[iVar1], iParam2, 145);
			iVar1++;
		}
		if (func_13(iVar0)) {
			uParam1->f_59 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_59;
			uParam1->f_60 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_60;
			uParam1->f_61 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_61;
			uParam1->f_62 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_62;
			uParam1->f_63 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_63;
			uParam1->f_64 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_64;
		}
		else if (network::network_is_game_in_progress() &&
				 entity::get_entity_model(iParam0) == entity::get_entity_model(player::player_ped_id())) {
			if (func_290(161, -1)) {
				uParam1->f_59 = func_287(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_287(747, Global_69521, 0);
			}
			uParam1->f_60 = func_287(748, Global_69521, 0);
			uParam1->f_61 = func_287(749, Global_69521, 0);
		}
		if (network::network_is_game_in_progress() && iParam0 == player::player_ped_id()) {
			if (func_290(161, -1)) {
				uParam1->f_59 = func_287(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_287(747, Global_69521, 0);
			}
		}
	}
}

// Position - 0xE3FB
int func_287(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_288(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0xE42D
int func_288(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_289();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0xE461
var func_289() { return Global_1312735; }

// Position - 0xE46D
bool func_290(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_288(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return false;
}

// Position - 0xE499
void func_291(int iParam0, int iParam1, int *iParam2, int *iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_prop_index(iParam0, iParam1);
		*iParam3 = ped::get_ped_prop_texture_index(iParam0, iParam1);
	}
	else {
		iVar0 = iParam5;
	}
	if (iParam4 == 0) {
		return;
	}
	if (iParam1 == 0) {
		if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
			if (iParam0 != 0) {
				if (ped::is_ped_wearing_helmet(iParam0) && ped::_0x451294E859ECC018(iParam0) != -1) {
					*iParam2 = ped::_0x451294E859ECC018(iParam0);
					*iParam3 = ped::_0x9D728C1E12BF5518(iParam0);
				}
			}
		}
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 0) {
			if (*iParam2 == 7) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 28) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		else if (iParam1 == 1) {
			if (*iParam2 == 1) {
				if ((iParam4 & 2) != 0 || (iParam4 & 64) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 0) {
			if (*iParam2 == 2) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 4) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 6) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 17) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 20) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 8 && *iParam2 <= 14) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 0) {
			if (*iParam2 == 9) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 12) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20 || *iParam2 == 2) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;
	}
}

// Position - 0xE9E1
void func_292(int iParam0, int iParam1, int *iParam2, int *iParam3, var *uParam4, int iParam5, int iParam6) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_drawable_variation(iParam0, iParam1);
		*iParam3 = ped::get_ped_texture_variation(iParam0, iParam1);
		*uParam4 = ped::get_ped_palette_variation(iParam0, iParam1);
	}
	else {
		iVar0 = iParam6;
	}
	if (iParam5 == 0) {
		return;
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 15) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 3 || *iParam2 == 22) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 8) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 1 || *iParam2 == 10) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 19) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 3) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if (*iParam2 >= 5 && *iParam2 <= 7) {
				if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0xEC22
int func_293() {
	func_11();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0xEC3B
void func_294(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_14(iParam0);
	if (func_13(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			func_295(iParam0, &Global_101700.f_2095.f_539.f_298[iVar0 /*284*/]);
			iVar2 = 0;
			while (iVar2 <= 8 - 1) {
				Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] = ui::_0xA13E93403F26C812(iVar2);
				if (iParam1) {
					iVar1 = ui::_0xA48931185F0536FE();
					if (Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] == iVar1) {
						Global_101700.f_2095.f_539.f_1184 = iVar2;
					}
				}
				iVar2++;
			}
			player::get_player_parachute_pack_tint_index(player::player_id(), &iVar3);
			if (iVar0 == 0) {
				stats::stat_set_int(joaat("sp0_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 1) {
				stats::stat_set_int(joaat("sp1_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 2) {
				stats::stat_set_int(joaat("sp2_parachute_current_tint"), iVar3, 1);
			}
		}
	}
}

// Position - 0xED2E
void func_295(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	int iVar7;
	int iVar8;
	struct<2> Var9;
	struct<4> Var48;
	int iVar70;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			(*uParam1)[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			iVar3 = func_299(iVar0);
			if (iVar3 != 0) {
				vVar4.x = weapon::get_ped_weapontype_in_slot(iParam0, func_299(iVar0));
				vVar4.y = 0;
				vVar4.z = 0;
				if (vVar4.x != 0 && vVar4.x != joaat("weapon_unarmed")) {
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (vVar4.x == joaat("gadget_parachute")) {
						vVar4.y = 1;
					}
					gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					(*uParam1)[iVar0 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					iVar2 = func_297(vVar4.x, iVar1);
					while (iVar2 != 0) {
						if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, iVar2)) {
							gameplay::set_bit(&vVar4.f_2, iVar1);
						}
						iVar1++;
						iVar2 = func_297(vVar4.x, iVar1);
					}
				}
				(*uParam1)[iVar0 /*3*/] = {vVar4};
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 50 - 1) {
			uParam1->f_133[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar8 = dlc1::get_num_dlc_weapons();
		iVar7 = 0;
		while (iVar7 < iVar8) {
			if (dlc1::get_dlc_weapon_data(iVar7, &Var9) && !func_296(Var9.f_1) && iVar70 < 50) {
				if (!dlc1::_is_dlc_data_empty(Var9)) {
					vVar4.x = Var9.f_1;
					vVar4.y = 0;
					vVar4.z = 0;
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					}
					else {
						gameplay::set_bit(&vVar4.f_2, 20);
					}
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					uParam1->f_133[iVar70 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					while (iVar1 < dlc1::get_num_dlc_weapon_components(iVar7)) {
						if (dlc1::get_dlc_weapon_component_data(iVar7, iVar1, &Var48)) {
							if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, Var48.f_3)) {
								gameplay::set_bit(&vVar4.f_2, iVar1);
							}
						}
						iVar1++;
					}
				}
				if (vVar4.x != 0) {
					if (!weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						vVar4.x = 0;
						vVar4.y = 0;
					}
				}
				uParam1->f_133[iVar70 /*3*/] = {vVar4};
				iVar70++;
			}
			iVar7++;
		}
	}
}

// Position - 0xEF92
int func_296(int iParam0) {
	if (network::network_is_game_in_progress()) {
	}
	else {
		switch (iParam0) {
		case joaat("weapon_pistol50"):
		case joaat("weapon_bullpupshotgun"):
		case joaat("weapon_assaultsmg"): return 0;

		case joaat("weapon_bottle"):
		case joaat("weapon_snspistol"):
		case joaat("weapon_gusenberg"): return 0;

		case joaat("weapon_heavypistol"):
		case joaat("weapon_specialcarbine"): return 0;

		case joaat("weapon_bullpuprifle"): return 0;

		case joaat("weapon_dagger"):
		case joaat("weapon_vintagepistol"): return 0;

		case joaat("weapon_firework"):
		case joaat("weapon_musket"): return 0;

		case joaat("weapon_heavyshotgun"):
		case joaat("weapon_marksmanrifle"): return 0;

		case joaat("weapon_hominglauncher"):
		case joaat("weapon_proxmine"): return 0;

		case joaat("weapon_combatpdw"):
		case joaat("weapon_knuckle"):
		case joaat("weapon_marksmanpistol"): return 0;

		case -947031628:
		case -572349828:
		case 392730790:
		case -1523701417:
		case -2112826155:
		case -664359727:
		case -1887867191:
		case -837150131:
		case -344484024:
		case joaat("weapon_flaregun"):
		case joaat("weapon_handcuffs"):
		case joaat("weapon_snowball"):
		case joaat("weapon_garbagebag"):
		case joaat("weapon_flashlight"):
		case joaat("weapon_switchblade"):
		case joaat("weapon_revolver"):
		case joaat("weapon_dbshotgun"):
		case joaat("weapon_compactrifle"):
		case 317205821:
		case -1121678507:
		case 125959754:
		case -853065399:
		case -1169823560:
		case -1810795771:
		case 419712736: return 1;
		}
	}
	return 0;
}

// Position - 0xF100
int func_297(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var *uVar2;
	struct<4> Var41;

	iVar0 = 0;
	switch (iParam0) {
	case joaat("weapon_pistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpistol_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_combatpistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_appistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_appistol_clip_01"); break;

		case 1: iVar0 = joaat("component_appistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_appistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_microsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_microsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_microsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_microsmg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_smg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_smg_clip_01"); break;

		case 1: iVar0 = joaat("component_smg_clip_02"); break;

		case 2: iVar0 = joaat("component_smg_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_pi_supp"); break;

		case 5: iVar0 = joaat("component_at_scope_macro_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_smg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_assaultrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_assaultrifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_at_ar_flsh"); break;

		case 5: iVar0 = joaat("component_at_scope_macro"); break;

		case 6: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 7: iVar0 = joaat("component_assaultrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_carbinerifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_carbinerifle_clip_01"); break;

		case 1: iVar0 = joaat("component_carbinerifle_clip_02"); break;

		case 2: iVar0 = joaat("component_carbinerifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_railcover_01"); break;

		case 4: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 5: iVar0 = joaat("component_at_ar_flsh"); break;

		case 6: iVar0 = joaat("component_at_scope_medium"); break;

		case 7: iVar0 = joaat("component_at_ar_supp"); break;

		case 8: iVar0 = joaat("component_carbinerifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_advancedrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_advancedrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_advancedrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_advancedrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_mg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_mg_clip_01"); break;

		case 1: iVar0 = joaat("component_mg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_scope_small_02"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_mg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_combatmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatmg_clip_01"); break;

		case 1: iVar0 = joaat("component_combatmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_scope_medium"); break;

		case 4: iVar0 = joaat("component_combatmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_pumpshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_sr_supp"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_pumpshotgun_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_assaultshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultshotgun_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultshotgun_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;
		}
		break;

	case joaat("weapon_sniperrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sniperrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_sniperrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_heavysniper"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_heavysniper_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;
		}
		break;

	case joaat("weapon_grenadelauncher"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_scope_small"); break;
		}
		break;

	case joaat("weapon_minigun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_minigun_clip_01"); break;
		}
		break;

	case joaat("weapon_assaultsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_assaultsmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_ar_supp_02"); break;
		}
		break;

	case joaat("weapon_pistol50"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol50_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol50_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol50_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpdw"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpdw_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpdw_clip_02"); break;

		case 2: iVar0 = joaat("component_combatpdw_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_small"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sawnoffshotgun_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_bullpuprifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_bullpuprifle_clip_01"); break;

		case 1: iVar0 = joaat("component_bullpuprifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 6: iVar0 = joaat("component_bullpuprifle_varmod_low"); break;
		}
		break;

	case joaat("weapon_snspistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_snspistol_clip_01"); break;

		case 1: iVar0 = joaat("component_snspistol_clip_02"); break;

		case 2: iVar0 = joaat("component_snspistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_specialcarbine"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_specialcarbine_clip_01"); break;

		case 1: iVar0 = joaat("component_specialcarbine_clip_02"); break;

		case 2: iVar0 = joaat("component_specialcarbine_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_medium"); break;

		case 5: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_specialcarbine_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_knuckle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_knuckle_varmod_pimp"); break;

		case 1: iVar0 = joaat("component_knuckle_varmod_ballas"); break;

		case 2: iVar0 = joaat("component_knuckle_varmod_dollar"); break;

		case 3: iVar0 = joaat("component_knuckle_varmod_diamond"); break;

		case 4: iVar0 = joaat("component_knuckle_varmod_hate"); break;

		case 5: iVar0 = joaat("component_knuckle_varmod_love"); break;

		case 6: iVar0 = joaat("component_knuckle_varmod_player"); break;

		case 7: iVar0 = joaat("component_knuckle_varmod_king"); break;

		case 8: iVar0 = joaat("component_knuckle_varmod_vagos"); break;
		}
		break;

	case joaat("weapon_machinepistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_machinepistol_clip_01"); break;

		case 1: iVar0 = joaat("component_machinepistol_clip_02"); break;

		case 2: iVar0 = joaat("component_machinepistol_clip_03"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;
		}
		break;

	case joaat("weapon_switchblade"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_switchblade_varmod_var1"); break;

		case 1: iVar0 = joaat("component_switchblade_varmod_var2"); break;
		}
		break;

	case joaat("weapon_revolver"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_revolver_clip_01"); break;

		case 1: iVar0 = joaat("component_revolver_varmod_boss"); break;

		case 2: iVar0 = joaat("component_revolver_varmod_goon"); break;
		}
		break;

	case -1121678507:
		switch (iParam1) {
		case 0: iVar0 = -2067221805; break;

		case 1: iVar0 = -1820405577; break;
		}
		break;

	default:
		if (iParam0 != 0) {
			iVar1 = func_298(iParam0, &uVar2);
			if (iVar1 != -1) {
				if (iParam1 < dlc1::get_num_dlc_weapon_components(iVar1)) {
					if (dlc1::get_dlc_weapon_component_data(iVar1, iParam1, &Var41)) {
						return Var41.f_3;
					}
				}
			}
		}
		break;
	}
	return iVar0;
}

// Position - 0xFBEC
int func_298(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xFC27
int func_299(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (iParam0) {
	case 0: iVar0 = 1993361168; break;

	case 1: iVar0 = 1277010230; break;

	case 2: iVar0 = 932043479; break;

	case 3: iVar0 = -690654591; break;

	case 4: iVar0 = -1459198205; break;

	case 5: iVar0 = 195782970; break;

	case 6: iVar0 = -438797331; break;

	case 7: iVar0 = 896793492; break;

	case 8: iVar0 = 495159329; break;

	case 9: iVar0 = -1155528315; break;

	case 10: iVar0 = -515636489; break;

	case 11: iVar0 = -871913299; break;

	case 12: iVar0 = -1352759032; break;

	case 13: iVar0 = -542958961; break;

	case 14: iVar0 = 1682645887; break;

	case 15: iVar0 = -859470162; break;

	case 16: iVar0 = -2125426402; break;

	case 17: iVar0 = 2067210266; break;

	case 18: iVar0 = -538172856; break;

	case 19: iVar0 = 1783244476; break;

	case 20: iVar0 = 439844898; break;

	case 21: iVar0 = -24829327; break;

	case 22: iVar0 = 1949306232; break;

	case 23: iVar0 = -1941230881; break;

	case 24: iVar0 = -1033554448; break;

	case 25: iVar0 = 320513715; break;

	case 26: iVar0 = -695165975; break;

	case 27: iVar0 = -281028447; break;

	case 28: iVar0 = -686713772; break;

	case 29: iVar0 = 347509793; break;

	case 30: iVar0 = 1769089473; break;

	case 31: iVar0 = 189935548; break;

	case 33: iVar0 = 248801358; break;

	case 34: iVar0 = 386596758; break;

	case 35: iVar0 = -157212362; break;

	case 36: iVar0 = 436985596; break;

	case 37: iVar0 = -47957369; break;

	case 38: iVar0 = 575938238; break;
	}
	return iVar0;
}

// Position - 0xFE9B
void func_300(int iParam0) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (func_13(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_294[iVar0] = ped::get_ped_armour(iParam0);
	}
}

// Position - 0xFED7
void func_301(var *uParam0, int iParam1) {
	int iVar0;
	vector3 vVar1;
	float *fVar4;
	int iVar5;

	*uParam0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	uParam0->f_3 = entity::get_entity_heading(player::player_ped_id());
	uParam0->f_5 = ped::get_ped_parachute_state(player::player_ped_id());
	if (player::is_player_playing(player::player_id())) {
		uParam0->f_4 = player::get_player_wanted_level(player::player_id());
	}
	if (system::vdist(*uParam0, 320.9934f, 265.2515f, 82.1221f) < 10f) {
		*uParam0 = {301.2162f, 202.1357f, 103.3797f};
		uParam0->f_3 = 156.5144f;
	}
	else if (system::vdist(*uParam0, 377.153f, -717.567f, 10.0536f) < 10f) {
		*uParam0 = {394.2567f, -713.5439f, 28.2853f};
		uParam0->f_3 = 276.6273f;
	}
	else if (system::vdist(*uParam0, -1425.564f, -244.3f, 15.8053f) < 10f) {
		*uParam0 = {-1423.472f, -214.2539f, 45.5004f};
		uParam0->f_3 = 353.8757f;
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("finale_choice")) > 0) {
		*uParam0 = {4.2587f, 525.0214f, 173.6281f};
		uParam0->f_3 = 203.6746f;
	}
	else if (gameplay::is_bit_set(Global_69950, 4)) {
		*uParam0 = {452.0255f, 5571.85f, 780.1859f};
		uParam0->f_3 = 78.9858f;
	}
	else if (gameplay::is_bit_set(Global_69950, 5)) {
		*uParam0 = {-745.4462f, 5595.146f, 40.6594f};
		uParam0->f_3 = 261.747f;
	}
	else if (gameplay::is_bit_set(Global_69950, 6)) {
		*uParam0 = {-1675.521f, -1125.59f, 12.091f};
		uParam0->f_3 = 271.8208f;
	}
	else if (gameplay::is_bit_set(Global_69950, 7)) {
		*uParam0 = {-1631.219f, -1112.805f, 12.0212f};
		uParam0->f_3 = 316.8879f;
	}
	else if (interior::get_interior_from_entity(player::player_ped_id()) ==
			 interior::get_interior_at_coords_with_type(1272.659f, -1715.467f, 53.7715f, "v_lesters")) {
		*uParam0 = {1276.956f, -1725.189f, 53.6551f};
		uParam0->f_3 = 204.1703f;
	}
	else if (entity::is_entity_in_angled_area(player::player_ped_id(), -415.4365f, 2068.289f, 113.3002f, -564.9516f,
											  1884.703f, 134.0403f, 258.75f, 0, 1, 0) ||
			 entity::is_entity_in_angled_area(player::player_ped_id(), -596.4706f, 2089.921f, 125.4128f, -581.2134f,
											  2036.256f, 136.2836f, 9.5f, 0, 1, 0)) {
		*uParam0 = {-601.59f, 2099.197f, 128.8928f};
		uParam0->f_3 = 204.7498f;
	}
	else if (system::vdist(*uParam0, -1007.393f, -477.9584f, 52.5357f) < 8f) {
		*uParam0 = {-1018.376f, -483.9436f, 36.0964f};
		uParam0->f_3 = 114.7664f;
	}
	else if (system::vdist(*uParam0, 480.6662f, -1317.808f, 28.20303f) < 15f) {
		*uParam0 = {497.7238f, -1310.932f, 28.2372f};
		uParam0->f_3 = 289.3663f;
	}
	else if (system::vdist(*uParam0, 2329.527f, 2571.311f, 45.6779f) < 5f) {
		*uParam0 = {2316.93f, 2594.153f, 45.7199f};
		uParam0->f_3 = 348.1325f;
	}
	if (iParam1 == 1) {
		if (func_304(&iVar0)) {
			if (func_303(iVar0, &vVar1, &fVar4)) {
				vVar1.z++;
				*uParam0 = {vVar1};
				uParam0->f_3 = fVar4;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 207.4336f, -1019.795f, -100.4728f, 189.9338f,
												  -1019.623f, -95.56883f, 17.1875f, 0, 1, 0)) {
			iVar5 = func_10();
			if (iVar5 == 0) {
				*uParam0 = {-65.1234f, 81.2517f, 70.5644f};
				uParam0->f_3 = 71.6237f;
			}
			else if (iVar5 == 1) {
				*uParam0 = {-68.5531f, -1824.377f, 25.9424f};
				uParam0->f_3 = 215.8295f;
			}
			else if (iVar5 == 2) {
				*uParam0 = {-220.8189f, -1162.302f, 22.0242f};
				uParam0->f_3 = 70.2711f;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 483.7175f, -1326.63f, 28.2135f, 474.9644f,
												  -1307.998f, 34.49498f, 12f, 0, 1, 0)) {
			*uParam0 = {495.4108f, -1306.08f, 29.2883f};
			uParam0->f_3 = 213.6273f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), -1146.77f, -1534.22f, 3.37f, -1158.453f,
												  -1517.75f, 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_3 = 305.6424f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 439.5432f, -996.9769f, 24.88307f, 428.2935f,
												  -997.0192f, 28.57458f, 8.5f, 0, 1, 0)) {
			*uParam0 = {431.8853f, -1013.133f, 28.7907f};
			uParam0->f_3 = 186.6814f;
		}
		else if (func_302(*uParam0, "v_hospital", 307.3065f, -589.9595f, 43.302f)) {
			*uParam0 = {279.4137f, -585.8815f, 43.2502f};
			uParam0->f_3 = 48.8028f;
		}
	}
}

// Position - 0x10434
bool func_302(vector3 vParam0, char *sParam3, vector3 vParam4) {
	int iVar0;
	int iVar1;

	if (!interior::_are_coords_colliding_with_exterior(vParam0)) {
		iVar0 = interior::get_interior_at_coords_with_type(vParam4, sParam3);
		if (!interior::is_valid_interior(iVar0)) {
			return false;
		}
		iVar1 = interior::get_interior_from_collision(vParam0);
		if (iVar1 == iVar0) {
			return true;
		}
	}
	return false;
}

// Position - 0x10478
bool func_303(int iParam0, var *uParam1, float *fParam2) {
	*uParam1 = {0f, 0f, 0f};
	*fParam2 = 0f;
	switch (iParam0) {
	case 0:
		*uParam1 = {-829.842f, -191.7454f, 36.4386f};
		*fParam2 = 29.5061f;
		break;

	case 1:
		*uParam1 = {129.8484f, -1716.528f, 28.0702f};
		*fParam2 = 50.3483f;
		break;

	case 2:
		*uParam1 = {-1296.913f, -1120.999f, 5.3951f};
		*fParam2 = 0.9933f;
		break;

	case 3:
		*uParam1 = {1938.028f, 3718.736f, 31.3154f};
		*fParam2 = 118.2305f;
		break;

	case 4:
		*uParam1 = {1197.866f, -469.3809f, 65.0885f};
		*fParam2 = 346.4477f;
		break;

	case 5:
		*uParam1 = {-32.2161f, -135.8212f, 56.0532f};
		*fParam2 = 186.0052f;
		break;

	case 6:
		*uParam1 = {-287.7696f, 6238.081f, 30.2902f};
		*fParam2 = 316.1349f;
		break;

	case 7:
		*uParam1 = {99.2876f, -1395.16f, 28.2759f};
		*fParam2 = 320.2739f;
		break;

	case 8:
		*uParam1 = {1679.445f, 4819.056f, 41.0035f};
		*fParam2 = 4.6192f;
		break;

	case 9:
		*uParam1 = {411.3063f, -809.1863f, 28.1554f};
		*fParam2 = 1.8972f;
		break;

	case 10:
		*uParam1 = {-1088.054f, 2699.167f, 19.2748f};
		*fParam2 = 129.7382f;
		break;

	case 11:
		*uParam1 = {1194.163f, 2695.644f, 36.9225f};
		*fParam2 = 1.1454f;
		break;

	case 12:
		*uParam1 = {-821.2829f, -1088.027f, 10.0499f};
		*fParam2 = 120.5883f;
		break;

	case 13:
		*uParam1 = {-3.3416f, 6521.303f, 30.2961f};
		*fParam2 = 316.4451f;
		break;

	case 14:
		*uParam1 = {-1208.417f, -785.9635f, 16.0139f};
		*fParam2 = 36.3181f;
		break;

	case 15:
		*uParam1 = {623.1845f, 2739.191f, 40.9588f};
		*fParam2 = 3.5411f;
		break;

	case 16:
		*uParam1 = {130.9555f, -198.2084f, 53.41f};
		*fParam2 = 251.3506f;
		break;

	case 17:
		*uParam1 = {-3164.065f, 1067.317f, 19.6778f};
		*fParam2 = 101.2229f;
		break;

	case 18:
		*uParam1 = {-713.2797f, -174.2767f, 35.8962f};
		*fParam2 = 29.8138f;
		break;

	case 19:
		*uParam1 = {-147.0616f, -306.4322f, 37.7912f};
		*fParam2 = 160.4526f;
		break;

	case 20:
		*uParam1 = {-1461.355f, -230.6092f, 48.3064f};
		*fParam2 = 318.7851f;
		break;

	case 21:
		*uParam1 = {-1347.739f, -1278.573f, 3.8952f};
		*fParam2 = 17.9365f;
		break;

	case 22:
		*uParam1 = {325.6833f, 164.3263f, 102.4425f};
		*fParam2 = 68.6407f;
		break;

	case 23:
		*uParam1 = {1858.774f, 3742.393f, 32.0779f};
		*fParam2 = 301.2329f;
		break;

	case 24:
		*uParam1 = {-286.3272f, 6202.802f, 30.3323f};
		*fParam2 = 225.1334f;
		break;

	case 25:
		*uParam1 = {-1161.596f, -1417.7f, 3.712f};
		*fParam2 = 246.9161f;
		break;

	case 26:
		*uParam1 = {1308.952f, -1660.611f, 50.2362f};
		*fParam2 = 163.5456f;
		break;

	case 27:
		*uParam1 = {-3161.585f, 1074.214f, 19.6847f};
		*fParam2 = 98.6092f;
		break;

	case 28:
		*uParam1 = {28.423f, -1110.814f, 28.2848f};
		*fParam2 = 85.2495f;
		break;

	case 29:
		*uParam1 = {1704.966f, 3749.709f, 33.0188f};
		*fParam2 = 45.6778f;
		break;

	case 30:
		*uParam1 = {223.949f, -38.7894f, 68.6483f};
		*fParam2 = 159.4265f;
		break;

	case 31:
		*uParam1 = {837.7854f, -1017.963f, 26.3045f};
		*fParam2 = 181.0445f;
		break;

	case 32:
		*uParam1 = {-313.1914f, 6093.351f, 30.4625f};
		*fParam2 = 315.8405f;
		break;

	case 33:
		*uParam1 = {-663.4631f, -952.8069f, 20.3143f};
		*fParam2 = 92.6796f;
		break;

	case 34:
		*uParam1 = {-1323.06f, -392.8577f, 35.4596f};
		*fParam2 = 210.7398f;
		break;

	case 35:
		*uParam1 = {-1106.102f, 2684.35f, 18.0953f};
		*fParam2 = 127.0383f;
		break;

	case 36:
		*uParam1 = {-3157.932f, 1081.309f, 19.6953f};
		*fParam2 = 100.2942f;
		break;

	case 37:
		*uParam1 = {2562.882f, 312.8641f, 107.4612f};
		*fParam2 = 179.205f;
		break;

	case 38:
		*uParam1 = {822.48f, -2142.875f, 27.8496f};
		*fParam2 = 355.0598f;
		break;

	case 39:
		*uParam1 = {-1137.053f, -1993.916f, 12.1677f};
		*fParam2 = 43.1213f;
		break;

	case 40:
		*uParam1 = {717.8107f, -1084.081f, 21.3094f};
		*fParam2 = 93.2649f;
		break;

	case 41:
		*uParam1 = {-387.6789f, -128.2568f, 37.6796f};
		*fParam2 = 119.1085f;
		break;

	case 42:
		*uParam1 = {117.8835f, 6599.415f, 31.0134f};
		*fParam2 = 90.7225f;
		break;

	case 43:
		*uParam1 = {1201.709f, 2664.813f, 36.8102f};
		*fParam2 = 133.9002f;
		break;

	case 44:
		*uParam1 = {-200.1521f, -1297.502f, 30.296f};
		*fParam2 = 269.0687f;
		break;

	case 45:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		break;
	}
	return !func_184(*uParam1, 0f, 0f, 0f, 0);
}

// Position - 0x10B07
bool func_304(int *iParam0) {
	if (!entity::is_entity_dead(player::player_ped_id(), 0) && !ped::is_ped_injured(player::player_ped_id())) {
		if (func_315()) {
			*iParam0 = func_310(entity::get_entity_coords(player::player_ped_id(), 0), 6, -1, 0, 1, -1);
			if (func_309(*iParam0) && !func_305(*iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x10B62
int func_305(int iParam0) { return func_306(iParam0, 0, 1); }

// Position - 0x10B72
int func_306(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		return gameplay::is_bit_set(Global_91543.f_1308[iParam0], iParam1);
	}
	else if (network::network_is_game_in_progress()) {
		if (func_308() == 0) {
			return gameplay::is_bit_set(func_287(func_307(iParam0), -1, 0), iParam1);
		}
	}
	else {
		return gameplay::is_bit_set(Global_101700.f_668[iParam0], iParam1);
	}
	return 0;
}

// Position - 0x10BD2
int func_307(int iParam0) {
	switch (iParam0) {
	case 0: return 822;

	case 1: return 823;

	case 2: return 824;

	case 3: return 825;

	case 4: return 826;

	case 5: return 827;

	case 6: return 828;

	case 7: return 829;

	case 8: return 830;

	case 9: return 831;

	case 10: return 832;

	case 11: return 833;

	case 12: return 834;

	case 13: return 835;

	case 14: return 836;

	case 15: return 838;

	case 16: return 839;

	case 17: return 840;

	case 18: return 841;

	case 19: return 842;

	case 20: return 843;

	case 21: return 844;

	case 22: return 845;

	case 23: return 846;

	case 24: return 847;

	case 25: return 848;

	case 26: return 849;

	case 27: return 850;

	case 28: return 851;

	case 29: return 852;

	case 30: return 853;

	case 31: return 854;

	case 32: return 855;

	case 33: return 856;

	case 34: return 857;

	case 35: return 858;

	case 36: return 859;

	case 37: return 860;

	case 38: return 861;

	case 39: return 862;

	case 40: return 866;

	case 41: return 867;

	case 42: return 868;

	case 43: return 869;

	case 44: return 5847;

	case 45: return 3780;

	default: break;
	}
	return 6022;
}

// Position - 0x10E99
int func_308() { return Global_25190; }

// Position - 0x10EA4
int func_309(int iParam0) { return func_306(iParam0, 5, 1); }

// Position - 0x10EB4
int func_310(vector3 vParam0, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = -1;
	iVar0 = 0;
	while (iVar0 <= 45) {
		if (iParam3 == 6 || iParam3 == func_314(iVar0)) {
			if (!iParam5 || func_313(iVar0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, func_311(iVar0, 0), 1);
				if (fVar1 < fVar2 && (fVar1 <= IntToFloat(iParam4) || iParam4 == -1) && (iParam6 || iVar0 != 21) &&
					iVar0 != iParam7) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x10F56
Vector3 func_311(int iParam0, int iParam1) {
	switch (iParam0) {
	case -1: return 0f, 0f, 0f;

	case 0: return -821.9946f, -187.1776f, 36.5689f;

	case 1: return 133.5702f, -1710.918f, 28.2916f;

	case 2: return -1287.082f, -1116.558f, 5.9901f;

	case 3: return 1933.119f, 3726.079f, 31.8444f;

	case 4: return 1208.333f, -470.917f, 65.208f;

	case 5: return -30.7448f, -148.4921f, 56.0765f;

	case 6: return -280.8165f, 6231.771f, 30.6955f;

	case 7: return 80.665f, -1391.669f, 28.3761f;

	case 8: return 1687.881f, 4820.55f, 41.0096f;

	case 9: return 419.531f, -807.5787f, 28.4896f;

	case 10: return -1094.049f, 2704.171f, 18.0873f;

	case 11: return 1197.972f, 2704.22f, 37.1572f;

	case 12: return -818.6218f, -1077.533f, 10.3282f;

	case 13: return -0.2361f, 6516.045f, 30.8684f;

	case 14: return -1199.809f, -776.6886f, 16.3237f;

	case 15: return 618.1857f, 2752.567f, 41.0881f;

	case 16: return 126.6853f, -212.5027f, 53.5578f;

	case 17: return -3168.966f, 1055.287f, 19.8632f;

	case 18: return -715.3598f, -155.7742f, 36.4105f;

	case 19: return -158.2199f, -304.9663f, 38.735f;

	case 20: return -1455.005f, -233.1862f, 48.7936f;

	case 21: return -1335.973f, -1278.555f, 3.8598f;

	case 22: return 321.6098f, 179.4165f, 102.5865f;

	case 23: return 1861.685f, 3750.08f, 32.0318f;

	case 24: return -290.1603f, 6199.095f, 30.4871f;

	case 25: return -1153.948f, -1425.019f, 3.9544f;

	case 26: return 1322.455f, -1651.125f, 51.1885f;

	case 27: return -3169.42f, 1074.727f, 19.8343f;

	case 28: return 17.6804f, -1114.288f, 28.797f;

	case 29: return 1697.979f, 3753.2f, 33.7053f;

	case 30: return 245.2711f, -45.8126f, 68.941f;

	case 31: return 844.1248f, -1025.571f, 27.1948f;

	case 32: return -325.8904f, 6077.026f, 30.4548f;

	case 33: return -664.2178f, -943.3646f, 20.8292f;

	case 34: return -1313.948f, -390.9637f, 35.592f;

	case 35: return -1111.238f, 2688.463f, 17.6131f;

	case 36: return -3165.231f, 1082.855f, 19.8438f;

	case 37: return 2569.612f, 302.576f, 107.7349f;

	case 38: return 811.8699f, -2149.102f, 28.6363f;

	case 39: return -1147.314f, -1992.434f, 12.1803f;

	case 40: return 724.524f, -1089.081f, 21.1692f;

	case 41: return -354.5272f, -135.4011f, 38.185f;

	case 42: return 113.2615f, 6624.28f, 30.7871f;

	case 43: return 1174.707f, 2644.45f, 36.7552f;

	case 44:
		if (iParam1) {
			return -211.5f, -1324.2f, 30.296f;
		}
		else {
			return -205.6654f, -1311.113f, 30.296f;
		}
		break;

	case 45: return func_312(Global_93004);
	}
	return 1000000f, 1000000f, 1000000f;
}

// Position - 0x11470
Vector3 func_312(int iParam0) {
	switch (iParam0) {
	case 1: return 1060f, -2990f, -35f;

	case 2: return 1060f, -2990f, -35f;

	case 3: return 974.9542f, -3000.091f, -35f;

	case 6: return -1586.36f, -566.6f, 106.17f;

	case 7: return -1389.87f, -465.17f, 82.68f;

	case 8: return -145.81f, -590.2f, 171.13f;

	case 9: return -62.49f, -823.55f, 288.74f;

	case 4: return 1102.515f, -3158.888f, -38.5186f;

	case 5: return 1005.861f, -3156.162f, -39.907f;

	default: return 0f, 0f, -200f;
	}
	return 0f, 0f, -200f;
}

// Position - 0x11586
int func_313(int iParam0) { return func_306(iParam0, 0, 0); }

// Position - 0x11596
int func_314(int iParam0) {
	switch (iParam0) {
	case -1: return 6;

	case 0: return 0;

	case 1: return 0;

	case 2: return 0;

	case 3: return 0;

	case 4: return 0;

	case 5: return 0;

	case 6: return 0;

	case 7: return 1;

	case 8: return 1;

	case 9: return 1;

	case 10: return 1;

	case 11: return 1;

	case 12: return 1;

	case 13: return 1;

	case 14: return 1;

	case 15: return 1;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 2;

	case 23: return 2;

	case 24: return 2;

	case 25: return 2;

	case 26: return 2;

	case 27: return 2;

	case 28: return 3;

	case 29: return 3;

	case 30: return 3;

	case 31: return 3;

	case 32: return 3;

	case 33: return 3;

	case 34: return 3;

	case 35: return 3;

	case 36: return 3;

	case 37: return 3;

	case 38: return 3;

	case 39: return 4;

	case 40: return 4;

	case 41: return 4;

	case 42: return 4;

	case 43: return 4;

	case 44: return 4;

	case 45: return 5;
	}
	return 6;
}

// Position - 0x11809
bool func_315() { return Global_91543.f_303 > 0; }

// Position - 0x1181A
var func_316() {
	int *iVar0;

	func_326(&iVar0, time::get_clock_seconds());
	func_325(&iVar0, time::get_clock_minutes());
	func_324(&iVar0, time::get_clock_hours());
	func_319(&iVar0, time::get_clock_day_of_month());
	func_318(&iVar0, time::get_clock_month());
	func_317(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x11860
void func_317(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x118E6
void func_318(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x11919
void func_319(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_323(*uParam0);
	iVar1 = func_321(*uParam0);
	if (iParam1 < 1 || iParam1 > func_320(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x1196A
int func_320(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x11A0C
var func_321(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_322(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x11A31
int func_322(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x11A48
int func_323(var uParam0) { return uParam0 & 15; }

// Position - 0x11A55
void func_324(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x11A8F
void func_325(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x11ACA
void func_326(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x11B06
int func_327(char *sParam0) {
	if (gameplay::are_strings_equal("BailBond1", sParam0)) {
		return 0;
	}
	else if (gameplay::are_strings_equal("BailBond2", sParam0)) {
		return 1;
	}
	else if (gameplay::are_strings_equal("BailBond3", sParam0)) {
		return 2;
	}
	else if (gameplay::are_strings_equal("BailBond4", sParam0)) {
		return 3;
	}
	return -1;
}

// Position - 0x11B5C
struct<2> func_328(int iParam0) {
	struct<2> Var0;

	StringCopy(&Var0, "", 8);
	switch (iParam0) {
	case 0: StringCopy(&Var0, "ABI1", 8); break;

	case 1: StringCopy(&Var0, "ABI2", 8); break;

	case 2: StringCopy(&Var0, "BA1", 8); break;

	case 3: StringCopy(&Var0, "BA2", 8); break;

	case 4: StringCopy(&Var0, "BA3", 8); break;

	case 5: StringCopy(&Var0, "BA3A", 8); break;

	case 6: StringCopy(&Var0, "BA3C", 8); break;

	case 7: StringCopy(&Var0, "BA4", 8); break;

	case 8: StringCopy(&Var0, "DRE1", 8); break;

	case 9: StringCopy(&Var0, "EPS1", 8); break;

	case 10: StringCopy(&Var0, "EPS2", 8); break;

	case 11: StringCopy(&Var0, "EPS3", 8); break;

	case 12: StringCopy(&Var0, "EPS4", 8); break;

	case 13: StringCopy(&Var0, "EPS5", 8); break;

	case 14: StringCopy(&Var0, "EPS6", 8); break;

	case 15: StringCopy(&Var0, "EPS7", 8); break;

	case 16: StringCopy(&Var0, "EPS8", 8); break;

	case 17: StringCopy(&Var0, "EXT1", 8); break;

	case 18: StringCopy(&Var0, "EXT2", 8); break;

	case 19: StringCopy(&Var0, "EXT3", 8); break;

	case 20: StringCopy(&Var0, "EXT4", 8); break;

	case 21: StringCopy(&Var0, "FAN1", 8); break;

	case 22: StringCopy(&Var0, "FAN2", 8); break;

	case 23: StringCopy(&Var0, "FAN3", 8); break;

	case 24: StringCopy(&Var0, "HAO1", 8); break;

	case 25: StringCopy(&Var0, "HUN1", 8); break;

	case 26: StringCopy(&Var0, "HUN2", 8); break;

	case 27: StringCopy(&Var0, "JOS1", 8); break;

	case 28: StringCopy(&Var0, "JOS2", 8); break;

	case 29: StringCopy(&Var0, "JOS3", 8); break;

	case 30: StringCopy(&Var0, "JOS4", 8); break;

	case 31: StringCopy(&Var0, "MAU1", 8); break;

	case 32: StringCopy(&Var0, "MIN1", 8); break;

	case 33: StringCopy(&Var0, "MIN2", 8); break;

	case 34: StringCopy(&Var0, "MIN3", 8); break;

	case 35: StringCopy(&Var0, "MRS1", 8); break;

	case 36: StringCopy(&Var0, "MRS2", 8); break;

	case 37: StringCopy(&Var0, "NI1", 8); break;

	case 38: StringCopy(&Var0, "NI1A", 8); break;

	case 39: StringCopy(&Var0, "NI1B", 8); break;

	case 40: StringCopy(&Var0, "NI1C", 8); break;

	case 41: StringCopy(&Var0, "NI1D", 8); break;

	case 42: StringCopy(&Var0, "NI2", 8); break;

	case 43: StringCopy(&Var0, "NI3", 8); break;

	case 44: StringCopy(&Var0, "OME1", 8); break;

	case 45: StringCopy(&Var0, "OME2", 8); break;

	case 46: StringCopy(&Var0, "PA1", 8); break;

	case 47: StringCopy(&Var0, "PA2", 8); break;

	case 48: StringCopy(&Var0, "PA3", 8); break;

	case 49: StringCopy(&Var0, "PA3A", 8); break;

	case 50: StringCopy(&Var0, "PA3B", 8); break;

	case 51: StringCopy(&Var0, "PA4", 8); break;

	case 52: StringCopy(&Var0, "RAM1", 8); break;

	case 53: StringCopy(&Var0, "RAM2", 8); break;

	case 54: StringCopy(&Var0, "RAM3", 8); break;

	case 55: StringCopy(&Var0, "RAM4", 8); break;

	case 56: StringCopy(&Var0, "RAM5", 8); break;

	case 57: StringCopy(&Var0, "SAS1", 8); break;

	case 58: StringCopy(&Var0, "TON1", 8); break;

	case 59: StringCopy(&Var0, "TON2", 8); break;

	case 60: StringCopy(&Var0, "TON3", 8); break;

	case 61: StringCopy(&Var0, "TON4", 8); break;

	case 62: StringCopy(&Var0, "TON5", 8); break;

	default: break;
	}
	return Var0;
}

//Position - 0x11FA8
int func_329(char* sParam0, int iParam1)
{
	int iVar0;
	char *sVar1;
	int iVar33;
	int iVar34;

	iVar33 = gameplay::get_hash_key(sParam0);
	iVar34 = 0;
	iVar34 = 0;
	while (iVar34 < 63) {
		iVar0 = iVar34;
		func_330(iVar0, &sVar1);
		if (gameplay::get_hash_key(sVar1) == iVar33) {
			return iVar0;
		}
		iVar34++;
	}
	if (iParam1 == 0) {
	}
	return -1;
}

// Position - 0x11FF1
void func_330(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		func_331(uParam1, "Abigail1", func_333(iParam0), 0, 0, 4, -1604.668f, 5239.1f, 3.01f, 66, "", 109, 0,
				 "ambient_Diving", 0, 0, 1, 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 1:
		func_331(uParam1, "Abigail2", func_333(iParam0), 0, 0, 4, -1592.84f, 5214.04f, 3.01f, 400, "", 110, 0, "", 0, 0,
				 -1, 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 2:
		func_331(uParam1, "Barry1", func_333(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", 74, 0, "", 0, 1, -1,
				 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 3:
		func_331(uParam1, "Barry2", func_333(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", -1, 0, "", 0, 1, -1,
				 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 4:
		func_331(uParam1, "Barry3", func_333(iParam0), 0, 1, 4, 414f, -761f, 29f, 381, "", -1, 0, "", 164, 1, -1, 0, 2,
				 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 5:
		func_331(uParam1, "Barry3A", func_333(iParam0), 1, 1, 0, 1199.27f, -1255.63f, 34.23f, 381, "BARSTASH", 84, 0,
				 "", 166, 0, 7, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 6:
		func_331(uParam1, "Barry3C", func_333(iParam0), 3, 1, 0, -468.9f, -1713.06f, 18.21f, 381, "", 84, 0, "", 166, 0,
				 7, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 7:
		func_331(uParam1, "Barry4", func_333(iParam0), 0, 1, 4, 237.65f, -385.41f, 44.4f, 381, "", 85, 0,
				 "postRC_Barry4", 0, 0, -1, 4, 2, 800, 2000, func_332(iParam0), 0, 0);
		break;

	case 8:
		func_331(uParam1, "Dreyfuss1", func_333(iParam0), 0, 2, 4, -1458.97f, 485.99f, 115.38f, 66, "LETTERS_HINT", 106,
				 0, "", 0, 0, -1, 4, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 9:
		func_331(uParam1, "Epsilon1", func_333(iParam0), 0, 3, 4, -1622.89f, 4204.87f, 83.3f, 66, "", 86, 0, "", 0, 1,
				 10, 4, 1, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 10:
		func_331(uParam1, "Epsilon2", func_333(iParam0), 0, 3, 4, 242.7f, 362.7f, 104.74f, 206, "", 87, 16, "", 0, 0,
				 11, 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 11:
		func_331(uParam1, "Epsilon3", func_333(iParam0), 0, 3, 4, 1835.53f, 4705.86f, 38.1f, 206, "", 88, 16, "epsCars",
				 0, 0, 12, 4, 1, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 12:
		func_331(uParam1, "Epsilon4", func_333(iParam0), 0, 3, 4, 1826.13f, 4698.88f, 38.92f, 206, "", 90, 16,
				 "postRC_Epsilon4", 0, 0, 13, 4, 1, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 13:
		func_331(uParam1, "Epsilon5", func_333(iParam0), 0, 3, 4, 637.02f, 119.7093f, 89.5f, 206, "", 89, 16,
				 "epsRobes", 0, 0, 14, 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 14:
		func_331(uParam1, "Epsilon6", func_333(iParam0), 0, 3, 4, -2892.93f, 3192.37f, 11.66f, 206, "", 93, 0, "", 0, 0,
				 15, 4, 1, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 15:
		func_331(uParam1, "Epsilon7", func_333(iParam0), 0, 3, 4, 524.43f, 3079.82f, 39.48f, 206, "", -1, 16,
				 "epsDesert", 0, 0, 16, 4, 1, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 16:
		func_331(uParam1, "Epsilon8", func_333(iParam0), 0, 3, 4, -697.75f, 45.38f, 43.03f, 206, "", 94, 16,
				 "epsilonTract", 0, 0, -1, 4, 1, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 17:
		func_331(uParam1, "Extreme1", func_333(iParam0), 0, 4, 4, -188.22f, 1296.1f, 302.86f, 66, "", -1, 0, "", 4, 1,
				 18, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 18:
		func_331(uParam1, "Extreme2", func_333(iParam0), 0, 4, 4, -954.19f, -2760.05f, 14.64f, 382, "", 96, 0, "", 171,
				 0, 19, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 19:
		func_331(uParam1, "Extreme3", func_333(iParam0), 0, 4, 4, -63.8f, -809.5f, 321.8f, 382, "", 97, 0, "", 0, 0, 20,
				 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 20:
		func_331(uParam1, "Extreme4", func_333(iParam0), 0, 4, 4, 1731.41f, 96.96f, 170.39f, 382, "", 98, 16, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 21:
		func_331(uParam1, "Fanatic1", func_333(iParam0), 0, 5, 4, -1877.82f, -440.649f, 45.05f, 405, "", 74, 0, "", 0,
				 1, -1, 4, 1, 700, 2000, func_332(iParam0), 1, 0);
		break;

	case 22:
		func_331(uParam1, "Fanatic2", func_333(iParam0), 0, 5, 4, 809.66f, 1279.76f, 360.49f, 405, "", -1, 0, "", 0, 1,
				 -1, 4, 4, 700, 2000, func_332(iParam0), 1, 0);
		break;

	case 23:
		func_331(uParam1, "Fanatic3", func_333(iParam0), 0, 5, 4, -915.6f, 6139.2f, 5.5f, 405, "", -1, 0, "", 0, 1, -1,
				 4, 2, 700, 2000, func_332(iParam0), 0, 1);
		break;

	case 24:
		func_331(uParam1, "Hao1", func_333(iParam0), 0, 6, 4, -72.29f, -1260.63f, 28.14f, 66, "", -1, 0,
				 "controller_Races", 13, 1, -1, 4, 2, 2000, 500, func_332(iParam0), 0, 1);
		break;

	case 25:
		func_331(uParam1, "Hunting1", func_333(iParam0), 0, 7, 4, 1804.32f, 3931.33f, 32.82f, 66, "", -1, 0, "", 174, 1,
				 26, 4, 4, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 26:
		func_331(uParam1, "Hunting2", func_333(iParam0), 0, 7, 4, -684.17f, 5839.16f, 16.09f, 384, "", 99, 0, "", 7, 0,
				 -1, 4, 4, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 27:
		func_331(uParam1, "Josh1", func_333(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 66, "", -1, 0, "forSaleSigns",
				 0, 1, 28, 4, 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 28:
		func_331(uParam1, "Josh2", func_333(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", 105, 0, "", 0, 0,
				 29, 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 29:
		func_331(uParam1, "Josh3", func_333(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", -1, 16, "", 0, 0,
				 30, 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 30:
		func_331(uParam1, "Josh4", func_333(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 385, "", -1, 36, "", 0, 0, -1,
				 4, 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 31:
		func_331(uParam1, "Maude1", func_333(iParam0), 0, 9, 4, 2726.1f, 4145f, 44.3f, 66, "", -1, 0,
				 "BailBond_Launcher", 0, 1, -1, 4, 4, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 32:
		func_331(uParam1, "Minute1", func_333(iParam0), 0, 10, 4, 327.85f, 3405.7f, 35.73f, 66, "", -1, 0, "", 0, 1, 33,
				 4, 4, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 33:
		func_331(uParam1, "Minute2", func_333(iParam0), 0, 10, 4, 18f, 4527f, 105f, 386, "", -1, 10, "", 0, 0, 34, 4, 4,
				 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 34:
		func_331(uParam1, "Minute3", func_333(iParam0), 0, 10, 4, -303.82f, 6211.29f, 31.05f, 386, "", -1, 10, "", 0, 0,
				 -1, 4, 4, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 35:
		func_331(uParam1, "MrsPhilips1", func_333(iParam0), 0, 11, 4, 1972.59f, 3816.43f, 32.42f, 66, "", -1, 0,
				 "ambient_MrsPhilips", 0, 1, -1, 4, 4, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 36:
		func_331(uParam1, "MrsPhilips2", func_333(iParam0), 0, 11, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 1, -1, 4, 4, 0,
				 2359, func_332(iParam0), 0, 0);
		break;

	case 37:
		func_331(uParam1, "Nigel1", func_333(iParam0), 0, 12, 4, -1097.16f, 790.01f, 164.52f, 66, "", -1, 0, "", 177, 1,
				 -1, 1, 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 38:
		func_331(uParam1, "Nigel1A", func_333(iParam0), 0, 12, 1, -558.65f, 284.49f, 90.86f, 149, "NIGITEMS", 100, 0,
				 "", 0, 0, 42, 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 39:
		func_331(uParam1, "Nigel1B", func_333(iParam0), 0, 12, 1, -1034.15f, 366.08f, 80.11f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_332(iParam0), 1, 1);
		break;

	case 40:
		func_331(uParam1, "Nigel1C", func_333(iParam0), 0, 12, 1, -623.91f, -266.17f, 37.76f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_332(iParam0), 1, 1);
		break;

	case 41:
		func_331(uParam1, "Nigel1D", func_333(iParam0), 0, 12, 1, -1096.85f, 67.68f, 52.95f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_332(iParam0), 1, 1);
		break;

	case 42:
		func_331(uParam1, "Nigel2", func_333(iParam0), 0, 12, 4, -1310.7f, -640.22f, 26.54f, 149, "", -1, 8, "", 0, 0,
				 43, 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 43:
		func_331(uParam1, "Nigel3", func_333(iParam0), 0, 12, 4, -44.75f, -1288.67f, 28.21f, 149, "", -1, 16,
				 "postRC_Nigel3", 0, 0, -1, 4, 4, 0, 2359, func_332(iParam0), 1, 1);
		break;

	case 44:
		func_331(uParam1, "Omega1", func_333(iParam0), 0, 13, 4, 2468.51f, 3437.39f, 49.9f, 66, "", -1, 0,
				 "spaceshipParts", 0, 1, 45, 4, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 45:
		func_331(uParam1, "Omega2", func_333(iParam0), 0, 13, 4, 2319.44f, 2583.58f, 46.76f, 387, "", 107, 0, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 46:
		func_331(uParam1, "Paparazzo1", func_333(iParam0), 0, 14, 4, -149.75f, 285.81f, 93.67f, 66, "", -1, 0, "", 0, 1,
				 47, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 47:
		func_331(uParam1, "Paparazzo2", func_333(iParam0), 0, 14, 4, -70.71f, 301.43f, 106.79f, 389, "", -1, 8, "", 0,
				 0, 48, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 48:
		func_331(uParam1, "Paparazzo3", func_333(iParam0), 0, 14, 4, -257.22f, 292.85f, 90.63f, 389, "", -1, 8, "", 183,
				 1, -1, 2, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 49:
		func_331(uParam1, "Paparazzo3A", func_333(iParam0), 0, 14, 2, 305.52f, 157.19f, 102.94f, 389, "PAPPHOTO", 102,
				 0, "", 0, 0, 51, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 50:
		func_331(uParam1, "Paparazzo3B", func_333(iParam0), 0, 14, 2, 1040.96f, -534.42f, 60.17f, 389, "", 102, 0, "",
				 0, 0, 51, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 51:
		func_331(uParam1, "Paparazzo4", func_333(iParam0), 0, 14, 4, -484.2f, 229.68f, 82.21f, 389, "", -1, 8, "", 0, 1,
				 -1, 4, 2, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 52:
		func_331(uParam1, "Rampage1", func_333(iParam0), 0, 15, 4, 908f, 3643.7f, 32.2f, 66, "", -1, 0, "", 0, 1, 54, 4,
				 4, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 54:
		func_331(uParam1, "Rampage3", func_333(iParam0), 0, 15, 4, 465.1f, -1849.3f, 27.8f, 84, "", -1, 0, "", 0, 1, 55,
				 4, 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 55:
		func_331(uParam1, "Rampage4", func_333(iParam0), 0, 15, 4, -161f, -1669.7f, 33f, 84, "", -1, 0, "", 0, 0, 56, 4,
				 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 56:
		func_331(uParam1, "Rampage5", func_333(iParam0), 0, 15, 4, -1298.2f, 2504.14f, 21.09f, 84, "", -1, 0, "", 0, 0,
				 53, 4, 4, 0, 2359, func_332(iParam0), 0, 0);
		break;

	case 53:
		func_331(uParam1, "Rampage2", func_333(iParam0), 0, 15, 4, 1181.5f, -400.1f, 67.5f, 84, "", -1, 0,
				 "rampage_controller", 0, 0, -1, 4, 4, 0, 2359, func_332(iParam0), 1, 0);
		break;

	case 57:
		func_331(uParam1, "TheLastOne", func_333(iParam0), 0, 16, 4, -1298.98f, 4640.16f, 105.67f, 66, "", 133, 1, "",
				 0, 1, -1, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 58:
		func_331(uParam1, "Tonya1", func_333(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 66, "AM_H_RCFS", -1, 0,
				 "ambient_TonyaCall", 24, 1, 59, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 59:
		func_331(uParam1, "Tonya2", func_333(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48,
				 "ambient_Tonya", 185, 0, 60, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	case 60:
		func_331(uParam1, "Tonya3", func_333(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 187, 0, 61, 4, 2, 0,
				 2359, func_332(iParam0), 0, 1);
		break;

	case 61:
		func_331(uParam1, "Tonya4", func_333(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 0, 62, 4, 2, 0, 2359,
				 func_332(iParam0), 0, 1);
		break;

	case 62:
		func_331(uParam1, "Tonya5", func_333(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_332(iParam0), 0, 1);
		break;

	default: break;
	}
}

// Position - 0x131A6
void func_331(var *uParam0, char *sParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6, vector3 vParam7,
			  int iParam10, char *sParam11, int iParam12, int iParam13, char *sParam14, int iParam15, int iParam16,
			  int iParam17, int iParam18, int iParam19, int iParam20, int iParam21, int iParam22, int iParam23,
			  int iParam24) {
	uParam0->f_4 = iParam5;
	*uParam0 = sParam1;
	uParam0->f_1 = {Param2};
	uParam0->f_3 = iParam4;
	uParam0->f_5 = iParam6;
	uParam0->f_6 = {vParam7};
	uParam0->f_9 = iParam10;
	StringCopy(&uParam0->f_10, sParam11, 16);
	uParam0->f_14 = iParam12;
	uParam0->f_15 = iParam13;
	StringCopy(&uParam0->f_16, sParam14, 24);
	uParam0->f_22 = iParam15;
	uParam0->f_23 = iParam16;
	uParam0->f_24 = iParam17;
	uParam0->f_25 = iParam18;
	uParam0->f_26 = iParam19;
	uParam0->f_27 = iParam20;
	uParam0->f_28 = iParam21;
	uParam0->f_29 = iParam22;
	uParam0->f_30 = iParam23;
	uParam0->f_31 = iParam24;
}

// Position - 0x13237
int func_332(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 0;

	case 2: return 1;

	case 3: return 1;

	case 4: return 0;

	case 5: return 1;

	case 6: return 1;

	case 7: return 0;

	case 8: return 1;

	case 9: return 0;

	case 10: return 0;

	case 11: return 0;

	case 12: return 1;

	case 13: return 0;

	case 14: return 1;

	case 15: return 0;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 1;

	case 23: return 1;

	case 24: return 1;

	case 25: return 1;

	case 26: return 1;

	case 27: return 0;

	case 28: return 1;

	case 29: return 1;

	case 30: return 1;

	case 31: return 0;

	case 32: return 1;

	case 33: return 1;

	case 34: return 1;

	case 35: return 0;

	case 36: return 0;

	case 37: return 0;

	case 38: return 1;

	case 39: return 1;

	case 40: return 1;

	case 41: return 1;

	case 42: return 1;

	case 43: return 1;

	case 44: return 0;

	case 45: return 0;

	case 46: return 1;

	case 47: return 1;

	case 48: return 0;

	case 49: return 1;

	case 50: return 1;

	case 51: return 1;

	case 52: return 1;

	case 54: return 1;

	case 55: return 1;

	case 56: return 1;

	case 53: return 1;

	case 57: return 1;

	case 58: return 1;

	case 59: return 1;

	case 60: return 1;

	case 61: return 1;

	case 62: return 1;

	default: break;
	}
	return 0;
}

// Position - 0x1357D
struct<2> func_333(int iParam0) {
	struct<2> Var0;
	char[] cVar2[8];

	StringCopy(&Var0, "", 8);
	cVar2 = {func_328(iParam0)};
	if (gameplay::is_string_null_or_empty(&cVar2)) {
	}
	else {
		StringCopy(&Var0, "RC_", 8);
		StringConCat(&Var0, &cVar2, 8);
	}
	return Var0;
}

//Position - 0x135B4
int func_334(int iParam0)
{
	switch (iParam0) {
	case 69:
	case 70: return func_335(Global_101700.f_8044.f_99.f_205[10]);

	case 74:
	case 75: return func_335(Global_101700.f_8044.f_99.f_205[8]);

	case 84:
	case 85: return func_335(Global_101700.f_8044.f_99.f_205[11]);

	case 90: return func_335(Global_101700.f_8044.f_99.f_205[7]);

	case 93: return func_335(Global_101700.f_8044.f_99.f_205[9]);
	}
	return 0;
}

// Position - 0x13670
int func_335(int iParam0) {
	switch (iParam0) {
	case 1:
	case 3:
	case 5:
	case 6:
	case 8: return 0;

	case 2:
	case 4:
	case 7:
	case 9: return 1;
	}
	return -1;
}

// Position - 0x136C4
int func_336(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = gameplay::get_hash_key(sParam0);
	iVar1 = func_337(iVar0, 1);
	if (iVar1 == -1 && !iParam1) {
	}
	return iVar1;
}

// Position - 0x136EE
int func_337(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 94) {
		if (Global_82612[iVar0 /*34*/].f_6 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	if (!iParam1) {
	}
	return -1;
}

// Position - 0x13724
void func_338() {
	char *sVar0;

	switch (iLocal_1460) {
	case 0: sVar0 = "ASS_ML_TXT_BB"; break;

	case 1: sVar0 = "ASS_ML_TXT_YT"; break;

	case 2: sVar0 = "ASS_ML_TXT_WW"; break;

	case 3: sVar0 = "ASS_ML_TXT_BK"; break;
	}
	if (!gameplay::is_string_null_or_empty(sVar0)) {
		func_339(12, 1, sVar0, 1, 0, 0, 0, 0, 1, 0, 1);
	}
}

// Position - 0x1378C
int func_339(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10) {
	int iVar0;
	char *sVar1;
	int iVar2;
	char *sVar3;
	int iVar4;
	char *sVar5;
	char *sVar6;

	gameplay::clear_bit(&G_SleepModeOnOn25, 10);
	iVar0 = 0;
	sVar1 = "NULL";
	iVar2 = -99;
	sVar3 = "NULL";
	iVar4 = 0;
	sVar5 = "NULL";
	sVar6 = "NULL";
	if (func_340(iParam0, sParam2, iParam3, iVar0, sVar1, sVar3, iVar2, iParam4, iParam5, iParam6, iParam8, iParam9,
				 iParam10, iVar4, sVar5, sVar6, iParam1) == 1) {
		if (iParam8 == 1) {
			Global_3020 = iParam7;
			Global_2923[3 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
			Global_3000 = iParam0;
			gameplay::set_bit(&G_SleepModeOnOn25, 1);
			gameplay::set_bit(&G_SleepModeOnOn25, 7);
		}
		return 1;
	}
	return 0;
}

// Position - 0x13821
int func_340(var uParam0, char *sParam1, int iParam2, int iParam3, char *sParam4, char *sParam5, int iParam6,
			 int iParam7, var uParam8, var uParam9, bool bParam10, var uParam11, var uParam12, int iParam13,
			 char *sParam14, char *sParam15, int iParam16) {
	int iVar0;

	if (iParam13 > 99) {
	}
	if (gameplay::are_strings_equal(sParam14, sParam15)) {
	}
	func_27();
	iVar0 = 0;
	switch (iParam16) {
	case 0:
		if (Global_14443 == 0) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	case 2:
		if (Global_14443 == 2) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	case 1:
		if (Global_14443 == 1) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	default: iVar0 = 0; break;
	}
	if (iVar0 == 0) {
		if (player::is_player_playing(player::player_id())) {
			if (ped::is_ped_swimming_under_water(player::player_ped_id())) {
				return 0;
			}
		}
		if (Global_101700.f_13010[Global_14443 /*20*/].f_17 == 1) {
			return 0;
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("apptextmessage")) > 0) {
			return 0;
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("apptextmessage")) > 0) {
			return 0;
		}
	}
	if (func_349() == 0) {
		func_347();
		return 0;
	}
	func_346(Global_16812);
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/], sParam1, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_17 = uParam0;
	if (iParam2 == 0) {
	}
	else {
		Global_101700.f_13100[Global_16812 /*104*/].f_24 = iParam2;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_25 = iParam7;
	Global_101700.f_13100[Global_16812 /*104*/].f_26 = uParam8;
	Global_101700.f_13100[Global_16812 /*104*/].f_29 = uParam9;
	Global_101700.f_13100[Global_16812 /*104*/].f_30 = uParam12;
	Global_101700.f_13100[Global_16812 /*104*/].f_31 = uParam11;
	Global_101700.f_13100[Global_16812 /*104*/].f_28 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_32 = iParam3;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_33, sParam4, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_49 = iParam6;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_50, sParam5, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_66 = iParam13;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_67, sParam14, 64);
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_83, sParam15, 64);
	if (gameplay::is_bit_set(G_SleepModeOnOn25, 10)) {
		Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 1;
		Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 1;
		Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 1;
		Global_3019 = 4;
		func_345(0);
		func_345(2);
		func_345(1);
	}
	else {
		func_27();
		switch (iParam16) {
		case 3: Global_101700.f_13100[Global_16812 /*104*/].f_99[Global_14443] = 1; break;

		case 0: Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 1; break;

		case 2: Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 1; break;

		case 1: Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 1; break;
		}
		if (iParam16 == 3) {
			switch (Global_14443) {
			case 0:
				func_345(0);
				Global_3019 = 0;
				break;

			case 1:
				func_345(1);
				Global_3019 = 1;
				break;

			case 2:
				func_345(2);
				Global_3019 = 2;
				break;

			case 3:
				func_345(3);
				Global_3019 = 3;
				break;

			default: Global_3019 = 4; break;
			}
		}
	}
	if (iParam7 == 1) {
		if (gameplay::is_bit_set(G_SleepModeOnOn25, 10)) {
			Global_101700.f_13010[0 /*20*/].f_17 = 1;
			Global_101700.f_13010[1 /*20*/].f_17 = 1;
			Global_101700.f_13010[2 /*20*/].f_17 = 1;
		}
		else {
			switch (iParam16) {
			case 3: Global_101700.f_13010[Global_14443 /*20*/].f_17 = 1; break;

			case 0: Global_101700.f_13010[0 /*20*/].f_17 = 1; break;

			case 2: Global_101700.f_13010[2 /*20*/].f_17 = 1; break;

			case 1: Global_101700.f_13010[1 /*20*/].f_17 = 1; break;
			}
		}
	}
	Global_16814[Global_16812] = 0;
	if (bParam10) {
		func_27();
		if (Global_14386) {
			StringCopy(&Global_14432, "Phone_SoundSet_Prologue", 24);
		}
		else {
			switch (Global_14443) {
			case 0: StringCopy(&Global_14432, "Phone_SoundSet_Michael", 24); break;

			case 2: StringCopy(&Global_14432, "Phone_SoundSet_Trevor", 24); break;

			case 1: StringCopy(&Global_14432, "Phone_SoundSet_Franklin", 24); break;

			default: StringCopy(&Global_14432, "Phone_SoundSet_Default", 24); break;
			}
		}
		if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 != 1) {
			if (!func_344()) {
				audio::play_sound_frontend(-1, "Text_Arrive_Tone", &Global_14432, 1);
			}
		}
	}
	if (!Global_14605) {
		if (Global_14443.f_1 == 6) {
			func_343(Global_14424, "SET_DATA_SLOT_EMPTY", 1f, -1082130432, -1082130432, -1082130432, -1082130432);
			func_341(1);
			func_343(Global_14424, "DISPLAY_VIEW", 1f, system::to_float(Global_14423), -1082130432, -1082130432,
					 -1082130432);
		}
	}
	return 1;
}

// Position - 0x13CD8
void func_341(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;

	Global_16813 = 0;
	Global_2918 = iParam0;
	iVar0 = 0;
	while (iVar0 < 9) {
		Global_2882[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		iVar1 = 0;
		if (func_12(14)) {
			while (iVar1 < 34) {
				if (iParam0 == Global_2320[iVar1 /*15*/].f_11) {
					if (iVar0 == Global_2320[iVar1 /*15*/].f_4) {
						if (Global_2882[iVar0] == 0) {
							Global_2846[iVar0] = iVar1;
							if (iVar1 == 3) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 3)) {
									iVar2 = 42;
									Global_14608 = 1;
								}
								else {
									iVar2 = 255;
									Global_14608 = 0;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar2);
								graphics::_pop_scaleform_movie_function_void();
							}
							if (Global_2452520) {
								if (iVar1 == 14) {
									func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(Global_16808), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0,
											 0);
								}
							}
							Global_2882[iVar0] = 1;
						}
					}
				}
				iVar1++;
			}
		}
		else {
			while (iVar1 < 34) {
				if (iParam0 == Global_2320[iVar1 /*15*/].f_11) {
					if (iVar0 == Global_2320[iVar1 /*15*/].f_4) {
						if (Global_2882[iVar0] == 0) {
							Global_2846[iVar0] = iVar1;
							if (iVar1 == 1) {
								iVar3 = 0;
								while (iVar3 < 35) {
									if (Global_101700.f_13100[iVar3 /*104*/].f_24 != 0) {
										if (Global_101700.f_13100[iVar3 /*104*/].f_28 == 0) {
											if (Global_101700.f_13100[iVar3 /*104*/].f_99[Global_14443] == 1) {
												Global_16813++;
											}
										}
									}
									iVar3++;
								}
								func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10),
										 system::to_float(Global_16813), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else if (iVar1 == 7) {
								if (Global_69702) {
									iVar4 = 0;
									iVar4 = Global_2594052;
									iVar5 = 0;
									while (iVar5 < 12) {
										if (Global_2594053[iVar5 /*104*/].f_24 != 0) {
											if (Global_2594053[iVar5 /*104*/].f_28 == 0) {
												if (Global_2594053[iVar5 /*104*/
												]
														.f_99[Global_14443] == 1) {
													iVar4++;
												}
											}
										}
										iVar5++;
									}
									func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(iVar4), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
								}
								else {
									switch (Global_14443) {
									case 0: iVar6 = Global_36917; break;

									case 1: iVar6 = Global_36918; break;

									case 2: iVar6 = Global_36919; break;

									default: break;
									}
									func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(iVar6), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
								}
							}
							else if (iVar1 == 14) {
								func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10),
										 system::to_float(Global_16808), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else if (iVar1 == 20) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2319);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 2) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 6)) {
									iVar7 = 42;
								}
								else {
									iVar7 = 255;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar7);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 3) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 3)) {
									iVar8 = 42;
									Global_14608 = 1;
								}
								else {
									iVar8 = 255;
									Global_14608 = 0;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar8);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 8) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(42);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 23 &&
									 gameplay::are_strings_equal(&Global_2320[iVar1 /*15*/], "CELL_BENWEB") &&
									 gameplay::is_bit_set(G_SleepModeOffOn11, 6)) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_90(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(42);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (Global_2320[iVar1 /*15*/].f_10 == 57 && iVar1 == 23) {
								iVar9 = 0;
								iVar9 = Global_1618161.f_1;
								func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10), system::to_float(iVar9), -1f,
										 &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else {
								func_342(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10), system::to_float(0), -1f,
										 &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							Global_2882[iVar0] = 1;
						}
					}
				}
				iVar1++;
			}
		}
		iVar0++;
	}
}

// Position - 0x14281
void func_342(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  char *sParam7, char *sParam8, char *sParam9, char *sParam10, char *sParam11) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	if (!gameplay::is_string_null_or_empty(sParam7)) {
		func_90(sParam7);
	}
	if (!gameplay::is_string_null_or_empty(sParam8)) {
		func_90(sParam8);
	}
	if (!gameplay::is_string_null_or_empty(sParam9)) {
		func_90(sParam9);
	}
	if (!gameplay::is_string_null_or_empty(sParam10)) {
		func_90(sParam10);
	}
	if (!gameplay::is_string_null_or_empty(sParam11)) {
		func_90(sParam11);
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x14334
void func_343(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x14397
bool func_344() { return Global_1315233; }

// Position - 0x143A3
void func_345(int iParam0) {
	var uVar0;
	var uVar1;

	uVar0 = Global_101700.f_13010[iParam0 /*20*/].f_8;
	uVar0 = uVar0;
	uVar1 = uVar1;
}

// Position - 0x143C2
void func_346(int iParam0) {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;

	uVar0 = time::get_clock_seconds();
	uVar1 = time::get_clock_minutes();
	uVar2 = time::get_clock_hours();
	uVar3 = time::get_clock_day_of_month();
	uVar4 = time::get_clock_month() + 1;
	uVar5 = time::get_clock_year();
	Global_101700.f_13100[iParam0 /*104*/].f_18 = uVar0;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_1 = uVar1;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_2 = uVar2;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_3 = uVar3;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_4 = uVar4;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_5 = uVar5;
}

// Position - 0x14454
void func_347() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (Global_69702) {
		iVar0 = 24;
		iVar1 = 33;
	}
	else {
		iVar0 = 0;
		iVar1 = 20;
	}
	iVar2 = iVar0;
	Global_16812 = 34;
	Global_101700.f_13100[Global_16812 /*104*/].f_18 = -1;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_1 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_2 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_3 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_5 = 99999;
	while (iVar2 < iVar1) {
		if (!func_348(Global_101700.f_13100[iVar2 /*104*/].f_18, Global_101700.f_13100[Global_16812 /*104*/].f_18)) {
			Global_16812 = iVar2;
		}
		iVar2++;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_24 = 1;
}

// Position - 0x1451F
int func_348(struct<6> Param0, struct<6> Param6) {
	struct<4> Var0;
	struct<4> Var6;
	int iVar12;
	int iVar13;

	if (Param0.f_5 < Param6.f_5) {
		return 0;
	}
	if (Param0.f_5 > Param6.f_5) {
		return 1;
	}
	if (Param0.f_5 == Param6.f_5) {
		if (Param0.f_4 < Param6.f_4) {
			return 0;
		}
		if (Param0.f_4 > Param6.f_4) {
			return 1;
		}
		if (Param0.f_4 == Param6.f_4) {
			Var0 = Param0;
			Var0.f_1 = Param0.f_1 * 60;
			Var0.f_2 = Param0.f_2 * 3600;
			Var0.f_3 = Param0.f_3 * 86400;
			iVar12 = Var0 + Var0.f_1 + Var0.f_2 + Var0.f_3;
			Var6 = Param6;
			Var6.f_1 = Param6.f_1 * 60;
			Var6.f_2 = Param6.f_2 * 3600;
			Var6.f_3 = Param6.f_3 * 86400;
			iVar13 = Var6 + Var6.f_1 + Var6.f_2 + Var6.f_3;
			if (iVar12 > iVar13 || iVar12 == iVar13) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
	return 0;
}

// Position - 0x1460A
int func_349() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (Global_69702) {
		iVar0 = 24;
		iVar1 = 33;
	}
	else {
		iVar0 = 0;
		iVar1 = 20;
	}
	iVar2 = iVar0;
	while (iVar2 < iVar1) {
		if (Global_101700.f_13100[iVar2 /*104*/].f_24 == 0) {
			Global_16812 = iVar2;
			return 1;
		}
		iVar2++;
	}
	iVar2 = iVar0;
	Global_16812 = 34;
	Global_101700.f_13100[Global_16812 /*104*/].f_18 = -1;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_1 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_2 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_3 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_5 = 99999;
	while (iVar2 < iVar1) {
		if (Global_101700.f_13100[iVar2 /*104*/].f_24 == 0 || Global_101700.f_13100[iVar2 /*104*/].f_24 == 1) {
			if (!func_348(Global_101700.f_13100[iVar2 /*104*/].f_18,
						  Global_101700.f_13100[Global_16812 /*104*/].f_18)) {
				Global_16812 = iVar2;
			}
		}
		iVar2++;
	}
	if (Global_16812 == 34) {
		return 0;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 0;
	return 1;
}

// Position - 0x14761
int func_350(var *uParam0) {
	switch (iLocal_1460) {
	case 2:
		if (!func_360(uParam0)) {
			return 0;
		}
		break;

	case 1:
		if (!func_359(uParam0)) {
			return 0;
		}
		break;

	case 3:
		if (!func_358(uParam0)) {
			return 0;
		}
		break;

	case 0:
		if (!func_351(uParam0)) {
			return 0;
		}
		break;
	}
	return 1;
}

// Position - 0x147CE
int func_351(var *uParam0) {
	if (func_357(&uParam0->f_34) && func_353(&uLocal_1929) && func_352()) {
		return 1;
	}
	return 0;
}

// Position - 0x147FB
int func_352() {
	streaming::request_model(joaat("premier"));
	streaming::request_model(joaat("dilettante"));
	streaming::request_model(joaat("vigero"));
	while (!streaming::has_model_loaded(joaat("premier")) || !streaming::has_model_loaded(joaat("dilettante")) ||
		   !streaming::has_model_loaded(joaat("vigero"))) {
		return 0;
	}
	return 1;
}

// Position - 0x14853
int func_353(var *uParam0) { return func_354(uParam0); }

// Position - 0x14861
int func_354(var *uParam0) {
	int iVar0;

	if (!uParam0->f_271) {
		return 1;
	}
	iVar0 = 0;
	while (iVar0 < 15) {
		if (gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 30)) {
			if (!gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 29)) {
				return 0;
			}
			if (!func_355(&(*uParam0)[iVar0 /*18*/])) {
				return 0;
			}
		}
		iVar0++;
	}
	uParam0->f_271 = 0;
	return 1;
}

// Position - 0x148C5
int func_355(var *uParam0) { return func_356(*uParam0, &uParam0->f_2, uParam0->f_1); }

// Position - 0x148DC
int func_356(int iParam0, char *sParam1, int iParam2) {
	if (gameplay::is_bit_set(iParam0, 30)) {
		if (gameplay::is_bit_set(iParam0, 29)) {
			switch (func_155(iParam0)) {
			case 0: return streaming::has_model_loaded(iParam2);

			case 1: return streaming::has_anim_dict_loaded(sParam1);

			case 2: return streaming::has_clip_set_loaded(sParam1);

			case 3: return graphics::has_streamed_texture_dict_loaded(sParam1);

			case 4: return vehicle::has_vehicle_recording_been_loaded(iParam2, sParam1);

			case 5: return ai::get_is_waypoint_recording_loaded(sParam1);

			case 6: return audio::request_script_audio_bank(sParam1, gameplay::is_bit_set(iParam0, 27), -1);

			case 7: return script::has_script_with_name_hash_loaded(iParam2);

			case 8: return ui::has_additional_text_loaded(iParam2);

			case 9: return streaming::has_ptfx_asset_loaded();

			default: break;
			}
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x149D0
int func_357(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				}
				return 0;
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x14A17
int func_358(var *uParam0) {
	if (func_357(&uParam0->f_34) && func_353(&uLocal_1929)) {
		return 1;
	}
	return 0;
}

// Position - 0x14A3B
int func_359(var *uParam0) {
	if (func_357(&uParam0->f_34) && func_353(&uLocal_1929)) {
		return 1;
	}
	return 0;
}

// Position - 0x14A5F
int func_360(var *uParam0) {
	if (func_357(&uParam0->f_34) && func_353(&uLocal_1929)) {
		return 1;
	}
	return 0;
}

// Position - 0x14A83
int func_361(var *uParam0, var *uParam1, int iParam2) {
	if (iParam2) {
		if (!func_362()) {
			return 0;
		}
	}
	if (uParam0->f_274 == 0) {
		if (!ai::get_is_waypoint_recording_loaded("OJASbs_102") || !ai::get_is_waypoint_recording_loaded("OJASbs01") ||
			!ai::get_is_waypoint_recording_loaded("OJASbs02") || !ai::get_is_waypoint_recording_loaded("OJASbs03") ||
			!ai::get_is_waypoint_recording_loaded("OJASbs04") || !vehicle::has_vehicle_asset_loaded(uParam0->f_5) ||
			!vehicle::has_vehicle_asset_loaded(uParam0->f_15) || !streaming::has_ptfx_asset_loaded()) {
			return 0;
		}
	}
	else if (uParam0->f_274 == 1) {
		if (!ai::get_is_waypoint_recording_loaded("OJAShk_101") ||
			!ai::get_is_waypoint_recording_loaded("OJAShk_102") ||
			!ai::get_is_waypoint_recording_loaded("OJAShk_103") ||
			!ai::get_is_waypoint_recording_loaded("OJAShk_104") ||
			!streaming::has_anim_dict_loaded("ODDJOBS@assassinate@vice@incar")) {
		}
	}
	else if (uParam0->f_274 == 2) {
		if (!streaming::has_ptfx_asset_loaded()) {
		}
	}
	if (!ui::has_additional_text_loaded(3) && !func_357(&uParam0->f_34) && !func_353(uParam1)) {
		func_456(uParam1);
		return 0;
	}
	return 1;
}

// Position - 0x14BB0
int func_362() { return func_363(&Global_96040.f_2311); }

// Position - 0x14BC3
bool func_363(var *uParam0) {
	if (func_364(uParam0)) {
		if (streaming::has_model_loaded(uParam0->f_12.f_66)) {
			return true;
		}
		else {
			return false;
		}
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x14BF8
bool func_364(var *uParam0) {
	if (uParam0->f_12.f_66 == 0) {
		return false;
	}
	if (!func_366(uParam0->f_12.f_66, 0)) {
		return false;
	}
	if (uParam0->f_12.f_66 == joaat("stunt") && func_365(*uParam0, 1694.62f, 3276.27f, 41.31f, 1056964608, 0)) {
		return false;
	}
	return true;
}

// Position - 0x14C57
int func_365(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return 1;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x14CD2
int func_366(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_374()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_373() && !func_372() && !func_371() && !func_370() && !func_374()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_371()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_369(iParam0)) {
			return 0;
		}
	}
	if (!func_367(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x14E60
int func_367(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_368()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x14F2C
int func_368() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x14F40
int func_369(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x15C83
int func_370() { return 0; }

// Position - 0x15C8C
int func_371() { return 1; }

// Position - 0x15C95
int func_372() { return 1; }

// Position - 0x15C9E
int func_373() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x15CB7
bool func_374() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x15D72
void func_375(int iParam0) {
	if (!cam::is_screen_faded_in()) {
		cam::do_screen_fade_in(iParam0);
		while (!cam::is_screen_faded_in()) {
			system::wait(0);
		}
	}
}

// Position - 0x15D98
void func_376(int iParam0, int iParam1, int iParam2) {
	if (func_466() && func_378()) {
		while (Global_91486 != 6) {
			system::wait(0);
		}
		gameplay::set_game_paused(0);
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::clear_ped_wetness(player::player_ped_id());
			}
		}
		if (iParam0 != 0) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (entity::does_entity_exist(iParam0)) {
					if (vehicle::is_vehicle_driveable(iParam0, 0)) {
						if (!ped::is_ped_in_vehicle(player::player_ped_id(), iParam0, 0)) {
							ped::set_ped_into_vehicle(player::player_ped_id(), iParam0, iParam1);
							cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
							cam::set_gameplay_cam_relative_heading(0f);
							system::wait(0);
						}
					}
				}
			}
		}
		if (iParam2 == 1) {
			if (player::is_player_playing(player::player_id())) {
				player::set_player_control(player::player_id(), 1, 0);
			}
		}
		graphics::_stop_all_screen_effects();
		func_377(0);
	}
}

// Position - 0x15E5C
void func_377(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&Global_91491.f_20, 13);
	}
	else {
		gameplay::clear_bit(&Global_91491.f_20, 13);
	}
}

// Position - 0x15E85
var func_378() { return gameplay::is_bit_set(Global_91491.f_20, 13); }

// Position - 0x15E99
void func_379() {
	if (!entity::does_entity_exist(uLocal_1577[0])) {
		uLocal_1577[0] = vehicle::create_vehicle(iLocal_1584[0], -723.8201f, -916.5402f, 18.0145f, 267.798f, 1, 1);
	}
	if (!entity::does_entity_exist(uLocal_1577[1])) {
		uLocal_1577[1] = vehicle::create_vehicle(iLocal_1584[1], -735.5003f, -931.6205f, 18.0173f, 359.3239f, 1, 1);
		entity::set_entity_lod_dist(uLocal_1577[1], 100);
	}
	if (!entity::does_entity_exist(uLocal_1577[2])) {
		uLocal_1577[2] = vehicle::create_vehicle(iLocal_1584[0], -726.7143f, -940.2681f, 18.0173f, 178.3615f, 1, 1);
	}
	if (!entity::does_entity_exist(uLocal_1577[3])) {
		uLocal_1577[3] = vehicle::create_vehicle(iLocal_1584[2], -730.5711f, -909.9425f, 18.0349f, 357.4066f, 1, 1);
	}
}

// Position - 0x15F7D
int func_380(vector3 vParam0, float fParam3) { return func_381(&Global_96040.f_2311, vParam0, fParam3, 0); }

// Position - 0x15F97
int func_381(var *uParam0, vector3 vParam1, float fParam4, int iParam5) {
	int iVar0;
	vector3 vVar1;
	bool bVar4;
	var uVar5;
	int iVar8;

	if (func_364(uParam0)) {
		if (func_184(vParam1, 0f, 0f, 0f, 0)) {
			vParam1 = {*uParam0};
			fParam4 = uParam0->f_6;
		}
		if (uParam0->f_12.f_66 == joaat("monster") || uParam0->f_12.f_66 == joaat("marshall")) {
			if (object::is_point_in_angled_area(vParam1, -816.8716f, 185.6238f, 71.40275f, -807.4894f, 189.3762f,
												75.27323f, 6.5f, 0, 1)) {
				vParam1 = {-850.93f, 158.82f, 65.7f};
				fParam4 = 89.5f;
			}
		}
		if (func_363(uParam0)) {
			gameplay::clear_area(vParam1, 5f, 1, 0, 0, 0);
			func_410(vParam1, 5f, 0);
			iVar0 = vehicle::create_vehicle(uParam0->f_12.f_66, vParam1, fParam4, 1, 1);
			if (entity::does_entity_exist(iVar0)) {
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
				if (system::vdist2(vVar1, -1151.15f, -1530.32f, 7.48925f) <= 3f) {
					entity::set_entity_coords_no_offset(iVar0, vParam1, 0, 0, 1);
				}
				func_402(iVar0, &uParam0->f_12, 0, 1);
				bVar4 = true;
				if (vehicle::is_this_model_a_boat(uParam0->f_12.f_66) ||
					vehicle::_is_this_model_an_emergency_boat(uParam0->f_12.f_66)) {
					if (!water::test_probe_against_water(vParam1.x, vParam1.y, vParam1.z + 30f, vParam1.x, vParam1.y,
														 vParam1.z - 30f, &uVar5)) {
						bVar4 = false;
					}
				}
				if (bVar4) {
					vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
				}
				if (uParam0->f_7 == 1) {
					if (iParam5) {
						if (vehicle::is_this_model_a_car(entity::get_entity_model(iVar0))) {
							func_401(uParam0->f_11, 1);
						}
						else if (vehicle::is_this_model_a_bike(entity::get_entity_model(iVar0))) {
							func_401(uParam0->f_11, 2);
						}
					}
					vehicle::_0xAB04325045427AAE(iVar0, 0);
					vehicle::_0x428BACCDF5E26EAD(iVar0, 0);
					vehicle::set_vehicle_has_strong_axles(iVar0, 1);
					func_400(iVar0, uParam0->f_11);
				}
				else if (!func_398(iVar0, uParam0->f_3, uParam0->f_8) && uParam0->f_10 &&
						 gameplay::are_strings_equal(script::get_this_script_name(), "startup_positioning")) {
					iVar8 = func_397(iVar0);
					if (iVar8 == -1) {
						uParam0->f_10 = 0;
					}
					else {
						func_392(iVar8);
					}
				}
				if (Global_91491 != 13 && Global_91491 != 10 && Global_91491 != 11 && Global_91491 != 12) {
					if (gameplay::get_hash_key(&Global_91491.f_3) == Global_69519) {
						if (uParam0->f_12.f_66 == Global_101700.f_31389.f_69[21 /*78*/].f_66) {
							func_389(24, 0);
							func_392(24);
						}
					}
				}
				if (uParam0->f_9 == 1) {
					func_382(iVar0, uParam0->f_11);
				}
				streaming::set_model_as_no_longer_needed(uParam0->f_12.f_66);
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
			}
			return iVar0;
		}
	}
	return iVar0;
}

// Position - 0x16248
void func_382(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_383(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_270(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x1644A
int func_383(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_284(iParam0, 0, 0) ||
		func_284(iParam0, 1, 0) || func_284(iParam0, 2, 0) || func_266(iParam0) != 145 || func_388(iParam0) ||
		func_387(iParam0) || func_386(iParam0) || func_385(iParam0) || !func_384(entity::get_entity_model(iParam0))) {
		if (func_387(iParam0)) {
		}
		if (func_387(iParam0)) {
		}
		if (func_284(iParam0, 0, 0)) {
		}
		if (func_284(iParam0, 1, 0)) {
		}
		if (func_284(iParam0, 2, 0)) {
		}
		if (func_266(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x16527
int func_384(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_366(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x166D8
int func_385(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_366(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x1671E
int func_386(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x16759
bool func_387(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x167D5
int func_388(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x168BD
void func_389(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_391(iParam0, 0)) {
			func_390(iParam0, 1, 0);
			func_390(iParam0, 2, 0);
			func_390(iParam0, 3, 0);
			func_390(iParam0, 4, 0);
			func_390(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_390(iParam0, 0, 0);
	}
}

// Position - 0x1691A
void func_390(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0x16955
int func_391(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x16978
void func_392(int iParam0) {
	bool bVar0;

	if (iParam0 == -1) {
		return;
	}
	if (func_396(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			bVar0 = true;
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (vehicle::is_vehicle_driveable(Global_68531.f_139[iParam0], 0)) {
					if (ped::is_ped_in_vehicle(player::player_ped_id(), Global_68531.f_139[iParam0], 0)) {
						bVar0 = false;
					}
				}
			}
			if (bVar0) {
				entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
				vehicle::delete_vehicle(&Global_68531.f_139[iParam0]);
			}
		}
		Global_68531[iParam0] = 1;
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			if (iParam0 == 24 && func_391(iParam0, 0) && Global_69440.f_66 == 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] != 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] > 3 &&
				(!func_394(0, Global_68531.f_555[0 /*21*/].f_12) || !func_394(1, Global_68531.f_555[0 /*21*/].f_12))) {
				func_393(&Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/], &Global_69440);
				Global_69518 = Global_101700.f_31389.f_5591;
			}
			func_389(iParam0, 0);
		}
	}
}

// Position - 0x16AEA
void func_393(var *uParam0, var *uParam1) {
	uParam1->f_66 = uParam0->f_66;
	*uParam1 = *uParam0;
	uParam1->f_1 = {uParam0->f_1};
	uParam1->f_5 = uParam0->f_5;
	uParam1->f_6 = uParam0->f_6;
	uParam1->f_7 = uParam0->f_7;
	uParam1->f_8 = uParam0->f_8;
	uParam1->f_9 = {uParam0->f_9};
	uParam1->f_59 = {uParam0->f_59};
	uParam1->f_62 = uParam0->f_62;
	uParam1->f_63 = uParam0->f_63;
	uParam1->f_64 = uParam0->f_64;
	uParam1->f_65 = uParam0->f_65;
	uParam1->f_77 = uParam0->f_77;
	uParam1->f_67 = uParam0->f_67;
	uParam1->f_69 = uParam0->f_69;
	uParam1->f_68 = uParam0->f_68;
	uParam1->f_71 = uParam0->f_71;
	uParam1->f_72 = uParam0->f_72;
	uParam1->f_73 = uParam0->f_73;
	uParam1->f_74 = uParam0->f_74;
	uParam1->f_75 = uParam0->f_75;
	uParam1->f_76 = uParam0->f_76;
}

// Position - 0x16BB6
int func_394(int iParam0, int iParam1) {
	int iVar0;

	switch (iParam1) {
	case 0: iVar0 = 0; break;

	case 1: iVar0 = 1; break;

	case 2: iVar0 = 2; break;
	}
	if (iParam0 < 0 || iParam0 >= func_395(&Global_101700.f_31389.f_5038[iVar0 /*157*/])) {
		return 0;
	}
	return func_366(Global_101700.f_31389.f_5038[iVar0 /*157*/][iParam0 /*78*/].f_66, 0);
}

// Position - 0x16C28
int func_395(var *uParam0) { return *uParam0; }

// Position - 0x16C33
bool func_396(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_268(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_268(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_268(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_268(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_268(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_268(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_268(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_268(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_268(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_374()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_374()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_184(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_184(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_184(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0x1832C
int func_397(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0]) &&
			!entity::is_entity_dead(Global_68531.f_484[iVar0], 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[iVar0], 0)) {
			vehicle::get_vehicle_colours(iParam0, &iVar1, &iVar2);
			vehicle::get_vehicle_colours(Global_68531.f_484[iVar0], &iVar3, &iVar4);
			if (entity::get_entity_model(iParam0) == entity::get_entity_model(Global_68531.f_484[iVar0]) &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[iVar0]) &&
				iVar1 == iVar2 && iVar3 == iVar4) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x183EF
int func_398(int iParam0, vector3 vParam1, bool bParam4) {
	int iVar0;
	var uVar1[3];
	int iVar5;
	int iVar6;

	iVar0 = entity::get_entity_model(iParam0);
	switch (iVar0) {
	case joaat("cargobob"):
		if (func_399(iParam0, Global_68531.f_139[38], 0)) {
			func_392(38);
			return 1;
		}
		break;

	case joaat("firetruk"):
		if (func_399(iParam0, Global_68531.f_139[43], 1)) {
			func_392(43);
			return 1;
		}
		break;

	case joaat("cuban800"):
		iVar5 = ped::get_ped_nearby_vehicles(player::player_ped_id(), &uVar1);
		iVar6 = 0;
		while (iVar6 <= iVar5 - 1) {
			if (func_399(iParam0, uVar1[iVar6], 1) &&
				func_365(entity::get_entity_coords(uVar1[iVar6], 1), 2136.133f, 4780.563f, 39.9702f, 5f, 0)) {
				if (!bParam4 || func_184(vParam1, 0f, 0f, 0f, 0) ||
					gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1),
														  entity::get_entity_coords(uVar1[iVar6], 1), 1) < 10f) {
					vehicle::delete_vehicle(&iParam0);
					return 1;
				}
				else {
					return 0;
				}
			}
			iVar6++;
		}
		break;

	case joaat("luxor2"):
		if (entity::does_entity_exist(Global_68531.f_484[14]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[14], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[14]) == joaat("luxor2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[14])) {
				func_392(14);
				return 1;
			}
		}
		break;

	case joaat("swift2"):
		if (entity::does_entity_exist(Global_68531.f_484[20]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[20], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[20]) == joaat("swift2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[20])) {
				func_392(20);
				return 1;
			}
		}
		break;
	}
	return 0;
}

// Position - 0x185F7
bool func_399(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam1) && !entity::is_entity_dead(iParam1, 0) &&
		vehicle::is_vehicle_driveable(iParam1, 0)) {
		if (iParam2) {
			vehicle::get_vehicle_colours(iParam0, &iVar0, &iVar1);
			vehicle::get_vehicle_colours(iParam1, &iVar2, &iVar3);
			if (iVar0 == iVar2 && iVar1 == iVar3) {
				return true;
			}
		}
		else {
			return true;
		}
	}
	return false;
}

// Position - 0x18658
void func_400(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (!entity::does_entity_exist(Global_89155[iVar0])) {
			Global_89155[iVar0] = iParam0;
			Global_89165[iVar0] = iParam1;
			Global_89175[iVar0] = entity::get_entity_model(iParam0);
			if (vehicle::is_this_model_a_car(Global_89175[iVar0])) {
				Global_89203[iParam1 /*3*/][0] = -1;
			}
			else {
				Global_89203[iParam1 /*3*/][1] = -1;
			}
			iVar0 = 9;
		}
		if (iVar0 == 8) {
		}
		iVar0++;
	}
}

// Position - 0x186DA
void func_401(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (iParam0 == 145 || Global_89165[iVar0] == iParam0) {
				if (iParam1 == 0 || entity::get_entity_model(Global_89155[iVar0]) == func_268(iParam0, iParam1)) {
					if (!ped::is_ped_in_vehicle(player::player_ped_id(), Global_89155[iVar0], 0)) {
						entity::set_entity_as_mission_entity(Global_89155[iVar0], 0, 1);
						vehicle::delete_vehicle(&Global_89155[iVar0]);
						Global_89165[iVar0] = 145;
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x18778
void func_402(int iParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (gameplay::get_hash_key(&uParam1->f_1) != 0) {
			vehicle::set_vehicle_number_plate_text(iParam0, &uParam1->f_1);
		}
		if (*uParam1 >= 0 && *uParam1 < vehicle::get_number_of_vehicle_number_plates()) {
			vehicle::set_vehicle_number_plate_text_index(iParam0, *uParam1);
		}
		if (uParam1->f_66 == joaat("sovereign")) {
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 111;
		}
		else if (uParam1->f_66 == joaat("casco")) {
			iVar0 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_271(iVar0 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_271(iVar0 + 1));
			}
		}
		else if (uParam1->f_66 == joaat("sandking") || uParam1->f_66 == joaat("sandking2")) {
			iVar1 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_271(iVar1 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_271(iVar1 + 1));
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 13)) {
			vehicle::set_vehicle_custom_primary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_primary_colour(iParam0);
		}
		if (gameplay::is_bit_set(uParam1->f_77, 12)) {
			vehicle::set_vehicle_custom_secondary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_secondary_colour(iParam0);
		}
		vehicle::set_vehicle_colours(iParam0, uParam1->f_5, uParam1->f_6);
		if (uParam1->f_7 < 0) {
			uParam1->f_7 = 0;
		}
		if (uParam1->f_8 < 0) {
			uParam1->f_8 = 0;
		}
		vehicle::set_vehicle_extra_colours(iParam0, uParam1->f_7, uParam1->f_8);
		if (gameplay::is_bit_set(uParam1->f_77, 15) || func_409(iParam0) ||
			uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0 && uParam1->f_9[20] > 0)
			&&func_408() {
				uParam1->f_62 = 0;
				uParam1->f_63 = 0;
				uParam1->f_64 = 0;
			}
		else if (uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0) {
			uParam1->f_62 = 255;
			uParam1->f_63 = 255;
			uParam1->f_64 = 255;
		}
		vehicle::set_vehicle_tyre_smoke_color(iParam0, uParam1->f_62, uParam1->f_63, uParam1->f_64);
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			vehicle::set_vehicle_window_tint(iParam0, 0);
		}
		else {
			vehicle::set_vehicle_window_tint(iParam0, 0);
			vehicle::set_vehicle_window_tint(iParam0, uParam1->f_65);
		}
		vehicle::set_vehicle_tyres_can_burst(iParam0, !gameplay::is_bit_set(uParam1->f_77, 9));
		if (iParam2) {
			vehicle::set_vehicle_doors_locked(iParam0, uParam1->f_70);
		}
		vehicle::_set_vehicle_neon_lights_colour(iParam0, uParam1->f_74, uParam1->f_75, uParam1->f_76);
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 2, gameplay::is_bit_set(uParam1->f_77, 28));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 3, gameplay::is_bit_set(uParam1->f_77, 29));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 0, gameplay::is_bit_set(uParam1->f_77, 30));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 1, gameplay::is_bit_set(uParam1->f_77, 31));
		vehicle::set_vehicle_is_stolen(iParam0, gameplay::is_bit_set(uParam1->f_77, 10));
		if (vehicle::get_vehicle_livery_count(iParam0) > 1 && uParam1->f_67 >= 0) {
			vehicle::set_vehicle_livery(iParam0, uParam1->f_67);
		}
		if (uParam1->f_69 > -1 && uParam1->f_69 < 255) {
			if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(iParam0))) {
				if (vehicle::is_this_model_a_bike(entity::get_entity_model(iParam0))) {
					if (uParam1->f_69 == 6) {
						func_407(iParam0, uParam1->f_69);
					}
				}
				else {
					func_407(iParam0, uParam1->f_69);
				}
			}
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			if (uParam1->f_68 == 0 || uParam1->f_68 == 3 || uParam1->f_68 == 5) {
				vehicle::raise_convertible_roof(iParam0, 1);
			}
			else {
				vehicle::lower_convertible_roof(iParam0, 1);
			}
		}
		if (iParam3) {
			func_403(&iParam0, &uParam1->f_9, &uParam1->f_59);
		}
		if (!vehicle::is_this_model_a_heli(uParam1->f_66) && !vehicle::is_this_model_a_boat(uParam1->f_66)) {
			iVar2 = 0;
			while (iVar2 <= 11) {
				if (gameplay::is_bit_set(uParam1->f_77, func_271(iVar2 + 1))) {
					if (!vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
						vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 0);
					}
				}
				else if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
					vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 1);
				}
				iVar2++;
			}
		}
		if (entity::get_entity_model(iParam0) == joaat("sheava") ||
			entity::get_entity_model(iParam0) == joaat("omnis") || entity::get_entity_model(iParam0) == joaat("le7b")) {
			if (vehicle::get_vehicle_mod(iParam0, 0) == -1) {
				vehicle::set_vehicle_extra(iParam0, 1, 0);
			}
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (!gameplay::is_bit_set(uParam1->f_77, 23)) {
				if (gameplay::is_bit_set(uParam1->f_77, 22)) {
					vehicle::control_landing_gear(iParam0, 2);
				}
				else {
					vehicle::control_landing_gear(iParam0, 3);
				}
			}
			else {
				vehicle::control_landing_gear(iParam0, 4);
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 27)) {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 1);
		}
		else {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 0);
		}
	}
}

// Position - 0x18C26
int func_403(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	vehicle::set_vehicle_mod_kit(*iParam0, 0);
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			vehicle::toggle_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] > 0);
		}
		else if (vehicle::get_vehicle_mod(*iParam0, iVar1) != (*uParam1)[iVar0] - 1) {
			vehicle::remove_vehicle_mod(*iParam0, iVar1);
			if ((*uParam1)[iVar0] > 0) {
				if (iVar0 == 23) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[0] > 0);
				}
				else if (iVar0 == 24) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[1] > 0);
				}
				else {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, 0);
				}
			}
		}
		iVar0++;
	}
	if (func_406(entity::get_entity_model(*iParam0), 1) &&
		vehicle::get_vehicle_mod(*iParam0, 24) != func_405(*iParam0, (*uParam1)[38] - 1)) {
		vehicle::set_vehicle_mod(*iParam0, 24, func_405(*iParam0, (*uParam1)[38] - 1), 0);
	}
	if (func_404(*iParam0)) {
		vehicle::set_vehicle_strong(*iParam0, 1);
		vehicle::set_vehicle_has_strong_axles(*iParam0, 1);
	}
	return 1;
}

// Position - 0x18D9E
bool func_404(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	char cVar3[16];

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0) &&
		vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = 0;
		while (iVar0 < 49) {
			iVar1 = iVar0;
			if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			}
			else if (vehicle::get_vehicle_mod(iParam0, iVar1) != -1) {
				StringCopy(&cVar3,
						   vehicle::get_mod_text_label(iParam0, iVar1, vehicle::get_vehicle_mod(iParam0, iVar1)), 16);
				iVar2 = gameplay::get_hash_key(&cVar3);
				if (iVar2 != 0) {
					if (iVar2 == gameplay::get_hash_key("MNU_CAGE") || iVar2 == gameplay::get_hash_key("SABRE_CAG")) {
						return true;
					}
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x18E7A
int func_405(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	float fVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		switch (entity::get_entity_model(iParam0)) {
		case joaat("tornado5"):
			switch (iParam1) {
			case 0: return 0;

			case 1: return 1;

			case 2: return 2;

			case 3: return 3;

			case 4: return 4;

			case 5: return 4;
			}
			break;

		case joaat("faction3"): return 3;
		}
		iVar0 = vehicle::get_num_vehicle_mods(iParam0, 38);
		iVar1 = vehicle::get_num_vehicle_mods(iParam0, 24);
		fVar2 = system::to_float(iParam1 + 1) / system::to_float(iVar0);
		iVar3 = system::floor(system::to_float(iVar1) * fVar2) - 1;
		if (iVar3 < 0) {
			iVar3 = 0;
		}
		if (iVar3 >= iVar0) {
			iVar3 = iVar0 - 1;
		}
		return iVar3;
	}
	return 0;
}

// Position - 0x18F5F
int func_406(int iParam0, int iParam1) {
	switch (iParam0) {
	case joaat("faction2"):
	case joaat("buccaneer2"):
	case joaat("chino2"):
	case joaat("moonbeam2"):
	case joaat("primo2"):
	case joaat("voodoo"): return 1;

	case joaat("sabregt2"):
		if (!Global_262145.f_12339) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("tornado5"):
		if (!Global_262145.f_12340) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("virgo2"):
		if (!Global_262145.f_12338) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("minivan2"):
		if (!Global_262145.f_12341) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("slamvan3"):
		if (!Global_262145.f_12343) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("faction3"):
		if (!Global_262145.f_12342) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("sultanrs"):
	case joaat("banshee2"):
		if ((iParam1 & 1) != 0) {
			return 0;
		}
		return 1;

	case joaat("comet3"):
		if (Global_262145.f_16780) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("diablous2"):
		if (Global_262145.f_16782) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("fcr2"):
		if (Global_262145.f_16786) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("elegy"):
		if (Global_262145.f_16783) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("nero2"):
		if (Global_262145.f_16790) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("italigtb2"):
		if (Global_262145.f_16788) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("specter2"):
		if (Global_262145.f_16793) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x19184
void func_407(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = vehicle::get_vehicle_mod(iParam0, 24);
		iVar1 = vehicle::get_vehicle_mod_variation(iParam0, 24);
		vehicle::set_vehicle_wheel_type(iParam0, iParam1);
		if (entity::get_entity_model(iParam0) == joaat("tornado6")) {
			return;
		}
		if (iVar0 == -1) {
			vehicle::remove_vehicle_mod(iParam0, 24);
		}
		else {
			vehicle::set_vehicle_mod(iParam0, 24, iVar0, iVar1 == 1);
		}
	}
}

// Position - 0x191E9
var func_408() { return dlc2::is_dlc_present(-1691188696); }

// Position - 0x191FA
int func_409(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (decorator::decor_is_registered_as_type("MPBitset", 3)) {
				if (decorator::decor_exist_on(iParam0, "MPBitset")) {
					iVar0 = decorator::decor_get_int(iParam0, "MPBitset");
				}
				return gameplay::is_bit_set(iVar0, 4);
			}
		}
	}
	return 0;
}

// Position - 0x19245
void func_410(vector3 vParam0, float fParam3, int iParam4) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (func_396(&Global_68531.f_555[0 /*21*/], iVar0)) {
			if (gameplay::get_distance_between_coords(vParam0, Global_68531.f_555[0 /*21*/], iParam4) <= fParam3) {
				func_392(iVar0);
			}
		}
		iVar0++;
	}
}

// Position - 0x19295
void func_411(var *uParam0, var *uParam1, int iParam2) {
	player::set_wanted_level_multiplier(0.2f);
	if (uParam0->f_274 == 1) {
		ui::request_additional_text("ASS_hk", 3);
		ai::request_waypoint_recording("OJAShk_101");
		ai::request_waypoint_recording("OJAShk_102");
		ai::request_waypoint_recording("OJAShk_103");
		ai::request_waypoint_recording("OJAShk_104");
		streaming::request_anim_dict("ODDJOBS@assassinate@vice@incar");
		streaming::request_anim_dict("mini@hookers_spvanilla");
	}
	else if (uParam0->f_274 == 0) {
		ui::request_additional_text("ASS_bs", 3);
		ai::request_waypoint_recording("OJASbs_102");
		ai::request_waypoint_recording("OJASbs01");
		ai::request_waypoint_recording("OJASbs02");
		ai::request_waypoint_recording("OJASbs03");
		ai::request_waypoint_recording("OJASbs04");
		streaming::request_anim_dict("ODDJOBS@assassinate@old_lady");
		streaming::request_clip_set("move_m@casual@d");
		vehicle::request_vehicle_asset(uParam0->f_5, 3);
		vehicle::request_vehicle_asset(uParam0->f_15, 3);
		streaming::request_ptfx_asset();
	}
	else if (uParam0->f_274 == 2) {
		ui::request_additional_text("ASS_ml", 3);
		streaming::request_ptfx_asset();
	}
	func_417(&uParam0->f_34);
	func_414(&uParam0->f_46, uParam1);
	if (iParam2) {
		func_412();
		while (!func_362()) {
			func_456(uParam1);
			system::wait(0);
		}
	}
	if (uParam0->f_274 == 0) {
		while (!ai::get_is_waypoint_recording_loaded("OJASbs_102") ||
			   !ai::get_is_waypoint_recording_loaded("OJASbs01") || !ai::get_is_waypoint_recording_loaded("OJASbs02") ||
			   !ai::get_is_waypoint_recording_loaded("OJASbs03") || !ai::get_is_waypoint_recording_loaded("OJASbs04") ||
			   !streaming::has_anim_dict_loaded("ODDJOBS@assassinate@old_lady") ||
			   !vehicle::has_vehicle_asset_loaded(uParam0->f_5) || !vehicle::has_vehicle_asset_loaded(uParam0->f_15) ||
			   !streaming::has_ptfx_asset_loaded() || !streaming::has_clip_set_loaded("move_m@casual@d")) {
			func_456(uParam1);
			system::wait(0);
		}
	}
	else if (uParam0->f_274 == 1) {
		while (!ai::get_is_waypoint_recording_loaded("OJAShk_101") ||
			   !ai::get_is_waypoint_recording_loaded("OJAShk_102") ||
			   !ai::get_is_waypoint_recording_loaded("OJAShk_103") ||
			   !ai::get_is_waypoint_recording_loaded("OJAShk_104") ||
			   !streaming::has_anim_dict_loaded("ODDJOBS@assassinate@vice@incar") ||
			   !streaming::has_anim_dict_loaded("mini@hookers_spvanilla")) {
			func_456(uParam1);
			system::wait(0);
		}
	}
	else if (uParam0->f_274 == 2) {
		while (!streaming::has_ptfx_asset_loaded()) {
			func_456(uParam1);
			system::wait(0);
		}
	}
	while (!ui::has_additional_text_loaded(3) || !func_357(&uParam0->f_34) || !func_353(uParam1)) {
		func_456(uParam1);
		system::wait(0);
	}
	if (uParam0->f_274 == 1) {
		gameplay::clear_area_of_vehicles(uParam0->f_18, 100f, 0, 0, 0, 0, 0);
		vehicle::set_all_vehicle_generators_active_in_area(-690.763f, -1607.467f, -100.9649f, -404.4197f, -1856.529f,
														   100.5908f, 0, 1);
		vehicle::set_random_vehicle_density_multiplier_this_frame(0.2f);
		StringCopy(&Local_726, "ASS_HK_PASSED", 24);
		StringCopy(&Local_726.f_6, "ASS_HK_NAME", 24);
		StringCopy(&Local_726.f_12, "ASS_HK_TIMER", 24);
		StringCopy(&Local_726.f_18, "ASS_HK_BASE", 24);
		StringCopy(&Local_726.f_24, "ASS_HK_BDESC", 24);
		StringCopy(&Local_726.f_30, "ASS_HK_CASH", 24);
		StringCopy(&Local_726.f_36, "ASS_HK_COMP", 24);
		StringCopy(&Local_726.f_42, "ASS_HK_COMP", 24);
		StringCopy(&Local_726.f_48, "ASS_HK_COMP", 24);
		StringCopy(&Local_726.f_54, "ASS_HK_COMP", 24);
		StringCopy(&Local_726.f_60, "ASS_HK_CONT", 24);
		fLocal_135 = 3000f;
		fLocal_136 = 2000f;
	}
	else if (uParam0->f_274 == 0) {
		StringCopy(&Local_726, "ASS_BS_PASSED", 24);
		StringCopy(&Local_726.f_6, "ASS_BS_NAME", 24);
		StringCopy(&Local_726.f_12, "ASS_BS_TIMER", 24);
		StringCopy(&Local_726.f_18, "ASS_BS_BASE", 24);
		StringCopy(&Local_726.f_24, "ASS_BS_BDESC", 24);
		StringCopy(&Local_726.f_30, "ASS_BS_CASH", 24);
		StringCopy(&Local_726.f_36, "ASS_BS_COMP", 24);
		StringCopy(&Local_726.f_42, "ASS_BS_COMP", 24);
		StringCopy(&Local_726.f_48, "ASS_BS_COMP", 24);
		StringCopy(&Local_726.f_54, "ASS_BS_COMP", 24);
		StringCopy(&Local_726.f_60, "ASS_BS_CONT", 24);
		fLocal_135 = 5000f;
		fLocal_136 = 2000f;
	}
	else if (uParam0->f_274 == 2) {
		StringCopy(&Local_726, "ASS_ML_PASSED", 24);
		StringCopy(&Local_726.f_6, "ASS_ML_NAME", 24);
		StringCopy(&Local_726.f_12, "ASS_ML_TIMER", 24);
		StringCopy(&Local_726.f_18, "ASS_ML_BASE", 24);
		StringCopy(&Local_726.f_24, "ASS_ML_BDESC", 24);
		StringCopy(&Local_726.f_30, "ASS_ML_CASH", 24);
		StringCopy(&Local_726.f_36, "ASS_ML_COMP", 24);
		StringCopy(&Local_726.f_42, "ASS_ML_COMP", 24);
		StringCopy(&Local_726.f_48, "ASS_ML_COMP", 24);
		StringCopy(&Local_726.f_54, "ASS_ML_COMP", 24);
		StringCopy(&Local_726.f_60, "ASS_ML_CONT", 24);
		fLocal_135 = 5000f;
		fLocal_136 = 2000f;
	}
	player::clear_player_has_damaged_at_least_one_ped(player::player_id());
}

// Position - 0x196FA
void func_412() { func_413(&Global_96040.f_2311); }

// Position - 0x1970D
void func_413(var *uParam0) {
	if (func_364(uParam0)) {
		streaming::request_model(uParam0->f_12.f_66);
	}
}

// Position - 0x1972B
void func_414(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (!gameplay::is_string_null((*uParam0)[iVar0])) {
			func_415(uParam1, (*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x19761
void func_415(var *uParam0, char *sParam1) { func_416(uParam0, 1, -1, sParam1, 0); }

// Position - 0x19774
void func_416(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 15) {
		if (gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 30)) {
			if (gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], iParam1)) {
				if (iParam2 != -1) {
					if ((*uParam0)[iVar0 /*18*/].f_1 == iParam2) {
						return;
					}
				}
				if (iParam1 != 4) {
					if (!gameplay::are_strings_equal(sParam3, "NULL")) {
						if (gameplay::are_strings_equal(&(*uParam0)[iVar0 /*18*/].f_2, sParam3)) {
							return;
						}
					}
				}
				if (iParam1 == 9) {
					return;
				}
			}
		}
		iVar0++;
	}
	if (!uParam0->f_271) {
		uParam0->f_271 = 1;
	}
	iVar0 = 0;
	while (iVar0 < 15) {
		if (!gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 30)) {
			StringCopy(&(*uParam0)[iVar0 /*18*/].f_2, sParam3, 64);
			(*uParam0)[iVar0 /*18*/].f_1 = iParam2;
			(*uParam0)[iVar0 /*18*/] = iParam4;
			gameplay::set_bit(&(*uParam0)[iVar0 /*18*/], iParam1);
			gameplay::set_bit(&(*uParam0)[iVar0 /*18*/], 30);
			return;
		}
		iVar0++;
	}
}

// Position - 0x1985E
void func_417(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			streaming::request_model((*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x1988E
void func_418() {
	vLocal_1616[0 /*3*/] = {-1208.462f, -1559.661f, 3.6087f};
	vLocal_1616[1 /*3*/] = {-2164.723f, -405.4532f, 12.3954f};
	vLocal_1616[2 /*3*/] = {-693.613f, 233.9349f, 79.7011f};
}

// Position - 0x198DB
void func_419(var *uParam0) {
	switch (iLocal_1460) {
	case 0:
		func_428(uParam0);
		func_427();
		break;

	case 1: func_426(uParam0); break;

	case 2: func_423(uParam0); break;

	case 3: func_420(uParam0); break;
	}
	func_417(&uParam0->f_34);
	func_414(&uParam0->f_46, &uLocal_1929);
}

// Position - 0x1993E
void func_420(var *uParam0) {
	*uParam0 = joaat("u_m_y_sbike");
	uParam0->f_1 = {-1406.767f, 738.4614f, 182.4823f};
	uParam0->f_4 = 125.2133f;
	uParam0->f_268 = 1;
	uParam0->f_13 = joaat("weapon_pistol");
	uParam0->f_6 = {-1408.17f, 742.0872f, 182.0377f};
	uParam0->f_5 = joaat("bati");
	uParam0->f_9 = {-1408.17f, 742.0872f, 182.0377f};
	uParam0->f_12 = 15.0077f;
	uParam0->f_271 = {-1382.691f, 744.9668f, 182.2854f};
	uParam0->f_76 = {-1402.094f, 738.1398f, 183.9362f};
	uParam0->f_79 = {-0.2429f, 0f, 76.3241f};
	uParam0->f_82 = 35f;
	Local_122.f_6 = 5;
	func_421(&uParam0->f_34, uParam0->f_5);
	func_421(&uParam0->f_34, joaat("bjxl"));
	func_421(&uParam0->f_34, joaat("camper"));
	fLocal_1557 = 250f;
}

// Position - 0x19A32
int func_421(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if ((*uParam0)[iVar0] == iParam1) {
				return 0;
			}
		}
		iVar0++;
	}
	iVar1 = func_422(uParam0);
	if (iVar1 < 0 || iVar1 >= *uParam0) {
		return 0;
	}
	(*uParam0)[iVar1] = iParam1;
	return 1;
}

// Position - 0x19A8F
int func_422(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x19ABB
void func_423(var *uParam0) {
	*uParam0 = joaat("s_m_y_winclean_01");
	uParam0->f_244[0] = joaat("prop_bmu_02_ld");
	uParam0->f_244[1] = joaat("prop_bmu_02_ld_sup");
	uParam0->f_249[0 /*3*/] = {-643.75f, 305.28f, 99.2f};
	uParam0->f_262[0] = 175.3f;
	uParam0->f_249[1 /*3*/] = {-643.51f, 308.26f, 138.62f};
	uParam0->f_262[1] = 175f;
	uParam0->f_1 = {-642.6985f, 305.823f, 111.5572f};
	uParam0->f_4 = 349.4722f;
	uParam0->f_6 = {-662.1583f, 255.0944f, 80.40974f};
	uParam0->f_76 = {-660.3444f, 184.7394f, 80.3851f};
	uParam0->f_79 = {12.3694f, 0.0001f, -20.505f};
	uParam0->f_82 = 35f;
	StringCopy(&uParam0->f_83[0 /*16*/], "oddjobs@assassinate@multi@windowwasher", 64);
	uParam0->f_271 = {-662.6647f, 242.4725f, 80.3006f};
	uParam0->f_268 = 1;
	Local_122.f_6 = 15;
	func_421(&uParam0->f_34, uParam0->f_244[0]);
	func_421(&uParam0->f_34, uParam0->f_244[1]);
	func_424(&uParam0->f_46, &uParam0->f_83[0 /*16*/]);
	audio::load_stream("WINDOWWASHERFALL_MASTER", 0);
	fLocal_1557 = 500f;
}

// Position - 0x19C04
int func_424(var *uParam0, char *sParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (!gameplay::is_string_null((*uParam0)[iVar0])) {
			if (gameplay::are_strings_equal((*uParam0)[iVar0], sParam1)) {
				return 0;
			}
		}
		iVar0++;
	}
	iVar1 = func_425(uParam0);
	if (iVar1 < 0 || iVar1 >= *uParam0) {
		return 0;
	}
	(*uParam0)[iVar1] = sParam1;
	return 1;
}

// Position - 0x19C69
int func_425(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (gameplay::is_string_null((*uParam0)[iVar0])) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x19C98
void func_426(var *uParam0) {
	*uParam0 = joaat("a_m_m_beach_01");
	uParam0->f_1 = {-2211.742f, -587.6183f, -0.4f};
	uParam0->f_4 = 222.563f;
	uParam0->f_268 = 1;
	uParam0->f_14 = joaat("a_f_y_beach_01");
	uParam0->f_18 = {-2211.742f, -587.6183f, -0.4f};
	uParam0->f_16 = joaat("a_f_y_beach_01");
	uParam0->f_22 = {-2155.479f, -459.9046f, 2.53347f};
	uParam0->f_25 = 129.6666f;
	uParam0->f_5 = joaat("marquis");
	uParam0->f_9 = {-2211.742f, -587.6183f, -0.4f};
	uParam0->f_12 = 222.563f;
	uParam0->f_6 = {-2172.901f, -395.7628f, 12.349f};
	uParam0->f_271 = {-2178.855f, -410.6809f, 12.1595f};
	uParam0->f_76 = {-2171.462f, -446.2333f, 5.9263f};
	uParam0->f_79 = {-5.0921f, -0.0249f, 163.0108f};
	uParam0->f_82 = 35f;
	StringCopy(&uParam0->f_83[0 /*16*/], "oddjobs@assassinate@multi@yachttarget@lapdance", 64);
	StringCopy(&uParam0->f_83[1 /*16*/], "amb@world_human_sunbathe@female@back@idle_a", 64);
	StringCopy(&uParam0->f_83[2 /*16*/], "veh@boat@marquis@rps@enter_exit", 64);
	Local_122.f_6 = 5;
	func_421(&uParam0->f_34, uParam0->f_5);
	func_421(&uParam0->f_34, joaat("seashark"));
	func_424(&uParam0->f_46, &uParam0->f_83[0 /*16*/]);
	func_424(&uParam0->f_46, &uParam0->f_83[1 /*16*/]);
	fLocal_1557 = 400f;
}

// Position - 0x19E05
void func_427() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		streaming::request_model(iLocal_1584[iVar0]);
		iVar0++;
	}
}

// Position - 0x19E2A
void func_428(var *uParam0) {
	*uParam0 = joaat("u_m_y_babyd");
	uParam0->f_1 = {vLocal_1562};
	uParam0->f_268 = 1;
	uParam0->f_4 = 24.7111f;
	uParam0->f_6 = {-1183.12f, -1523.178f, 3.364f};
	uParam0->f_271 = {-1205.392f, -1548.022f, 3.3229f};
	uParam0->f_76 = {-1202.369f, -1550.902f, 5.8757f};
	uParam0->f_79 = {-4.6f, -0.0003f, 152.2f};
	uParam0->f_82 = 35f;
	StringCopy(&uParam0->f_83[0 /*16*/], "oddjobs@assassinate@multi@", 64);
	StringCopy(&uParam0->f_83[1 /*16*/], "misscommon@response", 64);
	Local_122.f_6 = 5;
	func_421(&uParam0->f_34, joaat("premier"));
	func_421(&uParam0->f_34, joaat("dilettante"));
	func_421(&uParam0->f_34, joaat("vigero"));
	func_424(&uParam0->f_46, &uParam0->f_83[0 /*16*/]);
	func_424(&uParam0->f_46, &uParam0->f_83[1 /*16*/]);
	fLocal_1557 = 175f;
	func_429();
}

// Position - 0x19F27
void func_429() {
	iLocal_1584[0] = joaat("premier");
	iLocal_1584[1] = joaat("dilettante");
	iLocal_1584[2] = joaat("vigero");
}

// Position - 0x19F50
void func_430(var *uParam0) {
	if (iLocal_1463 < 3) {
		streaming::set_hd_area(-717.8348f, -932.1736f, 18.01735f, 26f);
	}
	switch (iLocal_1463) {
	case 0:
		streaming::request_anim_dict("oddjobs@assassinate@multi@call");
		streaming::request_model(-1559354806);
		func_429();
		system::settimera(0);
		audio::request_script_audio_bank("SCRIPT\ASSASSINATION_MULTI", 0, -1);
		if (streaming::has_anim_dict_loaded("oddjobs@assassinate@multi@call") &&
			streaming::has_model_loaded(-1559354806) && func_352()) {
			bLocal_1534 = true;
		}
		if (bLocal_1534) {
			if (entity::does_entity_exist(iLocal_1464)) {
				func_444(-736.7908f, -924.1303f, 18.16373f, -696.8614f, -923.7517f, 19.65864f, 45f, -711.8602f,
						 -920.7141f, 18.0145f, 0.0954f, func_450(), 1, 1, 1, 0, 0);
				gameplay::clear_area(-700.1226f, -916.8699f, 18.1667f, 5f, 1, 0, 0, 0);
				if (!func_452(&uLocal_1493)) {
					func_37(&uLocal_1493);
				}
				if (entity::does_entity_exist(iLocal_1464)) {
					entity::set_entity_visible(iLocal_1464, 0, 0);
					entity::set_entity_collision(iLocal_1464, 0, 0);
					entity::set_entity_can_be_damaged(iLocal_1464, 0);
					iLocal_1465 = object::create_object(-1559354806, -700.1226f, -916.8699f, 18.1667f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_1465, 0f, 0f, 0f, 2, 1);
					entity::set_entity_collision(iLocal_1465, 0, 0);
					entity::set_entity_can_be_damaged(iLocal_1465, 0);
				}
				iLocal_1505 = streaming::format_focus_heading(-700.1226f, -916.8699f, 18.1667f, 350f, 12, 127);
				func_436(1, 1, 1, 0);
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
					entity::set_entity_coords(player::player_ped_id(), vLocal_1471, 1, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), fLocal_1474);
					weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
					ped::remove_ped_helmet(player::player_ped_id(), 1);
				}
				iLocal_1504 = ped::create_synchronized_scene(vLocal_1498, vLocal_1501, 2);
				if (entity::does_entity_exist(iLocal_1465)) {
					ped::attach_synchronized_scene_to_entity(iLocal_1504, iLocal_1465, -1);
				}
				ai::task_synchronized_scene(player::player_ped_id(), iLocal_1504, "oddjobs@assassinate@multi@call",
											"ass_multi_target_call_p1", 1000f, -2f, 2, 0, 1148846080, 0);
				entity::play_synchronized_entity_anim(iLocal_1465, iLocal_1504, "ass_multi_target_call_phone",
													  "oddjobs@assassinate@multi@call", 1000f, -2f, 0, 1148846080);
				if (!cam::does_cam_exist(iLocal_1466)) {
					iLocal_1467 = cam::create_camera_with_params(26379945, vLocal_1478, vLocal_1481, 35f, 1, 2);
					iLocal_1466 = cam::create_camera_with_params(26379945, vLocal_1484, vLocal_1487, 35f, 0, 2);
					cam::set_cam_active_with_interp(iLocal_1466, iLocal_1467, 2500, 1, 1);
					cam::render_script_cams(1, 0, 3000, 1, 0, 0);
					cam::shake_cam(iLocal_1466, "HAND_SHAKE", 0.2f);
				}
				func_379();
				func_32(&uParam0->f_16, 3, 0, "LESTER", 0, 1);
				func_32(&uParam0->f_16, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
				ui::display_radar(0);
				ui::display_hud(0);
				weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 0);
				player::set_player_control(player::player_id(), 0, 56);
				func_435(23, 1);
				iLocal_1463 = 1;
			}
			else {
				streaming::request_anim_dict("oddjobs@assassinate@multi@call");
				streaming::request_model(-1559354806);
				if (!entity::does_entity_exist(iLocal_1464)) {
					iLocal_1464 = object::get_closest_object_of_type(vLocal_1468, 5f, 1281992692, 1, 0, 1);
				}
			}
		}
		break;

	case 1:
		func_433();
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			player::set_all_random_peds_flee_this_frame(player::player_id());
		}
		if (func_452(&uLocal_1490)) {
			if (func_39(&uLocal_1490) > 1f) {
				if (func_432()) {
					bLocal_1496 = true;
					if (!cam::is_screen_faded_out()) {
						func_431(800);
					}
					iLocal_1463 = 2;
					break;
				}
			}
		}
		if (!iLocal_1497) {
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				if (ped::is_synchronized_scene_running(iLocal_1504)) {
					if (ped::get_synchronized_scene_phase(iLocal_1504) > 0.05f) {
						if (func_21(&uParam0->f_16, "OJASAUD", "OJAScnt_ml", 9, 0, 0, 0)) {
							if (!func_452(&uLocal_1490)) {
								func_37(&uLocal_1490);
								iLocal_1497 = 1;
								if (func_17(0)) {
									func_375(500);
								}
							}
						}
					}
				}
			}
		}
		if (func_452(&uLocal_1490) && func_39(&uLocal_1490) > fLocal_1475 ||
			ped::is_synchronized_scene_running(iLocal_1504) &&
				ped::get_synchronized_scene_phase(iLocal_1504) >= 0.978f ||
			bLocal_1496) {
			iLocal_1463 = 3;
		}
		break;

	case 2:
		audio::stop_scripted_conversation(0);
		if (bLocal_1496) {
			if (cam::is_screen_faded_out()) {
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
					entity::set_entity_coords(player::player_ped_id(), -700.2628f, -917.5313f, 18.2147f, 1, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), 73.3924f);
				}
				entity::stop_synchronized_entity_anim(iLocal_1465, -1000f, 1);
				system::wait(0);
				cam::do_screen_fade_in(500);
				cam::destroy_all_cams(0);
				cam::render_script_cams(0, 0, 3000, 1, 0, 0);
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				iLocal_1463 = 3;
			}
		}
		break;

	case 3:
		if (!bLocal_1496) {
			cam::_0xC819F3CBB62BF692(0, 0, 3, 0);
			cam::destroy_all_cams(0);
		}
		if (streaming::_0x07C313F94746702C(iLocal_1505)) {
			streaming::_0x1EE7D8DF4425F053(iLocal_1505);
		}
		entity::set_entity_collision(iLocal_1465, 1, 0);
		streaming::clear_hd_area();
		ui::display_radar(1);
		ui::display_hud(1);
		ai::clear_ped_tasks(player::player_ped_id());
		player::set_player_control(player::player_id(), 1, 0);
		ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 1, 0, 0);
		func_435(23, 0);
		func_436(0, 1, 1, 0);
		player::set_player_wanted_level(player::player_id(), 0, 0);
		player::set_player_wanted_level_now(player::player_id(), 0);
		streaming::remove_anim_dict("oddjobs@assassinate@multi@call");
		entity::set_object_as_no_longer_needed(&iLocal_1464);
		iLocal_1041 = 4;
		break;
	}
}

// Position - 0x1A4CA
int func_431(int iParam0) {
	cam::do_screen_fade_out(iParam0);
	while (!cam::is_screen_faded_out()) {
		system::wait(0);
	}
	return 1;
}

// Position - 0x1A4E9
bool func_432() {
	if (ui::is_pause_menu_active()) {
		return false;
	}
	if (controls::is_control_just_pressed(0, 18) || controls::is_control_just_pressed(2, 18)) {
		return true;
	}
	return false;
}

// Position - 0x1A51B
void func_433() {
	switch (iLocal_1552) {
	case 0:
		if (func_434(&iLocal_1466, 8f, -728.4891f, -933.7799f, 19.9947f, -4.0865f, 0.0581f, -61.3739f, 30.7441f, 1,
					 0.2f)) {
			iLocal_1552 = 1;
		}
		break;

	case 1:
		if (func_434(&iLocal_1466, 14f, -702.2474f, -918.3937f, 19.7582f, -1.9904f, 0f, -56.7173f, 30f, 1, 0.3f)) {
			iLocal_1552 = 2;
		}
		break;

	case 2:
		if (func_434(&iLocal_1466, 23f, -698.241f, -917.8708f, 19.533f, -3.3396f, 0f, 75.4344f, 40f, 1, 0.3f)) {
			iLocal_1552 = 3;
		}
		break;

	case 3:
		if (func_434(&iLocal_1466, 28f, -716.4577f, -945.2582f, 19.8525f, -1.1558f, 0f, -21.0827f, 31f, 1, 0.2f)) {
			iLocal_1552 = 4;
		}
		break;

	case 4:
		if (func_434(&iLocal_1466, 33f, -702.0552f, -917.9715f, 19.7381f, -3.1893f, 0f, -63.3392f, 33.4611f, 1, 0.2f)) {
			iLocal_1552 = 5;
		}
		break;

	case 5:
		if (func_434(&iLocal_1466, 39f, -697.374f, -918.0989f, 19.8386f, -4.5194f, 0f, 86.2972f, 42f, 1, 0.2f)) {
			iLocal_1552 = 6;
		}
		break;

	case 6: break;
	}
}

// Position - 0x1A6BE
bool func_434(int iParam0, float fParam1, vector3 vParam2, vector3 vParam5, float fParam8, int iParam9,
			  float fParam10) {
	if (cam::does_cam_exist(*iParam0)) {
		if (func_452(&uLocal_1493)) {
			if (func_39(&uLocal_1493) >= fParam1) {
				cam::set_cam_coord(iLocal_1466, vParam2);
				cam::set_cam_rot(iLocal_1466, vParam5, 2);
				cam::set_cam_fov(iLocal_1466, fParam8);
				if (iParam9) {
					cam::shake_cam(iLocal_1466, "HAND_SHAKE", fParam10);
				}
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1A71E
void func_435(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_25434, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_25434, iParam0);
	}
}

// Position - 0x1A740
void func_436(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_443(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_25()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_442(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_443(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_442(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_440(player::player_id()) &&
				!func_438(player::player_id(), 0) && !func_437()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_440(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0x1A859
bool func_437() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0x1A876
bool func_438(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_439(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x1A8C1
int func_439(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_289();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x1A902
int func_440(int iParam0) {
	if (func_438(iParam0, 0)) {
		return 1;
	}
	if (func_441()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0x1A944
bool func_441() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x1A955
int func_442(int iParam0, int iParam1, var uParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && uParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x1A988
void func_443(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0x1A9AB
void func_444(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, vector3 vParam11,
			  int iParam14, int iParam15, int iParam16, int iParam17, int iParam18) {
	func_445(vParam0, vParam3, fParam6, vParam7, fParam10, vParam11, iParam14, iParam15, iParam16, iParam17, iParam18);
}

// Position - 0x1A9D5
void func_445(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, vector3 vParam11,
			  bool bParam14, int iParam15, bool bParam16, bool bParam17, bool bParam18) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	int iVar3;
	vector3 vVar4;
	vector3 vVar7;
	vector3 vVar10;
	int iVar13;
	int iVar14;
	int iVar15;

	if (iParam15) {
		iParam15 = 0;
	}
	bVar2 = true;
	iVar3 = 0;
	iVar0 = player::get_players_last_vehicle();
	if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_a_mission_entity(iVar0)) {
			entity::set_entity_as_mission_entity(iVar0, 1, 0);
			iVar3 = 1;
		}
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			if (bParam18) {
				func_449(iVar0);
			}
			if (entity::is_entity_in_angled_area(iVar0, vParam0, vParam3, fParam6, 0, 1, 0)) {
				bVar1 = true;
			}
			else {
				vVar10 = {entity::get_entity_coords(iVar0, 1)};
				if (vVar10.z > vParam0.z && vVar10.z < vParam3.z || vVar10.z > vParam3.z && vVar10.z < vParam0.z) {
					if (func_446(iVar0, vParam0, vParam3, fParam6)) {
						bVar1 = true;
					}
				}
			}
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (vehicle::is_vehicle_model(iVar0, joaat("taxi"))) {
					if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != player::player_ped_id() &&
						vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != 0) {
						if (gameplay::get_distance_between_coords(vParam0 + vParam3 / FtoV(2f),
																  entity::get_entity_coords(iVar0, 1), 1) < 20f) {
							bVar1 = true;
							bVar2 = false;
						}
					}
				}
			}
			if (bParam16) {
				if (func_284(iVar0, func_10(), 1)) {
					bVar1 = false;
				}
			}
			if (bVar1) {
				if (!func_250(vParam11)) {
					if (vehicle::is_vehicle_driveable(iVar0, 0)) {
						iVar13 = entity::get_entity_model(iVar0);
						vehicle::_0xDF7E3EEB29642C38(iVar0, &vVar4, &vVar7);
						if (vehicle::is_this_model_a_heli(iVar13)) {
							vParam11.x += 3f;
							vParam11.y += 3f;
						}
						if (iVar13 == joaat("zentorno") || iVar13 == joaat("btype") || iVar13 == joaat("dubsta3") ||
							iVar13 == joaat("monster")) {
							vParam11 = {vParam11 * FtoV(1.1f)};
						}
						else if (iVar13 == joaat("t20") || iVar13 == joaat("virgo")) {
							vParam11 = {vParam11 * FtoV(1.2f)};
						}
						if (vVar7.x - vVar4.x > vParam11.x) {
							bVar2 = false;
						}
						else if (vVar7.y - vVar4.y > vParam11.y) {
							bVar2 = false;
						}
						else if (vVar7.z - vVar4.z > vParam11.z) {
							bVar2 = false;
						}
					}
				}
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (bVar2) {
						gameplay::clear_area_of_vehicles(vParam7, 5f, 0, 0, 0, 0, 0);
						entity::set_entity_heading(iVar0, fParam10);
						entity::set_entity_coords(iVar0, vParam7, 1, 0, 0, 1);
						vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
						if (bParam17) {
							vehicle::set_vehicle_engine_on(iVar0, 0, 1, 0);
							vehicle::set_vehicle_doors_shut(iVar0, 1);
						}
					}
					else {
						if (!entity::is_entity_a_mission_entity(iVar0) ||
							!entity::does_entity_belong_to_this_script(iVar0, 1)) {
							entity::set_entity_as_mission_entity(iVar0, 1, 1);
						}
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
							entity::set_entity_coords(player::player_ped_id(), entity::get_entity_coords(iVar0, 1), 1,
													  0, 0, 1);
						}
						vehicle::delete_vehicle(&iVar0);
					}
				}
			}
			if (bParam14) {
				gameplay::clear_angled_area_of_vehicles(vParam0, vParam3, fParam6, 0, 0, 0, 0, 0);
			}
			if (iVar3 == 1) {
				if (entity::does_entity_exist(iVar0)) {
					if (entity::is_entity_a_mission_entity(iVar0)) {
						entity::set_vehicle_as_no_longer_needed(&iVar0);
					}
				}
			}
		}
		else {
			if (!entity::is_entity_a_mission_entity(iVar0)) {
				entity::set_entity_as_mission_entity(iVar0, 1, 0);
			}
			iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0);
			if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
				entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
			}
			iVar15 = vehicle::get_vehicle_model_number_of_seats(entity::get_entity_model(iVar0));
			if (iVar15 <= 2) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			if (iVar15 <= 4) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 1, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 2, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			vehicle::delete_vehicle(&iVar0);
		}
	}
}

// Position - 0x1ADC7
bool func_446(int iParam0, vector3 vParam1, vector3 vParam4, float fParam7) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18[4];
	struct<2> Var31;
	struct<2> Var34;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		vParam1.z = vParam4.z;
		vVar0 = {func_448(vParam1 - vParam4)};
		vVar3 = {vVar0};
		vVar0.x = -vVar3.y;
		vVar0.y = vVar3.x;
		vVar0.z = 0f;
		vVar6 = {vParam1 - vVar0 * FtoV(fParam7 / 2f)};
		vVar9 = {vParam1 + vVar0 * FtoV(fParam7 / 2f)};
		vVar12 = {vParam4 - vVar0 * FtoV(fParam7 / 2f)};
		vVar15 = {vParam4 + vVar0 * FtoV(fParam7 / 2f)};
		gameplay::get_model_dimensions(entity::get_entity_model(iParam0), &Var31, &Var34);
		vVar18[0 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var31.f_1, 0f)};
		vVar18[1 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var34.f_1, 0f)};
		vVar18[2 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var31.f_1, 0f)};
		vVar18[3 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var34.f_1, 0f)};
		if (func_447(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar9) ||
			func_447(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar9, vVar15) ||
			func_447(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar12, vVar15) ||
			func_447(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar12) ||
			func_447(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar9) ||
			func_447(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar9, vVar15) ||
			func_447(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar12, vVar15) ||
			func_447(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar12) ||
			func_447(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar9) ||
			func_447(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar9, vVar15) ||
			func_447(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar12, vVar15) ||
			func_447(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar12) ||
			func_447(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar9) ||
			func_447(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar9, vVar15) ||
			func_447(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar12, vVar15) ||
			func_447(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar12)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1B0BD
int func_447(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5, struct<2> Param6, var uParam8,
			 struct<2> Param9, var uParam11) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;

	fVar0 = Param0;
	fVar1 = Param0.f_1;
	fVar2 = Param3;
	fVar3 = Param3.f_1;
	fVar4 = Param6;
	fVar5 = Param6.f_1;
	fVar6 = Param9;
	fVar7 = Param9.f_1;
	fVar8 = fVar2 - fVar0;
	fVar9 = fVar3 - fVar1;
	fVar10 = fVar6 - fVar4;
	fVar11 = fVar7 - fVar5;
	fVar12 = (-fVar9 * (fVar0 - fVar4) + fVar8 * (fVar1 - fVar5)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	fVar13 = (fVar10 * (fVar1 - fVar5) - fVar11 * (fVar0 - fVar4)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	if (fVar12 >= 0f && fVar12 <= 1f && fVar13 >= 0f && fVar13 <= 1f) {
		return 1;
	}
	return 0;
}

// Position - 0x1B171
Vector3 func_448(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x1B1B0
void func_449(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_vehicle_engine_health(iParam0) <= 200f) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
			if (vehicle::get_vehicle_petrol_tank_health(iParam0) <= 700f) {
				vehicle::set_vehicle_engine_health(iParam0, 900f);
			}
			if (entity::get_entity_health(iParam0) < 200) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
		}
	}
}

// Position - 0x1B215
Vector3 func_450() { return 2.55f, 5.665f, 2.55f; }

// Position - 0x1B22C
void func_451(var *uParam0) { func_467(uParam0); }

// Position - 0x1B23A
bool func_452(int *iParam0) { return gameplay::is_bit_set(*iParam0, 1); }

// Position - 0x1B24A
bool func_453() {
	if (Global_3) {
		return true;
	}
	if (Global_91491 == 7 || Global_91491 == 8) {
		return true;
	}
	return false;
}

// Position - 0x1B277
bool func_454(var *uParam0) {
	if (uParam0->f_270) {
		return true;
	}
	return false;
}

// Position - 0x1B28C
void func_455(int *iParam0, float fParam1, int iParam2) {
	if (func_139(iParam0, fParam1)) {
		if (iParam2) {
			func_177(&cLocal_1018, -1);
		}
		else {
			func_142(&cLocal_1018, 7500, 1);
		}
	}
}

// Position - 0x1B2BA
void func_456(var *uParam0) {
	int iVar0;

	if (uParam0->f_271) {
		if (gameplay::get_frame_count() >= uParam0->f_272 + uParam0->f_273 ||
			gameplay::is_bit_set(Global_91491.f_20, 2) || gameplay::is_bit_set(Global_91491.f_20, 13)) {
			iVar0 = 0;
			while (iVar0 < 15) {
				if (gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 30)) {
					if (!gameplay::is_bit_set((*uParam0)[iVar0 /*18*/], 29)) {
						func_457(&(*uParam0)[iVar0 /*18*/]);
						uParam0->f_272 = gameplay::get_frame_count();
						return;
					}
				}
				iVar0++;
			}
		}
	}
}

// Position - 0x1B348
void func_457(int *iParam0) { func_458(iParam0, &iParam0->f_2, iParam0->f_1); }

// Position - 0x1B35E
void func_458(int *iParam0, char *sParam1, int iParam2) {
	if (gameplay::is_bit_set(*iParam0, 30)) {
		switch (func_155(*iParam0)) {
		case 0: streaming::request_model(iParam2); break;

		case 1: streaming::request_anim_dict(sParam1); break;

		case 2: streaming::request_clip_set(sParam1); break;

		case 3: graphics::request_streamed_texture_dict(sParam1, gameplay::is_bit_set(*iParam0, 28)); break;

		case 4: vehicle::request_vehicle_recording(iParam2, sParam1); break;

		case 5: ai::request_waypoint_recording(sParam1); break;

		case 6: audio::request_script_audio_bank(sParam1, gameplay::is_bit_set(*iParam0, 27), -1); break;

		case 7: script::request_script_with_name_hash(iParam2); break;

		case 8: ui::request_additional_text(sParam1, iParam2); break;

		case 9: streaming::request_ptfx_asset(); break;

		default: break;
		}
		gameplay::set_bit(iParam0, 29);
	}
}

// Position - 0x1B438
void func_459(vector3 vParam0, float fParam3, int iParam4, int iParam5) {
	if (func_466()) {
		gameplay::set_this_script_can_be_paused(0);
		gameplay::clear_bit(&Global_91491.f_20, 2);
		gameplay::set_game_paused(1);
		if (player::is_player_playing(player::player_id())) {
			player::set_player_control(player::player_id(), 0, 0);
		}
		Global_91487 = {vParam0};
		Global_91490 = fParam3;
		Global_91486 = 1;
		if (iParam4 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 14);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 14);
		}
		if (iParam5 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 24);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 24);
		}
		func_377(1);
	}
}

// Position - 0x1B4CD
int func_460() {
	if (Global_91491 != 10 && Global_91491 != 9) {
		return 0;
	}
	return Global_91491.f_2;
}

// Position - 0x1B4F7
struct<39> func_461(int iParam0) {
	struct<39> Var0;

	if (iParam0 == 0) {
		Var0 = 1;
		Var0.f_1 = {0f, 0f, 0f};
		Var0.f_4 = {0f, 0f, 0f};
		Var0.f_7 = {func_462(0)};
		Var0.f_22 = "Assassin_Valet";
		Var0.f_23 = 7000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-1700.015f, -1066.335f, 12.144f};
		Var0.f_28 = {-1691.564f, -1066.514f, 12.076f};
		Var0.f_31 = 35.4714f;
		Var0.f_10 = {-1700.467f, -1066.672f, 13.8795f};
		Var0.f_13 = {-4.8332f, 0f, -177.1283f};
		Var0.f_16 = {-1700.467f, -1066.672f, 13.8795f};
		Var0.f_19 = {-4.8332f, 0f, -177.1283f};
		Var0.f_33 = {-1700.098f, -1067.939f, 12.1547f};
		Var0.f_36 = 162.4559f;
		Var0.f_37 = 1;
	}
	else if (iParam0 == 1) {
		Var0 = 0;
		Var0.f_1 = {-699.3992f, -917.5043f, 18.2143f};
		Var0.f_4 = {0f, 0f, 0f};
		Var0.f_7 = {func_462(1)};
		Var0.f_22 = "Assassin_Multi";
		Var0.f_23 = 5000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-700.1855f, -917.9558f, 18.2143f};
		Var0.f_28 = {-699.9455f, -921.7786f, 18.0144f};
		Var0.f_31 = 78.0874f;
		Var0.f_10 = {-697.8064f, -921.4629f, 20.5104f};
		Var0.f_13 = {-13.5249f, 0f, 30.6033f};
		Var0.f_16 = {-702.4851f, -921.2747f, 21.1235f};
		Var0.f_19 = {-22.5196f, 0f, -43.0435f};
		Var0.f_33 = {0f, 0f, 0f};
		Var0.f_36 = 0f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 2) {
		Var0 = 0;
		Var0.f_1 = {215.1206f, -853.3143f, 29.3684f};
		Var0.f_4 = {0f, 0f, 87.1787f};
		Var0.f_7 = {func_462(2)};
		Var0.f_22 = "Assassin_Hooker";
		Var0.f_23 = 3000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {213.7994f, -853.9389f, 29.3929f};
		Var0.f_28 = {205.2641f, -847.2667f, 29.4903f};
		Var0.f_31 = 140.1039f;
		Var0.f_10 = {216.7391f, -856.0031f, 32.7127f};
		Var0.f_13 = {-25.1365f, 0f, 41.3912f};
		Var0.f_16 = {210.4668f, -851.3092f, 32.1099f};
		Var0.f_19 = {-16.3326f, 0f, -127.0114f};
		Var0.f_33 = {213.8733f, -853.8161f, 29.3922f};
		Var0.f_36 = 344.0112f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 3) {
		Var0 = 0;
		Var0.f_1 = {-22.5499f, -107.3546f, 56.0161f};
		Var0.f_4 = {0f, 0f, 269.7924f};
		Var0.f_7 = {func_462(3)};
		Var0.f_22 = "Assassin_Bus";
		Var0.f_23 = 5000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-22.3125f, -108.9183f, 56.0068f};
		Var0.f_28 = {-17.2677f, -118.5915f, 55.8734f};
		Var0.f_31 = 1.4374f;
		Var0.f_10 = {-26.1094f, -108.0298f, 59.052f};
		Var0.f_13 = {-21.2059f, 0f, -109.0176f};
		Var0.f_16 = {-20.1189f, -111.9639f, 59.4377f};
		Var0.f_19 = {-27.0037f, 0f, 29.464f};
		Var0.f_33 = {0f, 0f, 0f};
		Var0.f_36 = 0f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 4) {
		Var0 = 0;
		Var0.f_1 = {806.1469f, -1070.21f, 27.3361f};
		Var0.f_4 = {0f, 0f, 90f};
		Var0.f_7 = {func_462(4)};
		Var0.f_22 = "Assassin_Construction";
		Var0.f_23 = 8000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = 1;
		Var0.f_25 = {804.9559f, -1070.46f, 27.3361f};
		Var0.f_28 = {799.8408f, -1079.142f, 27.321f};
		Var0.f_31 = 69.6524f;
		Var0.f_10 = {801.8048f, -1068.068f, 30.3496f};
		Var0.f_13 = {-20.8953f, 0f, -132.9451f};
		Var0.f_16 = {805.8168f, -1074.496f, 28.9803f};
		Var0.f_19 = {-1.5585f, 0f, 6.9143f};
		Var0.f_33 = {804.8776f, -1070.523f, 27.3416f};
		Var0.f_36 = 287.8741f;
		Var0.f_37 = 0;
	}
	return Var0;
}

// Position - 0x1B9AF
Vector3
func_462(int iParam0) {
	switch (iParam0) {
	case 0: return -1704.427f, -1077.316f, 12.1111f;

	case 1: return -700.429f, -916.7467f, 18.2143f;

	case 2: return 214.1641f, -852.8006f, 29.3929f;

	case 3: return -21.9871f, -107.4823f, 55.997f;

	case 4: return 806.1469f, -1070.21f, 27.3361f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x1BA39
void func_463() {
	bool bVar0;

	bVar0 = func_78(Global_101700.f_18922.f_1, 4096);
	Global_101700.f_18922.f_1 = 0;
	if (bVar0) {
		func_470(&Global_101700.f_18922.f_1, 4096);
	}
}

// Position - 0x1BA72
void func_464(int iParam0) {
	if (iParam0) {
		StringCopy(&Global_100756, script::get_this_script_name(), 24);
		Global_100750 = 1;
	}
	else {
		StringCopy(&Global_100756, "NULL", 24);
		Global_100750 = 0;
	}
}

// Position - 0x1BA9E
bool func_465() { return func_364(&Global_96040.f_2311); }

// Position - 0x1BAB1
bool func_466() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return true;
	}
	return false;
}

// Position - 0x1BAD5
void func_467(var *uParam0) {
	vector3 vVar0;

	rope::rope_unload_textures();
	func_464(0);
	audio::stop_scripted_conversation(0);
	func_119(0);
	if (!entity::is_entity_dead(player::player_ped_id(), 0) && !ped::is_ped_injured(player::player_ped_id())) {
		ped::set_ped_using_action_mode(player::player_ped_id(), 0, -1, 0);
	}
	iLocal_1027 = iLocal_1027;
	vehicle::_0x1033371FC8E842A7(iLocal_1027);
	vehicle::set_vehicle_density_multiplier_this_frame(1f);
	vehicle::set_random_vehicle_density_multiplier_this_frame(1f);
	vehicle::set_all_vehicle_generators_active_in_area(-690.763f, -1607.467f, -100.9649f, -404.4197f, -1856.529f,
													   100.5908f, 1, 1);
	pathfind::set_roads_back_to_original_in_angled_area(-706.106f, -1708.865f, -100f, -512.576f, -1842.173f, 100f, 100f,
														1);
	pathfind::set_roads_back_to_original_in_angled_area(-480.9742f, -1801.922f, 19.28045f, -712.8968f, -1671.164f,
														29.93867f, 170f, 1);
	pathfind::set_roads_back_to_original_in_angled_area(-674.8915f, -1683.639f, 9.116446f, -446.189f, -1807.7f,
														31.72464f, 200f, 1);
	pathfind::set_roads_back_to_original_in_angled_area(-662.6993f, -1645.326f, 24.07147f, -672.2144f, -1777.59f,
														38.81248f, 45f, 1);
	pathfind::set_roads_back_to_original_in_angled_area(-382.9608f, -1688.732f, 17.8985f, -431.2512f, -1811.23f,
														37.6825f, 80f, 1);
	vVar0 = {414.1398f, -640.002f, 27.5001f};
	vehicle::set_all_vehicle_generators_active_in_area(vVar0.x - 40f, vVar0.y - 40f, vVar0.z - 40f, vVar0.x + 40f,
													   vVar0.y + 40f, vVar0.z + 40f, 1, 1);
	pathfind::set_roads_back_to_original_in_angled_area(426.035f, -644.93f, -100f, 421.035f, -644.93f, 100f, 55f, 1);
	vehicle::set_parked_vehicle_density_multiplier_this_frame(1f);
	ped::clear_ped_non_creation_area();
	ped::stop_any_ped_model_being_suppressed();
	audio::stop_stream();
	func_150(uParam0, 0);
	player::set_wanted_level_multiplier(1f);
	script::terminate_this_thread();
}

// Position - 0x1BCB5
void func_468() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_17(0)) {
		if (!func_469()) {
			iVar0 = func_16();
			if (iVar0 != -1) {
				if (!func_4(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_9();
		}
	}
}

// Position - 0x1BD26
int func_469() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

// Position - 0x1BD64
void func_470(var *uParam0, int iParam1) { func_471(uParam0, iParam1); }

// Position - 0x1BD74
void func_471(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x1BD85
float func_472() { return system::to_float(540000 - iLocal_1554); }

// Position - 0x1BD99
void func_473() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 35) {
		ui::_remove_notification(Global_101700.f_13100[iVar0 /*104*/].f_16);
		iVar0++;
	}
}

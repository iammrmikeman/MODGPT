void __EntryFunction__() {}

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
var uLocal_21 = 0;
var uLocal_22 = 0;
float fLocal_23 = 0f;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
var uLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
int iLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 10;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 2;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 8;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 8;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
float fLocal_90 = 0f;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
float fLocal_94 = 0f;
float fLocal_95 = 0f;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
float fLocal_101 = 0f;
float fLocal_102 = 0f;
float fLocal_103 = 0f;
float fLocal_104 = 0f;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
float fLocal_114 = 0f;
var uLocal_115 = 0;
struct<6> Local_116[16];
var uLocal_213[4] = {0, 0, 0, 0};
int iLocal_218 = 0;
int iLocal_219 = 0;
int iLocal_220 = 0;
var *uLocal_221 = NULL;
var uLocal_222 = 0;
struct<16> Local_223[4];
struct<78> Local_288 = {
	0, -1, 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0
};
struct<2> Local_366[4];
var *uLocal_375 = NULL;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 4;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 2;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 60;
var uLocal_430 = 0;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 2;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 60;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var uLocal_524 = 0;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 2;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 60;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 0;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 0;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 2;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 60;
var uLocal_667 = 0;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 0;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
var uLocal_726 = 0;
struct<20> ScriptParam_0 = {
	0, -1, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1
};
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_23 = 80f;
	fLocal_24 = 140f;
	fLocal_25 = 180f;
	fLocal_28 = 0f;
	fLocal_32 = -0.0375f;
	fLocal_33 = 0.17f;
	iLocal_36 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_90 = 0.05f + 0.275f - 0.01f;
	fLocal_93 = -0.05f;
	fLocal_94 = 0.92f;
	fLocal_95 = 1.94f;
	fLocal_96 = 2.99f;
	fLocal_97 = 3.7f;
	fLocal_101 = 3f;
	fLocal_102 = 0f;
	fLocal_103 = 2f;
	fLocal_104 = 100f;
	fLocal_114 = 0.5f;
	iLocal_218 = -1;
	iLocal_220 = -1;
	ScriptParam_0 = 137;
	if (network::network_is_game_in_progress()) {
		func_209(ScriptParam_0);
	}
	func_208(1);
	while (true) {
		func_207();
		if (func_198()) {
			func_197();
		}
		if (network::network_is_game_in_progress()) {
			func_1(&uLocal_375);
		}
		else {
			func_197();
		}
	}
}

// Position - 0x10A
void func_1(var *uParam0) {
	if (Local_288 < 11) {
		func_181(uParam0);
	}
	switch (*uParam0) {
	case 0:
		if (Local_288 > 3 && Local_288 != 9) {
			func_180(uParam0, 11);
			return;
		}
		func_178(uParam0);
		break;

	case 1: func_175(uParam0); break;

	case 2: func_171(uParam0); break;

	case 3: func_167(uParam0); break;

	case 4: func_165(uParam0); break;

	case 5: func_163(uParam0); break;

	case 6: func_159(uParam0); break;

	case 7: func_122(uParam0); break;

	case 8: func_78(uParam0); break;

	case 9: func_54(uParam0); break;

	case 10: func_45(uParam0); break;

	case 11: func_29(uParam0); break;
	}
	switch (Local_288) {
	case 0: func_28(uParam0); break;

	case 1: func_27(uParam0); break;

	case 2: func_26(uParam0); break;

	case 3: func_25(uParam0); break;

	case 4: func_23(uParam0); break;

	case 5: func_22(uParam0); break;

	case 6: func_18(uParam0); break;

	case 7: func_17(uParam0); break;

	case 8: func_13(uParam0); break;

	case 9: func_4(uParam0); break;

	case 10: break;

	case 11: break;
	}
	func_2(uParam0);
}

// Position - 0x2B1
void func_2(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 5)) {
		ui::hide_help_text_this_frame();
	}
	gameplay::clear_bit(&uParam0->f_2, 5);
	if (*uParam0 > 1 && *uParam0 < 11 && graphics::has_scaleform_movie_loaded(uParam0->f_34) &&
		!ui::is_pause_menu_active()) {
		graphics::draw_scaleform_movie_fullscreen(uParam0->f_34, 255, 255, 255, 255, 0);
	}
	if (gameplay::is_bit_set(uParam0->f_2, 17)) {
		func_3(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 17);
	}
}

// Position - 0x329
void func_3(var *uParam0) {
	graphics::draw_sprite("LineArcadeMinigame", "Degenatron_DontCrossTheLine_Home", 0.5f, 0.5f, 1f * uParam0->f_9, 1f,
						  0f, 255, 255, 255, 255, 0);
}

// Position - 0x353
void func_4(var *uParam0) {
	bool bVar0;
	int iVar1;
	bool bVar2;
	int iVar3;

	if (network::network_is_host_of_this_script()) {
		bVar0 = true;
		iVar1 = 0;
		bVar2 = false;
		iVar3 = 0;
		while (iVar3 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar3)) &&
				Local_366[iVar3 /*2*/] > -1) {
				if (!gameplay::is_bit_set(Local_366[iVar3 /*2*/].f_1, 6)) {
					bVar2 = true;
				}
				if (gameplay::is_bit_set(Local_366[iVar3 /*2*/].f_1, 2)) {
					iVar1 = 1;
				}
				if (!gameplay::is_bit_set(Local_366[iVar3 /*2*/].f_1, 4)) {
					bVar0 = false;
				}
			}
			else if (Local_288.f_7[iVar3] != 0) {
				Local_288.f_7[iVar3] = 0;
			}
			iVar3++;
		}
		if (!func_12(&uParam0->f_28) && !func_11(uParam0) && !iVar1) {
			func_10(&uParam0->f_28, 0, 0);
		}
		else {
			if (bVar2 || iVar1 || func_11(uParam0)) {
				func_9(&uParam0->f_28);
			}
			if (func_8(&uParam0->f_28, 3000, 0) && func_12(&uParam0->f_28) && !func_11(uParam0) && !iVar1) {
				if (bVar0) {
					func_7(uParam0, 10);
					return;
				}
				else if (!iVar1) {
					Local_288.f_77 = 0;
					func_7(uParam0, 4);
					Local_288.f_1 = -1;
					return;
				}
			}
		}
		if (!func_12(&uParam0->f_26) && !bVar2) {
			func_10(&uParam0->f_26, 0, 0);
		}
		else {
			if (bVar2) {
				func_9(&uParam0->f_26);
				return;
			}
			if (func_8(&uParam0->f_26, 10000, 0)) {
				func_6(0);
				func_5(0, 0);
				Local_288.f_77 = 0;
				func_7(uParam0, 4);
			}
		}
	}
}

// Position - 0x4FA
void func_5(int iParam0, int iParam1) {
	if (iParam0) {
		if (!gameplay::is_bit_set(Global_1619421[player::player_id() /*390*/].f_3, 0)) {
			gameplay::set_bit(&Global_1751026, 7);
		}
		gameplay::set_bit(&Global_1619421[player::player_id() /*390*/].f_3, 0);
	}
	else {
		if (iParam1) {
			if (gameplay::is_bit_set(Global_1751026, 4)) {
				gameplay::clear_bit(&Global_1751026, 4);
			}
			if (gameplay::is_bit_set(Global_1751026, 0)) {
				gameplay::set_bit(&Global_1751026, 1);
				gameplay::clear_bit(&Global_1751026, 0);
			}
		}
		gameplay::clear_bit(&Global_1619421[player::player_id() /*390*/].f_3, 0);
	}
}

// Position - 0x585
void func_6(int iParam0) {
	if (iParam0) {
		gameplay::set_bit(&Global_1619421[player::player_id() /*390*/].f_3, 1);
	}
	else {
		gameplay::clear_bit(&Global_1619421[player::player_id() /*390*/].f_3, 1);
	}
}

// Position - 0x5B9
void func_7(var *uParam0, int iParam1) {
	uParam0->f_4 = 0;
	Local_288 = iParam1;
}

// Position - 0x5CB
bool func_8(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_10(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0x629
void func_9(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0x636
void func_10(var *uParam0, int iParam1, int iParam2) {
	if (uParam0->f_1 == 0) {
		if (network::network_is_game_in_progress() && !iParam1) {
			if (!iParam2) {
				*uParam0 = network::get_network_time();
			}
			else {
				*uParam0 = network::_0x89023FBBF9200E9F();
			}
		}
		else {
			*uParam0 = gameplay::get_game_timer();
		}
		uParam0->f_1 = 1;
	}
}

// Position - 0x67B
int func_11(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < network::_network_get_num_participants_host()) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
			if (!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 6) && (*uParam0 != 9 || *uParam0 != 3)) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x6D2
bool func_12(var *uParam0) { return uParam0->f_1; }

// Position - 0x6DE
void func_13(var *uParam0) {
	int iVar0;
	bool bVar1;

	if (network::network_is_host_of_this_script()) {
		if (!func_12(&uParam0->f_22)) {
			func_10(&uParam0->f_22, 0, 0);
			if (Local_288.f_1 != -1) {
				Local_288.f_7[Local_288.f_1]++;
			}
			iVar0 = 0;
			while (iVar0 <= network::_network_get_num_participants_host() - 1) {
				if (!network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
					Local_288.f_7[iVar0] = 0;
				}
				iVar0++;
			}
		}
		else if (func_8(&uParam0->f_22, 3000, 0)) {
			bVar1 = true;
			iVar0 = 0;
			while (iVar0 <= network::_network_get_num_participants_host() - 1) {
				if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
					Local_366[iVar0 /*2*/] > -1) {
					if (!gameplay::is_bit_set(Local_366[iVar0 /*2*/].f_1, 2)) {
						bVar1 = false;
					}
					else {
						iVar0++;
					}
					if (bVar1) {
						func_14(uParam0);
						func_5(1, 0);
						func_7(uParam0, 9);
					}
				}
				// Malformed control flow, Output may be wrong
			}
		}
	}
}

// Position - 0x7CD
void func_14(var *uParam0) {
	int iVar0;

	func_9(&uParam0->f_12);
	func_9(&uParam0->f_16);
	func_9(&uParam0->f_18);
	func_9(&uParam0->f_20);
	func_9(&uParam0->f_22);
	func_9(&uParam0->f_26);
	func_9(&uParam0->f_28);
	func_9(&uParam0->f_30);
	func_9(&uParam0->f_24);
	gameplay::clear_bit(&uParam0->f_2, 0);
	gameplay::clear_bit(&uParam0->f_2, 1);
	gameplay::clear_bit(&uParam0->f_2, 2);
	gameplay::clear_bit(&uParam0->f_2, 3);
	gameplay::clear_bit(&uParam0->f_2, 9);
	gameplay::clear_bit(&uParam0->f_2, 8);
	gameplay::clear_bit(&uParam0->f_2, 7);
	gameplay::clear_bit(&uParam0->f_2, 10);
	gameplay::clear_bit(&uParam0->f_2, 12);
	gameplay::clear_bit(&uParam0->f_2, 6);
	gameplay::clear_bit(&uParam0->f_2, 11);
	gameplay::clear_bit(&uParam0->f_2, 13);
	gameplay::clear_bit(&uParam0->f_2, 15);
	gameplay::clear_bit(&uParam0->f_2, 16);
	gameplay::clear_bit(&uParam0->f_2, 18);
	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (iVar0 < 4) {
			uParam0->f_35[iVar0 /*79*/].f_3 = 0;
			uParam0->f_35[iVar0 /*79*/].f_17 = 1f;
		}
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
			func_16(&uParam0->f_35, 0, iVar0);
		}
		else {
			func_15(&uParam0->f_35[iVar0 /*79*/].f_18);
			func_16(&uParam0->f_35, 3, iVar0);
		}
		iVar0++;
	}
}

// Position - 0x914
void func_15(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = 0f;
		iVar0++;
	}
}

// Position - 0x93A
void func_16(var *uParam0, int iParam1, int iParam2) { (*uParam0)[iParam2 /*79*/] = iParam1; }

// Position - 0x94A
void func_17(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (network::network_is_host_of_this_script()) {
		iVar1 = 4;
		iVar2 = -1;
		iVar0 = 0;
		while (iVar0 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
				Local_366[iVar0 /*2*/] > -1) {
				if (uParam0->f_35[iVar0 /*79*/] == 3) {
					iVar1--;
				}
				else if (uParam0->f_35[iVar0 /*79*/] == 2) {
					iVar2 = iVar0;
				}
			}
			else {
				iVar1--;
			}
			iVar0++;
		}
		if (iVar1 <= 1) {
			if (!func_12(&uParam0->f_24)) {
				func_10(&uParam0->f_24, 0, 0);
			}
			else if (func_8(&uParam0->f_24, 1000, 0)) {
				func_7(uParam0, 8);
			}
			else if (func_8(&uParam0->f_24, 500, 0)) {
				if (iVar2 > -1) {
					Local_288.f_1 = iVar2;
				}
			}
		}
	}
}

// Position - 0xA14
void func_18(var *uParam0) {
	if (network::network_is_host_of_this_script()) {
		if (func_12(&uParam0->f_18)) {
			if (func_8(&uParam0->f_18, 2000, 0) && !gameplay::is_bit_set(iLocal_219, 1)) {
				func_19(network::_0x89023FBBF9200E9F() + 1250);
				gameplay::set_bit(&iLocal_219, 1);
			}
			if (func_8(&uParam0->f_18, 3000, 0)) {
				func_7(uParam0, 7);
				gameplay::clear_bit(&iLocal_219, 1);
			}
		}
	}
}

// Position - 0xA79
void func_19(var uParam0) {
	vector3 vVar0;
	int iVar3;

	vVar0.x = 561;
	vVar0.y = player::player_id();
	vVar0.z = uParam0;
	iVar3 = func_20(1);
	if (iVar3 != 0) {
		script::trigger_script_event(1, &vVar0, 3, iVar3);
	}
}

// Position - 0xAB0
var func_20(int iParam0) {
	var uVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	while (iVar1 < network::_network_get_num_participants_host()) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
			iVar2 = network::network_get_player_index(player::int_to_participantindex(iVar1));
			if (func_21(iVar2, 0, 0)) {
				if (iVar2 != player::player_id() || iParam0) {
					gameplay::set_bit(&uVar0, iVar2);
				}
			}
		}
		iVar1++;
	}
	return uVar0;
}

// Position - 0xB0D
bool func_21(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0xB57
void func_22(var *uParam0) {
	int iVar0;

	if (network::network_is_host_of_this_script()) {
		iVar0 = network::network_get_num_participants();
		if (iVar0 == 1) {
			func_7(uParam0, 10);
			return;
		}
		if (func_12(&uParam0->f_16)) {
			if (func_8(&uParam0->f_16, 2000, 0)) {
				func_7(uParam0, 6);
			}
		}
	}
}

// Position - 0xB9E
void func_23(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	bool bVar4;

	if (network::network_is_host_of_this_script()) {
		if (!func_12(&uParam0->f_32)) {
			func_10(&uParam0->f_32, 0, 0);
		}
		else if (func_8(&uParam0->f_32, 1000, 0)) {
			iVar0 = network::network_get_num_participants();
			if (iVar0 == 1) {
				func_7(uParam0, 10);
				return;
			}
			bVar4 = true;
			switch (Local_288.f_77) {
			case 0:
				iVar1 = 0;
				while (iVar1 <= network::_network_get_num_participants_host() - 1) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar1)) &&
						Local_366[iVar1 /*2*/] > -1) {
						Local_288.f_2[iVar1] = Local_366[iVar1 /*2*/];
					}
					else {
						Local_288.f_2[iVar1] = -1;
					}
					iVar1++;
				}
				Local_288.f_77 = 1;
				break;

			case 1:
				iVar1 = 0;
				while (iVar1 <= network::_network_get_num_participants_host() - 1) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
						if (Local_288.f_2[iVar1] == -1) {
							Local_288.f_2[iVar1] = func_24();
						}
					}
					iVar1++;
				}
				Local_288.f_77 = 2;
				break;

			case 2:
				iVar1 = 0;
				while (iVar1 <= network::_network_get_num_participants_host() - 1) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
						iVar2 = 0;
						while (iVar2 <= network::_network_get_num_participants_host() - 1) {
							if (network::network_is_participant_active(player::int_to_participantindex(iVar2))) {
								if (iVar2 != iVar1 &&
									(Local_288.f_2[iVar1] == Local_288.f_2[iVar2] || Local_288.f_2[iVar1] == -1)) {
									Local_288.f_2[iVar1] = -1;
									Local_288.f_77 = 1;
									return;
								}
							}
							iVar2++;
						}
					}
					iVar1++;
				}
				iVar1 = 0;
				while (iVar1 <= network::_network_get_num_participants_host() - 1) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
						if (Local_288.f_2[iVar1] != -1) {
							iVar3 = func_24();
							if (iVar3 != -1 && iVar3 < Local_288.f_2[iVar1]) {
								Local_288.f_2[iVar1] = iVar3;
								return;
							}
						}
					}
					iVar1++;
				}
				Local_288.f_77 = 3;
				break;

			case 3:
				iVar1 = 0;
				while (iVar1 <= network::_network_get_num_participants_host() - 1) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
						if (!gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 5)) {
							bVar4 = false;
						}
					}
					iVar1++;
				}
				if (bVar4) {
					func_9(&uParam0->f_12);
					func_9(&uParam0->f_32);
					func_7(uParam0, 5);
				}
				break;
			}
		}
	}
}

// Position - 0xDFA
int func_24() {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		iVar2 = 0;
		iVar1 = 0;
		while (iVar1 <= network::_network_get_num_participants_host() - 1) {
			if (Local_288.f_2[iVar1] == iVar0) {
				iVar2 = 1;
			}
			else {
				iVar1++;
			}
		}
		if (iVar2 == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xE53
void func_25(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (network::network_is_host_of_this_script()) {
		iVar0 = 1;
		iVar1 = 0;
		iVar2 = 0;
		while (iVar2 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar2)) &&
				Local_366[iVar2 /*2*/] > -1) {
				if (!gameplay::is_bit_set(Local_366[iVar2 /*2*/].f_1, 6)) {
					iVar1 = 1;
				}
				if (gameplay::is_bit_set(Local_366[iVar2 /*2*/].f_1, 2)) {
					iVar0 = 0;
				}
			}
			iVar2++;
		}
		if (!func_12(&uParam0->f_14) && !func_11(uParam0) && !iVar1) {
			func_10(&uParam0->f_14, 0, 0);
		}
		else {
			if (iVar1 || func_11(uParam0)) {
				func_9(&uParam0->f_14);
				return;
			}
			iVar3 = network::network_get_num_participants();
			if (iVar0 && iVar3 > 1 || func_8(&uParam0->f_14, 30000, 0)) {
				if (!func_12(&uParam0->f_12)) {
					func_10(&uParam0->f_12, 0, 0);
				}
				else if (func_8(&uParam0->f_12, 3000, 0) && !func_11(uParam0)) {
					func_9(&uParam0->f_12);
					if (iVar3 == 1) {
						func_7(uParam0, 10);
						return;
					}
					Local_288.f_77 = 0;
					func_7(uParam0, 4);
					func_6(0);
					func_5(0, 0);
				}
			}
		}
	}
}

// Position - 0xF97
void func_26(var *uParam0) {
	bool bVar0;
	int iVar1;

	if (network::network_is_host_of_this_script()) {
		bVar0 = true;
		iVar1 = 0;
		while (iVar1 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar1)) &&
				Local_366[iVar1 /*2*/] > -1) {
				if (!gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 1)) {
					bVar0 = false;
				}
				else {
					iVar1++;
				}
				if (bVar0) {
					func_7(uParam0, 3);
				}
			}
			// Malformed control flow, Output may be wrong
		}
	}
}

// Position - 0xFFF
void func_27(var *uParam0) {
	bool bVar0;
	int iVar1;

	if (network::network_is_host_of_this_script()) {
		bVar0 = true;
		iVar1 = 0;
		while (iVar1 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar1)) &&
				Local_366[iVar1 /*2*/] > -1) {
				if (!gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 0)) {
					bVar0 = false;
				}
				else {
					iVar1++;
				}
				if (bVar0) {
					func_7(uParam0, 2);
				}
			}
			// Malformed control flow, Output may be wrong
		}
	}
}

// Position - 0x1067
void func_28(var *uParam0) {
	int iVar0;

	if (network::network_is_host_of_this_script()) {
		iVar0 = 0;
		while (iVar0 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
				if (Local_366[iVar0 /*2*/] == -1) {
					return;
				}
			}
			iVar0++;
		}
		func_7(uParam0, 1);
	}
}

// Position - 0x10AF
void func_29(var *uParam0) {
	audio::stop_audio_scene("DLC_Exec_Arc_Mac_Playing_Game_Scene");
	audio::stop_sound(uParam0->f_3);
	audio::stop_sound(uParam0->f_7);
	if (network::participant_id_to_int() != -1) {
		audio::stop_sound(uParam0->f_35[network::participant_id_to_int() /*79*/].f_5);
	}
	if (audio::is_stream_playing()) {
		audio::stop_stream();
	}
	func_43();
	Global_1633501.f_102723 = 0;
	func_42();
	Global_1591201[player::player_id() /*602*/].f_510 = 0;
	func_41(0, 1, 1, 0);
	func_40();
	func_39();
	ui::clear_additional_text(3, 1);
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_34);
	}
	if (func_37() && !streaming::is_new_load_scene_active()) {
		if (network::network_is_game_in_progress()) {
			func_32(player::player_id(), 1, 0);
		}
		else {
			player::set_player_control(player::player_id(), 1, 0);
		}
	}
	func_31(1);
	func_180(uParam0, 12);
	func_208(0);
	func_30();
}

// Position - 0x1182
void func_30() { script::terminate_this_thread(); }

// Position - 0x118E
void func_31(int iParam0) {
	Global_1751026.f_1 = 0;
	Global_1751026 = 0;
	if (player::player_id() != -1) {
		Global_1619421[player::player_id() /*390*/].f_3 = 0;
	}
	if (iParam0) {
		func_10(&Global_1751026.f_2, 0, 0);
	}
	else {
		func_9(&Global_1751026.f_2);
	}
}

// Position - 0x11D6
void func_32(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	bool bVar3;
	bool bVar4;
	bool bVar5;
	bool bVar6;
	bool bVar7;
	bool bVar8;
	bool bVar9;
	bool bVar10;
	bool bVar11;
	bool bVar12;
	bool bVar13;
	bool bVar14;
	int iVar15;
	int iVar16;
	bool bVar17;
	bool bVar18;
	bool bVar19;
	bool bVar20;
	bool bVar21;
	bool bVar22;
	bool bVar23;
	bool bVar24;
	int iVar25;
	int iVar26;

	if (iParam1) {
		if (script::_get_no_loading_screen()) {
			script::set_no_loading_screen(0);
		}
	}
	if (!network::network_is_game_in_progress()) {
		iVar0 = iParam2;
		player::set_player_control(iParam0, iParam1, iVar0);
	}
	else {
		bVar1 = (iParam2 & 2) != false;
		bVar2 = (iParam2 & 4) != false;
		bVar3 = (iParam2 & 8) != false;
		bVar4 = (iParam2 & 16) != false;
		bVar5 = (iParam2 & 32) != false;
		bVar6 = (iParam2 & 64) != false;
		bVar7 = (iParam2 & 128) != false;
		bVar8 = (iParam2 & 256) != false;
		bVar9 = (iParam2 & 512) != false;
		bVar10 = (iParam2 & 1024) != false;
		bVar11 = (iParam2 & 2048) != false;
		bVar12 = (iParam2 & 4096) != false;
		bVar13 = (iParam2 & 8192) != false;
		bVar14 = (iParam2 & 16384) != false;
		iVar15 = (iParam2 & 32768) != 0;
		iVar16 = (iParam2 & 65536) != 0;
		bVar17 = (iParam2 & 131072) != false;
		bVar18 = (iParam2 & 262144) != false;
		bVar19 = (iParam2 & 524288) != false;
		bVar20 = (iParam2 & 1048576) != false;
		bVar21 = (iParam2 & 2097152) != false;
		bVar22 = (iParam2 & 4194304) != false;
		bVar23 = (iParam2 & 8388608) != false;
		if (!func_37()) {
			bVar24 = false;
			if (iParam1 == 1) {
				bVar24 = true;
			}
			if (iVar15 == 0 && !bVar20) {
				bVar24 = true;
			}
			if (bVar9 == 1) {
				bVar24 = true;
			}
			if (bVar24) {
				return;
			}
		}
		if (bVar17) {
		}
		if (network::network_is_player_active(iParam0) && player::is_player_playing(iParam0)) {
			iVar25 = player::get_player_ped(iParam0);
			if (!bVar19) {
				if (bVar18 && iParam1 == 0 && network::network_is_game_in_progress()) {
					network::fade_out_local_player(1);
				}
				else {
					entity::set_entity_visible(iVar25, !bVar13, 0);
				}
				if (!bVar13) {
					if (network::network_is_game_in_progress() && !bVar18) {
						network::fade_out_local_player(0);
					}
					Global_2421664[iParam0 /*358*/].f_247 = 0;
				}
			}
			if (iParam1) {
				if (!func_36(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, 1, 0);
					}
				}
				if (!entity::is_entity_attached(iVar25)) {
					if (!bVar20) {
						entity::freeze_entity_position(iVar25, 0);
					}
					entity::_set_entity_register(iVar25, 1);
				}
				else if (!bVar20) {
					entity::freeze_entity_position(iVar25, 0);
				}
				ped::set_ped_can_be_targetted(iVar25, 1);
				player::set_player_invincible(iParam0, 0);
				ped::_0x4668D80430D6C299(iVar25);
				ped::set_ped_can_ragdoll(iVar25, 1);
				func_35();
				func_34();
				if (player::is_player_teleport_active()) {
					if (!bVar22) {
					}
				}
				if (streaming::is_new_load_scene_active()) {
				}
				Global_2421664[iParam0 /*358*/].f_248 = 0;
				if (!bVar23) {
					bVar2 = true;
				}
			}
			else {
				if (!func_36(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, !bVar14, 0);
					}
					if (!entity::is_entity_attached(iVar25)) {
						if (!bVar20) {
							entity::freeze_entity_position(iVar25, iVar15);
						}
						if (!iVar15) {
							entity::_set_entity_register(iVar25, 1);
						}
					}
					if (func_33(Global_1633501.f_107548)) {
						entity::freeze_entity_position(iVar25, 1);
					}
				}
				if (bVar9) {
					player::set_player_invincible(iParam0, 0);
				}
				else {
					player::set_player_invincible(iParam0, 1);
				}
				ped::set_ped_can_be_targetted(iVar25, iVar16);
				if (bVar2) {
					if (!ped::is_ped_fatally_injured(iVar25) && !ped::is_ped_in_any_vehicle(iVar25, 0)) {
						ai::clear_ped_tasks_immediately(iVar25);
					}
				}
			}
			iVar26 = 0;
			if (bVar1) {
				iVar26 |= 2;
			}
			if (bVar2) {
				iVar26 |= 4;
			}
			if (bVar3) {
				iVar26 |= 8;
			}
			if (bVar4) {
				iVar26 |= 16;
			}
			if (bVar5) {
				iVar26 |= 32;
			}
			if (bVar6) {
				iVar26 |= 64;
			}
			if (bVar7) {
				iVar26 |= 128;
			}
			if (bVar8) {
				iVar26 |= 256;
			}
			if (bVar9) {
				iVar26 |= 512;
			}
			if (bVar10) {
				iVar26 |= 1024;
			}
			if (bVar11) {
				iVar26 |= 2048;
			}
			if (bVar12) {
				iVar26 |= 4096;
			}
			player::set_player_control(iParam0, iParam1, iVar26);
		}
	}
}

// Position - 0x158D
bool func_33(int iParam0) { return iParam0 == 17; }

// Position - 0x159A
void func_34() {
	struct<2> Var0;

	Global_2433125.f_731 = 0;
	Global_2433125.f_732 = 0;
	Global_2433125.f_733 = {9999.9f, 9999.9f, 9999.9f};
	Global_2404994.f_2220 = {Var0};
}

// Position - 0x15D7
void func_35() {
	Global_2404994.f_644 = 0;
	Global_2404994.f_2261 = 0;
	Global_2404994.f_501 = 0;
	Global_2404994.f_576 = 0;
	Global_2421664[player::player_id() /*358*/].f_210 = 0;
}

// Position - 0x160D
int func_36(int iParam0) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iParam0, 1)) {
		return 1;
	}
	else {
		iVar0 = ai::get_script_task_status(iParam0, -1794415470);
		if (iVar0 == 0) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x163E
int func_37() {
	if (func_38() == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x1653
int func_38() { return Global_1312466.f_18; }

// Position - 0x1661
void func_39() {
	graphics::set_streamed_texture_dict_as_no_longer_needed("LineArcadeMinigame");
	audio::release_named_script_audio_bank("DLC_EXEC1/OFFICE_BOARDROOM");
	ui::clear_additional_text(3, 0);
	gameplay::clear_bit(&Global_1751026, 6);
	gameplay::clear_bit(&Global_1751026, 7);
}

// Position - 0x168E
void func_40() { Global_2433125.f_655.f_10 = 0; }

// Position - 0x16A0
int func_41(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && iParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x16D3
void func_42() {
	if (Global_1751495) {
	}
	Global_1751495 = 0;
}

// Position - 0x16E7
void func_43() {
	if (!Global_1312567) {
		return;
	}
	func_44();
}

// Position - 0x16FE
void func_44() {
	Global_1312567 = 0;
	StringCopy(&Global_1312567.f_1, "", 24);
	Global_1312567.f_7 = 0;
}

// Position - 0x171D
void func_45(var *uParam0) {
	func_52(uParam0);
	func_48(uParam0);
	if (gameplay::is_bit_set(uParam0->f_2, 16)) {
		func_47(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 16);
	}
	if (audio::has_sound_finished(uParam0->f_7)) {
		audio::play_sound_frontend(uParam0->f_7, "Game_Over_Blink", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
	}
	if (!func_12(&uParam0->f_30)) {
		func_10(&uParam0->f_30, 0, 0);
	}
	else if (func_8(&uParam0->f_30, 5000, 0)) {
		func_180(uParam0, 11);
		func_46(0);
	}
	if (controls::is_control_just_pressed(2, 201) || controls::is_control_just_pressed(2, 202)) {
		func_180(uParam0, 11);
		func_46(0);
	}
}

// Position - 0x17C1
void func_46(int iParam0) {
	if (iParam0) {
		gameplay::set_bit(&Global_1619421[player::player_id() /*390*/].f_3, 5);
	}
	else {
		gameplay::clear_bit(&Global_1619421[player::player_id() /*390*/].f_3, 5);
	}
}

// Position - 0x17F5
void func_47(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "HIDE_LOBBY");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x1818
void func_48(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 12)) {
		func_49(uParam0, "DCTL_GAMEOVER", 0, 1);
		gameplay::set_bit(&uParam0->f_2, 12);
	}
}

// Position - 0x1843
void func_49(var *uParam0, char *sParam1, int iParam2, int iParam3) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "SET_CENTRAL_MESSAGE");
		func_51(sParam1);
		graphics::_push_scaleform_movie_function_parameter_int(iParam2);
		graphics::_push_scaleform_movie_function_parameter_int(iParam3);
		func_50("");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x187F
void func_50(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x188D
void func_51(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x189F
void func_52(var *uParam0) {
	int iVar0;

	iVar0 = 255;
	func_53(0f, 0f, 1f, 1f, 0, 0, 0, iVar0);
	graphics::draw_sprite("LineArcadeMinigame", "Degenatron_DontCrossTheLine_Game", 0.5f, 0.5f, 1f * uParam0->f_9, 1f,
						  0f, 255, 255, 255, iVar0, 0);
}

// Position - 0x18DA
void func_53(float fParam0, float fParam1, float fParam2, float fParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7) {
	graphics::draw_rect(fParam0 + fParam2 * 0.5f, fParam1 + fParam3 * 0.5f, fParam2, fParam3, iParam4, iParam5, iParam6,
						iParam7, 0);
}

// Position - 0x1909
void func_54(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_2, 15)) {
		func_77(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 15);
	}
	func_52(uParam0);
	func_72(uParam0);
	if (gameplay::is_pc_version()) {
		controls::disable_control_action(2, 200, 1);
	}
	if (!ui::is_pause_menu_active()) {
		if (controls::is_control_just_pressed(2, 201) && !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
			!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
			func_71(3);
		}
		else if (controls::is_control_just_pressed(2, 202) &&
				 !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
				 !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
			func_71(4);
		}
	}
	if (func_70()) {
		func_6(1);
	}
	if (!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
		!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 4)) {
			ui::display_help_text_this_frame("DCTL_REPLAYHELP", 0);
			gameplay::set_bit(&uParam0->f_2, 5);
		}
	}
	func_56(uParam0, 1);
	func_55(uParam0);
	if (Local_288 == 10) {
		audio::stop_sound(uParam0->f_3);
		audio::play_sound_frontend(-1, "Music_Game_Over", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
		gameplay::set_bit(&uParam0->f_2, 4);
		func_180(uParam0, 10);
		func_46(1);
		func_6(0);
		func_5(0, 0);
	}
	else if (Local_288 == 4) {
		if (gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4) ||
			gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 2)) {
			func_180(uParam0, 11);
			return;
		}
		gameplay::clear_bit(&iLocal_219, 0);
		func_14(uParam0);
		func_6(0);
		func_5(0, 0);
		gameplay::set_bit(&uParam0->f_2, 4);
		func_180(uParam0, 4);
	}
}

// Position - 0x1ABE
void func_55(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			if (gameplay::is_bit_set(Local_366[iVar0 /*2*/].f_1, 3) &&
				!gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 2)) {
				audio::play_sound_frontend(uParam0->f_6, "Insert_Coin", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				gameplay::set_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 2);
				if (gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 3)) {
					gameplay::clear_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 3);
				}
			}
			else if (gameplay::is_bit_set(Local_366[iVar0 /*2*/].f_1, 4) &&
					 !gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 3)) {
				audio::play_sound_frontend(uParam0->f_6, "Cancel", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				gameplay::set_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 3);
				if (gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 2)) {
					gameplay::clear_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 2);
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x1BC5
void func_56(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Local_288.f_2[iLocal_218] != Local_366[iLocal_218 /*2*/]) {
		Local_366[iLocal_218 /*2*/] = Local_288.f_2[iLocal_218];
	}
	if (!gameplay::is_bit_set(iLocal_219, 2)) {
		iVar0 = 0;
		while (iVar0 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
				if (Local_366[iVar0 /*2*/] > -1 && (gameplay::is_string_null_or_empty(&Local_288.f_12[iVar0 /*16*/]) ||
													gameplay::is_string_null_or_empty(&Local_223[iVar0 /*16*/]))) {
					gameplay::set_bit(&iLocal_219, 2);
				}
			}
			else if (!(gameplay::is_string_null_or_empty(&Local_288.f_12[iVar0 /*16*/]) ||
					   gameplay::is_string_null_or_empty(&Local_223[iVar0 /*16*/]))) {
				gameplay::set_bit(&iLocal_219, 2);
			}
			iVar0++;
		}
	}
	if (gameplay::is_bit_set(iLocal_219, 2)) {
		func_62();
		iVar1 = 1;
		iVar0 = 0;
		while (iVar0 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar0))) {
				if (Local_366[iVar0 /*2*/] == -1 || gameplay::is_string_null_or_empty(&Local_288.f_12[iVar0 /*16*/]) ||
					gameplay::is_string_null_or_empty(&Local_223[iVar0 /*16*/])) {
					iVar1 = 0;
				}
			}
			else if (!gameplay::is_string_null_or_empty(&Local_288.f_12[iVar0 /*16*/]) ||
					 !gameplay::is_string_null_or_empty(&Local_223[iVar0 /*16*/])) {
				iVar1 = 0;
			}
			iVar0++;
		}
		if (iVar1 == 1) {
			if (iParam1) {
				func_57(uParam0, "DCTL_REPLAY", 0);
			}
			else {
				func_57(uParam0, "DCTL_INSERT", 0);
			}
			gameplay::clear_bit(&iLocal_219, 2);
		}
	}
}

// Position - 0x1D3C
void func_57(var *uParam0, char *sParam1, int iParam2) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "INIT_LOBBY");
		func_51(sParam1);
		graphics::_push_scaleform_movie_function_parameter_int(iParam2);
		func_58(0);
		func_58(1);
		func_58(2);
		func_58(3);
		if (iLocal_218 > -1 && Local_366[iLocal_218 /*2*/] > -1) {
			graphics::_push_scaleform_movie_function_parameter_int(Local_366[iLocal_218 /*2*/]);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x1DA0
void func_58(int iParam0) {
	struct<16> Var0;
	struct<16> Var16;

	Var0 = {func_61(iParam0)};
	Var16 = {func_59(iParam0)};
	graphics::_push_scaleform_movie_function_parameter_string(&Var16);
	func_50(&Var0);
}

// Position - 0x1DCA
struct<16> func_59(int iParam0) {
	struct<16> Var0;
	int iVar16;

	StringCopy(&Var0, func_60(), 64);
	iVar16 = 0;
	while (iVar16 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar16)) &&
			Local_366[iVar16 /*2*/] == iParam0) {
			Var0 = {Local_223[iVar16 /*16*/]};
		}
		iVar16++;
	}
	return Var0;
}

//Position - 0x1E1B
var func_60()
{
	var uVar0;

	return uVar0;
}

// Position - 0x1E25
struct<16> func_61(int iParam0) {
	struct<16> Var0;
	int iVar16;

	StringCopy(&Var0, "", 64);
	iVar16 = 0;
	while (iVar16 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar16)) &&
			Local_366[iVar16 /*2*/] == iParam0) {
			Var0 = {Local_288.f_12[iVar16 /*16*/]};
		}
		iVar16++;
	}
	return Var0;
}

//Position - 0x1E78
void func_62()
{
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (iVar0 < 4) {
			if (network::network_is_host_of_this_script()) {
				StringCopy(&Local_288.f_12[iVar0 /*16*/], "", 64);
			}
			StringCopy(&Local_223[iVar0 /*16*/], func_60(), 64);
		}
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			if (network::network_is_host_of_this_script()) {
				StringCopy(
					&Local_288.f_12[iVar0 /*16*/],
					player::get_player_name(network::network_get_player_index(player::int_to_participantindex(iVar0))),
					64);
			}
			iVar1 = func_63(network::network_get_player_index(player::int_to_participantindex(iVar0)));
			if (iVar1 != 0) {
				StringCopy(&Local_223[iVar0 /*16*/], ped::get_pedheadshot_txd_string(iVar1), 64);
			}
		}
		iVar0++;
	}
}

// Position - 0x1F1D
int func_63(int iParam0) {
	int iVar0;

	iVar0 = func_66(iParam0);
	if (iVar0 == -1) {
		func_64(iParam0, 1);
		return 0;
	}
	Global_1364072[iVar0 /*5*/].f_4 = 1;
	return Global_1364072[iVar0 /*5*/].f_2;
}

// Position - 0x1F53
void func_64(int iParam0, int iParam1) {
	if (!func_21(iParam0, 0, 1)) {
		return;
	}
	if (func_66(iParam0) != -1) {
		return;
	}
	if (Global_1364235) {
		if (iParam0 == Global_1364235.f_1) {
			return;
		}
	}
	if (func_65(iParam0)) {
		return;
	}
	if (Global_1364273 >= 32) {
		return;
	}
	Global_1364240[Global_1364273] = iParam0;
	Global_1364273++;
	if (iParam1) {
	}
}

// Position - 0x1FBF
bool func_65(int iParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_1364273) {
		if (Global_1364240[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x1FF1
int func_66(int iParam0) {
	int iVar0;

	if (!func_21(iParam0, 0, 1)) {
		return -1;
	}
	if (Global_1364233 == 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_1364233) {
		if (Global_1364072[iVar0 /*5*/].f_1 == iParam0) {
			if (ped::is_pedheadshot_valid(Global_1364072[iVar0 /*5*/].f_2) &&
				ped::is_pedheadshot_ready(Global_1364072[iVar0 /*5*/].f_2)) {
				return iVar0;
			}
			func_67(iVar0);
			return -1;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x2070
void func_67(int iParam0) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;

	if (iParam0 >= Global_1364233) {
		return;
	}
	if (ped::is_pedheadshot_valid(Global_1364072[iParam0 /*5*/].f_2)) {
		StringCopy(&cVar0, "CHAR_DEFAULT", 64);
		if (Global_1364072[iParam0 /*5*/].f_2 != 0) {
			StringCopy(&cVar16, ped::get_pedheadshot_txd_string(Global_1364072[iParam0 /*5*/].f_2), 64);
			ui::_0x317EBA71D7543F52(&cVar16, &cVar16, &cVar0, &cVar0);
		}
		ped::unregister_pedheadshot(Global_1364072[iParam0 /*5*/].f_2);
	}
	iVar32 = iParam0;
	iVar33 = iVar32 + 1;
	while (iVar33 < Global_1364233) {
		Global_1364072[iVar32 /*5*/] = {Global_1364072[iVar33 /*5*/]};
		iVar32++;
		iVar33++;
	}
	func_68(&Global_1364072[iVar32 /*5*/]);
	Global_1364233--;
}

// Position - 0x2126
void func_68(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_1 = func_69();
	uParam0->f_2 = 0;
	uParam0->f_4 = 0;
	if (network::network_is_game_in_progress()) {
		uParam0->f_3 = network::get_network_time();
	}
}

// Position - 0x2153
int func_69() { return -1; }

// Position - 0x215C
bool func_70() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	while (iVar1 < network::_network_get_num_participants_host()) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
			if (gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 3)) {
				iVar0++;
			}
		}
		iVar1++;
	}
	if (iVar0 > 1) {
		return true;
	}
	return false;
}

// Position - 0x21AB
void func_71(int iParam0) {
	gameplay::clear_bit(&Local_366[iLocal_218 /*2*/].f_1, 2);
	gameplay::clear_bit(&Local_366[iLocal_218 /*2*/].f_1, 3);
	gameplay::clear_bit(&Local_366[iLocal_218 /*2*/].f_1, 4);
	gameplay::set_bit(&Local_366[iLocal_218 /*2*/].f_1, iParam0);
}

// Position - 0x21EC
void func_72(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 16)) {
		func_57(uParam0, "DCTL_REPLAY", 0);
		gameplay::set_bit(&uParam0->f_2, 16);
	}
	func_75(uParam0);
	func_73(uParam0);
}

// Position - 0x2223
void func_73(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "SET_MICS");
		graphics::_push_scaleform_movie_function_parameter_int(func_74(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_74(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_74(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_74(3));
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x226B
int func_74(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] == iParam0) {
			iVar1 = network::network_get_player_index(player::int_to_participantindex(iVar0));
			if (!network::network_player_has_headset(iVar1)) {
				return 0;
			}
			if (network::network_is_player_muted_by_me(iVar1)) {
				return 1;
			}
			if (network::network_is_player_talking(iVar1)) {
				return 3;
			}
			return 2;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x22DA
void func_75(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "UPDATE_LOBBY");
		func_76(0);
		func_76(1);
		func_76(2);
		func_76(3);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x2312
void func_76(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	while (iVar1 < Local_366) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar1)) &&
			Local_366[iVar1 /*2*/] == iParam0) {
			iVar0 = 1;
			if (gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 3)) {
				graphics::_push_scaleform_movie_function_parameter_int(2);
			}
			else if (gameplay::is_bit_set(Local_366[iVar1 /*2*/].f_1, 4)) {
				graphics::_push_scaleform_movie_function_parameter_int(1);
			}
			else {
				graphics::_push_scaleform_movie_function_parameter_int(0);
			}
		}
		iVar1++;
	}
	if (!iVar0) {
		graphics::_push_scaleform_movie_function_parameter_int(0);
	}
}

// Position - 0x2392
void func_77(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "HIDE_HUD");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x23B6
void func_78(var *uParam0) {
	int iVar0;
	int iVar1;

	if (gameplay::is_bit_set(uParam0->f_2, 15)) {
		func_77(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 15);
	}
	func_52(uParam0);
	func_119(uParam0);
	if (Local_288 >= 9) {
		func_5(1, 0);
		if (audio::has_sound_finished(uParam0->f_3)) {
			audio::play_sound_frontend(uParam0->f_3, "Background", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
		}
		iVar0 = func_118(3762, -1, 0);
		iVar0++;
		func_117(3762, iVar0, -1, 1, 0);
		if (Local_288.f_1 == iLocal_218) {
			iVar1 = func_118(3761, -1, 0);
			iVar1++;
			func_117(3761, iVar1, -1, 1, 0);
			if (iVar1 >= Global_262145.f_14428) {
				func_116(7551, 1, -1, 1);
				if (entity::get_entity_model(player::player_ped_id()) == joaat("mp_m_freemode_01")) {
					func_79(func_113(-621355603, 3), 1, 1, 0, 0, -1);
				}
				else {
					func_79(func_113(-46521805, 4), 1, 1, 0, 0, -1);
				}
			}
		}
		func_62();
		func_180(uParam0, 9);
	}
	if (!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 2)) {
		func_71(2);
	}
}

// Position - 0x24C7
void func_79(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	if (iParam4 || iParam1) {
		if (iParam0 != 87 && iParam0 != 89 && iParam0 != 88 && iParam0 != 13 && iParam0 != 14 && iParam0 != 15 &&
			iParam0 != 16) {
			if (iParam0 != 71 && iParam0 != 72) {
				func_112(1233, iParam5);
			}
		}
		else {
			func_112(1233, iParam5);
		}
	}
	if (iParam1) {
		if (!func_111(iParam0, iParam5)) {
			func_108(iParam0, 1, iParam5);
		}
		if (iParam2 && iParam0 < 129) {
			if (func_106(iParam0) == 0) {
				func_100(12, func_105(iParam0, 3), func_104(iParam0, 3), func_103(iParam0, 3), func_102(iParam0, 3), -1,
						 0, 0, 0, -1);
				func_99(iParam0, 1);
			}
		}
		if (iParam3) {
			func_94(iParam0, 1, iParam5);
		}
		if (Global_1353070.f_1010 == 0) {
			Global_1353070.f_1011 = iParam0;
		}
	}
	else {
		if (func_111(iParam0, iParam5)) {
			func_108(iParam0, 0, iParam5);
			func_89(1233, -1, iParam5);
		}
		if (func_106(iParam0) == 1) {
			func_99(iParam0, 0);
		}
		if (func_88(iParam0, iParam5)) {
			func_80(iParam0, 0, iParam5);
		}
	}
}

// Position - 0x2610
void func_80(int iParam0, int iParam1, int iParam2) {
	if (iParam1) {
		if (!func_88(iParam0, iParam2)) {
			func_81(iParam0, 1, iParam2);
		}
	}
	else if (func_88(iParam0, iParam2)) {
		func_81(iParam0, 0, iParam2);
	}
}

// Position - 0x2649
void func_81(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	iVar0 = func_87(iParam0, iParam2);
	iVar1 = iParam0;
	if (iVar1 > -1) {
		if (iParam1) {
			gameplay::set_bit(&iVar0, func_86(iVar1));
		}
		else {
			gameplay::clear_bit(&iVar0, func_86(iVar1));
		}
		func_117(func_82(iParam0), iVar0, iParam2, 1, 0);
	}
}

// Position - 0x2698
int func_82(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = func_85(iVar0);
	if (func_84() == 0 || func_83() == 0 || func_84() == 999 && func_83() == 999) {
		switch (iVar1) {
		case 0: return 1043;

		case 1: return 1044;

		case 2: return 1045;

		case 3: return 1046;

		case 4: return 1047;

		case 5: return 1048;

		case 6: return 1482;

		case 7: return 1483;

		case 8: return 1484;

		case 9: return 1485;

		case 10: return 1941;

		case 11: return 1942;

		case 12: return 1943;

		case 13: return 2405;

		case 14: return 2425;

		case 15: return 2428;

		case 16: return 2431;

		case 17: return 2594;

		case 18: return 2597;

		case 19: return 2600;

		case 20: return 3756;

		case 21: return 3759;

		case 22: return 3834;

		case 23: return 3837;

		case 24: return 3840;

		case 25: return 3843;

		case 26: return 5334;

		case 27: return 5337;
		}
	}
	return 6022;
}

// Position - 0x2887
int func_83() { return Global_25191; }

// Position - 0x2892
int func_84() { return Global_25190; }

// Position - 0x289D
int func_85(int iParam0) { return iParam0 / 32; }

// Position - 0x28AA
int func_86(int iParam0) { return iParam0 % 32; }

// Position - 0x28B7
int func_87(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_118(func_82(iParam0), iParam1, 0);
	return iVar0;
}

// Position - 0x28D0
bool func_88(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam0 == -1) {
		return false;
	}
	iVar0 = func_87(iParam0, iParam1);
	iVar1 = func_86(iParam0);
	if (iVar1 < 0 || iVar1 >= 32) {
		return false;
	}
	return gameplay::is_bit_set(iVar0, iVar1);
}

// Position - 0x2912
void func_89(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = func_118(iParam0, func_92(iParam2), 0);
	iVar0 += iParam1;
	if (!func_91(iParam0)) {
		func_117(iParam0, iVar0, iParam2, 1, 0);
	}
	else {
		func_90(iParam0, iVar0, iParam2, 1);
	}
}

// Position - 0x2954
void func_90(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = Global_2503826[iParam0 /*3*/][func_92(iParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
	switch (iParam0) {
	case 782: Global_1363219[func_92(iParam2)] = iParam1; break;

	case 783: Global_1363225[func_92(iParam2)] = iParam1; break;

	case 784: Global_1363231[func_92(iParam2)] = iParam1; break;

	case 785: Global_1363237[func_92(iParam2)] = iParam1; break;

	case 772: Global_1363195[func_92(iParam2)] = iParam1; break;

	case 773: Global_1363201[func_92(iParam2)] = iParam1; break;

	case 774: Global_1363207[func_92(iParam2)] = iParam1; break;

	case 775: Global_1363213[func_92(iParam2)] = iParam1; break;

	case 762: Global_1363171[func_92(iParam2)] = iParam1; break;

	case 763: Global_1363177[func_92(iParam2)] = iParam1; break;

	case 764: Global_1363183[func_92(iParam2)] = iParam1; break;

	case 765: Global_1363189[func_92(iParam2)] = iParam1; break;

	case 752: Global_1363243[func_92(iParam2)] = iParam1; break;

	case 753: Global_1363249[func_92(iParam2)] = iParam1; break;

	case 754: Global_1363255[func_92(iParam2)] = iParam1; break;

	case 755: Global_1363261[func_92(iParam2)] = iParam1; break;

	case 1298: Global_1363267[func_92(iParam2)] = iParam1; break;

	case 634: Global_1363273[func_92(iParam2)] = iParam1; break;

	case 1273: Global_1363279[func_92(iParam2)] = iParam1; break;

	case 1870: Global_2524277[0 /*3*/][func_92(iParam2)] = iParam1; break;

	case 2261: Global_2524277[1 /*3*/][func_92(iParam2)] = iParam1; break;

	case 2911: Global_2524277[2 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3040: Global_2524277[3 /*3*/][func_92(iParam2)] = iParam1; break;

	case 5886: Global_2524348[func_92(iParam2)] = iParam1; break;

	case 759: Global_1363285[func_92(iParam2)] = iParam1; break;

	case 760: Global_1363291[func_92(iParam2)] = iParam1; break;

	case 761: Global_1363297[func_92(iParam2)] = iParam1; break;

	case 1231: Global_1363303[func_92(iParam2)] = iParam1; break;

	case 3035: Global_2524311[0 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3036: Global_2524311[1 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3037: Global_2524311[2 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3038: Global_2524311[3 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3039: Global_2524311[4 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3618: Global_2524351[0 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3619: Global_2524351[1 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3620: Global_2524351[2 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3621: Global_2524351[3 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3622: Global_2524351[4 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3623: Global_2524367[0 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3624: Global_2524367[1 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3625: Global_2524367[2 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3626: Global_2524367[3 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3627: Global_2524367[4 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3203: Global_2524311[5 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3209: Global_2524277[4 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3645: Global_2524383[func_92(iParam2)] = iParam1; break;

	case 3646: Global_2524392[func_92(iParam2)] = iParam1; break;

	case 3647: Global_2524386[func_92(iParam2)] = iParam1; break;

	case 3648: Global_2524395[func_92(iParam2)] = iParam1; break;

	case 3649: Global_2524389[func_92(iParam2)] = iParam1; break;

	case 3650: Global_2524398[func_92(iParam2)] = iParam1; break;

	case 3671: Global_2524401[func_92(iParam2)] = iParam1; break;

	case 3211: Global_2524311[6 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3212: Global_2524277[5 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3216: Global_2524311[7 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3214: Global_2524277[6 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3991: Global_2524311[8 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3992: Global_2524277[7 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3994: Global_2524311[9 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3995: Global_2524277[8 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3997: Global_2524311[10 /*3*/][func_92(iParam2)] = iParam1; break;

	case 3998: Global_2524277[9 /*3*/][func_92(iParam2)] = iParam1; break;

	case 4000: Global_2524311[11 /*3*/][func_92(iParam2)] = iParam1; break;

	case 4001: Global_2524277[10 /*3*/][func_92(iParam2)] = iParam1; break;

	default: break;
	}
}

// Position - 0x2FB3
int func_91(int iParam0) {
	if (Global_1363152) {
		switch (iParam0) {
		case 782:
		case 783:
		case 784:
		case 785:
		case 772:
		case 773:
		case 774:
		case 775:
		case 762:
		case 763:
		case 764:
		case 765:
		case 752:
		case 753:
		case 754:
		case 755:
		case 1298:
		case 634:
		case 1273:
		case 759:
		case 760:
		case 761:
		case 1231:
		case 1870:
		case 2261:
		case 2911:
		case 3040:
		case 5886:
		case 3035:
		case 3036:
		case 3037:
		case 3038:
		case 3039:
		case 3214:
		case 3216:
		case 3618:
		case 3619:
		case 3620:
		case 3621:
		case 3622:
		case 3623:
		case 3624:
		case 3625:
		case 3626:
		case 3627:
		case 3209:
		case 3203:
		case 3645:
		case 3646:
		case 3647:
		case 3648:
		case 3649:
		case 3650:
		case 3671:
		case 3212:
		case 3211:
		case 3992:
		case 3991:
		case 3995:
		case 3994:
		case 3998:
		case 3997:
		case 4001:
		case 4000: return 1;
		}
	}
	return 0;
}

// Position - 0x3151
int func_92(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_93();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x3185
var func_93() { return Global_1312735; }

// Position - 0x3191
void func_94(int iParam0, int iParam1, int iParam2) {
	if (iParam1) {
		if (!func_98(iParam0)) {
			func_95(iParam0, 1, iParam2);
		}
	}
	else if (func_98(iParam0)) {
		func_95(iParam0, 0, iParam2);
	}
}

// Position - 0x31C6
void func_95(var uParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	iVar0 = func_97(uParam0);
	iVar1 = uParam0;
	if (iVar1 > -1) {
		if (iParam1) {
			gameplay::set_bit(&iVar0, func_86(iVar1));
		}
		else {
			gameplay::clear_bit(&iVar0, func_86(iVar1));
		}
		func_117(func_96(uParam0), iVar0, iParam2, 1, 0);
	}
}

// Position - 0x3213
int func_96(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	iVar1 = func_85(iVar0);
	if (func_84() == 0 || func_83() == 0 || func_84() == 999 && func_83() == 999) {
		switch (iVar1) {
		case 0: return 1038;

		case 1: return 1039;

		case 2: return 1040;

		case 3: return 1041;

		case 4: return 1042;

		case 5: return 1486;

		case 6: return 1487;

		case 7: return 1488;

		case 8: return 1489;

		case 9: return 1937;

		case 10: return 1938;

		case 11: return 1939;

		case 12: return 1940;

		case 13: return 2406;

		case 14: return 2426;

		case 15: return 2429;

		case 16: return 2432;

		case 17: return 2595;

		case 18: return 2598;

		case 19: return 2601;

		case 20: return 3757;

		case 21: return 3760;

		case 22: return 3835;

		case 23: return 3838;

		case 24: return 3841;

		case 25: return 3844;

		case 26: return 5335;

		case 27: return 5338;
		}
	}
	return 6022;
}

// Position - 0x3405
int func_97(var uParam0) {
	int iVar0;

	iVar0 = func_118(func_96(uParam0), -1, 0);
	return iVar0;
}

// Position - 0x341D
bool func_98(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = func_97(uParam0);
	iVar1 = uParam0;
	return gameplay::is_bit_set(iVar0, func_86(iVar1));
}

// Position - 0x343D
void func_99(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 > -1) {
		if (iParam1) {
			gameplay::set_bit(&Global_2502458.f_1027[func_85(iVar0)], func_86(iVar0));
		}
		else {
			gameplay::clear_bit(&Global_2502458.f_1027[func_85(iVar0)], func_86(iVar0));
		}
	}
}

// Position - 0x348C
void func_100(int iParam0, char *sParam1, char *sParam2, char *sParam3, char *sParam4, int iParam5, int iParam6,
			  int iParam7, char *sParam8, int iParam9) {
	int iVar0;

	iVar0 = func_101(&Global_1360303);
	Global_1360303[iVar0 /*105*/] = iParam0;
	StringCopy(&Global_1360303[iVar0 /*105*/].f_17, sParam3, 64);
	StringCopy(&Global_1360303[iVar0 /*105*/].f_1, sParam4, 64);
	StringCopy(&Global_1360303[iVar0 /*105*/].f_33, sParam1, 64);
	StringCopy(&Global_1360303[iVar0 /*105*/].f_49, sParam2, 64);
	Global_1360303[iVar0 /*105*/].f_97 = iParam5;
	Global_1360303[iVar0 /*105*/].f_104 = iParam9;
	if (iParam6 != 0) {
	}
	if (iParam7 != 0) {
	}
	if (!gameplay::is_string_null_or_empty(sParam8)) {
		StringCopy(&Global_1360303[iVar0 /*105*/].f_98, sParam8, 24);
	}
}

// Position - 0x351C
int func_101(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 <= 9) {
		if ((*uParam0)[iVar1 /*105*/] == 0) {
			iVar0 = iVar1;
			iVar1 = 10;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x354B
char *func_102(int iParam0, int iParam1) {
	char *sVar0;

	sVar0 = "MPTATTOOS";
	if (iParam0 == iParam0) {
	}
	if (iParam1 == iParam1) {
	}
	switch (iParam0) {
	case 56: return "MPTattoos3";

	case 89: return "MPTSHIRTAWARDS";

	case 88: return "MPTSHIRTAWARDS";

	case 87: return "MPTSHIRTAWARDS";

	case 57: return "MPTattoos2";

	case 58: return "MPTattoos2";

	case 59: return "MPTattoos2";

	case 60: return "MPTattoos2";

	case 12:
	case 55:
	case 49:
	case 48:
	case 46:
	case 45:
	case 34:
	case 65:
	case 25: return "MPTattoos3";
	}
	return sVar0;
}

// Position - 0x3630
char *func_103(int iParam0, int iParam1) {
	char *sVar0;

	sVar0 = "";
	if (iParam0 == iParam0) {
	}
	if (iParam1 == iParam1) {
	}
	switch (iParam0) {
	case 56: return "TATTOO_WIN_PARLEY";

	case 57: return "TATTOO_HOLD_UP_SHOPS_10";

	case 58: return "TATTOO_HOLD_UP_SHOPS_25";

	case 59: return "TATTOO_HOLD_UP_SHOPS_50";

	case 60: return "TATTOO_HOLD_UP_SHOPS_100";

	case 0: return "HeadBanger";

	case 1: return "theslayer";

	case 2: return "clearout";

	case 4: return "thehustler";

	case 3: return "armoredvantakedowns";

	case 54: return "wineverymodeonce";

	case 5: return "killplayerbountyhead";

	case 6: return "holdworldrecord";

	case 55: return "MP_FM_Tat_Award_008";

	case 7: return "getrevengekills";

	case 8: return "kill3otherracers";

	case 9: return "reachrank1";

	case 10: return "reachrank2";

	case 11: return "reachrank3";

	case 13: return "HeadBanger";

	case 14: return "HeadBanger";

	case 15: return "HeadBanger";

	case 16: return "HeadBanger";

	case 89: return "RockstarVerifiied";

	case 88: return "PickUpCrateFirst";

	case 87: return "ReachHordeModeWave";

	case 12: return "TATTOO_RACES_WON";
	}
	switch (iParam0) {
	case 17: return "Headbanger";

	case 18: return "Headbanger";

	case 19: return "Headbanger";

	case 20: return "Headbanger";

	case 21: return "Headbanger";

	case 22: return "Headbanger";

	case 23: return "Headbanger";

	case 24: return "Headbanger";

	case 25: return "MP_FM_Tat_002";

	case 26: return "Headbanger";

	case 27: return "Headbanger";

	case 28: return "Headbanger";

	case 61: return "Headbanger";

	case 62: return "Headbanger";

	case 63: return "Headbanger";

	case 64: return "Headbanger";

	case 65: return "MP_FM_Tat_019";

	case 29: return "Headbanger";

	case 30: return "Headbanger";

	case 31: return "Headbanger";

	case 66: return "Headbanger";

	case 32: return "Headbanger";

	case 33: return "Headbanger";

	case 34: return "MP_FM_Tat_023";

	case 35: return "Headbanger";

	case 36: return "Headbanger";

	case 37: return "Headbanger";

	case 38: return "Headbanger";

	case 39: return "Headbanger";

	case 40: return "Headbanger";

	case 67: return "Headbanger";

	case 41: return "Headbanger";

	case 68: return "Headbanger";

	case 42: return "Headbanger";

	case 43: return "Headbanger";

	case 44: return "Headbanger";

	case 45: return "MP_FM_Tat_036";

	case 46: return "MP_FM_Tat_037";

	case 47: return "Headbanger";

	case 48: return "MP_FM_Tat_039";

	case 49: return "MP_FM_Tat_040";

	case 50: return "Headbanger";

	case 51: return "Headbanger";

	case 52: return "Headbanger";

	case 53: return "Headbanger";

	case 69: return "Headbanger";
	}
	return sVar0;
}

// Position - 0x3AEB
char *func_104(int iParam0, int iParam1) {
	char *sVar0;

	sVar0 = "";
	if (iParam0 == iParam0) {
	}
	if (iParam1 == iParam1) {
	}
	switch (iParam0) {
	case 7: return "TAT_FM_REVENKIL_D";

	case 6: return "TAT_FM_RECHOLD_d";

	case 8: return "TAT_FM_KIL3RACE_D";

	case 5: return "TAT_FM_KILb_D";

	case 0: return "TAT_FM_HEADBANG_D";

	case 12: return "TAT_RACE50_D";

	case 2: return "TAT_CLEAROUT_D";

	case 9: return "TAT_FM_RANK1_D";

	case 10: return "TAT_FM_RANK2_D";

	case 11: return "TAT_FM_RANK3_D";

	case 4: return "TAT_FM_HUST_D";

	case 1: return "TAT_FM_SLAY_D";

	case 54: return "TAT_FM_EVERMODE1_D";

	case 3: return "TAT_FM_ARVANTAKE_D";

	case 56: return "TAT_CHEATER_D";

	case 13: return "TAT_CRANKA_D";

	case 14: return "TAT_CRANKB_D";

	case 15: return "TAT_CRANKC_D";

	case 16: return "TAT_CRANKD_D";

	case 89: return "TAT_FM_ROCKSTAR_D";

	case 88: return "TAT_FM_BELLE_D";

	case 87: return "TAT_FM_REDSKULL_D";

	case 55: return "TAT_FM_MODDED_D";
	}
	switch (iParam0) {
	case 17: return "TAT_RANK10_D";

	case 18: return "TAT_RANK20_D";

	case 19: return "TAT_RANK20_D";

	case 20: return "TAT_RANK10_D";

	case 21: return "TAT_RANK20_D";

	case 22: return "TAT_RANK10_D";

	case 23: return "TAT_RANK10_D";

	case 24: return "TAT_RANK20_D";

	case 25: return "TAT_TAT9U";

	case 26: return "TAT_RANK20_D";

	case 27: return "TAT_RANK20_D";

	case 28: return "TAT_RANK10_D";

	case 61: return "TAT_RANK10_D";

	case 62: return "TAT_RANK10_D";

	case 63: return "TAT_RANK10_D";

	case 64: return "TAT_RANK10_D";

	case 65: return "TAT_TAT17U";

	case 29: return "TAT_RANK10_D";

	case 30: return "TAT_RANK10_D";

	case 31: return "TAT_RANK10_D";

	case 66: return "TAT_RANK20_D";

	case 32: return "TAT_RANK20_D";

	case 33: return "TAT_RANK20_D";

	case 34: return "TAT_TAT24U";

	case 35: return "TAT_RANK20_D";

	case 36: return "TAT_RANK20_D";

	case 37: return "TAT_RANK20_D";

	case 38: return "TAT_RANK20_D";

	case 39: return "TAT_RANK20_D";

	case 40: return "TAT_RANK20_D";

	case 67: return "TAT_RANK20_D";

	case 41: return "TAT_RANK20_D";

	case 68: return "TAT_RANK20_D";

	case 42: return "TAT_RANK20_D";

	case 43: return "TAT_RANK20_D";

	case 44: return "TAT_RANK20_D";

	case 45: return "TAT_TAT37U";

	case 46: return "TAT_TAT38U";

	case 47: return "TAT_RANK20_D";

	case 48: return "TAT_TAT40U";

	case 49: return "TAT_TAT41U";

	case 50: return "TAT_RANK20_D";

	case 51: return "TAT_RANK20_D";

	case 52: return "TAT_RANK20_D";

	case 53: return "TAT_RANK20_D";

	case 69: return "TAT_RANK20_D";

	case 57: return "TAT_HOLDUP1V_D";

	case 58: return "TAT_HOLDUP5V_D";

	case 59: return "TAT_HOLDUP10V_D";

	case 60: return "TAT_HOLDUP20V_D";
	}
	return sVar0;
}

// Position - 0x3FA6
char *func_105(int iParam0, int iParam1) {
	char *sVar0;

	sVar0 = "";
	if (iParam0 == iParam0) {
	}
	if (iParam1 == iParam1) {
	}
	switch (iParam0) {
	case 0: return "TAT_FM_HEADBANG";

	case 2: return "TAT_CLEAROUT";

	case 9: return "TAT_FM_RANK1";

	case 10: return "TAT_FM_RANK2";

	case 11: return "TAT_FM_RANK3";

	case 4: return "TAT_FM_HUST";

	case 1: return "TAT_FM_SLAY";

	case 54: return "TAT_FM_EVERMODE1";

	case 3: return "TAT_FM_ARVANTAKE";

	case 7: return "TAT_FM_REVENKIL";

	case 5: return "TAT_FM_KILb";

	case 8: return "TAT_FM_KIL3RACE";

	case 6: return "TAT_FM_RECHOLD";

	case 12: return "TAT_RACE50";

	case 13: return "TAT_CRANKA";

	case 14: return "TAT_CRANKB";

	case 15: return "TAT_CRANKC";

	case 16: return "TAT_CRANKD";

	case 87: return "TAT_FM_REDSKULL";

	case 88: return "TAT_FM_BELLE";

	case 89: return "TAT_FM_ROCKSTAR";

	case 55: return "TAT_FM_MODDED";

	case 17: return "TAT_FM_TAT1";

	case 18: return "TAT_FM_TAT2";

	case 19: return "TAT_FM_TAT3";

	case 20: return "TAT_FM_TAT4";

	case 21: return "TAT_FM_TAT5";

	case 22: return "TAT_FM_TAT6";

	case 56: return "TAT_CHEATER";
	}
	switch (iParam0) {
	case 23: return "TAT_FM_TAT7";

	case 24: return "TAT_FM_TAT8";

	case 25: return "TAT_FM_TAT9";

	case 26: return "TAT_FM_TAT10";

	case 27: return "TAT_FM_TAT11";

	case 28: return "TAT_FM_TAT12";

	case 61: return "TAT_FM_TAT13";

	case 62: return "TAT_FM_TAT14";

	case 63: return "TAT_FM_TAT15";

	case 64: return "TAT_FM_TAT16";

	case 65: return "TAT_FM_TAT38";

	case 29: return "TAT_FM_TAT18";

	case 30: return "TAT_FM_TAT19";

	case 31: return "TAT_FM_TAT20";

	case 66: return "TAT_FM_TAT21";

	case 32: return "TAT_FM_TAT22";

	case 33: return "TAT_FM_TAT23";

	case 34: return "TAT_FM_TAT24";

	case 35: return "TAT_FM_TAT25";

	case 36: return "TAT_FM_TAT26";

	case 37: return "TAT_FM_TAT27";

	case 38: return "TAT_FM_TAT28";

	case 39: return "TAT_FM_TAT29";

	case 40: return "TAT_FM_TAT30";

	case 67: return "TAT_FM_TAT31";

	case 41: return "TAT_FM_TAT32";

	case 68: return "TAT_FM_TAT33";

	case 42: return "TAT_FM_TAT34";

	case 43: return "TAT_FM_TAT35";

	case 44: return "TAT_FM_TAT36";

	case 45: return "TAT_FM_TAT37";

	case 46: return "TAT_FM_TAT41";

	case 47: return "TAT_FM_TAT39";

	case 48: return "TAT_FM_TAT40";

	case 49: return "TAT_FM_TAT17";

	case 50: return "TAT_FM_TAT42";

	case 51: return "TAT_FM_TAT43";

	case 52: return "TAT_FM_TAT44";

	case 53: return "TAT_FM_TAT45";

	case 69: return "TAT_FM_TAT46";

	case 57: return "TAT_HOLDUP1V";

	case 58: return "TAT_HOLDUP5V";

	case 59: return "TAT_HOLDUP10V";

	case 60: return "TAT_HOLDUP20V";
	}
	return sVar0;
}

// Position - 0x44A1
int func_106(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = func_107(iParam0);
	iVar1 = iParam0;
	return gameplay::is_bit_set(iVar0, func_86(iVar1));
}

// Position - 0x44C1
var func_107(int iParam0) {
	var uVar0;

	uVar0 = Global_2502458.f_1027[func_85(iParam0)];
	return uVar0;
}

// Position - 0x44DC
void func_108(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (func_110(iParam0) == 6022) {
		return;
	}
	iVar0 = func_109(iParam0, -1);
	iVar1 = iParam0;
	if (iVar1 > -1) {
		if (iParam1) {
			gameplay::set_bit(&iVar0, func_86(iVar1));
		}
		else {
			gameplay::clear_bit(&iVar0, func_86(iVar1));
		}
		func_117(func_110(iParam0), iVar0, iParam2, 1, 0);
	}
}

// Position - 0x4539
int func_109(var uParam0, int iParam1) {
	int iVar0;

	iVar0 = func_118(func_110(uParam0), iParam1, 0);
	return iVar0;
}

// Position - 0x4552
int func_110(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	iVar1 = func_85(iVar0);
	if (func_84() == 0 || func_83() == 0 || func_84() == 999 && func_83() == 999) {
		switch (iVar1) {
		case 0: return 1033;

		case 1: return 1034;

		case 2: return 1035;

		case 3: return 1036;

		case 4: return 1037;

		case 5: return 1497;

		case 6: return 1750;

		case 7: return 1944;

		case 8: return 1945;

		case 9: return 1946;

		case 10: return 1947;

		case 11: return 1948;

		case 12: return 1949;

		case 13: return 2404;

		case 14: return 2424;

		case 15: return 2427;

		case 16: return 2430;

		case 17: return 2593;

		case 18: return 2596;

		case 19: return 2599;

		case 20: return 3755;

		case 21: return 3758;

		case 22: return 3833;

		case 23: return 3836;

		case 24: return 3839;

		case 25: return 3842;

		case 26: return 5333;

		case 27: return 5336;
		}
	}
	return 6022;
}

// Position - 0x4744
bool func_111(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (func_110(iParam0) == 6022) {
		return false;
	}
	iVar0 = func_109(iParam0, iParam1);
	iVar1 = iParam0;
	return gameplay::is_bit_set(iVar0, func_86(iVar1));
}

// Position - 0x4776
void func_112(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_118(iParam0, func_92(iParam1), 0);
	iVar0++;
	if (!func_91(iParam0)) {
		func_117(iParam0, iVar0, iParam1, 1, 0);
	}
	else {
		func_90(iParam0, iVar0, iParam1, 1);
	}
}

// Position - 0x47B7
int func_113(int iParam0, int iParam1) {
	int *iVar0;
	int iVar1;
	int iVar2;
	struct<4> Var3;

	if (iParam1 == 3) {
		if (func_115(iParam0, &iVar0)) {
			return iVar0;
		}
	}
	else if (iParam1 == 4) {
		if (func_114(iParam0, &iVar0)) {
			return iVar0;
		}
	}
	iVar2 = dlc1::_get_num_decorations(iParam1);
	iVar1 = 0;
	while (iVar1 < iVar2) {
		if (dlc1::_0xFF56381874F82086(iParam1, iVar1, &Var3)) {
			if (iParam0 == Var3.f_3) {
				return 129 + iVar1;
			}
		}
		iVar1++;
	}
	return -1;
}

// Position - 0x4828
bool func_114(int iParam0, int *iParam1) {
	int iVar0;

	iVar0 = -1;
	switch (iParam0) {
	case 497719213: iVar0 = 0; break;

	case -1575660783: iVar0 = 1; break;

	case -720631087: iVar0 = 2; break;

	case 2143620721: iVar0 = 3; break;

	case 2049754822: iVar0 = 4; break;

	case -1293749076: iVar0 = 5; break;

	case -1571403599: iVar0 = 6; break;

	case -711123906: iVar0 = 7; break;

	case 152801037: iVar0 = 8; break;

	case -1324018585: iVar0 = 9; break;

	case -481068829: iVar0 = 10; break;

	case -1486741196: iVar0 = 11; break;

	case 939412564: iVar0 = 12; break;

	case 1187637739: iVar0 = 13; break;

	case -1092669445: iVar0 = 14; break;

	case 1659530389: iVar0 = 15; break;

	case 996857777: iVar0 = 16; break;

	case 817476859: iVar0 = 17; break;

	case -17051268: iVar0 = 18; break;

	case 1293774274: iVar0 = 19; break;

	case 567121699: iVar0 = 20; break;

	case -1179302160: iVar0 = 21; break;

	case -949165473: iVar0 = 22; break;

	case 354975189: iVar0 = 23; break;

	case -489121482: iVar0 = 24; break;

	case -1636954018: iVar0 = 25; break;

	case -1277740240: iVar0 = 26; break;

	case -1047439708: iVar0 = 27; break;

	case -814026121: iVar0 = 28; break;

	case 1732157956: iVar0 = 29; break;

	case 1024282018: iVar0 = 30; break;

	case -2099685063: iVar0 = 31; break;

	case 1483932781: iVar0 = 32; break;

	case 1406925627: iVar0 = 33; break;

	case 698590923: iVar0 = 34; break;

	case 1869001296: iVar0 = 35; break;

	case 1169907450: iVar0 = 36; break;

	case 717727185: iVar0 = 37; break;

	case 1058197095: iVar0 = 38; break;

	case 434115743: iVar0 = 39; break;

	case 665432114: iVar0 = 40; break;

	case 1198780358: iVar0 = 41; break;

	case -2128873857: iVar0 = 42; break;

	case -148547780: iVar0 = 43; break;

	case 1819096318: iVar0 = 44; break;

	case 1051122042: iVar0 = 45; break;

	case -1350495965: iVar0 = 46; break;

	case -150859291: iVar0 = 47; break;

	case -1186193045: iVar0 = 48; break;

	case -1206837515: iVar0 = 49; break;

	case -1513653662: iVar0 = 50; break;

	case -543948331: iVar0 = 51; break;

	case -175559233: iVar0 = 52; break;

	case -131530830: iVar0 = 53; break;

	case -1816086813: iVar0 = 54; break;

	case -2113006722: iVar0 = 55; break;

	case -1101886458: iVar0 = 56; break;

	case -1398740829: iVar0 = 57; break;

	case 1939258347: iVar0 = 58; break;

	case -1004151544: iVar0 = 59; break;

	case -822873436: iVar0 = 60; break;

	case -1445222284: iVar0 = 61; break;

	case -63910623: iVar0 = 62; break;

	case 101834979: iVar0 = 63; break;

	case -673512330: iVar0 = 64; break;

	case -423845319: iVar0 = 65; break;

	case 963561372: iVar0 = 66; break;

	case 1384839636: iVar0 = 67; break;

	case -1712879828: iVar0 = 68; break;

	case -951688727: iVar0 = 69; break;

	case -1132639145: iVar0 = 70; break;

	case -513632731: iVar0 = 71; break;

	case 263680718: iVar0 = 72; break;

	case 36296627: iVar0 = 73; break;

	case 800240324: iVar0 = 74; break;

	case 614243480: iVar0 = 75; break;

	case 1408138043: iVar0 = 76; break;

	case 957564293: iVar0 = 77; break;

	case -1614279399: iVar0 = 78; break;

	case -1451286393: iVar0 = 79; break;

	case -1758069771: iVar0 = 80; break;

	case -1225475222: iVar0 = 81; break;

	case -1992892433: iVar0 = 82; break;

	case -1838157215: iVar0 = 83; break;

	case 1688803028: iVar0 = 84; break;

	case 1844259164: iVar0 = 85; break;

	case 1070943545: iVar0 = 86; break;

	case 1234460855: iVar0 = 87; break;

	case -753798460: iVar0 = 88; break;

	case -1453351072: iVar0 = 89; break;

	case -1308053326: iVar0 = 90; break;

	case -2083859401: iVar0 = 91; break;

	case 1586137527: iVar0 = 92; break;

	case 1884564810: iVar0 = 93; break;

	case 1092964089: iVar0 = 94; break;

	case 1264280421: iVar0 = 95; break;

	case 496601058: iVar0 = 96; break;

	case 861352797: iVar0 = 97; break;

	case 1418328330: iVar0 = 98; break;

	case 1784554566: iVar0 = 99; break;
	}
	switch (iParam0) {
	case 2081736627: iVar0 = 100; break;

	case -1897271971: iVar0 = 101; break;

	case -1666742056: iVar0 = 102; break;

	case -1282165072: iVar0 = 103; break;

	case -1052880379: iVar0 = 104; break;

	case -745474390: iVar0 = 105; break;

	case -515796465: iVar0 = 106; break;

	case -811206225: iVar0 = 107; break;

	case -1586815686: iVar0 = 108; break;

	case -1423429452: iVar0 = 109; break;

	case -1697869815: iVar0 = 110; break;

	case -1470846183: iVar0 = 111; break;

	case 1093884035: iVar0 = 112; break;

	case 861256904: iVar0 = 113; break;

	case 603201029: iVar0 = 114; break;

	case 1991426949: iVar0 = 115; break;

	case -135838228: iVar0 = 116; break;

	case 121616864: iVar0 = 117; break;

	case -834517002: iVar0 = 118; break;

	case -403932342: iVar0 = 119; break;

	case -1179738417: iVar0 = 120; break;

	case -1022250603: iVar0 = 121; break;

	case 558694786: iVar0 = 122; break;

	case 569279177: iVar0 = 123; break;

	case 544309199: iVar0 = 124; break;

	case 1190448341: iVar0 = 125; break;

	case 885139568: iVar0 = 126; break;

	case -1845683606: iVar0 = 127; break;

	case -1555317497: iVar0 = 128; break;

	case 1704673699: iVar0 = 129; break;

	case 1993401358: iVar0 = 130; break;

	case 1227065524: iVar0 = 131; break;

	case -533227790: iVar0 = 132; break;

	case 309459814: iVar0 = 133; break;

	case 77815753: iVar0 = 134; break;

	case -280939203: iVar0 = 135; break;

	case 1246882601: iVar0 = 136; break;

	case 314833986: iVar0 = 137; break;

	case -25635924: iVar0 = 138; break;

	case 351567983: iVar0 = 139; break;

	case -2027428652: iVar0 = 140; break;

	case 962677064: iVar0 = 141; break;

	case -105475497: iVar0 = 142; break;

	case 766835283: iVar0 = 143; break;

	case 471979821: iVar0 = 144; break;

	case 1122542778: iVar0 = 145; break;

	case 815530017: iVar0 = 146; break;

	case 1157900525: iVar0 = 147; break;

	case 859243859: iVar0 = 148; break;

	case 2032013608: iVar0 = 149; break;

	case 1471663700: iVar0 = 150; break;

	case -1679206722: iVar0 = 151; break;

	case -309397848: iVar0 = 152; break;

	case 534666054: iVar0 = 153; break;

	case -769376301: iVar0 = 154; break;

	case 1531057961: iVar0 = 155; break;

	case 1986678137: iVar0 = 156; break;

	case 2142789653: iVar0 = 157; break;

	case 7463306: iVar0 = 158; break;

	case 308053343: iVar0 = 159; break;

	case 753842819: iVar0 = 160; break;

	case 1052794406: iVar0 = 161; break;

	case -695726661: iVar0 = 162; break;

	case -1001821890: iVar0 = 163; break;

	case -1425459522: iVar0 = 164; break;

	case 1412653072: iVar0 = 165; break;

	case 1163510365: iVar0 = 166; break;

	case 933242602: iVar0 = 167; break;

	case -1347021116: iVar0 = 168; break;

	case 1297354841: iVar0 = 169; break;

	case -839806574: iVar0 = 170; break;

	case -542100209: iVar0 = 171; break;

	case 1472218269: iVar0 = 172; break;

	case 1783196079: iVar0 = 173; break;

	case 1007062314: iVar0 = 174; break;

	case -870732522: iVar0 = 175; break;

	case 547542627: iVar0 = 176; break;

	case 863894553: iVar0 = 177; break;

	case -2099242332: iVar0 = 178; break;

	case -1860028632: iVar0 = 179; break;

	case -560967165: iVar0 = 180; break;

	case -59437904: iVar0 = 181; break;

	case 757067269: iVar0 = 182; break;

	case 455625238: iVar0 = 183; break;

	case -1750514914: iVar0 = 184; break;

	case -983982466: iVar0 = 185; break;

	case -232228837: iVar0 = 186; break;

	case 1558269323: iVar0 = 187; break;

	case 2070579873: iVar0 = 188; break;

	case -1203181916: iVar0 = 189; break;

	case -2112587204: iVar0 = 190; break;

	case 1942412705: iVar0 = 191; break;

	case -1846437386: iVar0 = 192; break;

	case 61799795: iVar0 = 193; break;

	case -1388490611: iVar0 = 194; break;

	case -1627212776: iVar0 = 195; break;

	case 1525246127: iVar0 = 196; break;

	case -11341151: iVar0 = 197; break;

	case 516055815: iVar0 = 198; break;

	case -1034642040: iVar0 = 199; break;
	}
	switch (iParam0) {
	case 1022637316: iVar0 = 200; break;

	case -1677156418: iVar0 = 201; break;

	case -1130213300: iVar0 = 202; break;

	case 104062694: iVar0 = 203; break;

	case 869579299: iVar0 = 204; break;

	case 1201332655: iVar0 = 205; break;

	case 1028967715: iVar0 = 206; break;

	case -1651634800: iVar0 = 207; break;

	case -892278763: iVar0 = 208; break;

	case -1032005779: iVar0 = 209; break;

	case -255675400: iVar0 = 210; break;

	case 1890137027: iVar0 = 211; break;

	case -406805808: iVar0 = 212; break;

	case -592540500: iVar0 = 213; break;

	case 205417419: iVar0 = 214; break;

	case -2127276619: iVar0 = 215; break;

	case -1362677538: iVar0 = 216; break;

	case -1549722990: iVar0 = 217; break;

	case 3495990: iVar0 = 218; break;

	case -285526590: iVar0 = 219; break;

	case 1907377338: iVar0 = 220; break;

	case 2136399879: iVar0 = 221; break;

	case 1568410532: iVar0 = 222; break;

	case 1068879892: iVar0 = 223; break;

	case -1592750929: iVar0 = 224; break;

	case 772896404: iVar0 = 225; break;

	case -1999229916: iVar0 = 226; break;

	case -744701520: iVar0 = 227; break;

	case -425039925: iVar0 = 228; break;

	case -798409911: iVar0 = 229; break;

	case 1379974898: iVar0 = 230; break;

	case -1681436154: iVar0 = 231; break;

	case -1486919370: iVar0 = 232; break;

	case 2014677667: iVar0 = 233; break;

	case 325697857: iVar0 = 234; break;

	case -1188819501: iVar0 = 235; break;

	case -1765193438: iVar0 = 236; break;

	case -1416269126: iVar0 = 237; break;

	case -2111365154: iVar0 = 238; break;

	case -1880573087: iVar0 = 239; break;

	case 1421296887: iVar0 = 240; break;

	case 1655562468: iVar0 = 241; break;

	case 946048080: iVar0 = 242; break;

	case 1188768063: iVar0 = 243; break;

	case 498456313: iVar0 = 244; break;

	case 323007907: iVar0 = 245; break;

	case -1325371100: iVar0 = 246; break;

	case -829313978: iVar0 = 247; break;

	case -530624543: iVar0 = 248; break;

	case -299046020: iVar0 = 249; break;

	case 1812260650: iVar0 = 250; break;

	case 2043511487: iVar0 = 251; break;

	case -1753235933: iVar0 = 252; break;

	case -1525589690: iVar0 = 253; break;

	case 31003408: iVar0 = 254; break;

	case -1864998224: iVar0 = 255; break;

	case -2140814897: iVar0 = 256; break;

	case 223468453: iVar0 = 257; break;

	case -83970305: iVar0 = 258; break;

	case -406843262: iVar0 = 259; break;

	case -954740942: iVar0 = 260; break;

	case -1675526854: iVar0 = 261; break;

	case 2111717556: iVar0 = 262; break;

	case -415395003: iVar0 = 263; break;

	case 427521984: iVar0 = 264; break;

	case 1570178485: iVar0 = 265; break;

	case -1619850916: iVar0 = 266; break;

	case -713067148: iVar0 = 267; break;

	case 946477614: iVar0 = 268; break;

	case -1423343701: iVar0 = 269; break;

	case 445931457: iVar0 = 270; break;

	case 678558588: iVar0 = 271; break;

	case -854631987: iVar0 = 272; break;

	case -1707871209: iVar0 = 273; break;

	case 1675446188: iVar0 = 274; break;

	case 1911627074: iVar0 = 275; break;

	case -607391498: iVar0 = 276; break;

	case -1544625218: iVar0 = 277; break;

	case 1185175875: iVar0 = 278; break;

	case 155591269: iVar0 = 279; break;

	case -1057958846: iVar0 = 280; break;

	case -1853795495: iVar0 = 281; break;

	case -1860485560: iVar0 = 282; break;

	case 499288642: iVar0 = 283; break;

	case -7887054: iVar0 = 284; break;

	case -1553041502: iVar0 = 285; break;

	case -1080591445: iVar0 = 286; break;

	case -741060436: iVar0 = 287; break;

	case 645634644: iVar0 = 288; break;

	case -1096728771: iVar0 = 289; break;

	case 503268386: iVar0 = 290; break;

	case 109804153: iVar0 = 291; break;

	case 1410910279: iVar0 = 292; break;

	case 1501700194: iVar0 = 293; break;

	case -1793199216: iVar0 = 294; break;

	case 1405944575: iVar0 = 295; break;

	case 1731382556: iVar0 = 296; break;

	case 1743809026: iVar0 = 297; break;

	case 1589237530: iVar0 = 298; break;

	case -1558441108: iVar0 = 299; break;
	}
	switch (iParam0) {
	case 793815980: iVar0 = 303; break;

	case 87277824: iVar0 = 304; break;

	case 1305470790: iVar0 = 305; break;

	case 252924758: iVar0 = 306; break;

	case 1043745875: iVar0 = 307; break;

	case 24304530: iVar0 = 308; break;

	case 582246031: iVar0 = 309; break;

	case 1840225396: iVar0 = 310; break;

	case -47863515: iVar0 = 311; break;

	case 26968202: iVar0 = 312; break;

	case 1720638120: iVar0 = 313; break;

	case 1372737856: iVar0 = 314; break;

	case -675719916: iVar0 = 315; break;

	case -610888268: iVar0 = 316; break;

	case -129698248: iVar0 = 317; break;

	case 1060644905: iVar0 = 318; break;

	case 776078819: iVar0 = 319; break;

	case -1069464482: iVar0 = 320; break;

	case -1342875239: iVar0 = 321; break;

	case 1967892405: iVar0 = 322; break;

	case 642864781: iVar0 = 323; break;

	case 1270860039: iVar0 = 324; break;

	case -1290780406: iVar0 = 325; break;

	case 1127641545: iVar0 = 326; break;

	case -1221948530: iVar0 = 327; break;

	case 1954153055: iVar0 = 328; break;

	case 543727307: iVar0 = 329; break;

	case -1806626643: iVar0 = 330; break;

	case 1146362323: iVar0 = 331; break;

	case -1918158051: iVar0 = 332; break;

	case -1835082731: iVar0 = 333; break;

	case 1935907419: iVar0 = 334; break;

	case 961997868: iVar0 = 335; break;

	case -415246024: iVar0 = 336; break;

	case -2003529037: iVar0 = 337; break;

	case -1272951326: iVar0 = 338; break;

	case 837851491: iVar0 = 339; break;

	case -64649653: iVar0 = 340; break;

	case 1997623301: iVar0 = 341; break;

	case 1177835340: iVar0 = 342; break;

	case -1261787835: iVar0 = 343; break;

	case -965491494: iVar0 = 344; break;

	case 939374190: iVar0 = 345; break;

	case 149461503: iVar0 = 346; break;

	case -1117498985: iVar0 = 347; break;

	case 1184468662: iVar0 = 348; break;

	case -772488648: iVar0 = 349; break;

	case -1399171334: iVar0 = 350; break;

	case -963164512: iVar0 = 351; break;

	case -1284517669: iVar0 = 352; break;

	case 1613773443: iVar0 = 353; break;

	case 1963092516: iVar0 = 354; break;

	case -878642668: iVar0 = 355; break;

	case -1618544925: iVar0 = 356; break;

	case 1185417232: iVar0 = 357; break;

	case -1649044153: iVar0 = 358; break;

	case -1293956525: iVar0 = 359; break;

	case -84085370: iVar0 = 360; break;

	case -943861479: iVar0 = 361; break;

	case -1355455834: iVar0 = 362; break;

	case 711764191: iVar0 = 363; break;

	case 41616632: iVar0 = 364; break;

	case -2053984264: iVar0 = 365; break;

	case -522832741: iVar0 = 366; break;

	case 711940316: iVar0 = 367; break;

	case -1512107004: iVar0 = 368; break;

	case -273305505: iVar0 = 369; break;

	case -779122930: iVar0 = 370; break;

	case 565678099: iVar0 = 371; break;

	case 2130135469: iVar0 = 372; break;

	case 2142072717: iVar0 = 373; break;

	case -636638153: iVar0 = 374; break;

	case 289539239: iVar0 = 375; break;

	case -1040822561: iVar0 = 376; break;

	case 217486581: iVar0 = 377; break;

	case -2147244302: iVar0 = 378; break;

	case 830186237: iVar0 = 379; break;

	case -1902384566: iVar0 = 380; break;

	case 1471583453: iVar0 = 381; break;

	case 2007332931: iVar0 = 382; break;

	case 1104156493: iVar0 = 383; break;

	case 616400258: iVar0 = 384; break;

	case 511243162: iVar0 = 385; break;

	case -477451680: iVar0 = 386; break;

	case 743616295: iVar0 = 387; break;

	case 712215816: iVar0 = 388; break;

	case 1475570942: iVar0 = 389; break;

	case -1768978416: iVar0 = 390; break;

	case -2139711822: iVar0 = 391; break;

	case -1509236263: iVar0 = 392; break;

	case -1143383459: iVar0 = 393; break;

	case -1690206781: iVar0 = 394; break;

	case 1947095236: iVar0 = 395; break;

	case 300333876: iVar0 = 396; break;

	case 37732721: iVar0 = 397; break;

	case 959183706: iVar0 = 398; break;

	case -1542393224: iVar0 = 399; break;
	}
	switch (iParam0) {
	case 874488242: iVar0 = 400; break;

	case 1389335000: iVar0 = 401; break;

	case -366075547: iVar0 = 402; break;

	case -1125431584: iVar0 = 403; break;

	case -2000068963: iVar0 = 404; break;

	case 1497445248: iVar0 = 405; break;

	case 1989766704: iVar0 = 406; break;

	case -2086401979: iVar0 = 407; break;

	case -1846467361: iVar0 = 408; break;

	case -1325458477: iVar0 = 409; break;

	case -566725051: iVar0 = 410; break;

	case -787850263: iVar0 = 411; break;

	case -1885021085: iVar0 = 412; break;

	case 979307144: iVar0 = 413; break;

	case -473732439: iVar0 = 414; break;

	case 2062186390: iVar0 = 415; break;

	case -60867780: iVar0 = 416; break;

	case 926967912: iVar0 = 417; break;

	case -1886278590: iVar0 = 418; break;

	case -1314959708: iVar0 = 419; break;

	case -1696774529: iVar0 = 420; break;

	case -356446484: iVar0 = 421; break;

	case 857810380: iVar0 = 422; break;

	case -629676646: iVar0 = 423; break;

	case -1879530481: iVar0 = 424; break;

	case -1265847311: iVar0 = 425; break;

	case 32094424: iVar0 = 426; break;

	case 1969286744: iVar0 = 427; break;

	case 560620683: iVar0 = 428; break;

	case -148312642: iVar0 = 429; break;

	case -578277428: iVar0 = 430; break;

	case -718909970: iVar0 = 431; break;

	case -859026859: iVar0 = 432; break;

	case -839897805: iVar0 = 433; break;

	case 1676439910: iVar0 = 434; break;

	case -294157184: iVar0 = 435; break;

	case -1222200221: iVar0 = 436; break;

	case 874532672: iVar0 = 437; break;

	case -135929055: iVar0 = 438; break;

	case 1654917353: iVar0 = 439; break;

	case -13131391: iVar0 = 440; break;

	case 154845196: iVar0 = 441; break;

	case -1147884322: iVar0 = 442; break;

	case 291693311: iVar0 = 443; break;

	case -1401933531: iVar0 = 444; break;

	case 1820267020: iVar0 = 445; break;

	case 2134488961: iVar0 = 446; break;

	case -1861952745: iVar0 = 447; break;

	case 994458405: iVar0 = 448; break;

	case -1931715008: iVar0 = 449; break;

	case 1308745884: iVar0 = 450; break;

	case -1322955084: iVar0 = 451; break;

	case -816658183: iVar0 = 452; break;

	case -988307698: iVar0 = 453; break;

	case -1341411308: iVar0 = 454; break;

	case 1865570599: iVar0 = 455; break;

	case -549458010: iVar0 = 456; break;

	case -1328545177: iVar0 = 457; break;

	case -1361353619: iVar0 = 458; break;

	case 1103253806: iVar0 = 459; break;

	case -24183456: iVar0 = 460; break;

	case 436214104: iVar0 = 461; break;

	case 2072615278: iVar0 = 462; break;

	case -1131891426: iVar0 = 463; break;

	case 1392085456: iVar0 = 464; break;

	case 2035895234: iVar0 = 465; break;

	case 368784798: iVar0 = 466; break;

	case 1398938833: iVar0 = 467; break;

	case 1250040566: iVar0 = 468; break;

	case 2133228190: iVar0 = 469; break;

	case 675551540: iVar0 = 470; break;

	case -1826137848: iVar0 = 471; break;

	case -144105601: iVar0 = 472; break;

	case -748983650: iVar0 = 473; break;

	case 630291027: iVar0 = 474; break;

	case 293950434: iVar0 = 475; break;

	case 1857352111: iVar0 = 476; break;

	case -777671131: iVar0 = 477; break;

	case 221602924: iVar0 = 478; break;

	case 2039295216: iVar0 = 479; break;

	case 1800147054: iVar0 = 480; break;

	case -2019505897: iVar0 = 481; break;

	case 1647997020: iVar0 = 482; break;

	case -1405854945: iVar0 = 483; break;

	case -1171294997: iVar0 = 484; break;

	case -77076350: iVar0 = 485; break;

	case 775569873: iVar0 = 486; break;

	case 330569485: iVar0 = 487; break;

	case -1549217620: iVar0 = 488; break;

	case 1674429052: iVar0 = 489; break;

	case -254669596: iVar0 = 490; break;

	case 1802602254: iVar0 = 491; break;

	case -941072260: iVar0 = 492; break;

	case -1844749517: iVar0 = 493; break;

	case 82745424: iVar0 = 494; break;

	case -673460083: iVar0 = 495; break;

	case -99954496: iVar0 = 496; break;

	case 2078163456: iVar0 = 497; break;

	case 1362343227: iVar0 = 498; break;

	case 1176005743: iVar0 = 499; break;
	}
	switch (iParam0) {
	case -1504557219: iVar0 = 500; break;

	case 367912881: iVar0 = 501; break;

	case -836343280: iVar0 = 502; break;

	case -46521805: iVar0 = 503; break;

	case -743048780: iVar0 = 504; break;

	case 1294865118: iVar0 = 505; break;

	case -1479686374: iVar0 = 506; break;

	case 256017193: iVar0 = 507; break;

	case 1232443120: iVar0 = 508; break;

	case -803282271: iVar0 = 509; break;

	case 1788600442: iVar0 = 510; break;

	case 1439605343: iVar0 = 511; break;

	case -1094679264: iVar0 = 512; break;

	case 1230482241: iVar0 = 513; break;

	case 2054714291: iVar0 = 514; break;

	case 192117676: iVar0 = 515; break;

	case -2071204405: iVar0 = 516; break;

	case -1618181476: iVar0 = 517; break;

	case -1408253665: iVar0 = 518; break;

	case -134185391: iVar0 = 519; break;

	case -785783411: iVar0 = 520; break;

	case -633466710: iVar0 = 521; break;

	case -2072487372: iVar0 = 522; break;

	case 1211025296: iVar0 = 523; break;

	case 742659337: iVar0 = 524; break;

	case 1365533160: iVar0 = 525; break;

	case 1213205618: iVar0 = 526; break;

	case -164052103: iVar0 = 527; break;

	case -1306490297: iVar0 = 528; break;

	case -994802645: iVar0 = 529; break;

	case 637406209: iVar0 = 530; break;

	case -170855031: iVar0 = 531; break;

	case 1333098305: iVar0 = 532; break;

	case 119103934: iVar0 = 533; break;

	case -141369051: iVar0 = 534; break;

	case -593355218: iVar0 = 535; break;

	case 316832763: iVar0 = 536; break;

	case -393713544: iVar0 = 537; break;

	case -1876234625: iVar0 = 538; break;

	case -1453082334: iVar0 = 539; break;

	case -1397705983: iVar0 = 540; break;

	case -1278086171: iVar0 = 541; break;

	case -1510892268: iVar0 = 542; break;

	case 204876084: iVar0 = 543; break;

	case -988359492: iVar0 = 544; break;

	case 975745281: iVar0 = 545; break;

	case 591099372: iVar0 = 546; break;

	case -1014948306: iVar0 = 547; break;

	case -1866439788: iVar0 = 548; break;

	case -1265767186: iVar0 = 549; break;

	case 2070931859: iVar0 = 550; break;

	case 413611416: iVar0 = 551; break;

	case 765001063: iVar0 = 552; break;

	case -686624622: iVar0 = 553; break;

	case -937548349: iVar0 = 554; break;

	case 212584159: iVar0 = 555; break;

	case -328340062: iVar0 = 556; break;

	case 1657725123: iVar0 = 557; break;

	case -1517964336: iVar0 = 558; break;

	case -785490239: iVar0 = 559; break;

	case -11769229: iVar0 = 560; break;

	case 745912106: iVar0 = 561; break;

	case -2064265098: iVar0 = 562; break;

	case -1515892875: iVar0 = 563; break;

	case 1368234729: iVar0 = 564; break;

	case 1960230923: iVar0 = 565; break;

	case -860169810: iVar0 = 566; break;

	case -177882114: iVar0 = 567; break;

	case 661384509: iVar0 = 568; break;

	case 1221860095: iVar0 = 569; break;

	case 698192473: iVar0 = 570; break;

	case -817251083: iVar0 = 571; break;

	case -1108876323: iVar0 = 572; break;

	case 1274482696: iVar0 = 573; break;

	case 468009056: iVar0 = 574; break;

	case 2063732427: iVar0 = 575; break;

	case -764016411: iVar0 = 576; break;

	case -1530816149: iVar0 = 577; break;

	case 1189996018: iVar0 = 578; break;

	case -210110115: iVar0 = 579; break;

	case -207110256: iVar0 = 580; break;

	case 1801308144: iVar0 = 581; break;

	case 320631086: iVar0 = 582; break;

	case 1022560466: iVar0 = 583; break;

	case -952946041: iVar0 = 584; break;

	case 1321460664: iVar0 = 585; break;

	case -781625914: iVar0 = 586; break;

	case -1522247835: iVar0 = 587; break;

	case -1531245231: iVar0 = 588; break;

	case -1070472994: iVar0 = 589; break;

	case -2113341060: iVar0 = 590; break;

	case 965047293: iVar0 = 591; break;

	case 2114285045: iVar0 = 592; break;

	case -1635032213: iVar0 = 593; break;

	case 1310864345: iVar0 = 594; break;

	case -973977633: iVar0 = 595; break;

	case -1439643329: iVar0 = 596; break;

	case 434150104: iVar0 = 597; break;

	case 1243301688: iVar0 = 598; break;

	case -1233567982: iVar0 = 599; break;
	}
	switch (iParam0) {
	case 1262886680: iVar0 = 600; break;

	case 283135569: iVar0 = 601; break;

	case -548917969: iVar0 = 602; break;

	case 153465812: iVar0 = 603; break;

	case 1916093085: iVar0 = 604; break;

	case -701486200: iVar0 = 605; break;

	case 1951718630: iVar0 = 606; break;

	case -1981978861: iVar0 = 607; break;

	case -1998094267: iVar0 = 608; break;

	case -718445629: iVar0 = 609; break;

	case -35697399: iVar0 = 610; break;

	case -899081349: iVar0 = 611; break;

	case 1123547916: iVar0 = 612; break;

	case -1139893782: iVar0 = 613; break;

	case 1446511785: iVar0 = 614; break;

	case 1234256191: iVar0 = 615; break;

	case 413901048: iVar0 = 616; break;

	case 1527450164: iVar0 = 617; break;

	case -1786525476: iVar0 = 618; break;

	case 1439516635: iVar0 = 619; break;

	case 733800794: iVar0 = 620; break;

	case -399223540: iVar0 = 621; break;

	case -1894392230: iVar0 = 622; break;

	case 229993415: iVar0 = 623; break;

	case -620189683: iVar0 = 624; break;

	case 1846617794: iVar0 = 625; break;

	case -1142479347: iVar0 = 626; break;

	case -512960025: iVar0 = 627; break;

	case -759812557: iVar0 = 628; break;

	case 468661890: iVar0 = 629; break;

	case 1907925586: iVar0 = 630; break;

	case 646243571: iVar0 = 631; break;

	case 1953935161: iVar0 = 632; break;

	case 874867224: iVar0 = 633; break;

	case 1344008898: iVar0 = 634; break;

	case 1297781304: iVar0 = 635; break;

	case 1977233252: iVar0 = 636; break;

	case -194410344: iVar0 = 637; break;

	case 392012609: iVar0 = 638; break;

	case 705148450: iVar0 = 639; break;

	case 1677522529: iVar0 = 640; break;

	case -1362677538: iVar0 = 641; break;

	case 863458948: iVar0 = 642; break;

	case 9874621: iVar0 = 643; break;

	case 1809338990: iVar0 = 644; break;

	case -346939959: iVar0 = 645; break;

	case -934753544: iVar0 = 646; break;

	case 1604986209: iVar0 = 647; break;

	case -1514700421: iVar0 = 648; break;

	case 1177361060: iVar0 = 649; break;

	case -937529288: iVar0 = 650; break;

	case 547723644: iVar0 = 651; break;

	case 1750314531: iVar0 = 652; break;

	case -988332613: iVar0 = 653; break;

	case 80720443: iVar0 = 654; break;

	case -1220194634: iVar0 = 655; break;

	case -925735153: iVar0 = 656; break;

	case -1403745446: iVar0 = 657; break;

	case -1084626028: iVar0 = 658; break;

	case 2060572320: iVar0 = 659; break;

	case 1064377095: iVar0 = 660; break;

	case -1985597576: iVar0 = 661; break;

	case -2003189104: iVar0 = 662; break;

	case 1452329956: iVar0 = 663; break;

	case 1928573506: iVar0 = 664; break;

	case -185753722: iVar0 = 665; break;

	case -1580916109: iVar0 = 666; break;

	case -1077059973: iVar0 = 667; break;

	case 131755133: iVar0 = 668; break;

	case -253351038: iVar0 = 669; break;

	case 1332845224: iVar0 = 670; break;

	case -685051870: iVar0 = 671; break;

	case 2122847199: iVar0 = 672; break;

	case -149940744: iVar0 = 673; break;

	case -147741130: iVar0 = 674; break;

	case 302211868: iVar0 = 675; break;

	case -1361568592: iVar0 = 676; break;

	case -156600218: iVar0 = 677; break;

	case 1592739450: iVar0 = 678; break;

	case -633744004: iVar0 = 679; break;

	case -1467745952: iVar0 = 680; break;

	case 1129961041: iVar0 = 681; break;

	case -1221180772: iVar0 = 682; break;

	case 1957517559: iVar0 = 683; break;

	case -335233377: iVar0 = 684; break;

	case 2146762380: iVar0 = 685; break;

	case 427236107: iVar0 = 686; break;

	case -49636427: iVar0 = 687; break;

	case 1988133312: iVar0 = 688; break;

	case 40044091: iVar0 = 689; break;

	case -1189893809: iVar0 = 690; break;

	case 1182549017: iVar0 = 691; break;

	case 1403255481: iVar0 = 692; break;

	case 821579887: iVar0 = 693; break;

	case 1975948161: iVar0 = 694; break;

	case -953362234: iVar0 = 695; break;

	case 1521494915: iVar0 = 696; break;

	case 84635211: iVar0 = 697; break;

	case 2074655231: iVar0 = 698; break;

	case 1742494019: iVar0 = 699; break;
	}
	switch (iParam0) {
	case 1841934566: iVar0 = 700; break;

	case 1648222412: iVar0 = 701; break;

	case 1019312748: iVar0 = 702; break;

	case -1218730541: iVar0 = 703; break;

	case -88186884: iVar0 = 704; break;

	case 1428588096: iVar0 = 705; break;

	case -1788493673: iVar0 = 706; break;

	case -241894528: iVar0 = 707; break;

	case -1425414573: iVar0 = 708; break;

	case 1797163947: iVar0 = 709; break;

	case 823191231: iVar0 = 710; break;

	case 894133321: iVar0 = 711; break;

	case 1889485313: iVar0 = 712; break;
	}
	if (iVar0 != -1) {
		*iParam1 = 129 + iVar0;
		return true;
	}
	return false;
}

// Position - 0x6E4A
bool func_115(int iParam0, int *iParam1) {
	int iVar0;

	iVar0 = -1;
	switch (iParam0) {
	case -1917324065: iVar0 = 0; break;

	case 1056297333: iVar0 = 1; break;

	case 494620709: iVar0 = 2; break;

	case 800453786: iVar0 = 3; break;

	case -1082736975: iVar0 = 4; break;

	case -754981437: iVar0 = 5; break;

	case -1801855538: iVar0 = 6; break;

	case 459313194: iVar0 = 7; break;

	case 2007087579: iVar0 = 8; break;

	case 1987172386: iVar0 = 9; break;

	case 1801787829: iVar0 = 10; break;

	case -221624488: iVar0 = 11; break;

	case 25158851: iVar0 = 12; break;

	case 472458130: iVar0 = 13; break;

	case 164352862: iVar0 = 14; break;

	case -904148779: iVar0 = 15; break;

	case -694439771: iVar0 = 16; break;

	case -1469590466: iVar0 = 17; break;

	case -1511207100: iVar0 = 18; break;

	case -1352670678: iVar0 = 19; break;

	case -1960273476: iVar0 = 20; break;

	case -1657389609: iVar0 = 21; break;

	case 1826839858: iVar0 = 22; break;

	case 1989701788: iVar0 = 23; break;

	case 1213109257: iVar0 = 24; break;

	case 607407061: iVar0 = 25; break;

	case 875031480: iVar0 = 26; break;

	case 1487418552: iVar0 = 27; break;

	case 264053475: iVar0 = 28; break;

	case 99094329: iVar0 = 29; break;

	case -244193715: iVar0 = 30; break;

	case -540785934: iVar0 = 31; break;

	case -694833003: iVar0 = 32; break;

	case -852058665: iVar0 = 33; break;

	case -1512648940: iVar0 = 34; break;

	case -761354077: iVar0 = 35; break;

	case 1560551467: iVar0 = 36; break;

	case 827974775: iVar0 = 37; break;

	case 1595162603: iVar0 = 38; break;

	case 709663738: iVar0 = 39; break;

	case 990002533: iVar0 = 40; break;

	case 1860213958: iVar0 = 41; break;

	case 2119318441: iVar0 = 42; break;

	case -1953737187: iVar0 = 43; break;

	case 193320466: iVar0 = 44; break;

	case 1936646403: iVar0 = 45; break;

	case -1126042648: iVar0 = 46; break;

	case -1125022512: iVar0 = 47; break;

	case -1304369017: iVar0 = 48; break;

	case -2018143375: iVar0 = 49; break;

	case 224730392: iVar0 = 50; break;

	case 439629494: iVar0 = 51; break;

	case 736778786: iVar0 = 52; break;

	case 1048444745: iVar0 = 53; break;

	case 1988816738: iVar0 = 54; break;

	case 2140603469: iVar0 = 55; break;

	case 214245031: iVar0 = 56; break;

	case 1006238992: iVar0 = 57; break;

	case 689952604: iVar0 = 58; break;

	case -681528353: iVar0 = 59; break;

	case 1157448359: iVar0 = 60; break;

	case 43105745: iVar0 = 61; break;

	case -270395278: iVar0 = 62; break;

	case 505181414: iVar0 = 63; break;

	case 254662409: iVar0 = 64; break;

	case -982924414: iVar0 = 65; break;

	case -1156010272: iVar0 = 66; break;

	case 1885313391: iVar0 = 67; break;

	case -694786597: iVar0 = 68; break;

	case -1950199756: iVar0 = 69; break;

	case 384168721: iVar0 = 70; break;

	case -369452741: iVar0 = 71; break;

	case -89113946: iVar0 = 72; break;

	case 1836261422: iVar0 = 73; break;

	case -1004417654: iVar0 = 74; break;

	case -754095263: iVar0 = 75; break;

	case -1210698509: iVar0 = 76; break;

	case 1332405298: iVar0 = 77; break;

	case 552929095: iVar0 = 78; break;

	case 861154309: iVar0 = 79; break;

	case -1653801207: iVar0 = 80; break;

	case -87213624: iVar0 = 81; break;

	case 1285643631: iVar0 = 82; break;

	case 523240077: iVar0 = 83; break;

	case 823174734: iVar0 = 84; break;

	case -1248612522: iVar0 = 85; break;

	case 123359970: iVar0 = 86; break;

	case 369684543: iVar0 = 87; break;

	case -337142787: iVar0 = 88; break;

	case 1395583642: iVar0 = 89; break;

	case 1782520810: iVar0 = 90; break;

	case -660506451: iVar0 = 91; break;

	case -1092860637: iVar0 = 92; break;

	case 524387820: iVar0 = 93; break;

	case -1829180023: iVar0 = 94; break;

	case 2091368679: iVar0 = 95; break;

	case 1851597906: iVar0 = 96; break;

	case -434629734: iVar0 = 97; break;

	case 1415278623: iVar0 = 98; break;

	case 1252285617: iVar0 = 99; break;
	}
	switch (iParam0) {
	case 893595891: iVar0 = 100; break;

	case 423819507: iVar0 = 101; break;

	case -1433887872: iVar0 = 102; break;

	case -464613621: iVar0 = 103; break;

	case -301227387: iVar0 = 104; break;

	case -701762906: iVar0 = 105; break;

	case -890282963: iVar0 = 106; break;

	case -1188251480: iVar0 = 107; break;

	case 258827560: iVar0 = 108; break;

	case 965649655: iVar0 = 109; break;

	case 718800778: iVar0 = 110; break;

	case 1959959422: iVar0 = 111; break;

	case 1200177388: iVar0 = 112; break;

	case -1874439579: iVar0 = 113; break;

	case -1679505893: iVar0 = 114; break;

	case -1976229188: iVar0 = 115; break;

	case 2037875009: iVar0 = 116; break;

	case -235146664: iVar0 = 117; break;

	case -441853516: iVar0 = 118; break;

	case -664221443: iVar0 = 119; break;

	case -371627042: iVar0 = 120; break;

	case -1266220742: iVar0 = 121; break;

	case -968055611: iVar0 = 122; break;

	case 248100286: iVar0 = 123; break;

	case 551606764: iVar0 = 124; break;

	case 1805971315: iVar0 = 125; break;

	case -43642121: iVar0 = 126; break;

	case 1172251624: iVar0 = 127; break;

	case 1471989667: iVar0 = 128; break;

	case -2124702788: iVar0 = 129; break;

	case -1826734271: iVar0 = 130; break;

	case -900452940: iVar0 = 131; break;

	case -292194762: iVar0 = 132; break;

	case 637166847: iVar0 = 133; break;

	case -1204844181: iVar0 = 134; break;

	case 324779970: iVar0 = 135; break;

	case 329039940: iVar0 = 136; break;

	case 1854928425: iVar0 = 137; break;

	case 13179549: iVar0 = 138; break;

	case 1899823455: iVar0 = 139; break;

	case -2090490448: iVar0 = 140; break;

	case -1801467868: iVar0 = 141; break;

	case 953986562: iVar0 = 142; break;

	case 585335312: iVar0 = 143; break;

	case 489617063: iVar0 = 144; break;

	case 210195800: iVar0 = 145; break;

	case 1843402776: iVar0 = 146; break;

	case -1600520821: iVar0 = 147; break;

	case 1399087889: iVar0 = 148; break;

	case 1169344430: iVar0 = 149; break;

	case -2028647818: iVar0 = 150; break;

	case -1335845620: iVar0 = 151; break;

	case -1450406320: iVar0 = 152; break;

	case -1209849091: iVar0 = 153; break;

	case 2065609077: iVar0 = 154; break;

	case -664245241: iVar0 = 155; break;

	case 1676130538: iVar0 = 156; break;

	case -1730534702: iVar0 = 157; break;

	case -1767432596: iVar0 = 158; break;

	case -2016105604: iVar0 = 159; break;

	case 1971947238: iVar0 = 160; break;

	case -362811247: iVar0 = 161; break;

	case -668087251: iVar0 = 162; break;

	case -821282326: iVar0 = 163; break;

	case -1083467095: iVar0 = 164; break;

	case 550067555: iVar0 = 165; break;

	case 1439221609: iVar0 = 166; break;

	case 67412954: iVar0 = 167; break;

	case -1999360357: iVar0 = 168; break;

	case 1461537582: iVar0 = 169; break;

	case -1828273408: iVar0 = 170; break;

	case -1319239762: iVar0 = 171; break;

	case -1234400821: iVar0 = 172; break;

	case -992303449: iVar0 = 173; break;

	case -638398249: iVar0 = 174; break;

	case -41543683: iVar0 = 175; break;

	case -1934903018: iVar0 = 176; break;

	case 2132090345: iVar0 = 177; break;

	case 1751052413: iVar0 = 178; break;

	case 1519604966: iVar0 = 179; break;

	case -1964624525: iVar0 = 180; break;

	case 2006191823: iVar0 = 181; break;

	case 1633280603: iVar0 = 182; break;

	case 632918673: iVar0 = 183; break;

	case -190040148: iVar0 = 184; break;

	case 42936837: iVar0 = 185; break;

	case -1458541976: iVar0 = 186; break;

	case -606014753: iVar0 = 187; break;

	case -613376371: iVar0 = 188; break;

	case -446291501: iVar0 = 189; break;

	case 739308497: iVar0 = 190; break;

	case 495343292: iVar0 = 191; break;

	case -1686711653: iVar0 = 192; break;

	case 1187457341: iVar0 = 193; break;

	case 956403122: iVar0 = 194; break;

	case 1647042566: iVar0 = 195; break;

	case -461478743: iVar0 = 196; break;

	case -1883325653: iVar0 = 197; break;

	case -2114248796: iVar0 = 198; break;

	case 314228205: iVar0 = 199; break;
	}
	switch (iParam0) {
	case 1503775674: iVar0 = 200; break;

	case 1862399610: iVar0 = 201; break;

	case 708472048: iVar0 = 202; break;

	case -1207367545: iVar0 = 203; break;

	case 111650251: iVar0 = 204; break;

	case -28941494: iVar0 = 205; break;

	case -1827173138: iVar0 = 206; break;

	case -520681423: iVar0 = 207; break;

	case -209343154: iVar0 = 208; break;

	case -293579471: iVar0 = 209; break;

	case 20871853: iVar0 = 210; break;

	case -89823344: iVar0 = 211; break;

	case -1820191335: iVar0 = 212; break;

	case -1588547274: iVar0 = 213; break;

	case -1224287070: iVar0 = 214; break;

	case -994150383: iVar0 = 215; break;

	case -869824793: iVar0 = 216; break;

	case -633330920: iVar0 = 217; break;

	case -308131364: iVar0 = 218; break;

	case -38278649: iVar0 = 219; break;

	case 555692245: iVar0 = 220; break;

	case 929455459: iVar0 = 221; break;

	case -2092436411: iVar0 = 222; break;

	case 1904300216: iVar0 = 223; break;

	case -1599361268: iVar0 = 224; break;

	case -1897002095: iVar0 = 225; break;

	case -1011813098: iVar0 = 226; break;

	case -1316794181: iVar0 = 227; break;

	case -416105443: iVar0 = 228; break;

	case -47978497: iVar0 = 229; break;

	case -358202620: iVar0 = 230; break;

	case 547139312: iVar0 = 231; break;

	case 1124688073: iVar0 = 232; break;

	case 888521890: iVar0 = 233; break;

	case 665823766: iVar0 = 234; break;

	case 427888057: iVar0 = 235; break;

	case 1121411181: iVar0 = 236; break;

	case 890225886: iVar0 = 237; break;

	case 651012186: iVar0 = 238; break;

	case 422776101: iVar0 = 239; break;

	case 1630543134: iVar0 = 240; break;

	case -1945668916: iVar0 = 241; break;

	case -627999265: iVar0 = 242; break;

	case 1682346315: iVar0 = 243; break;

	case 1021952654: iVar0 = 244; break;

	case 1319396867: iVar0 = 245; break;

	case 560794517: iVar0 = 246; break;

	case 858697496: iVar0 = 247; break;

	case -30981230: iVar0 = 248; break;

	case -328032215: iVar0 = 249; break;

	case -1451681225: iVar0 = 250; break;

	case 267904819: iVar0 = 251; break;

	case 1570178485: iVar0 = 252; break;

	case -1619850916: iVar0 = 253; break;

	case -713067148: iVar0 = 254; break;

	case 946477614: iVar0 = 255; break;

	case -1423343701: iVar0 = 256; break;

	case 445931457: iVar0 = 257; break;

	case 678558588: iVar0 = 258; break;

	case -854631987: iVar0 = 259; break;

	case -1707871209: iVar0 = 260; break;

	case -863391184: iVar0 = 261; break;

	case 671171671: iVar0 = 262; break;

	case 904519720: iVar0 = 263; break;

	case 670952414: iVar0 = 264; break;

	case -282875325: iVar0 = 265; break;

	case 2079623104: iVar0 = 266; break;

	case 1088443427: iVar0 = 267; break;

	case 200001600: iVar0 = 268; break;

	case 1620729159: iVar0 = 269; break;

	case -1713274238: iVar0 = 270; break;

	case -1571590969: iVar0 = 271; break;

	case -457639374: iVar0 = 272; break;

	case 64160805: iVar0 = 273; break;

	case 1015325203: iVar0 = 274; break;

	case -1951778967: iVar0 = 275; break;

	case 1836042304: iVar0 = 276; break;

	case -421094621: iVar0 = 277; break;

	case 641062099: iVar0 = 278; break;

	case 597454468: iVar0 = 279; break;

	case 713758205: iVar0 = 280; break;

	case 1042267708: iVar0 = 281; break;

	case -637951661: iVar0 = 282; break;

	case 195911857: iVar0 = 283; break;

	case 903988957: iVar0 = 284; break;

	case 1068170761: iVar0 = 285; break;

	case -619065384: iVar0 = 286; break;

	case -497085955: iVar0 = 287; break;

	case 1138369002: iVar0 = 288; break;

	case -1957731308: iVar0 = 289; break;

	case -2063712125: iVar0 = 290; break;

	case 1773674262: iVar0 = 291; break;

	case 1027059614: iVar0 = 292; break;

	case 1366782677: iVar0 = 293; break;

	case 216134256: iVar0 = 294; break;

	case 810154442: iVar0 = 295; break;

	case 77285961: iVar0 = 296; break;

	case 1617489838: iVar0 = 297; break;

	case 1697138602: iVar0 = 298; break;

	case 711811694: iVar0 = 299; break;
	}
	switch (iParam0) {
	case -895106351: iVar0 = 300; break;

	case 875367934: iVar0 = 301; break;

	case -979867160: iVar0 = 302; break;

	case -1233816942: iVar0 = 303; break;

	case -866958715: iVar0 = 304; break;

	case -1303573005: iVar0 = 305; break;

	case 2085207152: iVar0 = 306; break;

	case 857137150: iVar0 = 307; break;

	case 535952639: iVar0 = 308; break;

	case -1974657401: iVar0 = 309; break;

	case 129909013: iVar0 = 310; break;

	case -1499060170: iVar0 = 311; break;

	case 412032123: iVar0 = 312; break;

	case 915049044: iVar0 = 313; break;

	case 456478679: iVar0 = 314; break;

	case 907364848: iVar0 = 315; break;

	case -1783721060: iVar0 = 316; break;

	case -1008363280: iVar0 = 317; break;

	case 1429817922: iVar0 = 318; break;

	case -938326281: iVar0 = 319; break;

	case -1073925235: iVar0 = 320; break;

	case 1498524677: iVar0 = 321; break;

	case 1525596308: iVar0 = 322; break;

	case 1232639216: iVar0 = 323; break;

	case 956061600: iVar0 = 324; break;

	case 816551665: iVar0 = 325; break;

	case 2049704410: iVar0 = 326; break;

	case -796818724: iVar0 = 327; break;

	case 1775476370: iVar0 = 328; break;

	case 266230635: iVar0 = 329; break;

	case -588549683: iVar0 = 330; break;

	case 464027076: iVar0 = 331; break;

	case 2122049260: iVar0 = 332; break;

	case 1049130700: iVar0 = 333; break;

	case -116952560: iVar0 = 334; break;

	case 1424723115: iVar0 = 335; break;

	case -1007272003: iVar0 = 336; break;

	case -644829701: iVar0 = 337; break;

	case -2103222497: iVar0 = 338; break;

	case -1589795073: iVar0 = 339; break;

	case -1689668067: iVar0 = 340; break;

	case -189814108: iVar0 = 341; break;

	case -1595292141: iVar0 = 342; break;

	case -1540940714: iVar0 = 343; break;

	case -2136471172: iVar0 = 344; break;

	case -666892434: iVar0 = 345; break;

	case -1001125323: iVar0 = 346; break;

	case 904104464: iVar0 = 347; break;

	case 690016265: iVar0 = 348; break;

	case 38190590: iVar0 = 349; break;

	case 2119761078: iVar0 = 350; break;

	case -1213131712: iVar0 = 351; break;

	case 990079224: iVar0 = 352; break;

	case -905045993: iVar0 = 353; break;

	case 2104378143: iVar0 = 354; break;

	case -666631800: iVar0 = 355; break;

	case 549954933: iVar0 = 356; break;

	case 1830069972: iVar0 = 357; break;

	case 859320876: iVar0 = 358; break;

	case -552358316: iVar0 = 359; break;

	case 1522216340: iVar0 = 360; break;

	case -1783296601: iVar0 = 361; break;

	case 283995288: iVar0 = 362; break;

	case -975534410: iVar0 = 363; break;

	case -2088194624: iVar0 = 364; break;

	case 1744801848: iVar0 = 365; break;

	case -481389646: iVar0 = 366; break;

	case -1781363036: iVar0 = 367; break;

	case 496009839: iVar0 = 368; break;

	case -667608820: iVar0 = 369; break;

	case 460475899: iVar0 = 370; break;

	case 1491168919: iVar0 = 371; break;

	case -1611478806: iVar0 = 372; break;

	case 523495612: iVar0 = 373; break;

	case -78008273: iVar0 = 374; break;

	case -762375847: iVar0 = 375; break;

	case 331482129: iVar0 = 376; break;

	case -2083628050: iVar0 = 377; break;

	case -468800117: iVar0 = 378; break;

	case 724819757: iVar0 = 379; break;

	case -1058761348: iVar0 = 380; break;

	case -546178212: iVar0 = 381; break;

	case -118052734: iVar0 = 382; break;

	case 1654466691: iVar0 = 383; break;

	case -1077553649: iVar0 = 384; break;

	case -886092159: iVar0 = 385; break;

	case -1406331536: iVar0 = 386; break;

	case -1968934850: iVar0 = 387; break;

	case 3741245: iVar0 = 388; break;

	case 1387838298: iVar0 = 389; break;

	case -1941058219: iVar0 = 390; break;

	case 955033120: iVar0 = 391; break;

	case 677119231: iVar0 = 392; break;

	case -1616214916: iVar0 = 393; break;

	case -841195297: iVar0 = 394; break;

	case -909289279: iVar0 = 395; break;

	case -239567341: iVar0 = 396; break;

	case -613592707: iVar0 = 397; break;

	case -988568374: iVar0 = 398; break;

	case -1090807654: iVar0 = 399; break;
	}
	switch (iParam0) {
	case 534771589: iVar0 = 400; break;

	case -1340139519: iVar0 = 401; break;

	case -849980761: iVar0 = 402; break;

	case -551553478: iVar0 = 403; break;

	case 386581472: iVar0 = 404; break;

	case 1466454525: iVar0 = 405; break;

	case 283190173: iVar0 = 406; break;

	case 1528527015: iVar0 = 407; break;

	case -1690029966: iVar0 = 408; break;

	case -1685994466: iVar0 = 409; break;

	case 255166927: iVar0 = 410; break;

	case -271257487: iVar0 = 411; break;

	case 1885215284: iVar0 = 412; break;

	case -1935156988: iVar0 = 413; break;

	case 1061465906: iVar0 = 414; break;

	case -871031729: iVar0 = 415; break;

	case -101171485: iVar0 = 416; break;

	case -1590298770: iVar0 = 417; break;

	case 303441856: iVar0 = 418; break;

	case -2049689650: iVar0 = 419; break;

	case 788520303: iVar0 = 420; break;

	case -859861445: iVar0 = 421; break;

	case 1045897298: iVar0 = 422; break;

	case 116964921: iVar0 = 423; break;

	case -1502257606: iVar0 = 424; break;

	case -546150284: iVar0 = 425; break;

	case -357466888: iVar0 = 426; break;

	case 718674880: iVar0 = 427; break;

	case -1529401172: iVar0 = 428; break;

	case 2088037441: iVar0 = 429; break;

	case 2048866271: iVar0 = 430; break;

	case -1565431690: iVar0 = 431; break;

	case -1528465573: iVar0 = 432; break;

	case 401532197: iVar0 = 433; break;

	case 826974918: iVar0 = 434; break;

	case -676067408: iVar0 = 435; break;

	case 1877289089: iVar0 = 436; break;

	case 859380017: iVar0 = 437; break;

	case 233098354: iVar0 = 438; break;

	case 566101858: iVar0 = 439; break;

	case 529460830: iVar0 = 440; break;

	case -1833118141: iVar0 = 441; break;

	case 422823598: iVar0 = 442; break;

	case 1450358661: iVar0 = 443; break;

	case 741089893: iVar0 = 444; break;

	case 1289848370: iVar0 = 445; break;

	case 616166430: iVar0 = 446; break;

	case 1489225316: iVar0 = 447; break;

	case 753969632: iVar0 = 448; break;

	case -1182831168: iVar0 = 449; break;

	case 1545103753: iVar0 = 450; break;

	case 2090080808: iVar0 = 451; break;

	case 903606896: iVar0 = 452; break;

	case 26759391: iVar0 = 453; break;

	case 1651885364: iVar0 = 454; break;

	case 729529407: iVar0 = 455; break;

	case 528802126: iVar0 = 456; break;

	case -1468003071: iVar0 = 457; break;

	case 1683696787: iVar0 = 458; break;

	case -726859160: iVar0 = 459; break;

	case 1209899578: iVar0 = 460; break;

	case 930604285: iVar0 = 461; break;

	case -308584186: iVar0 = 462; break;

	case -64129874: iVar0 = 463; break;

	case -1431204514: iVar0 = 464; break;

	case -1133334304: iVar0 = 465; break;

	case -1809784771: iVar0 = 466; break;

	case -1576934998: iVar0 = 467; break;

	case -1570929684: iVar0 = 468; break;

	case 1976578151: iVar0 = 469; break;

	case -441419962: iVar0 = 470; break;

	case -841238543: iVar0 = 471; break;

	case 1644315794: iVar0 = 472; break;

	case 1964334039: iVar0 = 473; break;

	case -1168614925: iVar0 = 474; break;

	case -56760095: iVar0 = 475; break;

	case -1006202521: iVar0 = 476; break;

	case -1834049539: iVar0 = 477; break;

	case -2060372580: iVar0 = 478; break;

	case 1057304170: iVar0 = 479; break;

	case 1421572640: iVar0 = 480; break;

	case 481259621: iVar0 = 481; break;

	case 1227497670: iVar0 = 482; break;

	case 319276780: iVar0 = 483; break;

	case 2070827921: iVar0 = 484; break;

	case 1433629991: iVar0 = 485; break;

	case -1712994650: iVar0 = 486; break;

	case 2125094286: iVar0 = 487; break;

	case 712298404: iVar0 = 488; break;

	case 1998072324: iVar0 = 489; break;

	case 1249206960: iVar0 = 490; break;

	case -621355603: iVar0 = 491; break;

	case 1570835960: iVar0 = 492; break;

	case -1254202543: iVar0 = 493; break;

	case -956136061: iVar0 = 494; break;

	case -1925480683: iVar0 = 495; break;

	case 220143168: iVar0 = 496; break;

	case -1021851577: iVar0 = 497; break;

	case -773345516: iVar0 = 498; break;

	case 1091795205: iVar0 = 499; break;
	}
	switch (iParam0) {
	case -1159824040: iVar0 = 500; break;

	case 1448723789: iVar0 = 501; break;

	case -488127340: iVar0 = 502; break;

	case -1964967283: iVar0 = 503; break;

	case -1635180127: iVar0 = 504; break;

	case -10501563: iVar0 = 505; break;

	case 933419071: iVar0 = 506; break;

	case 1362374839: iVar0 = 507; break;

	case 488078687: iVar0 = 508; break;

	case -1869054624: iVar0 = 509; break;

	case -1817642831: iVar0 = 510; break;

	case 482472119: iVar0 = 511; break;

	case -1736839817: iVar0 = 512; break;

	case 415527077: iVar0 = 513; break;

	case -907440189: iVar0 = 514; break;

	case -2099454789: iVar0 = 515; break;

	case -1719543542: iVar0 = 516; break;

	case 1848661824: iVar0 = 517; break;

	case -2018029706: iVar0 = 518; break;

	case -717212544: iVar0 = 519; break;

	case -594210450: iVar0 = 520; break;

	case 1520437442: iVar0 = 521; break;

	case 374349467: iVar0 = 522; break;

	case 1533123503: iVar0 = 523; break;

	case -1832780872: iVar0 = 524; break;

	case 130721536: iVar0 = 525; break;

	case 195356001: iVar0 = 526; break;

	case -556915722: iVar0 = 527; break;

	case -1930562696: iVar0 = 528; break;

	case 941227127: iVar0 = 529; break;

	case -842699589: iVar0 = 530; break;

	case 1654019571: iVar0 = 531; break;

	case 224191803: iVar0 = 532; break;

	case -1996796255: iVar0 = 533; break;

	case -1850715440: iVar0 = 534; break;

	case 1603163718: iVar0 = 535; break;

	case 1567227108: iVar0 = 536; break;

	case -1630649997: iVar0 = 537; break;

	case -25727072: iVar0 = 538; break;

	case -1363418653: iVar0 = 539; break;

	case 1878229535: iVar0 = 540; break;

	case 1531050226: iVar0 = 541; break;

	case 1246243345: iVar0 = 542; break;

	case 463561930: iVar0 = 543; break;

	case 1431846777: iVar0 = 544; break;

	case -460168116: iVar0 = 545; break;

	case -2015343582: iVar0 = 546; break;

	case 2051301469: iVar0 = 547; break;

	case 1887452986: iVar0 = 548; break;

	case -1551331969: iVar0 = 549; break;

	case 682382693: iVar0 = 550; break;

	case 765481743: iVar0 = 551; break;

	case 1094179010: iVar0 = 552; break;

	case 1906582382: iVar0 = 553; break;

	case 1923135102: iVar0 = 554; break;

	case -964908188: iVar0 = 555; break;

	case -1145896773: iVar0 = 556; break;

	case -776248682: iVar0 = 557; break;

	case 872613482: iVar0 = 558; break;

	case 1049060638: iVar0 = 559; break;

	case -927135334: iVar0 = 560; break;

	case -445820043: iVar0 = 561; break;

	case 1610045630: iVar0 = 562; break;

	case -1070800165: iVar0 = 563; break;

	case -589592162: iVar0 = 564; break;

	case 1723966869: iVar0 = 565; break;

	case 402539085: iVar0 = 566; break;

	case 873283678: iVar0 = 567; break;

	case -883161109: iVar0 = 568; break;

	case -1764919154: iVar0 = 569; break;

	case -2050352513: iVar0 = 570; break;

	case 1114188021: iVar0 = 571; break;

	case 1798282399: iVar0 = 572; break;

	case 1944820428: iVar0 = 573; break;

	case 100210893: iVar0 = 574; break;

	case -1699022511: iVar0 = 575; break;

	case 466917406: iVar0 = 576; break;

	case -349746245: iVar0 = 577; break;

	case 715904570: iVar0 = 578; break;

	case 281777035: iVar0 = 579; break;

	case 1511283406: iVar0 = 580; break;

	case -241337647: iVar0 = 581; break;

	case 748393780: iVar0 = 582; break;

	case 709511536: iVar0 = 583; break;

	case -652535466: iVar0 = 584; break;

	case -1148900842: iVar0 = 585; break;

	case -271863310: iVar0 = 586; break;

	case 35654857: iVar0 = 587; break;

	case 1894813304: iVar0 = 588; break;

	case 1184660438: iVar0 = 589; break;

	case -1461750963: iVar0 = 590; break;

	case 769964545: iVar0 = 591; break;

	case 1424500982: iVar0 = 592; break;

	case -1810785185: iVar0 = 593; break;

	case 837990279: iVar0 = 594; break;

	case -1357788003: iVar0 = 595; break;

	case -8210327: iVar0 = 596; break;

	case 1186553524: iVar0 = 597; break;

	case 1174934203: iVar0 = 598; break;

	case -984449089: iVar0 = 599; break;
	}
	switch (iParam0) {
	case -49570837: iVar0 = 600; break;

	case -1680371785: iVar0 = 601; break;

	case -1850912390: iVar0 = 602; break;

	case -1740038087: iVar0 = 603; break;

	case -619541947: iVar0 = 604; break;

	case 294240494: iVar0 = 605; break;

	case -765542196: iVar0 = 606; break;

	case -1420662645: iVar0 = 607; break;

	case 331918356: iVar0 = 608; break;

	case 204953755: iVar0 = 609; break;

	case 1764172461: iVar0 = 610; break;

	case 1462870109: iVar0 = 611; break;

	case -2071014467: iVar0 = 612; break;

	case 478439238: iVar0 = 613; break;

	case 796489219: iVar0 = 614; break;

	case 843279688: iVar0 = 615; break;

	case 1752551314: iVar0 = 616; break;

	case 735155845: iVar0 = 617; break;

	case 1863251462: iVar0 = 618; break;

	case -2142058763: iVar0 = 619; break;

	case -207591105: iVar0 = 620; break;

	case -932813887: iVar0 = 621; break;

	case -313503199: iVar0 = 622; break;

	case 718936417: iVar0 = 623; break;

	case -1107649605: iVar0 = 624; break;

	case 39090475: iVar0 = 625; break;

	case 1628251208: iVar0 = 626; break;

	case -311245907: iVar0 = 627; break;

	case -942031335: iVar0 = 628; break;

	case -1285040537: iVar0 = 629; break;

	case -606706891: iVar0 = 630; break;

	case -1719095858: iVar0 = 631; break;

	case 1725502681: iVar0 = 632; break;

	case 609583888: iVar0 = 633; break;

	case -1172383155: iVar0 = 634; break;

	case -3492404: iVar0 = 635; break;

	case -1006004645: iVar0 = 636; break;

	case -1937311482: iVar0 = 637; break;

	case -2065604094: iVar0 = 638; break;

	case 2028818254: iVar0 = 639; break;

	case 1624012067: iVar0 = 640; break;

	case -1877817141: iVar0 = 641; break;

	case -911576192: iVar0 = 642; break;

	case -2038013276: iVar0 = 643; break;

	case -901986542: iVar0 = 644; break;

	case 1792492176: iVar0 = 645; break;

	case -86485329: iVar0 = 646; break;

	case -1083434268: iVar0 = 647; break;

	case 613606704: iVar0 = 648; break;

	case -394853815: iVar0 = 649; break;

	case -1103127620: iVar0 = 650; break;

	case -1565650506: iVar0 = 651; break;

	case 1845793118: iVar0 = 652; break;

	case 105835401: iVar0 = 653; break;

	case 874268443: iVar0 = 654; break;

	case 2088424900: iVar0 = 655; break;

	case -786732051: iVar0 = 656; break;

	case 2054090970: iVar0 = 657; break;

	case 1878368697: iVar0 = 658; break;

	case 569662133: iVar0 = 659; break;

	case -792802958: iVar0 = 660; break;

	case 2006001399: iVar0 = 661; break;

	case 1785762805: iVar0 = 662; break;

	case 737220320: iVar0 = 663; break;

	case 1396060544: iVar0 = 664; break;

	case -1964728736: iVar0 = 665; break;

	case 1593302778: iVar0 = 666; break;

	case 84849272: iVar0 = 667; break;

	case -402776165: iVar0 = 668; break;

	case -221660734: iVar0 = 669; break;

	case 1648112645: iVar0 = 670; break;

	case 2066668749: iVar0 = 671; break;

	case -4424163: iVar0 = 672; break;

	case -173288591: iVar0 = 673; break;

	case 253771760: iVar0 = 674; break;

	case -1431574022: iVar0 = 675; break;

	case 959314664: iVar0 = 676; break;

	case 1670479428: iVar0 = 677; break;

	case 1779534675: iVar0 = 678; break;

	case -1268204471: iVar0 = 679; break;

	case -1937668252: iVar0 = 680; break;

	case -192802570: iVar0 = 681; break;

	case 1200380295: iVar0 = 682; break;

	case -644503216: iVar0 = 683; break;

	case 496410473: iVar0 = 684; break;

	case 462780886: iVar0 = 685; break;

	case 211198653: iVar0 = 686; break;

	case -504012739: iVar0 = 687; break;

	case 34276608: iVar0 = 688; break;

	case -2088223199: iVar0 = 689; break;

	case 2056773549: iVar0 = 690; break;

	case 962023066: iVar0 = 691; break;

	case 893288510: iVar0 = 692; break;

	case 1963590204: iVar0 = 693; break;

	case 919272855: iVar0 = 694; break;

	case 413754974: iVar0 = 695; break;

	case -1862916472: iVar0 = 696; break;

	case -1184732039: iVar0 = 697; break;

	case -143503455: iVar0 = 698; break;
	}
	if (iVar0 != -1) {
		*iParam1 = 129 + iVar0;
		return true;
	}
	return false;
}

// Position - 0x9602
int func_116(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;
	var uVar6;
	var uVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;

	if (iParam2 == -1) {
		iParam2 = func_93();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
		iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
		iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
		iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
		iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
		iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
		iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		uVar9 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2, "_NGTATPSTAT_BOOL");
		iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2, "_DLCBIKEPSTAT_BOOL");
		iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
	}
	return iVar0;
}

// Position - 0x9996
void func_117(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam4) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_92(iParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
}

// Position - 0x99C6
int func_118(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_92(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x99F8
void func_119(var *uParam0) {
	struct<16> Var0;
	int iVar16;

	if (Local_288.f_1 != -1) {
		if (!gameplay::is_bit_set(uParam0->f_2, 11)) {
			Var0 = {func_61(Local_366[Local_288.f_1 /*2*/])};
			iVar16 = func_121(Local_366[Local_288.f_1 /*2*/]);
			func_120(uParam0, "DCTL_WINNERV2", &Var0, 0, 1, iVar16);
			gameplay::set_bit(&uParam0->f_2, 11);
		}
	}
	else if (!gameplay::is_bit_set(uParam0->f_2, 11)) {
		func_49(uParam0, "DCTL_DRAW", 0, 1);
		gameplay::set_bit(&uParam0->f_2, 11);
	}
}

// Position - 0x9A7B
void func_120(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "SET_CENTRAL_MESSAGE");
		func_51(sParam1);
		graphics::_push_scaleform_movie_function_parameter_int(iParam3);
		graphics::_push_scaleform_movie_function_parameter_int(iParam4);
		func_50(sParam2);
		graphics::_push_scaleform_movie_function_parameter_int(iParam5);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x9ABC
int func_121(int iParam0) {
	switch (iParam0) {
	case 0: return 211;

	case 1: return 213;

	case 2: return 210;

	case 3: return 209;

	default:
	}
	return 0;
}

// Position - 0x9AF8
void func_122(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			uParam0->f_35[iVar0 /*79*/].f_8 = uParam0->f_35[iVar0 /*79*/].f_2;
			uParam0->f_35[iVar0 /*79*/].f_9 = uParam0->f_35[iVar0 /*79*/].f_2;
		}
		iVar0++;
	}
	func_153(uParam0);
	func_147(uParam0);
	func_145(uParam0);
	func_141(uParam0);
	func_140(uParam0);
	if (gameplay::is_bit_set(iLocal_219, 0)) {
		iVar0 = 0;
		while (iVar0 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
				Local_366[iVar0 /*2*/] > -1) {
				func_125(uParam0, &uParam0->f_35, iVar0);
				if (gameplay::is_bit_set(iLocal_219, 11 + iVar0)) {
					gameplay::clear_bit(&iLocal_219, 11 + iVar0);
				}
				if (gameplay::is_bit_set(iLocal_219, 7 + iVar0)) {
					gameplay::set_bit(&iLocal_219, 11 + iVar0);
					gameplay::clear_bit(&iLocal_219, 7 + iVar0);
				}
			}
			else if (uParam0->f_35[iVar0 /*79*/] == 2) {
				func_16(&uParam0->f_35, 3, iVar0);
				uParam0->f_35[iVar0 /*79*/].f_1 = 0;
			}
			iVar0++;
		}
		if (!func_12(&uLocal_221)) {
			func_10(&uLocal_221, 0, 0);
		}
		else if (func_8(&uLocal_221, 500, 0)) {
			iVar1 = network::network_get_num_participants();
			if (iVar1 == 1) {
				audio::play_sound_frontend(-1, "Music_Game_Over", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				func_180(uParam0, 10);
				return;
			}
			func_123(4, func_124(uParam0->f_35[iLocal_218 /*79*/].f_14, uParam0->f_35[iLocal_218 /*79*/].f_15, 9974),
					 iLocal_218, 99999);
			func_9(&uLocal_221);
		}
		if (!gameplay::is_bit_set(uParam0->f_2, 4) && uParam0->f_35[iLocal_218 /*79*/] == 2) {
			ui::display_help_text_this_frame("DCTL_GAMEHELP", 0);
			gameplay::set_bit(&uParam0->f_2, 5);
		}
		if (Local_288 >= 8) {
			audio::play_sound_frontend(-1, "Music_Win", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			iVar0 = 0;
			while (iVar0 <= 3) {
				audio::stop_sound(uParam0->f_35[iVar0 /*79*/].f_5);
				iVar0++;
			}
			if (audio::is_stream_playing()) {
				audio::stop_stream();
			}
			gameplay::clear_bit(&iLocal_219, 0);
			func_180(uParam0, 8);
		}
	}
	else if (iLocal_220 != -1 && network::_0x89023FBBF9200E9F() >= iLocal_220) {
		gameplay::set_bit(&iLocal_219, 0);
	}
}

// Position - 0x9D2B
void func_123(int iParam0, float fParam1, int iParam2, int iParam3) {
	struct<6> Var0;
	int iVar6;

	Var0.f_2 = -1;
	Var0.f_3 = -1082130432;
	Var0.f_4 = -1;
	Var0.f_5 = -1;
	Var0 = 559;
	Var0.f_1 = player::player_id();
	Var0.f_2 = iParam0;
	Var0.f_3 = fParam1;
	Var0.f_4 = iParam2;
	Var0.f_5 = iParam3;
	iVar6 = func_20(0);
	if (iVar6 != 0) {
		script::trigger_script_event(1, &Var0, 6, iVar6);
	}
}

// Position - 0x9D93
float func_124(float fParam0, float fParam1, int iParam2) {
	float fVar0;
	float fVar1;

	fVar0 = system::to_float(system::floor(fParam0 * IntToFloat(iParam2 - 1)));
	fVar1 = system::to_float(system::floor(fParam1 * IntToFloat(iParam2 - 1)));
	return fVar0 * IntToFloat(iParam2) + fVar1;
}

// Position - 0x9DC8
void func_125(var *uParam0, var *uParam1, int iParam2) {
	switch ((*uParam1)[iParam2 /*79*/]) {
	case 0:
		switch (iParam2) {
		case 0:
			(*uParam1)[iParam2 /*79*/].f_4 = 0;
			(*uParam1)[iParam2 /*79*/].f_1 = 255;
			(*uParam1)[iParam2 /*79*/].f_3 = 0;
			(*uParam1)[iParam2 /*79*/].f_9 = -1;
			func_139(Local_366[iParam2 /*2*/], &(*uParam1)[iParam2 /*79*/].f_2, &(*uParam1)[iParam2 /*79*/].f_14,
					 &(*uParam1)[iParam2 /*79*/].f_15, &(*uParam1)[iParam2 /*79*/].f_8);
			break;

		case 1:
			(*uParam1)[iParam2 /*79*/].f_4 = 0;
			(*uParam1)[iParam2 /*79*/].f_1 = 255;
			(*uParam1)[iParam2 /*79*/].f_3 = 0;
			(*uParam1)[iParam2 /*79*/].f_9 = -1;
			func_139(Local_366[iParam2 /*2*/], &(*uParam1)[iParam2 /*79*/].f_2, &(*uParam1)[iParam2 /*79*/].f_14,
					 &(*uParam1)[iParam2 /*79*/].f_15, &(*uParam1)[iParam2 /*79*/].f_8);
			break;

		case 2:
			(*uParam1)[iParam2 /*79*/].f_4 = 0;
			(*uParam1)[iParam2 /*79*/].f_1 = 255;
			(*uParam1)[iParam2 /*79*/].f_3 = 0;
			(*uParam1)[iParam2 /*79*/].f_9 = -1;
			func_139(Local_366[iParam2 /*2*/], &(*uParam1)[iParam2 /*79*/].f_2, &(*uParam1)[iParam2 /*79*/].f_14,
					 &(*uParam1)[iParam2 /*79*/].f_15, &(*uParam1)[iParam2 /*79*/].f_8);
			break;

		case 3:
			(*uParam1)[iParam2 /*79*/].f_4 = 0;
			(*uParam1)[iParam2 /*79*/].f_1 = 255;
			(*uParam1)[iParam2 /*79*/].f_3 = 0;
			(*uParam1)[iParam2 /*79*/].f_9 = -1;
			func_139(Local_366[iParam2 /*2*/], &(*uParam1)[iParam2 /*79*/].f_2, &(*uParam1)[iParam2 /*79*/].f_14,
					 &(*uParam1)[iParam2 /*79*/].f_15, &(*uParam1)[iParam2 /*79*/].f_8);
			break;
		}
		gameplay::clear_bit(&iLocal_219, 15 + iParam2);
		func_138(uParam1, iParam2);
		func_15(&(*uParam1)[iParam2 /*79*/].f_18);
		func_16(uParam1, 1, iParam2);
		break;

	case 1:
		if (Local_288 == 7) {
			func_16(uParam1, 2, iParam2);
		}
		break;

	case 2:
		if (iParam2 == iLocal_218) {
			if (!ui::is_pause_menu_active()) {
				func_137(uParam1);
			}
		}
		if (func_136(uParam0) <= 1) {
			(*uParam1)[iParam2 /*79*/].f_17 = 0f;
			(*uParam1)[iParam2 /*79*/].f_9 = (*uParam1)[iParam2 /*79*/].f_2;
		}
		if (!gameplay::is_bit_set(iLocal_219, 3 + iParam2)) {
			func_133(uParam0, uParam1, iParam2);
		}
		gameplay::clear_bit(&iLocal_219, 3 + iParam2);
		if (iParam2 == iLocal_218) {
			func_129(uParam0, uParam1, 1);
			if (func_128(uParam0, uParam1, iLocal_218)) {
				func_127(iLocal_218);
			}
		}
		else if (func_128(uParam0, uParam1, iParam2)) {
			(*uParam1)[iParam2 /*79*/].f_17 = 0f;
		}
		break;

	case 3: func_126(uParam1, iParam2); break;
	}
}

// Position - 0xA040
void func_126(var *uParam0, int iParam1) {
	float fVar0;

	fVar0 = system::to_float((*uParam0)[iParam1 /*79*/].f_1);
	fVar0 -= 300f * system::timestep();
	if (fVar0 < 0f) {
		fVar0 = 0f;
	}
	(*uParam0)[iParam1 /*79*/].f_1 = system::floor(fVar0);
}

// Position - 0xA07D
void func_127(int iParam0) {
	vector3 vVar0;
	int iVar3;

	vVar0.x = 560;
	vVar0.y = player::player_id();
	vVar0.z = iParam0;
	iVar3 = func_20(1);
	if (iVar3 != 0) {
		script::trigger_script_event(1, &vVar0, 3, iVar3);
	}
}

// Position - 0xA0B4
bool func_128(var *uParam0, var *uParam1, int iParam2) {
	float fVar0;
	float fVar1;

	fVar0 = 0.5f - (0.5f - (*uParam1)[iParam2 /*79*/].f_14) * uParam0->f_9;
	fVar1 = 0.0068f * uParam0->f_9;
	switch ((*uParam1)[iParam2 /*79*/].f_2) {
	case 0:
		if ((*uParam1)[iParam2 /*79*/].f_15 - 0.012f * 0.42f <= 0.229f) {
			return true;
		}
		break;

	case 1:
		if ((*uParam1)[iParam2 /*79*/].f_15 + 0.012f * 0.42f >= 0.851f) {
			return true;
		}
		break;

	case 2:
		if (fVar0 - fVar1 * 0.42f <= 0.5f - 0.339f * uParam0->f_9) {
			return true;
		}
		break;

	case 3:
		if (fVar0 + fVar1 * 0.42f >= 0.5f + 0.343f * uParam0->f_9) {
			return true;
		}
		break;
	}
	return false;
}

// Position - 0xA19D
void func_129(var *uParam0, var *uParam1, int iParam2) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;
	float fVar14;
	float fVar15;
	float fVar16;
	float fVar17;
	float fVar18;
	float fVar19;
	int iVar20;
	int iVar21;
	int iVar22;
	int iVar23;
	float fVar24;
	float fVar25;
	bool bVar26;
	float fVar27;

	fVar0 = 0.5f - (0.5f - (*uParam1)[iLocal_218 /*79*/].f_14) * uParam0->f_9;
	fVar1 = 0.0068f * uParam0->f_9;
	iVar20 = (*uParam1)[iLocal_218 /*79*/].f_4 - 1;
	if (iVar20 > -1 && iVar20 < 59) {
		func_132((*uParam1)[iLocal_218 /*79*/].f_18[iVar20], &fVar12, &fVar13, 9974);
		if ((*uParam1)[iLocal_218 /*79*/].f_2 == 2) {
			fVar14 = (*uParam1)[iLocal_218 /*79*/].f_14 + fVar1 * 0.5f;
			fVar15 = (*uParam1)[iLocal_218 /*79*/].f_15;
			if (fVar14 > fVar12) {
				fVar14 = fVar12;
			}
		}
		else if ((*uParam1)[iLocal_218 /*79*/].f_2 == 3) {
			fVar14 = (*uParam1)[iLocal_218 /*79*/].f_14 - fVar1 * 0.5f;
			fVar15 = (*uParam1)[iLocal_218 /*79*/].f_15;
			if (fVar14 < fVar12) {
				fVar14 = fVar12;
			}
		}
		else if ((*uParam1)[iLocal_218 /*79*/].f_2 == 0) {
			fVar14 = (*uParam1)[iLocal_218 /*79*/].f_14;
			fVar15 = (*uParam1)[iLocal_218 /*79*/].f_15 + 0.012f * 0.5f;
			if (fVar15 > fVar13) {
				fVar15 = fVar13;
			}
		}
		else if ((*uParam1)[iLocal_218 /*79*/].f_2 == 1) {
			fVar14 = (*uParam1)[iLocal_218 /*79*/].f_14;
			fVar15 = (*uParam1)[iLocal_218 /*79*/].f_15 - 0.012f * 0.5f;
			if (fVar15 < fVar13) {
				fVar15 = fVar13;
			}
		}
	}
	iVar21 = 0;
	while (iVar21 <= 3) {
		iVar23 = 0;
		if (iVar21 == iLocal_218) {
		}
		else if ((*uParam1)[iVar21 /*79*/] == 2 && (*uParam1)[iLocal_218 /*79*/] == 2) {
			iVar22 = 0;
			while (iVar22 <= 59) {
				func_132((*uParam1)[iVar21 /*79*/].f_18[iVar22], &fVar2, &fVar3, 9974);
				if (fVar2 != 0f || fVar3 != 0f) {
					if (iVar22 + 1 >= 60) {
						fVar4 = (*uParam1)[iVar21 /*79*/].f_14;
						fVar5 = (*uParam1)[iVar21 /*79*/].f_15;
					}
					else {
						func_132((*uParam1)[iVar21 /*79*/].f_18[iVar22 + 1], &fVar4, &fVar5, 9974);
						if (fVar4 == 0f && fVar5 == 0f) {
							fVar4 = (*uParam1)[iVar21 /*79*/].f_14;
							fVar5 = (*uParam1)[iVar21 /*79*/].f_15;
						}
					}
					fVar6 = fVar4 - fVar2;
					fVar7 = fVar5 - fVar3;
					fVar8 = fVar2 + fVar6 * 0.5f;
					fVar9 = fVar3 + fVar7 * 0.5f;
					if (gameplay::absf(fVar6) > 0.001f) {
						fVar10 = gameplay::absf(fVar6) + 0.003f * 0.5f;
						fVar11 = 0.003f * uParam0->f_8;
					}
					else if (gameplay::absf(fVar7) > 0.001f) {
						fVar10 = 0.003f;
						fVar11 = gameplay::absf(fVar7) + 0.003f * 0.5f * uParam0->f_8;
					}
					else {
						fVar10 = 0.0001f;
						fVar11 = 0.0001f;
					}
					fVar24 = 0.5f - (0.5f - fVar8) * uParam0->f_9;
					fVar25 = fVar10 * uParam0->f_9;
					bVar26 = false;
					if ((*uParam1)[iLocal_218 /*79*/].f_2 == 2 || (*uParam1)[iLocal_218 /*79*/].f_2 == 3) {
						bVar26 = func_131(fVar0, (*uParam1)[iLocal_218 /*79*/].f_15, fVar1 * 0.42f, 0.012f * 0.42f,
										  fVar24, fVar9, fVar25 * 0.95f, fVar11);
					}
					if ((*uParam1)[iLocal_218 /*79*/].f_2 == 0 || (*uParam1)[iLocal_218 /*79*/].f_2 == 1) {
						bVar26 = func_131(fVar0, (*uParam1)[iLocal_218 /*79*/].f_15, fVar1 * 0.42f, 0.012f * 0.42f,
										  fVar24, fVar9, fVar25, fVar11 * 0.95f);
					}
					if (bVar26) {
						if (iParam2) {
							func_127(iLocal_218);
						}
						iVar23 = 1;
					}
					else if (!gameplay::is_bit_set(iLocal_219, 7 + iVar21) &&
							 gameplay::is_bit_set(iLocal_219, 11 + iVar21)) {
						if (iVar22 == (*uParam1)[iVar21 /*79*/].f_4 - 1) {
							if (fVar12 != 0f && fVar13 != 0f && fVar14 != 0f && fVar15 != 0f) {
								func_130(uParam0, fVar12, fVar13, fVar14, fVar15, &fVar16, &fVar17, &fVar18, &fVar19,
										 0.0015f);
								if (func_131(fVar24, fVar9, fVar25, fVar11, fVar16, fVar17, fVar18, fVar19)) {
									if (iParam2) {
										func_127(iLocal_218);
									}
									iVar23 = 1;
								}
							}
						}
					}
				}
				iVar22++;
			}
			if (!iVar23) {
				fVar27 = 0.5f - (0.5f - (*uParam1)[iVar21 /*79*/].f_14) * uParam0->f_9;
				if (func_131(fVar0, (*uParam1)[iLocal_218 /*79*/].f_15, fVar1 * 0.42f, 0.012f * 0.42f, fVar27,
							 (*uParam1)[iVar21 /*79*/].f_15, fVar1 * 0.42f, 0.012f * 0.42f)) {
					if (iParam2) {
						func_127(iLocal_218);
					}
				}
			}
		}
		iVar21++;
	}
}

// Position - 0xA61B
void func_130(var *uParam0, float fParam1, float fParam2, float fParam3, float fParam4, float *fParam5, float *fParam6,
			  float *fParam7, float *fParam8, float fParam9) {
	float fVar0;
	float fVar1;

	if (fParam9 == 0f) {
		fParam9 = 0.003f;
	}
	fVar0 = fParam3 - fParam1;
	fVar1 = fParam4 - fParam2;
	*fParam5 = fParam1 + fVar0 * 0.5f;
	*fParam6 = fParam2 + fVar1 * 0.5f;
	if (gameplay::absf(fVar0) > 0.001f) {
		*fParam7 = gameplay::absf(fVar0) + fParam9 * 0.5f;
		*fParam8 = fParam9 * uParam0->f_8;
	}
	else {
		*fParam7 = fParam9;
		*fParam8 = gameplay::absf(fVar1) + fParam9 * 0.5f * uParam0->f_8;
	}
	*fParam5 = 0.5f - (0.5f - *fParam5) * uParam0->f_9;
	*fParam7 *= uParam0->f_9;
}

// Position - 0xA6C7
bool func_131(float fParam0, float fParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  float fParam7) {
	if (fParam0 + fParam2 * 0.5f < fParam4 - fParam6 * 0.5f) {
		return false;
	}
	if (fParam4 + fParam6 * 0.5f < fParam0 - fParam2 * 0.5f) {
		return false;
	}
	if (fParam1 + fParam3 * 0.5f < fParam5 - fParam7 * 0.5f) {
		return false;
	}
	if (fParam5 + fParam7 * 0.5f < fParam1 - fParam3 * 0.5f) {
		return false;
	}
	return true;
}

// Position - 0xA748
void func_132(float fParam0, float *fParam1, float *fParam2, int iParam3) {
	*fParam1 = system::to_float(system::floor(fParam0 / IntToFloat(iParam3)));
	*fParam2 = fParam0 % IntToFloat(iParam3);
	*fParam1 /= IntToFloat(iParam3 - 1);
	*fParam2 /= IntToFloat(iParam3 - 1);
}

// Position - 0xA782
void func_133(var *uParam0, var *uParam1, int iParam2) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;

	if (network::network_is_participant_active(player::int_to_participantindex(iParam2)) &&
		(*uParam1)[iParam2 /*79*/] == 2) {
		if (audio::has_sound_finished((*uParam1)[iParam2 /*79*/].f_5)) {
			if (Local_366[iParam2 /*2*/] == 0) {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_5, "Trail_1", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			}
			else if (Local_366[iParam2 /*2*/] == 1) {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_5, "Trail_2", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			}
			else if (Local_366[iParam2 /*2*/] == 2) {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_5, "Trail_3", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			}
			else {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_5, "Trail_4", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			}
		}
		if (!audio::has_sound_finished((*uParam1)[iParam2 /*79*/].f_5)) {
			audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_5, "X", (*uParam1)[iParam2 /*79*/].f_14);
			audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_5, "Y", (*uParam1)[iParam2 /*79*/].f_15);
		}
	}
	if ((*uParam1)[iParam2 /*79*/].f_9 != (*uParam1)[iParam2 /*79*/].f_2 && (*uParam1)[iParam2 /*79*/].f_4 > 0) {
		func_132((*uParam1)[iParam2 /*79*/].f_18[(*uParam1)[iParam2 /*79*/].f_4 - 1], &fVar0, &fVar1, 9974);
		fVar4 = 0.2f;
		if ((*uParam1)[iParam2 /*79*/].f_9 == 0 && (*uParam1)[iParam2 /*79*/].f_10[1] == 1 ||
			(*uParam1)[iParam2 /*79*/].f_9 == 1 && (*uParam1)[iParam2 /*79*/].f_10[1] == 0 ||
			(*uParam1)[iParam2 /*79*/].f_9 == 2 && (*uParam1)[iParam2 /*79*/].f_10[1] == 3 ||
			(*uParam1)[iParam2 /*79*/].f_9 == 3 && (*uParam1)[iParam2 /*79*/].f_10[1] == 2) {
			fVar4 = 0.25f;
		}
		if ((*uParam1)[iParam2 /*79*/].f_9 == 0 || (*uParam1)[iParam2 /*79*/].f_9 == 1) {
			fVar2 = gameplay::absf((*uParam1)[iParam2 /*79*/].f_14 - fVar0);
			fVar3 = 0.0068f * uParam0->f_8 * fVar4;
		}
		else if ((*uParam1)[iParam2 /*79*/].f_9 == 2 || (*uParam1)[iParam2 /*79*/].f_9 == 3) {
			fVar2 = gameplay::absf((*uParam1)[iParam2 /*79*/].f_15 - fVar1);
			fVar3 = 0.0068f * uParam0->f_8 * fVar4 * uParam0->f_8;
		}
		if (fVar2 >= fVar3 || iParam2 != iLocal_218 && !gameplay::is_bit_set(iLocal_219, 15 + iParam2)) {
			if (iParam2 == iLocal_218) {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_7, "Turn", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				func_123((*uParam1)[iParam2 /*79*/].f_9,
						 func_124((*uParam1)[iParam2 /*79*/].f_14, (*uParam1)[iParam2 /*79*/].f_15, 9974), iLocal_218,
						 uLocal_213[iLocal_218]);
				func_9(&uLocal_221);
				uLocal_213[iLocal_218]++;
			}
			else {
				audio::play_sound_frontend((*uParam1)[iParam2 /*79*/].f_7, "Turn_NPC", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			}
			audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_7, "X", (*uParam1)[iParam2 /*79*/].f_14);
			audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_7, "Y", (*uParam1)[iParam2 /*79*/].f_15);
			if (!audio::has_sound_finished((*uParam1)[iParam2 /*79*/].f_5)) {
				audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_5, "Turning", 1f);
			}
			(*uParam1)[iParam2 /*79*/].f_2 = (*uParam1)[iParam2 /*79*/].f_9;
			(*uParam1)[iParam2 /*79*/].f_10[1] = (*uParam1)[iParam2 /*79*/].f_10[0];
			(*uParam1)[iParam2 /*79*/].f_10[0] = (*uParam1)[iParam2 /*79*/].f_2;
			(*uParam1)[iParam2 /*79*/].f_13 = gameplay::get_game_timer();
		}
	}
	else if (!audio::has_sound_finished((*uParam1)[iParam2 /*79*/].f_5)) {
		audio::set_variable_on_sound((*uParam1)[iParam2 /*79*/].f_5, "Turning", 0f);
	}
	func_135(uParam0, iParam2);
	func_134(uParam0, uParam1, iParam2);
	func_138(uParam1, iParam2);
	gameplay::set_bit(&iLocal_219, 3 + iParam2);
}

// Position - 0xAB37
void func_134(var *uParam0, var *uParam1, int iParam2) {
	float fVar0;
	float fVar1;

	fVar0 = 0.06f * (*uParam1)[iParam2 /*79*/].f_17;
	fVar1 = 0.06f * (*uParam1)[iParam2 /*79*/].f_17 * uParam0->f_8;
	switch ((*uParam1)[iParam2 /*79*/].f_2) {
	case 0: (*uParam1)[iParam2 /*79*/].f_15 -= fVar1 * system::timestep(); break;

	case 1: (*uParam1)[iParam2 /*79*/].f_15 += fVar1 * system::timestep(); break;

	case 2: (*uParam1)[iParam2 /*79*/].f_14 -= fVar0 * system::timestep(); break;

	case 3: (*uParam1)[iParam2 /*79*/].f_14 += fVar0 * system::timestep(); break;
	}
	(*uParam1)[iParam2 /*79*/].f_17 = 1f;
}

// Position - 0xABFE
void func_135(var *uParam0, int iParam1) {
	int iVar0;
	float fVar1;
	float fVar2;

	if (uParam0->f_35[iParam1 /*79*/].f_4 == 0) {
		uParam0->f_35[iParam1 /*79*/].f_18[uParam0->f_35[iParam1 /*79*/].f_4] =
			func_124(uParam0->f_35[iParam1 /*79*/].f_14, uParam0->f_35[iParam1 /*79*/].f_15, 9974);
		uParam0->f_35[iParam1 /*79*/].f_4++;
	}
	if (uParam0->f_35[iParam1 /*79*/].f_2 != uParam0->f_35[iParam1 /*79*/].f_8) {
		if (uParam0->f_35[iParam1 /*79*/].f_4 >= 60) {
			iVar0 = 0;
			while (iVar0 <= 59) {
				if (iVar0 == 59) {
					uParam0->f_35[iParam1 /*79*/].f_18[iVar0] =
						func_124(uParam0->f_35[iParam1 /*79*/].f_14, uParam0->f_35[iParam1 /*79*/].f_15, 9974);
				}
				else {
					fVar1 = 0f;
					fVar2 = 0f;
					func_132(uParam0->f_35[iParam1 /*79*/].f_18[iVar0 + 1], &fVar1, &fVar2, 9974);
					uParam0->f_35[iParam1 /*79*/].f_18[iVar0] = func_124(fVar1, fVar2, 9974);
				}
				iVar0++;
			}
		}
		else {
			uParam0->f_35[iParam1 /*79*/].f_18[uParam0->f_35[iParam1 /*79*/].f_4] =
				func_124(uParam0->f_35[iParam1 /*79*/].f_14, uParam0->f_35[iParam1 /*79*/].f_15, 9974);
			uParam0->f_35[iParam1 /*79*/].f_4++;
		}
		uParam0->f_35[iParam1 /*79*/].f_8 = uParam0->f_35[iParam1 /*79*/].f_2;
	}
}

// Position - 0xAD5F
int func_136(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar1 = 0;
	while (iVar1 <= network::_network_get_num_participants_host() - 1) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar1)) &&
			Local_366[iVar1 /*2*/] > -1) {
			if (uParam0->f_35[iVar1 /*79*/] != 3) {
				iVar0++;
			}
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0xADB3
void func_137(var *uParam0) {
	float fVar0;
	float fVar1;

	if ((*uParam0)[iLocal_218 /*79*/].f_9 < 0) {
		(*uParam0)[iLocal_218 /*79*/].f_9 = (*uParam0)[iLocal_218 /*79*/].f_2;
	}
	if (gameplay::get_game_timer() - (*uParam0)[iLocal_218 /*79*/].f_13 >= 66) {
		fVar0 = controls::get_control_normal(2, 218);
		fVar1 = controls::get_control_normal(2, 219);
		if (fVar1 < -0.65f || controls::is_control_pressed(2, 188)) {
			if ((*uParam0)[iLocal_218 /*79*/].f_2 != 1) {
				(*uParam0)[iLocal_218 /*79*/].f_9 = 0;
			}
		}
		if (fVar1 > 0.65f || controls::is_control_pressed(2, 187)) {
			if ((*uParam0)[iLocal_218 /*79*/].f_2 != 0) {
				(*uParam0)[iLocal_218 /*79*/].f_9 = 1;
			}
		}
		if (fVar0 < -0.65f || controls::is_control_pressed(2, 189)) {
			if ((*uParam0)[iLocal_218 /*79*/].f_2 != 3) {
				(*uParam0)[iLocal_218 /*79*/].f_9 = 2;
			}
		}
		if (fVar0 > 0.65f || controls::is_control_pressed(2, 190)) {
			if ((*uParam0)[iLocal_218 /*79*/].f_2 != 2) {
				(*uParam0)[iLocal_218 /*79*/].f_9 = 3;
			}
		}
	}
}

// Position - 0xAEAF
void func_138(var *uParam0, int iParam1) {
	switch ((*uParam0)[iParam1 /*79*/].f_2) {
	case 0: (*uParam0)[iParam1 /*79*/].f_16 = 0f; break;

	case 1: (*uParam0)[iParam1 /*79*/].f_16 = 180f; break;

	case 2: (*uParam0)[iParam1 /*79*/].f_16 = 270f; break;

	case 3: (*uParam0)[iParam1 /*79*/].f_16 = 90f; break;
	}
}

// Position - 0xAF18
void func_139(int iParam0, int *iParam1, float *fParam2, float *fParam3, int *iParam4) {
	switch (iParam0) {
	case 0:
		*fParam2 = 0.5f + -0.32f;
		*fParam3 = 0.54f;
		*iParam1 = 3;
		*iParam4 = 3;
		break;

	case 1:
		*fParam2 = 0.5f + 0.321f;
		*fParam3 = 0.54f;
		*iParam1 = 2;
		*iParam4 = 2;
		break;

	case 2:
		*fParam2 = 0.5f + 0f;
		*fParam3 = 0.26f;
		*iParam1 = 1;
		*iParam4 = 1;
		break;

	case 3:
		*fParam2 = 0.5f + 0f;
		*fParam3 = 0.822f;
		*iParam1 = 0;
		*iParam4 = 0;
		break;
	}
}

// Position - 0xAFBB
void func_140(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 <= 3) {
		if (uParam0->f_35[iVar0 /*79*/] == 2) {
			iVar1++;
		}
		iVar0++;
	}
	if (*uParam0 < 7) {
		audio::load_stream("Music_Stream", "DLC_EXEC_ARC_MAC_SOUNDS");
	}
	else if (iVar1 > 1) {
		if (!gameplay::is_bit_set(uParam0->f_2, 3)) {
			audio::play_stream_frontend();
			gameplay::set_bit(&uParam0->f_2, 3);
		}
	}
	else if (audio::is_stream_playing()) {
		audio::stop_stream();
	}
}

// Position - 0xB02E
void func_141(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 15)) {
		func_142(uParam0);
		gameplay::set_bit(&uParam0->f_2, 15);
	}
	func_73(uParam0);
}

// Position - 0xB05A
void func_142(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "SHOW_HUD");
		func_143(0);
		func_143(1);
		func_143(2);
		func_143(3);
		if (iLocal_218 > -1 && Local_366[iLocal_218 /*2*/] > -1) {
			graphics::_push_scaleform_movie_function_parameter_int(Local_366[iLocal_218 /*2*/]);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xB0B2
void func_143(int iParam0) {
	struct<16> Var0;
	struct<16> Var16;
	int iVar32;

	Var0 = {func_61(iParam0)};
	Var16 = {func_59(iParam0)};
	iVar32 = func_144(iParam0);
	graphics::_push_scaleform_movie_function_parameter_int(iVar32);
	graphics::_push_scaleform_movie_function_parameter_string(&Var16);
	func_50(&Var0);
}

// Position - 0xB0EA
int func_144(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] == iParam0) {
			return Local_288.f_7[iVar0];
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xB12D
void func_145(var *uParam0) {
	if (!func_8(&uParam0->f_20, 1000, 0)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 10)) {
			func_49(uParam0, "DCTL_COUNTDOWNGO", 0, 0);
			gameplay::set_bit(&uParam0->f_2, 10);
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_2, 10)) {
		func_146(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 10);
	}
}

// Position - 0xB189
void func_146(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "CLEAR_CENTRAL_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xB1AD
void func_147(var *uParam0) {
	int iVar0;

	func_52(uParam0);
	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			if (uParam0->f_35[iVar0 /*79*/].f_1 != 0) {
				func_148(uParam0, &uParam0->f_35, iVar0);
			}
		}
		iVar0++;
	}
}

// Position - 0xB207
void func_148(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	float fVar4;
	int iVar5;
	int iVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;
	float fVar14;
	float fVar15;
	float fVar16;
	float fVar17;
	float fVar18;
	float fVar19;
	bool bVar20;
	int iVar21;

	func_149(Local_366[iParam2 /*2*/], &iVar0, &iVar1, &iVar2);
	if ((*uParam1)[iParam2 /*79*/] == 3) {
		iVar0 = 255;
		iVar1 = 255;
		iVar2 = 255;
	}
	fVar3 = 0.5f - (0.5f - (*uParam1)[iParam2 /*79*/].f_14) * uParam0->f_9;
	fVar4 = 0.0068f * uParam0->f_9;
	iVar5 = 0;
	iVar5 = 0;
	while (iVar5 < 60) {
		func_132((*uParam1)[iParam2 /*79*/].f_18[iVar5], &fVar7, &fVar8, 9974);
		if (fVar7 != 0f || fVar8 != 0f) {
			if (iVar5 + 1 >= 60) {
				fVar9 = (*uParam1)[iParam2 /*79*/].f_14;
				fVar10 = (*uParam1)[iParam2 /*79*/].f_15;
			}
			else {
				func_132((*uParam1)[iParam2 /*79*/].f_18[iVar5 + 1], &fVar9, &fVar10, 9974);
				if (fVar9 == 0f && fVar10 == 0f) {
					fVar9 = (*uParam1)[iParam2 /*79*/].f_14;
					fVar10 = (*uParam1)[iParam2 /*79*/].f_15;
				}
			}
			fVar11 = fVar9 - fVar7;
			fVar12 = fVar10 - fVar8;
			fVar13 = fVar7 + fVar11 * 0.5f;
			fVar14 = fVar8 + fVar12 * 0.5f;
			if (gameplay::absf(fVar11) > 0.001f) {
				if (fVar11 > 0f) {
					iVar6 = 3;
				}
				else {
					iVar6 = 2;
				}
				fVar15 = 90f;
				fVar16 = gameplay::absf(fVar11) + 0.003f;
				fVar17 = 0.003f * uParam0->f_8;
			}
			if (gameplay::absf(fVar12) > 0.001f) {
				if (fVar12 > 0f) {
					iVar6 = 1;
				}
				else {
					iVar6 = 0;
				}
				fVar15 = 0f;
				fVar16 = 0.003f;
				fVar17 = gameplay::absf(fVar12) + 0.003f * 0.5f * uParam0->f_8;
			}
			fVar18 = 0.5f - (0.5f - fVar13) * uParam0->f_9;
			fVar19 = fVar16 * uParam0->f_9;
			graphics::draw_sprite("LineArcadeMinigame", "Tail", fVar18, fVar14, fVar19, fVar17, fVar15, iVar0, iVar1,
								  iVar2, (*uParam1)[iParam2 /*79*/].f_1, 0);
			if (iParam2 == iLocal_218) {
				if ((*uParam1)[iParam2 /*79*/] == 2) {
					bVar20 = false;
					if ((*uParam1)[iParam2 /*79*/].f_2 == 2 || (*uParam1)[iParam2 /*79*/].f_2 == 3) {
						bVar20 = func_131(fVar3, (*uParam1)[iParam2 /*79*/].f_15, fVar4 * 0.42f, 0.012f * 0.42f, fVar18,
										  fVar14, fVar19 * 0.95f, fVar17);
					}
					if ((*uParam1)[iParam2 /*79*/].f_2 == 0 || (*uParam1)[iParam2 /*79*/].f_2 == 1) {
						bVar20 = func_131(fVar3, (*uParam1)[iParam2 /*79*/].f_15, fVar4 * 0.42f, 0.012f * 0.42f, fVar18,
										  fVar14, fVar19, fVar17 * 0.95f);
					}
					if (bVar20) {
						iVar21 = 0;
						if (iVar5 == (*uParam1)[iParam2 /*79*/].f_4 - 3) {
							if (iVar6 == (*uParam1)[iParam2 /*79*/].f_2) {
								iVar21 = 1;
							}
						}
						if (iVar5 < (*uParam1)[iParam2 /*79*/].f_4 - 2 && !iVar21) {
							func_127(iParam2);
						}
					}
				}
			}
			fVar15 = 0f;
			fVar16 = 0f;
			fVar17 = 0f;
		}
		iVar5++;
	}
	graphics::draw_sprite("LineArcadeMinigame", "HeadPixel", fVar3, (*uParam1)[iParam2 /*79*/].f_15, fVar4, 0.012f,
						  (*uParam1)[iParam2 /*79*/].f_16, iVar0, iVar1, iVar2, (*uParam1)[iParam2 /*79*/].f_1, 0);
}

// Position - 0xB513
void func_149(int iParam0, var *uParam1, var *uParam2, var *uParam3) {
	var *uVar0;

	func_150(func_151(func_121(iParam0)), uParam1, uParam2, uParam3, &uVar0);
}

// Position - 0xB531
void func_150(var uParam0, var *uParam1, var *uParam2, var *uParam3, var *uParam4) {
	*uParam1 = gameplay::get_bits_in_range(uParam0, 24, 31);
	*uParam2 = gameplay::get_bits_in_range(uParam0, 16, 23);
	*uParam3 = gameplay::get_bits_in_range(uParam0, 8, 15);
	*uParam4 = gameplay::get_bits_in_range(uParam0, 0, 7);
}

// Position - 0xB568
var func_151(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(iParam0, &iVar0, &iVar1, &iVar2, &iVar3);
	return func_152(iVar0, iVar1, iVar2, iVar3);
}

// Position - 0xB58A
var func_152(int iParam0, int iParam1, int iParam2, int iParam3) {
	var uVar0;

	gameplay::set_bits_in_range(&uVar0, 24, 31, iParam0);
	gameplay::set_bits_in_range(&uVar0, 16, 23, iParam1);
	gameplay::set_bits_in_range(&uVar0, 8, 15, iParam2);
	gameplay::set_bits_in_range(&uVar0, 0, 7, iParam3);
	return uVar0;
}

// Position - 0xB5BF
void func_153(var *uParam0) {
	int iVar0;
	struct<6> Var1;
	vector3 vVar7;
	vector3 vVar10;
	struct<6> Var13;
	int iVar206;
	int *iVar207;
	float fVar208;
	float fVar209;
	int iVar210;
	int iVar211;
	struct<6> Var212;
	int iVar218;
	float fVar219;
	float fVar220;
	float fVar221;
	float fVar222;
	int iVar223;
	int *iVar224;
	int *iVar225;

	Var1.f_2 = -1;
	Var1.f_3 = -1082130432;
	Var1.f_4 = -1;
	Var1.f_5 = -1;
	Var13 = 32;
	Var13.f_1.f_2 = -1;
	Var13.f_1.f_3 = -1082130432;
	Var13.f_1.f_4 = -1;
	Var13.f_1.f_5 = -1;
	Var13.f_1.f_6.f_2 = -1;
	Var13.f_1.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_4 = -1;
	Var13.f_1.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 =
		-1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 =
		-1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_2 =
		-1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_3 =
		-1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_4 =
		-1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_5 =
		-1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_5 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_6.f_2 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_6.f_3 = -1082130432;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_6.f_4 = -1;
	Var13.f_1.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6.f_6
		.f_6.f_6.f_6.f_6.f_6.f_5 = -1;
	iVar206 = 0;
	iVar207 = 0;
	iVar0 = 0;
	while (iVar0 < script::get_number_of_events(1)) {
		if (script::get_event_at_index(1, iVar0) == 171) {
			if (gameplay::is_bit_set(iLocal_219, 0)) {
				if (script::get_event_data(1, iVar0, &Var1, 6)) {
					if (Var1 == 559) {
						if (iVar206 < 16) {
							Var13[iVar206 /*6*/] = {Var1};
							if (!gameplay::is_bit_set(iLocal_219, 7 + Var1.f_4)) {
								gameplay::set_bit(&iLocal_219, 7 + Var1.f_4);
							}
							iVar206++;
						}
					}
				}
				if (script::get_event_data(1, iVar0, &vVar7, 3)) {
					if (vVar7.x == 560) {
						func_158(&uParam0->f_35, vVar7.z);
					}
				}
			}
			else if (script::get_event_data(1, iVar0, &vVar10, 3)) {
				if (vVar10.x == 561) {
					iLocal_220 = vVar10.z;
				}
			}
		}
		iVar0++;
	}
	Var212.f_2 = -1;
	Var212.f_3 = -1082130432;
	Var212.f_4 = -1;
	Var212.f_5 = -1;
	iVar210 = iVar206;
	while (iVar210 <= 15) {
		if (Local_116[iVar210 /*6*/].f_5 < 99999 && Local_116[iVar210 /*6*/].f_5 > -1) {
			Var13[iVar206 + iVar210 /*6*/] = {Local_116[iVar210 /*6*/]};
			Local_116[iVar210 /*6*/] = {Var212};
			iVar211++;
		}
		iVar210++;
	}
	iVar206 += iVar211;
	if (iVar206 > 1) {
		iVar0 = 0;
		while (iVar0 <= iVar206 - 1) {
			iVar0++;
		}
		func_156(&Var13, 0, iVar206 - 1);
		iVar0 = 0;
		while (iVar0 <= iVar206 - 1) {
			iVar0++;
		}
	}
	iVar0 = 0;
	while (iVar0 <= iVar206 - 1) {
		func_132(Var13[iVar0 /*6*/].f_3, &fVar208, &fVar209, 9974);
		if (Var13[iVar0 /*6*/].f_5 < 99999) {
			if (uLocal_213[Var13[iVar0 /*6*/].f_4] != Var13[iVar0 /*6*/].f_4 * 10000) {
				if (Var13[iVar0 /*6*/].f_5 > uLocal_213[Var13[iVar0 /*6*/].f_4] + 2) {
					iVar218 = 0;
					if (func_155(&iVar218)) {
						Local_116[iVar218 /*6*/] = {Var13[iVar0 /*6*/]};
					}
					if (Var13[iVar0 /*6*/].f_5 > uLocal_213[Var13[iVar0 /*6*/].f_4] + 4) {
						uLocal_213[Var13[iVar0 /*6*/].f_4]++;
					}
					Jump @682; // curOff = 1562
				}
				else if (Var13[iVar0 /*6*/].f_5 < uLocal_213[Var13[iVar0 /*6*/].f_4]) {
				}
				else {
					if (Var13[iVar0 /*6*/].f_5 == uLocal_213[Var13[iVar0 /*6*/].f_4] + 2) {
						fVar219 = 0f;
						fVar220 = 0f;
						fVar221 = 0f;
						fVar222 = 0f;
						iVar223 = -1;
						if (uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/].f_4 > 0) {
							func_132(uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/]
										 .f_18[uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/].f_4 - 1],
									 &fVar221, &fVar222, 9974);
						}
						else {
							func_139(Local_366[Var13[iVar0 /*6*/].f_4 /*2*/], &iVar224, &fVar221, &fVar222, &iVar225);
						}
						switch (uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/].f_2) {
						case 0:
						case 1:
							if (fVar221 > fVar208) {
								iVar223 = 3;
							}
							else {
								iVar223 = 2;
							}
							break;

						case 3:
						case 2:
							if (fVar222 > fVar209) {
								iVar223 = 1;
							}
							else {
								iVar223 = 0;
							}
							break;
						}
						switch (iVar223) {
						case 0:
							fVar219 = fVar208;
							fVar220 = fVar222;
							break;

						case 1:
							fVar219 = fVar208;
							fVar220 = fVar222;
							break;

						case 3:
							fVar219 = fVar221;
							fVar220 = fVar209;
							break;

						case 2:
							fVar219 = fVar221;
							fVar220 = fVar209;
							break;
						}
						func_154(uParam0, Var13[iVar0 /*6*/].f_4, iVar223, fVar219, fVar220, &iVar207);
						func_133(uParam0, &uParam0->f_35, Var13[iVar0 /*6*/].f_4);
						func_154(uParam0, Var13[iVar0 /*6*/].f_4, Var13[iVar0 /*6*/].f_2, fVar208, fVar209, &iVar207);
						func_133(uParam0, &uParam0->f_35, Var13[iVar0 /*6*/].f_4);
					}
					else {
						if (Var13[iVar0 /*6*/].f_5 != uLocal_213[Var13[iVar0 /*6*/].f_4] + 1 &&
							Var13[iVar0 /*6*/].f_5 != Var13[iVar0 /*6*/].f_4 * 10000) {
						}
						func_132(Var13[iVar0 /*6*/].f_3, &fVar208, &fVar209, 9974);
						func_154(uParam0, Var13[iVar0 /*6*/].f_4, Var13[iVar0 /*6*/].f_2, fVar208, fVar209, &iVar207);
						func_133(uParam0, &uParam0->f_35, Var13[iVar0 /*6*/].f_4);
					}
					uLocal_213[Var13[iVar0 /*6*/].f_4] = Var13[iVar0 /*6*/].f_5;
					Jump @125; // curOff = 2119
					if (Var13[iVar0 /*6*/].f_2 == 4 && !gameplay::is_bit_set(iVar207, Var13[iVar0 /*6*/].f_4)) {
						if (!gameplay::is_bit_set(iLocal_219, 15 + Var13[iVar0 /*6*/].f_4)) {
							gameplay::set_bit(&iLocal_219, 15 + Var13[iVar0 /*6*/].f_4);
						}
						uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/].f_14 = fVar208;
						uParam0->f_35[Var13[iVar0 /*6*/].f_4 /*79*/].f_15 = fVar209;
						func_133(uParam0, &uParam0->f_35, Var13[iVar0 /*6*/].f_4);
					}
				}
				iVar0++;
			}
			// Malformed control flow, Output may be wrong
		}
	}
}

// Position - 0xBE92
void func_154(var *uParam0, int iParam1, int iParam2, float fParam3, float fParam4, int *iParam5) {
	uParam0->f_35[iParam1 /*79*/].f_9 = iParam2;
	uParam0->f_35[iParam1 /*79*/].f_14 = fParam3;
	uParam0->f_35[iParam1 /*79*/].f_15 = fParam4;
	if (gameplay::is_bit_set(*iParam5, iParam1)) {
		uParam0->f_35[iParam1 /*79*/].f_8 = uParam0->f_35[iParam1 /*79*/].f_2;
	}
	else {
		gameplay::set_bit(iParam5, iParam1);
	}
}

// Position - 0xBEE9
bool func_155(int iParam0) {
	*iParam0 = 0;
	while (*iParam0 <= 15) {
		if (Local_116[*iParam0 /*6*/].f_5 == -1) {
			return true;
		}
		*iParam0++;
	}
	return false;
}

// Position - 0xBF1A
void func_156(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = func_157(uParam0, iParam1, iParam2);
	if (iParam1 < iVar0 - 1) {
		func_156(uParam0, iParam1, iVar0 - 1);
	}
	if (iVar0 < iParam2) {
		func_156(uParam0, iVar0, iParam2);
	}
}

// Position - 0xBF54
int func_157(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	struct<6> Var2;
	int iVar8;

	iVar0 = iParam1;
	iVar1 = iParam2;
	Var2.f_2 = -1;
	Var2.f_3 = -1082130432;
	Var2.f_4 = -1;
	Var2.f_5 = -1;
	iVar8 = (*uParam0)[(iParam1 + iParam2) / 2 /*6*/].f_5;
	while (iVar0 <= iVar1) {
		while ((*uParam0)[iVar0 /*6*/].f_5 < iVar8) {
			iVar0++;
		}
		while ((*uParam0)[iVar1 /*6*/].f_5 > iVar8) {
			iVar1--;
		}
		if (iVar0 <= iVar1) {
			Var2 = {(*uParam0)[iVar0 /*6*/]};
			(*uParam0)[iVar0 /*6*/] = {(*uParam0)[iVar1 /*6*/]};
			(*uParam0)[iVar1 /*6*/] = {Var2};
			iVar0++;
			iVar1--;
		}
	}
	return iVar0;
}

// Position - 0xC005
void func_158(var *uParam0, int iParam1) {
	if (!audio::has_sound_finished((*uParam0)[iParam1 /*79*/].f_5)) {
		audio::stop_sound((*uParam0)[iParam1 /*79*/].f_5);
	}
	if (iParam1 == iLocal_218) {
		audio::play_sound_frontend((*uParam0)[iParam1 /*79*/].f_6, "Crash", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
	}
	else {
		audio::play_sound_frontend((*uParam0)[iParam1 /*79*/].f_6, "Crash_NPC", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
	}
	audio::set_variable_on_sound((*uParam0)[iParam1 /*79*/].f_6, "X", (*uParam0)[iParam1 /*79*/].f_14);
	audio::set_variable_on_sound((*uParam0)[iParam1 /*79*/].f_6, "Y", (*uParam0)[iParam1 /*79*/].f_15);
	func_16(uParam0, 3, iParam1);
}

// Position - 0xC094
void func_159(var *uParam0) {
	int iVar0;

	if (!func_12(&uParam0->f_18)) {
		func_10(&uParam0->f_18, 0, 0);
	}
	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			func_125(uParam0, &uParam0->f_35, iVar0);
		}
		iVar0++;
	}
	func_147(uParam0);
	func_162(uParam0);
	func_141(uParam0);
	func_153(uParam0);
	func_161(uParam0);
	func_140(uParam0);
	if (Local_288 >= 7) {
		audio::stop_sound(uParam0->f_3);
		audio::play_sound_frontend(-1, "Go", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
		func_9(&uParam0->f_18);
		func_160();
		func_180(uParam0, 7);
	}
}

// Position - 0xC143
void func_160() {
	int iVar0;
	struct<6> Var1;

	Var1.f_2 = -1;
	Var1.f_3 = -1082130432;
	Var1.f_4 = -1;
	Var1.f_5 = -1;
	iVar0 = 0;
	while (iVar0 <= 3) {
		uLocal_213[iVar0] = iVar0 * 10000;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 <= 15) {
		Local_116[iVar0 /*6*/] = {Var1};
		iVar0++;
	}
}

// Position - 0xC1A6
void func_161(var *uParam0) {
	if (!func_8(&uParam0->f_18, 1000, 0)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 2)) {
			audio::play_sound_frontend(-1, "321", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			gameplay::set_bit(&uParam0->f_2, 2);
		}
	}
	else if (!func_8(&uParam0->f_18, 2000, 0)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 1)) {
			audio::play_sound_frontend(-1, "321", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			gameplay::set_bit(&uParam0->f_2, 1);
		}
	}
	else if (!gameplay::is_bit_set(uParam0->f_2, 0)) {
		audio::play_sound_frontend(-1, "321", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
		gameplay::set_bit(&uParam0->f_2, 0);
	}
}

// Position - 0xC23D
void func_162(var *uParam0) {
	if (!func_8(&uParam0->f_18, 1000, 0)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 7)) {
			func_49(uParam0, "DCTL_COUNTDOWN3", 0, 0);
			gameplay::set_bit(&uParam0->f_2, 7);
		}
	}
	else if (!func_8(&uParam0->f_18, 2000, 0)) {
		if (!gameplay::is_bit_set(uParam0->f_2, 8)) {
			func_49(uParam0, "DCTL_COUNTDOWN2", 0, 0);
			gameplay::set_bit(&uParam0->f_2, 8);
		}
	}
	else if (!gameplay::is_bit_set(uParam0->f_2, 9)) {
		func_49(uParam0, "DCTL_COUNTDOWN1", 0, 0);
		gameplay::set_bit(&uParam0->f_2, 9);
	}
}

// Position - 0xC2D5
void func_163(var *uParam0) {
	int iVar0;

	if (!func_12(&uParam0->f_16)) {
		func_10(&uParam0->f_16, 0, 0);
	}
	iVar0 = 0;
	while (iVar0 <= network::_network_get_num_participants_host() - 1) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			func_125(uParam0, &uParam0->f_35, iVar0);
		}
		iVar0++;
	}
	if (gameplay::is_bit_set(uParam0->f_2, 16)) {
		func_47(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 16);
	}
	if (!gameplay::is_bit_set(uParam0->f_2, 18)) {
		audio::play_sound_frontend(-1, "Ready", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
		gameplay::set_bit(&uParam0->f_2, 18);
	}
	func_147(uParam0);
	func_164(uParam0);
	func_141(uParam0);
	func_140(uParam0);
	if (Local_288 == 10) {
		func_180(uParam0, 10);
		func_46(1);
	}
	else if (Local_288 >= 6) {
		func_180(uParam0, 6);
	}
}

// Position - 0xC3B1
void func_164(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 6)) {
		func_49(uParam0, "DCTL_READY", 0, 2);
		gameplay::set_bit(&uParam0->f_2, 6);
	}
}

// Position - 0xC3DB
void func_165(var *uParam0) {
	bool bVar0;
	int iVar1;

	func_52(uParam0);
	func_166(uParam0);
	if (gameplay::is_bit_set(uParam0->f_2, 16)) {
		func_47(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 16);
	}
	if (Local_288.f_77 == 3 && !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 5)) {
		bVar0 = true;
		iVar1 = 0;
		while (iVar1 <= network::_network_get_num_participants_host() - 1) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
				if (Local_288.f_2[iVar1] == -1) {
					bVar0 = false;
				}
				else {
					if (iVar1 == iLocal_218) {
						Local_366[iLocal_218 /*2*/] = Local_288.f_2[iLocal_218];
						func_139(Local_366[iVar1 /*2*/], &uParam0->f_35[iVar1 /*79*/].f_2,
								 &uParam0->f_35[iVar1 /*79*/].f_14, &uParam0->f_35[iVar1 /*79*/].f_15,
								 &uParam0->f_35[iVar1 /*79*/].f_8);
					}
					else if (Local_366[iVar1 /*2*/] == Local_288.f_2[iVar1]) {
						func_139(Local_366[iVar1 /*2*/], &uParam0->f_35[iVar1 /*79*/].f_2,
								 &uParam0->f_35[iVar1 /*79*/].f_14, &uParam0->f_35[iVar1 /*79*/].f_15,
								 &uParam0->f_35[iVar1 /*79*/].f_8);
					}
					else {
						bVar0 = false;
					}
					iVar1++;
				}
				if (bVar0) {
					gameplay::set_bit(&Local_366[iLocal_218 /*2*/].f_1, 5);
				}
				if (Local_288 == 10) {
					audio::stop_sound(uParam0->f_3);
					audio::play_sound_frontend(-1, "Music_Game_Over", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
					func_180(uParam0, 10);
					func_46(0);
				}
				else if (Local_288 >= 5) {
					uParam0->f_5 = network::network_get_num_participants();
					audio::set_variable_on_sound(uParam0->f_3, "FadeOut", 7f);
					func_62();
					func_180(uParam0, 5);
					gameplay::clear_bit(&Local_366[iLocal_218 /*2*/].f_1, 5);
				}
			}
			// Malformed control flow, Output may be wrong
		}
	}
}

// Position - 0xC571
void func_166(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 13)) {
		func_49(uParam0, "DCTL_LOADING", 0, 2);
		gameplay::set_bit(&uParam0->f_2, 13);
	}
}

// Position - 0xC59D
void func_167(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_2, 14)) {
		func_170(uParam0);
		gameplay::clear_bit(&uParam0->f_2, 14);
		gameplay::set_bit(&uParam0->f_2, 17);
	}
	func_52(uParam0);
	func_169(uParam0);
	if (gameplay::is_pc_version()) {
		controls::disable_control_action(2, 200, 1);
	}
	if (!ui::is_pause_menu_active()) {
		if (controls::is_control_just_pressed(2, 201) && !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
			!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
			func_71(3);
		}
		if (controls::is_control_just_pressed(2, 202) && !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
			!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
			func_71(4);
		}
	}
	if (func_70()) {
		func_6(1);
	}
	if (!gameplay::is_bit_set(uParam0->f_2, 4) && !gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 3) &&
		!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4)) {
		ui::display_help_text_this_frame("DCTL_TITLEHELP", 0);
		gameplay::set_bit(&uParam0->f_2, 5);
	}
	func_168(uParam0);
	func_140(uParam0);
	func_56(uParam0, 0);
	if (Local_288 > 3) {
		if (gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 4) ||
			gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 2)) {
			func_180(uParam0, 11);
		}
		else {
			if (Local_288 == 10) {
				func_6(0);
				func_5(0, 0);
				func_180(uParam0, 10);
				func_46(1);
				return;
			}
			func_14(uParam0);
			func_6(0);
			func_5(0, 0);
			if (Local_288 == 4) {
				func_180(uParam0, 4);
			}
			else {
				uParam0->f_5 = network::network_get_num_participants();
				audio::set_variable_on_sound(uParam0->f_3, "FadeOut", 7f);
				func_180(uParam0, 5);
			}
		}
	}
	else if (audio::has_sound_finished(uParam0->f_3)) {
		audio::play_sound_frontend(uParam0->f_3, "Background", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
	}
}

// Position - 0xC779
void func_168(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		if (network::network_is_participant_active(player::int_to_participantindex(iVar0)) &&
			Local_366[iVar0 /*2*/] > -1) {
			if (gameplay::is_bit_set(Local_366[iVar0 /*2*/].f_1, 3) &&
				!gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 0)) {
				audio::play_sound_frontend(uParam0->f_6, "Insert_Coin", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				gameplay::set_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 0);
				if (gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 1)) {
					gameplay::clear_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 1);
				}
			}
			else if (gameplay::is_bit_set(Local_366[iVar0 /*2*/].f_1, 4) &&
					 !gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 1)) {
				audio::play_sound_frontend(uParam0->f_6, "Cancel", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				gameplay::set_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 1);
				if (gameplay::is_bit_set(uParam0->f_35[iVar0 /*79*/].f_3, 0)) {
					gameplay::clear_bit(&uParam0->f_35[iVar0 /*79*/].f_3, 0);
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xC880
void func_169(var *uParam0) {
	if (!gameplay::is_bit_set(uParam0->f_2, 16)) {
		gameplay::set_bit(&uParam0->f_2, 16);
	}
	func_57(uParam0, "DCTL_INSERT", 0);
	func_75(uParam0);
	func_73(uParam0);
}

// Position - 0xC8B7
void func_170(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "HIDE_LOADING_SCREEN");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xC8DB
void func_171(var *uParam0) {
	if (!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 1)) {
		if (network::network_is_game_in_progress()) {
			func_32(player::player_id(), 0, 0);
			func_174();
		}
		else {
			player::set_player_control(player::player_id(), 0, 0);
		}
		func_41(1, 0, 1, 0);
		audio::start_audio_scene("DLC_Exec_Arc_Mac_Playing_Game_Scene");
		func_173(uParam0);
		func_10(&uParam0->f_10, 0, 0);
		gameplay::set_bit(&uParam0->f_2, 14);
		gameplay::set_bit(&Local_366[iLocal_218 /*2*/].f_1, 1);
	}
	else {
		switch (uParam0->f_1) {
		case 0:
			audio::play_sound_frontend(-1, "Degenatron_Logo", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
			func_172(uParam0, 1);
			break;

		case 1:
			if (func_8(&uParam0->f_10, 1800, 0)) {
				audio::play_sound_frontend(-1, "Degenatron_Star", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				func_172(uParam0, 2);
			}
			break;

		case 2:
			if (func_8(&uParam0->f_10, 2250, 0)) {
				if (audio::has_sound_finished(uParam0->f_3)) {
					audio::play_sound_frontend(uParam0->f_3, "Background", "DLC_EXEC_ARC_MAC_SOUNDS", 1);
				}
				func_172(uParam0, 3);
			}
			break;
		}
		if (func_8(&uParam0->f_10, 2200, 0)) {
			gameplay::set_bit(&uParam0->f_2, 17);
		}
		if (func_8(&uParam0->f_10, 6000, 0) ||
			uParam0->f_1 == 3 && func_8(&uParam0->f_10, 3000, 0) && controls::is_control_just_pressed(2, 201)) {
			gameplay::set_bit(&Local_366[iLocal_218 /*2*/].f_1, 6);
			func_62();
			if (Local_288 == 9) {
				func_180(uParam0, 9);
			}
			else if (Local_288 >= 3) {
				func_180(uParam0, 3);
			}
		}
	}
}

// Position - 0xCA63
void func_172(var *uParam0, int iParam1) { uParam0->f_1 = iParam1; }

// Position - 0xCA71
void func_173(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
		graphics::_push_scaleform_movie_function(uParam0->f_34, "SHOW_LOADING_SCREEN");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xCA95
void func_174() { Global_2433125.f_655.f_10 = 1; }

// Position - 0xCAA7
void func_175(var *uParam0) {
	if (!gameplay::is_bit_set(Local_366[iLocal_218 /*2*/].f_1, 0)) {
		func_177();
		uParam0->f_34 = unk_0x67D02A194A2FC2BD("dont_cross_the_line");
		if (func_176() && graphics::has_scaleform_movie_loaded(uParam0->f_34)) {
			gameplay::set_bit(&Local_366[iLocal_218 /*2*/].f_1, 0);
			func_180(uParam0, 2);
		}
	}
}

// Position - 0xCAFB
int func_176() {
	if (audio::request_script_audio_bank("DLC_EXEC1/OFFICE_BOARDROOM", 0, -1) &&
		graphics::has_streamed_texture_dict_loaded("LineArcadeMinigame") && ui::has_additional_text_loaded(3)) {
		return 1;
	}
	return 0;
}

// Position - 0xCB29
int func_177() {
	if (audio::request_script_audio_bank("DLC_EXEC1/OFFICE_BOARDROOM", 0, -1)) {
		graphics::request_streamed_texture_dict("LineArcadeMinigame", 0);
		ui::request_additional_text("DCTL", 3);
		gameplay::set_bit(&Global_1751026, 6);
		return 1;
	}
	return 0;
}

// Position - 0xCB5B
void func_178(var *uParam0) {
	int iVar0;

	if (iLocal_218 == -1) {
		Global_1633501.f_102723 = 1;
		uParam0->f_8 = func_179();
		uParam0->f_3 = audio::get_sound_id();
		uParam0->f_6 = audio::get_sound_id();
		uParam0->f_7 = audio::get_sound_id();
		iVar0 = 0;
		while (iVar0 <= 3) {
			uParam0->f_35[iVar0 /*79*/].f_5 = audio::get_sound_id();
			uParam0->f_35[iVar0 /*79*/].f_6 = audio::get_sound_id();
			uParam0->f_35[iVar0 /*79*/].f_7 = audio::get_sound_id();
			iVar0++;
		}
		Global_1591201[player::player_id() /*602*/].f_510 = 1;
		iLocal_218 = network::participant_id_to_int();
		Local_366[iLocal_218 /*2*/] = -1;
		uParam0->f_34 = 0;
		func_71(2);
		func_172(uParam0, 0);
	}
	if (Local_366[iLocal_218 /*2*/] == -1) {
		if (Local_288.f_2[iLocal_218] > -1) {
			Local_366[iLocal_218 /*2*/] = Local_288.f_2[iLocal_218];
		}
	}
	else {
		func_180(uParam0, 1);
	}
	func_6(0);
}

// Position - 0xCC35
float func_179() {
	int iVar0;
	int iVar1;
	float fVar2;

	iVar0 = 0;
	iVar1 = 0;
	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (gameplay::is_pc_version()) {
		if (fVar2 >= 4f) {
			fVar2 /= 3f;
		}
	}
	return fVar2;
}

// Position - 0xCC70
void func_180(var *uParam0, int iParam1) {
	uParam0->f_4 = 0;
	*uParam0 = iParam1;
}

// Position - 0xCC82
void func_181(var *uParam0) {
	bool bVar0;
	int iVar1;
	int iVar2;

	controls::_disable_input_group(0);
	controls::_disable_input_group(2);
	graphics::_0xC6372ECD45D73BCD(0);
	func_196(1);
	func_195(4, -1);
	ui::hide_scripted_hud_component_this_frame(19);
	func_194();
	func_193();
	func_192();
	ui::_0x25F87B30C382FCA7();
	if (!func_190(player::player_id())) {
		func_180(uParam0, 11);
	}
	if (!func_37()) {
		func_180(uParam0, 11);
	}
	func_189();
	unk1::_0xEB2D525B57F42B40();
	if (Local_288 > 2) {
		func_184();
	}
	func_182(uParam0);
	if (!ui::is_pause_menu_active() && Local_288 > 2) {
		ui::hide_hud_and_radar_this_frame();
		graphics::_set_2d_layer(1);
	}
	if (network::network_is_host_of_this_script() && Local_288 != 4) {
		iVar1 = 0;
		while (iVar1 <= 3) {
			if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
				if (Local_288.f_2[iVar1] == -1) {
					Local_288.f_2[iVar1] = func_24();
					bVar0 = true;
				}
			}
			else if (Local_288.f_2[iVar1] != -1) {
				Local_288.f_2[iVar1] = -1;
				bVar0 = true;
			}
			iVar1++;
		}
		if (bVar0) {
			iVar1 = 0;
			while (iVar1 <= network::_network_get_num_participants_host() - 1) {
				if (network::network_is_participant_active(player::int_to_participantindex(iVar1))) {
					iVar2 = 0;
					while (iVar2 <= network::_network_get_num_participants_host() - 1) {
						if (network::network_is_participant_active(player::int_to_participantindex(iVar2))) {
							if (iVar2 != iVar1 &&
								(Local_288.f_2[iVar1] == Local_288.f_2[iVar2] || Local_288.f_2[iVar1] == -1)) {
								Local_288.f_2[iVar1] = -1;
								return;
							}
						}
						iVar2++;
					}
				}
				iVar1++;
			}
		}
	}
}

// Position - 0xCE08
void func_182(var *uParam0) {
	uParam0->f_8 = func_179();
	uParam0->f_9 = func_183(uParam0->f_8);
}

// Position - 0xCE24
float func_183(float fParam0) { return 1.778f / fParam0; }

// Position - 0xCE34
void func_184() {
	if (Global_14443.f_1 != 1) {
		if (func_188(0)) {
			func_185(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0xCE5C
void func_185(int iParam0) {
	if (Global_14604) {
		func_187(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_186()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0xCECC
int func_186() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0xCEF3
void func_187(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_188(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0xCF67
bool func_188(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0xCFC1
void func_189() { Global_17151.f_134 = 1; }

// Position - 0xCFCF
int func_190(int iParam0) {
	if (func_191(Global_1591201[iParam0 /*602*/].f_258.f_15)) {
		return 1;
	}
	return 0;
}

// Position - 0xCFF1
bool func_191(int iParam0) {
	switch (iParam0) {
	case 87:
	case 88:
	case 89:
	case 90: return true;
	}
	return false;
}

// Position - 0xD020
void func_192() { Global_2494199.f_4394 = 0; }

// Position - 0xD030
void func_193() { Global_17151.f_6 = 1; }

// Position - 0xD03E
void func_194() {
	Global_1312567 = 1;
	StringCopy(&Global_1312567.f_1, script::get_this_script_name(), 24);
	Global_1312567.f_7 = gameplay::get_hash_key(&Global_1312567.f_1);
}

// Position - 0xD067
void func_195(int iParam0, int iParam1) {
	gameplay::set_bit(&Global_1353070.f_1014, iParam0);
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			Global_1353070.f_170[iParam1] = 1;
		}
		break;
	}
}

// Position - 0xD09D
void func_196(int iParam0) { Global_1354542.f_995 = iParam0; }

// Position - 0xD0AE
void func_197() {
	func_29(&uLocal_375);
	func_30();
}

// Position - 0xD0C1
bool func_198() {
	bool bVar0;
	int *iVar1;

	func_204(&bVar0, &iVar1);
	if (bVar0) {
		return true;
	}
	if (Global_1315210 == 0) {
		if (!network::network_is_game_in_progress()) {
			return true;
		}
	}
	if (func_203()) {
		return true;
	}
	if (Global_2454747) {
		return true;
	}
	if (func_202()) {
		return true;
	}
	if (func_201(157)) {
		if (!func_200()) {
			return true;
		}
	}
	if (func_201(155)) {
		return true;
	}
	if (!network::network_is_signed_online()) {
		return true;
	}
	if (func_199() != 0) {
		if (script::_get_number_of_instances_of_script_with_name_hash(func_199()) == 0) {
			return true;
		}
	}
	return false;
}

// Position - 0xD156
int func_199() {
	switch (func_84()) {
	case 0: return joaat("freemode");

	case 2: return joaat("creator");
	}
	return 0;
}

// Position - 0xD18A
bool func_200() { return Global_2443134.f_577; }

// Position - 0xD199
bool func_201(int iParam0) {
	if (script::get_event_exists(1, iParam0)) {
		return true;
	}
	return false;
}

// Position - 0xD1B0
bool func_202() { return Global_2452525; }

// Position - 0xD1BC
bool func_203() { return Global_2443134.f_572; }

// Position - 0xD1CB
void func_204(int *iParam0, int *iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < script::get_number_of_events(1)) {
		iVar1 = script::get_event_at_index(1, iVar0);
		if (iVar1 == 171) {
			script::get_event_data(1, iVar0, &iVar2, 2);
			switch (iVar2) {
			case 381: func_205(iVar0); break;

			case 2:
				script::get_event_data(1, iVar0, &vVar4, 3);
				if (vVar4.z == 55) {
					*iParam0 = 1;
				}
				else if (vVar4.z == 32) {
					*iParam1 = 1;
				}
				break;
			}
		}
		iVar0++;
	}
}

// Position - 0xD24B
void func_205(int iParam0) {
	vector3 vVar0;
	int iVar3;
	int iVar4;
	bool bVar5;

	if (script::get_event_data(1, iParam0, &vVar0, 3)) {
		if (func_21(vVar0.y, 1, 1)) {
			iVar3 = player::get_player_ped(vVar0.y);
			if (entity::does_entity_exist(iVar3)) {
				if (ped::is_ped_in_any_vehicle(iVar3, 0)) {
					iVar4 = ped::get_vehicle_ped_is_in(iVar3, 0);
					if (vehicle::is_vehicle_window_intact(iVar4, vVar0.z) &&
						network::network_get_this_script_is_network_script()) {
						if (func_206(iVar4, &bVar5)) {
							vehicle::remove_vehicle_window(iVar4, vVar0.z);
						}
						if (bVar5) {
							entity::set_vehicle_as_no_longer_needed(&iVar4);
						}
					}
				}
			}
		}
	}
}

// Position - 0xD2CC
bool func_206(int iParam0, int *iParam1) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_a_mission_entity(iParam0)) {
			if (network::network_get_entity_is_local(iParam0)) {
				if (!vehicle::is_this_model_a_train(entity::get_entity_model(iParam0))) {
					entity::set_entity_as_mission_entity(iParam0, 0, 1);
					*iParam1 = 1;
				}
			}
		}
		if (entity::does_entity_belong_to_this_script(iParam0, 0)) {
			if (network::network_has_control_of_entity(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0xD32B
void func_207() { system::wait(0); }

// Position - 0xD338
void func_208(int iParam0) {
	if (iParam0) {
		if (!gameplay::is_bit_set(Global_1619421[player::player_id() /*390*/].f_3, 3)) {
			func_177();
		}
		gameplay::set_bit(&Global_1619421[player::player_id() /*390*/].f_3, 3);
	}
	else {
		gameplay::clear_bit(&Global_1619421[player::player_id() /*390*/].f_3, 3);
	}
}

// Position - 0xD387
void func_209(struct<20> Param0) {
	func_213(4, Param0);
	if (!func_211(0, -1, 1)) {
		func_197();
	}
	network::network_register_host_broadcast_variables(&Local_288, 78);
	network::network_register_player_broadcast_variables(&Local_366, 9);
	if (!func_210()) {
		func_197();
	}
}

// Position - 0xD3C6
int func_210() {
	int iVar0;

	iVar0 = 0;
	while (true) {
		iVar0++;
		if (!network::network_is_game_in_progress()) {
			return 0;
		}
		if (network::_0x5D10B3795F3FC886()) {
			return 1;
		}
		if (func_203()) {
			return 0;
		}
		if (func_201(155)) {
			return 0;
		}
		if (iVar0 >= 3600) {
			return 0;
		}
		system::wait(0);
	}
	return 0;
}

// Position - 0xD41F
int func_211(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = network::network_get_script_status();
	while (iVar0 != 2) {
		if (iVar0 == 3 || iVar0 == 4 || iVar0 == 5 || iVar0 == 6) {
			if (!iParam2) {
				func_30();
			}
			else {
				return 0;
			}
		}
		if (!func_212()) {
			if (iParam0 == 0) {
				if (!network::network_is_game_in_progress()) {
					if (!iParam2) {
						func_30();
					}
					else {
						return 0;
					}
				}
				if (func_203()) {
					if (!iParam2) {
						func_30();
					}
					else {
						return 0;
					}
				}
				if (func_201(155)) {
					if (!iParam2) {
						func_30();
					}
					else {
						return 0;
					}
				}
			}
			else if (!network::network_is_in_session()) {
				if (!iParam2) {
					func_30();
				}
				else {
					return 0;
				}
			}
		}
		system::wait(0);
		iVar0 = network::network_get_script_status();
	}
	if (iParam1 > -1) {
		Global_1312500 = iVar0;
	}
	if (iParam0 == 0) {
		if (!network::network_is_game_in_progress()) {
			if (!iParam2) {
				func_30();
			}
			else {
				return 0;
			}
		}
	}
	else if (!network::network_is_in_session()) {
		if (!iParam2) {
			func_30();
		}
		else {
			return 0;
		}
	}
	return 1;
}

// Position - 0xD534
bool func_212() { return Global_1315210; }

// Position - 0xD540
void func_213(int iParam0, struct<17> Param1, var uParam18, var uParam19, var uParam20) {
	if (!network::network_is_game_in_progress()) {
		func_30();
	}
	network::network_set_this_script_is_network_script(iParam0, 0, Param1.f_16);
}

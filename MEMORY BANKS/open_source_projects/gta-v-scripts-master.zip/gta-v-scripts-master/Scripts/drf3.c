#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
var uLocal_20 = 0;
var uLocal_21 = 0;
var uLocal_22 = 0;
char *sLocal_23 = NULL;
float fLocal_24 = 0f;
var uLocal_25 = 0;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
float fLocal_29 = 0f;
var uLocal_30 = 0;
int iLocal_31 = 0;
var uLocal_32 = 0;
var uLocal_33 = 0;
float fLocal_34 = 0f;
float fLocal_35 = 0f;
float fLocal_36 = 0f;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int iLocal_44 = 0;
int iLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
int iLocal_48 = 0;
var *uLocal_49 = NULL;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
int iLocal_70 = 0;
int *iLocal_71 = NULL;
var uLocal_72 = 0;
var uLocal_73 = 0;
var *uLocal_74 = NULL;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var *uLocal_239 = NULL;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var *uLocal_287 = NULL;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var *uLocal_335 = NULL;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 0;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 0;
var uLocal_430 = 0;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 0;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var *uLocal_524 = NULL;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 0;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 0;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 0;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 0;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var *uLocal_713 = NULL;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
var uLocal_726 = 0;
var uLocal_727 = 0;
var uLocal_728 = 0;
var uLocal_729 = 0;
var uLocal_730 = 0;
var uLocal_731 = 0;
var uLocal_732 = 0;
var uLocal_733 = 0;
var uLocal_734 = 0;
var uLocal_735 = 0;
var uLocal_736 = 0;
var uLocal_737 = 0;
var uLocal_738 = 0;
var uLocal_739 = 0;
var uLocal_740 = 0;
var *uLocal_741 = NULL;
var uLocal_742 = 0;
var uLocal_743 = 0;
var uLocal_744 = 0;
var uLocal_745 = 0;
var uLocal_746 = 0;
var uLocal_747 = 0;
var uLocal_748 = 0;
var uLocal_749 = 0;
var uLocal_750 = 0;
var uLocal_751 = 0;
var uLocal_752 = 0;
var uLocal_753 = 0;
var uLocal_754 = 0;
var uLocal_755 = 0;
var uLocal_756 = 0;
var uLocal_757 = 0;
var uLocal_758 = 0;
var uLocal_759 = 0;
var uLocal_760 = 0;
var uLocal_761 = 0;
var uLocal_762 = 0;
var uLocal_763 = 0;
var uLocal_764 = 0;
var uLocal_765 = 0;
var uLocal_766 = 0;
var uLocal_767 = 0;
var uLocal_768 = 0;
var *uLocal_769 = NULL;
var uLocal_770 = 0;
var uLocal_771 = 0;
var uLocal_772 = 0;
var uLocal_773 = 0;
var uLocal_774 = 0;
var uLocal_775 = 0;
var uLocal_776 = 0;
var uLocal_777 = 0;
var uLocal_778 = 0;
var uLocal_779 = 0;
var uLocal_780 = 0;
var uLocal_781 = 0;
var uLocal_782 = 0;
var uLocal_783 = 0;
var uLocal_784 = 0;
var uLocal_785 = 0;
var uLocal_786 = 0;
var uLocal_787 = 0;
var uLocal_788 = 0;
var uLocal_789 = 0;
var uLocal_790 = 0;
var uLocal_791 = 0;
var uLocal_792 = 0;
var uLocal_793 = 0;
var uLocal_794 = 0;
var uLocal_795 = 0;
var uLocal_796 = 0;
var uLocal_797 = 0;
var uLocal_798 = 0;
var uLocal_799 = 0;
var uLocal_800 = 0;
var uLocal_801 = 0;
var uLocal_802 = 0;
var uLocal_803 = 0;
var uLocal_804 = 0;
var uLocal_805 = 0;
var uLocal_806 = 0;
var uLocal_807 = 0;
var uLocal_808 = 0;
var uLocal_809 = 0;
var uLocal_810 = 0;
var uLocal_811 = 0;
var uLocal_812 = 0;
var uLocal_813 = 0;
var uLocal_814 = 0;
var uLocal_815 = 0;
var uLocal_816 = 0;
var uLocal_817 = 0;
var uLocal_818 = 0;
var uLocal_819 = 0;
var uLocal_820 = 0;
var uLocal_821 = 0;
var uLocal_822 = 0;
var uLocal_823 = 0;
var uLocal_824 = 0;
var uLocal_825 = 0;
var uLocal_826 = 0;
var uLocal_827 = 0;
var uLocal_828 = 0;
var uLocal_829 = 0;
var uLocal_830 = 0;
var uLocal_831 = 0;
var uLocal_832 = 0;
var uLocal_833 = 0;
var uLocal_834 = 0;
var uLocal_835 = 0;
var uLocal_836 = 0;
var uLocal_837 = 0;
var uLocal_838 = 0;
var uLocal_839 = 0;
var uLocal_840 = 0;
var uLocal_841 = 0;
var uLocal_842 = 0;
var uLocal_843 = 0;
var uLocal_844 = 0;
var uLocal_845 = 0;
var uLocal_846 = 0;
var uLocal_847 = 0;
var uLocal_848 = 0;
var uLocal_849 = 0;
var uLocal_850 = 0;
var uLocal_851 = 0;
var uLocal_852 = 0;
var uLocal_853 = 0;
var uLocal_854 = 0;
var uLocal_855 = 0;
var uLocal_856 = 0;
var uLocal_857 = 0;
var uLocal_858 = 0;
var uLocal_859 = 0;
var uLocal_860 = 0;
var uLocal_861 = 0;
var uLocal_862 = 0;
var uLocal_863 = 0;
var uLocal_864 = 0;
var uLocal_865 = 0;
var uLocal_866 = 0;
var uLocal_867 = 0;
var uLocal_868 = 0;
var uLocal_869 = 0;
var uLocal_870 = 0;
var uLocal_871 = 0;
var uLocal_872 = 0;
var uLocal_873 = 0;
var uLocal_874 = 0;
var uLocal_875 = 0;
var uLocal_876 = 0;
var uLocal_877 = 0;
var *uLocal_878 = NULL;
var uLocal_879 = 0;
var uLocal_880 = 0;
var uLocal_881 = 0;
var uLocal_882 = 0;
var uLocal_883 = 0;
var uLocal_884 = 0;
var uLocal_885 = 0;
var uLocal_886 = 0;
var uLocal_887 = 0;
var uLocal_888 = 0;
var uLocal_889 = 0;
var uLocal_890 = 0;
var uLocal_891 = 0;
var uLocal_892 = 0;
var uLocal_893 = 0;
var uLocal_894 = 0;
var uLocal_895 = 0;
var uLocal_896 = 0;
var uLocal_897 = 0;
var uLocal_898 = 0;
var uLocal_899 = 0;
var uLocal_900 = 0;
var uLocal_901 = 0;
var uLocal_902 = 0;
var uLocal_903 = 0;
var uLocal_904 = 0;
var uLocal_905 = 0;
var uLocal_906 = 0;
var uLocal_907 = 0;
var uLocal_908 = 0;
var uLocal_909 = 0;
var uLocal_910 = 0;
var uLocal_911 = 0;
var uLocal_912 = 0;
var uLocal_913 = 0;
var uLocal_914 = 0;
var uLocal_915 = 0;
var uLocal_916 = 0;
var uLocal_917 = 0;
var uLocal_918 = 0;
var uLocal_919 = 0;
var uLocal_920 = 0;
var uLocal_921 = 0;
var uLocal_922 = 0;
var uLocal_923 = 0;
var uLocal_924 = 0;
var uLocal_925 = 0;
var uLocal_926 = 0;
var uLocal_927 = 0;
var uLocal_928 = 0;
var uLocal_929 = 0;
var uLocal_930 = 0;
var uLocal_931 = 0;
var uLocal_932 = 0;
var uLocal_933 = 0;
var uLocal_934 = 0;
var uLocal_935 = 0;
var uLocal_936 = 0;
var uLocal_937 = 0;
var uLocal_938 = 0;
var uLocal_939 = 0;
var uLocal_940 = 0;
var uLocal_941 = 0;
var uLocal_942 = 0;
var uLocal_943 = 0;
var uLocal_944 = 0;
var uLocal_945 = 0;
var uLocal_946 = 0;
var uLocal_947 = 0;
var uLocal_948 = 0;
var uLocal_949 = 0;
var uLocal_950 = 0;
var uLocal_951 = 0;
var uLocal_952 = 0;
var uLocal_953 = 0;
var uLocal_954 = 0;
var uLocal_955 = 0;
var uLocal_956 = 0;
var uLocal_957 = 0;
var uLocal_958 = 0;
var uLocal_959 = 0;
var uLocal_960 = 0;
var uLocal_961 = 0;
var uLocal_962 = 0;
var uLocal_963 = 0;
var uLocal_964 = 0;
var uLocal_965 = 0;
var uLocal_966 = 0;
var uLocal_967 = 0;
var uLocal_968 = 0;
var uLocal_969 = 0;
var uLocal_970 = 0;
var uLocal_971 = 0;
var uLocal_972 = 0;
var uLocal_973 = 0;
var uLocal_974 = 0;
var uLocal_975 = 0;
var uLocal_976 = 0;
var uLocal_977 = 0;
var uLocal_978 = 0;
var uLocal_979 = 0;
var uLocal_980 = 0;
var uLocal_981 = 0;
var uLocal_982 = 0;
var uLocal_983 = 0;
var uLocal_984 = 0;
var uLocal_985 = 0;
var uLocal_986 = 0;
var *uLocal_987 = NULL;
var uLocal_988 = 0;
var uLocal_989 = 0;
var uLocal_990 = 0;
var uLocal_991 = 0;
var uLocal_992 = 0;
var uLocal_993 = 0;
var uLocal_994 = 0;
var uLocal_995 = 0;
var uLocal_996 = 0;
var uLocal_997 = 0;
var uLocal_998 = 0;
var uLocal_999 = 0;
var uLocal_1000 = 0;
var uLocal_1001 = 0;
var uLocal_1002 = 0;
var uLocal_1003 = 0;
var uLocal_1004 = 0;
var uLocal_1005 = 0;
var uLocal_1006 = 0;
var uLocal_1007 = 0;
var uLocal_1008 = 0;
var uLocal_1009 = 0;
var uLocal_1010 = 0;
var uLocal_1011 = 0;
var uLocal_1012 = 0;
var uLocal_1013 = 0;
var uLocal_1014 = 0;
var *uLocal_1015 = NULL;
var uLocal_1016 = 0;
var uLocal_1017 = 0;
var uLocal_1018 = 0;
var uLocal_1019 = 0;
var uLocal_1020 = 0;
var uLocal_1021 = 0;
var uLocal_1022 = 0;
var uLocal_1023 = 0;
var uLocal_1024 = 0;
var uLocal_1025 = 0;
var uLocal_1026 = 0;
var uLocal_1027 = 0;
var uLocal_1028 = 0;
var uLocal_1029 = 0;
var uLocal_1030 = 0;
var uLocal_1031 = 0;
var uLocal_1032 = 0;
var uLocal_1033 = 0;
var uLocal_1034 = 0;
var uLocal_1035 = 0;
var uLocal_1036 = 0;
var uLocal_1037 = 0;
var uLocal_1038 = 0;
var uLocal_1039 = 0;
var uLocal_1040 = 0;
var uLocal_1041 = 0;
var uLocal_1042 = 0;
var *uLocal_1043 = NULL;
var uLocal_1044 = 0;
var uLocal_1045 = 0;
var uLocal_1046 = 0;
var uLocal_1047 = 0;
var uLocal_1048 = 0;
var uLocal_1049 = 0;
var uLocal_1050 = 0;
var uLocal_1051 = 0;
var uLocal_1052 = 0;
var uLocal_1053 = 0;
var uLocal_1054 = 0;
var uLocal_1055 = 0;
var uLocal_1056 = 0;
var uLocal_1057 = 0;
var uLocal_1058 = 0;
var uLocal_1059 = 0;
var uLocal_1060 = 0;
var uLocal_1061 = 0;
var uLocal_1062 = 0;
var uLocal_1063 = 0;
var uLocal_1064 = 0;
var uLocal_1065 = 0;
var uLocal_1066 = 0;
var uLocal_1067 = 0;
var uLocal_1068 = 0;
var uLocal_1069 = 0;
var uLocal_1070 = 0;
var uLocal_1071 = 0;
var uLocal_1072 = 0;
var uLocal_1073 = 0;
var uLocal_1074 = 0;
var uLocal_1075 = 0;
var uLocal_1076 = 0;
var uLocal_1077 = 0;
var uLocal_1078 = 0;
var uLocal_1079 = 0;
var uLocal_1080 = 0;
var uLocal_1081 = 0;
var uLocal_1082 = 0;
var uLocal_1083 = 0;
var uLocal_1084 = 0;
var uLocal_1085 = 0;
var uLocal_1086 = 0;
var uLocal_1087 = 0;
var uLocal_1088 = 0;
var uLocal_1089 = 0;
var uLocal_1090 = 0;
var uLocal_1091 = 0;
var uLocal_1092 = 0;
var uLocal_1093 = 0;
var uLocal_1094 = 0;
var uLocal_1095 = 0;
var uLocal_1096 = 0;
var uLocal_1097 = 0;
var uLocal_1098 = 0;
var uLocal_1099 = 0;
var uLocal_1100 = 0;
var uLocal_1101 = 0;
var uLocal_1102 = 0;
var uLocal_1103 = 0;
var uLocal_1104 = 0;
var uLocal_1105 = 0;
var uLocal_1106 = 0;
var uLocal_1107 = 0;
var uLocal_1108 = 0;
var uLocal_1109 = 0;
var uLocal_1110 = 0;
var uLocal_1111 = 0;
var uLocal_1112 = 0;
var uLocal_1113 = 0;
var uLocal_1114 = 0;
var uLocal_1115 = 0;
var uLocal_1116 = 0;
var uLocal_1117 = 0;
var uLocal_1118 = 0;
var uLocal_1119 = 0;
var uLocal_1120 = 0;
var uLocal_1121 = 0;
var uLocal_1122 = 0;
var uLocal_1123 = 0;
var uLocal_1124 = 0;
var uLocal_1125 = 0;
var uLocal_1126 = 0;
var uLocal_1127 = 0;
var uLocal_1128 = 0;
var uLocal_1129 = 0;
var uLocal_1130 = 0;
var uLocal_1131 = 0;
var uLocal_1132 = 0;
var uLocal_1133 = 0;
var uLocal_1134 = 0;
var uLocal_1135 = 0;
var uLocal_1136 = 0;
var uLocal_1137 = 0;
var uLocal_1138 = 0;
var uLocal_1139 = 0;
var uLocal_1140 = 0;
var uLocal_1141 = 0;
var uLocal_1142 = 0;
var uLocal_1143 = 0;
var uLocal_1144 = 0;
var uLocal_1145 = 0;
var uLocal_1146 = 0;
var uLocal_1147 = 0;
var uLocal_1148 = 0;
var uLocal_1149 = 0;
var uLocal_1150 = 0;
var uLocal_1151 = 0;
var *uLocal_1152 = NULL;
var uLocal_1153 = 0;
var uLocal_1154 = 0;
var uLocal_1155 = 0;
var uLocal_1156 = 0;
var uLocal_1157 = 0;
var uLocal_1158 = 0;
var uLocal_1159 = 0;
var uLocal_1160 = 0;
var uLocal_1161 = 0;
var uLocal_1162 = 0;
var uLocal_1163 = 0;
var uLocal_1164 = 0;
var uLocal_1165 = 0;
var uLocal_1166 = 0;
var uLocal_1167 = 0;
var uLocal_1168 = 0;
var uLocal_1169 = 0;
var uLocal_1170 = 0;
var uLocal_1171 = 0;
var uLocal_1172 = 0;
var uLocal_1173 = 0;
var uLocal_1174 = 0;
var uLocal_1175 = 0;
var uLocal_1176 = 0;
var uLocal_1177 = 0;
var uLocal_1178 = 0;
var uLocal_1179 = 0;
var uLocal_1180 = 0;
var uLocal_1181 = 0;
var uLocal_1182 = 0;
var uLocal_1183 = 0;
var uLocal_1184 = 0;
var uLocal_1185 = 0;
var uLocal_1186 = 0;
var uLocal_1187 = 0;
var uLocal_1188 = 0;
var uLocal_1189 = 0;
var uLocal_1190 = 0;
var uLocal_1191 = 0;
var uLocal_1192 = 0;
var uLocal_1193 = 0;
var uLocal_1194 = 0;
var uLocal_1195 = 0;
var uLocal_1196 = 0;
var uLocal_1197 = 0;
var uLocal_1198 = 0;
var uLocal_1199 = 0;
var uLocal_1200 = 0;
var uLocal_1201 = 0;
var uLocal_1202 = 0;
var uLocal_1203 = 0;
var uLocal_1204 = 0;
var uLocal_1205 = 0;
var uLocal_1206 = 0;
var uLocal_1207 = 0;
var uLocal_1208 = 0;
var uLocal_1209 = 0;
var uLocal_1210 = 0;
var uLocal_1211 = 0;
var uLocal_1212 = 0;
var uLocal_1213 = 0;
var uLocal_1214 = 0;
var uLocal_1215 = 0;
var uLocal_1216 = 0;
var uLocal_1217 = 0;
var uLocal_1218 = 0;
var uLocal_1219 = 0;
var uLocal_1220 = 0;
var uLocal_1221 = 0;
var uLocal_1222 = 0;
var uLocal_1223 = 0;
var uLocal_1224 = 0;
var uLocal_1225 = 0;
var uLocal_1226 = 0;
var uLocal_1227 = 0;
var uLocal_1228 = 0;
var uLocal_1229 = 0;
var uLocal_1230 = 0;
var uLocal_1231 = 0;
var uLocal_1232 = 0;
var uLocal_1233 = 0;
var uLocal_1234 = 0;
var uLocal_1235 = 0;
var uLocal_1236 = 0;
var uLocal_1237 = 0;
var uLocal_1238 = 0;
var uLocal_1239 = 0;
var uLocal_1240 = 0;
var uLocal_1241 = 0;
var uLocal_1242 = 0;
var uLocal_1243 = 0;
var uLocal_1244 = 0;
var uLocal_1245 = 0;
var uLocal_1246 = 0;
var uLocal_1247 = 0;
var uLocal_1248 = 0;
var uLocal_1249 = 0;
var uLocal_1250 = 0;
var uLocal_1251 = 0;
var uLocal_1252 = 0;
var uLocal_1253 = 0;
var uLocal_1254 = 0;
var uLocal_1255 = 0;
var uLocal_1256 = 0;
var uLocal_1257 = 0;
var uLocal_1258 = 0;
var uLocal_1259 = 0;
var uLocal_1260 = 0;
int iLocal_1261 = 0;
int iLocal_1262 = 0;
int iLocal_1263 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	bool bVar1;
	bool bVar2;
	int iVar3;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_23 = "NULL";
	fLocal_24 = 0f;
	fLocal_28 = -0.0375f;
	fLocal_29 = 0.17f;
	iLocal_31 = 3;
	fLocal_34 = 80f;
	fLocal_35 = 140f;
	fLocal_36 = 180f;
	iLocal_42 = 1;
	iLocal_43 = 65;
	iLocal_44 = 49;
	iLocal_45 = 64;
	if (player::has_force_cleanup_occurred(67)) {
		func_127();
		func_122();
	}
	iLocal_70 = func_121();
	func_120(&uLocal_49, iLocal_70);
	bVar1 = func_119(0) < func_118(iLocal_70);
	while (true) {
		system::wait(0);
		switch (iLocal_48) {
		case 0:
			if (bVar1) {
				if (func_114(&uLocal_74, &uLocal_335, &uLocal_524, &iLocal_1261)) {
					func_112(&uLocal_239, &uLocal_335, iLocal_1261);
					func_112(&uLocal_287, &uLocal_524, iLocal_1261);
					bVar2 = true;
				}
			}
			else {
				func_78(&uLocal_74, &uLocal_335, &uLocal_524, &iLocal_1261, &uLocal_769, &uLocal_878, &iLocal_1262,
						&uLocal_1043, &uLocal_1152, &iLocal_1263, &uLocal_49, iLocal_70);
				Global_88285 = 0;
				func_112(&uLocal_239, &uLocal_335, iLocal_1261);
				func_112(&uLocal_287, &uLocal_524, iLocal_1261);
				func_112(&uLocal_713, &uLocal_769, iLocal_1262);
				func_112(&uLocal_741, &uLocal_878, iLocal_1262);
				func_112(&uLocal_987, &uLocal_1043, iLocal_1263);
				func_112(&uLocal_1015, &uLocal_1152, iLocal_1263);
				iVar3 = 0;
			}
			iLocal_48 = 1;
			break;

		case 1:
			if (bVar1) {
				if (bVar2) {
					func_77(iLocal_1261, &uLocal_74, 36, "DrfAud", &uLocal_239, &uLocal_287, 9, 1, 0, 0, 0);
					iLocal_48 = 3;
				}
				else {
					iLocal_48 = 2;
				}
			}
			else if (func_65(iLocal_1261, &uLocal_74, 36, "DrfAud", &uLocal_239, &uLocal_287, "SHRINK_CELL_Q", 9, 1, 0,
							 0, 0)) {
				func_64(iLocal_1262, iLocal_1263, &uLocal_713, &uLocal_741, &uLocal_987, &uLocal_1015);
				iLocal_48 = 3;
			}
			break;

		case 2:
			if (!mobile::can_phone_be_seen_on_screen()) {
				while (!ui::has_additional_text_loaded(0)) {
					system::wait(0);
				}
				func_63("SHRINK_BROKE", -1);
				iLocal_48 = 5;
			}
			break;

		case 3:
			if (audio::get_current_scripted_conversation_line() > iVar0) {
				iVar0 = audio::get_current_scripted_conversation_line();
			}
			if (func_62()) {
				func_59(&iLocal_71);
				iVar3 = 1;
				iVar0 = -1;
				if (func_52(&iLocal_71, 30f)) {
					func_51(1);
				}
			}
			if (ped::is_ped_jumping_out_of_vehicle(player::player_ped_id()) ||
				entity::is_entity_in_water(player::player_ped_id())) {
				func_47(0);
			}
			if (func_46()) {
				if (!bVar1 && iVar3 && (func_121() == 2 && iVar0 >= 8 || func_121() == 3 && iVar0 >= 10)) {
					iLocal_48 = 4;
				}
				else {
					if (bVar1) {
						while (!ui::has_additional_text_loaded(0)) {
							system::wait(0);
						}
						func_63("SHRINK_BROKE", -1);
					}
					iLocal_48 = 5;
				}
			}
			break;

		case 4:
			func_13(func_41(), 24, func_118(iLocal_70));
			func_11(0, 0);
			func_122();
			break;

		case 5:
			if (!bVar1 || !func_10("SHRINK_BROKE")) {
				func_1(0);
				func_122();
			}
			break;
		}
	}
}

// Position - 0x316
void func_1(int iParam0) {
	int iVar0;

	if (Global_101700.f_8044 || func_9(0)) {
		iVar0 = func_8();
		if (!func_2(iVar0)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
		Global_91527 = iParam0;
	}
}

// Position - 0x35B
int func_2(int iParam0) {
	int iVar0;
	int iVar1;

	func_7();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_6(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_3(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0x472
void func_3(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_5(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_4(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0x63B
void func_4(int *iParam0) { *iParam0 = -15; }

// Position - 0x649
int func_5(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_5(8, uParam1, fParam2);

	case 10: return func_5(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0xFB8
void func_6(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0xFF6
void func_7() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_41()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_41()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x10DD
int func_8() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1112
int func_9(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return 1;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x113D
bool func_10(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x1150
void func_11(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (!Global_55824) {
		Global_55824 = iParam1;
	}
	if (iParam0) {
		if (func_9(0) && Global_69948.f_1 == 1 && func_12(Global_69948)) {
		}
		else {
			Global_55822 = 1;
		}
	}
	if (Global_101700.f_8044 || func_9(0)) {
		iVar0 = func_8();
		iVar1 = Global_82576[iVar0 /*5*/];
		uVar2 = G_TextMessageConfig.f_109[iVar1 /*4*/];
		if (iVar0 == -1) {
			if (Global_101700.f_8044) {
			}
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 4)) {
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 5)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 4);
		gameplay::set_bit(&Global_69950, 1);
		Global_69966 = uVar2;
		Global_69967 = gameplay::get_game_timer();
	}
}

// Position - 0x1226
int func_12(int iParam0) {
	switch (iParam0) {
	case 71: return 1;

	case 86: return 1;

	case 91: return 1;

	default: return 0;
	}
	return 0;
}

// Position - 0x1264
int func_13(int iParam0, int iParam1, int iParam2) {
	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 3) {
		return 0;
	}
	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 4) {
		return 0;
	}
	return func_14(Global_101700.f_27009[iParam0 /*29*/].f_17, 0, iParam1, iParam2, 0);
}

// Position - 0x12AD
int func_14(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	func_40();
	if (iParam3 < 1) {
		return 0;
	}
	fVar0 = 1f;
	switch (iParam1) {
	case 0:
		switch (iParam0) {
		case 0:
			func_39(99, 1);
			func_38(joaat("sp0_money_total_spent"), iParam3);
			break;

		case 1: func_38(joaat("sp1_money_total_spent"), iParam3); break;

		case 2: func_38(joaat("sp2_money_total_spent"), iParam3); break;
		}
		func_22(0);
		switch (iParam2) {
		case 126:
		case 128:
		case 124:
		case 125:
		case 127:
			if (func_21(5)) {
				fVar0 = 0.9f;
				iVar1 = 5;
			}
			break;

		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
			switch (iParam0) {
			case 0: func_38(joaat("sp0_money_spent_on_tattoos"), iParam3); break;

			case 1: func_38(joaat("sp1_money_spent_on_tattoos"), iParam3); break;

			case 2: func_38(joaat("sp2_money_spent_on_tattoos"), iParam3); break;
			}
			if (func_21(1)) {
				fVar0 = 0f;
				iVar1 = 1;
			}
			break;

		case 21:
			switch (iParam0) {
			case 0: func_38(joaat("sp0_money_spent_on_taxis"), iParam3); break;

			case 1: func_38(joaat("sp1_money_spent_on_taxis"), iParam3); break;

			case 2: func_38(joaat("sp2_money_spent_on_taxis"), iParam3); break;
			}
			break;

		case 25:
			switch (iParam0) {
			case 0: func_38(joaat("sp0_money_spent_in_strip_clubs"), iParam3); break;

			case 1: func_38(joaat("sp1_money_spent_in_strip_clubs"), iParam3); break;

			case 2: func_38(joaat("sp2_money_spent_in_strip_clubs"), iParam3); break;
			}
			break;

		case 98:
		case 99:
		case 100:
		case 101:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 112:
			switch (iParam0) {
			case 0: func_38(joaat("sp0_money_spent_property"), iParam3); break;

			case 1: func_38(joaat("sp1_money_spent_property"), iParam3); break;

			case 2: func_38(joaat("sp2_money_spent_property"), iParam3); break;
			}
			break;

		default:
			switch (script::get_hash_of_this_script_name()) {
			case joaat("clothes_shop_sp"):
				switch (iParam0) {
				case 0: func_38(joaat("sp0_money_spent_in_clothes"), iParam3); break;

				case 1: func_38(joaat("sp1_money_spent_in_clothes"), iParam3); break;

				case 2: func_38(joaat("sp2_money_spent_in_clothes"), iParam3); break;
				}
				break;

			case joaat("hairdo_shop_sp"):
				switch (iParam0) {
				case 0: func_38(joaat("sp0_money_spent_on_hairdos"), iParam3); break;

				case 1: func_38(joaat("sp1_money_spent_on_hairdos"), iParam3); break;

				case 2: func_38(joaat("sp2_money_spent_on_hairdos"), iParam3); break;
				}
				if (func_21(0)) {
					fVar0 = 0f;
					iVar1 = 0;
				}
				break;

			case joaat("gunclub_shop"):
				switch (iParam0) {
				case 0: func_38(joaat("sp0_money_spent_in_buying_guns"), iParam3); break;

				case 1: func_38(joaat("sp1_money_spent_in_buying_guns"), iParam3); break;

				case 2: func_38(joaat("sp2_money_spent_in_buying_guns"), iParam3); break;
				}
				break;

			case joaat("carmod_shop"):
				switch (iParam0) {
				case 0: func_38(joaat("sp0_money_spent_car_mods"), iParam3); break;

				case 1: func_38(joaat("sp1_money_spent_car_mods"), iParam3); break;

				case 2: func_38(joaat("sp2_money_spent_car_mods"), iParam3); break;
				}
				func_20(iParam3);
				break;
			}
			break;
		}
		break;

	case 1:
		switch (iParam0) {
		case 0: func_39(95, iParam3); break;

		case 1: func_39(97, iParam3); break;

		case 2: func_39(96, iParam3); break;
		}
		func_39(98, iParam3);
		break;
	}
	iVar2 = iParam0;
	iParam3 = system::floor(fVar0 * system::to_float(iParam3));
	iVar3 = 0;
	iVar4 = iParam3;
	if (fVar0 == 0f) {
		func_17(iVar1);
		return 1;
	}
	else if (fVar0 != 1f) {
		func_17(iVar1);
	}
	iVar5 = Global_52996[iVar2] + iParam3;
	switch (iParam1) {
	case 1:
		if (Global_52996[iVar2] >= 0 && iParam3 > 0) {
			if (iVar5 <= 0) {
				Global_52996[iVar2] = 2147483647;
			}
			else {
				Global_52996[iVar2] += iParam3;
			}
		}
		switch (iParam0) {
		case 0: func_38(joaat("sp0_total_cash_earned"), iParam3); break;

		case 1: func_38(joaat("sp1_total_cash_earned"), iParam3); break;

		case 2: func_38(joaat("sp2_total_cash_earned"), iParam3); break;
		}
		break;

	case 0:
		if (!iParam4) {
			if (Global_52996[iVar2] - iParam3 < 0) {
				return 0;
			}
		}
		iVar3 = Global_52996[iVar2];
		Global_52996[iVar2] -= iParam3;
		if (iParam4) {
			iVar4 = iVar3;
		}
		break;
	}
	if (iParam2 == 1) {
		if (iVar4 > 20) {
		}
	}
	else {
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/] = iParam1;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_1 =
			iParam2;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_2 =
			iParam3;
		Global_101700.f_19523.f_233[iVar2 /*69*/]++;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_1++;
		if (Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 > 10) {
			Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 = 0;
		}
	}
	func_16(iParam0);
	if (Global_35781 == 15) {
		func_15(0);
	}
	return 1;
}

// Position - 0x18AC
void func_15(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x1B2E
void func_16(int iParam0) {
	int iVar0;

	iVar0 = Global_52996[iParam0];
	switch (iParam0) {
	case 0: stats::stat_set_int(joaat("sp0_total_cash"), iVar0, 1); break;

	case 1: stats::stat_set_int(joaat("sp1_total_cash"), iVar0, 1); break;

	case 2: stats::stat_set_int(joaat("sp2_total_cash"), iVar0, 1); break;
	}
}

// Position - 0x1B88
void func_17(int iParam0) {
	bool bVar0;
	char cVar1[64];

	bVar0 = false;
	if (!network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0)) {
			bVar0 = true;
			gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		}
	}
	else if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0) ||
			 gameplay::is_bit_set(Global_2097152[func_19() /*10758*/].f_7546.f_10, iParam0)) {
		bVar0 = true;
		gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		gameplay::clear_bit(&Global_2097152[func_19() /*10758*/].f_7546.f_10, iParam0);
	}
	if (bVar0) {
		StringCopy(&cVar1, "CHAR_LIFEINVADER", 64);
		ui::_set_notification_text_entry("COUP_RED");
		ui::add_text_component_substring_text_label(func_18(iParam0));
		ui::_set_notification_message(&cVar1, &cVar1, 1, 0, "", 0);
	}
}

// Position - 0x1C48
char *func_18(int iParam0) {
	switch (iParam0) {
	case 0: return "COUP_HAIRC";

	case 1: return "COUP_TATTOO";

	case 2: return "COUP_WARSTOCK";

	case 3: return "COUP_MOSPORT";

	case 4: return "COUP_ELITAS";

	case 5: return "COUP_MEDSPENS";

	case 6: return "COUP_SPRUNK";

	case 7: return "COUP_RESPRAY";

	default:
	}
	return "";
}

// Position - 0x1CBA
int func_19() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x1CC7
void func_20(int iParam0) {
	func_39(93, iParam0);
	func_39(29, iParam0);
	func_39(30, iParam0);
}

// Position - 0x1CE7
bool func_21(int iParam0) {
	if (!network::network_is_game_in_progress()) {
		return gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0);
	}
	return gameplay::is_bit_set(Global_2097152[func_19() /*10758*/].f_7546.f_10, iParam0);
}

// Position - 0x1D23
int func_22(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (player::has_achievement_been_passed(27)) {
		return 0;
	}
	if (stats::stat_get_int(joaat("sp0_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp1_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp2_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (iParam0) {
	}
	iVar2 = 0;
	stats::stat_get_int(joaat("num_cash_spent"), &iVar2, -1);
	if (iVar1 > 0 && iVar2 / 2000000 != iVar1 / 2000000) {
		stats::stat_set_int(joaat("num_cash_spent"), iVar1, 1);
		func_37(27, iVar1);
	}
	if (iVar1 < 200000000) {
		return 0;
	}
	func_23(27, 1);
	return 1;
}

// Position - 0x1DDA
int func_23(int iParam0, int iParam1) {
	if (iParam0 >= 70) {
		return 0;
	}
	return func_24(iParam0, iParam1);
}

// Position - 0x1DF5
int func_24(int iParam0, int iParam1) {
	if (func_36(14) && !func_35(iParam0)) {
		return 0;
	}
	if (player::has_achievement_been_passed(iParam0) && iParam1 == 1) {
		return 0;
	}
	if (Global_25436 != 0 && !Global_69702) {
		return 0;
	}
	if (func_34(&Global_2595550)) {
		if (func_32(&Global_2595550, iParam0)) {
			return 0;
		}
		if (func_25(&Global_2595550, iParam0)) {
			return 1;
		}
	}
	else {
		if (!player::give_achievement_to_player(iParam0)) {
			return 0;
		}
		if (player::has_achievement_been_passed(iParam0)) {
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x1E92
bool func_25(var *uParam0, int iParam1) {
	int iVar0;
	var *uVar1[70];

	if (player::has_achievement_been_passed(iParam1)) {
		return false;
	}
	if (func_36(14) && !func_35(iParam1)) {
		return false;
	}
	if (func_32(uParam0, iParam1)) {
		return false;
	}
	if (func_31(uParam0) < 0f) {
		func_30(uParam0, 0);
	}
	func_28(&uVar1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0 - 1) {
		uVar1[iVar0 + 1] = (*uParam0)[iVar0];
		iVar0++;
	}
	func_26(&uVar1, iParam1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = uVar1[iVar0];
		iVar0++;
	}
	return true;
}

// Position - 0x1F43
int func_26(var *uParam0, int iParam1) {
	int iVar0;

	if (player::has_achievement_been_passed(iParam1)) {
		return 0;
	}
	if (func_36(14) && !func_35(iParam1)) {
		return 0;
	}
	if (func_32(uParam0, iParam1)) {
		return 0;
	}
	if (func_31(uParam0) < 0f) {
		func_30(uParam0, 0);
	}
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (func_27(uParam0, iVar0)) {
			(*uParam0)[iVar0] = iParam1;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1FBE
bool func_27(var *uParam0, int iParam1) { return (*uParam0)[iParam1] == 70; }

// Position - 0x1FCF
void func_28(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		func_29(uParam0, iVar0);
		iVar0++;
	}
	func_30(uParam0, Global_2595549 - 0.5f);
}

// Position - 0x2003
void func_29(var *uParam0, int iParam1) { (*uParam0)[iParam1] = 70; }

// Position - 0x2013
void func_30(var *uParam0, float fParam1) {
	if (fParam1 == 0f) {
		uParam0->f_72 = 0f;
	}
	else {
		uParam0->f_72 = fParam1;
	}
}

// Position - 0x2030
float func_31(var *uParam0) { return uParam0->f_72; }

// Position - 0x203C
bool func_32(var *uParam0, int iParam1) { return func_33(uParam0, iParam1) != -1; }

// Position - 0x204E
int func_33(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x207B
bool func_34(var *uParam0) { return uParam0->f_71 == 1; }

// Position - 0x2089
int func_35(int iParam0) {
	switch (iParam0) {
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69: return 1;

	default:
	}
	return 0;
}

// Position - 0x20D9
bool func_36(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x20E7
int func_37(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x2138
void func_38(int iParam0, int iParam1) {
	int iVar0;

	stats::stat_get_int(iParam0, &iVar0, -1);
	iVar0 += iParam1;
	stats::stat_set_int(iParam0, iVar0, 1);
}

// Position - 0x215B
void func_39(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 < 1) {
		return;
	}
	if (Global_51564[iParam0 /*7*/].f_2) {
		return;
	}
	if (network::network_is_game_in_progress()) {
		return;
	}
	if (Global_51564[iParam0 /*7*/]) {
		stats::stat_get_int(Global_51564[iParam0 /*7*/].f_1, &iVar0, -1);
		iVar0 += iParam1;
		stats::stat_set_int(Global_51564[iParam0 /*7*/].f_1, iVar0, 1);
	}
}

// Position - 0x21B8
void func_40() {
	int iVar0;

	if (network::network_is_signed_in()) {
		stats::stat_get_int(joaat("sp0_total_cash"), &iVar0, -1);
		if (Global_52996[0] != iVar0) {
			Global_52996[0] = iVar0;
		}
		stats::stat_get_int(joaat("sp1_total_cash"), &iVar0, -1);
		if (Global_52996[1] != iVar0) {
			Global_52996[1] = iVar0;
		}
		stats::stat_get_int(joaat("sp2_total_cash"), &iVar0, -1);
		if (Global_52996[2] != iVar0) {
			Global_52996[2] = iVar0;
		}
	}
}

// Position - 0x222D
int func_41() {
	func_42();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x2246
void func_42() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_45(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_44(player::player_ped_id());
			if (func_43(iVar0) && (!func_36(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_43(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x2343
bool func_43(int iParam0) { return iParam0 < 3; }

// Position - 0x234F
int func_44(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_45(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x238C
int func_45(int iParam0) {
	if (func_43(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x23B6
bool func_46() {
	if (Global_15745 == 0) {
		return true;
	}
	return false;
}

// Position - 0x23CD
void func_47(int iParam0) {
	if (Global_14604) {
		func_49(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_48()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x243D
bool func_48() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x2464
void func_49(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_50(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x24D8
bool func_50(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x2532
void func_51(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 24);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 24);
	}
}

// Position - 0x2555
bool func_52(int *iParam0, float fParam1) {
	if (func_54(iParam0, fParam1)) {
		func_53(iParam0);
		return true;
	}
	return false;
}

// Position - 0x2573
void func_53(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x2589
bool func_54(var *uParam0, float fParam1) {
	if (func_58(uParam0)) {
		if (func_55(uParam0) > fParam1) {
			return true;
		}
	}
	return false;
}

// Position - 0x25AB
float func_55(var *uParam0) {
	if (func_58(uParam0)) {
		if (func_57(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_56(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x25EA
float func_56(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x2642
bool func_57(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x2652
bool func_58(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x2662
void func_59(var *uParam0) {
	if (!func_58(uParam0)) {
		func_60(uParam0);
	}
}

// Position - 0x267A
void func_60(var *uParam0) { func_61(uParam0, 0f); }

// Position - 0x2689
void func_61(int *iParam0, float fParam1) {
	uParam0->f_1 = func_56(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x26B7
bool func_62() {
	if (gameplay::is_bit_set(G_SleepModeOffOn11, 23)) {
		if (Global_15798 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0x26E1
void func_63(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x26F8
int func_64(int iParam0, int iParam1, var *uParam2, var *uParam3, var *uParam4, var *uParam5) {
	int iVar0;
	int iVar1;

	if (gameplay::is_bit_set(G_SleepModeOffOn11, 9)) {
		return 0;
	}
	gameplay::set_bit(&G_SleepModeOffOn11, 9);
	Global_16729 = iParam0;
	iVar0 = 0;
	while (iVar0 < iParam0 + 1) {
		StringCopy(&Global_16004[iVar0 /*6*/], (*uParam2)[iVar0], 24);
		StringCopy(&Global_16366[iVar0 /*6*/], (*uParam3)[iVar0], 24);
		iVar0++;
	}
	Global_16728 = iParam1;
	iVar1 = 0;
	while (iVar1 < iParam1 + 1) {
		StringCopy(&Global_16185[iVar1 /*6*/], (*uParam4)[iVar1], 24);
		StringCopy(&Global_16547[iVar1 /*6*/], (*uParam5)[iVar1], 24);
		iVar1++;
	}
	return 1;
}

// Position - 0x278D
bool func_65(int iParam0, var *uParam1, int iParam2, char *sParam3, var *uParam4, var *uParam5, char *sParam6,
			 int iParam7, int iParam8, int iParam9, int iParam10, int iParam11) {
	func_76(uParam1, iParam2, sParam3, iParam9, iParam10, 0);
	func_75();
	if (iParam8 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	func_74(iParam0);
	Global_15797 = 1;
	StringCopy(&Global_15893, sParam6, 24);
	Global_15744 = 3;
	return func_66(uParam4, uParam5, iParam7, iParam11);
}

// Position - 0x27DA
int func_66(var *uParam0, var *uParam1, int iParam2, bool bParam3) {
	int iVar0;

	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam2 > Global_15747) {
				if (bParam3 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
				}
				else {
					func_73();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_72(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_71();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16741 = Global_16742;
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15364.f_370 = Global_16734;
		Global_15741 = Global_15742;
		Global_15743 = Global_15744;
		if (Global_16003 == 0) {
			Global_15899[0 /*6*/] = {Global_15925[0 /*6*/]};
			Global_15899[1 /*6*/] = {Global_15925[1 /*6*/]};
			Global_15951[0 /*6*/] = {Global_15977[0 /*6*/]};
			Global_15951[1 /*6*/] = {Global_15977[1 /*6*/]};
			Global_15912[0 /*6*/] = {Global_15938[0 /*6*/]};
			Global_15912[1 /*6*/] = {Global_15938[1 /*6*/]};
			Global_15964[0 /*6*/] = {Global_15990[0 /*6*/]};
			Global_15964[1 /*6*/] = {Global_15990[1 /*6*/]};
		}
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (bParam3) {
				func_70();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam2 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_69()) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (Global_16003 == 0) {
						if (entity::is_entity_in_water(player::player_ped_id())) {
							return 0;
						}
						if (player::is_player_climbing(player::player_id())) {
							return 0;
						}
						if (ped::is_ped_planting_bomb(player::player_ped_id())) {
							return 0;
						}
						if (player::is_special_ability_active(player::player_id())) {
							return 0;
						}
					}
				}
			}
			if (func_48()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
			}
			func_68();
			Global_15755 = bParam3;
		}
		Global_15747 = iParam2;
		if (Global_15741 > 0) {
			iVar0 = 0;
			while (iVar0 < Global_15741) {
				StringCopy(&Global_15364.f_6[iVar0 /*6*/], (*uParam0)[iVar0], 24);
				StringCopy(&Global_15364.f_187[iVar0 /*6*/], (*uParam1)[iVar0], 24);
				iVar0++;
			}
		}
		Global_14611 = 0;
		func_67();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam2 < Global_15747 || iParam2 == Global_15747) {
		return 0;
	}
	if (iParam2 == 2) {
	}
	else {
		func_73();
	}
	return 0;
}

// Position - 0x2B44
void func_67() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x2B75
void func_68() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x2C0A
bool func_69() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x2CA3
void func_70() {
	if (func_36(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_41();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x2D45
void func_71() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x2D9C
bool func_72(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x2DD7
void func_73() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x2E2E
void func_74(var uParam0) {
	Global_15742 = uParam0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
}

// Position - 0x2E54
void func_75() {
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_15759 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
}

// Position - 0x2E8D
void func_76(var *uParam0, var uParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = uParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x2EE3
int func_77(int iParam0, var *uParam1, int iParam2, char *sParam3, var *uParam4, var *uParam5, int iParam6, int iParam7,
			int iParam8, int iParam9, int iParam10) {
	func_76(uParam1, iParam2, sParam3, iParam8, iParam9, 0);
	func_75();
	if (iParam7 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	func_74(iParam0);
	return func_66(uParam4, uParam5, iParam6, iParam10);
}

// Position - 0x2F21
void func_78(var *uParam0, var *uParam1, var *uParam2, int *iParam3, var *uParam4, var *uParam5, int *iParam6,
			 var *uParam7, var *uParam8, int *iParam9, var *uParam10, int iParam11) {
	int iVar0;
	struct<4> Var1;
	int *iVar5;
	int *iVar6;
	int iVar7;

	ui::request_additional_text("SHRINK", 0);
	ui::request_additional_text("DrfAud", 6);
	while (!ui::has_additional_text_loaded(0) || !ui::has_additional_text_loaded(6)) {
		system::wait(0);
	}
	func_111(uParam0, 0, player::player_ped_id(), "MICHAEL", 0, 1);
	func_111(uParam0, 1, 0, "FRIEDLANDER", 0, 1);
	func_110(uParam1, uParam2, iParam3, iParam11);
	Var1 = {func_106(iParam11, &iVar5, &iVar6, 1)};
	iVar0 = func_105(&Var1);
	func_101(uParam1, uParam2, iParam3, iVar0);
	func_100(uParam1, uParam2, iParam3, iParam11);
	func_93(uParam1, uParam2, iParam3, iParam11);
	func_92(uParam4, uParam5, uParam7, uParam8, iParam6, iParam9, iParam11);
	func_82(uParam4, uParam5, uParam7, uParam8, iParam6, iParam9, uParam10, iParam11);
	func_81(uParam4, uParam5, uParam7, uParam8, iParam6, iParam9, uParam10);
	func_79(uParam4, uParam5, uParam7, uParam8, iParam6, iParam9, iParam11);
	iVar7 = 0;
	while (iVar7 < 47) {
		if (gameplay::is_string_null_or_empty(&(*uParam1)[iVar7 /*4*/])) {
			iVar7 = 47;
		}
		iVar7++;
	}
	iVar7 = 0;
	while (iVar7 < 27) {
		if (gameplay::is_string_null_or_empty(&(*uParam4)[iVar7 /*4*/])) {
			iVar7 = 27;
		}
		iVar7++;
	}
	iVar7 = 0;
	while (iVar7 < 27) {
		if (gameplay::is_string_null_or_empty(&(*uParam7)[iVar7 /*4*/])) {
			iVar7 = 27;
		}
		iVar7++;
	}
}

// Position - 0x3078
void func_79(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int *iParam4, int *iParam5, int iParam6) {
	struct<2> Var0;
	int iVar4;
	int iVar5;

	switch (iParam6) {
	case 2:
		StringCopy(&Var0, "DRF_3", 16);
		iVar4 = 17;
		iVar5 = 7;
		break;

	case 3:
		StringCopy(&Var0, "DRF_4", 16);
		iVar4 = 6;
		iVar5 = 17;
		break;

	default: break;
	}
	func_80(uParam0, uParam1, iParam4, &Var0, iVar4, iVar5, 0);
	func_80(uParam2, uParam3, iParam5, &Var0, iVar4, iVar5, 0);
}

// Position - 0x30DB
void func_80(var *uParam0, var *uParam1, int *iParam2, char *sParam3, int iParam4, int iParam5, int iParam6) {
	struct<4> Var0;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar4 = iParam4;
	while (iVar4 <= iParam4 + iParam5 - 1) {
		StringCopy(&Var0, sParam3, 16);
		StringConCat(&Var0, "_", 16);
		if (iVar4 < 9 && iParam6) {
			StringConCat(&Var0, "0", 16);
		}
		StringIntConCat(&Var0, iVar4 + 1, 16);
		if (ui::does_text_label_exist(&Var0)) {
			iVar5 = *iParam2 + iVar6;
			StringCopy(&(*uParam0)[iVar5 /*4*/], sParam3, 16);
			(*uParam1)[iVar5 /*4*/] = {Var0};
			iVar6++;
		}
		iVar4++;
	}
	*iParam2 += iVar6;
}

// Position - 0x3162
void func_81(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int *iParam4, int *iParam5, var *uParam6) {
	int iVar0;

	switch (uParam6->f_19) {
	case 1:
		switch (gameplay::get_random_int_in_range(0, 4)) {
		case 0: iVar0 = 6; break;

		case 1: iVar0 = 7; break;

		case 2: iVar0 = 8; break;

		case 3: iVar0 = 9; break;
		}
		break;

	case 2:
	case 4:
		switch (gameplay::get_random_int_in_range(0, 3)) {
		case 0: iVar0 = 6; break;

		case 1: iVar0 = 7; break;

		case 2: iVar0 = 9; break;
		}
		break;

	case 3:
		switch (gameplay::get_random_int_in_range(0, 4)) {
		case 0: iVar0 = 2; break;

		case 1: iVar0 = 6; break;

		case 2: iVar0 = 7; break;

		case 3: iVar0 = 9; break;
		}
		break;

	case 5:
	case 6:
		switch (gameplay::get_random_int_in_range(0, 4)) {
		case 0: iVar0 = 3; break;

		case 1: iVar0 = 6; break;

		case 2: iVar0 = 7; break;

		case 3: iVar0 = 9; break;
		}
		break;

	case 7:
		switch (gameplay::get_random_int_in_range(0, 6)) {
		case 0: iVar0 = 2; break;

		case 1: iVar0 = 4; break;

		case 2: iVar0 = 6; break;

		case 3: iVar0 = 7; break;

		case 4: iVar0 = 8; break;

		case 5: iVar0 = 9; break;
		}
		break;

	case 8:
	case 9:
	case 11:
		switch (gameplay::get_random_int_in_range(0, 8)) {
		case 0: iVar0 = 2; break;

		case 1: iVar0 = 3; break;

		case 2: iVar0 = 4; break;

		case 3: iVar0 = 6; break;

		case 4: iVar0 = 7; break;

		case 5: iVar0 = 8; break;

		case 6: iVar0 = 9; break;

		case 7: iVar0 = 11; break;
		}
		break;

	case 10:
		switch (gameplay::get_random_int_in_range(0, 7)) {
		case 0: iVar0 = 3; break;

		case 1: iVar0 = 4; break;

		case 2: iVar0 = 6; break;

		case 3: iVar0 = 7; break;

		case 4: iVar0 = 8; break;

		case 5: iVar0 = 9; break;

		case 6: iVar0 = 11; break;
		}
		break;

	case 12:
		switch (gameplay::get_random_int_in_range(0, 4)) {
		case 0: iVar0 = 6; break;

		case 1: iVar0 = 7; break;

		case 2: iVar0 = 9; break;

		case 3: iVar0 = 11; break;
		}
		break;
	}
	func_80(uParam0, uParam1, iParam4, "PMCSUM", iVar0 - 1, 1, 0);
	func_80(uParam2, uParam3, iParam5, "PMCSUM", iVar0 - 1, 1, 0);
}

// Position - 0x3443
void func_82(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int *iParam4, int *iParam5, var *uParam6,
			 int iParam7) {
	struct<4> Var0;
	int iVar4;
	int iVar5;

	switch (iParam7) {
	case 2: iVar4 = 1; break;

	case 3: iVar4 = 3; break;
	}
	func_80(uParam0, uParam1, iParam4, "DRF_SEX", iVar4, 1, 0);
	func_80(uParam2, uParam3, iParam5, "DRF_SEX", iVar4, 1, 0);
	Var0 = {func_83(uParam6, &iVar5, iParam7, 1)};
	func_80(uParam0, uParam1, iParam4, &Var0, 0, iVar5, 0);
	func_80(uParam2, uParam3, iParam5, &Var0, 0, iVar5, 0);
}

// Position - 0x34BD
struct<4> func_83(var *uParam0, int *iParam1, int iParam2, int iParam3) {
	struct<4> Var0;
	int iVar4;

	if (func_91() <= 0) {
		if (!func_90()) {
			iVar4 = func_87(1, 2, 3, 4, 12);
		}
		else if (func_86() >= 1) {
			iVar4 = func_87(5, 6, 7, 0, 0);
		}
		else {
			iVar4 = func_87(5, 7, 0, 0, 0);
		}
	}
	else if (func_91() >= 2) {
		iVar4 = func_87(10, 11, 0, 0, 0);
	}
	else if (!func_90()) {
		if (iParam2 != 4) {
			iVar4 = func_87(8, 9, 0, 0, 0);
		}
		else {
			iVar4 = 9;
		}
	}
	else if (iParam2 != 4) {
		iVar4 = func_87(8, 9, 10, 0, 0);
	}
	else {
		iVar4 = func_87(9, 10, 0, 0, 0);
	}
	func_85(uParam0, iVar4);
	if (iParam3) {
		func_84(&Global_101700.f_18920, iVar4, 1);
	}
	StringCopy(&Var0, "DRF_PR_", 16);
	switch (iVar4) {
	case 1:
		StringConCat(&Var0, "1_A", 16);
		*iParam1 = 3;
		break;

	case 2:
		StringConCat(&Var0, "1_B", 16);
		*iParam1 = 5;
		break;

	case 3:
		StringConCat(&Var0, "1_C", 16);
		*iParam1 = 3;
		break;

	case 4:
		StringConCat(&Var0, "1_D", 16);
		*iParam1 = 3;
		break;

	case 5:
		StringConCat(&Var0, "1_STR", 16);
		*iParam1 = 3;
		break;

	case 6:
		StringConCat(&Var0, "5_T1B", 16);
		*iParam1 = 5;
		break;

	case 7:
		StringCopy(&Var0, "5_T1C", 16);
		*iParam1 = 4;
		break;

	case 8:
		StringConCat(&Var0, "5PROA", 16);
		*iParam1 = 5;
		break;

	case 9:
		StringConCat(&Var0, "5PROB", 16);
		*iParam1 = 5;
		break;

	case 10:
		StringConCat(&Var0, "5STRA", 16);
		*iParam1 = 7;
		break;

	case 11:
		StringConCat(&Var0, "5STRB", 16);
		*iParam1 = 4;
		break;

	case 12:
		StringConCat(&Var0, "5_NON", 16);
		*iParam1 = 5;
		break;
	}
	return Var0;
}

//Position - 0x368E
void func_84(var* uParam0, int iParam1, int iParam2)
{
	if (iParam1 < 0 || iParam1 > 12) {
		return;
	}
	iParam1 += 11;
	if (iParam2) {
		gameplay::set_bit(&uParam0->f_1, iParam1);
	}
	else {
		gameplay::clear_bit(&uParam0->f_1, iParam1);
	}
}

// Position - 0x36CD
void func_85(var *uParam0, int iParam1) { uParam0->f_19 = iParam1; }

// Position - 0x36DB
int func_86() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 1) {
		if (Global_88289[iVar0] > 0) {
			iVar1++;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x3709
int func_87(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2[13];

	iVar0 = 0;
	while (iVar0 < 13) {
		iVar2[iVar0] = iVar0;
		iVar0++;
	}
	if (iParam0 > 0 && iParam0 < 13 && !func_89(&Global_101700.f_18920, iParam0)) {
		iVar2[iParam0] = 0;
	}
	else if (iParam1 > 0 && iParam1 < 13 && !func_89(&Global_101700.f_18920, iParam1)) {
		iVar2[iParam1] = 0;
	}
	else if (iParam2 > 0 && iParam2 < 13 && !func_89(&Global_101700.f_18920, iParam2)) {
		iVar2[iParam2] = 0;
	}
	else if (iParam3 > 0 && iParam3 < 13 && !func_89(&Global_101700.f_18920, iParam3)) {
		iVar2[iParam3] = 0;
	}
	else if (iParam4 > 0 && iParam4 < 13 && !func_89(&Global_101700.f_18920, iParam4)) {
		iVar2[iParam4] = 0;
	}
	iVar1 = func_88(&iVar2, 13, 1, 13);
	if (iVar1 > 0) {
		return iVar1;
	}
	if (iParam2 <= 0 || iParam2 >= 13) {
		iVar1 = gameplay::get_random_int_in_range(1, 3);
	}
	else if (iParam3 <= 0 || iParam3 >= 13) {
		iVar1 = gameplay::get_random_int_in_range(1, 4);
	}
	else if (iParam4 <= 0 || iParam4 >= 13) {
		iVar1 = gameplay::get_random_int_in_range(1, 5);
	}
	else {
		iVar1 = gameplay::get_random_int_in_range(1, 6);
	}
	switch (iVar1) {
	case 1: return iParam0;

	case 2: return iParam1;

	case 3: return iParam2;

	case 4: return iParam3;

	case 5: return iParam4;

	default:
	}
	return 0;
}

// Position - 0x38CB
int func_88(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = 1;
	iVar2 = 0;
	while (iVar0 && iVar2 < 50) {
		iVar0 = 0;
		iVar3 = gameplay::get_random_int_in_range(0, 50000) % (iParam3 - iParam2) + iParam2;
		iVar1 = 0;
		while (iVar1 <= iParam1 - 1) {
			if ((*iParam0)[iVar1] == iVar3) {
				iVar0 = 1;
				iVar1 = 999999;
			}
			iVar1++;
		}
		iVar2++;
	}
	if (iVar2 == 50) {
		return -1;
	}
	return iVar3;
}

// Position - 0x393E
int func_89(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 12) {
		return 0;
	}
	iParam1 += 11;
	return gameplay::is_bit_set(uParam0->f_1, iParam1);
}

// Position - 0x396C
bool func_90() { return Global_88291 > 0; }

// Position - 0x397A
int func_91() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 2) {
		if (Global_88286[iVar0] > 0) {
			iVar1++;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x39A8
void func_92(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int *iParam4, int *iParam5, int iParam6) {
	int iVar0;
	int iVar1;

	switch (iParam6) {
	case 2:
		iVar0 = 3;
		iVar1 = 1;
		break;

	case 3:
		iVar0 = 0;
		iVar1 = 3;
		break;
	}
	func_80(uParam0, uParam1, iParam4, "DRF_ACC", iVar0, 1, 0);
	func_80(uParam2, uParam3, iParam5, "DRF_DEN", iVar1, 1, 0);
}

// Position - 0x39F9
void func_93(var *uParam0, var *uParam1, int *iParam2, int iParam3) {
	struct<4> Var0;
	int iVar4;
	int iVar5;

	switch (iParam3) {
	case 2: iVar4 = 2; break;

	case 3: iVar4 = 3; break;
	}
	func_80(uParam0, uParam1, iParam2, "DRF_OPW", iVar4, 1, 0);
	Var0 = {func_94(iParam3, 0, 1, &iVar5)};
	func_80(uParam0, uParam1, iParam2, &Var0, 0, iVar5, 0);
}

// Position - 0x3A50
struct<4> func_94(int iParam0, int iParam1, int iParam2, int *iParam3) {
	struct<4> Var0;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;

	if (!func_99(&Global_101700.f_18920, 8) && iParam1 && iParam0 != 4 && func_97(3) > 0 &&
		gameplay::get_random_float_in_range(0f, 1f) < 0.75f) {
		iVar4 = 8;
		*iParam3 = 4;
	}
	else {
		if (!func_99(&Global_101700.f_18920, 1) && func_97(5) > 0) {
			gameplay::set_bit(&iVar5, 1);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 2) && func_97(7) >= 2) {
			gameplay::set_bit(&iVar5, 2);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 3) && (func_97(8) > 0 || func_97(9) > 0) && func_97(7) > 0 && iParam1 &&
			iParam0 != 4) {
			gameplay::set_bit(&iVar5, 3);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 4) && func_97(1) > 0 && func_97(1) < 3) {
			gameplay::set_bit(&iVar5, 4);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 5) && func_97(1) >= 3) {
			gameplay::set_bit(&iVar5, 5);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 6) && func_97(0) > 0) {
			gameplay::set_bit(&iVar5, 6);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 7)) {
			gameplay::set_bit(&iVar5, 7);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 8) && iParam1 && func_97(3) > 0 && iParam0 != 4) {
			gameplay::set_bit(&iVar5, 8);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 9)) {
			gameplay::set_bit(&iVar5, 9);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 10)) {
			gameplay::set_bit(&iVar5, 10);
			iVar6++;
		}
		if (!func_99(&Global_101700.f_18920, 11)) {
			gameplay::set_bit(&iVar5, 11);
			iVar6++;
		}
		if (iVar6 <= 0) {
			if (iParam0 != 4) {
				iVar4 = func_96(7, 9, 10, 11, 0);
			}
			else {
				iVar4 = func_96(7, 9, 10, 0, 0);
			}
		}
		else {
			iVar7 = gameplay::get_random_int_in_range(1, iVar6 + 1);
			iVar8 = 1;
			while (iVar7 > 0) {
				if (gameplay::is_bit_set(iVar5, iVar8)) {
					iVar7--;
					if (iVar7 == 0) {
						iVar4 = iVar8;
					}
				}
				iVar8++;
			}
		}
		switch (iVar4) {
		case 1: *iParam3 = 5; break;

		case 2: *iParam3 = 5; break;

		case 3: *iParam3 = 7; break;

		case 4: *iParam3 = 4; break;

		case 5: *iParam3 = 4; break;

		case 6: *iParam3 = 5; break;

		case 7: *iParam3 = 4; break;

		case 8: *iParam3 = 4; break;

		case 9: *iParam3 = 4; break;

		case 10: *iParam3 = 5; break;

		case 11: *iParam3 = 7; break;
		}
	}
	if (iParam2) {
		func_95(&Global_101700.f_18920, iVar4, 1);
	}
	StringCopy(&Var0, "DRF_OWR_", 16);
	if (iVar4 >= 1 && iVar4 <= 3) {
		StringIntConCat(&Var0, iVar4, 16);
	}
	else if (iVar4 < 7) {
		StringIntConCat(&Var0, 4, 16);
		if (iVar4 == 4) {
			StringConCat(&Var0, "A", 16);
		}
		else if (iVar4 == 5) {
			StringConCat(&Var0, "B", 16);
		}
		else {
			StringConCat(&Var0, "C", 16);
		}
	}
	else {
		StringIntConCat(&Var0, 7, 16);
		if (iVar4 == 7) {
			StringConCat(&Var0, "A", 16);
		}
		else if (iVar4 == 8) {
			StringConCat(&Var0, "B", 16);
		}
		else if (iVar4 == 9) {
			StringConCat(&Var0, "C", 16);
		}
		else if (iVar4 == 10) {
			StringConCat(&Var0, "D", 16);
		}
		else {
			StringConCat(&Var0, "E", 16);
		}
	}
	return Var0;
}

//Position - 0x3E43
void func_95(var* uParam0, int iParam1, int iParam2)
{
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&uParam0->f_1, iParam1);
	}
	else {
		gameplay::clear_bit(&uParam0->f_1, iParam1);
	}
}

// Position - 0x3E7C
int func_96(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2[12];
	int iVar15;

	iVar0 = 0;
	while (iVar0 < 12) {
		iVar2[iVar0] = iVar0;
		iVar0++;
	}
	if (iParam0 > 0 && iParam0 < 12 && !func_99(&Global_101700.f_18920, iParam0)) {
		iVar2[iParam0] = 0;
		iVar15 = 1;
	}
	if (iParam1 > 0 && iParam1 < 12 && !func_99(&Global_101700.f_18920, iParam1)) {
		iVar2[iParam1] = 0;
		iVar15 = 1;
	}
	if (iParam2 > 0 && iParam2 < 12 && !func_99(&Global_101700.f_18920, iParam2)) {
		iVar2[iParam2] = 0;
		iVar15 = 1;
	}
	if (iParam3 > 0 && iParam3 < 12 && !func_99(&Global_101700.f_18920, iParam3)) {
		iVar2[iParam3] = 0;
		iVar15 = 1;
	}
	if (iParam4 > 0 && iParam4 < 12 && !func_99(&Global_101700.f_18920, iParam4)) {
		iVar2[iParam4] = 0;
		iVar15 = 1;
	}
	if (!iVar15) {
		if (iParam0 > 0 && iParam0 < 12) {
			iVar2[iParam0] = 0;
		}
		if (iParam1 > 0 && iParam1 < 12) {
			iVar2[iParam1] = 0;
		}
		if (iParam2 > 0 && iParam2 < 12) {
			iVar2[iParam2] = 0;
		}
		if (iParam3 > 0 && iParam3 < 12) {
			iVar2[iParam3] = 0;
		}
		if (iParam4 > 0 && iParam4 < 12) {
			iVar2[iParam4] = 0;
		}
	}
	iVar1 = func_88(&iVar2, 12, 1, 12);
	if (iVar1 > 0) {
		return iVar1;
	}
	iVar1 = gameplay::get_random_int_in_range(1, 3);
	switch (iVar1) {
	case 1: return iParam0;

	case 2: return iParam1;

	default:
	}
	return 0;
}

// Position - 0x4048
int func_97(int iParam0) {
	switch (iParam0) {
	case 0: return func_98(&Global_88292, 1);

	case 1: return func_98(&Global_88294, 3);

	case 2: return func_98(&Global_88298, 1);

	case 3: return func_98(&Global_88300, 1);

	case 4: return func_98(&Global_88302, 1);

	case 5: return func_98(&Global_88304, 1);

	case 6: return func_98(&Global_88306, 1);

	case 7: return func_98(&Global_88308, 2);

	case 8: return func_98(&Global_88311, 1);

	case 9: return func_98(&Global_88313, 1);
	}
	return 0;
}

// Position - 0x412A
int func_98(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < iParam1) {
		if ((*uParam0)[iVar0] > 0) {
			iVar1++;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x4157
int func_99(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return 0;
	}
	return gameplay::is_bit_set(uParam0->f_1, iParam1);
}

// Position - 0x417F
void func_100(var *uParam0, var *uParam1, int *iParam2, int iParam3) {
	struct<4> Var0;
	int iVar4;
	int iVar5;

	Var0 = {func_106(iParam3, &iVar4, &iVar5, 1)};
	func_80(uParam0, uParam1, iParam2, &Var0, iVar4, iVar5, 0);
}

// Position - 0x41A7
void func_101(var *uParam0, var *uParam1, int *iParam2, int iParam3) {
	if (iParam3 == 0) {
		func_80(uParam0, uParam1, iParam2, "DRF_OVG", gameplay::get_random_int_in_range(1, 3), 1, 0);
		func_80(uParam0, uParam1, iParam2, "DRF_TMG", func_103(func_104(), 0, 2), 1, 0);
	}
	else if (iParam3 == 1) {
		func_80(uParam0, uParam1, iParam2, "DRF_OVO", gameplay::get_random_int_in_range(1, 3), 1, 0);
		func_102(uParam0, uParam1, iParam2, "PDRTMO", 3);
	}
	else {
		func_80(uParam0, uParam1, iParam2, "DRF_OVB", 0, 1, 0);
		func_80(uParam0, uParam1, iParam2, "DRF_TMB", 2, 1, 0);
	}
}

// Position - 0x4238
void func_102(var *uParam0, var *uParam1, int *iParam2, char *sParam3, int iParam4) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(1, iParam4 + 1);
	StringCopy(&(*uParam0)[*iParam2 /*4*/], sParam3, 16);
	StringCopy(&(*uParam1)[*iParam2 /*4*/], sParam3, 16);
	StringConCat(&(*uParam1)[*iParam2 /*4*/], "_", 16);
	if (iVar0 < 10) {
		StringConCat(&(*uParam1)[*iParam2 /*4*/], "0", 16);
	}
	StringIntConCat(&(*uParam1)[*iParam2 /*4*/], iVar0, 16);
	*iParam2++;
}

// Position - 0x4295
int func_103(int iParam0, int iParam1, int iParam2) {
	if (iParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x42AC
int func_104() {
	if (gameplay::is_bit_set(gameplay::get_random_int_in_range(0, 65535), 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x42CD
int func_105(char *sParam0) {
	int iVar0;

	iVar0 = 2;
	if (gameplay::is_string_null_or_empty(sParam0)) {
		return iVar0;
	}
	if (gameplay::are_strings_equal(sParam0, "DRF_SOL1")) {
		iVar0 = 1;
	}
	else if (gameplay::are_strings_equal(sParam0, "DRF_EXILE")) {
		iVar0 = 2;
	}
	else if (gameplay::are_strings_equal(sParam0, "DRF_SOL2")) {
		iVar0 = 1;
	}
	else if (gameplay::are_strings_equal(sParam0, "DRF_MIC2")) {
		iVar0 = 1;
	}
	return iVar0;
}

// Position - 0x4331
struct<4> func_106(int iParam0, int *iParam1, int *iParam2, int iParam3) {
	struct<4> Var0;

	if (func_109(59) && !func_109(45)) {
		if (iParam0 == 2) {
			StringCopy(&Var0, "DRF_SOL1", 16);
			*iParam1 = 0;
			*iParam2 = 19;
			if (iParam3) {
				func_108(&Global_101700.f_18920, 6);
			}
		}
	}
	else if (func_109(14) && !func_109(16)) {
		StringCopy(&Var0, "DRF_EXILE", 16);
		*iParam1 = 0;
		*iParam2 = 9;
		if (iParam3) {
			func_108(&Global_101700.f_18920, 7);
		}
	}
	else if (func_109(16) && !func_109(39)) {
		StringCopy(&Var0, "DRF_EXILE", 16);
		*iParam1 = 9;
		*iParam2 = 10;
		if (iParam3) {
			func_108(&Global_101700.f_18920, 8);
		}
	}
	else if (func_109(39) && !func_109(47) && !func_107(518202687)) {
		StringCopy(&Var0, "DRF_SOL2", 16);
		*iParam1 = 0;
		*iParam2 = 15;
		if (iParam3) {
			func_108(&Global_101700.f_18920, 9);
		}
	}
	else if (func_109(47) && !func_109(22)) {
		StringCopy(&Var0, "DRF_MIC2", 16);
		*iParam1 = 0;
		*iParam2 = 13;
		if (iParam3) {
			func_108(&Global_101700.f_18920, 10);
		}
	}
	return Var0;
}

//Position - 0x4475
int func_107(int iParam0)
{
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x4571
void func_108(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 12) {
		return;
	}
	*uParam0 -= (*uParam0 & 31);
	*uParam0 |= iParam1;
}

// Position - 0x45A4
int func_109(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return 0;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0x45D0
void func_110(var *uParam0, var *uParam1, var *uParam2, int iParam3) {
	struct<4> Var0;
	int iVar4;

	switch (iParam3) {
	case 2:
		StringCopy(&Var0, "DRF_3", 16);
		iVar4 = 17;
		break;

	case 3:
		StringCopy(&Var0, "DRF_4", 16);
		iVar4 = 6;
		break;

	default: break;
	}
	func_80(uParam0, uParam1, uParam2, &Var0, 0, iVar4, 0);
	switch (iParam3) {
	case 2: StringCopy(&Var0, "DRF_OVR_2", 16); break;

	case 3: StringCopy(&Var0, "DRF_OVR_5", 16); break;
	}
	StringCopy(&(*uParam0)[*uParam2 /*4*/], "DRF_OVR", 16);
	(*uParam1)[*uParam2 /*4*/] = {Var0};
	*uParam2++;
}

// Position - 0x4665
void func_111(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x4700
void func_112(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iParam2) {
		(*uParam0)[iVar0] = func_113(&(*uParam1)[iVar0 /*4*/]);
		iVar0++;
	}
}

// Position - 0x472B
var func_113(var uParam0) { return uParam0; }

// Position - 0x4735
bool func_114(var *uParam0, var *uParam1, var *uParam2, int *iParam3) {
	if (Global_88285 != 0 && gameplay::get_game_timer() - Global_88285 < 1800000) {
		return false;
	}
	ui::request_additional_text("SHRINK", 0);
	ui::request_additional_text("DrfAud", 6);
	while (!ui::has_additional_text_loaded(0) || !ui::has_additional_text_loaded(6)) {
		system::wait(0);
	}
	if (!func_115(uParam1, uParam2, iParam3)) {
		return false;
	}
	func_111(uParam0, 0, player::player_ped_id(), "MICHAEL", 0, 1);
	func_111(uParam0, 1, 0, "FRIEDLANDER", 0, 1);
	Global_88285 = gameplay::get_game_timer();
	return true;
}

// Position - 0x47C1
int func_115(var *uParam0, var *uParam1, int *iParam2) {
	int iVar0;

	iVar0 = func_117(&Global_101700.f_18920);
	switch (iVar0) {
	case 0:
		func_80(uParam0, uParam1, iParam2, "PBTNM", 0, 11, 0);
		func_116(&Global_101700.f_18920, 1);
		break;

	case 1:
		func_80(uParam0, uParam1, iParam2, "PBTNM2", 0, 10, 0);
		func_116(&Global_101700.f_18920, 2);
		break;

	case 2:
		func_80(uParam0, uParam1, iParam2, "PBTNM3", 0, 12, 0);
		func_116(&Global_101700.f_18920, 3);
		break;

	default: return 0;
	}
	return 1;
}

// Position - 0x485A
void func_116(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 3) {
		return;
	}
	*uParam0 -= (*uParam0 & system::shift_left(3, 5));
	*uParam0 |= system::shift_left(iParam1, 5);
}

// Position - 0x4895
int func_117(var *uParam0) { return system::shift_right(*uParam0, 5) & 3; }

// Position - 0x48A7
int func_118(int iParam0) {
	switch (iParam0) {
	case 0: return 500;

	case 1: return 1000;

	case 2: return 1500;

	case 3: return 1500;

	case 4: return 2000;
	}
	return 0;
}

// Position - 0x4902
int func_119(int iParam0) { return Global_52996[iParam0]; }

// Position - 0x4911
void func_120(var *uParam0, int iParam1) {
	switch (iParam1) {
	case 0:
		StringCopy(uParam0, "DRF_MIC_1_CS_1", 24);
		StringCopy(&uParam0->f_6, "OBTNR1", 24);
		StringCopy(&uParam0->f_12, "DRF_MIC_1_CS_2", 24);
		uParam0->f_18 = 293200;
		break;

	case 1:
		StringCopy(uParam0, "DRF_MIC_2_CS_1", 24);
		StringCopy(&uParam0->f_6, "OBTNR2", 24);
		StringCopy(&uParam0->f_12, "DRF_MIC_2_CS_2", 24);
		uParam0->f_18 = 243600;
		break;

	case 2:
		StringCopy(uParam0, "PBTINT1", 24);
		StringCopy(&uParam0->f_6, "PBTNR2", 24);
		StringCopy(&uParam0->f_12, "PBTOUT1", 24);
		break;

	case 3:
		StringCopy(uParam0, "PBTINT2", 24);
		StringCopy(&uParam0->f_6, "PBTNR3", 24);
		StringCopy(&uParam0->f_12, "PBTOUT2", 24);
		break;

	case 4:
		StringCopy(uParam0, "DRF_MIC_3_CS_1", 24);
		StringCopy(&uParam0->f_6, "OBTNR1", 24);
		StringCopy(&uParam0->f_12, "DRF_MIC_3_CS_2", 24);
		uParam0->f_18 = 252700;
		break;

	default: break;
	}
}

// Position - 0x49F4
int func_121() { return 2; }

// Position - 0x49FD
void func_122() {
	func_126();
	func_124();
	func_123();
	script::terminate_this_thread();
}

// Position - 0x4A15
void func_123() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 1) {
		Global_88289[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		Global_88286[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x4A53
void func_124() {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 < 10) {
		iVar0 = iVar1;
		switch (iVar0) {
		case 0: func_125(&Global_88292, 1); break;

		case 1: func_125(&Global_88294, 3); break;

		case 2: func_125(&Global_88298, 1); break;

		case 3: func_125(&Global_88300, 1); break;

		case 4: func_125(&Global_88302, 1); break;

		case 5: func_125(&Global_88304, 1); break;

		case 6: func_125(&Global_88306, 1); break;

		case 7: func_125(&Global_88308, 2); break;

		case 8: func_125(&Global_88311, 1); break;

		case 9: func_125(&Global_88313, 1); break;
		}
		iVar1++;
	}
}

// Position - 0x4B2D
void func_125(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iParam1) {
		(*uParam0)[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x4B4F
void func_126() {
	Global_14611 = 0;
	func_73();
}

// Position - 0x4B5F
void func_127() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_9(0)) {
		if (!func_128()) {
			iVar0 = func_8();
			if (iVar0 != -1) {
				if (!func_2(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_7();
		}
	}
}

// Position - 0x4BD0
int func_128() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

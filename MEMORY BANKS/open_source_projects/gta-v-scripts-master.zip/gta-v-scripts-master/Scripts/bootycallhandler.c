#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
var uLocal_35 = 0;
var *uLocal_36 = NULL;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
var uLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
int *iLocal_201 = NULL;
#pragma endregion //}

void __EntryFunction__() {
	bool bVar0;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_201 = -1;
	bVar0 = network::network_is_game_in_progress();
	if (!bVar0) {
		if (player::has_force_cleanup_occurred(34)) {
			func_81();
		}
	}
	func_80(-1);
	while (true) {
		system::wait(0);
		if (func_79()) {
			func_81();
		}
		if (bVar0) {
			if (!network::network_is_game_in_progress()) {
				func_81();
			}
		}
		func_77();
		func_67();
		func_1();
	}
	script::terminate_this_thread();
}

// Position - 0xB8
void func_1() {
	int iVar0;
	int iVar1;
	char cVar2[64];
	struct<16> Var18;

	switch (Global_100694) {
	case 0:
		if (!Global_100694.f_27) {
			iVar1 = 0;
			while (iVar1 < 10) {
				iVar0 = iVar1;
				if (func_65(func_66(iVar0)) && Global_100694.f_15[iVar1] + 120000 < gameplay::get_game_timer()) {
					if (func_63(iVar0)) {
						func_62(iVar0, 0);
						func_57(iVar0, 0);
					}
					if (func_56(iVar0)) {
						Global_100694.f_26 = 0;
					}
					else {
						func_54(&uLocal_36, 3, 0, func_55(iVar0), 0, 1);
						Var18 = {func_53()};
						if (func_51(iVar0)) {
							func_62(iVar0, 1);
							Global_100694.f_26 = 0;
							StringCopy(&cVar2, "BC_HATE_", 64);
						}
						else if (gameplay::get_game_timer() >= Global_100694.f_4[iVar1] && func_50() &&
								 func_49(iVar0) && func_48(iVar0) >= func_47(iVar0)) {
							Global_100694.f_26 = 1;
							StringCopy(&cVar2, "BC_STRY_", 64);
						}
						else {
							Global_100694.f_26 = 0;
							StringCopy(&cVar2, "BC_STRN_", 64);
						}
						if (func_46() == 2) {
							func_54(&uLocal_36, 0, player::player_ped_id(), "TREVOR", 0, 1);
						}
						else if (func_46() == 0) {
							func_54(&uLocal_36, 0, player::player_ped_id(), "MICHAEL", 0, 1);
						}
						else if (func_46() == 1) {
							func_54(&uLocal_36, 0, player::player_ped_id(), "FRANKLIN", 0, 1);
						}
						StringIntConCat(&cVar2, iVar1, 64);
						func_32(&uLocal_36, func_66(iVar1), "BCAUD", &Var18, &Var18, &cVar2, &cVar2, 12, 1, 0, 0, 0);
					}
					Global_100694.f_1 = iVar1;
					Global_100694 = 1;
				}
				iVar1++;
			}
		}
		break;

	case 1:
		if (!func_31()) {
			if (Global_100694.f_26) {
				if (func_30() && !func_29()) {
					func_18(Global_100694.f_1);
				}
				if (func_17()) {
					func_3();
					func_2(0);
				}
			}
			else {
				func_2(0);
			}
		}
		break;
	}
}

// Position - 0x2A2
void func_2(int iParam0) {
	Global_100694 = 0;
	Global_100694.f_1 = -1;
	Global_100694.f_2 = -1;
	if (iParam0) {
		func_80(-1);
	}
}

// Position - 0x2C7
void func_3() {
	int iVar0;

	if (func_15()) {
		return;
	}
	iVar0 = func_14(Global_100694.f_1);
	func_4(-384575792, iVar0, 7, 3, func_9(), func_66(Global_100694.f_1), 0, 10000, -1, 0, -1, 0, 1);
}

// Position - 0x30A
int func_4(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
		   int iParam8, int iParam9, int iParam10, int iParam11, int iParam12) {
	struct<14> Var0;

	if (func_8(0)) {
		return 0;
	}
	if (iParam6 < 0) {
		return 0;
	}
	if (iParam7 < 0) {
		return 0;
	}
	if (iParam8 == 76) {
		return 0;
	}
	if (iParam9 == 235) {
		return 0;
	}
	if (iParam5 < 3) {
		if (gameplay::is_bit_set(iParam4, iParam5)) {
			return 0;
		}
	}
	if (iParam4 < 1 || iParam4 > 7) {
		return 0;
	}
	if (iParam1 == -1) {
		return 0;
	}
	if (iParam1 == 83 || iParam2 == 83) {
		return 0;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 < 8) {
		Var0 = iParam0;
		Var0.f_3 = func_7(iParam3);
		Var0.f_4 = gameplay::get_game_timer() + iParam6;
		Var0.f_5 = iParam7;
		Var0.f_1 = iParam11;
		Var0.f_2 = iParam4;
		Var0.f_6 = iParam5;
		Var0.f_7 = iParam8;
		Var0.f_8 = iParam9;
		Var0.f_9 = iParam10;
		Var0.f_10 = iParam1;
		Var0.f_11 = iParam2;
		Var0.f_13 = iParam12;
		gameplay::clear_bit(&Var0.f_1, 0);
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 /*14*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_764++;
		func_5(0);
		func_5(1);
		func_5(2);
		return 1;
	}
	return 0;
}

// Position - 0x448
void func_5(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (!func_6(iParam0)) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 > iVar1) {
				iVar1 = G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3;
			}
		}
		iVar0++;
	}
	iVar2 = 0;
	while (iVar2 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_3 == 5) {
				iVar1 = 5;
			}
		}
		iVar2++;
	}
	G_SomeGlobalState.MessageCallStates.f_919[iParam0] = iVar1;
}

// Position - 0x50C
bool func_6(int iParam0) { return iParam0 < 3; }

// Position - 0x518
int func_7(int iParam0) {
	switch (iParam0) {
	case 0:
	case 4: return 5;

	case 7: return 4;

	case 2: return 3;

	case 1: return 2;

	case 3: return 1;

	case 5:
	case 6: return 0;
	}
	return 7;
}

// Position - 0x582
bool func_8(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x5AD
int func_9() {
	func_10();
	switch (Global_101700.f_2095.f_539.f_3549) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;
	}
	return 0;
}

// Position - 0x5F3
void func_10() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_13(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_12(player::player_ped_id());
			if (func_6(iVar0) && (!func_11(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_6(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x6F0
bool func_11(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x6FE
int func_12(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_13(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x73B
int func_13(int iParam0) {
	if (func_6(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x765
int func_14(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 1;

	case 4: return 2;

	case 5: return 3;

	case 8: return 4;

	case 9: return 5;
	}
	return -1;
}

// Position - 0x7C3
bool func_15() {
	if (func_16() == 0) {
		return true;
	}
	return false;
}

// Position - 0x7D8
int func_16() { return Global_25190; }

// Position - 0x7E3
bool func_17() {
	if (Global_15795) {
		return true;
	}
	return false;
}

// Position - 0x7F9
void func_18(int iParam0) {
	struct<6> Var0;
	int iVar6;
	struct<6> Var7;

	script::request_script("stripperhome");
	while (!script::has_script_loaded("stripperhome")) {
		system::wait(0);
	}
	if (func_50()) {
		if (func_15()) {
			Var0 = 1;
			Var0[0] = iParam0;
			Var0.f_2 = 1;
			Var0.f_3 = -1;
			Var0.f_4 = 1;
			Var0.f_5 = 1;
			system::start_new_script_with_args("stripperhome", &Var0, 6, 1424);
			func_28(Global_100694.f_1, -1);
			Global_100694 = 3;
		}
		else {
			iLocal_201 = -1;
			iVar6 = func_23(&iLocal_201, 6, 10, 0, 0);
			while (iVar6 == 2) {
				iVar6 = func_23(&iLocal_201, 6, 10, 0, 0);
				system::wait(0);
			}
			if (iVar6 == 1) {
				func_19(iParam0, 0);
				Var7 = 1;
				Var7[0] = iParam0;
				Var7.f_2 = 1;
				Var7.f_3 = iLocal_201;
				Var7.f_4 = 1;
				Var7.f_5 = 0;
				system::start_new_script_with_args("stripperhome", &Var7, 6, 1424);
				func_28(Global_100694.f_1, -1);
				Global_100694 = 3;
			}
			else {
				script::set_script_as_no_longer_needed("stripperhome");
				Global_100694 = 0;
			}
		}
	}
	else {
		script::set_script_as_no_longer_needed("stripperhome");
		Global_100694 = 0;
	}
	Global_100694.f_1 = -1;
	func_80(-1);
}

// Position - 0x90F
void func_19(int iParam0, int iParam1) { Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_1 = iParam1; }

// Position - 0x92D
int func_20() {
	int iVar0;

	iVar0 = func_46();
	switch (iVar0) {
	case 0: return 0;

	case 1: return 1;

	case 2: return 2;

	default:
		switch (func_21(-1)) {
		case 0: return 3;

		case 1: return 4;

		case 2: return 5;

		case 3: return 6;

		case 4: return 7;

		default: break;
		}
		break;
	}
	return 3;
}

// Position - 0x9BB
int func_21(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	if (iVar0 == -1) {
		iVar1 = func_22();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x9EF
var func_22() { return Global_1312735; }

// Position - 0x9FB
int func_23(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_27(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_25(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_24(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0xB32
void func_24(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0xB81
bool func_25(int iParam0) { return func_26(iParam0, Global_35781); }

// Position - 0xB92
int func_26(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0xD73
bool func_27(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_25(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0xD95
void func_28(int iParam0, int iParam1) {
	if (iParam1 > -1) {
		Global_100694.f_4[iParam0] = gameplay::get_game_timer() + iParam1;
	}
	else {
		Global_100694.f_4[iParam0] = gameplay::get_game_timer() + gameplay::get_random_int_in_range(1200000, 2100000);
	}
}

// Position - 0xDD2
int func_29() {
	if (Global_15794 == 1 || Global_16761 == 1) {
		return 1;
	}
	return 0;
}

// Position - 0xDF5
int func_30() {
	if (Global_15745 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0xE0C
int func_31() {
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		return 1;
	}
	return 0;
}

// Position - 0xE35
int func_32(var *uParam0, int iParam1, char *sParam2, var uParam3, var uParam4, char[4] cParam5, char[4] cParam6,
			int iParam7, int iParam8, int iParam9, int iParam10, int iParam11) {
	var *uVar0;
	var *uVar11;

	func_45(uParam0, iParam1, sParam2, iParam9, iParam10, 0);
	func_44();
	if (iParam8 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	uVar0 = 10;
	uVar11 = 10;
	func_42(2, &uVar0, &uVar11, uParam3, uParam4, cParam5, cParam6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	return func_33(&uVar0, &uVar11, iParam7, iParam11);
}

// Position - 0xE94
int func_33(var *uParam0, var *uParam1, int iParam2, bool bParam3) {
	int iVar0;

	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam2 > Global_15747) {
				if (bParam3 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
				}
				else {
					func_41();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_40(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_39();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16741 = Global_16742;
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15364.f_370 = Global_16734;
		Global_15741 = Global_15742;
		Global_15743 = Global_15744;
		if (Global_16003 == 0) {
			Global_15899[0 /*6*/] = {Global_15925[0 /*6*/]};
			Global_15899[1 /*6*/] = {Global_15925[1 /*6*/]};
			Global_15951[0 /*6*/] = {Global_15977[0 /*6*/]};
			Global_15951[1 /*6*/] = {Global_15977[1 /*6*/]};
			Global_15912[0 /*6*/] = {Global_15938[0 /*6*/]};
			Global_15912[1 /*6*/] = {Global_15938[1 /*6*/]};
			Global_15964[0 /*6*/] = {Global_15990[0 /*6*/]};
			Global_15964[1 /*6*/] = {Global_15990[1 /*6*/]};
		}
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (bParam3) {
				func_38();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam2 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_37()) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (Global_16003 == 0) {
						if (entity::is_entity_in_water(player::player_ped_id())) {
							return 0;
						}
						if (player::is_player_climbing(player::player_id())) {
							return 0;
						}
						if (ped::is_ped_planting_bomb(player::player_ped_id())) {
							return 0;
						}
						if (player::is_special_ability_active(player::player_id())) {
							return 0;
						}
					}
				}
			}
			if (func_36()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
			}
			func_35();
			Global_15755 = bParam3;
		}
		Global_15747 = iParam2;
		if (Global_15741 > 0) {
			iVar0 = 0;
			while (iVar0 < Global_15741) {
				StringCopy(&Global_15364.f_6[iVar0 /*6*/], (*uParam0)[iVar0], 24);
				StringCopy(&Global_15364.f_187[iVar0 /*6*/], (*uParam1)[iVar0], 24);
				iVar0++;
			}
		}
		Global_14611 = 0;
		func_34();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam2 < Global_15747 || iParam2 == Global_15747) {
		return 0;
	}
	if (iParam2 == 2) {
	}
	else {
		func_41();
	}
	return 0;
}

// Position - 0x11FE
void func_34() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x122F
void func_35() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x12C4
bool func_36() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x12EB
bool func_37() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x1384
void func_38() {
	if (func_11(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_46();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x1426
void func_39() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x147D
bool func_40(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x14B8
void func_41() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x150F
void func_42(int iParam0, var *uParam1, var *uParam2, var uParam3, var uParam4, var uParam5, var uParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			 int iParam15, int iParam16) {
	func_43(iParam0);
	(*uParam1)[0] = uParam3;
	(*uParam2)[0] = uParam4;
	(*uParam1)[1] = uParam5;
	(*uParam2)[1] = uParam6;
	(*uParam1)[2] = iParam7;
	(*uParam2)[2] = iParam8;
	(*uParam1)[3] = iParam9;
	(*uParam2)[3] = iParam10;
	(*uParam1)[4] = iParam11;
	(*uParam2)[4] = iParam12;
	(*uParam1)[5] = iParam13;
	(*uParam2)[5] = iParam14;
	(*uParam1)[6] = iParam15;
	(*uParam2)[6] = iParam16;
}

// Position - 0x157F
void func_43(var uParam0) {
	Global_15742 = uParam0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
}

// Position - 0x15A5
void func_44() {
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_15759 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
}

// Position - 0x15DE
void func_45(var *uParam0, var uParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = uParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x1634
int func_46() {
	func_10();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x164D
int func_47(int iParam0) {
	switch (iParam0) {
	case 0: return system::floor(0.95f * 7500f);

	case 1: return system::floor(0.95f * 7500f);

	case 2: return system::floor(0.95f * 7500f);

	case 3: return system::floor(0.95f * 7500f);

	case 4: return system::floor(0.95f * 7500f);

	case 5: return system::floor(0.95f * 7500f);

	case 6: return system::floor(0.95f * 7500f);

	case 7: return system::floor(0.95f * 7500f);
	}
	return 0;
}

// Position - 0x1735
int func_48(int iParam0) { return Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/]; }

// Position - 0x174F
int func_49(int iParam0) {
	switch (iParam0) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
		if (time::get_clock_hours() < 6 || time::get_clock_hours() > 14) {
			return 1;
		}
		break;

	case 8:
	case 9: return 1;
	}
	return 0;
}

// Position - 0x17BF
bool func_50() {
	if (func_79() || Global_100722) {
		return false;
	}
	return true;
}

// Position - 0x17DD
bool func_51(int iParam0) { return func_52(Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 2); }

// Position - 0x17FE
bool func_52(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x180D
struct<16> func_53() {
	struct<16> Var0;

	StringCopy(&Var0, "BC_PLYRQ_", 64);
	if (func_46() == 0) {
		StringConCat(&Var0, "M", 64);
	}
	else if (func_46() == 2) {
		StringConCat(&Var0, "T", 64);
	}
	else if (func_46() == 1) {
		StringConCat(&Var0, "F", 64);
	}
	return Var0;
}

//Position - 0x1854
void func_54(var* uParam0, int iParam1, int iParam2, char* sParam3, int iParam4, int iParam5)
{
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x18EF
char *func_55(int iParam0) {
	switch (iParam0) {
	case 0: return "Juliet";

	case 1: return "Nikki";

	case 2: return "Chastity";

	case 3: return "Cheetah";

	case 4: return "Sapphire";

	case 5: return "Infernus";

	case 6: return "Fufu";

	case 7: return "Peach";

	case 8: return "TaxiLiz";

	case 9: return "REHH2Hiker";
	}
	return "Invalid name";
}

// Position - 0x1997
bool func_56(int iParam0) { return func_52(Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 4); }

// Position - 0x19B8
void func_57(int iParam0, int iParam1) {
	if (iParam1) {
		func_60(&Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 2);
	}
	else {
		func_58(&Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 2);
	}
}

// Position - 0x19FA
void func_58(int *iParam0, int iParam1) { func_59(iParam0, iParam1); }

// Position - 0x1A0A
void func_59(int *iParam0, var uParam1) { *iParam0 -= (*iParam0 & uParam1); }

// Position - 0x1A1F
void func_60(var *uParam0, int iParam1) { func_61(uParam0, iParam1); }

// Position - 0x1A2F
void func_61(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x1A40
void func_62(int iParam0, int iParam1) {
	if (iParam1) {
		func_60(&Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 4);
	}
	else {
		func_58(&Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_3, 4);
	}
}

// Position - 0x1A82
bool func_63(int iParam0) {
	if (func_51(iParam0)) {
		return func_48(iParam0) >= func_64(iParam0);
	}
	return func_48(iParam0) >= func_47(iParam0);
}

// Position - 0x1AB3
int func_64(int iParam0) {
	switch (iParam0) {
	case 0: return system::floor(0.8f * 7500f);

	case 1: return system::floor(0.8f * 7500f);

	case 2: return system::floor(0.8f * 7500f);

	case 3: return system::floor(0.8f * 7500f);

	case 4: return system::floor(0.8f * 7500f);

	case 5: return system::floor(0.8f * 7500f);

	case 6: return system::floor(0.8f * 7500f);

	case 7: return system::floor(0.8f * 7500f);

	default: return 7500;
	}
	return 0;
}

// Position - 0x1BA4
int func_65(int iParam0) {
	if (Global_16859 || Global_16858 || Global_16860) {
		if (iParam0 == 130) {
		}
		else {
			return 0;
		}
	}
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_14443.f_1 == 10) {
			if (Global_1628 == iParam0) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x1C08
int func_66(int iParam0) {
	switch (iParam0) {
	case 0: return 104;

	case 1: return 105;

	case 2: return 106;

	case 3: return 107;

	case 4: return 108;

	case 5: return 109;

	case 6: return 110;

	case 7: return 111;

	case 8: return 112;

	case 9: return 93;
	}
	return 145;
}

// Position - 0x1CA5
void func_67() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (func_15()) {
		return;
	}
	switch (Global_100694) {
	case 0:
		if (!Global_100694.f_27 && func_75(0)) {
			if (gameplay::get_game_timer() >= Global_100694.f_3) {
				Global_100694.f_1 = func_74();
				iVar0 = Global_100694.f_1;
				if (Global_100694.f_1 >= 0 && func_50() && func_72(func_66(iVar0)) && func_49(iVar0) &&
					func_48(iVar0) >= func_47(iVar0)) {
					iVar1 = func_14(Global_100694.f_1);
					iVar2 = func_71(0);
					func_4(-384575792, iVar1, iVar2, 3, func_9(), func_66(Global_100694.f_1), 0, 10000, -1, 0, -1, 0,
						   1);
					func_68(Global_100694.f_1);
				}
				if (!func_49(Global_100694.f_1)) {
					func_80(300000);
				}
				else {
					func_80(-1);
				}
			}
		}
		break;

	case 2: break;
	}
}

// Position - 0x1DA6
void func_68(int iParam0) {
	if (func_70(iParam0) < 0) {
		func_69(iParam0, 0);
	}
	Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_2++;
}

// Position - 0x1DE9
void func_69(int iParam0, int iParam1) { Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_2 = iParam1; }

// Position - 0x1E07
int func_70(int iParam0) { return Global_101700.f_243[func_20() /*53*/].f_2[iParam0 /*5*/].f_2; }

// Position - 0x1E23
int func_71(int iParam0) {
	switch (iParam0) {
	case 0: return 10;

	case 1: return 8;

	case 2: return 9;
	}
	return -1;
}

// Position - 0x1E5D
bool func_72(int iParam0) {
	int iVar0;

	iVar0 = func_73();
	return Global_101700.f_27009[iParam0 /*29*/].f_12[iVar0] == 1;
}

// Position - 0x1E7E
int func_73() {
	switch (func_12(player::player_ped_id())) {
	case 0: return 0;

	case 2: return 2;

	case 1: return 1;
	}
	return 4;
}

// Position - 0x1EBB
int func_74() {
	int iVar0;
	int iVar1;
	int iVar2[10];
	int iVar13;

	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 10) {
		if (Global_101700.f_243[func_46() /*53*/].f_2[iVar0 /*5*/].f_4 &&
			gameplay::get_game_timer() >= Global_100694.f_4[iVar0]) {
			iVar2[iVar1] = iVar0;
			iVar1++;
		}
		iVar0++;
	}
	if (iVar1 > 0) {
		iVar13 = gameplay::get_random_int_in_range(0, iVar1);
		return iVar2[iVar13];
	}
	return -1;
}

// Position - 0x1F31
int func_75(int iParam0) {
	if (func_76(0) && !iParam0 || func_31() || Global_100694.f_2 != -1 || !func_6(func_46())) {
		return 0;
	}
	return 1;
}

// Position - 0x1F75
int func_76(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return 1;
	}
	if (Global_14443.f_1 > 3) {
		return 1;
	}
	return 0;
}

// Position - 0x1FCF
void func_77() {
	if (!Global_100694.f_27) {
		if (!func_78()) {
			func_2(0);
			Global_100694.f_27 = 1;
		}
	}
	else if (func_78()) {
		if (Global_100694.f_3 < gameplay::get_game_timer() + 120000) {
			func_80(1800000);
		}
		Global_100694.f_27 = 0;
	}
}

// Position - 0x2020
bool func_78() {
	if (!func_50() || Global_100723) {
		return false;
	}
	return true;
}

// Position - 0x203F
bool func_79() {
	if (Global_35781 == 15) {
		return false;
	}
	return true;
}

// Position - 0x2054
void func_80(int iParam0) {
	if (iParam0 != -1) {
		Global_100694.f_3 = gameplay::get_game_timer() + iParam0;
	}
	else {
		Global_100694.f_3 = gameplay::get_game_timer() + gameplay::get_random_int_in_range(21600000, 25200000);
	}
}

// Position - 0x208B
void func_81() {
	if (iLocal_201 != -1) {
		func_82(&iLocal_201);
	}
	if (Global_100694 == 1) {
		func_3();
		func_2(0);
	}
	script::terminate_this_thread();
}

// Position - 0x20B4
void func_82(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

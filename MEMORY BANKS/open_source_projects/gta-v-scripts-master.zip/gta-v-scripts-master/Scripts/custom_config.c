void __EntryFunction__() {
	if (player::has_force_cleanup_occurred(3)) {
		script::terminate_this_thread();
	}
	script::terminate_this_thread();
}

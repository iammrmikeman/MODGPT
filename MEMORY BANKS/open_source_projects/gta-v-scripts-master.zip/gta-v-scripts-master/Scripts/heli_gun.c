#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
var uLocal_21 = 0;
var uLocal_22 = 0;
float fLocal_23 = 0f;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
var uLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
int iLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
vector3 vLocal_59 = {0f, 0f, 0f};
int iLocal_62 = 0;
int iLocal_63 = 0;
int iLocal_64 = 0;
struct<205> Local_65 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1056964608, 1084227584, 0, 1109393408, 0, 0, 1125515264, 0, 0, 0, 0, 0, 0, 0,
		1065848144, 1074048008, 1073959928, 1077206319, -1033122611, -1055016354, 0, 0, 0, 0, 0, 0, 1105199104,
		1092616192, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 1101004800, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, 0
};
var *uLocal_270 = NULL;
var uLocal_271 = 0;
int iLocal_272 = 0;
int iLocal_273 = 0;
int iLocal_274 = 0;
int iLocal_275 = 0;
bool bLocal_276 = 0;
bool bLocal_277 = 0;
int iLocal_278 = 0;
bool bLocal_279 = 0;
int iLocal_280 = 0;
int iLocal_281 = 0;
bool bLocal_282 = 0;
int iLocal_283 = 0;
int iLocal_284 = 0;
vector3 vLocal_285 = {0f, 0f, 0f};
float fLocal_288 = 0f;
int iLocal_289 = 0;
int iLocal_290 = 0;
int iLocal_291 = 0;
int iLocal_292 = 0;
int iLocal_293 = 0;
int iLocal_294 = 0;
int iLocal_295 = 0;
int iLocal_296 = 0;
int iLocal_297 = 0;
struct<2> Local_298[2];
int iLocal_303 = 0;
struct<20> ScriptParam_0 = {
	0, -1, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1
};
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_23 = 80f;
	fLocal_24 = 140f;
	fLocal_25 = 180f;
	fLocal_28 = 0f;
	fLocal_32 = -0.0375f;
	fLocal_33 = 0.17f;
	iLocal_36 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	iLocal_284 = 1;
	vLocal_285 = {0.1f, 0.1f, 0.1f};
	fLocal_288 = 0f;
	if (network::network_is_game_in_progress()) {
		func_113(ScriptParam_0);
	}
	while (true) {
		func_112();
		if (func_102()) {
			func_101(3);
		}
		if (func_93(0)) {
			func_101(3);
		}
		if (Global_1751014) {
			func_101(3);
		}
		if (Global_1315161) {
			func_101(3);
		}
		if (Global_1318175) {
			func_101(3);
		}
		if (Global_1574109) {
			func_101(3);
		}
		if (Global_1574275) {
			func_101(3);
		}
		if (Global_1751032) {
			func_101(3);
		}
		if (!network::network_is_game_in_progress()) {
			func_89();
		}
		if (func_88()) {
			func_101(3);
		}
		if (network::network_is_player_in_mp_cutscene(player::player_id())) {
			func_101(3);
		}
		if (func_87()) {
			func_101(3);
		}
		if (vehicle::is_vehicle_driveable(iLocal_291, 0)) {
			if (network::_0x21D04D7BC538C146(iLocal_291) && func_86(player::player_id()) != 129) {
				func_101(3);
			}
		}
		func_85(&uLocal_270, 0, 0);
		func_82();
		if (network::network_is_game_in_progress() && network::participant_id_to_int() != -1) {
			switch (Local_298[network::participant_id_to_int() /*2*/]) {
			case 0: func_101(1); break;

			case 1:
				func_1();
				Global_2454056 = 0;
				if (iLocal_297 >= 3) {
					func_101(3);
				}
				break;

			case 2: break;

			case 3: func_89(); break;

			default: break;
			}
		}
		if (network::network_is_host_of_this_script()) {
			switch (iLocal_297) {
			case 0: iLocal_297 = 1; break;

			case 1: break;

			case 2: break;

			case 3: func_89(); break;

			default: break;
			}
		}
	}
}

// Position - 0x219
void func_1() {
	if (func_81(&Local_65)) {
		if (!iLocal_283) {
			audio::set_audio_flag("ForceSniperAudio", 1);
			iLocal_283 = 1;
		}
	}
	else if (iLocal_283) {
		audio::set_audio_flag("ForceSniperAudio", 0);
		iLocal_283 = 0;
	}
	if (gameplay::is_bit_set(Global_1633501.f_102485, 1)) {
		if (iLocal_294 == player::player_id()) {
			if (!iLocal_281) {
				vehicle::disable_vehicle_weapon(1, joaat("vehicle_weapon_space_rocket"), iLocal_291,
												player::player_ped_id());
				iLocal_281 = 1;
			}
		}
	}
	else if (func_80()) {
		if (iLocal_294 == player::player_id()) {
			if (!iLocal_281) {
				vehicle::disable_vehicle_weapon(1, joaat("vehicle_weapon_space_rocket"), iLocal_291,
												player::player_ped_id());
				iLocal_281 = 1;
			}
		}
	}
	else if (iLocal_294 == player::player_id()) {
		if (iLocal_281) {
			vehicle::disable_vehicle_weapon(0, joaat("vehicle_weapon_space_rocket"), iLocal_291,
											player::player_ped_id());
			iLocal_281 = 0;
		}
	}
	func_79();
	func_78();
	switch (Local_298[network::participant_id_to_int() /*2*/].f_1) {
	case 0:
		func_72();
		Global_1591201[player::player_id() /*602*/].f_493 = 0;
		if (func_70()) {
			func_69(1);
		}
		else if (bLocal_276) {
			if (iLocal_272 == joaat("valkyrie")) {
				controls::disable_control_action(0, 24, 1);
				controls::disable_control_action(0, 66, 1);
				controls::disable_control_action(0, 67, 1);
				controls::disable_control_action(0, 68, 1);
				controls::disable_control_action(0, 114, 1);
				controls::disable_control_action(0, 69, 1);
				controls::disable_control_action(0, 70, 1);
				controls::disable_control_action(0, 91, 1);
				controls::disable_control_action(0, 92, 1);
				controls::disable_control_action(0, 99, 1);
				controls::disable_control_action(0, 100, 1);
				controls::disable_control_action(0, 37, 1);
			}
		}
		break;

	case 1:
		iLocal_64 = unk_0x67D02A194A2FC2BD("heli_cam");
		graphics::request_streamed_texture_dict("helicopterhud", 0);
		func_68();
		if (func_67(&Local_65, 0) && graphics::has_scaleform_movie_loaded(iLocal_64) &&
			graphics::has_streamed_texture_dict_loaded("helicopterhud")) {
			Local_65.f_9 = func_66(iLocal_291);
			Local_65.f_4 = 1;
			Global_1591201[player::player_id() /*602*/].f_493 = 1;
			func_64(&Local_65, iLocal_291, 1, 1);
			Global_2502456 = 1;
			func_62();
			entity::set_entity_always_prerender(iLocal_291, 1);
			func_69(2);
			if (!bLocal_276) {
				Local_65.f_7 = 1;
				func_59();
			}
			func_58();
		}
		break;

	case 2:
		Global_1318176 = 0;
		func_68();
		func_54();
		func_53(&Local_65, 1);
		Local_65.f_4 = 1;
		if (func_52()) {
			controls::disable_control_action(0, 91, 1);
			controls::disable_control_action(0, 92, 1);
		}
		controls::disable_control_action(0, 91, 1);
		controls::disable_control_action(0, 68, 1);
		controls::disable_control_action(0, 69, 1);
		controls::disable_control_action(0, 80, 1);
		controls::disable_control_action(0, 65, 1);
		controls::disable_control_action(0, 99, 1);
		controls::disable_control_action(0, 100, 1);
		controls::disable_control_action(1, 1, 1);
		controls::disable_control_action(1, 2, 1);
		controls::disable_control_action(0, 37, 1);
		if (bLocal_276) {
			controls::disable_control_action(1, 85, 1);
		}
		func_51();
		func_47();
		func_46();
		func_58();
		func_29(&Local_65, 0);
		Local_65.f_87 = 1;
		if (Local_65.f_34) {
			func_89();
		}
		func_24(&Local_65);
		Local_65.f_25 = 90f;
		if (!bLocal_276) {
			Local_65.f_7 = 1;
			func_59();
		}
		if (bLocal_276) {
			func_17();
			func_6();
		}
		if (Global_2433125.f_3458.f_1) {
			if (iLocal_284) {
				audio::play_sound_from_coord(-1, "Prison_Finale_Buzzard_Rocket", func_4(), "DLC_HEISTS_GENERIC_SOUNDS",
											 1, 50, 0);
				iLocal_284 = 0;
			}
		}
		else {
			iLocal_284 = 1;
		}
		if (!ui::is_pause_menu_active() && !func_3() && !func_2(0)) {
			if (controls::is_control_just_pressed(0, 51) ||
				vehicle::is_vehicle_driveable(iLocal_291, 0) && entity::is_entity_in_water(iLocal_291)) {
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
				func_101(3);
			}
		}
		break;
	}
}

// Position - 0x59A
bool func_2(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x5F4
bool func_3() { return gameplay::get_game_timer() <= Global_17290.f_5745 + 100; }

// Position - 0x609
Vector3 func_4() {
	int iVar0;
	vector3 vVar1;

	switch (iLocal_272) {
	case joaat("buzzard"):
	case joaat("savage"):
		switch (func_5()) {
		case 0: vVar1 = {1.59f, 0.415f, -0.43f}; break;

		case 1: vVar1 = {-1.59f, 0.415f, -0.43f}; break;
		}
		break;

	case joaat("valkyrie"):
		switch (func_5()) {
		case 0: vVar1 = {2.89f, 1.215f, -0.43f}; break;

		case 1: vVar1 = {-2.89f, 1.215f, -0.43f}; break;
		}
		break;
	}
	if (entity::does_entity_exist(player::player_ped_id())) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
				return entity::get_offset_from_entity_in_world_coords(iVar0, vVar1);
			}
		}
	}
	return 0f, 0f, 0f;
}

// Position - 0x6F1
int func_5() {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	float fVar9;
	float fVar10;
	float fVar11;

	vVar6 = {cam::get_cam_rot(Local_65.f_32, 2)};
	vVar3 = {-system::sin(vVar6.z) * system::cos(vVar6.x), system::cos(vVar6.z) * system::cos(vVar6.x),
			 system::sin(vVar6.x)};
	vVar0 = {entity::get_entity_forward_vector(Local_65.f_8)};
	fVar10 = gameplay::atan2(vVar3.y, vVar3.x);
	fVar9 = gameplay::atan2(vVar0.y, vVar0.x);
	if (fVar10 < -3.14f) {
		fVar10 = -3.14f;
	}
	if (fVar10 > 3.14f) {
		fVar10 = 3.14f;
	}
	if (fVar9 < -3.14f) {
		fVar9 = -3.14f;
	}
	if (fVar9 > 3.14f) {
		fVar9 = 3.14f;
	}
	fVar11 = fVar10 - fVar9;
	if (fVar11 <= 0f) {
		return 0;
	}
	return 1;
}

// Position - 0x7AE
void func_6() {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar3;
	vector3 vVar6;
	float fVar9;
	float fVar10;
	int iVar11;
	float fVar12;
	float fVar13;
	float *fVar14;
	float *fVar15;
	bool bVar16;
	bool bVar17;

	fVar10 = 99999f;
	iVar11 = -1;
	iVar0 = 0;
	while (iVar0 < 32) {
		bVar16 = gameplay::is_bit_set(Global_1574198, iVar0);
		iVar2 = iVar0;
		if (iVar2 != player::player_id()) {
			if (func_16(iVar2, 1, 1)) {
				iVar1 = player::get_player_ped(iVar2);
				vVar3 = {entity::get_entity_coords(iVar1, 1)};
				if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1), vVar3,
														  1) <= 150f) {
					if (func_15(iVar2, -1)) {
						if (graphics::get_screen_coord_from_world_coord(vVar3, &fVar12, &fVar13)) {
							if (!bVar16) {
								if (func_14(fVar12, fVar13, 0.4f, 0.4f, 0.6f, 0.6f)) {
									fVar9 = func_13(fVar12, fVar13, &fVar14, &fVar15);
									if (fVar9 < fVar10) {
										fVar10 = fVar9;
										iVar11 = iVar0;
										vVar6 = {vVar3};
									}
								}
							}
						}
					}
				}
			}
		}
		iVar0++;
	}
	if (iVar11 != -1) {
		if (graphics::get_screen_coord_from_world_coord(vVar6 + Vector(-1f, 0f, 0f), &fVar12, &fVar13)) {
			func_7(fVar12, fVar13);
			if (!ui::is_pause_menu_active()) {
				bVar17 = false;
				if (controls::_is_input_disabled(0)) {
					bVar17 = controls::is_control_just_pressed(0, 25);
				}
				else {
					bVar17 = controls::is_control_just_pressed(2, 201);
				}
				if (bVar17) {
					gameplay::set_bit(&Global_1574198, iVar11);
				}
			}
		}
	}
}

// Position - 0x8E1
void func_7(float fParam0, float fParam1) {
	var *uVar0;
	var *uVar2;

	func_9(&uVar0, &uVar2, fParam0, fParam1);
	if (controls::_is_input_disabled(0)) {
		func_8("HUNTGUN_5_KM", -1);
	}
	else {
		func_8("HUNTGUN_5", -1);
	}
}

// Position - 0x910
void func_8(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x927
void func_9(var *uParam0, var *uParam1, var uParam2, var uParam3) {
	*uParam0 = uParam2;
	uParam0->f_1 = uParam3;
	*uParam1 = 0;
	uParam1->f_1 = 0.25f;
	uParam1->f_2 = 0.25f;
	uParam1->f_7 = 2;
	func_10(func_11(1), &uParam1->f_3, &uParam1->f_4, &uParam1->f_5, &uParam1->f_6);
}

// Position - 0x96E
void func_10(var uParam0, var *uParam1, var *uParam2, var *uParam3, var *uParam4) {
	*uParam1 = gameplay::get_bits_in_range(uParam0, 24, 31);
	*uParam2 = gameplay::get_bits_in_range(uParam0, 16, 23);
	*uParam3 = gameplay::get_bits_in_range(uParam0, 8, 15);
	*uParam4 = gameplay::get_bits_in_range(uParam0, 0, 7);
}

// Position - 0x9A5
var func_11(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(iParam0, &iVar0, &iVar1, &iVar2, &iVar3);
	return func_12(iVar0, iVar1, iVar2, iVar3);
}

// Position - 0x9C7
var func_12(int iParam0, int iParam1, int iParam2, int iParam3) {
	var uVar0;

	gameplay::set_bits_in_range(&uVar0, 24, 31, iParam0);
	gameplay::set_bits_in_range(&uVar0, 16, 23, iParam1);
	gameplay::set_bits_in_range(&uVar0, 8, 15, iParam2);
	gameplay::set_bits_in_range(&uVar0, 0, 7, iParam3);
	return uVar0;
}

// Position - 0x9FC
float func_13(float fParam0, float fParam1, float *fParam2, float *fParam3) {
	float fVar0;
	float fVar1;

	if (fParam0 <= 0.5f) {
		fVar0 = 0.5f - fParam0;
	}
	else {
		fVar0 = fParam0 - 0.5f;
	}
	if (fParam1 <= 0.5f) {
		fVar1 = 0.5f - fParam1;
	}
	else {
		fVar1 = fParam1 - 0.5f;
	}
	*fParam2 = fVar0;
	*fParam3 = fVar1;
	return fVar0 + fVar1;
}

// Position - 0xA57
bool func_14(float fParam0, float fParam1, float fParam2, float fParam3, float fParam4, float fParam5) {
	if (fParam0 >= fParam2 && fParam0 <= fParam4) {
		if (fParam1 >= fParam3 && fParam1 <= fParam5) {
			return true;
		}
	}
	return false;
}

// Position - 0xA88
bool func_15(int iParam0, int iParam1) {
	if (iParam1 == -1) {
		return gameplay::is_bit_set(Global_2421664[player::player_id() /*358*/].f_32, iParam0);
	}
	else if (Global_2433125.f_3239[iParam0] >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0xAC4
bool func_16(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0xB0E
void func_17() {
	int iVar0;
	int iVar1;
	struct<2> Var2;

	if (func_52()) {
		if (!func_87()) {
			if (!func_23(&Global_2433125.f_3458)) {
				if (controls::is_control_pressed(2, 24)) {
					if (entity::does_entity_exist(player::player_ped_id())) {
						if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
							if (cam::does_cam_exist(Local_65.f_32)) {
								if (cam::is_cam_active(Local_65.f_32)) {
									iVar0 = 250;
									if (func_21(player::player_id(), 0)) {
										iVar1 = -1;
										if (decorator::decor_is_registered_as_type("MC_EntityID", 3)) {
											if (decorator::decor_exist_on(iLocal_291, "MC_EntityID")) {
												iVar1 = decorator::decor_get_int(iLocal_291, "MC_EntityID");
											}
										}
										if (iVar1 != -1 && Global_1633501.f_57271[iVar1 /*138*/].f_131 != -1) {
											iVar0 = Global_1633501.f_57271[iVar1 /*138*/].f_131;
										}
									}
									gameplay::shoot_single_bullet_between_coords(func_4(), Local_65.f_45, iVar0, 1,
																				 joaat("weapon_passenger_rocket"),
																				 player::player_ped_id(), 1, 1, -1f);
									audio::play_sound_from_coord(-1, "Prison_Finale_Buzzard_Rocket_Player", func_4(),
																 "DLC_HEISTS_GENERIC_SOUNDS", 0, 0, 0);
									func_20(&Global_2433125.f_3458, 0, 0);
								}
							}
						}
					}
				}
			}
			else if (func_19(&Global_2433125.f_3458, 2000, 0)) {
				func_18(&Global_2433125.f_3458);
				Global_2433125.f_3458 = {Var2};
			}
		}
	}
}

// Position - 0xC3E
void func_18(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0xC4B
bool func_19(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_20(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0xCA9
void func_20(var *uParam0, int iParam1, int iParam2) {
	if (uParam0->f_1 == 0) {
		if (network::network_is_game_in_progress() && !iParam1) {
			if (!iParam2) {
				*uParam0 = network::get_network_time();
			}
			else {
				*uParam0 = network::_0x89023FBBF9200E9F();
			}
		}
		else {
			*uParam0 = gameplay::get_game_timer();
		}
		uParam0->f_1 = 1;
	}
}

// Position - 0xCEE
bool func_21(int iParam0, int iParam1) {
	int iVar0;

	if (Global_1312447 != 0) {
		return false;
	}
	if (!func_22(iParam0)) {
		return false;
	}
	iVar0 = iParam0;
	if (Global_1591201[iVar0 /*602*/] == iParam1) {
		return true;
	}
	return false;
}

// Position - 0xD27
int func_22(int iParam0) {
	if (iParam0 == -1) {
		return 0;
	}
	else {
		return gameplay::is_bit_set(Global_2433125.f_1, iParam0);
	}
	return 1;
}

// Position - 0xD4C
bool func_23(var *uParam0) { return uParam0->f_1; }

// Position - 0xD58
void func_24(int *iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	vector3 vVar6;
	float fVar9;
	float fVar10;
	float fVar11;
	vector3 vVar12;
	bool bVar15;
	float fVar16;
	float fVar17;
	int iVar18;
	float fVar19;
	vector3 vVar20;
	float fVar23;
	float fVar24;
	vector3 vVar25;
	float fVar28;

	fVar5 = -75f;
	if (iParam0->f_204) {
		fVar5 = -25f;
	}
	if (iParam0->f_33 == 1) {
		if (cam::does_cam_exist(iParam0->f_32)) {
			if (!cam::is_cam_active(iParam0->f_32)) {
				cam::set_cam_active(iParam0->f_32, 1);
				cam::render_script_cams(1, 0, 3000, 1, 0, 0);
			}
		}
		if (iParam0->f_35) {
			if (cam::does_cam_exist(iParam0->f_32)) {
				vVar6 = {cam::get_cam_coord(iParam0->f_32)};
				if (gameplay::get_ground_z_for_3d_coord(vVar6.x, vVar6.y, vVar6.z + 1f, &fVar9, 0)) {
					if (fVar9 > vVar6.z) {
						iParam0->f_34 = 1;
					}
				}
			}
		}
		if (iParam0->f_35 == 0) {
			if (cam::does_cam_exist(iParam0->f_32)) {
				if (entity::does_entity_exist(iParam0->f_9)) {
					if (!entity::is_entity_dead(iParam0->f_9, 0)) {
						if (iParam0->f_4) {
							switch (entity::get_entity_model(iParam0->f_9)) {
							case joaat("valkyrie"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 5.32f, -0.3f, 1);
								break;

							case joaat("polmav"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 2.75f, -1.25f, 1);
								break;

							case joaat("maverick"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 2.75f, -1.25f, 1);
								break;

							case joaat("savage"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 5.75f, -0.75f, 1);
								break;

							default:
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 1.958f, -0.618f, 1);
								break;
							}
						}
						else {
							switch (entity::get_entity_model(iParam0->f_9)) {
							case joaat("buzzard"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 1.958f, -0.468f, 1);
								break;

							case joaat("polmav"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 2.75f, -1.25f, 1);
								break;

							case joaat("buzzard2"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 1.958f, -0.618f, 1);
								break;

							case joaat("valkyrie"):
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 5.32f, -0.3f, 1);
								break;

							default:
								cam::attach_cam_to_entity(iParam0->f_32, iParam0->f_9, 0f, 1.958f, -0.618f, 1);
								break;
							}
						}
						iParam0->f_35 = 1;
					}
				}
			}
		}
		if (iParam0->f_35 == 1 && iParam0->f_7 == 0) {
			if (cam::does_cam_exist(iParam0->f_32)) {
				if (cam::is_cam_active(iParam0->f_32)) {
					if (!func_28(1)) {
						if (!controls::is_control_pressed(2, 19) && !ui::is_pause_menu_active()) {
							controls::set_input_exclusive(0, 39);
							fVar10 = 128f;
							if (controls::_is_input_disabled(0)) {
								fVar10 = 15f;
								fVar3 = controls::_0x4F8A26A890FD62FB(0, 291) * -fVar10;
								fVar4 = controls::_0x4F8A26A890FD62FB(0, 290) * fVar10;
							}
							else {
								iVar2 = system::floor(controls::_0x4F8A26A890FD62FB(0, 291) * -fVar10);
								iVar1 = system::floor(controls::_0x4F8A26A890FD62FB(0, 290) * fVar10);
							}
							iVar0 = system::floor(controls::get_disabled_control_normal(0, 39) * 128f);
						}
						if (!controls::_is_input_disabled(0)) {
							if (iVar0 > 0) {
								iVar0 -= 22;
								if (iVar0 < 0) {
									iVar0 = 0;
								}
							}
							if (iVar0 < 0) {
								iVar0 += 22;
								if (iVar0 > 0) {
									iVar0 = 0;
								}
							}
							if (iVar2 > 0) {
								iVar2 -= 22;
								if (iVar2 < 0) {
									iVar2 = 0;
								}
							}
							if (iVar2 < 0) {
								iVar2 += 22;
								if (iVar2 > 0) {
									iVar2 = 0;
								}
							}
							if (iVar1 > 0) {
								iVar1 -= 22;
								if (iVar1 < 0) {
									iVar1 = 0;
								}
							}
							if (iVar1 < 0) {
								iVar1 += 22;
								if (iVar1 > 0) {
									iVar1 = 0;
								}
							}
						}
						fVar11 = iParam0->f_42 / -75f * 0.5f;
						if (fVar11 > 0f) {
							fVar11++;
						}
						else {
							fVar11 = 1f;
						}
						if (controls::_is_input_disabled(0)) {
							iParam0->f_56 = fVar3 * iParam0->f_40 * iParam0->f_36;
							iParam0->f_57 = fVar4 * iParam0->f_40 * iParam0->f_36 * fVar11;
						}
						else {
							iParam0->f_56 =
								system::to_float(iVar2) * iParam0->f_40 * iParam0->f_36 * system::timestep();
							iParam0->f_57 =
								system::to_float(iVar1) * iParam0->f_40 * iParam0->f_36 * fVar11 * system::timestep();
						}
						iParam0->f_57 = func_27(iParam0->f_57, -1020002304, 1127481344);
						if (func_26(iParam0->f_45, 0f, 0f, 0f, 0)) {
							vVar12 = {cam::get_cam_coord(iParam0->f_32)};
							iParam0->f_45 = system::sin(iParam0->f_42.f_2) * 150f;
							iParam0->f_45.f_1 = system::cos(iParam0->f_42.f_2) * 150f;
							iParam0->f_45.f_2 = vVar12.z;
						}
						if (iParam0->f_4) {
							if (iVar2 != 0 && iVar1 != 0) {
								iParam0->f_42 = {cam::get_cam_rot(iParam0->f_32, 2)};
							}
						}
						else {
							iParam0->f_42 = {cam::get_cam_rot(iParam0->f_32, 2)};
						}
						if (!func_26(cam::get_cam_coord(iParam0->f_32), 0f, 0f, 0f, 0)) {
							if (iParam0->f_25 != 0f) {
								if (vehicle::is_vehicle_driveable(iParam0->f_8, 0)) {
									fVar16 = entity::get_entity_heading(iParam0->f_8);
									fVar17 = fVar16 - iParam0->f_42.f_2;
									while (gameplay::absf(fVar17) >= 180f && iVar18 < 30) {
										if (fVar17 < 0f) {
											fVar17 += 360f;
										}
										else {
											fVar17 -= 360f;
										}
										iVar18++;
										if (iVar18 == 30) {
										}
									}
									if (gameplay::absf(fVar17) > iParam0->f_25) {
										bVar15 = true;
										if (fVar17 > 0f) {
											iParam0->f_42.f_2 = fVar16 - iParam0->f_25;
										}
										else {
											iParam0->f_42.f_2 = fVar16 + iParam0->f_25;
										}
									}
								}
							}
							if (iParam0->f_56 != 0f || iParam0->f_57 != 0f) {
								iLocal_62++;
								iParam0->f_42 = {iParam0->f_42 + Vector(-iParam0->f_57, 0f, iParam0->f_56)};
								if (iParam0->f_42 < fVar5) {
									iParam0->f_42 = fVar5;
								}
								if (iParam0->f_42 > 6f) {
									iParam0->f_42 = 6f;
								}
								if (iLocal_62 > 5) {
									if (!func_25(vLocal_59, iParam0->f_42, 0.05f, 0)) {
										vLocal_59 = {iParam0->f_42};
										iLocal_63 = 0;
									}
									else {
										iLocal_63 = 1;
									}
									iLocal_62 = 0;
								}
								if (iParam0->f_197 != -1) {
									if (bVar15) {
										fVar19 = 0f;
									}
									else {
										fVar19 += gameplay::absf(iParam0->f_57);
									}
									if (iParam0->f_42 < 6f && iParam0->f_42 > -75f) {
										fVar19 += gameplay::absf(iParam0->f_56);
									}
									if (fVar19 != 0f) {
										if (audio::has_sound_finished(iParam0->f_197) && !iLocal_63) {
											audio::play_sound_frontend(iParam0->f_197, "COP_HELI_CAM_TURN", 0, 1);
										}
										if (!audio::has_sound_finished(iParam0->f_197)) {
											if (!iLocal_63) {
												audio::set_variable_on_sound(iParam0->f_197, "Ctrl", fVar19);
											}
											else {
												audio::stop_sound(iParam0->f_197);
												iLocal_62 = 6;
											}
										}
									}
								}
							}
							else if (iParam0->f_197 != -1) {
								if (!audio::has_sound_finished(iParam0->f_197)) {
									audio::stop_sound(iParam0->f_197);
									iLocal_63 = 1;
									iLocal_62 = 6;
								}
							}
							vVar20 = {iParam0->f_159};
							if (iParam0->f_4) {
								fVar23 = 150f;
							}
							else {
								fVar23 =
									gameplay::get_distance_between_coords(vVar20, cam::get_cam_coord(iParam0->f_32), 1);
							}
							iParam0->f_45 = system::cos(iParam0->f_42) * fVar23 * system::sin(-iParam0->f_42.f_2);
							iParam0->f_45.f_1 = system::cos(iParam0->f_42) * fVar23 * system::cos(-iParam0->f_42.f_2);
							iParam0->f_45.f_2 = system::sin(iParam0->f_42) * fVar23;
							iParam0->f_45 = {iParam0->f_45 + cam::get_cam_coord(iParam0->f_32)};
							cam::point_cam_at_coord(iParam0->f_32, iParam0->f_45);
						}
						if (!(iVar0 == 0 || iParam0->f_40 == iParam0->f_38 || iParam0->f_40 == iParam0->f_39)) {
							if (iParam0->f_196 != -1) {
								if (audio::has_sound_finished(iParam0->f_196)) {
									audio::play_sound_frontend(iParam0->f_196, "COP_HELI_CAM_ZOOM", 0, 1);
								}
							}
							if (iParam0->f_196 != -1) {
								if (!audio::has_sound_finished(iParam0->f_196)) {
									audio::set_variable_on_sound(iParam0->f_196, "Ctrl",
																 gameplay::absf(system::to_float(iVar0) / 128f));
									if (iVar0 < 0) {
										audio::set_variable_on_sound(iParam0->f_196, "Dir", -1f);
									}
								}
							}
						}
						else if (iParam0->f_196 != -1) {
							if (!audio::has_sound_finished(iParam0->f_196)) {
								audio::stop_sound(iParam0->f_196);
							}
						}
						iParam0->f_40 += system::to_float(iVar0) / iParam0->f_37 * system::timestep();
						if (iParam0->f_40 > iParam0->f_38) {
							iParam0->f_40 = iParam0->f_38;
						}
						if (iParam0->f_40 < iParam0->f_39) {
							iParam0->f_40 = iParam0->f_39;
						}
						cam::custom_menu_coordinates(1f);
						cam::set_cam_fov(iParam0->f_32, iParam0->f_40);
						fVar24 = (iParam0->f_40 - 5f) / 42f;
						graphics::_0xE2892E7E55D7073A(fVar24);
					}
				}
			}
		}
		else if (iParam0->f_35 == 1 && iParam0->f_7 == 1) {
			vVar25 = {iParam0->f_159};
			fVar28 = gameplay::get_distance_between_coords(vVar25, cam::get_cam_coord(iParam0->f_32), 1);
			iParam0->f_45 = system::cos(iParam0->f_42) * fVar28 * system::sin(-iParam0->f_42.f_2);
			iParam0->f_45.f_1 = system::cos(iParam0->f_42) * fVar28 * system::cos(-iParam0->f_42.f_2);
			iParam0->f_45.f_2 = system::sin(iParam0->f_42) * fVar28;
			iParam0->f_45 = {iParam0->f_45 + cam::get_cam_coord(iParam0->f_32)};
			cam::point_cam_at_coord(iParam0->f_32, iParam0->f_45);
			cam::set_cam_fov(iParam0->f_32, iParam0->f_40);
		}
	}
	else if (cam::does_cam_exist(iParam0->f_32)) {
		if (cam::is_cam_active(iParam0->f_32)) {
			cam::set_cam_active(iParam0->f_32, 0);
			cam::render_script_cams(0, 0, 3000, 1, 0, 0);
		}
	}
}

// Position - 0x1667
int func_25(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return 1;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x16E2
bool func_26(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x1729
float func_27(float fParam0, float fParam1, float fParam2) {
	while (fParam0 < fParam1) {
		fParam0 += 360f;
	}
	while (fParam0 > fParam2) {
		fParam0 -= 360f;
	}
	return fParam0;
}

// Position - 0x175D
bool func_28(int iParam0) {
	if (iParam0) {
		return Global_17151.f_4 && Global_17151.f_104 == 4;
	}
	return Global_17151.f_4;
}

// Position - 0x1786
void func_29(int *iParam0, int iParam1) {
	if (cam::does_cam_exist(iParam0->f_32)) {
	}
	if (entity::does_entity_exist(iParam0->f_8)) {
		iParam0->f_9 = func_66(iParam0->f_8);
	}
	if (*iParam0 == 0) {
		if (func_67(iParam0, iParam1)) {
			*iParam0 = 1;
		}
	}
	else {
		if (iParam1 == 0) {
			func_44(iParam0);
			func_24(iParam0);
			func_43(iParam0);
		}
		func_42(iParam0);
		func_31(iParam0, iParam1);
		func_30();
	}
}

// Position - 0x17F3
void func_30() { Global_89108 = 1; }

// Position - 0x1800
void func_31(int *iParam0, int iParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	vector3 vVar12;
	float fVar15;
	float fVar16;
	float fVar17;
	float fVar18;
	var uVar19;
	int iVar20;
	float fVar21;
	vector3 vVar22;
	int iVar25;
	vector3 vVar26;
	int iVar29;
	vector3 vVar30;
	vector3 vVar33;
	vector3 vVar36;
	float fVar39;
	vector3 vVar40;
	float fVar43;
	float fVar44;
	float fVar45;
	float fVar46;
	float fVar47;

	if (iParam0->f_50 == 1) {
		fVar0 = (iParam0->f_42 - iParam0->f_31) / (iParam0->f_30 - iParam0->f_31);
		if (fVar0 < 0f) {
			fVar0 = 0f;
		}
		if (fVar0 > 1f) {
			fVar0 = 1f;
		}
		fVar1 = iParam0->f_26 + (iParam0->f_28 - iParam0->f_26) * fVar0;
		fVar2 = iParam0->f_27 + (iParam0->f_29 - iParam0->f_27) * fVar0;
		streaming::_0xBED8CA5FF5E04113(1.7f, 4.7f, fVar1, fVar2);
		fVar3 = entity::get_entity_speed(iParam0->f_8);
		if (fVar3 > 30f) {
			streaming::_0x472397322E92A856();
		}
		streaming::_0x03F1A106BDA7DD3E();
		if (!graphics::has_streamed_texture_dict_loaded("helicopterhud") ||
			iParam1 == 0 && !graphics::has_scaleform_movie_loaded(iLocal_64)) {
			iParam0->f_86 = 0;
		}
		else {
			iParam0->f_80 = 1f - 2f * iParam0->f_54;
			graphics::_set_2d_layer(1);
			if (iParam1 == 0) {
				graphics::_set_2d_layer(0);
				graphics::draw_scaleform_movie_fullscreen(iLocal_64, 255, 255, 255, 0, 1);
				ui::hide_hud_component_this_frame(14);
				if (!iParam0->f_86) {
					if (vehicle::is_vehicle_driveable(iParam0->f_8, 0)) {
						if (entity::get_entity_model(iParam0->f_8) == joaat("polmav") &&
							vehicle::get_vehicle_livery(iParam0->f_8) == 0) {
							graphics::_push_scaleform_movie_function(iLocal_64, "SET_CAM_LOGO");
							graphics::_push_scaleform_movie_function_parameter_int(1);
							graphics::_pop_scaleform_movie_function_void();
						}
						else {
							graphics::_push_scaleform_movie_function(iLocal_64, "SET_CAM_LOGO");
							graphics::_push_scaleform_movie_function_parameter_int(0);
							graphics::_pop_scaleform_movie_function_void();
						}
					}
					else {
						graphics::_push_scaleform_movie_function(iLocal_64, "SET_CAM_LOGO");
						graphics::_push_scaleform_movie_function_parameter_int(0);
						graphics::_pop_scaleform_movie_function_void();
					}
				}
			}
			iParam0->f_86 = 1;
		}
		if (iParam0->f_86 == 1) {
			if (iParam1 == 0) {
			}
			fVar18 = iParam0->f_157;
			iVar20 = -1;
			if (!entity::is_entity_dead(iParam0->f_9, 0)) {
				vVar22 = {entity::get_entity_coords(iParam0->f_9, 1)};
			}
			if (iParam0->f_87 == 0) {
				iVar4 = 0;
				iParam0->f_53 = 0;
				iVar4 = 0;
				while (iVar4 < iParam0->f_175) {
					if (gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 9)) {
						if (entity::does_entity_exist(iParam0->f_175[iVar4 /*10*/])) {
							if (!entity::is_entity_dead(iParam0->f_175[iVar4 /*10*/], 0)) {
								if (gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 0)) {
									switch (iParam0->f_175[iVar4 /*10*/].f_4) {
									case 2:
										func_40(
											iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_65, iParam0->f_65.f_1, iParam0->f_65.f_2);
										break;

									case 3:
										func_40(
											iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_68, iParam0->f_68.f_1, iParam0->f_68.f_2);
										break;

									case 0:
										func_40(
											iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_62, iParam0->f_62.f_1, iParam0->f_62.f_2);
										break;

									case 1:
										func_40(
											iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_68, iParam0->f_68.f_1, iParam0->f_68.f_2);
										break;
									}
								}
								else if (time::get_clock_hours() < 19 && time::get_clock_hours() > 7) {
									func_40(iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_62, iParam0->f_62.f_1, iParam0->f_62.f_2);
								}
								else {
									func_40(iParam0,
											entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0),
											iParam0->f_62, iParam0->f_62.f_1, iParam0->f_62.f_2);
								}
							}
						}
					}
					iVar4++;
				}
				if (!entity::is_entity_dead(iParam0->f_9, 0)) {
					gameplay::get_ground_z_for_3d_coord(vVar22, &uVar19, 0);
					if (iParam0->f_52 == 0 && iParam0->f_48 > 0) {
						iVar4 = 0;
						while (iVar4 <= iParam0->f_48 - 1) {
							if (entity::does_entity_exist(iParam0->f_175[iVar4 /*10*/])) {
								if (!entity::is_entity_dead(iParam0->f_175[iVar4 /*10*/], 0) &&
									!entity::is_entity_dead(player::player_ped_id(), 0)) {
									vVar12 = {
										entity::get_world_position_of_entity_bone(iParam0->f_175[iVar4 /*10*/], 0)};
									if (entity::is_entity_on_screen(iParam0->f_175[iVar4 /*10*/])) {
										fVar8 = 0f;
										fVar9 = 0f;
										fVar16 = gameplay::get_distance_between_coords(
											vVar12, entity::get_entity_coords(iParam0->f_9, 1), 1);
										fVar21 = func_39(iParam0, iParam0->f_175[iVar4 /*10*/], iParam0->f_9);
										fVar17 = iParam0->f_74 * fVar21;
										if (gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 2) ||
											iVar4 == iParam0->f_92) {
											if (gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 0)) {
												if (system::timera() - iParam0->f_175[iVar4 /*10*/].f_1 < 500) {
													func_38(iParam0, vVar12, fVar21, iParam0->f_175[iVar4 /*10*/].f_4,
															-1, -1, -1);
													iParam0->f_175[iVar4 /*10*/].f_6 = {
														entity::get_entity_coords(iParam0->f_175[iVar4 /*10*/
													],
																				  1)};
												}
												else {
													func_37(iParam0, iParam0->f_175[iVar4 /*10*/].f_4, &iVar5, &iVar6,
															&iVar7);
													graphics::set_draw_origin(iParam0->f_175[iVar4 /*10*/].f_6, 0);
													graphics::draw_sprite("helicopterhud", "TargetLost", fVar8, fVar9,
																		  fVar17, fVar17 * 2f, 0f, iVar5, iVar6, iVar7,
																		  200, 1);
													graphics::clear_draw_origin();
													func_36(iVar5, iVar6, iVar7, 0.5f, 1);
													iParam0->f_53 = 1;
												}
											}
											else {
												func_37(iParam0, 3, &iVar5, &iVar6, &iVar7);
												if (iVar4 == iParam0->f_92) {
													func_38(iParam0, vVar12, fVar21, iParam0->f_175[iVar4 /*10*/].f_4,
															iParam0->f_62, iParam0->f_62.f_1, iParam0->f_62.f_2);
												}
												else {
													func_38(iParam0, vVar12, fVar21, iParam0->f_175[iVar4 /*10*/].f_4,
															iParam0->f_62, iParam0->f_62.f_1, iParam0->f_62.f_2);
												}
											}
											if (gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 7)) {
												func_38(iParam0, vVar12, fVar21, iParam0->f_175[iVar4 /*10*/].f_4, 227,
														24, 234);
											}
										}
										iVar25 = 0;
										vVar26 = {0f, 0f, 0f};
										iVar29 = 0;
										switch (worldprobe::get_shape_test_result(iParam0->f_175[iVar4 /*10*/].f_9,
																				  &iVar25, &vVar26, &vVar26, &iVar29)) {
										case 0:
											vVar30 = {entity::get_entity_coords(iParam0->f_8, 1)};
											vVar33 = {entity::get_entity_coords(iParam0->f_175[iVar4 /*10*/], 1) +
													  Vector(0.5f, 0f, 0f)};
											iParam0->f_175[iVar4 /*10*/].f_9 =
												worldprobe::start_shape_test_los_probe(vVar30, vVar33, 1, 0, 7);
											break;

										case 2:
											if (iVar25 == 0) {
												iParam0->f_175[iVar4 /*10*/].f_1 = system::timera();
											}
											break;
										}
										if (system::timera() - iParam0->f_175[iVar4 /*10*/].f_1 < 1500 ||
											gameplay::is_bit_set(iParam0->f_175[iVar4 /*10*/].f_2, 0)) {
											if (iParam0->f_78 / (iParam0->f_40 * fVar16) > 1f) {
												graphics::get_screen_coord_from_world_coord(vVar12, &fVar8, &fVar9);
												fVar15 = system::sqrt((fVar8 - 0.5f) * (fVar8 - 0.5f) +
																	  (fVar9 - 0.5f) * (fVar9 - 0.5f));
												if (fVar15 < fVar18) {
													fVar10 = fVar8;
													fVar11 = fVar9;
													fVar10 = fVar10;
													fVar11 = fVar11;
													fVar18 = fVar15;
													iVar20 = iVar4;
												}
											}
										}
										graphics::clear_draw_origin();
									}
								}
							}
							iVar4++;
						}
					}
					iParam0->f_76++;
					if (iParam0->f_76 > iParam0->f_48 - 1) {
						iParam0->f_76 = 0;
					}
				}
				if (iParam0->f_92 != iVar20) {
					if (iParam0->f_198 != -1) {
						if (audio::has_sound_finished(iParam0->f_198)) {
							audio::play_sound_frontend(iParam0->f_198, "COP_HELI_CAM_BLEEP", 0, 1);
						}
					}
				}
				iParam0->f_92 = iVar20;
				iParam0->f_49 = 0;
				if (iParam0->f_92 != -1 && iParam0->f_2 == 1) {
					if (!gameplay::is_bit_set(iParam0->f_175[iParam0->f_92 /*10*/].f_2, 0)) {
						if (controls::is_control_pressed(2, 229)) {
							if (iParam0->f_77 / (iParam0->f_40 * fVar16) > 0.5f) {
								if (iParam0->f_195 == 1) {
									if (iParam0->f_203 != -1) {
										if (!audio::has_sound_finished(iParam0->f_203)) {
											audio::stop_sound(iParam0->f_203);
										}
									}
									iParam0->f_195 = 0;
								}
								iParam0->f_49 = 1;
								if (iParam0->f_175[iParam0->f_92 /*10*/].f_3 < 1f) {
									if (iParam0->f_200 != -1) {
										if (audio::has_sound_finished(iParam0->f_200)) {
											audio::play_sound_frontend(iParam0->f_200, "COP_HELI_CAM_SCAN_PED_LOOP", 0,
																	   1);
										}
									}
									fVar18 = gameplay::absf(1f - fVar18);
									iParam0->f_175[iParam0->f_92 /*10*/].f_3 += fVar18 * system::timestep() / 3.5f;
									fVar21 = func_39(iParam0, iParam0->f_175[iParam0->f_92 /*10*/], iParam0->f_9);
									fVar17 = iParam0->f_74 * fVar21;
									func_36(255, 0, 0, 0.5f, 1);
									if (system::timera() % 600 < 300) {
										func_35(0.5f, 0.68f, "scan", 1);
									}
									fVar21 = func_39(iParam0, iParam0->f_175[iParam0->f_92 /*10*/], iParam0->f_9);
									fVar17 = 0.03f;
									graphics::set_draw_origin(entity::get_world_position_of_entity_bone(
																  iParam0->f_175[iParam0->f_92 /*10*/], 0),
															  0);
									func_33(iParam0, iParam0->f_175[iParam0->f_92 /*10*/],
											iParam0->f_175[iParam0->f_92 /*10*/].f_3, fVar21);
									graphics::clear_draw_origin();
								}
								else {
									if (gameplay::is_bit_set(iParam0->f_175[iParam0->f_92 /*10*/].f_2, 3)) {
										gameplay::set_bit(&iParam0->f_175[iParam0->f_92 /*10*/].f_2, 2);
									}
									gameplay::set_bit(&iParam0->f_175[iParam0->f_92 /*10*/].f_2, 0);
									iParam0->f_55 = iParam0->f_175[iParam0->f_92 /*10*/];
									if (iParam0->f_200 != -1) {
										if (!audio::has_sound_finished(iParam0->f_200)) {
											audio::stop_sound(iParam0->f_200);
										}
									}
									if (iParam0->f_175[iParam0->f_92 /*10*/].f_4 == 2) {
										if (iParam0->f_201 != -1) {
											if (audio::has_sound_finished(iParam0->f_201)) {
												audio::play_sound_frontend(iParam0->f_201,
																		   "COP_HELI_CAM_SCAN_PED_"
																		   "SUCCESS",
																		   0, 1);
											}
										}
									}
									else if (iParam0->f_202 != -1) {
										if (audio::has_sound_finished(iParam0->f_202)) {
											audio::play_sound_frontend(iParam0->f_202, "COP_HELI_CAM_SCAN_PED_FAILURE",
																	   0, 1);
										}
									}
								}
							}
							else {
								fVar21 = func_39(iParam0, iParam0->f_175[iParam0->f_92 /*10*/], iParam0->f_9);
								fVar17 = iParam0->f_74 * fVar21;
								func_36(255, 0, 0, 0.5f, 1);
								func_35(0.5f, 0.68f, "HUD_RNG", 0);
								if (!iParam0->f_195) {
									if (iParam0->f_203 != -1) {
										if (audio::has_sound_finished(iParam0->f_203)) {
											audio::play_sound_frontend(iParam0->f_203, "COP_HELI_CAM_BLEEP_TOO_FAR", 0,
																	   1);
											iParam0->f_195 = 1;
										}
									}
								}
							}
						}
						else if (iParam0->f_195 == 1) {
							if (iParam0->f_203 != -1) {
								if (!audio::has_sound_finished(iParam0->f_203)) {
									audio::stop_sound(iParam0->f_203);
								}
							}
							iParam0->f_195 = 0;
						}
					}
					else if (controls::is_control_pressed(2, 229) ||
							 gameplay::get_game_timer() < iParam0->f_94 && iParam0->f_93 == iParam0->f_92) {
						if (!entity::is_entity_dead(iParam0->f_175[iParam0->f_92 /*10*/], 0)) {
							if (system::timera() - iParam0->f_175[iParam0->f_92 /*10*/].f_1 < 500) {
								if (!iParam0->f_53) {
									iParam0->f_93 = iParam0->f_92;
									iParam0->f_94 = gameplay::get_game_timer() + 3000;
									graphics::set_draw_origin(entity::get_world_position_of_entity_bone(
																  iParam0->f_175[iParam0->f_92 /*10*/], 0),
															  0);
									fVar21 = func_39(iParam0, iParam0->f_175[iParam0->f_92 /*10*/], iParam0->f_9);
									fVar8 = 0f;
									fVar9 = 0f;
									func_37(iParam0, iParam0->f_175[iParam0->f_92 /*10*/].f_4, &iVar5, &iVar6, &iVar7);
									graphics::clear_draw_origin();
									if (iParam0->f_175[iParam0->f_92 /*10*/].f_4 == 2) {
										func_32(iParam0, iParam0->f_92, fVar8 - fVar17 / 2f + fVar17 * 0.04f,
												fVar9 + fVar17 + 0.005f, iVar5, iVar6, iVar7, fVar21, 1);
									}
									else {
										func_32(iParam0, iParam0->f_92, fVar8 - fVar17 / 2f + fVar17 * 0.04f,
												fVar9 + fVar17 + 0.005f, iVar5, iVar6, iVar7, fVar21, 0);
									}
								}
							}
						}
					}
				}
				if (iParam0->f_49 == 0) {
					if (iParam0->f_200 != -1) {
						if (!audio::has_sound_finished(iParam0->f_200)) {
							audio::stop_sound(iParam0->f_200);
						}
					}
				}
			}
			if (iParam0->f_162 > 0) {
				iVar4 = 0;
				while (iVar4 <= 0) {
					if (iParam0->f_163[iVar4 /*11*/].f_5 != -1) {
						if (graphics::get_screen_coord_from_world_coord(iParam0->f_163[iVar4 /*11*/], &fVar8, &fVar9)) {
							if (entity::does_entity_exist(iParam0->f_8) &&
								vehicle::is_vehicle_driveable(iParam0->f_8, 0)) {
								vVar36 = {entity::get_entity_coords(iParam0->f_8, 1)};
							}
							else if (entity::does_entity_exist(iParam0->f_9) &&
									 !entity::is_entity_dead(iParam0->f_9, 0)) {
								vVar36 = {entity::get_entity_coords(iParam0->f_9, 1)};
							}
							graphics::set_draw_origin(iParam0->f_163[iVar4 /*11*/], 0);
							fVar8 = 0f;
							fVar9 = 0f;
							if (iParam0->f_163[iVar4 /*11*/].f_6 == 1) {
								fVar16 = gameplay::get_distance_between_coords(iParam0->f_163[iVar4 /*11*/], vVar36, 1);
								fVar21 = iParam0->f_79 / (iParam0->f_40 * fVar16);
								if (fVar21 < 0.4f) {
									fVar21 = 0.4f;
								}
								if (fVar21 > 2f) {
									fVar21 = 2f;
								}
								func_38(iParam0, iParam0->f_163[iVar4 /*11*/], fVar21, 0, -1, -1, -1);
								graphics::set_draw_origin(iParam0->f_163[iVar4 /*11*/], 0);
							}
							else {
								graphics::draw_sprite("helicopterhud", "hud_dest", fVar8, fVar9, 0.042f, 0.042f, 0f,
													  iParam0->f_163[iVar4 /*11*/].f_8,
													  iParam0->f_163[iVar4 /*11*/].f_9,
													  iParam0->f_163[iVar4 /*11*/].f_10, 255, 1);
							}
							graphics::clear_draw_origin();
						}
						else if (iParam0->f_163[iVar4 /*11*/].f_6 == 1) {
							func_40(iParam0, iParam0->f_163[iVar4 /*11*/], iParam0->f_163[iVar4 /*11*/].f_8,
									iParam0->f_163[iVar4 /*11*/].f_9, iParam0->f_163[iVar4 /*11*/].f_10);
						}
						else {
							func_40(iParam0, iParam0->f_163[iVar4 /*11*/], iParam0->f_163[iVar4 /*11*/].f_8,
									iParam0->f_163[iVar4 /*11*/].f_9, iParam0->f_163[iVar4 /*11*/].f_10);
						}
					}
					iVar4++;
				}
			}
			if (iParam1 == 0) {
				fVar39 = iParam0->f_42.f_2;
				vVar40 = {0f, 0f, 0f};
				if (entity::does_entity_exist(iParam0->f_9)) {
					if (!entity::is_entity_dead(iParam0->f_9, 0)) {
						vVar40 = {entity::get_entity_coords(iParam0->f_9, 1)};
						fVar47 = entity::get_entity_heading(iParam0->f_9);
					}
				}
				while (fVar39 < 0f) {
					fVar39 += 360f;
				}
				while (fVar39 > 360f) {
					fVar39 -= 360f;
				}
				while (fVar47 < 0f) {
					fVar47 += 360f;
				}
				while (fVar47 > 360f) {
					fVar47 -= 360f;
				}
				fVar46 = fVar39;
				fVar44 = fVar47 - iParam0->f_25;
				fVar45 = fVar47 + iParam0->f_25;
				if (fVar46 < fVar44 && fVar46 + 360f <= fVar45) {
					fVar46 += 360f;
				}
				if (fVar46 > fVar45 && fVar46 - 360f >= fVar44) {
					fVar46 -= 360f;
				}
				fVar43 = (fVar46 - fVar44) / (fVar45 - fVar44);
				if (fVar43 == 2f) {
					fVar43 = 0f;
				}
				else if (fVar43 == -1f) {
					fVar43 = 1f;
				}
				else if (fVar43 < 0f && fVar43 >= -0.5f) {
					fVar43 = 0f;
				}
				else if (fVar43 < 0f && fVar43 > -1f) {
					fVar43 = 1f;
				}
				else if (fVar43 > 1.5f && fVar43 < 2f) {
					fVar43 = 0f;
				}
				else if (fVar43 > 2f || fVar43 < -1f) {
					fVar43 = 0.5f;
				}
				graphics::_push_scaleform_movie_function(iLocal_64, "SET_ALT_FOV_HEADING");
				graphics::_push_scaleform_movie_function_parameter_float(vVar40.z);
				if (network::network_is_game_in_progress()) {
					graphics::_push_scaleform_movie_function_parameter_float(fVar43);
				}
				else {
					graphics::_push_scaleform_movie_function_parameter_float((iParam0->f_40 - iParam0->f_39) /
																			 (iParam0->f_38 - iParam0->f_39));
				}
				graphics::_push_scaleform_movie_function_parameter_float(fVar39);
				graphics::_pop_scaleform_movie_function_void();
				ui::hide_hud_component_this_frame(3);
				if (!iParam0->f_51) {
					ui::hide_hud_and_radar_this_frame();
				}
			}
		}
	}
}

// Position - 0x267D
int func_32(var *uParam0, int iParam1, float fParam2, float fParam3, int iParam4, int iParam5, int iParam6,
			float fParam7, int iParam8) {
	struct<2> Var0;
	int iVar4;
	int iVar5;

	func_36(iParam4, iParam5, iParam6, 0.43f, iParam8);
	if (fParam7 < 0.7f) {
		fParam7 = 0.7f;
	}
	if (fParam7 > 1.5f) {
		fParam7 = 1.5f;
	}
	if (gameplay::is_bit_set(uParam0->f_175[iParam1 /*10*/].f_2, 8)) {
	}
	iVar4 = 24;
	while (iVar4 <= 31) {
		if (gameplay::is_bit_set(uParam0->f_175[iParam1 /*10*/].f_5, iVar4)) {
			StringCopy(&Var0, "crimes_", 16);
			StringIntConCat(&Var0, iVar4 - 23, 16);
			func_36(iParam4, iParam5, iParam6, 0.43f, iParam8);
			func_35(0.5f, 0.68f + 0.037f * IntToFloat(iVar5 + 1), &Var0, 1);
			iVar5++;
		}
		iVar4++;
	}
	if (iVar5 == 0) {
		func_36(iParam4, iParam5, iParam6, 0.43f, iParam8);
		func_35(fParam2, fParam3 + uParam0->f_190 * fParam7, "unknown", 1);
	}
	if (uParam0->f_175[iParam1 /*10*/].f_4 == 0) {
		func_36(iParam4, iParam5, iParam6, 0.43f, iParam8);
		func_35(fParam2, fParam3 + uParam0->f_190 * fParam7, "HUD_ID2", 1);
	}
	return 1;
}

// Position - 0x279A
void func_33(var *uParam0, int iParam1, float fParam2, float fParam3) {
	vector3 vVar0;
	vector3 vVar3;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	vector3 vVar12;
	float fVar15;
	float fVar16;

	vVar12 = {0f, 0f, 0f};
	if (fParam2 < 0.5f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 14201, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 63931, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 52301, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 36864, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
	}
	if (fParam2 > 0.15f && fParam2 < 0.7f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 36864, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 51826, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.15f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 63931, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 58271, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.15f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
	}
	if (fParam2 > 0.3f && fParam2 < 1f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 11816, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 39317, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.3f;
		fVar16 = 0.5f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 2f);
	}
	if (fParam2 > 0.6f && fParam2 < 1f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 31086, vVar12)};
			vVar3 = {vVar0 + vVar0 - ped::get_ped_bone_coords(iParam1, 39317, vVar12) * FtoV(3f)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.6f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1.3f);
	}
	if (fParam2 > 0.6f && fParam2 < 1f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 40269, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 28252, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.6f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 45509, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 61163, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.6f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
	}
	if (fParam2 > 0.75f && fParam2 < 1f) {
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 28252, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 57005, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.75f;
		fVar16 = 0.25f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
		if (!ped::is_ped_injured(iParam1)) {
			vVar0 = {ped::get_ped_bone_coords(iParam1, 61163, vVar12)};
			vVar3 = {ped::get_ped_bone_coords(iParam1, 18905, vVar12)};
			graphics::set_draw_origin(vVar0, 0);
			graphics::get_screen_coord_from_world_coord(vVar0, &fVar8, &fVar9);
			graphics::get_screen_coord_from_world_coord(vVar3, &fVar10, &fVar11);
			fVar6 = (fVar10 - fVar8) / 10f;
			fVar7 = (fVar11 - fVar9) / 10f;
		}
		fVar15 = 0.75f;
		fVar16 = 0.3f;
		func_34(uParam0, fParam2, fVar15, fVar16, fVar6, fVar7, fParam3, fVar10, fVar8, fVar11, fVar9, 1065353216);
	}
	graphics::clear_draw_origin();
}

// Position - 0x2E0B
void func_34(var *uParam0, float fParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			 float fParam7, float fParam8, float fParam9, float fParam10, float fParam11) {
	int iVar0;
	float fVar1;
	float fVar2;

	fVar2 = fParam3 / 10f;
	iVar0 = 0;
	while (iVar0 <= 10) {
		fVar1 = fParam1 - (fParam2 + IntToFloat(iVar0) * fVar2);
		if (fVar1 > 0f && fVar1 < 0.3f) {
			fVar1 = system::sin(fVar1 * 600f);
			graphics::draw_sprite("helicopterhud", "hud_line", fParam4 * IntToFloat(iVar0), fParam5 * IntToFloat(iVar0),
								  fParam6 * fParam11 * 0.01f, fParam6 * fParam11 * 0.01f,
								  gameplay::get_angle_between_2d_vectors(0f, 1f, fParam7 - fParam8, fParam9 - fParam10),
								  uParam0->f_71, uParam0->f_71.f_1, uParam0->f_71.f_2, system::floor(fVar1 * 32f), 1);
		}
		iVar0++;
	}
}

// Position - 0x2EBA
void func_35(float fParam0, float fParam1, char *sParam2, int iParam3) {
	ui::begin_text_command_display_text(sParam2);
	ui::end_text_command_display_text(fParam0, fParam1, iParam3);
}

// Position - 0x2ED2
void func_36(int iParam0, int iParam1, int iParam2, float fParam3, int iParam4) {
	ui::set_text_scale(fParam3, fParam3);
	ui::set_text_colour(iParam0, iParam1, iParam2, 150);
	if (iParam4) {
		ui::set_text_dropshadow(5, 0, 0, 0, 255);
	}
	ui::set_text_centre(1);
	ui::set_text_font(0);
}

// Position - 0x2F07
int func_37(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	switch (iParam1) {
	case 0:
		*iParam2 = uParam0->f_62;
		*iParam3 = uParam0->f_62.f_1;
		*iParam4 = uParam0->f_62.f_2;
		return 1;

	case 1:
		*iParam2 = 255;
		*iParam3 = 255;
		*iParam4 = 0;
		return 1;

	case 2:
		*iParam2 = uParam0->f_65;
		*iParam3 = uParam0->f_65.f_1;
		*iParam4 = uParam0->f_65.f_2;
		return 1;

	case 3:
		*iParam2 = uParam0->f_68;
		*iParam3 = uParam0->f_68.f_1;
		*iParam4 = uParam0->f_68.f_2;
		return 1;
	}
	return 0;
}

// Position - 0x2FA4
void func_38(var *uParam0, vector3 vParam1, float fParam4, int iParam5, int iParam6, int iParam7, int iParam8) {
	int iVar0;
	int iVar1;
	int iVar2;

	func_37(uParam0, iParam5, &iVar0, &iVar1, &iVar2);
	graphics::set_draw_origin(vParam1, 0);
	if (iParam6 != -1) {
		iVar0 = iParam6;
		iVar1 = iParam7;
		iVar2 = iParam8;
	}
	fParam4 *= 0.03f;
	graphics::draw_sprite("helicopterhud", "hud_corner", -fParam4 * 0.5f, -fParam4, 0.013f, 0.013f, 0f, iVar0, iVar1,
						  iVar2, 200, 1);
	graphics::draw_sprite("helicopterhud", "hud_corner", fParam4 * 0.5f, -fParam4, 0.013f, 0.013f, 90f, iVar0, iVar1,
						  iVar2, 200, 1);
	graphics::draw_sprite("helicopterhud", "hud_corner", -fParam4 * 0.5f, fParam4, 0.013f, 0.013f, 270f, iVar0, iVar1,
						  iVar2, 200, 1);
	graphics::draw_sprite("helicopterhud", "hud_corner", fParam4 * 0.5f, fParam4, 0.013f, 0.013f, 180f, iVar0, iVar1,
						  iVar2, 200, 1);
	graphics::clear_draw_origin();
}

// Position - 0x3098
float func_39(var *uParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	float fVar3;
	float fVar4;

	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar0 = {entity::get_world_position_of_entity_bone(iParam1, 0)};
		if (!entity::is_entity_dead(iParam2, 0)) {
			fVar3 = gameplay::get_distance_between_coords(vVar0, entity::get_entity_coords(iParam2, 1), 1);
			fVar4 = uParam0->f_79 / (uParam0->f_40 * fVar3);
			if (fVar4 < 0.4f) {
				fVar4 = 0.4f;
			}
			if (fVar4 > 2f) {
				fVar4 = 2f;
			}
			return fVar4;
		}
	}
	return 0f;
}

// Position - 0x3103
void func_40(var *uParam0, vector3 vParam1, int iParam4, int iParam5, int iParam6) {
	var uVar0;
	vector3 vVar1;
	vector3 vVar4;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;

	if (cam::does_cam_exist(cam::get_rendering_cam())) {
		if (!graphics::get_screen_coord_from_world_coord(vParam1, &uVar0, &uVar0)) {
			vVar1 = {cam::get_cam_coord(cam::get_rendering_cam())};
			vVar4 = {cam::get_cam_rot(cam::get_rendering_cam(), 2)};
			fVar7 = gameplay::get_distance_between_coords(vVar1.x, vVar1.y, 0f, vParam1.x, vParam1.y, 0f, 1);
			fVar8 = vParam1.z - vVar1.z;
			if (fVar7 > 0f) {
				fVar9 = gameplay::atan(fVar8 / fVar7);
			}
			else {
				fVar9 = 0f;
			}
			fVar10 = func_41(vVar1, vParam1, 0);
			fVar11 =
				gameplay::atan2(system::cos(vVar4.x) * system::sin(fVar9) -
									system::sin(vVar4.x) * system::cos(fVar9) * system::cos(fVar10 * -1f - vVar4.z),
								system::sin(fVar10 * -1f - vVar4.z) * system::cos(fVar9));
			if (uParam0->f_10 > 0f) {
			}
			fVar12 = 0.5f - system::cos(fVar11) * 0.29f;
			fVar13 = 0.5f - system::sin(fVar11) * 0.29f;
			graphics::draw_sprite("helicopterhud", "hudArrow", fVar12, fVar13, 0.02f, 0.04f, fVar11 - 90f, iParam4,
								  iParam5, iParam6, 255, 1);
			ui::set_text_centre(1);
		}
	}
}

// Position - 0x3229
float func_41(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5, int iParam6) {
	float fVar0;
	float fVar1;
	float fVar2;

	fVar1 = Param3 - Param0;
	fVar2 = Param3.f_1 - Param0.f_1;
	if (fVar2 != 0f) {
		fVar0 = gameplay::atan2(fVar1, fVar2);
	}
	else if (fVar1 < 0f) {
		fVar0 = -90f;
	}
	else {
		fVar0 = 90f;
	}
	if (iParam6 == 1) {
		fVar0 *= -1f;
		if (fVar0 < 0f) {
			fVar0 += 360f;
		}
	}
	return fVar0;
}

// Position - 0x328E
void func_42(int *iParam0) {
	if (iParam0->f_194 == 0) {
		if (audio::request_ambient_audio_bank("SCRIPT\POLICE_CHOPPER_CAM", 0, -1)) {
			iParam0->f_194 = 1;
			iParam0->f_196 = audio::get_sound_id();
			iParam0->f_197 = audio::get_sound_id();
			iParam0->f_199 = audio::get_sound_id();
			iParam0->f_198 = audio::get_sound_id();
			iParam0->f_200 = audio::get_sound_id();
			iParam0->f_201 = audio::get_sound_id();
			iParam0->f_202 = audio::get_sound_id();
			iParam0->f_203 = audio::get_sound_id();
		}
	}
}

// Position - 0x32F0
void func_43(int *iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iParam0->f_163) {
		if (iParam0->f_163[iVar0 /*11*/].f_5 != -1) {
			if (iParam0->f_163[iVar0 /*11*/].f_3 != 0) {
				if (!entity::is_entity_dead(iParam0->f_163[iVar0 /*11*/].f_3, 0)) {
					iParam0->f_163[iVar0 /*11*/] = {entity::get_entity_coords(iParam0->f_163[iVar0 /*11*/].f_3, 1)};
				}
			}
			if (iParam0->f_163[iVar0 /*11*/].f_4 != 0) {
				if (!entity::is_entity_dead(iParam0->f_163[iVar0 /*11*/].f_4, 0)) {
					iParam0->f_163[iVar0 /*11*/] = {
						entity::get_world_position_of_entity_bone(iParam0->f_163[iVar0 /*11*/].f_4, 0)};
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x338F
void func_44(int *iParam0) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	float fVar9;
	float fVar10;
	float fVar11;
	int iVar12;
	int iVar13;
	vector3 vVar14;
	float fVar17;
	int iVar18;
	int iVar19;
	float fVar20;
	float fVar21;
	float fVar22;
	float fVar23;
	float fVar24;

	if (cam::does_cam_exist(iParam0->f_32) && iParam0->f_7 == 0 && iParam0->f_35 && !iParam0->f_4) {
		iVar12 = 2;
		iVar12 = iVar12;
		vVar0 = {cam::get_cam_coord(iParam0->f_32)};
		vVar3 = {cam::get_cam_rot(iParam0->f_32, 2)};
		fVar17 = 0f;
		iVar18 = 0;
		iVar19 = 0;
		iVar19 = iVar19;
		fVar20 = vVar0.z;
		fVar20 = fVar20;
		if (iVar18 == 0) {
			fVar21 = 0f;
			fVar22 = system::cos(vVar3.x) * 50f;
			while (iVar12 < 21) {
				iVar12++;
				fVar11 = fVar22 * IntToFloat(iVar12);
				fVar9 = system::sin(vVar3.z) * fVar11 * -1f;
				fVar10 = system::cos(vVar3.z) * fVar11;
				fVar21 = pathfind::_0x8ABE8608576D9CE3(vVar0.x + fVar9 - 3f, vVar0.y + fVar10 - 3f,
													   vVar0.x + fVar9 + 3f, vVar0.y + fVar10 + 3f);
				fVar21 -= 20f;
				fVar20 = vVar0.z + system::sin(vVar3.x) * 50f * IntToFloat(iVar12);
				if (fVar21 > fVar20) {
					if (iVar18 == 0) {
						iVar18 = 1;
						fVar17 = fVar21;
						iVar12 = 21;
					}
				}
			}
		}
		if (iVar18 == 0) {
			if (gameplay::get_ground_z_for_3d_coord(vVar0, &fVar24, 0)) {
				fVar23 = vVar0.z - fVar24;
				if (fVar23 < 150f) {
					fVar23 = 150f;
				}
			}
			else {
				fVar23 = 150f;
			}
			if (vVar3.x < 0f) {
				fVar11 = gameplay::absf(fVar23 / gameplay::tan(vVar3.x));
				fVar17 = vVar0.z - fVar23;
			}
			else {
				fVar11 = 1000f;
				fVar17 = vVar0.z + fVar11 * gameplay::tan(vVar3.x);
			}
		}
		fVar9 = system::sin(vVar3.z) * fVar11 * -1f;
		fVar10 = system::cos(vVar3.z) * fVar11;
		vVar6 = {fVar9 + vVar0.x, fVar10 + vVar0.y, fVar17};
		iVar13 = 0;
		while (iVar13 < iParam0->f_175) {
			if (!ped::is_ped_injured(iParam0->f_175[iVar13 /*10*/])) {
				if (func_45(entity::get_entity_coords(iParam0->f_175[iVar13 /*10*/], 1), 0.4f, 0.4f, 0.6f, 0.6f)) {
					iVar18 = 1;
					iVar19 = 1;
					vVar6 = {entity::get_entity_coords(iParam0->f_175[iVar13 /*10*/], 1)};
					fVar17 = vVar14.z;
				}
			}
			iVar13++;
		}
		iParam0->f_159 = {vVar6};
	}
}

// Position - 0x35B6
bool func_45(vector3 vParam0, float fParam3, float fParam4, float fParam5, float fParam6) {
	float fVar0;
	float fVar1;

	graphics::get_screen_coord_from_world_coord(vParam0, &fVar0, &fVar1);
	if (fVar0 >= fParam3 && fVar0 <= fParam5) {
		if (fVar1 >= fParam4 && fVar1 <= fParam6) {
			return true;
		}
	}
	return false;
}

// Position - 0x35F4
void func_46() {
	if (bLocal_282) {
		if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_291, 0)) {
			switch (iLocal_290) {
			case 0:
				if (func_81(&Local_65)) {
					if (audio::start_audio_scene("MP_HELI_CAM_FILTERING")) {
						iLocal_290++;
					}
				}
				break;

			case 1:
				audio::set_audio_scene_variable("MP_HELI_CAM_FILTERING", "HeliFiltering",
												entity::get_entity_speed(iLocal_291));
				break;
			}
		}
		else if (iLocal_290 != 99 && iLocal_290 > 0) {
			audio::stop_audio_scene("MP_HELI_CAM_FILTERING");
			iLocal_290 = 99;
		}
	}
}

// Position - 0x367D
void func_47() {
	switch (iLocal_289) {
	case 0:
		if (!ui::is_help_message_being_displayed()) {
			if (bLocal_276) {
				if (iLocal_272 == joaat("buzzard") || iLocal_272 == joaat("savage")) {
					func_8("HUNTGUN_2", -1);
				}
				else if (iLocal_272 == joaat("valkyrie")) {
					func_8("HUNTGUN_2c", -1);
				}
				else {
					func_8("HUNTGUN_2b", -1);
				}
			}
			else if (iLocal_272 == joaat("buzzard") || iLocal_272 == joaat("savage")) {
				func_8("HUNTGUN_4", -1);
			}
			else if (iLocal_272 == joaat("valkyrie")) {
				func_8("HUNTGUN_4c", -1);
			}
			else {
				func_8("HUNTGUN_4b", -1);
			}
			iLocal_289++;
		}
		break;

	case 1:
		if (func_50("HUNTGUN_2") || func_50("HUNTGUN_4") || func_50("HUNTGUN_2b") || func_50("HUNTGUN_4b")) {
			iLocal_289++;
		}
		break;

	case 2:
		if (!ui::is_help_message_being_displayed()) {
			if (bLocal_276) {
				if (func_49(player::player_id(), 19)) {
					if (!func_48()) {
						if (controls::_is_input_disabled(0)) {
							func_8("HUNTGUN_6_KM", -1);
						}
						else {
							func_8("HUNTGUN_6", -1);
						}
					}
				}
			}
			iLocal_289++;
		}
		break;
	}
}

// Position - 0x37D4
bool func_48() { return gameplay::is_bit_set(Global_2494199.f_1642, 11); }

// Position - 0x37E9
bool func_49(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_211, iParam1); }

// Position - 0x3802
bool func_50(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x3815
void func_51() {
	if (func_50("HUNTGUN_1")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_1b")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_1c")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_3")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_3b")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_3c")) {
		ui::clear_help(1);
	}
}

// Position - 0x387D
bool func_52() {
	if (Global_2454056) {
		return false;
	}
	if (iLocal_272 == joaat("buzzard")) {
		return true;
	}
	if (iLocal_272 == joaat("savage")) {
		return true;
	}
	return false;
}

// Position - 0x38AF
void func_53(var *uParam0, int iParam1) { uParam0->f_51 = iParam1; }

// Position - 0x38BD
void func_54() {
	if (Global_14443.f_1 != 1) {
		if (func_2(0)) {
			func_55(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x38E5
void func_55(int iParam0) {
	if (Global_14604) {
		func_57(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_56()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x3955
int func_56() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x397C
void func_57(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_2(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x39F0
void func_58() {
	if (entity::does_entity_exist(Local_65.f_9)) {
		if (!entity::is_entity_dead(Local_65.f_9, 0)) {
			if (entity::get_entity_model(Local_65.f_9) != joaat("valkyrie") &&
				entity::get_entity_model(Local_65.f_9) != joaat("savage")) {
				network::set_entity_locally_invisible(Local_65.f_9);
				if (!iLocal_278) {
					network::set_player_invisible_locally(iLocal_294, 0);
				}
				if (!iLocal_280) {
					network::set_player_invisible_locally(iLocal_295, 0);
				}
			}
		}
	}
}

// Position - 0x3A5A
void func_59() {
	vector3 vVar0;
	float fVar3;

	if (bLocal_279) {
		if (!iLocal_280) {
			vVar0 = {cam::_0x26903D9CD1175F2C(iLocal_295, 2)};
			fVar3 = cam::_0x5F35F6732C3FBBA0(iLocal_295);
			switch (iLocal_303) {
			case 0:
				if (cam::does_cam_exist(Local_65.f_32)) {
					Local_65.f_42 = {vVar0};
					Local_65.f_40 = fVar3;
					cam::set_cam_rot(Local_65.f_32, Local_65.f_42, 2);
					cam::set_cam_fov(Local_65.f_32, Local_65.f_40);
					iLocal_303++;
				}
				break;

			case 1:
				vVar0 = {func_61(vVar0, Local_65.f_42)};
				fVar3 = func_60(fVar3, Local_65.f_40);
				if (cam::does_cam_exist(Local_65.f_32)) {
					Local_65.f_42 = {vVar0};
					Local_65.f_40 = fVar3;
					cam::set_cam_rot(Local_65.f_32, Local_65.f_42, 2);
					cam::set_cam_fov(Local_65.f_32, Local_65.f_40);
				}
				break;
			}
		}
	}
}

// Position - 0x3B30
float func_60(float fParam0, float fParam1) {
	float fVar0;

	fVar0 = fParam1 + (fParam0 - fParam1) * vLocal_285.x;
	if (gameplay::absf(fVar0 - fParam0) < fLocal_288) {
		fVar0 = fParam0;
	}
	return fVar0;
}

// Position - 0x3B5C
Vector3 func_61(vector3 vParam0, vector3 vParam3) {
	vector3 vVar0;
	float fVar3;

	fVar3 = vParam0.z - vParam3.z;
	if (gameplay::absf(fVar3) > 180f) {
		if (fVar3 > 0f) {
			fVar3 -= 360f;
		}
		else {
			fVar3 += 360f;
		}
		vParam3.z = vParam0.z - fVar3;
	}
	vVar0 = {vParam3 + vParam0 - vParam3 * vLocal_285};
	if (gameplay::absf(vVar0.x - vParam0.x) < fLocal_288) {
		vVar0 = {vParam0};
	}
	if (gameplay::absf(vVar0.y - vParam0.y) < fLocal_288) {
		vVar0 = {vParam0};
	}
	if (gameplay::absf(vVar0.z - vParam0.z) < fLocal_288) {
		vVar0 = {vParam0};
	}
	return vVar0;
}

// Position - 0x3C13
void func_62() {
	vector3 vVar0;

	if (bLocal_282) {
		vVar0 = {entity::get_offset_from_entity_in_world_coords(iLocal_291, 0f, 20f, -1f)};
		func_29(&Local_65, 0);
		func_24(&Local_65);
		func_63(&Local_65, vVar0);
		cam::_0x661B5C8654ADD825(Local_65.f_32, 1);
		Local_65.f_42 = {entity::get_entity_rotation(iLocal_291, 2) - Vector(0f, 0f, 3f)};
	}
}

// Position - 0x3C65
void func_63(int *iParam0, vector3 vParam1) {
	iParam0->f_45 = {vParam1};
	cam::point_cam_at_coord(iParam0->f_32, iParam0->f_45);
	iParam0->f_159 = {vParam1};
}

// Position - 0x3C8F
int func_64(var *uParam0, int iParam1, int iParam2, int iParam3) {
	vector3 vVar0;
	vector3 vVar3;
	int iVar6;
	float fVar7;

	if (iParam2 == 1 && uParam0->f_1 == 0) {
		if (uParam0->f_5 == 0) {
			iLocal_64 = unk_0x67D02A194A2FC2BD("heli_cam");
		}
		graphics::request_streamed_texture_dict("helicopterhud", 0);
		if (!cam::does_cam_exist(uParam0->f_32)) {
			uParam0->f_35 = 0;
			uParam0->f_32 = cam::create_cam("default_scripted_camera", 0);
			cam::set_cam_near_clip(uParam0->f_32, uParam0->f_12);
		}
		gameplay::_set_unk_map_flag(4);
		func_65(1, 1, 1, 0);
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				if (entity::is_entity_a_vehicle(iParam1)) {
					uParam0->f_8 = entity::get_vehicle_index_from_entity_index(iParam1);
					vehicle::_0xBC3CCA5844452B06(300f);
				}
				vehicle::_0xBC3CCA5844452B06(300f);
				uParam0->f_6 = 1;
				uParam0->f_33 = 1;
				uParam0->f_50 = 1;
				uParam0->f_2 = 1;
				uParam0->f_9 = iParam1;
				vVar0 = {entity::get_entity_coords(iParam1, 1)};
				uParam0->f_22 = vVar0.z;
				vVar3 = {entity::get_entity_rotation(iParam1, 2)};
				uParam0->f_41 = vVar3.z;
				if (uParam0->f_4) {
					controls::disable_all_control_actions(0);
				}
				else {
					controls::disable_all_control_actions(0);
					player::set_everyone_ignore_player(player::player_id(), 1);
				}
				graphics::push_timecycle_modifier();
				if (vehicle::is_vehicle_driveable(uParam0->f_8, 0)) {
					iVar6 = entity::get_entity_model(uParam0->f_8);
				}
				if (iVar6 == joaat("buzzard") || iVar6 == joaat("savage")) {
					graphics::set_timecycle_modifier("heliGunCam");
				}
				else if (iVar6 == joaat("valkyrie")) {
					graphics::set_timecycle_modifier("heliGunCam");
				}
				else {
					graphics::set_timecycle_modifier("eyeinthesky");
				}
				graphics::_0x6DDBF9DFFC4AC080(1);
				gameplay::get_ground_z_for_3d_coord(vVar0, &fVar7, 0);
				uParam0->f_193 = fVar7 * 10f;
				if (uParam0->f_194 == 1) {
					if (uParam0->f_199 != -1) {
						if (audio::has_sound_finished(uParam0->f_199)) {
							audio::play_sound_frontend(uParam0->f_199, "COP_HELI_CAM_BACKGROUND", 0, 1);
						}
					}
				}
				func_42(uParam0);
				uParam0->f_1 = 1;
			}
		}
		return 0;
	}
	else {
		if (uParam0->f_1 == 1 && iParam2 == 1) {
			if (uParam0->f_86 == 0) {
				func_31(uParam0, 0);
				func_30();
			}
			else {
				return 1;
			}
		}
		if (uParam0->f_1 == 1 && iParam2 == 0) {
			if (iParam3 == 0) {
				uParam0->f_48 = 0;
			}
			uParam0->f_6 = 0;
			uParam0->f_33 = 0;
			uParam0->f_50 = 0;
			uParam0->f_9 = 0;
			uParam0->f_2 = 0;
			uParam0->f_55 = 0;
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				controls::enable_all_control_actions(0);
				player::set_everyone_ignore_player(player::player_id(), 0);
			}
			if (vehicle::is_vehicle_driveable(uParam0->f_8, 0)) {
				if (entity::is_entity_attached_to_any_object(uParam0->f_8)) {
					entity::detach_entity(uParam0->f_8, 1, 1);
				}
				if (!uParam0->f_4) {
					entity::freeze_entity_position(uParam0->f_8, 0);
					entity::set_entity_invincible(uParam0->f_8, 0);
					entity::set_entity_has_gravity(uParam0->f_8, 1);
					vehicle::set_vehicle_gravity(uParam0->f_8, 1);
				}
			}
			gameplay::_set_unk_map_flag(0);
			if (cam::does_cam_exist(uParam0->f_32)) {
				if (cam::is_cam_active(uParam0->f_32)) {
					cam::set_cam_active(uParam0->f_32, 0);
				}
				if (cam::is_cam_rendering(uParam0->f_32)) {
					cam::render_script_cams(0, 0, 3000, 1, 0, 0);
				}
				cam::destroy_cam(uParam0->f_32, 0);
			}
			if (uParam0->f_196 != -1) {
				if (!audio::has_sound_finished(uParam0->f_196)) {
					audio::stop_sound(uParam0->f_196);
				}
			}
			if (uParam0->f_197 != -1) {
				if (!audio::has_sound_finished(uParam0->f_197)) {
					audio::stop_sound(uParam0->f_197);
				}
			}
			if (uParam0->f_198 != -1) {
				if (!audio::has_sound_finished(uParam0->f_198)) {
					audio::stop_sound(uParam0->f_198);
				}
			}
			if (uParam0->f_200 != -1) {
				if (!audio::has_sound_finished(uParam0->f_200)) {
					audio::stop_sound(uParam0->f_200);
				}
			}
			if (uParam0->f_201 != -1) {
				if (!audio::has_sound_finished(uParam0->f_201)) {
					audio::stop_sound(uParam0->f_201);
				}
			}
			if (uParam0->f_202 != -1) {
				if (!audio::has_sound_finished(uParam0->f_202)) {
					audio::stop_sound(uParam0->f_202);
				}
			}
			if (uParam0->f_199 != -1) {
				if (!audio::has_sound_finished(uParam0->f_199)) {
					audio::stop_sound(uParam0->f_199);
				}
			}
			if (uParam0->f_203 != -1) {
				if (!audio::has_sound_finished(uParam0->f_203)) {
					audio::stop_sound(uParam0->f_203);
				}
			}
			if (uParam0->f_194 == 1) {
				audio::release_ambient_audio_bank();
				audio::release_sound_id(uParam0->f_199);
				audio::release_sound_id(uParam0->f_196);
				audio::release_sound_id(uParam0->f_197);
				audio::release_sound_id(uParam0->f_198);
				audio::release_sound_id(uParam0->f_200);
				audio::release_sound_id(uParam0->f_201);
				audio::release_sound_id(uParam0->f_202);
				audio::release_sound_id(uParam0->f_203);
				uParam0->f_199 = -1;
				uParam0->f_196 = -1;
				uParam0->f_197 = -1;
				uParam0->f_198 = -1;
				uParam0->f_200 = -1;
				uParam0->f_201 = -1;
				uParam0->f_202 = -1;
				uParam0->f_203 = -1;
				uParam0->f_194 = 0;
			}
			graphics::clear_timecycle_modifier();
			graphics::_0x6DDBF9DFFC4AC080(0);
			graphics::set_streamed_texture_dict_as_no_longer_needed("helicopterHUD");
			graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_64);
			graphics::pop_timecycle_modifier();
			func_65(0, 0, 1, 0);
			uParam0->f_8 = 0;
			uParam0->f_1 = 0;
			func_42(uParam0);
			return 1;
		}
	}
	return 0;
}

// Position - 0x40ED
int func_65(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && iParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x4120
var func_66(int iParam0) { return iParam0; }

// Position - 0x412A
bool func_67(var *uParam0, int iParam1) {
	uParam0->f_5 = iParam1;
	uParam0->f_62 = 93;
	uParam0->f_62.f_1 = 182;
	uParam0->f_62.f_2 = 229;
	uParam0->f_65 = 255;
	uParam0->f_65.f_1 = 0;
	uParam0->f_65.f_2 = 0;
	uParam0->f_68 = 255;
	uParam0->f_68.f_1 = 255;
	uParam0->f_68.f_2 = 255;
	uParam0->f_71 = 255;
	uParam0->f_71.f_1 = 40;
	uParam0->f_71.f_2 = 0;
	uParam0->f_15 = 40f;
	uParam0->f_36 = 0.0075f;
	uParam0->f_37 = 20f;
	uParam0->f_40 = 28f;
	uParam0->f_54 = 0.234f;
	uParam0->f_58 = 22;
	uParam0->f_59 = 201;
	uParam0->f_60 = 39;
	uParam0->f_61 = 181;
	uParam0->f_74 = 0.044f;
	uParam0->f_75 = 0.02f;
	uParam0->f_77 = 1240f;
	uParam0->f_78 = 5000f;
	uParam0->f_79 = 1000f;
	uParam0->f_81 = 0.829f;
	uParam0->f_82 = 0.096f;
	uParam0->f_83 = 0.865f;
	uParam0->f_84 = 0.567f;
	uParam0->f_85 = 0.087f;
	uParam0->f_18 = 140f;
	uParam0->f_19 = 1f;
	uParam0->f_20 = 3f;
	uParam0->f_21 = 1f;
	uParam0->f_88 = 0.052f;
	uParam0->f_89 = 0.75f;
	uParam0->f_90 = 0.86f;
	uParam0->f_91 = 0.02f;
	uParam0->f_189 = 0.65f;
	uParam0->f_190 = 0.024f;
	uParam0->f_157 = 0.12f;
	if (network::network_is_game_in_progress()) {
		ui::request_additional_text("CHOPPER", 5);
		if (ui::has_this_additional_text_loaded("CHOPPER", 5)) {
			return true;
		}
	}
	else {
		ui::request_additional_text("CHOPPER", 3);
		if (ui::has_this_additional_text_loaded("CHOPPER", 3)) {
			return true;
		}
	}
	return false;
}

// Position - 0x42C0
void func_68() { gameplay::set_bit(&G_SleepModeOffOn11, 4); }

// Position - 0x42D0
void func_69(int iParam0) {
	if (network::participant_id_to_int() != -1) {
		Local_298[network::participant_id_to_int() /*2*/].f_1 = iParam0;
	}
}

// Position - 0x42ED
bool func_70() {
	int iVar0;

	if (!ui::is_pause_menu_active() && !func_3() && !func_2(0) && !Global_1315161 && !Global_1318087) {
		if (controls::is_control_just_pressed(0, 51)) {
			if (!gameplay::is_bit_set(Global_1633501.f_15, 12) && !Global_2452556) {
				if (vehicle::is_vehicle_driveable(iLocal_291, 0) && !entity::is_entity_in_water(iLocal_291)) {
					iVar0 = 1;
				}
			}
			else {
				return false;
			}
		}
		else if (func_71()) {
		}
	}
	if (bLocal_276) {
		return iVar0;
	}
	else if (func_80()) {
		return iVar0;
	}
	return false;
}

// Position - 0x4391
bool func_71() {
	if (!Global_2494199.f_4253) {
		if (Global_2494199.f_4254 == iLocal_291) {
			Global_2494199.f_4253 = 1;
			return true;
		}
	}
	return false;
}

// Position - 0x43BE
void func_72() {
	int iVar0;

	if (gameplay::is_bit_set(Global_1633501.f_15, 12) || Global_2452556 || Global_1318087) {
		return;
	}
	if (iLocal_291 != Global_2494199.f_4397) {
		if (!iLocal_273) {
			if (!ui::is_help_message_being_displayed()) {
				if (bLocal_276) {
					if (iLocal_272 == joaat("buzzard") || iLocal_272 == joaat("savage")) {
						if (func_49(player::player_id(), 19)) {
							if (!func_48()) {
								iVar0 = 1;
							}
						}
						if (!iVar0) {
							func_8("HUNTGUN_1", -1);
						}
					}
					else if (iLocal_272 == joaat("valkyrie")) {
						if (func_49(player::player_id(), 19)) {
							if (!func_48()) {
								iVar0 = 1;
							}
						}
						if (!iVar0) {
							func_8("HUNTGUN_1c", -1);
						}
					}
					else {
						func_8("HUNTGUN_1b", -1);
					}
					iLocal_273 = 1;
				}
				else if (func_80() && !Global_2452556.f_131 && !Global_1318087) {
					if (iLocal_272 == joaat("buzzard") || iLocal_272 == joaat("savage")) {
						func_8("HUNTGUN_3", -1);
					}
					else if (iLocal_272 == joaat("valkyrie")) {
						func_8("HUNTGUN_3c", -1);
					}
					else {
						func_8("HUNTGUN_3b", -1);
					}
					iLocal_273 = 1;
				}
			}
			else if (func_50("VEX_EYEHLPe")) {
				iLocal_273 = 1;
			}
		}
		else if (func_77(player::player_id(), 1) || func_74(player::player_id(), 1)) {
			if (!ui::is_help_message_being_displayed()) {
				if (!iLocal_275) {
					if (!bLocal_276) {
						if (func_73()) {
							iLocal_275 = 1;
							Global_2494199.f_4397 = iLocal_291;
						}
					}
					else {
						iLocal_275 = 1;
						Global_2494199.f_4397 = iLocal_291;
					}
				}
			}
		}
		else {
			iLocal_275 = 1;
			Global_2494199.f_4397 = iLocal_291;
		}
	}
	else {
		iLocal_273 = 1;
		iLocal_275 = 1;
	}
}

// Position - 0x4588
bool func_73() { return false; }

// Position - 0x4591
int func_74(int iParam0, int iParam1) {
	if (iParam1) {
		if (func_75(iParam0)) {
			return 1;
		}
	}
	if (Global_1591201[iParam0 /*602*/] == -1) {
		return 0;
	}
	return 1;
}

// Position - 0x45BD
bool func_75(int iParam0) { return func_76(iParam0); }

// Position - 0x45CB
var func_76(int iParam0) { return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_13.f_1, 0); }

// Position - 0x45E5
int func_77(int iParam0, int iParam1) {
	if (iParam1) {
		if (func_75(iParam0)) {
			return 1;
		}
	}
	if (Global_1591201[iParam0 /*602*/] == 2 || Global_1591201[iParam0 /*602*/] == 1 ||
		Global_1591201[iParam0 /*602*/] == 0 || Global_1591201[iParam0 /*602*/] == 3 ||
		Global_1591201[iParam0 /*602*/] == 8) {
		return 1;
	}
	return 0;
}

// Position - 0x4657
void func_78() {
	if (gameplay::is_bit_set(Global_1633501.f_15, 12) || Global_2452556) {
		return;
	}
	if (iLocal_294 == player::player_id()) {
		if (func_52()) {
			if (iLocal_281 && !iLocal_274 &&
				(controls::is_control_just_pressed(0, 99) || controls::is_control_just_pressed(0, 100))) {
				if (!ui::is_help_message_being_displayed()) {
					func_8("HUNTGUN_8", -1);
					iLocal_274 = 1;
				}
			}
		}
	}
}

// Position - 0x46C9
void func_79() {
	if (vehicle::is_vehicle_driveable(iLocal_291, 0)) {
		if (!entity::is_entity_in_air(iLocal_291)) {
			if (func_80()) {
				Local_65.f_204 = 1;
			}
			else {
				cam::_clamp_gameplay_cam_pitch(-25f, 6f);
				Local_65.f_204 = 0;
			}
		}
		else {
			Local_65.f_204 = 0;
		}
	}
}

// Position - 0x470D
bool func_80() {
	if (bLocal_279) {
		if (!iLocal_280) {
			if (Local_298[iLocal_296 /*2*/].f_1 == 2) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x4735
bool func_81(var *uParam0) {
	if (uParam0->f_1 == 1) {
		return true;
	}
	return false;
}

// Position - 0x474A
void func_82() {
	int iVar0;

	iVar0 = player::player_ped_id();
	bLocal_277 = false;
	iLocal_278 = 1;
	bLocal_279 = false;
	iLocal_280 = 1;
	iLocal_292 = -1;
	iLocal_293 = -1;
	iLocal_294 = func_84();
	iLocal_295 = func_84();
	bLocal_276 = false;
	Global_1574197 = func_84();
	bLocal_282 = false;
	if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (ped::is_ped_sitting_in_any_vehicle(iVar0)) {
				if (vehicle::is_vehicle_driveable(iLocal_291, 0)) {
					bLocal_282 = true;
					if (!vehicle::is_vehicle_seat_free(iLocal_291, -1, 0)) {
						iLocal_292 = vehicle::get_ped_in_vehicle_seat(iLocal_291, -1, 0);
						bLocal_277 = entity::does_entity_exist(iLocal_292);
						if (bLocal_277) {
							iLocal_278 = entity::is_entity_dead(iLocal_292, 0);
							if (ped::is_ped_a_player(iLocal_292)) {
								iLocal_294 = network::network_get_player_index_from_ped(iLocal_292);
							}
						}
					}
					if (!vehicle::is_vehicle_seat_free(iLocal_291, 0, 0)) {
						iLocal_293 = vehicle::get_ped_in_vehicle_seat(iLocal_291, 0, 0);
						bLocal_279 = entity::does_entity_exist(iLocal_293);
						if (bLocal_279) {
							iLocal_280 = entity::is_entity_dead(iLocal_293, 0);
							if (func_83(iLocal_293, iLocal_291, 0) &&
								ped::is_ped_in_vehicle(iLocal_293, iLocal_291, 0)) {
								if (ped::is_ped_a_player(iLocal_293)) {
									iLocal_295 = network::network_get_player_index_from_ped(iLocal_293);
									if (network::network_is_player_a_participant(iLocal_295)) {
										iLocal_296 = network::network_get_participant_index(iLocal_295);
									}
									if (iLocal_295 == player::player_id()) {
										bLocal_276 = true;
									}
								}
							}
						}
					}
					if (iLocal_295 == player::player_id()) {
						if (!iLocal_278) {
							Global_1574197 = iLocal_294;
						}
					}
					else if (!iLocal_280) {
						Global_1574197 = iLocal_295;
					}
				}
			}
		}
	}
}

// Position - 0x48B3
int func_83(int iParam0, int iParam1, int iParam2) {
	if (!entity::is_entity_dead(iParam0, 0) && !entity::is_entity_dead(iParam1, 0)) {
		if (ped::is_ped_sitting_in_vehicle(iParam0, iParam1)) {
			if (vehicle::get_ped_in_vehicle_seat(iParam1, iParam2, 0) == iParam0) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x48F1
int func_84() { return -1; }

// Position - 0x48FA
void func_85(var *uParam0, int iParam1, int iParam2) {
	if (network::network_is_game_in_progress() && !iParam1) {
		if (!iParam2) {
			*uParam0 = network::get_network_time();
		}
		else {
			*uParam0 = network::_0x89023FBBF9200E9F();
		}
	}
	else {
		*uParam0 = gameplay::get_game_timer();
	}
	uParam0->f_1 = 1;
}

// Position - 0x4937
int func_86(var uParam0) {
	int iVar0;

	iVar0 = uParam0;
	if (iVar0 != -1) {
		return Global_1619421[iVar0 /*390*/];
	}
	return -1;
}

// Position - 0x4956
bool func_87() { return Global_1312416; }

// Position - 0x4962
bool func_88() { return Global_1315233; }

// Position - 0x496E
void func_89() {
	int iVar0;

	func_92();
	func_51();
	Global_1318175 = 0;
	if (entity::does_entity_exist(iLocal_291)) {
		if (iLocal_292 == player::player_ped_id() && network::network_has_control_of_entity(iLocal_291)) {
			vehicle::disable_vehicle_weapon(0, joaat("vehicle_weapon_space_rocket"), iLocal_291,
											player::player_ped_id());
		}
	}
	func_92();
	func_91();
	func_64(&Local_65, iVar0, 0, 1);
	Global_2502456 = 0;
	if (!func_52()) {
		Global_1318176 = 1;
	}
	Global_1591201[player::player_id() /*602*/].f_493 = 0;
	audio::stop_audio_scene("CAR_2_HELI_FILTERING");
	func_90();
}

// Position - 0x49F5
void func_90() { script::terminate_this_thread(); }

// Position - 0x4A01
void func_91() {
	if (bLocal_276) {
		ped::remove_ped_helmet(player::player_ped_id(), 0);
	}
}

// Position - 0x4A18
void func_92() {
	if (func_50("HUNTGUN_2")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_2b")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_2c")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_4")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_4b")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_4c")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_5")) {
		ui::clear_help(1);
	}
	if (func_50("HUNTGUN_6")) {
		ui::clear_help(1);
	}
	if (gameplay::is_pc_version()) {
		if (func_50("HUNTGUN_5_KM")) {
			ui::clear_help(1);
		}
		if (func_50("HUNTGUN_6_KM")) {
			ui::clear_help(1);
		}
	}
}

// Position - 0x4AC5
bool func_93(int iParam0) {
	if (func_100()) {
		if (iParam0) {
			if (!Global_1574283 && !func_49(player::player_id(), 2)) {
				graphics::_start_screen_effect("MinigameTransitionIn", 0, 1);
				func_94(0, 0);
			}
		}
		return true;
	}
	return false;
}

// Position - 0x4B05
void func_94(int iParam0, int iParam1) {
	if (iParam0) {
		func_99(1);
	}
	else {
		func_95(iParam1);
	}
}

// Position - 0x4B20
void func_95(int iParam0) {
	func_98();
	if (iParam0 == 0) {
		if (unk::_0xEF7D17BC6C85264C()) {
			return;
		}
	}
	if (func_97() == 0 || ui::is_pause_menu_active()) {
		func_96(1);
		graphics::_set_frozen_rendering_disabled(0);
		graphics::_set_frozen_rendering_disabled(0);
	}
}

// Position - 0x4B61
void func_96(int iParam0) {
	if (Global_1312466.f_20 != iParam0) {
		Global_1312466.f_20 = iParam0;
	}
}

// Position - 0x4B7C
int func_97() { return Global_1312466.f_20; }

// Position - 0x4B8A
void func_98() { Global_2454055 = 1; }

// Position - 0x4B97
void func_99(int iParam0) {
	if (func_97() == 1 || ui::is_pause_menu_active() || iParam0) {
		func_96(0);
		graphics::_set_frozen_rendering_disabled(1);
		graphics::_set_frozen_rendering_disabled(1);
		graphics::_0xE1C8709406F2C41C();
	}
}

// Position - 0x4BCD
bool func_100() { return Global_2433125.f_2; }

// Position - 0x4BDB
void func_101(int iParam0) {
	if (network::participant_id_to_int() != -1) {
		Local_298[network::participant_id_to_int() /*2*/] = iParam0;
	}
}

// Position - 0x4BF6
bool func_102() {
	bool bVar0;
	int *iVar1;

	func_109(&bVar0, &iVar1);
	if (bVar0) {
		return true;
	}
	if (Global_1315210 == 0) {
		if (!network::network_is_game_in_progress()) {
			return true;
		}
	}
	if (func_108()) {
		return true;
	}
	if (Global_2454747) {
		return true;
	}
	if (func_107()) {
		return true;
	}
	if (func_106(157)) {
		if (!func_105()) {
			return true;
		}
	}
	if (func_106(155)) {
		return true;
	}
	if (!network::network_is_signed_online()) {
		return true;
	}
	if (func_103() != 0) {
		if (script::_get_number_of_instances_of_script_with_name_hash(func_103()) == 0) {
			return true;
		}
	}
	return false;
}

// Position - 0x4C8B
int func_103() {
	switch (func_104()) {
	case 0: return joaat("freemode");

	case 2: return joaat("creator");
	}
	return 0;
}

// Position - 0x4CBF
int func_104() { return Global_25190; }

// Position - 0x4CCA
bool func_105() { return Global_2443134.f_577; }

// Position - 0x4CD9
bool func_106(int iParam0) {
	if (script::get_event_exists(1, iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x4CF0
bool func_107() { return Global_2452525; }

// Position - 0x4CFC
bool func_108() { return Global_2443134.f_572; }

// Position - 0x4D0B
void func_109(int *iParam0, int *iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < script::get_number_of_events(1)) {
		iVar1 = script::get_event_at_index(1, iVar0);
		if (iVar1 == 171) {
			script::get_event_data(1, iVar0, &iVar2, 2);
			switch (iVar2) {
			case 381: func_110(iVar0); break;

			case 2:
				script::get_event_data(1, iVar0, &vVar4, 3);
				if (vVar4.z == 55) {
					*iParam0 = 1;
				}
				else if (vVar4.z == 32) {
					*iParam1 = 1;
				}
				break;
			}
		}
		iVar0++;
	}
}

// Position - 0x4D8B
void func_110(int iParam0) {
	vector3 vVar0;
	int iVar3;
	int iVar4;
	bool bVar5;

	if (script::get_event_data(1, iParam0, &vVar0, 3)) {
		if (func_16(vVar0.y, 1, 1)) {
			iVar3 = player::get_player_ped(vVar0.y);
			if (entity::does_entity_exist(iVar3)) {
				if (ped::is_ped_in_any_vehicle(iVar3, 0)) {
					iVar4 = ped::get_vehicle_ped_is_in(iVar3, 0);
					if (vehicle::is_vehicle_window_intact(iVar4, vVar0.z) &&
						network::network_get_this_script_is_network_script()) {
						if (func_111(iVar4, &bVar5)) {
							vehicle::remove_vehicle_window(iVar4, vVar0.z);
						}
						if (bVar5) {
							entity::set_vehicle_as_no_longer_needed(&iVar4);
						}
					}
				}
			}
		}
	}
}

// Position - 0x4E0C
bool func_111(int iParam0, int *iParam1) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_a_mission_entity(iParam0)) {
			if (network::network_get_entity_is_local(iParam0)) {
				if (!vehicle::is_this_model_a_train(entity::get_entity_model(iParam0))) {
					entity::set_entity_as_mission_entity(iParam0, 0, 1);
					*iParam1 = 1;
				}
			}
		}
		if (entity::does_entity_belong_to_this_script(iParam0, 0)) {
			if (network::network_has_control_of_entity(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x4E6B
void func_112() { system::wait(0); }

// Position - 0x4E78
void func_113(struct<20> Param0) {
	func_117(func_118(Param0), Param0);
	func_115(0, -1, 0);
	network::network_register_host_broadcast_variables(&iLocal_297, 1);
	network::network_register_player_broadcast_variables(&Local_298, 5);
	gameplay::set_this_script_can_be_paused(0);
	if (entity::does_entity_exist(player::player_ped_id())) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				if (vehicle::is_vehicle_driveable(ped::get_vehicle_ped_is_using(player::player_ped_id()), 0)) {
					iLocal_272 = entity::get_entity_model(ped::get_vehicle_ped_is_using(player::player_ped_id()));
					iLocal_291 = ped::get_vehicle_ped_is_using(player::player_ped_id());
				}
			}
		}
	}
	if (!func_114()) {
		func_89();
	}
	func_101(0);
}

// Position - 0x4F0B
int func_114() {
	int iVar0;

	iVar0 = 0;
	while (true) {
		iVar0++;
		if (!network::network_is_game_in_progress()) {
			return 0;
		}
		if (network::_0x5D10B3795F3FC886()) {
			return 1;
		}
		if (func_108()) {
			return 0;
		}
		if (func_106(155)) {
			return 0;
		}
		if (iVar0 >= 3600) {
			return 0;
		}
		system::wait(0);
	}
	return 0;
}

// Position - 0x4F64
int func_115(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = network::network_get_script_status();
	while (iVar0 != 2) {
		if (iVar0 == 3 || iVar0 == 4 || iVar0 == 5 || iVar0 == 6) {
			if (!iParam2) {
				func_90();
			}
			else {
				return 0;
			}
		}
		if (!func_116()) {
			if (iParam0 == 0) {
				if (!network::network_is_game_in_progress()) {
					if (!iParam2) {
						func_90();
					}
					else {
						return 0;
					}
				}
				if (func_108()) {
					if (!iParam2) {
						func_90();
					}
					else {
						return 0;
					}
				}
				if (func_106(155)) {
					if (!iParam2) {
						func_90();
					}
					else {
						return 0;
					}
				}
			}
			else if (!network::network_is_in_session()) {
				if (!iParam2) {
					func_90();
				}
				else {
					return 0;
				}
			}
		}
		system::wait(0);
		iVar0 = network::network_get_script_status();
	}
	if (iParam1 > -1) {
		Global_1312500 = iVar0;
	}
	if (iParam0 == 0) {
		if (!network::network_is_game_in_progress()) {
			if (!iParam2) {
				func_90();
			}
			else {
				return 0;
			}
		}
	}
	else if (!network::network_is_in_session()) {
		if (!iParam2) {
			func_90();
		}
		else {
			return 0;
		}
	}
	return 1;
}

// Position - 0x5079
bool func_116() { return Global_1315210; }

// Position - 0x5085
void func_117(int iParam0, struct<17> Param1, var uParam18, var uParam19, var uParam20) {
	if (!network::network_is_game_in_progress()) {
		func_90();
	}
	network::network_set_this_script_is_network_script(iParam0, 0, Param1.f_16);
}

// Position - 0x50A4
int func_118(int iParam0) {
	switch (iParam0) {
	case 3: return 2;

	case 1: return 32;

	case 2: return 32;

	case 32: return 32;

	case 33: return 32;

	case 34: return 32;

	case 35: return 32;

	case 36: return 32;

	case 37: return 32;

	case 38: return 32;

	case 39: return 32;

	case 40: return 32;

	case 41: return 32;

	case 42: return 32;

	case 43: return 32;

	case 44: return 32;

	case 45: return 32;

	case 46: return 32;

	case 47: return 32;

	case 48: return 32;

	case 49: return 32;

	case 50: return 4;

	case 51: return 32;

	case 52: return 32;

	case 53: return 32;

	case 54: return 32;

	case 55: return 32;

	case 56: return 32;

	case 57: return 32;

	case 58: return 32;

	case 59: return 32;

	case 60: return 32;

	case 61: return 32;

	case 62: return 32;

	case 63: return 32;

	case 64: return 4;

	case 65: return 32;

	case 66: return 4;

	case 67: return 4;

	case 68: return 32;

	case 69: return 32;

	case 70: return 4;

	case 71: return 32;

	case 72: return 32;

	case 73:
	case 74: return 4;

	case 75: return 32;

	case 76: return 32;

	case 77: return 32;

	case 78: return 32;

	case 79: return 32;

	case 80: return 32;

	case 81: return 32;

	case 82: return 32;

	case 84: return 32;

	case 83: return 32;

	case 85: return 32;

	case 86: return 32;

	case 87: return 32;

	case 88: return 32;

	case 89: return 32;

	case 90: return 8;

	case 91: return 32;

	case 92: return 8;

	case 93: return 8;

	case 101: return 8;

	case 94: return 8;

	case 95: return 32;

	case 96: return 32;

	case 97: return 32;

	case 98: return 8;

	case 99: return 32;

	case 100: return 32;

	case 102: return 32;

	case 103: return 32;

	case 104: return 32;

	case 105: return 8;

	case 12: return 32;

	case 4: return 16;

	case 13: return 32;

	case 5: return 16;

	case 6: return 2;

	case 8: return 2;

	case 9: return 2;

	case 7: return 16;

	case 10: return 2;

	case 11: return 4;

	case 15: return 32;

	case 16: return 32;

	case 27: return 2;

	case 25: return 2;

	case 26: return 2;

	case 18: return 32;

	case 28: return 32;

	case 29: return 2;

	case 30: return 32;

	case 31: return 32;

	case 17: return 2;

	case 106: return 32;

	case 107: return 32;

	case 19: return 32;

	case 22: return 32;

	case 23: return 32;

	case 24: return 32;

	case 20: return 2;

	case 0: return 0;

	case 21: return 32;

	case 118: return 32;

	case 119: return 32;

	case 108: return 32;

	case 109: return 32;

	case 113: return 32;

	case 111: return 32;

	case 112: return 32;

	case 116: return 32;

	case 117: return 32;

	case 114: return 32;

	case 115: return 32;

	case 120: return 32;

	case 121: return 32;

	case 122: return 32;

	case 123: return 32;

	case 124: return 2;

	case 129: return 1;

	case 125: return 2;

	case 126: return 4;

	case 127: return 2;

	case 128: return 2;

	case 110: return 1;

	case 130: return 2;

	case 131:
	case 132:
	case 133:
	case 134:
	case 135:
	case 136: return 0;

	case 140: return 1;

	case 137: return 4;

	case 138: return 16;

	case 139: return 32;

	default:
	}
	return 0;
}

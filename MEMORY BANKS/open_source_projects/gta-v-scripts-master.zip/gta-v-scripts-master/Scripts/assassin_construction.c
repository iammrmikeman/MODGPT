#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 1132396544;
var uLocal_48 = 1132396544;
var uLocal_49 = 1132396544;
var uLocal_50 = 0;
var uLocal_51 = -1082130432;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 8;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = -1;
var uLocal_112 = 1092616192;
var uLocal_113 = 0;
var uLocal_114 = 0;
bool bLocal_115 = 0;
int iLocal_116 = 0;
int iLocal_117 = 0;
int iLocal_118 = 0;
vector3 vLocal_119 = {0f, 0f, 0f};
struct<4> Local_122 = {
	0, 0, 1097859072, 1500
};
var uLocal_126 = 45;
var uLocal_127 = 1103626240;
var uLocal_128 = 5;
var *uLocal_129 = NULL;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
int *iLocal_133 = NULL;
float fLocal_134 = 0f;
float fLocal_135 = 0f;
float fLocal_136 = 0f;
bool bLocal_137 = 0;
bool bLocal_138 = 0;
int iLocal_139 = 0;
int iLocal_140 = 0;
float fLocal_141 = 0f;
var uLocal_142 = 0;
var uLocal_143 = 0;
int iLocal_144 = 0;
int iLocal_145 = 0;
int iLocal_146 = 0;
var *uLocal_147 = NULL;
var uLocal_148 = 0;
var uLocal_149 = 0;
var *uLocal_150 = NULL;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 3;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 1;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 2;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 13;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 13;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 0;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 0;
var uLocal_430 = 13;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 0;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var uLocal_524 = 0;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 13;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 13;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 13;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 13;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
struct<55> Local_726 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_781 = 0;
var uLocal_782 = 0;
var uLocal_783 = 0;
var uLocal_784 = 0;
var uLocal_785 = 0;
var uLocal_786 = 0;
var uLocal_787 = 0;
var uLocal_788 = 0;
var uLocal_789 = 0;
var uLocal_790 = 0;
var uLocal_791 = 0;
var uLocal_792 = 0;
var uLocal_793 = 0;
var uLocal_794 = 0;
var uLocal_795 = 0;
var uLocal_796 = 0;
var uLocal_797 = 0;
var uLocal_798 = 0;
var uLocal_799 = 0;
var uLocal_800 = 0;
struct<39> Local_801 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_840 = 0;
var uLocal_841 = 16;
var uLocal_842 = 0;
var uLocal_843 = 0;
var uLocal_844 = 0;
var uLocal_845 = 0;
var uLocal_846 = 0;
var uLocal_847 = 0;
var uLocal_848 = 0;
var uLocal_849 = 0;
var uLocal_850 = 0;
var uLocal_851 = 0;
var uLocal_852 = 0;
var uLocal_853 = 0;
var uLocal_854 = 0;
var uLocal_855 = 0;
var uLocal_856 = 0;
var uLocal_857 = 0;
var uLocal_858 = 0;
var uLocal_859 = 0;
var uLocal_860 = 0;
var uLocal_861 = 0;
var uLocal_862 = 0;
var uLocal_863 = 0;
var uLocal_864 = 0;
var uLocal_865 = 0;
var uLocal_866 = 0;
var uLocal_867 = 0;
var uLocal_868 = 0;
var uLocal_869 = 0;
var uLocal_870 = 0;
var uLocal_871 = 0;
var uLocal_872 = 0;
var uLocal_873 = 0;
var uLocal_874 = 0;
var uLocal_875 = 0;
var uLocal_876 = 0;
var uLocal_877 = 0;
var uLocal_878 = 0;
var uLocal_879 = 0;
var uLocal_880 = 0;
var uLocal_881 = 0;
var uLocal_882 = 0;
var uLocal_883 = 0;
var uLocal_884 = 0;
var uLocal_885 = 0;
var uLocal_886 = 0;
var uLocal_887 = 0;
var uLocal_888 = 0;
var uLocal_889 = 0;
var uLocal_890 = 0;
var uLocal_891 = 0;
var uLocal_892 = 0;
var uLocal_893 = 0;
var uLocal_894 = 0;
var uLocal_895 = 0;
var uLocal_896 = 0;
var uLocal_897 = 0;
var uLocal_898 = 0;
var uLocal_899 = 0;
var uLocal_900 = 0;
var uLocal_901 = 0;
var uLocal_902 = 0;
var uLocal_903 = 0;
var uLocal_904 = 0;
var uLocal_905 = 0;
var uLocal_906 = 0;
var uLocal_907 = 0;
var uLocal_908 = 0;
var uLocal_909 = 0;
var uLocal_910 = 0;
var uLocal_911 = 0;
var uLocal_912 = 0;
var uLocal_913 = 0;
var uLocal_914 = 0;
var uLocal_915 = 0;
var uLocal_916 = 0;
var uLocal_917 = 0;
var uLocal_918 = 0;
var uLocal_919 = 0;
var uLocal_920 = 0;
var uLocal_921 = 0;
var uLocal_922 = 0;
var uLocal_923 = 0;
var uLocal_924 = 0;
var uLocal_925 = 0;
var uLocal_926 = 0;
var uLocal_927 = 0;
var uLocal_928 = 0;
var uLocal_929 = 0;
var uLocal_930 = 0;
var uLocal_931 = 0;
var uLocal_932 = 0;
var uLocal_933 = 0;
var uLocal_934 = 0;
var uLocal_935 = 0;
var uLocal_936 = 0;
var uLocal_937 = 0;
var uLocal_938 = 0;
var uLocal_939 = 0;
var uLocal_940 = 0;
var uLocal_941 = 0;
var uLocal_942 = 0;
var uLocal_943 = 0;
var uLocal_944 = 0;
var uLocal_945 = 0;
var uLocal_946 = 0;
var uLocal_947 = 0;
var uLocal_948 = 0;
var uLocal_949 = 0;
var uLocal_950 = 0;
var uLocal_951 = 0;
var uLocal_952 = 0;
var uLocal_953 = 0;
var uLocal_954 = 0;
var uLocal_955 = 0;
var uLocal_956 = 0;
var uLocal_957 = 0;
var uLocal_958 = 0;
var uLocal_959 = 0;
var uLocal_960 = 0;
var uLocal_961 = 0;
var uLocal_962 = 0;
var uLocal_963 = 0;
var uLocal_964 = 0;
var uLocal_965 = 0;
var uLocal_966 = 0;
var uLocal_967 = 0;
var uLocal_968 = 0;
var uLocal_969 = 0;
var uLocal_970 = 0;
var uLocal_971 = 0;
var uLocal_972 = 0;
var uLocal_973 = 0;
var uLocal_974 = 0;
var uLocal_975 = 0;
var uLocal_976 = 0;
var uLocal_977 = 0;
var uLocal_978 = 0;
var uLocal_979 = 0;
var uLocal_980 = 0;
var uLocal_981 = 0;
var uLocal_982 = 0;
var uLocal_983 = 0;
var uLocal_984 = 0;
var uLocal_985 = 0;
var uLocal_986 = 0;
var uLocal_987 = 0;
var uLocal_988 = 0;
var uLocal_989 = 0;
var uLocal_990 = 0;
var uLocal_991 = 0;
var uLocal_992 = 0;
var uLocal_993 = 0;
var uLocal_994 = 0;
var uLocal_995 = 0;
var uLocal_996 = 0;
var uLocal_997 = 0;
var uLocal_998 = 0;
var uLocal_999 = 0;
var uLocal_1000 = 0;
var uLocal_1001 = 0;
var uLocal_1002 = 0;
var uLocal_1003 = 0;
var uLocal_1004 = 0;
var uLocal_1005 = 0;
var uLocal_1006 = 0;
var uLocal_1007 = 0;
var uLocal_1008 = 0;
var uLocal_1009 = 0;
var uLocal_1010 = 0;
var uLocal_1011 = 0;
int iLocal_1012 = 0;
int iLocal_1013 = 0;
float fLocal_1014 = 0f;
var uLocal_1015 = 0;
var uLocal_1016 = 0;
var uLocal_1017 = 0;
var uLocal_1018 = 0;
var uLocal_1019 = 0;
var uLocal_1020 = 0;
var uLocal_1021 = 0;
var uLocal_1022 = 0;
var uLocal_1023 = 0;
var uLocal_1024 = 0;
var uLocal_1025 = 21;
var uLocal_1026 = 6;
var uLocal_1027 = 0;
var uLocal_1028 = 0;
var uLocal_1029 = 0;
int iLocal_1030 = 0;
int iLocal_1031 = 0;
int iLocal_1032 = 0;
int iLocal_1033 = 0;
int iLocal_1034 = 0;
int iLocal_1035 = 0;
int iLocal_1036 = 0;
int iLocal_1037 = 0;
vector3 vLocal_1038 = {0f, 0f, 0f};
vector3 vLocal_1041 = {0f, 0f, 0f};
float fLocal_1044 = 0f;
float fLocal_1045 = 0f;
var uLocal_1046 = 0;
var uLocal_1047 = 0;
vector3 vLocal_1048 = {0f, 0f, 0f};
vector3 vLocal_1051 = {0f, 0f, 0f};
var *uLocal_1054 = NULL;
var uLocal_1055 = 0;
var uLocal_1056 = 0;
var *uLocal_1057 = NULL;
var uLocal_1058 = 0;
var uLocal_1059 = 0;
bool bLocal_1060 = 0;
int iLocal_1061 = 0;
bool bLocal_1062 = 0;
int *iLocal_1063 = NULL;
bool bLocal_1064 = 0;
bool bLocal_1065 = 0;
int iLocal_1066 = 0;
int iLocal_1067 = 0;
vector3 vLocal_1068 = {0f, 0f, 0f};
vector3 vLocal_1071 = {0f, 0f, 0f};
int iLocal_1074 = 0;
int iLocal_1075 = 0;
int iLocal_1076 = 0;
var *uLocal_1077 = NULL;
var uLocal_1078 = 0;
var uLocal_1079 = 8;
var uLocal_1080 = 0;
var uLocal_1081 = 0;
var uLocal_1082 = 0;
var uLocal_1083 = 4;
var uLocal_1084 = 0;
var uLocal_1085 = 0;
var uLocal_1086 = 0;
var uLocal_1087 = 0;
var uLocal_1088 = 0;
var uLocal_1089 = 0;
var uLocal_1090 = 0;
var uLocal_1091 = 0;
var uLocal_1092 = 0;
var uLocal_1093 = 0;
var uLocal_1094 = 0;
var uLocal_1095 = 0;
var uLocal_1096 = 0;
var uLocal_1097 = 0;
var uLocal_1098 = 4;
var uLocal_1099 = 0;
var uLocal_1100 = 0;
var uLocal_1101 = 0;
var uLocal_1102 = 0;
var uLocal_1103 = 0;
var uLocal_1104 = 0;
var uLocal_1105 = 0;
var uLocal_1106 = 0;
var uLocal_1107 = 0;
var uLocal_1108 = 0;
var uLocal_1109 = 0;
var uLocal_1110 = 0;
var uLocal_1111 = 0;
var uLocal_1112 = 0;
var uLocal_1113 = 4;
var uLocal_1114 = 0;
var uLocal_1115 = 0;
var uLocal_1116 = 0;
var uLocal_1117 = 0;
var uLocal_1118 = 0;
var uLocal_1119 = 0;
var uLocal_1120 = 0;
var uLocal_1121 = 0;
var uLocal_1122 = 0;
var uLocal_1123 = 0;
var uLocal_1124 = 0;
var uLocal_1125 = 0;
var uLocal_1126 = 0;
var uLocal_1127 = 0;
var uLocal_1128 = 4;
var uLocal_1129 = 0;
var uLocal_1130 = 0;
var uLocal_1131 = 0;
var uLocal_1132 = 0;
var uLocal_1133 = 0;
var uLocal_1134 = 0;
var uLocal_1135 = 0;
var uLocal_1136 = 0;
var uLocal_1137 = 0;
var uLocal_1138 = 0;
var uLocal_1139 = 0;
var uLocal_1140 = 0;
var uLocal_1141 = 0;
var uLocal_1142 = 0;
var uLocal_1143 = 4;
var uLocal_1144 = 0;
var uLocal_1145 = 0;
var uLocal_1146 = 0;
var uLocal_1147 = 0;
var uLocal_1148 = 0;
var uLocal_1149 = 0;
var uLocal_1150 = 0;
var uLocal_1151 = 0;
var uLocal_1152 = 0;
var uLocal_1153 = 0;
var uLocal_1154 = 0;
var uLocal_1155 = 0;
var uLocal_1156 = 0;
var uLocal_1157 = 0;
var uLocal_1158 = 4;
var uLocal_1159 = 0;
var uLocal_1160 = 0;
var uLocal_1161 = 0;
var uLocal_1162 = 0;
var uLocal_1163 = 0;
var uLocal_1164 = 0;
var uLocal_1165 = 0;
var uLocal_1166 = 0;
var uLocal_1167 = 0;
var uLocal_1168 = 0;
var uLocal_1169 = 0;
var uLocal_1170 = 0;
var uLocal_1171 = 0;
var uLocal_1172 = 0;
var uLocal_1173 = 4;
var uLocal_1174 = 0;
var uLocal_1175 = 0;
var uLocal_1176 = 0;
var uLocal_1177 = 0;
var uLocal_1178 = 0;
var uLocal_1179 = 0;
var uLocal_1180 = 0;
var uLocal_1181 = 0;
var uLocal_1182 = 0;
var uLocal_1183 = 0;
var uLocal_1184 = 0;
var uLocal_1185 = 0;
var uLocal_1186 = 0;
var uLocal_1187 = 0;
var uLocal_1188 = 4;
var uLocal_1189 = 0;
var uLocal_1190 = 0;
var uLocal_1191 = 0;
var uLocal_1192 = 0;
var uLocal_1193 = 0;
var uLocal_1194 = 0;
var uLocal_1195 = 0;
var uLocal_1196 = 0;
var uLocal_1197 = 0;
var uLocal_1198 = 0;
var uLocal_1199 = 0;
var uLocal_1200 = 0;
int iLocal_1201 = 0;
struct<19> Local_1202[5];
struct<19> Local_1298[3];
struct<19> Local_1356[6];
struct<19> Local_1471[2];
struct<19> Local_1510[4];
struct<19> Local_1587[3];
struct<19> Local_1645[3];
int iLocal_1703[3] = {0, 0, 0};
int iLocal_1707 = 0;
int iLocal_1708 = 0;
int iLocal_1709 = 0;
int iLocal_1710 = 0;
int iLocal_1711 = 0;
int iLocal_1712 = 0;
int *iLocal_1713 = NULL;
bool bLocal_1714 = 0;
int iLocal_1715 = 0;
int iLocal_1716 = 0;
int iLocal_1717 = 0;
int iLocal_1718 = 0;
int iLocal_1719 = 0;
int iLocal_1720 = 0;
int iLocal_1721 = 0;
int iLocal_1722 = 0;
int iLocal_1723 = 0;
int iLocal_1724 = 0;
int iLocal_1725 = 0;
int *iLocal_1726 = NULL;
bool bLocal_1727 = 0;
int iLocal_1728 = 0;
int iLocal_1729 = 0;
int iLocal_1730 = 0;
int iLocal_1731 = 0;
int iLocal_1732 = 0;
int iLocal_1733 = 0;
int iLocal_1734 = 0;
int iLocal_1735 = 0;
bool bLocal_1736 = 0;
int iLocal_1737 = 0;
int iLocal_1738 = 0;
int iLocal_1739 = 0;
bool bLocal_1740 = 0;
int iLocal_1741 = 0;
bool bLocal_1742 = 0;
int iLocal_1743 = 0;
int iLocal_1744 = 0;
int iLocal_1745 = 0;
bool bLocal_1746 = 0;
int iLocal_1747 = 0;
bool bLocal_1748 = 0;
int iLocal_1749 = 0;
bool bLocal_1750 = 0;
bool bLocal_1751 = 0;
int iLocal_1752 = 0;
int iLocal_1753 = 0;
int iLocal_1754 = 0;
int iLocal_1755 = 0;
int iLocal_1756 = 0;
int iLocal_1757 = 0;
float fLocal_1758 = 0f;
int iLocal_1759 = 0;
int iLocal_1760 = 0;
int iLocal_1761 = 0;
int iLocal_1762 = 0;
int iLocal_1763 = 0;
var uLocal_1764 = 0;
int *iLocal_1765 = NULL;
int iLocal_1766 = 0;
int iLocal_1767 = 0;
int iLocal_1768 = 0;
int iLocal_1769 = 0;
int iLocal_1770 = 0;
int iLocal_1771 = 0;
int iLocal_1772 = 0;
int iLocal_1773 = 0;
int iLocal_1774 = 0;
int iLocal_1775 = 0;
int iLocal_1776 = 0;
int iLocal_1777 = 0;
int iLocal_1778[2] = {0, 0};
int iLocal_1781 = 0;
int iLocal_1782 = 0;
int iLocal_1783 = 0;
int iLocal_1784 = 0;
int iLocal_1785 = 0;
int iLocal_1786 = 0;
var uLocal_1787[3] = {0, 0, 0};
var uLocal_1791[3] = {0, 0, 0};
var uLocal_1795[5] = {0, 0, 0, 0, 0};
int iLocal_1801 = 0;
int iLocal_1802 = 0;
int iLocal_1803 = 0;
int iLocal_1804 = 0;
var uLocal_1805[2] = {0, 0};
var uLocal_1808 = 0;
int iLocal_1809 = 0;
int iLocal_1810 = 0;
vector3 vLocal_1811 = {0f, 0f, 0f};
vector3 vLocal_1814 = {0f, 0f, 0f};
vector3 vLocal_1817 = {0f, 0f, 0f};
vector3 vLocal_1820 = {0f, 0f, 0f};
vector3 vLocal_1823 = {0f, 0f, 0f};
vector3 vLocal_1826 = {0f, 0f, 0f};
vector3 vLocal_1829 = {0f, 0f, 0f};
vector3 vLocal_1832[3] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
vector3 vLocal_1842[2] = {{0f, 0f, 0f}, {0f, 0f, 0f}};
vector3 vLocal_1849[20] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
vector3 vLocal_1910 = {0f, 0f, 0f};
vector3 vLocal_1913 = {0f, 0f, 0f};
vector3 vLocal_1916 = {0f, 0f, 0f};
vector3 vLocal_1919[3] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
vector3 vLocal_1929[3] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
float fLocal_1939[3] = {0f, 0f, 0f};
vector3 vLocal_1943 = {0f, 0f, 0f};
vector3 vLocal_1946 = {0f, 0f, 0f};
vector3 vLocal_1949 = {0f, 0f, 0f};
float fLocal_1952 = 0f;
vector3 vLocal_1953 = {0f, 0f, 0f};
float fLocal_1956 = 0f;
vector3 vLocal_1957 = {0f, 0f, 0f};
float fLocal_1960 = 0f;
vector3 vLocal_1961 = {0f, 0f, 0f};
float fLocal_1964 = 0f;
vector3 vLocal_1965 = {0f, 0f, 0f};
float fLocal_1968 = 0f;
int iLocal_1969 = 0;
int iLocal_1970 = 0;
int iLocal_1971 = 0;
int iLocal_1972 = 0;
int iLocal_1973 = 0;
int iLocal_1974 = 0;
int iLocal_1975 = 0;
var *uLocal_1976 = NULL;
var uLocal_1977 = 0;
var uLocal_1978 = 0;
var *uLocal_1979 = NULL;
var uLocal_1980 = 0;
var uLocal_1981 = 0;
var *uLocal_1982 = NULL;
var uLocal_1983 = 0;
var uLocal_1984 = 0;
var *uLocal_1985 = NULL;
var uLocal_1986 = 0;
var uLocal_1987 = 0;
var *uLocal_1988 = NULL;
var uLocal_1989 = 0;
var uLocal_1990 = 0;
var *uLocal_1991 = NULL;
var uLocal_1992 = 0;
var uLocal_1993 = 0;
var *uLocal_1994 = NULL;
var uLocal_1995 = 0;
var uLocal_1996 = 0;
var *uLocal_1997 = NULL;
var uLocal_1998 = 0;
var uLocal_1999 = 0;
var *uLocal_2000 = NULL;
var uLocal_2001 = 0;
var uLocal_2002 = 0;
int iLocal_2003 = 0;
int iLocal_2004 = 0;
var *uLocal_2005 = NULL;
var uLocal_2006 = 0;
var uLocal_2007 = 0;
var uLocal_2008 = 0;
var uLocal_2009 = 0;
var uLocal_2010 = 0;
var uLocal_2011 = 0;
var uLocal_2012 = 0;
var uLocal_2013 = 0;
var uLocal_2014 = 0;
var uLocal_2015 = 0;
var uLocal_2016 = 0;
var uLocal_2017 = 0;
var uLocal_2018 = 0;
var uLocal_2019 = 0;
var uLocal_2020 = 0;
var uLocal_2021 = 0;
var uLocal_2022 = 0;
var uLocal_2023 = 0;
var uLocal_2024 = 0;
var uLocal_2025 = 0;
var uLocal_2026 = 0;
var uLocal_2027 = 0;
var uLocal_2028 = 0;
var uLocal_2029 = 0;
var uLocal_2030 = 0;
var uLocal_2031 = 0;
var uLocal_2032 = 0;
var uLocal_2033 = 0;
var uLocal_2034 = 0;
var uLocal_2035 = 0;
var uLocal_2036 = 0;
var uLocal_2037 = 0;
var uLocal_2038 = 0;
var uLocal_2039 = 0;
var uLocal_2040 = 0;
var uLocal_2041 = 0;
var uLocal_2042 = 0;
var uLocal_2043 = 0;
var uLocal_2044 = 0;
var uLocal_2045 = 0;
var uLocal_2046 = 0;
var uLocal_2047 = 0;
var uLocal_2048 = 0;
var uLocal_2049 = 0;
var uLocal_2050 = 0;
var uLocal_2051 = 0;
var uLocal_2052 = 0;
var uLocal_2053 = 0;
var uLocal_2054 = 0;
var uLocal_2055 = 0;
var uLocal_2056 = 0;
var uLocal_2057 = 0;
var uLocal_2058 = 0;
var uLocal_2059 = 0;
var uLocal_2060 = 0;
var uLocal_2061 = 0;
var uLocal_2062 = 0;
var uLocal_2063 = 0;
var uLocal_2064 = 0;
var uLocal_2065 = 0;
var uLocal_2066 = 0;
var uLocal_2067 = 0;
var uLocal_2068 = 0;
var uLocal_2069 = 0;
var uLocal_2070 = 0;
var uLocal_2071 = 0;
var uLocal_2072 = 0;
var uLocal_2073 = 0;
var uLocal_2074 = 0;
var uLocal_2075 = 0;
var uLocal_2076 = 0;
var uLocal_2077 = 0;
var uLocal_2078 = 0;
var uLocal_2079 = 0;
var uLocal_2080 = 0;
var uLocal_2081 = 0;
var uLocal_2082 = 0;
var uLocal_2083 = 0;
var uLocal_2084 = 0;
var uLocal_2085 = 0;
var uLocal_2086 = 0;
var uLocal_2087 = 0;
var uLocal_2088 = 0;
var uLocal_2089 = 0;
var uLocal_2090 = 0;
var uLocal_2091 = 0;
var uLocal_2092 = 0;
var uLocal_2093 = 0;
var uLocal_2094 = 0;
var uLocal_2095 = 0;
var uLocal_2096 = 0;
var uLocal_2097 = 0;
var uLocal_2098 = 0;
var uLocal_2099 = 0;
var uLocal_2100 = 0;
var uLocal_2101 = 0;
var uLocal_2102 = 0;
var uLocal_2103 = 0;
var uLocal_2104 = 0;
var uLocal_2105 = 0;
var uLocal_2106 = 0;
var uLocal_2107 = 0;
var uLocal_2108 = 0;
var uLocal_2109 = 0;
var uLocal_2110 = 0;
var uLocal_2111 = 0;
var uLocal_2112 = 0;
var uLocal_2113 = 0;
var uLocal_2114 = 0;
var uLocal_2115 = 0;
var uLocal_2116 = 0;
var uLocal_2117 = 0;
var uLocal_2118 = 0;
var uLocal_2119 = 0;
var uLocal_2120 = 0;
var uLocal_2121 = 0;
var uLocal_2122 = 0;
var uLocal_2123 = 0;
var uLocal_2124 = 0;
var uLocal_2125 = 0;
var uLocal_2126 = 0;
var uLocal_2127 = 0;
var uLocal_2128 = 0;
var uLocal_2129 = 0;
var uLocal_2130 = 0;
var uLocal_2131 = 0;
var uLocal_2132 = 0;
var uLocal_2133 = 0;
var uLocal_2134 = 0;
var uLocal_2135 = 0;
var uLocal_2136 = 0;
var uLocal_2137 = 0;
var uLocal_2138 = 0;
var uLocal_2139 = 0;
var uLocal_2140 = 0;
var uLocal_2141 = 0;
var uLocal_2142 = 0;
var uLocal_2143 = 0;
var uLocal_2144 = 0;
var uLocal_2145 = 0;
var uLocal_2146 = 0;
var uLocal_2147 = 0;
var uLocal_2148 = 0;
var uLocal_2149 = 0;
var uLocal_2150 = 0;
var uLocal_2151 = 0;
var uLocal_2152 = 0;
var uLocal_2153 = 0;
var uLocal_2154 = 0;
var uLocal_2155 = 0;
var uLocal_2156 = 0;
var uLocal_2157 = 0;
var uLocal_2158 = 0;
var uLocal_2159 = 0;
var uLocal_2160 = 0;
var uLocal_2161 = 0;
var uLocal_2162 = 0;
var uLocal_2163 = 0;
var uLocal_2164 = 0;
var uLocal_2165 = 0;
var uLocal_2166 = 0;
var uLocal_2167 = 0;
var uLocal_2168 = 0;
var uLocal_2169 = 0;
var *uLocal_2170 = NULL;
var *uLocal_2171 = NULL;
var *uLocal_2172 = NULL;
int iLocal_2173 = 0;
int iLocal_2174 = 0;
vector3 vLocal_2175 = {0f, 0f, 0f};
int iLocal_2178 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	int iVar1;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	iLocal_28 = 3;
	fLocal_31 = 80f;
	fLocal_32 = 140f;
	fLocal_33 = 180f;
	iLocal_39 = 1;
	iLocal_40 = 65;
	iLocal_41 = 49;
	iLocal_42 = 64;
	vLocal_119 = {500f, 500f, 500f};
	iLocal_145 = 100;
	iLocal_146 = 3;
	uLocal_798 = ui::_0x4A9923385BDB9DAD();
	uLocal_799 = ui::_get_blip_info_id_iterator();
	iLocal_1012 = -1;
	fLocal_1014 = 1f;
	iLocal_1030 = 1;
	vLocal_1038 = {809.297f, -1075.809f, 27.6534f};
	vLocal_1041 = {809.22f, -1075.856f, 27.6541f};
	fLocal_1044 = 85.4771f;
	fLocal_1045 = 45f;
	vLocal_1048 = {810.9202f, -1075.502f, 29.1399f};
	vLocal_1051 = {-1.9308f, 0f, 78.5519f};
	vLocal_1068 = {0f, 0f, 0f};
	vLocal_1071 = {0f, 0f, 0f};
	fLocal_1758 = 140f;
	iLocal_1765 = -1;
	iLocal_1772 = 7;
	iLocal_1773 = 5;
	vLocal_1811 = {-110.9849f, -972.0396f, 295.4f};
	vLocal_1814 = {-134.2935f, -982.4351f, 26.2731f};
	vLocal_1817 = {-133.51f, -997.09f, 26.28f};
	vLocal_1820 = {-184.11f, -1015.63f, 30.06f};
	vLocal_1823 = {-158.02f, -940.52f, 114.25f};
	vLocal_1826 = {-154.6688f, -941.5961f, 268.2575f};
	vLocal_1829 = {-152.0844f, -943.5401f, 268.1324f};
	vLocal_1913 = {-0.469401f, -0.863015f, -0.6957f};
	vLocal_1916 = {-0.369f, -1.705f, -1.329f};
	vLocal_1943 = {-109.3679f, -908.5847f, 28.2615f};
	vLocal_1946 = {-0.2f, -2.2f, -1.3f};
	vLocal_1949 = {-140.2973f, -966.4312f, 268.1324f};
	fLocal_1952 = 95.6565f;
	vLocal_1953 = {-146.7524f, -959.7552f, 268.1324f};
	fLocal_1956 = 241.6704f;
	vLocal_1957 = {-150.5756f, -945.9047f, 268.1324f};
	fLocal_1960 = 134.4706f;
	vLocal_1961 = {797.9703f, -1064.692f, 26.7261f};
	fLocal_1964 = 6.2218f;
	vLocal_1965 = {-87.0079f, -915.3242f, 28.1966f};
	fLocal_1968 = 70.2099f;
	vLocal_2175 = {-132.83f, -981.025f, 26.2754f};
	if (player::has_force_cleanup_occurred(3)) {
		audio::trigger_music_event("ASS5_FAIL");
		func_448(&Global_101700.f_18922.f_1, 1024);
		func_446();
		func_439();
	}
	gameplay::set_mission_flag(1);
	if (func_438()) {
		if (func_437()) {
			bLocal_1746 = true;
		}
		bLocal_1727 = true;
	}
	else {
		bLocal_1727 = false;
	}
	iLocal_1801 = player::player_ped_id();
	streaming::remove_ipl("DT1_21_prop_lift_on");
	streaming::request_ipl("DT1_21_ConSiteAssass");
	if (!ped::is_ped_injured(player::player_ped_id())) {
		ped::set_ped_config_flag(player::player_ped_id(), 32, 0);
	}
	func_436();
	func_435();
	iLocal_1013 = 4;
	Local_801 = {func_433(iLocal_1013)};
	func_448(&Local_122, 16);
	func_448(&Local_122, 2);
	Local_122.f_3 = 750;
	player::set_wanted_level_multiplier(0.2f);
	iLocal_1030 = 1;
	if (func_438()) {
		bLocal_138 = true;
		iLocal_1775 = func_432();
		if (Global_86001) {
			if (iLocal_1775 <= 3) {
				iLocal_1775++;
			}
		}
		if (iLocal_1775 == 0) {
			if (bLocal_1746) {
				func_430();
				while (!func_429()) {
					system::wait(0);
				}
				iVar0 = func_386(vLocal_1961, fLocal_1964);
				if (!vehicle::is_this_model_a_boat(entity::get_entity_model(iVar0)) &&
					!vehicle::is_this_model_a_plane(entity::get_entity_model(iVar0)) &&
					!vehicle::is_this_model_a_heli(entity::get_entity_model(iVar0))) {
					vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
				}
				else {
					vehicle::delete_vehicle(&iVar0);
				}
			}
			func_385(804.2744f, -1077.559f, 27.5087f, 71.7369f, 1, 0);
		}
		else if (iLocal_1775 == 1) {
			if (bLocal_1746) {
				func_430();
				while (!func_429()) {
					system::wait(0);
				}
				iVar1 = func_386(vLocal_1965, fLocal_1968);
				if (!vehicle::is_this_model_a_boat(entity::get_entity_model(iVar1)) &&
					!vehicle::is_this_model_a_plane(entity::get_entity_model(iVar1)) &&
					!vehicle::is_this_model_a_heli(entity::get_entity_model(iVar1))) {
					vehicle::set_vehicle_on_ground_properly(iVar1, 1084227584);
				}
				else {
					vehicle::delete_vehicle(&iVar1);
				}
			}
			func_385(-102.4433f, -907.4056f, 28.2065f, 160.4677f, 1, 0);
		}
		else if (iLocal_1775 == 2) {
			if (ai::does_scripted_cover_point_exist_at_coords(-182.0891f, -1004.055f, 113.1355f)) {
				ai::remove_cover_point(iLocal_1711);
			}
			iLocal_1711 = ai::add_cover_point(-182.0891f, -1004.055f, 113.1355f, 341.2941f, 1, 2, 0, 0);
			cam::set_gameplay_cam_relative_heading(90f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			func_385(-182.1094f, -1004.058f, 113.1362f, 250.235f, 1, 0);
		}
		else if (iLocal_1775 == 3) {
			if (ai::does_scripted_cover_point_exist_at_coords(-150.5964f, -945.8911f, 268.1318f)) {
				ai::remove_cover_point(iLocal_1712);
			}
			iLocal_1712 = ai::add_cover_point(-150.5964f, -945.8911f, 268.1318f, 231.5456f, 2, 0, 0, 0);
			ped::_0x2208438012482A1A(iLocal_1801, 1, 0);
			ai::task_put_ped_directly_into_cover(iLocal_1801, vLocal_1957, -1, 0, 0f, 0, 0, 0, 0);
			cam::set_gameplay_cam_relative_heading(90f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			func_385(vLocal_1957, fLocal_1960, 1, 0);
		}
		else if (iLocal_1775 == 4) {
			if (ai::does_scripted_cover_point_exist_at_coords(-150.5964f, -945.8911f, 268.1318f)) {
				ai::remove_cover_point(iLocal_1712);
			}
			func_385(-102.221f, -941.379f, 28.233f, 67.1012f, 1, 0);
		}
	}
	while (true) {
		unk1::_0x208784099002BC30("M_ASS5", 0);
		if (iLocal_1730) {
			if (func_384()) {
				func_383();
			}
		}
		else if (!ped::is_ped_injured(iLocal_1801)) {
			func_1();
		}
		system::wait(0);
	}
}

// Position - 0x605
void func_1() {
	if (iLocal_1030 > 6 && iLocal_1030 < 13) {
		func_382();
	}
	if (iLocal_1030 > 6 && iLocal_1030 < 10) {
		func_381();
	}
	func_380();
	switch (iLocal_1030) {
	case 1:
		iLocal_2178 = 0;
		iLocal_1762 = 0;
		iLocal_1759 = 0;
		iLocal_1732 = 0;
		vLocal_1919[0 /*3*/] = {-100.4532f, -947.6407f, 25.72967f};
		vLocal_1929[0 /*3*/] = {-122.5554f, -939.6339f, 36.72875f};
		fLocal_1939[0] = 15f;
		vLocal_1919[1 /*3*/] = {-209.1907f, -1087.517f, 18.19053f};
		vLocal_1929[1 /*3*/] = {-188.87f, -1095.158f, 34.43797f};
		fLocal_1939[1] = 25f;
		vLocal_1919[2 /*3*/] = {-84.50335f, -1029.008f, 24.75447f};
		vLocal_1929[2 /*3*/] = {-80.10741f, -1016.94f, 35.95333f};
		fLocal_1939[2] = 15f;
		if (func_438()) {
			iLocal_1030 = 4;
			break;
		}
		func_370();
		break;

	case 4:
		if (func_438()) {
			bLocal_1727 = true;
		}
		func_369();
		func_368();
		func_367();
		ped::set_ped_non_creation_area(-250.5509f, -1126.146f, -100.7299f, -55.8166f, -858.6929f, 100.7734f);
		ped::add_scenario_blocking_area(-55.8166f, -1126.146f, -100.7299f, -250.5509f, -858.6929f, 100.7734f, 0, 1, 1,
										1);
		func_366();
		func_365();
		func_364();
		func_363(&uLocal_2005, 1, iLocal_1801, "FRANKLIN", 0, 1);
		iLocal_1030 = 5;
		break;

	case 5:
		if (func_362()) {
			ped::set_ped_model_is_suppressed(iLocal_1778[0], 1);
			iLocal_1030 = 6;
		}
		break;

	case 6: func_339(); break;

	case 7:
		func_336();
		func_335();
		func_325();
		break;

	case 8: func_318(); break;

	case 9:
		func_336();
		func_335();
		func_310();
		break;

	case 10: func_307(); break;

	case 11: func_302(); break;

	case 12: func_297(); break;

	case 13: func_211(); break;

	case 14: func_209(); break;

	case 15: func_168(); break;

	case 16: func_80(); break;
	}
	if (iLocal_1030 != 8) {
		func_42();
	}
	func_39();
	if (func_24(&iLocal_1726)) {
		func_2();
	}
}

// Position - 0x884
void func_2() {
	char *sVar0;

	if (iLocal_1730 == 0) {
		audio::trigger_music_event("ASS5_FAIL");
		func_22(-99.4653f, -940.7606f, 28.229f, 82.5402f);
		func_20(-99.494f, -937.6118f, 28.1219f, 250.2531f);
		if (!iLocal_1726) {
			sVar0 = "ASS_CS_ESCAPED";
		}
		else {
			sVar0 = "ASS_CS_ESCAPED";
		}
		iLocal_1730 = 1;
		func_18(sVar0);
		func_3(0);
	}
}

// Position - 0x8ED
void func_3(int iParam0) {
	int iVar0;

	if (Global_101700.f_8044 || func_17(0)) {
		iVar0 = func_16();
		if (!func_4(iVar0)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
		Global_91527 = iParam0;
	}
}

// Position - 0x932
int func_4(int iParam0) {
	int iVar0;
	int iVar1;

	func_9();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_8(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_5(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0xA49
void func_5(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_7(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_6(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0xC12
void func_6(int *iParam0) { *iParam0 = -15; }

// Position - 0xC20
int func_7(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_7(8, uParam1, fParam2);

	case 10: return func_7(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0x158F
void func_8(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x15CD
void func_9() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_10()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_10()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x16B4
int func_10() {
	func_11();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x16CD
void func_11() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_15(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_14(player::player_ped_id());
			if (func_13(iVar0) && (!func_12(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_13(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x17CA
bool func_12(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x17D8
bool func_13(int iParam0) { return iParam0 < 3; }

// Position - 0x17E4
int func_14(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_15(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x1821
int func_15(int iParam0) {
	if (func_13(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x184B
int func_16() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1880
bool func_17(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x18AB
void func_18(char *sParam0) {
	func_448(&Global_101700.f_18922.f_1, 1024);
	if (!gameplay::is_string_null(sParam0)) {
		func_19(sParam0);
	}
}

// Position - 0x18D3
void func_19(char *sParam0) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (ui::get_length_of_literal_string(sParam0) <= 16) {
			StringCopy(&Global_69934, sParam0, 16);
			StringCopy(&Global_69938, "", 16);
			if (unk1::_is_recording()) {
				unk1::_stop_recording_and_save_clip();
			}
		}
	}
}

// Position - 0x1912
void func_20(vector3 vParam0, float fParam3) { func_21(&Global_96040.f_2311, vParam0, fParam3); }

// Position - 0x192B
void func_21(var *uParam0, vector3 vParam1, var uParam4) {
	*uParam0 = {vParam1};
	uParam0->f_6 = uParam4;
}

// Position - 0x1941
void func_22(vector3 vParam0, float fParam3) {
	if (func_23(Global_69942, 0f, 0f, 0f, 0)) {
		Global_69942 = {vParam0};
		Global_69945 = fParam3;
	}
}

// Position - 0x196D
bool func_23(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x19B4
bool func_24(int *iParam0) {
	vector3 vVar0;

	if (func_36(iLocal_1802, 250f, 0) || func_35() && func_36(iLocal_1802, 250f, 325f)) {
		return true;
	}
	else if (iLocal_1030 >= 11) {
		if (iLocal_1030 == 13) {
			vVar0 = {entity::get_entity_coords(iLocal_1801, 1)};
			if (!bLocal_1742) {
				if (vVar0.z < vLocal_1826.z - 50f && entity::does_entity_exist(iLocal_1802) &&
					!ped::is_ped_injured(iLocal_1802) && !ped::is_ped_in_any_vehicle(iLocal_1802, 0)) {
					return true;
				}
			}
		}
	}
	else if (cam::is_screen_faded_in()) {
		if (iLocal_1030 < 8) {
			if (func_25(&iLocal_1713, vLocal_1817, "ASS_CS_RTNY", 500f)) {
				*iParam0 = 1;
				return true;
			}
		}
		else if (func_25(&iLocal_1713, vLocal_1817, "ASS_CS_RTNR", 250f)) {
			*iParam0 = 1;
			return true;
		}
	}
	return false;
}

// Position - 0x1AA8
bool func_25(int *iParam0, vector3 vParam1, char *sParam4, float fParam5) {
	float fVar0;

	if (!iLocal_140) {
		fLocal_141 = func_33(vParam1, 1);
		iLocal_140 = 1;
	}
	fVar0 = func_33(vParam1, 1);
	if (!*iParam0) {
		if (fVar0 > fLocal_141 + fParam5 / 2f) {
			if (!ui::is_message_being_displayed()) {
				func_32(sParam4, 7500, 1);
				*iParam0 = 1;
				func_30(&uLocal_147);
			}
		}
	}
	else if (fVar0 > fParam5) {
		if (!ui::is_message_being_displayed()) {
			if (func_29(&uLocal_147)) {
				if (func_26(&uLocal_147) > 15f) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x1B2F
float func_26(var *uParam0) {
	if (func_29(uParam0)) {
		if (func_28(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_27(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x1B6E
float func_27(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x1BC6
bool func_28(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x1BD6
bool func_29(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x1BE6
void func_30(var *uParam0) { func_31(uParam0, 0f); }

// Position - 0x1BF5
void func_31(int *iParam0, float fParam1) {
	uParam0->f_1 = func_27(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x1C23
void func_32(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 1);
}

// Position - 0x1C3C
float func_33(vector3 vParam0, int iParam3) {
	return func_34(player::get_player_ped(player::get_player_index()), vParam0, iParam3);
}

// Position - 0x1C56
float func_34(int iParam0, vector3 vParam1, int iParam4) {
	if (entity::is_entity_dead(iParam0, 0)) {
		return -1f;
	}
	return gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1), vParam1, iParam4);
}

// Position - 0x1C80
int func_35() {
	if (entity::does_entity_exist(Local_1587[0 /*19*/])) {
		if (!ped::is_ped_injured(Local_1587[0 /*19*/])) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1CA8
int func_36(int iParam0, float fParam1, float fParam2) {
	int iVar0;
	float fVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
				iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
				fVar1 = func_37(iParam0, 1);
				if (fVar1 > fParam1) {
					if (!entity::is_entity_on_screen(iVar0) || entity::is_entity_occluded(iVar0)) {
						return 1;
					}
					else if (fParam2 != 0f) {
						if (fVar1 > fParam2) {
							if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
								return 1;
							}
						}
					}
				}
			}
			else if (func_37(iParam0, 1) > fParam1) {
				if (!entity::is_entity_on_screen(iParam0) || entity::is_entity_occluded(iParam0)) {
					return 1;
				}
			}
		}
	}
	return 0;
}

// Position - 0x1D4F
float func_37(int iParam0, int iParam1) {
	return func_38(player::get_player_ped(player::get_player_index()), iParam0, iParam1);
}

// Position - 0x1D67
float func_38(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x1DC5
void func_39() {
	if (iLocal_1030 >= 13 && iLocal_1030 < 14) {
		if (func_41(&iLocal_1802, &iLocal_1972) && player::is_player_ready_for_cutscene(player::player_id())) {
			if (!ped::is_ped_injured(Local_1510[3 /*19*/])) {
				ped::set_ped_combat_attributes(Local_1510[3 /*19*/], 30, 1);
				entity::set_entity_coords(Local_1510[3 /*19*/], -119.0637f, -973.7914f, 292.04f, 1, 0, 0, 1);
				ai::task_combat_ped(Local_1510[3 /*19*/], iLocal_1801, 0, 16);
			}
			func_40();
			iLocal_1030 = 14;
		}
	}
}

// Position - 0x1E4C
void func_40() {
	iLocal_1760 = 0;
	iLocal_1761 = 0;
	iLocal_1777 = 0;
	iLocal_1721 = 0;
	iLocal_1722 = 0;
	iLocal_1723 = 0;
	func_30(&uLocal_1979);
}

// Position - 0x1E73
int func_41(int iParam0, int iParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (ped::is_ped_injured(*iParam0) || entity::is_entity_dead(*iParam0, 0)) {
			if (entity::does_entity_exist(*iParam1)) {
				entity::set_entity_lod_dist(*iParam1, 500);
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x1EB6
void func_42() {
	func_68();
	func_67(&Local_1202, 5);
	if (bLocal_1750) {
		func_67(&Local_1298, 3);
	}
	func_67(&Local_1645, 3);
	func_67(&Local_1356, 6);
	func_67(&Local_1471, 2);
	func_67(&Local_1510, 4);
	if (entity::does_entity_exist(iLocal_1802)) {
		if (!ped::is_ped_injured(iLocal_1802)) {
			func_67(&Local_1587, 3);
		}
		else {
			if (func_66(Local_1587[0 /*19*/])) {
				func_65(&Local_1587[0 /*19*/].f_2);
			}
			else {
				func_64(Local_1587[0 /*19*/], &Local_1587[0 /*19*/].f_2, -1, 0, 0, 0, -1082130432, 0, -1, -1, 1);
			}
			if (func_66(Local_1587[1 /*19*/])) {
				func_65(&Local_1587[1 /*19*/].f_2);
			}
			else {
				func_64(Local_1587[1 /*19*/], &Local_1587[1 /*19*/].f_2, -1, 0, 0, 0, -1082130432, 0, -1, -1, 1);
			}
			if (func_66(Local_1587[2 /*19*/])) {
				func_65(&Local_1587[2 /*19*/].f_2);
			}
			else {
				func_64(Local_1587[2 /*19*/], &Local_1587[2 /*19*/].f_2, -1, 0, 0, 0, -1082130432, 0, -1, -1, 1);
			}
		}
	}
	func_63();
	func_43();
}

// Position - 0x1FD4
void func_43() {
	if (!func_62()) {
		if (cam::is_screen_faded_in() && !ui::is_message_being_displayed()) {
			if (iLocal_1030 >= 13 && iLocal_1763 < 10) {
				iLocal_1763 = 10;
			}
			else if (iLocal_1030 >= 11 && iLocal_1763 < 4) {
				iLocal_1763 = 4;
			}
			switch (iLocal_1763) {
			case 0:
				if (bLocal_1714) {
					if (!func_29(&uLocal_1979)) {
						func_61(&uLocal_1979);
					}
					else if (func_26(&uLocal_1979) > 2f) {
						iLocal_1804 = func_60(35f);
						if (iLocal_1804 != 0) {
							func_59(iLocal_1804);
							iLocal_1763++;
						}
					}
				}
				break;

			case 1:
				if (iLocal_1762 >= 2) {
					iLocal_1804 = func_60(35f);
					if (iLocal_1804 != 0) {
						func_363(&uLocal_2005, 5, iLocal_1804, "OJAcsGUARD2", 0, 1);
						if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
							func_58(&uLocal_2005, "OJASAUD", "OJAScs_G1a", 9, 0, 0, 0);
						}
						else {
							func_58(&uLocal_2005, "OJASAUD", "OJAScs_G1c", 9, 0, 0, 0);
						}
						iLocal_1763++;
					}
				}
				break;

			case 2:
				if (iLocal_1762 > 3 || iLocal_1719) {
					iLocal_1804 = func_60(35f);
					if (iLocal_1804 != 0) {
						func_363(&uLocal_2005, 7, iLocal_1804, "OJAcsGUARD4", 0, 1);
						if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
							func_58(&uLocal_2005, "OJASAUD", "OJAScs_G3a", 9, 0, 0, 0);
						}
						else {
							func_58(&uLocal_2005, "OJASAUD", "OJAScs_G3c", 9, 0, 0, 0);
						}
						func_30(&uLocal_1979);
						iLocal_1763++;
					}
				}
				break;

			case 3:
				if (func_33(vLocal_1820, 1) <= 50f) {
					if (func_29(&uLocal_1979)) {
						if (func_26(&uLocal_1979) > 15f) {
							iLocal_1804 = func_60(15f);
							if (iLocal_1804 != 0) {
								func_363(&uLocal_2005, 5, iLocal_1804, "OJAcsGUARD2", 0, 1);
								if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
									func_58(&uLocal_2005, "OJASAUD", "OJAScs_G1d", 9, 0, 0, 0);
								}
								else {
									func_58(&uLocal_2005, "OJASAUD", "OJAScs_G1b", 9, 0, 0, 0);
								}
								iLocal_1763++;
							}
						}
					}
				}
				break;

			case 4:
				if (iLocal_1030 >= 11) {
					if (func_29(&uLocal_1979)) {
						if (func_26(&uLocal_1979) > 13f) {
							iLocal_1804 = func_60(50f);
							if (iLocal_1804 != 0) {
								if (ped::_0x6CD5A433374D4CFB(iLocal_1804, player::player_ped_id())) {
									func_363(&uLocal_2005, 7, iLocal_1804, "OJAcsGUARD4", 0, 1);
									func_58(&uLocal_2005, "OJASAUD", "OJAScs_G3d", 9, 0, 0, 0);
									func_30(&uLocal_1979);
									iLocal_1763++;
								}
							}
						}
					}
					else {
						func_30(&uLocal_1979);
					}
				}
				break;

			case 5:
				if (func_29(&uLocal_1979)) {
					if (func_26(&uLocal_1979) > 8f) {
						if (func_57(&Local_1356, 6) >= 2) {
							iLocal_1804 = func_60(50f);
							if (iLocal_1804 != 0) {
								if (ped::_0x6CD5A433374D4CFB(iLocal_1804, player::player_ped_id())) {
									func_363(&uLocal_2005, 6, iLocal_1804, "OJAcsGUARD3", 0, 1);
									if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
										func_58(&uLocal_2005, "OJASAUD", "OJAScs_G2a", 9, 0, 0, 0);
									}
									else {
										func_58(&uLocal_2005, "OJASAUD", "OJAScs_G2b", 9, 0, 0, 0);
									}
									func_30(&uLocal_1979);
									iLocal_1763++;
								}
							}
						}
					}
				}
				else {
					func_56(&uLocal_1979, 0f);
				}
				break;

			case 6:
				if (func_57(&Local_1356, 6) >= 4) {
					iLocal_1804 = func_60(75f);
					if (iLocal_1804 != 0) {
						if (ped::_0x6CD5A433374D4CFB(iLocal_1804, player::player_ped_id())) {
							func_363(&uLocal_2005, 4, iLocal_1804, "OJAcsGUARD", 0, 1);
							if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
								func_45(&uLocal_2005, "OJASAUD", "OJAScs_GDb", "OJAScs_GDb_1", 9, 0, 0);
							}
							else {
								func_45(&uLocal_2005, "OJASAUD", "OJAScs_GDb", "OJAScs_GDb_3", 9, 0, 0);
							}
							func_30(&uLocal_1979);
							iLocal_1763++;
						}
					}
				}
				break;

			case 7:
				if (func_26(&uLocal_1979) > 12f) {
					if (ped::is_ped_in_cover(iLocal_1801, 0) || func_44(&Local_1356, 6) < 4) {
						iLocal_1804 = func_60(75f);
						if (iLocal_1804 != 0) {
							if (ped::is_ped_in_cover(iLocal_1801, 0)) {
								func_363(&uLocal_2005, 7, iLocal_1804, "OJAcsGUARD4", 0, 1);
								func_58(&uLocal_2005, "OJASAUD", "OJAScs_G3b", 9, 0, 0, 0);
							}
							else {
								func_363(&uLocal_2005, 5, iLocal_1804, "OJAcsGUARD2", 0, 1);
								func_58(&uLocal_2005, "OJASAUD", "OJAScs_G1e", 9, 0, 0, 0);
							}
							func_30(&uLocal_1979);
							iLocal_1763++;
						}
					}
				}
				break;

			case 8:
				if (func_44(&Local_1356, 6) <= 2) {
					iLocal_1804 = func_60(50f);
					if (iLocal_1804 != 0) {
						func_363(&uLocal_2005, 8, iLocal_1804, "OJAcsGUARD5", 0, 1);
						if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
							func_45(&uLocal_2005, "OJASAUD", "OJAScs_G4", "OJAScs_G4_1", 9, 0, 0);
						}
						else {
							func_45(&uLocal_2005, "OJASAUD", "OJAScs_G4", "OJAScs_G4_3", 9, 0, 0);
						}
						iLocal_1763++;
					}
				}
				break;

			case 9:
				if (func_44(&Local_1356, 6) <= 1) {
					iLocal_1804 = func_60(50f);
					if (iLocal_1804 != 0) {
						func_363(&uLocal_2005, 4, iLocal_1804, "OJAcsGUARD", 0, 1);
						func_58(&uLocal_2005, "OJASAUD", "OJAScs_GDa", 9, 0, 0, 0);
						iLocal_1763++;
					}
					else if (iLocal_1030 == 13) {
						iLocal_1763++;
					}
				}
				break;

			case 10:
				if (entity::does_entity_exist(Local_1510[0 /*19*/]) && entity::does_entity_exist(iLocal_1802)) {
					if (!ped::is_ped_injured(Local_1510[0 /*19*/]) && !ped::is_ped_injured(iLocal_1802)) {
						func_363(&uLocal_2005, 4, Local_1510[0 /*19*/], "OJAcsGUARD", 0, 1);
						func_58(&uLocal_2005, "OJASAUD", "OJAScs_ROOF", 9, 0, 0, 0);
						iLocal_1763++;
					}
					else {
						iLocal_1763++;
					}
				}
				break;

			case 11:
				if (entity::does_entity_exist(iLocal_1802)) {
					if (!ped::is_ped_injured(iLocal_1802)) {
						func_58(&uLocal_2005, "OJASAUD", "OJAScs_BOSS", 9, 1, 0, 0);
						iLocal_1763++;
					}
					else {
						iLocal_1763++;
					}
				}
				break;

			case 12:
				if (iLocal_1030 == 13) {
					iLocal_1804 = func_60(35f);
					if (iLocal_1804 != 0) {
						if (iLocal_1804 != iLocal_1802) {
							func_363(&uLocal_2005, 8, iLocal_1804, "OJAcsGUARD5", 0, 1);
							if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
								func_58(&uLocal_2005, "OJASAUD", "OJAScs_G5a", 9, 0, 0, 0);
							}
							else {
								func_58(&uLocal_2005, "OJASAUD", "OJAScs_G5b", 9, 0, 0, 0);
							}
						}
						func_30(&uLocal_1979);
						iLocal_1763++;
					}
				}
				break;

			case 13:
				if (func_29(&uLocal_1979)) {
					if (!ped::is_ped_injured(iLocal_1802)) {
						if (func_26(&uLocal_1979) > 10f) {
							func_58(&uLocal_2005, "OJASAUD", "OJAScs_BOSS4", 9, 1, 0, 0);
							iLocal_1763++;
						}
					}
					else {
						iLocal_1763++;
					}
				}
				else {
					func_56(&uLocal_1979, 0f);
				}
				break;

			case 14:
				if (func_29(&uLocal_1979)) {
					if (func_26(&uLocal_1979) > 9f) {
						iLocal_1804 = func_60(35f);
						if (iLocal_1804 != 0) {
							if (iLocal_1804 != iLocal_1802) {
								func_363(&uLocal_2005, 5, iLocal_1804, "OJAcsGUARD2", 0, 1);
								if (gameplay::get_random_int_in_range(0, 65535) % 2 == 0) {
									func_58(&uLocal_2005, "OJASAUD", "OJAScs_G6a", 9, 0, 0, 0);
								}
								else {
									func_58(&uLocal_2005, "OJASAUD", "OJAScs_G6b", 9, 0, 0, 0);
								}
							}
							func_30(&uLocal_1979);
							iLocal_1763++;
						}
					}
				}
				else {
					func_56(&uLocal_1979, 0f);
				}
				break;

			case 15:
				if (!ped::is_ped_injured(iLocal_1802)) {
					if (func_26(&uLocal_1979) > 25f) {
						func_58(&uLocal_2005, "OJASAUD", "OJAScs_BOSS2", 9, 0, 0, 0);
						iLocal_1763++;
					}
				}
				break;
			}
		}
	}
}

// Position - 0x2805
int func_44(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 <= iParam1 - 1) {
		if (entity::does_entity_exist((*uParam0)[iVar1 /*19*/])) {
			if (!ped::is_ped_injured((*uParam0)[iVar1 /*19*/])) {
				iVar0++;
			}
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x2845
int func_45(var *uParam0, char *sParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6) {
	func_55(uParam0, 145, sParam1, iParam5, iParam6, 0);
	if (iParam4 > 7) {
		if (iParam4 < 12) {
			iParam4 = 7;
		}
	}
	Global_15752 = 0;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 1;
	Global_16738 = 0;
	Global_16742 = 0;
	StringCopy(&Global_16749, sParam3, 24);
	Global_2621441 = 0;
	return func_46(sParam2, iParam4, 0);
}

// Position - 0x2899
int func_46(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_54();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_53(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_52();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_51();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_50()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_49()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_48();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_47();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_54();
	}
	return 0;
}

// Position - 0x2B65
void func_47() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x2B96
void func_48() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x2C2B
bool func_49() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x2C52
bool func_50() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x2CEB
void func_51() {
	if (func_12(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_10();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x2D8D
void func_52() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x2DE4
bool func_53(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x2E1F
void func_54() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x2E76
void func_55(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x2ECC
void func_56(var *uParam0, float fParam1) {
	if (!func_29(uParam0)) {
		func_31(uParam0, fParam1);
	}
}

// Position - 0x2EE6
int func_57(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 <= iParam1 - 1) {
		if (entity::does_entity_exist((*uParam0)[iVar1 /*19*/])) {
			if (ped::is_ped_injured((*uParam0)[iVar1 /*19*/])) {
				iVar0++;
			}
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x2F25
bool func_58(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_55(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_46(sParam2, iParam3, 0);
}

// Position - 0x2F73
void func_59(int iParam0) {
	if (!ped::is_ped_injured(iParam0)) {
		func_363(&uLocal_2005, 4, iParam0, "OJAcsGUARD", 0, 1);
		if (weapon::is_ped_armed(iLocal_1801, 6) && !ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
			func_45(&uLocal_2005, "OJASAUD", "OJAScs_SPOT", "OJAScs_SPOT_3", 9, 0, 0);
		}
		else {
			func_45(&uLocal_2005, "OJASAUD", "OJAScs_SPOT", "OJAScs_SPOT_1", 9, 0, 0);
		}
	}
}

// Position - 0x2FDF
int func_60(float fParam0) {
	int iVar0;
	vector3 vVar1;
	int iVar4;
	float fVar5;
	float fVar6;

	iVar0 = 0;
	fVar5 = fParam0 * fParam0;
	vVar1 = {entity::get_entity_coords(iLocal_1801, 1)};
	if (iLocal_1030 < 10) {
		iVar4 = 0;
		while (iVar4 <= 4) {
			if (!ped::is_ped_injured(Local_1202[iVar4 /*19*/])) {
				fVar6 = system::vdist2(vVar1, entity::get_entity_coords(Local_1202[iVar4 /*19*/], 1));
				if (fVar6 < fVar5) {
					fVar5 = fVar6;
					iVar0 = Local_1202[iVar4 /*19*/];
				}
			}
			iVar4++;
		}
	}
	else if (iLocal_1030 < 12) {
		iVar4 = 0;
		while (iVar4 <= 5) {
			if (!ped::is_ped_injured(Local_1356[iVar4 /*19*/])) {
				fVar6 = system::vdist2(vVar1, entity::get_entity_coords(Local_1356[iVar4 /*19*/], 1));
				if (fVar6 < fVar5) {
					fVar5 = fVar6;
					iVar0 = Local_1356[iVar4 /*19*/];
				}
			}
			iVar4++;
		}
	}
	else {
		iVar4 = 0;
		while (iVar4 <= 3) {
			if (!ped::is_ped_injured(Local_1510[iVar4 /*19*/])) {
				fVar6 = system::vdist2(vVar1, entity::get_entity_coords(Local_1510[iVar4 /*19*/], 1));
				if (fVar6 < fVar5) {
					fVar5 = fVar6;
					iVar0 = Local_1510[iVar4 /*19*/];
				}
			}
			iVar4++;
		}
	}
	return iVar0;
}

// Position - 0x30F9
void func_61(var *uParam0) {
	if (!func_29(uParam0)) {
		func_30(uParam0);
	}
}

// Position - 0x3111
bool func_62() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return true;
	}
	return false;
}

// Position - 0x3133
void func_63() {
	if (bLocal_1714) {
		if (!func_62()) {
			if (!ui::is_message_being_displayed()) {
				switch (iLocal_1759) {
				case 0:
					if (iLocal_1762 >= 1) {
						if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV5", 8, 0, 0, 0)) {
							iLocal_1759++;
						}
					}
					break;

				case 1:
					if (iLocal_1762 >= 2) {
						if (!entity::does_entity_exist(iLocal_1802) ||
							!entity::is_entity_dead(iLocal_1802, 0) && iLocal_1030 < 13) {
							if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV1", 8, 0, 0, 0)) {
								iLocal_1759++;
							}
						}
						else {
							iLocal_1759 = 3;
						}
					}
					break;

				case 2:
					if (iLocal_1762 >= 5) {
						if (iLocal_1030 < 13) {
							if (!entity::does_entity_exist(iLocal_1802) || !entity::is_entity_dead(iLocal_1802, 0)) {
								if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV2", 8, 0, 0, 0)) {
									iLocal_1759++;
								}
							}
							else {
								iLocal_1759 = 3;
							}
						}
						else {
							iLocal_1759 = 3;
						}
					}
					break;

				case 3:
					if (iLocal_1762 >= 7) {
						if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV3", 8, 0, 0, 0)) {
							iLocal_1759++;
						}
					}
					break;

				case 4:
					if (iLocal_1030 < 13) {
						if (iLocal_1762 >= 11) {
							if (!entity::does_entity_exist(iLocal_1802) || !entity::is_entity_dead(iLocal_1802, 0)) {
								if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV6", 8, 0, 0, 0)) {
									iLocal_1759++;
								}
							}
							else {
								iLocal_1759 = 6;
							}
						}
					}
					break;

				case 5:
					if (iLocal_1762 >= 13) {
						if (!entity::does_entity_exist(iLocal_1802) || !entity::is_entity_dead(iLocal_1802, 0)) {
							if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_TREV4", 8, 0, 0, 0)) {
								iLocal_1759++;
							}
						}
						else {
							iLocal_1759 = 6;
						}
					}
					break;

				case 6:
					if (iLocal_1762 >= 15) {
						if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_SHIT", 9, 0, 0, 0)) {
							iLocal_1759++;
						}
					}
					break;
				}
			}
		}
	}
}

// Position - 0x3344
int func_64(int iParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5, float fParam6, char *sParam7,
			int iParam8, int iParam9, int iParam10) {
	if (iParam3 == 0) {
		iParam3 = player::get_player_index();
	}
	if (fParam6 < 0f) {
		fParam6 = 100f;
	}
	if (!ped::is_ped_injured(iParam0)) {
		if (!ui::does_ped_have_ai_blip(iParam0)) {
			if (iParam8 == -1) {
				ui::_set_ped_enemy_ai_blip(iParam0, 1);
			}
			else {
				unk_0xB13DCB4C6FAAD238(iParam0, 1, iParam8);
			}
			uParam1->f_7 = iParam0;
			ui::_0xE52B8E7F85D39A08(iParam0, iParam2);
			ui::_set_ai_blip_max_distance(iParam0, fParam6);
			if (ui::does_blip_exist(*uParam1)) {
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (iParam9 != -1) {
			unk_0xFCFACD0DB9D7A57D(iParam0, iParam9);
		}
		ui::_0x0C4BBF625CA98C4E(iParam0, iParam4);
		ui::hide_special_ability_lockon_operation(iParam0, iParam5);
		*uParam1 = ui::_0x7CD934010E115C2C(iParam0);
		if (iParam9 != -1) {
			if (ui::does_blip_exist(*uParam1)) {
				if (iParam8 != -1) {
					ui::set_blip_colour(*uParam1, iParam8);
				}
				ui::begin_text_command_set_blip_name("STRING");
				if (iParam10) {
					ui::add_text_component_substring_player_name(sParam7);
				}
				else {
					ui::add_text_component_substring_text_label(sParam7);
				}
				ui::end_text_command_set_blip_name(*uParam1);
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (!gameplay::is_bit_set(uParam1->f_6, 2)) {
			if (ui::does_blip_exist(*uParam1)) {
				if (!gameplay::is_string_null_or_empty(sParam7)) {
					ui::begin_text_command_set_blip_name("STRING");
					if (iParam10) {
						ui::add_text_component_substring_player_name(sParam7);
					}
					else {
						ui::add_text_component_substring_text_label(sParam7);
					}
					ui::end_text_command_set_blip_name(*uParam1);
				}
				gameplay::set_bit(&uParam1->f_6, 2);
			}
		}
		if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			uParam1->f_1 = ui::_0x56176892826A4FE8(iParam0);
			if (!gameplay::is_bit_set(uParam1->f_6, 3)) {
				if (ui::does_blip_exist(uParam1->f_1)) {
					ui::set_blip_priority(uParam1->f_1, 7);
					gameplay::set_bit(&uParam1->f_6, 3);
				}
			}
		}
		else if (ui::does_blip_exist(uParam1->f_1)) {
			uParam1->f_1 = 0;
			gameplay::clear_bit(&uParam1->f_6, 3);
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0x34E1
void func_65(int *iParam0) {
	bool bVar0;
	struct<8> Var1;

	if (ui::does_blip_exist(*uParam0)) {
		ui::remove_blip(uParam0);
		bVar0 = true;
	}
	if (ui::does_blip_exist(iParam0->f_1)) {
		ui::remove_blip(&iParam0->f_1);
		bVar0 = true;
	}
	if (entity::does_entity_exist(iParam0->f_7)) {
		if (!ped::is_ped_injured(iParam0->f_7)) {
			if (ui::does_ped_have_ai_blip(iParam0->f_7)) {
				ui::_set_ped_enemy_ai_blip(iParam0->f_7, 0);
			}
		}
		bVar0 = true;
	}
	if (bVar0) {
		*iParam0 = {Var1};
	}
}

// Position - 0x354F
bool func_66(int iParam0) {
	if (!ped::is_ped_injured(iParam0)) {
		if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x3570
void func_67(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= iParam1 - 1) {
		if (entity::does_entity_exist((*uParam0)[iVar0 /*19*/])) {
			func_64((*uParam0)[iVar0 /*19*/], &(*uParam0)[iVar0 /*19*/].f_2, -1, 0, 0, 0, -1082130432, 0, -1, -1, 1);
			if (ped::is_ped_injured((*uParam0)[iVar0 /*19*/])) {
				if (!(*uParam0)[iVar0 /*19*/].f_1) {
					iLocal_1762++;
					(*uParam0)[iVar0 /*19*/].f_1 = 1;
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x35E4
void func_68() {
	int iVar0;
	int iVar1;

	if (!bLocal_1714) {
		if (iLocal_1766 == 0) {
			iVar0 = 0;
			while (iVar0 <= 2) {
				if (func_72(Local_1202[iVar0 /*19*/], 0, &Local_122, &iLocal_133, 0, 1, 0, 0, 1) ||
					func_71(Local_1202[iVar0 /*19*/], 0)) {
					bLocal_1714 = true;
					return;
				}
				iVar0++;
			}
		}
		else if (iLocal_1766 == 1) {
			iVar0 = 3;
			while (iVar0 <= 4) {
				if (func_72(Local_1202[iVar0 /*19*/], 0, &Local_122, &iLocal_133, 0, 1, 0, 0, 1) ||
					func_71(Local_1202[iVar0 /*19*/], 0)) {
					bLocal_1714 = true;
					return;
				}
				iVar0++;
			}
		}
		else if (iLocal_1766 == 2) {
			iVar0 = 0;
			while (iVar0 <= 2) {
				if (func_72(Local_1298[iVar0 /*19*/], 0, &Local_122, &iLocal_133, 0, 1, 0, 0, 1) ||
					func_71(Local_1298[iVar0 /*19*/], 0)) {
					bLocal_1714 = true;
					return;
				}
				iVar0++;
			}
		}
		iLocal_1766++;
		if (iLocal_1766 > 2) {
			iLocal_1766 = 0;
		}
		if (!iLocal_1715) {
			iVar1 = 0;
			while (iVar1 < 5) {
				if (func_69(Local_1202[iVar1 /*19*/])) {
					iLocal_1810 = Local_1202[iVar1 /*19*/];
					iLocal_1715 = 1;
					return;
				}
				iVar1++;
			}
			iVar1 = 0;
			iVar1 = 0;
			while (iVar1 < 3) {
				if (func_69(Local_1298[iVar1 /*19*/])) {
					iLocal_1810 = Local_1298[iVar1 /*19*/];
					iLocal_1715 = 1;
					return;
				}
				iVar1++;
			}
		}
	}
}

// Position - 0x3756
bool func_69(int iParam0) {
	float fVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (func_70()) {
				fVar0 = func_37(iParam0, 0);
				if (fVar0 <= 33f && ped::_0x6CD5A433374D4CFB(iParam0, iLocal_1801) ||
					ped::is_ped_in_any_vehicle(iLocal_1801, 0) && fVar0 <= 5f) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x37B6
bool func_70() {
	if (entity::is_entity_in_angled_area(iLocal_1801, -140.6299f, -1029.231f, 26.29815f, -109.2613f, -943.295f,
										 29.2294f, 107f, 0, 0, 0) ||
		entity::is_entity_in_angled_area(iLocal_1801, -169.2749f, -1096.598f, 18.68888f, -142.4606f, -1029.005f,
										 27.31028f, 99.5f, 0, 0, 0)) {
		return true;
	}
	return false;
}

// Position - 0x3826
int func_71(int iParam0, int iParam1) {
	int iVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1) &&
			!entity::is_entity_dead(iParam0, 0)) {
			return 1;
		}
		iVar0 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
				return 1;
			}
		}
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (ped::is_ped_being_jacked(iParam0)) {
				if (ped::get_peds_jacker(iParam0) == player::player_ped_id()) {
					return 1;
				}
			}
		}
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam1, player::player_ped_id(), 1)) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x38BA
bool func_72(int iParam0, int iParam1, var *uParam2, int *iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	int iVar0;
	bool bVar1;

	iVar0 = player::player_ped_id();
	if (!entity::is_entity_dead(iVar0, 0) && !entity::is_entity_dead(iParam0, 0)) {
		if (!func_79(*uParam2, 1)) {
			if (func_78(iParam0, uParam2)) {
				*iParam3 = 1;
				return true;
			}
		}
		if (!func_79(*uParam2, 2)) {
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				*iParam3 = 2;
				return true;
			}
		}
		if (!func_79(*uParam2, 4)) {
			if (func_76(iVar0, iParam0, uParam2, iParam5)) {
				*iParam3 = 4;
				return true;
			}
		}
		if (!func_79(*uParam2, 8)) {
			if (func_75(iVar0, iParam0, uParam2)) {
				*iParam3 = 8;
				return true;
			}
		}
		bVar1 = !func_79(*uParam2, 128);
		if (iParam4) {
			if (func_73(iParam0, iParam1, 1, iParam6, bVar1, 1)) {
				*iParam3 = 32;
				return true;
			}
		}
		else if (!func_79(*uParam2, 16)) {
			if (func_73(iParam0, iParam1, 0, iParam6, bVar1, iParam8)) {
				*iParam3 = 16;
				return true;
			}
		}
	}
	else if (entity::does_entity_exist(iParam0)) {
		if (iParam7 && entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
			*iParam3 = 16;
			return true;
		}
	}
	return false;
}

// Position - 0x39E4
bool func_73(int iParam0, int iParam1, int iParam2, bool bParam3, bool bParam4, int iParam5) {
	int iVar0;
	int iVar1;

	if (bParam3) {
		if (!bLocal_115) {
			iLocal_116 = entity::get_entity_health(iParam0);
			bLocal_115 = true;
		}
		iLocal_117 = entity::get_entity_health(iParam0);
		iLocal_118 = iLocal_116 - iLocal_117;
		iVar0 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
				if (IntToFloat(iLocal_118) > 100f) {
					return true;
				}
			}
		}
		if (bLocal_115) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
				if (IntToFloat(iLocal_118) > 100f) {
					return true;
				}
			}
		}
	}
	else if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
		return true;
	}
	if (!bParam3) {
		iVar1 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar1, 1)) {
				return true;
			}
		}
	}
	if (bParam4) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (ped::is_ped_being_jacked(iParam0)) {
				if (ped::get_peds_jacker(iParam0) == player::player_ped_id()) {
					return true;
				}
			}
		}
	}
	if (iParam5) {
		if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
			if (entity::is_entity_at_coord(iParam0, entity::get_entity_coords(player::player_ped_id(), 1), 10f, 10f,
										   10f, 0, 1, 0)) {
				if (player::has_player_damaged_at_least_one_ped(player::player_id())) {
					return true;
				}
			}
		}
	}
	if (ped::is_ped_performing_stealth_kill(player::player_ped_id())) {
		if (ped::was_ped_killed_by_stealth(iParam0)) {
			return true;
		}
	}
	if (func_74(player::player_ped_id(), iParam0)) {
		return true;
	}
	if (iParam2) {
		if (ped::is_ped_ragdoll(iParam0) && func_37(iParam0, 1) < 1.5f) {
			return true;
		}
		else if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			if (entity::is_entity_touching_entity(player::player_ped_id(), ped::get_vehicle_ped_is_in(iParam0, 0))) {
				return true;
			}
		}
		else if (entity::is_entity_touching_entity(player::player_ped_id(), iParam0)) {
			return true;
		}
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam1, player::player_ped_id(), 1)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x3BAC
bool func_74(int iParam0, int iParam1) {
	int iVar0;

	weapon::get_current_ped_weapon(iParam0, &iVar0, 1);
	if (iVar0 == joaat("weapon_petrolcan")) {
		if (ped::is_ped_shooting(iParam0)) {
			if (system::vdist(entity::get_entity_coords(iParam0, 1), entity::get_entity_coords(iParam1, 1)) < 2.5f) {
				if (ped::is_ped_facing_ped(iParam0, iParam1, 180f)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x3C01
bool func_75(int iParam0, int iParam1, var *uParam2) {
	if (weapon::is_ped_armed(iParam0, 4)) {
		if (ped::is_ped_shooting(iParam0) && !weapon::is_ped_current_weapon_silenced(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_4),
										   IntToFloat(uParam2->f_4), IntToFloat(uParam2->f_4), 0, 1, 0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x3C4F
bool func_76(int iParam0, int iParam1, var *uParam2, bool bParam3) {
	vector3 vVar0;
	int iVar3;

	iVar3 = 0;
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar0 = {entity::get_entity_coords(iParam1, 1)};
	}
	if (gameplay::is_bullet_in_area(vVar0, 4f, 1)) {
		return true;
	}
	if (gameplay::has_bullet_impacted_in_area(vVar0, system::to_float(uParam2->f_6), 1, 1)) {
		return true;
	}
	if (weapon::is_ped_armed(iParam0, 2)) {
		if (ped::is_ped_shooting(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_6 * 3),
										   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
				if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
					entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
					return true;
				}
			}
		}
		else {
			if (ped::is_ped_in_any_vehicle(entity::get_ped_index_from_entity_index(iParam1), 0)) {
				iVar3 = ped::get_vehicle_ped_is_in(entity::get_ped_index_from_entity_index(iParam1), 0);
			}
			if (ped::is_ped_planting_bomb(iParam0) || func_77(iVar3)) {
				if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1),
											   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3),
											   IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
					if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
						entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
						return true;
					}
				}
			}
		}
	}
	if (bParam3) {
		if (gameplay::is_projectile_in_area(vVar0.x - IntToFloat(uParam2->f_6), vVar0.y - IntToFloat(uParam2->f_6),
											vVar0.z - IntToFloat(uParam2->f_6), vVar0.x + IntToFloat(uParam2->f_6),
											vVar0.y + IntToFloat(uParam2->f_6), vVar0.z + IntToFloat(uParam2->f_6),
											0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x3DC8
int func_77(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0) != 0) {
				if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
					if (iVar0 == joaat("weapon_stickybomb")) {
						if (func_38(player::player_ped_id(), iParam0, 1) < 40f) {
							if (player::get_entity_player_is_free_aiming_at(player::player_id(), &iVar1)) {
								if (entity::is_entity_a_vehicle(iVar1) &&
										entity::get_vehicle_index_from_entity_index(iVar1) == iParam0 ||
									entity::is_entity_a_ped(iVar1) &&
										entity::get_ped_index_from_entity_index(iVar1) ==
											vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0)) {
									if (ped::is_ped_on_foot(player::player_ped_id()) &&
											controls::is_control_pressed(0, 24) ||
										ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
											controls::is_control_pressed(0, 69)) {
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x3E96
bool func_78(int iParam0, var *uParam1) {
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (weapon::is_ped_armed(player::player_ped_id(), 6)) {
			if (player::is_player_free_aiming_at_entity(player::player_id(), iParam0) ||
				player::is_player_targetting_entity(player::player_id(), iParam0)) {
				if (ped::is_ped_facing_ped(iParam0, player::player_ped_id(), 90f)) {
					if (func_37(iParam0, 1) < uParam1->f_2) {
						if (uParam1->f_1 == 0) {
							uParam1->f_1 = gameplay::get_game_timer();
						}
						else if (gameplay::get_game_timer() - uParam1->f_1 > uParam1->f_3) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x3F1B
bool func_79(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x3F2A
void func_80() {
	switch (iLocal_1075) {
	case 0:
		if (!iLocal_139) {
			if (!iLocal_1738) {
				iLocal_1031 = 1;
				iLocal_1031 = iLocal_1031;
				bLocal_137 = true;
				func_167();
			}
			else {
				iLocal_1031 = 0;
				bLocal_137 = false;
			}
			Global_101700.f_18922.f_9 = func_26(&uLocal_1976);
			fLocal_134 = Global_101700.f_18922.f_9;
			func_160();
			iLocal_139 = 1;
			iLocal_1075 = 1;
		}
		break;

	case 1:
		if (!iLocal_1066) {
			audio::play_mission_complete_audio("FRANKLIN_BIG_01");
			iLocal_1066 = 1;
		}
		if (func_156(&uLocal_150, 1, 0) && audio::_0x6F259F82D873B8B8()) {
			func_155(&uLocal_1077, 0, 0, 0, 1);
			func_154(&uLocal_1077, "ASS_CS_CONT", 2, 215, 1, 1, 0);
			func_154(&uLocal_1077, "ES_XPAND", 2, 216, 1, 1, 0);
			system::settimera(0);
			iLocal_1075 = 2;
		}
		break;

	case 2:
		if (func_126(&uLocal_150, 0, 1065353216, 0, 0, 0)) {
			bLocal_1065 = true;
		}
		if (!bLocal_1065) {
			func_118(&uLocal_1077, 1128792064, 1, 0, 1, 1065353216);
		}
		if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
			if (!bLocal_1065) {
				bLocal_1065 = true;
				func_117(&uLocal_150);
			}
		}
		if (bLocal_1065) {
			if (func_126(&uLocal_150, 0, 1065353216, 0, 0, 0)) {
				func_115(&uLocal_150);
				Global_101700.f_18922++;
				func_114();
				func_85(Local_801);
				func_83(0, 0);
				func_81();
				func_439();
			}
		}
		break;
	}
}

// Position - 0x40A6
void func_81() { func_82(); }

// Position - 0x40B3
int func_82() {
	if (func_17(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x40FE
void func_83(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (!Global_55824) {
		Global_55824 = iParam1;
	}
	if (iParam0) {
		if (func_17(0) && Global_69948.f_1 == 1 && func_84(Global_69948)) {
		}
		else {
			Global_55822 = 1;
		}
	}
	if (Global_101700.f_8044 || func_17(0)) {
		iVar0 = func_16();
		iVar1 = Global_82576[iVar0 /*5*/];
		uVar2 = G_TextMessageConfig.f_109[iVar1 /*4*/];
		if (iVar0 == -1) {
			if (Global_101700.f_8044) {
			}
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 4)) {
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 5)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 4);
		gameplay::set_bit(&Global_69950, 1);
		Global_69966 = uVar2;
		Global_69967 = gameplay::get_game_timer();
	}
}

// Position - 0x41D4
int func_84(int iParam0) {
	switch (iParam0) {
	case 71: return 1;

	case 86: return 1;

	case 91: return 1;

	default: return 0;
	}
	return 0;
}

// Position - 0x4212
void func_85(struct<25> Param0, var uParam25, var uParam26, var uParam27, var uParam28, var uParam29, var uParam30,
			 var uParam31, var uParam32, var uParam33, var uParam34, var uParam35, var uParam36, var uParam37,
			 var uParam38) {
	float fVar0;

	fVar0 = 1f + func_113();
	fVar0 *= Param0.f_23;
	if (func_79(Global_101700.f_18922.f_1, 4194304)) {
		fVar0 += Param0.f_24;
	}
	func_86(func_10(), 96, system::round(fVar0), 0, 0);
}

// Position - 0x425D
void func_86(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;

	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 3) {
		return;
	}
	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 4) {
		return;
	}
	func_87(Global_101700.f_27009[iParam0 /*29*/].f_17, 1, iParam1, iParam2, 0);
	if (iParam3) {
		iVar0 = 0;
		if (iParam4) {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_random_peds"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_random_peds"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_random_peds"); break;

			default: return;
			}
		}
		else {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_missions"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_missions"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_missions"); break;

			default: return;
			}
		}
		stats::stat_get_int(iVar1, &iVar0, -1);
		iVar0 += iParam2;
		stats::stat_set_int(iVar1, iVar0, 1);
	}
}

// Position - 0x4344
int func_87(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	func_112();
	if (iParam3 < 1) {
		return 0;
	}
	fVar0 = 1f;
	switch (iParam1) {
	case 0:
		switch (iParam0) {
		case 0:
			func_111(99, 1);
			func_110(joaat("sp0_money_total_spent"), iParam3);
			break;

		case 1: func_110(joaat("sp1_money_total_spent"), iParam3); break;

		case 2: func_110(joaat("sp2_money_total_spent"), iParam3); break;
		}
		func_95(0);
		switch (iParam2) {
		case 126:
		case 128:
		case 124:
		case 125:
		case 127:
			if (func_94(5)) {
				fVar0 = 0.9f;
				iVar1 = 5;
			}
			break;

		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
			switch (iParam0) {
			case 0: func_110(joaat("sp0_money_spent_on_tattoos"), iParam3); break;

			case 1: func_110(joaat("sp1_money_spent_on_tattoos"), iParam3); break;

			case 2: func_110(joaat("sp2_money_spent_on_tattoos"), iParam3); break;
			}
			if (func_94(1)) {
				fVar0 = 0f;
				iVar1 = 1;
			}
			break;

		case 21:
			switch (iParam0) {
			case 0: func_110(joaat("sp0_money_spent_on_taxis"), iParam3); break;

			case 1: func_110(joaat("sp1_money_spent_on_taxis"), iParam3); break;

			case 2: func_110(joaat("sp2_money_spent_on_taxis"), iParam3); break;
			}
			break;

		case 25:
			switch (iParam0) {
			case 0: func_110(joaat("sp0_money_spent_in_strip_clubs"), iParam3); break;

			case 1: func_110(joaat("sp1_money_spent_in_strip_clubs"), iParam3); break;

			case 2: func_110(joaat("sp2_money_spent_in_strip_clubs"), iParam3); break;
			}
			break;

		case 98:
		case 99:
		case 100:
		case 101:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 112:
			switch (iParam0) {
			case 0: func_110(joaat("sp0_money_spent_property"), iParam3); break;

			case 1: func_110(joaat("sp1_money_spent_property"), iParam3); break;

			case 2: func_110(joaat("sp2_money_spent_property"), iParam3); break;
			}
			break;

		default:
			switch (script::get_hash_of_this_script_name()) {
			case joaat("clothes_shop_sp"):
				switch (iParam0) {
				case 0: func_110(joaat("sp0_money_spent_in_clothes"), iParam3); break;

				case 1: func_110(joaat("sp1_money_spent_in_clothes"), iParam3); break;

				case 2: func_110(joaat("sp2_money_spent_in_clothes"), iParam3); break;
				}
				break;

			case joaat("hairdo_shop_sp"):
				switch (iParam0) {
				case 0: func_110(joaat("sp0_money_spent_on_hairdos"), iParam3); break;

				case 1: func_110(joaat("sp1_money_spent_on_hairdos"), iParam3); break;

				case 2: func_110(joaat("sp2_money_spent_on_hairdos"), iParam3); break;
				}
				if (func_94(0)) {
					fVar0 = 0f;
					iVar1 = 0;
				}
				break;

			case joaat("gunclub_shop"):
				switch (iParam0) {
				case 0: func_110(joaat("sp0_money_spent_in_buying_guns"), iParam3); break;

				case 1: func_110(joaat("sp1_money_spent_in_buying_guns"), iParam3); break;

				case 2: func_110(joaat("sp2_money_spent_in_buying_guns"), iParam3); break;
				}
				break;

			case joaat("carmod_shop"):
				switch (iParam0) {
				case 0: func_110(joaat("sp0_money_spent_car_mods"), iParam3); break;

				case 1: func_110(joaat("sp1_money_spent_car_mods"), iParam3); break;

				case 2: func_110(joaat("sp2_money_spent_car_mods"), iParam3); break;
				}
				func_93(iParam3);
				break;
			}
			break;
		}
		break;

	case 1:
		switch (iParam0) {
		case 0: func_111(95, iParam3); break;

		case 1: func_111(97, iParam3); break;

		case 2: func_111(96, iParam3); break;
		}
		func_111(98, iParam3);
		break;
	}
	iVar2 = iParam0;
	iParam3 = system::floor(fVar0 * system::to_float(iParam3));
	iVar3 = 0;
	iVar4 = iParam3;
	if (fVar0 == 0f) {
		func_90(iVar1);
		return 1;
	}
	else if (fVar0 != 1f) {
		func_90(iVar1);
	}
	iVar5 = Global_52996[iVar2] + iParam3;
	switch (iParam1) {
	case 1:
		if (Global_52996[iVar2] >= 0 && iParam3 > 0) {
			if (iVar5 <= 0) {
				Global_52996[iVar2] = 2147483647;
			}
			else {
				Global_52996[iVar2] += iParam3;
			}
		}
		switch (iParam0) {
		case 0: func_110(joaat("sp0_total_cash_earned"), iParam3); break;

		case 1: func_110(joaat("sp1_total_cash_earned"), iParam3); break;

		case 2: func_110(joaat("sp2_total_cash_earned"), iParam3); break;
		}
		break;

	case 0:
		if (!iParam4) {
			if (Global_52996[iVar2] - iParam3 < 0) {
				return 0;
			}
		}
		iVar3 = Global_52996[iVar2];
		Global_52996[iVar2] -= iParam3;
		if (iParam4) {
			iVar4 = iVar3;
		}
		break;
	}
	if (iParam2 == 1) {
		if (iVar4 > 20) {
		}
	}
	else {
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/] = iParam1;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_1 =
			iParam2;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_2 =
			iParam3;
		Global_101700.f_19523.f_233[iVar2 /*69*/]++;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_1++;
		if (Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 > 10) {
			Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 = 0;
		}
	}
	func_89(iParam0);
	if (Global_35781 == 15) {
		func_88(0);
	}
	return 1;
}

// Position - 0x4943
void func_88(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x4BC5
void func_89(int iParam0) {
	int iVar0;

	iVar0 = Global_52996[iParam0];
	switch (iParam0) {
	case 0: stats::stat_set_int(joaat("sp0_total_cash"), iVar0, 1); break;

	case 1: stats::stat_set_int(joaat("sp1_total_cash"), iVar0, 1); break;

	case 2: stats::stat_set_int(joaat("sp2_total_cash"), iVar0, 1); break;
	}
}

// Position - 0x4C1F
void func_90(int iParam0) {
	bool bVar0;
	char cVar1[64];

	bVar0 = false;
	if (!network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0)) {
			bVar0 = true;
			gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		}
	}
	else if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0) ||
			 gameplay::is_bit_set(Global_2097152[func_92() /*10758*/].f_7546.f_10, iParam0)) {
		bVar0 = true;
		gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		gameplay::clear_bit(&Global_2097152[func_92() /*10758*/].f_7546.f_10, iParam0);
	}
	if (bVar0) {
		StringCopy(&cVar1, "CHAR_LIFEINVADER", 64);
		ui::_set_notification_text_entry("COUP_RED");
		ui::add_text_component_substring_text_label(func_91(iParam0));
		ui::_set_notification_message(&cVar1, &cVar1, 1, 0, "", 0);
	}
}

// Position - 0x4CE1
char *func_91(int iParam0) {
	switch (iParam0) {
	case 0: return "COUP_HAIRC";

	case 1: return "COUP_TATTOO";

	case 2: return "COUP_WARSTOCK";

	case 3: return "COUP_MOSPORT";

	case 4: return "COUP_ELITAS";

	case 5: return "COUP_MEDSPENS";

	case 6: return "COUP_SPRUNK";

	case 7: return "COUP_RESPRAY";

	default:
	}
	return "";
}

// Position - 0x4D5B
int func_92() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x4D68
void func_93(int iParam0) {
	func_111(93, iParam0);
	func_111(29, iParam0);
	func_111(30, iParam0);
}

// Position - 0x4D88
bool func_94(int iParam0) {
	if (!network::network_is_game_in_progress()) {
		return gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0);
	}
	return gameplay::is_bit_set(Global_2097152[func_92() /*10758*/].f_7546.f_10, iParam0);
}

// Position - 0x4DC4
int func_95(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (player::has_achievement_been_passed(27)) {
		return 0;
	}
	if (stats::stat_get_int(joaat("sp0_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp1_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp2_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (iParam0) {
	}
	iVar2 = 0;
	stats::stat_get_int(joaat("num_cash_spent"), &iVar2, -1);
	if (iVar1 > 0 && iVar2 / 2000000 != iVar1 / 2000000) {
		stats::stat_set_int(joaat("num_cash_spent"), iVar1, 1);
		func_109(27, iVar1);
	}
	if (iVar1 < 200000000) {
		return 0;
	}
	func_96(27, 1);
	return 1;
}

// Position - 0x4E7B
int func_96(int iParam0, int iParam1) {
	if (iParam0 >= 70) {
		return 0;
	}
	return func_97(iParam0, iParam1);
}

// Position - 0x4E96
int func_97(int iParam0, int iParam1) {
	if (func_12(14) && !func_108(iParam0)) {
		return 0;
	}
	if (player::has_achievement_been_passed(iParam0) && iParam1 == 1) {
		return 0;
	}
	if (Global_25436 != 0 && !Global_69702) {
		return 0;
	}
	if (func_107(&Global_2595550)) {
		if (func_105(&Global_2595550, iParam0)) {
			return 0;
		}
		if (func_98(&Global_2595550, iParam0)) {
			return 1;
		}
	}
	else {
		if (!player::give_achievement_to_player(iParam0)) {
			return 0;
		}
		if (player::has_achievement_been_passed(iParam0)) {
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x4F33
bool func_98(var *uParam0, int iParam1) {
	int iVar0;
	var *uVar1[70];

	if (player::has_achievement_been_passed(iParam1)) {
		return false;
	}
	if (func_12(14) && !func_108(iParam1)) {
		return false;
	}
	if (func_105(uParam0, iParam1)) {
		return false;
	}
	if (func_104(uParam0) < 0f) {
		func_103(uParam0, 0);
	}
	func_101(&uVar1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0 - 1) {
		uVar1[iVar0 + 1] = (*uParam0)[iVar0];
		iVar0++;
	}
	func_99(&uVar1, iParam1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = uVar1[iVar0];
		iVar0++;
	}
	return true;
}

// Position - 0x4FE4
int func_99(var *uParam0, int iParam1) {
	int iVar0;

	if (player::has_achievement_been_passed(iParam1)) {
		return 0;
	}
	if (func_12(14) && !func_108(iParam1)) {
		return 0;
	}
	if (func_105(uParam0, iParam1)) {
		return 0;
	}
	if (func_104(uParam0) < 0f) {
		func_103(uParam0, 0);
	}
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (func_100(uParam0, iVar0)) {
			(*uParam0)[iVar0] = iParam1;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x505F
bool func_100(var *uParam0, int iParam1) { return (*uParam0)[iParam1] == 70; }

// Position - 0x5070
void func_101(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		func_102(uParam0, iVar0);
		iVar0++;
	}
	func_103(uParam0, Global_2595549 - 0.5f);
}

// Position - 0x50A4
void func_102(var *uParam0, int iParam1) { (*uParam0)[iParam1] = 70; }

// Position - 0x50B4
void func_103(var *uParam0, float fParam1) {
	if (fParam1 == 0f) {
		uParam0->f_72 = 0f;
	}
	else {
		uParam0->f_72 = fParam1;
	}
}

// Position - 0x50D1
float func_104(var *uParam0) { return uParam0->f_72; }

// Position - 0x50DD
bool func_105(var *uParam0, int iParam1) { return func_106(uParam0, iParam1) != -1; }

// Position - 0x50EF
int func_106(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x511C
bool func_107(var *uParam0) { return uParam0->f_71 == 1; }

// Position - 0x512A
int func_108(int iParam0) {
	switch (iParam0) {
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69: return 1;

	default:
	}
	return 0;
}

// Position - 0x517A
int func_109(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x51CB
void func_110(int iParam0, int iParam1) {
	int iVar0;

	stats::stat_get_int(iParam0, &iVar0, -1);
	iVar0 += iParam1;
	stats::stat_set_int(iParam0, iVar0, 1);
}

// Position - 0x51EE
void func_111(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 < 1) {
		return;
	}
	if (Global_51564[iParam0 /*7*/].f_2) {
		return;
	}
	if (network::network_is_game_in_progress()) {
		return;
	}
	if (Global_51564[iParam0 /*7*/]) {
		stats::stat_get_int(Global_51564[iParam0 /*7*/].f_1, &iVar0, -1);
		iVar0 += iParam1;
		stats::stat_set_int(Global_51564[iParam0 /*7*/].f_1, iVar0, 1);
	}
}

// Position - 0x524B
void func_112() {
	int iVar0;

	if (network::network_is_signed_in()) {
		stats::stat_get_int(joaat("sp0_total_cash"), &iVar0, -1);
		if (Global_52996[0] != iVar0) {
			Global_52996[0] = iVar0;
		}
		stats::stat_get_int(joaat("sp1_total_cash"), &iVar0, -1);
		if (Global_52996[1] != iVar0) {
			Global_52996[1] = iVar0;
		}
		stats::stat_get_int(joaat("sp2_total_cash"), &iVar0, -1);
		if (Global_52996[2] != iVar0) {
			Global_52996[2] = iVar0;
		}
	}
}

// Position - 0x52C0
float func_113() {
	float fVar0;

	fVar0 = 0f;
	if (func_79(Global_101700.f_18922.f_1, 8192)) {
		fVar0 += 0.2f;
	}
	if (func_79(Global_101700.f_18922.f_1, 16384)) {
		fVar0 += 0.2f;
	}
	if (func_79(Global_101700.f_18922.f_1, 32768)) {
		fVar0 += 0.2f;
	}
	if (func_79(Global_101700.f_18922.f_1, 65536)) {
		fVar0 += 0.1f;
	}
	if (func_79(Global_101700.f_18922.f_1, 131072)) {
		fVar0 += 0.1f;
	}
	if (func_79(Global_101700.f_18922.f_1, 262144)) {
		fVar0 += 0.1f;
	}
	if (func_79(Global_101700.f_18922.f_1, 524288)) {
		fVar0 += 0.333f;
	}
	if (func_79(Global_101700.f_18922.f_1, 1048576)) {
		fVar0 += 0.333f;
	}
	if (func_79(Global_101700.f_18922.f_1, 2097152)) {
		fVar0 += 0.333f;
	}
	return fVar0;
}

// Position - 0x53D9
void func_114() { func_448(&Global_101700.f_18922.f_1, 2048); }

// Position - 0x53F1
void func_115(var *uParam0) {
	if (uParam0->f_1 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_1);
		uParam0->f_1 = 0;
	}
	if (uParam0->f_562 && uParam0->f_4 != 0) {
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_4);
		uParam0->f_4 = 0;
	}
	if (uParam0->f_564) {
		script::set_no_loading_screen(0);
		uParam0->f_564 = 0;
	}
	if (!Global_69970) {
		if (!player::is_player_dead(player::get_player_index())) {
			if (!G_TextMessageConfig) {
				if (cam::is_screen_faded_out() && !func_17(0)) {
					cam::do_screen_fade_in(800);
				}
			}
		}
	}
	func_116(0);
}

// Position - 0x5498
void func_116(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x54AC
void func_117(var *uParam0) {
	if (uParam0->f_561 || uParam0->f_572 <= uParam0->f_558) {
		uParam0->f_561 = 0;
		uParam0->f_558 = uParam0->f_572 - 1;
	}
}

// Position - 0x54DF
void func_118(var *uParam0, float fParam1, int iParam2, int iParam3, int iParam4, float fParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char *sVar3;
	bool bVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	float fVar8;

	if (cam::is_screen_fading_out() || cam::is_screen_fading_in() || cam::is_screen_faded_out() ||
		gameplay::is_frontend_fading()) {
		if (!iParam3) {
			return;
		}
	}
	if (!func_125(uParam0)) {
		return;
	}
	ui::hide_loading_on_fade_this_frame();
	graphics::_set_2d_layer(iParam2);
	if (!func_124(uParam0->f_1, 256) || func_124(uParam0->f_1, 8192) && controls::_0x6CD79468A1E595C6(2)) {
		graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
		graphics::_push_scaleform_movie_function_parameter_float(fParam1);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_MAX_WIDTH");
		graphics::_push_scaleform_movie_function_parameter_float(fParam5);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(*uParam0, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(func_124(uParam0->f_1, 4096));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar5 = 0;
		iVar6 = 0;
		while (iVar6 < uParam0->f_123) {
			switch (uParam0->f_2[iVar6 /*15*/].f_2) {
			case 0: bVar4 = true; break;

			case 1: bVar4 = controls::_is_input_disabled(2); break;

			case 2: bVar4 = !controls::_is_input_disabled(2); break;

			default: bVar4 = false; break;
			}
			if (bVar4) {
				if (graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT")) {
					graphics::_push_scaleform_movie_function_parameter_int(iVar5);
					iVar5++;
					iVar7 = 0;
					while (iVar7 < uParam0->f_2[iVar6 /*15*/].f_14) {
						iVar0 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/];
						iVar1 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/].f_1;
						iVar2 = gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_13, iVar7);
						if (!gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_12, iVar7)) {
							sVar3 = controls::get_control_instructional_button(iVar0, iVar1, iVar2);
						}
						else {
							sVar3 = controls::_0x80C2FD58D720C801(iVar0, iVar1, iVar2);
						}
						if (!gameplay::is_string_null_or_empty(sVar3)) {
							func_123(sVar3);
						}
						iVar7++;
					}
					if (!gameplay::is_string_null_or_empty(uParam0->f_2[iVar6 /*15*/])) {
						func_122(uParam0->f_2[iVar6 /*15*/]);
					}
					if (gameplay::is_pc_version()) {
						if (func_124(uParam0->f_1, 4096)) {
							if (uParam0->f_2[iVar6 /*15*/].f_1) {
								graphics::_push_scaleform_movie_function_parameter_bool(1);
								graphics::_push_scaleform_movie_function_parameter_int(
									uParam0->f_2[iVar6 /*15*/].f_3[0 /*2*/].f_1);
							}
							else {
								graphics::_push_scaleform_movie_function_parameter_bool(0);
								graphics::_push_scaleform_movie_function_parameter_int(-1);
							}
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar6++;
		}
		fVar8 = func_121(iParam4, func_121(func_124(uParam0->f_1, 32), 1f, 0f), -1f);
		graphics::_push_scaleform_movie_function(*uParam0, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_float(fVar8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(80f);
		graphics::_pop_scaleform_movie_function_void();
		func_120(&uParam0->f_1, 256);
		func_119(&uParam0->f_1, 128);
	}
	graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
}

// Position - 0x579F
void func_119(int *iParam0, int iParam1) { *iParam0 -= (*iParam0 & iParam1); }

// Position - 0x57B4
void func_120(var *uParam0, int iParam1) { *uParam0 |= iParam1; }

// Position - 0x57C5
float func_121(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x57DC
void func_122(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x57EE
void func_123(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x57FC
bool func_124(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x580B
int func_125(var *uParam0) {
	if (*uParam0 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			func_120(&uParam0->f_1, 1);
			return 1;
		}
	}
	return 0;
}

// Position - 0x5832
bool func_126(var *uParam0, int iParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (gameplay::get_frame_count() == uParam0->f_574) {
		return uParam0->f_575;
	}
	uParam0->f_574 = gameplay::get_frame_count();
	if (!network::network_is_game_in_progress()) {
		if (ped::is_ped_dead_or_dying(player::get_player_ped(player::get_player_index()), 1)) {
			uParam0->f_575 = 1;
			return true;
		}
		if (ai::is_ped_being_arrested(player::get_player_ped(player::get_player_index()))) {
			uParam0->f_575 = 1;
			return true;
		}
	}
	if (!uParam0->f_564) {
		if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
			script::set_no_loading_screen(1);
			uParam0->f_564 = 1;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (!network::network_is_game_in_progress()) {
			if (player::is_special_ability_active(player::player_id())) {
				player::special_ability_deactivate(player::player_id());
			}
		}
	}
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(19);
	controls::disable_control_action(2, 19, 1);
	controls::disable_control_action(0, 37, 1);
	controls::disable_control_action(0, 21, 1);
	controls::disable_control_action(0, 28, 1);
	controls::disable_control_action(0, 29, 1);
	controls::disable_control_action(0, 171, 1);
	func_150();
	if (controls::_is_input_disabled(2)) {
		if (player::_is_player_cam_control_disabled() || cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			ui::_show_cursor_this_frame();
		}
	}
	Global_36331 = 1;
	if (!uParam0->f_563) {
		switch (func_14(player::get_player_ped(player::get_player_index()))) {
		case 1: graphics::_start_screen_effect("SuccessFranklin", 1000, 0); break;

		case 2: graphics::_start_screen_effect("SuccessTrevor", 1000, 0); break;

		default: graphics::_start_screen_effect("SuccessMichael", 1000, 0); break;
		}
		uParam0->f_563 = 1;
	}
	if (uParam0->f_558 == 0) {
		uParam0->f_558 = uParam0->f_572 + system::floor(15000f * fParam2);
	}
	if (iParam4 && uParam0->f_572 >= uParam0->f_558 - 1500) {
		uParam0->f_558 = uParam0->f_572 + 3000;
	}
	if (uParam0->f_560 == 0f) {
		uParam0->f_560 += func_149(30f);
		uParam0->f_560 += IntToFloat(uParam0->f_56) * func_149(25f);
		if (uParam0->f_56 > 0) {
			uParam0->f_560 += func_149(25f * 0.5f);
		}
		if (uParam0->f_549) {
			uParam0->f_560 += func_149(30f) - func_149(2f);
		}
	}
	iVar0 = 1;
	while (iVar0) {
		func_116(1);
		uParam0->f_572 += system::round(0f + 1000f * system::timestep());
		func_129(uParam0, fParam2, iParam3);
		if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 666) - 15000f * fParam2) {
			if (uParam0->f_30 < 1f) {
				uParam0->f_30 += 0f + 1f / 0.225f * system::timestep();
			}
		}
		uParam0->f_30 = func_128(uParam0->f_30, 0f, 1f);
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_565) {
					uParam0->f_565 = 0;
					uParam0->f_566 = 0;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_547 -= (0f + 1f / 1.215f * system::timestep());
			}
		}
		uParam0->f_547 = func_128(uParam0->f_547, 0f, 1f);
		if (uParam0->f_547 <= 0.7f && !uParam0->f_545 && uParam0->f_1 != 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_OUT");
			graphics::_pop_scaleform_movie_function_void();
			uParam0->f_546 = uParam0->f_572;
			uParam0->f_545 = 1;
		}
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_548 < 1f) {
					uParam0->f_548 += 0f + 1f / 0.3f * system::timestep();
				}
			}
		}
		uParam0->f_548 = func_128(uParam0->f_548, 0f, 1f);
		if (uParam0->f_562) {
			if (controls::_0x6CD79468A1E595C6(2)) {
				if (graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
					if (!uParam0->f_567) {
						func_127(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
					}
				}
			}
		}
		if (controls::is_control_just_pressed(2, 216) && uParam0->f_558 > uParam0->f_572 + 333) {
			if (!uParam0->f_566 && uParam0->f_56 != 0 && graphics::has_scaleform_movie_loaded(uParam0->f_4) &&
				IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (!uParam0->f_565) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					if (uParam0->f_572 > uParam0->f_558 - 5000) {
						uParam0->f_558 = uParam0->f_572 + 5000;
					}
				}
				else if (iParam5) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 0;
					uParam0->f_573 = 0.75f;
				}
				func_127(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
			}
		}
		if ((uParam0->f_565 || uParam0->f_566) && uParam0->f_56 != 0) {
			if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (uParam0->f_566 && !uParam0->f_565) {
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_559 = func_128(uParam0->f_559 + 1f / 0.3f * uParam0->f_573 * system::timestep(), 0f, 1f);
				uParam0->f_573 = func_128(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
			}
		}
		else {
			uParam0->f_559 = func_128(uParam0->f_559 - 1f / 0.3f * uParam0->f_573 * 0.01f * system::timestep(), 0f, 1f);
			uParam0->f_573 = func_128(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
		}
		if (uParam0->f_572 > uParam0->f_558) {
			if (uParam0->f_561) {
				if (!uParam0->f_567) {
					if (controls::is_control_just_pressed(2, 215)) {
						uParam0->f_561 = 0;
					}
				}
			}
			else if (uParam0->f_572 - uParam0->f_546 > 1000 && uParam0->f_545) {
				iVar0 = 0;
			}
		}
		uParam0->f_575 = !iVar0;
		if (iParam1) {
			system::wait(0);
		}
		else {
			if (!iVar0) {
				func_116(0);
			}
			return !iVar0;
		}
	}
	func_116(0);
	return true;
}

// Position - 0x5E8A
void func_127(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_123(controls::get_control_instructional_button(2, 215, 1));
	func_122("ES_HELP");
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_push_scaleform_movie_function_parameter_int(215);
	}
	graphics::_pop_scaleform_movie_function_void();
	if (iParam1) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_123(controls::get_control_instructional_button(2, 216, 1));
		func_122("ES_XPAND");
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_push_scaleform_movie_function_parameter_int(216);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x5F4E
float func_128(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x5F75
void func_129(var *uParam0, float fParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	float fVar18;
	float *fVar19;
	float fVar20;
	float fVar21;
	float fVar22;
	char cVar23[16];
	char cVar27[32];
	int iVar35;
	int iVar36;
	int iVar37;
	int iVar38;
	float fVar39;
	float fVar40;
	float fVar41;
	float fVar42;
	float fVar43;

	iVar0 = system::round(uParam0->f_547 * 255f);
	fVar1 = func_148() * 0.25f;
	if (graphics::has_scaleform_movie_loaded(uParam0->f_1)) {
		if (uParam0->f_30 >= 0f) {
			if (!uParam0->f_2) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "SHOW_MISSION_PASSED_MESSAGE");
				func_122(&uParam0->f_5);
				func_122(&uParam0->f_13);
				if (network::network_is_game_in_progress()) {
					graphics::_push_scaleform_movie_function_parameter_int(150);
				}
				else {
					graphics::_push_scaleform_movie_function_parameter_int(100);
				}
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_56);
				graphics::_push_scaleform_movie_function_parameter_bool(iParam2);
				graphics::_push_scaleform_movie_function_parameter_int(69);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_2 = 1;
			}
			if (uParam0->f_56 > 0 && !uParam0->f_3 && uParam0->f_572 > 600) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(0.15f);
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_3 = 1;
			}
		}
		func_147();
		graphics::draw_scaleform_movie_fullscreen(uParam0->f_1, 255, 255, 255, 255, 0);
	}
	fVar2 = uParam0->f_560 * uParam0->f_559 * (1f - uParam0->f_548);
	fVar3 = 0f;
	if (uParam0->f_567) {
		fVar3 = (0.1388889f + func_149(2f * 2f)) * uParam0->f_568 * (1f - uParam0->f_548);
		fVar2 += 3f * fVar3;
	}
	if (uParam0->f_548 != 0f) {
		fVar4 = 0f;
		if (fVar2 < fVar4) {
			fVar2 = fVar4;
		}
	}
	else {
		fVar5 = 0f;
		if (uParam0->f_30 >= 0.975f) {
			if (fVar2 < fVar5) {
				fVar2 = fVar5;
			}
		}
	}
	fVar1 = 0.3f * func_148();
	if (uParam0->f_12) {
		fVar1 = 0.5f;
	}
	fVar6 = *uParam0 * 2f;
	fVar7 = func_146(&uParam0->f_13);
	if (fVar6 < fVar7) {
		fVar6 = fVar7 + 3f * 0.006f;
	}
	if (graphics::_get_aspect_ratio(0) < 1.4f) {
		fVar6 *= 1.3f;
	}
	fVar7 = func_146(&uParam0->f_550);
	fVar8 = (0.119f + 0.05f) / func_148() / 2.5f;
	if ((uParam0->f_556 == 1 || uParam0->f_556 == 0) && uParam0->f_557 != 0) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (uParam0->f_556 == 3) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (fVar6 < fVar7 + 1.9f * fVar8) {
		fVar6 = fVar7 + 2f * fVar8;
	}
	fVar9 = 0.499f - fVar6 / 2f + 0.006f;
	fVar10 = 0.499f + fVar6 / 2f - 0.006f;
	controls::set_input_exclusive(2, 215);
	controls::set_input_exclusive(2, 216);
	controls::set_input_exclusive(2, 200);
	controls::disable_control_action(2, 200, 1);
	if (uParam0->f_562 || uParam0->f_567) {
		if (IntToFloat(uParam0->f_558) - 14000f * fParam1 < IntToFloat(uParam0->f_572) ||
			uParam0->f_567 && uParam0->f_559 > 0.95f && uParam0->f_558 - 10000 < uParam0->f_572) {
			if (uParam0->f_567) {
				if (uParam0->f_570 < 0) {
					uParam0->f_570 *= -1;
					uParam0->f_570 = uParam0->f_572 + uParam0->f_570;
				}
				if (uParam0->f_570 > 0) {
					if (uParam0->f_570 - uParam0->f_572 > 0) {
						func_143(uParam0->f_570 - uParam0->f_572, "TIMER_TIME", 0, 0, -1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0,
								 0, 0);
					}
					else {
						uParam0->f_570 = 0;
						uParam0->f_569 = 1;
						uParam0->f_567 = 0;
						uParam0->f_561 = 0;
						uParam0->f_562 = 0;
						uParam0->f_558 = uParam0->f_572 + 500;
						uParam0->f_570 = 0;
					}
				}
				if (uParam0->f_568 < 1f) {
					uParam0->f_568 += 0f + 1f / 0.166f * system::timestep();
					if (uParam0->f_568 > 1f) {
						uParam0->f_568 = 1f;
					}
				}
			}
			if (cam::is_screen_faded_out()) {
				ui::hide_loading_on_fade_this_frame();
			}
			if (uParam0->f_4 != 0 && uParam0->f_548 < 0.1f && uParam0->f_572 <= uParam0->f_558) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				graphics::draw_scaleform_movie_fullscreen(uParam0->f_4, 255, 255, 255, iVar0, 0);
			}
			if (uParam0->f_567) {
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				controls::disable_control_action(2, 188, 1);
				if (controls::is_disabled_control_just_pressed(2, 188)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 3;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 187, 1);
				if (controls::is_disabled_control_just_pressed(2, 187)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 4;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 202, 1);
				if (controls::is_disabled_control_just_pressed(2, 202)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 2;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
			else if (uParam0->f_562) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_562 = 0;
					uParam0->f_561 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
		}
	}
	ui::get_hud_colour(1, &iVar13, &iVar14, &iVar15, &iVar16);
	ui::set_text_colour(iVar13, iVar14, iVar15, iVar0);
	ui::set_text_wrap(fVar9, fVar10);
	ui::set_text_justification(0);
	ui::set_text_scale(1f, 0.4f);
	fVar1 -= func_149(6f);
	fVar1 += func_149(30f) - func_149(2f * 2f);
	fVar11 = fVar2 - func_149(2f * 14f);
	if (fVar11 >= 0f) {
		fVar12 = func_128(fVar11 / (0.6f * func_149(25f)), 0f, 1f);
		func_147();
		graphics::draw_rect(0.5f, fVar1 - (func_149(2f - 0.5f) - 0.001388889f), fVar6, func_142(1f), iVar13, iVar14,
							iVar15, system::round(fVar12 * IntToFloat(iVar16)), 0);
	}
	else {
		return;
	}
	fVar1 += func_149(2f * 0.3f);
	if (uParam0->f_56 > 0) {
		fVar1 += func_149(25f * 0.2f);
	}
	iVar17 = 0;
	iVar17 = 0;
	while (iVar17 < uParam0->f_56) {
		fVar11 = fVar2 - (fVar1 - 0.3f * func_148());
		if (fVar11 >= 0f) {
			fVar12 = func_128(fVar11 / (0.8f * func_149(25f)), 0f, 1f);
			func_139(uParam0, iVar17, fVar1 + func_149(2f), fVar9, fVar10, system::round(IntToFloat(iVar0) * fVar12));
		}
		else {
			return;
		}
		fVar1 += func_149(25f);
		iVar17++;
	}
	if (uParam0->f_56 > 0) {
		fVar1 += func_149(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_148());
		if (fVar11 >= 0f) {
			fVar1 += func_149(2f);
			fVar12 = func_128(fVar11 / (0.6f * func_149(25f)), 0f, 1f);
			func_147();
			graphics::draw_rect(0.5f, fVar1 + func_149(2f * 0.5f), fVar6, func_142(1f), iVar13, iVar14, iVar15,
								system::round(fVar12 * IntToFloat(iVar16)), 0);
		}
	}
	if (uParam0->f_549) {
		fVar1 += func_149(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_148());
		if (fVar11 >= 0f) {
			fVar12 = func_128(fVar11 / (0.8f * func_149(25f)), 0f, 1f);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			func_132(7, 0, 1, &fVar18, &fVar19, 0);
			fVar20 = fVar9;
			fVar21 = fVar10;
			if (unk::_get_current_language_id() == 0) {
				fVar20 = fVar9 + 0.119f / func_148() / 2.5f;
				fVar21 = fVar10 - 0.119f / func_148() / 2.5f;
				if (uParam0->f_556 == 1) {
					fVar20 = fVar9 + (0.119f + 0.05f) / func_148() / 2.5f;
					fVar21 = fVar10 - (0.119f + 0.05f) / func_148() / 2.5f;
				}
			}
			if (uParam0->f_557 == 0) {
				fVar20 += (fVar18 * 0.28f + 0.006f) / 2f;
				fVar21 += (fVar18 * 0.28f + 0.006f) / 2f;
			}
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(1);
			ui::set_text_scale(1f, 0.4f);
			func_131(&uParam0->f_550, fVar20, fVar1 + func_149(2f * 2f), 0, 0, 0);
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(2);
			ui::set_text_scale(1f, 0.4f);
			ui::set_text_centre(0);
			func_147();
			fVar22 = fVar21;
			StringCopy(&cVar23, "MPHud", 16);
			StringCopy(&cVar27, "MissionPassedMedal", 32);
			fVar22 -= (fVar18 * 0.28f + 0.006f);
			ui::set_text_wrap(fVar20, fVar22);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			switch (uParam0->f_556) {
			case 0:
				ui::begin_text_command_display_text("PERCENTAGE");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_149(2f * 2f), 0);
				break;

			case 1:
				ui::begin_text_command_display_text("FO_TWO_NUM");
				ui::add_text_component_integer(uParam0->f_554);
				ui::add_text_component_integer(uParam0->f_555);
				ui::end_text_command_display_text(fVar20, fVar1 + func_149(2f * 2f), 0);
				break;

			case 2:
				ui::begin_text_command_display_text("MTPHPER_XPNO");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_149(2f * 2f), 0);
				break;

			case 3:
				ui::begin_text_command_display_text("ESDOLLA");
				ui::add_text_component_formatted_integer(uParam0->f_554, 1);
				ui::end_text_command_display_text(fVar20, fVar1 + func_149(2f * 2f), 0);
				break;
			}
			if (uParam0->f_557 != 0) {
				iVar35 = 255;
				iVar36 = 255;
				iVar37 = 255;
				iVar38 = iVar0;
				switch (uParam0->f_557) {
				case 1: ui::get_hud_colour(107, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 3: ui::get_hud_colour(109, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 2: ui::get_hud_colour(108, &iVar35, &iVar36, &iVar37, &iVar38); break;
				}
				fVar39 = 0.001388889f * 5f;
				fVar40 = 0.00078125f * 16f * 2f;
				fVar41 = 0.001388889f * 16f * 2f;
				fVar42 = fVar21 + func_130(4f) - 0.006f;
				fVar43 = fVar1 + func_149(10f) + fVar39;
				if (uParam0->f_556 == -1) {
					fVar42 -= 0.006f * 6f;
				}
				fVar40 *= 0.65f;
				fVar41 *= 0.65f;
				graphics::draw_sprite(&cVar23, &cVar27, fVar42, fVar43, fVar40, fVar41, 0f, iVar35, iVar36, iVar37,
									  system::round(fVar12 * IntToFloat(iVar0)), 0);
			}
			fVar1 += func_149(30f) - 2f;
		}
	}
}

// Position - 0x6AC7
float func_130(float fParam0) { return fParam0 * 0.00078125f; }

// Position - 0x6AD7
void func_131(char *sParam0, float fParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	ui::set_text_centre(iParam3);
	ui::set_text_font(iParam5);
	func_147();
	if (iParam4) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam0);
	}
	else {
		ui::begin_text_command_display_text(sParam0);
	}
	ui::end_text_command_display_text(fParam1, fParam2, 0);
}

// Position - 0x6B14
int func_132(int iParam0, int iParam1, int iParam2, float fParam3, float *fParam4, int iParam5) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	float fVar36;
	vector3 vVar37;

	StringCopy(&cVar0, func_138(iParam0), 64);
	StringCopy(&cVar16, func_135(iParam0, iParam1), 64);
	if (gameplay::get_hash_key(&cVar16) != 0) {
		fVar34 = 1f;
		if (iParam5) {
			graphics::_get_active_screen_resolution(&iVar32, &iVar33);
			fVar35 = graphics::_get_aspect_ratio(0);
			if (func_134()) {
				iVar32 = system::round(system::to_float(iVar33) * fVar35);
			}
			fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
			fVar34 = fVar36 / fVar35;
			if (func_134()) {
				fVar34 = 1f;
			}
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
				graphics::get_screen_resolution(&iVar32, &iVar33);
			}
			iVar32 = system::round(system::to_float(iVar32) / fVar34);
			iVar33 = system::round(system::to_float(iVar33) / fVar34);
		}
		else {
			graphics::get_screen_resolution(&iVar32, &iVar33);
		}
		vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
		vVar37.x *= func_133(iParam0) / fVar34;
		vVar37.y *= func_133(iParam0) / fVar34;
		if (!iParam2) {
			vVar37.x -= 2f;
			vVar37.y -= 2f;
		}
		if (iParam0 == 30) {
			vVar37.x = 288f;
			vVar37.y = 106f;
		}
		if (iParam0 == 29 && gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
			vVar37.x = 106f;
			vVar37.y = 106f;
		}
		*fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
		*fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) * *fParam3;
		if (!iParam5) {
			if (!graphics::get_is_widescreen() && iParam0 != 30) {
				*fParam3 *= 1.33f;
			}
		}
		if (iParam0 == 29) {
			if (*fParam3 > Global_17289) {
				*fParam4 *= Global_17289 / *fParam3;
				*fParam3 = Global_17289;
			}
		}
		return 1;
	}
	return 0;
}

// Position - 0x6CC5
float func_133(int iParam0) {
	switch (iParam0) {
	case 33:
	case 4:
	case 11:
	case 31:
	case 20:
	case 15:
	case 10:
	case 12:
	case 13:
	case 32:
	case 9:
	case 5:
	case 6:
	case 7:
	case 14:
	case 18:
	case 19:
	case 17:
	case 28:
	case 26:
	case 27:
	case 49: return 0.5f;
	}
	return 1f;
}

// Position - 0x6D64
bool func_134() {
	int iVar0;
	int iVar1;
	float fVar2;

	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (fVar2 > 3.5f) {
		return true;
	}
	return false;
}

// Position - 0x6D96
var func_135(int iParam0, int iParam1) {
	char *sVar0[2];
	var uVar3;
	struct<13> Var19;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_6703[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) == -1487683087) {
			Var19 = {func_137(player::player_id())};
			if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
				return func_136(&uVar3);
			}
		}
		else {
			return func_136(&Global_17290.f_6703[iParam0 /*16*/]);
		}
	}
	switch (iParam0) {
	case 3:
		sVar0[0] = "MP_hostCrown";
		sVar0[1] = "MP_hostCrown";
		break;

	case 21:
		sVar0[0] = "MP_SpecItem_Coke";
		sVar0[1] = "MP_SpecItem_Coke";
		break;

	case 22:
		sVar0[0] = "MP_SpecItem_Heroin";
		sVar0[1] = "MP_SpecItem_Heroin";
		break;

	case 23:
		sVar0[0] = "MP_SpecItem_Weed";
		sVar0[1] = "MP_SpecItem_Weed";
		break;

	case 24:
		sVar0[0] = "MP_SpecItem_Meth";
		sVar0[1] = "MP_SpecItem_Meth";
		break;

	case 25:
		sVar0[0] = "MP_SpecItem_Cash";
		sVar0[1] = "MP_SpecItem_Cash";
		break;

	case 1:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 2:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 4:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 6:
		sVar0[0] = "Shop_Box_CrossB";
		sVar0[1] = "Shop_Box_Cross";
		break;

	case 7:
		sVar0[0] = "Shop_Box_BlankB";
		sVar0[1] = "Shop_Box_Blank";
		break;

	case 5:
		sVar0[0] = "Shop_Box_TickB";
		sVar0[1] = "Shop_Box_Tick";
		break;

	case 8:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 9:
		sVar0[0] = "Shop_Clothing_Icon_B";
		sVar0[1] = "Shop_Clothing_Icon_A";
		break;

	case 10:
		sVar0[0] = "Shop_GunClub_Icon_B";
		sVar0[1] = "Shop_GunClub_Icon_A";
		break;

	case 17:
		sVar0[0] = "Shop_Ammo_Icon_B";
		sVar0[1] = "Shop_Ammo_Icon_A";
		break;

	case 18:
		sVar0[0] = "Shop_Armour_Icon_B";
		sVar0[1] = "Shop_Armour_Icon_A";
		break;

	case 19:
		sVar0[0] = "Shop_Health_Icon_B";
		sVar0[1] = "Shop_Health_Icon_A";
		break;

	case 20:
		sVar0[0] = "Shop_MakeUp_Icon_B";
		sVar0[1] = "Shop_MakeUp_Icon_A";
		break;

	case 11:
		sVar0[0] = "Shop_Tattoos_Icon_B";
		sVar0[1] = "Shop_Tattoos_Icon_A";
		break;

	case 12:
		sVar0[0] = "Shop_Garage_Icon_B";
		sVar0[1] = "Shop_Garage_Icon_A";
		break;

	case 13:
		sVar0[0] = "Shop_Garage_Bike_Icon_B";
		sVar0[1] = "Shop_Garage_Bike_Icon_A";
		break;

	case 14:
		sVar0[0] = "Shop_Barber_Icon_B";
		sVar0[1] = "Shop_Barber_Icon_A";
		break;

	case 15:
		sVar0[0] = "shop_Lock";
		sVar0[1] = "shop_Lock";
		break;

	case 16:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 26:
		sVar0[0] = "arrowleft";
		sVar0[1] = "arrowleft";
		break;

	case 27:
		sVar0[0] = "arrowright";
		sVar0[1] = "arrowright";
		break;

	case 28:
		sVar0[0] = "MP_AlertTriangle";
		sVar0[1] = "MP_AlertTriangle";
		break;

	case 29:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 31:
		sVar0[0] = "Shop_Michael_Icon_B";
		sVar0[1] = "Shop_Michael_Icon_A";
		break;

	case 32:
		sVar0[0] = "Shop_Franklin_Icon_B";
		sVar0[1] = "Shop_Franklin_Icon_A";
		break;

	case 33:
		sVar0[0] = "Shop_Trevor_Icon_B";
		sVar0[1] = "Shop_Trevor_Icon_A";
		break;

	case 48:
		sVar0[0] = "SaleIcon";
		sVar0[1] = "SaleIcon";
		break;

	case 49:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 0:
		sVar0[0] = "";
		sVar0[1] = "";
		break;
	}
	if (iParam1) {
		return sVar0[0];
	}
	return sVar0[1];
}

// Position - 0x71CB
var func_136(var uParam0) { return uParam0; }

// Position - 0x71D5
struct<13> func_137(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

// Position - 0x71EC
char *
func_138(int iParam0) {
	var uVar0;
	struct<13> Var16;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5886[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) == -1487683087) {
			Var16 = {func_137(player::player_id())};
			network::_0x5835D9CD92E83184(&Var16, &uVar0);
			return func_136(&uVar0);
		}
		else {
			return func_136(&Global_17290.f_5886[iParam0 /*16*/]);
		}
	}
	if (iParam0 == 48) {
		return "MPShopSale";
	}
	return "CommonMenu";
}

// Position - 0x7261
void func_139(var *uParam0, int iParam1, float fParam2, float fParam3, float fParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uVar3);
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	ui::set_text_wrap(fParam3, fParam4);
	ui::set_text_justification(1);
	ui::set_text_scale(1f, func_141(14f));
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_147();
	if (uParam0->f_531[iParam1]) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(&uParam0->f_71[iParam1 /*16*/]);
	}
	else {
		ui::begin_text_command_display_text(&uParam0->f_71[iParam1 /*16*/]);
		if (uParam0->f_57[iParam1] == 16 || uParam0->f_57[iParam1] == 17) {
			ui::add_text_component_integer(uParam0->f_489[iParam1]);
		}
	}
	ui::end_text_command_display_text(fParam3, fParam2, 0);
	fVar4 = fParam4;
	switch (uParam0->f_517[iParam1]) {
	case 0: break;

	case 1:
		func_132(7, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_135(7, 0), fParam4 - 0.006f, fParam2 + func_149(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 2:
		func_132(5, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_135(5, 0), fParam4 - 0.006f, fParam2 + func_149(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 3:
		func_132(6, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_135(6, 0), fParam4 - 0.006f, fParam2 + func_149(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;
	}
	if (uParam0->f_57[iParam1] == 0) {
		return;
	}
	if (uParam0->f_57[iParam1] == 15) {
		ui::set_text_justification(1);
	}
	else {
		ui::set_text_justification(2);
	}
	ui::set_text_scale(1f, func_141(14f));
	if (uParam0->f_57[iParam1] == 5 || uParam0->f_57[iParam1] == 4) {
		ui::set_text_wrap(fParam3, fVar4 - 0.00078125f * 3f);
	}
	else {
		ui::set_text_wrap(fParam3, fVar4 + 0.00078125f * 2f);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	func_140(uParam0->f_489[iParam1], uParam0->f_503[iParam1], fParam4, fParam2, &uParam0->f_280[iParam1 /*16*/],
			 uParam0->f_57[iParam1]);
}

// Position - 0x74EC
void func_140(int iParam0, int iParam1, float fParam2, float fParam3, char *sParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = 1;
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_147();
	fVar1 = 0f;
	fVar2 = 8f * 0.00078125f;
	fVar3 = 16f * 0.001388889f;
	iVar4 = 93;
	iVar5 = 182;
	iVar6 = 229;
	if (iParam5 == 4) {
		iVar4 = 194;
		iVar5 = 80;
		iVar6 = 80;
	}
	switch (iParam5) {
	case 4:
	case 5:
		ui::set_text_scale(1f, func_141(18f));
		ui::set_text_font(4);
		if (iParam0 < 0) {
			ui::_begin_text_command_width("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		else {
			ui::_begin_text_command_width("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		fVar1 -= fVar1 % 0.00078125f;
		graphics::draw_sprite("CommonMenu", "BettingBox_Left", fParam2 - fVar1,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Centre", fParam2 - fVar1 * 0.5f - 0.00078125f * 2f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar1 - fVar2 * 0.5f, fVar3, 0f, iVar4, iVar5,
							  iVar6, 255, 0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Right", fParam2 - 0.00078125f * 4f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		ui::set_text_scale(1f, func_141(14f));
		break;
	}
	ui::_set_notification_color_next(iVar0);
	switch (iParam5) {
	case 11:
		ui::begin_text_command_display_text("PERCENTAGE");
		ui::add_text_component_integer(iParam0);
		break;

	case 1:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_NUM");
		ui::add_text_component_integer(iParam0);
		break;

	case 2:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_TWO_NUM");
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 4:
	case 5: ui::set_text_scale(1f, func_141(18f));

	case 3:
		if (iParam0 < 0) {
			ui::begin_text_command_display_text("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
		}
		else {
			ui::begin_text_command_display_text("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
		}
		break;

	case 6: ui::begin_text_command_display_text(sParam4); break;

	case 7:
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam4);
		break;

	case 8:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 14);
		break;

	case 9:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 6);
		break;

	case 10:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 18:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 12:
		ui::begin_text_command_display_text("AHD_DIST");
		ui::add_text_component_integer(iParam0);
		break;

	case 13:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 15:
	case 14:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 16:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam1);
		break;
	}
	if (iParam5 != 17) {
		if (iParam5 == 4 || iParam5 == 5) {
			ui::end_text_command_display_text(fParam2 - 0.00078125f * 4f, fParam3, 0);
			ui::set_text_scale(1f, func_141(14f));
		}
		else {
			ui::end_text_command_display_text(fParam2, fParam3, 0);
		}
	}
}

// Position - 0x7865
float func_141(float fParam0) { return fParam0 * 0.025f; }

// Position - 0x7875
float func_142(float fParam0) { return fParam0 * 0.0009259259f; }

// Position - 0x7885
void func_143(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			  int iParam15, int iParam16) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_145(7, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_144(7, iVar0);
		Global_1354542.f_4282[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_4282.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_4282.f_172[iVar0] = iParam2;
		Global_1354542.f_4282.f_216[iVar0] = iParam3;
		Global_1354542.f_4282.f_183[iVar0] = iParam4;
		Global_1354542.f_4282.f_194[iVar0] = iParam5;
		Global_1354542.f_4282.f_249[iVar0] = iParam6;
		Global_1354542.f_4282.f_260[iVar0] = iParam7;
		Global_1354542.f_4282.f_205[iVar0] = iParam8;
		Global_1354542.f_4282.f_314[iVar0] = iParam9;
		Global_1354542.f_4282.f_325[iVar0] = iParam10;
		Global_1354542.f_4282.f_357[iVar0] = iParam11;
		Global_1354542.f_4282.f_238[iVar0] = iParam12;
		Global_1354542.f_4282.f_271[iVar0] = iParam13;
		Global_1354542.f_4282.f_368[iVar0] = iParam14;
		Global_1354542.f_4282.f_379[iVar0] = iParam15;
		Global_1354542.f_4282.f_390[iVar0] = iParam16;
	}
}

// Position - 0x79D3
void func_144(int iParam0, int iParam1) { gameplay::set_bit(&Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x79EC
int func_145(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x7A05
float func_146(char *sParam0) {
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1) / 2f;
}

// Position - 0x7A1A
void func_147() {
	graphics::_set_2d_layer(1);
	if (cam::is_screen_fading_out() || cam::is_screen_faded_out()) {
		graphics::_set_2d_layer(7);
	}
	graphics::_0xC6372ECD45D73BCD(0);
}

// Position - 0x7A42
float func_148() {
	float fVar0;

	fVar0 = 1f;
	if (gameplay::is_pc_version()) {
	}
	return fVar0;
}

// Position - 0x7A56
float func_149(float fParam0) { return fParam0 * 0.001388889f; }

// Position - 0x7A66
void func_150() {
	if (Global_14443.f_1 != 1) {
		if (func_153(0)) {
			func_151(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x7A8E
void func_151(int iParam0) {
	if (Global_14604) {
		func_152(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_49()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x7AFE
void func_152(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_153(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x7B72
bool func_153(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x7BCC
int func_154(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;

	if (*uParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	if (iParam5 == 1) {
		iVar0 = 1;
	}
	iVar1 = uParam0->f_123;
	if (iVar1 < 8) {
		uParam0->f_2[iVar1 /*15*/] = sParam1;
		uParam0->f_2[iVar1 /*15*/].f_1 = iVar0;
		uParam0->f_2[iVar1 /*15*/].f_2 = iParam6;
		uParam0->f_2[iVar1 /*15*/].f_12 = 0;
		uParam0->f_2[iVar1 /*15*/].f_13 = 0;
		uParam0->f_2[iVar1 /*15*/].f_14 = 0;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/] = iParam2;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
		if (iParam4 == 1) {
			gameplay::set_bit(&uParam0->f_2[iVar1 /*15*/].f_13, 0);
		}
		uParam0->f_2[iVar1 /*15*/].f_14++;
		uParam0->f_123++;
		return 1;
	}
	return 0;
}

// Position - 0x7C95
void func_155(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (*uParam0 == 0) {
		*uParam0 = graphics::request_scaleform_movie_instance("instructional_buttons");
	}
	uParam0->f_1 = 0;
	uParam0->f_123 = 0;
	if (iParam1) {
		func_120(&uParam0->f_1, 32);
	}
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		func_120(&uParam0->f_1, 1);
		if (iParam2) {
			graphics::set_scaleform_movie_to_use_system_time(*uParam0, 1);
		}
	}
	if (gameplay::is_pc_version()) {
		if (iParam3) {
			func_120(&uParam0->f_1, 4096);
		}
	}
	if (iParam4) {
		func_120(&uParam0->f_1, 8192);
	}
}

// Position - 0x7D0F
int func_156(var *uParam0, int iParam1, int iParam2) {
	uParam0->f_12 = iParam2;
	func_159(uParam0);
	func_158(uParam0);
	if (gameplay::are_strings_equal(&uParam0->f_550, "SPR_RESULT") ||
		gameplay::are_strings_equal(&uParam0->f_550, "") && uParam0->f_56 > 0) {
		uParam0->f_566 = 1;
	}
	if (network::network_is_game_in_progress()) {
		graphics::request_streamed_texture_dict("MPHud", 0);
	}
	if (uParam0->f_1 == 0) {
		graphics::request_streamed_texture_dict("CommonMenu", 0);
		graphics::request_streamed_texture_dict("MPLeaderboard", 0);
		graphics::request_streamed_texture_dict("MPHud", 0);
		uParam0->f_1 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
		uParam0->f_2 = 0;
		uParam0->f_3 = 0;
	}
	uParam0->f_4 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	if (iParam1) {
		while (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			   !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			   !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			   !graphics::has_streamed_texture_dict_loaded("MPHud")) {
			system::wait(0);
		}
		if (uParam0->f_562 || uParam0->f_567) {
			while (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				system::wait(0);
			}
		}
	}
	else {
		if (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			!graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			!graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			!graphics::has_streamed_texture_dict_loaded("MPHud")) {
			return 0;
		}
		if (uParam0->f_562) {
			if (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				return 0;
			}
		}
	}
	if (uParam0->f_562) {
		if (uParam0->f_567) {
			func_157(uParam0);
		}
		else if (uParam0->f_56 != 0) {
			func_127(uParam0, 1);
		}
		else {
			func_127(uParam0, 0);
		}
	}
	Global_69963 = 1;
	return 1;
}

// Position - 0x7EAE
void func_157(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(2);
	func_123(controls::get_control_instructional_button(2, 188, 1));
	func_122("ES_HELP_TU");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(1);
	func_123(controls::get_control_instructional_button(2, 187, 1));
	func_122("ES_HELP_TD");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_123(controls::get_control_instructional_button(2, 202, 1));
	func_122("ES_HELP_AB");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x7F73
void func_158(float *fParam0) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	fVar0 = 0f;
	ui::set_text_justification(0);
	ui::set_text_scale(1f, func_141(16f));
	if (fParam0->f_31 == 0) {
		if (fParam0->f_29) {
			ui::_begin_text_command_width("STRING");
			ui::add_text_component_substring_player_name(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
		else {
			ui::_begin_text_command_width(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
	}
	else {
		ui::_begin_text_command_width("STRING");
		iVar1 = 0;
		iVar2 = 0;
		iVar3 = 0;
		iVar3 = 0;
		while (iVar3 < fParam0->f_31) {
			switch (fParam0->f_32[iVar3]) {
			case 0:
				ui::add_text_component_integer(fParam0->f_53[iVar1]);
				iVar1++;
				break;

			case 1:
				ui::add_text_component_substring_text_label(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;

			case 2:
				ui::add_text_component_substring_player_name(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;
			}
			iVar3++;
		}
		fVar0 = ui::_end_text_command_get_width(1);
	}
	if (fVar0 > 0.1125f * 2f - 0.006f * 2f) {
		*fParam0 = fVar0 / 2f + 0.006f * 2f;
	}
}

// Position - 0x808D
void func_159(var *uParam0) {
	uParam0->f_547 = 1f;
	uParam0->f_546 = 0;
	uParam0->f_568 = 0f;
	uParam0->f_558 = 0;
	uParam0->f_30 = 0f;
	uParam0->f_548 = 0f;
	uParam0->f_559 = 0f;
	uParam0->f_560 = 0f;
	uParam0->f_545 = 0;
	uParam0->f_563 = 0;
	uParam0->f_572 = 0;
	uParam0->f_564 = 0;
	uParam0->f_565 = 0;
	uParam0->f_566 = 0;
	*uParam0 = 0.1125f;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_574 = 0;
	uParam0->f_575 = 0;
	uParam0->f_573 = 1f;
}

// Position - 0x810C
void func_160() {
	int iVar0;
	int iVar1;

	if (!iLocal_139) {
		func_166(&uLocal_150, &Local_726, &Global_55837, 0);
		fLocal_134 *= 1000f;
		if (Global_86001) {
			func_165(&uLocal_150, 6, &Local_726.f_12, "MTPHPERSKI", system::floor(fLocal_134), 0, 3, 0);
			func_165(&uLocal_150, 6, &Local_726.f_24, "MTPHPERSKI", 0, 0, 3, 0);
			func_165(&uLocal_150, 6, &Local_726.f_30, "MTPHPERSKI", system::round(fLocal_136 + fLocal_135), 0, 3, 0);
			func_164();
		}
		else {
			if (bLocal_138) {
				func_165(&uLocal_150, 6, &Local_726.f_12, "MTPHPERRET", system::floor(fLocal_134), 0, 3, 0);
			}
			else {
				func_165(&uLocal_150, 9, &Local_726.f_12, "", system::floor(fLocal_134), 0, 0, 0);
			}
			if (!gameplay::is_string_null_or_empty(&Local_726.f_18)) {
				if (bLocal_137) {
					func_165(&uLocal_150, 6, &Local_726.f_24, "", 0, 0, 2, 0);
					func_165(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_136 + fLocal_135), 0, 2, 0);
				}
				else {
					func_165(&uLocal_150, 6, &Local_726.f_24, "", 0, 0, 1, 0);
					func_165(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_135), 0, 0, 0);
				}
			}
			else {
				func_165(&uLocal_150, 3, &Local_726.f_30, "", system::round(fLocal_135), 0, 0, 0);
			}
		}
		iVar0 = 0;
		if (Global_86001) {
			iVar1 = 0;
			while (iVar1 < Global_67917) {
				if (Global_67918[iVar1 /*9*/] >= 0 && !MissionObjectives[Global_67918[iVar1 /*9*/] /*13*/].f_7) {
					if (Global_67918[iVar1 /*9*/].f_3 == 2) {
						iVar0 = 1;
					}
				}
				iVar1++;
			}
		}
		if (iVar0 == 1) {
			iLocal_145 = 50;
			iLocal_146 = 1;
			func_163(&uLocal_150, 1, &Local_726.f_48, iLocal_145, 0, 0, 1);
		}
		else if (bLocal_137) {
			if (bLocal_138) {
				iLocal_145 = 75;
				iLocal_146 = 2;
				func_163(&uLocal_150, 1, &Local_726.f_42, iLocal_145, 0, 0, 2);
			}
			else {
				iLocal_145 = 100;
				iLocal_146 = 3;
				func_163(&uLocal_150, 1, &Local_726.f_36, iLocal_145, 0, 0, 3);
			}
		}
		else if (!bLocal_137 && !bLocal_138) {
			iLocal_145 = 75;
			iLocal_146 = 2;
			func_163(&uLocal_150, 1, &Local_726.f_42, iLocal_145, 0, 0, 2);
		}
		else {
			iLocal_145 = 50;
			iLocal_146 = 1;
			func_163(&uLocal_150, 1, &Local_726.f_48, iLocal_145, 0, 0, 1);
		}
		func_161();
		iLocal_139 = 1;
	}
}

// Position - 0x8346
void func_161() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_valet")) == 1) {
		func_162(38, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_162(39, 1, 1);
		}
		else {
			func_162(39, 0, 1);
		}
		if (bLocal_137) {
			func_162(40, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_162(40, system::round(fLocal_135), 1);
		}
		func_162(41, iLocal_145, 1);
		func_162(42, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_multi")) == 1) {
		func_162(52, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_162(53, 1, 1);
		}
		else {
			func_162(53, 0, 1);
		}
		if (bLocal_137) {
			func_162(56, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_162(56, system::round(fLocal_135), 1);
		}
		func_162(54, iLocal_145, 1);
		func_162(55, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_hooker")) == 1) {
		func_162(66, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_162(67, 1, 1);
		}
		else {
			func_162(67, 0, 1);
		}
		if (bLocal_137) {
			func_162(68, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_162(68, system::round(fLocal_135), 1);
		}
		func_162(69, iLocal_145, 1);
		func_162(70, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_bus")) == 1) {
		func_162(81, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_162(82, 1, 1);
		}
		else {
			func_162(82, 0, 1);
		}
		if (bLocal_137) {
			func_162(83, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_162(83, system::round(fLocal_135), 1);
		}
		func_162(84, iLocal_145, 1);
		func_162(85, iLocal_146, 1);
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_construction")) == 1) {
		func_162(97, system::floor(fLocal_134), 1);
		if (bLocal_137) {
			func_162(98, 1, 1);
		}
		else {
			func_162(98, 0, 1);
		}
		if (bLocal_137) {
			func_162(99, system::round(fLocal_136 + fLocal_135), 1);
		}
		else {
			func_162(99, system::round(fLocal_135), 1);
		}
		func_162(100, iLocal_145, 1);
		func_162(101, iLocal_146, 1);
	}
}

// Position - 0x856A
void func_162(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_67917) {
		if (Global_67918[iVar0 /*9*/] == iParam0) {
			if (iParam2) {
				Global_67918[iVar0 /*9*/].f_1 = iParam1;
			}
			else {
				Global_67918[iVar0 /*9*/].f_1 += iParam1;
			}
			return;
		}
		iVar0++;
	}
	if (Global_67918[iVar0 /*9*/] != -1) {
		if (MissionObjectives[Global_67918[iVar0 /*9*/] /*13*/] == 3) {
			if (Global_67918[iVar0 /*9*/].f_1 > 1) {
				Global_67918[iVar0 /*9*/].f_1 = 1;
			}
			if (Global_67918[iVar0 /*9*/].f_1 < 0) {
				Global_67918[iVar0 /*9*/].f_1 = 0;
			}
		}
	}
}

// Position - 0x8614
void func_163(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	uParam0->f_549 = iParam1;
	StringCopy(&uParam0->f_550, sParam2, 16);
	uParam0->f_554 = iParam3;
	uParam0->f_555 = iParam4;
	uParam0->f_556 = iParam5;
	uParam0->f_557 = iParam6;
}

// Position - 0x8648
void func_164() {
	Global_86000 = 0;
	Global_86001 = 0;
}

// Position - 0x865A
void func_165(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	int iVar0;

	if (uParam0->f_56 == 13) {
		return;
	}
	iVar0 = uParam0->f_56;
	uParam0->f_57[iVar0] = iParam1;
	StringCopy(&uParam0->f_71[iVar0 /*16*/], sParam2, 64);
	StringCopy(&uParam0->f_280[iVar0 /*16*/], sParam3, 64);
	uParam0->f_489[iVar0] = iParam4;
	uParam0->f_503[iVar0] = iParam5;
	uParam0->f_517[iVar0] = iParam6;
	uParam0->f_531[iVar0] = iParam7;
	uParam0->f_56++;
}

// Position - 0x86CD
void func_166(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	StringCopy(&uParam0->f_5, sParam1, 16);
	StringCopy(&uParam0->f_13, sParam2, 64);
	uParam0->f_29 = iParam3;
	uParam0->f_11 = 0;
}

// Position - 0x86F0
void func_167() { func_448(&Global_101700.f_18922.f_1, 4194304); }

// Position - 0x8709
void func_168() {
	func_208(&iLocal_1063, &uLocal_2005, "OJASAUD", "OJAS_COCOM", 9, 1, 0, 0);
	if (!iLocal_1753) {
		if (!func_207("ASS_CS_PARA", 0, 0)) {
			if (!func_62()) {
				if (func_70()) {
					func_32("ASS_CS_PARA", 7500, 1);
					if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP")) {
						audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP");
					}
					if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE")) {
						audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE");
					}
					if (!audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA")) {
						audio::start_audio_scene("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA");
					}
				}
				func_30(&uLocal_2000);
				iLocal_1753 = 1;
			}
		}
	}
	else if (!iLocal_1754 && iLocal_1760 == 0) {
		if (func_26(&uLocal_2000) > 7f && !ui::is_message_being_displayed() && !ui::is_help_message_being_displayed()) {
			func_206("ASS_CS_REMIND", -1);
			iLocal_1754 = 1;
		}
	}
	func_208(&iLocal_1063, &uLocal_2005, "OJASAUD", "OJAS_COCOM", 9, 1, 0, 0);
	switch (iLocal_1760) {
	case 0:
		if (ped::get_ped_parachute_state(iLocal_1801) != -1) {
			if (!iLocal_1755 && !audio::is_scripted_conversation_ongoing()) {
				if (func_58(&uLocal_2005, "OJASAUD", "OJAS_JUMP", 9, 0, 0, 0)) {
					iLocal_1755 = 1;
				}
			}
			if (ped::get_ped_parachute_state(iLocal_1801) == 1 || ped::get_ped_parachute_state(iLocal_1801) == 2) {
				ui::clear_help(1);
				audio::trigger_music_event("ASS5_STOP");
				if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP")) {
					audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP");
				}
				if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE")) {
					audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE");
				}
				if (!audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA")) {
					audio::start_audio_scene("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA");
				}
				iLocal_1760++;
			}
			else if (ped::get_ped_parachute_state(iLocal_1801) == 0) {
				if (ui::does_blip_exist(iLocal_1710)) {
					ui::remove_blip(&iLocal_1710);
				}
				func_206("ASS_CS_PARA2", -1);
			}
		}
		else {
			if (func_204(-158.3f, -940.8f, 269.2f)) {
				func_203();
				if (controls::is_control_just_pressed(0, 51) || controls::is_control_just_pressed(2, 51)) {
					if (func_202("ASS_CS_ELEHELP")) {
						func_201(&iLocal_1765);
						audio::trigger_music_event("ASS5_STOP");
						decisionevent::remove_all_shocking_events(0);
						iLocal_1760++;
						iLocal_1738 = 1;
					}
				}
			}
			else if (func_202("ASS_CS_ELEHELP")) {
				ui::clear_help(1);
			}
			if (!func_70() && !ped::is_ped_ragdoll(iLocal_1801)) {
				iLocal_1760 = 3;
			}
		}
		break;

	case 1:
		if (!iLocal_1738) {
			if (ped::get_ped_parachute_state(iLocal_1801) == 3) {
				system::settimera(0);
				decisionevent::remove_all_shocking_events(0);
				iLocal_1760++;
			}
			else if (!weapon::has_ped_got_weapon(iLocal_1801, joaat("gadget_parachute"), 0)) {
				if (!ped::is_ped_injured(iLocal_1801)) {
					system::settimera(0);
					decisionevent::remove_all_shocking_events(0);
					iLocal_1760++;
				}
			}
		}
		else if (iLocal_1739) {
			if (entity::does_entity_exist(iLocal_1971)) {
				if (vehicle::is_vehicle_driveable(iLocal_1971, 0)) {
					vehicle::set_vehicle_on_ground_properly(iLocal_1971, 1084227584);
				}
			}
			iLocal_1760++;
		}
		else {
			func_176();
		}
		break;

	case 2:
		if (ped::get_ped_parachute_state(iLocal_1801) == -1 && !entity::is_entity_in_air(iLocal_1801)) {
			if (!ped::is_ped_injured(iLocal_1801)) {
				if (func_70()) {
					func_32("ASS_CS_PARA", 7500, 1);
					iLocal_1760++;
				}
				else {
					iLocal_1760++;
				}
			}
		}
		break;

	case 3:
		if (!func_70()) {
			if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA")) {
				audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA");
			}
			if (func_173()) {
				func_40();
				iLocal_1030 = 16;
			}
		}
		break;
	}
	func_169();
}

// Position - 0x8A86
void func_169() {
	vector3 vVar0;

	if (!iLocal_1717) {
		vVar0 = {entity::get_entity_coords(iLocal_1801, 1)};
		if (vVar0.z <= 200f) {
			func_170(1);
			iLocal_1717 = 1;
		}
	}
}

// Position - 0x8AB7
void func_170(int iParam0) {
	func_171(&Local_1202, 5);
	func_171(&Local_1298, 3);
	func_171(&Local_1356, 6);
	func_171(&Local_1471, 2);
	func_171(&Local_1510, 4);
	if (iParam0) {
		if (entity::does_entity_exist(iLocal_1802)) {
			if (!ped::is_ped_injured(iLocal_1802)) {
				if (ped::is_ped_in_any_heli(iLocal_1802)) {
					ped::set_ped_combat_attributes(iLocal_1802, 3, 0);
					ped::set_ped_flee_attributes(iLocal_1802, 2, 0);
					ped::set_ped_keep_task(iLocal_1802, 1);
				}
			}
			entity::set_ped_as_no_longer_needed(&iLocal_1802);
		}
		if (ui::does_blip_exist(iLocal_1707)) {
			ui::remove_blip(&iLocal_1707);
		}
	}
}

// Position - 0x8B3D
void func_171(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= iParam1 - 1) {
		if (entity::does_entity_exist((*uParam0)[iVar0 /*19*/])) {
			if (!ped::is_ped_injured((*uParam0)[iVar0 /*19*/])) {
				if (entity::is_entity_occluded((*uParam0)[iVar0 /*19*/]) ||
					!entity::is_entity_on_screen((*uParam0)[iVar0 /*19*/])) {
					if (!ped::is_ped_injured((*uParam0)[iVar0 /*19*/])) {
						entity::set_entity_health((*uParam0)[iVar0 /*19*/], 0);
					}
				}
				else {
					entity::set_ped_as_no_longer_needed(&(*uParam0)[iVar0 /*19*/]);
				}
			}
		}
		iVar0++;
	}
	func_172(&uLocal_2005, 4);
	func_172(&uLocal_2005, 5);
	func_172(&uLocal_2005, 6);
	func_172(&uLocal_2005, 7);
	func_172(&uLocal_2005, 8);
}

// Position - 0x8BE2
void func_172(var *uParam0, int iParam1) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
		(*uParam0)[iParam1 /*10*/].f_7 = 0;
	}
}

// Position - 0x8BFF
bool func_173() {
	if (!iLocal_1752) {
		func_363(&uLocal_2005, 3, 0, "LESTER", 0, 1);
		if (func_175(&uLocal_2005, 12, "OJASAUD", "OJAS_CONST_C", 14, 1, 0, 0, 0)) {
			iLocal_1752 = 1;
		}
	}
	if (iLocal_1752 && func_174()) {
		return true;
	}
	return false;
}

// Position - 0x8C50
int func_174() {
	if (Global_15745 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x8C67
bool func_175(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8) {
	func_55(uParam0, iParam1, sParam2, iParam6, iParam7, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	if (iParam5 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_2621441 = 0;
	return func_46(sParam3, iParam4, iParam8);
}

// Position - 0x8CC6
void func_176() {
	vector3 vVar0;

	switch (iLocal_1769) {
	case 0:
		func_201(&iLocal_1765);
		func_200(256, 0, 1);
		func_199();
		func_198(&Local_1202, 5);
		func_198(&Local_1298, 3);
		func_198(&Local_1356, 6);
		func_198(&Local_1471, 2);
		func_198(&Local_1510, 4);
		func_198(&Local_1587, 3);
		func_197();
		ui::clear_prints();
		ui::clear_help(1);
		player::set_player_invincible(player::player_id(), 1);
		gameplay::clear_area(vLocal_1826, 10f, 1, 0, 0, 0);
		ui::clear_help(1);
		system::settimera(0);
		iLocal_1769++;
		break;

	case 1:
		if (func_196(uLocal_1787[1], uLocal_1791[1], 152.2146f)) {
			iLocal_1769++;
		}
		break;

	case 2:
		if (system::timera() >= 0) {
			func_201(&iLocal_1765);
			entity::freeze_entity_position(iLocal_1801, 0);
			ui::display_radar(0);
			ui::display_hud(0);
			iLocal_1769++;
		}
		break;

	case 3:
		if (entity::does_entity_exist(uLocal_1787[1])) {
			vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
			if (vVar0.z <= 32f) {
				if (cam::is_screen_fading_out()) {
					if (!cam::is_screen_fading_in()) {
						cam::do_screen_fade_in(1000);
					}
				}
				else {
					func_195(1);
					player::set_player_control(player::player_id(), 0, 0);
					func_201(&iLocal_1765);
					iLocal_1769++;
				}
			}
			else {
				func_192(uLocal_1787[1], 0, 0, 0.25f, 1, 0, 1);
			}
		}
		break;

	case 4:
		func_201(&iLocal_1765);
		system::settimera(0);
		func_181(1, 1, 1);
		iLocal_1739 = 1;
		return;
	}
	if (iLocal_1769 >= 3) {
		if (!iLocal_1722) {
			if (func_179(iLocal_144)) {
				iLocal_1722 = 1;
			}
		}
		else if (cam::is_screen_faded_out()) {
			func_178();
			func_195(1);
			entity::set_entity_heading(iLocal_1801, 74.1208f);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			func_181(1, 1, 1);
			func_177();
			iLocal_1739 = 1;
			return;
		}
	}
}

// Position - 0x8EB7
void func_177() {
	cam::do_screen_fade_in(1000);
	while (!cam::is_screen_faded_in()) {
		system::wait(0);
	}
}

// Position - 0x8ED6
void func_178() {
	Global_14611 = 0;
	func_54();
}

// Position - 0x8EE6
bool func_179(int iParam0) {
	if (func_180() && gameplay::get_game_timer() >= iParam0 + 1000) {
		cam::do_screen_fade_out(500);
		while (!cam::is_screen_faded_out()) {
			system::wait(0);
		}
		func_151(0);
		func_178();
		return true;
	}
	return false;
}

// Position - 0x8F29
bool func_180() {
	if (ui::is_pause_menu_active()) {
		return false;
	}
	if (controls::is_control_just_pressed(0, 18) || controls::is_control_just_pressed(2, 18)) {
		return true;
	}
	return false;
}

// Position - 0x8F5B
void func_181(int iParam0, int iParam1, int iParam2) {
	if (iParam0) {
		player::set_player_control(player::get_player_index(), 1, 0);
	}
	cutscene::_0xC61B86C9F61EB404(1);
	func_183(0, 1, iParam2, 0);
	if (iParam1) {
		ui::display_radar(1);
		ui::display_hud(1);
	}
	func_182(23, 0);
}

// Position - 0x8F96
void func_182(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_25434, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_25434, iParam0);
	}
}

// Position - 0x8FB8
void func_183(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_191(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_49()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_190(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_191(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_190(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_188(player::player_id()) &&
				!func_185(player::player_id(), 0) && !func_184()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_188(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0x90D1
bool func_184() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0x90EE
bool func_185(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_186(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x9139
int func_186(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_187();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x917A
var func_187() { return Global_1312735; }

// Position - 0x9186
int func_188(int iParam0) {
	if (func_185(iParam0, 0)) {
		return 1;
	}
	if (func_189()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0x91C8
bool func_189() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x91D9
int func_190(int iParam0, int iParam1, var uParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && uParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x920C
void func_191(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0x922F
void func_192(int iParam0, int iParam1, int iParam2, float fParam3, int iParam4, int iParam5, int iParam6) {
	vector3 vVar0;
	float fVar3;
	int iVar4;

	iParam5 = iParam5;
	iParam1 = iParam1;
	iParam2 = iParam2;
	iParam6 = iParam6;
	if (entity::does_entity_exist(iParam0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
		if (ui::is_hud_component_active(19)) {
			fParam3 /= 5f;
		}
		if (iParam5) {
			entity::set_entity_coords(iParam0, vVar0.x, vVar0.y, vVar0.z + fParam3, 1, 0, 0, 1);
		}
		else {
			entity::set_entity_coords(iParam0, vVar0.x, vVar0.y, vVar0.z - fParam3, 1, 0, 0, 1);
		}
	}
	if (iParam4) {
		if (ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
			iVar4 = ped::get_vehicle_ped_is_in(iLocal_1801, 0);
		}
		if (iVar4 == 0) {
			if (!entity::is_entity_attached(iLocal_1801)) {
				fVar3 = entity::get_entity_heading(iLocal_1801);
				if (fVar3 + 90f >= 360f) {
					fVar3 += 90f - 360f;
				}
				else {
					fVar3 += 90f;
				}
				if (!ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
					entity::attach_entity_to_entity(iLocal_1801, iParam0, 0, vLocal_1946, 0f, 0f, fVar3, 0, 0, 1, 0, 2,
													1);
				}
			}
		}
		else if (!entity::is_entity_attached(iVar4)) {
			fVar3 = entity::get_entity_heading(iVar4);
			if (fVar3 + 90f >= 360f) {
				fVar3 += 90f - 360f;
			}
			else {
				fVar3 += 90f;
			}
			entity::attach_entity_to_entity(iVar4, iParam0, 0, 0.4f, -2.2f, -1.2f, 0f, 0f, fVar3, 0, 0, 0, 0, 2, 1);
		}
	}
	cam::_0xDD79DF9F4D26E1C9();
	func_193(&iLocal_1765, iParam0);
}

// Position - 0x9399
void func_193(int *iParam0, int iParam1) {
	if (*iParam0 == -1) {
		*iParam0 = audio::get_sound_id();
		func_194("FREIGHT_ELEVATOR_02_MOTOR", iParam0, 1, iParam1, 0, 0, 0, 0);
	}
}

// Position - 0x93C0
void func_194(char *sParam0, int *iParam1, int iParam2, int iParam3, float fParam4, float fParam5, float fParam6,
			  char *sParam7) {
	func_201(iParam1);
	if (iParam2) {
		*iParam1 = audio::get_sound_id();
	}
	else {
		*iParam1 = -1;
	}
	if (iParam3 != 0) {
		audio::play_sound_from_entity(*iParam1, sParam0, iParam3, sParam7, 0, 0);
	}
	else if (fParam4 != 0f || fParam5 != 0f || fParam6 != 0f) {
		audio::play_sound_from_coord(*iParam1, sParam0, fParam4, fParam5, fParam6, sParam7, 0, 0, 0);
	}
	else {
		audio::play_sound_frontend(*iParam1, sParam0, sParam7, 1);
	}
}

// Position - 0x9437
void func_195(int iParam0) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(iLocal_1801, 0);
		entity::detach_entity(iVar0, 1, 1);
	}
	else {
		entity::detach_entity(iLocal_1801, 1, 1);
	}
	func_201(&iLocal_1765);
	if (entity::does_entity_exist(uLocal_1787[1])) {
		entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 31.44f, 1, 0, 0, 1);
	}
	else {
		uLocal_1787[1] = object::create_object(iLocal_1784, -158.84f, -942.24f, 31.44f, 1, 1, 0);
		entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 31.44f, 1, 0, 0, 1);
		entity::set_entity_rotation(uLocal_1787[1], vLocal_1832[1 /*3*/], 2, 1);
	}
	if (iVar0 == 0) {
		entity::attach_entity_to_entity(iLocal_1801, uLocal_1787[1], 0, vLocal_1946, 0f, 0f, 74.1208f, 0, 0, 1, 0, 2,
										1);
	}
	else {
		entity::attach_entity_to_entity(iVar0, uLocal_1787[1], 0, 0.4f, -2.2f, -1.2f, 0f, 0f, 74.1208f, 0, 0, 0, 0, 2,
										1);
	}
	if (iParam0) {
	}
	if (iVar0 != 0) {
		entity::detach_entity(iVar0, 0, 0);
	}
	else {
		entity::detach_entity(iLocal_1801, 0, 0);
	}
	player::set_player_control(player::player_id(), 1, 0);
	cam::set_gameplay_cam_relative_heading(0f);
}

// Position - 0x956C
bool func_196(int iParam0, var uParam1, int iParam2) {
	vector3 vVar0;

	switch (iLocal_1761) {
	case 0:
		ai::task_go_straight_to_coord(player::player_ped_id(),
									  entity::get_offset_from_entity_in_world_coords(iParam0, vLocal_1916), 1f, -1,
									  iParam2, 1056964608);
		iLocal_1761++;
		break;

	case 1:
		if (ai::get_script_task_status(player::player_ped_id(), 2106541073) != 1) {
			weapon::get_current_ped_weapon(player::player_ped_id(), &iLocal_2174, 1);
			weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
			uParam1 = uParam1;
			iLocal_1761++;
		}
		break;

	case 2:
		if (ai::get_script_task_status(player::player_ped_id(), -875674219) != 1) {
			iLocal_1777 =
				ped::create_synchronized_scene(entity::get_offset_from_entity_in_world_coords(iParam0, vLocal_1916),
											   entity::get_entity_rotation(iParam0, 2), 2);
			ai::task_synchronized_scene(player::player_ped_id(), iLocal_1777, "oddjobs@assassinate@construction@",
										"ig_1_button", 4f, -4f, 1, 0, 1148846080, 0);
			iLocal_1761++;
		}
		break;

	case 3:
		if (ped::is_synchronized_scene_running(iLocal_1777) && ped::get_synchronized_scene_phase(iLocal_1777) > 0.9f) {
			iLocal_1761++;
		}
		break;

	case 4:
		vVar0 = {entity::get_offset_from_entity_given_world_coords(
			iParam0, entity::get_entity_coords(player::player_ped_id(), 1))};
		vVar0.z = -1.333402f;
		entity::attach_entity_to_entity(player::player_ped_id(), iParam0, 0, vVar0, 0f, 0f,
										entity::get_entity_heading(player::player_ped_id()) -
											entity::get_entity_heading(iParam0),
										1, 1, 0, 0, 2, 1);
		ai::clear_ped_tasks(player::player_ped_id());
		return true;
	}
	return false;
}

// Position - 0x96CC
void func_197() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Local_1645[iVar0 /*19*/])) {
			if (entity::is_entity_occluded(Local_1645[iVar0 /*19*/])) {
				ped::delete_ped(&Local_1645[iVar0 /*19*/]);
			}
			else {
				entity::set_ped_as_no_longer_needed(&Local_1645[iVar0 /*19*/]);
			}
		}
		iVar0++;
	}
}

// Position - 0x971B
void func_198(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= iParam1 - 1) {
		if (entity::does_entity_exist((*uParam0)[iVar0 /*19*/])) {
			if (entity::is_entity_occluded((*uParam0)[iVar0 /*19*/])) {
				ped::delete_ped(&(*uParam0)[iVar0 /*19*/]);
			}
			else {
				if (ped::is_ped_in_any_heli((*uParam0)[iVar0 /*19*/])) {
					if (!ped::is_ped_injured((*uParam0)[iVar0 /*19*/])) {
						ped::set_ped_combat_attributes((*uParam0)[iVar0 /*19*/], 3, 0);
						ped::set_ped_flee_attributes((*uParam0)[iVar0 /*19*/], 2, 0);
						ped::set_ped_keep_task((*uParam0)[iVar0 /*19*/], 1);
					}
				}
				entity::set_ped_as_no_longer_needed(&(*uParam0)[iVar0 /*19*/]);
			}
		}
		iVar0++;
	}
}

// Position - 0x97A7
var func_199() {
	iLocal_144 = gameplay::get_game_timer();
	return iLocal_144;
}

// Position - 0x97B7
void func_200(int iParam0, int iParam1, int iParam2) {
	player::set_player_control(player::get_player_index(), 0, iParam0);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		fire::stop_fire_in_range(entity::get_entity_coords(player::player_ped_id(), 1), 15f);
	}
	cutscene::_0xC61B86C9F61EB404(iParam1);
	func_151(0);
	func_183(1, 1, iParam2, 0);
	ui::display_radar(0);
	ui::display_hud(0);
	func_182(23, 1);
}

// Position - 0x980D
void func_201(int *iParam0) {
	if (*iParam0 != -1) {
		audio::stop_sound(*iParam0);
		audio::release_sound_id(*iParam0);
		*iParam0 = -1;
	}
}

// Position - 0x982E
bool func_202(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x9841
void func_203() {
	if (!func_202("ASS_CS_ELEHELP")) {
		func_206("ASS_CS_ELEHELP", -1);
	}
}

// Position - 0x985E
bool func_204(vector3 vParam0) {
	if (func_34(iLocal_1801, vParam0, 1) <= 1.65f && !entity::is_entity_in_air(iLocal_1801) &&
		!ped::is_ped_ragdoll(player::player_ped_id()) && func_60(3f) == 0 && !func_205() &&
		!ped::is_ped_jumping(iLocal_1801) && !ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
		return true;
	}
	return false;
}

// Position - 0x98CC
int func_205() {
	if (Global_14443.f_1 == 6) {
		return 1;
	}
	return 0;
}

// Position - 0x98E5
void func_206(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x98FC
bool func_207(char *sParam0, int iParam1, char *sParam2) {
	ui::begin_text_command_is_message_displayed(sParam0);
	if (iParam1 == 1) {
		ui::add_text_component_substring_text_label(sParam2);
	}
	return ui::end_text_command_is_message_displayed();
}

// Position - 0x991A
int func_208(int *iParam0, var *uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7) {
	if (!*iParam0) {
		if (func_58(uParam1, sParam2, sParam3, iParam4, iParam5, iParam6, iParam7)) {
			*iParam0 = 1;
			return 1;
		}
	}
	return 0;
}

// Position - 0x9947
void func_209() {
	switch (iLocal_1760) {
	case 0:
		bLocal_1750 = false;
		audio::trigger_music_event("ASS5_KILL");
		if (entity::does_entity_exist(iLocal_1972)) {
			if (!entity::is_entity_dead(iLocal_1972, 0) &&
				!entity::is_entity_dead(vehicle::get_ped_in_vehicle_seat(iLocal_1972, -1, 0), 0)) {
				ai::task_heli_mission(vehicle::get_ped_in_vehicle_seat(iLocal_1972, -1, 0), iLocal_1972, 0, iLocal_1801,
									  0f, 0f, 180f, 8, 20f, 30f, -1f, 325, 40, -1f, 0);
			}
			else {
				entity::set_vehicle_as_no_longer_needed(&iLocal_1972);
			}
		}
		unk1::_0x293220DA1B46CEBC(3f, 1073741824, 3);
		system::settimera(0);
		iLocal_1760++;
		break;

	case 1:
		if (system::timera() >= 3000) {
			func_210();
			func_40();
			iLocal_1030 = 15;
		}
		else {
			func_208(&iLocal_1063, &uLocal_2005, "OJASAUD", "OJAS_COCOM", 9, 1, 0, 0);
		}
		break;
	}
}

// Position - 0x9A26
void func_210() {
	if (ui::does_blip_exist(iLocal_1708)) {
		ui::remove_blip(&iLocal_1708);
	}
	if (ui::does_blip_exist(iLocal_1709)) {
		ui::remove_blip(&iLocal_1709);
	}
}

// Position - 0x9A50
void func_211() {
	int iVar0;
	var *uVar1;

	switch (iLocal_1760) {
	case 0:
		if (bLocal_1742) {
			bLocal_1748 = true;
		}
		else {
			func_226(3, "assassin_construction_rooftop_battle", 0, 0, 0, 1);
		}
		audio::trigger_music_event("ASS5_ROOF");
		audio::start_audio_scene("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE");
		if (ui::does_blip_exist(iLocal_1710)) {
			ui::remove_blip(&iLocal_1710);
		}
		streaming::end_srl();
		player::set_player_invincible(player::player_id(), 0);
		func_223(5);
		func_222(0);
		if (!entity::is_entity_dead(iLocal_1802, 0) && !entity::is_entity_dead(iLocal_1972, 0) &&
			!ped::is_ped_in_vehicle(iLocal_1802, iLocal_1972, 0)) {
			ai::task_enter_vehicle(iLocal_1802, iLocal_1972, 20000, 0, 2f, 1, 0);
		}
		if (bLocal_1736) {
			if (!object::does_pickup_exist(uVar1)) {
				iVar0 = 0;
				gameplay::set_bit(&iVar0, 3);
				gameplay::set_bit(&iVar0, 4);
			}
			iLocal_1760++;
		}
		break;

	case 1:
		if (cam::is_screen_faded_in()) {
			if (!entity::is_entity_dead(Local_1587[1 /*19*/], 0)) {
				ai::task_combat_ped(Local_1587[1 /*19*/], iLocal_1801, 0, 16);
			}
			if (!entity::is_entity_dead(Local_1587[2 /*19*/], 0)) {
				ai::task_combat_ped(Local_1587[2 /*19*/], iLocal_1801, 0, 16);
			}
			func_221();
			system::settimera(0);
			iLocal_1760++;
		}
		break;

	case 2:
		if (system::timera() > 4000) {
			bLocal_1751 = true;
			func_32("ASS_CS_KILL", 7500, 1);
			iLocal_1760++;
		}
		break;

	case 3: break;
	}
	func_219();
	if (bLocal_1748) {
		func_218();
	}
	func_213();
	func_212();
}

// Position - 0x9BCF
void func_212() {
	if (!iLocal_1733) {
		if (!entity::is_entity_dead(Local_1510[3 /*19*/], 0)) {
			if (entity::has_entity_been_damaged_by_entity(Local_1510[3 /*19*/], player::player_ped_id(), 1) ||
				ped::is_ped_injured(Local_1510[3 /*19*/])) {
				entity::apply_force_to_entity(Local_1510[3 /*19*/], 1, 0f, -4f, 2f, 0f, 0.2f, 0f, 0, 1, 1, 1, 0, 1);
				entity::set_entity_collision(Local_1510[3 /*19*/], 0, 0);
				entity::set_entity_has_gravity(Local_1510[3 /*19*/], 1);
				entity::set_entity_health(Local_1510[3 /*19*/], 0);
				iLocal_1733 = 1;
			}
		}
	}
	if (!iLocal_1734) {
		if (!entity::is_entity_dead(Local_1510[3 /*19*/], 0)) {
			if (!ped::is_ped_injured(Local_1510[3 /*19*/]) && !ped::is_ped_ragdoll(Local_1510[3 /*19*/])) {
				if (!entity::is_entity_at_coord(Local_1510[3 /*19*/], vLocal_1811, 5f, 5f, 5f, 0, 1, 0)) {
					entity::set_entity_coords(Local_1510[3 /*19*/], vLocal_1811, 1, 0, 0, 1);
					iLocal_1734 = 1;
				}
			}
		}
	}
	switch (iLocal_1767) {
	case 0:
		if (bLocal_1751) {
			if (!ped::is_ped_injured(Local_1510[3 /*19*/])) {
				if (!entity::is_entity_waiting_for_world_collision(Local_1510[3 /*19*/])) {
					ped::set_ped_accuracy(Local_1510[3 /*19*/], 0);
					entity::freeze_entity_position(Local_1510[3 /*19*/], 0);
					if (ai::get_script_task_status(Local_1510[3 /*19*/], 167901368) != 1 &&
						ai::get_script_task_status(Local_1510[3 /*19*/], 167901368) != 0) {
						ai::task_shoot_at_entity(Local_1510[3 /*19*/], iLocal_1801, -1, -957453492);
					}
				}
			}
			uLocal_1764 = gameplay::get_random_int_in_range(5000, 10000);
			uLocal_1764 = uLocal_1764;
			iLocal_1767++;
		}
		break;

	case 1:
		if (!ped::is_ped_injured(Local_1510[3 /*19*/])) {
			vLocal_1910 = {entity::get_entity_coords(Local_1510[3 /*19*/], 1)};
			if (vLocal_1910.z > 294f) {
				if (!entity::is_entity_at_coord(Local_1510[3 /*19*/], vLocal_1811, 2f, 2f, 2f, 0, 1, 0)) {
					if (ai::get_script_task_status(Local_1510[3 /*19*/], 2106541073) != 1 &&
						ai::get_script_task_status(Local_1510[3 /*19*/], 2106541073) != 0) {
						ai::task_go_straight_to_coord(Local_1510[3 /*19*/], vLocal_1811, 2f, 20000, 1193033728,
													  1056964608);
					}
				}
				else if (ai::get_script_task_status(Local_1510[3 /*19*/], 167901368) != 1 &&
						 ai::get_script_task_status(Local_1510[3 /*19*/], 167901368) != 0) {
					ai::task_shoot_at_entity(Local_1510[3 /*19*/], iLocal_1801, -1, -957453492);
				}
			}
		}
		break;
	}
}

// Position - 0x9E2E
void func_213() {
	func_217();
	if (entity::does_entity_exist(iLocal_1972)) {
		if (entity::does_entity_exist(iLocal_1802)) {
			if (!vehicle::is_vehicle_driveable(iLocal_1972, 0) ||
				ped::is_ped_injured(vehicle::get_ped_in_vehicle_seat(iLocal_1972, -1, 0))) {
				if (!iLocal_1737) {
					if (!entity::is_entity_dead(iLocal_1972, 0)) {
						if (vehicle::is_playback_going_on_for_vehicle(iLocal_1972)) {
							vehicle::stop_playback_recorded_vehicle(iLocal_1972);
						}
						if (entity::is_entity_in_air(iLocal_1972)) {
							entity::set_entity_load_collision_flag(iLocal_1972, 1);
							vehicle::set_vehicle_out_of_control(iLocal_1972, 1, 1);
							vehicle::set_vehicle_engine_health(iLocal_1972, 10f);
							vehicle::set_vehicle_doors_locked(iLocal_1972, 3);
						}
						else {
							func_216();
							func_215();
						}
						iLocal_1737 = 1;
					}
				}
			}
			else if (iLocal_1731 == 0) {
				if (!ped::is_ped_injured(iLocal_1802)) {
					if (ped::is_ped_in_vehicle(iLocal_1802, iLocal_1972, 0)) {
						iLocal_1731 = 1;
					}
				}
			}
			else {
				func_214();
			}
		}
	}
}

// Position - 0x9EFD
void func_214() {
	switch (iLocal_1032) {
	case 0:
		if (!entity::is_entity_dead(iLocal_1802, 0) && !entity::is_entity_dead(iLocal_1972, 0)) {
			if (ped::is_ped_in_vehicle(iLocal_1802, iLocal_1972, 0)) {
				vehicle::set_heli_blades_speed(iLocal_1972, 1f);
				ai::task_heli_mission(vehicle::get_ped_in_vehicle_seat(iLocal_1972, -1, 0), iLocal_1972, 0, iLocal_1801,
									  0f, 0f, 10f, 9, 20f, 30f, -1f, 325, 40, -1f, 0);
			}
		}
		func_30(&uLocal_1988);
		iLocal_1032 = 1;
		break;

	case 1:
		if (!ped::is_ped_injured(Local_1587[0 /*19*/])) {
			if (entity::does_entity_exist(iLocal_1802)) {
				if (!ped::is_ped_injured(iLocal_1802)) {
					if (ped::is_ped_injured(Local_1587[1 /*19*/]) && ped::is_ped_injured(Local_1587[2 /*19*/])) {
						if (!func_29(&uLocal_1991)) {
							func_30(&uLocal_1991);
						}
						else if (func_26(&uLocal_1991) > 45f) {
							ai::task_heli_mission(Local_1587[0 /*19*/], iLocal_1972, 0, iLocal_1801, 0f, 0f, 0f, 8, 30f,
												  300f, -1f, 325, 40, -1f, 0);
							iLocal_1032 = 2;
						}
					}
					else if (!func_29(&uLocal_1988)) {
						func_30(&uLocal_1988);
					}
					else if (func_26(&uLocal_1988) > 180f) {
						ai::task_heli_mission(Local_1587[0 /*19*/], iLocal_1972, 0, iLocal_1801, 0f, 0f, 0f, 8, 30f,
											  300f, -1f, 325, 40, -1f, 0);
						iLocal_1032 = 2;
					}
				}
			}
		}
		break;

	case 2:
		if (!iLocal_1732) {
			if (!func_62()) {
				if (!ped::is_ped_injured(iLocal_1802)) {
					if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_BOSS3", 9, 0, 0, 0)) {
						iLocal_1732 = 1;
					}
				}
			}
		}
		break;
	}
}

// Position - 0xA0B9
void func_215() {
	int iVar0;

	if (!ped::is_ped_injured(iLocal_1802)) {
		ped::set_ped_combat_attributes(iLocal_1802, 3, 1);
		ai::open_sequence_task(&iVar0);
		ai::task_leave_any_vehicle(0, 0, 0);
		ai::task_cower(0, -1);
		ai::close_sequence_task(iVar0);
		ai::task_perform_sequence(iLocal_1802, iVar0);
		ai::clear_sequence_task(&iVar0);
	}
}

// Position - 0xA0FD
void func_216() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(Local_1587[iVar0 /*19*/])) {
			ped::set_ped_combat_attributes(Local_1587[iVar0 /*19*/], 3, 1);
			ai::task_combat_ped(Local_1587[iVar0 /*19*/], player::player_ped_id(), 0, 16);
		}
		iVar0++;
	}
}

// Position - 0xA145
void func_217() {
	int iVar0;

	if (!iLocal_1747) {
		if (entity::does_entity_exist(iLocal_1972) && !entity::is_entity_dead(iLocal_1972, 0)) {
			if (vehicle::get_ped_in_vehicle_seat(iLocal_1972, 1, 0) != 0) {
				uLocal_1808 = vehicle::get_ped_in_vehicle_seat(iLocal_1972, 1, 0);
				uLocal_1808 = uLocal_1808;
			}
			if (vehicle::get_ped_in_vehicle_seat(iLocal_1972, 2, 0) != 0) {
				iLocal_1809 = vehicle::get_ped_in_vehicle_seat(iLocal_1972, 2, 0);
			}
			if (vehicle::is_vehicle_seat_free(iLocal_1972, 1, 0)) {
				ai::clear_sequence_task(&iVar0);
				ai::open_sequence_task(&iVar0);
				ai::task_shuffle_to_next_vehicle_seat(0, iLocal_1972);
				ai::task_combat_ped(0, iLocal_1801, 0, 16);
				ai::close_sequence_task(iVar0);
				if (!entity::is_entity_dead(iLocal_1809, 0)) {
					ai::task_perform_sequence(iLocal_1809, iVar0);
				}
				ai::clear_sequence_task(&iVar0);
				iLocal_1747 = 1;
			}
		}
	}
}

// Position - 0xA1F4
void func_218() {
	if (!iLocal_1749) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (ped::is_ped_on_foot(player::player_ped_id())) {
				if (entity::is_entity_in_angled_area(player::player_ped_id(), -160.1407f, -981.4936f, 273.4415f,
													 -144.7745f, -941.6792f, 266.6331f, 42f, 0, 1, 0)) {
					func_226(3, "assassin_construction_rooftop_battle", 0, 0, 0, 1);
					iLocal_1749 = 1;
				}
			}
		}
	}
}

// Position - 0xA25D
void func_219() {
	if (func_29(&uLocal_1997)) {
		if (!iLocal_2004) {
			if (func_26(&uLocal_1997) >= 12f) {
				func_220(5, 15);
				func_220(6, 15);
				iLocal_2004 = 1;
			}
		}
	}
	else {
		func_61(&uLocal_1997);
		func_220(5, 0);
		func_220(6, 0);
	}
}

// Position - 0xA2AE
void func_220(int iParam0, int iParam1) {
	int iVar0;

	switch (iParam0) {
	case 1:
		iVar0 = 0;
		while (iVar0 <= 4) {
			if (entity::does_entity_exist(Local_1202[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1202[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1202[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	case 2:
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (entity::does_entity_exist(Local_1298[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1298[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1298[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	case 3:
		iVar0 = 0;
		while (iVar0 <= 5) {
			if (entity::does_entity_exist(Local_1356[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1356[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1356[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	case 4:
		iVar0 = 0;
		while (iVar0 <= 1) {
			if (entity::does_entity_exist(Local_1471[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1471[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1471[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	case 5:
		iVar0 = 0;
		while (iVar0 <= 3) {
			if (entity::does_entity_exist(Local_1510[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1510[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1510[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	case 6:
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (entity::does_entity_exist(Local_1587[iVar0 /*19*/])) {
				if (!ped::is_ped_injured(Local_1587[iVar0 /*19*/])) {
					ped::set_ped_accuracy(Local_1587[iVar0 /*19*/], iParam1);
				}
			}
			iVar0++;
		}
		break;

	default: break;
	}
}

// Position - 0xA45E
void func_221() {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 <= 3) {
		if (iVar1 == 0) {
			if (!ped::is_ped_injured(Local_1510[iVar1 /*19*/])) {
				if (cam::is_screen_faded_in()) {
					ped::set_ped_sphere_defensive_area(Local_1510[iVar1 /*19*/], Local_1510[iVar1 /*19*/].f_10, 15f, 0,
													   0);
					ai::clear_sequence_task(&iVar0);
					ai::open_sequence_task(&iVar0);
					ai::task_aim_gun_at_entity(0, iLocal_1801, 250, 0);
					ai::task_go_to_coord_while_aiming_at_entity(0, -141.3603f, -946.2284f, 268.135f, iLocal_1801, 2f, 1,
																1056964608, 1082130432, 1, 0, 0, -957453492, 20000);
					ai::task_combat_ped(0, iLocal_1801, 0, 16);
					ai::close_sequence_task(iVar0);
					ai::task_perform_sequence(Local_1510[iVar1 /*19*/], iVar0);
					ai::clear_sequence_task(&iVar0);
					ped::set_ped_combat_movement(Local_1510[iVar1 /*19*/], 2);
					ped::set_ped_keep_task(Local_1510[iVar1 /*19*/], 1);
				}
			}
		}
		else if (iVar1 == 1) {
			if (!ped::is_ped_injured(Local_1510[iVar1 /*19*/])) {
				ai::clear_sequence_task(&iVar0);
				ai::open_sequence_task(&iVar0);
				ai::task_go_to_coord_any_means(0, -140.121f, -959.6016f, 268.2571f, 3f, 0, 0, 786603, -1082130432);
				ai::task_combat_ped(0, iLocal_1801, 0, 16);
				ai::close_sequence_task(iVar0);
				ai::task_perform_sequence(Local_1510[iVar1 /*19*/], iVar0);
				ai::clear_sequence_task(&iVar0);
				ped::set_ped_combat_movement(Local_1510[iVar1 /*19*/], 2);
				ped::set_ped_keep_task(Local_1510[iVar1 /*19*/], 1);
			}
		}
		else if (iVar1 == 2) {
			if (!ped::is_ped_injured(Local_1510[iVar1 /*19*/])) {
				ai::task_combat_ped(Local_1510[iVar1 /*19*/], iLocal_1801, 0, 16);
				ped::set_ped_sphere_defensive_area(Local_1510[iVar1 /*19*/], Local_1510[iVar1 /*19*/].f_10, 10f, 0, 0);
				ped::set_ped_combat_movement(Local_1510[iVar1 /*19*/], 2);
				ped::set_ped_keep_task(Local_1510[iVar1 /*19*/], 1);
			}
		}
		iVar1++;
	}
}

// Position - 0xA610
void func_222(int iParam0) {
	streaming::request_model(iLocal_1785);
	if (!bLocal_1736) {
		if (streaming::has_model_loaded(iLocal_1785)) {
			bLocal_1736 = true;
		}
	}
	if (bLocal_1736) {
		if (!iLocal_1729) {
			if (!entity::does_entity_exist(iLocal_1972)) {
				iLocal_1972 = vehicle::create_vehicle(iLocal_1785, vLocal_1949, fLocal_1952, 1, 1);
				vehicle::set_vehicle_engine_on(iLocal_1972, 1, 1, 0);
				audio::set_vehicle_radio_enabled(iLocal_1972, 0);
				entity::set_entity_load_collision_flag(iLocal_1972, 1);
				if (iParam0) {
					iLocal_1802 = ped::create_ped_inside_vehicle(iLocal_1972, 26, iLocal_1778[0], 0, 1, 1);
				}
				else {
					iLocal_1802 = ped::create_ped(26, iLocal_1778[0], vLocal_1953, fLocal_1956, 1, 1);
				}
				ped::set_ped_default_component_variation(iLocal_1802);
				func_363(&uLocal_2005, 3, iLocal_1802, "MAFIABOSS", 0, 1);
				ped::set_ped_combat_attributes(iLocal_1802, 3, 0);
				weapon::give_weapon_to_ped(iLocal_1802, joaat("weapon_pistol"), -1, 1, 1);
				ped::set_ped_combat_movement(iLocal_1802, 2);
				ped::set_ped_accuracy(iLocal_1802, 10);
				entity::set_entity_load_collision_flag(iLocal_1802, 1);
				ped::set_ped_relationship_group_hash(iLocal_1802, iLocal_1975);
				ped::set_blocking_of_non_temporary_events(iLocal_1802, 1);
				audio::_dynamic_mixer_related_fn(iLocal_1972, "ASSASSINATION_CONSTRUCT_HELI_GROUP", 0);
				func_223(6);
				iLocal_1729 = 1;
			}
		}
	}
}

// Position - 0xA729
void func_223(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 == 1) {
		iVar0 = 0;
		while (iVar0 <= 4) {
			if (!entity::does_entity_exist(Local_1202[iVar0 /*19*/]) && !func_225(Local_1202[iVar0 /*19*/].f_10)) {
				if (iVar0 % 2 == 0) {
					Local_1202[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[0], Local_1202[iVar0 /*19*/].f_10,
															   Local_1202[iVar0 /*19*/].f_13, 1, 1);
					ped::set_ped_component_variation(Local_1202[iVar0 /*19*/], 3, 0,
													 gameplay::get_random_int_in_range(1, 4), 0);
				}
				else {
					Local_1202[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[1], Local_1202[iVar0 /*19*/].f_10,
															   Local_1202[iVar0 /*19*/].f_13, 1, 1);
				}
				if (iVar0 == 0) {
					ai::task_patrol(Local_1202[iVar0 /*19*/], "miss_Ass0", 1, 0, 1);
				}
				else if (iVar0 == 1) {
					ai::task_patrol(Local_1202[iVar0 /*19*/], "miss_Ass4", 1, 0, 1);
				}
				else if (iVar0 == 2) {
					ai::task_guard_current_position(Local_1202[iVar0 /*19*/], 10f, 10f, 1);
				}
				else if (iVar0 == 3) {
					ai::task_patrol(Local_1202[iVar0 /*19*/], "miss_Ass6", 1, 0, 1);
				}
				else if (iVar0 == 4) {
					ai::task_patrol(Local_1202[iVar0 /*19*/], "miss_Ass3", 1, 0, 1);
				}
				func_224(&Local_1202, iVar0, 0);
				entity::set_entity_load_collision_flag(Local_1202[iVar0 /*19*/], 1);
				ped::set_ped_combat_attributes(Local_1202[iVar0 /*19*/], 50, 1);
				ped::stop_ped_weapon_firing_when_dropped(Local_1202[iVar0 /*19*/]);
			}
			iVar0++;
		}
	}
	if (iParam0 == 2) {
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (!entity::does_entity_exist(Local_1298[iVar0 /*19*/])) {
				if (entity::does_entity_exist(iLocal_1970)) {
					if (vehicle::is_vehicle_driveable(iLocal_1970, 0)) {
						if (iVar0 == 0) {
							Local_1298[iVar0 /*19*/] =
								ped::create_ped_inside_vehicle(iLocal_1970, 26, iLocal_1778[0], -1, 1, 1);
							ped::set_ped_component_variation(Local_1298[iVar0 /*19*/], 3, 0,
															 gameplay::get_random_int_in_range(1, 4), 0);
						}
						else if (iVar0 == 1) {
							Local_1298[iVar0 /*19*/] =
								ped::create_ped_inside_vehicle(iLocal_1970, 26, iLocal_1778[0], 0, 1, 1);
							ped::set_ped_component_variation(Local_1298[iVar0 /*19*/], 3, 0,
															 gameplay::get_random_int_in_range(1, 4), 0);
						}
						else if (iVar0 == 2) {
							Local_1298[iVar0 /*19*/] =
								ped::create_ped_inside_vehicle(iLocal_1970, 26, iLocal_1778[1], 1, 1, 1);
						}
						ped::set_ped_combat_attributes(Local_1298[iVar0 /*19*/], 3, 0);
					}
					func_224(&Local_1298, iVar0, 1);
					ped::set_ped_combat_attributes(Local_1298[iVar0 /*19*/], 50, 1);
					ped::stop_ped_weapon_firing_when_dropped(Local_1298[iVar0 /*19*/]);
				}
			}
			iVar0++;
		}
	}
	else if (iParam0 == 3) {
		iVar0 = 0;
		while (iVar0 <= 5) {
			if (!entity::does_entity_exist(Local_1356[iVar0 /*19*/])) {
				if (iVar0 % 2 == 0) {
					Local_1356[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[0], Local_1356[iVar0 /*19*/].f_10,
															   Local_1356[iVar0 /*19*/].f_13, 1, 1);
					ped::set_ped_component_variation(Local_1356[iVar0 /*19*/], 3, 0,
													 gameplay::get_random_int_in_range(1, 4), 0);
				}
				else {
					Local_1356[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[1], Local_1356[iVar0 /*19*/].f_10,
															   Local_1356[iVar0 /*19*/].f_13, 1, 1);
				}
				func_224(&Local_1356, iVar0, 1);
				ped::set_ped_combat_attributes(Local_1356[iVar0 /*19*/], 50, 1);
				audio::stop_ped_speaking(Local_1356[iVar0 /*19*/], 1);
				if (iVar0 == 0) {
					if (!ped::is_ped_injured(Local_1356[iVar0 /*19*/])) {
						ai::task_play_anim(Local_1356[iVar0 /*19*/], "oddjobs@assassinate@construction@",
										   "unarmed_fold_arms", 8f, -8f, -1, 1, 0, 0, 0, 0);
					}
				}
			}
			iVar0++;
		}
	}
	else if (iParam0 == 4) {
		iVar0 = 0;
		while (iVar0 <= 1) {
			if (!entity::does_entity_exist(Local_1471[iVar0 /*19*/])) {
				if (iVar0 % 2 == 0) {
					Local_1471[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[0], Local_1471[iVar0 /*19*/].f_10,
															   Local_1471[iVar0 /*19*/].f_13, 1, 1);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 3, 0,
													 gameplay::get_random_int_in_range(1, 4), 0);
					ai::task_aim_gun_at_entity(Local_1471[iVar0 /*19*/], player::player_ped_id(), -1, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 0, 0, 0, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 2, 0, 0, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 3, 0, 2, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 4, 0, 2, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 11, 1, 0, 0);
				}
				else {
					Local_1471[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[1], Local_1471[iVar0 /*19*/].f_10,
															   Local_1471[iVar0 /*19*/].f_13, 1, 1);
					ai::task_aim_gun_at_entity(Local_1471[iVar0 /*19*/], player::player_ped_id(), -1, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 0, 0, 2, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 3, 0, 0, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 4, 0, 1, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 8, 0, 0, 0);
					ped::set_ped_component_variation(Local_1471[iVar0 /*19*/], 11, 1, 1, 0);
				}
				if (entity::does_entity_exist(uLocal_1787[1])) {
					if (iVar0 == 0) {
						entity::attach_entity_to_entity(Local_1471[iVar0 /*19*/], uLocal_1787[1], 0, vLocal_1946, 0f,
														0f, 84.24f, 0, 0, 0, 0, 2, 1);
						func_363(&uLocal_2005, 4, Local_1471[iVar0 /*19*/], "OJAcsGUARD", 0, 1);
					}
					else if (iVar0 == 1) {
						entity::attach_entity_to_entity(Local_1471[iVar0 /*19*/], uLocal_1787[1], 0, -1.34f, -2.36f,
														-1.34f, 0f, 0f, 84.24f, 0, 0, 0, 0, 2, 1);
						func_363(&uLocal_2005, 5, Local_1471[iVar0 /*19*/], "OJAcsGUARD2", 0, 1);
					}
				}
			}
			func_224(&Local_1471, iVar0, 1);
			ped::set_ped_combat_attributes(Local_1471[iVar0 /*19*/], 50, 1);
			iVar0++;
		}
	}
	else if (iParam0 == 5) {
		if (!iLocal_1728) {
			if (bLocal_1742) {
				iVar1 = 1;
			}
			else {
				iVar1 = 1;
			}
			iVar0 = 0;
			while (iVar0 <= 4 - iVar1) {
				if (!entity::does_entity_exist(Local_1510[iVar0 /*19*/])) {
					if (iVar0 % 2 == 0) {
						Local_1510[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[0], Local_1510[iVar0 /*19*/].f_10,
																   Local_1510[iVar0 /*19*/].f_13, 1, 1);
						ped::set_ped_component_variation(Local_1510[iVar0 /*19*/], 3, 0,
														 gameplay::get_random_int_in_range(1, 4), 0);
					}
					else {
						Local_1510[iVar0 /*19*/] = ped::create_ped(26, iLocal_1778[1], Local_1510[iVar0 /*19*/].f_10,
																   Local_1510[iVar0 /*19*/].f_13, 1, 1);
					}
					if (iVar0 == 3) {
						ai::task_aim_gun_at_entity(Local_1510[iVar0 /*19*/], player::player_ped_id(), -1, 1);
						entity::freeze_entity_position(Local_1510[iVar0 /*19*/], 1);
					}
					func_224(&Local_1510, iVar0, 1);
					ped::set_ped_combat_attributes(Local_1510[iVar0 /*19*/], 50, 1);
				}
				iVar0++;
			}
			iLocal_1728 = 1;
		}
	}
	else if (iParam0 == 6) {
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (!entity::does_entity_exist(Local_1587[iVar0 /*19*/])) {
				if (vehicle::is_vehicle_driveable(iLocal_1972, 0)) {
					if (iVar0 == 0) {
						Local_1587[iVar0 /*19*/] =
							ped::create_ped_inside_vehicle(iLocal_1972, 26, iLocal_1778[0], -1, 1, 1);
						ped::set_ped_component_variation(Local_1587[iVar0 /*19*/], 3, 0,
														 gameplay::get_random_int_in_range(1, 4), 0);
						weapon::give_weapon_to_ped(Local_1587[0 /*19*/], joaat("weapon_assaultrifle"), -1, 1, 1);
					}
					else if (iVar0 == 1) {
						Local_1587[1 /*19*/] = ped::create_ped_inside_vehicle(iLocal_1972, 26, iLocal_1778[1], 2, 1, 1);
						weapon::give_weapon_to_ped(Local_1587[1 /*19*/], joaat("weapon_carbinerifle"), -1, 1, 1);
					}
					else if (iVar0 == 2) {
						Local_1587[2 /*19*/] = ped::create_ped_inside_vehicle(iLocal_1972, 26, iLocal_1778[0], 1, 1, 1);
						ped::set_ped_component_variation(Local_1587[iVar0 /*19*/], 3, 0,
														 gameplay::get_random_int_in_range(1, 4), 0);
						weapon::give_weapon_to_ped(Local_1587[2 /*19*/], joaat("weapon_carbinerifle"), -1, 1, 1);
					}
					ped::set_blocking_of_non_temporary_events(Local_1587[iVar0 /*19*/], 1);
					ped::set_ped_combat_attributes(Local_1587[iVar0 /*19*/], 3, 0);
					ped::set_ped_combat_movement(Local_1587[iVar0 /*19*/], 2);
					ped::set_ped_accuracy(Local_1587[iVar0 /*19*/], 0);
					ped::set_ped_relationship_group_hash(Local_1587[iVar0 /*19*/], iLocal_1975);
					ped::set_ped_combat_attributes(Local_1587[iVar0 /*19*/], 50, 1);
					ped::set_ped_config_flag(Local_1587[iVar0 /*19*/], 115, 1);
				}
			}
			iVar0++;
		}
	}
}

// Position - 0xAECA
void func_224(var *uParam0, int iParam1, int iParam2) {
	weapon::give_weapon_to_ped((*uParam0)[iParam1 /*19*/], (*uParam0)[iParam1 /*19*/].f_14, -1, 1, 1);
	ped::set_ped_as_enemy((*uParam0)[iParam1 /*19*/], 1);
	ped::set_ped_relationship_group_hash((*uParam0)[iParam1 /*19*/], iLocal_1975);
	ped::set_blocking_of_non_temporary_events((*uParam0)[iParam1 /*19*/], 1);
	ped::set_ped_combat_ability((*uParam0)[iParam1 /*19*/], (*uParam0)[iParam1 /*19*/].f_17);
	if (iParam2) {
		ped::set_ped_combat_range((*uParam0)[iParam1 /*19*/], (*uParam0)[iParam1 /*19*/].f_16);
	}
	ped::set_ped_combat_attributes((*uParam0)[iParam1 /*19*/], (*uParam0)[iParam1 /*19*/].f_18, 1);
	ped::set_ped_combat_movement((*uParam0)[iParam1 /*19*/], (*uParam0)[iParam1 /*19*/].f_15);
	ped::set_ped_accuracy((*uParam0)[iParam1 /*19*/], 20);
}

// Position - 0xAF64
int func_225(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0xAF8E
void func_226(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char[] cVar3[8];
	int iVar5;
	var uVar6;
	int iVar10;

	if (iParam3 == 1) {
		if (!gameplay::are_strings_equal("FinaleC2", script::get_this_script_name())) {
		}
	}
	iVar0 = 0;
	if (iParam3 == 1) {
		if (iParam0 != Global_91528) {
			iVar0 = 1;
		}
	}
	else if (iParam0 > Global_91528) {
		iVar0 = 1;
	}
	if (iVar0 == 1) {
		func_88(1);
		if (iParam0 <= Global_91528) {
		}
		iVar1 = func_295(script::get_this_script_name(), 1);
		if (iVar1 != -1 && iVar1 != 94) {
			Global_101700.f_8044.f_330[iVar1 /*6*/].f_1 = 0;
			iVar2 = func_293(iVar1);
			cVar3 = {Global_82612[iVar1 /*34*/].f_8};
			if (iVar1 == 90) {
				switch (Global_101700.f_8044.f_99.f_205[7]) {
				case 1: StringConCat(&cVar3, "A", 8); break;

				case 2: StringConCat(&cVar3, "B", 8); break;
				}
			}
			stats::playstats_mission_checkpoint(&cVar3, iVar2, Global_91528, iParam0);
		}
		else {
			iVar5 = func_288(script::get_this_script_name(), 1);
			if (iVar5 != -1) {
				Global_101700.f_17533[iVar5 /*6*/].f_4 = 0;
				MemCopy(&uVar6, {func_287(iVar5)}, 4);
				stats::playstats_mission_checkpoint(&uVar6, 0, Global_91528, iParam0);
			}
			else {
				iVar10 = func_286(&Global_91491.f_3);
				if (iVar10 > -1) {
					Global_101700.f_23945.f_4[iVar10] = 0;
				}
			}
		}
		Global_86002 = iParam2;
		Global_91528 = iParam0;
		func_227(iParam0, sParam1, iParam4, iParam5);
		if (gameplay::are_strings_equal(sParam1, "")) {
		}
	}
	else if (iParam0 < Global_91528) {
	}
}

// Position - 0xB103
void func_227(int iParam0, var uParam1, int iParam2, int iParam3) {
	func_228(&Global_96040, script::get_this_script_name(), iParam0, uParam1, iParam3, iParam2);
}

// Position - 0xB11F
void func_228(var *uParam0, var uParam1, var uParam2, var uParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;

	*uParam0 = func_10();
	uParam0->f_1 = func_275();
	gameplay::_get_weather_type_transition(&uParam0->f_6, &uParam0->f_7, &uParam0->f_8);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		func_260(&uParam0->f_2305, 0);
		func_259(player::player_ped_id());
		func_253(player::player_ped_id(), 0);
		weapon::get_current_ped_weapon(player::player_ped_id(), &uParam0->f_2, 1);
		if (uParam0->f_2 == 0 || uParam0->f_2 == joaat("object")) {
			uParam0->f_2 = joaat("weapon_unarmed");
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		uParam0->f_17[iVar1] = Global_101700.f_2095.f_539.f_294[iVar1];
		if (iVar1 == func_252()) {
			func_246(player::player_ped_id(), &uParam0->f_616[iVar1 /*65*/], 1);
		}
		else {
			iVar0 = 0;
			while (iVar0 < 12) {
				uParam0->f_616[iVar1 /*65*/][iVar0] = Global_91281[iVar1 /*65*/][iVar0];
				uParam0->f_616[iVar1 /*65*/].f_13[iVar0] = Global_91281[iVar1 /*65*/].f_13[iVar0];
				iVar0++;
			}
			uParam0->f_616[iVar1 /*65*/].f_59 = Global_91281[iVar1 /*65*/].f_59;
			uParam0->f_616[iVar1 /*65*/].f_60 = Global_91281[iVar1 /*65*/].f_60;
			uParam0->f_616[iVar1 /*65*/].f_61 = Global_91281[iVar1 /*65*/].f_61;
			uParam0->f_616[iVar1 /*65*/].f_62 = Global_91281[iVar1 /*65*/].f_62;
			uParam0->f_616[iVar1 /*65*/].f_63 = Global_91281[iVar1 /*65*/].f_63;
			uParam0->f_616[iVar1 /*65*/].f_64 = Global_91281[iVar1 /*65*/].f_64;
			iVar0 = 0;
			while (iVar0 < 9) {
				uParam0->f_616[iVar1 /*65*/].f_39[iVar0] = Global_91281[iVar1 /*65*/].f_39[iVar0];
				uParam0->f_616[iVar1 /*65*/].f_49[iVar0] = Global_91281[iVar1 /*65*/].f_49[iVar0];
				iVar0++;
			}
		}
		iVar0 = 0;
		while (iVar0 < 44) {
			uParam0->f_812[iVar1 /*284*/][iVar0 /*3*/] = {Global_101700.f_2095.f_539.f_298[iVar1 /*284*/][iVar0 /*3*/]};
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			uParam0->f_812[iVar1 /*284*/].f_133[iVar0 /*3*/] = {
				Global_101700.f_2095.f_539.f_298[iVar1 /*284*/].f_133[iVar0 /*3*/]};
			iVar0++;
		}
		switch (iVar1) {
		case 0:
			stats::stat_get_int(joaat("sp0_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp0_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 1:
			stats::stat_get_int(joaat("sp1_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp1_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 2:
			stats::stat_get_int(joaat("sp2_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp2_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;
		}
		uParam0->f_9[iVar1] = Global_101700.f_19523.f_233[iVar1 /*69*/].f_1;
		uParam0->f_13[iVar1] = Global_52996[iVar1];
		uParam0->f_25[0 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[0 /*295*/][iVar1 /*98*/]};
		uParam0->f_25[1 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[1 /*295*/][iVar1 /*98*/]};
		iVar0 = 0;
		while (iVar0 <= 3) {
			uParam0->f_2259[iVar1 /*15*/][iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/][iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_5[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_5[iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_10[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_10[iVar0];
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 2) {
			uParam0->f_1766[iVar1 /*164*/][iVar0] = Global_101700.f_2095[iVar1 /*164*/][iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_4[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_4[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_8[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_8[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_12[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_12[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_16[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_16[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_20[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_20[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_24[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_24[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_28[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_28[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_32[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_32[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_36[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_36[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_40[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_40[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_44[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_44[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_48[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_48[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_52[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_52[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_56[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_56[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_60[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_60[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_64[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_64[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_68[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_68[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_72[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_72[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_76[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_76[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_80[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_80[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_84[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_84[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_88[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_88[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_92[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_92[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_96[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_96[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_100[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_100[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_104[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_104[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_108[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_108[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_112[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_112[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_116[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_116[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_120[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_120[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_124[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_124[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_128[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_128[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_132[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_132[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_136[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_136[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_140[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_140[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_144[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_144[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_148[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_148[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_152[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_152[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_156[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_156[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_160[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_160[iVar0];
			iVar0++;
		}
		iVar1++;
	}
	stats::stat_get_int(joaat("sp0_special_ability"), &uParam0->f_1762[0], -1);
	stats::stat_get_int(joaat("sp1_special_ability"), &uParam0->f_1762[1], -1);
	stats::stat_get_int(joaat("sp2_special_ability"), &uParam0->f_1762[2], -1);
	uParam0->f_5 = 145;
	if (iParam4 == 1) {
		func_230(&uParam0->f_2311, uParam0, iParam5, 1, 1, 0);
	}
	func_229(&uParam0->f_2401);
	uParam3 = uParam3;
	uParam2 = uParam2;
}

// Position - 0xBFA7
int func_229(var *uParam0) {
	*uParam0 = Global_87673;
	uParam0->f_1 = Global_87674;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	return 1;
}

// Position - 0xBFC9
void func_230(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (iParam2 == 0) {
		iParam2 = player::player_ped_id();
	}
	if (entity::does_entity_exist(iParam2)) {
		uParam1->f_5 = func_14(iParam2);
	}
	if (func_243(iParam2, &iVar0, iParam3, iParam5)) {
		func_231(uParam0, uParam1, iVar0, iParam4);
	}
	else if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (vehicle::is_vehicle_model(iVar0, joaat("skylift")) &&
				ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
				func_231(uParam0, uParam1, iVar0, iParam4);
			}
		}
	}
}

// Position - 0xC052
int func_231(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (vehicle::is_vehicle_driveable(iParam2, 0)) {
		func_233(uParam0, iParam2, iParam3);
		uParam1->f_4 = iParam2;
		if (func_232(iParam2)) {
			uParam1->f_3 = 1;
		}
		else {
			uParam1->f_3 = 0;
		}
		return 1;
	}
	return 0;
}

// Position - 0xC092
bool func_232(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 6) {
		if (Global_91491.f_22[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0xC0C0
void func_233(var *uParam0, int iParam1, int iParam2) {
	func_239(iParam1, &uParam0->f_12);
	uParam0->f_7 = func_236(iParam1, 145, 0);
	uParam0->f_11 = func_235(iParam1);
	if (!uParam0->f_7) {
		if (!uParam0->f_10) {
			uParam0->f_10 = func_234(iParam1);
		}
	}
	if (iParam2 == 1) {
		*uParam0 = {entity::get_entity_coords(iParam1, 1)};
		uParam0->f_6 = entity::get_entity_heading(iParam1);
		uParam0->f_3 = {entity::get_entity_velocity(iParam1)};
		if (entity::is_entity_in_angled_area(iParam1, -1154.326f, -1523.871f, 3.262189f, -1158.453f, -1517.75f,
											 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_6 = 305.6424f;
		}
		if (Global_69436 == iParam1) {
			uParam0->f_9 = 1;
		}
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		uParam0->f_8 = 1;
	}
	else {
		uParam0->f_8 = 0;
	}
}

// Position - 0xC19C
int func_234(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iParam0 == Global_68531.f_484[iVar0]) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xC1DE
int func_235(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0xC241
int func_236(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				if (iParam1 == 145 || iParam1 == Global_89165[iVar0]) {
					if (iParam2 == 0 || entity::get_entity_model(iParam0) == func_237(iParam1, iParam2)) {
						return 1;
					}
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xC2CF
int func_237(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_13(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_238(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0xC311
void func_238(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xC56D
void func_239(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_242(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_241(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_240(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0xC819
int func_240(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0xC8C9
int func_241(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0xC9A3
void func_242(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0xCA53
bool func_243(int iParam0, var *uParam1, int iParam2, int iParam3) {
	char *sVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (iParam0 == player::player_ped_id()) {
				*uParam1 = player::get_players_last_vehicle();
			}
			else {
				*uParam1 = ped::get_vehicle_ped_is_in(iParam0, 1);
			}
			if (entity::does_entity_exist(*uParam1)) {
				if (vehicle::is_vehicle_driveable(*uParam1, 0)) {
					if (iParam2 == 0 ||
						gameplay::get_distance_between_coords(entity::get_entity_coords(*uParam1, 1),
															  entity::get_entity_coords(iParam0, 1), 1) < 100f) {
						if (vehicle::is_vehicle_model(*uParam1, joaat("taxi"))) {
							if (vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != iParam0 &&
								vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != 0) {
								return false;
							}
						}
						if (func_244(*uParam1, func_10(), 1)) {
							sVar0 = script::get_this_script_name();
							if (!gameplay::are_strings_equal(sVar0, "save_anywhere")) {
								return false;
							}
							else if (!ped::is_ped_in_any_vehicle(iParam0, 1)) {
								return false;
							}
						}
						if (iParam3 == 1) {
							if (decorator::decor_exist_on(*uParam1, "IgnoredByQuickSave")) {
								if (decorator::decor_get_bool(*uParam1, "IgnoredByQuickSave")) {
									return false;
								}
							}
						}
						else if (vehicle::is_vehicle_model(*uParam1, joaat("blimp"))) {
							return false;
						}
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0xCB82
bool func_244(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_245(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0xCBF3
bool func_245(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0xCCCB
void func_246(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = func_14(iParam0);
		iVar1 = 0;
		while (iVar1 < 12) {
			func_251(iParam0, iVar1, &uParam1->f_13[iVar1], &(*uParam1)[iVar1], &uParam1->f_26[iVar1], iParam2, 145);
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 9) {
			func_250(iParam0, iVar1, &uParam1->f_39[iVar1], &uParam1->f_49[iVar1], iParam2, 145);
			iVar1++;
		}
		if (func_13(iVar0)) {
			uParam1->f_59 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_59;
			uParam1->f_60 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_60;
			uParam1->f_61 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_61;
			uParam1->f_62 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_62;
			uParam1->f_63 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_63;
			uParam1->f_64 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_64;
		}
		else if (network::network_is_game_in_progress() &&
				 entity::get_entity_model(iParam0) == entity::get_entity_model(player::player_ped_id())) {
			if (func_249(161, -1)) {
				uParam1->f_59 = func_247(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_247(747, Global_69521, 0);
			}
			uParam1->f_60 = func_247(748, Global_69521, 0);
			uParam1->f_61 = func_247(749, Global_69521, 0);
		}
		if (network::network_is_game_in_progress() && iParam0 == player::player_ped_id()) {
			if (func_249(161, -1)) {
				uParam1->f_59 = func_247(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_247(747, Global_69521, 0);
			}
		}
	}
}

// Position - 0xCE75
int func_247(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_248(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0xCEA7
int func_248(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_187();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0xCEDB
bool func_249(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_248(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return false;
}

// Position - 0xCF07
void func_250(int iParam0, int iParam1, int *iParam2, int *iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_prop_index(iParam0, iParam1);
		*iParam3 = ped::get_ped_prop_texture_index(iParam0, iParam1);
	}
	else {
		iVar0 = iParam5;
	}
	if (iParam4 == 0) {
		return;
	}
	if (iParam1 == 0) {
		if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
			if (iParam0 != 0) {
				if (ped::is_ped_wearing_helmet(iParam0) && ped::_0x451294E859ECC018(iParam0) != -1) {
					*iParam2 = ped::_0x451294E859ECC018(iParam0);
					*iParam3 = ped::_0x9D728C1E12BF5518(iParam0);
				}
			}
		}
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 0) {
			if (*iParam2 == 7) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 28) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		else if (iParam1 == 1) {
			if (*iParam2 == 1) {
				if ((iParam4 & 2) != 0 || (iParam4 & 64) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 0) {
			if (*iParam2 == 2) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 4) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 6) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 17) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 20) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 8 && *iParam2 <= 14) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 0) {
			if (*iParam2 == 9) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 12) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20 || *iParam2 == 2) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;
	}
}

// Position - 0xD44F
void func_251(int iParam0, int iParam1, int *iParam2, int *iParam3, var *uParam4, int iParam5, int iParam6) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_drawable_variation(iParam0, iParam1);
		*iParam3 = ped::get_ped_texture_variation(iParam0, iParam1);
		*uParam4 = ped::get_ped_palette_variation(iParam0, iParam1);
	}
	else {
		iVar0 = iParam6;
	}
	if (iParam5 == 0) {
		return;
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 15) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 3 || *iParam2 == 22) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 8) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 1 || *iParam2 == 10) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 19) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 3) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if (*iParam2 >= 5 && *iParam2 <= 7) {
				if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0xD690
int func_252() {
	func_11();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0xD6A9
void func_253(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_14(iParam0);
	if (func_13(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			func_254(iParam0, &Global_101700.f_2095.f_539.f_298[iVar0 /*284*/]);
			iVar2 = 0;
			while (iVar2 <= 8 - 1) {
				Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] = ui::_0xA13E93403F26C812(iVar2);
				if (iParam1) {
					iVar1 = ui::_0xA48931185F0536FE();
					if (Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] == iVar1) {
						Global_101700.f_2095.f_539.f_1184 = iVar2;
					}
				}
				iVar2++;
			}
			player::get_player_parachute_pack_tint_index(player::player_id(), &iVar3);
			if (iVar0 == 0) {
				stats::stat_set_int(joaat("sp0_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 1) {
				stats::stat_set_int(joaat("sp1_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 2) {
				stats::stat_set_int(joaat("sp2_parachute_current_tint"), iVar3, 1);
			}
		}
	}
}

// Position - 0xD79C
void func_254(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	int iVar7;
	int iVar8;
	struct<2> Var9;
	struct<4> Var48;
	int iVar70;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			(*uParam1)[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			iVar3 = func_258(iVar0);
			if (iVar3 != 0) {
				vVar4.x = weapon::get_ped_weapontype_in_slot(iParam0, func_258(iVar0));
				vVar4.y = 0;
				vVar4.z = 0;
				if (vVar4.x != 0 && vVar4.x != joaat("weapon_unarmed")) {
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (vVar4.x == joaat("gadget_parachute")) {
						vVar4.y = 1;
					}
					gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					(*uParam1)[iVar0 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					iVar2 = func_256(vVar4.x, iVar1);
					while (iVar2 != 0) {
						if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, iVar2)) {
							gameplay::set_bit(&vVar4.f_2, iVar1);
						}
						iVar1++;
						iVar2 = func_256(vVar4.x, iVar1);
					}
				}
				(*uParam1)[iVar0 /*3*/] = {vVar4};
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 50 - 1) {
			uParam1->f_133[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar8 = dlc1::get_num_dlc_weapons();
		iVar7 = 0;
		while (iVar7 < iVar8) {
			if (dlc1::get_dlc_weapon_data(iVar7, &Var9) && !func_255(Var9.f_1) && iVar70 < 50) {
				if (!dlc1::_is_dlc_data_empty(Var9)) {
					vVar4.x = Var9.f_1;
					vVar4.y = 0;
					vVar4.z = 0;
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					}
					else {
						gameplay::set_bit(&vVar4.f_2, 20);
					}
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					uParam1->f_133[iVar70 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					while (iVar1 < dlc1::get_num_dlc_weapon_components(iVar7)) {
						if (dlc1::get_dlc_weapon_component_data(iVar7, iVar1, &Var48)) {
							if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, Var48.f_3)) {
								gameplay::set_bit(&vVar4.f_2, iVar1);
							}
						}
						iVar1++;
					}
				}
				if (vVar4.x != 0) {
					if (!weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						vVar4.x = 0;
						vVar4.y = 0;
					}
				}
				uParam1->f_133[iVar70 /*3*/] = {vVar4};
				iVar70++;
			}
			iVar7++;
		}
	}
}

// Position - 0xDA00
int func_255(int iParam0) {
	if (network::network_is_game_in_progress()) {
	}
	else {
		switch (iParam0) {
		case joaat("weapon_pistol50"):
		case joaat("weapon_bullpupshotgun"):
		case joaat("weapon_assaultsmg"): return 0;

		case joaat("weapon_bottle"):
		case joaat("weapon_snspistol"):
		case joaat("weapon_gusenberg"): return 0;

		case joaat("weapon_heavypistol"):
		case joaat("weapon_specialcarbine"): return 0;

		case joaat("weapon_bullpuprifle"): return 0;

		case joaat("weapon_dagger"):
		case joaat("weapon_vintagepistol"): return 0;

		case joaat("weapon_firework"):
		case joaat("weapon_musket"): return 0;

		case joaat("weapon_heavyshotgun"):
		case joaat("weapon_marksmanrifle"): return 0;

		case joaat("weapon_hominglauncher"):
		case joaat("weapon_proxmine"): return 0;

		case joaat("weapon_combatpdw"):
		case joaat("weapon_knuckle"):
		case joaat("weapon_marksmanpistol"): return 0;

		case -947031628:
		case -572349828:
		case 392730790:
		case -1523701417:
		case -2112826155:
		case -664359727:
		case -1887867191:
		case -837150131:
		case -344484024:
		case joaat("weapon_flaregun"):
		case joaat("weapon_handcuffs"):
		case joaat("weapon_snowball"):
		case joaat("weapon_garbagebag"):
		case joaat("weapon_flashlight"):
		case joaat("weapon_switchblade"):
		case joaat("weapon_revolver"):
		case joaat("weapon_dbshotgun"):
		case joaat("weapon_compactrifle"):
		case 317205821:
		case -1121678507:
		case 125959754:
		case -853065399:
		case -1169823560:
		case -1810795771:
		case 419712736: return 1;
		}
	}
	return 0;
}

// Position - 0xDB6E
int func_256(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var *uVar2;
	struct<4> Var41;

	iVar0 = 0;
	switch (iParam0) {
	case joaat("weapon_pistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpistol_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_combatpistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_appistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_appistol_clip_01"); break;

		case 1: iVar0 = joaat("component_appistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_appistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_microsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_microsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_microsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_microsmg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_smg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_smg_clip_01"); break;

		case 1: iVar0 = joaat("component_smg_clip_02"); break;

		case 2: iVar0 = joaat("component_smg_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_pi_supp"); break;

		case 5: iVar0 = joaat("component_at_scope_macro_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_smg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_assaultrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_assaultrifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_at_ar_flsh"); break;

		case 5: iVar0 = joaat("component_at_scope_macro"); break;

		case 6: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 7: iVar0 = joaat("component_assaultrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_carbinerifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_carbinerifle_clip_01"); break;

		case 1: iVar0 = joaat("component_carbinerifle_clip_02"); break;

		case 2: iVar0 = joaat("component_carbinerifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_railcover_01"); break;

		case 4: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 5: iVar0 = joaat("component_at_ar_flsh"); break;

		case 6: iVar0 = joaat("component_at_scope_medium"); break;

		case 7: iVar0 = joaat("component_at_ar_supp"); break;

		case 8: iVar0 = joaat("component_carbinerifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_advancedrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_advancedrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_advancedrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_advancedrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_mg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_mg_clip_01"); break;

		case 1: iVar0 = joaat("component_mg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_scope_small_02"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_mg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_combatmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatmg_clip_01"); break;

		case 1: iVar0 = joaat("component_combatmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_scope_medium"); break;

		case 4: iVar0 = joaat("component_combatmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_pumpshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_sr_supp"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_pumpshotgun_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_assaultshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultshotgun_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultshotgun_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;
		}
		break;

	case joaat("weapon_sniperrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sniperrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_sniperrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_heavysniper"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_heavysniper_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;
		}
		break;

	case joaat("weapon_grenadelauncher"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_scope_small"); break;
		}
		break;

	case joaat("weapon_minigun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_minigun_clip_01"); break;
		}
		break;

	case joaat("weapon_assaultsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_assaultsmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_ar_supp_02"); break;
		}
		break;

	case joaat("weapon_pistol50"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol50_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol50_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol50_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpdw"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpdw_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpdw_clip_02"); break;

		case 2: iVar0 = joaat("component_combatpdw_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_small"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sawnoffshotgun_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_bullpuprifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_bullpuprifle_clip_01"); break;

		case 1: iVar0 = joaat("component_bullpuprifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 6: iVar0 = joaat("component_bullpuprifle_varmod_low"); break;
		}
		break;

	case joaat("weapon_snspistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_snspistol_clip_01"); break;

		case 1: iVar0 = joaat("component_snspistol_clip_02"); break;

		case 2: iVar0 = joaat("component_snspistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_specialcarbine"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_specialcarbine_clip_01"); break;

		case 1: iVar0 = joaat("component_specialcarbine_clip_02"); break;

		case 2: iVar0 = joaat("component_specialcarbine_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_medium"); break;

		case 5: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_specialcarbine_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_knuckle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_knuckle_varmod_pimp"); break;

		case 1: iVar0 = joaat("component_knuckle_varmod_ballas"); break;

		case 2: iVar0 = joaat("component_knuckle_varmod_dollar"); break;

		case 3: iVar0 = joaat("component_knuckle_varmod_diamond"); break;

		case 4: iVar0 = joaat("component_knuckle_varmod_hate"); break;

		case 5: iVar0 = joaat("component_knuckle_varmod_love"); break;

		case 6: iVar0 = joaat("component_knuckle_varmod_player"); break;

		case 7: iVar0 = joaat("component_knuckle_varmod_king"); break;

		case 8: iVar0 = joaat("component_knuckle_varmod_vagos"); break;
		}
		break;

	case joaat("weapon_machinepistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_machinepistol_clip_01"); break;

		case 1: iVar0 = joaat("component_machinepistol_clip_02"); break;

		case 2: iVar0 = joaat("component_machinepistol_clip_03"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;
		}
		break;

	case joaat("weapon_switchblade"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_switchblade_varmod_var1"); break;

		case 1: iVar0 = joaat("component_switchblade_varmod_var2"); break;
		}
		break;

	case joaat("weapon_revolver"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_revolver_clip_01"); break;

		case 1: iVar0 = joaat("component_revolver_varmod_boss"); break;

		case 2: iVar0 = joaat("component_revolver_varmod_goon"); break;
		}
		break;

	case -1121678507:
		switch (iParam1) {
		case 0: iVar0 = -2067221805; break;

		case 1: iVar0 = -1820405577; break;
		}
		break;

	default:
		if (iParam0 != 0) {
			iVar1 = func_257(iParam0, &uVar2);
			if (iVar1 != -1) {
				if (iParam1 < dlc1::get_num_dlc_weapon_components(iVar1)) {
					if (dlc1::get_dlc_weapon_component_data(iVar1, iParam1, &Var41)) {
						return Var41.f_3;
					}
				}
			}
		}
		break;
	}
	return iVar0;
}

// Position - 0xE65A
int func_257(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xE695
int func_258(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (iParam0) {
	case 0: iVar0 = 1993361168; break;

	case 1: iVar0 = 1277010230; break;

	case 2: iVar0 = 932043479; break;

	case 3: iVar0 = -690654591; break;

	case 4: iVar0 = -1459198205; break;

	case 5: iVar0 = 195782970; break;

	case 6: iVar0 = -438797331; break;

	case 7: iVar0 = 896793492; break;

	case 8: iVar0 = 495159329; break;

	case 9: iVar0 = -1155528315; break;

	case 10: iVar0 = -515636489; break;

	case 11: iVar0 = -871913299; break;

	case 12: iVar0 = -1352759032; break;

	case 13: iVar0 = -542958961; break;

	case 14: iVar0 = 1682645887; break;

	case 15: iVar0 = -859470162; break;

	case 16: iVar0 = -2125426402; break;

	case 17: iVar0 = 2067210266; break;

	case 18: iVar0 = -538172856; break;

	case 19: iVar0 = 1783244476; break;

	case 20: iVar0 = 439844898; break;

	case 21: iVar0 = -24829327; break;

	case 22: iVar0 = 1949306232; break;

	case 23: iVar0 = -1941230881; break;

	case 24: iVar0 = -1033554448; break;

	case 25: iVar0 = 320513715; break;

	case 26: iVar0 = -695165975; break;

	case 27: iVar0 = -281028447; break;

	case 28: iVar0 = -686713772; break;

	case 29: iVar0 = 347509793; break;

	case 30: iVar0 = 1769089473; break;

	case 31: iVar0 = 189935548; break;

	case 33: iVar0 = 248801358; break;

	case 34: iVar0 = 386596758; break;

	case 35: iVar0 = -157212362; break;

	case 36: iVar0 = 436985596; break;

	case 37: iVar0 = -47957369; break;

	case 38: iVar0 = 575938238; break;
	}
	return iVar0;
}

// Position - 0xE909
void func_259(int iParam0) {
	int iVar0;

	iVar0 = func_14(iParam0);
	if (func_13(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_294[iVar0] = ped::get_ped_armour(iParam0);
	}
}

// Position - 0xE945
void func_260(var *uParam0, int iParam1) {
	int iVar0;
	vector3 vVar1;
	float *fVar4;
	int iVar5;

	*uParam0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	uParam0->f_3 = entity::get_entity_heading(player::player_ped_id());
	uParam0->f_5 = ped::get_ped_parachute_state(player::player_ped_id());
	if (player::is_player_playing(player::player_id())) {
		uParam0->f_4 = player::get_player_wanted_level(player::player_id());
	}
	if (system::vdist(*uParam0, 320.9934f, 265.2515f, 82.1221f) < 10f) {
		*uParam0 = {301.2162f, 202.1357f, 103.3797f};
		uParam0->f_3 = 156.5144f;
	}
	else if (system::vdist(*uParam0, 377.153f, -717.567f, 10.0536f) < 10f) {
		*uParam0 = {394.2567f, -713.5439f, 28.2853f};
		uParam0->f_3 = 276.6273f;
	}
	else if (system::vdist(*uParam0, -1425.564f, -244.3f, 15.8053f) < 10f) {
		*uParam0 = {-1423.472f, -214.2539f, 45.5004f};
		uParam0->f_3 = 353.8757f;
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("finale_choice")) > 0) {
		*uParam0 = {4.2587f, 525.0214f, 173.6281f};
		uParam0->f_3 = 203.6746f;
	}
	else if (gameplay::is_bit_set(Global_69950, 4)) {
		*uParam0 = {452.0255f, 5571.85f, 780.1859f};
		uParam0->f_3 = 78.9858f;
	}
	else if (gameplay::is_bit_set(Global_69950, 5)) {
		*uParam0 = {-745.4462f, 5595.146f, 40.6594f};
		uParam0->f_3 = 261.747f;
	}
	else if (gameplay::is_bit_set(Global_69950, 6)) {
		*uParam0 = {-1675.521f, -1125.59f, 12.091f};
		uParam0->f_3 = 271.8208f;
	}
	else if (gameplay::is_bit_set(Global_69950, 7)) {
		*uParam0 = {-1631.219f, -1112.805f, 12.0212f};
		uParam0->f_3 = 316.8879f;
	}
	else if (interior::get_interior_from_entity(player::player_ped_id()) ==
			 interior::get_interior_at_coords_with_type(1272.659f, -1715.467f, 53.7715f, "v_lesters")) {
		*uParam0 = {1276.956f, -1725.189f, 53.6551f};
		uParam0->f_3 = 204.1703f;
	}
	else if (entity::is_entity_in_angled_area(player::player_ped_id(), -415.4365f, 2068.289f, 113.3002f, -564.9516f,
											  1884.703f, 134.0403f, 258.75f, 0, 1, 0) ||
			 entity::is_entity_in_angled_area(player::player_ped_id(), -596.4706f, 2089.921f, 125.4128f, -581.2134f,
											  2036.256f, 136.2836f, 9.5f, 0, 1, 0)) {
		*uParam0 = {-601.59f, 2099.197f, 128.8928f};
		uParam0->f_3 = 204.7498f;
	}
	else if (system::vdist(*uParam0, -1007.393f, -477.9584f, 52.5357f) < 8f) {
		*uParam0 = {-1018.376f, -483.9436f, 36.0964f};
		uParam0->f_3 = 114.7664f;
	}
	else if (system::vdist(*uParam0, 480.6662f, -1317.808f, 28.20303f) < 15f) {
		*uParam0 = {497.7238f, -1310.932f, 28.2372f};
		uParam0->f_3 = 289.3663f;
	}
	else if (system::vdist(*uParam0, 2329.527f, 2571.311f, 45.6779f) < 5f) {
		*uParam0 = {2316.93f, 2594.153f, 45.7199f};
		uParam0->f_3 = 348.1325f;
	}
	if (iParam1 == 1) {
		if (func_263(&iVar0)) {
			if (func_262(iVar0, &vVar1, &fVar4)) {
				vVar1.z++;
				*uParam0 = {vVar1};
				uParam0->f_3 = fVar4;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 207.4336f, -1019.795f, -100.4728f, 189.9338f,
												  -1019.623f, -95.56883f, 17.1875f, 0, 1, 0)) {
			iVar5 = func_10();
			if (iVar5 == 0) {
				*uParam0 = {-65.1234f, 81.2517f, 70.5644f};
				uParam0->f_3 = 71.6237f;
			}
			else if (iVar5 == 1) {
				*uParam0 = {-68.5531f, -1824.377f, 25.9424f};
				uParam0->f_3 = 215.8295f;
			}
			else if (iVar5 == 2) {
				*uParam0 = {-220.8189f, -1162.302f, 22.0242f};
				uParam0->f_3 = 70.2711f;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 483.7175f, -1326.63f, 28.2135f, 474.9644f,
												  -1307.998f, 34.49498f, 12f, 0, 1, 0)) {
			*uParam0 = {495.4108f, -1306.08f, 29.2883f};
			uParam0->f_3 = 213.6273f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), -1146.77f, -1534.22f, 3.37f, -1158.453f,
												  -1517.75f, 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_3 = 305.6424f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 439.5432f, -996.9769f, 24.88307f, 428.2935f,
												  -997.0192f, 28.57458f, 8.5f, 0, 1, 0)) {
			*uParam0 = {431.8853f, -1013.133f, 28.7907f};
			uParam0->f_3 = 186.6814f;
		}
		else if (func_261(*uParam0, "v_hospital", 307.3065f, -589.9595f, 43.302f)) {
			*uParam0 = {279.4137f, -585.8815f, 43.2502f};
			uParam0->f_3 = 48.8028f;
		}
	}
}

// Position - 0xEEA0
bool func_261(vector3 vParam0, char *sParam3, vector3 vParam4) {
	int iVar0;
	int iVar1;

	if (!interior::_are_coords_colliding_with_exterior(vParam0)) {
		iVar0 = interior::get_interior_at_coords_with_type(vParam4, sParam3);
		if (!interior::is_valid_interior(iVar0)) {
			return false;
		}
		iVar1 = interior::get_interior_from_collision(vParam0);
		if (iVar1 == iVar0) {
			return true;
		}
	}
	return false;
}

// Position - 0xEEE4
bool func_262(int iParam0, var *uParam1, float *fParam2) {
	*uParam1 = {0f, 0f, 0f};
	*fParam2 = 0f;
	switch (iParam0) {
	case 0:
		*uParam1 = {-829.842f, -191.7454f, 36.4386f};
		*fParam2 = 29.5061f;
		break;

	case 1:
		*uParam1 = {129.8484f, -1716.528f, 28.0702f};
		*fParam2 = 50.3483f;
		break;

	case 2:
		*uParam1 = {-1296.913f, -1120.999f, 5.3951f};
		*fParam2 = 0.9933f;
		break;

	case 3:
		*uParam1 = {1938.028f, 3718.736f, 31.3154f};
		*fParam2 = 118.2305f;
		break;

	case 4:
		*uParam1 = {1197.866f, -469.3809f, 65.0885f};
		*fParam2 = 346.4477f;
		break;

	case 5:
		*uParam1 = {-32.2161f, -135.8212f, 56.0532f};
		*fParam2 = 186.0052f;
		break;

	case 6:
		*uParam1 = {-287.7696f, 6238.081f, 30.2902f};
		*fParam2 = 316.1349f;
		break;

	case 7:
		*uParam1 = {99.2876f, -1395.16f, 28.2759f};
		*fParam2 = 320.2739f;
		break;

	case 8:
		*uParam1 = {1679.445f, 4819.056f, 41.0035f};
		*fParam2 = 4.6192f;
		break;

	case 9:
		*uParam1 = {411.3063f, -809.1863f, 28.1554f};
		*fParam2 = 1.8972f;
		break;

	case 10:
		*uParam1 = {-1088.054f, 2699.167f, 19.2748f};
		*fParam2 = 129.7382f;
		break;

	case 11:
		*uParam1 = {1194.163f, 2695.644f, 36.9225f};
		*fParam2 = 1.1454f;
		break;

	case 12:
		*uParam1 = {-821.2829f, -1088.027f, 10.0499f};
		*fParam2 = 120.5883f;
		break;

	case 13:
		*uParam1 = {-3.3416f, 6521.303f, 30.2961f};
		*fParam2 = 316.4451f;
		break;

	case 14:
		*uParam1 = {-1208.417f, -785.9635f, 16.0139f};
		*fParam2 = 36.3181f;
		break;

	case 15:
		*uParam1 = {623.1845f, 2739.191f, 40.9588f};
		*fParam2 = 3.5411f;
		break;

	case 16:
		*uParam1 = {130.9555f, -198.2084f, 53.41f};
		*fParam2 = 251.3506f;
		break;

	case 17:
		*uParam1 = {-3164.065f, 1067.317f, 19.6778f};
		*fParam2 = 101.2229f;
		break;

	case 18:
		*uParam1 = {-713.2797f, -174.2767f, 35.8962f};
		*fParam2 = 29.8138f;
		break;

	case 19:
		*uParam1 = {-147.0616f, -306.4322f, 37.7912f};
		*fParam2 = 160.4526f;
		break;

	case 20:
		*uParam1 = {-1461.355f, -230.6092f, 48.3064f};
		*fParam2 = 318.7851f;
		break;

	case 21:
		*uParam1 = {-1347.739f, -1278.573f, 3.8952f};
		*fParam2 = 17.9365f;
		break;

	case 22:
		*uParam1 = {325.6833f, 164.3263f, 102.4425f};
		*fParam2 = 68.6407f;
		break;

	case 23:
		*uParam1 = {1858.774f, 3742.393f, 32.0779f};
		*fParam2 = 301.2329f;
		break;

	case 24:
		*uParam1 = {-286.3272f, 6202.802f, 30.3323f};
		*fParam2 = 225.1334f;
		break;

	case 25:
		*uParam1 = {-1161.596f, -1417.7f, 3.712f};
		*fParam2 = 246.9161f;
		break;

	case 26:
		*uParam1 = {1308.952f, -1660.611f, 50.2362f};
		*fParam2 = 163.5456f;
		break;

	case 27:
		*uParam1 = {-3161.585f, 1074.214f, 19.6847f};
		*fParam2 = 98.6092f;
		break;

	case 28:
		*uParam1 = {28.423f, -1110.814f, 28.2848f};
		*fParam2 = 85.2495f;
		break;

	case 29:
		*uParam1 = {1704.966f, 3749.709f, 33.0188f};
		*fParam2 = 45.6778f;
		break;

	case 30:
		*uParam1 = {223.949f, -38.7894f, 68.6483f};
		*fParam2 = 159.4265f;
		break;

	case 31:
		*uParam1 = {837.7854f, -1017.963f, 26.3045f};
		*fParam2 = 181.0445f;
		break;

	case 32:
		*uParam1 = {-313.1914f, 6093.351f, 30.4625f};
		*fParam2 = 315.8405f;
		break;

	case 33:
		*uParam1 = {-663.4631f, -952.8069f, 20.3143f};
		*fParam2 = 92.6796f;
		break;

	case 34:
		*uParam1 = {-1323.06f, -392.8577f, 35.4596f};
		*fParam2 = 210.7398f;
		break;

	case 35:
		*uParam1 = {-1106.102f, 2684.35f, 18.0953f};
		*fParam2 = 127.0383f;
		break;

	case 36:
		*uParam1 = {-3157.932f, 1081.309f, 19.6953f};
		*fParam2 = 100.2942f;
		break;

	case 37:
		*uParam1 = {2562.882f, 312.8641f, 107.4612f};
		*fParam2 = 179.205f;
		break;

	case 38:
		*uParam1 = {822.48f, -2142.875f, 27.8496f};
		*fParam2 = 355.0598f;
		break;

	case 39:
		*uParam1 = {-1137.053f, -1993.916f, 12.1677f};
		*fParam2 = 43.1213f;
		break;

	case 40:
		*uParam1 = {717.8107f, -1084.081f, 21.3094f};
		*fParam2 = 93.2649f;
		break;

	case 41:
		*uParam1 = {-387.6789f, -128.2568f, 37.6796f};
		*fParam2 = 119.1085f;
		break;

	case 42:
		*uParam1 = {117.8835f, 6599.415f, 31.0134f};
		*fParam2 = 90.7225f;
		break;

	case 43:
		*uParam1 = {1201.709f, 2664.813f, 36.8102f};
		*fParam2 = 133.9002f;
		break;

	case 44:
		*uParam1 = {-200.1521f, -1297.502f, 30.296f};
		*fParam2 = 269.0687f;
		break;

	case 45:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		break;
	}
	return !func_23(*uParam1, 0f, 0f, 0f, 0);
}

// Position - 0xF573
bool func_263(int *iParam0) {
	if (!entity::is_entity_dead(player::player_ped_id(), 0) && !ped::is_ped_injured(player::player_ped_id())) {
		if (func_274()) {
			*iParam0 = func_269(entity::get_entity_coords(player::player_ped_id(), 0), 6, -1, 0, 1, -1);
			if (func_268(*iParam0) && !func_264(*iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0xF5CE
int func_264(int iParam0) { return func_265(iParam0, 0, 1); }

// Position - 0xF5DE
int func_265(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		return gameplay::is_bit_set(Global_91543.f_1308[iParam0], iParam1);
	}
	else if (network::network_is_game_in_progress()) {
		if (func_267() == 0) {
			return gameplay::is_bit_set(func_247(func_266(iParam0), -1, 0), iParam1);
		}
	}
	else {
		return gameplay::is_bit_set(Global_101700.f_668[iParam0], iParam1);
	}
	return 0;
}

// Position - 0xF63E
int func_266(int iParam0) {
	switch (iParam0) {
	case 0: return 822;

	case 1: return 823;

	case 2: return 824;

	case 3: return 825;

	case 4: return 826;

	case 5: return 827;

	case 6: return 828;

	case 7: return 829;

	case 8: return 830;

	case 9: return 831;

	case 10: return 832;

	case 11: return 833;

	case 12: return 834;

	case 13: return 835;

	case 14: return 836;

	case 15: return 838;

	case 16: return 839;

	case 17: return 840;

	case 18: return 841;

	case 19: return 842;

	case 20: return 843;

	case 21: return 844;

	case 22: return 845;

	case 23: return 846;

	case 24: return 847;

	case 25: return 848;

	case 26: return 849;

	case 27: return 850;

	case 28: return 851;

	case 29: return 852;

	case 30: return 853;

	case 31: return 854;

	case 32: return 855;

	case 33: return 856;

	case 34: return 857;

	case 35: return 858;

	case 36: return 859;

	case 37: return 860;

	case 38: return 861;

	case 39: return 862;

	case 40: return 866;

	case 41: return 867;

	case 42: return 868;

	case 43: return 869;

	case 44: return 5847;

	case 45: return 3780;

	default: break;
	}
	return 6022;
}

// Position - 0xF905
int func_267() { return Global_25190; }

// Position - 0xF910
int func_268(int iParam0) { return func_265(iParam0, 5, 1); }

// Position - 0xF920
int func_269(vector3 vParam0, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = -1;
	iVar0 = 0;
	while (iVar0 <= 45) {
		if (iParam3 == 6 || iParam3 == func_273(iVar0)) {
			if (!iParam5 || func_272(iVar0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, func_270(iVar0, 0), 1);
				if (fVar1 < fVar2 && (fVar1 <= IntToFloat(iParam4) || iParam4 == -1) && (iParam6 || iVar0 != 21) &&
					iVar0 != iParam7) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0xF9C2
Vector3 func_270(int iParam0, int iParam1) {
	switch (iParam0) {
	case -1: return 0f, 0f, 0f;

	case 0: return -821.9946f, -187.1776f, 36.5689f;

	case 1: return 133.5702f, -1710.918f, 28.2916f;

	case 2: return -1287.082f, -1116.558f, 5.9901f;

	case 3: return 1933.119f, 3726.079f, 31.8444f;

	case 4: return 1208.333f, -470.917f, 65.208f;

	case 5: return -30.7448f, -148.4921f, 56.0765f;

	case 6: return -280.8165f, 6231.771f, 30.6955f;

	case 7: return 80.665f, -1391.669f, 28.3761f;

	case 8: return 1687.881f, 4820.55f, 41.0096f;

	case 9: return 419.531f, -807.5787f, 28.4896f;

	case 10: return -1094.049f, 2704.171f, 18.0873f;

	case 11: return 1197.972f, 2704.22f, 37.1572f;

	case 12: return -818.6218f, -1077.533f, 10.3282f;

	case 13: return -0.2361f, 6516.045f, 30.8684f;

	case 14: return -1199.809f, -776.6886f, 16.3237f;

	case 15: return 618.1857f, 2752.567f, 41.0881f;

	case 16: return 126.6853f, -212.5027f, 53.5578f;

	case 17: return -3168.966f, 1055.287f, 19.8632f;

	case 18: return -715.3598f, -155.7742f, 36.4105f;

	case 19: return -158.2199f, -304.9663f, 38.735f;

	case 20: return -1455.005f, -233.1862f, 48.7936f;

	case 21: return -1335.973f, -1278.555f, 3.8598f;

	case 22: return 321.6098f, 179.4165f, 102.5865f;

	case 23: return 1861.685f, 3750.08f, 32.0318f;

	case 24: return -290.1603f, 6199.095f, 30.4871f;

	case 25: return -1153.948f, -1425.019f, 3.9544f;

	case 26: return 1322.455f, -1651.125f, 51.1885f;

	case 27: return -3169.42f, 1074.727f, 19.8343f;

	case 28: return 17.6804f, -1114.288f, 28.797f;

	case 29: return 1697.979f, 3753.2f, 33.7053f;

	case 30: return 245.2711f, -45.8126f, 68.941f;

	case 31: return 844.1248f, -1025.571f, 27.1948f;

	case 32: return -325.8904f, 6077.026f, 30.4548f;

	case 33: return -664.2178f, -943.3646f, 20.8292f;

	case 34: return -1313.948f, -390.9637f, 35.592f;

	case 35: return -1111.238f, 2688.463f, 17.6131f;

	case 36: return -3165.231f, 1082.855f, 19.8438f;

	case 37: return 2569.612f, 302.576f, 107.7349f;

	case 38: return 811.8699f, -2149.102f, 28.6363f;

	case 39: return -1147.314f, -1992.434f, 12.1803f;

	case 40: return 724.524f, -1089.081f, 21.1692f;

	case 41: return -354.5272f, -135.4011f, 38.185f;

	case 42: return 113.2615f, 6624.28f, 30.7871f;

	case 43: return 1174.707f, 2644.45f, 36.7552f;

	case 44:
		if (iParam1) {
			return -211.5f, -1324.2f, 30.296f;
		}
		else {
			return -205.6654f, -1311.113f, 30.296f;
		}
		break;

	case 45: return func_271(Global_93004);
	}
	return 1000000f, 1000000f, 1000000f;
}

// Position - 0xFEDC
Vector3 func_271(int iParam0) {
	switch (iParam0) {
	case 1: return 1060f, -2990f, -35f;

	case 2: return 1060f, -2990f, -35f;

	case 3: return 974.9542f, -3000.091f, -35f;

	case 6: return -1586.36f, -566.6f, 106.17f;

	case 7: return -1389.87f, -465.17f, 82.68f;

	case 8: return -145.81f, -590.2f, 171.13f;

	case 9: return -62.49f, -823.55f, 288.74f;

	case 4: return 1102.515f, -3158.888f, -38.5186f;

	case 5: return 1005.861f, -3156.162f, -39.907f;

	default: return 0f, 0f, -200f;
	}
	return 0f, 0f, -200f;
}

// Position - 0xFFF2
int func_272(int iParam0) { return func_265(iParam0, 0, 0); }

// Position - 0x10003
int func_273(int iParam0) {
	switch (iParam0) {
	case -1: return 6;

	case 0: return 0;

	case 1: return 0;

	case 2: return 0;

	case 3: return 0;

	case 4: return 0;

	case 5: return 0;

	case 6: return 0;

	case 7: return 1;

	case 8: return 1;

	case 9: return 1;

	case 10: return 1;

	case 11: return 1;

	case 12: return 1;

	case 13: return 1;

	case 14: return 1;

	case 15: return 1;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 2;

	case 23: return 2;

	case 24: return 2;

	case 25: return 2;

	case 26: return 2;

	case 27: return 2;

	case 28: return 3;

	case 29: return 3;

	case 30: return 3;

	case 31: return 3;

	case 32: return 3;

	case 33: return 3;

	case 34: return 3;

	case 35: return 3;

	case 36: return 3;

	case 37: return 3;

	case 38: return 3;

	case 39: return 4;

	case 40: return 4;

	case 41: return 4;

	case 42: return 4;

	case 43: return 4;

	case 44: return 4;

	case 45: return 5;
	}
	return 6;
}

// Position - 0x10276
bool func_274() { return Global_91543.f_303 > 0; }

// Position - 0x10287
var func_275() {
	int *iVar0;

	func_285(&iVar0, time::get_clock_seconds());
	func_284(&iVar0, time::get_clock_minutes());
	func_283(&iVar0, time::get_clock_hours());
	func_278(&iVar0, time::get_clock_day_of_month());
	func_277(&iVar0, time::get_clock_month());
	func_276(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x102CD
void func_276(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x10353
void func_277(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x10386
void func_278(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_282(*uParam0);
	iVar1 = func_280(*uParam0);
	if (iParam1 < 1 || iParam1 > func_279(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x103D7
int func_279(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x10479
var func_280(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_281(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x1049E
int func_281(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x104B5
int func_282(var uParam0) { return uParam0 & 15; }

// Position - 0x104C2
void func_283(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x104FC
void func_284(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x10537
void func_285(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x10573
int func_286(char *sParam0) {
	if (gameplay::are_strings_equal("BailBond1", sParam0)) {
		return 0;
	}
	else if (gameplay::are_strings_equal("BailBond2", sParam0)) {
		return 1;
	}
	else if (gameplay::are_strings_equal("BailBond3", sParam0)) {
		return 2;
	}
	else if (gameplay::are_strings_equal("BailBond4", sParam0)) {
		return 3;
	}
	return -1;
}

// Position - 0x105C9
struct<2> func_287(int iParam0) {
	struct<2> Var0;

	StringCopy(&Var0, "", 8);
	switch (iParam0) {
	case 0: StringCopy(&Var0, "ABI1", 8); break;

	case 1: StringCopy(&Var0, "ABI2", 8); break;

	case 2: StringCopy(&Var0, "BA1", 8); break;

	case 3: StringCopy(&Var0, "BA2", 8); break;

	case 4: StringCopy(&Var0, "BA3", 8); break;

	case 5: StringCopy(&Var0, "BA3A", 8); break;

	case 6: StringCopy(&Var0, "BA3C", 8); break;

	case 7: StringCopy(&Var0, "BA4", 8); break;

	case 8: StringCopy(&Var0, "DRE1", 8); break;

	case 9: StringCopy(&Var0, "EPS1", 8); break;

	case 10: StringCopy(&Var0, "EPS2", 8); break;

	case 11: StringCopy(&Var0, "EPS3", 8); break;

	case 12: StringCopy(&Var0, "EPS4", 8); break;

	case 13: StringCopy(&Var0, "EPS5", 8); break;

	case 14: StringCopy(&Var0, "EPS6", 8); break;

	case 15: StringCopy(&Var0, "EPS7", 8); break;

	case 16: StringCopy(&Var0, "EPS8", 8); break;

	case 17: StringCopy(&Var0, "EXT1", 8); break;

	case 18: StringCopy(&Var0, "EXT2", 8); break;

	case 19: StringCopy(&Var0, "EXT3", 8); break;

	case 20: StringCopy(&Var0, "EXT4", 8); break;

	case 21: StringCopy(&Var0, "FAN1", 8); break;

	case 22: StringCopy(&Var0, "FAN2", 8); break;

	case 23: StringCopy(&Var0, "FAN3", 8); break;

	case 24: StringCopy(&Var0, "HAO1", 8); break;

	case 25: StringCopy(&Var0, "HUN1", 8); break;

	case 26: StringCopy(&Var0, "HUN2", 8); break;

	case 27: StringCopy(&Var0, "JOS1", 8); break;

	case 28: StringCopy(&Var0, "JOS2", 8); break;

	case 29: StringCopy(&Var0, "JOS3", 8); break;

	case 30: StringCopy(&Var0, "JOS4", 8); break;

	case 31: StringCopy(&Var0, "MAU1", 8); break;

	case 32: StringCopy(&Var0, "MIN1", 8); break;

	case 33: StringCopy(&Var0, "MIN2", 8); break;

	case 34: StringCopy(&Var0, "MIN3", 8); break;

	case 35: StringCopy(&Var0, "MRS1", 8); break;

	case 36: StringCopy(&Var0, "MRS2", 8); break;

	case 37: StringCopy(&Var0, "NI1", 8); break;

	case 38: StringCopy(&Var0, "NI1A", 8); break;

	case 39: StringCopy(&Var0, "NI1B", 8); break;

	case 40: StringCopy(&Var0, "NI1C", 8); break;

	case 41: StringCopy(&Var0, "NI1D", 8); break;

	case 42: StringCopy(&Var0, "NI2", 8); break;

	case 43: StringCopy(&Var0, "NI3", 8); break;

	case 44: StringCopy(&Var0, "OME1", 8); break;

	case 45: StringCopy(&Var0, "OME2", 8); break;

	case 46: StringCopy(&Var0, "PA1", 8); break;

	case 47: StringCopy(&Var0, "PA2", 8); break;

	case 48: StringCopy(&Var0, "PA3", 8); break;

	case 49: StringCopy(&Var0, "PA3A", 8); break;

	case 50: StringCopy(&Var0, "PA3B", 8); break;

	case 51: StringCopy(&Var0, "PA4", 8); break;

	case 52: StringCopy(&Var0, "RAM1", 8); break;

	case 53: StringCopy(&Var0, "RAM2", 8); break;

	case 54: StringCopy(&Var0, "RAM3", 8); break;

	case 55: StringCopy(&Var0, "RAM4", 8); break;

	case 56: StringCopy(&Var0, "RAM5", 8); break;

	case 57: StringCopy(&Var0, "SAS1", 8); break;

	case 58: StringCopy(&Var0, "TON1", 8); break;

	case 59: StringCopy(&Var0, "TON2", 8); break;

	case 60: StringCopy(&Var0, "TON3", 8); break;

	case 61: StringCopy(&Var0, "TON4", 8); break;

	case 62: StringCopy(&Var0, "TON5", 8); break;

	default: break;
	}
	return Var0;
}

//Position - 0x10A15
int func_288(char* sParam0, int iParam1)
{
	int iVar0;
	char *sVar1;
	int iVar33;
	int iVar34;

	iVar33 = gameplay::get_hash_key(sParam0);
	iVar34 = 0;
	iVar34 = 0;
	while (iVar34 < 63) {
		iVar0 = iVar34;
		func_289(iVar0, &sVar1);
		if (gameplay::get_hash_key(sVar1) == iVar33) {
			return iVar0;
		}
		iVar34++;
	}
	if (iParam1 == 0) {
	}
	return -1;
}

// Position - 0x10A5E
void func_289(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		func_290(uParam1, "Abigail1", func_292(iParam0), 0, 0, 4, -1604.668f, 5239.1f, 3.01f, 66, "", 109, 0,
				 "ambient_Diving", 0, 0, 1, 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 1:
		func_290(uParam1, "Abigail2", func_292(iParam0), 0, 0, 4, -1592.84f, 5214.04f, 3.01f, 400, "", 110, 0, "", 0, 0,
				 -1, 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 2:
		func_290(uParam1, "Barry1", func_292(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", 74, 0, "", 0, 1, -1,
				 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 3:
		func_290(uParam1, "Barry2", func_292(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", -1, 0, "", 0, 1, -1,
				 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 4:
		func_290(uParam1, "Barry3", func_292(iParam0), 0, 1, 4, 414f, -761f, 29f, 381, "", -1, 0, "", 164, 1, -1, 0, 2,
				 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 5:
		func_290(uParam1, "Barry3A", func_292(iParam0), 1, 1, 0, 1199.27f, -1255.63f, 34.23f, 381, "BARSTASH", 84, 0,
				 "", 166, 0, 7, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 6:
		func_290(uParam1, "Barry3C", func_292(iParam0), 3, 1, 0, -468.9f, -1713.06f, 18.21f, 381, "", 84, 0, "", 166, 0,
				 7, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 7:
		func_290(uParam1, "Barry4", func_292(iParam0), 0, 1, 4, 237.65f, -385.41f, 44.4f, 381, "", 85, 0,
				 "postRC_Barry4", 0, 0, -1, 4, 2, 800, 2000, func_291(iParam0), 0, 0);
		break;

	case 8:
		func_290(uParam1, "Dreyfuss1", func_292(iParam0), 0, 2, 4, -1458.97f, 485.99f, 115.38f, 66, "LETTERS_HINT", 106,
				 0, "", 0, 0, -1, 4, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 9:
		func_290(uParam1, "Epsilon1", func_292(iParam0), 0, 3, 4, -1622.89f, 4204.87f, 83.3f, 66, "", 86, 0, "", 0, 1,
				 10, 4, 1, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 10:
		func_290(uParam1, "Epsilon2", func_292(iParam0), 0, 3, 4, 242.7f, 362.7f, 104.74f, 206, "", 87, 16, "", 0, 0,
				 11, 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 11:
		func_290(uParam1, "Epsilon3", func_292(iParam0), 0, 3, 4, 1835.53f, 4705.86f, 38.1f, 206, "", 88, 16, "epsCars",
				 0, 0, 12, 4, 1, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 12:
		func_290(uParam1, "Epsilon4", func_292(iParam0), 0, 3, 4, 1826.13f, 4698.88f, 38.92f, 206, "", 90, 16,
				 "postRC_Epsilon4", 0, 0, 13, 4, 1, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 13:
		func_290(uParam1, "Epsilon5", func_292(iParam0), 0, 3, 4, 637.02f, 119.7093f, 89.5f, 206, "", 89, 16,
				 "epsRobes", 0, 0, 14, 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 14:
		func_290(uParam1, "Epsilon6", func_292(iParam0), 0, 3, 4, -2892.93f, 3192.37f, 11.66f, 206, "", 93, 0, "", 0, 0,
				 15, 4, 1, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 15:
		func_290(uParam1, "Epsilon7", func_292(iParam0), 0, 3, 4, 524.43f, 3079.82f, 39.48f, 206, "", -1, 16,
				 "epsDesert", 0, 0, 16, 4, 1, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 16:
		func_290(uParam1, "Epsilon8", func_292(iParam0), 0, 3, 4, -697.75f, 45.38f, 43.03f, 206, "", 94, 16,
				 "epsilonTract", 0, 0, -1, 4, 1, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 17:
		func_290(uParam1, "Extreme1", func_292(iParam0), 0, 4, 4, -188.22f, 1296.1f, 302.86f, 66, "", -1, 0, "", 4, 1,
				 18, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 18:
		func_290(uParam1, "Extreme2", func_292(iParam0), 0, 4, 4, -954.19f, -2760.05f, 14.64f, 382, "", 96, 0, "", 171,
				 0, 19, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 19:
		func_290(uParam1, "Extreme3", func_292(iParam0), 0, 4, 4, -63.8f, -809.5f, 321.8f, 382, "", 97, 0, "", 0, 0, 20,
				 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 20:
		func_290(uParam1, "Extreme4", func_292(iParam0), 0, 4, 4, 1731.41f, 96.96f, 170.39f, 382, "", 98, 16, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 21:
		func_290(uParam1, "Fanatic1", func_292(iParam0), 0, 5, 4, -1877.82f, -440.649f, 45.05f, 405, "", 74, 0, "", 0,
				 1, -1, 4, 1, 700, 2000, func_291(iParam0), 1, 0);
		break;

	case 22:
		func_290(uParam1, "Fanatic2", func_292(iParam0), 0, 5, 4, 809.66f, 1279.76f, 360.49f, 405, "", -1, 0, "", 0, 1,
				 -1, 4, 4, 700, 2000, func_291(iParam0), 1, 0);
		break;

	case 23:
		func_290(uParam1, "Fanatic3", func_292(iParam0), 0, 5, 4, -915.6f, 6139.2f, 5.5f, 405, "", -1, 0, "", 0, 1, -1,
				 4, 2, 700, 2000, func_291(iParam0), 0, 1);
		break;

	case 24:
		func_290(uParam1, "Hao1", func_292(iParam0), 0, 6, 4, -72.29f, -1260.63f, 28.14f, 66, "", -1, 0,
				 "controller_Races", 13, 1, -1, 4, 2, 2000, 500, func_291(iParam0), 0, 1);
		break;

	case 25:
		func_290(uParam1, "Hunting1", func_292(iParam0), 0, 7, 4, 1804.32f, 3931.33f, 32.82f, 66, "", -1, 0, "", 174, 1,
				 26, 4, 4, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 26:
		func_290(uParam1, "Hunting2", func_292(iParam0), 0, 7, 4, -684.17f, 5839.16f, 16.09f, 384, "", 99, 0, "", 7, 0,
				 -1, 4, 4, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 27:
		func_290(uParam1, "Josh1", func_292(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 66, "", -1, 0, "forSaleSigns",
				 0, 1, 28, 4, 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 28:
		func_290(uParam1, "Josh2", func_292(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", 105, 0, "", 0, 0,
				 29, 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 29:
		func_290(uParam1, "Josh3", func_292(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", -1, 16, "", 0, 0,
				 30, 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 30:
		func_290(uParam1, "Josh4", func_292(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 385, "", -1, 36, "", 0, 0, -1,
				 4, 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 31:
		func_290(uParam1, "Maude1", func_292(iParam0), 0, 9, 4, 2726.1f, 4145f, 44.3f, 66, "", -1, 0,
				 "BailBond_Launcher", 0, 1, -1, 4, 4, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 32:
		func_290(uParam1, "Minute1", func_292(iParam0), 0, 10, 4, 327.85f, 3405.7f, 35.73f, 66, "", -1, 0, "", 0, 1, 33,
				 4, 4, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 33:
		func_290(uParam1, "Minute2", func_292(iParam0), 0, 10, 4, 18f, 4527f, 105f, 386, "", -1, 10, "", 0, 0, 34, 4, 4,
				 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 34:
		func_290(uParam1, "Minute3", func_292(iParam0), 0, 10, 4, -303.82f, 6211.29f, 31.05f, 386, "", -1, 10, "", 0, 0,
				 -1, 4, 4, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 35:
		func_290(uParam1, "MrsPhilips1", func_292(iParam0), 0, 11, 4, 1972.59f, 3816.43f, 32.42f, 66, "", -1, 0,
				 "ambient_MrsPhilips", 0, 1, -1, 4, 4, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 36:
		func_290(uParam1, "MrsPhilips2", func_292(iParam0), 0, 11, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 1, -1, 4, 4, 0,
				 2359, func_291(iParam0), 0, 0);
		break;

	case 37:
		func_290(uParam1, "Nigel1", func_292(iParam0), 0, 12, 4, -1097.16f, 790.01f, 164.52f, 66, "", -1, 0, "", 177, 1,
				 -1, 1, 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 38:
		func_290(uParam1, "Nigel1A", func_292(iParam0), 0, 12, 1, -558.65f, 284.49f, 90.86f, 149, "NIGITEMS", 100, 0,
				 "", 0, 0, 42, 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 39:
		func_290(uParam1, "Nigel1B", func_292(iParam0), 0, 12, 1, -1034.15f, 366.08f, 80.11f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_291(iParam0), 1, 1);
		break;

	case 40:
		func_290(uParam1, "Nigel1C", func_292(iParam0), 0, 12, 1, -623.91f, -266.17f, 37.76f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_291(iParam0), 1, 1);
		break;

	case 41:
		func_290(uParam1, "Nigel1D", func_292(iParam0), 0, 12, 1, -1096.85f, 67.68f, 52.95f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_291(iParam0), 1, 1);
		break;

	case 42:
		func_290(uParam1, "Nigel2", func_292(iParam0), 0, 12, 4, -1310.7f, -640.22f, 26.54f, 149, "", -1, 8, "", 0, 0,
				 43, 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 43:
		func_290(uParam1, "Nigel3", func_292(iParam0), 0, 12, 4, -44.75f, -1288.67f, 28.21f, 149, "", -1, 16,
				 "postRC_Nigel3", 0, 0, -1, 4, 4, 0, 2359, func_291(iParam0), 1, 1);
		break;

	case 44:
		func_290(uParam1, "Omega1", func_292(iParam0), 0, 13, 4, 2468.51f, 3437.39f, 49.9f, 66, "", -1, 0,
				 "spaceshipParts", 0, 1, 45, 4, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 45:
		func_290(uParam1, "Omega2", func_292(iParam0), 0, 13, 4, 2319.44f, 2583.58f, 46.76f, 387, "", 107, 0, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 46:
		func_290(uParam1, "Paparazzo1", func_292(iParam0), 0, 14, 4, -149.75f, 285.81f, 93.67f, 66, "", -1, 0, "", 0, 1,
				 47, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 47:
		func_290(uParam1, "Paparazzo2", func_292(iParam0), 0, 14, 4, -70.71f, 301.43f, 106.79f, 389, "", -1, 8, "", 0,
				 0, 48, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 48:
		func_290(uParam1, "Paparazzo3", func_292(iParam0), 0, 14, 4, -257.22f, 292.85f, 90.63f, 389, "", -1, 8, "", 183,
				 1, -1, 2, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 49:
		func_290(uParam1, "Paparazzo3A", func_292(iParam0), 0, 14, 2, 305.52f, 157.19f, 102.94f, 389, "PAPPHOTO", 102,
				 0, "", 0, 0, 51, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 50:
		func_290(uParam1, "Paparazzo3B", func_292(iParam0), 0, 14, 2, 1040.96f, -534.42f, 60.17f, 389, "", 102, 0, "",
				 0, 0, 51, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 51:
		func_290(uParam1, "Paparazzo4", func_292(iParam0), 0, 14, 4, -484.2f, 229.68f, 82.21f, 389, "", -1, 8, "", 0, 1,
				 -1, 4, 2, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 52:
		func_290(uParam1, "Rampage1", func_292(iParam0), 0, 15, 4, 908f, 3643.7f, 32.2f, 66, "", -1, 0, "", 0, 1, 54, 4,
				 4, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 54:
		func_290(uParam1, "Rampage3", func_292(iParam0), 0, 15, 4, 465.1f, -1849.3f, 27.8f, 84, "", -1, 0, "", 0, 1, 55,
				 4, 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 55:
		func_290(uParam1, "Rampage4", func_292(iParam0), 0, 15, 4, -161f, -1669.7f, 33f, 84, "", -1, 0, "", 0, 0, 56, 4,
				 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 56:
		func_290(uParam1, "Rampage5", func_292(iParam0), 0, 15, 4, -1298.2f, 2504.14f, 21.09f, 84, "", -1, 0, "", 0, 0,
				 53, 4, 4, 0, 2359, func_291(iParam0), 0, 0);
		break;

	case 53:
		func_290(uParam1, "Rampage2", func_292(iParam0), 0, 15, 4, 1181.5f, -400.1f, 67.5f, 84, "", -1, 0,
				 "rampage_controller", 0, 0, -1, 4, 4, 0, 2359, func_291(iParam0), 1, 0);
		break;

	case 57:
		func_290(uParam1, "TheLastOne", func_292(iParam0), 0, 16, 4, -1298.98f, 4640.16f, 105.67f, 66, "", 133, 1, "",
				 0, 1, -1, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 58:
		func_290(uParam1, "Tonya1", func_292(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 66, "AM_H_RCFS", -1, 0,
				 "ambient_TonyaCall", 24, 1, 59, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 59:
		func_290(uParam1, "Tonya2", func_292(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48,
				 "ambient_Tonya", 185, 0, 60, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	case 60:
		func_290(uParam1, "Tonya3", func_292(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 187, 0, 61, 4, 2, 0,
				 2359, func_291(iParam0), 0, 1);
		break;

	case 61:
		func_290(uParam1, "Tonya4", func_292(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 0, 62, 4, 2, 0, 2359,
				 func_291(iParam0), 0, 1);
		break;

	case 62:
		func_290(uParam1, "Tonya5", func_292(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_291(iParam0), 0, 1);
		break;

	default: break;
	}
}

// Position - 0x11C13
void func_290(var *uParam0, char *sParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6, vector3 vParam7,
			  int iParam10, char *sParam11, int iParam12, int iParam13, char *sParam14, int iParam15, int iParam16,
			  int iParam17, int iParam18, int iParam19, int iParam20, int iParam21, int iParam22, int iParam23,
			  int iParam24) {
	uParam0->f_4 = iParam5;
	*uParam0 = sParam1;
	uParam0->f_1 = {Param2};
	uParam0->f_3 = iParam4;
	uParam0->f_5 = iParam6;
	uParam0->f_6 = {vParam7};
	uParam0->f_9 = iParam10;
	StringCopy(&uParam0->f_10, sParam11, 16);
	uParam0->f_14 = iParam12;
	uParam0->f_15 = iParam13;
	StringCopy(&uParam0->f_16, sParam14, 24);
	uParam0->f_22 = iParam15;
	uParam0->f_23 = iParam16;
	uParam0->f_24 = iParam17;
	uParam0->f_25 = iParam18;
	uParam0->f_26 = iParam19;
	uParam0->f_27 = iParam20;
	uParam0->f_28 = iParam21;
	uParam0->f_29 = iParam22;
	uParam0->f_30 = iParam23;
	uParam0->f_31 = iParam24;
}

// Position - 0x11CA4
int func_291(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 0;

	case 2: return 1;

	case 3: return 1;

	case 4: return 0;

	case 5: return 1;

	case 6: return 1;

	case 7: return 0;

	case 8: return 1;

	case 9: return 0;

	case 10: return 0;

	case 11: return 0;

	case 12: return 1;

	case 13: return 0;

	case 14: return 1;

	case 15: return 0;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 1;

	case 23: return 1;

	case 24: return 1;

	case 25: return 1;

	case 26: return 1;

	case 27: return 0;

	case 28: return 1;

	case 29: return 1;

	case 30: return 1;

	case 31: return 0;

	case 32: return 1;

	case 33: return 1;

	case 34: return 1;

	case 35: return 0;

	case 36: return 0;

	case 37: return 0;

	case 38: return 1;

	case 39: return 1;

	case 40: return 1;

	case 41: return 1;

	case 42: return 1;

	case 43: return 1;

	case 44: return 0;

	case 45: return 0;

	case 46: return 1;

	case 47: return 1;

	case 48: return 0;

	case 49: return 1;

	case 50: return 1;

	case 51: return 1;

	case 52: return 1;

	case 54: return 1;

	case 55: return 1;

	case 56: return 1;

	case 53: return 1;

	case 57: return 1;

	case 58: return 1;

	case 59: return 1;

	case 60: return 1;

	case 61: return 1;

	case 62: return 1;

	default: break;
	}
	return 0;
}

// Position - 0x11FEA
struct<2> func_292(int iParam0) {
	struct<2> Var0;
	char[] cVar2[8];

	StringCopy(&Var0, "", 8);
	cVar2 = {func_287(iParam0)};
	if (gameplay::is_string_null_or_empty(&cVar2)) {
	}
	else {
		StringCopy(&Var0, "RC_", 8);
		StringConCat(&Var0, &cVar2, 8);
	}
	return Var0;
}

//Position - 0x12021
int func_293(int iParam0)
{
	switch (iParam0) {
	case 69:
	case 70: return func_294(Global_101700.f_8044.f_99.f_205[10]);

	case 74:
	case 75: return func_294(Global_101700.f_8044.f_99.f_205[8]);

	case 84:
	case 85: return func_294(Global_101700.f_8044.f_99.f_205[11]);

	case 90: return func_294(Global_101700.f_8044.f_99.f_205[7]);

	case 93: return func_294(Global_101700.f_8044.f_99.f_205[9]);
	}
	return 0;
}

// Position - 0x120DD
int func_294(int iParam0) {
	switch (iParam0) {
	case 1:
	case 3:
	case 5:
	case 6:
	case 8: return 0;

	case 2:
	case 4:
	case 7:
	case 9: return 1;
	}
	return -1;
}

// Position - 0x12131
int func_295(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = gameplay::get_hash_key(sParam0);
	iVar1 = func_296(iVar0, 1);
	if (iVar1 == -1 && !iParam1) {
	}
	return iVar1;
}

// Position - 0x1215B
int func_296(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 94) {
		if (Global_82612[iVar0 /*34*/].f_6 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	if (!iParam1) {
	}
	return -1;
}

// Position - 0x12191
void func_297() {
	vector3 vVar0;
	float fVar3;

	switch (iLocal_1760) {
	case 0:
		if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_START")) {
			audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_START");
		}
		audio::start_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP");
		func_201(&iLocal_1765);
		func_200(256, 0, 1);
		func_199();
		ui::clear_prints();
		ui::clear_help(1);
		player::set_player_invincible(player::player_id(), 1);
		gameplay::clear_area(vLocal_1823, 10f, 1, 0, 0, 0);
		ui::clear_help(1);
		system::settimera(0);
		iLocal_1760++;
		break;

	case 1:
		if (func_196(uLocal_1787[1], uLocal_1791[1], 152.2146f)) {
			func_301();
			iLocal_1760++;
		}
		break;

	case 2:
		if (system::timera() >= 0) {
			func_201(&iLocal_1765);
			func_171(&Local_1356, 6);
			func_171(&Local_1471, 2);
			func_170(0);
			entity::freeze_entity_position(iLocal_1801, 0);
			ui::display_radar(0);
			ui::display_hud(0);
			iLocal_1760++;
		}
		break;

	case 3:
		if (entity::does_entity_exist(uLocal_1787[1])) {
			vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
			if (vVar0.z >= 270.46f) {
				if (cam::is_screen_fading_out()) {
					if (!cam::is_screen_fading_in()) {
						cam::do_screen_fade_in(1000);
					}
				}
				else {
					entity::detach_entity(iLocal_1801, 0, 0);
					system::settimera(0);
					func_201(&iLocal_1765);
					iLocal_1760++;
				}
			}
			else {
				if (vVar0.z >= 235f) {
					if (!entity::does_entity_exist(iLocal_1972)) {
						func_222(0);
					}
					if (!iLocal_1728) {
						func_223(5);
					}
				}
				fVar3 = func_300(vVar0.z, 260f, 270.46f, 266f, 0.1f, 0.25f);
				func_192(uLocal_1787[1], 0, 0, fVar3, 1, 1, 1);
				func_299();
			}
		}
		break;

	case 4:
		func_201(&iLocal_1765);
		system::settimera(0);
		iLocal_1760++;
		break;

	case 5:
		func_181(1, 1, 1);
		func_177();
		func_40();
		iLocal_1030 = 13;
		break;
	}
	if (iLocal_1760 >= 3) {
		if (!iLocal_1722) {
			if (func_179(iLocal_144)) {
				iLocal_1722 = 1;
			}
		}
		else if (cam::is_screen_faded_out()) {
			if (!iLocal_1728) {
				func_223(5);
			}
			if (!iLocal_1729) {
				func_222(0);
			}
			if (iLocal_1728 && iLocal_1729) {
				func_178();
				func_298(1, 1);
				entity::set_entity_heading(iLocal_1801, 243.9563f);
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				func_181(1, 1, 1);
				func_177();
				func_40();
				iLocal_1030 = 13;
			}
		}
	}
}

// Position - 0x1240F
void func_298(int iParam0, int iParam1) {
	entity::detach_entity(iLocal_1801, 1, 1);
	func_201(&iLocal_1765);
	if (iParam0) {
		if (entity::does_entity_exist(uLocal_1787[1])) {
			entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 270.46f, 1, 0, 0, 1);
		}
		else {
			uLocal_1787[1] = object::create_object(iLocal_1784, -158.84f, -942.24f, 270.46f, 1, 1, 0);
			entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 270.46f, 1, 0, 0, 1);
			entity::set_entity_rotation(uLocal_1787[1], vLocal_1832[1 /*3*/], 2, 1);
		}
	}
	if (iParam1) {
		entity::attach_entity_to_entity(iLocal_1801, uLocal_1787[1], 0, vLocal_1946, 0f, 0f, 269f, 0, 0, 1, 0, 2, 1);
		entity::detach_entity(iLocal_1801, 0, 0);
		player::set_player_control(player::player_id(), 1, 0);
		cam::set_gameplay_cam_relative_heading(0f);
	}
	if (!entity::does_entity_exist(uLocal_1791[1])) {
		uLocal_1791[1] = object::create_object(iLocal_1786, vLocal_1842[1 /*3*/], 1, 1, 0);
		entity::attach_entity_to_entity(uLocal_1791[1], uLocal_1787[1], 0, vLocal_1913, 0f, 0f, 0f, 0, 0, 0, 0, 2, 1);
	}
}

// Position - 0x1252B
void func_299() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1);
		if (iVar0 == joaat("weapon_unarmed") && iLocal_2174 != joaat("weapon_unarmed") && iLocal_2174 != 0) {
			weapon::set_current_ped_weapon(player::player_ped_id(), iLocal_2174, 1);
			weapon::get_ammo_in_clip(player::player_ped_id(), iLocal_2174, &iVar1);
			iVar2 = weapon::get_max_ammo_in_clip(player::player_ped_id(), iLocal_2174, 1);
			iVar3 = weapon::get_ammo_in_ped_weapon(player::player_ped_id(), iLocal_2174);
			if (iVar1 < iVar2 && ai::get_script_task_status(player::player_ped_id(), 1785177548) != 1 &&
				iVar3 > iVar1) {
				ai::task_reload_weapon(player::player_ped_id(), 1);
			}
		}
	}
}

// Position - 0x125D3
float func_300(float fParam0, float fParam1, float fParam2, float fParam3, float fParam4, float fParam5) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;

	if (fParam0 < fParam2) {
		if (fParam0 >= fParam1) {
			fVar0 = fParam3 - fParam1;
			fVar1 = fParam3 - fParam0;
			fVar2 = fVar1 / fVar0;
			fVar3 = fParam5 - fParam4;
			fVar4 = fVar2 * fVar3 + fParam4;
		}
		else {
			fVar4 = fParam5;
		}
	}
	if (fVar4 < fParam4) {
		fVar4 = fParam4;
	}
	return fVar4;
}

// Position - 0x12626
void func_301() {
	int iVar0;
	vector3 vVar1;

	iVar0 = 0;
	while (iVar0 < 2) {
		if (ped::is_ped_injured(Local_1471[iVar0 /*19*/])) {
			vVar1 = {entity::get_entity_coords(Local_1471[iVar0 /*19*/], 0)};
			if (gameplay::get_distance_between_coords(vVar1, vLocal_1823, 1) < 3.25f) {
				ped::delete_ped(&Local_1471[iVar0 /*19*/]);
			}
		}
		iVar0++;
	}
}

// Position - 0x12680
void func_302() {
	int iVar0;
	int iVar1;

	if (!iLocal_2003) {
		if (func_29(&uLocal_1994)) {
			if (func_26(&uLocal_1994) >= 12f) {
				func_220(3, 20);
				func_220(4, 20);
				iLocal_2003 = 1;
			}
		}
	}
	switch (iLocal_1760) {
	case 0:
		func_226(2, "assassin_construction_get_to_second_elevator", 0, 0, 0, 1);
		if (!bLocal_1714) {
			bLocal_1714 = true;
		}
		if (!ui::does_blip_exist(iLocal_1710)) {
			iLocal_1710 = ui::add_blip_for_coord(-154.799f, -941.62f, 269.1f);
			ui::set_blip_route(iLocal_1710, 0);
			ui::set_blip_name_from_text_file(iLocal_1710, "ASS_CS_TARGET");
		}
		else {
			ui::set_blip_coords(iLocal_1710, -154.799f, -941.62f, 269.1f);
		}
		if (iLocal_1763 < 4) {
			iLocal_1763 = 4;
		}
		audio::trigger_music_event("ASS5_TOP");
		func_171(&Local_1202, 5);
		func_171(&Local_1298, 3);
		cam::render_script_cams(0, 1, 3000, 1, 0, 0);
		func_183(0, 1, 1, 0);
		ui::display_radar(1);
		ui::display_hud(1);
		player::set_player_control(player::player_id(), 1, 0);
		player::set_player_invincible(player::player_id(), 0);
		func_32("ASS_CS_EHELP1", 7500, 1);
		system::settimera(0);
		iLocal_1760++;
		break;

	case 1:
		if (entity::does_entity_exist(uLocal_1787[1])) {
			func_306(0);
			iLocal_1760++;
		}
		else {
			entity::create_model_hide(vLocal_1823, 5f, joaat("prop_conslift_lift"), 1);
			func_306(0);
			iLocal_1760++;
		}
		break;

	case 2:
		if (func_34(iLocal_1801, -148.6073f, -952.5458f, 113.1339f, 1) <= 5f) {
			func_223(4);
			func_58(&uLocal_2005, "OJASAUD", "OJAScs_LIFT", 9, 0, 0, 0);
			iLocal_1760++;
		}
		break;

	case 3:
		if (iLocal_1718) {
			if (func_204(vLocal_1823)) {
				func_203();
				if (controls::is_control_just_pressed(0, 51) || controls::is_control_just_pressed(2, 51)) {
					if (func_202("ASS_CS_ELEHELP")) {
						func_201(&iLocal_1765);
						func_40();
						iLocal_1030 = 12;
					}
				}
			}
			else if (func_202("ASS_CS_ELEHELP")) {
				ui::clear_help(1);
			}
			else if (!iLocal_1725) {
				if (!func_62()) {
					iLocal_1725 = 1;
				}
			}
		}
		else {
			func_304();
		}
		break;
	}
	if (iLocal_1723 == 0) {
		iVar1 = func_44(&Local_1356, 6);
		if (iVar1 == 3) {
			func_303(&Local_1298, 3);
			iLocal_1723 = 1;
		}
		else if (iVar1 == 5) {
			if (!iLocal_1724) {
				if (func_60(50f) != 0) {
					iVar0 = func_60(50f);
					ped::remove_ped_defensive_area(iVar0, 0);
					ped::set_ped_combat_movement(iVar0, 2);
					ai::task_clear_defensive_area(iVar0);
					ai::task_combat_ped(iVar0, iLocal_1801, 0, 16);
					iLocal_1724 = 1;
				}
			}
		}
	}
}

// Position - 0x12918
void func_303(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= iParam1 - 1) {
		if (!ped::is_ped_injured((*uParam0)[iVar0 /*19*/])) {
			ped::remove_ped_defensive_area((*uParam0)[iVar0 /*19*/], 0);
			ped::set_ped_combat_movement((*uParam0)[iVar0 /*19*/], 2);
			ai::task_clear_defensive_area((*uParam0)[iVar0 /*19*/]);
			ai::task_combat_ped((*uParam0)[iVar0 /*19*/], iLocal_1801, 0, 16);
		}
		iVar0++;
	}
}

// Position - 0x12973
void func_304() {
	vector3 vVar0;

	if (!iLocal_1718) {
		vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
		if (vVar0.z >= 115.5f) {
			func_192(uLocal_1787[1], 0, 0, 0.2f, 0, 0, 0);
			if (vVar0.z >= 117.8f) {
			}
		}
		else {
			func_305();
			func_201(&iLocal_1765);
			iLocal_1718 = 1;
		}
	}
}

// Position - 0x129D1
void func_305() {
	int iVar0;
	int iVar1;
	vector3 vVar2;

	iVar0 = 0;
	while (iVar0 <= 1) {
		if (!ped::is_ped_injured(Local_1471[iVar0 /*19*/])) {
			entity::detach_entity(Local_1471[iVar0 /*19*/], 0, 0);
			if (iVar0 == 0) {
				ped::set_ped_sphere_defensive_area(Local_1471[iVar0 /*19*/], -145.5655f, -941.1028f, 113.2452f, 10f, 0,
												   0);
			}
			else if (iVar0 == 1) {
				ped::set_ped_sphere_defensive_area(Local_1471[iVar0 /*19*/], -152.5679f, -947.0895f, 113.1339f, 10f, 0,
												   0);
			}
			ped::set_ped_keep_task(Local_1471[iVar0 /*19*/], 1);
			ai::clear_sequence_task(&iVar1);
			ai::open_sequence_task(&iVar1);
			if (iVar0 == 0) {
				vVar2 = {-153.0079f, -944.3201f, 113.1388f};
			}
			else {
				vVar2 = {-152.1749f, -941.6376f, 113.1388f};
			}
			ai::task_go_to_coord_while_aiming_at_entity(0, vVar2, iLocal_1801, 2f, 0, 0.5f, 0f, 1, 0, 0, -957453492,
														20000);
			ai::task_combat_ped(0, iLocal_1801, 0, 16);
			ai::close_sequence_task(iVar1);
			ai::task_perform_sequence(Local_1471[iVar0 /*19*/], iVar1);
			ai::clear_sequence_task(&iVar1);
		}
		iVar0++;
	}
}

// Position - 0x12AE2
void func_306(int iParam0) {
	if (!entity::does_entity_exist(uLocal_1787[1])) {
		if (iParam0) {
			uLocal_1787[1] = object::create_object(iLocal_1784, vLocal_1842[1 /*3*/], 1, 1, 0);
		}
		else {
			uLocal_1787[1] = object::create_object(iLocal_1784, vLocal_1842[1 /*3*/], 1, 1, 0);
			entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 125.8f, 1, 0, 0, 1);
		}
		entity::set_entity_rotation(uLocal_1787[1], vLocal_1832[1 /*3*/], 2, 1);
	}
	else {
		entity::set_entity_coords(uLocal_1787[1], -158.84f, -942.24f, 125.8f, 1, 0, 0, 1);
		entity::set_entity_rotation(uLocal_1787[1], vLocal_1832[1 /*3*/], 2, 1);
	}
	uLocal_1791[1] = object::create_object(iLocal_1786, vLocal_1842[1 /*3*/], 1, 1, 0);
	entity::attach_entity_to_entity(uLocal_1791[1], uLocal_1787[1], 0, vLocal_1913, 0f, 0f, 0f, 0, 0, 0, 0, 2, 1);
}

// Position - 0x12BCC
void func_307() {
	var uVar0;
	vector3 vVar1;
	float fVar4;

	uVar0 = uVar0;
	if (entity::does_entity_exist(uLocal_1787[0])) {
		vVar1 = {entity::get_entity_coords(uLocal_1787[0], 1)};
	}
	switch (iLocal_1760) {
	case 0:
		func_200(256, 0, 1);
		func_199();
		func_201(&iLocal_1765);
		ui::clear_prints();
		ui::clear_help(1);
		if (iLocal_1763 < 4) {
			iLocal_1763 = 4;
		}
		player::set_player_invincible(player::player_id(), 1);
		gameplay::clear_area(vLocal_1820, 10f, 1, 0, 0, 0);
		system::settimera(0);
		iLocal_1760++;
		break;

	case 1:
		if (func_196(uLocal_1787[0], uLocal_1791[0], 264.1952f)) {
			iLocal_1760++;
		}
		break;

	case 2:
		if (system::timera() >= 0) {
			func_201(&iLocal_1765);
			func_223(3);
			entity::freeze_entity_position(iLocal_1801, 0);
			system::settimera(0);
			iLocal_1760++;
		}
		break;

	case 3:
		if (entity::does_entity_exist(uLocal_1787[0])) {
			if (vVar1.z >= 115.4f || iLocal_1721) {
				if (cam::is_screen_fading_out()) {
					if (!cam::is_screen_fading_in()) {
						func_171(&Local_1202, 5);
						func_171(&Local_1298, 3);
						cam::do_screen_fade_in(1000);
					}
				}
				else {
					if (!ped::is_ped_in_any_vehicle(iLocal_1801, 0)) {
						entity::detach_entity(iLocal_1801, 0, 0);
					}
					else {
						entity::detach_entity(ped::get_vehicle_ped_is_in(iLocal_1801, 0), 0, 0);
					}
					system::settimera(0);
					func_201(&iLocal_1765);
					iLocal_1760++;
				}
			}
			else {
				fVar4 = func_300(vVar1.z, 105f, 115.4f, 111f, 0.1f, 0.25f);
				func_192(uLocal_1787[0], 0, 0, fVar4, 1, 1, 1);
				if (vVar1.z >= 113.8f) {
					if (!bLocal_1714) {
						func_59(Local_1356[0 /*19*/]);
						bLocal_1714 = true;
					}
					func_309();
				}
				func_299();
			}
		}
		break;

	case 4:
		func_201(&iLocal_1765);
		func_171(&Local_1202, 5);
		func_171(&Local_1298, 3);
		func_197();
		func_309();
		func_181(1, 1, 1);
		func_177();
		func_40();
		iLocal_1030 = 11;
		break;
	}
	if (iLocal_1760 >= 3) {
		if (!iLocal_1722) {
			if (func_179(iLocal_144)) {
				iLocal_1722 = 1;
			}
		}
		else if (cam::is_screen_faded_out()) {
			func_178();
			if (iLocal_1763 < 4) {
				iLocal_1763 = 4;
			}
			func_308(1);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			iLocal_1721 = 1;
		}
	}
}

// Position - 0x12E29
void func_308(int iParam0) {
	entity::detach_entity(iLocal_1801, 1, 1);
	func_201(&iLocal_1765);
	if (entity::does_entity_exist(uLocal_1787[0])) {
		entity::set_entity_coords(uLocal_1787[0], -182.17f, -1016.09f, 115.46f, 1, 0, 0, 1);
	}
	else {
		uLocal_1787[0] = object::create_object(iLocal_1784, -182.17f, -1016.09f, 115.46f, 1, 1, 0);
		entity::set_entity_coords(uLocal_1787[0], -182.17f, -1016.09f, 115.46f, 1, 0, 0, 1);
		entity::set_entity_rotation(uLocal_1787[0], vLocal_1832[0 /*3*/], 2, 1);
		entity::set_entity_load_collision_flag(uLocal_1787[0], 1);
	}
	if (!entity::does_entity_exist(uLocal_1791[0]) && entity::does_entity_exist(uLocal_1787[0])) {
		uLocal_1791[0] = object::create_object(iLocal_1786, vLocal_1842[0 /*3*/], 1, 1, 0);
		entity::attach_entity_to_entity(uLocal_1791[0], uLocal_1787[0], 0, vLocal_1913, 0f, 0f, 0f, 0, 0, 0, 0, 2, 1);
	}
	if (iParam0) {
		entity::attach_entity_to_entity(iLocal_1801, uLocal_1787[0], 0, vLocal_1946, 0f, 0f, 340f, 0, 0, 1, 0, 2, 1);
		entity::detach_entity(iLocal_1801, 0, 0);
		entity::set_entity_heading(iLocal_1801, 340.3911f);
		player::set_player_control(player::player_id(), 1, 0);
		cam::set_gameplay_cam_relative_heading(0f);
	}
}

// Position - 0x12F66
void func_309() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 <= 5) {
		if (!ped::is_ped_injured(Local_1356[iVar0 /*19*/])) {
			if (ai::get_script_task_status(Local_1356[iVar0 /*19*/], 242628503) != 1) {
				if (iVar0 == 0) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], Local_1356[iVar0 /*19*/].f_10, 10f, 0,
													   0);
					entity::set_entity_load_collision_flag(Local_1356[iVar0 /*19*/], 1);
				}
				else if (iVar0 == 1) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], Local_1356[iVar0 /*19*/].f_10, 10f, 0,
													   0);
				}
				else if (iVar0 == 2) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], -151.3457f, -948.0886f, 113.1339f, 10f,
													   0, 0);
				}
				else if (iVar0 == 3) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], -145.5338f, -986.0398f, 113.1282f, 10f,
													   0, 0);
				}
				else if (iVar0 == 4) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], -139.7715f, -968.064f, 113.1339f, 10f,
													   0, 0);
				}
				else if (iVar0 == 5) {
					ped::set_ped_sphere_defensive_area(Local_1356[iVar0 /*19*/], -154.0288f, -960.1566f, 113.1317f, 10f,
													   0, 0);
				}
				ai::open_sequence_task(&iVar1);
				if (iVar0 == 0) {
					ai::task_go_to_coord_while_aiming_at_entity(0, -162.7042f, -999.0336f, 113.1382f,
																player::player_ped_id(), 2f, 0, 1.5f, 1.5f, 0, 0, 0,
																-957453492, 20000);
				}
				ai::task_combat_ped(0, iLocal_1801, 0, 16);
				ai::close_sequence_task(iVar1);
				ai::task_perform_sequence(Local_1356[iVar0 /*19*/], iVar1);
				ai::clear_sequence_task(&iVar1);
				ped::set_ped_combat_movement(Local_1356[iVar0 /*19*/], 2);
				ped::set_combat_float(Local_1356[iVar0 /*19*/], 13, 3f);
				ped::set_ped_keep_task(Local_1356[iVar0 /*19*/], 1);
			}
		}
		iVar0++;
	}
}

// Position - 0x13125
void func_310() {
	switch (iLocal_1760) {
	case 0:
		func_226(1, "assassin_construction_enter_site", 0, 0, 0, 1);
		audio::start_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_START");
		audio::trigger_music_event("ASS5_START");
		if (!entity::does_entity_exist(uLocal_1787[0])) {
			func_317();
		}
		func_210();
		func_32("ASS_CS_ROOF", 7500, 1);
		if (!ui::does_blip_exist(iLocal_1710)) {
			iLocal_1710 = ui::add_blip_for_coord(-184.599f, -1015.819f, 254.2567f);
			ui::set_blip_route(iLocal_1710, 0);
			ui::set_blip_name_from_text_file(iLocal_1710, "ASS_CS_TARGET");
		}
		iLocal_1760++;
		break;

	case 1:
		if (func_204(vLocal_1820) && !func_316()) {
			func_203();
			if (controls::is_control_just_pressed(0, 51) || controls::is_control_just_pressed(2, 51)) {
				if (func_202("ASS_CS_ELEHELP")) {
					iLocal_1971 = player::get_players_last_vehicle();
					if (iLocal_1971 != 0) {
						if (vehicle::is_vehicle_driveable(iLocal_1971, 0)) {
							entity::set_entity_as_mission_entity(iLocal_1971, 1, 0);
						}
					}
					audio::trigger_music_event("ASS5_LIFT");
					func_40();
					iLocal_1030 = 10;
				}
			}
		}
		else {
			if (func_202("ASS_CS_ELEHELP")) {
				ui::clear_help(1);
			}
			if (iLocal_1723 == 0) {
				if (func_44(&Local_1202, 5) + func_44(&Local_1298, 3) == 1) {
					func_303(&Local_1202, 5);
					func_303(&Local_1298, 3);
					iLocal_1723 = 1;
				}
			}
		}
		break;
	}
	func_312();
	if (bLocal_1714 && !iLocal_1716) {
		func_311();
		iLocal_1716 = 1;
	}
}

// Position - 0x13292
void func_311() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 4) {
		if (!ped::is_ped_injured(Local_1202[iVar0 /*19*/])) {
			if (iVar0 == 0) {
				ped::set_ped_combat_movement(Local_1202[iVar0 /*19*/], 2);
			}
			else if (iVar0 == 1) {
				ped::set_ped_combat_movement(Local_1202[iVar0 /*19*/], 2);
			}
			else if (iVar0 == 2) {
				ped::set_ped_sphere_defensive_area(Local_1202[iVar0 /*19*/], Local_1202[iVar0 /*19*/].f_10, 10f, 0, 0);
			}
			else if (iVar0 == 3) {
				ped::set_ped_sphere_defensive_area(Local_1202[iVar0 /*19*/], Local_1202[iVar0 /*19*/].f_10, 10f, 0, 0);
			}
			else if (iVar0 == 4) {
				ped::set_ped_combat_movement(Local_1202[iVar0 /*19*/], 2);
			}
			else {
				ped::set_ped_sphere_defensive_area(Local_1202[iVar0 /*19*/], -176.2501f, -1026.913f, 26.2752f, 25f, 0,
												   0);
				ped::set_ped_combat_movement(Local_1202[iVar0 /*19*/], 1);
			}
			if (ai::get_script_task_status(Local_1202[iVar0 /*19*/], -1253019028) == 1) {
				ped::_0xF1C03A5352243A30(Local_1202[iVar0 /*19*/]);
				ai::clear_ped_tasks(Local_1202[iVar0 /*19*/]);
			}
			ai::task_combat_ped(Local_1202[iVar0 /*19*/], iLocal_1801, 0, 16);
			ped::set_ped_keep_task(Local_1202[iVar0 /*19*/], 1);
		}
		iVar0++;
	}
}

// Position - 0x133BA
void func_312() {
	vector3 vVar0;

	if (!iLocal_1735) {
		if (entity::does_entity_exist(iLocal_1970) && !entity::is_entity_dead(iLocal_1970, 0)) {
			vVar0 = {entity::get_entity_coords(iLocal_1970, 1)};
			if (func_34(player::player_ped_id(), vVar0, 1) <= 5f) {
				func_315();
				iLocal_1735 = 1;
			}
		}
	}
	if (!iLocal_1720) {
		if (entity::does_entity_exist(iLocal_1970)) {
			if (bLocal_1714 && entity::is_entity_in_angled_area(iLocal_1801, -125.446f, -999.097f, 27.228f, -173.264f,
																-1095.935f, 27.228f, 98f, 0, 0, 0) ||
				bLocal_1714 && func_37(iLocal_1970, 1) < 50f || bLocal_1714 && func_33(vLocal_1820, 0) < 50f) {
				func_314();
				iLocal_1720 = 1;
			}
		}
	}
	else {
		func_313();
	}
}

// Position - 0x13499
void func_313() {
	if (!iLocal_1719) {
		if (vehicle::is_vehicle_driveable(iLocal_1970, 0)) {
			if (!ai::is_waypoint_playback_going_on_for_vehicle(iLocal_1970) ||
				ped::is_ped_injured(vehicle::get_ped_in_vehicle_seat(iLocal_1970, -1, 0)) ||
				func_34(iLocal_1970, -177.2643f, -1036.083f, 26.2322f, 0) <= 8f ||
				vehicle::is_vehicle_stuck_timer_up(iLocal_1970, 0, 3000) ||
				vehicle::is_vehicle_stuck_timer_up(iLocal_1970, 2, 3000) ||
				vehicle::is_vehicle_stuck_timer_up(iLocal_1970, 3, 3000)) {
				if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CAR_ARRIVES")) {
					audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CAR_ARRIVES");
				}
				func_315();
			}
		}
		else {
			func_315();
		}
	}
}

// Position - 0x13545
void func_314() {
	int iVar0;

	if (entity::does_entity_exist(iLocal_1970)) {
		if (vehicle::is_vehicle_driveable(iLocal_1970, 0)) {
			if (!ai::is_waypoint_playback_going_on_for_vehicle(iLocal_1970)) {
				iVar0 = 0;
				while (iVar0 <= 2) {
					if (!ped::is_ped_injured(Local_1298[iVar0 /*19*/])) {
						if (Local_1298[iVar0 /*19*/] == vehicle::get_ped_in_vehicle_seat(iLocal_1970, -1, 0)) {
							if (!audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CAR_ARRIVES")) {
								audio::start_audio_scene("ASSASSINATION_CONSTRUCT_CAR_ARRIVES");
							}
							ai::task_vehicle_follow_waypoint_recording(Local_1298[iVar0 /*19*/], iLocal_1970,
																	   "OJAScs_101", 52, 0, 0, -1, -1f, 0, 1073741824);
							ped::set_ped_keep_task(Local_1298[iVar0 /*19*/], 1);
							bLocal_1750 = true;
						}
						else {
							ai::task_combat_ped(Local_1298[iVar0 /*19*/], iLocal_1801, 0, 16);
							ped::set_ped_keep_task(Local_1298[iVar0 /*19*/], 1);
							bLocal_1750 = true;
						}
					}
					iVar0++;
				}
				bLocal_1714 = true;
				iLocal_1720 = 1;
			}
		}
	}
}

// Position - 0x13614
void func_315() {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	while (iVar1 <= 2) {
		if (!ped::is_ped_injured(Local_1298[iVar1 /*19*/])) {
			ped::set_ped_combat_attributes(Local_1298[iVar1 /*19*/], 3, 1);
			if (iVar1 != 2) {
				ped::set_ped_sphere_defensive_area(Local_1298[iVar1 /*19*/], Local_1202[3 /*19*/].f_10, 10f, 0, 0);
				ped::set_ped_combat_movement(Local_1298[iVar1 /*19*/], 2);
			}
			ai::clear_sequence_task(&iVar0);
			ai::open_sequence_task(&iVar0);
			ai::task_leave_any_vehicle(0, 0, 256);
			ai::task_combat_ped(0, iLocal_1801, 0, 16);
			ai::close_sequence_task(iVar0);
			ai::task_perform_sequence(Local_1298[iVar1 /*19*/], iVar0);
			ai::clear_sequence_task(&iVar0);
		}
		iVar1++;
	}
	bLocal_1750 = true;
	iLocal_1719 = 1;
}

// Position - 0x136B9
int func_316() {
	int iVar0;

	iVar0 = player::get_players_last_vehicle();
	if (entity::does_entity_exist(iVar0)) {
		if (entity::is_entity_in_angled_area(iVar0, -185.0424f, -1018.321f, 29.05155f, -183.1528f, -1013.212f,
											 31.05155f, 2f, 0, 1, 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x13700
void func_317() {
	uLocal_1787[0] = object::create_object(iLocal_1784, vLocal_1842[0 /*3*/], 1, 1, 0);
	entity::set_entity_rotation(uLocal_1787[0], vLocal_1832[0 /*3*/], 2, 1);
	uLocal_1791[0] = object::create_object(iLocal_1786, vLocal_1842[0 /*3*/], 1, 1, 0);
	entity::attach_entity_to_entity(uLocal_1791[0], uLocal_1787[0], 0, vLocal_1913, 0f, 0f, 0f, 0, 0, 0, 0, 2, 1);
}

// Position - 0x1376B
void func_318() {
	vector3 vVar0;
	float fVar3;

	switch (iLocal_1760) {
	case 0:
		if (func_322(5f, 0) && streaming::is_srl_loaded() ||
			func_322(1084227584, 1) && func_29(&uLocal_2000) && func_26(&uLocal_2000) > 15f) {
			if (!iLocal_1744) {
				iLocal_1768 = vehicle::_0x2CE544C68FB812A0(-69.7777f, -923.6335f, 28.2933f, 10f, 0f, 0);
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						iLocal_1973 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (entity::does_entity_exist(iLocal_1973)) {
							if (!entity::is_entity_dead(iLocal_1973, 0)) {
								audio::set_veh_radio_station(iLocal_1973, "OFF");
							}
						}
					}
				}
				func_321(1);
				if (!ped::is_ped_injured(iLocal_1802)) {
					ped::_0x2208438012482A1A(iLocal_1802, 1, 0);
					ai::task_play_anim(iLocal_1802, "oddjobs@assassinate@construction@", "CS_GetInLift", 1000f, -4f,
									   9500, 0, 0, 0, 0, 0);
				}
				if (!ped::is_ped_injured(iLocal_1803)) {
					ped::_0x2208438012482A1A(iLocal_1803, 1, 0);
					ai::task_play_anim(iLocal_1803, "oddjobs@assassinate@construction@", "idle_a", 1000f, -4f, -1, 1, 0,
									   0, 0, 0);
					ai::task_look_at_entity(iLocal_1803, iLocal_1802, -1, 0, 2);
				}
				entity::create_model_hide(vLocal_1823, 5f, joaat("prop_conslift_lift"), 1);
				func_306(1);
				if (entity::does_entity_exist(uLocal_1787[1])) {
					if (!ped::is_ped_injured(iLocal_1802)) {
						entity::attach_entity_to_entity(iLocal_1802, uLocal_1787[1], 0, -1.75f, -1.88f, -1.3f, 0f, 0f,
														84.2f, 0, 0, 0, 0, 2, 1);
					}
				}
				iLocal_1756 = cam::create_camera_with_params(26379945, -147.5668f, -958.6139f, 114.8839f, -1.648425f,
															 -0.29868f, 24.55094f, 31.35205f, 0, 2);
				iLocal_1757 = cam::create_camera_with_params(26379945, -147.2354f, -957.6655f, 114.8667f, -1.648426f,
															 -0.29868f, 25.52002f, 31.35205f, 0, 2);
				cam::shake_cam(iLocal_1756, "HAND_SHAKE", 0.2f);
				cam::shake_cam(iLocal_1757, "HAND_SHAKE", 0.2f);
				iLocal_1744 = 1;
			}
			else {
				audio::start_audio_scene("ASSASSINATION_CONSTRUCT_CUTSCENE");
				streaming::_0xBEB2D9A1D9A8F55A(5, 5, 5, 5);
				streaming::begin_srl();
				streaming::_0xEF39EE20C537E98C(-112.1211f, -907.9638f, 30.1577f, -1.9677f, 0f, 71.475f);
				func_200(0, 0, 1);
				func_199();
				streaming::_0xA76359FC80B2438E(1f);
				cam::set_cam_active_with_interp(iLocal_1757, iLocal_1756, 4800, 0, 1);
				cam::render_script_cams(1, 0, 3000, 1, 0, 0);
				func_363(&uLocal_2005, 3, iLocal_1802, "MAFIABOSS", 0, 1);
				if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_SCARE", 9, 0, 0, 0)) {
					iLocal_1745 = 1;
				}
				iLocal_140 = 0;
				system::settimera(0);
				iLocal_1760++;
			}
		}
		break;

	case 1:
		streaming::set_srl_time(system::to_float(system::timera()));
		if (!iLocal_1745) {
			if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_SCARE", 9, 0, 0, 0)) {
				iLocal_1745 = 1;
			}
		}
		if (system::timera() >= 4800) {
			cam::set_cam_params(iLocal_1756, -152.6485f, -944.8f, 114.2028f, 2.386309f, -0.295268f, 43.69577f,
								31.34258f, 0, 1, 1, 2);
			cam::set_cam_params(iLocal_1757, -152.7505f, -944.6934f, 114.2089f, 2.386309f, -0.295268f, 43.69577f,
								31.34258f, 0, 1, 1, 2);
			cam::shake_cam(iLocal_1756, "HAND_SHAKE", 0.2f);
			cam::shake_cam(iLocal_1757, "HAND_SHAKE", 0.2f);
			cam::set_cam_active_with_interp(iLocal_1757, iLocal_1756, 6000, 0, 1);
			iLocal_1760++;
		}
		streaming::_0xA76359FC80B2438E(1f);
		break;

	case 2:
		streaming::set_srl_time(system::to_float(system::timera()));
		if (system::timera() >= 7500) {
			cam::set_cam_params(iLocal_1756, -165.2002f, -938.0276f, 113.4667f, 4.389886f, 0.213688f, -112.1127f,
								32.21227f, 0, 1, 1, 2);
			cam::set_cam_params(iLocal_1757, -164.6229f, -937.1241f, 113.4675f, 77.82435f, 0.213692f, -131.0643f,
								32.21227f, 0, 1, 1, 2);
			cam::shake_cam(iLocal_1756, "HAND_SHAKE", 0.2f);
			cam::shake_cam(iLocal_1757, "HAND_SHAKE", 0.2f);
			cam::set_cam_active_with_interp(iLocal_1757, iLocal_1756, 4250, 1, 1);
			func_201(&iLocal_1765);
			iLocal_1760++;
		}
		streaming::_0xA76359FC80B2438E(1f);
		break;

	case 3:
		streaming::set_srl_time(system::to_float(system::timera()));
		if (system::timera() >= 9250) {
			func_201(&iLocal_1765);
			iLocal_1760++;
		}
		vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
		fVar3 = func_320(vVar0.z, vLocal_1842[1 /*3*/].f_2 + 7.5f, vLocal_1842[1 /*3*/].f_2 + 2.763f, 0.1f, 0.2f);
		func_192(uLocal_1787[1], 0, 0, fVar3, 0, 1, 1);
		break;

	case 4:
		if (!iLocal_1067) {
			if (func_319()) {
				if (system::timera() >= 12550) {
					graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
					audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
					iLocal_1067 = 1;
				}
			}
		}
		streaming::set_srl_time(system::to_float(system::timera()));
		if (system::timera() >= 12850) {
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			iLocal_1760++;
		}
		vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
		fVar3 = func_320(vVar0.z, vLocal_1842[1 /*3*/].f_2 + 7.5f, vLocal_1842[1 /*3*/].f_2 + 2.763f, 0.1f, 0.25f);
		func_192(uLocal_1787[1], 0, 0, fVar3, 0, 1, 1);
		break;

	case 5:
		if (func_62()) {
			func_178();
			ui::clear_prints();
			streaming::set_srl_time(system::to_float(system::timera()));
		}
		else {
			func_181(1, 1, 1);
			cam::render_script_cams(0, 0, 3000, 1, 0, 0);
			func_172(&uLocal_2005, 3);
			func_172(&uLocal_2005, 5);
			ped::delete_ped(&iLocal_1802);
			ped::delete_ped(&iLocal_1803);
			func_201(&iLocal_1765);
			func_177();
			func_40();
			streaming::end_srl();
			if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CUTSCENE")) {
				audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CUTSCENE");
			}
			iLocal_1030 = 9;
		}
		vVar0 = {entity::get_entity_coords(uLocal_1787[1], 1)};
		fVar3 = func_320(vVar0.z, vLocal_1842[1 /*3*/].f_2 + 7.5f, vLocal_1842[1 /*3*/].f_2 + 2.763f, 0.1f, 0.25f);
		func_192(uLocal_1787[1], 0, 0, 0.25f, 0, 1, 1);
		break;
	}
	if (iLocal_1760 >= 2) {
		if (!iLocal_1721) {
			if (func_179(iLocal_144)) {
				if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CUTSCENE")) {
					audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CUTSCENE");
				}
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				iLocal_1760 = 5;
				iLocal_1721 = 1;
				func_201(&iLocal_1765);
				streaming::end_srl();
			}
		}
	}
}

// Position - 0x13E12
bool func_319() {
	if (cam::_0xEE778F8C7E1142E2(cam::_0x19CAFA3C87F7C2FF()) == 4) {
		return true;
	}
	return false;
}

// Position - 0x13E2B
float func_320(float fParam0, float fParam1, float fParam2, float fParam3, float fParam4) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;

	if (fParam0 <= fParam1) {
		fVar0 = fParam1 - fParam2;
		fVar1 = fParam1 - fParam0;
		fVar2 = fVar1 / fVar0;
		fVar3 = (1f - fVar2) * fParam4;
	}
	else {
		fVar3 = fParam4;
	}
	if (fVar3 < fParam3) {
		fVar3 = fParam3;
	}
	else if (fVar3 > fParam4) {
		fVar3 = fParam4;
	}
	return fVar3;
}

// Position - 0x13E7D
void func_321(int iParam0) {
	if (!entity::does_entity_exist(iLocal_1802)) {
		if (iParam0) {
			iLocal_1802 = ped::create_ped(26, iLocal_1778[0], -153.2591f, -941.5044f, 113.1339f, 263f, 1, 1);
			ped::set_ped_default_component_variation(iLocal_1802);
			func_363(&uLocal_2005, 3, iLocal_1802, "MAFIABOSS", 0, 1);
			iLocal_1803 = ped::create_ped(26, iLocal_1778[1], -153.6352f, -942.8479f, 113.1339f, 66f, 1, 1);
			ped::set_ped_random_component_variation(iLocal_1803, 0);
			weapon::give_weapon_to_ped(iLocal_1803, joaat("weapon_smg"), -1, 1, 1);
		}
		if (!ped::is_ped_injured(iLocal_1803)) {
			func_363(&uLocal_2005, 5, iLocal_1803, "OJAcsGUARD2", 0, 1);
		}
		ped::set_ped_relationship_group_hash(iLocal_1802, iLocal_1975);
		ped::set_blocking_of_non_temporary_events(iLocal_1802, 1);
	}
}

// Position - 0x13F3B
int func_322(float fParam0, int iParam1) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
			func_323(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), fParam0, 1, 1056964608, 0, 1, 0) &&
			!entity::is_entity_in_air(player::player_ped_id()) ||
		!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!func_29(&uLocal_129)) {
			func_30(&uLocal_129);
			if (entity::does_entity_exist(player::get_players_last_vehicle())) {
				iVar0 = player::get_players_last_vehicle();
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					vehicle::set_vehicle_forward_speed(iVar0, 0f);
				}
			}
			player::set_player_control(player::player_id(), 0, 0);
		}
		else if (func_26(&uLocal_129) > 1f || iParam1 == 0) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x13FE3
int func_323(int iParam0, float fParam1, int iParam2, float fParam3, int iParam4, int iParam5, int iParam6) {
	controls::disable_control_action(0, 71, 1);
	controls::disable_control_action(0, 72, 1);
	controls::disable_control_action(0, 76, 1);
	controls::disable_control_action(0, 73, 1);
	controls::disable_control_action(0, 59, 1);
	controls::disable_control_action(0, 60, 1);
	if (iParam5) {
		controls::disable_control_action(0, 75, 1);
	}
	controls::disable_control_action(0, 80, 1);
	if (!iParam6) {
		controls::disable_control_action(0, 69, 1);
		controls::disable_control_action(0, 70, 1);
		controls::disable_control_action(0, 68, 1);
	}
	controls::disable_control_action(0, 74, 1);
	controls::disable_control_action(0, 86, 1);
	controls::disable_control_action(0, 81, 1);
	controls::disable_control_action(0, 82, 1);
	controls::disable_control_action(0, 138, 1);
	controls::disable_control_action(0, 136, 1);
	controls::disable_control_action(0, 114, 1);
	controls::disable_control_action(0, 107, 1);
	controls::disable_control_action(0, 110, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 87, 1);
	controls::disable_control_action(0, 88, 1);
	controls::disable_control_action(0, 113, 1);
	controls::disable_control_action(0, 115, 1);
	controls::disable_control_action(0, 116, 1);
	controls::disable_control_action(0, 117, 1);
	controls::disable_control_action(0, 118, 1);
	controls::disable_control_action(0, 119, 1);
	controls::disable_control_action(0, 131, 1);
	controls::disable_control_action(0, 132, 1);
	controls::disable_control_action(0, 123, 1);
	controls::disable_control_action(0, 126, 1);
	controls::disable_control_action(0, 129, 1);
	controls::disable_control_action(0, 130, 1);
	controls::disable_control_action(0, 133, 1);
	controls::disable_control_action(0, 134, 1);
	cam::_0x17FCA7199A530203();
	func_324(iParam0);
	if (gameplay::get_game_timer() - Global_29 > 500) {
		vehicle::_set_vehicle_halt(iParam0, fParam1, iParam2, iParam4);
	}
	Global_29 = gameplay::get_game_timer();
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (gameplay::absf(entity::get_entity_speed(iParam0)) <= fParam3) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x14176
void func_324(int iParam0) {
	if (vehicle::_get_has_vehicle_got_rocket_boost(iParam0)) {
		if (vehicle::_is_vehicle_rocket_boost_active(iParam0)) {
			vehicle::_set_rocket_boost_active(iParam0, 0);
		}
	}
}

// Position - 0x14197
void func_325() {
	func_334();
	func_332();
	if (!bLocal_1064 || bLocal_1714 == 1) {
		if (func_33(vLocal_1943, 0) < 500f) {
			if (func_331()) {
				func_223(1);
				func_223(2);
				func_329();
				bLocal_1064 = true;
			}
		}
	}
	if (player::get_player_wanted_level(player::player_id()) > 0) {
		if (func_70() || func_33(vLocal_1943, 1) < 25f) {
			bLocal_1714 = true;
		}
	}
	if (bLocal_1714) {
		streaming::end_srl();
		if (bLocal_1064) {
			func_40();
			iLocal_1030 = 9;
			return;
		}
	}
	switch (iLocal_1760) {
	case 0:
		if (!entity::does_entity_exist(uLocal_1787[0])) {
			func_317();
		}
		if (entity::is_entity_at_coord(player::player_ped_id(), vLocal_1943, 5f, 5f, 2f, 1, 1, 0)) {
		}
		if (func_327(vLocal_1943, 5f) && player::is_player_ready_for_cutscene(player::player_id())) {
			if (ui::does_blip_exist(iLocal_1709)) {
				ui::remove_blip(&iLocal_1709);
			}
			iLocal_1760++;
		}
		else {
			func_326();
		}
		break;

	case 1:
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
				func_323(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 10f, 1, 1056964608, 0, 1, 0) ||
			!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			if (!bLocal_1714) {
				func_30(&uLocal_2000);
				func_40();
				iLocal_1030 = 8;
			}
		}
		break;
	}
}

// Position - 0x142FD
void func_326() {
	if (!iLocal_1743) {
		if (func_33(vLocal_1943, 1) <= 100f) {
			streaming::prefetch_srl("ass_construction");
			iLocal_1743 = 1;
		}
	}
	else if (func_33(vLocal_1943, 1) > 120f) {
		if (streaming::is_srl_loaded()) {
			streaming::end_srl();
			iLocal_1743 = 0;
		}
	}
}

// Position - 0x14350
int func_327(vector3 vParam0, float fParam3) {
	if (func_33(vParam0, 1) <= fParam3 && !func_328()) {
		return 1;
	}
	return 0;
}

// Position - 0x14376
int func_328() {
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (vehicle::is_vehicle_model(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), joaat("taxi"))) {
			if (vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), -1, 0) !=
				player::player_ped_id()) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x143BA
void func_329() {
	if (!entity::does_entity_exist(Local_1645[0 /*19*/])) {
		Local_1645[0 /*19*/] = ped::create_ped(26, iLocal_1778[1], -111.9202f, -943.5192f, 28.2288f, 344.7112f, 1, 1);
		entity::set_entity_load_collision_flag(Local_1645[0 /*19*/], 1);
		ped::set_ped_combat_attributes(Local_1645[0 /*19*/], 50, 1);
		ped::stop_ped_weapon_firing_when_dropped(Local_1645[0 /*19*/]);
		func_330(0);
	}
	if (!entity::does_entity_exist(Local_1645[1 /*19*/])) {
		Local_1645[1 /*19*/] = ped::create_ped(26, iLocal_1778[1], -197.8959f, -1078.97f, 20.6882f, 166.4473f, 1, 1);
		entity::set_entity_load_collision_flag(Local_1645[1 /*19*/], 1);
		ped::set_ped_combat_attributes(Local_1645[1 /*19*/], 50, 1);
		ped::stop_ped_weapon_firing_when_dropped(Local_1645[1 /*19*/]);
		func_330(1);
	}
	if (!entity::does_entity_exist(Local_1645[2 /*19*/])) {
		Local_1645[2 /*19*/] = ped::create_ped(26, iLocal_1778[1], -82.0262f, -1023.124f, 27.3748f, 269.8311f, 1, 1);
		entity::set_entity_load_collision_flag(Local_1645[2 /*19*/], 1);
		ped::set_ped_combat_attributes(Local_1645[2 /*19*/], 50, 1);
		ped::stop_ped_weapon_firing_when_dropped(Local_1645[2 /*19*/]);
		func_330(2);
	}
}

// Position - 0x144D9
void func_330(int iParam0) {
	ped::set_blocking_of_non_temporary_events(Local_1645[iParam0 /*19*/], 1);
	weapon::give_weapon_to_ped(Local_1645[iParam0 /*19*/], joaat("weapon_microsmg"), -1, 0, 1);
	ped::set_ped_combat_movement(Local_1645[iParam0 /*19*/], 2);
	ped::set_ped_combat_range(Local_1645[iParam0 /*19*/], 2);
	ai::task_play_anim(Local_1645[iParam0 /*19*/], "oddjobs@assassinate@construction@", "unarmed_fold_arms", 8f, -4f,
					   -1, 1, 0, 0, 0, 0);
	ped::set_ped_relationship_group_hash(Local_1645[iParam0 /*19*/], iLocal_1975);
}

// Position - 0x14549
bool func_331() {
	int iVar0;

	streaming::request_model(iLocal_1778[0]);
	streaming::request_model(iLocal_1778[1]);
	if (streaming::has_model_loaded(iLocal_1778[0]) && streaming::has_model_loaded(iLocal_1778[1])) {
		iVar0 = 1;
	}
	else {
		iVar0 = 0;
	}
	return iVar0;
}

// Position - 0x1458C
void func_332() {
	if (!entity::does_entity_exist(iLocal_1974)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iLocal_1974 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
				if (entity::does_entity_exist(iLocal_1974) && !entity::is_entity_dead(iLocal_1974, 0)) {
					func_333(iLocal_1974);
				}
			}
		}
	}
}

// Position - 0x145E3
void func_333(int iParam0) { func_231(&Global_96040.f_2311, &Global_96040, iParam0, 1); }

// Position - 0x145FE
void func_334() {
	vector3 vVar0;

	if (!entity::does_entity_exist(iLocal_1036)) {
		return;
	}
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	}
	if (system::vdist2(vVar0, vLocal_1038) > 10000f) {
		if (entity::does_entity_exist(iLocal_1036)) {
			streaming::set_model_as_no_longer_needed(-1559354806);
			object::delete_object(&iLocal_1036);
		}
		if (entity::does_entity_exist(iLocal_1035)) {
			entity::set_entity_visible(iLocal_1035, 1, 0);
			entity::set_entity_collision(iLocal_1035, 1, 0);
		}
	}
}

// Position - 0x1467A
void func_335() {
	switch (iLocal_1033) {
	case 0:
		if (iLocal_1715 || fire::get_number_of_fires_in_range(vLocal_2175, 10f) > 0) {
			iLocal_1033 = 1;
		}
		break;

	case 1:
		if (!func_29(&uLocal_1985)) {
			func_30(&uLocal_1985);
			if (!ped::is_ped_injured(iLocal_1810)) {
				func_363(&uLocal_2005, 4, iLocal_1810, "OJAcsGUARD", 0, 1);
				func_58(&uLocal_2005, "OJASAUD", "OJAScs_ALERT", 8, 0, 0, 0);
				if (ai::get_script_task_status(iLocal_1810, -1253019028) == 1) {
					ped::_0xF1C03A5352243A30(iLocal_1810);
					ai::clear_ped_tasks(iLocal_1810);
				}
				if (!ped::is_ped_in_any_vehicle(iLocal_1810, 0)) {
					if (func_38(iLocal_1810, iLocal_1801, 1) > 5f) {
						ai::task_go_to_entity_while_aiming_at_entity(iLocal_1810, iLocal_1801, iLocal_1801, 2f, 0, 0.5f,
																	 1082130432, 1, 0, -957453492);
					}
					else {
						ai::task_aim_gun_at_entity(iLocal_1810, iLocal_1801, -1, 0);
					}
				}
			}
		}
		else if (func_26(&uLocal_1985) > 0.25f) {
			bLocal_1714 = true;
			iLocal_1033 = 2;
		}
		break;

	case 2: break;
	}
}

// Position - 0x1478B
int func_336() {
	int iVar0;

	if (!entity::is_entity_dead(iLocal_1801, 0)) {
		if (entity::is_entity_in_angled_area(iLocal_1801, -113.319f, -941.315f, -100f, -171.373f, -1095.764f, 100f,
											 100f, 0, 0, 0) ||
			entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[0 /*3*/], vLocal_1919[0 /*3*/], fLocal_1939[0], 0,
											 1, 0) ||
			entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[1 /*3*/], vLocal_1919[1 /*3*/], fLocal_1939[1], 0,
											 1, 0) ||
			entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[2 /*3*/], vLocal_1919[2 /*3*/], fLocal_1939[2], 0,
											 1, 0)) {
			bLocal_1740 = true;
		}
		else {
			bLocal_1740 = false;
		}
	}
	if (!iLocal_1741) {
		if (func_338() || bLocal_1714) {
			if (iLocal_1770 < 5) {
				iLocal_1770 = 5;
				iLocal_1741 = 1;
			}
		}
	}
	switch (iLocal_1770) {
	case 0:
		iVar0 = 0;
		while (iVar0 < 3) {
			if (!ped::is_ped_injured(Local_1645[iVar0 /*19*/])) {
				if (iLocal_1703[iVar0]) {
					ai::task_play_anim(Local_1645[iVar0 /*19*/], "oddjobs@assassinate@construction@",
									   "unarmed_fold_arms", 4f, -4f, -1, 1, 0, 0, 0, 0);
					iLocal_1703[iVar0] = 0;
				}
				if (entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[0 /*3*/], vLocal_1919[0 /*3*/],
													 fLocal_1939[0], 0, 1, 0)) {
					iLocal_1771 = 0;
				}
				else if (entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[1 /*3*/], vLocal_1919[1 /*3*/],
														  fLocal_1939[1], 0, 1, 0)) {
					iLocal_1771 = 1;
				}
				else if (entity::is_entity_in_angled_area(iLocal_1801, vLocal_1929[2 /*3*/], vLocal_1919[2 /*3*/],
														  fLocal_1939[2], 0, 1, 0)) {
					iLocal_1771 = 2;
				}
				else {
					iLocal_1771 = -1;
				}
				if (iLocal_1771 != -1) {
					if (!func_29(&uLocal_1982)) {
						func_61(&uLocal_1982);
					}
					else {
						func_30(&uLocal_1982);
					}
					if (!ped::is_ped_injured(Local_1645[iLocal_1771 /*19*/])) {
						ai::task_turn_ped_to_face_entity(Local_1645[iLocal_1771 /*19*/], player::player_ped_id(), -1);
					}
					iLocal_1770 = 1;
					break;
				}
			}
			iVar0++;
		}
		break;

	case 1:
		func_363(&uLocal_2005, 8, Local_1645[iLocal_1771 /*19*/], "OJAScsWARN1", 0, 1);
		if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_WRN1", 9, 0, 0, 0)) {
			iLocal_1770 = 2;
		}
		break;

	case 2:
		if (func_29(&uLocal_1982)) {
			if (func_26(&uLocal_1982) > IntToFloat(iLocal_1772)) {
				if (!func_337() && bLocal_1740) {
					iLocal_1770 = 3;
				}
				else if (!func_337()) {
					iLocal_1770 = 0;
				}
				else {
					iLocal_1770 = 3;
				}
			}
		}
		break;

	case 3:
		if (!ped::is_ped_injured(Local_1645[iLocal_1771 /*19*/])) {
			func_363(&uLocal_2005, 8, Local_1645[iLocal_1771 /*19*/], "OJAScsWARN1", 0, 1);
			if (func_58(&uLocal_2005, "OJASAUD", "OJAScs_WRN2", 9, 0, 0, 0)) {
				if (!ped::is_ped_injured(Local_1645[iLocal_1771 /*19*/])) {
					ai::task_aim_gun_at_entity(Local_1645[iLocal_1771 /*19*/], player::player_ped_id(), -1, 1);
					iLocal_1703[iLocal_1771] = 1;
				}
				if (func_29(&uLocal_1982)) {
					func_30(&uLocal_1982);
				}
				iLocal_1770 = 4;
			}
		}
		else {
			iLocal_1770 = 0;
		}
		break;

	case 4:
		if (func_29(&uLocal_1982)) {
			if (func_26(&uLocal_1982) > IntToFloat(iLocal_1773)) {
				if (bLocal_1740) {
					func_363(&uLocal_2005, 8, Local_1645[iLocal_1771 /*19*/], "OJAScsWARN1", 0, 1);
					func_58(&uLocal_2005, "OJASAUD", "OJAScs_WRN3", 9, 0, 0, 0);
					iLocal_1770 = 5;
				}
				else {
					iLocal_1770 = 0;
				}
			}
		}
		break;

	case 5:
		iVar0 = 0;
		while (iVar0 < 3) {
			if (!ped::is_ped_injured(Local_1645[iVar0 /*19*/])) {
				ai::clear_ped_tasks(Local_1645[iVar0 /*19*/]);
				ai::task_combat_ped(Local_1645[iVar0 /*19*/], player::player_ped_id(), 0, 16);
			}
			iVar0++;
		}
		bLocal_1714 = true;
		iLocal_1770 = 6;
		break;

	case 6: return 1;
	}
	return 0;
}

// Position - 0x14B70
int func_337() {
	int iVar0;

	if (!ped::is_ped_injured(player::player_ped_id())) {
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1);
		if (iVar0 != joaat("weapon_unarmed")) {
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x14BA6
int func_338() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (!entity::is_entity_dead(Local_1645[iVar0 /*19*/], 0)) {
			if (func_72(Local_1645[iVar0 /*19*/], 0, &Local_122, &iLocal_133, 0, 1, 0, 0, 1)) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x14BED
void func_339() {
	func_361();
	func_360();
	func_359();
	func_358(0);
	func_357();
	func_356();
	func_40();
	if (bLocal_1727) {
		if (Global_101700.f_18922.f_9 != 0f) {
			func_31(&uLocal_1976, Global_101700.f_18922.f_9);
		}
		if (iLocal_1775 == 0) {
			func_355();
		}
		else if (iLocal_1775 == 1) {
			func_354();
		}
		else if (iLocal_1775 == 2) {
			func_350();
		}
		else if (iLocal_1775 == 3) {
			func_348();
		}
		else if (iLocal_1775 == 4) {
			func_343();
		}
	}
	else {
		if (!func_29(&uLocal_1976)) {
			func_61(&uLocal_1976);
			Global_101700.f_18922.f_9 = 0f;
		}
		func_340(1);
		func_226(0, "assassin_construction_get_to_site", 0, 0, 0, 1);
		func_333(iLocal_1974);
		iLocal_1030 = 7;
	}
}

// Position - 0x14CB5
void func_340(int iParam0) {
	if (!ui::does_blip_exist(iLocal_1709)) {
		iLocal_1709 = func_342(vLocal_1943, 1);
		ui::set_blip_name_from_text_file(iLocal_1709, "ASS_CS_STATION");
		func_341(&iLocal_1709, -79.8767f, -917.7642f, 28.1898f, 269.6892f);
		if (iParam0) {
			func_32("ASS_CS_GOSITE", 7500, 1);
			audio::trigger_music_event("ASS5_DRIVE");
		}
	}
}

// Position - 0x14D15
void func_341(int iParam0, vector3 vParam1, float fParam4) {
	if (ui::does_blip_exist(*iParam0)) {
		Global_100736 = *iParam0;
		Global_100741 = {vParam1};
		Global_100745 = fParam4;
	}
}

// Position - 0x14D3E
int func_342(vector3 vParam0, int iParam3) {
	int iVar0;

	iVar0 = ui::add_blip_for_coord(vParam0);
	ui::set_blip_scale(iVar0, func_121(network::network_is_game_in_progress(), 1f, 1f));
	ui::set_blip_route(iVar0, iParam3);
	return iVar0;
}

// Position - 0x14D6A
void func_343() {
	func_298(1, 0);
	player::clear_player_wanted_level(player::player_id());
	func_345(0, -1, 1);
	cam::set_gameplay_cam_relative_heading(0f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	func_344(500);
	iLocal_1030 = 16;
}

// Position - 0x14DA2
void func_344(int iParam0) {
	if (!cam::is_screen_faded_in()) {
		cam::do_screen_fade_in(iParam0);
		while (!cam::is_screen_faded_in()) {
			system::wait(0);
		}
	}
}

// Position - 0x14DC8
void func_345(int iParam0, int iParam1, int iParam2) {
	if (func_438() && func_347()) {
		while (Global_91486 != 6) {
			system::wait(0);
		}
		gameplay::set_game_paused(0);
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::clear_ped_wetness(player::player_ped_id());
			}
		}
		if (iParam0 != 0) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (entity::does_entity_exist(iParam0)) {
					if (vehicle::is_vehicle_driveable(iParam0, 0)) {
						if (!ped::is_ped_in_vehicle(player::player_ped_id(), iParam0, 0)) {
							ped::set_ped_into_vehicle(player::player_ped_id(), iParam0, iParam1);
							cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
							cam::set_gameplay_cam_relative_heading(0f);
							system::wait(0);
						}
					}
				}
			}
		}
		if (iParam2 == 1) {
			if (player::is_player_playing(player::player_id())) {
				player::set_player_control(player::player_id(), 1, 0);
			}
		}
		graphics::_stop_all_screen_effects();
		func_346(0);
	}
}

// Position - 0x14E8C
void func_346(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&Global_91491.f_20, 13);
	}
	else {
		gameplay::clear_bit(&Global_91491.f_20, 13);
	}
}

// Position - 0x14EB5
var func_347() { return gameplay::is_bit_set(Global_91491.f_20, 13); }

// Position - 0x14EC9
void func_348() {
	while (!func_331()) {
		system::wait(0);
	}
	while (!func_349()) {
		system::wait(0);
	}
	func_298(1, 0);
	func_222(1);
	func_223(5);
	player::clear_player_wanted_level(player::player_id());
	ped::_0x2208438012482A1A(iLocal_1801, 1, 0);
	ai::task_put_ped_directly_into_cover(iLocal_1801, vLocal_1957, -1, 0, 0f, 0, 0, 0, 0);
	func_345(0, -1, 1);
	cam::set_gameplay_cam_relative_heading(90f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	func_344(500);
	iLocal_1063 = 0;
	iLocal_1755 = 0;
	audio::trigger_music_event("ASS5_RESTART3");
	iLocal_1030 = 13;
}

// Position - 0x14F5C
int func_349() {
	int iVar0;

	streaming::request_model(iLocal_1785);
	if (streaming::has_model_loaded(iLocal_1785)) {
		iVar0 = 1;
	}
	else {
		iVar0 = 0;
	}
	return iVar0;
}

// Position - 0x14F80
void func_350() {
	while (!func_331()) {
		system::wait(0);
	}
	func_223(3);
	if (!ped::is_ped_injured(Local_1356[0 /*19*/])) {
		entity::set_entity_coords(Local_1356[0 /*19*/], -152.2697f, -1003.765f, 113.1382f, 1, 0, 0, 1);
	}
	func_309();
	func_308(0);
	func_353(joaat("weapon_pistol"), 50);
	func_220(3, 0);
	func_351();
	if (!func_29(&uLocal_1994)) {
		func_61(&uLocal_1994);
	}
	else {
		func_30(&uLocal_1994);
	}
	audio::trigger_music_event("ASS5_RESTART2");
	ped::_0x2208438012482A1A(iLocal_1801, 1, 0);
	ai::task_put_ped_directly_into_cover(iLocal_1801, -182.1094f, -1004.058f, 113.1362f, -1, 0, 0f, 0, 0, 0, 0);
	func_345(0, -1, 1);
	cam::set_gameplay_cam_relative_heading(90f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	player::clear_player_wanted_level(player::player_id());
	func_344(500);
	iLocal_1030 = 11;
}

// Position - 0x1505F
void func_351() {
	iLocal_2173 = func_352(1);
	if (iLocal_2173 != 0) {
		weapon::give_weapon_to_ped(player::player_ped_id(), iLocal_2173, 0, 0, 0);
	}
	else {
		iLocal_2173 = weapon::get_best_ped_weapon(player::player_ped_id(), 0);
		weapon::give_weapon_to_ped(player::player_ped_id(), iLocal_2173, 0, 0, 0);
	}
}

// Position - 0x150A1
var func_352(int iParam0) {
	if (Global_91528 > 0) {
		return Global_96040.f_21[iParam0];
	}
	return Global_93635.f_21[iParam0];
}

// Position - 0x150CB
void func_353(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (weapon::has_ped_got_weapon(player::player_ped_id(), iParam0, 0)) {
			iVar0 = weapon::get_ammo_in_ped_weapon(player::player_ped_id(), iParam0);
			if (iVar0 < iParam1) {
				weapon::set_ped_ammo(player::player_ped_id(), iParam0, iParam1, 0);
			}
		}
		else {
			iVar0 = weapon::get_ammo_in_ped_weapon(player::player_ped_id(), iParam0);
			if (iVar0 < iParam1) {
				weapon::set_ped_ammo(player::player_ped_id(), iParam0, iParam1, 0);
			}
			weapon::give_weapon_to_ped(player::player_ped_id(), iParam0, 0, 0, 0);
		}
	}
}

// Position - 0x1513D
void func_354() {
	bLocal_1714 = false;
	while (!func_331()) {
		system::wait(0);
	}
	func_223(1);
	func_223(2);
	func_329();
	streaming::end_srl();
	func_351();
	audio::trigger_music_event("ASS5_RESTART1");
	func_345(0, -1, 1);
	cam::set_gameplay_cam_relative_heading(0f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	player::clear_player_wanted_level(player::player_id());
	func_344(500);
	iLocal_1030 = 9;
}

// Position - 0x151A2
void func_355() {
	bLocal_1064 = false;
	func_340(1);
	func_345(0, -1, 1);
	cam::set_gameplay_cam_relative_heading(0f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	player::clear_player_wanted_level(player::player_id());
	func_344(500);
	iLocal_1030 = 7;
}

// Position - 0x151DC
void func_356() {
	if (!object::does_pickup_exist(uLocal_2171)) {
		iLocal_1776 = 0;
		gameplay::set_bit(&iLocal_1776, 3);
		gameplay::set_bit(&iLocal_1776, 4);
		uLocal_2171 =
			object::create_pickup(joaat("pickup_parachute"), -140.6149f, -945.9811f, 268.1331f, iLocal_1776, 1, 1, 0);
		if (!object::does_pickup_exist(uLocal_2172)) {
			uLocal_2172 = object::create_pickup_rotate(joaat("pickup_parachute"), -149.709f, -966.41f, 269.23f, 87f,
													   22f, 90f, 0, -1, 2, 1, 0);
		}
	}
}

// Position - 0x1525E
void func_357() {
	if (!object::does_pickup_exist(uLocal_2170)) {
		uLocal_2170 = object::create_pickup_rotate(joaat("pickup_health_standard"), -170.47f, -1016.089f, 114.537f, 0f,
												   0f, 65f, 0, -1, 2, 1, 0);
	}
}

// Position - 0x15298
void func_358(int iParam0) {
	int iVar0;
	vector3 vVar1[5];
	float fVar17[5];

	vVar1[0 /*3*/] = {-113.3033f, -958.0001f, 26.2774f};
	vVar1[1 /*3*/] = {-143.1153f, -1007.305f, 26.2751f};
	vVar1[2 /*3*/] = {-185.375f, -1036.015f, 26.1f};
	vVar1[3 /*3*/] = {-130.0018f, -970.9893f, 26.3f};
	vVar1[4 /*3*/] = {-162.4316f, -1039.58f, 26.2758f};
	fVar17[0] = 160.3873f;
	fVar17[1] = 149.8891f;
	fVar17[2] = 254.0606f;
	fVar17[3] = 353.8129f;
	fVar17[4] = 314.2361f;
	iVar0 = 0;
	while (iVar0 < 5) {
		if (iParam0) {
			if (entity::does_entity_exist(uLocal_1795[iVar0])) {
				entity::set_object_as_no_longer_needed(&uLocal_1795[iVar0]);
			}
		}
		else if (!entity::does_entity_exist(uLocal_1795[iVar0])) {
			uLocal_1795[iVar0] = object::create_object(-1951226014, vVar1[iVar0 /*3*/], 1, 1, 0);
			entity::set_entity_heading(uLocal_1795[iVar0], fVar17[iVar0]);
			entity::freeze_entity_position(uLocal_1795[iVar0], 1);
		}
		iVar0++;
	}
}

// Position - 0x153C4
void func_359() {
	StringCopy(&Local_726, "ASS_CS_PASSED", 24);
	MemCopy(&Local_726.f_6, {Global_55837}, 6);
	StringCopy(&Local_726.f_12, "ASS_CS_TIMER", 24);
	StringCopy(&Local_726.f_18, "ASS_CS_BASE", 24);
	StringCopy(&Local_726.f_24, "ASS_CS_BDESC", 24);
	StringCopy(&Local_726.f_30, "ASS_CS_CASH", 24);
	StringCopy(&Local_726.f_36, "ASS_CS_COMP", 24);
	StringCopy(&Local_726.f_42, "ASS_CS_COMP", 24);
	StringCopy(&Local_726.f_48, "ASS_CS_COMP", 24);
	StringCopy(&Local_726.f_54, "ASS_CS_COMP", 24);
}

// Position - 0x1543A
void func_360() {
	if (!entity::does_entity_exist(iLocal_1969)) {
		iLocal_1969 = vehicle::create_vehicle(iLocal_1781, vLocal_1814, fLocal_1758, 1, 1);
	}
	if (!entity::does_entity_exist(iLocal_1970)) {
		iLocal_1970 = vehicle::create_vehicle(iLocal_1782, -130.3431f, -1096.441f, 21.3323f, 337f, 1, 1);
		audio::_dynamic_mixer_related_fn(iLocal_1970, "ASSASSINATION_CONSTRUCT_CAR_GROUP", 0);
	}
}

// Position - 0x15498
void func_361() {
	iLocal_1756 = cam::create_camera_with_params(26379945, -150.9599f, -944.2627f, 114.3693f, 3.6074f, -0.2888f,
												 15.6398f, 50f, 0, 2);
	iLocal_1757 = cam::create_camera_with_params(26379945, -150.6499f, -945.0825f, 114.3487f, 1.2634f, -0.2776f,
												 28.5068f, 50f, 0, 2);
}

// Position - 0x15502
bool func_362() {
	int iVar0;

	iVar0 = 0;
	if (streaming::has_model_loaded(iLocal_1781) && streaming::has_model_loaded(iLocal_1782) &&
		streaming::has_model_loaded(iLocal_1783) && streaming::has_model_loaded(iLocal_1784) &&
		streaming::has_model_loaded(-1951226014) && streaming::has_model_loaded(iLocal_1786) &&
		ui::has_additional_text_loaded(3) && streaming::has_anim_dict_loaded("oddjobs@assassinate@construction@") &&
		ai::get_is_waypoint_recording_loaded("OJAScs_101") &&
		vehicle::has_vehicle_recording_been_loaded(102, "OJAScs") &&
		audio::request_script_audio_bank("Freight_Elevator", 0, -1) &&
		audio::request_script_audio_bank("SCRIPT\ASSASSINATION_MULTI", 0, -1)) {
		iVar0 = 1;
	}
	return iVar0;
}

// Position - 0x155AE
void func_363(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x15649
void func_364() {
	vLocal_1849[0 /*3*/] = {-139.7842f, -992.1964f, 26.2754f};
	vLocal_1849[1 /*3*/] = {-119.2258f, -986.6719f, 26.28716f};
	vLocal_1849[2 /*3*/] = {-129.0208f, -981.0884f, 26.2754f};
	ai::open_patrol_route("miss_Ass0");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[0 /*3*/], -139.4077f, -993.4732f, 26.2754f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[1 /*3*/], -116.1392f, -987.4984f, 26.38541f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(2, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[2 /*3*/], -128.4685f, -979.0341f, 26.2754f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 2);
	ai::add_patrol_route_link(2, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[3 /*3*/] = {-138.6994f, -979.7902f, 27.3835f};
	vLocal_1849[4 /*3*/] = {-168.261f, -970.3499f, 28.3159f};
	vLocal_1849[5 /*3*/] = {-150.2031f, -982.3716f, 27.3835f};
	ai::open_patrol_route("miss_Ass1");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[3 /*3*/], -138.0908f, -980.1388f, 26.3835f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[4 /*3*/], 0f, 0f, 0f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(2, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[5 /*3*/], -150.6753f, -982.7073f, 26.3835f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 2);
	ai::add_patrol_route_link(2, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[6 /*3*/] = {-119.74f, -987.43f, 27.2835f};
	vLocal_1849[7 /*3*/] = {-126.7858f, -1005.104f, 26.2731f};
	vLocal_1849[8 /*3*/] = {-134.0714f, -1033.095f, 26.2731f};
	ai::open_patrol_route("miss_Ass2");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[6 /*3*/], 0f, 0f, 0f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[7 /*3*/], 0f, 0f, 0f, 0);
	ai::add_patrol_route_node(2, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[8 /*3*/], 0f, 0f, 0f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 2);
	ai::add_patrol_route_link(2, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[9 /*3*/] = {-118.0965f, -1040.031f, 26.274f};
	vLocal_1849[10 /*3*/] = {-114.6962f, -1053.844f, 26.2942f};
	vLocal_1849[11 /*3*/] = {-143.5082f, -1044.117f, 26.2913f};
	ai::open_patrol_route("miss_Ass3");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[9 /*3*/], -108.7927f, -1033.771f, 26.2731f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[10 /*3*/], -115.0062f, -1054.933f, 26.2892f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(2, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[11 /*3*/], -144.801f, -1043.662f, 26.2912f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 2);
	ai::add_patrol_route_link(2, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[12 /*3*/] = {-129.831f, -1003.887f, 26.2731f};
	vLocal_1849[13 /*3*/] = {-142.1477f, -1007.604f, 26.2731f};
	ai::open_patrol_route("miss_Ass4");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[12 /*3*/], -130.3284f, -998.4552f, 26.2731f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[13 /*3*/], -142.5782f, -1008.276f, 26.2731f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[14 /*3*/] = {-193.2124f, -1058.531f, 23.4276f};
	vLocal_1849[15 /*3*/] = {-176.157f, -1028.944f, 27.2832f};
	vLocal_1849[16 /*3*/] = {-170.2736f, -1037.587f, 27.28f};
	ai::open_patrol_route("miss_Ass5");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[14 /*3*/], -194.7176f, -1062.09f, 21.8847f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[15 /*3*/], -167.7465f, -1038.089f, 26.2798f, 0);
	ai::add_patrol_route_node(2, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[16 /*3*/], -194.7176f, -1062.09f, 21.8847f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 2);
	ai::add_patrol_route_link(2, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
	vLocal_1849[17 /*3*/] = {-180.4631f, -1022.162f, 28.2893f};
	vLocal_1849[18 /*3*/] = {-188.5225f, -1019.491f, 28.2893f};
	ai::open_patrol_route("miss_Ass6");
	ai::add_patrol_route_node(0, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[17 /*3*/], -194.4449f, -1017.974f, 28.2895f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_node(1, "WORLD_HUMAN_GUARD_STAND", vLocal_1849[18 /*3*/], -182.4519f, -1021.044f, 28.2863f,
							  gameplay::get_random_int_in_range(5000, 10000));
	ai::add_patrol_route_link(0, 1);
	ai::add_patrol_route_link(1, 0);
	ai::close_patrol_route();
	ai::create_patrol_route();
}

// Position - 0x15BDA
void func_365() {
	Local_1202[0 /*19*/].f_10 = {-132.1519f, -983.1443f, 26.2731f};
	Local_1202[0 /*19*/].f_13 = 320.6974f;
	Local_1202[0 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1202[0 /*19*/].f_15 = 2;
	Local_1202[0 /*19*/].f_16 = 1;
	Local_1202[0 /*19*/].f_17 = 2;
	Local_1202[0 /*19*/].f_18 = 0;
	Local_1202[1 /*19*/].f_10 = {-128.4393f, -1007.132f, 26.2731f};
	Local_1202[1 /*19*/].f_13 = 347.4975f;
	Local_1202[1 /*19*/].f_14 = joaat("weapon_pumpshotgun");
	Local_1202[1 /*19*/].f_15 = 2;
	Local_1202[1 /*19*/].f_16 = 0;
	Local_1202[1 /*19*/].f_17 = 2;
	Local_1202[1 /*19*/].f_18 = 0;
	Local_1202[2 /*19*/].f_10 = {-170.5017f, -969.5618f, 28.2893f};
	Local_1202[2 /*19*/].f_13 = 158f;
	Local_1202[2 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1202[2 /*19*/].f_15 = 1;
	Local_1202[2 /*19*/].f_16 = 1;
	Local_1202[2 /*19*/].f_17 = 2;
	Local_1202[2 /*19*/].f_18 = 0;
	Local_1202[3 /*19*/].f_10 = {-189.2459f, -1014.732f, 28.2884f};
	Local_1202[3 /*19*/].f_13 = 238.8071f;
	Local_1202[3 /*19*/].f_14 = joaat("weapon_assaultrifle");
	Local_1202[3 /*19*/].f_15 = 1;
	Local_1202[3 /*19*/].f_16 = 1;
	Local_1202[3 /*19*/].f_17 = 2;
	Local_1202[3 /*19*/].f_18 = 13;
	Local_1202[4 /*19*/].f_10 = {-118.25f, -1051.072f, 27.3f};
	Local_1202[4 /*19*/].f_13 = 286.918f;
	Local_1202[4 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1202[4 /*19*/].f_15 = 1;
	Local_1202[4 /*19*/].f_16 = 1;
	Local_1202[4 /*19*/].f_17 = 2;
	Local_1202[4 /*19*/].f_18 = 0;
	Local_1298[0 /*19*/].f_10 = {-137.2297f, -1095.23f, 20.6838f};
	Local_1298[0 /*19*/].f_13 = 160f;
	Local_1298[0 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1298[0 /*19*/].f_15 = 2;
	Local_1298[0 /*19*/].f_16 = 1;
	Local_1298[0 /*19*/].f_17 = 2;
	Local_1298[0 /*19*/].f_18 = 0;
	Local_1298[1 /*19*/].f_10 = {-135.9752f, -1091.701f, 20.6838f};
	Local_1298[1 /*19*/].f_13 = 160f;
	Local_1298[1 /*19*/].f_14 = joaat("weapon_microsmg");
	Local_1298[1 /*19*/].f_15 = 1;
	Local_1298[1 /*19*/].f_16 = 1;
	Local_1298[1 /*19*/].f_17 = 2;
	Local_1298[1 /*19*/].f_18 = 0;
	Local_1298[2 /*19*/].f_10 = {-136.1536f, -1092.415f, 20.6838f};
	Local_1298[2 /*19*/].f_13 = 160f;
	Local_1298[2 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1298[2 /*19*/].f_15 = 1;
	Local_1298[2 /*19*/].f_16 = 1;
	Local_1298[2 /*19*/].f_17 = 2;
	Local_1298[2 /*19*/].f_18 = 0;
	Local_1356[0 /*19*/].f_10 = {-176.6884f, -999.788f, 113.1382f};
	Local_1356[0 /*19*/].f_13 = 165.9047f;
	Local_1356[0 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1356[0 /*19*/].f_15 = 1;
	Local_1356[0 /*19*/].f_16 = 0;
	Local_1356[0 /*19*/].f_17 = 2;
	Local_1356[0 /*19*/].f_18 = 13;
	Local_1356[1 /*19*/].f_10 = {-157.008f, -979.8131f, 113.133f};
	Local_1356[1 /*19*/].f_13 = 246.3884f;
	Local_1356[1 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1356[1 /*19*/].f_15 = 1;
	Local_1356[1 /*19*/].f_16 = 0;
	Local_1356[1 /*19*/].f_17 = 2;
	Local_1356[1 /*19*/].f_18 = 13;
	Local_1356[2 /*19*/].f_10 = {-154.27f, -945.61f, 113.1339f};
	Local_1356[2 /*19*/].f_13 = 160.8846f;
	Local_1356[2 /*19*/].f_14 = joaat("weapon_carbinerifle");
	Local_1356[2 /*19*/].f_15 = 1;
	Local_1356[2 /*19*/].f_16 = 0;
	Local_1356[2 /*19*/].f_17 = 2;
	Local_1356[2 /*19*/].f_18 = 13;
	Local_1356[3 /*19*/].f_10 = {-145.5338f, -986.0398f, 113.1282f};
	Local_1356[3 /*19*/].f_13 = 137f;
	Local_1356[3 /*19*/].f_14 = joaat("weapon_microsmg");
	Local_1356[3 /*19*/].f_15 = 1;
	Local_1356[3 /*19*/].f_16 = 0;
	Local_1356[3 /*19*/].f_17 = 2;
	Local_1356[3 /*19*/].f_18 = 13;
	Local_1356[4 /*19*/].f_10 = {-158.9804f, -951.3898f, 113.1328f};
	Local_1356[4 /*19*/].f_13 = 173f;
	Local_1356[4 /*19*/].f_14 = joaat("weapon_microsmg");
	Local_1356[4 /*19*/].f_15 = 1;
	Local_1356[4 /*19*/].f_16 = 0;
	Local_1356[4 /*19*/].f_17 = 2;
	Local_1356[4 /*19*/].f_18 = 13;
	Local_1356[5 /*19*/].f_10 = {-146.8379f, -964.5045f, 113.1339f};
	Local_1356[5 /*19*/].f_13 = 156.7863f;
	Local_1356[5 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1356[5 /*19*/].f_15 = 1;
	Local_1356[5 /*19*/].f_16 = 0;
	Local_1356[5 /*19*/].f_17 = 2;
	Local_1356[5 /*19*/].f_18 = 13;
	Local_1471[0 /*19*/].f_10 = {-152.9496f, -946.5169f, 123.2578f};
	Local_1471[0 /*19*/].f_13 = 124.2627f;
	Local_1471[0 /*19*/].f_14 = joaat("weapon_pumpshotgun");
	Local_1471[0 /*19*/].f_15 = 2;
	Local_1471[0 /*19*/].f_16 = 0;
	Local_1471[0 /*19*/].f_17 = 2;
	Local_1471[0 /*19*/].f_18 = 13;
	Local_1471[1 /*19*/].f_10 = {-151.9618f, -945.3404f, 123.2578f};
	Local_1471[1 /*19*/].f_13 = 338.7249f;
	Local_1471[1 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1471[1 /*19*/].f_15 = 1;
	Local_1471[1 /*19*/].f_16 = 0;
	Local_1471[1 /*19*/].f_17 = 2;
	Local_1471[1 /*19*/].f_18 = 13;
	Local_1510[0 /*19*/].f_10 = {-147.7198f, -952.7476f, 268.135f};
	Local_1510[0 /*19*/].f_13 = 14.5077f;
	Local_1510[0 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1510[0 /*19*/].f_15 = 2;
	Local_1510[0 /*19*/].f_16 = 0;
	Local_1510[0 /*19*/].f_17 = 2;
	Local_1510[0 /*19*/].f_18 = 13;
	Local_1510[1 /*19*/].f_10 = {-156.9518f, -966.8706f, 268.2581f};
	Local_1510[1 /*19*/].f_13 = 336.0895f;
	Local_1510[1 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1510[1 /*19*/].f_15 = 2;
	Local_1510[1 /*19*/].f_16 = 0;
	Local_1510[1 /*19*/].f_17 = 2;
	Local_1510[1 /*19*/].f_18 = 13;
	Local_1510[2 /*19*/].f_10 = {-147.4382f, -967.9998f, 268.1325f};
	Local_1510[2 /*19*/].f_13 = 50.9751f;
	Local_1510[2 /*19*/].f_14 = joaat("weapon_pistol");
	Local_1510[2 /*19*/].f_15 = 1;
	Local_1510[2 /*19*/].f_16 = 1;
	Local_1510[2 /*19*/].f_17 = 2;
	Local_1510[2 /*19*/].f_18 = 13;
	Local_1510[3 /*19*/].f_10 = {vLocal_1811};
	Local_1510[3 /*19*/].f_13 = 90f;
	Local_1510[3 /*19*/].f_14 = joaat("weapon_carbinerifle");
	Local_1510[3 /*19*/].f_15 = 1;
	Local_1510[3 /*19*/].f_16 = 2;
	Local_1510[3 /*19*/].f_17 = 2;
	Local_1510[3 /*19*/].f_18 = 13;
	ped::add_relationship_group("ConstructionEnemies", &iLocal_1975);
	ped::set_relationship_between_groups(5, iLocal_1975, 1862763509);
	ped::set_relationship_between_groups(5, 1862763509, iLocal_1975);
}

// Position - 0x162D7
void func_366() {
	vLocal_1842[0 /*3*/] = {-182.24f, -1016.44f, 28.59f};
	vLocal_1832[0 /*3*/] = {0f, 0f, 250.24f};
	vLocal_1842[1 /*3*/] = {-158.84f, -942.24f, 112.8f};
	vLocal_1832[1 /*3*/] = {0f, 0f, 160.2f};
}

// Position - 0x1632B
void func_367() {
	fLocal_135 = 8000f;
	fLocal_136 = 2000f;
}

// Position - 0x16341
void func_368() {
	streaming::request_model(iLocal_1781);
	streaming::request_model(iLocal_1782);
	streaming::request_model(iLocal_1783);
	streaming::request_model(iLocal_1784);
	streaming::request_model(-1951226014);
	streaming::request_model(iLocal_1786);
	streaming::request_anim_dict("oddjobs@assassinate@construction@");
	ai::request_waypoint_recording("OJAScs_101");
	vehicle::request_vehicle_recording(102, "OJAScs");
	audio::request_script_audio_bank("Freight_Elevator", 0, -1);
	audio::request_script_audio_bank("SCRIPT\ASSASSINATION_MULTI", 0, -1);
	ui::request_additional_text("ASS_CS", 3);
}

// Position - 0x163AE
void func_369() {
	iLocal_1778[0] = joaat("a_m_y_business_01");
	iLocal_1778[1] = joaat("s_m_m_highsec_01");
	iLocal_1781 = joaat("utillitruck3");
	iLocal_1782 = joaat("seminole");
	iLocal_1783 = joaat("prop_conslift_door");
	iLocal_1784 = joaat("prop_conslift_lift");
	iLocal_1785 = joaat("maverick");
	iLocal_1786 = joaat("prop_sub_release");
}

// Position - 0x163FC
void func_370() {
	switch (iLocal_1034) {
	case 0:
		streaming::request_anim_dict("oddjobs@assassinate@construction@call");
		streaming::request_model(-1559354806);
		if (streaming::has_anim_dict_loaded("oddjobs@assassinate@construction@call") &&
			streaming::has_model_loaded(-1559354806)) {
			bLocal_1062 = true;
		}
		if (bLocal_1062) {
			if (entity::does_entity_exist(iLocal_1035)) {
				func_374(805.0217f, -1076.811f, 26.62203f, 813.8823f, -1076.814f, 32.50576f, 5f, 814.4346f, -1081.688f,
						 27.3991f, 90.2655f, 1, 1, 1, 0, 0);
				gameplay::clear_area(809.3085f, -1074.928f, 27.6018f, 3f, 1, 0, 0, 0);
				if (!func_29(&uLocal_1057)) {
					func_61(&uLocal_1057);
				}
				if (entity::does_entity_exist(iLocal_1035)) {
					entity::set_entity_visible(iLocal_1035, 0, 0);
					entity::set_entity_collision(iLocal_1035, 0, 0);
					entity::set_entity_can_be_damaged(iLocal_1035, 0);
					iLocal_1036 = object::create_object(-1559354806, 809.3085f, -1074.928f, 27.6018f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_1036, 0f, 0f, 0.091681f, 2, 1);
					entity::set_entity_collision(iLocal_1036, 0, 0);
					entity::set_entity_can_be_damaged(iLocal_1036, 0);
					entity::set_entity_visible(player::player_ped_id(), 1, 0);
				}
				iLocal_1201 = streaming::format_focus_heading(809.3085f, -1074.928f, 27.6018f, 350f, 12, 127);
				func_183(1, 1, 1, 0);
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
					entity::set_entity_coords(player::player_ped_id(), vLocal_1041, 1, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), fLocal_1044);
					weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
					ped::remove_ped_helmet(player::player_ped_id(), 1);
				}
				iLocal_1074 = ped::create_synchronized_scene(vLocal_1068, vLocal_1071, 2);
				if (entity::does_entity_exist(iLocal_1036)) {
					ped::attach_synchronized_scene_to_entity(iLocal_1074, iLocal_1036, -1);
				}
				ai::task_synchronized_scene(player::player_ped_id(), iLocal_1074,
											"oddjobs@assassinate@construction@call", "ass_construction_call_p1", 1000f,
											-2f, 2, 0, 1148846080, 0);
				entity::play_synchronized_entity_anim(iLocal_1036, iLocal_1074, "ass_construction_call_phone",
													  "oddjobs@assassinate@construction@call", 1000f, -2f, 0,
													  1148846080);
				graphics::remove_particle_fx_in_range(vLocal_1041, 5f);
				if (!cam::does_cam_exist(iLocal_1037)) {
					iLocal_1037 = cam::create_camera_with_params(26379945, vLocal_1048, vLocal_1051, 34.0542f, 1, 2);
					cam::render_script_cams(1, 0, 3000, 1, 0, 0);
					cam::shake_cam(iLocal_1037, "HAND_SHAKE", 0.2f);
				}
				func_363(&uLocal_2005, 3, 0, "LESTER", 0, 1);
				func_363(&uLocal_2005, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
				ui::display_radar(0);
				ui::display_hud(0);
				weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 0);
				player::set_player_control(player::player_id(), 0, 56);
				func_182(23, 1);
				iLocal_1034 = 1;
			}
			else {
				streaming::request_anim_dict("oddjobs@assassinate@construction@call");
				streaming::request_model(-1559354806);
				if (!entity::does_entity_exist(iLocal_1035)) {
					iLocal_1035 = object::get_closest_object_of_type(vLocal_1038, 5f, 1281992692, 1, 0, 1);
				}
			}
		}
		break;

	case 1:
		func_372();
		if (func_29(&uLocal_1054)) {
			if (func_26(&uLocal_1054) > 1f) {
				if (func_180()) {
					bLocal_1060 = true;
					if (!cam::is_screen_faded_out()) {
						func_371(800);
					}
					iLocal_1034 = 2;
					break;
				}
			}
		}
		if (!iLocal_1061) {
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				if (ped::is_synchronized_scene_running(iLocal_1074)) {
					if (ped::get_synchronized_scene_phase(iLocal_1074) > 0.05f) {
						if (func_58(&uLocal_2005, "OJASAUD", "OJAScnt_cs", 9, 0, 0, 0)) {
							if (!func_29(&uLocal_1054)) {
								func_61(&uLocal_1054);
								iLocal_1061 = 1;
								if (func_17(0)) {
									func_344(500);
								}
							}
						}
					}
				}
			}
		}
		if (func_29(&uLocal_1054)) {
			if (func_26(&uLocal_1054) > fLocal_1045 ||
				ped::is_synchronized_scene_running(iLocal_1074) &&
					ped::get_synchronized_scene_phase(iLocal_1074) >= 0.961f ||
				bLocal_1060) {
				iLocal_1034 = 3;
			}
		}
		break;

	case 2:
		audio::stop_scripted_conversation(0);
		if (bLocal_1060) {
			if (cam::is_screen_faded_out()) {
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
					entity::set_entity_coords(player::player_ped_id(), vLocal_1041, 1, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), fLocal_1044);
				}
				entity::stop_synchronized_entity_anim(iLocal_1036, -1000f, 1);
				system::wait(0);
				cam::do_screen_fade_in(500);
				cam::destroy_all_cams(0);
				cam::render_script_cams(0, 0, 3000, 1, 0, 0);
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				iLocal_1034 = 3;
			}
		}
		break;

	case 3:
		if (!bLocal_1060) {
			cam::_0xC819F3CBB62BF692(0, 0, 3, 0);
			cam::destroy_all_cams(0);
		}
		if (streaming::_0x07C313F94746702C(iLocal_1201)) {
			streaming::_0x1EE7D8DF4425F053(iLocal_1201);
		}
		entity::set_entity_collision(iLocal_1036, 1, 0);
		ui::display_radar(1);
		ui::display_hud(1);
		ai::clear_ped_tasks(player::player_ped_id());
		player::set_player_control(player::player_id(), 1, 0);
		ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 1, 0, 0);
		func_182(23, 0);
		func_183(0, 1, 1, 0);
		player::set_player_wanted_level(player::player_id(), 0, 0);
		player::set_player_wanted_level_now(player::player_id(), 0);
		streaming::remove_anim_dict("oddjobs@assassinate@construction@call");
		entity::set_object_as_no_longer_needed(&iLocal_1035);
		iLocal_1030 = 4;
		break;
	}
}

// Position - 0x168F0
int func_371(int iParam0) {
	cam::do_screen_fade_out(iParam0);
	while (!cam::is_screen_faded_out()) {
		system::wait(0);
	}
	return 1;
}

// Position - 0x1690F
void func_372() {
	switch (iLocal_1076) {
	case 0:
		if (func_373(&iLocal_1037, 4f, 799.7321f, -1083.417f, 30.3753f, -1.3455f, 0f, -42.1124f, 42.5517f, 1, 0.3f)) {
			iLocal_1076 = 1;
		}
		break;

	case 1:
		if (func_373(&iLocal_1037, 11f, 814.8909f, -1078.272f, 29.0784f, 0f, -0.0387f, 70.1654f, 30.1956f, 1, 0.3f)) {
			iLocal_1076 = 2;
		}
		break;

	case 2:
		if (func_373(&iLocal_1037, 20f, 808.044f, -1074.647f, 29.2119f, -4.8627f, 0f, -129.3806f, 36.3462f, 1, 0.3f)) {
			iLocal_1076 = 3;
		}
		break;

	case 3:
		if (func_373(&iLocal_1037, 25f, 814.8909f, -1078.272f, 29.0784f, 0f, -0.0387f, 70.1654f, 30.1956f, 1, 0.2f)) {
			iLocal_1076 = 4;
		}
		break;

	case 4:
		if (func_373(&iLocal_1037, 30f, 808.044f, -1074.647f, 29.2119f, -4.8627f, 0f, -129.3806f, 36.3462f, 1, 0.2f)) {
			iLocal_1076 = 5;
		}
		break;

	case 5:
		if (func_373(&iLocal_1037, 37f, 812.5805f, -1076.648f, 28.9375f, 2.1171f, 0.0247f, 79.0055f, 29.2734f, 1,
					 0.2f)) {
			iLocal_1076 = 6;
		}
		break;

	case 6: break;
	}
}

// Position - 0x16AAE
bool func_373(int iParam0, float fParam1, vector3 vParam2, vector3 vParam5, float fParam8, int iParam9,
			  float fParam10) {
	if (cam::does_cam_exist(*iParam0)) {
		if (func_29(&uLocal_1057)) {
			if (func_26(&uLocal_1057) >= fParam1) {
				cam::set_cam_coord(iLocal_1037, vParam2);
				cam::set_cam_rot(iLocal_1037, vParam5, 2);
				cam::set_cam_fov(iLocal_1037, fParam8);
				if (iParam9) {
					cam::shake_cam(iLocal_1037, "HAND_SHAKE", fParam10);
				}
				return true;
			}
		}
	}
	return false;
}

// Position - 0x16B0E
void func_374(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, int iParam11,
			  int iParam12, int iParam13, int iParam14, int iParam15) {
	func_375(vParam0, vParam3, fParam6, vParam7, fParam10, 0f, 0f, 0f, iParam11, iParam12, iParam13, iParam14,
			 iParam15);
}

// Position - 0x16B37
void func_375(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, vector3 vParam11,
			  bool bParam14, int iParam15, bool bParam16, bool bParam17, bool bParam18) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	int iVar3;
	vector3 vVar4;
	vector3 vVar7;
	vector3 vVar10;
	int iVar13;
	int iVar14;
	int iVar15;

	if (iParam15) {
		iParam15 = 0;
	}
	bVar2 = true;
	iVar3 = 0;
	iVar0 = player::get_players_last_vehicle();
	if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_a_mission_entity(iVar0)) {
			entity::set_entity_as_mission_entity(iVar0, 1, 0);
			iVar3 = 1;
		}
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			if (bParam18) {
				func_379(iVar0);
			}
			if (entity::is_entity_in_angled_area(iVar0, vParam0, vParam3, fParam6, 0, 1, 0)) {
				bVar1 = true;
			}
			else {
				vVar10 = {entity::get_entity_coords(iVar0, 1)};
				if (vVar10.z > vParam0.z && vVar10.z < vParam3.z || vVar10.z > vParam3.z && vVar10.z < vParam0.z) {
					if (func_376(iVar0, vParam0, vParam3, fParam6)) {
						bVar1 = true;
					}
				}
			}
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (vehicle::is_vehicle_model(iVar0, joaat("taxi"))) {
					if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != player::player_ped_id() &&
						vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != 0) {
						if (gameplay::get_distance_between_coords(vParam0 + vParam3 / FtoV(2f),
																  entity::get_entity_coords(iVar0, 1), 1) < 20f) {
							bVar1 = true;
							bVar2 = false;
						}
					}
				}
			}
			if (bParam16) {
				if (func_244(iVar0, func_10(), 1)) {
					bVar1 = false;
				}
			}
			if (bVar1) {
				if (!func_225(vParam11)) {
					if (vehicle::is_vehicle_driveable(iVar0, 0)) {
						iVar13 = entity::get_entity_model(iVar0);
						vehicle::_0xDF7E3EEB29642C38(iVar0, &vVar4, &vVar7);
						if (vehicle::is_this_model_a_heli(iVar13)) {
							vParam11.x += 3f;
							vParam11.y += 3f;
						}
						if (iVar13 == joaat("zentorno") || iVar13 == joaat("btype") || iVar13 == joaat("dubsta3") ||
							iVar13 == joaat("monster")) {
							vParam11 = {vParam11 * FtoV(1.1f)};
						}
						else if (iVar13 == joaat("t20") || iVar13 == joaat("virgo")) {
							vParam11 = {vParam11 * FtoV(1.2f)};
						}
						if (vVar7.x - vVar4.x > vParam11.x) {
							bVar2 = false;
						}
						else if (vVar7.y - vVar4.y > vParam11.y) {
							bVar2 = false;
						}
						else if (vVar7.z - vVar4.z > vParam11.z) {
							bVar2 = false;
						}
					}
				}
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (bVar2) {
						gameplay::clear_area_of_vehicles(vParam7, 5f, 0, 0, 0, 0, 0);
						entity::set_entity_heading(iVar0, fParam10);
						entity::set_entity_coords(iVar0, vParam7, 1, 0, 0, 1);
						vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
						if (bParam17) {
							vehicle::set_vehicle_engine_on(iVar0, 0, 1, 0);
							vehicle::set_vehicle_doors_shut(iVar0, 1);
						}
					}
					else {
						if (!entity::is_entity_a_mission_entity(iVar0) ||
							!entity::does_entity_belong_to_this_script(iVar0, 1)) {
							entity::set_entity_as_mission_entity(iVar0, 1, 1);
						}
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
							entity::set_entity_coords(player::player_ped_id(), entity::get_entity_coords(iVar0, 1), 1,
													  0, 0, 1);
						}
						vehicle::delete_vehicle(&iVar0);
					}
				}
			}
			if (bParam14) {
				gameplay::clear_angled_area_of_vehicles(vParam0, vParam3, fParam6, 0, 0, 0, 0, 0);
			}
			if (iVar3 == 1) {
				if (entity::does_entity_exist(iVar0)) {
					if (entity::is_entity_a_mission_entity(iVar0)) {
						entity::set_vehicle_as_no_longer_needed(&iVar0);
					}
				}
			}
		}
		else {
			if (!entity::is_entity_a_mission_entity(iVar0)) {
				entity::set_entity_as_mission_entity(iVar0, 1, 0);
			}
			iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0);
			if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
				entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
			}
			iVar15 = vehicle::get_vehicle_model_number_of_seats(entity::get_entity_model(iVar0));
			if (iVar15 <= 2) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			if (iVar15 <= 4) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 1, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 2, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			vehicle::delete_vehicle(&iVar0);
		}
	}
}

// Position - 0x16F29
bool func_376(int iParam0, vector3 vParam1, vector3 vParam4, float fParam7) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18[4];
	struct<2> Var31;
	struct<2> Var34;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		vParam1.z = vParam4.z;
		vVar0 = {func_378(vParam1 - vParam4)};
		vVar3 = {vVar0};
		vVar0.x = -vVar3.y;
		vVar0.y = vVar3.x;
		vVar0.z = 0f;
		vVar6 = {vParam1 - vVar0 * FtoV(fParam7 / 2f)};
		vVar9 = {vParam1 + vVar0 * FtoV(fParam7 / 2f)};
		vVar12 = {vParam4 - vVar0 * FtoV(fParam7 / 2f)};
		vVar15 = {vParam4 + vVar0 * FtoV(fParam7 / 2f)};
		gameplay::get_model_dimensions(entity::get_entity_model(iParam0), &Var31, &Var34);
		vVar18[0 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var31.f_1, 0f)};
		vVar18[1 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var34.f_1, 0f)};
		vVar18[2 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var31.f_1, 0f)};
		vVar18[3 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var34.f_1, 0f)};
		if (func_377(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar9) ||
			func_377(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar9, vVar15) ||
			func_377(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar12, vVar15) ||
			func_377(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar12) ||
			func_377(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar9) ||
			func_377(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar9, vVar15) ||
			func_377(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar12, vVar15) ||
			func_377(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar12) ||
			func_377(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar9) ||
			func_377(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar9, vVar15) ||
			func_377(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar12, vVar15) ||
			func_377(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar12) ||
			func_377(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar9) ||
			func_377(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar9, vVar15) ||
			func_377(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar12, vVar15) ||
			func_377(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar12)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1721F
int func_377(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5, struct<2> Param6, var uParam8,
			 struct<2> Param9, var uParam11) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;

	fVar0 = Param0;
	fVar1 = Param0.f_1;
	fVar2 = Param3;
	fVar3 = Param3.f_1;
	fVar4 = Param6;
	fVar5 = Param6.f_1;
	fVar6 = Param9;
	fVar7 = Param9.f_1;
	fVar8 = fVar2 - fVar0;
	fVar9 = fVar3 - fVar1;
	fVar10 = fVar6 - fVar4;
	fVar11 = fVar7 - fVar5;
	fVar12 = (-fVar9 * (fVar0 - fVar4) + fVar8 * (fVar1 - fVar5)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	fVar13 = (fVar10 * (fVar1 - fVar5) - fVar11 * (fVar0 - fVar4)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	if (fVar12 >= 0f && fVar12 <= 1f && fVar13 >= 0f && fVar13 <= 1f) {
		return 1;
	}
	return 0;
}

// Position - 0x172D3
Vector3 func_378(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x17312
void func_379(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_vehicle_engine_health(iParam0) <= 200f) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
			if (vehicle::get_vehicle_petrol_tank_health(iParam0) <= 700f) {
				vehicle::set_vehicle_engine_health(iParam0, 900f);
			}
			if (entity::get_entity_health(iParam0) < 200) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
		}
	}
}

// Position - 0x17377
void func_380() {
	if (iLocal_1030 > 8 && iLocal_1030 < 16) {
		if (player::get_max_wanted_level() != 0) {
			player::set_max_wanted_level(0);
			gameplay::enable_dispatch_service(3, 0);
			gameplay::enable_dispatch_service(5, 0);
			ped::set_create_random_cops(0);
		}
	}
}

// Position - 0x173B1
void func_381() {
	if (iLocal_2178 > 0) {
		if (fire::get_number_of_fires_in_range(vLocal_2175, 5f) > 0) {
			if (vehicle::is_vehicle_driveable(iLocal_1969, 0)) {
				if (vehicle::get_vehicle_petrol_tank_health(iLocal_1969) > 499f) {
					vehicle::set_vehicle_petrol_tank_health(iLocal_1969, 499f);
				}
			}
		}
	}
	switch (iLocal_2178) {
	case 0:
		if (func_33(vLocal_2175, 0) < 100f) {
			if (vehicle::is_vehicle_driveable(iLocal_1969, 0)) {
				entity::set_entity_proofs(iLocal_1969, 0, 0, 0, 0, 0, 0, 0, 0);
				vehicle::_0x192547247864DFDD(iLocal_1969, 1);
				vehicle::set_disable_vehicle_petrol_tank_fires(iLocal_1969, 0);
			}
			graphics::add_petrol_decal(vLocal_2175, 1.5f, 2f, 1f);
			iLocal_2178++;
		}
		break;

	case 1:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 0.35f, 0.25f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 2:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 0.7f, 0.5f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 3:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 1.05f, 0.75f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 4:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 1.4f, 1f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 5:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 1.75f, 1.25f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 6:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 2.15f, 1.5f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 7:
		graphics::add_petrol_decal(vLocal_2175 + Vector(0f, 2.4f, 1.8f), 1.5f, 2f, 1f);
		iLocal_2178++;
		break;

	case 8:
		graphics::_0x99AC7F0D8B9C893D(1f);
		graphics::_0x967278682CB6967A(vLocal_2175, 1f);
		iLocal_2178++;
		break;

	case 9:
		graphics::_0x967278682CB6967A(vLocal_2175 + Vector(0f, 0.7f, 0.5f), 1f);
		iLocal_2178++;
		break;

	case 10:
		graphics::_0x967278682CB6967A(vLocal_2175 + Vector(0f, 1.4f, 1f), 1f);
		iLocal_2178++;
		break;

	case 11:
		graphics::_0x967278682CB6967A(vLocal_2175 + Vector(0f, 2.15f, 1.5f), 1f);
		iLocal_2178++;
		break;

	case 12:
		graphics::_0x0A123435A26C36CD();
		iLocal_2178++;
		break;

	case 13: break;
	}
}

// Position - 0x17649
void func_382() {
	vector3 vVar0;
	float fVar3;
	int iVar4;

	switch (iLocal_1774) {
	case 0:
		if (!ped::is_ped_injured(player::player_ped_id())) {
			vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
			if (ped::get_ped_parachute_state(iLocal_1801) != -1) {
				if (ped::get_ped_parachute_state(iLocal_1801) == 1 || ped::get_ped_parachute_state(iLocal_1801) == 2) {
					iVar4 = 1;
				}
			}
			if (ped::is_ped_in_any_heli(player::player_ped_id()) || ped::is_ped_in_any_plane(player::player_ped_id()) ||
				iVar4 ||
				entity::is_entity_in_angled_area(iLocal_1801, -117.225f, -977.2565f, 200.1625f, -135.9228f, -971.2293f,
												 268.8807f, 11f, 0, 1, 0)) {
				fVar3 = system::vdist2(vVar0, vLocal_1829);
				if (fVar3 < 90000f && vVar0.z > 150f) {
					bLocal_1742 = true;
					if (ui::does_blip_exist(iLocal_1709)) {
						ui::remove_blip(&iLocal_1709);
					}
					iLocal_1774 = 1;
				}
			}
		}
		break;

	case 1:
		if (bLocal_1742) {
			func_198(&Local_1202, 5);
			func_198(&Local_1298, 3);
			func_198(&Local_1356, 6);
			func_197();
			if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_START")) {
				audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_START");
			}
			if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CAR_ARRIVES")) {
				audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CAR_ARRIVES");
			}
			if (entity::does_entity_exist(iLocal_1970)) {
				audio::_0x18EB48CFC41F2EA0(iLocal_1970, 0);
			}
			iLocal_1760 = 0;
			iLocal_1030 = 13;
			iLocal_1774 = 2;
		}
		break;

	case 2: break;
	}
}

// Position - 0x177B3
void func_383() { func_439(); }

// Position - 0x177BF
bool func_384() {
	if (Global_3) {
		return true;
	}
	if (Global_91491 == 7 || Global_91491 == 8) {
		return true;
	}
	return false;
}

// Position - 0x177EC
void func_385(vector3 vParam0, float fParam3, int iParam4, int iParam5) {
	if (func_438()) {
		gameplay::set_this_script_can_be_paused(0);
		gameplay::clear_bit(&Global_91491.f_20, 2);
		gameplay::set_game_paused(1);
		if (player::is_player_playing(player::player_id())) {
			player::set_player_control(player::player_id(), 0, 0);
		}
		Global_91487 = {vParam0};
		Global_91490 = fParam3;
		Global_91486 = 1;
		if (iParam4 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 14);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 14);
		}
		if (iParam5 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 24);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 24);
		}
		func_346(1);
	}
}

// Position - 0x17881
int func_386(vector3 vParam0, float fParam3) { return func_387(&Global_96040.f_2311, vParam0, fParam3, 0); }

// Position - 0x1789B
int func_387(var *uParam0, vector3 vParam1, float fParam4, int iParam5) {
	int iVar0;
	vector3 vVar1;
	bool bVar4;
	var uVar5;
	int iVar8;

	if (func_428(uParam0)) {
		if (func_23(vParam1, 0f, 0f, 0f, 0)) {
			vParam1 = {*uParam0};
			fParam4 = uParam0->f_6;
		}
		if (uParam0->f_12.f_66 == joaat("monster") || uParam0->f_12.f_66 == joaat("marshall")) {
			if (object::is_point_in_angled_area(vParam1, -816.8716f, 185.6238f, 71.40275f, -807.4894f, 189.3762f,
												75.27323f, 6.5f, 0, 1)) {
				vParam1 = {-850.93f, 158.82f, 65.7f};
				fParam4 = 89.5f;
			}
		}
		if (func_427(uParam0)) {
			gameplay::clear_area(vParam1, 5f, 1, 0, 0, 0);
			func_426(vParam1, 5f, 0);
			iVar0 = vehicle::create_vehicle(uParam0->f_12.f_66, vParam1, fParam4, 1, 1);
			if (entity::does_entity_exist(iVar0)) {
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
				if (system::vdist2(vVar1, -1151.15f, -1530.32f, 7.48925f) <= 3f) {
					entity::set_entity_coords_no_offset(iVar0, vParam1, 0, 0, 1);
				}
				func_418(iVar0, &uParam0->f_12, 0, 1);
				bVar4 = true;
				if (vehicle::is_this_model_a_boat(uParam0->f_12.f_66) ||
					vehicle::_is_this_model_an_emergency_boat(uParam0->f_12.f_66)) {
					if (!water::test_probe_against_water(vParam1.x, vParam1.y, vParam1.z + 30f, vParam1.x, vParam1.y,
														 vParam1.z - 30f, &uVar5)) {
						bVar4 = false;
					}
				}
				if (bVar4) {
					vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
				}
				if (uParam0->f_7 == 1) {
					if (iParam5) {
						if (vehicle::is_this_model_a_car(entity::get_entity_model(iVar0))) {
							func_417(uParam0->f_11, 1);
						}
						else if (vehicle::is_this_model_a_bike(entity::get_entity_model(iVar0))) {
							func_417(uParam0->f_11, 2);
						}
					}
					vehicle::_0xAB04325045427AAE(iVar0, 0);
					vehicle::_0x428BACCDF5E26EAD(iVar0, 0);
					vehicle::set_vehicle_has_strong_axles(iVar0, 1);
					func_416(iVar0, uParam0->f_11);
				}
				else if (!func_413(iVar0, uParam0->f_3, uParam0->f_8) && uParam0->f_10 &&
						 gameplay::are_strings_equal(script::get_this_script_name(), "startup_positioning")) {
					iVar8 = func_412(iVar0);
					if (iVar8 == -1) {
						uParam0->f_10 = 0;
					}
					else {
						func_407(iVar8);
					}
				}
				if (Global_91491 != 13 && Global_91491 != 10 && Global_91491 != 11 && Global_91491 != 12) {
					if (gameplay::get_hash_key(&Global_91491.f_3) == Global_69519) {
						if (uParam0->f_12.f_66 == Global_101700.f_31389.f_69[21 /*78*/].f_66) {
							func_404(24, 0);
							func_407(24);
						}
					}
				}
				if (uParam0->f_9 == 1) {
					func_388(iVar0, uParam0->f_11);
				}
				streaming::set_model_as_no_longer_needed(uParam0->f_12.f_66);
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
			}
			return iVar0;
		}
	}
	return iVar0;
}

// Position - 0x17B4C
void func_388(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_389(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_239(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x17D4E
int func_389(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_244(iParam0, 0, 0) ||
		func_244(iParam0, 1, 0) || func_244(iParam0, 2, 0) || func_235(iParam0) != 145 || func_403(iParam0) ||
		func_402(iParam0) || func_401(iParam0) || func_400(iParam0) || !func_390(entity::get_entity_model(iParam0))) {
		if (func_402(iParam0)) {
		}
		if (func_402(iParam0)) {
		}
		if (func_244(iParam0, 0, 0)) {
		}
		if (func_244(iParam0, 1, 0)) {
		}
		if (func_244(iParam0, 2, 0)) {
		}
		if (func_235(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x17E2B
int func_390(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_391(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x17FDC
int func_391(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_399()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_398() && !func_397() && !func_396() && !func_395() && !func_399()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_396()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_394(iParam0)) {
			return 0;
		}
	}
	if (!func_392(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x1816F
int func_392(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_393()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x1823B
int func_393() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x1824F
int func_394(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x18F92
int func_395() { return 0; }

// Position - 0x18F9B
int func_396() { return 1; }

// Position - 0x18FA4
int func_397() { return 1; }

// Position - 0x18FAD
int func_398() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x18FC6
bool func_399() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x19081
int func_400(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_391(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x190C7
int func_401(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x19102
bool func_402(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x1917E
int func_403(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x19266
void func_404(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_406(iParam0, 0)) {
			func_405(iParam0, 1, 0);
			func_405(iParam0, 2, 0);
			func_405(iParam0, 3, 0);
			func_405(iParam0, 4, 0);
			func_405(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_405(iParam0, 0, 0);
	}
}

// Position - 0x192C3
void func_405(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0x192FE
int func_406(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x19321
void func_407(int iParam0) {
	bool bVar0;

	if (iParam0 == -1) {
		return;
	}
	if (func_411(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			bVar0 = true;
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (vehicle::is_vehicle_driveable(Global_68531.f_139[iParam0], 0)) {
					if (ped::is_ped_in_vehicle(player::player_ped_id(), Global_68531.f_139[iParam0], 0)) {
						bVar0 = false;
					}
				}
			}
			if (bVar0) {
				entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
				vehicle::delete_vehicle(&Global_68531.f_139[iParam0]);
			}
		}
		Global_68531[iParam0] = 1;
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			if (iParam0 == 24 && func_406(iParam0, 0) && Global_69440.f_66 == 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] != 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] > 3 &&
				(!func_409(0, Global_68531.f_555[0 /*21*/].f_12) || !func_409(1, Global_68531.f_555[0 /*21*/].f_12))) {
				func_408(&Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/], &Global_69440);
				Global_69518 = Global_101700.f_31389.f_5591;
			}
			func_404(iParam0, 0);
		}
	}
}

// Position - 0x19493
void func_408(var *uParam0, var *uParam1) {
	uParam1->f_66 = uParam0->f_66;
	*uParam1 = *uParam0;
	uParam1->f_1 = {uParam0->f_1};
	uParam1->f_5 = uParam0->f_5;
	uParam1->f_6 = uParam0->f_6;
	uParam1->f_7 = uParam0->f_7;
	uParam1->f_8 = uParam0->f_8;
	uParam1->f_9 = {uParam0->f_9};
	uParam1->f_59 = {uParam0->f_59};
	uParam1->f_62 = uParam0->f_62;
	uParam1->f_63 = uParam0->f_63;
	uParam1->f_64 = uParam0->f_64;
	uParam1->f_65 = uParam0->f_65;
	uParam1->f_77 = uParam0->f_77;
	uParam1->f_67 = uParam0->f_67;
	uParam1->f_69 = uParam0->f_69;
	uParam1->f_68 = uParam0->f_68;
	uParam1->f_71 = uParam0->f_71;
	uParam1->f_72 = uParam0->f_72;
	uParam1->f_73 = uParam0->f_73;
	uParam1->f_74 = uParam0->f_74;
	uParam1->f_75 = uParam0->f_75;
	uParam1->f_76 = uParam0->f_76;
}

// Position - 0x1955F
int func_409(int iParam0, int iParam1) {
	int iVar0;

	switch (iParam1) {
	case 0: iVar0 = 0; break;

	case 1: iVar0 = 1; break;

	case 2: iVar0 = 2; break;
	}
	if (iParam0 < 0 || iParam0 >= func_410(&Global_101700.f_31389.f_5038[iVar0 /*157*/])) {
		return 0;
	}
	return func_391(Global_101700.f_31389.f_5038[iVar0 /*157*/][iParam0 /*78*/].f_66, 0);
}

// Position - 0x195D1
int func_410(var *uParam0) { return *uParam0; }

// Position - 0x195DC
bool func_411(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_237(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_237(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_237(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_237(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_237(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_237(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_237(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_237(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_237(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_399()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_399()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_23(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_23(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_23(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0x1ACD3
int func_412(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0]) &&
			!entity::is_entity_dead(Global_68531.f_484[iVar0], 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[iVar0], 0)) {
			vehicle::get_vehicle_colours(iParam0, &iVar1, &iVar2);
			vehicle::get_vehicle_colours(Global_68531.f_484[iVar0], &iVar3, &iVar4);
			if (entity::get_entity_model(iParam0) == entity::get_entity_model(Global_68531.f_484[iVar0]) &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[iVar0]) &&
				iVar1 == iVar2 && iVar3 == iVar4) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1AD96
int func_413(int iParam0, vector3 vParam1, bool bParam4) {
	int iVar0;
	var uVar1[3];
	int iVar5;
	int iVar6;

	iVar0 = entity::get_entity_model(iParam0);
	switch (iVar0) {
	case joaat("cargobob"):
		if (func_415(iParam0, Global_68531.f_139[38], 0)) {
			func_407(38);
			return 1;
		}
		break;

	case joaat("firetruk"):
		if (func_415(iParam0, Global_68531.f_139[43], 1)) {
			func_407(43);
			return 1;
		}
		break;

	case joaat("cuban800"):
		iVar5 = ped::get_ped_nearby_vehicles(player::player_ped_id(), &uVar1);
		iVar6 = 0;
		while (iVar6 <= iVar5 - 1) {
			if (func_415(iParam0, uVar1[iVar6], 1) &&
				func_414(entity::get_entity_coords(uVar1[iVar6], 1), 2136.133f, 4780.563f, 39.9702f, 5f, 0)) {
				if (!bParam4 || func_23(vParam1, 0f, 0f, 0f, 0) ||
					gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1),
														  entity::get_entity_coords(uVar1[iVar6], 1), 1) < 10f) {
					vehicle::delete_vehicle(&iParam0);
					return 1;
				}
				else {
					return 0;
				}
			}
			iVar6++;
		}
		break;

	case joaat("luxor2"):
		if (entity::does_entity_exist(Global_68531.f_484[14]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[14], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[14]) == joaat("luxor2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[14])) {
				func_407(14);
				return 1;
			}
		}
		break;

	case joaat("swift2"):
		if (entity::does_entity_exist(Global_68531.f_484[20]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[20], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[20]) == joaat("swift2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[20])) {
				func_407(20);
				return 1;
			}
		}
		break;
	}
	return 0;
}

// Position - 0x1AF9E
int func_414(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return 1;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1B019
bool func_415(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam1) && !entity::is_entity_dead(iParam1, 0) &&
		vehicle::is_vehicle_driveable(iParam1, 0)) {
		if (iParam2) {
			vehicle::get_vehicle_colours(iParam0, &iVar0, &iVar1);
			vehicle::get_vehicle_colours(iParam1, &iVar2, &iVar3);
			if (iVar0 == iVar2 && iVar1 == iVar3) {
				return true;
			}
		}
		else {
			return true;
		}
	}
	return false;
}

// Position - 0x1B07A
void func_416(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (!entity::does_entity_exist(Global_89155[iVar0])) {
			Global_89155[iVar0] = iParam0;
			Global_89165[iVar0] = iParam1;
			Global_89175[iVar0] = entity::get_entity_model(iParam0);
			if (vehicle::is_this_model_a_car(Global_89175[iVar0])) {
				Global_89203[iParam1 /*3*/][0] = -1;
			}
			else {
				Global_89203[iParam1 /*3*/][1] = -1;
			}
			iVar0 = 9;
		}
		if (iVar0 == 8) {
		}
		iVar0++;
	}
}

// Position - 0x1B0FC
void func_417(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (iParam0 == 145 || Global_89165[iVar0] == iParam0) {
				if (iParam1 == 0 || entity::get_entity_model(Global_89155[iVar0]) == func_237(iParam0, iParam1)) {
					if (!ped::is_ped_in_vehicle(player::player_ped_id(), Global_89155[iVar0], 0)) {
						entity::set_entity_as_mission_entity(Global_89155[iVar0], 0, 1);
						vehicle::delete_vehicle(&Global_89155[iVar0]);
						Global_89165[iVar0] = 145;
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x1B19A
void func_418(int iParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (gameplay::get_hash_key(&uParam1->f_1) != 0) {
			vehicle::set_vehicle_number_plate_text(iParam0, &uParam1->f_1);
		}
		if (*uParam1 >= 0 && *uParam1 < vehicle::get_number_of_vehicle_number_plates()) {
			vehicle::set_vehicle_number_plate_text_index(iParam0, *uParam1);
		}
		if (uParam1->f_66 == joaat("sovereign")) {
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 111;
		}
		else if (uParam1->f_66 == joaat("casco")) {
			iVar0 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_240(iVar0 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_240(iVar0 + 1));
			}
		}
		else if (uParam1->f_66 == joaat("sandking") || uParam1->f_66 == joaat("sandking2")) {
			iVar1 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_240(iVar1 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_240(iVar1 + 1));
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 13)) {
			vehicle::set_vehicle_custom_primary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_primary_colour(iParam0);
		}
		if (gameplay::is_bit_set(uParam1->f_77, 12)) {
			vehicle::set_vehicle_custom_secondary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_secondary_colour(iParam0);
		}
		vehicle::set_vehicle_colours(iParam0, uParam1->f_5, uParam1->f_6);
		if (uParam1->f_7 < 0) {
			uParam1->f_7 = 0;
		}
		if (uParam1->f_8 < 0) {
			uParam1->f_8 = 0;
		}
		vehicle::set_vehicle_extra_colours(iParam0, uParam1->f_7, uParam1->f_8);
		if (gameplay::is_bit_set(uParam1->f_77, 15) || func_425(iParam0) ||
			uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0 && uParam1->f_9[20] > 0)
			&&func_424() {
				uParam1->f_62 = 0;
				uParam1->f_63 = 0;
				uParam1->f_64 = 0;
			}
		else if (uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0) {
			uParam1->f_62 = 255;
			uParam1->f_63 = 255;
			uParam1->f_64 = 255;
		}
		vehicle::set_vehicle_tyre_smoke_color(iParam0, uParam1->f_62, uParam1->f_63, uParam1->f_64);
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			vehicle::set_vehicle_window_tint(iParam0, 0);
		}
		else {
			vehicle::set_vehicle_window_tint(iParam0, 0);
			vehicle::set_vehicle_window_tint(iParam0, uParam1->f_65);
		}
		vehicle::set_vehicle_tyres_can_burst(iParam0, !gameplay::is_bit_set(uParam1->f_77, 9));
		if (iParam2) {
			vehicle::set_vehicle_doors_locked(iParam0, uParam1->f_70);
		}
		vehicle::_set_vehicle_neon_lights_colour(iParam0, uParam1->f_74, uParam1->f_75, uParam1->f_76);
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 2, gameplay::is_bit_set(uParam1->f_77, 28));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 3, gameplay::is_bit_set(uParam1->f_77, 29));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 0, gameplay::is_bit_set(uParam1->f_77, 30));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 1, gameplay::is_bit_set(uParam1->f_77, 31));
		vehicle::set_vehicle_is_stolen(iParam0, gameplay::is_bit_set(uParam1->f_77, 10));
		if (vehicle::get_vehicle_livery_count(iParam0) > 1 && uParam1->f_67 >= 0) {
			vehicle::set_vehicle_livery(iParam0, uParam1->f_67);
		}
		if (uParam1->f_69 > -1 && uParam1->f_69 < 255) {
			if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(iParam0))) {
				if (vehicle::is_this_model_a_bike(entity::get_entity_model(iParam0))) {
					if (uParam1->f_69 == 6) {
						func_423(iParam0, uParam1->f_69);
					}
				}
				else {
					func_423(iParam0, uParam1->f_69);
				}
			}
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			if (uParam1->f_68 == 0 || uParam1->f_68 == 3 || uParam1->f_68 == 5) {
				vehicle::raise_convertible_roof(iParam0, 1);
			}
			else {
				vehicle::lower_convertible_roof(iParam0, 1);
			}
		}
		if (iParam3) {
			func_419(&iParam0, &uParam1->f_9, &uParam1->f_59);
		}
		if (!vehicle::is_this_model_a_heli(uParam1->f_66) && !vehicle::is_this_model_a_boat(uParam1->f_66)) {
			iVar2 = 0;
			while (iVar2 <= 11) {
				if (gameplay::is_bit_set(uParam1->f_77, func_240(iVar2 + 1))) {
					if (!vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
						vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 0);
					}
				}
				else if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
					vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 1);
				}
				iVar2++;
			}
		}
		if (entity::get_entity_model(iParam0) == joaat("sheava") ||
			entity::get_entity_model(iParam0) == joaat("omnis") || entity::get_entity_model(iParam0) == joaat("le7b")) {
			if (vehicle::get_vehicle_mod(iParam0, 0) == -1) {
				vehicle::set_vehicle_extra(iParam0, 1, 0);
			}
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (!gameplay::is_bit_set(uParam1->f_77, 23)) {
				if (gameplay::is_bit_set(uParam1->f_77, 22)) {
					vehicle::control_landing_gear(iParam0, 2);
				}
				else {
					vehicle::control_landing_gear(iParam0, 3);
				}
			}
			else {
				vehicle::control_landing_gear(iParam0, 4);
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 27)) {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 1);
		}
		else {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 0);
		}
	}
}

// Position - 0x1B648
int func_419(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	vehicle::set_vehicle_mod_kit(*iParam0, 0);
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			vehicle::toggle_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] > 0);
		}
		else if (vehicle::get_vehicle_mod(*iParam0, iVar1) != (*uParam1)[iVar0] - 1) {
			vehicle::remove_vehicle_mod(*iParam0, iVar1);
			if ((*uParam1)[iVar0] > 0) {
				if (iVar0 == 23) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[0] > 0);
				}
				else if (iVar0 == 24) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[1] > 0);
				}
				else {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, 0);
				}
			}
		}
		iVar0++;
	}
	if (func_422(entity::get_entity_model(*iParam0), 1) &&
		vehicle::get_vehicle_mod(*iParam0, 24) != func_421(*iParam0, (*uParam1)[38] - 1)) {
		vehicle::set_vehicle_mod(*iParam0, 24, func_421(*iParam0, (*uParam1)[38] - 1), 0);
	}
	if (func_420(*iParam0)) {
		vehicle::set_vehicle_strong(*iParam0, 1);
		vehicle::set_vehicle_has_strong_axles(*iParam0, 1);
	}
	return 1;
}

// Position - 0x1B7C0
bool func_420(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	char cVar3[16];

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0) &&
		vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = 0;
		while (iVar0 < 49) {
			iVar1 = iVar0;
			if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			}
			else if (vehicle::get_vehicle_mod(iParam0, iVar1) != -1) {
				StringCopy(&cVar3,
						   vehicle::get_mod_text_label(iParam0, iVar1, vehicle::get_vehicle_mod(iParam0, iVar1)), 16);
				iVar2 = gameplay::get_hash_key(&cVar3);
				if (iVar2 != 0) {
					if (iVar2 == gameplay::get_hash_key("MNU_CAGE") || iVar2 == gameplay::get_hash_key("SABRE_CAG")) {
						return true;
					}
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x1B89C
int func_421(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	float fVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		switch (entity::get_entity_model(iParam0)) {
		case joaat("tornado5"):
			switch (iParam1) {
			case 0: return 0;

			case 1: return 1;

			case 2: return 2;

			case 3: return 3;

			case 4: return 4;

			case 5: return 4;
			}
			break;

		case joaat("faction3"): return 3;
		}
		iVar0 = vehicle::get_num_vehicle_mods(iParam0, 38);
		iVar1 = vehicle::get_num_vehicle_mods(iParam0, 24);
		fVar2 = system::to_float(iParam1 + 1) / system::to_float(iVar0);
		iVar3 = system::floor(system::to_float(iVar1) * fVar2) - 1;
		if (iVar3 < 0) {
			iVar3 = 0;
		}
		if (iVar3 >= iVar0) {
			iVar3 = iVar0 - 1;
		}
		return iVar3;
	}
	return 0;
}

// Position - 0x1B981
int func_422(int iParam0, int iParam1) {
	switch (iParam0) {
	case joaat("faction2"):
	case joaat("buccaneer2"):
	case joaat("chino2"):
	case joaat("moonbeam2"):
	case joaat("primo2"):
	case joaat("voodoo"): return 1;

	case joaat("sabregt2"):
		if (!Global_262145.f_12339) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("tornado5"):
		if (!Global_262145.f_12340) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("virgo2"):
		if (!Global_262145.f_12338) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("minivan2"):
		if (!Global_262145.f_12341) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("slamvan3"):
		if (!Global_262145.f_12343) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("faction3"):
		if (!Global_262145.f_12342) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("sultanrs"):
	case joaat("banshee2"):
		if ((iParam1 & 1) != 0) {
			return 0;
		}
		return 1;

	case joaat("comet3"):
		if (Global_262145.f_16780) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("diablous2"):
		if (Global_262145.f_16782) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("fcr2"):
		if (Global_262145.f_16786) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("elegy"):
		if (Global_262145.f_16783) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("nero2"):
		if (Global_262145.f_16790) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("italigtb2"):
		if (Global_262145.f_16788) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("specter2"):
		if (Global_262145.f_16793) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x1BBA6
void func_423(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = vehicle::get_vehicle_mod(iParam0, 24);
		iVar1 = vehicle::get_vehicle_mod_variation(iParam0, 24);
		vehicle::set_vehicle_wheel_type(iParam0, iParam1);
		if (entity::get_entity_model(iParam0) == joaat("tornado6")) {
			return;
		}
		if (iVar0 == -1) {
			vehicle::remove_vehicle_mod(iParam0, 24);
		}
		else {
			vehicle::set_vehicle_mod(iParam0, 24, iVar0, iVar1 == 1);
		}
	}
}

// Position - 0x1BC0B
var func_424() { return dlc2::is_dlc_present(-1691188696); }

// Position - 0x1BC1C
int func_425(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (decorator::decor_is_registered_as_type("MPBitset", 3)) {
				if (decorator::decor_exist_on(iParam0, "MPBitset")) {
					iVar0 = decorator::decor_get_int(iParam0, "MPBitset");
				}
				return gameplay::is_bit_set(iVar0, 4);
			}
		}
	}
	return 0;
}

// Position - 0x1BC67
void func_426(vector3 vParam0, float fParam3, int iParam4) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (func_411(&Global_68531.f_555[0 /*21*/], iVar0)) {
			if (gameplay::get_distance_between_coords(vParam0, Global_68531.f_555[0 /*21*/], iParam4) <= fParam3) {
				func_407(iVar0);
			}
		}
		iVar0++;
	}
}

// Position - 0x1BCB7
bool func_427(var *uParam0) {
	if (func_428(uParam0)) {
		if (streaming::has_model_loaded(uParam0->f_12.f_66)) {
			return true;
		}
		else {
			return false;
		}
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x1BCEC
bool func_428(var *uParam0) {
	if (uParam0->f_12.f_66 == 0) {
		return false;
	}
	if (!func_391(uParam0->f_12.f_66, 0)) {
		return false;
	}
	if (uParam0->f_12.f_66 == joaat("stunt") && func_414(*uParam0, 1694.62f, 3276.27f, 41.31f, 1056964608, 0)) {
		return false;
	}
	return true;
}

// Position - 0x1BD4B
int func_429() { return func_427(&Global_96040.f_2311); }

// Position - 0x1BD5E
void func_430() { func_431(&Global_96040.f_2311); }

// Position - 0x1BD71
void func_431(var *uParam0) {
	if (func_428(uParam0)) {
		streaming::request_model(uParam0->f_12.f_66);
	}
}

// Position - 0x1BD8F
int func_432() {
	if (Global_91491 != 10 && Global_91491 != 9) {
		return 0;
	}
	return Global_91491.f_2;
}

// Position - 0x1BDB9
struct<39> func_433(int iParam0) {
	struct<39> Var0;

	if (iParam0 == 0) {
		Var0 = 1;
		Var0.f_1 = {0f, 0f, 0f};
		Var0.f_4 = {0f, 0f, 0f};
		Var0.f_7 = {func_434(0)};
		Var0.f_22 = "Assassin_Valet";
		Var0.f_23 = 7000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-1700.015f, -1066.335f, 12.144f};
		Var0.f_28 = {-1691.564f, -1066.514f, 12.076f};
		Var0.f_31 = 35.4714f;
		Var0.f_10 = {-1700.467f, -1066.672f, 13.8795f};
		Var0.f_13 = {-4.8332f, 0f, -177.1283f};
		Var0.f_16 = {-1700.467f, -1066.672f, 13.8795f};
		Var0.f_19 = {-4.8332f, 0f, -177.1283f};
		Var0.f_33 = {-1700.098f, -1067.939f, 12.1547f};
		Var0.f_36 = 162.4559f;
		Var0.f_37 = 1;
	}
	else if (iParam0 == 1) {
		Var0 = 0;
		Var0.f_1 = {-699.3992f, -917.5043f, 18.2143f};
		Var0.f_4 = {0f, 0f, 0f};
		Var0.f_7 = {func_434(1)};
		Var0.f_22 = "Assassin_Multi";
		Var0.f_23 = 5000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-700.1855f, -917.9558f, 18.2143f};
		Var0.f_28 = {-699.9455f, -921.7786f, 18.0144f};
		Var0.f_31 = 78.0874f;
		Var0.f_10 = {-697.8064f, -921.4629f, 20.5104f};
		Var0.f_13 = {-13.5249f, 0f, 30.6033f};
		Var0.f_16 = {-702.4851f, -921.2747f, 21.1235f};
		Var0.f_19 = {-22.5196f, 0f, -43.0435f};
		Var0.f_33 = {0f, 0f, 0f};
		Var0.f_36 = 0f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 2) {
		Var0 = 0;
		Var0.f_1 = {215.1206f, -853.3143f, 29.3684f};
		Var0.f_4 = {0f, 0f, 87.1787f};
		Var0.f_7 = {func_434(2)};
		Var0.f_22 = "Assassin_Hooker";
		Var0.f_23 = 3000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {213.7994f, -853.9389f, 29.3929f};
		Var0.f_28 = {205.2641f, -847.2667f, 29.4903f};
		Var0.f_31 = 140.1039f;
		Var0.f_10 = {216.7391f, -856.0031f, 32.7127f};
		Var0.f_13 = {-25.1365f, 0f, 41.3912f};
		Var0.f_16 = {210.4668f, -851.3092f, 32.1099f};
		Var0.f_19 = {-16.3326f, 0f, -127.0114f};
		Var0.f_33 = {213.8733f, -853.8161f, 29.3922f};
		Var0.f_36 = 344.0112f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 3) {
		Var0 = 0;
		Var0.f_1 = {-22.5499f, -107.3546f, 56.0161f};
		Var0.f_4 = {0f, 0f, 269.7924f};
		Var0.f_7 = {func_434(3)};
		Var0.f_22 = "Assassin_Bus";
		Var0.f_23 = 5000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = -1;
		Var0.f_25 = {-22.3125f, -108.9183f, 56.0068f};
		Var0.f_28 = {-17.2677f, -118.5915f, 55.8734f};
		Var0.f_31 = 1.4374f;
		Var0.f_10 = {-26.1094f, -108.0298f, 59.052f};
		Var0.f_13 = {-21.2059f, 0f, -109.0176f};
		Var0.f_16 = {-20.1189f, -111.9639f, 59.4377f};
		Var0.f_19 = {-27.0037f, 0f, 29.464f};
		Var0.f_33 = {0f, 0f, 0f};
		Var0.f_36 = 0f;
		Var0.f_37 = 0;
	}
	else if (iParam0 == 4) {
		Var0 = 0;
		Var0.f_1 = {806.1469f, -1070.21f, 27.3361f};
		Var0.f_4 = {0f, 0f, 90f};
		Var0.f_7 = {func_434(4)};
		Var0.f_22 = "Assassin_Construction";
		Var0.f_23 = 8000f;
		Var0.f_24 = 2000f;
		Var0.f_32 = 1;
		Var0.f_25 = {804.9559f, -1070.46f, 27.3361f};
		Var0.f_28 = {799.8408f, -1079.142f, 27.321f};
		Var0.f_31 = 69.6524f;
		Var0.f_10 = {801.8048f, -1068.068f, 30.3496f};
		Var0.f_13 = {-20.8953f, 0f, -132.9451f};
		Var0.f_16 = {805.8168f, -1074.496f, 28.9803f};
		Var0.f_19 = {-1.5585f, 0f, 6.9143f};
		Var0.f_33 = {804.8776f, -1070.523f, 27.3416f};
		Var0.f_36 = 287.8741f;
		Var0.f_37 = 0;
	}
	return Var0;
}

// Position - 0x1C274
Vector3
func_434(int iParam0) {
	switch (iParam0) {
	case 0: return -1704.427f, -1077.316f, 12.1111f;

	case 1: return -700.429f, -916.7467f, 18.2143f;

	case 2: return 214.1641f, -852.8006f, 29.3929f;

	case 3: return -21.9871f, -107.4823f, 55.997f;

	case 4: return 806.1469f, -1070.21f, 27.3361f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x1C2FE
void func_435() {
	bool bVar0;

	bVar0 = func_79(Global_101700.f_18922.f_1, 4096);
	Global_101700.f_18922.f_1 = 0;
	if (bVar0) {
		func_448(&Global_101700.f_18922.f_1, 4096);
	}
}

// Position - 0x1C337
void func_436() {}

// Position - 0x1C33F
bool func_437() { return func_428(&Global_96040.f_2311); }

// Position - 0x1C352
bool func_438() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return true;
	}
	return false;
}

// Position - 0x1C376
void func_439() {
	if (entity::does_entity_exist(iLocal_1036)) {
		streaming::set_model_as_no_longer_needed(-1559354806);
		object::delete_object(&iLocal_1036);
	}
	if (entity::does_entity_exist(iLocal_1035)) {
		entity::set_entity_visible(iLocal_1035, 1, 0);
		entity::set_entity_collision(iLocal_1035, 1, 0);
	}
	if (func_29(&uLocal_1976)) {
		Global_101700.f_18922.f_9 = func_26(&uLocal_1976);
	}
	bLocal_1736 = false;
	iLocal_1729 = 0;
	func_358(1);
	func_445();
	func_444();
	streaming::end_srl();
	vehicle::_0x1033371FC8E842A7(iLocal_1768);
	func_198(&Local_1202, 5);
	func_198(&Local_1298, 3);
	func_198(&Local_1356, 6);
	func_198(&Local_1471, 2);
	func_198(&Local_1510, 4);
	func_198(&Local_1587, 3);
	func_443();
	func_197();
	func_442();
	func_170(1);
	func_210();
	func_441();
	ped::set_create_random_cops(1);
	streaming::set_model_as_no_longer_needed(iLocal_1778[0]);
	streaming::set_model_as_no_longer_needed(iLocal_1778[1]);
	streaming::set_model_as_no_longer_needed(iLocal_1783);
	streaming::set_model_as_no_longer_needed(iLocal_1784);
	streaming::set_model_as_no_longer_needed(iLocal_1786);
	ped::set_ped_model_is_suppressed(iLocal_1778[0], 0);
	entity::remove_model_hide(vLocal_1820, 5f, joaat("prop_conslift_lift"), 0);
	entity::remove_model_hide(vLocal_1823, 5f, joaat("prop_conslift_lift"), 0);
	streaming::request_ipl("DT1_21_prop_lift_on");
	streaming::remove_ipl("DT1_21_ConSiteAssass");
	if (entity::does_entity_exist(uLocal_1787[1])) {
		if (entity::is_entity_attached_to_entity(iLocal_1801, uLocal_1787[1])) {
			entity::detach_entity(iLocal_1801, 1, 1);
		}
	}
	if (entity::does_entity_exist(uLocal_1787[0])) {
		if (entity::is_entity_attached_to_entity(iLocal_1801, uLocal_1787[0])) {
			entity::detach_entity(iLocal_1801, 1, 1);
		}
	}
	player::set_wanted_level_multiplier(1f);
	player::set_max_wanted_level(6);
	player::set_player_invincible(player::player_id(), 0);
	gameplay::enable_dispatch_service(3, 1);
	gameplay::enable_dispatch_service(5, 1);
	func_178();
	ped::clear_ped_non_creation_area();
	func_440();
	audio::release_script_audio_bank();
	graphics::remove_decals_in_range(vLocal_2175, 10f);
	if (entity::does_entity_exist(iLocal_1035)) {
		entity::set_entity_visible(iLocal_1035, 1, 0);
		entity::set_entity_collision(iLocal_1035, 1, 0);
		entity::set_entity_can_be_damaged(iLocal_1035, 1);
	}
	script::terminate_this_thread();
}

// Position - 0x1C553
void func_440() {
	if (entity::does_entity_exist(iLocal_1970)) {
		audio::_0x18EB48CFC41F2EA0(iLocal_1970, 0);
	}
	if (entity::does_entity_exist(iLocal_1972)) {
		audio::_0x18EB48CFC41F2EA0(iLocal_1972, 0);
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CUTSCENE")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CUTSCENE");
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_START")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_START");
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_CAR_ARRIVES")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_CAR_ARRIVES");
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_SHOOTOUT_ROOFTOP");
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_HELICOPTER_SCENE");
	}
	if (audio::is_audio_scene_active("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA")) {
		audio::stop_audio_scene("ASSASSINATION_CONSTRUCT_LEAVE_THE_AREA");
	}
}

// Position - 0x1C5F1
void func_441() {
	if (entity::does_entity_exist(iLocal_1969)) {
		entity::set_vehicle_as_no_longer_needed(&iLocal_1969);
	}
	if (entity::does_entity_exist(iLocal_1972)) {
		entity::set_vehicle_as_no_longer_needed(&iLocal_1972);
	}
}

// Position - 0x1C61B
void func_442() {
	if (entity::does_entity_exist(iLocal_1972)) {
		if (entity::is_entity_occluded(iLocal_1972)) {
			vehicle::delete_vehicle(&iLocal_1972);
		}
		else {
			entity::set_vehicle_as_no_longer_needed(&iLocal_1972);
		}
	}
	if (entity::does_entity_exist(iLocal_1802)) {
		if (entity::is_entity_occluded(iLocal_1802)) {
			ped::delete_ped(&iLocal_1802);
		}
		else {
			if (!ped::is_ped_injured(iLocal_1802)) {
				if (ped::is_ped_in_any_heli(iLocal_1802)) {
					ped::set_ped_combat_attributes(iLocal_1802, 3, 0);
					ped::set_ped_flee_attributes(iLocal_1802, 2, 0);
					ped::set_ped_keep_task(iLocal_1802, 1);
				}
			}
			entity::set_ped_as_no_longer_needed(&iLocal_1802);
		}
	}
}

// Position - 0x1C6A2
void func_443() {
	if (entity::does_entity_exist(uLocal_1805[0])) {
		ped::delete_ped(&uLocal_1805[0]);
	}
	if (entity::does_entity_exist(uLocal_1805[1])) {
		ped::delete_ped(&uLocal_1805[1]);
	}
}

// Position - 0x1C6D8
void func_444() {
	if (object::does_pickup_exist(uLocal_2171)) {
		object::remove_pickup(uLocal_2171);
	}
	if (object::does_pickup_exist(uLocal_2172)) {
		object::remove_pickup(uLocal_2172);
	}
}

// Position - 0x1C702
void func_445() {
	if (object::does_pickup_exist(uLocal_2170)) {
		object::remove_pickup(uLocal_2170);
	}
}

// Position - 0x1C71B
void func_446() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_17(0)) {
		if (!func_447()) {
			iVar0 = func_16();
			if (iVar0 != -1) {
				if (!func_4(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_9();
		}
	}
}

// Position - 0x1C78C
int func_447() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

// Position - 0x1C7CA
void func_448(var *uParam0, int iParam1) { func_449(uParam0, iParam1); }

// Position - 0x1C7DA
void func_449(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

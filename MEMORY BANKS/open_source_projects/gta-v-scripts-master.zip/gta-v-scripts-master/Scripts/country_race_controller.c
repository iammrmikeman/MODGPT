#pragma region Local Var //{
int iLocal_0 = 0;
var uLocal_1 = 0;
var uLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
int iLocal_12 = 0;
var uLocal_13 = 0;
var uLocal_14 = 0;
float fLocal_15 = 0f;
var uLocal_16 = 0;
var uLocal_17 = 0;
int iLocal_18 = 0;
char *sLocal_19 = NULL;
var uLocal_20 = 0;
var uLocal_21 = 0;
var uLocal_22 = 0;
var uLocal_23 = 0;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
float fLocal_29 = 0f;
var uLocal_30 = 0;
var uLocal_31 = 0;
var uLocal_32 = 0;
float fLocal_33 = 0f;
float fLocal_34 = 0f;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
vector3 vLocal_56 = {0f, 0f, 0f};
float fLocal_59 = 0f;
vector3 vLocal_60 = {0f, 0f, 0f};
vector3 vLocal_63 = {0f, 0f, 0f};
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 6;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 9;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 9;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
int iLocal_150 = 0;
int iLocal_151 = 0;
int *iLocal_152 = NULL;
int iLocal_153 = 0;
int iLocal_154 = 0;
int iLocal_155 = 0;
float fLocal_156 = 0f;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_0 = 3;
	iLocal_3 = 1;
	iLocal_4 = 134;
	iLocal_5 = 134;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 1;
	iLocal_9 = 134;
	iLocal_10 = 1;
	iLocal_11 = 12;
	iLocal_12 = 12;
	fLocal_15 = 0.001f;
	iLocal_18 = -1;
	sLocal_19 = "NULL";
	fLocal_24 = 80f;
	fLocal_25 = 140f;
	fLocal_26 = 180f;
	fLocal_29 = 0f;
	fLocal_33 = -0.0375f;
	fLocal_34 = 0.17f;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	vLocal_56 = {-1124.392f, -514.7001f, 33.21493f};
	fLocal_59 = 200f;
	vLocal_60 = {2490f, 3777f, 2402.879f};
	vLocal_63 = {-2052f, 3237f, 1450.078f};
	iLocal_155 = 1;
	if (player::has_force_cleanup_occurred(18)) {
		func_62(1);
	}
	iLocal_151 = 2;
	if (func_61(player::player_ped_id())) {
		if (system::vdist2(func_60(), entity::get_entity_coords(player::player_ped_id(), 1)) < 40000f) {
			if (cam::is_screen_faded_in()) {
				if (player::is_player_control_on(player::player_id())) {
					Global_101700.f_24032.f_8 = 1;
				}
			}
		}
	}
	gameplay::_0x6F2135B6129620C1(1);
	while (true) {
		if (!func_61(player::player_ped_id())) {
			return;
		}
		func_56();
		switch (iLocal_150) {
		case 0: func_23(); break;

		case 1: func_13(); break;

		case 2: func_11(); break;

		case 3: func_1(); break;
		}
		system::wait(0);
	}
}

// Position - 0x165
void func_1() {
	if (func_10()) {
		func_8();
		func_6(Global_101700.f_24032);
	}
	Global_101700.f_24032.f_8 = 1;
	func_5(65, 0, 0);
	func_4();
	func_2();
	iLocal_150 = 0;
}

// Position - 0x1A1
int func_2() {
	if (func_3(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x1EC
bool func_3(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x217
void func_4() { Global_101697 = 0; }

// Position - 0x224
void func_5(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	if (iVar0 < 0 || iVar0 >= 263 || iParam0 == 263) {
		return;
	}
	if (!iParam2) {
		iVar1 = gameplay::is_bit_set(Global_25501[iVar0 /*23*/].f_11, 15);
		if (iVar1 == iParam1) {
			return;
		}
	}
	if (iParam1 != gameplay::is_bit_set(Global_25501[iVar0 /*23*/].f_11, 0)) {
		gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 18);
		if (Global_25498 == 1) {
			Global_25499 = 1;
		}
		Global_25498 = 1;
	}
	if (iParam1) {
		gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 0);
		gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 15);
		gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 3);
	}
	else {
		gameplay::clear_bit(&Global_25501[iVar0 /*23*/].f_11, 0);
		gameplay::clear_bit(&Global_25501[iVar0 /*23*/].f_11, 15);
	}
	if (!gameplay::is_bit_set(Global_25501[iVar0 /*23*/].f_11, 0)) {
		if (ui::does_blip_exist(Global_25501[iVar0 /*23*/].f_19)) {
			gameplay::set_this_script_can_remove_blips_created_by_any_script(1);
			ui::remove_blip(&Global_25501[iVar0 /*23*/].f_19);
			gameplay::set_this_script_can_remove_blips_created_by_any_script(0);
		}
	}
}

// Position - 0x32D
void func_6(int iParam0) {
	func_7(iParam0);
	switch (iParam0) {
	case 0:
		Global_101700.f_24032 = 1;
		Global_101700.f_24032.f_3 = 1;
		break;

	case 1:
		Global_101700.f_24032 = 2;
		Global_101700.f_24032.f_4 = 1;
		break;

	case 2:
		Global_101700.f_24032 = 3;
		Global_101700.f_24032.f_5 = 1;
		break;

	case 3:
		Global_101700.f_24032 = 4;
		Global_101700.f_24032.f_6 = 1;
		break;

	case 4:
		Global_101700.f_24032 = 0;
		Global_101700.f_24032.f_7 = 1;
		break;
	}
}

// Position - 0x3C9
void func_7(int iParam0) {
	int iVar0;

	iVar0 = 0;
	stats::stat_get_int(joaat("num_stock_races_completed"), &iVar0, -1);
	if (iVar0 < iParam0 + 1) {
		stats::stat_set_int(joaat("num_stock_races_completed"), iParam0 + 1, 1);
	}
}

// Position - 0x3F9
void func_8() {
	struct<2> Var0;

	ui::clear_help(1);
	StringCopy(&Var0, "CRACEWIN", 16);
	StringIntConCat(&Var0, Global_101700.f_24032 + 1, 16);
	func_9(&Var0, -1);
}

// Position - 0x420
void func_9(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x437
bool func_10() { return Global_101697; }

// Position - 0x443
void func_11() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("country_race")) == 0) {
		func_12(&Global_101698);
		Global_101698 = -1;
		iLocal_151 = 2;
		iLocal_150 = 3;
	}
}

// Position - 0x46B
void func_12(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0x4A8
void func_13() {
	ui::hide_help_text_this_frame();
	func_22();
	player::set_all_random_peds_flee_this_frame(player::player_id());
	script::request_script("Country_Race");
	controls::disable_control_action(0, 74, 1);
	gameplay::clear_area_of_projectiles(func_60(), 20f, 0);
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("country_race")) == 0) {
		if (script::has_script_loaded("Country_Race")) {
			if (iLocal_151 == 2) {
				iLocal_151 = func_17(&Global_101698, 2, 9, 0, 0);
			}
			else if (iLocal_151 == 1) {
				func_15(&iLocal_153, 0);
				func_14(&iLocal_152, 0);
				system::start_new_script("Country_Race", 4500);
				script::set_script_as_no_longer_needed("Country_Race");
				iLocal_150 = 2;
			}
			else if (iLocal_151 == 0) {
				func_62(0);
			}
		}
	}
}

// Position - 0x543
void func_14(int *iParam0, int iParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (!entity::is_entity_dead(*iParam0, 0)) {
			if (vehicle::is_playback_going_on_for_vehicle(*iParam0)) {
				vehicle::stop_playback_recorded_vehicle(*iParam0);
			}
			entity::stop_synchronized_entity_anim(*iParam0, -8f, 1);
			if (entity::is_entity_attached(*iParam0)) {
				entity::detach_entity(*iParam0, 1, 1);
			}
		}
		if (iParam1) {
			vehicle::delete_vehicle(iParam0);
		}
		else {
			entity::set_vehicle_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0x5A7
void func_15(int iParam0, int iParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (!ped::is_ped_injured(*iParam0)) {
			if (!ped::is_ped_in_any_vehicle(*iParam0, 0) && !ped::is_ped_getting_into_a_vehicle(*iParam0)) {
				if (entity::is_entity_attached_to_any_object(*iParam0) ||
					entity::is_entity_attached_to_any_ped(*iParam0) ||
					entity::is_entity_attached_to_any_vehicle(*iParam0)) {
					entity::detach_entity(*iParam0, 1, 1);
				}
				entity::freeze_entity_position(*iParam0, 0);
			}
			if (!ped::is_ped_in_any_vehicle(*iParam0, 0)) {
				entity::set_entity_collision(*iParam0, 1, 0);
			}
			if (ped::is_ped_group_member(*iParam0, func_16())) {
				ped::remove_ped_from_group(*iParam0);
			}
			if (!iParam1) {
				ped::set_ped_keep_task(*iParam0, 1);
			}
		}
		if (iParam1) {
			ped::delete_ped(iParam0);
		}
		else {
			entity::set_ped_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0x65E
var func_16() { return player::get_player_group(player::get_player_index()); }

// Position - 0x66E
int func_17(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_21(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_19(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_18(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0x7A5
void func_18(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0x7F4
bool func_19(int iParam0) { return func_20(iParam0, Global_35781); }

// Position - 0x805
int func_20(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x9E6
bool func_21(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_19(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0xA08
void func_22() { Global_17151.f_6 = 1; }

// Position - 0xA16
void func_23() {
	if (func_43()) {
		if (entity::is_entity_at_coord(player::player_ped_id(), func_60(), 5f, 5f, 5f, 1, 1, 0)) {
			controls::disable_control_action(0, 74, 1);
			ped::set_ik_target(iLocal_153, 1, player::player_ped_id(), 0, 0f, 0f, 0f, 0, 150, 400);
			if (func_41()) {
				if (func_38()) {
					func_35();
					func_33();
					func_32();
					if (!streaming::is_player_switch_in_progress() && !func_31(1) && !func_30(0) &&
						script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) == 0) {
						if (controls::is_control_just_pressed(2, 51)) {
							audio::play_sound_frontend(-1, "YES", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
							ui::clear_help(1);
							gameplay::clear_area_of_projectiles(func_60(), 20f, 0);
							entity::set_entity_invincible(player::player_ped_id(), 1);
							entity::set_entity_invincible(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 1);
							ui::hide_help_text_this_frame();
							iLocal_150 = 1;
						}
					}
				}
				else {
					func_28();
					func_27();
				}
			}
			else {
				func_24();
				func_27();
			}
		}
		else {
			func_24();
			func_27();
		}
	}
	else {
		func_24();
		func_27();
	}
}

// Position - 0xB12
void func_24() {
	struct<4> Var0;

	Var0 = {func_26()};
	if (ui::has_this_additional_text_loaded("C_RACE", 3) && (func_25(&Var0) || func_25("CRACECAR"))) {
		ui::clear_help(1);
	}
}

// Position - 0xB4A
bool func_25(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0xB5D
struct<4> func_26() {
	struct<4> Var0;

	StringCopy(&Var0, "CRACEHELP", 16);
	StringIntConCat(&Var0, Global_101700.f_24032 + 1, 16);
	return Var0;
}

//Position - 0xB7D
void func_27()
{
	if (cam::is_gameplay_hint_active()) {
		cam::stop_gameplay_hint(0);
	}
	iLocal_155 = 1;
}

// Position - 0xB94
void func_28() {
	if (ui::has_this_additional_text_loaded("C_RACE", 3)) {
		if (!func_25("CRACECAR") &&
			script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) == 0) {
			ui::clear_help(1);
			func_29("CRACECAR", 1, 1, -1);
		}
	}
}

// Position - 0xBD1
void func_29(char *sParam0, int iParam1, int iParam2, int iParam3) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, iParam1, iParam2, iParam3);
}

// Position - 0xBEA
int func_30(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return 1;
	}
	if (Global_14443.f_1 > 3) {
		return 1;
	}
	return 0;
}

// Position - 0xC44
bool func_31(int iParam0) {
	if (iParam0) {
		return Global_17151.f_4 && Global_17151.f_104 == 4;
	}
	return Global_17151.f_4;
}

// Position - 0xC6D
void func_32() {
	struct<4> Var0;

	if (ui::has_this_additional_text_loaded("C_RACE", 3)) {
		Var0 = {func_26()};
		if (!func_25(&Var0) && script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) == 0) {
			ui::clear_help(1);
			func_29(&Var0, 1, 1, -1);
		}
	}
}

// Position - 0xCB0
void func_33() {
	if (cam::get_follow_vehicle_cam_view_mode() != 3 && cam::get_follow_vehicle_cam_view_mode() != 4 &&
		!cam::is_gameplay_cam_looking_behind() && player::is_player_playing(player::player_id()) &&
		func_34(iLocal_153) && entity::get_entity_speed(player::player_ped_id()) < 20f) {
		if (iLocal_155) {
			if (!cam::is_gameplay_hint_active()) {
				cam::set_gameplay_entity_hint(iLocal_153, 0f, 0f, 0f, 1, 2000, 2000, 2000, 0);
				iLocal_155 = 0;
			}
		}
	}
	else {
		if (cam::is_gameplay_hint_active()) {
			cam::stop_gameplay_hint(0);
		}
		iLocal_155 = 1;
	}
}

// Position - 0xD37
int func_34(int iParam0) {
	if (func_61(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xD57
void func_35() {
	if (gameplay::get_game_timer() > iLocal_154 + 5000) {
		func_36(iLocal_153, "PRERACE_CHAT", 11);
		iLocal_154 = gameplay::get_game_timer();
	}
}

// Position - 0xD7C
void func_36(int iParam0, char *sParam1, int iParam2) {
	audio::_play_ambient_speech1(iParam0, sParam1, func_37(iParam2), 1);
}

// Position - 0xD93
int func_37(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: return "SPEECH_PARAMS_STANDARD";

	case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

	case 2: return "SPEECH_PARAMS_BEAT";

	case 3: return "SPEECH_PARAMS_FORCE";

	case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

	case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

	case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

	case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

	case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

	case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

	case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

	case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

	case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

	case 13: return "SPEECH_PARAMS_MEGAPHONE";

	case 14: return "SPEECH_PARAMS_HELI";

	case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

	case 16: return "SPEECH_PARAMS_FORCE_HELI";

	case 17: return "SPEECH_PARAMS_INTERRUPT";

	case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

	case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

	case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

	case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

	case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

	case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

	case 24: return "SPEECH_PARAMS_ADD_BLIP";

	case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

	case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

	case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

	case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

	case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

	case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

	case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

	case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

	case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

	case 34: return "SPEECH_PARAMS_SHOUTED";

	case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

	case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

	default:
	}
	iVar0 = 0;
	return iVar0;
}

// Position - 0xF82
bool func_38() {
	int iVar0;
	int iVar1;
	int iVar2[91];

	if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
		if (func_40(player::get_players_last_vehicle())) {
			iVar0 = entity::get_entity_model(player::get_players_last_vehicle());
			if (func_39(iVar0)) {
				return false;
			}
			if (iVar0 == joaat("police4") || iVar0 == joaat("policeold1") || iVar0 == joaat("policeold2") ||
				iVar0 == joaat("fbi") || iVar0 == joaat("fbi2") || iVar0 == joaat("lguard") ||
				iVar0 == joaat("sheriff") || iVar0 == joaat("sheriff2")) {
				return false;
			}
			if (vehicle::is_this_model_a_bike(iVar0) || vehicle::is_this_model_a_boat(iVar0) ||
				vehicle::is_this_model_a_heli(iVar0) || vehicle::is_this_model_a_plane(iVar0)) {
				return false;
			}
			iVar2[0] = joaat("ambulance");
			iVar2[1] = joaat("benson");
			iVar2[2] = joaat("biff");
			iVar2[3] = joaat("bus");
			iVar2[4] = joaat("firetruk");
			iVar2[5] = joaat("forklift");
			iVar2[6] = joaat("mule");
			iVar2[7] = joaat("mule2");
			iVar2[8] = joaat("packer");
			iVar2[9] = joaat("phantom");
			iVar2[10] = joaat("mower");
			iVar2[11] = joaat("stockade");
			iVar2[12] = joaat("squalo");
			iVar2[13] = joaat("maverick");
			iVar2[14] = joaat("polmav");
			iVar2[15] = joaat("airtug");
			iVar2[16] = joaat("pranger");
			iVar2[17] = joaat("annihilator");
			iVar2[18] = joaat("dinghy");
			iVar2[19] = joaat("police");
			iVar2[20] = joaat("ripley");
			iVar2[21] = joaat("trash");
			iVar2[22] = joaat("burrito");
			iVar2[23] = joaat("pony");
			iVar2[24] = joaat("speedo");
			iVar2[25] = joaat("marquis");
			iVar2[26] = joaat("sanchez");
			iVar2[27] = joaat("airtug");
			iVar2[28] = joaat("taco");
			iVar2[29] = joaat("barracks");
			iVar2[30] = joaat("romero");
			iVar2[31] = joaat("blazer");
			iVar2[32] = joaat("blazer2");
			iVar2[33] = joaat("bodhi2");
			iVar2[34] = joaat("boxville2");
			iVar2[35] = joaat("bulldozer");
			iVar2[36] = joaat("caddy");
			iVar2[37] = joaat("caddy2");
			iVar2[38] = joaat("camper");
			iVar2[39] = joaat("tiptruck");
			iVar2[40] = joaat("tourbus");
			iVar2[41] = joaat("towtruck");
			iVar2[42] = joaat("towtruck2");
			iVar2[43] = joaat("tractor");
			iVar2[44] = joaat("tractor2");
			iVar2[45] = joaat("utillitruck");
			iVar2[46] = joaat("utillitruck2");
			iVar2[47] = joaat("utillitruck3");
			iVar2[48] = joaat("ratloader");
			iVar2[49] = joaat("dloader");
			iVar2[50] = joaat("docktug");
			iVar2[51] = joaat("dump");
			iVar2[52] = joaat("gburrito");
			iVar2[53] = joaat("handler");
			iVar2[54] = joaat("hauler");
			iVar2[55] = joaat("journey");
			iVar2[56] = joaat("rentalbus");
			iVar2[57] = joaat("mixer");
			iVar2[58] = joaat("rhino");
			iVar2[59] = joaat("cutter");
			iVar2[60] = joaat("pounder");
			iVar2[61] = joaat("tiptruck2");
			iVar2[62] = joaat("mixer2");
			iVar2[63] = joaat("rubble");
			iVar2[64] = joaat("scrap");
			iVar2[65] = joaat("armytanker");
			iVar2[66] = joaat("barracks2");
			iVar2[67] = joaat("airbus");
			iVar2[68] = joaat("coach");
			iVar2[69] = joaat("pbus");
			iVar2[70] = joaat("riot");
			iVar2[71] = joaat("boxville3");
			iVar2[72] = joaat("stockade3");
			iVar2[73] = joaat("flatbed");
			iVar2[74] = joaat("boxville");
			iVar2[75] = joaat("burrito2");
			iVar2[76] = joaat("burrito3");
			iVar2[77] = joaat("burrito4");
			iVar2[78] = joaat("rumpo");
			iVar2[79] = joaat("speedo2");
			iVar2[80] = joaat("blimp");
			iVar2[81] = joaat("blimp2");
			iVar2[82] = joaat("submersible");
			iVar2[83] = joaat("submersible2");
			iVar2[84] = joaat("blazer3");
			iVar2[85] = joaat("pony2");
			iVar2[86] = joaat("rumpo2");
			iVar2[87] = joaat("taxi");
			iVar2[88] = gameplay::get_hash_key("RATLOADER2");
			iVar2[89] = gameplay::get_hash_key("SLAMVAN");
			iVar2[90] = 0;
			iVar1 = 0;
			while (iVar1 < iVar2) {
				if (iVar0 == iVar2[iVar1]) {
					return false;
				}
				iVar1++;
			}
			return true;
		}
	}
	return false;
}

// Position - 0x1469
bool func_39(int iParam0) {
	switch (iParam0) {
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("polmav"):
	case joaat("policeb"):
	case joaat("policet"):
	case joaat("policeold2"):
	case joaat("policeold1"):
	case joaat("sheriff"):
	case joaat("sheriff2"): return true;
	}
	return false;
}

// Position - 0x14C2
bool func_40(int iParam0) {
	if (func_61(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (!fire::is_entity_on_fire(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x14EC
bool func_41() {
	int iVar0;

	if (func_42()) {
		return false;
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("chop")) != 0) {
		return false;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (vehicle::get_vehicle_number_of_passengers(iVar0) == 0) {
			return true;
		}
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x153D
bool func_42() {
	int iVar0;

	if (Global_25340) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (!ped::is_ped_injured(vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0))) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x1581
bool func_43() {
	if (!Global_101700.f_24032.f_9 && !Global_101700.f_24032.f_8 &&
		system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), func_60()) < 84100f) {
		Global_101700.f_24032.f_9 = func_54();
		func_51();
		if (!Global_101700.f_24032.f_9) {
			if (func_61(iLocal_153) && func_61(iLocal_152)) {
				if (!ui::has_this_additional_text_loaded("C_RACE", 3) &&
					script::_get_number_of_instances_of_script_with_name_hash(joaat("mission_stat_watcher")) <= 0) {
					ui::request_additional_text("C_RACE", 3);
				}
				return true;
			}
			else {
				func_44(0);
			}
		}
	}
	else {
		if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), func_60()) > 90000f) {
			func_15(&iLocal_153, 1);
			func_14(&iLocal_152, 1);
			if (Global_101700.f_24032.f_9) {
				Global_101700.f_24032.f_9 = 0;
			}
			if (Global_101700.f_24032.f_8) {
				Global_101700.f_24032.f_8 = 0;
			}
		}
		if (Global_101700.f_24032.f_9) {
			func_15(&iLocal_153, 0);
			func_14(&iLocal_152, 0);
			if (entity::is_entity_at_coord(player::player_ped_id(), func_60(), 5f, 5f, 5f, 1, 1, 0)) {
				if (ui::has_this_additional_text_loaded("C_RACE", 3)) {
					if (!func_25("CRACEDISRUPT") &&
						script::_get_number_of_instances_of_script_with_name_hash(joaat("appinternet")) == 0) {
						ui::clear_help(1);
						func_29("CRACEDISRUPT", 1, 1, -1);
					}
				}
			}
			else if (ui::has_this_additional_text_loaded("C_RACE", 3) && func_25("CRACEDISRUPT")) {
				ui::clear_help(1);
			}
		}
		else if (ui::has_this_additional_text_loaded("C_RACE", 3) && func_25("CRACEDISRUPT")) {
			ui::clear_help(1);
		}
	}
	return false;
}

// Position - 0x1721
void func_44(int iParam0) {
	if (!entity::does_entity_exist(iLocal_152) && !entity::does_entity_exist(iLocal_153)) {
		streaming::request_model(func_50());
		streaming::request_model(joaat("a_m_y_motox_02"));
		if (iParam0) {
			while (!streaming::has_model_loaded(func_50())) {
				system::wait(0);
			}
			while (!streaming::has_model_loaded(joaat("a_m_y_motox_02"))) {
				system::wait(0);
			}
		}
		if (streaming::has_model_loaded(func_50()) && streaming::has_model_loaded(joaat("a_m_y_motox_02"))) {
			iLocal_152 = vehicle::create_vehicle(func_50(), func_49(), func_48(), 1, 1);
			vehicle::set_vehicle_on_ground_properly(iLocal_152, 1084227584);
			if (Global_101700.f_24032 == 4) {
				vehicle::set_vehicle_livery(iLocal_152, 0);
				vehicle::set_vehicle_colours(iLocal_152, 44, 83);
				vehicle::set_vehicle_extra_colours(iLocal_152, 111, 111);
			}
			vehicle::set_vehicle_doors_locked(iLocal_152, 3);
			vehicle::set_vehicle_automatically_attaches(iLocal_152, 0, 0);
			vehicle::_0x2B6747FAA9DB9D6B(iLocal_152, 1);
			streaming::set_model_as_no_longer_needed(func_50());
			iLocal_153 = ped::create_ped(26, joaat("a_m_y_motox_02"), func_47(), func_46(), 1, 1);
			func_45(iLocal_153);
			audio::set_ambient_voice_name(iLocal_153, "A_M_Y_RACER_01_WHITE_MINI_01");
			ai::task_start_scenario_in_place(iLocal_153, "WORLD_HUMAN_STAND_IMPATIENT", -1, 1);
			streaming::set_model_as_no_longer_needed(joaat("a_m_y_motox_02"));
		}
	}
}

// Position - 0x1836
void func_45(int iParam0) {
	switch (Global_101700.f_24032) {
	case 0:
		ped::set_ped_component_variation(iParam0, 0, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;

	case 1:
		ped::set_ped_component_variation(iParam0, 0, 1, 1, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 7, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 4, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 1, 0);
		break;

	case 2:
		ped::set_ped_component_variation(iParam0, 0, 1, 2, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 5, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 2, 0);
		break;

	case 3:
		ped::set_ped_component_variation(iParam0, 0, 1, 0, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 2, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 3, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;

	case 4:
		ped::set_ped_component_variation(iParam0, 0, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 6, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 3, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;
	}
}

// Position - 0x1976
float func_46() { return 294.2507f; }

// Position - 0x1983
Vector3 func_47() { return 1965.248f, 3114.886f, 46.1663f; }

// Position - 0x199A
float func_48() { return 194.8257f; }

// Position - 0x19A7
Vector3 func_49() { return 1964.038f, 3114.635f, 46.1319f; }

// Position - 0x19BE
int func_50() {
	switch (Global_101700.f_24032) {
	case 0: return joaat("stalion2");

	case 1: return joaat("gauntlet2");

	case 2: return joaat("dominator2");

	case 3: return joaat("buffalo3");

	case 4: return joaat("marshall");
	}
	return joaat("buffalo3");
}

// Position - 0x1A2C
void func_51() {
	if (func_61(iLocal_153)) {
		if (!ped::is_ped_fleeing(iLocal_153) && !ped::is_ped_in_combat(iLocal_153, 0) &&
			!ped::is_ped_ragdoll(iLocal_153)) {
			if (!func_53(iLocal_153, 993674639, 1)) {
				ai::task_start_scenario_in_place(iLocal_153, "WORLD_HUMAN_STAND_IMPATIENT", -1, 1);
			}
			if (func_52(iLocal_152) || Global_101700.f_24032.f_9) {
				ped::_0xF1C03A5352243A30(iLocal_153);
				ai::task_combat_ped(iLocal_153, player::player_ped_id(), 0, 16);
			}
			fLocal_156 = entity::get_entity_speed(player::player_ped_id());
		}
		else if (ped::is_ped_ragdoll(iLocal_153)) {
			if (!func_53(iLocal_153, 780511057, 1)) {
				ped::_0xF1C03A5352243A30(iLocal_153);
				ai::task_combat_ped(iLocal_153, player::player_ped_id(), 0, 16);
			}
		}
	}
}

// Position - 0x1AE0
int func_52(int iParam0) {
	int iVar0;
	float fVar1;

	iVar0 = player::get_players_last_vehicle();
	if (func_61(iParam0)) {
		if (func_61(iVar0) && fLocal_156 != 0f && fLocal_156 >= 9f) {
			fVar1 = entity::get_entity_speed(iVar0);
			if (entity::is_entity_touching_entity(iParam0, iVar0) && fVar1 <= fLocal_156 * 0.5f) {
				return 1;
			}
		}
		if (entity::get_entity_health(iParam0) + 100 < entity::get_entity_max_health(iParam0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1B53
int func_53(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = ai::get_script_task_status(iParam0, iParam1);
	if (iVar0 == 1 || iVar0 == 0) {
		return 1;
	}
	else if (!iParam2) {
		if (iVar0 == 2 || iVar0 == 3) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1B99
int func_54() {
	if (entity::does_entity_exist(iLocal_153)) {
		if (entity::is_entity_dead(iLocal_153, 0)) {
			return 1;
		}
		else if (ped::is_ped_fleeing(iLocal_153)) {
			return 1;
		}
		else if (ped::is_ped_in_combat(iLocal_153, 0)) {
			return 1;
		}
		else if (ped::is_ped_ragdoll(iLocal_153)) {
			return 1;
		}
		else if (ped::is_ped_shooting(player::player_ped_id())) {
			return 1;
		}
	}
	if (entity::does_entity_exist(iLocal_152)) {
		if (entity::is_entity_dead(iLocal_152, 0)) {
			return 1;
		}
		else {
			if (func_55(iLocal_152, func_49(), 1) > 2f) {
				return 1;
			}
			if (weapon::has_vehicle_got_projectile_attached(player::player_ped_id(), iLocal_152, 0, -1)) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x1C3D
float func_55(int iParam0, vector3 vParam1, int iParam4) {
	vector3 vVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vParam1, iParam4);
}

// Position - 0x1C77
void func_56() {
	if (!func_59(0, 19)) {
		Global_101700.f_24032.f_8 = 1;
		func_62(0);
	}
	if (func_21(9) && iLocal_150 == 0) {
		Global_101700.f_24032.f_8 = 1;
		func_62(0);
	}
	if (func_58(13)) {
		Global_101700.f_24032.f_8 = 1;
		func_62(0);
	}
	if (!func_57()) {
		Global_101700.f_24032.f_8 = 1;
		func_62(0);
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("country_race")) == 0) {
		if (system::vdist2(func_60(), entity::get_entity_coords(player::player_ped_id(), 1)) > 160000f) {
			func_62(0);
		}
	}
}

// Position - 0x1D15
int func_57() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return 1;
			}
		}
	}
	if (Global_139179 == 2) {
		return 1;
	}
	else if (Global_139179 == 3) {
		return 0;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1DD0
bool func_58(int iParam0) {
	int iVar0;

	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	if (Global_85809[iParam0 /*2*/]) {
		return true;
	}
	iVar0 = 0;
	while (iVar0 < Global_82576) {
		if (Global_82576[iVar0 /*5*/] != -1) {
			if (G_TextMessageConfig.f_109[Global_82576[iVar0 /*5*/] /*4*/] == iParam0) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x1E38
int func_59(int iParam0, int iParam1) {
	var uVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return 0;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return 0;
	}
	uVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	return uVar0;
}

// Position - 0x1E85
Vector3 func_60() { return 1967.042f, 3116.005f, 45.8901f; }

// Position - 0x1E9C
bool func_61(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1EBD
void func_62(int iParam0) {
	struct<4> Var0;

	func_12(&Global_101698);
	if (func_61(iLocal_153)) {
		if (func_53(iLocal_153, -1098463898, 1) || func_53(iLocal_153, 993674639, 1)) {
			ai::task_wander_standard(iLocal_153, 1193033728, 0);
		}
	}
	func_15(&iLocal_153, iParam0);
	func_14(&iLocal_152, iParam0);
	if (iParam0) {
		gameplay::clear_area(func_60(), 100f, 1, 0, 0, 0);
	}
	if (cam::is_gameplay_hint_active()) {
		cam::stop_gameplay_hint(0);
	}
	iLocal_155 = 1;
	Var0 = {func_26()};
	if (ui::has_this_additional_text_loaded("C_RACE", 3)) {
		if (func_25("CRACEDISRUPT") || func_25("CRACECAR") || func_25(&Var0)) {
			ui::clear_help(1);
		}
	}
	script::set_script_as_no_longer_needed("Country_Race");
	script::terminate_this_thread();
}

void __EntryFunction__() { script::terminate_this_thread(); }

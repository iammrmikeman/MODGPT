#pragma region Local Var //{
bool bLocal_0 = 0;
var uLocal_1 = 0;
var uLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
int iLocal_12 = 0;
var uLocal_13 = 0;
var uLocal_14 = 0;
float fLocal_15 = 0f;
var uLocal_16 = 0;
var uLocal_17 = 0;
int iLocal_18 = 0;
var uLocal_19 = 0;
var uLocal_20 = 0;
char *sLocal_21 = NULL;
float fLocal_22 = 0f;
var uLocal_23 = 0;
var uLocal_24 = 0;
var uLocal_25 = 0;
float fLocal_26 = 0f;
float fLocal_27 = 0f;
var uLocal_28 = 0;
int iLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
float fLocal_34 = 0f;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 10;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 2;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 8;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 8;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
var uLocal_94 = 0;
var uLocal_95 = 0;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
float fLocal_98 = 0f;
float fLocal_99 = 0f;
float fLocal_100 = 0f;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 17;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 17;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 12;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 12;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 12;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 9;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 9;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 2;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
float fLocal_230 = 0f;
float fLocal_231 = 0f;
float fLocal_232 = 0f;
var uLocal_233 = 0;
vector3 vLocal_234 = {0f, 0f, 0f};
float fLocal_237 = 0f;
bool bLocal_238 = 0;
bool bLocal_239 = 0;
bool bLocal_240 = 0;
bool bLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
vector3 vLocal_248 = {0f, 0f, 0f};
var uLocal_251 = 0;
var uLocal_252 = 0;
int iLocal_253 = 0;
bool bLocal_254 = 0;
int iLocal_255 = 0;
int iLocal_256 = 0;
int iLocal_257 = 0;
var uLocal_258 = 0;
int iLocal_259 = 0;
int iLocal_260 = 0;
int iLocal_261 = 0;
#pragma endregion //}

void __EntryFunction__() {
	struct<170> Var0;
	struct<44> Var341;
	var *uVar397;
	int iVar422;
	var *uVar423;
	int iVar435;
	int iVar436;
	int iVar437;

	iLocal_3 = 1;
	iLocal_4 = 134;
	iLocal_5 = 134;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 1;
	iLocal_9 = 134;
	iLocal_10 = 1;
	iLocal_11 = 12;
	iLocal_12 = 12;
	fLocal_15 = 0.001f;
	iLocal_18 = -1;
	sLocal_21 = "NULL";
	fLocal_22 = 0f;
	fLocal_26 = -0.0375f;
	fLocal_27 = 0.17f;
	iLocal_29 = 3;
	fLocal_32 = 80f;
	fLocal_33 = 140f;
	fLocal_34 = 180f;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_93 = 0.05f + 0.275f - 0.01f;
	fLocal_96 = -0.05f;
	fLocal_97 = 0.92f;
	fLocal_98 = 1.94f;
	fLocal_99 = 2.99f;
	fLocal_100 = 3.7f;
	fLocal_230 = -1213f;
	fLocal_231 = 118.179f;
	fLocal_232 = 1f;
	vLocal_234 = {0.57f, 0.03f, 0f};
	fLocal_237 = 50f;
	iLocal_253 = 1;
	iLocal_259 = -1;
	iLocal_260 = -1;
	iLocal_261 = 200;
	Var0 = 2;
	Var0.f_1.f_15 = 4;
	Var0.f_1.f_152 = 2;
	Var0.f_1.f_167 = 2;
	Var0.f_1.f_170.f_15 = 4;
	Var0.f_1.f_170.f_152 = 2;
	Var0.f_1.f_170.f_167 = 2;
	Var341 = 9;
	Var341.f_30 = 4;
	Var341.f_43 = 4;
	uVar397 = 14;
	uVar423 = 11;
	iVar422 = 2;
	uLocal_242 = uLocal_242;
	if (player::has_force_cleanup_occurred(67)) {
		func_310(&Var341);
		func_307(&Var0);
		script::terminate_this_thread();
	}
	while (true) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		}
		switch (iVar422) {
		case 2:
			if (bLocal_0) {
			}
			func_304(&Var341);
			streaming::request_anim_dict(func_303());
			streaming::request_anim_set("move_m@golfer@");
			func_299(&uVar423);
			iVar422 = 3;
			break;

		case 3:
			if (streaming::has_anim_dict_loaded(func_303()) && func_298(&uVar423) &&
				streaming::has_anim_set_loaded("move_m@golfer@")) {
				func_295(&uVar397);
				iVar422 = 4;
			}
			break;

		case 4:
			if (func_294(time::get_clock_hours())) {
				if (!cam::is_sphere_visible(func_292(&Var341, func_293(&Var0[iVar436 /*170*/])), 10f) || func_291(4)) {
					func_295(&uVar397);
					iVar422 = 5;
					iVar436 = 0;
					while (iVar436 < Var0) {
						func_278(&Var341, &Var0[iVar436 /*170*/], 1, iVar436 * 4, 0);
						iVar435 = 0;
						while (iVar435 < func_277(&Var0[iVar436 /*170*/])) {
							func_276(&Var0[iVar436 /*170*/], iVar435, 4194304);
							func_273(&Var0[iVar436 /*170*/], func_275(&uVar397, 19));
							iVar435++;
						}
						iVar436++;
					}
				}
			}
			break;

		case 5:
			func_272(&uVar397, 8);
			iVar422 = 6;
			break;

		case 6:
			func_272(&uVar397, 8);
			func_1(&uVar397, &Var341, &Var0[iVar437 /*170*/]);
			iVar437++;
			if (iVar437 >= Var0) {
				iVar437 = 0;
			}
			break;

		case 9:
			func_310(&Var341);
			func_307(&Var0);
			streaming::remove_anim_dict(func_303());
			script::terminate_this_thread();
			break;

		default: break;
		}
		system::wait(0);
	}
}

// Position - 0x30A
void func_1(var *uParam0, var *uParam1, var *uParam2) {
	struct<7> Var0;
	int *iVar7;
	int iVar8;

	if (entity::is_entity_dead(func_271(uParam2), 0) || ped::is_ped_injured(func_271(uParam2)) ||
		!entity::does_entity_exist(func_271(uParam2)) || ped::is_ped_fleeing(func_271(uParam2))) {
		if (entity::does_entity_exist(func_269(uParam2))) {
			func_267(uParam2);
		}
		return;
	}
	else {
		Var0.f_2 = 1097859072;
		Var0.f_3 = 1500;
		Var0.f_4 = 45;
		Var0.f_5 = 1103626240;
		Var0.f_6 = 5;
		if (func_257(func_271(uParam2), 0, &Var0, &iVar7, 0, 1, 0, 1, 1) ||
			ped::is_ped_in_melee_combat(func_271(uParam2)) || ped::is_ped_responding_to_event(func_271(uParam2), 60)) {
			ai::clear_ped_tasks(func_271(uParam2));
			ai::task_smart_flee_ped(func_271(uParam2), player::player_ped_id(), 150f, -1, 0, 0);
			ped::set_blocking_of_non_temporary_events(func_271(uParam2), 1);
			func_256(uParam2, 4);
			return;
		}
	}
	func_254(&uParam2->f_15[func_255(uParam2) /*34*/], player::player_ped_id(), uParam2, func_255(uParam2), uParam1);
	switch (func_253(uParam2)) {
	case 0:
		func_252(uParam2, uParam0);
		func_243(uParam1, uParam2);
		if (func_242(&uParam2->f_15[0 /*34*/])) {
			func_256(uParam2, 2);
		}
		break;

	case 2:
		func_30(uParam0, uParam1, uParam2);
		ped::set_ped_reset_flag(func_271(uParam2), 129, 1);
		if (func_29(uParam2) <= 3) {
			func_252(uParam2, uParam0);
		}
		if (func_26(uParam2, -1, 0)) {
			if (bLocal_0) {
			}
			func_252(uParam2, uParam0);
			uParam2->f_157 = 0;
			while (uParam2->f_157 < func_277(uParam2)) {
				func_24(uParam2, 0);
				func_23(uParam2, 0f, 0f, 0f, 5);
				func_22(uParam2, 0f, 0f, -1f);
				uParam2->f_157++;
			}
			iVar8 = func_293(uParam2);
			if (iVar8 == 0) {
				func_21(uParam2, 1);
			}
			else if (iVar8 == 1) {
				func_21(uParam2, 0);
			}
			else if (iVar8 == 4) {
				func_21(uParam2, 3);
			}
			else if (iVar8 == 3) {
				func_21(uParam2, 4);
			}
			func_20(uParam2, 0);
			if (func_293(uParam2) != iVar8) {
				func_7(uParam1, uParam2);
				func_256(uParam2, 3);
			}
			if (entity::does_entity_exist(func_269(uParam2))) {
				func_5(uParam2, entity::get_entity_coords(func_269(uParam2), 1));
			}
		}
		else if (func_2(&uParam2->f_15[func_255(uParam2) /*34*/])) {
			func_24(uParam2, 1);
			func_243(uParam1, uParam2);
			func_20(uParam2, 0);
			func_252(uParam2, uParam0);
			func_256(uParam2, 0);
		}
		break;

	case 3:
		func_243(uParam1, uParam2);
		func_256(uParam2, 0);
		break;

	case 4: break;
	}
}

// Position - 0x5BE
bool func_2(var *uParam0) {
	if (func_4(uParam0) == 9 || func_4(uParam0) == 10 || func_3(uParam0, 16777216)) {
		return true;
	}
	return false;
}

// Position - 0x5F7
bool func_3(var *uParam0, int iParam1) { return (uParam0->f_22 & iParam1) != 0; }

// Position - 0x608
int func_4(var *uParam0) { return *uParam0; }

// Position - 0x613
void func_5(var *uParam0, vector3 vParam1) { func_6(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x62D
void func_6(var *uParam0, vector3 vParam1) { uParam0->f_7 = {vParam1}; }

// Position - 0x63F
void func_7(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_277(uParam1)) {
		func_13(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, 0f, 5, 1);
		func_12(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, -1f);
		func_11(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, 0f);
		func_6(&uParam1->f_15[iVar0 /*34*/], func_292(uParam0, func_293(uParam1)));
		func_9(&uParam1->f_15[iVar0 /*34*/], func_10(uParam0, func_293(uParam1)));
		func_8(&uParam1->f_15[iVar0 /*34*/], 0);
		iVar0++;
	}
}

// Position - 0x6CA
void func_8(var *uParam0, int iParam1) { uParam0->f_18 = iParam1; }

// Position - 0x6D8
void func_9(var *uParam0, float fParam1) { uParam0->f_13 = fParam1; }

// Position - 0x6E6
float func_10(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f;
	}
	return (*uParam0)[iParam1 /*3*/];
}

// Position - 0x70C
void func_11(var *uParam0, vector3 vParam1) { uParam0->f_10 = {vParam1}; }

// Position - 0x71E
void func_12(var *uParam0, vector3 vParam1) { uParam0->f_25 = {vParam1}; }

// Position - 0x730
void func_13(var *uParam0, vector3 vParam1, int iParam4, int iParam5) {
	if (iParam5) {
	}
	if (!func_19(vParam1)) {
		if (iParam4 == 3) {
			if (func_16(vParam1)) {
				iParam4 = 2;
			}
		}
		if (func_14(vParam1)) {
			iParam4 = 9;
		}
	}
	uParam0->f_23 = iParam4;
}

// Position - 0x772
bool func_14(vector3 vParam0) { return func_15(vParam0, -1215.93f, -15.72f, 45.21f, 2.5f, 1); }

// Position - 0x797
bool func_15(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	return gameplay::get_distance_between_coords(vParam0, vParam3, iParam7) <= fParam6;
}

// Position - 0x7B0
bool func_16(vector3 vParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (system::vdist2(func_18(iVar0), vParam0) < func_17(iVar0) * func_17(iVar0)) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x7EF
float func_17(int iParam0) {
	switch (iParam0) {
	case 0: return 11.26f;

	case 1: return 10.38f;

	case 2: return 13.4f;

	case 3: return 8.94f;

	case 4: return 12.8f;

	case 5: return 9.42f;

	case 6: return 9.42f;

	case 7: return 15f;

	case 8: return 11.69f;
	}
	return 0f;
}

// Position - 0x898
Vector3 func_18(int iParam0) {
	switch (iParam0) {
	case 0: return -1329.875f, 52.557f, 52.677f;

	case 1: return -1329.26f, 35.458f, 52.677f;

	case 2: return -1330.135f, 95.877f, 54.98f;

	case 3: return -1334.394f, 103.347f, 55.392f;

	case 4: return -1332.059f, 68.521f, 52.736f;

	case 5: return -1336.215f, 82.867f, 53.703f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x94C
int func_19(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0x976
void func_20(var *uParam0, int iParam1) { uParam0->f_157 = iParam1; }

// Position - 0x984
void func_21(var *uParam0, int iParam1) { uParam0->f_158 = iParam1; }

// Position - 0x992
void func_22(var *uParam0, vector3 vParam1) { func_12(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x9AC
void func_23(var *uParam0, vector3 vParam1, int iParam4) {
	func_13(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1, iParam4, 1);
}

// Position - 0x9C9
void func_24(var *uParam0, int iParam1) { func_25(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1, 0); }

// Position - 0x9E2
void func_25(var *uParam0, int iParam1, int iParam2) {
	if (iParam2) {
	}
	*uParam0 = iParam1;
}

// Position - 0x9F4
bool func_26(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_277(uParam0)) {
		if (iParam1 < 0 || iParam1 != iVar0) {
			if (func_4(&uParam0->f_15[iVar0 /*34*/]) != 10 &&
				(func_28(&uParam0->f_15[iVar0 /*34*/]) != 4 || !iParam2) && !func_27(uParam0, iVar0, 16777216)) {
				return false;
			}
		}
		iVar0++;
	}
	return true;
}

// Position - 0xA6B
bool func_27(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return false;
	}
	return func_3(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xA99
int func_28(var *uParam0) { return uParam0->f_1; }

// Position - 0xAA5
int func_29(var *uParam0) {
	if (uParam0->f_157 < 0) {
		return -1;
	}
	return func_4(&uParam0->f_15[uParam0->f_157 /*34*/]);
}

// Position - 0xAC7
void func_30(var *uParam0, var *uParam1, var *uParam2) {
	vector3 vVar0;

	if (!entity::does_entity_exist(func_271(uParam2))) {
		return;
	}
	if (entity::is_entity_dead(func_271(uParam2), 0)) {
		return;
	}
	switch (func_29(uParam2)) {
	case 0:
		vVar0 = {func_292(uParam1, func_293(uParam2))};
		func_241(&vVar0, 1073741824, 1065353216);
		if (!entity::does_entity_exist(func_269(uParam2))) {
			func_235(uParam2, func_237(vVar0, func_238(func_240(uParam1, func_293(uParam2)), func_239(uParam2))));
		}
		else if (!func_234()) {
			entity::set_entity_coords(func_269(uParam2), vVar0, 1, 0, 0, 1);
		}
		func_5(uParam2, entity::get_entity_coords(func_269(uParam2), 1));
		if (func_233(uParam1, func_293(uParam2)) == 1) {
			func_23(uParam2, 0f, 0f, 0f, 3);
		}
		else {
			func_23(uParam2, 0f, 0f, 0f, 5);
		}
		func_22(uParam2, 0f, 0f, -1f);
		if (!bLocal_238) {
			func_221(uParam0, uParam1, uParam2, 1);
		}
		func_197(uParam1, uParam2, uParam0, 0, 0, 1, 1, 0);
		entity::set_entity_records_collisions(func_269(uParam2), 0);
		func_196(func_269(uParam2), 1);
		func_193(uParam0, uParam1, uParam2);
		func_191(&uParam2->f_1, &uParam2->f_15[func_255(uParam2) /*34*/], uParam0);
		func_188(uParam2, func_189(uParam2, uParam0));
		func_187(&uParam2->f_162);
		func_24(uParam2, 3);
		break;

	case 1:
		if (!bLocal_238) {
			func_221(uParam0, uParam1, uParam2, 1);
		}
		func_197(uParam1, uParam2, uParam0, 0, 0, 0, 1, 0);
		if (!entity::does_entity_exist(func_269(uParam2))) {
			func_235(uParam2, func_237(func_292(uParam1, func_293(uParam2)) + Vector(0.075f, 0f, 0f),
									   func_238(func_240(uParam1, func_293(uParam2)), func_239(uParam2))));
		}
		func_193(uParam0, uParam1, uParam2);
		func_191(&uParam2->f_1, &uParam2->f_15[func_255(uParam2) /*34*/], uParam0);
		if (!func_186(uParam2)) {
			func_188(uParam2, func_189(uParam2, uParam0));
		}
		func_187(&uParam2->f_162);
		func_24(uParam2, 3);
		break;

	case 3:
		if (func_185(uParam2) || func_3(&uParam2->f_15[func_255(uParam2) /*34*/], 1048576)) {
			if (func_3(&uParam2->f_15[func_255(uParam2) /*34*/], 1048576)) {
				func_178(uParam2, func_255(uParam2), uParam1, 0, 1);
				func_176(&uParam2->f_162);
				func_24(uParam2, func_175());
				return;
			}
			if (entity::does_entity_exist(func_271(uParam2)) && !entity::is_entity_dead(func_271(uParam2), 0)) {
				if (system::vdist2(entity::get_entity_coords(func_271(uParam2), 1), func_239(uParam2)) > 9f) {
					ai::clear_ped_tasks(func_271(uParam2));
					func_24(uParam2, 1);
					return;
				}
			}
			func_176(&uParam2->f_162);
			func_24(uParam2, func_175());
			func_174(uParam2, 1);
			func_160(uParam0, &uParam2->f_15[func_255(uParam2) /*34*/], &uParam2->f_1);
			if (func_157(uParam1, uParam2)) {
				func_188(uParam2, func_189(uParam2, uParam0));
			}
		}
		else if (entity::get_entity_speed(func_271(uParam2)) == 0f && func_156(&uParam2->f_162, 15f)) {
			func_187(&uParam2->f_162);
			ai::clear_ped_tasks(func_271(uParam2));
			if (!func_154(uParam2, -1)) {
				func_24(uParam2, 0);
			}
			else {
				func_24(uParam2, 1);
			}
		}
		break;

	case 4:
		if (func_153(player::player_ped_id(), uParam2->f_15[func_255(uParam2) /*34*/].f_2, 0) < 1f) {
			if (entity::is_entity_touching_entity(player::player_ped_id(),
												  uParam2->f_15[func_255(uParam2) /*34*/].f_2)) {
				ai::clear_ped_tasks_immediately(uParam2->f_15[func_255(uParam2) /*34*/].f_2);
				func_197(uParam1, uParam2, uParam0, 0, 0, 0, 1, 0);
				func_256(uParam2, 0);
				func_24(uParam2, 1);
				func_152(&uParam2->f_162);
				return;
			}
		}
		if (bLocal_0) {
		}
		func_140(uParam2, uParam0, &uParam2->f_1, 0, 0);
		if (!func_139(uParam2, 1048576)) {
			func_160(uParam0, &uParam2->f_15[func_255(uParam2) /*34*/], &uParam2->f_1);
		}
		if (!func_138(uParam0, 8)) {
			if (uParam2->f_1 == 4 || uParam2->f_1 == 6 || func_139(uParam2, 1048576))
				&&entity::does_entity_exist(func_269(uParam2)) {
					if (func_137(func_271(uParam2)) || func_156(&uParam2->f_162, 2.5f) || func_139(uParam2, 1048576))
						&&entity::does_entity_have_physics(func_269(uParam2)) {
							if (func_139(uParam2, 1048576)) {
								if (bLocal_0) {
								}
								uParam2->f_1 = 4;
							}
							if (func_108(uParam0, uParam1, uParam2)) {
								uParam2->f_1 = 0;
								func_24(uParam2, 5);
							}
							else {
								uParam2->f_1 = 0;
								func_24(uParam2, 3);
							}
							func_107(uParam0, 8);
						}
				}
			else if (!entity::does_entity_exist(func_269(uParam2))) {
				uParam2->f_1 = 0;
				func_24(uParam2, 0);
			}
		}
		break;

	case 5:
		if (func_106(func_271(uParam2), 1f)) {
			func_100(uParam0, uParam2, 1);
		}
		if (!entity::does_entity_exist(func_269(uParam2))) {
			func_235(uParam2,
					 func_237(func_239(uParam2), func_238(func_240(uParam1, func_293(uParam2)), func_239(uParam2))));
		}
		if (!func_157(uParam1, uParam2)) {
			func_83(uParam0, uParam1, uParam2);
			func_82(&uParam2->f_1);
			if (func_139(uParam2, 4)) {
				func_81(&uParam2->f_1);
			}
		}
		else {
			func_67(uParam0, uParam1, uParam2);
			if (func_139(uParam2, 4)) {
				func_81(&uParam2->f_1);
			}
		}
		break;

	case 6:
		func_100(uParam0, uParam2, 1);
		if (func_66(uParam2) || func_65(uParam2) || func_62(entity::get_entity_coords(func_269(uParam2), 1))) {
			func_61(uParam2);
		}
		else {
			func_52(uParam1, uParam2);
		}
		func_24(uParam2, 7);
		func_51(uParam2, 1);
		if (func_49(uParam2) > func_233(uParam1, func_293(uParam2)) + 3) {
			func_24(uParam2, 7);
			func_47(uParam2, 16384);
		}
		break;

	case 8:
		func_100(uParam0, uParam2, 1);
		func_24(uParam2, 7);
		func_51(uParam2, 1);
		func_267(uParam2);
		func_45(uParam2, 67108864);
		if (!func_26(uParam2, func_255(uParam2), 0) && !func_139(uParam2, 1048576)) {
			ai::clear_ped_tasks(func_271(uParam2));
			ai::open_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
			ai::task_go_to_coord_any_means(0, func_44(uParam1, func_293(uParam2), func_255(uParam2)), 1f, 0, 0, 786603,
										   -1082130432);
			ai::task_turn_ped_to_face_coord(0, func_43(uParam1, func_293(uParam2)), 0);
			ai::close_sequence_task(uParam2->f_15[func_255(uParam2) /*34*/].f_21);
			ai::task_perform_sequence(func_271(uParam2), uParam2->f_15[func_255(uParam2) /*34*/].f_21);
			ai::clear_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
		}
		break;

	case 7:
		if (!func_100(uParam0, uParam2, 0)) {
			if (func_39(uParam1, uParam2) && !func_154(uParam2, func_255(uParam2))) {
				if (!func_139(uParam2, 1048576)) {
					if (bLocal_0) {
					}
					ai::clear_ped_tasks(func_271(uParam2));
					ai::open_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
					ai::task_follow_nav_mesh_to_coord(0, func_38(uParam1, func_293(uParam2), func_255(uParam2)), 1f, -1,
													  1048576000, 0, 1193033728);
					ai::task_turn_ped_to_face_coord(0, func_292(uParam1, func_293(uParam2)), 0);
					ai::close_sequence_task(uParam2->f_15[func_255(uParam2) /*34*/].f_21);
					ai::task_perform_sequence(func_271(uParam2), uParam2->f_15[func_255(uParam2) /*34*/].f_21);
					ai::clear_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
				}
				else {
					entity::set_entity_coords(func_271(uParam2), func_38(uParam1, func_293(uParam2), func_255(uParam2)),
											  1, 0, 0, 1);
				}
			}
			else if (func_186(uParam2) || func_139(uParam2, 67108864)) {
				if (!func_139(uParam2, 1048576)) {
					if (!func_26(uParam2, func_255(uParam2), 0)) {
						if (bLocal_0) {
						}
						ai::clear_ped_tasks(func_271(uParam2));
						ai::open_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::task_follow_nav_mesh_to_coord(0, func_44(uParam1, func_293(uParam2), func_255(uParam2)), 1f,
														  -1, 1048576000, 0, 1193033728);
						ai::task_turn_ped_to_face_coord(0, func_43(uParam1, func_293(uParam2)), 0);
						ai::close_sequence_task(uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::task_perform_sequence(func_271(uParam2), uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::clear_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
					}
				}
				else if (!func_139(uParam2, 4194304)) {
					entity::set_entity_coords(func_271(uParam2), func_44(uParam1, func_293(uParam2), func_255(uParam2)),
											  1, 0, 0, 1);
				}
			}
			else if (!func_139(uParam2, 1048576)) {
				if (!func_26(uParam2, func_255(uParam2), 0) && entity::does_entity_exist(func_35(uParam2))) {
					if (!entity::is_entity_dead(func_35(uParam2), 0)) {
						ai::clear_ped_tasks(func_271(uParam2));
						ai::open_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::task_enter_vehicle(0, func_35(uParam2), -1, func_33(uParam2), 1f, 1, 0);
						ai::close_sequence_task(uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::task_perform_sequence(func_271(uParam2), uParam2->f_15[func_255(uParam2) /*34*/].f_21);
						ai::clear_sequence_task(&uParam2->f_15[func_255(uParam2) /*34*/].f_21);
					}
				}
			}
			if (func_31(uParam2) == 8 || func_139(uParam2, 16384)) {
				func_24(uParam2, 10);
				func_45(uParam2, 16384);
			}
			else {
				func_24(uParam2, 9);
			}
		}
		break;
	}
}

// Position - 0x14A1
int func_31(var *uParam0) { return func_32(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x14B7
int func_32(var *uParam0) { return uParam0->f_23; }

// Position - 0x14C3
int func_33(var *uParam0) { return func_34(func_255(uParam0)); }

// Position - 0x14D5
int func_34(int iParam0) {
	if (iParam0 == 0 || iParam0 == 2) {
		return -1;
	}
	return 0;
}

// Position - 0x14F6
var func_35(var *uParam0) { return func_36(uParam0, func_37(uParam0, func_255(uParam0))); }

// Position - 0x1510
var func_36(var *uParam0, int iParam1) { return uParam0->f_152[iParam1]; }

// Position - 0x1520
int func_37(var *uParam0, int iParam1) { return uParam0->f_15[iParam1 /*34*/].f_31; }

// Position - 0x1532
Vector3 func_38(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0:
		switch (iParam2) {
		case 0: return -1369.208f, 166.1965f, 57.013f;

		case 1: return -1367.259f, 166.6778f, 57.013f;

		case 2: return -1370.803f, 167.6664f, 57.013f;

		case 3: return -1371.507f, 169.5609f, 57.013f;

		case 4: return -1370.846f, 164.1834f, 56.89f;

		case 5: return -1367.902f, 164.2965f, 56.869f;
		}
		break;

	case 1:
		switch (iParam2) {
		case 0: return -1101.049f, 156.1904f, 62.0401f;

		case 1: return -1100.905f, 159.2561f, 62.0415f;

		case 2: return -1102.783f, 161.6288f, 62.0412f;

		case 3: return -1105.964f, 161.2863f, 62.0406f;

		case 4: return -1104.451f, 163.5161f, 62.0095f;

		case 5: return -1099.934f, 161.6773f, 62.0185f;
		}
		break;

	case 2:
		switch (iParam2) {
		case 0: return -1317.028f, 128.0565f, 56.4377f;

		case 1: return -1315.436f, 129.9425f, 56.6243f;

		case 2: return -1313.452f, 131.9924f, 56.8265f;

		case 3: return -1317.249f, 133.3213f, 56.705f;

		case 4: return -1318.786f, 131.5965f, 56.4503f;

		case 5: return -1320.138f, 129.2562f, 56.324f;
		}
		break;

	case 3:
		switch (iParam2) {
		case 0: return -1218.894f, 110.6482f, 57.08f;

		case 1: return -1222.243f, 110.2088f, 57.08f;

		case 2: return -1220f, 111.91f, 58.0703f;

		case 3: return -1221.256f, 101.3278f, 57.08f;

		case 4: return -1223.297f, 103.1185f, 56.813f;

		case 5: return -1216.389f, 115.3967f, 57.1354f;
		}
		break;

	case 4:
		switch (iParam2) {
		case 0: return -1104.607f, 70.6124f, 53.212f;

		case 1: return -1101.698f, 73.7137f, 53.1993f;

		case 2: return -1103.9f, 72.917f, 54.3f;

		case 3: return -1100.425f, 75.0875f, 54.3712f;

		case 4: return -1108.588f, 72.7163f, 53.4783f;

		case 5: return -1107.175f, 68.8603f, 53.2257f;
		}
		break;

	case 5:
		switch (iParam2) {
		case 0: return -984.8632f, -108.5439f, 39.5642f;

		case 1: return -982.4098f, -106.4736f, 39.5732f;

		case 2: return -981.2261f, -103.0422f, 39.5779f;

		case 3: return -981.8594f, -100.6231f, 39.5813f;

		case 4: return -978.5359f, -100.5075f, 39.5193f;

		case 5: return -981.4874f, -109.4747f, 39.2195f;
		}
		break;

	case 6:
		switch (iParam2) {
		case 0: return -1113.865f, -100.3123f, 40.905f;

		case 1: return -1111.559f, -104.7822f, 40.8405f;

		case 2: return -1113.281f, -107.0443f, 40.8405f;

		case 3: return -1116.94f, -109.7583f, 40.8608f;

		case 4: return -1110.02f, -108.1524f, 40.7427f;

		case 5: return -1112.815f, -103.1259f, 40.8406f;
		}
		break;

	case 7:
		switch (iParam2) {
		case 0: return -1277.277f, 36.1405f, 48.9194f;

		case 1: return -1277.344f, 39.2424f, 49.1028f;

		case 2: return -1275.593f, 41.3619f, 49.0876f;

		case 3: return -1271.244f, 43.9149f, 48.9679f;

		case 4: return -1279.021f, 42.0418f, 49.3157f;

		case 5: return -1281.184f, 37.6356f, 49.3165f;
		}
		break;

	case 8:
		switch (iParam2) {
		case 0: return -1138.589f, -5.6756f, 47.9822f;

		case 1: return -1136.48f, -5.8462f, 47.9822f;

		case 2: return -1134.645f, -4.3631f, 47.9822f;

		case 3: return -1133.712f, -2.4897f, 47.9822f;

		case 4: return -1133.803f, -7.843f, 47.9822f;

		case 5: return -1137.603f, -9.0347f, 47.8107f;
		}
		break;
	}
	return 0f, 0f, 0f;
}

// Position - 0x1BA0
bool func_39(var *uParam0, var *uParam1) {
	if (func_293(uParam1) < 0 || func_293(uParam1) >= func_42(uParam0)) {
		return false;
	}
	if (func_40(uParam1) != 5) {
		return false;
	}
	return true;
}

// Position - 0x1BD9
int func_40(var *uParam0) { return func_41(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x1BEF
var func_41(var *uParam0) { return uParam0->f_24; }

// Position - 0x1BFB
int func_42(var *uParam0) { return uParam0->f_28; }

// Position - 0x1C07
Vector3 func_43(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0: return -1329.875f, 35.458f, 52.677f;

	case 1: return -1329.26f, 52.557f, 52.677f;

	case 2: return -1330.135f, 68.521f, 52.736f;

	case 3: return -1334.394f, 82.867f, 53.703f;

	case 4: return -1332.059f, 95.877f, 54.98f;

	case 5: return -1336.215f, 103.347f, 55.392f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x1CD5
Vector3 func_44(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0:
		switch (iParam2) {
		case 0: return -1121.482f, 210.4423f, 63.9292f;

		case 1: return -1111.883f, 211.2035f, 63.844f;

		case 2: return -1109.581f, 220.781f, 63.9314f;

		case 3: return -1117.733f, 231.4756f, 64.5959f;

		case 4: return -1124.819f, 232.4564f, 65.106f;

		case 5: return -1114.602f, 228.6924f, 64.1294f;

		case 6: return -1124.336f, 220.1641f, 64.0189f;
		}
		break;

	case 1:
		switch (iParam2) {
		case 0: return -1324.647f, 150.2405f, 56.9512f;

		case 1: return -1332.147f, 152.7218f, 56.9449f;

		case 2: return -1340.339f, 165.985f, 57.0015f;

		case 3: return -1330.341f, 172.5728f, 57.0822f;

		case 4: return -1325.275f, 173.1006f, 57.1633f;

		case 5: return -1337.177f, 158.5159f, 56.9107f;

		case 6: return -1320.53f, 169.4781f, 56.8531f;
		}
		break;

	case 2:
		switch (iParam2) {
		case 0: return -1230.481f, 103.0481f, 55.7491f;

		case 1: return -1234.842f, 95.7965f, 55.6671f;

		case 2: return -1243.458f, 95.5196f, 55.5717f;

		case 3: return -1245.146f, 112.5895f, 55.9974f;

		case 4: return -1239.073f, 119.9953f, 56.4275f;

		case 5: return -1232.428f, 116.2665f, 56.6504f;

		case 6: return -1235.999f, 119.75f, 56.425f;
		}
		break;

	case 3:
		switch (iParam2) {
		case 0: return -1101.042f, 27.2703f, 50.1697f;

		case 1: return -1094.131f, 23.785f, 50.087f;

		case 2: return -1087.636f, 20.9966f, 50.0321f;

		case 3: return -1080.524f, 13.8964f, 49.734f;

		case 4: return -1086.105f, 4.0804f, 49.7967f;

		case 5: return -1097.654f, -1.5694f, 50.0125f;

		case 6: return -1108.614f, -4.9012f, 49.6852f;
		}
		break;

	case 4:
		switch (iParam2) {
		case 0: return -949.3773f, -93.7449f, 39.525f;

		case 1: return -965.4772f, -92.9853f, 39.3605f;

		case 2: return -965.3192f, -101.431f, 39.4042f;

		case 3: return -952.4808f, -99.1808f, 39.5487f;

		case 4: return -958.345f, -103.7673f, 39.334f;

		case 5: return -949.268f, -87.9874f, 39.3694f;

		case 6: return -951.558f, -85.9542f, 39.2469f;
		}
		break;

	case 5:
		switch (iParam2) {
		case 0: return -1098.276f, -107.6579f, 40.5369f;

		case 1: return -1106.573f, -106.9375f, 40.696f;

		case 2: return -1111.654f, -121.3032f, 40.7039f;

		case 3: return -1102.013f, -127.7622f, 40.69f;

		case 4: return -1092.945f, -115.8245f, 40.5376f;

		case 5: return -1094.257f, -122.7798f, 40.552f;

		case 6: return -1092.991f, -118.4603f, 40.5422f;
		}
		break;

	case 6:
		switch (iParam2) {
		case 0: return -1294.887f, 10.1593f, 50.3758f;

		case 1: return -1288.871f, 14.8418f, 49.8751f;

		case 2: return -1276.27f, 11.8301f, 48.5562f;

		case 3: return -1283.162f, -6.8256f, 48.6238f;

		case 4: return -1275.606f, -2.029f, 48.0408f;

		case 5: return -1273.712f, 5.2094f, 48.184f;

		case 6: return -1293.384f, 0.3131f, 49.4842f;
		}
		break;

	case 7:
		switch (iParam2) {
		case 0: return -1041.685f, -75.4766f, 43.0439f;

		case 1: return -1030.31f, -76.6724f, 43.2806f;

		case 2: return -1029.791f, -88.4011f, 43.1511f;

		case 3: return -1041.575f, -92.4546f, 42.8253f;

		case 4: return -1050.466f, -93.7612f, 42.5099f;

		case 5: return -1050.863f, -84.3568f, 42.5056f;

		case 6: return -1048.343f, -82.4877f, 42.5625f;
		}
		break;

	case 8:
		switch (iParam2) {
		case 0: return -1284.551f, 76.0288f, 53.9062f;

		case 1: return -1282.676f, 86.4323f, 53.9098f;

		case 2: return -1299.27f, 80.8423f, 53.911f;

		case 3: return -1299.105f, 87.1486f, 53.9145f;

		case 4: return -1290.099f, 74.7491f, 53.9426f;

		case 5: return -1292.312f, 90.6955f, 53.9123f;

		case 6: return -1291.197f, 89.2305f, 53.9061f;
		}
		break;
	}
	return 0f, 0f, 0f;
}

// Position - 0x2436
void func_45(var *uParam0, int iParam1) { func_46(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x244E
void func_46(var *uParam0, int iParam1) { uParam0->f_22 -= (uParam0->f_22 & iParam1); }

// Position - 0x2466
void func_47(var *uParam0, int iParam1) { func_48(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x247E
void func_48(var *uParam0, int iParam1) { uParam0->f_22 |= iParam1; }

// Position - 0x2491
int func_49(var *uParam0) { return func_50(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x24A7
int func_50(var *uParam0) { return uParam0->f_18; }

// Position - 0x24B3
void func_51(var *uParam0, int iParam1) {
	func_8(&uParam0->f_15[uParam0->f_157 /*34*/], func_50(&uParam0->f_15[uParam0->f_157 /*34*/]) + iParam1);
}

// Position - 0x24DA
void func_52(var *uParam0, var *uParam1) {
	if (!bLocal_238) {
		if (func_60(uParam1) != 4) {
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		}
		func_5(uParam1, entity::get_entity_coords(func_269(uParam1), 1));
		func_59(uParam1, system::vdist(func_239(uParam1), func_43(uParam0, func_293(uParam1))));
	}
	else {
		entity::set_entity_coords(func_269(uParam1), func_239(uParam1) + Vector(0.05f, 0f, 0f), 1, 0, 0, 1);
		func_57(uParam1);
		func_55(uParam1);
	}
	entity::set_entity_max_speed(func_269(uParam1), 150f);
	func_196(func_269(uParam1), 1);
	func_45(uParam1, 2);
	func_53(uParam1, 0f);
}

// Position - 0x2581
void func_53(var *uParam0, float fParam1) { func_54(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x2599
void func_54(var *uParam0, var uParam1) { uParam0->f_16 = uParam1; }

// Position - 0x25A7
void func_55(var *uParam0) { func_56(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x25BD
void func_56(var *uParam0) { uParam0->f_25 = {uParam0->f_28}; }

// Position - 0x25D1
void func_57(var *uParam0) { func_58(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x25E7
void func_58(var *uParam0) { uParam0->f_23 = uParam0->f_24; }

// Position - 0x25F7
void func_59(var *uParam0, float fParam1) { func_9(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x260F
int func_60(var *uParam0) { return func_28(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2625
void func_61(var *uParam0) {
	func_57(uParam0);
	func_55(uParam0);
	func_45(uParam0, 2);
	func_47(uParam0, 64);
	func_53(uParam0, 0f);
	func_47(uParam0, 536870912);
}

// Position - 0x265A
int func_62(vector3 vParam0) {
	vector3 vVar0;
	float fVar3;

	vVar0 = {func_64(Vector(51.66f, 61.69f, -1405.69f) - Vector(51.76f, 61.61f, -1403.44f))};
	fVar3 = func_63(vVar0, -1405.69f, 61.69f, 51.66f);
	if (func_63(vParam0, vVar0) > fVar3) {
		return 1;
	}
	vVar0 = {func_64(Vector(0f, -85.86f, -1167.9f) - Vector(0f, -89.1f, -1162.01f))};
	fVar3 = func_63(vVar0, Vector(0f, -89.1f, -1162.01f) - FtoV(9.92f) * vVar0);
	if (func_63(vParam0, vVar0) > fVar3) {
		vVar0 = {func_64(Vector(0f, -89.76f, -1193.7f) - Vector(0f, -87.41f, -1192.45f))};
		fVar3 = func_63(vVar0, Vector(39.97f, -89.76f, -1193.7f) - FtoV(2.778f) * vVar0);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
		if (object::is_point_in_angled_area(vParam0, -1227.909f, -68.76888f, 43.06714f, -1260.599f, -50.60131f,
											44.63058f, 2.74f, 0, 0)) {
			return 1;
		}
	}
	else {
		vVar0 = {func_64(Vector(0f, -89.76f, -1193.7f) - Vector(0f, -87.41f, -1192.45f))};
		fVar3 = func_63(vVar0, Vector(39.97f, -89.76f, -1193.7f) - FtoV(1.03f) * vVar0);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	vVar0 = {func_64(Vector(0f, -113.24f, -970.31f) - Vector(0f, -115.19f, -973.91f))};
	fVar3 = func_63(vVar0, -970.31f, -113.24f, 38.28f);
	if (func_63(vParam0, vVar0) > fVar3) {
		vVar0 = {func_64(Vector(0f, -106.46f, -948.52f) - Vector(0f, -102.2f, -951.06f))};
		fVar3 = func_63(vVar0, -948.52f, -106.46f, 42.39f);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	else {
		vVar0 = {func_64(Vector(0f, -127.38f, -1028.62f) - Vector(0f, -129.55f, -1034.37f))};
		fVar3 = func_63(vVar0, -1028.62f, -127.38f, 39.51f);
		if (func_63(vParam0, vVar0) > fVar3) {
			vVar0 = {func_64(Vector(0f, -125.95f, -994.29f) - Vector(0f, -94.44f, -1001.81f))};
			fVar3 = func_63(vVar0, -994.29f, -125.95f, 40.12f);
			if (func_63(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
		else {
			vVar0 = {func_64(Vector(0f, -140.83f, -1037.99f) - Vector(0f, -131.81f, -1043.54f))};
			fVar3 = func_63(vVar0, -1037.99f, -140.83f, 42.99f);
			if (func_63(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
	}
	vVar0 = {func_64(Vector(0f, 96.74f, -1047.59f) - Vector(0f, 87.45f, -1041.82f))};
	fVar3 = func_63(vVar0, -1047.59f, 96.74f, 52.25f);
	if (func_63(vParam0, vVar0) > fVar3) {
		vVar0 = {func_64(Vector(0f, 180.44f, -1094.08f) - Vector(0f, 167.17f, -1086.17f))};
		fVar3 = func_63(vVar0, -1094.08f, 180.44f, 61.49f);
		if (func_63(vParam0, vVar0) > fVar3) {
			vVar0 = {func_64(Vector(0f, 196.78f, -1092f) - Vector(0f, 179.38f, -1163.07f))};
			fVar3 = func_63(vVar0, Vector(60.09f, 196.78f, -1092f) - FtoV(3.75f) * vVar0);
			if (func_63(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
		else {
			vVar0 = {func_64(Vector(0f, 145.22f, -1069.28f) - Vector(0f, 98.02f, -1152.37f))};
			fVar3 = func_63(vVar0, -1069.28f, 145.22f, 61.6f);
			if (func_63(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
	}
	else {
		vVar0 = {func_64(Vector(0f, -19.35f, -967.03f) - Vector(0f, -63.01f, -1035.28f))};
		fVar3 = func_63(vVar0, -967.03f, -19.35f, 48.28f);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	vVar0 = {func_64(Vector(0f, 186.79f, -1274.15f) - Vector(0f, 185.87f, -1255.38f))};
	fVar3 = func_63(vVar0, -1274.15f, 186.79f, 61.97f);
	if (func_63(vParam0, vVar0) > fVar3) {
		vVar0 = {func_64(Vector(0f, 192.648f, -1326.063f) - Vector(0f, 183.78f, -1325.44f))};
		fVar3 = func_63(vVar0, -1326.063f, 192.648f, 61.76f);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	else {
		vVar0 = {func_64(Vector(0f, 226.63f, -1159.35f) - Vector(0f, 203.93f, -1152.92f))};
		fVar3 = func_63(vVar0, -1159.35f, 226.63f, 70f);
		if (func_63(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x2BF3
float func_63(vector3 vParam0, vector3 vParam3) {
	return vParam0.x * vParam3.x + vParam0.y * vParam3.y + vParam0.z * vParam3.z;
}

// Position - 0x2C14
Vector3 func_64(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x2C53
int func_65(var *uParam0) {
	if (func_31(uParam0) != -1) {
		return 0;
	}
	return 1;
}

// Position - 0x2C6A
int func_66(var *uParam0) {
	if (func_31(uParam0) != 7) {
		return 0;
	}
	return 1;
}

// Position - 0x2C81
void func_67(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	vector3 vVar1;
	float fVar4;
	vector3 vVar5;
	vector3 vVar8;
	int iVar11;

	iVar0 = func_269(uParam2);
	vVar1 = {entity::get_entity_velocity(iVar0)};
	fVar4 = system::vmag(vVar1);
	vVar5 = {func_43(uParam1, func_293(uParam2))};
	vVar8 = {entity::get_entity_coords(iVar0, 1)};
	rope::set_damping(iVar0, 0, 2.96f);
	rope::set_damping(iVar0, 3, 2.96f);
	iVar11 = func_80(uParam1, func_293(uParam2));
	if (func_78(uParam0, uParam1, uParam2)) {
		return;
	}
	uParam2->f_1.f_5 = 0f;
	uParam2->f_1.f_6 = 0f;
	if (entity::has_entity_collided_with_anything(iVar0)) {
		func_23(uParam2, entity::get_entity_coords(iVar0, 1), func_77(entity::get_last_material_hit_by_entity(iVar0)));
		func_47(uParam2, 2);
		func_272(uParam0, 268435456);
		if (entity::does_entity_exist(iVar11)) {
			if (entity::is_entity_touching_entity(iVar0, iVar11) && !func_139(uParam2, 268435456)) {
				audio::play_sound_from_entity(-1, "GOLF_BALL_IMPACT_FLAG_MASTER", func_269(uParam2), 0, 0, 0);
				entity::set_entity_collision(iVar11, 0, 0);
				func_47(uParam2, 268435456);
			}
		}
	}
	else if (func_139(uParam2, 2) && func_186(uParam2)) {
		if (!func_138(uParam0, 268435456) && system::vdist2(vVar8, vVar5) < 0.3f * 0.3f) {
			audio::play_sound_from_entity(-1, "GOLF_BALL_CUP_MISS_MASTER", func_269(uParam2), 0, 0, 0);
			func_107(uParam0, 268435456);
		}
	}
	if (fVar4 < 0.25f || fVar4 < 6f && func_76(uParam1, uParam2) || func_139(uParam2, 256) || func_75()) {
		if (!func_74(&uParam2->f_159)) {
			func_23(uParam2, entity::get_entity_coords(iVar0, 1),
					func_77(entity::get_last_material_hit_by_entity(iVar0)));
			func_22(uParam2, entity::get_collision_normal_of_last_hit_for_entity(iVar0));
			if (func_76(uParam1, uParam2)) {
			}
			func_187(&uParam2->f_159);
		}
		if (!func_76(uParam1, uParam2) &&
			(func_139(uParam2, 256) || system::vdist2(vVar8, vVar5) < 0.1601f * 0.1601f || func_75() ||
			 func_71(uParam1, uParam2)) &&
			0) {
			func_70(iVar0, vVar8, vVar5);
			func_47(uParam2, 256);
		}
		else if (func_156(&uParam2->f_159, 0.5f)) {
			if (bLocal_0) {
			}
			entity::set_entity_records_collisions(iVar0, 0);
			func_47(uParam2, 2048);
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 0f;
			if (func_76(uParam1, uParam2)) {
				func_47(uParam2, 8192);
				func_24(uParam2, 8);
				func_196(iVar0, 0);
			}
			else {
				func_196(iVar0, 1);
				func_24(uParam2, 6);
			}
			func_47(uParam2, 4);
		}
	}
	else if (func_74(&uParam2->f_159)) {
		func_152(&uParam2->f_159);
	}
	if (func_156(&uParam2->f_162, 30f) && !func_75()) {
		entity::set_entity_coords(iVar0, func_68(uParam2), 1, 0, 0, 1);
		entity::set_entity_records_collisions(iVar0, 0);
		func_196(iVar0, 1);
		func_24(uParam2, 6);
		func_47(uParam2, 68);
	}
}

// Position - 0x2F97
Vector3 func_68(var *uParam0) { return func_69(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2FAD
Vector3 func_69(var *uParam0) { return uParam0->f_10; }

// Position - 0x2FBB
void func_70(int iParam0, struct<2> Param1, Vector3 vParam3, struct<2> Param4, var uParam6) {
	vector3 vVar0;

	vVar0 = {func_64(Vector(0f, Param4.f_1, Param4) - Vector(0f, Param1.f_1, Param1)) * FtoV(9f)};
	entity::apply_force_to_entity(iParam0, 0, vVar0, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
}

// Position - 0x2FF5
int func_71(var *uParam0, var *uParam1) {
	vector3 vVar0;
	float fVar3;

	if (func_60(uParam1) != 4) {
		return 0;
	}
	if (!func_157(uParam0, uParam1)) {
		return 0;
	}
	vVar0 = {func_239(uParam1)};
	fVar3 = 0.7f;
	switch (func_72(uParam1)) {
	case 0: fVar3 = 1f; break;

	case 1: fVar3 = 1.5f; break;

	case 2: fVar3 = 2.5f; break;
	}
	if (system::vdist(vVar0, func_43(uParam0, func_293(uParam1))) > fVar3) {
		return 0;
	}
	return 1;
}

// Position - 0x3082
int func_72(var *uParam0) { return func_73(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x3098
var func_73(var *uParam0) { return uParam0->f_33; }

// Position - 0x30A4
bool func_74(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x30B4
int func_75() { return 0; }

// Position - 0x30BD
bool func_76(var *uParam0, var *uParam1) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::does_entity_exist(func_269(uParam1))) {
		return false;
	}
	vVar0 = {entity::get_entity_coords(func_269(uParam1), 0)};
	vVar3 = {func_43(uParam0, func_293(uParam1))};
	if (system::vdist2(vVar0, vVar3) > 0.25f * 0.25f) {
		return false;
	}
	if (func_31(uParam1) == 8) {
		if (vVar0.z < vVar3.z + 0.11f) {
			return true;
		}
	}
	if (system::vdist2(vVar0, vVar3) < 0.1f * 0.1f) {
		func_23(uParam1, 0f, 0f, 0f, 8);
		return true;
	}
	return false;
}

// Position - 0x3161
int func_77(int iParam0) {
	switch (iParam0) {
	case -461750719:
	case 930824497: return 4;

	case 581794674:
	case -2041329971:
	case -309121453:
	case 555004797:
	case -1885547121:
	case -1915425863: return 9;

	case -2073312001:
	case 627123000: return 8;

	case 1187676648:
	case 282940568:
	case 951832588:
	case -840216541:
	case 510490462: return 1;

	case 1333033863: return 2;

	case -1286696947: return 3;

	case -1595148316: return 0;

	case 435688960: return 7;
	}
	return -1;
}

// Position - 0x321A
bool func_78(var uParam0, var *uParam1, var *uParam2) {
	int iVar0;

	iVar0 = func_269(uParam2);
	if (entity::is_entity_in_water(iVar0)) {
		entity::set_entity_records_collisions(iVar0, 0);
		func_196(iVar0, 1);
		func_23(uParam2, 0f, 0f, 0f, 7);
		func_79(uParam2);
		func_24(uParam2, 6);
		func_47(uParam2, 4);
		func_47(uParam2, 2);
		return true;
	}
	return false;
}

// Position - 0x326B
void func_79(var *uParam0) {
	audio::play_sound_from_entity(-1, "GOLF_BALL_IN_WATER_MASTER", func_269(uParam0), 0, 0, 0);
	return;
	graphics::start_particle_fx_non_looped_at_coord(
		"scr_golf_landing_water", entity::get_entity_coords(func_269(uParam0), 1), 0f, 0f,
		func_238(entity::get_entity_coords(func_269(uParam0), 1), func_239(uParam0)), 1065353216, 0, 0, 0);
}

// Position - 0x32B9
int func_80(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0;
	}
	return (*uParam0)[iParam1 /*3*/].f_2;
}

// Position - 0x32E1
void func_81(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_2 = 0f;
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0f;
	uParam0->f_5 = 0f;
	uParam0->f_6 = 0f;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 0;
	uParam0->f_13 = 0;
}

// Position - 0x3329
void func_82(var uParam0) {}

// Position - 0x3331
void func_83(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float fVar5;
	var uVar6;
	vector3 vVar7;
	float fVar10;
	vector3 vVar11;
	vector3 vVar14;
	vector3 vVar17;
	float fVar20;
	float fVar21;
	float fVar22;
	float fVar23;
	vector3 vVar24;
	vector3 vVar27;
	vector3 vVar30;
	vector3 vVar33;
	vector3 vVar36;
	vector3 vVar39;

	iVar0 = func_269(uParam2);
	iVar1 = func_80(uParam1, func_293(uParam2));
	vVar2 = {entity::get_entity_velocity(iVar0)};
	fVar5 = system::vmag(vVar2);
	vVar7 = {uParam2->f_1.f_5, uParam2->f_1.f_6, 0f};
	fVar10 = func_98(uParam2);
	vVar11 = {func_64(system::cos(fVar10), system::sin(fVar10), 0f)};
	vVar14 = {func_97(vVar11, 0)};
	vVar17 = {vVar11 * FtoV(-vVar7.x) * FtoV(0.05f) + vVar14 * FtoV(vVar7.y) * FtoV(0.2f)};
	unk_0x0A25F80D5BADC013(entity::get_entity_coords(iVar0, 1), entity::get_entity_coords(iVar0, 1) + func_64(vVar17),
						   0, 0, 0, 255);
	if (func_78(uParam0, uParam1, uParam2)) {
		return;
	}
	if (entity::has_entity_collided_with_anything(iVar0)) {
		if (entity::does_entity_exist(iVar1)) {
			if (entity::is_entity_touching_entity(iVar0, iVar1)) {
				if (!func_139(uParam2, 268435456)) {
					audio::play_sound_from_entity(-1, "GOLF_BALL_IMPACT_FLAG_MASTER", func_269(uParam2), 0, 0, 0);
					func_47(uParam2, 268435456);
				}
				if (!entity::is_entity_in_air(iVar0)) {
					entity::set_entity_collision(iVar1, 0, 0);
				}
			}
		}
		fVar20 = 1f;
		fVar21 = 0f;
		fVar22 = 0f;
		fVar23 = 0f;
		switch (func_77(entity::get_last_material_hit_by_entity(iVar0))) {
		case 1:
			fVar20 = 0.89f;
			fVar21 = 0.75f;
			fVar23 = 0.2f;
			fVar22 = 0.3f;
			break;

		case 4:
		case 9:
			fVar21 = 0.25f;
			fVar20 = 0.85f;
			fVar23 = 0.5f;
			fVar22 = 0.15f;
			break;

		case 0:
			fVar20 = 0.35f;
			fVar21 = 0f;
			fVar23 = 0.2f;
			fVar22 = 0f;
			break;

		case 7: fVar20 = 0.5f; break;

		case 2:
			fVar20 = 0.85f;
			fVar21 = 0.5f;
			fVar23 = 0.55f;
			fVar22 = 0.3f;
			break;

		case 3:
			fVar20 = 0.85f;
			fVar21 = 0.3f;
			fVar23 = 0.55f;
			fVar22 = 1.2f;
			break;

		case -1: break;
		}
		if (!bLocal_241) {
			vVar17 = {vVar11 * FtoV(-vVar7.x) * FtoV(0.2f) + vVar14 * FtoV(vVar7.y) * FtoV(0.2f)};
			vVar17 = {vVar17 * FtoV(fVar22)};
			entity::apply_force_to_entity(iVar0, 0, vVar17, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
		func_96(&uParam2->f_1);
		if (!func_138(uParam0, 64)) {
			if (fVar21 != 0f && system::vmag2(vVar2) > 9.5f) {
				gameplay::_0x8BDC7BFC57A81E76(entity::get_entity_coords(iVar0, 1) + Vector(1f, 0f, 0f), &uVar6,
											  &vVar27);
				vVar30 = {FtoV(func_63(vLocal_248, vVar27)) * vVar27};
				vVar24 = {FtoV(-(1f + fVar21)) * vVar30 + vLocal_248};
				vVar33 = {vLocal_248 - vVar30};
				vVar24 = {vVar24 - vVar33 * FtoV(fVar23)};
				entity::set_entity_velocity(iVar0, vVar24);
			}
			func_107(uParam0, 64);
			func_94(uParam2, 0, func_95(iVar0));
		}
		else {
			vVar36 = {entity::get_entity_velocity(iVar0)};
			if (fVar20 != 1f) {
				vVar36 = {vVar36 * FtoV(fVar20)};
				entity::set_entity_velocity(iVar0, vVar36);
			}
		}
	}
	else {
		if (func_138(uParam0, 64)) {
			func_272(uParam0, 64);
		}
		if (!bLocal_240 && !func_93(uParam2)) {
			vVar39 = {func_64(uParam0->f_16, uParam0->f_16.f_1, 0f) * FtoV(uParam0->f_20) * FtoV(0.5f)};
			entity::apply_force_to_entity(iVar0, 0, vVar39, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
		if (!bLocal_241) {
			entity::apply_force_to_entity(iVar0, 0, vVar17, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
	}
	if (func_92(uParam2)) {
		controls::set_pad_shake(0, 50,
								func_90(0, func_91(256, gameplay::absi(system::round(uParam2->f_1.f_6)) +
															gameplay::absi(system::round(uParam2->f_1.f_5)) + 30)));
	}
	if (!func_139(uParam2, 2)) {
		if (!func_74(&uParam2->f_159) && !func_139(uParam2, 2)) {
			func_187(&uParam2->f_159);
		}
		if (entity::has_entity_collided_with_anything(iVar0) && func_86(&uParam2->f_159, 0.2f)) {
			if (func_60(uParam2) != 4) {
				ui::clear_help(1);
			}
			if (bLocal_0) {
			}
			func_53(uParam2, system::vdist(entity::get_entity_coords(iVar0, 1), func_239(uParam2)));
			func_47(uParam2, 2);
			func_152(&uParam2->f_159);
			func_84(uParam2);
		}
	}
	else if (func_75() && !func_76(uParam1, uParam2)) {
		func_70(iVar0, entity::get_entity_coords(iVar0, 1), func_43(uParam1, func_293(uParam2)));
	}
	else if (fVar5 < 0.5f && gameplay::absf(uParam2->f_1.f_5) + gameplay::absf(uParam2->f_1.f_6) < 0.05f ||
			 fVar5 < 6f && func_76(uParam1, uParam2)) {
		if (!func_74(&uParam2->f_159)) {
			func_23(uParam2, entity::get_entity_coords(iVar0, 1),
					func_77(entity::get_last_material_hit_by_entity(iVar0)));
			func_22(uParam2, entity::get_collision_normal_of_last_hit_for_entity(iVar0));
			func_187(&uParam2->f_159);
			if (func_76(uParam1, uParam2)) {
			}
		}
		if (func_156(&uParam2->f_159, 1f)) {
			entity::set_entity_records_collisions(iVar0, 0);
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 0f;
			if (func_76(uParam1, uParam2)) {
				func_47(uParam2, 8192);
				func_24(uParam2, 8);
			}
			else {
				func_24(uParam2, 6);
				if (func_92(uParam2)) {
					controls::set_pad_shake(0, 10, 10);
				}
			}
			func_47(uParam2, 4);
			func_196(iVar0, 1);
			func_47(uParam2, 2048);
			if (func_39(uParam1, uParam2)) {
				func_47(uParam2, 8);
			}
		}
	}
	else if (func_74(&uParam2->f_159)) {
		func_152(&uParam2->f_159);
	}
	if (func_156(&uParam2->f_162, 14f) && !func_75()) {
		entity::set_entity_records_collisions(iVar0, 0);
		func_196(iVar0, 1);
		func_24(uParam2, 6);
		func_47(uParam2, 68);
		if (func_139(uParam2, 4194304)) {
			func_23(uParam2, 0f, 0f, 0f, 3);
		}
		else {
			func_23(uParam2, 0f, 0f, 0f, 4);
		}
	}
	if (entity::does_entity_exist(iVar0)) {
		vLocal_248 = {entity::get_entity_velocity(iVar0)};
	}
	func_272(uParam0, 32);
}

// Position - 0x3956
void func_84(var *uParam0) {
	char *sVar0;

	return;
	if (func_186(uParam0)) {
		return;
	}
	sVar0 = "";
	switch (entity::get_last_material_hit_by_entity(func_269(uParam0))) {
	case -461750719:
	case 930824497: sVar0 = "scr_golf_landing_thick_grass"; break;

	case -309121453:
	case 555004797:
	case 581794674:
	case -2041329971:
	case -1915425863: sVar0 = "scr_golf_hit_branches"; break;

	case -1595148316: sVar0 = "scr_golf_landing_bunker"; break;

	case 1333033863:
	case -1286696947:
	case 951832588:
	case 1187676648:
	case 282940568:
	case -2073312001: break;

	default: break;
	}
	if (!func_85(sVar0)) {
		graphics::start_particle_fx_non_looped_at_coord(
			sVar0, entity::get_entity_coords(func_269(uParam0), 1), 0f, 0f,
			func_238(entity::get_entity_coords(func_269(uParam0), 1), func_239(uParam0)), 1065353216, 0, 0, 0);
	}
}

// Position - 0x3A2E
int func_85(char *sParam0) {
	if (gameplay::is_string_null(sParam0)) {
		return 1;
	}
	if (ui::get_length_of_literal_string(sParam0) <= 0) {
		return 1;
	}
	return 0;
}

// Position - 0x3A52
bool func_86(var *uParam0, float fParam1) {
	if (func_74(uParam0)) {
		if (func_87(uParam0) > fParam1) {
			return true;
		}
	}
	return false;
}

// Position - 0x3A74
float func_87(var *uParam0) {
	if (func_74(uParam0)) {
		if (func_89(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_88(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x3AB3
float func_88(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x3B0B
bool func_89(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x3B1B
int func_90(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam0;
	}
	return iParam1;
}

// Position - 0x3B31
int func_91(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam1;
	}
	return iParam0;
}

// Position - 0x3B47
bool func_92(var *uParam0) { return func_60(uParam0) == 1 || func_60(uParam0) == 2; }

// Position - 0x3B65
bool func_93(var *uParam0) { return (func_72(uParam0) == 2 || func_139(uParam0, 65536)) && func_60(uParam0) == 4; }

// Position - 0x3B92
void func_94(var *uParam0, int iParam1, bool bParam2) {
	char *sVar0;

	sVar0 = "";
	switch (entity::get_last_material_hit_by_entity(func_269(uParam0))) {
	case 1333033863:
	case -1286696947:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_FAIRWAY_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_FAIRWAY_MASTER";
		}
		break;

	case -461750719:
	case 930824497:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_GRASS_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_GRASS_MASTER";
		}
		break;

	case -1595148316:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_SAND_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_SAND_MASTER";
		}
		break;

	case 951832588:
	case 1187676648:
	case 282940568:
	case -840216541:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_CONCRETE_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_CONCRETE_MASTER";
		}
		break;

	case -309121453:
	case 555004797:
	case 581794674:
	case -1915425863:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_TREE_SOFT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_TREE_MASTER";
		}
		break;

	default:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_TREE_SOFT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_TREE_MASTER";
		}
		break;
	}
	if (!func_85(sVar0)) {
		if (iParam1) {
			audio::play_sound_from_coord(-1, sVar0, entity::get_entity_coords(func_269(uParam0), 1), 0, 0, 0, 0);
		}
		else {
			audio::play_sound_from_entity(-1, sVar0, func_269(uParam0), 0, 0, 0);
		}
	}
}

// Position - 0x3CBC
bool func_95(int iParam0) { return entity::get_entity_speed(iParam0) < 6f; }

// Position - 0x3CCC
void func_96(var *uParam0) {
	vector3 vVar0;
	vector3 vVar3;

	if (uParam0->f_5 == 0f && uParam0->f_6 == 0f) {
		return;
	}
	vVar0 = {func_64(uParam0->f_5, uParam0->f_6, 0f) * FtoV(25f) * FtoV(gameplay::get_frame_time())};
	vVar3 = {-vVar0};
	if (gameplay::absf(uParam0->f_5) < gameplay::absf(vVar0.x)) {
		uParam0->f_5 = 0f;
	}
	else {
		uParam0->f_5 += vVar3.x;
	}
	if (gameplay::absf(uParam0->f_6) < gameplay::absf(vVar0.y)) {
		uParam0->f_6 = 0f;
	}
	else {
		uParam0->f_6 += vVar3.y;
	}
}

// Position - 0x3D60
Vector3 func_97(vector3 vParam0, int iParam3) {
	vector3 vVar0;

	switch (iParam3) {
	case 0:
		vVar0.x = -vParam0.y;
		vVar0.y = vParam0.x;
		break;

	case 1:
		vVar0.x = -vParam0.x;
		vVar0.y = -vParam0.y;
		break;

	case 2:
		vVar0.x = vParam0.y;
		vVar0.y = -vParam0.x;
		break;
	}
	vVar0.z = vParam0.z;
	return vVar0;
}

// Position - 0x3DBE
float func_98(var *uParam0) { return func_99(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x3DD4
float func_99(var *uParam0) { return uParam0->f_14; }

// Position - 0x3DE0
int func_100(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	char cVar2[32];

	iVar0 = func_271(uParam1);
	sVar1 = func_103(uParam0, &uParam1->f_15[func_255(uParam1) /*34*/], 1, 1);
	StringCopy(&cVar2, sVar1, 32);
	StringConCat(&cVar2, "react_", 32);
	StringConCat(&cVar2, "nuetral_01", 32);
	if (entity::is_entity_playing_anim(iVar0, func_101(0), &cVar2, 3)) {
		if (entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar2) > 0.95f) {
			return 0;
		}
	}
	if (iParam2) {
		if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar2, 3) &&
			(entity::is_entity_playing_anim(iVar0, func_101(0), "iron_swing_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_101(0), "putt_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_101(0), "wedge_swing_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_101(0), "wood_swing_action", 3))) {
			ai::task_play_anim(iVar0, func_101(0), &cVar2, 8f, -2f, -1, 0, 0, 0, 0, 0);
		}
		return 1;
	}
	return 0;
}

// Position - 0x3ED7
char *func_101(int iParam0) {
	return func_303();
	if (!iParam0) {
		return func_303();
	}
	return func_102();
}

// Position - 0x3EFA
char *func_102() { return "MINI@GOLF"; }

// Position - 0x3F06
char *func_103(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;

	iVar0 = func_105(uParam1);
	iVar1 = func_104(uParam0, iVar0);
	if (iVar1 <= 5 && !iParam2) {
		return "Wood_";
	}
	else if (iVar1 > 5 && iVar1 <= 13 && !iParam2) {
		return "Iron_";
	}
	else if (iVar1 > 13 && iVar1 <= 18 && iParam3) {
		return "Wedge_";
	}
	else if (iVar1 == 19) {
		return "Putt_";
	}
	if (iParam2) {
		return "Swing_";
	}
	return "";
}

// Position - 0x3F9C
int func_104(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 1;
	}
	return (*uParam0)[iParam1];
}

// Position - 0x3FC2
int func_105(var *uParam0) { return uParam0->f_17; }

// Position - 0x3FCE
bool func_106(int iParam0, float fParam1) {
	char cVar0[32];
	char cVar8[32];
	char cVar16[32];
	char cVar24[32];

	if (!ped::is_ped_injured(iParam0)) {
		StringCopy(&cVar0, "Wood_swing_action", 32);
		StringCopy(&cVar8, "Iron_swing_action", 32);
		StringCopy(&cVar16, "Wedge_swing_action", 32);
		StringCopy(&cVar24, "Putt_action", 32);
		if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar0, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar0) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar8, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar8) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar16, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar16) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar24, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar24) >= fParam1) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x40AB
void func_107(var *uParam0, int iParam1) { uParam0->f_22 |= iParam1; }

// Position - 0x40BE
bool func_108(var *uParam0, var *uParam1, var *uParam2) {
	bool bVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18;
	float fVar21;
	float fVar22;
	float fVar23;
	vector3 vVar24;
	float fVar27;
	float fVar28;

	func_196(func_269(uParam2), 0);
	entity::set_entity_records_collisions(func_269(uParam2), 1);
	object::set_object_physics_params(func_269(uParam2), -1f, -1f, 0f, 0f, 0.01f, -1f, -1f, -1f, -1f, -1f, -1082130432);
	bVar0 = func_60(uParam2) == 4;
	fVar1 = func_124(&uParam2->f_15[func_255(uParam2) /*34*/], uParam0, &uParam2->f_1, bVar0, !bLocal_239, 0);
	fVar2 = 1f;
	switch (func_31(uParam2)) {
	case 2: fVar2 = 0.95f; break;

	case 4:
	case 1: fVar2 = func_123(0.9f, 0.075f); break;

	case 0:
	case 7:
	case -1:
		fVar2 = func_123(0.85f, 0.15f);
		if (fVar2 > 0.85f) {
			fVar2 = 0.85f;
		}
		break;
	}
	fVar1 *= fVar2;
	if (func_60(uParam2) == 4 && func_104(uParam0, func_122(uParam2)) == 17) {
		fVar1 *= 0.85f;
	}
	fVar3 = func_121(uParam0, func_122(uParam2)) / 90f;
	fVar3 += 0.05f;
	fVar4 = func_98(uParam2);
	fVar5 = func_120(uParam0, func_122(uParam2));
	if (func_118(uParam2) == 2) {
		fVar3 = func_121(uParam0, func_122(uParam2)) / 150f;
	}
	switch (uParam2->f_1) {
	case 4:
		fVar4 = func_98(uParam2);
		if (bVar0 && !func_186(uParam2)) {
			fVar4 = func_238(func_68(uParam2), func_239(uParam2)) + 90f;
		}
		if (func_31(uParam2) == 0 && func_122(uParam2) != func_275(uParam0, 16)) {
			fVar4 += 25f * gameplay::get_random_float_in_range(-1f, 1f);
		}
		if (!bVar0) {
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 45f * uParam2->f_1.f_4;
		}
		if (func_118(uParam2) == 1) {
			fVar4 += func_123(0f, 5f);
			uParam2->f_1.f_5 *= 2f;
			uParam2->f_1.f_6 *= 2f;
		}
		break;

	case 6:
		if (!func_186(uParam2)) {
			fVar1 *= gameplay::get_random_float_in_range(0.15f, 0.25f);
			fVar3 *= gameplay::get_random_float_in_range(0.25f, 1.25f);
		}
		if (uParam2->f_1.f_7 < 0) {
			fVar4 = func_98(uParam2) + 90f * gameplay::get_random_float_in_range(0f, 1f);
			uParam2->f_1.f_5 = gameplay::get_random_float_in_range(0f, 20f) * fVar5;
		}
		else {
			fVar4 = func_98(uParam2) + 90f * gameplay::get_random_float_in_range(-1f, 0f);
			uParam2->f_1.f_5 = gameplay::get_random_float_in_range(-20f, 0f) * fVar5;
		}
		uParam2->f_1.f_6 = gameplay::get_random_float_in_range(-20f, 20f) * fVar5;
		break;

	default: break;
	}
	if (func_186(uParam2)) {
		fVar1 *= 0.95f;
		vVar6 = {system::cos(fVar4) * fVar1, system::sin(fVar4) * fVar1, 0f};
	}
	else {
		fVar21 = 1f - fVar3;
		fVar22 = 2f * fVar21 - fVar21 * fVar21;
		fVar23 = 2f * fVar3 - fVar3 * fVar3;
		vVar9 = {func_115(func_60(uParam2) == 4, 0f, 0f, 1f, -func_116(uParam2))};
		vVar12 = {func_64(system::cos(fVar4), system::sin(fVar4), 0f)};
		vVar15 = {-func_64(vVar12 - FtoV(func_63(vVar12, vVar9)) * vVar9)};
		vVar18 = {func_64(-vVar12 * FtoV(fVar22) + vVar9 * FtoV(fVar23))};
		vVar24 = {func_64(vVar15 * FtoV(fVar22) + vVar9 * FtoV(fVar23))};
		fVar27 = func_63(vVar12, func_64(vVar24.x, vVar24.y, 0f));
		fVar28 = func_114(vVar12.x * vVar24.y - vVar12.y * vVar24.x < 0f, -1f, 1f);
		if (gameplay::absf(fVar27) < system::cos(15f)) {
			vVar24 = {func_113(vVar24, fVar28 * (gameplay::acos(gameplay::absf(fVar27)) - 15f))};
		}
		vVar18.y = vVar24.y / gameplay::absf(vVar24.y) *
				   system::sqrt(
					   gameplay::absf((vVar18.z * vVar18.z - 1f) / (vVar24.x * vVar24.x / (vVar24.y * vVar24.y) + 1f)));
		vVar18.x = vVar24.x * vVar18.y / vVar24.y;
		vVar6 = {FtoV(-1f * fVar1) * vVar18};
	}
	if (bLocal_0) {
		if (func_112(vVar6, 0f, 0f, 0f, 0.001f, 0)) {
			if (bLocal_0) {
			}
			return false;
		}
	}
	if (func_31(uParam2) == 3 && !func_186(uParam2)) {
		func_23(uParam2, 0f, 0f, 0f, 2);
	}
	entity::set_entity_velocity(func_269(uParam2), vVar6);
	entity::set_entity_max_speed(func_269(uParam2), 150f);
	func_107(uParam0, 32);
	func_111(uParam0, uParam2, 0, func_138(uParam0, 16), uParam2->f_1.f_2 < 50f);
	func_109(uParam2, uParam1, uParam0);
	func_45(uParam2, 4);
	if (!func_157(uParam1, uParam2)) {
		func_47(uParam2, 1024);
	}
	func_176(&uParam2->f_162);
	if (func_92(uParam2)) {
		if (!func_157(uParam1, uParam2)) {
			controls::set_pad_shake(0, 100, 256);
		}
	}
	return true;
}

// Position - 0x45DD
void func_109(var *uParam0, var *uParam1, var *uParam2) {
	char *sVar0;

	return;
	sVar0 = "";
	switch (func_31(uParam0)) {
	case 2:
		if (gameplay::absf(uParam0->f_1.f_4) < 10f) {
			sVar0 = "scr_golf_strike_fairway";
		}
		else {
			sVar0 = "scr_golf_strike_fairway_bad";
		}
		break;

	case 4: sVar0 = "scr_golf_strike_thick_grass"; break;

	case 0: sVar0 = "scr_golf_strike_bunker"; break;

	case 3: break;

	case 5:
		if (uParam0->f_1 != 6 && func_233(uParam1, func_293(uParam0)) > 3) {
			sVar0 = "scr_golf_tee_perfect";
		}
		break;

	case 1:
	case 7:
	case -1: break;
	}
	func_110(uParam0, func_138(uParam2, 16));
	if (!func_85(sVar0)) {
		graphics::start_particle_fx_non_looped_at_coord(sVar0, func_239(uParam0), 0f, 0f, func_98(uParam0), 1065353216,
														0, 0, 0);
	}
}

// Position - 0x46BF
void func_110(var *uParam0, bool bParam1) {
	int iVar0;

	return;
	if (!func_186(uParam0) && entity::does_entity_exist(func_269(uParam0))) {
		iVar0 = graphics::start_particle_fx_looped_on_entity("scr_golf_ball_trail", func_269(uParam0), 0f, 0f, 0f, 0f,
															 0f, 0f, 1065353216, 0, 0, 0);
		if (bParam1) {
			graphics::set_particle_fx_looped_colour(iVar0, 240f / 255f, 200f / 255f, 80f / 255f, 0);
		}
	}
}

// Position - 0x472E
void func_111(var *uParam0, var *uParam1, int iParam2, bool bParam3, bool bParam4) {
	char *sVar0;

	sVar0 = "";
	if (func_139(uParam1, 1048576)) {
		return;
	}
	switch (func_104(uParam0, func_122(uParam1))) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
		switch (func_31(uParam1)) {
		case 2:
			if (bParam4) {
				sVar0 = "GOLF_SWING_GRASS_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_GRASS_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_GRASS_MASTER";
			}
			break;

		case 5:
			if (bParam4) {
				sVar0 = "GOLF_SWING_TEE_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_TEE_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_TEE_MASTER";
			}
			break;

		default:
			if (func_31(uParam1) == 3) {
			}
			else if (func_31(uParam1) == -1) {
			}
			else if (func_31(uParam1) == 7) {
			}
			else if (func_31(uParam1) == 8) {
			}
			else if (func_31(uParam1) == 0) {
			}
			else if (func_31(uParam1) == 1) {
			}
			else if (func_31(uParam1) == 4) {
			}
			break;
		}
		break;

	case 6:
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
		switch (func_31(uParam1)) {
		case 5:
			if (bParam4) {
				sVar0 = "GOLF_SWING_TEE_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_TEE_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_TEE_IRON_MASTER";
			}
			break;

		case 2:
			if (bParam4) {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_MASTER";
			}
			break;

		case 4:
			if (bParam4) {
				sVar0 = "GOLF_SWING_ROUGH_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_ROUGH_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_ROUGH_IRON_MASTER";
			}
			break;

		case 0:
			if (bParam4) {
				sVar0 = "GOLF_SWING_SAND_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_SAND_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_SAND_IRON_MASTER";
			}
			break;

		case 1: sVar0 = "GOLF_SWING_TEE_IRON_MASTER"; break;

		default:
			if (func_31(uParam1) == 3) {
			}
			else if (func_31(uParam1) == -1) {
			}
			else if (func_31(uParam1) == 7) {
			}
			else if (func_31(uParam1) == 8) {
			}
			break;
		}
		break;

	case 15:
	case 17:
	case 18:
	case 14:
	case 16:
		switch (func_31(uParam1)) {
		case 5:
		case 2:
		case 3:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_MASTER";
			}
			break;

		case 4:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_GRASS_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_GRASS_MASTER";
			}
			break;

		case 0:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_SAND_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_SAND_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_SAND_MASTER";
			}
			break;

		case 1: sVar0 = "GOLF_SWING_CHIP_MASTER"; break;

		default: break;
		}
		break;

	case 19: sVar0 = "GOLF_SWING_PUTT_MASTER"; break;
	}
	if (!func_85(sVar0)) {
		if (iParam2 || !entity::does_entity_exist(func_269(uParam1))) {
			audio::play_sound_from_coord(-1, sVar0, func_239(uParam1), 0, 0, 0, 0);
		}
		else {
			audio::play_sound_from_entity(-1, sVar0, func_269(uParam1), 0, 0, 0);
		}
	}
}

// Position - 0x4A86
bool func_112(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return true;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return true;
		}
	}
	return false;
}

// Position - 0x4B01
Vector3 func_113(vector3 vParam0, float fParam3) {
	vector3 vVar0;
	float fVar3;
	float fVar4;

	fVar3 = system::sin(fParam3);
	fVar4 = system::cos(fParam3);
	vVar0.x = vParam0.x * fVar4 - vParam0.y * fVar3;
	vVar0.y = vParam0.x * fVar3 + vParam0.y * fVar4;
	vVar0.z = vParam0.z;
	return vVar0;
}

// Position - 0x4B45
float func_114(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x4B5C
Vector3 func_115(bool bParam0, vector3 vParam1, vector3 vParam4) {
	if (bParam0) {
		return vParam1;
	}
	return vParam4;
}

// Position - 0x4B77
Vector3 func_116(var *uParam0) { return func_117(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x4B8D
Vector3 func_117(var *uParam0) { return uParam0->f_25; }

// Position - 0x4B9B
int func_118(var *uParam0) { return func_119(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x4BB1
int func_119(var *uParam0) { return uParam0->f_19; }

// Position - 0x4BBD
float func_120(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 0.25f;

	case 2: return 0.25f;

	case 3: return 0.25f;

	case 4: return 0.25f;

	case 5: return 0.25f;

	case 6: return 0.5f;

	case 7: return 0.5f;

	case 8: return 0.5f;

	case 9: return 0.6f;

	case 10: return 0.6f;

	case 11: return 0.7f;

	case 12: return 0.7f;

	case 13: return 0.8f;

	case 14: return 1f;

	case 15: return 1f;

	case 16: return 1f;

	case 17: return 1f;

	case 18: return 1f;

	case 19: return 0.1f;
	}
	return 0f;
}

// Position - 0x4D18
float func_121(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 13.5f;

	case 2: return 13.75f;

	case 3: return 16f;

	case 4: return 18f;

	case 5: return 21f;

	case 6: return 17f;

	case 7: return 20f;

	case 8: return 23f;

	case 9: return 26f;

	case 10: return 29f;

	case 11: return 30f;

	case 12: return 37f;

	case 13: return 41f;

	case 14: return 45f;

	case 15: return 50f;

	case 16: return 55f;

	case 17: return 60f;

	case 18: return 64f;

	case 19: return 5f;
	}
	return 0f;
}

// Position - 0x4E83
int func_122(var *uParam0) { return func_105(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x4E99
float func_123(float fParam0, float fParam1) {
	float fVar0;

	fVar0 = system::sin(gameplay::get_random_float_in_range(-180f, 180f));
	if (fVar0 < 0f) {
		fVar0++;
	}
	else {
		fVar0--;
	}
	return fParam0 + fVar0 * fParam1;
}

// Position - 0x4ED3
float func_124(var *uParam0, var *uParam1, var *uParam2, bool bParam3, bool bParam4, int iParam5) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;

	fVar0 = uParam2->f_3;
	if (iParam5) {
		fVar0 = 100f;
	}
	else if (!bParam4) {
		fVar0 = func_127(uParam0, 1);
	}
	switch (func_119(uParam0)) {
	case 0:
		fVar1 = 0.5575f;
		fVar2 = 0f;
		break;

	case 1:
		fVar1 = 0.575f;
		fVar2 = 15f * (1f - system::sqrt(fVar0 / 100f));
		break;

	case 3:
		fVar1 = 0.5075f;
		fVar2 = func_114(fVar0 > 25f, 25f, 15f);
		fVar2 *= (1f - system::sqrt(fVar0 / 100f));
		break;

	case 2:
		fVar1 = 0.558f;
		fVar2 = 15f * (1f - system::sqrt(fVar0 / 100f));
		break;

	case 5:
		fVar1 = 0.53f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 <= 63f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 <= 55f) {
			fVar1 *= 1.04f;
		}
		if (fVar0 <= 46f) {
			fVar1 *= 1.038f;
		}
		if (fVar0 <= 38f) {
			fVar1 *= 1.04f;
		}
		if (fVar0 <= 34f) {
			fVar1 *= 1.045f;
		}
		if (fVar0 <= 28f) {
			fVar1 *= 1.045f;
		}
		fVar2 = 0.1f;
		break;

	case 7: return -1f;

	case 4:
		fVar1 = 0.36f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 <= 62f) {
			fVar1 *= 1.035f;
		}
		else if (fVar0 <= 75f) {
			fVar1 *= 1.015f;
		}
		if (fVar0 <= 49f) {
			fVar1 *= 1.035f;
		}
		else if (fVar0 <= 58f) {
			fVar1 *= 1.025f;
		}
		if (fVar0 <= 39f) {
			fVar1 *= 1.075f;
		}
		else if (fVar0 <= 43f) {
			fVar1 *= 1.055f;
		}
		if (fVar0 <= 30f) {
			fVar1 *= 1.075f;
		}
		fVar2 = 0.1f;
		break;

	case 6:
		fVar1 = 0.79f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 < 65f) {
			fVar1 *= 1.015f;
		}
		if (fVar0 < 56f) {
			fVar1 *= 1.01f;
		}
		if (fVar0 < 51f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 < 45f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 < 35f) {
			fVar1 *= 1.07f;
		}
		if (fVar0 < 25f) {
			fVar1 *= 1.1f;
		}
		fVar2 = 0.1f;
		break;
	}
	if (!bParam3) {
		fVar2 = 0f;
	}
	fVar3 = -1f * (fVar0 / 100f * func_126(uParam1, func_105(uParam0)) * func_125(func_32(uParam0)) * fVar1 + fVar2);
	return fVar3;
}

// Position - 0x5202
float func_125(int iParam0) {
	switch (iParam0) {
	case 2:
	case 5: return 1f;

	case 4:
	case 1: return 0.95f;

	case 0:
	case 7:
	case -1: return 0.75f;

	case 3: return 1f;

	default: return 1f;
	}
	return 1f;
}

// Position - 0x526D
float func_126(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 220f / 1.85f;

	case 2: return 210f / 1.85f;

	case 3: return 200f / 1.85f;

	case 4: return 190f / 1.85f;

	case 5: return 180f / 1.85f;

	case 6: return 180f / 1.85f;

	case 7: return 170f / 1.85f;

	case 8: return 160f / 1.85f;

	case 9: return 150f / 1.85f;

	case 10: return 140f / 1.85f;

	case 11: return 130f / 1.85f;

	case 12: return 120f / 1.85f;

	case 13: return 110f / 1.85f;

	case 14: return 100f / 1.85f;

	case 15: return 85f / 1.85f;

	case 16: return 75f / 1.85f;

	case 17: return 65f / 1.85f;

	case 18: return 40f / 1.85f;

	case 19: return 30f / 1.85f;
	}
	return 0f;
}

// Position - 0x544E
float func_127(var *uParam0, int iParam1) {
	float fVar0;

	fVar0 = uParam0->f_15;
	if (iParam1 && (func_28(uParam0) == 1 || func_28(uParam0) == 2)) {
		fVar0 -= func_128() * 10f;
		fVar0 = func_114(fVar0 < 5f, 5f, fVar0);
	}
	return fVar0;
}

// Position - 0x549A
float func_128() {
	int iVar0;
	float fVar1;

	stats::stat_get_int(func_129(func_131(), 2), &iVar0, -1);
	fVar1 = IntToFloat(iVar0) / 100f;
	fVar1 = 1f - fVar1;
	return fVar1;
}

// Position - 0x54C6
var func_129(int iParam0, int iParam1) {
	int *iVar0;
	int *iVar1;

	func_130(iParam0, iParam1, &iVar0, &iVar1);
	return iVar0;
}

// Position - 0x54DC
void func_130(int iParam0, int iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp0_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp0_stamina"); break;

		case 3: *iParam2 = joaat("sp0_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp0_strength"); break;

		case 4: *iParam2 = joaat("sp0_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp0_flying_ability"); break;

		case 6: *iParam2 = joaat("sp0_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp0_stealth_ability"); break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp1_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp1_stamina"); break;

		case 3: *iParam2 = joaat("sp1_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp1_strength"); break;

		case 4: *iParam2 = joaat("sp1_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp1_flying_ability"); break;

		case 6: *iParam2 = joaat("sp1_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp1_stealth_ability"); break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp2_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp2_stamina"); break;

		case 3: *iParam2 = joaat("sp2_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp2_strength"); break;

		case 4: *iParam2 = joaat("sp2_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp2_flying_ability"); break;

		case 6: *iParam2 = joaat("sp2_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp2_stealth_ability"); break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: *iParam3 = 64; break;

		case 1: *iParam3 = 65; break;

		case 3: *iParam3 = 67; break;

		case 2: *iParam3 = 66; break;

		case 4: *iParam3 = 68; break;

		case 5: *iParam3 = 69; break;

		case 6: *iParam3 = 70; break;

		case 7: *iParam3 = 71; break;
		}
		break;
	}
}

// Position - 0x5733
int func_131() {
	func_132();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x574C
void func_132() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_136(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_135(player::player_ped_id());
			if (func_134(iVar0) && (!func_133(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_134(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x5849
bool func_133(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x5857
bool func_134(int iParam0) { return iParam0 < 3; }

// Position - 0x5863
int func_135(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_136(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x58A0
int func_136(int iParam0) {
	if (func_134(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x58CA
int func_137(int iParam0) {
	char cVar0[32];
	char cVar8[32];
	char cVar16[32];
	char cVar24[32];

	if (!ped::is_ped_injured(iParam0)) {
		StringCopy(&cVar0, "Wood_swing_action", 32);
		StringCopy(&cVar8, "Iron_swing_action", 32);
		StringCopy(&cVar16, "Wedge_swing_action", 32);
		StringCopy(&cVar24, "Putt_action", 32);
		if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar0, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar0) > 0.16f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar8, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar8) > 0.134f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar16, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar16) > 0.119f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_101(0), &cVar24, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_101(0), &cVar24) > 0.159f) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x59B2
bool func_138(var *uParam0, int iParam1) { return (uParam0->f_22 & iParam1) != 0; }

// Position - 0x59C3
bool func_139(var *uParam0, int iParam1) { return func_3(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x59DB
void func_140(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4) {
	int iVar0;
	bool bVar1;
	float fVar2;
	float fVar3;

	iVar0 = 1000;
	if (func_139(uParam0, 256)) {
		iVar0 = 450;
	}
	bVar1 = func_139(uParam0, 131072);
	fVar2 = 0f;
	fVar3 = func_114(bVar1, 2f, 1f);
	if (uParam2->f_12 > 0) {
		uParam2->f_12 += system::floor(gameplay::get_frame_time() * 1000f);
	}
	if (uParam2->f_11 == 0 && !func_139(uParam0, 1048576) || func_150(uParam0) == 0) {
		func_174(uParam0, 1);
		uParam2->f_11 = gameplay::get_game_timer();
		uParam2->f_12 = uParam2->f_11;
		func_176(&uParam0->f_162);
		func_149(uParam0);
		*uParam2 = 1;
	}
	else if (uParam2->f_11 + iVar0 < uParam2->f_12 || uParam2->f_10 != 0)
		&&*uParam2 != 4 && *uParam2 != 6 || func_139(uParam0, 1048576) {
			func_174(uParam0, 4);
			*uParam2 = 4;
			if (iParam3) {
				uParam2->f_4 = func_123(0f, func_114(iParam4, 5f, 0f));
				uParam2->f_3 = func_148(uParam0, 0);
			}
			else {
				uParam2->f_4 = func_123(0f, fVar2);
				uParam2->f_3 = func_123(func_148(uParam0, 0), 20f) / fVar3;
				if (uParam2->f_3 < 15f) {
					uParam2->f_3 = 15f;
				}
			}
			if (func_118(uParam0) == 4 || func_118(uParam0) == 7 || func_118(uParam0) == 6 || func_118(uParam0) == 5) {
			}
			else {
				func_145(uParam0, uParam1, 0, 1f);
			}
			if (func_139(uParam0, 1048576)) {
				func_143(uParam0, uParam2->f_3);
				func_141(uParam0, uParam2->f_4);
			}
		}
}

// Position - 0x5B8D
void func_141(var *uParam0, float fParam1) { func_142(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x5BA5
void func_142(var *uParam0, float fParam1) { uParam0->f_14 += fParam1; }

// Position - 0x5BB8
void func_143(var *uParam0, float fParam1) {
	if (fParam1 > 100f) {
		fParam1 = 100f;
	}
	else if (fParam1 < 5f) {
		fParam1 = 5f;
	}
	func_144(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1);
}

// Position - 0x5BEF
void func_144(var *uParam0, float fParam1) { uParam0->f_15 = fParam1; }

// Position - 0x5BFD
void func_145(var *uParam0, var uParam1, int iParam2, float fParam3) {
	iParam2 = iParam2;
	fParam3 = fParam3;
	switch (func_118(uParam0)) {
	case 0:
	case 1:
	case 3:
	case 2: audio::play_sound_from_entity(-1, "GOLF_FORWARD_SWING_HARD_MASTER", func_146(uParam0), 0, 0, 0); break;

	case 4:
	case 5:
	case 6:
	case 7: break;
	}
}

// Position - 0x5C60
var func_146(var *uParam0) { return func_147(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x5C76
var func_147(var *uParam0) { return uParam0->f_4; }

// Position - 0x5C82
float func_148(var *uParam0, int iParam1) { return func_127(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x5C9A
void func_149(var *uParam0) {
	switch (func_118(uParam0)) {
	case 0:
	case 1: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_146(uParam0), 0, 0, 0); break;

	case 3:
	case 2: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_146(uParam0), 0, 0, 0); break;

	case 4:
	case 5:
	case 6:
	case 7: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_146(uParam0), 0, 0, 0); break;
	}
}

// Position - 0x5D1C
int func_150(var *uParam0) { return func_151(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x5D32
int func_151(var *uParam0) { return uParam0->f_20; }

// Position - 0x5D3E
void func_152(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x5D54
float func_153(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	if (iParam2) {
		return system::vdist2(vVar0, vVar3);
	}
	return system::pow(vVar0.x - vVar3.x, 2f) + system::pow(vVar0.y - vVar3.y, 2f);
}

// Position - 0x5DD4
int func_154(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_277(uParam0)) {
		if (iParam1 < 0 || iParam1 != iVar0) {
			if (func_50(&uParam0->f_15[iVar0 /*34*/]) < 1 && func_155(uParam0, iVar0) != 10) {
				return 0;
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x5E2B
int func_155(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return -1;
	}
	return func_4(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x5E57
bool func_156(int *iParam0, float fParam1) {
	if (func_86(iParam0, fParam1)) {
		func_152(iParam0);
		return true;
	}
	return false;
}

// Position - 0x5E75
bool func_157(var *uParam0, var *uParam1) {
	int iVar0;
	vector3 vVar1;

	iVar0 = func_269(uParam1);
	if (entity::does_entity_exist(func_158(uParam1)) && func_31(uParam1) == 3) {
		return true;
	}
	if (!entity::does_entity_exist(iVar0)) {
		return false;
	}
	vVar1 = {entity::get_entity_coords(func_269(uParam1), 0)};
	if (func_31(uParam1) != 3 && system::vdist2(vVar1, func_43(uParam0, func_293(uParam1))) > 0.7f * 0.7f) {
		return false;
	}
	if (system::vdist2(vVar1, func_43(uParam0, func_293(uParam1))) > 55f * 55f) {
		return false;
	}
	return true;
}

// Position - 0x5F1C
var func_158(var *uParam0) { return func_159(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x5F32
var func_159(var *uParam0) { return uParam0->f_6; }

// Position - 0x5F3E
void func_160(var *uParam0, var *uParam1, var *uParam2) {
	if (func_3(uParam1, 1048576) || func_4(uParam1) == 5) {
		return;
	}
	switch (func_119(uParam1)) {
	case 0:
	case 1:
	case 3:
	case 2: func_161(uParam0, uParam1, uParam2); break;

	case 4:
	case 5:
	case 6:
	case 7: func_161(uParam0, uParam1, uParam2); break;
	}
}

// Position - 0x5FB9
void func_161(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float *fVar5;
	char *sVar6;
	bool bVar7;
	char *sVar8;
	char cVar9[32];
	char cVar17[32];
	char cVar25[32];
	char cVar33[32];

	if (func_173(uParam1)) {
		func_172(uParam0, uParam1, uParam2);
		return;
	}
	iVar0 = func_171(uParam1);
	fVar1 = 1f;
	fVar2 = 0.1f;
	fVar3 = 0.05f;
	fVar1 = fVar1;
	if (bLocal_0) {
	}
	if (!ped::is_ped_injured(iVar0)) {
		sVar6 = func_163(uParam1, uParam0, &fVar5, 0, 0, 0, 0);
		bVar7 = !func_85(sVar6);
		sVar8 = func_103(uParam0, uParam1, 0, 1);
		StringCopy(&cVar9, sVar8, 32);
		StringCopy(&cVar17, sVar8, 32);
		StringCopy(&cVar25, sVar8, 32);
		StringCopy(&cVar33, sVar8, 32);
		StringConCat(&cVar9, "Idle", 32);
		StringConCat(&cVar17, "Swing_Intro", 32);
		StringConCat(&cVar25, "Swing_Action", 32);
		StringConCat(&cVar33, "Swing_idle", 32);
		sVar6 = sVar6;
		bVar7 = bVar7;
		switch (func_151(uParam1)) {
		case 0:
			if (bLocal_0) {
			}
			break;

		case 1:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
				ai::task_play_anim(iVar0, func_101(0), &cVar17, 8f, -8f, -1, 2, 0, 0, 0, 0);
				if (bLocal_0) {
				}
			}
			else {
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
				if (entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17) >= 0.975f) {
					if (bLocal_0) {
					}
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0f);
					if (uParam2->f_10 == 0) {
						uParam2->f_10 = gameplay::get_game_timer();
					}
				}
				else {
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0.6f);
				}
				if (fVar4 < fVar2) {
					entity::set_entity_anim_current_time(iVar0, func_101(0), &cVar17, fVar2);
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0.8f);
				}
			}
			break;

		case 3:
			if (bLocal_0) {
			}
			StringConCat(&cVar9, "_A", 32);
			if (entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
				entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0f);
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
				if (fVar4 < fVar2) {
					ai::task_play_anim(iVar0, func_101(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					func_162(uParam1, 0);
				}
				else {
					entity::set_entity_anim_current_time(iVar0, func_101(0), &cVar17, fVar4 - fVar3);
					if (bLocal_0) {
					}
				}
			}
			else {
				if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar9, 3)) {
					ai::task_play_anim(iVar0, func_101(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				func_162(uParam1, 0);
			}
			break;

		case 4:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar25, 3)) {
				if (entity::has_entity_anim_finished(iVar0, func_101(0), &cVar17, 3)) {
					ai::task_play_anim(iVar0, func_101(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else if (entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
					fVar1 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
					ai::task_play_anim(iVar0, func_101(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else {
					func_162(uParam1, 0);
				}
			}
			break;
		}
	}
}

// Position - 0x62B0
void func_162(var *uParam0, int iParam1) { uParam0->f_20 = iParam1; }

// Position - 0x62BE
char *func_163(var *uParam0, var *uParam1, float *fParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	float fVar8;
	float fVar9;
	float fVar10;
	vector3 vVar11;
	vector3 vVar14;
	vector3 vVar17;
	vector3 vVar20;
	float fVar23;
	float fVar24;
	vector3 vVar25;

	return "";
	iVar0 = func_105(uParam0);
	iVar1 = func_104(uParam1, iVar0);
	vVar2 = {entity::get_entity_coords(func_171(uParam0), 1)};
	if (iParam3) {
		vVar2 = {iParam4, iParam5, iParam6};
	}
	vVar5 = {func_170(uParam0)};
	fVar8 = 52.25f;
	func_168(iVar1, &fVar8, &fVar9, &fVar10);
	vVar2.z += fVar10;
	vVar11 = {entity::get_entity_forward_vector(func_171(uParam0))};
	vVar14 = {func_64(vVar5 - vVar2)};
	vVar17 = {func_113(vVar11, 90f)};
	vVar20 = {vVar11};
	func_164(&vVar20, fVar8, vVar17);
	fVar23 = gameplay::acos(func_63(vVar11, vVar14));
	fVar24 = fVar23 - fVar8;
	vVar25 = {func_64(vVar20)};
	func_164(&vVar25, fVar24, vVar17);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar14, 255, 0, 0, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar11, 0, 0, 255, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar25, 255, 255, 255, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar20, 0, 0, 0, 255);
	if (fVar23 < fVar8) {
		*fParam2 = gameplay::absf(fVar24) * fVar9;
		if (*fParam2 > 0.9999f) {
			*fParam2 = 0.9999f;
		}
		return "_High";
	}
	else {
		*fParam2 = gameplay::absf(fVar24) * fVar9;
		if (*fParam2 > 0.9999f) {
			*fParam2 = 0.9999f;
		}
		return "_Low";
	}
	*fParam2 = 0f;
	return "_High";
}

// Position - 0x6454
void func_164(var *uParam0, float fParam1, vector3 vParam2) {
	float fVar0;
	float fVar1;

	vParam2 = {func_64(vParam2)};
	fVar0 = system::cos(fParam1);
	fVar1 = system::sin(fParam1);
	*uParam0 = {func_167(*uParam0, vParam2) * FtoV(fVar0) + func_166(vParam2, *uParam0) * FtoV(fVar1) +
				func_165(*uParam0, vParam2)};
}

// Position - 0x64AA
Vector3 func_165(vector3 vParam0, vector3 vParam3) {
	vector3 vVar0;

	vVar0 = {vParam3 * FtoV(func_63(vParam0, vParam3))};
	return vVar0;
}

// Position - 0x64CC
Vector3 func_166(vector3 vParam0, vector3 vParam3) {
	return vParam0.y * vParam3.z - vParam0.z * vParam3.y, vParam0.z * vParam3.x - vParam0.x * vParam3.z,
		   vParam0.x * vParam3.y - vParam0.y * vParam3.x;
}

// Position - 0x6505
Vector3 func_167(vector3 vParam0, vector3 vParam3) {
	vector3 vVar0;

	vVar0 = {vParam0 - func_165(vParam0, vParam3)};
	return vVar0;
}

// Position - 0x6526
void func_168(int iParam0, float *fParam1, float *fParam2, float *fParam3) {
	if (func_169()) {
		if (iParam0 <= 5) {
			*fParam1 = 47.24f;
			*fParam2 = 0.2f;
			*fParam3 = 0.09f;
		}
		else if (iParam0 > 5 && iParam0 <= 13) {
			*fParam1 = 53.367f;
			*fParam2 = 0.2f;
			*fParam3 = 0f;
		}
		else if (iParam0 > 13 && iParam0 <= 18) {
			*fParam1 = 52.199f;
			*fParam2 = 0.2f;
			*fParam3 = -0.07f;
		}
		else {
			*fParam1 = 70.53f;
			*fParam2 = 0.35f;
			*fParam3 = 0.5f;
		}
	}
	else if (iParam0 <= 5) {
		*fParam1 = 46.23f;
		*fParam2 = 0.2f;
		*fParam3 = 0.09f;
	}
	else if (iParam0 > 5 && iParam0 <= 13) {
		*fParam1 = 52.25f;
		*fParam2 = 0.2f;
		*fParam3 = 0f;
	}
	else if (iParam0 > 13 && iParam0 <= 18) {
		*fParam1 = 51.91f;
		*fParam2 = 0.15f;
		*fParam3 = -0.07f;
	}
	else {
		*fParam1 = 70.53f;
		*fParam2 = 0.35f;
		*fParam3 = 0.5f;
	}
}

// Position - 0x6654
bool func_169() { return false; }

// Position - 0x665D
Vector3 func_170(var *uParam0) { return uParam0->f_7; }

// Position - 0x666B
int func_171(var *uParam0) { return uParam0->f_2; }

// Position - 0x6677
void func_172(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float *fVar5;
	char *sVar6;
	bool bVar7;
	char *sVar8;
	char cVar9[32];
	char cVar17[32];
	char cVar25[32];

	iVar0 = func_171(uParam1);
	fVar1 = 1f;
	fVar2 = 0.1f;
	fVar3 = 0.05f;
	fVar1 = fVar1;
	if (bLocal_0) {
	}
	if (!ped::is_ped_injured(iVar0)) {
		sVar6 = func_163(uParam1, uParam0, &fVar5, 0, 0, 0, 0);
		bVar7 = !func_85(sVar6);
		sVar8 = func_103(uParam0, uParam1, 0, 1);
		StringCopy(&cVar9, sVar8, 32);
		StringCopy(&cVar17, sVar8, 32);
		StringCopy(&cVar25, sVar8, 32);
		StringConCat(&cVar9, "Idle", 32);
		StringConCat(&cVar17, "Intro", 32);
		StringConCat(&cVar25, "Action", 32);
		sVar6 = sVar6;
		bVar7 = bVar7;
		switch (func_151(uParam1)) {
		case 0:
			if (bLocal_0) {
			}
			break;

		case 1:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
				ai::task_play_anim(iVar0, func_101(0), &cVar17, 8f, -8f, -1, 2, 0, 0, 0, 0);
				if (bLocal_0) {
				}
			}
			else {
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
				if (entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17) >= 0.975f) {
					if (bLocal_0) {
					}
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0f);
					if (uParam2->f_10 == 0) {
						uParam2->f_10 = gameplay::get_game_timer();
					}
				}
				else {
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0.6f);
				}
				if (fVar4 < fVar2) {
					entity::set_entity_anim_current_time(iVar0, func_101(0), &cVar17, fVar2);
					entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0.8f);
				}
			}
			break;

		case 3:
			if (bLocal_0) {
			}
			StringConCat(&cVar9, "_a", 32);
			if (entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
				entity::set_entity_anim_speed(iVar0, func_101(0), &cVar17, 0f);
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
				if (fVar4 < fVar2) {
					ai::task_play_anim(iVar0, func_101(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					func_162(uParam1, 0);
				}
				else {
					entity::set_entity_anim_current_time(iVar0, func_101(0), &cVar17, fVar4 - fVar3);
					if (bLocal_0) {
					}
				}
			}
			else {
				if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar9, 3)) {
					ai::task_play_anim(iVar0, func_101(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				func_162(uParam1, 0);
			}
			break;

		case 4:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_101(0), &cVar25, 3)) {
				if (entity::has_entity_anim_finished(iVar0, func_101(0), &cVar17, 3)) {
					ai::task_play_anim(iVar0, func_101(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else if (entity::is_entity_playing_anim(iVar0, func_101(0), &cVar17, 3)) {
					fVar1 = entity::get_entity_anim_current_time(iVar0, func_101(0), &cVar17);
					ai::task_play_anim(iVar0, func_101(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else {
					func_162(uParam1, 0);
				}
			}
			break;
		}
	}
}

// Position - 0x694A
bool func_173(var *uParam0) {
	int iVar0;

	iVar0 = func_119(uParam0);
	if (iVar0 == 5 || iVar0 == 4 || iVar0 == 6 || iVar0 == 7) {
		return true;
	}
	return false;
}

// Position - 0x6984
void func_174(var *uParam0, int iParam1) { func_162(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x699C
int func_175() { return 4; }

// Position - 0x69A5
void func_176(var *uParam0) { func_177(uParam0, 0f); }

// Position - 0x69B4
void func_177(int *iParam0, float fParam1) {
	uParam0->f_1 = func_88(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x69E2
void func_178(var *uParam0, int iParam1, var *uParam2, int iParam3, int iParam4) {
	func_179(uParam0, iParam1, func_184(uParam0, iParam1), uParam2, iParam3, iParam4);
}

// Position - 0x6A00
void func_179(var *uParam0, int iParam1, vector3 vParam2, var *uParam5, int iParam6, int iParam7) {
	var uVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	float *fVar8;
	int iVar9;

	if (iParam6) {
		if (gameplay::get_ground_z_for_3d_coord(vParam2 + Vector(50f, 0f, 0f), &uVar0, 0)) {
			vParam2.z = uVar0;
		}
	}
	entity::set_entity_coords(func_183(uParam0, iParam1), vParam2, 0, 0, 0, 1);
	iVar1 = func_37(uParam0, iParam1);
	if (entity::does_entity_exist(func_36(uParam0, iVar1)) && iParam7) {
		vVar2 = {0f, 0f, 0f};
		vVar5 = {0f, 0f, 0f};
		fVar8 = 0f;
		if (iVar1 > 0) {
			vVar5 = {5f, 5f, 0f};
		}
		if (!entity::is_entity_dead(func_36(uParam0, iVar1), 0)) {
			if (func_27(uParam0, iParam1, 1048576)) {
				iVar9 = func_182(vParam2 + vVar5, func_43(uParam5, func_293(uParam0)), &vVar2, &fVar8);
			}
			else {
				iVar9 = func_180(vParam2 + vVar5, func_43(uParam5, func_293(uParam0)), &vVar2, &fVar8, 0f, 0f, 0f, 0f,
								 0f, 0f, 0);
			}
			if (iVar9 && !cam::is_sphere_visible(vVar2, 5f)) {
				entity::set_entity_coords(func_36(uParam0, iVar1), vVar2, 1, 0, 0, 1);
				entity::set_entity_heading(func_36(uParam0, iVar1), fVar8);
			}
		}
	}
}

// Position - 0x6B19
bool func_180(vector3 vParam0, struct<2> Param3, var uParam5, var *uParam6, float *fParam7, vector3 vParam8,
			  struct<2> Param11, float fParam13, int iParam14) {
	int iVar0;
	int iVar1;
	var uVar2;
	vector3 vVar3;

	iVar1 = 1;
	vVar3 = {0f, 0f, 0f};
	while (!iVar0 && iVar1 < 10) {
		if (!pathfind::get_nth_closest_vehicle_node_with_heading(vParam0, iVar1, uParam6, fParam7, &uVar2, 1, 3f, 0f)) {
			return false;
		}
		else if (system::vdist2(vParam0, *uParam6) > 100f && !vehicle::is_any_vehicle_near_point(*uParam6, 5f) &&
				 !func_62(*uParam6)) {
			vVar3 = {func_64(Vector(0f, uParam6->f_1, *uParam6) - Vector(0f, Param11.f_1, Param11))};
			if (!iParam14 || func_181(vParam8, vVar3) < 0.75f) {
				iVar0 = 1;
			}
		}
		iVar1++;
	}
	if (gameplay::absf(gameplay::get_heading_from_vector_2d(Param3 - vParam0.x, Param3.f_1 - vParam0.y) - *fParam7) >
		90f) {
		*fParam7 += 180f;
	}
	func_241(uParam6, 5f, 0.5f);
	return true;
}

// Position - 0x6C0E
float func_181(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
	return Param0 * Param3 + Param0.f_1 * Param3.f_1;
}

// Position - 0x6C25
bool func_182(vector3 vParam0, struct<2> Param3, var uParam5, var uParam6, float *fParam7) {
	if (!pathfind::get_closest_vehicle_node_with_heading(vParam0, uParam6, fParam7, 1, 1077936128, 0)) {
		return false;
	}
	if (gameplay::absf(gameplay::get_heading_from_vector_2d(Param3 - vParam0.x, Param3.f_1 - vParam0.y) - *fParam7) >
		90f) {
		*fParam7 += 180f;
	}
	return true;
}

// Position - 0x6C78
int func_183(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_171(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x6CA4
Vector3 func_184(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f, 0f, 0f;
	}
	return func_170(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x6CD2
int func_185(var *uParam0) {
	if (func_234() || func_186(uParam0)) {
		if (ai::get_script_task_status(func_271(uParam0), 242628503) == 1) {
			if (ai::get_sequence_progress(func_271(uParam0)) == 2) {
				return 1;
			}
		}
	}
	else if (ai::get_script_task_status(func_271(uParam0), 242628503) != 1 &&
			 ai::get_script_task_status(func_271(uParam0), 242628503) != 0) {
		return 1;
	}
	return 0;
}

// Position - 0x6D44
bool func_186(var *uParam0) {
	int iVar0;

	iVar0 = func_118(uParam0);
	if (iVar0 == 5 || iVar0 == 4 || iVar0 == 6 || iVar0 == 7) {
		return true;
	}
	return false;
}

// Position - 0x6D7E
void func_187(var *uParam0) {
	if (!func_74(uParam0)) {
		func_176(uParam0);
	}
}

// Position - 0x6D96
void func_188(var *uParam0, vector3 vParam1) { func_11(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x6DB0
Vector3 func_189(var *uParam0, var *uParam1) {
	vector3 vVar0;
	float fVar3;
	float fVar4;
	var uVar5;
	vector3 vVar6;

	fVar3 = func_123(0f, 8f);
	fVar4 = func_123(1f, 0.2f);
	if (func_93(uParam0)) {
		fVar3 = func_123(0f, 4f);
		fVar4 = 1f;
	}
	if (func_139(uParam0, 1048576) || func_60(uParam0) == 4) {
		vVar0 = {object::_get_object_offset_from_coords(
			func_239(uParam0), func_98(uParam0) + fVar3,
			-func_126(uParam1, func_122(uParam0)) * func_190(func_118(uParam0)) *
				func_125(func_32(&uParam0->f_15[func_255(uParam0) /*34*/])) * func_148(uParam0, 1) * fVar4 / 100f,
			0f, 0f)};
	}
	else if (func_31(uParam0) != 3) {
		vVar0 = {object::_get_object_offset_from_coords(
			func_239(uParam0), func_98(uParam0),
			-func_126(uParam1, func_122(uParam0)) * func_190(func_118(uParam0)) *
				func_125(func_32(&uParam0->f_15[func_255(uParam0) /*34*/])) * func_148(uParam0, 1) / 100f,
			0f, 0f)};
	}
	else {
		vVar0 = {object::_get_object_offset_from_coords(func_239(uParam0), func_98(uParam0),
														FtoV(-uParam0->f_1.f_1) *
															Vector(0f, 0f, func_148(uParam0, 1) / 100f))};
	}
	if (gameplay::get_ground_z_for_3d_coord(vVar0, &uVar5, 0)) {
		vVar0.z = uVar5;
	}
	else {
		vVar0.z += 50f;
		if (gameplay::get_ground_z_for_3d_coord(vVar0, &uVar5, 0)) {
			vVar0.z = uVar5;
		}
		else {
			vVar6 = {func_239(uParam0)};
			vVar0.z = vVar6.z;
		}
	}
	return vVar0;
}

// Position - 0x6F35
float func_190(int iParam0) {
	switch (iParam0) {
	case 0: return 1f;

	case 3: return 0.5075f / 0.5575f;

	case 2: return 0.558f / 0.5575f;

	case 5: return 0.53f / 0.5575f;

	case 7:
	case 4: return 0.36f / 0.5575f;

	case 6: return 0.79f / 0.5575f;

	case 1: return 0.575f / 0.5575f;
	}
	return 1f;
}

// Position - 0x6FE2
void func_191(var *uParam0, var *uParam1, var *uParam2) {
	float fVar0;
	float fVar1;
	float fVar2;
	int iVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;

	fVar0 = func_192(uParam1);
	fVar1 = uParam0->f_1;
	fVar2 = 100f * fVar0 / fVar1;
	iVar3 = func_104(uParam2, func_105(uParam1));
	if (iVar3 == 17 || iVar3 == 16) {
		fVar4 = fVar0 / fVar1;
		fVar5 = 1f - fVar4;
		if (iVar3 == 16) {
			fVar6 = 2.5f;
		}
		else if (func_28(uParam1) != 4) {
			if (fVar2 > 40f) {
				fVar6 = 1.5f;
			}
			else if (fVar2 > 30f) {
				fVar6 = 2f;
			}
			else {
				fVar6 = 2.5f;
			}
		}
		fVar7 = fVar6 * fVar5 * fVar5 + 1f;
		fVar4 *= fVar7;
		fVar2 = fVar4 * 100f;
	}
	else if (iVar3 == 19 && func_28(uParam1) != 4) {
		fVar2 += func_128() * 10f;
	}
	func_144(uParam1, fVar2);
	if (func_127(uParam1, 0) > 100f) {
		func_144(uParam1, 100f);
	}
	else if (func_127(uParam1, 0) < 5f) {
		func_144(uParam1, 5f);
	}
}

// Position - 0x70F8
var func_192(var *uParam0) { return uParam0->f_13; }

// Position - 0x7104
void func_193(var *uParam0, var *uParam1, var *uParam2) {
	if (!func_157(uParam1, uParam2) && !func_186(uParam2)) {
		uParam2->f_1.f_1 = func_194(uParam2, uParam0);
	}
	else if (func_118(uParam2) == 4) {
		uParam2->f_1.f_1 = 5f;
	}
	else if (func_118(uParam2) == 5 || func_118(uParam2) == 7) {
		uParam2->f_1.f_1 = 10f;
	}
	else {
		uParam2->f_1.f_1 = 20f;
	}
}

// Position - 0x717B
float func_194(var *uParam0, var *uParam1) {
	float fVar0;

	fVar0 = func_195(uParam1, func_122(uParam0));
	return fVar0;
}

// Position - 0x7193
float func_195(var *uParam0, int iParam1) {
	switch ((*uParam0)[iParam1]) {
	case 1: return 105.8f;

	case 3: return 100.5f;

	case 5: return 97.3f;

	case 7: return 90.2f;

	case 8: return 87f;

	case 9: return 83f;

	case 10: return 79.9f;

	case 11: return 73.5f;

	case 12: return 68f;

	case 13: return 59.1f;

	case 14: return 52.5f;

	case 16: return 30.9f;

	case 17: return 21.8f;

	default: break;
	}
	return 0f;
}

// Position - 0x7287
void func_196(int iParam0, int iParam1) { entity::freeze_entity_position(iParam0, iParam1); }

// Position - 0x7297
void func_197(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	vector3 vVar0;
	int iVar3;

	if (iParam5) {
		vVar0 = {func_240(uParam0, func_293(uParam1))};
	}
	else {
		vVar0 = {func_43(uParam0, func_293(uParam1))};
	}
	iVar3 = func_238(vVar0, func_239(uParam1)) + 90f;
	func_198(&uParam1->f_15[func_255(uParam1) /*34*/], uParam2, iVar3, 0, iParam3, iParam4, iParam6, iParam7);
}

// Position - 0x72FA
void func_198(var *uParam0, var *uParam1, int iParam2, int iParam3, var uParam4, int iParam5, var uParam6,
			  bool bParam7) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;
	float fVar7;
	bool bVar8;

	if (func_28(uParam0) == 4) {
		ai::task_stand_still(func_171(uParam0), -1);
	}
	else {
		iParam5 = 1;
	}
	iVar0 = func_104(uParam1, func_105(uParam0));
	func_46(uParam0, 134217728);
	func_220(uParam0, iParam2);
	vVar1 = {object::_get_object_offset_from_coords(func_170(uParam0), func_99(uParam0), func_219(iVar0))};
	vVar4 = {entity::get_entity_coords(func_171(uParam0), 1)};
	if (iParam3) {
		ai::clear_ped_tasks_immediately(func_171(uParam0));
	}
	if (iParam5 || func_3(uParam0, 1048576)) {
		if (func_28(uParam0) != 4) {
			func_241(&vVar4, 100f, 0f);
		}
		if (gameplay::get_ground_z_for_3d_coord(vVar1 + Vector(1f, 0f, 0f), &fVar7, 0)) {
			if (gameplay::absf(fVar7 - vVar4.z) < 0.35f || fVar7 < vVar1.z || bParam7) {
				vVar1.z = fVar7;
			}
		}
		if (uParam4 && func_169()) {
			func_210(vVar1, func_99(uParam0), 0, 0, 0, 0, 1, 0, 1, 0);
		}
		else {
			bVar8 = true;
			if (bVar8) {
				entity::set_entity_heading(func_171(uParam0), func_99(uParam0));
				entity::set_entity_coords(func_171(uParam0), vVar1, 0, 1, 1, 1);
			}
		}
	}
	else {
		ai::clear_ped_tasks(func_171(uParam0));
		ai::open_sequence_task(&uParam0->f_21);
		if (func_234() || func_173(uParam0)) {
			ai::task_follow_nav_mesh_to_coord(0, vVar1, 1f, -1, 0.25f, 512, iParam2);
			ai::task_play_anim(0, "mini@golfai", "putt_approach_no_ball", 2f, -4f, -1, 0, 0, 0, 0, 0);
			ai::task_play_anim(0, "mini@golfai", "putt_approach_no_ball", 4f, -4f, -1, 2, 0.999f, 0, 0, 0);
		}
		else {
			ai::task_follow_nav_mesh_to_coord(0, vVar1, 1f, -1, 0.25f, 512, iParam2);
		}
		ai::close_sequence_task(uParam0->f_21);
		ai::task_perform_sequence(func_171(uParam0), uParam0->f_21);
		ai::clear_sequence_task(&uParam0->f_21);
	}
	if (bParam7) {
		func_207(uParam0, uParam1);
	}
	if (uParam6 && !func_3(uParam0, 1048576)) {
		func_199(uParam0, uParam1, 0, 0);
	}
}

// Position - 0x750D
void func_199(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	bool bVar2;
	int iVar3;

	iVar0 = func_104(uParam1, func_105(uParam0));
	iVar1 = func_206(uParam1, func_105(uParam0));
	if (iParam3) {
		if (!func_205(func_171(uParam0), iVar0)) {
			return;
		}
	}
	bVar2 = true;
	if (entity::does_entity_exist(func_147(uParam0))) {
		if (iVar1 == entity::get_entity_model(func_147(uParam0))) {
			bVar2 = false;
		}
	}
	if (bVar2) {
		func_202(uParam0, func_203(uParam0, uParam1));
	}
	if (!iParam2 || bVar2) {
		iVar3 = func_171(uParam0);
		if (!ped::is_ped_injured(iVar3)) {
			entity::attach_entity_to_entity(func_147(uParam0), iVar3, ped::get_ped_bone_index(iVar3, 28422),
											func_201(iVar3, iVar0), func_200(iVar3, iVar0), 0, 0, 0, 0, 2, 1);
		}
	}
}

// Position - 0x75C9
Vector3 func_200(int iParam0, int iParam1) {
	iParam0 = iParam0;
	iParam1 = iParam1;
	return 0f, 0f, 0f;
}

// Position - 0x75DC
Vector3 func_201(int iParam0, int iParam1) { return 0f, 0f, 0f; }

// Position - 0x75E7
void func_202(var *uParam0, int iParam1) {
	if (uParam0->f_4 == iParam1) {
		return;
	}
	if (entity::does_entity_exist(uParam0->f_4)) {
		object::delete_object(&uParam0->f_4);
	}
	uParam0->f_4 = iParam1;
}

// Position - 0x7614
int func_203(var *uParam0, var *uParam1) {
	var uVar0;

	func_204(uParam0);
	uVar0 = object::create_object_no_offset(func_206(uParam1, func_105(uParam0)), func_170(uParam0), 0, 1, 0);
	return uVar0;
}

// Position - 0x763F
void func_204(var *uParam0) {
	if (entity::does_entity_exist(uParam0->f_4)) {
		entity::detach_entity(uParam0->f_4, 1, 1);
		object::delete_object(&uParam0->f_4);
	}
}

// Position - 0x7664
int func_205(int iParam0, int iParam1) {
	if (iParam1 >= 1 && iParam1 <= 5) {
		return entity::is_entity_playing_anim(iParam0, func_101(0), "wood_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "wood_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "wood_idle_c", 3);
	}
	else if (iParam1 >= 6 && iParam1 <= 13) {
		return entity::is_entity_playing_anim(iParam0, func_101(0), "iron_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "iron_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "iron_idle_c", 3);
	}
	else if (iParam1 >= 14 && iParam1 <= 18) {
		return entity::is_entity_playing_anim(iParam0, func_101(0), "wedge_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "wedge_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "wedge_idle_c", 3);
	}
	else if (iParam1 == 19) {
		return entity::is_entity_playing_anim(iParam0, func_101(0), "putt_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "putt_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_101(1), "putt_idle_c", 3);
	}
	return 0;
}

// Position - 0x77AC
int func_206(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return joaat("prop_golf_driver");
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return joaat("prop_golf_wood_01");

	case 2: return joaat("prop_golf_wood_01");

	case 3: return joaat("prop_golf_wood_01");

	case 4: return joaat("prop_golf_wood_01");

	case 5: return joaat("prop_golf_wood_01");

	case 6: return joaat("prop_golf_iron_01");

	case 7: return joaat("prop_golf_iron_01");

	case 8: return joaat("prop_golf_iron_01");

	case 9: return joaat("prop_golf_iron_01");

	case 10: return joaat("prop_golf_iron_01");

	case 11: return joaat("prop_golf_iron_01");

	case 12: return joaat("prop_golf_iron_01");

	case 13: return joaat("prop_golf_iron_01");

	case 14: return joaat("prop_golf_pitcher_01");

	case 15: return joaat("prop_golf_pitcher_01");

	case 16: return joaat("prop_golf_pitcher_01");

	case 17: return joaat("prop_golf_pitcher_01");

	case 18: return joaat("prop_golf_pitcher_01");

	case 19: return joaat("prop_golf_putter_01");
	}
	return joaat("prop_golf_driver");
}

// Position - 0x7923
void func_207(var *uParam0, var *uParam1) {
	float fVar0;
	char *sVar1;
	bool bVar2;
	char cVar3[32];
	char cVar11[32];

	sVar1 = func_163(uParam0, uParam1, &fVar0, 0, 0, 0, 0);
	bVar2 = !func_85(sVar1);
	StringCopy(&cVar3, func_103(uParam1, uParam0, 0, 1), 32);
	StringConCat(&cVar3, "idle", 32);
	cVar11 = {cVar3};
	StringConCat(&cVar11, sVar1, 32);
	StringConCat(&cVar11, "_a", 32);
	StringConCat(&cVar3, "_a", 32);
	if (bVar2) {
	}
	func_208(func_171(uParam0), &cVar3, &cVar11, bVar2, fVar0, 1f, 10, 0f, 0f, 0f, 0);
	if (!func_3(uParam0, 32768)) {
		ped::_0x2208438012482A1A(func_171(uParam0), 1, 0);
		ped::_0xED3C76ADFA6D07C4(func_171(uParam0));
		func_48(uParam0, 32768);
	}
}

// Position - 0x79C6
void func_208(int iParam0, char[4] cParam1, char[4] cParam2, bool bParam3, float fParam4, float fParam5, int iParam6,
			  float fParam7, float fParam8, float fParam9, int iParam10) {
	struct<20> Var0;
	struct<21> Var22;

	Var0.f_4 = 1065353216;
	Var0.f_5 = 1065353216;
	Var0.f_9 = 1065353216;
	Var0.f_10 = 1065353216;
	Var0.f_14 = 1065353216;
	Var0.f_15 = 1065353216;
	Var0.f_17 = 1040187392;
	Var0.f_18 = 1040187392;
	Var0.f_19 = -1;
	Var22.f_4 = 1065353216;
	Var22.f_5 = 1065353216;
	Var22.f_9 = 1065353216;
	Var22.f_10 = 1065353216;
	Var22.f_14 = 1065353216;
	Var22.f_15 = 1065353216;
	Var22.f_17 = 1040187392;
	Var22.f_18 = 1040187392;
	Var22.f_19 = -1;
	if (bParam3) {
		Var22 = 2;
		Var22.f_5 = 1f - fParam4;
		Var22.f_10 = fParam4;
		Var22.f_15 = 0f;
		Var22.f_12 = func_209(cParam1);
		Var22.f_11 = func_101(iParam10);
	}
	else {
		Var22 = 1;
	}
	Var22.f_2 = func_209(cParam1);
	Var22.f_1 = func_101(iParam10);
	Var22.f_3 = fParam7;
	Var22.f_4 = fParam5;
	if (bParam3) {
		Var22.f_7 = func_209(cParam2);
		Var22.f_6 = func_101(1);
		Var22.f_8 = fParam7;
		Var22.f_9 = fParam5;
	}
	Var22.f_20 = iParam6;
	ai::task_scripted_animation(iParam0, &Var22, &Var0, &Var0, fParam8, fParam9);
}

// Position - 0x7B0F
var func_209(var uParam0) { return uParam0; }

// Position - 0x7B19
int func_210(vector3 vParam0, float fParam3, int iParam4, int iParam5, int iParam6, int iParam7, int iParam8,
			 int iParam9, int iParam10, int iParam11) {
	vector3 vVar0;
	float fVar3;
	int iVar4;

	Global_17151.f_6 = 1;
	if (streaming::is_player_switch_in_progress() && !iParam9) {
		if (Global_2433125.f_731) {
			func_216(0, iParam9);
		}
		return 0;
	}
	if (streaming::is_new_load_scene_active() && !iParam9 && !player::is_player_teleport_active()) {
		return 0;
	}
	if (!func_215()) {
		if (func_214(player::player_id(), 1, 0)) {
			if (iParam9 && func_213(player::player_id(), 1, 0) && streaming::is_player_switch_in_progress() &&
				Global_2421664[player::player_id() /*358*/].f_225 == 1) {
			}
			else {
				return 0;
			}
		}
	}
	if (fParam3 < 0f) {
		fParam3 += 360f;
	}
	if (fParam3 >= 360f) {
		fParam3 += -360f;
	}
	if (!Global_2433125.f_731 && !iParam11) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 0)};
		if (gameplay::absf(vVar0.x - vParam0.x) < 0.2f && gameplay::absf(vVar0.y - vParam0.y) < 0.2f &&
			gameplay::absf(vVar0.z - vParam0.z) < 1.2f) {
			fVar3 = fParam3 - entity::get_entity_heading(player::player_ped_id());
			if (fVar3 > 180f) {
				fVar3 += -360f;
			}
			if (fVar3 < -180f) {
				fVar3 += 360f;
			}
			if (gameplay::absf(fVar3) < 1f) {
				Global_2433125.f_731 = 0;
				Global_2433125.f_732 = 0;
				if (player::is_player_teleport_active()) {
					player::stop_player_teleport();
				}
				return 1;
			}
		}
	}
	if (vParam0.x != Global_2433125.f_733 || vParam0.y != Global_2433125.f_733.f_1 ||
		vParam0.z != Global_2433125.f_733.f_2 || fParam3 != Global_2433125.f_736) {
		if (Global_2433125.f_731 == 1) {
			if (network::get_time_difference(network::get_network_time(), Global_2433125.f_737) < func_212(0)) {
				return 0;
			}
			player::stop_player_teleport();
			Global_2433125.f_732 = 1;
		}
		else {
			Global_2433125.f_732 = 0;
		}
		Global_2433125.f_733 = {vParam0};
		Global_2433125.f_736 = fParam3;
		Global_2433125.f_731 = 0;
	}
	if (!Global_2433125.f_731 && !player::is_player_teleport_active()) {
		if (iParam4) {
			iParam5 = 0;
		}
		iParam7 = iParam7;
		if (iParam7) {
		}
		if (iParam5) {
		}
		if (iParam8) {
		}
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			if (!gameplay::is_bit_set(Global_91543.f_1308[44], 16)) {
				func_211();
			}
			if (!weapon::get_current_ped_vehicle_weapon(player::player_ped_id(), &Global_2404994.f_490)) {
				Global_2404994.f_490 = 0;
			}
		}
		if (iParam9) {
			if (iParam4) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					iVar4 = ped::get_vehicle_ped_is_using(player::player_ped_id());
					entity::set_entity_coords(iVar4, vParam0, 0, 1, 1, 1);
					entity::set_entity_heading(iVar4, fParam3);
				}
				else {
					entity::set_entity_coords(player::player_ped_id(), vParam0, 0, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), fParam3);
				}
			}
			else {
				entity::set_entity_coords(player::player_ped_id(), vParam0, 0, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), fParam3);
			}
			func_216(iParam6, iParam9);
			return 1;
		}
		else {
			streaming::clear_focus();
			player::start_player_teleport(player::player_id(), vParam0, fParam3, iParam4, iParam10, 0);
		}
		Global_2433125.f_737 = network::get_network_time();
		Global_2433125.f_731 = 1;
	}
	if (Global_2433125.f_731) {
		Global_17151.f_6 = 1;
		Global_2433125.f_737 = network::get_network_time();
		if (iParam9) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), Global_2433125.f_733) < 2f) {
				if (player::is_player_teleport_active()) {
					player::stop_player_teleport();
				}
				func_216(iParam6, iParam9);
				return 1;
			}
		}
		if (!player::is_player_teleport_active()) {
			func_216(iParam6, iParam9);
			return 1;
		}
	}
	return 0;
}

// Position - 0x7EC2
void func_211() {
	int iVar0;

	iVar0 = audio::get_player_radio_station_index();
	if (unk_0x2DD39BF3E2F9C47F() && Global_2404994.f_2219 == 0) {
		iVar0 = 255;
	}
	if (iVar0 != Global_2404994.f_2218) {
		if (!audio::is_radio_retuning()) {
			Global_2404994.f_2218 = iVar0;
		}
	}
}

// Position - 0x7F0B
int func_212(int iParam0) {
	if (cam::is_screen_faded_out()) {
		return 10000;
	}
	if (iParam0) {
		return 5000;
	}
	return 1000;
}

// Position - 0x7F2E
int func_213(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return 0;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return 0;
				}
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x7F78
bool func_214(int iParam0, int iParam1, int iParam2) {
	if (Global_2421664[iParam0 /*358*/].f_225 == 99) {
		if (iParam2 && Global_2421664[iParam0 /*358*/].f_228 == 0 || iParam2 == 0) {
			return false;
		}
	}
	if (iParam1) {
		if (Global_2421664[iParam0 /*358*/].f_225 == 13) {
			return false;
		}
	}
	return true;
}

// Position - 0x7FCF
bool func_215() { return Global_1315210; }

// Position - 0x7FDB
void func_216(int iParam0, bool bParam1) {
	if (!iParam0) {
		cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		cam::set_gameplay_cam_relative_heading(0f);
	}
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		ped::clear_ped_wetness(player::player_ped_id());
	}
	if (!bParam1) {
		streaming::clear_focus();
	}
	if (player::is_player_teleport_active()) {
		player::stop_player_teleport();
	}
	func_218();
	if (!gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_258.f_13, 14)) {
		func_217();
	}
}

// Position - 0x8045
void func_217() { Global_2501682.f_80 = 1; }

// Position - 0x8054
void func_218() {
	struct<2> Var0;

	Global_2433125.f_731 = 0;
	Global_2433125.f_732 = 0;
	Global_2433125.f_733 = {9999.9f, 9999.9f, 9999.9f};
	Global_2404994.f_2220 = {Var0};
}

// Position - 0x8091
Vector3 func_219(int iParam0) {
	if (iParam0 <= 5) {
		return 0.11f, -1.08f, 0f;
	}
	if (iParam0 <= 13) {
		return 0.11f, -0.81f, 0f;
	}
	if (iParam0 != 19) {
		return 0.03f, -0.75f, 0f;
	}
	return 0.1f, -0.55f, 0f;
}

// Position - 0x80EB
void func_220(var *uParam0, var uParam1) { uParam0->f_14 = uParam1; }

// Position - 0x80F9
void func_221(var *uParam0, var *uParam1, var *uParam2, int iParam3) {
	float fVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	float fVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	fVar0 = func_232(uParam2);
	fVar3 = -9999f;
	fVar4 = -1f;
	if (func_157(uParam1, uParam2) || func_234()) {
		if (func_231(uParam1, uParam2, 0)) {
			func_229(uParam2, 7);
		}
		else if (fVar0 < 5f) {
			func_229(uParam2, 4);
		}
		else if (fVar0 < 9.5f) {
			func_229(uParam2, 5);
		}
		else {
			func_229(uParam2, 6);
		}
		func_273(uParam2, func_275(uParam0, 19));
		if (func_122(uParam2) != -1) {
			return;
		}
	}
	else if (func_228(uParam2)) {
		func_229(uParam2, 0);
		func_273(uParam2, func_275(uParam0, 16));
		if (func_122(uParam2) != -1) {
			return;
		}
	}
	else if (func_227(uParam1, uParam2, iParam3)) {
		func_229(uParam2, 3);
	}
	else {
		func_229(uParam2, 0);
	}
	func_224(uParam1, uParam2, &iVar5, &iVar6, 0);
	fVar4 = func_195(uParam0, func_275(uParam0, iVar6));
	if (func_118(uParam2) == 3 || func_118(uParam2) == 2) {
		fVar4 *= func_223();
	}
	if (fVar4 > fVar0) {
		func_273(uParam2, func_275(uParam0, iVar6));
		return;
	}
	iVar2 = -1;
	iVar1 = 0;
	while (iVar1 < *uParam0) {
		iVar7 = func_104(uParam0, iVar1);
		if (iVar7 >= iVar5 && iVar7 <= iVar6) {
			fVar4 = func_195(uParam0, iVar1);
			if (func_118(uParam2) == 3 || func_118(uParam2) == 2) {
				fVar4 *= func_223();
			}
			if ((*uParam0)[iVar1] >= 14) {
				fVar4 *= 0.75f;
			}
			if (func_222(uParam1, uParam2)) {
				if (func_293(uParam2) == 2) {
					fVar4 *= 1.1f;
				}
				else if (func_293(uParam2) == 3) {
					fVar4 *= 2.25f;
				}
			}
			fVar4 -= fVar0;
			if (fVar4 < 0f && fVar4 > fVar3) {
				iVar2 = iVar1;
				fVar3 = fVar4;
			}
		}
		iVar1++;
	}
	if (iVar2 != -1) {
		func_273(uParam2, iVar2);
		return;
	}
	func_273(uParam2, func_275(uParam0, iVar5));
}

// Position - 0x8316
bool func_222(var *uParam0, var *uParam1) {
	if (func_293(uParam1) < 0 || func_293(uParam1) >= func_42(uParam0)) {
		return false;
	}
	if (func_31(uParam1) != 5) {
		return false;
	}
	return true;
}

// Position - 0x834F
float func_223() { return 0.935f; }

// Position - 0x835C
void func_224(var *uParam0, var *uParam1, int *iParam2, int *iParam3, int iParam4) {
	if (func_157(uParam0, uParam1)) {
		*iParam2 = 14;
		*iParam3 = 19;
	}
	else if (func_228(uParam1)) {
		*iParam2 = 7;
		*iParam3 = 17;
	}
	else if (func_227(uParam0, uParam1, 1)) {
		*iParam2 = 7;
		if (iParam4) {
			*iParam3 = 19;
		}
		else {
			*iParam3 = 17;
		}
	}
	else if (func_226(uParam1)) {
		*iParam2 = 7;
		*iParam3 = 17;
	}
	else if (func_222(uParam0, uParam1)) {
		*iParam2 = 1;
		*iParam3 = 17;
	}
	else if (func_225(uParam1)) {
		*iParam2 = 3;
		*iParam3 = 17;
	}
	else {
		*iParam2 = 7;
		*iParam3 = 17;
	}
}

// Position - 0x8400
bool func_225(var *uParam0) {
	if (func_31(uParam0) != 2) {
		return false;
	}
	return true;
}

// Position - 0x8417
bool func_226(var *uParam0) {
	if (func_31(uParam0) != 4) {
		return false;
	}
	return true;
}

// Position - 0x842E
bool func_227(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	vector3 vVar1;

	if (func_255(uParam1) < 0) {
		return false;
	}
	iVar0 = func_269(uParam1);
	if (iParam2) {
		if (!entity::does_entity_exist(iVar0)) {
			return false;
		}
		vVar1 = {entity::get_entity_coords(func_269(uParam1), 0)};
	}
	else {
		vVar1 = {func_239(uParam1)};
	}
	if (system::vdist2(vVar1, func_43(uParam0, func_293(uParam1))) > 55f * 55f) {
		return false;
	}
	return true;
}

// Position - 0x84A3
bool func_228(var *uParam0) {
	if (func_31(uParam0) != 0) {
		return false;
	}
	return true;
}

// Position - 0x84BA
void func_229(var *uParam0, int iParam1) { func_230(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x84D2
void func_230(var *uParam0, var uParam1) { uParam0->f_19 = uParam1; }

// Position - 0x84E0
bool func_231(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;

	if (!func_157(uParam0, uParam1)) {
		return false;
	}
	vVar0 = {func_239(uParam1)};
	if (iParam2) {
		if (entity::does_entity_exist(func_269(uParam1))) {
			vVar0 = {entity::get_entity_coords(func_269(uParam1), 1)};
		}
	}
	if (system::vdist2(vVar0, func_43(uParam0, func_293(uParam1))) > 0.7f * 0.7f) {
		return false;
	}
	return true;
}

// Position - 0x854B
float func_232(var *uParam0) { return func_192(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x8561
int func_233(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0;
	}
	return (*uParam0)[iParam1 /*3*/].f_1;
}

// Position - 0x8589
int func_234() {
	if (bLocal_0) {
	}
	return 1;
	return 0;
}

// Position - 0x859B
void func_235(var *uParam0, int iParam1) { func_236(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x85B3
void func_236(var *uParam0, var uParam1) { uParam0->f_3 = uParam1; }

// Position - 0x85C1
int func_237(vector3 vParam0, float fParam3) {
	int iVar0;

	if (func_112(vParam0, 0f, 0f, 0f, 1056964608, 0)) {
		return 0;
	}
	iVar0 = object::create_object(joaat("prop_golf_ball"), vParam0, 1, 1, 0);
	object::_0xC6033D32241F6FB5(iVar0, 1);
	entity::_set_entity_register(iVar0, 0);
	entity::set_entity_heading(iVar0, fParam3);
	if (bLocal_0) {
	}
	return iVar0;
}

// Position - 0x8610
float func_238(struct<2> Param0, Vector3 vParam2, struct<2> Param3, var uParam5) {
	return gameplay::get_heading_from_vector_2d(Param3 - Param0, Param3.f_1 - Param0.f_1);
}

// Position - 0x862A
Vector3 func_239(var *uParam0) { return func_170(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x8640
Vector3 func_240(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0: return -1329.875f, 35.458f, 52.677f;

	case 1: return -1329.26f, 52.557f, 52.677f;

	case 2: return -1330.135f, 68.521f, 52.736f;

	case 3: return -1334.394f, 82.867f, 53.703f;

	case 4: return -1332.059f, 95.877f, 54.98f;

	case 5: return -1336.215f, 103.347f, 55.392f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x870E
int func_241(var *uParam0, float fParam1, float fParam2) {
	float fVar0;

	if (gameplay::get_ground_z_for_3d_coord(*uParam0 + Vector(fParam2, 0f, 0f), &fVar0, 0)) {
		if (gameplay::absf(uParam0->f_2 - fVar0) < fParam1) {
			uParam0->f_2 = fVar0;
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x874C
bool func_242(var *uParam0) {
	float fVar0;

	if (!entity::does_entity_exist(func_171(uParam0))) {
		return false;
	}
	fVar0 = system::vdist2(entity::get_entity_coords(func_171(uParam0), 1), func_170(uParam0));
	if (fVar0 < 4f * 4f || func_3(uParam0, 512))
		&&!ped::is_ped_ragdoll(func_171(uParam0)) && !entity::is_entity_in_air(func_171(uParam0)) &&
			!ai::is_ped_getting_up(func_171(uParam0)) {
			return true;
		}
	if (ped::is_ped_in_any_vehicle(func_171(uParam0), 0)) {
		if (fVar0 < 12f * 12f) {
			return true;
		}
	}
	return false;
}

// Position - 0x87ED
void func_243(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_277(uParam1)) {
		func_244(uParam0, uParam1, iVar0);
		iVar0++;
	}
}

// Position - 0x8816
void func_244(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;
	int iVar3;
	vector3 vVar4;
	float *fVar7;

	if (func_28(&uParam1->f_15[iParam2 /*34*/]) != 4) {
		return;
	}
	if (!entity::does_entity_exist(func_171(&uParam1->f_15[iParam2 /*34*/]))) {
		return;
	}
	if (entity::is_entity_dead(func_171(&uParam1->f_15[iParam2 /*34*/]), 0)) {
		return;
	}
	if (func_28(&uParam1->f_15[iParam2 /*34*/]) == 3) {
		return;
	}
	vVar0 = {func_170(&uParam1->f_15[iParam2 /*34*/])};
	iVar3 = func_183(uParam1, iParam2);
	if (func_222(uParam0, uParam1)) {
		vVar0 = {func_38(uParam0, func_293(uParam1), iParam2)};
	}
	if (ped::is_ped_in_group(iVar3) || system::vmag2(vVar0) == 0f) {
		return;
	}
	if (func_27(uParam1, iParam2, 1048576)) {
		if (bLocal_0) {
		}
		if (!cam::is_sphere_visible(vVar0, 5f)) {
			entity::set_entity_coords(func_171(&uParam1->f_15[iParam2 /*34*/]), vVar0, 0, 0, 0, 1);
		}
		vVar4 = {0f, 0f, 0f};
		fVar7 = 0f;
		if (entity::does_entity_exist(func_36(uParam1, 0))) {
			if (!entity::is_entity_dead(func_36(uParam1, 0), 0)) {
				if (func_180(func_184(uParam1, 0), func_43(uParam0, func_293(uParam1)), &vVar4, &fVar7, 0f, 0f, 0f, 0f,
							 0f, 0f, 0)) {
					if (!cam::is_sphere_visible(vVar4, 5f)) {
						entity::set_entity_coords(func_36(uParam1, 0), vVar4, 1, 0, 0, 1);
						entity::set_entity_heading(func_36(uParam1, 0), fVar7);
					}
				}
			}
		}
	}
	else if (ai::get_script_task_status(iVar3, 242628503) != 1 && ai::get_script_task_status(iVar3, 242628503) != 0) {
		if (func_27(uParam1, iParam2, 4194304) && entity::does_entity_exist(func_269(uParam1))) {
			vVar0 = {entity::get_entity_coords(func_269(uParam1), 1)};
		}
		else if (func_155(uParam1, iParam2) == 10 || func_155(uParam1, iParam2) == 8 ||
				 func_32(&uParam1->f_15[iParam2 /*34*/]) == 3) {
			if (func_32(&uParam1->f_15[iParam2 /*34*/]) == 3 || func_155(uParam1, iParam2) == 10 ||
				func_155(uParam1, iParam2) == 8 ||
				func_32(&uParam1->f_15[iParam2 /*34*/]) == 8 && func_248(uParam1, uParam0) != iParam2) {
				vVar0 = {func_44(uParam0, func_293(uParam1), iParam2)};
				func_276(uParam1, iParam2, 67108864);
			}
			else {
				vVar0 = {func_170(&uParam1->f_15[iParam2 /*34*/])};
			}
		}
		if (system::vdist2(vVar0, entity::get_entity_coords(iVar3, 1)) > 1.5f) {
			ai::clear_ped_tasks(iVar3);
			ai::open_sequence_task(&uParam1->f_15[iParam2 /*34*/].f_21);
			ai::task_follow_nav_mesh_to_coord(0, vVar0, 1f, -1, 0.25f, 4,
											  func_247(vVar0, func_43(uParam0, func_293(uParam1))));
			ai::close_sequence_task(uParam1->f_15[iParam2 /*34*/].f_21);
			ai::task_perform_sequence(iVar3, uParam1->f_15[iParam2 /*34*/].f_21);
			ai::clear_sequence_task(&uParam1->f_15[iParam2 /*34*/].f_21);
		}
		if (func_246(uParam1, iParam2) != 4) {
			func_245(uParam1, 32);
		}
	}
}

// Position - 0x8B1B
void func_245(var *uParam0, int iParam1) {
	if (uParam0->f_165 < 0 || uParam0->f_165 >= uParam0->f_15) {
		return;
	}
	func_48(&uParam0->f_15[uParam0->f_165 /*34*/], iParam1);
}

// Position - 0x8B4E
int func_246(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_28(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x8B7A
var func_247(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
	return gameplay::get_heading_from_vector_2d(Param3 - Param0, Param3.f_1 - Param0.f_1);
}

// Position - 0x8B94
int func_248(var *uParam0, var *uParam1) {
	float fVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	vector3 vVar4;
	vector3 vVar7;

	fVar0 = 0f;
	iVar1 = -1;
	if (func_232(uParam0) < 0.7f * 0.7f && func_31(uParam0) == 3 && func_29(uParam0) != 10 &&
		func_249(uParam0, uParam1)) {
		return func_255(uParam0);
	}
	iVar2 = 0;
	while (iVar2 < func_277(uParam0)) {
		if (func_246(uParam0, iVar2) != 0) {
			if (func_155(uParam0, iVar2) != 10 && !func_27(uParam0, iVar2, 16777216)) {
				vVar4 = {func_184(uParam0, iVar2)};
				vVar7 = {func_43(uParam1, func_293(uParam0))};
				vVar4.z = 0f;
				vVar7.z = 0f;
				fVar3 = system::vdist(vVar4, vVar7);
				fVar3 *= func_114(func_32(&uParam0->f_15[iVar2 /*34*/]) == 3, 1f, 99999f);
				fVar3 *= func_114(func_32(&uParam0->f_15[iVar2 /*34*/]) == 5, 100f, 1f);
				fVar3 *= IntToFloat(uParam0->f_15[iVar2 /*34*/].f_32 + 1);
				if (fVar3 > fVar0) {
					iVar1 = iVar2;
					fVar0 = fVar3;
				}
			}
		}
		iVar2++;
	}
	if (iVar1 == -1) {
		iVar1 = 0;
	}
	if (bLocal_0) {
	}
	return iVar1;
}

// Position - 0x8CCC
int func_249(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_277(uParam0)) {
		if (func_32(&uParam0->f_15[iVar0 /*34*/]) != 3 && func_32(&uParam0->f_15[iVar0 /*34*/]) != 8 &&
			func_155(uParam0, iVar0) != 10 && !func_27(uParam0, iVar0, 16384) &&
			!func_250(uParam0, uParam1, iVar0, 0) && !func_27(uParam0, iVar0, 16777216)) {
			return 0;
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x8D5A
bool func_250(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (iParam2 == -1) {
		iParam2 = func_255(uParam0);
	}
	return func_251(uParam0, iParam2) >= func_233(uParam1, func_293(uParam0)) + 5 + iParam3;
}

// Position - 0x8D8A
int func_251(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_50(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x8DB6
void func_252(var *uParam0, var *uParam1) {
	int iVar0;

	if (entity::does_entity_exist(func_146(uParam0))) {
		iVar0 = func_104(uParam1, func_122(uParam0));
		entity::attach_entity_to_entity(func_146(uParam0), func_271(uParam0),
										ped::get_ped_bone_index(func_271(uParam0), 28422), 0f, 0f, 0f, 0f, 0f, 0f, 0, 0,
										0, 0, 2, 1);
	}
}

// Position - 0x8E02
int func_253(var *uParam0) { return *uParam0; }

// Position - 0x8E0D
void func_254(var *uParam0, int iParam1, var *uParam2, int iParam3, var *uParam4) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	var uVar9;
	vector3 vVar10;
	float fVar13;
	vector3 vVar14;
	vector3 vVar17;

	if (!entity::does_entity_exist(func_171(uParam0))) {
		return;
	}
	if (entity::is_entity_dead(func_171(uParam0), 0) || ped::is_ped_injured(func_171(uParam0))) {
		return;
	}
	if (!entity::does_entity_exist(iParam1)) {
		return;
	}
	if (ai::get_script_task_status(func_171(uParam0), -1794415470) == 1) {
		return;
	}
	vVar0 = {func_170(uParam0)};
	vVar3 = {entity::get_entity_coords(iParam1, 1)};
	vVar6 = {entity::get_entity_coords(func_171(uParam0), 1)};
	if (system::vdist2(vVar6, vVar3) > 150f * 150f && system::vdist2(vVar0, vVar3) > 150f * 150f) {
		if (!func_3(uParam0, 1048576)) {
			ped::set_ped_gravity(uParam0->f_2, 0);
			ped::set_ped_can_ragdoll(uParam0->f_2, 0);
		}
		func_48(uParam0, 1048576);
	}
	else {
		if (func_3(uParam0, 1048576)) {
			ped::set_ped_gravity(uParam0->f_2, 1);
			ped::set_ped_can_ragdoll(uParam0->f_2, 1);
		}
		func_46(uParam0, 1048576);
	}
	if (system::vdist2(vVar0, vVar3) > 150f * 150f) {
		func_48(uParam0, 262144);
		if (vVar0.z > 100f) {
			if (entity::does_entity_exist(uParam0->f_3)) {
				if (!entity::is_entity_dead(uParam0->f_3, 0)) {
					entity::set_entity_coords(uParam0->f_3, vVar0.x, vVar0.y, 50f, 1, 0, 0, 1);
				}
			}
		}
	}
	else {
		if (func_3(uParam0, 262144)) {
			if (entity::does_entity_exist(uParam0->f_3)) {
				if (!entity::is_entity_dead(uParam0->f_3, 0)) {
					vVar10 = {uParam0->f_7 + Vector(50f, 0f, 0f)};
					if (gameplay::get_ground_z_for_3d_coord(vVar10, &uVar9, 0)) {
						uParam0->f_7.f_2 = uVar9;
						entity::set_entity_coords(uParam0->f_3, uParam0->f_7, 1, 0, 0, 1);
					}
				}
			}
			if (func_4(uParam0) == 5) {
				func_25(uParam0, 6, 0);
			}
			func_46(uParam0, 262144);
		}
		if (func_3(uParam0, 524288) && func_154(uParam2, -1)) {
			fVar13 = system::vdist(vVar6, vVar0);
			vVar14 = {func_64(vVar0 - vVar6)};
			vVar17 = {vVar6 + vVar14 * FtoV(fVar13) * FtoV(0.5f)};
			func_179(uParam2, iParam3, vVar17, uParam4, 1, 1);
			if (ai::get_script_task_status(func_171(uParam0), 1435919172) == 1) {
				ai::clear_ped_tasks(func_171(uParam0));
			}
		}
	}
	if (system::vdist2(vVar6, vVar3) > 150f * 150f) {
		func_48(uParam0, 524288);
		if (func_3(uParam0, 262144) && iParam3 == func_255(uParam2)) {
			if (ai::get_script_task_status(uParam0->f_2, 1435919172) == 1) {
				ai::clear_ped_tasks(uParam0->f_2);
			}
			func_256(uParam2, 2);
		}
	}
	else if (func_3(uParam0, 524288)) {
		if (func_3(uParam0, 262144) && func_154(uParam2, -1)) {
			func_178(uParam2, iParam3, uParam4, 1, 1);
			if (ai::get_script_task_status(uParam0->f_2, 1435919172) == 1) {
				ai::clear_ped_tasks(uParam0->f_2);
			}
			func_256(uParam2, 5);
			if (func_222(uParam4, uParam2)) {
				func_25(uParam0, 0, 0);
			}
			else {
				func_25(uParam0, 1, 0);
			}
		}
		else {
			func_154(uParam2, -1);
			if (gameplay::get_ground_z_for_3d_coord(vVar6, &uVar9, 0)) {
				vVar6.z = uVar9;
				entity::set_entity_coords(uParam0->f_2, vVar6, 1, 0, 0, 1);
			}
		}
		func_46(uParam0, 524288);
	}
}

// Position - 0x9184
int func_255(var *uParam0) { return uParam0->f_157; }

// Position - 0x9190
void func_256(var *uParam0, int iParam1) { *uParam0 = iParam1; }

// Position - 0x919D
int func_257(int iParam0, int iParam1, var *uParam2, int *iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	int iVar0;
	bool bVar1;

	iVar0 = player::player_ped_id();
	if (!entity::is_entity_dead(iVar0, 0) && !entity::is_entity_dead(iParam0, 0)) {
		if (!func_266(*uParam2, 1)) {
			if (func_265(iParam0, uParam2)) {
				*iParam3 = 1;
				return 1;
			}
		}
		if (!func_266(*uParam2, 2)) {
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				*iParam3 = 2;
				return 1;
			}
		}
		if (!func_266(*uParam2, 4)) {
			if (func_263(iVar0, iParam0, uParam2, iParam5)) {
				*iParam3 = 4;
				return 1;
			}
		}
		if (!func_266(*uParam2, 8)) {
			if (func_262(iVar0, iParam0, uParam2)) {
				*iParam3 = 8;
				return 1;
			}
		}
		bVar1 = !func_266(*uParam2, 128);
		if (iParam4) {
			if (func_258(iParam0, iParam1, 1, iParam6, bVar1, 1)) {
				*iParam3 = 32;
				return 1;
			}
		}
		else if (!func_266(*uParam2, 16)) {
			if (func_258(iParam0, iParam1, 0, iParam6, bVar1, iParam8)) {
				*iParam3 = 16;
				return 1;
			}
		}
	}
	else if (entity::does_entity_exist(iParam0)) {
		if (iParam7 && entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
			*iParam3 = 16;
			return 1;
		}
	}
	return 0;
}

// Position - 0x92C7
bool func_258(int iParam0, int iParam1, int iParam2, bool bParam3, bool bParam4, int iParam5) {
	int iVar0;
	int iVar1;

	if (bParam3) {
		if (!bLocal_254) {
			iLocal_255 = entity::get_entity_health(iParam0);
			bLocal_254 = true;
		}
		iLocal_256 = entity::get_entity_health(iParam0);
		iLocal_257 = iLocal_255 - iLocal_256;
		iVar0 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
				if (IntToFloat(iLocal_257) > 100f) {
					return true;
				}
			}
		}
		if (bLocal_254) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
				if (IntToFloat(iLocal_257) > 100f) {
					return true;
				}
			}
		}
	}
	else if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
		return true;
	}
	if (!bParam3) {
		iVar1 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar1, 1)) {
				return true;
			}
		}
	}
	if (bParam4) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (ped::is_ped_being_jacked(iParam0)) {
				if (ped::get_peds_jacker(iParam0) == player::player_ped_id()) {
					return true;
				}
			}
		}
	}
	if (iParam5) {
		if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
			if (entity::is_entity_at_coord(iParam0, entity::get_entity_coords(player::player_ped_id(), 1), 10f, 10f,
										   10f, 0, 1, 0)) {
				if (player::has_player_damaged_at_least_one_ped(player::player_id())) {
					return true;
				}
			}
		}
	}
	if (ped::is_ped_performing_stealth_kill(player::player_ped_id())) {
		if (ped::was_ped_killed_by_stealth(iParam0)) {
			return true;
		}
	}
	if (func_261(player::player_ped_id(), iParam0)) {
		return true;
	}
	if (iParam2) {
		if (ped::is_ped_ragdoll(iParam0) && func_259(iParam0, 1) < 1.5f) {
			return true;
		}
		else if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			if (entity::is_entity_touching_entity(player::player_ped_id(), ped::get_vehicle_ped_is_in(iParam0, 0))) {
				return true;
			}
		}
		else if (entity::is_entity_touching_entity(player::player_ped_id(), iParam0)) {
			return true;
		}
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam1, player::player_ped_id(), 1)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x9494
float func_259(int iParam0, int iParam1) {
	return func_260(player::get_player_ped(player::get_player_index()), iParam0, iParam1);
}

// Position - 0x94AC
float func_260(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x950A
bool func_261(int iParam0, int iParam1) {
	int iVar0;

	weapon::get_current_ped_weapon(iParam0, &iVar0, 1);
	if (iVar0 == joaat("weapon_petrolcan")) {
		if (ped::is_ped_shooting(iParam0)) {
			if (system::vdist(entity::get_entity_coords(iParam0, 1), entity::get_entity_coords(iParam1, 1)) < 2.5f) {
				if (ped::is_ped_facing_ped(iParam0, iParam1, 180f)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x955F
bool func_262(int iParam0, int iParam1, var *uParam2) {
	if (weapon::is_ped_armed(iParam0, 4)) {
		if (ped::is_ped_shooting(iParam0) && !weapon::is_ped_current_weapon_silenced(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_4),
										   IntToFloat(uParam2->f_4), IntToFloat(uParam2->f_4), 0, 1, 0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x95AD
bool func_263(int iParam0, int iParam1, var *uParam2, bool bParam3) {
	vector3 vVar0;
	int iVar3;

	iVar3 = 0;
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar0 = {entity::get_entity_coords(iParam1, 1)};
	}
	if (gameplay::is_bullet_in_area(vVar0, 4f, 1)) {
		return true;
	}
	if (gameplay::has_bullet_impacted_in_area(vVar0, system::to_float(uParam2->f_6), 1, 1)) {
		return true;
	}
	if (weapon::is_ped_armed(iParam0, 2)) {
		if (ped::is_ped_shooting(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_6 * 3),
										   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
				if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
					entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
					return true;
				}
			}
		}
		else {
			if (ped::is_ped_in_any_vehicle(entity::get_ped_index_from_entity_index(iParam1), 0)) {
				iVar3 = ped::get_vehicle_ped_is_in(entity::get_ped_index_from_entity_index(iParam1), 0);
			}
			if (ped::is_ped_planting_bomb(iParam0) || func_264(iVar3)) {
				if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1),
											   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3),
											   IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
					if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
						entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
						return true;
					}
				}
			}
		}
	}
	if (bParam3) {
		if (gameplay::is_projectile_in_area(vVar0.x - IntToFloat(uParam2->f_6), vVar0.y - IntToFloat(uParam2->f_6),
											vVar0.z - IntToFloat(uParam2->f_6), vVar0.x + IntToFloat(uParam2->f_6),
											vVar0.y + IntToFloat(uParam2->f_6), vVar0.z + IntToFloat(uParam2->f_6),
											0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x9726
int func_264(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0) != 0) {
				if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
					if (iVar0 == joaat("weapon_stickybomb")) {
						if (func_260(player::player_ped_id(), iParam0, 1) < 40f) {
							if (player::get_entity_player_is_free_aiming_at(player::player_id(), &iVar1)) {
								if (entity::is_entity_a_vehicle(iVar1) &&
										entity::get_vehicle_index_from_entity_index(iVar1) == iParam0 ||
									entity::is_entity_a_ped(iVar1) &&
										entity::get_ped_index_from_entity_index(iVar1) ==
											vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0)) {
									if (ped::is_ped_on_foot(player::player_ped_id()) &&
											controls::is_control_pressed(0, 24) ||
										ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
											controls::is_control_pressed(0, 69)) {
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x97F4
bool func_265(int iParam0, var *uParam1) {
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (weapon::is_ped_armed(player::player_ped_id(), 6)) {
			if (player::is_player_free_aiming_at_entity(player::player_id(), iParam0) ||
				player::is_player_targetting_entity(player::player_id(), iParam0)) {
				if (ped::is_ped_facing_ped(iParam0, player::player_ped_id(), 90f)) {
					if (func_259(iParam0, 1) < uParam1->f_2) {
						if (uParam1->f_1 == 0) {
							uParam1->f_1 = gameplay::get_game_timer();
						}
						else if (gameplay::get_game_timer() - uParam1->f_1 > uParam1->f_3) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x9879
bool func_266(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x9888
void func_267(var *uParam0) { func_268(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x989E
void func_268(var *uParam0) {
	if (func_3(uParam0, 128)) {
		streaming::clear_focus();
		func_46(uParam0, 128);
	}
	if (entity::does_entity_exist(uParam0->f_3)) {
		if (streaming::is_entity_focus(uParam0->f_3)) {
			streaming::clear_focus();
		}
		if (entity::is_entity_a_mission_entity(uParam0->f_3)) {
			object::delete_object(&uParam0->f_3);
		}
	}
	uParam0->f_3 = 0;
}

// Position - 0x98EF
int func_269(var *uParam0) { return func_270(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x9905
var func_270(var *uParam0) { return uParam0->f_3; }

// Position - 0x9911
int func_271(var *uParam0) {
	if (uParam0->f_157 < 0) {
		return 0;
	}
	return func_171(&uParam0->f_15[uParam0->f_157 /*34*/]);
}

// Position - 0x9933
void func_272(var *uParam0, int iParam1) { uParam0->f_22 -= (uParam0->f_22 & iParam1); }

// Position - 0x994B
void func_273(var *uParam0, int iParam1) { func_274(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x9963
void func_274(var *uParam0, var uParam1) { uParam0->f_17 = uParam1; }

// Position - 0x9971
int func_275(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < uParam0->f_15) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x999F
void func_276(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_48(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0x99CC
int func_277(var *uParam0) { return uParam0->f_156; }

// Position - 0x99D8
void func_278(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	func_287(uParam0, uParam1, iParam3, iParam2);
	iVar0 = 0;
	while (iVar0 < func_277(uParam1)) {
		func_281(uParam0, uParam1, iVar0);
		iVar0++;
	}
	if (iParam4) {
		func_279(uParam0, uParam1, iParam3, iParam2);
	}
}

// Position - 0x9A1E
void func_279(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	vector3 vVar0;
	float *fVar3;
	int iVar4;
	vector3 vVar5;

	vVar5 = {0f, 0f, 0f};
	iVar4 = 0;
	while (iVar4 < iParam3 + 1 / 2) {
		if (!entity::does_entity_exist(func_36(uParam1, iVar4))) {
			if (iVar4 == 1) {
				vVar5 = {FtoV(10f) * entity::get_entity_forward_vector(func_36(uParam1, 0))};
			}
			if (func_182(func_292(uParam0, iParam2) + vVar5, func_43(uParam0, func_293(uParam1)), &vVar0, &fVar3)) {
				func_280(uParam1, vehicle::create_vehicle(joaat("caddy"), vVar0, fVar3, 1, 1), iVar4);
				vehicle::set_vehicle_extra(func_36(uParam1, iVar4), 5, 1);
				entity::_set_entity_register(func_36(uParam1, iVar4), 1);
			}
		}
		iVar4++;
	}
}

// Position - 0x9AC8
void func_280(var *uParam0, var uParam1, int iParam2) { uParam0->f_152[iParam2] = uParam1; }

// Position - 0x9ADA
void func_281(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;
	int iVar3;
	int *iVar4;

	iVar4 = 3;
	func_285(uParam1, iParam2, 4);
	if (iParam2 == 0) {
		vVar0 = {func_292(uParam0, func_293(uParam1))};
	}
	else {
		vVar0 = {func_38(uParam0, func_293(uParam1), iParam2)};
	}
	if (!entity::does_entity_exist(func_183(uParam1, iParam2))) {
		iVar3 = func_284(&iVar4, 1065437102);
		func_282(uParam1, iParam2, ped::create_ped(iVar4, iVar3, vVar0, 0f, 1, 1));
		entity::set_entity_heading(func_183(uParam1, iParam2), func_238(vVar0, func_292(uParam0, func_293(uParam1))));
		if (streaming::has_anim_set_loaded("move_m@golfer@")) {
			ped::set_ped_weapon_movement_clipset(func_183(uParam1, iParam2), "move_m@golfer@");
		}
		ped::_0x2F3C3D9F50681DE4(func_183(uParam1, iParam2), 1);
	}
}

// Position - 0x9B91
void func_282(var *uParam0, int iParam1, var uParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_283(&uParam0->f_15[iParam1 /*34*/], uParam2);
}

// Position - 0x9BBE
void func_283(var *uParam0, var uParam1) { uParam0->f_2 = uParam1; }

// Position - 0x9BCC
int func_284(int *iParam0, float fParam1) {
	if (gameplay::get_random_float_in_range(0f, 1f) < fParam1) {
		*iParam0 = 4;
		return joaat("a_m_y_golfer_01");
	}
	*iParam0 = 5;
	return joaat("a_f_y_golfer_01");
}

// Position - 0x9BF9
void func_285(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_286(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0x9C26
void func_286(var *uParam0, var uParam1) { uParam0->f_1 = uParam1; }

// Position - 0x9C34
void func_287(var *uParam0, var *uParam1, var uParam2, var uParam3) {
	func_21(uParam1, uParam2);
	func_290(uParam1, uParam3);
	func_289(uParam1, 0, 0);
	func_289(uParam1, 2, 1);
	func_288(uParam1, 0);
	func_7(uParam0, uParam1);
	func_20(uParam1, 0);
	func_256(uParam1, 2);
}

// Position - 0x9C79
void func_288(var *uParam0, int iParam1) { uParam0->f_165 = iParam1; }

// Position - 0x9C87
void func_289(var *uParam0, int iParam1, int iParam2) { uParam0->f_167[iParam2] = iParam1; }

// Position - 0x9C99
void func_290(var *uParam0, var uParam1) { uParam0->f_156 = uParam1; }

// Position - 0x9CA7
bool func_291(int iParam0) { return (Global_100728.f_1 & iParam0) != 0; }

// Position - 0x9CBA
Vector3 func_292(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	return func_18(iParam1);
}

// Position - 0x9CE2
int func_293(var *uParam0) { return uParam0->f_158; }

// Position - 0x9CEE
bool func_294(int iParam0) { return iParam0 > 6 && iParam0 < 18; }

// Position - 0x9D04
void func_295(var *uParam0) {
	func_296(uParam0, 1);
	func_296(uParam0, 3);
	func_296(uParam0, 5);
	func_296(uParam0, 7);
	func_296(uParam0, 8);
	func_296(uParam0, 9);
	func_296(uParam0, 10);
	func_296(uParam0, 11);
	func_296(uParam0, 12);
	func_296(uParam0, 13);
	func_296(uParam0, 14);
	func_296(uParam0, 16);
	func_296(uParam0, 17);
	func_296(uParam0, 19);
}

// Position - 0x9D86
int func_296(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = *uParam0;
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if ((*uParam0)[iVar0] == 0) {
			func_297(&(*uParam0)[iVar0], iParam1);
			uParam0->f_15++;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x9DCB
void func_297(var *uParam0, var uParam1) { *uParam0 = uParam1; }

// Position - 0x9DD8
int func_298(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				}
				return 0;
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x9E1F
void func_299(var *uParam0) {
	func_301(uParam0, joaat("a_m_y_golfer_01"));
	func_301(uParam0, joaat("prop_golf_putter_01"));
	func_301(uParam0, joaat("prop_golf_ball"));
	func_301(uParam0, joaat("prop_golf_pitcher_01"));
	func_300(uParam0);
}

// Position - 0x9E5D
void func_300(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			streaming::request_model((*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x9E8D
int func_301(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if ((*uParam0)[iVar0] == iParam1) {
				return 0;
			}
		}
		iVar0++;
	}
	iVar1 = func_302(uParam0);
	if (iVar1 < 0 || iVar1 >= *uParam0) {
		return 0;
	}
	(*uParam0)[iVar1] = iParam1;
	return 1;
}

// Position - 0x9EEA
int func_302(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x9F16
char *func_303() { return "MINI@GOLFAI"; }

// Position - 0x9F22
void func_304(var *uParam0) {
	uParam0->f_28 = 6;
	func_305(uParam0);
}

// Position - 0x9F35
void func_305(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < func_42(uParam0)) {
		(*uParam0)[iVar0 /*3*/] = system::vdist(func_292(uParam0, iVar0), func_240(uParam0, iVar0)) +
								  system::vdist(func_240(uParam0, iVar0), func_43(uParam0, iVar0));
		if ((*uParam0)[iVar0 /*3*/] < 35f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 1;
		}
		else if ((*uParam0)[iVar0 /*3*/] < 125f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 3;
		}
		else if ((*uParam0)[iVar0 /*3*/] < 260f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 4;
		}
		else {
			(*uParam0)[iVar0 /*3*/].f_1 = 5;
		}
		iVar1 += (*uParam0)[iVar0 /*3*/].f_1;
		func_306(uParam0, iVar1);
		iVar0++;
	}
}

// Position - 0x9FF2
void func_306(var *uParam0, int iParam1) { uParam0->f_29 = iParam1; }

// Position - 0xA000
void func_307(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *iParam0) {
		iVar1 = 0;
		while (iVar1 < func_277(&(*iParam0)[iVar0 /*170*/])) {
			func_309(&(*iParam0)[iVar0 /*170*/], iVar1);
			func_204(&(*iParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/]);
			func_308(&(*iParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/]);
			if (entity::does_entity_exist((*iParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/].f_2)) {
				entity::set_ped_as_no_longer_needed(&(*iParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/].f_2);
			}
			iVar1++;
		}
		if (entity::does_entity_exist((*iParam0)[iVar0 /*170*/].f_152[0])) {
			entity::set_vehicle_as_no_longer_needed(&(*iParam0)[iVar0 /*170*/].f_152[0]);
		}
		if (entity::does_entity_exist((*iParam0)[iVar0 /*170*/].f_152[1])) {
			entity::set_vehicle_as_no_longer_needed(&(*iParam0)[iVar0 /*170*/].f_152[1]);
		}
		iVar0++;
	}
}

// Position - 0xA0CC
void func_308(var *uParam0) {
	if (entity::does_entity_exist(uParam0->f_5)) {
		entity::set_object_as_no_longer_needed(&uParam0->f_5);
	}
}

// Position - 0xA0E7
void func_309(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_268(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0xA112
void func_310(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		iVar1 = func_80(uParam0, iVar0);
		if (entity::does_entity_exist(iVar1) && entity::is_entity_a_mission_entity(iVar1)) {
			entity::set_object_as_no_longer_needed(&iVar1);
			object::delete_object(&iVar1);
		}
		iVar0++;
	}
}

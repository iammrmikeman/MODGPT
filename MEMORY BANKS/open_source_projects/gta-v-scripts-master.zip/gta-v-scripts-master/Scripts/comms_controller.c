#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
int iLocal_20 = 0;
char *sLocal_21 = NULL;
float fLocal_22 = 0f;
var uLocal_23 = 0;
var uLocal_24 = 0;
var uLocal_25 = 0;
float fLocal_26 = 0f;
float fLocal_27 = 0f;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
var uLocal_35 = 10;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
var uLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 2;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 8;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 8;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
int iLocal_71 = 0;
int iLocal_72 = 0;
int iLocal_73 = 0;
int iLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
int iLocal_78 = 0;
int iLocal_79 = 0;
int iLocal_80 = 0;
int iLocal_81 = 0;
int iLocal_82 = 0;
int iLocal_83 = 0;
int iLocal_84 = 0;
int iLocal_85 = 0;
int iLocal_86 = 0;
int iLocal_87 = 0;
int iLocal_88 = 0;
int iLocal_89 = 0;
int iLocal_90 = 0;
var *uLocal_91 = NULL;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	int iVar1;
	int iVar2;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	iLocal_20 = 3;
	sLocal_21 = "NULL";
	fLocal_22 = 0f;
	fLocal_26 = -0.0375f;
	fLocal_27 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_71 = 1;
	iLocal_72 = 65;
	iLocal_73 = 49;
	iLocal_74 = 64;
	iLocal_82 = -1;
	iLocal_85 = -1;
	iLocal_89 = -1;
	if (player::has_force_cleanup_occurred(82)) {
		func_276();
	}
	Global_36332 = gameplay::get_game_timer() + 20000;
	iVar0 = 0;
	iLocal_86 = gameplay::get_game_timer();
	while (true) {
		iVar1 = gameplay::get_game_timer();
		switch (iLocal_90) {
		case 0:
			if (IsGlobalFlag2Set() && !func_274(12)) {
				func_276();
			}
			iLocal_78 = 0;
			if (iLocal_82 != -1) {
				iLocal_82 = -1;
			}
			switch (iVar0) {
			case 0: func_273(&iVar1); break;

			case 1: func_266(&iVar1); break;

			case 2: func_245(&iVar1); break;

			case 3: func_204(&iVar1); break;

			case 4: func_169(&iVar1); break;
			}
			iVar0++;
			if (iVar0 > 4) {
				iVar0 = 0;
			}
			if (!func_274(0) && !func_274(4) && !func_274(5) && !func_274(2) && !func_274(1) && !func_274(3) &&
				!func_168()) {
				func_148();
			}
			break;

		case 1:
			if (Global_36329 == -1) {
				if (!func_146(0) && !func_274(12)) {
					func_138(&iVar1, 0);
					iLocal_90 = 0;
				}
			}
			if (iLocal_90 == 1) {
				if (iLocal_81) {
					if (!func_137()) {
						iLocal_81 = 0;
					}
				}
				else if (func_136() || func_135() || func_137() || G_DisableMessagesAndCalls1) {
					func_138(&iVar1, 0);
					iLocal_90 = 0;
				}
			}
			if (iLocal_90 == 1) {
				if (func_134(0)) {
					if (func_133()) {
						if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_3 == 5) {
							func_132(0);
						}
						if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 3)) {
							if (func_128()) {
								iLocal_90 = 2;
							}
						}
						else {
							iLocal_90 = 2;
						}
					}
				}
			}
			if (iLocal_90 == 1) {
				if (iLocal_82 == -1) {
					iLocal_82 = gameplay::get_game_timer();
				}
				else if (gameplay::get_game_timer() - iLocal_82 > 20000) {
					func_126();
					func_123(1);
					func_138(&iVar1, 1);
					iLocal_82 = -1;
					iLocal_90 = 0;
				}
			}
			break;

		case 2:
			if (func_122()) {
				func_118(&iVar1);
				iLocal_80 = 0;
				Global_36332 = iVar1 + 20000;
				iLocal_90 = 0;
				LastDispatchedMessageOrCall = -1;
			}
			else if (LastDispatchedMessageOrCall != -1) {
				func_76();
				func_67();
				func_65(iVar1);
			}
			break;
		}
		iVar2 = 0;
		while (iVar2 < G_SomeGlobalState.MessageCallStates.f_910) {
			func_49(&iVar1, &G_SomeGlobalState.MessageCallStates.f_867[iVar2 /*14*/]);
			iVar2++;
		}
		func_36();
		if (Global_36330 || Global_36331) {
			func_35();
			Global_36331 = 0;
		}
		func_1();
		system::wait(0);
	}
}

// Position - 0x31D
void func_1() {
	if (Global_101700.f_9008.f_116 == 0) {
		return;
	}
	if (!func_34(0, 3)) {
		return;
	}
	if (func_33(-358013836) || func_33(-589035286)) {
		if (func_15(Global_101700.f_9008.f_116)) {
			func_5(-358013836);
			func_5(-589035286);
			func_3(-1842374536, 4, 54, 3, 7200000, -1, 4);
			func_3(-418954710, 4, 54, 3, 7200000, -1, 4);
			return;
		}
	}
	if (func_2() == -1783816333) {
		func_5(-1783816333);
		func_5(-358013836);
		func_5(-589035286);
		func_5(-1842374536);
		func_5(-418954710);
		G_SomeGlobalState.MessageCallStates.f_911 = -1;
		if (func_15(Global_101700.f_9008.f_116)) {
			func_3(-1842374536, 4, 54, 3, 7200000, -1, 4);
			func_3(-418954710, 4, 54, 3, 7200000, -1, 4);
		}
		else {
			func_3(-358013836, 4, 54, 3, 7200000, -1, 4);
			func_3(-589035286, 4, 54, 3, 7200000, -1, 4);
		}
	}
}

// Position - 0x458
int func_2() { return G_SomeGlobalState.MessageCallStates.f_911; }

// Position - 0x46A
int func_3(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	struct<15> Var0;

	if (func_4(0)) {
		return 0;
	}
	if (iParam2 < 3) {
		if (gameplay::is_bit_set(iParam1, iParam2)) {
			return 0;
		}
	}
	if (iParam1 < 1 || iParam1 > 7) {
		return 0;
	}
	if (iParam4 <= 0) {
		return 0;
	}
	if (G_SomeGlobalState.MessageCallStates.f_650 < 30) {
		Var0 = iParam0;
		if (G_SomeGlobalState.MessageCallStates.f_911 == Var0) {
			G_SomeGlobalState.MessageCallStates.f_911 = -1;
		}
		Var0.f_1 = 0;
		Var0.f_6 = iParam2;
		Var0.f_2 = iParam1;
		Var0.f_14 = iParam3;
		Var0.f_3 = iParam6;
		Var0.f_7 = -1;
		Var0.f_8 = 0;
		Var0.f_9 = -1;
		Var0.f_4 = gameplay::get_game_timer() + iParam4;
		Var0.f_9 = iParam5;
		Var0.f_10 = -1;
		Var0.f_11 = -1;
		gameplay::set_bit(&Var0.f_1, 0);
		gameplay::set_bit(&Var0.f_1, 6);
		G_SomeGlobalState.MessageCallStates.f_199[G_SomeGlobalState.MessageCallStates.f_650 /*15*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_650++;
		return 1;
	}
	return 0;
}

// Position - 0x570
bool func_4(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x59B
int func_5(int iParam0) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			if (LastDispatchedMessageOrCall != iVar0) {
				func_14(iVar0);
				func_11(iParam0);
				iVar1 = 1;
			}
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			func_11(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/] == iParam0) {
			func_10(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] == iParam0) {
			func_7(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] == iParam0) {
			func_6(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x6C2
void func_6(int iParam0) {
	int iVar0;
	struct<10> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_866) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_866 - 2) {
			G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] = {G_SomeGlobalState.MessageCallStates.f_765[iVar0 + 1 /*10*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 0) {
		G_SomeGlobalState.MessageCallStates.f_765[G_SomeGlobalState.MessageCallStates.f_866 - 1 /*10*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_866--;
	}
}

// Position - 0x77B
void func_7(int iParam0) {
	int iVar0;
	struct<14> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_764) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_764 - 2) {
			G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] = {G_SomeGlobalState.MessageCallStates.f_651[iVar0 + 1 /*14*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 0) {
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 - 1 /*14*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_764--;
	}
	func_8(0);
	func_8(1);
	func_8(2);
}

// Position - 0x843
void func_8(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (!func_9(iParam0)) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 > iVar1) {
				iVar1 = G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3;
			}
		}
		iVar0++;
	}
	iVar2 = 0;
	while (iVar2 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_3 == 5) {
				iVar1 = 5;
			}
		}
		iVar2++;
	}
	G_SomeGlobalState.MessageCallStates.f_919[iParam0] = iVar1;
}

// Position - 0x907
bool func_9(int iParam0) { return iParam0 < 3; }

// Position - 0x913
void func_10(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar15 /*15*/] == iParam0) {
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_650 - 2) {
				G_SomeGlobalState.MessageCallStates.f_199[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_199[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_199[G_SomeGlobalState.MessageCallStates.f_650 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_650--;
			return;
		}
		iVar15++;
	}
}

// Position - 0x9C0
void func_11(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/] == iParam0) {
			func_12(G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/].f_6);
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_198 - 2) {
				G_SomeGlobalState.MessageCallStates.f_137[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_137[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_137[G_SomeGlobalState.MessageCallStates.f_198 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_198--;
			return;
		}
		iVar15++;
	}
}

// Position - 0xA7C
int func_12(int iParam0) {
	int iVar0;

	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] == 1) {
			Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] = 0;
			if (Global_101700.f_27009[iParam0 /*29*/].f_24[Global_14443] == 0) {
				iVar0 = Global_14443;
				func_13(iParam0, iVar0);
			}
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0xAED
void func_13(int iParam0, int iParam1) {
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (iParam1 > 3) {
		}
		else {
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 0;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 0;
		}
	}
}

// Position - 0xB30
void func_14(int iParam0) {
	int iVar0;
	int iVar1;
	struct<15> Var2;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_136) {
		return;
	}
	iVar1 = G_SomeGlobalState.MessageCallStates[iParam0 /*15*/].f_2;
	if (G_SomeGlobalState.MessageCallStates.f_136 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_136 - 2) {
			G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] = {G_SomeGlobalState.MessageCallStates[iVar0 + 1 /*15*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_136 > 0) {
		G_SomeGlobalState.MessageCallStates[G_SomeGlobalState.MessageCallStates.f_136 - 1 /*15*/] = {Var2};
		G_SomeGlobalState.MessageCallStates.f_136--;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		if (gameplay::is_bit_set(iVar1, iVar0)) {
			func_8(iVar0);
		}
		iVar0++;
	}
}

// Position - 0xC0B
bool func_15(int iParam0) { return func_16(func_26(), iParam0); }

// Position - 0xC1D
int func_16(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (!func_24(iParam1) || !func_24(iParam0)) {
		return 1;
	}
	iVar0 = func_22(iParam0);
	iVar1 = func_22(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	else if (iVar0 < iVar1) {
		return 0;
	}
	iVar0 = func_21(iParam0);
	iVar1 = func_21(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	else if (iVar0 < iVar1) {
		return 0;
	}
	iVar0 = func_20(iParam0);
	iVar1 = func_20(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	else if (iVar0 < iVar1) {
		return 0;
	}
	iVar0 = func_19(iParam0);
	iVar1 = func_19(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	else if (iVar0 < iVar1) {
		return 0;
	}
	iVar0 = func_18(iParam0);
	iVar1 = func_18(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	else if (iVar0 < iVar1) {
		return 0;
	}
	iVar0 = func_17(iParam0);
	iVar1 = func_17(iParam1);
	if (iVar0 > iVar1) {
		return 1;
	}
	return 0;
}

// Position - 0xD29
int func_17(int iParam0) { return system::shift_right(iParam0, 20) & 63; }

// Position - 0xD3C
int func_18(int iParam0) { return system::shift_right(iParam0, 14) & 63; }

// Position - 0xD4F
int func_19(int iParam0) { return system::shift_right(iParam0, 9) & 31; }

// Position - 0xD62
int func_20(int iParam0) { return system::shift_right(iParam0, 4) & 31; }

// Position - 0xD74
int func_21(int iParam0) { return iParam0 & 15; }

// Position - 0xD81
var func_22(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_23(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0xDA6
int func_23(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0xDBD
int func_24(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	if (iParam0 == -15) {
		return 0;
	}
	iVar0 = func_17(iParam0);
	if (iVar0 < 0 || iVar0 >= 60) {
		return 0;
	}
	iVar1 = func_18(iParam0);
	if (iVar1 < 0 || iVar1 >= 60) {
		return 0;
	}
	iVar2 = func_19(iParam0);
	if (iVar2 < 0 || iVar2 > 23) {
		return 0;
	}
	iVar3 = func_22(iParam0);
	if (iVar3 <= 0 || iVar3 > 2043 || iVar3 < 1979) {
		return 0;
	}
	iVar4 = func_21(iParam0);
	if (iVar4 < 0 || iVar4 > 11) {
		return 0;
	}
	iVar5 = func_20(iParam0);
	if (iVar5 < 1 || iVar5 > func_25(iVar4, iVar3)) {
		return 0;
	}
	return 1;
}

// Position - 0xE99
int func_25(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0xF3B
int func_26() {
	int *iVar0;

	func_32(&iVar0, time::get_clock_seconds());
	func_31(&iVar0, time::get_clock_minutes());
	func_30(&iVar0, time::get_clock_hours());
	func_29(&iVar0, time::get_clock_day_of_month());
	func_28(&iVar0, time::get_clock_month());
	func_27(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0xF81
void func_27(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x1007
void func_28(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x103A
void func_29(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_21(*uParam0);
	iVar1 = func_22(*uParam0);
	if (iParam1 < 1 || iParam1 > func_25(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x108B
void func_30(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x10C5
void func_31(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x1100
void func_32(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x113C
int func_33(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1238
int func_34(int iParam0, int iParam1) {
	var uVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return 0;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return 0;
	}
	uVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	return uVar0;
}

// Position - 0x1285
void func_35() {
	int iVar0;
	int iVar1;

	iVar1 = system::ceil(gameplay::get_frame_time() * 1000f);
	Global_36332 += iVar1;
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_4 += iVar1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_4 += iVar1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_4 += iVar1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/].f_4 += iVar1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 150) {
		Global_36333[iVar0] += iVar1;
		iVar0++;
	}
}

// Position - 0x13B9
void func_36() {
	if (!func_48(2)) {
		if (func_47(0)) {
			if (!func_47(1)) {
				if (func_134(1)) {
					if (LastDispatchedMessageOrCall != -1) {
						if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/] == 1611093726 ||
							G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/] == 742578279) {
							switch (func_46("AM_H_FCAL1")) {
							case 2: func_44("AM_H_FCAL1", 2, 0, 1000, 7500, 7, 0, 0, 0); break;

							case 1: func_43(2); break;
							}
						}
					}
				}
			}
		}
	}
	if (!func_48(3)) {
		if (!iLocal_79) {
			if (func_47(0)) {
				if (!func_47(1)) {
					if (func_134(1)) {
						if (LastDispatchedMessageOrCall != -1) {
							if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/] == 1611093726 ||
								G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/] == 742578279) {
								if (func_133()) {
									if (func_42("AM_H_FCAL1")) {
										func_38("AM_H_FCAL1", 1);
									}
									if (func_37("AM_H_FCAL1")) {
										ui::clear_help(0);
									}
									func_43(2);
									func_44("AM_H_FCAL2", 2, 0, 1000, 7500, 7, 0, 0, 0);
									iLocal_79 = 1;
								}
							}
						}
					}
				}
			}
		}
		else {
			if (func_46("AM_H_FCAL2") == 2) {
				iLocal_79 = 0;
			}
			else if (func_46("AM_H_FCAL2") == 1) {
				func_43(3);
			}
			if (!func_133()) {
				func_38("AM_H_FCAL2", 1);
				if (func_37("AM_H_FCAL2")) {
					ui::clear_help(0);
				}
				func_43(3);
			}
		}
		if (G_SomeGlobalState.MessageCallStates.f_911 == 1611093726 || G_SomeGlobalState.MessageCallStates.f_911 == 742578279) {
			func_43(3);
			func_43(2);
			if (func_42("AM_H_FCAL1")) {
				func_38("AM_H_FCAL1", 1);
			}
			if (func_37("AM_H_FCAL1")) {
				ui::clear_help(0);
			}
			if (func_42("AM_H_FCAL2")) {
				func_38("AM_H_FCAL2", 1);
			}
			if (func_37("AM_H_FCAL2")) {
				ui::clear_help(0);
			}
		}
	}
}

// Position - 0x15A1
bool func_37(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x15B4
void func_38(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_37(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_41(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_40(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_39();
			return;
		}
		iVar0++;
	}
}

// Position - 0x1661
void func_39() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0x1781
void func_40(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0x181B
void func_41(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0x192B
bool func_42(char *sParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x1966
void func_43(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		gameplay::set_bit(&Global_101700.f_19369.f_150[iVar1], iVar0);
	}
}

// Position - 0x19A8
void func_44(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_45(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x19C9
void func_45(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_39();
	}
}

// Position - 0x1B9C
int func_46(char *sParam0) {
	if (gameplay::are_strings_equal(sParam0, &Global_100345)) {
		return 1;
	}
	if (func_42(sParam0)) {
		return 0;
	}
	return 2;
}

// Position - 0x1BC3
bool func_47(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0x1BEF
bool func_48(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		return gameplay::is_bit_set(Global_101700.f_19369.f_150[iVar1], iVar0);
	}
	return false;
}

// Position - 0x1C32
void func_49(int iParam0, var *uParam1) {
	char *sVar0;

	func_63(*uParam1, &sVar0);
	switch (func_62(&sVar0)) {
	case 0:
		G_SomeGlobalState.MessageCallStates.f_916 = 0;
		func_50(iParam0, uParam1);
		break;

	case 3:
		G_SomeGlobalState.MessageCallStates.f_916 = 1;
		G_SomeGlobalState.MessageCallStates.f_917 = 1;
		func_50(iParam0, uParam1);
		break;

	case 4:
		G_SomeGlobalState.MessageCallStates.f_916 = 1;
		G_SomeGlobalState.MessageCallStates.f_917 = 0;
		break;
	}
}

// Position - 0x1CB0
void func_50(var *uParam0, var *uParam1) {
	func_53(uParam1);
	G_SomeGlobalState.MessageCallStates.f_915 = *uParam1;
	Global_36332 = *uParam0 + 20000;
	Global_36333[uParam1->f_6] = *uParam0 + 20000;
	func_51(*uParam1);
}

// Position - 0x1CEA
void func_51(int iParam0) {
	int iVar0;
	int iVar1;
	struct<14> Var2;

	iVar0 = func_52(iParam0);
	if (iVar0 == -1) {
		return;
	}
	iVar1 = iVar0;
	while (iVar1 <= G_SomeGlobalState.MessageCallStates.f_910 - 2) {
		G_SomeGlobalState.MessageCallStates.f_867[iVar1 /*14*/] = {G_SomeGlobalState.MessageCallStates.f_867[iVar1 + 1 /*14*/]};
		iVar1++;
	}
	G_SomeGlobalState.MessageCallStates.f_867[G_SomeGlobalState.MessageCallStates.f_910 - 1 /*14*/] = {Var2};
	G_SomeGlobalState.MessageCallStates.f_910--;
	func_8(0);
	func_8(1);
	func_8(2);
}

// Position - 0x1D8A
int func_52(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_910) {
		if (G_SomeGlobalState.MessageCallStates.f_867[iVar0 /*14*/] == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1DC6
void func_53(var *uParam0) {
	int iVar0;

	if (uParam0->f_8 == 235) {
		return;
	}
	if (gameplay::is_bit_set(uParam0->f_1, 5)) {
		iVar0 = 0;
		while (iVar0 < 3) {
			if (gameplay::is_bit_set(uParam0->f_2, iVar0)) {
				func_55(uParam0->f_6, iVar0, 0);
			}
			iVar0++;
		}
	}
	if (uParam0->f_8 != 0) {
		func_54(uParam0->f_8, 0);
		return;
	}
}

// Position - 0x1E24
void func_54(int iParam0, int iParam1) {
	if (iParam0 == 235 || iParam0 == 0) {
		return;
	}
	Global_101700.f_7572[iParam0] = 1;
	Global_101700.f_7572.f_236[iParam0] = gameplay::get_game_timer() + iParam1;
}

// Position - 0x1E61
void func_55(int iParam0, int iParam1, int iParam2) {
	Global_2999 = iParam0;
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		func_57();
		if (iParam1 == 4) {
			Global_101700.f_27009[iParam0 /*29*/].f_12[0] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[2] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[0] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[2] = 1;
		}
		else {
			if (Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] == 1 &&
				Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] == 1) {
				iParam2 = 0;
			}
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 1;
		}
		if (iParam2) {
			if (!Global_69702) {
				if (iParam1 != 4) {
					if (Global_14443 != iParam1) {
						Global_2972[iParam1 /*4*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
						Global_2989[iParam1] = 1;
						Global_2994[iParam1] = iParam0;
					}
					else if (iParam0 == Global_14443) {
					}
					else {
						Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
						Global_2923[1 /*6*/].f_5 = iParam1;
						func_56();
					}
				}
				else {
					Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
					Global_2923[1 /*6*/].f_5 = iParam1;
					func_56();
				}
			}
			else {
				Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
				Global_2923[1 /*6*/].f_5 = iParam1;
				func_56();
			}
		}
	}
}

// Position - 0x200B
void func_56() {
	char cVar0[64];
	char cVar16[64];
	char *sVar32;

	StringCopy(&cVar0, ui::_get_label_text(&Global_101700.f_27009[Global_2999 /*29*/].f_7), 64);
	if (Global_3018 == 0) {
		ui::_set_notification_text_entry("");
		StringCopy(&cVar16, ui::_get_label_text(&Global_2923[1 /*6*/]), 64);
		sVar32 = ui::_get_label_text("CELL_253");
		ui::_set_notification_message(&cVar0, &cVar0, 0, 3, sVar32, &cVar16);
	}
	else {
		ui::_set_notification_text_entry("CELL_255");
		ui::add_text_component_substring_text_label(&Global_2923[1 /*6*/]);
		ui::_set_notification_message(&cVar0, &cVar0, 0, 3, "", 0);
	}
	gameplay::clear_bit(&G_SleepModeOnOn25, 0);
}

// Position - 0x2088
void func_57() {
	if (func_274(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = ModifyAndGetSomeMessageCallState();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x212A
int ModifyAndGetSomeMessageCallState() {
	func_59();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x2143
void func_59() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_61(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_60(player::player_ped_id());
			if (func_9(iVar0) && (!func_274(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_9(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x2240
int func_60(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_61(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x227D
int func_61(int iParam0) {
	if (func_9(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x22A7
int func_62(char *sParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	while (iVar0 < 35) {
		if (!gameplay::is_string_null(&Global_101700.f_13100[iVar0 /*104*/])) {
			if (gameplay::are_strings_equal(&Global_101700.f_13100[iVar0 /*104*/], sParam0)) {
				iVar1 = Global_101700.f_13100[iVar0 /*104*/].f_29;
				return iVar1;
			}
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x2302
void func_63(int iParam0, char *sParam1) {
	if (GetMessageType(iParam0) == 2) {
		switch (iParam0) {
		case 1834414893: StringCopy(sParam1, "AH_1_U", 16); break;

		case 2114893093: StringCopy(sParam1, "AH_2_U", 16); break;

		case 230961098: StringCopy(sParam1, "AH_P_U", 16); break;

		case 639116137: StringCopy(sParam1, "AH_GETA_R", 16); break;

		case 1943637475: StringCopy(sParam1, "AH3B_UNLK", 16); break;

		case /* Assassination 1 Text */1635608802: StringCopy(sParam1, "ASS1_MIS", 16); break;

		case -799417230: StringCopy(sParam1, "ASS_FINA", 16); break;

		case -2135245515: StringCopy(sParam1, "ASS_FINB", 16); break;

		case -1982006572: StringCopy(sParam1, "ARM2_END", 16); break;

		case 866793964: StringCopy(sParam1, "ARM3_END2", 16); break;

		case 410510653: StringCopy(sParam1, "ARM3_END1", 16); break;

		case 341684477: StringCopy(sParam1, "CAR1_ALL", 16); break;

		case 1328556918: StringCopy(sParam1, "CAR2_DONE", 16); break;

		case 1023767: StringCopy(sParam1, "CAR3_F_REM", 16); break;

		case 190444893: StringCopy(sParam1, "CAR3_MT_REM", 16); break;

		case 1761525528: StringCopy(sParam1, "MIC2_MIS", 16); break;

		case 1674644829: StringCopy(sParam1, "CHOP_UNLOCK", 16); break;

		case 152157591: StringCopy(sParam1, "CITY_RON", 16); break;

		case 736324744: StringCopy(sParam1, "CHEF_U", 16); break;

		case 839361606: StringCopy(sParam1, "DOCKS1_F_SHT", 16); break;

		case 411396589: StringCopy(sParam1, "DCKP1_U", 16); break;

		case -631719301: StringCopy(sParam1, "DCKP2B_U", 16); break;

		case -549935988: StringCopy(sParam1, "DCKP2B_R", 16); break;

		case 1759805585: StringCopy(sParam1, "DOCKS1_M_FLY", 16); break;

		case 1269300253: StringCopy(sParam1, "DCK2_U", 16); break;

		case 610159002: StringCopy(sParam1, "EXIL2_U", 16); break;

		case -1281173598: StringCopy(sParam1, "EXIL2_OSC", 16); break;

		case -1293573249: StringCopy(sParam1, "RBH_PAT", 16); break;

		case 1328243545: StringCopy(sParam1, "EXIL_WAD", 16); break;

		case 1400447159: StringCopy(sParam1, "EXL_HUNT_PIE", 16); break;

		case 981904836: StringCopy(sParam1, "EXL_JIM_MCAR", 16); break;

		case -1428654185: StringCopy(sParam1, "FAM1_END", 16); break;

		case -1608680660: StringCopy(sParam1, "FAM3_INIT", 16); break;

		case 25048086: StringCopy(sParam1, "FAM5_END", 16); break;

		case 6861963: StringCopy(sParam1, "FBI4I_U", 16); break;

		case -655205392: StringCopy(sParam1, "FB4_RM_M", 16); break;

		case 1266526796: StringCopy(sParam1, "FB4_RM_FT", 16); break;

		case -1652588035: StringCopy(sParam1, "FBI4_UM", 16); break;

		case -125167689: StringCopy(sParam1, "FBI4_UFT", 16); break;

		case 1323596299: StringCopy(sParam1, "FBI4_ASS", 16); break;

		case -1205448796: StringCopy(sParam1, "FBI4_MTASS", 16); break;

		case -1942568571: StringCopy(sParam1, "FIH_PA_U", 16); break;

		case -408163515: StringCopy(sParam1, "FIH_PB_U", 16); break;

		case 2073240496: StringCopy(sParam1, "FIH_PD_U", 16); break;

		case -1216150262: StringCopy(sParam1, "FIH_GETA_R", 16); break;

		case 704657460: StringCopy(sParam1, "FIH_KILLM", 16); break;

		case -1198893762: StringCopy(sParam1, "FIH_KILLT", 16); break;

		case 497850717: StringCopy(sParam1, "FORSALE_TXT", 16); break;

		case -1501908698: StringCopy(sParam1, "FRAN0_END", 16); break;

		case /* lamar's text */943848816: StringCopy(sParam1, "FRA1_END", 16); break;

		case 689367973: StringCopy(sParam1, "JP1A_U", 16); break;

		case -666454256: StringCopy(sParam1, "JH1A_FRNK", 16); break;

		case -270587643: StringCopy(sParam1, "JP2A_U", 16); break;

		case -1641645609: StringCopy(sParam1, "JP1B_U", 16); break;

		case 1471029448: StringCopy(sParam1, "JP1B_HOST", 16); break;

		case -1879623490: StringCopy(sParam1, "JH2_P", 16); break;

		case -1816533207: StringCopy(sParam1, "JOSH1_TXT", 16); break;

		case -474700046: StringCopy(sParam1, "MAR1_U", 16); break;

		case -1577577773: StringCopy(sParam1, "MAR_CASH1", 16); break;

		case -1235391473: StringCopy(sParam1, "MAR_CASH2", 16); break;

		case 251204761: StringCopy(sParam1, "MAR_TREV", 16); break;

		case -1207693656: StringCopy(sParam1, "ME_A_FAIL", 16); break;

		case 809731919: StringCopy(sParam1, "ME_A_FAIL2", 16); break;

		case -149728591: StringCopy(sParam1, "ME_J_FAIL", 16); break;

		case 1245740196: StringCopy(sParam1, "ME_T_FAIL", 16); break;

		case -1589024007: StringCopy(sParam1, "MIC4_M", 16); break;

		case -658009473: StringCopy(sParam1, "MIC4_F", 16); break;

		case 772720529: StringCopy(sParam1, "PLTSC_U", 16); break;

		case 902928934: StringCopy(sParam1, "RBH_U", 16); break;

		case -831144864: StringCopy(sParam1, "RBH_P_U", 16); break;

		case 486824538: StringCopy(sParam1, "SHOOT_U", 16); break;

		case -384575792: StringCopy(sParam1, "SXT_", 16); break;

		case -1924990311: StringCopy(sParam1, "FTX_", 16); break;

		case 2091854273: StringCopy(sParam1, "FTX_", 16); break;

		case 328868333: StringCopy(sParam1, "FTX_", 16); break;

		case -1813399915: StringCopy(sParam1, "FTX_", 16); break;

		case 465306446: StringCopy(sParam1, "FTX_", 16); break;

		case -816460512: StringCopy(sParam1, "FTX_", 16); break;

		case -702667427: StringCopy(sParam1, "FTX_", 16); break;

		case 271682265: StringCopy(sParam1, "PRM", 16); break;

		case 1694883968: StringCopy(sParam1, "BSTXT_", 16); break;

		case -181320640: StringCopy(sParam1, "FGTXT_M", 16); break;

		case 1418815087: StringCopy(sParam1, "FGTXT_F", 16); break;

		case 2087297077: StringCopy(sParam1, "FGTXT_T", 16); break;

		case -1789721694: StringCopy(sParam1, "FGTXT_H", 16); break;

		case 483349085: StringCopy(sParam1, "BARR3_U", 16); break;

		case 1800466587: StringCopy(sParam1, "BARR4_U", 16); break;

		case 2106164812: StringCopy(sParam1, "EPSI6_U", 16); break;

		case -1783809705: StringCopy(sParam1, "EXTR2_U", 16); break;

		case -1159983966: StringCopy(sParam1, "EXTR3_U", 16); break;

		case -1134717682: StringCopy(sParam1, "HUNT1_U", 16); break;

		case -1444331296: StringCopy(sParam1, "PAP3_U", 16); break;

		case 969002696: StringCopy(sParam1, "TON3_U", 16); break;

		case 1794975438: StringCopy(sParam1, "TON4_U", 16); break;

		case 1988415324: StringCopy(sParam1, "RE_BUR_MIS", 16); break;

		case 1234461962: StringCopy(sParam1, "SOL2_PASS", 16); break;

		case 1516526930: StringCopy(sParam1, "DRF3_U", 16); break;

		case -685399607: StringCopy(sParam1, "DRF4_U", 16); break;

		case -527573502: StringCopy(sParam1, "SR_AIRPORT", 16); break;

		case 277048894: StringCopy(sParam1, "SR_FREEWAY", 16); break;

		case 477030223: StringCopy(sParam1, "SR_CANALS", 16); break;

		case -1900821691: StringCopy(sParam1, "MGTNS_U", 16); break;

		case -1845612607: StringCopy(sParam1, "MGTNS_U2", 16); break;

		case -815326385: StringCopy(sParam1, "T_LOST_HANGER", 16); break;

		case 367701416: StringCopy(sParam1, "OMEGA_TXT1", 16); break;

		case 65881433: StringCopy(sParam1, "BLAZER3_U", 16); break;

		case 1256519626: StringCopy(sParam1, "ABI1_MISS", 16); break;

		case 1324777792: StringCopy(sParam1, "HAO1_ENDT", 16); break;

		case 552744224: StringCopy(sParam1, "PHT_WLD_BEV1", 16); break;

		case 1751306471: StringCopy(sParam1, "MNKY_CAR_UNLK", 16); break;

		case -899711929: StringCopy(sParam1, "MNKY_LAMAR", 16); break;

		case 1139718847: StringCopy(sParam1, "CRACE_UNLK", 16); break;

		default: break;
		}
	}
	else {
		return;
	}
}

/// 2 = Text
// Position - 0x2A7D
int GetMessageType(int iParam0) {
	switch (iParam0) {
	case -1323332922:
	case -651018670:
	case -236506853:
	case -518176220:
	case -1889998615:
	case 777679877:
	case -1547927413:
	case 1770589463:
	case -1358914512:
	case 1611093726:
	case 742578279:
	case -1753640864:
	case 24012281:
	case 343235192:
	case 687625470:
	case -1134988206:
	case -1155501333:
	case -951496:
	case -1108940541:
	case 1372476011:
	case -452599906:
	case 944724110:
	case -749738207:
	case -1478217267:
	case -1451910289:
	case -1151582404:
	case 1645231:
	case -769656371:
	case -694220424:
	case -885867010:
	case -632277372:
	case -1763624884:
	case 1995383583:
	case -881570909:
	case -444489072:
	case 154402960:
	case 795730787:
	case -1847734803:
	case -714760066:
	case -1198055521:
	case 1374342572:
	case 530956160:
	case 240475766:
	case 580731697:
	case 728176806:
	case 910240872:
	case 74540475:
	case -1200353264:
	case 801340541:
	case 1527885205:
	case -224691627:
	case -2014002000:
	case -314546970:
	case -1306479777:
	case -621899663:
	case -1615086084:
	case -1989308064:
	case -1970925435:
	case -1060930305:
	case -1817481777:
	case 1080702705:
	case -2099041387:
	case -1468151569:
	case -121056641:
	case -579786137:
	case -1398697867:
	case 466185907:
	case 185453884:
	case 1972824823:
	case -288258721:
	case -47439340:
	case -553769964:
	case -1434443191:
	case -2032593637:
	case -458789713:
	case 321648831:
	case 312697495:
	case -1980743701:
	case 1567521709:
	case -1687842043:
	case -1631047976:
	case 962970051:
	case -1323797481:
	case 2095586439:
	case 1608868018:
	case 1134611425:
	case 187813079:
	case -39544602:
	case -997367701:
	case -128912482:
	case -131238069:
	case -330732224:
	case -1334144471:
	case -211946295:
	case 1679209251:
	case -1394105734:
	case 94848458:
	case -1106471007:
	case -268883259:
	case 546458037:
	case -78001721:
	case 327673956:
	case -1746082591:
	case -1945164276:
	case -1052097629:
	case 1595158098:
	case -420969532:
	case -2068958976:
	case -1366489923:
	case 406771743:
	case -837794877:
	case -441095892:
	case 153235461:
	case -67922520:
	case 707131591:
	case 2033185762:
	case 1801771084:
	case -1716308760:
	case -2116452823:
	case -1141220854:
	case 1880611494:
	case -1276059507:
	case -1434698871:
	case 1632742627:
	case -1074970768:
	case 643619115:
	case 720676600:
	case 1303349750:
	case -1343914045:
	case -1199050901:
	case 1082655975:
	case -2100435596:
	case -974942855:
	case -577064562:
	case 2025906743:
	case -1404384954:
	case -112860461:
	case 339632201:
	case 453095043:
	case 2111803439:
	case 1290939985:
	case -1690219790:
	case 1766909710:
	case -358013836:
	case -589035286:
	case -1842374536:
	case -418954710:
	case -1783816333:
	case 1438498239:
	case -2139605007:
	case 1906711117:
	case -1949184344:
	case 2065444157:
	case 624853379:
	case -1766792090:
	case -1878340166:
	case 279793409:
	case 460547213:
	case -330856906:
	case -690594988:
	case -349863294:
	case 424926942:
	case 1890717037:
	case -1636767510:
	case -1893250473:
	case -1160994395:
	case 963157723:
	case 1730771548:
	case 1410028576:
	case -2082393141:
	case -1497396589:
	case -1196085634:
	case 170512742:
	case 469005563:
	case -306898819:
	case 82970585:
	case 1867406480:
	case 1502097668:
	case -1621970384:
	case 1031237239:
	case 194808514:
	case 1509435260:
	case 673727449:
	case 71040001:
	case -755689100:
	case 556840426:
	case -177054098: return 0;

	default:
		switch (iParam0) {
		case -835252192:
		case 616513703:
		case 2064117051:
		case -1758542647:
		case 1089542219:
		case 675079903:
		case -1613846760:
		case 518202687:
		case 946886745:
		case 1229388294:
		case 522335044:
		case 2097475336:
		case -108894207:
		case -950205513:
		case -703684326:
		case -1982920067:
		case 1319343143:
		case -1118768768:
		case -705125709:
		case -782984853:
		case -92968020:
		case -406305198:
		case -1130010274:
		case 684213521:
		case 1388615949:
		case -2062910056:
		case -643694497:
		case -278713375:
		case -1105442476:
		case -805704433:
		case -1565848713:
		case -1351801605:
		case 1311040108:
		case 1562602199:
		case 1113666899:
		case 814649774:
		case 225734768:
		case 1628462442:
		case 1791324372:
		case -240877892:
		case -1141042322:
		case 1806999335:
		case 2054503592:
		case -2009081795:
		case 520422857:
		case -375893868:
		case 313472619:
		case 2038672434:
		case 1666308520:
		case 1894462438:
		case 1728635625:
		case 975196153:
		case -710274964:
		case 1289879258:
		case 1621076324:
		case 1005256598:
		case 1127548000:
		case -1291788156:
		case 1993031175: return 0;

		case 1635046052:
		case -464957327:
		case 178720519:
		case 738411510:
		case -100973682:
		case 1752783247:
		case 1016954269:
		case -456311088:
		case 2129099422:
		case 1357642229:
		case -767033321:
		case -1240893790: return 1;

		case 1834414893:
		case 2114893093:
		case 230961098:
		case 639116137:
		case 1943637475:
		case /* Assassination 1 Text */1635608802:
		case -799417230:
		case -2135245515:
		case -1982006572:
		case 866793964:
		case 410510653:
		case 341684477:
		case 1328556918:
		case 1023767:
		case 190444893:
		case 1761525528:
		case 1674644829:
		case 152157591:
		case 736324744:
		case 839361606:
		case 411396589:
		case -631719301:
		case -549935988:
		case 1759805585:
		case 1269300253:
		case 610159002:
		case -1281173598:
		case 1328243545:
		case 1400447159:
		case -1293573249:
		case 981904836:
		case -1428654185:
		case -1608680660:
		case 25048086:
		case 6861963:
		case -655205392:
		case 1266526796:
		case -1652588035:
		case -125167689:
		case 1323596299:
		case -1205448796:
		case -1942568571:
		case -408163515:
		case 2073240496:
		case -1216150262:
		case 704657460:
		case -1198893762:
		case 497850717:
		case -1501908698:
		case /* lamar's text */943848816:
		case 689367973:
		case -666454256:
		case -270587643:
		case -1641645609:
		case 1471029448:
		case -1879623490:
		case -1816533207:
		case -474700046:
		case -1207693656:
		case 809731919:
		case -149728591:
		case 1245740196:
		case -1589024007:
		case -658009473:
		case 772720529:
		case 483349085:
		case 1800466587:
		case 2106164812:
		case -1783809705:
		case -1159983966:
		case -1134717682:
		case -1444331296:
		case 969002696:
		case 1794975438:
		case 1988415324:
		case 902928934:
		case -831144864:
		case 1234461962:
		case 486824538:
		case 1516526930:
		case -685399607:
		case -527573502:
		case 277048894:
		case 477030223:
		case -1900821691:
		case -1845612607:
		case -815326385:
		case 367701416:
		case -384575792:
		case -1924990311:
		case 2091854273:
		case 328868333:
		case -1813399915:
		case 465306446:
		case -816460512:
		case -702667427:
		case 271682265:
		case 1694883968:
		case -181320640:
		case 1418815087:
		case 2087297077:
		case -1789721694:
		case -1577577773:
		case -1235391473:
		case 251204761:
		case 65881433:
		case 1256519626:
		case 1324777792:
		case 552744224:
		case 1751306471:
		case -899711929:
		case 1139718847: return 2;

		default:
			switch (iParam0) {
			case 2021846885:
			case 801347631:
			case 2107010167:
			case 1440910066:
			case 2063740346:
			case 957098437:
			case 338918687:
			case 1818503402:
			case 1511064644:
			case 1217225025:
			case -929373866:
			case -1252410668:
			case -1548445814:
			case -1853951201:
			case -709067855:
			case -1023257027:
			case 692693384:
			case 1209844154:
			case -1144971313:
			case 801546988:
			case 319357731:
			case -423103492:
			case -1504002834:
			case 1343538152:
			case 1357988739:
			case 374347954:
			case -1718545517:
			case 2022687760:
			case -1069372983:
			case -789275824:
			case 183426861:
			case -1303362934:
			case 632406285:
			case 859937019:
			case 430981897:
			case -771149390:
			case -1649944291:
			case -1821325152:
			case -132533604:
			case 711875844:
			case -1523625340:
			case -2135625223:
			case -2076002026:
			case -1897604564:
			case -1430864197:
			case 1424059178:
			case -666761274:
			case -2038240170:
			case -1551606815:
			case -980148216:
			case -1857996981:
			case -1674789340:
			case 448778385:
			case 546388833:
			case 1051395607:
			case -505415049:
			case 430538716:
			case 1428562614:
			case -748636148:
			case 353549167:
			case 1400649789:
			case 135464153:
			case -536513155:
			case 967465509:
			case -2132612619:
			case -1419493641:
			case -521917970:
			case -1521020490:
			case 1894922981:
			case 233370836:
			case 984305268:
			case -833431660:
			case 372434771:
			case -92983336:
			case 1638023784:
			case 2121956376:
			case -452245192:
			case 763248121:
			case -720564968:
			case -1067764575:
			case -921778680:
			case -606278748:
			case -414580094:
			case -1871231456:
			case 1127068257:
			case 359978756:
			case -1406368651:
			case -1093228087:
			case 143441204:
			case -615685450:
			case 1963267619: return 3;
			}
			break;
		}
		break;
	}
	return -1;
}

// Position - 0x3592
void func_65(int iParam0) {
	int iVar0;

	if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 3)) {
		iVar0 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_7;
		if (iVar0 != -1) {
			if (func_66(player::player_ped_id(), iVar0, Global_35782[iVar0 /*5*/].f_3 * 0.35f)) {
				func_138(&iParam0, 0);
				func_123(0);
				iLocal_90 = 0;
				Global_36332 = iParam0 + 20000;
			}
		}
	}
}

// Position - 0x35F9
bool func_66(int iParam0, int iParam1, float fParam2) {
	struct<5> Var0;
	float fVar5;

	if (!entity::is_entity_dead(iParam0, 0)) {
		Var0 = {Global_35782[iParam1 /*5*/]};
		fVar5 = Var0.f_3;
		if (fParam2 > 0f) {
			fVar5 = fParam2;
		}
		if (gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1), Var0, 1) < fVar5) {
			return true;
		}
		else if (Var0.f_4 != -1) {
			return func_66(iParam0, Var0.f_4, fParam2);
		}
	}
	return false;
}

// Position - 0x365F
void func_67() {
	int iVar0;

	if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 1)) {
		if (!func_48(26)) {
			if (func_75()) {
				// Choice whether to help michael's family or not.
				switch (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]) {
				case 1635046052:
				case -464957327:
				case 178720519:
					ShowHelpText("AM_H_FDEC", -1);
					func_43(26);
					break;
				}
			}
		}
		if (!G_SomeGlobalState.MessageCallStates.f_913) {
			if (func_73() != 0) {
				if (func_37("AM_H_FDEC")) {
					ui::clear_help(0);
				}
				if (func_73() == 1) {
					G_SomeGlobalState.MessageCallStates.f_914 = 1;
					G_SomeGlobalState.MessageCallStates.f_913 = 1;
				}
				else {
					if (Global_36329 != -1) {
						func_72(&Global_36329);
						func_70();
						iVar0 = 0;
						while (iVar0 < 9) {
							if (Global_101700.f_17062.f_175[iVar0 /*19*/].f_8 == 0) {
								func_68(&Global_101700.f_17062.f_175[iVar0 /*19*/].f_5, 300f);
							}
							iVar0++;
						}
					}
					G_SomeGlobalState.MessageCallStates.f_914 = 0;
					G_SomeGlobalState.MessageCallStates.f_913 = 1;
				}
			}
		}
	}
}

// Position - 0x3770
void func_68(int *iParam0, float fParam1) {
	uParam0->f_1 = func_69(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x379E
float func_69(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x37F6
void func_70() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 8) {
		if (Global_88757[iVar0 /*17*/] && !Global_88757[iVar0 /*17*/].f_1) {
			if (Global_88757[iVar0 /*17*/].f_3 == 0) {
				if (Global_88757[iVar0 /*17*/].f_5 != 88 && Global_88757[iVar0 /*17*/].f_5 != 89 &&
					Global_88757[iVar0 /*17*/].f_5 != 92) {
					func_71(Global_88757[iVar0 /*17*/].f_5, 1);
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x387D
void func_71(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x38BB
void func_72(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0x38F8
int func_73() { return Global_16762; }

// Position - 0x3903
void ShowHelpText(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x391A
bool func_75() {
	if (gameplay::is_bit_set(G_SleepModeOffOn11, 23)) {
		if (Global_15798 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0x3944
void func_76() {
	int iVar0;
	int iVar1;
	struct<5> Var2;

	if (iLocal_80) {
		iVar0 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_9;
		if (iVar0 != -1) {
			if (func_79(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_9)) {
				iVar1 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_10;
			}
			else {
				iVar1 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_11;
			}
			if (iVar1 != -1) {
				func_78(iVar1, &Var2);
				func_77(&Var2, &Var2.f_4);
			}
		}
		iLocal_80 = 0;
	}
}

// Position - 0x39C0
void func_77(char *sParam0, char *sParam1) {
	if (audio::is_mobile_phone_call_ongoing()) {
		Global_15802 = 1;
		StringCopy(&Global_15809, sParam0, 24);
		StringCopy(&Global_15803, sParam1, 24);
	}
}

// Position - 0x39E1
void func_78(int iParam0, var *uParam1) {
	if (GetMessageType(iParam0) == 0) {
		StringCopy(uParam1, "CHATCAU", 16);
		StringCopy(&uParam1->f_8, "", 16);
		switch (iParam0) {
		case -1323332922:
			StringCopy(uParam1, "FB3aAUD", 16);
			StringCopy(&uParam1->f_4, "F3A_INTALT", 16);
			break;

		case -651018670:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C4", 16);
			break;

		case -236506853:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C7", 16);
			break;

		case -518176220:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C5", 16);
			break;

		case -1889998615:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C6", 16);
			break;

		case 777679877:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C8", 16);
			break;

		case -1547927413:
			StringCopy(uParam1, "AHFAUD", 16);
			StringCopy(&uParam1->f_4, "AHF_C9", 16);
			break;

		case 1770589463:
			StringCopy(uParam1, "FBIS4AU", 16);
			StringCopy(&uParam1->f_4, "AH3A_PASS", 16);
			break;

		case -1358914512:
			StringCopy(uParam1, "AH3BAUD", 16);
			StringCopy(&uParam1->f_4, "AH3B_PASS", 16);
			break;

		case 1611093726:
			StringCopy(uParam1, "ARFLAUD", 16);
			StringCopy(&uParam1->f_4, "ARFL_CALL1", 16);
			break;

		case 742578279:
			StringCopy(uParam1, "ARFLAUD", 16);
			StringCopy(&uParam1->f_4, "ARFL_CALL_CT", 16);
			break;

		case -1753640864:
			StringCopy(uParam1, "ARFLAUD", 16);
			StringCopy(&uParam1->f_4, "ARFL_CALL2", 16);
			break;

		case 24012281:
			StringCopy(uParam1, "ASFLAUD", 16);
			StringCopy(&uParam1->f_4, "ASFL_CALL1", 16);
			break;

		case 343235192:
			StringCopy(uParam1, "OJASAUD", 16);
			StringCopy(&uParam1->f_4, "OJAS_HOTEL_C", 16);
			break;

		case 687625470:
			StringCopy(uParam1, "CSFLAUD", 16);
			StringCopy(&uParam1->f_4, "CSFL_CALL0", 16);
			break;

		case -1134988206:
			StringCopy(uParam1, "MIFLAUD", 16);
			StringCopy(&uParam1->f_4, "MIFL_CALL2", 16);
			break;

		case -1155501333:
			StringCopy(uParam1, "CHFLAUD", 16);
			StringCopy(&uParam1->f_4, "CHFL_CALL1", 16);
			StringCopy(&uParam1->f_8, "CHFL_CALL2", 16);
			break;

		case -951496:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_C3", 16);
			break;

		case -1108940541:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_C4", 16);
			break;

		case 1372476011:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_C3B", 16);
			break;

		case -452599906:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_WP1", 16);
			break;

		case 944724110:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_WP2", 16);
			break;

		case -749738207:
			StringCopy(uParam1, "DHFAUD", 16);
			StringCopy(&uParam1->f_4, "DHF_C2A", 16);
			break;

		case -1478217267:
			StringCopy(uParam1, "EXL1AUD", 16);
			StringCopy(&uParam1->f_4, "EXL1_CALLM", 16);
			break;

		case -1451910289:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_CALL1", 16);
			break;

		case -1151582404:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_CALL2", 16);
			break;

		case 1628462442:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR09", 16);
			break;

		case 1791324372:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR10", 16);
			break;

		case -240877892:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR11", 16);
			break;

		case -1141042322:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR05", 16);
			break;

		case 1806999335:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR12", 16);
			break;

		case 2054503592:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR13", 16);
			break;

		case -2009081795:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR14", 16);
			break;

		case 520422857:
			StringCopy(uParam1, "EXILAUD", 16);
			StringCopy(&uParam1->f_4, "EXIL_MAR07", 16);
			break;

		case 1645231:
			StringCopy(uParam1, "FMFLAUD", 16);
			StringCopy(&uParam1->f_4, "FMFL_AM4", 16);
			break;

		case -769656371:
			StringCopy(uParam1, "EXL3AUD", 16);
			StringCopy(&uParam1->f_4, "EXL3_STEVE", 16);
			break;

		case -694220424:
			StringCopy(uParam1, "EPSDAUD", 16);
			StringCopy(&uParam1->f_4, "EPSD_CRIS", 16);
			break;

		case -885867010:
			StringCopy(uParam1, "EPSDAUD", 16);
			StringCopy(&uParam1->f_4, "EPSD_FIN", 16);
			break;

		case -632277372:
			StringCopy(uParam1, "EPS8AU", 16);
			StringCopy(&uParam1->f_4, "EPS8_CF1", 16);
			break;

		case -1763624884:
			StringCopy(uParam1, "EPS8AU", 16);
			StringCopy(&uParam1->f_4, "EPS8_CF3", 16);
			break;

		case 1995383583:
			StringCopy(uParam1, "FMFLAUD", 16);
			StringCopy(&uParam1->f_4, "FMFL_TRFAM4", 16);
			break;

		case -881570909:
			StringCopy(uParam1, "FMFLAUD", 16);
			StringCopy(&uParam1->f_4, "FMFL_TRCHILL", 16);
			break;

		case -444489072:
			StringCopy(uParam1, "FOFLAUD", 16);
			StringCopy(&uParam1->f_4, "FOFL_CALL1A", 16);
			StringCopy(&uParam1->f_8, "FOFL_CALL1A2", 16);
			break;

		case 154402960:
			StringCopy(uParam1, "FOFLAUD", 16);
			StringCopy(&uParam1->f_4, "FOFL_CALL1B", 16);
			break;

		case 795730787:
			StringCopy(uParam1, "FOFLAUD", 16);
			StringCopy(&uParam1->f_4, "FOFL_CALL4", 16);
			break;

		case -1847734803:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP1_MENDC", 16);
			break;

		case -714760066:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP1_FENDC", 16);
			break;

		case -1198055521:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP1_TENDC", 16);
			break;

		case 1374342572:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP2_MENDC", 16);
			break;

		case 530956160:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP2_FENDC", 16);
			break;

		case 240475766:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP2_TENDC", 16);
			break;

		case 580731697:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP4_MENDC", 16);
			break;

		case 728176806:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP4_FENDC", 16);
			break;

		case 910240872:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP4_TENDC", 16);
			break;

		case 74540475:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP5_MENDC", 16);
			break;

		case -1200353264:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP5_FENDC", 16);
			break;

		case 801340541:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBIP5_TENDC", 16);
			break;

		case 1527885205:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_READY", 16);
			break;

		case -224691627:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_WAIT", 16);
			break;

		case -2014002000:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_READY", 16);
			break;

		case -314546970:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_ITSONF", 16);
			break;

		case -1306479777:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_ITSONT", 16);
			break;

		case -621899663:
			StringCopy(uParam1, "FBIPRAU", 16);
			StringCopy(&uParam1->f_4, "FBI4_ISAGO", 16);
			break;

		case -1615086084:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_CHC1", 16);
			break;

		case -1989308064:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_CHC1B", 16);
			break;

		case -1970925435:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_CHC2", 16);
			break;

		case -1060930305:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_CHC2B", 16);
			break;

		case -1817481777:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_CHC3", 16);
			break;

		case -2099041387:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_AMAN", 16);
			break;

		case -1468151569:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_DAVE", 16);
			break;

		case -121056641:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_DEV09", 16);
			break;

		case -579786137:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_LAM22", 16);
			break;

		case -1398697867:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_MDEAD1", 16);
			break;

		case 466185907:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_MDEAD2", 16);
			break;

		case 185453884:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_MDEAD3", 16);
			break;

		case 1972824823:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_STE01", 16);
			break;

		case -288258721:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_TDEAD1", 16);
			break;

		case -47439340:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_TDEAD2", 16);
			break;

		case -553769964:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_STN1", 16);
			break;

		case -1434443191:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_STN2", 16);
			break;

		case -2032593637:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_STN3", 16);
			break;

		case -458789713:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CUT1E", 16);
			break;

		case 321648831:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CUT2E", 16);
			break;

		case 312697495:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CUT3E", 16);
			break;

		case -1980743701:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_MPC1", 16);
			break;

		case 1567521709:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_FPC1", 16);
			break;

		case -1687842043:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TPC1", 16);
			break;

		case -1631047976:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_MPC2", 16);
			break;

		case 962970051:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_FPC2", 16);
			break;

		case -1323797481:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TPC2", 16);
			break;

		case 2095586439:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CAR1", 16);
			break;

		case 1608868018:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CAR2", 16);
			break;

		case 1134611425:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_CAR3", 16);
			break;

		case 187813079:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TRN1", 16);
			break;

		case -39544602:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TRN2", 16);
			break;

		case -997367701:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TRN3", 16);
			break;

		case -128912482:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_GETA1", 16);
			break;

		case -131238069:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_GETA2", 16);
			break;

		case -330732224:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_GETA3", 16);
			break;

		case -1334144471:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_RDY", 16);
			break;

		case -211946295:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_PREP", 16);
			break;

		case 1679209251:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_STNG", 16);
			break;

		case -1394105734:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_GETA", 16);
			break;

		case 94848458:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_DRILL", 16);
			break;

		case -1106471007:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_TRN", 16);
			break;

		case -268883259:
			StringCopy(uParam1, "FHFAUD", 16);
			StringCopy(&uParam1->f_4, "FHF_GAU", 16);
			break;

		case 546458037:
			StringCopy(uParam1, "FRFLAUD", 16);
			StringCopy(&uParam1->f_4, "FRFL_1LC", 16);
			break;

		case -2068958976:
			StringCopy(uParam1, "LSFLAUD", 16);
			StringCopy(&uParam1->f_4, "LSFL_ENG01", 16);
			break;

		case -1366489923:
			StringCopy(uParam1, "LSFLAUD", 16);
			StringCopy(&uParam1->f_4, "LSFL_ENG02", 16);
			break;

		case 406771743:
			StringCopy(uParam1, "LSFLAUD", 16);
			StringCopy(&uParam1->f_4, "LSFL_ENG03", 16);
			break;

		case -837794877:
			StringCopy(uParam1, "LSFLAUD", 16);
			StringCopy(&uParam1->f_4, "LSFL_ENG04", 16);
			break;

		case -78001721:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_C1", 16);
			break;

		case 327673956:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_C3A", 16);
			break;

		case -1746082591:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_P10A", 16);
			break;

		case -1945164276:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_P10B", 16);
			break;

		case -1052097629:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_BZD1", 16);
			break;

		case 1595158098:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_TRANSM", 16);
			break;

		case -420969532:
			StringCopy(uParam1, "JHFAUD", 16);
			StringCopy(&uParam1->f_4, "JHF_TRANSF", 16);
			break;

		case -441095892:
			StringCopy(uParam1, "MIFLAUD", 16);
			StringCopy(&uParam1->f_4, "MIFL_DAVE", 16);
			break;

		case 153235461:
			StringCopy(uParam1, "MIFLAUD", 16);
			StringCopy(&uParam1->f_4, "MIFL_TR1", 16);
			break;

		case -375893868:
			StringCopy(uParam1, "MIFLAUD", 16);
			StringCopy(&uParam1->f_4, "MIFL_PREM", 16);
			break;

		case -67922520:
			StringCopy(uParam1, "MIFLAUD", 16);
			StringCopy(&uParam1->f_4, "MIFL_AM1", 16);
			break;

		case 707131591:
			StringCopy(uParam1, "PAP3AAU", 16);
			StringCopy(&uParam1->f_4, "PAP3A_ENDCAL", 16);
			break;

		case 2033185762:
			StringCopy(uParam1, "PAFLAUD", 16);
			StringCopy(&uParam1->f_4, "PAFL_01", 16);
			break;

		case 1801771084:
			StringCopy(uParam1, "PAFLAUD", 16);
			StringCopy(&uParam1->f_4, "PAFL_02", 16);
			break;

		case -1716308760:
			StringCopy(uParam1, "PAFLAUD", 16);
			StringCopy(&uParam1->f_4, "PAFL_03", 16);
			break;

		case -2116452823:
			StringCopy(uParam1, "RHFAUD", 16);
			StringCopy(&uParam1->f_4, "RHF_C1", 16);
			break;

		case -1141220854:
			StringCopy(uParam1, "RHFAUD", 16);
			StringCopy(&uParam1->f_4, "RHF_C1A", 16);
			break;

		case 1880611494:
			StringCopy(uParam1, "RHFAUD", 16);
			StringCopy(&uParam1->f_4, "RHF_C2", 16);
			break;

		case -1276059507:
			StringCopy(uParam1, "RHFAUD", 16);
			StringCopy(&uParam1->f_4, "RHF_C2A", 16);
			break;

		case -1434698871:
			StringCopy(uParam1, "RHFAUD", 16);
			StringCopy(&uParam1->f_4, "RHF_C3", 16);
			break;

		case 1080702705:
			StringCopy(uParam1, "FNFLAUD", 16);
			StringCopy(&uParam1->f_4, "FNFL_TANISHA", 16);
			break;

		case 1632742627:
			StringCopy(uParam1, "FMFLAUD", 16);
			StringCopy(&uParam1->f_4, "FMFL_CALL2B", 16);
			break;

		case -1074970768:
			StringCopy(uParam1, "SLFLAUD", 16);
			StringCopy(&uParam1->f_4, "SLFL_MAR04", 16);
			break;

		case 643619115:
			StringCopy(uParam1, "T1M4AUD", 16);
			StringCopy(&uParam1->f_4, "SOL3_PASS", 16);
			break;

		case 720676600:
			StringCopy(uParam1, "DIVEAU", 16);
			StringCopy(&uParam1->f_4, "DIVE_PHONE", 16);
			break;

		case 1303349750:
			StringCopy(uParam1, "SONARAU", 16);
			StringCopy(&uParam1->f_4, "SONAR_PHONE", 16);
			break;

		case -1343914045:
			StringCopy(uParam1, "TRV5AUD", 16);
			StringCopy(&uParam1->f_4, "TRV5_LESCALL", 16);
			break;

		case -1199050901:
			StringCopy(uParam1, "REBU2AU", 16);
			StringCopy(&uParam1->f_4, "REBU2_CALLM", 16);
			break;

		case 1082655975:
			StringCopy(uParam1, "REBU2AU", 16);
			StringCopy(&uParam1->f_4, "REBU2_CALLF", 16);
			break;

		case -2100435596:
			StringCopy(uParam1, "REBU2AU", 16);
			StringCopy(&uParam1->f_4, "REBU2_CALLT", 16);
			break;

		case -974942855:
			StringCopy(uParam1, "HAO1AU", 16);
			StringCopy(&uParam1->f_4, "HAO1_PCW", 16);
			break;

		case -577064562:
			StringCopy(uParam1, "TOWAUD", 16);
			StringCopy(&uParam1->f_4, "TOW_CALLSALE", 16);
			break;

		case 2025906743:
			StringCopy(uParam1, "PROPAUD", 16);
			StringCopy(&uParam1->f_4, "PRP_INTRO", 16);
			break;

		case -1404384954:
			StringCopy(uParam1, "PROPAUD", 16);
			StringCopy(&uParam1->f_4, "PRP_INTROM", 16);
			break;

		case -112860461:
			StringCopy(uParam1, "PROPAUD", 16);
			StringCopy(&uParam1->f_4, "PRP_INTROF2", 16);
			break;

		case 339632201:
			StringCopy(uParam1, "PMPLANE", 16);
			StringCopy(&uParam1->f_4, "PMPLA_MAN", 16);
			break;

		case 453095043:
			StringCopy(uParam1, "PROPAUD", 16);
			StringCopy(&uParam1->f_4, "PRP_INTROF", 16);
			break;

		case 313472619:
			StringCopy(uParam1, "FMMAUD", 16);
			StringCopy(&uParam1->f_4, "FMM_GRGa", 16);
			break;

		case 2038672434:
			StringCopy(uParam1, "FMMAUD", 16);
			StringCopy(&uParam1->f_4, "FMM_GRRa", 16);
			break;

		case 1666308520:
			StringCopy(uParam1, "FMMAUD", 16);
			StringCopy(&uParam1->f_4, "FMM_GRCa", 16);
			break;

		case 1894462438:
			StringCopy(uParam1, "FMMAUD", 16);
			StringCopy(&uParam1->f_4, "FMM_GRHa", 16);
			break;

		case 1728635625:
			StringCopy(uParam1, "FMFAUD", 16);
			StringCopy(&uParam1->f_4, "FMF_GRGa", 16);
			break;

		case 975196153:
			StringCopy(uParam1, "FMFAUD", 16);
			StringCopy(&uParam1->f_4, "FMF_GRRa", 16);
			break;

		case -710274964:
			StringCopy(uParam1, "FMFAUD", 16);
			StringCopy(&uParam1->f_4, "FMF_GRCa", 16);
			break;

		case 1289879258:
			StringCopy(uParam1, "FMFAUD", 16);
			StringCopy(&uParam1->f_4, "FMF_GRB", 16);
			break;

		case 1621076324:
			StringCopy(uParam1, "FMFAUD", 16);
			StringCopy(&uParam1->f_4, "FMF_GRHa", 16);
			break;

		case 1005256598:
			StringCopy(uParam1, "FMTAUD", 16);
			StringCopy(&uParam1->f_4, "FMT_GRGa", 16);
			break;

		case 1127548000:
			StringCopy(uParam1, "FMTAUD", 16);
			StringCopy(&uParam1->f_4, "FMT_GRRa", 16);
			break;

		case -1291788156:
			StringCopy(uParam1, "FMTAUD", 16);
			StringCopy(&uParam1->f_4, "FMT_GRCa", 16);
			break;

		case 1993031175:
			StringCopy(uParam1, "FMTAUD", 16);
			StringCopy(&uParam1->f_4, "FMT_GRHa", 16);
			break;

		default:
			switch (iParam0) {
			case 2111803439:
				StringCopy(uParam1, "FMFLAUD", 16);
				StringCopy(&uParam1->f_4, "FMFL_AM1", 16);
				break;

			case 1290939985:
				StringCopy(uParam1, "FMFLAUD", 16);
				StringCopy(&uParam1->f_4, "FMFL_AM2", 16);
				break;

			case -1690219790:
				StringCopy(uParam1, "FMFLAUD", 16);
				StringCopy(&uParam1->f_4, "FMFL_AM3", 16);
				break;

			case 1766909710:
				StringCopy(uParam1, "FMFLAUD", 16);
				StringCopy(&uParam1->f_4, "FMFL_AM4", 16);
				break;

			case -358013836:
				StringCopy(uParam1, "HTAMBAU", 16);
				StringCopy(&uParam1->f_4, "HTAMB_PH1", 16);
				break;

			case -589035286:
				StringCopy(uParam1, "HTAMBAU", 16);
				StringCopy(&uParam1->f_4, "HTAMB_PH2", 16);
				break;

			case -1842374536:
				StringCopy(uParam1, "HTAMBAU", 16);
				StringCopy(&uParam1->f_4, "HTAMB_PH3", 16);
				break;

			case -418954710:
				StringCopy(uParam1, "HTAMBAU", 16);
				StringCopy(&uParam1->f_4, "HTAMB_PH4", 16);
				break;

			case -1783816333:
				StringCopy(uParam1, "HTAMBAU", 16);
				StringCopy(&uParam1->f_4, "HTAMB_PH5", 16);
				break;

			case 1438498239:
				StringCopy(uParam1, "JHFAUD", 16);
				StringCopy(&uParam1->f_4, "JHF_DAVE", 16);
				break;

			case -2139605007: StringCopy(&uParam1->f_4, "CHATC_DEV03", 16); break;

			case 1906711117: StringCopy(&uParam1->f_4, "CHATC_DEV04", 16); break;

			case -1949184344: StringCopy(&uParam1->f_4, "CHATC_DEV05", 16); break;

			case 2065444157: StringCopy(&uParam1->f_4, "CHATC_DEV06", 16); break;

			case 624853379: StringCopy(&uParam1->f_4, "CHATC_DEV07", 16); break;

			case -1766792090: StringCopy(&uParam1->f_4, "CHATC_DEV08", 16); break;

			case -1878340166: StringCopy(&uParam1->f_4, "CHATC_JIM05", 16); break;

			case 279793409: StringCopy(&uParam1->f_4, "CHATC_JIM06", 16); break;

			case 460547213: StringCopy(&uParam1->f_4, "CHATC_JIM07", 16); break;

			case -330856906: StringCopy(&uParam1->f_4, "CHATC_JIM08", 16); break;

			case -690594988: StringCopy(&uParam1->f_4, "CHATC_JIM09", 16); break;

			case -349863294: StringCopy(&uParam1->f_4, "CHATC_JIM10", 16); break;

			case 424926942: StringCopy(&uParam1->f_4, "CHATC_JIM11", 16); break;

			case 1890717037: StringCopy(&uParam1->f_4, "CHATC_JIM12", 16); break;

			case -1636767510: StringCopy(&uParam1->f_4, "CHATC_JIM13", 16); break;

			case -1893250473: StringCopy(&uParam1->f_4, "CHATC_JIM14", 16); break;

			case -1160994395: StringCopy(&uParam1->f_4, "CHATC_JIM15", 16); break;

			case 963157723: StringCopy(&uParam1->f_4, "CHATC_JIM16", 16); break;

			case 1730771548: StringCopy(&uParam1->f_4, "CHATC_JIM17", 16); break;

			case 1410028576: StringCopy(&uParam1->f_4, "CHATC_JIM18", 16); break;

			case -2082393141: StringCopy(&uParam1->f_4, "CHATC_JIM19", 16); break;

			case -1497396589: StringCopy(&uParam1->f_4, "CHATC_JIM20", 16); break;

			case -1196085634: StringCopy(&uParam1->f_4, "CHATC_JIM21", 16); break;

			case 170512742: StringCopy(&uParam1->f_4, "CHATC_JIM22", 16); break;

			case 469005563: StringCopy(&uParam1->f_4, "CHATC_JIM23", 16); break;

			case -306898819: StringCopy(&uParam1->f_4, "CHATC_JIM24", 16); break;

			case 82970585:
				StringCopy(uParam1, "CSFLAUD", 16);
				StringCopy(&uParam1->f_4, "LAM_06", 16);
				break;

			case 1867406480: StringCopy(&uParam1->f_4, "CHATC_LAM08", 16); break;

			case 1502097668: StringCopy(&uParam1->f_4, "CHATC_LAM09", 16); break;

			case -1621970384: StringCopy(&uParam1->f_4, "CHATC_LAM10", 16); break;

			case 1031237239: StringCopy(&uParam1->f_4, "CHATC_LAM11", 16); break;

			case 194808514: StringCopy(&uParam1->f_4, "CHATC_LAM12", 16); break;

			case 1509435260: StringCopy(&uParam1->f_4, "CHATC_LAM13", 16); break;

			case 673727449: StringCopy(&uParam1->f_4, "CHATC_LAM14", 16); break;

			case 71040001: StringCopy(&uParam1->f_4, "CHATC_LAM15", 16); break;

			case -755689100: StringCopy(&uParam1->f_4, "CHATC_LAM16", 16); break;

			case 556840426: StringCopy(&uParam1->f_4, "CHATC_LAM17", 16); break;

			case -177054098: StringCopy(&uParam1->f_4, "CHATC_LAM18", 16); break;

			case -835252192: StringCopy(&uParam1->f_4, "CHATC_LAM19", 16); break;

			case 616513703: StringCopy(&uParam1->f_4, "CHATC_LAM20", 16); break;

			case 2064117051:
				StringCopy(uParam1, "FNFLAUD", 16);
				StringCopy(&uParam1->f_4, "FNFL_LAM21", 16);
				break;

			case -1758542647: StringCopy(&uParam1->f_4, "CHATC_RON03", 16); break;

			case 1089542219: StringCopy(&uParam1->f_4, "CHATC_RON04", 16); break;

			case 675079903: StringCopy(&uParam1->f_4, "CHATC_RON05", 16); break;

			case -1613846760: StringCopy(&uParam1->f_4, "CHATC_SOL01", 16); break;

			case 518202687: StringCopy(&uParam1->f_4, "CHATC_SOL02", 16); break;

			case 946886745: StringCopy(&uParam1->f_4, "CHATC_SOL03", 16); break;

			case 1229388294: StringCopy(&uParam1->f_4, "CHATC_SOL04", 16); break;

			case 522335044: StringCopy(&uParam1->f_4, "CHATC_STR01", 16); break;

			case 2097475336: StringCopy(&uParam1->f_4, "CHATC_STR02", 16); break;

			case -108894207: StringCopy(&uParam1->f_4, "CHATC_STR03", 16); break;

			case -950205513: StringCopy(&uParam1->f_4, "CHATC_STR04", 16); break;

			case -703684326: StringCopy(&uParam1->f_4, "CHATC_STR05", 16); break;

			case -1982920067: StringCopy(&uParam1->f_4, "CHATC_TEXIL1", 16); break;

			case 1319343143: StringCopy(&uParam1->f_4, "CHATC_TEXIL2", 16); break;

			case -1118768768: StringCopy(&uParam1->f_4, "CHATC_TEXIL3", 16); break;

			case -705125709: StringCopy(&uParam1->f_4, "CHATC_TEXIL4", 16); break;

			case -782984853: StringCopy(&uParam1->f_4, "CHATC_TEXIL5", 16); break;

			case -92968020: StringCopy(&uParam1->f_4, "CHATC_TEXIL6", 16); break;

			case -406305198: StringCopy(&uParam1->f_4, "CHATC_TEXIL7", 16); break;

			case -1130010274:
				StringCopy(uParam1, "FMFLAUD", 16);
				StringCopy(&uParam1->f_4, "FMFL_TNOT", 16);
				break;

			case 684213521: StringCopy(&uParam1->f_4, "CHATC_TFAM", 16); break;

			case 1388615949: StringCopy(&uParam1->f_4, "CHATC_TFAM4", 16); break;

			case -2062910056: StringCopy(&uParam1->f_4, "CHATC_TFAM5", 16); break;

			case -643694497: StringCopy(&uParam1->f_4, "CHATC_WADE01", 16); break;

			case -278713375: StringCopy(&uParam1->f_4, "CHATC_WADE02", 16); break;

			case -1105442476: StringCopy(&uParam1->f_4, "CHATC_WADE04", 16); break;

			case -805704433: StringCopy(&uParam1->f_4, "CHATC_WADE05", 16); break;

			case -1565848713: StringCopy(&uParam1->f_4, "CHATC_MAR01", 16); break;

			case -1351801605: StringCopy(&uParam1->f_4, "CHATC_MAR02", 16); break;

			case 1311040108: StringCopy(&uParam1->f_4, "CHATC_MAR03", 16); break;

			case 1562602199: StringCopy(&uParam1->f_4, "CHATC_CHG1", 16); break;

			case 1113666899: StringCopy(&uParam1->f_4, "CHATC_CHG2", 16); break;

			case 814649774: StringCopy(&uParam1->f_4, "CHATC_CHG3", 16); break;

			case 225734768: StringCopy(&uParam1->f_4, "CHATC_HOSP", 16); break;

			default: break;
			}
			break;
		}
	}
	else {
		return;
	}
}

// Position - 0x51E6
bool func_79(int iParam0) {
	int *iVar0;

	if (iParam0 == -1 || iParam0 == 30) {
		return false;
	}
	func_80(iParam0, &iVar0);
	Call_Loc(iVar0);
	return StackVal;
}

// Position - 0x520F
void func_80(int iParam0, int *iParam1) {
	switch (iParam0) {
	case 0: *iParam1 = 23919 /*func_117*/; break;

	case 1: *iParam1 = 23818 /*func_116*/; break;

	case 2: *iParam1 = 23769 /*func_115*/; break;

	case 3: *iParam1 = 23735 /*func_114*/; break;

	case 4: *iParam1 = 23587 /*func_112*/; break;

	case 5: *iParam1 = 23564 /*func_111*/; break;

	case 6: *iParam1 = 23540 /*func_110*/; break;

	case 7: *iParam1 = 23302 /*func_109*/; break;

	case 8: *iParam1 = 23194 /*func_108*/; break;

	case 9: *iParam1 = 23170 /*func_107*/; break;

	case 10: *iParam1 = 23147 /*func_106*/; break;

	case 11: *iParam1 = 23123 /*func_105*/; break;

	case 12: *iParam1 = 22981 /*func_103*/; break;

	case 13: *iParam1 = 22958 /*func_102*/; break;

	case 14: *iParam1 = 22934 /*func_101*/; break;

	case 16: *iParam1 = 22902 /*func_100*/; break;

	case 17: *iParam1 = 22880 /*func_99*/; break;

	case 18: *iParam1 = 22714 /*func_97*/; break;

	case 19: *iParam1 = 22700 /*func_96*/; break;

	case 20: *iParam1 = 22676 /*func_95*/; break;

	case 21: *iParam1 = 22618 /*func_94*/; break;

	case 22: *iParam1 = 22558 /*func_93*/; break;

	case 23: *iParam1 = 21724 /*func_87*/; break;

	case 24: *iParam1 = 21697 /*func_86*/; break;

	case 25: *iParam1 = 21670 /*func_85*/; break;

	case 26: *iParam1 = 21643 /*func_84*/; break;

	case 27: *iParam1 = 21594 /*func_83*/; break;

	case 28: *iParam1 = 21545 /*func_82*/; break;

	case 29: *iParam1 = 21496 /*func_81*/; break;

	default: *iParam1 = 23919 /*func_117*/; break;
	}
}

// Position - 0x53F8
int func_81() {
	int iVar0;

	iVar0 = 5 - 3;
	if (iVar0 >= 0 && iVar0 < 3) {
		if (entity::does_entity_exist(Global_87658[iVar0])) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x5429
int func_82() {
	int iVar0;

	iVar0 = 4 - 3;
	if (iVar0 >= 0 && iVar0 < 3) {
		if (entity::does_entity_exist(Global_87658[iVar0])) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x545A
int func_83() {
	int iVar0;

	iVar0 = 3 - 3;
	if (iVar0 >= 0 && iVar0 < 3) {
		if (entity::does_entity_exist(Global_87658[iVar0])) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x548B
int func_84() {
	if (entity::does_entity_exist(Global_89302[2])) {
		return 0;
	}
	return 1;
}

// Position - 0x54A6
int func_85() {
	if (entity::does_entity_exist(Global_89302[1])) {
		return 0;
	}
	return 1;
}

// Position - 0x54C1
int func_86() {
	if (entity::does_entity_exist(Global_89302[0])) {
		return 0;
	}
	return 1;
}

// Position - 0x54DC
int func_87() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	if (script::is_thread_active(Global_101700.f_17062.f_395)) {
		return 0;
	}
	iVar0 = 4 - 3;
	if (iVar0 < 3) {
		if (entity::does_entity_exist(Global_87658[iVar0])) {
			return 0;
		}
	}
	iVar1 = 14;
	iVar2 = 5;
	iVar3 = time::get_clock_hours();
	if (iVar1 < iVar2) {
		if (iVar3 < iVar1 || iVar3 >= iVar2) {
			return 0;
		}
	}
	else if (iVar3 < iVar1 && iVar3 >= iVar2) {
		return 0;
	}
	iVar4 = func_91(func_92(ModifyAndGetSomeMessageCallState()), 4);
	if (iVar4 >= 9) {
		return 0;
	}
	else {
		if (Global_87680[iVar4 /*2*/] != 0) {
			return 0;
		}
		if (Global_101700.f_17062.f_175[iVar4 /*19*/].f_2 != 0) {
			return 0;
		}
		if (func_90(&Global_101700.f_17062.f_175[iVar4 /*19*/].f_5) &&
			func_88(&Global_101700.f_17062.f_175[iVar4 /*19*/].f_5) < 5f * 60f) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x55DA
float func_88(var *uParam0) {
	if (func_90(uParam0)) {
		if (func_89(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_69(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x5619
bool func_89(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x5629
bool func_90(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x5639
int func_91(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 != 0 && iParam0 != 1 && iParam0 != 2) {
		if (iParam1 == 0 || iParam1 == 1 || iParam1 == 2) {
			iVar0 = iParam1;
			iParam1 = iParam0;
			iParam0 = iVar0;
		}
	}
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: return 10;

		case 1: return 0;

		case 2: return 2;

		case 3: return 10;

		case 4: return 5;

		case 5: return 8;

		default: return 10;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: return 0;

		case 1: return 10;

		case 2: return 1;

		case 3: return 3;

		case 4: return 6;

		case 5: return 10;

		default: return 10;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return 2;

		case 1: return 1;

		case 2: return 10;

		case 3: return 4;

		case 4: return 7;

		case 5: return 10;

		default: return 10;
		}
		break;
	}
	return 10;
}

// Position - 0x57C3
int func_92(int iParam0) {
	if (iParam0 == 145) {
		return 7;
	}
	if (iParam0 < 150) {
		return Global_101700.f_27009[iParam0 /*29*/].f_11;
	}
	if (iParam0 == 144) {
		return 7;
	}
	if (iParam0 == 150) {
		return 6;
	}
	if (iParam0 == 151) {
		return 6;
	}
	return 6;
}

// Position - 0x581E
int func_93() {
	int iVar0;

	if (script::is_thread_active(Global_101700.f_17062.f_395)) {
		return 0;
	}
	iVar0 = 3 - 3;
	if (iVar0 < 3) {
		if (entity::does_entity_exist(Global_87658[iVar0])) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x585A
int func_94() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == 2033185762) {
			return 0;
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x5894
var func_95() { return gameplay::is_bit_set(Global_101700.f_17533[26 /*6*/], 3); }

// Position - 0x58AC
bool func_96() { return func_47(15); }

// Position - 0x58BA
int func_97() {
	float fVar0;

	if (Global_86826 == -1) {
		Global_86826 = gameplay::get_game_timer();
	}
	if (gameplay::get_game_timer() - Global_86826 > 240000) {
		Global_86826 = -1;
		return 1;
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		fVar0 = system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), func_98(212, 0));
		if (fVar0 > 22500f) {
			Global_86826 = -1;
			return 1;
		}
	}
	return 0;
}

// Position - 0x5922
Vector3 func_98(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 < 0 || iVar0 >= 263 || iParam0 == 263) {
		return 0f, 0f, 0f;
	}
	return Global_25501[iVar0 /*23*/][iParam1 /*3*/];
}

// Position - 0x5960
var func_99() { return Global_101700.f_8044.f_330[71 /*6*/]; }

// Position - 0x5976
int func_100() {
	if (Global_101700.f_8044.f_99.f_205[8] == 4) {
		return 1;
	}
	return 0;
}

// Position - 0x5996
bool func_101() { return !Global_101700.f_8044.f_99.f_58[77]; }

// Position - 0x59AE
var func_102() { return Global_101700.f_8044.f_99.f_58[77]; }

// Position - 0x59C5
int func_103() {
	if (func_47(88)) {
		return 1;
	}
	else if (func_104(88)) {
		return 1;
	}
	return 0;
}

// Position - 0x59EB
bool func_104(int iParam0) {
	int iVar0;

	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	if (Global_85809[iParam0 /*2*/]) {
		return true;
	}
	iVar0 = 0;
	while (iVar0 < Global_82576) {
		if (Global_82576[iVar0 /*5*/] != -1) {
			if (G_TextMessageConfig.f_109[Global_82576[iVar0 /*5*/] /*4*/] == iParam0) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x5A53
bool func_105() { return !Global_101700.f_8044.f_99.f_58[12]; }

// Position - 0x5A6B
var func_106() { return Global_101700.f_8044.f_99.f_58[12]; }

// Position - 0x5A82
bool func_107() { return !Global_101700.f_8044.f_99.f_58[34]; }

// Position - 0x5A9A
int func_108() {
	if (!func_47(40)) {
		return 0;
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (system::vdist2(func_98(181, 0), entity::get_entity_coords(player::player_ped_id(), 1)) > 40000f) {
			return 1;
		}
	}
	if (Global_86826 == -1) {
		Global_86826 = gameplay::get_game_timer();
	}
	if (gameplay::get_game_timer() - Global_86826 > 30000) {
		Global_86826 = -1;
		return 1;
	}
	return 0;
}

// Position - 0x5B06
int func_109() {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	while (iVar0 < 10) {
		iVar1 = 0;
		while (iVar1 < Global_87853[iVar0 /*19*/]) {
			iVar2 = 0;
			switch (iVar0) {
			case 1:
			case 2: iVar2 = func_47(90); break;

			case 3: iVar2 = func_47(74); break;

			case 4: iVar2 = func_47(75); break;

			case 5: iVar2 = func_47(93); break;

			case 6: iVar2 = func_47(69); break;

			case 7: iVar2 = func_47(70); break;

			case 8: iVar2 = func_47(84); break;

			case 9: iVar2 = func_47(85); break;
			}
			if (iVar2 && Global_101700.f_1.f_12[iVar0 /*6*/][iVar1] == 12) {
				return 1;
			}
			iVar1++;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x5BF4
bool func_110() { return !Global_101700.f_8044.f_99.f_58[45]; }

// Position - 0x5C0C
var func_111() { return Global_101700.f_8044.f_99.f_58[45]; }

// Position - 0x5C23
int func_112() {
	if (func_113(0)) {
		return 0;
	}
	return 1;
}

// Position - 0x5C38
bool func_113(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam0 >= 150) {
		return false;
	}
	iVar0 = func_92(iParam0);
	if (iVar0 != 7) {
		iVar1 = 0;
		while (iVar1 < 9) {
			if (Global_101700.f_17062.f_175[iVar1 /*19*/] == iVar0 ||
				Global_101700.f_17062.f_175[iVar1 /*19*/].f_1 == iVar0) {
				iVar2 = Global_87680[iVar1 /*2*/];
				if (iVar2 == 3 || iVar2 == 4) {
					return true;
				}
			}
			iVar1++;
		}
	}
	return false;
}

// Position - 0x5CB7
int func_114() {
	if (func_113(0)) {
		return 0;
	}
	if (func_104(49)) {
		return 0;
	}
	return 1;
}

// Position - 0x5CD9
int func_115() {
	int iVar0;

	if (func_113(0)) {
		return 0;
	}
	iVar0 = time::get_clock_hours();
	if (iVar0 < 6 || iVar0 > 14) {
		return 0;
	}
	return 1;
}

// Position - 0x5D0A
int func_116() {
	if (Global_86826 == -1) {
		Global_86826 = gameplay::get_game_timer();
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (!func_66(player::player_ped_id(), 11, 0)) {
			Global_86826 = -1;
			return 1;
		}
		if (gameplay::get_game_timer() - Global_86826 > 240000) {
			if (!func_66(player::player_ped_id(), 10, 0)) {
				Global_86826 = -1;
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x5D6F
int func_117() { return 1; }

// Position - 0x5D78
void func_118(var *uParam0) {
	int iVar0;

	if (LastDispatchedMessageOrCall != -1) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 1) && !G_SomeGlobalState.MessageCallStates.f_913) {
			func_138(uParam0, 0);
		}
		else {
			G_SomeGlobalState.MessageCallStates.f_912 = 1;
			func_120(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6, ModifyAndGetSomeMessageCallState());
			func_119();
			func_53(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
			G_SomeGlobalState.MessageCallStates.f_911 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/];
			Global_36332 = *uParam0 + 20000;
			Global_36333[G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6] = *uParam0 + 20000;
			func_11(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
			func_10(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
			func_14(LastDispatchedMessageOrCall);
			if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 15)) {
				switch (ModifyAndGetSomeMessageCallState()) {
				case 0: iVar0 = 0; break;

				case 1: iVar0 = 1; break;

				case 2: iVar0 = 2; break;
				}
				func_13(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6, iVar0);
				gameplay::clear_bit(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 15);
			}
			if (func_48(3)) {
				if (!func_47(1)) {
					if (func_37("AM_H_FCAL2")) {
						ui::clear_help(0);
					}
				}
			}
		}
	}
}

// Position - 0x5ED7
void func_119() {
	struct<165> Var0;

	Var0 = 16;
	Global_36163 = {Var0};
}

// Position - 0x5EF2
void func_120(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam0 != iParam1) {
		iVar0 = func_92(iParam0);
		iVar1 = func_92(iParam1);
		if (iVar0 != 7 && iVar1 != 7) {
			iVar2 = func_91(iVar0, iVar1);
			if (iVar2 != 10) {
				func_121(&Global_101700.f_17062.f_175[iVar2 /*19*/].f_5);
				Global_101700.f_17062.f_175[iVar2 /*19*/].f_8 = 0;
			}
		}
	}
}

// Position - 0x5F55
void func_121(var *uParam0) { func_68(uParam0, 0f); }

// Position - 0x5F64
bool func_122() {
	if (Global_15745 == 0) {
		return true;
	}
	return false;
}

// Position - 0x5F7B
void func_123(int iParam0) {
	if (Global_14604) {
		func_125(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_124()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x5FEB
bool func_124() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x6012
void func_125(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_134(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x6086
void func_126() {
	Global_14611 = 0;
	func_127();
}

// Position - 0x6096
void func_127() {
	if (audio::is_mobile_phone_call_ongoing() || Global_14442 == 1) {
		audio::restart_scripted_conversation();
		Global_16756 = 0;
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = Global_14445;
		return;
	}
}

// Position - 0x60CD
bool func_128() {
	switch (func_129(&Global_36329, 5, 0, 0, 0)) {
	case 1: return true;

	case 0: func_123(0); break;
	}
	return false;
}

// Position - 0x6101
int func_129(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_131(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_146(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_130(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0x6238
void func_130(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0x6287
bool func_131(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_146(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0x62A9
void func_132(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 20);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 20);
	}
}

// Position - 0x62CC
bool func_133() {
	if (Global_15745 == 4) {
		if (audio::is_mobile_phone_call_ongoing()) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0x62F1
bool func_134(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x634B
int func_135() {
	if (Global_15794 == 1 || Global_16761 == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x636E
int func_136() {
	if (Global_16761) {
		return 1;
	}
	return 0;
}

// Position - 0x6384
bool func_137() {
	if (Global_14428) {
		return true;
	}
	return false;
}

// Position - 0x639A
void func_138(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	func_123(0);
	if (func_37("AM_H_FCAL1")) {
		ui::clear_help(0);
	}
	if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 15)) {
		switch (ModifyAndGetSomeMessageCallState()) {
		case 0: iVar0 = 0; break;

		case 1: iVar0 = 1; break;

		case 2: iVar0 = 2; break;
		}
		func_13(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6, iVar0);
		gameplay::clear_bit(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 15);
	}
	if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 1)) {
		if (!G_SomeGlobalState.MessageCallStates.f_913) {
			gameplay::set_bit(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 10);
			func_142(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
			if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6 == 17) {
				func_54(125, 0);
			}
			else if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6 == 14) {
				func_54(126, 0);
			}
			else if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6 == 15) {
				func_54(127, 0);
			}
		}
	}
	if (Global_36329 != -1) {
		func_70();
		func_72(&Global_36329);
		iVar1 = 0;
		while (iVar1 < 9) {
			if (Global_101700.f_17062.f_175[iVar1 /*19*/].f_8 == 0) {
				func_68(&Global_101700.f_17062.f_175[iVar1 /*19*/].f_5, 300f);
			}
			iVar1++;
		}
	}
	if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 10) || iParam1) {
		func_141(*uParam0, &G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/], 0);
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 3)) {
			if (G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_5 < 300000) {
				G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_5 += 60000;
			}
		}
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 8)) {
			func_142(&G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
		}
	}
	else if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 11)) {
		func_139(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_10, 1, G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_2,
				 G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_6, G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_5,
				 G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_5, G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_7,
				 G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_8, G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_9,
				 G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/].f_1, 1);
		G_SomeGlobalState.MessageCallStates.f_911 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/];
		G_SomeGlobalState.MessageCallStates.f_912 = 0;
		func_11(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
		func_10(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
		func_14(LastDispatchedMessageOrCall);
	}
	else {
		G_SomeGlobalState.MessageCallStates.f_911 = G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/];
		G_SomeGlobalState.MessageCallStates.f_912 = 0;
		func_11(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
		func_10(G_SomeGlobalState.MessageCallStates[LastDispatchedMessageOrCall /*15*/]);
		func_14(LastDispatchedMessageOrCall);
	}
	func_119();
	LastDispatchedMessageOrCall = -1;
}

// Position - 0x66ED
int func_139(var uParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 var uParam8, var uParam9, int iParam10) {
	struct<14> Var0;

	if (func_4(0)) {
		return 0;
	}
	if (iParam4 < 0) {
		return 0;
	}
	if (iParam5 < 0) {
		return 0;
	}
	if (iParam6 == 76) {
		return 0;
	}
	if (iParam7 == 235) {
		return 0;
	}
	if (iParam3 < 3) {
		if (gameplay::is_bit_set(iParam2, iParam3)) {
			return 0;
		}
	}
	if (iParam2 < 1 || iParam2 > 7) {
		return 0;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 < 8) {
		Var0 = uParam0;
		Var0.f_3 = func_140(iParam1);
		Var0.f_4 = gameplay::get_game_timer() + iParam4;
		Var0.f_5 = iParam5;
		Var0.f_1 = uParam9;
		Var0.f_2 = iParam2;
		Var0.f_6 = iParam3;
		Var0.f_7 = iParam6;
		Var0.f_8 = iParam7;
		Var0.f_9 = uParam8;
		Var0.f_10 = -1;
		Var0.f_11 = -1;
		Var0.f_13 = iParam10;
		gameplay::clear_bit(&Var0.f_1, 0);
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 /*14*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_764++;
		func_8(0);
		func_8(1);
		func_8(2);
		return 1;
	}
	return 0;
}

// Position - 0x6808
int func_140(int iParam0) {
	switch (iParam0) {
	case 0:
	case 4: return 5;

	case 7: return 4;

	case 2: return 3;

	case 1: return 2;

	case 3: return 1;

	case 5:
	case 6: return 0;
	}
	return 7;
}

// Position - 0x6872
void func_141(int iParam0, var *uParam1, int iParam2) {
	if (uParam1->f_3 == 5) {
		uParam1->f_4 = iParam0 + 1000;
	}
	else if (iParam2) {
		uParam1->f_4 = iParam0 + 10000;
	}
	else {
		uParam1->f_4 = iParam0 + uParam1->f_5;
	}
}

// Position - 0x68AA
void func_142(var *uParam0) {
	if (!func_145(*uParam0)) {
		if (G_SomeGlobalState.MessageCallStates.f_198 < 4) {
			G_SomeGlobalState.MessageCallStates.f_137[G_SomeGlobalState.MessageCallStates.f_198 /*15*/] = {*uParam0};
			G_SomeGlobalState.MessageCallStates.f_198++;
			func_143(uParam0->f_6);
		}
	}
}

// Position - 0x6909
int func_143(int iParam0) {
	int iVar0;

	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] = 1;
		if (Global_101700.f_27009[iParam0 /*29*/].f_12[Global_14443] == 0) {
			iVar0 = Global_14443;
			func_144(iParam0, iVar0, 0);
		}
		return 1;
	}
	return 0;
}

// Position - 0x695E
void func_144(int iParam0, int iParam1, int iParam2) {
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (iParam1 == 4) {
			Global_101700.f_27009[iParam0 /*29*/].f_12[0] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[2] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[0] = 0;
			Global_101700.f_27009[iParam0 /*29*/].f_24[1] = 0;
			Global_101700.f_27009[iParam0 /*29*/].f_24[2] = 0;
		}
		else {
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 0;
		}
		if (iParam2) {
			Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
			Global_2923[1 /*6*/].f_5 = iParam1;
			gameplay::set_bit(&G_SleepModeOnOn25, 0);
		}
	}
}

// Position - 0x6A35
int func_145(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x6A6E
bool func_146(int iParam0) { return func_147(iParam0, Global_35781); }

// Position - 0x6A7F
int func_147(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x6C60
void func_148() {
	if (iLocal_84 == 1) {
		if (!func_167()) {
			audio::stop_sound(iLocal_89);
			audio::play_sound_frontend(-1, "End_Squelch", "CB_RADIO_SFX", 1);
			iLocal_84 = 0;
		}
		else if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
			func_165();
			audio::stop_sound(iLocal_89);
			audio::play_sound_frontend(-1, "End_Squelch", "CB_RADIO_SFX", 1);
			iLocal_84 = 0;
		}
	}
	else if (gameplay::get_game_timer() - iLocal_86 >= 10000 || iLocal_85 >= 1) {
		if (ModifyAndGetSomeMessageCallState() == 2) {
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					if (audio::_is_vehicle_radio_loud(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0))) {
						switch (iLocal_85) {
						case -1:
							iLocal_87 = gameplay::get_game_timer();
							iLocal_88 = gameplay::get_game_timer();
							iLocal_85++;
							iLocal_89 = audio::get_sound_id();
							break;

						case 0:
							if (gameplay::get_game_timer() - iLocal_87 >= 120000) {
								iLocal_85 = 1;
							}
							if (gameplay::get_game_timer() - iLocal_88 >= 300000) {
								iLocal_85 = 2;
							}
							break;

						case 1:
							if (func_164()) {
								iLocal_84 = 1;
								iLocal_87 = gameplay::get_game_timer();
								iLocal_85 = 0;
							}
							break;

						case 2:
							if (func_149()) {
								iLocal_84 = 1;
								iLocal_88 = gameplay::get_game_timer();
								iLocal_85 = 0;
							}
							break;
						}
					}
				}
				else if (iLocal_85 != -1) {
					iLocal_85 = -1;
				}
			}
		}
		iLocal_86 = gameplay::get_game_timer();
	}
}

// Position - 0x6D9F
bool func_149() {
	struct<2> Var0;
	int iVar4;
	struct<2> Var5;
	bool bVar9;
	int iVar10;
	int iVar11;
	struct<2> Var12;

	bVar9 = func_163();
	if (bVar9) {
		StringCopy(&Var0, "CB_MON", 16);
		iVar4 = func_161();
		StringIntConCat(&Var0, iVar4, 16);
		StringCopy(&Var5, "CB_CHAR", 16);
		StringIntConCat(&Var5, iVar4, 16);
		func_160(&uLocal_91, 3, 0, &Var5, 0, 0);
		if (func_151(&uLocal_91, "CBRADAU", &Var0, 1, 1, 0, 0)) {
			audio::play_sound_frontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1);
			audio::play_sound_frontend(iLocal_89, "Background_Loop", "CB_RADIO_SFX", 1);
			return true;
		}
	}
	else {
		StringCopy(&Var0, "CB_CONVO", 16);
		iVar4 = gameplay::get_random_int_in_range(1, 23);
		StringIntConCat(&Var0, iVar4, 16);
		func_150(iVar4, &iVar10, &iVar11);
		StringCopy(&Var5, "CB_CHAR", 16);
		StringIntConCat(&Var5, iVar10, 16);
		func_160(&uLocal_91, 3, 0, &Var5, 0, 0);
		StringCopy(&Var12, "CB_CHAR", 16);
		StringIntConCat(&Var12, iVar11, 16);
		func_160(&uLocal_91, 4, 0, &Var12, 0, 0);
		if (func_151(&uLocal_91, "CBRADAU", &Var0, 1, 1, 0, 0)) {
			audio::play_sound_frontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1);
			audio::play_sound_frontend(iLocal_89, "Background_Loop", "CB_RADIO_SFX", 1);
			return true;
		}
	}
	return false;
}

// Position - 0x6EA1
void func_150(int iParam0, int *iParam1, int *iParam2) {
	switch (iParam0) {
	case 1:
		*iParam1 = 1;
		*iParam2 = 8;
		break;

	case 2:
		*iParam1 = 5;
		*iParam2 = 2;
		break;

	case 3:
		*iParam1 = 3;
		*iParam2 = 10;
		break;

	case 4:
		*iParam1 = 4;
		*iParam2 = 13;
		break;

	case 5:
		*iParam1 = 7;
		*iParam2 = 6;
		break;

	case 6:
		*iParam1 = 12;
		*iParam2 = 9;
		break;

	case 7:
		*iParam1 = 11;
		*iParam2 = 44;
		break;

	case 8:
		*iParam1 = 34;
		*iParam2 = 14;
		break;

	case 9:
		*iParam1 = 15;
		*iParam2 = 28;
		break;

	case 10:
		*iParam1 = 43;
		*iParam2 = 16;
		break;

	case 11:
		*iParam1 = 17;
		*iParam2 = 18;
		break;

	case 12:
		*iParam1 = 19;
		*iParam2 = 20;
		break;

	case 13:
		*iParam1 = 26;
		*iParam2 = 21;
		break;

	case 14:
		*iParam1 = 22;
		*iParam2 = 23;
		break;

	case 15:
		*iParam1 = 24;
		*iParam2 = 25;
		break;

	case 16:
		*iParam1 = 27;
		*iParam2 = 29;
		break;

	case 17:
		*iParam1 = 30;
		*iParam2 = 31;
		break;

	case 18:
		*iParam1 = 33;
		*iParam2 = 32;
		break;

	case 19:
		*iParam1 = 35;
		*iParam2 = 36;
		break;

	case 20:
		*iParam1 = 38;
		*iParam2 = 37;
		break;

	case 21:
		*iParam1 = 40;
		*iParam2 = 39;
		break;

	case 22:
		*iParam1 = 41;
		*iParam2 = 42;
		break;

	default:
		*iParam1 = 1;
		*iParam2 = 2;
		break;
	}
}

// Position - 0x7056
bool func_151(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_159(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_152(sParam2, iParam3, 0);
}

// Position - 0x70A4
int func_152(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_158();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_157(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_156();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_57();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_155()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_124()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_154();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_153();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_158();
	}
	return 0;
}

// Position - 0x7370
void func_153() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x73A1
void func_154() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x7436
bool func_155() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x74CF
void func_156() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x7526
bool func_157(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x7561
void func_158() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x75B8
void func_159(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x760E
void func_160(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x76A9
int func_161() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_26();
	iVar1 = func_19(iVar0);
	iVar2 = 0;
	while (iVar2 == 0) {
		iVar3 = gameplay::get_random_int_in_range(1, 44);
		switch (iVar3) {
		case 5:
			if (iVar1 > 19) {
				iVar2 = 0;
			}
			else if (iVar1 < 9) {
				iVar2 = 0;
			}
			else if (!func_162(iVar3)) {
				iVar2 = 0;
			}
			else {
				iVar2 = 1;
			}
			break;

		default: iVar2 = 1; break;
		}
		system::wait(0);
	}
	return iVar3;
}

// Position - 0x771E
int func_162(int iParam0) {
	switch (iParam0) {
	case 5:
		if (gameplay::is_prev_weather_type("SMOG") || gameplay::is_prev_weather_type("OVERCAST") ||
			gameplay::is_prev_weather_type("RAIN") || gameplay::is_prev_weather_type("THUNDER") ||
			gameplay::is_prev_weather_type("SNOW") || gameplay::is_next_weather_type("SMOG") ||
			gameplay::is_next_weather_type("OVERCAST") || gameplay::is_next_weather_type("RAIN") ||
			gameplay::is_next_weather_type("THUNDER") || gameplay::is_next_weather_type("SNOW")) {
			return 0;
		}
		break;

	default: return 1;
	}
	return 1;
}

// Position - 0x77CB
int func_163() {
	if (gameplay::is_bit_set(gameplay::get_random_int_in_range(0, 65535), 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x77EC
bool func_164() {
	struct<2> Var0;
	int iVar4;
	struct<2> Var5;

	StringCopy(&Var0, "CB_IDN", 16);
	iVar4 = gameplay::get_random_int_in_range(1, 44);
	StringIntConCat(&Var0, iVar4, 16);
	StringCopy(&Var5, "CB_CHAR", 16);
	StringIntConCat(&Var5, iVar4, 16);
	func_160(&uLocal_91, 3, 0, &Var5, 0, 0);
	if (func_151(&uLocal_91, "CBRADAU", &Var0, 1, 1, 0, 0)) {
		audio::play_sound_frontend(-1, "Start_Squelch", "CB_RADIO_SFX", 1);
		audio::play_sound_frontend(iLocal_89, "Background_Loop", "CB_RADIO_SFX", 1);
		return true;
	}
	return false;
}

// Position - 0x785A
void func_165() {
	Global_14611 = 0;
	func_166();
}

// Position - 0x786A
void func_166() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0x788B
int func_167() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return 1;
	}
	return 0;
}

// Position - 0x78AD
int func_168() {
	if (Global_88746 != -1) {
		return gameplay::is_bit_set(Global_82612[Global_88746 /*34*/].f_15, 13);
	}
	return 0;
}

// Position - 0x78D3
void func_169(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_9(ModifyAndGetSomeMessageCallState())) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866 && !iLocal_78) {
		func_203(&G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/]);
		iVar1 = 0;
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_3 >= 5) {
			iVar1 = 1;
		}
		if (*uParam0 >= Global_36332 || gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_1, 21) ||
			iVar1) {
			if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_6] || iVar1) {
				if (*uParam0 >= G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_4) {
					if (func_171(&G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/])) {
						iLocal_82 = -1;
						func_170(uParam0, &G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/]);
						func_6(iVar0);
						iLocal_78 = 1;
					}
					else {
						func_141(*uParam0, &G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/], 0);
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x79F0
void func_170(var *uParam0, var *uParam1) {
	func_53(uParam1);
	G_SomeGlobalState.MessageCallStates.f_918 = *uParam1;
	Global_36332 = *uParam0 + 20000;
	if (uParam1->f_6 != 144) {
		Global_36333[uParam1->f_6] = *uParam0 + 20000;
	}
}

// Position - 0x7A2C
bool func_171(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (func_134(0) || IsGlobalFlag1Set() || func_201()) {
		return false;
	}
	if (!CanMessageOrCallBeReceived(uParam0->f_2, uParam0->f_6, uParam0->f_3, uParam0->f_7, uParam0->f_1)) {
		return false;
	}
	if (uParam0->f_9 != -1) {
		if (!func_79(uParam0->f_9)) {
			return false;
		}
	}
	if (uParam0->f_7 != -1) {
		if (func_66(player::player_ped_id(), uParam0->f_7, 0)) {
			return false;
		}
	}
	func_186(*uParam0, &iVar0);
	iVar2 = 0;
	if (gameplay::is_bit_set(uParam0->f_1, 16)) {
		iVar2 = 1;
	}
	if (gameplay::is_bit_set(uParam0->f_2, func_185()) || iVar2) {
		iVar1 = 0;
		while (iVar1 < 3) {
			if (gameplay::is_bit_set(uParam0->f_2, iVar1)) {
				if (func_184(iVar0)) {
					if (!func_183(iVar0)) {
						func_175(iVar0, iVar2);
						return true;
					}
					else {
						return false;
					}
				}
				else {
					func_172(iVar0, iVar2);
					return true;
				}
			}
			iVar1++;
		}
	}
	return false;
}

// Position - 0x7B30
void func_172(int iParam0, int iParam1) { func_173(iParam0, iParam1); }

// Position - 0x7B40
void func_173(int iParam0, int iParam1) {
	Global_36916 = 1;
	if (!Global_40250[iParam0 /*46*/] && !Global_40250[iParam0 /*46*/].f_1) {
		Global_40250[iParam0 /*46*/] = 1;
		func_175(iParam0, iParam1);
	}
	else {
		func_174(iParam0);
		func_173(iParam0, iParam1);
	}
}

// Position - 0x7B87
void func_174(int iParam0) {
	Global_40250[iParam0 /*46*/] = 0;
	Global_40250[iParam0 /*46*/].f_31 = 0;
	Global_40250[iParam0 /*46*/].f_42 = 0;
	Global_40250[iParam0 /*46*/].f_45 = 0;
	Global_40250[iParam0 /*46*/].f_43 = 0;
	Global_40250[iParam0 /*46*/].f_1 = 0;
}

// Position - 0x7BC9
void func_175(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (!Global_40250[iParam0 /*46*/] && !Global_40250[iParam0 /*46*/].f_1) {
		return;
	}
	if (Global_40250[iParam0 /*46*/].f_31 == Global_40250[iParam0 /*46*/].f_30) {
		iVar0 = Global_40250[iParam0 /*46*/].f_42 - 1;
		if (iVar0 < 0) {
			return;
		}
		if (Global_36925[Global_40250[iParam0 /*46*/].f_32[iVar0] /*12*/].f_4 == 0) {
			Global_40250[iParam0 /*46*/].f_1 = 1;
		}
		return;
	}
	if (Global_40250[iParam0 /*46*/].f_1) {
		return;
	}
	iVar1 = Global_40250[iParam0 /*46*/].f_8[Global_40250[iParam0 /*46*/].f_31];
	Global_40250[iParam0 /*46*/].f_31++;
	func_182(iParam0, iVar1);
	Global_40250[iParam0 /*46*/].f_45 = Global_36925[iVar1 /*12*/].f_10;
	Global_40250[iParam0 /*46*/].f_43 = Global_36925[iVar1 /*12*/].f_11;
	iVar2 = Global_40250[iParam0 /*46*/].f_2;
	func_176(Global_36925[iVar1 /*12*/].f_3, iParam0, 0, 0, iParam1);
	iVar3 = 0;
	while (iVar3 < iVar2) {
		if (Global_40250[iParam0 /*46*/].f_3[iVar3] != Global_36925[iVar1 /*12*/].f_2 &&
			Global_40250[iParam0 /*46*/].f_3[iVar3] != Global_36925[iVar1 /*12*/].f_3) {
			func_176(Global_40250[iParam0 /*46*/].f_3[iVar3], iParam0, 0, 0, iParam1);
		}
		iVar3++;
	}
	if (Global_40250[iParam0 /*46*/].f_31 == Global_40250[iParam0 /*46*/].f_30) {
		if (Global_36925[Global_40250[iParam0 /*46*/].f_32[Global_40250[iParam0 /*46*/].f_42 - 1] /*12*/].f_4 == 0) {
			Global_40250[iParam0 /*46*/].f_1 = 1;
			return;
		}
	}
}

// Position - 0x7D65
void func_176(int iParam0, int iParam1, int iParam2, int iParam3, bool bParam4) {
	int iVar0;
	int iVar1;
	int iVar2;
	struct<16> Var3;
	int iVar19;
	int iVar20;
	bool bVar21;
	bool bVar22;
	int iVar23;
	int iVar24;
	int iVar25;
	int iVar26;

	if (iParam0 >= 3) {
		return;
	}
	iVar0 = -1;
	StringCopy(&Var3, "UNSET", 64);
	if (!iParam2) {
		iVar19 = Global_40250[iParam1 /*46*/].f_42 - 1;
		if (iVar19 < 0) {
			return;
		}
		iVar20 = Global_40250[iParam1 /*46*/].f_32[iVar19];
		iVar2 = iVar20;
		Var3 = {func_181(Global_36925[iVar20 /*12*/].f_1)};
		if (Global_36925[iVar20 /*12*/].f_2 == iParam0 && Global_36925[iVar20 /*12*/].f_3 != iParam0) {
			return;
		}
		iVar1 = Global_36925[iVar20 /*12*/].f_2;
		iVar0 = Global_45863[iParam0 /*120*/];
		bVar21 = false;
		while (iVar0 >= 16) {
			iVar0 -= 16;
			bVar21 = true;
		}
		if (bVar21) {
			if (!Global_45863[iParam0 /*120*/].f_69[iVar0]) {
				switch (iParam0) {
				case 0:
					Global_36917--;
					if (Global_36917 < 0) {
						Global_36917 = 0;
					}
					break;

				case 1:
					Global_36918--;
					if (Global_36918 < 0) {
						Global_36918 = 0;
					}
					break;

				case 2:
					Global_36919--;
					if (Global_36919 < 0) {
						Global_36919 = 0;
					}
					break;
				}
			}
		}
		Global_45863[iParam0 /*120*/].f_18[iVar0] = iParam1;
		Global_45863[iParam0 /*120*/].f_1[iVar0] = iVar19;
		Global_45863[iParam0 /*120*/].f_35[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_86[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_69[iVar0] = 0;
		Global_45863[iParam0 /*120*/]++;
	}
	else {
		iVar0 = Global_45863[iParam0 /*120*/];
		bVar22 = false;
		while (iVar0 >= 16) {
			iVar0 -= 16;
			bVar22 = true;
		}
		if (bVar22) {
			if (!Global_45863[iParam0 /*120*/].f_69[iVar0]) {
				switch (iParam0) {
				case 0:
					Global_36917--;
					if (Global_36917 < 0) {
						Global_36917 = 0;
					}
					break;

				case 1:
					Global_36918--;
					if (Global_36918 < 0) {
						Global_36918 = 0;
					}
					break;

				case 2:
					Global_36919--;
					if (Global_36919 < 0) {
						Global_36919 = 0;
					}
					break;
				}
			}
		}
		iVar23 = -1;
		iVar24 = 0;
		iVar24 = 0;
		while (iVar24 < 7) {
			if (Global_46225[iVar24 /*203*/].f_1 == iParam1 && Global_46225[iVar24 /*203*/].f_9 > 0) {
				iVar23 = iVar24;
			}
			iVar24++;
		}
		if (iVar23 == -1) {
			return;
		}
		Global_45863[iParam0 /*120*/].f_18[iVar0] = Global_46225[iVar23 /*203*/].f_1;
		Global_45863[iParam0 /*120*/].f_1[iVar0] = Global_46225[iVar23 /*203*/].f_9 - 1;
		Global_45863[iParam0 /*120*/].f_35[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_86[iVar0] = 1;
		Global_45863[iParam0 /*120*/].f_69[iVar0] = 0;
		Global_45863[iParam0 /*120*/]++;
		iVar25 = Global_45863[iParam0 /*120*/].f_1[iVar0];
		iVar26 = Global_46225[iVar23 /*203*/].f_10[iVar25 /*48*/];
		iVar2 = iVar26;
		iVar1 = Global_36925[iVar26 /*12*/].f_2;
		if (Global_46225[iVar23 /*203*/].f_10[Global_46225[iVar23 /*203*/].f_9 - 1 /*48*/].f_1) {
			MemCopy(&Var3, {Global_46225[iVar23 /*203*/].f_10[Global_46225[iVar23 /*203*/].f_9 - 1 /*48*/].f_2}, 16);
		}
		else {
			Var3 = {func_181(Global_36925[iVar26 /*12*/].f_1)};
		}
	}
	if (!bParam4) {
		if (!Global_45863[iParam0 /*120*/].f_69[iVar0] && !iParam3) {
			switch (iParam0) {
			case 0: func_177(0, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); break;

			case 1:
				if (iVar2 == 249) {
					func_177(1, iVar1, iVar2, "PW_FEED_EM_1", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
				}
				else {
					func_177(1, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
				}
				break;

			case 2: func_177(2, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); break;
			}
		}
	}
}

// Position - 0x813C
void func_177(int iParam0, int iParam1, int iParam2, char *sParam3, char *sParam4, char *sParam5, char *sParam6,
			  char *sParam7, char *sParam8, char *sParam9, char *sParam10, char *sParam11, char *sParam12,
			  char *sParam13) {
	int iVar0;
	bool bVar1;
	char cVar2[64];

	if (cutscene::is_cutscene_playing()) {
		return;
	}
	iVar0 = ModifyAndGetSomeMessageCallState();
	bVar1 = false;
	StringCopy(&cVar2, func_180(iParam1, &bVar1), 64);
	if (iVar0 == iParam0) {
		switch (iParam2) {
		case 72: ui::_set_notification_text_entry("PROPR_INCEMAIL1"); break;

		case 73: ui::_set_notification_text_entry("PROPR_INCEMAIL3"); break;

		case 74: ui::_set_notification_text_entry("PROPR_INCEMAIL2"); break;

		default:
			ui::_set_notification_text_entry(sParam3);
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				ui::add_text_component_substring_text_label(sParam4);
			}
			if (!gameplay::is_string_null_or_empty(sParam5)) {
				ui::add_text_component_substring_text_label(sParam5);
			}
			if (!gameplay::is_string_null_or_empty(sParam6)) {
				ui::add_text_component_substring_text_label(sParam6);
			}
			if (!gameplay::is_string_null_or_empty(sParam7)) {
				ui::add_text_component_substring_text_label(sParam7);
			}
			if (!gameplay::is_string_null_or_empty(sParam8)) {
				ui::add_text_component_substring_text_label(sParam8);
			}
			if (!gameplay::is_string_null_or_empty(sParam9)) {
				ui::add_text_component_substring_text_label(sParam9);
			}
			if (!gameplay::is_string_null_or_empty(sParam10)) {
				ui::add_text_component_substring_text_label(sParam10);
			}
			if (!gameplay::is_string_null_or_empty(sParam11)) {
				ui::add_text_component_substring_text_label(sParam11);
			}
			if (!gameplay::is_string_null_or_empty(sParam12)) {
				ui::add_text_component_substring_text_label(sParam12);
			}
			if (!gameplay::is_string_null_or_empty(sParam13)) {
				ui::add_text_component_substring_text_label(sParam13);
			}
			break;
		}
		if (bVar1) {
			func_178(ui::_set_notification_message(&cVar2, &cVar2, 0, 2, ui::_get_label_text(func_179(iParam1)), 0));
		}
		else {
			func_178(ui::_set_notification_message("CHAR_DEFAULT", "CHAR_DEFAULT", 0, 2,
												   ui::_get_label_text(func_179(iParam1)), 0));
		}
		switch (Global_14443) {
		case 0:
			StringCopy(&Global_14432, "Phone_SoundSet_Michael", 24);
			Global_36917++;
			if (Global_36917 > 16) {
				Global_36917 = 16;
			}
			break;

		case 2:
			StringCopy(&Global_14432, "Phone_SoundSet_Trevor", 24);
			Global_36919++;
			if (Global_36919 > 16) {
				Global_36919 = 16;
			}
			break;

		case 1:
			StringCopy(&Global_14432, "Phone_SoundSet_Franklin", 24);
			Global_36918++;
			if (Global_36918 > 16) {
				Global_36918 = 16;
			}
			break;

		default: StringCopy(&Global_14432, "Phone_SoundSet_Default", 24); break;
		}
		audio::play_sound_frontend(-1, "Notification", &Global_14432, 1);
	}
}

// Position - 0x8324
void func_178(var uParam0) {
	Global_36920[Global_36924] = uParam0;
	Global_16803 = 1;
	Global_16802 = uParam0;
	Global_36924++;
	if (Global_36924 == 3) {
		Global_36924 = 0;
	}
}

// Position - 0x8352
char *func_179(int iParam0) {
	switch (iParam0) {
	case 0: return "EMSTR_0";

	case 3: return "EMSTR_3";

	case 1: return "EMSTR_6";

	case 2: return "EMSTR_9";

	case 4: return "EMSTR_12";

	case 5: return "EMSTR_29";

	case 6: return "EMSTR_36";

	case 7: return "EMSTR_39";

	case 8: return "EMSTR_52";

	case 9: return "EMSTR_55";

	case 10: return "EMSTR_58";

	case 11: return "EMSTR_78";

	case 12: return "EMSTR_81";

	case 13: return "EMSTR_84";

	case 14: return "EMSTR_87";

	case 15: return "EMSTR_106";

	case 16: return "EMSTR_114";

	case 17: return "EMSTR_142";

	case 18: return "EMSTR_145";

	case 19: return "EMSTR_152";

	case 20: return "EMSTR_157";

	case 21: return "EMSTR_163";

	case 22: return "EMSTR_182";

	case 23: return "EMSTR_187";

	case 24: return "EMSTR_190";

	case 25: return "EMSTR_206";

	case 26: return "EMSTR_219";

	case 27: return "EMSTR_226";

	case 28: return "EMSTR_233";

	case 29: return "EMSTR_242";

	case 30: return "EMSTR_249";

	case 31: return "EMSTR_262";

	case 32: return "EMSTR_269";

	case 33: return "EMSTR_319";

	case 34: return "EMSTR_340";

	case 35: return "EMSTR_348";

	case 36: return "EMSTR_182";

	case 37: return "EMSTR_357";

	case 38: return "EMSTR_360";

	case 39: return "EMSTR_369";

	case 40: return "EMSTR_376";

	case 41: return "EMSTR_379";

	case 42: return "EMSTR_382";

	case 43: return "EMSTR_384";

	case 44: return "EMSTR_387";

	case 45: return "EMSTR_390";

	case 46: return "EMSTR_393";

	case 47: return "EMSTR_396";

	case 48: return "EMSTR_399";

	case 49: return "EMSTR_402";

	case 50: return "EMSTR_405";

	case 51: return "EMSTR_408";

	case 52: return "EMSTR_411";

	case 53: return "EMSTR_414";

	case 54: return "EMSTR_465";

	case 55: return "EMSTR_468";

	case 56: return "EMSTR_489";

	case 57: return "EMSTR_492";

	case 58: return "EMSTR_495";

	case 59: return "EMSTR_498";

	case 60: return "EMSTR_501";

	case 61: return "EMSTR_504";

	case 62: return "EMSTR_507";

	case 63: return "EMSTR_640";

	case 64: return "EMSTR_643";

	case 65: return "EMSTR_652";

	default:
	}
	return "NULL";
}

// Position - 0x86BD
char *func_180(int iParam0, int *iParam1) {
	*iParam1 = 1;
	switch (iParam0) {
	case 0: return ui::_get_label_text(&Global_101700.f_27009[0 /*29*/].f_7);

	case 1: return ui::_get_label_text(&Global_101700.f_27009[1 /*29*/].f_7);

	case 2: return ui::_get_label_text(&Global_101700.f_27009[2 /*29*/].f_7);

	case 7: return ui::_get_label_text(&Global_101700.f_27009[12 /*29*/].f_7);

	case 4: return ui::_get_label_text(&Global_101700.f_27009[60 /*29*/].f_7);

	case 6: return ui::_get_label_text(&Global_101700.f_27009[62 /*29*/].f_7);

	case 3: return ui::_get_label_text(&Global_101700.f_27009[14 /*29*/].f_7);

	case 16: return ui::_get_label_text(&Global_101700.f_27009[97 /*29*/].f_7);

	case 19: return ui::_get_label_text(&Global_101700.f_27009[99 /*29*/].f_7);

	case 15: return ui::_get_label_text(&Global_101700.f_27009[96 /*29*/].f_7);

	case 63: return "CHAR_CARSITE2";

	case 64: return "CHAR_BOATSITE";

	case 8: return "CHAR_BANK_MAZE";

	case 9: return "CHAR_BANK_FLEECA";

	case 10: return "CHAR_BANK_BOL";

	case 21: return "CHAR_MINOTAUR";

	case 25: return ui::_get_label_text(&Global_101700.f_27009[15 /*29*/].f_7);

	case 26: return ui::_get_label_text(&Global_101700.f_27009[30 /*29*/].f_7);

	case 27: return ui::_get_label_text(&Global_101700.f_27009[17 /*29*/].f_7);

	case 29: return ui::_get_label_text(&Global_101700.f_27009[20 /*29*/].f_7);

	case 30: return ui::_get_label_text(&Global_101700.f_27009[43 /*29*/].f_7);

	case 31: return ui::_get_label_text(&Global_101700.f_27009[44 /*29*/].f_7);

	case 32: return ui::_get_label_text(&Global_101700.f_27009[19 /*29*/].f_7);

	case 34: return ui::_get_label_text(&Global_101700.f_27009[40 /*29*/].f_7);

	case 36: return ui::_get_label_text("CELL_E_381");

	case 38: return ui::_get_label_text(&Global_101700.f_27009[64 /*29*/].f_7);

	case 5: return "CHAR_EPSILON";

	case 13: return "CHAR_MILSITE";

	case 11: return "CHAR_CARSITE";

	case 14: return "CHAR_BOATSITE";

	case 12: return "CHAR_PLANESITE";

	case 24: return "CHAR_DR_FRIEDLANDER";

	case 55: return "CHAR_CARSITE2";

	case 54: return "CHAR_BIKESITE";

	case 39: return ui::_get_label_text(&Global_101700.f_27009[122 /*29*/].f_7);

	case 40: return ui::_get_label_text(&Global_101700.f_27009[125 /*29*/].f_7);

	case 41: return ui::_get_label_text(&Global_101700.f_27009[113 /*29*/].f_7);

	case 42: return ui::_get_label_text(&Global_101700.f_27009[126 /*29*/].f_7);

	case 43: return ui::_get_label_text(&Global_101700.f_27009[127 /*29*/].f_7);

	case 44: return ui::_get_label_text(&Global_101700.f_27009[124 /*29*/].f_7);

	case 45: return ui::_get_label_text(&Global_101700.f_27009[114 /*29*/].f_7);

	case 46: return ui::_get_label_text(&Global_101700.f_27009[115 /*29*/].f_7);

	case 47: return ui::_get_label_text(&Global_101700.f_27009[116 /*29*/].f_7);

	case 48: return ui::_get_label_text(&Global_101700.f_27009[123 /*29*/].f_7);

	case 49: return ui::_get_label_text(&Global_101700.f_27009[117 /*29*/].f_7);

	case 50: return ui::_get_label_text(&Global_101700.f_27009[118 /*29*/].f_7);

	case 51: return ui::_get_label_text(&Global_101700.f_27009[119 /*29*/].f_7);

	case 52: return ui::_get_label_text(&Global_101700.f_27009[120 /*29*/].f_7);

	case 53: return ui::_get_label_text(&Global_101700.f_27009[121 /*29*/].f_7);

	default:
	}
	*iParam1 = 0;
	return "ERROR!";
}

// Position - 0x8B10
struct<16> func_181(int iParam0) {
	struct<16> Var0;
	struct<16> Var16;

	if (iParam0 > -1) {
		StringCopy(&Var0, "EMSTR_", 64);
		StringIntConCat(&Var0, iParam0, 64);
		return Var0;
	}
	StringCopy(&Var16, "FAIL", 64);
	return Var16;
}

//Position - 0x8B41
int func_182(int iParam0, var uParam1)
{
	if (Global_40250[iParam0 /*46*/].f_42 >= 9) {
		return 0;
	}
	Global_40250[iParam0 /*46*/].f_32[Global_40250[iParam0 /*46*/].f_42] = uParam1;
	Global_40250[iParam0 /*46*/].f_42++;
	return 1;
}

// Position - 0x8B86
bool func_183(int iParam0) { return Global_40250[iParam0 /*46*/].f_1; }

// Position - 0x8B97
bool func_184(int iParam0) { return Global_40250[iParam0 /*46*/]; }

// Position - 0x8BA6
int func_185() {
	func_59();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x8BBF
void func_186(int iParam0, int *iParam1) {
	if (GetMessageType(iParam0) == 3) {
		switch (iParam0) {
		case 2021846885: *iParam1 = 14; break;

		case 801347631: *iParam1 = 6; break;

		case 2107010167: *iParam1 = 29; break;

		case 1440910066: *iParam1 = 31; break;

		case 2063740346: *iParam1 = 32; break;

		case 957098437: *iParam1 = 33; break;

		case 338918687: *iParam1 = 13; break;

		case 1818503402: *iParam1 = 15; break;

		case 1511064644: *iParam1 = 16; break;

		case 1217225025: *iParam1 = 17; break;

		case -929373866: *iParam1 = 18; break;

		case -1252410668: *iParam1 = 19; break;

		case -1548445814: *iParam1 = 20; break;

		case -1853951201: *iParam1 = 21; break;

		case -709067855: *iParam1 = 22; break;

		case -1023257027: *iParam1 = 30; break;

		case 692693384: *iParam1 = 28; break;

		case 1209844154: *iParam1 = 27; break;

		case -1144971313: *iParam1 = 26; break;

		case 801546988: *iParam1 = 107; break;

		case 319357731: *iParam1 = 108; break;

		case -423103492: *iParam1 = 109; break;

		case -1504002834: *iParam1 = 67; break;

		case 1343538152: *iParam1 = 68; break;

		case 1357988739: *iParam1 = 94; break;

		case 374347954: *iParam1 = 40; break;

		case -1718545517: *iParam1 = 41; break;

		case 2022687760: *iParam1 = 42; break;

		case -1069372983: *iParam1 = 43; break;

		case -789275824: *iParam1 = 46; break;

		case 183426861: *iParam1 = 64; break;

		case -1303362934: *iParam1 = 44; break;

		case 632406285: *iParam1 = 54; break;

		case 859937019: *iParam1 = 45; break;

		case 430981897: *iParam1 = 47; break;

		case -771149390: *iParam1 = 61; break;

		case -1649944291: *iParam1 = 48; break;

		case -1821325152: *iParam1 = 49; break;

		case -132533604: *iParam1 = 50; break;

		case 711875844: *iParam1 = 51; break;

		case -1523625340: *iParam1 = 52; break;

		case -2135625223: *iParam1 = 53; break;

		case -2076002026: *iParam1 = 55; break;

		case -1897604564: *iParam1 = 56; break;

		case -1430864197: *iParam1 = 57; break;

		case 1424059178: *iParam1 = 62; break;

		case -666761274: *iParam1 = 63; break;

		case -2038240170: *iParam1 = 65; break;

		case -1551606815: *iParam1 = 95; break;

		case -980148216: *iParam1 = 97; break;

		case -1857996981: *iParam1 = 96; break;

		case -1674789340: *iParam1 = 69; break;

		case 448778385: *iParam1 = 58; break;

		case 546388833: *iParam1 = 59; break;

		case 1051395607: *iParam1 = 60; break;

		case -505415049: *iParam1 = 71; break;

		case 430538716: *iParam1 = 74; break;

		case -748636148: *iParam1 = 75; break;

		case 353549167: *iParam1 = 76; break;

		case 1400649789: *iParam1 = 77; break;

		case 135464153: *iParam1 = 78; break;

		case -536513155: *iParam1 = 79; break;

		case 967465509: *iParam1 = 80; break;

		case -2132612619: *iParam1 = 81; break;

		case -1419493641: *iParam1 = 82; break;

		case -521917970: *iParam1 = 83; break;

		case -1521020490: *iParam1 = 84; break;

		case 1894922981: *iParam1 = 85; break;

		case 233370836: *iParam1 = 86; break;

		case 984305268: *iParam1 = 87; break;

		case -833431660: *iParam1 = 88; break;

		case 372434771: *iParam1 = 89; break;

		case -92983336: *iParam1 = 90; break;

		case 1638023784: *iParam1 = 91; break;

		case 2121956376: *iParam1 = 92; break;

		case -452245192: *iParam1 = 93; break;

		case 763248121: *iParam1 = 72; break;

		case -720564968: *iParam1 = 73; break;

		case -1067764575: *iParam1 = 110; break;

		case -921778680: *iParam1 = 111; break;

		case -606278748: *iParam1 = 112; break;

		case -414580094: *iParam1 = 113; break;

		case -1871231456: *iParam1 = 114; break;

		case 1127068257: *iParam1 = 115; break;

		case 359978756: *iParam1 = 116; break;

		case -1406368651: *iParam1 = 117; break;

		case -1093228087: *iParam1 = 118; break;

		case 143441204: *iParam1 = 119; break;

		case -615685450: *iParam1 = 120; break;

		case 1963267619: *iParam1 = 121; break;

		default: break;
		}
	}
	else {
		return;
	}
}

// Position - 0x90CC
int CanMessageOrCallBeReceived(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	var uVar5[16];
	int iVar22[2];
	int iVar25;
	int iVar26;
	int iVar27;

	if (!cam::is_screen_faded_in()) {
		return 0;
	}
	if (IsGlobalFlag1Set()) {
		return 0;
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_parachute_state(player::player_ped_id()) != -1) {
			return 0;
		}
	}
	if (audio::is_scripted_conversation_ongoing()) {
		return 0;
	}
	if (IsGlobalFlag2Set() && iParam2 < 4) {
		return 0;
	}
	if (player::is_player_playing(player::player_id())) {
		if (func_199(player::player_ped_id())) {
			if (gameplay::is_bit_set(iParam0, func_185()) && !gameplay::is_bit_set(iParam4, 19)) {
				return 0;
			}
		}
	}
	if (G_DisableMessagesAndCalls1) {
		return 0;
	}
	if (cutscene::is_cutscene_playing()) {
		return 0;
	}
	if (G_DisableMessagesAndCalls2) {
		return 0;
	}
	if (G_DisableMessagesAndCalls3) {
		return 0;
	}
	if (func_198() || Global_17151.f_4 && Global_17151.f_104 == 4 || func_197()) {
		return 0;
	}
	if (gameplay::is_bit_set(iParam4, 18)) {
		if (!gameplay::is_bit_set(iParam0, func_185())) {
			return 0;
		}
	}
	iVar0 = 1;
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		iVar0 = 0;
	}
	if (iVar0 == 1) {
		return 0;
	}
	if (!player::is_player_playing(player::player_id())) {
		return 0;
	}
	else if (iParam2 != 5) {
		if (player::get_player_wanted_level(player::player_id()) > 1) {
			return 0;
		}
		if (gameplay::is_auto_save_in_progress()) {
			return 0;
		}
		if (Global_88752) {
			return 0;
		}
		if (func_190(50f, 1) != -1) {
			return 0;
		}
		if (iParam1 == 17 || iParam1 == 19 || iParam1 == 14 || iParam1 == 0 || iParam1 == 1 || iParam1 == 2) {
			if (gameplay::is_bit_set(iParam0, func_185())) {
				iVar1 = func_92(ModifyAndGetSomeMessageCallState());
				iVar2 = func_92(iParam1);
				iVar3 = func_91(iVar1, iVar2);
				if (iVar3 < 9) {
					if (Global_101700.f_17062.f_175[iVar3 /*19*/].f_8 == 1 ||
						Global_101700.f_17062.f_175[iVar3 /*19*/].f_8 == 2) {
						if (func_90(&Global_101700.f_17062.f_175[iVar3 /*19*/].f_5)) {
							if (func_88(&Global_101700.f_17062.f_175[iVar3 /*19*/].f_5) < 30f) {
								return 0;
							}
						}
					}
				}
			}
		}
	}
	if (player::get_player_wanted_level(player::player_id()) > 2) {
		return 0;
	}
	if (func_189()) {
		return 0;
	}
	if (gameplay::is_bit_set(iParam4, 3)) {
		if (Global_100747) {
			return 0;
		}
		if (player::is_player_playing(player::player_id())) {
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				return 0;
			}
		}
		if (Global_100412.f_19 != 0) {
			return 0;
		}
		if (Global_35781 == 5) {
			return 0;
		}
	}
	if (iParam3 != -1) {
		if (func_66(player::player_ped_id(), iParam3, 0)) {
			return 0;
		}
	}
	iVar4 = ModifyAndGetSomeMessageCallState();
	if (func_9(iVar4)) {
		ped::get_ped_nearby_peds(player::player_ped_id(), &uVar5, -1);
		switch (iParam1) {
		case 4:
			switch (iVar4) {
			case 0:
				iVar22[0] = func_61(1);
				iVar22[1] = func_61(2);
				break;

			case 1:
				iVar22[0] = func_61(0);
				iVar22[1] = func_61(2);
				break;

			case 2:
				iVar22[0] = func_61(0);
				iVar22[1] = func_61(1);
				break;
			}
			break;

		case 5:
			iVar22[0] = func_61(1);
			iVar22[1] = func_61(2);
			break;

		case 6:
			iVar22[0] = func_188(12);
			iVar22[1] = func_61(1);
			break;

		case 7:
			iVar22[0] = func_188(12);
			iVar22[1] = func_61(0);
			break;

		case 8:
			iVar22[0] = func_61(0);
			iVar22[1] = func_61(1);
			break;

		case 9:
			iVar22[0] = func_61(0);
			iVar22[1] = func_61(2);
			break;

		case 10:
			iVar22[0] = func_188(23);
			iVar22[1] = func_61(0);
			break;

		case 11:
			iVar22[0] = func_188(23);
			iVar22[1] = func_61(0);
			break;

		default:
			if (func_9(iParam1)) {
				iVar22[0] = func_61(iParam1);
			}
			else {
				iVar22[0] = func_188(iParam1);
			}
			iVar22[1] = 0;
			break;
		}
		iVar25 = 0;
		while (iVar25 < 2) {
			if (iVar22[iVar25] != 0) {
				iVar26 = 0;
				while (iVar26 < 16) {
					if (entity::does_entity_exist(uVar5[iVar26])) {
						if (entity::get_entity_model(uVar5[iVar26]) == iVar22[iVar25]) {
							if (!entity::is_entity_dead(uVar5[iVar26], 0)) {
								if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
									if (system::vdist2(entity::get_entity_coords(uVar5[iVar26], 1),
													   entity::get_entity_coords(player::player_ped_id(), 1)) < 6400f) {
										return 0;
									}
								}
							}
							else {
								return 0;
							}
						}
					}
					iVar26++;
				}
				iVar27 = 0;
				switch (iVar22[iVar25]) {
				case joaat("player_zero"): iVar27 = Global_89302[0]; break;

				case joaat("player_one"): iVar27 = Global_89302[1]; break;

				case joaat("player_two"): iVar27 = Global_89302[2]; break;
				}
				if (entity::does_entity_exist(iVar27)) {
					if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
						if (system::vdist2(entity::get_entity_coords(iVar27, 1),
										   entity::get_entity_coords(player::player_ped_id(), 1)) < 6400f) {
							return 0;
						}
					}
				}
				switch (iVar22[iVar25]) {
				case joaat("player_zero"): iVar27 = Global_91481[0]; break;

				case joaat("player_one"): iVar27 = Global_91481[1]; break;

				case joaat("player_two"): iVar27 = Global_91481[2]; break;
				}
				if (entity::does_entity_exist(iVar27)) {
					if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
						if (system::vdist2(entity::get_entity_coords(iVar27, 1),
										   entity::get_entity_coords(player::player_ped_id(), 1)) < 6400f) {
							return 0;
						}
					}
				}
			}
			iVar25++;
		}
	}
	else {
		return 0;
	}
	return 1;
}

// Position - 0x96CA
int func_188(int iParam0) {
	if (!func_9(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x96F5
bool func_189() {
	if (Global_69962) {
		return true;
	}
	else if (Global_55816 && !Global_55822) {
		return true;
	}
	return false;
}

// Position - 0x971F
int func_190(float fParam0, int iParam1) {
	struct<27> Var0;
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	int iVar36;
	int iVar37;
	bool bVar38;

	iVar33 = -1;
	fVar34 = fParam0;
	if (player::is_player_playing(player::player_id())) {
		iVar36 = func_196();
		iVar37 = 0;
		iVar37 = 0;
		while (iVar37 < 63) {
			iVar32 = iVar37;
			if (gameplay::is_bit_set(Global_101700.f_17533[iVar32 /*6*/], 2) &&
				!gameplay::is_bit_set(Global_101700.f_17533[iVar32 /*6*/], 3)) {
				func_191(iVar32, &Var0);
				fVar35 = gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 0),
															   Var0.f_6, 1);
				if (fVar35 < fVar34) {
					bVar38 = true;
					if (iParam1) {
						if (iVar36 != Var0.f_26) {
							bVar38 = false;
						}
					}
					if (bVar38) {
						iVar33 = iVar32;
						fVar34 = fVar35;
					}
				}
			}
			iVar37++;
		}
	}
	return iVar33;
}

// Position - 0x97CB
void func_191(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		func_192(uParam1, "Abigail1", func_194(iParam0), 0, 0, 4, -1604.668f, 5239.1f, 3.01f, 66, "", 109, 0,
				 "ambient_Diving", 0, 0, 1, 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 1:
		func_192(uParam1, "Abigail2", func_194(iParam0), 0, 0, 4, -1592.84f, 5214.04f, 3.01f, 400, "", 110, 0, "", 0, 0,
				 -1, 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 2:
		func_192(uParam1, "Barry1", func_194(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", 74, 0, "", 0, 1, -1,
				 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 3:
		func_192(uParam1, "Barry2", func_194(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", -1, 0, "", 0, 1, -1,
				 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 4:
		func_192(uParam1, "Barry3", func_194(iParam0), 0, 1, 4, 414f, -761f, 29f, 381, "", -1, 0, "", 164, 1, -1, 0, 2,
				 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 5:
		func_192(uParam1, "Barry3A", func_194(iParam0), 1, 1, 0, 1199.27f, -1255.63f, 34.23f, 381, "BARSTASH", 84, 0,
				 "", 166, 0, 7, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 6:
		func_192(uParam1, "Barry3C", func_194(iParam0), 3, 1, 0, -468.9f, -1713.06f, 18.21f, 381, "", 84, 0, "", 166, 0,
				 7, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 7:
		func_192(uParam1, "Barry4", func_194(iParam0), 0, 1, 4, 237.65f, -385.41f, 44.4f, 381, "", 85, 0,
				 "postRC_Barry4", 0, 0, -1, 4, 2, 800, 2000, func_193(iParam0), 0, 0);
		break;

	case 8:
		func_192(uParam1, "Dreyfuss1", func_194(iParam0), 0, 2, 4, -1458.97f, 485.99f, 115.38f, 66, "LETTERS_HINT", 106,
				 0, "", 0, 0, -1, 4, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 9:
		func_192(uParam1, "Epsilon1", func_194(iParam0), 0, 3, 4, -1622.89f, 4204.87f, 83.3f, 66, "", 86, 0, "", 0, 1,
				 10, 4, 1, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 10:
		func_192(uParam1, "Epsilon2", func_194(iParam0), 0, 3, 4, 242.7f, 362.7f, 104.74f, 206, "", 87, 16, "", 0, 0,
				 11, 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 11:
		func_192(uParam1, "Epsilon3", func_194(iParam0), 0, 3, 4, 1835.53f, 4705.86f, 38.1f, 206, "", 88, 16, "epsCars",
				 0, 0, 12, 4, 1, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 12:
		func_192(uParam1, "Epsilon4", func_194(iParam0), 0, 3, 4, 1826.13f, 4698.88f, 38.92f, 206, "", 90, 16,
				 "postRC_Epsilon4", 0, 0, 13, 4, 1, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 13:
		func_192(uParam1, "Epsilon5", func_194(iParam0), 0, 3, 4, 637.02f, 119.7093f, 89.5f, 206, "", 89, 16,
				 "epsRobes", 0, 0, 14, 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 14:
		func_192(uParam1, "Epsilon6", func_194(iParam0), 0, 3, 4, -2892.93f, 3192.37f, 11.66f, 206, "", 93, 0, "", 0, 0,
				 15, 4, 1, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 15:
		func_192(uParam1, "Epsilon7", func_194(iParam0), 0, 3, 4, 524.43f, 3079.82f, 39.48f, 206, "", -1, 16,
				 "epsDesert", 0, 0, 16, 4, 1, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 16:
		func_192(uParam1, "Epsilon8", func_194(iParam0), 0, 3, 4, -697.75f, 45.38f, 43.03f, 206, "", 94, 16,
				 "epsilonTract", 0, 0, -1, 4, 1, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 17:
		func_192(uParam1, "Extreme1", func_194(iParam0), 0, 4, 4, -188.22f, 1296.1f, 302.86f, 66, "", -1, 0, "", 4, 1,
				 18, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 18:
		func_192(uParam1, "Extreme2", func_194(iParam0), 0, 4, 4, -954.19f, -2760.05f, 14.64f, 382, "", 96, 0, "", 171,
				 0, 19, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 19:
		func_192(uParam1, "Extreme3", func_194(iParam0), 0, 4, 4, -63.8f, -809.5f, 321.8f, 382, "", 97, 0, "", 0, 0, 20,
				 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 20:
		func_192(uParam1, "Extreme4", func_194(iParam0), 0, 4, 4, 1731.41f, 96.96f, 170.39f, 382, "", 98, 16, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 21:
		func_192(uParam1, "Fanatic1", func_194(iParam0), 0, 5, 4, -1877.82f, -440.649f, 45.05f, 405, "", 74, 0, "", 0,
				 1, -1, 4, 1, 700, 2000, func_193(iParam0), 1, 0);
		break;

	case 22:
		func_192(uParam1, "Fanatic2", func_194(iParam0), 0, 5, 4, 809.66f, 1279.76f, 360.49f, 405, "", -1, 0, "", 0, 1,
				 -1, 4, 4, 700, 2000, func_193(iParam0), 1, 0);
		break;

	case 23:
		func_192(uParam1, "Fanatic3", func_194(iParam0), 0, 5, 4, -915.6f, 6139.2f, 5.5f, 405, "", -1, 0, "", 0, 1, -1,
				 4, 2, 700, 2000, func_193(iParam0), 0, 1);
		break;

	case 24:
		func_192(uParam1, "Hao1", func_194(iParam0), 0, 6, 4, -72.29f, -1260.63f, 28.14f, 66, "", -1, 0,
				 "controller_Races", 13, 1, -1, 4, 2, 2000, 500, func_193(iParam0), 0, 1);
		break;

	case 25:
		func_192(uParam1, "Hunting1", func_194(iParam0), 0, 7, 4, 1804.32f, 3931.33f, 32.82f, 66, "", -1, 0, "", 174, 1,
				 26, 4, 4, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 26:
		func_192(uParam1, "Hunting2", func_194(iParam0), 0, 7, 4, -684.17f, 5839.16f, 16.09f, 384, "", 99, 0, "", 7, 0,
				 -1, 4, 4, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 27:
		func_192(uParam1, "Josh1", func_194(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 66, "", -1, 0, "forSaleSigns",
				 0, 1, 28, 4, 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 28:
		func_192(uParam1, "Josh2", func_194(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", 105, 0, "", 0, 0,
				 29, 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 29:
		func_192(uParam1, "Josh3", func_194(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", -1, 16, "", 0, 0,
				 30, 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 30:
		func_192(uParam1, "Josh4", func_194(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 385, "", -1, 36, "", 0, 0, -1,
				 4, 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 31:
		func_192(uParam1, "Maude1", func_194(iParam0), 0, 9, 4, 2726.1f, 4145f, 44.3f, 66, "", -1, 0,
				 "BailBond_Launcher", 0, 1, -1, 4, 4, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 32:
		func_192(uParam1, "Minute1", func_194(iParam0), 0, 10, 4, 327.85f, 3405.7f, 35.73f, 66, "", -1, 0, "", 0, 1, 33,
				 4, 4, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 33:
		func_192(uParam1, "Minute2", func_194(iParam0), 0, 10, 4, 18f, 4527f, 105f, 386, "", -1, 10, "", 0, 0, 34, 4, 4,
				 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 34:
		func_192(uParam1, "Minute3", func_194(iParam0), 0, 10, 4, -303.82f, 6211.29f, 31.05f, 386, "", -1, 10, "", 0, 0,
				 -1, 4, 4, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 35:
		func_192(uParam1, "MrsPhilips1", func_194(iParam0), 0, 11, 4, 1972.59f, 3816.43f, 32.42f, 66, "", -1, 0,
				 "ambient_MrsPhilips", 0, 1, -1, 4, 4, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 36:
		func_192(uParam1, "MrsPhilips2", func_194(iParam0), 0, 11, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 1, -1, 4, 4, 0,
				 2359, func_193(iParam0), 0, 0);
		break;

	case 37:
		func_192(uParam1, "Nigel1", func_194(iParam0), 0, 12, 4, -1097.16f, 790.01f, 164.52f, 66, "", -1, 0, "", 177, 1,
				 -1, 1, 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 38:
		func_192(uParam1, "Nigel1A", func_194(iParam0), 0, 12, 1, -558.65f, 284.49f, 90.86f, 149, "NIGITEMS", 100, 0,
				 "", 0, 0, 42, 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 39:
		func_192(uParam1, "Nigel1B", func_194(iParam0), 0, 12, 1, -1034.15f, 366.08f, 80.11f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_193(iParam0), 1, 1);
		break;

	case 40:
		func_192(uParam1, "Nigel1C", func_194(iParam0), 0, 12, 1, -623.91f, -266.17f, 37.76f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_193(iParam0), 1, 1);
		break;

	case 41:
		func_192(uParam1, "Nigel1D", func_194(iParam0), 0, 12, 1, -1096.85f, 67.68f, 52.95f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_193(iParam0), 1, 1);
		break;

	case 42:
		func_192(uParam1, "Nigel2", func_194(iParam0), 0, 12, 4, -1310.7f, -640.22f, 26.54f, 149, "", -1, 8, "", 0, 0,
				 43, 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 43:
		func_192(uParam1, "Nigel3", func_194(iParam0), 0, 12, 4, -44.75f, -1288.67f, 28.21f, 149, "", -1, 16,
				 "postRC_Nigel3", 0, 0, -1, 4, 4, 0, 2359, func_193(iParam0), 1, 1);
		break;

	case 44:
		func_192(uParam1, "Omega1", func_194(iParam0), 0, 13, 4, 2468.51f, 3437.39f, 49.9f, 66, "", -1, 0,
				 "spaceshipParts", 0, 1, 45, 4, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 45:
		func_192(uParam1, "Omega2", func_194(iParam0), 0, 13, 4, 2319.44f, 2583.58f, 46.76f, 387, "", 107, 0, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 46:
		func_192(uParam1, "Paparazzo1", func_194(iParam0), 0, 14, 4, -149.75f, 285.81f, 93.67f, 66, "", -1, 0, "", 0, 1,
				 47, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 47:
		func_192(uParam1, "Paparazzo2", func_194(iParam0), 0, 14, 4, -70.71f, 301.43f, 106.79f, 389, "", -1, 8, "", 0,
				 0, 48, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 48:
		func_192(uParam1, "Paparazzo3", func_194(iParam0), 0, 14, 4, -257.22f, 292.85f, 90.63f, 389, "", -1, 8, "", 183,
				 1, -1, 2, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 49:
		func_192(uParam1, "Paparazzo3A", func_194(iParam0), 0, 14, 2, 305.52f, 157.19f, 102.94f, 389, "PAPPHOTO", 102,
				 0, "", 0, 0, 51, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 50:
		func_192(uParam1, "Paparazzo3B", func_194(iParam0), 0, 14, 2, 1040.96f, -534.42f, 60.17f, 389, "", 102, 0, "",
				 0, 0, 51, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 51:
		func_192(uParam1, "Paparazzo4", func_194(iParam0), 0, 14, 4, -484.2f, 229.68f, 82.21f, 389, "", -1, 8, "", 0, 1,
				 -1, 4, 2, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 52:
		func_192(uParam1, "Rampage1", func_194(iParam0), 0, 15, 4, 908f, 3643.7f, 32.2f, 66, "", -1, 0, "", 0, 1, 54, 4,
				 4, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 54:
		func_192(uParam1, "Rampage3", func_194(iParam0), 0, 15, 4, 465.1f, -1849.3f, 27.8f, 84, "", -1, 0, "", 0, 1, 55,
				 4, 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 55:
		func_192(uParam1, "Rampage4", func_194(iParam0), 0, 15, 4, -161f, -1669.7f, 33f, 84, "", -1, 0, "", 0, 0, 56, 4,
				 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 56:
		func_192(uParam1, "Rampage5", func_194(iParam0), 0, 15, 4, -1298.2f, 2504.14f, 21.09f, 84, "", -1, 0, "", 0, 0,
				 53, 4, 4, 0, 2359, func_193(iParam0), 0, 0);
		break;

	case 53:
		func_192(uParam1, "Rampage2", func_194(iParam0), 0, 15, 4, 1181.5f, -400.1f, 67.5f, 84, "", -1, 0,
				 "rampage_controller", 0, 0, -1, 4, 4, 0, 2359, func_193(iParam0), 1, 0);
		break;

	case 57:
		func_192(uParam1, "TheLastOne", func_194(iParam0), 0, 16, 4, -1298.98f, 4640.16f, 105.67f, 66, "", 133, 1, "",
				 0, 1, -1, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 58:
		func_192(uParam1, "Tonya1", func_194(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 66, "AM_H_RCFS", -1, 0,
				 "ambient_TonyaCall", 24, 1, 59, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 59:
		func_192(uParam1, "Tonya2", func_194(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48,
				 "ambient_Tonya", 185, 0, 60, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	case 60:
		func_192(uParam1, "Tonya3", func_194(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 187, 0, 61, 4, 2, 0,
				 2359, func_193(iParam0), 0, 1);
		break;

	case 61:
		func_192(uParam1, "Tonya4", func_194(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 0, 62, 4, 2, 0, 2359,
				 func_193(iParam0), 0, 1);
		break;

	case 62:
		func_192(uParam1, "Tonya5", func_194(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_193(iParam0), 0, 1);
		break;

	default: break;
	}
}

// Position - 0xA980
void func_192(var *uParam0, char *sParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6, vector3 vParam7,
			  int iParam10, char *sParam11, int iParam12, int iParam13, char *sParam14, int iParam15, int iParam16,
			  int iParam17, int iParam18, int iParam19, int iParam20, int iParam21, int iParam22, int iParam23,
			  int iParam24) {
	uParam0->f_4 = iParam5;
	*uParam0 = sParam1;
	uParam0->f_1 = {Param2};
	uParam0->f_3 = iParam4;
	uParam0->f_5 = iParam6;
	uParam0->f_6 = {vParam7};
	uParam0->f_9 = iParam10;
	StringCopy(&uParam0->f_10, sParam11, 16);
	uParam0->f_14 = iParam12;
	uParam0->f_15 = iParam13;
	StringCopy(&uParam0->f_16, sParam14, 24);
	uParam0->f_22 = iParam15;
	uParam0->f_23 = iParam16;
	uParam0->f_24 = iParam17;
	uParam0->f_25 = iParam18;
	uParam0->f_26 = iParam19;
	uParam0->f_27 = iParam20;
	uParam0->f_28 = iParam21;
	uParam0->f_29 = iParam22;
	uParam0->f_30 = iParam23;
	uParam0->f_31 = iParam24;
}

// Position - 0xAA11
int func_193(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 0;

	case 2: return 1;

	case 3: return 1;

	case 4: return 0;

	case 5: return 1;

	case 6: return 1;

	case 7: return 0;

	case 8: return 1;

	case 9: return 0;

	case 10: return 0;

	case 11: return 0;

	case 12: return 1;

	case 13: return 0;

	case 14: return 1;

	case 15: return 0;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 1;

	case 23: return 1;

	case 24: return 1;

	case 25: return 1;

	case 26: return 1;

	case 27: return 0;

	case 28: return 1;

	case 29: return 1;

	case 30: return 1;

	case 31: return 0;

	case 32: return 1;

	case 33: return 1;

	case 34: return 1;

	case 35: return 0;

	case 36: return 0;

	case 37: return 0;

	case 38: return 1;

	case 39: return 1;

	case 40: return 1;

	case 41: return 1;

	case 42: return 1;

	case 43: return 1;

	case 44: return 0;

	case 45: return 0;

	case 46: return 1;

	case 47: return 1;

	case 48: return 0;

	case 49: return 1;

	case 50: return 1;

	case 51: return 1;

	case 52: return 1;

	case 54: return 1;

	case 55: return 1;

	case 56: return 1;

	case 53: return 1;

	case 57: return 1;

	case 58: return 1;

	case 59: return 1;

	case 60: return 1;

	case 61: return 1;

	case 62: return 1;

	default: break;
	}
	return 0;
}

// Position - 0xAD57
struct<2> func_194(int iParam0) {
	struct<2> Var0;
	char[] cVar2[8];

	StringCopy(&Var0, "", 8);
	cVar2 = {func_195(iParam0)};
	if (gameplay::is_string_null_or_empty(&cVar2)) {
	}
	else {
		StringCopy(&Var0, "RC_", 8);
		StringConCat(&Var0, &cVar2, 8);
	}
	return Var0;
}

// Position - 0xAD8E
struct<2>
func_195(int iParam0) {
	struct<2> Var0;

	StringCopy(&Var0, "", 8);
	switch (iParam0) {
	case 0: StringCopy(&Var0, "ABI1", 8); break;

	case 1: StringCopy(&Var0, "ABI2", 8); break;

	case 2: StringCopy(&Var0, "BA1", 8); break;

	case 3: StringCopy(&Var0, "BA2", 8); break;

	case 4: StringCopy(&Var0, "BA3", 8); break;

	case 5: StringCopy(&Var0, "BA3A", 8); break;

	case 6: StringCopy(&Var0, "BA3C", 8); break;

	case 7: StringCopy(&Var0, "BA4", 8); break;

	case 8: StringCopy(&Var0, "DRE1", 8); break;

	case 9: StringCopy(&Var0, "EPS1", 8); break;

	case 10: StringCopy(&Var0, "EPS2", 8); break;

	case 11: StringCopy(&Var0, "EPS3", 8); break;

	case 12: StringCopy(&Var0, "EPS4", 8); break;

	case 13: StringCopy(&Var0, "EPS5", 8); break;

	case 14: StringCopy(&Var0, "EPS6", 8); break;

	case 15: StringCopy(&Var0, "EPS7", 8); break;

	case 16: StringCopy(&Var0, "EPS8", 8); break;

	case 17: StringCopy(&Var0, "EXT1", 8); break;

	case 18: StringCopy(&Var0, "EXT2", 8); break;

	case 19: StringCopy(&Var0, "EXT3", 8); break;

	case 20: StringCopy(&Var0, "EXT4", 8); break;

	case 21: StringCopy(&Var0, "FAN1", 8); break;

	case 22: StringCopy(&Var0, "FAN2", 8); break;

	case 23: StringCopy(&Var0, "FAN3", 8); break;

	case 24: StringCopy(&Var0, "HAO1", 8); break;

	case 25: StringCopy(&Var0, "HUN1", 8); break;

	case 26: StringCopy(&Var0, "HUN2", 8); break;

	case 27: StringCopy(&Var0, "JOS1", 8); break;

	case 28: StringCopy(&Var0, "JOS2", 8); break;

	case 29: StringCopy(&Var0, "JOS3", 8); break;

	case 30: StringCopy(&Var0, "JOS4", 8); break;

	case 31: StringCopy(&Var0, "MAU1", 8); break;

	case 32: StringCopy(&Var0, "MIN1", 8); break;

	case 33: StringCopy(&Var0, "MIN2", 8); break;

	case 34: StringCopy(&Var0, "MIN3", 8); break;

	case 35: StringCopy(&Var0, "MRS1", 8); break;

	case 36: StringCopy(&Var0, "MRS2", 8); break;

	case 37: StringCopy(&Var0, "NI1", 8); break;

	case 38: StringCopy(&Var0, "NI1A", 8); break;

	case 39: StringCopy(&Var0, "NI1B", 8); break;

	case 40: StringCopy(&Var0, "NI1C", 8); break;

	case 41: StringCopy(&Var0, "NI1D", 8); break;

	case 42: StringCopy(&Var0, "NI2", 8); break;

	case 43: StringCopy(&Var0, "NI3", 8); break;

	case 44: StringCopy(&Var0, "OME1", 8); break;

	case 45: StringCopy(&Var0, "OME2", 8); break;

	case 46: StringCopy(&Var0, "PA1", 8); break;

	case 47: StringCopy(&Var0, "PA2", 8); break;

	case 48: StringCopy(&Var0, "PA3", 8); break;

	case 49: StringCopy(&Var0, "PA3A", 8); break;

	case 50: StringCopy(&Var0, "PA3B", 8); break;

	case 51: StringCopy(&Var0, "PA4", 8); break;

	case 52: StringCopy(&Var0, "RAM1", 8); break;

	case 53: StringCopy(&Var0, "RAM2", 8); break;

	case 54: StringCopy(&Var0, "RAM3", 8); break;

	case 55: StringCopy(&Var0, "RAM4", 8); break;

	case 56: StringCopy(&Var0, "RAM5", 8); break;

	case 57: StringCopy(&Var0, "SAS1", 8); break;

	case 58: StringCopy(&Var0, "TON1", 8); break;

	case 59: StringCopy(&Var0, "TON2", 8); break;

	case 60: StringCopy(&Var0, "TON3", 8); break;

	case 61: StringCopy(&Var0, "TON4", 8); break;

	case 62: StringCopy(&Var0, "TON5", 8); break;

	default: break;
	}
	return Var0;
}

//Position - 0xB1DA
int func_196()
{
	func_59();
	switch (Global_101700.f_2095.f_539.f_3549) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;
	}
	return 0;
}

// Position - 0xB220
int func_197() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0xB23A
int func_198() {
	if (!network::network_is_game_in_progress()) {
		return Global_89302.f_44 == 1;
	}
	return 0;
}

// Position - 0xB256
bool func_199(int iParam0) {
	if (iParam0 == 0) {
		return false;
	}
	if (func_200(iParam0) == -1) {
		return false;
	}
	return true;
}

// Position - 0xB277
int func_200(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36715[iVar0 /*5*/] != -1) {
			if (iParam0 == Global_36715[iVar0 /*5*/].f_1) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xB2C0
bool func_201() {
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		return true;
	}
	return false;
}

// Position - 0xB2E9
bool IsGlobalFlag1Set() {
	if (Global_14443.f_1 == 1) {
		return true;
	}
	return false;
}

// Position - 0xB302
void func_203(var *uParam0) {
	if (uParam0->f_3 == 5) {
		if (uParam0->f_4 - gameplay::get_game_timer() > 6000) {
			uParam0->f_4 = gameplay::get_game_timer() + 6000;
		}
	}
}

// Position - 0xB32C
void func_204(var *uParam0) {
	if (func_201()) {
		if (iLocal_90 == 0) {
			func_244(uParam0);
		}
		if (iLocal_90 == 0) {
			func_238(uParam0);
		}
		if (iLocal_90 == 0) {
			func_229(uParam0);
		}
	}
	func_205(uParam0);
}

// Position - 0xB365
void func_205(var *uParam0) {
	char[] cVar0[5][8];

	switch (iLocal_83) {
	case 0:
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (func_228(48)) {
				if (func_227() || func_226() || func_225() || func_224() || func_223()) {
					if (!entity::does_entity_exist(func_222(60)) && !entity::does_entity_exist(func_222(61)) &&
						Global_69698 == -1 && !func_221() && !func_220()) {
						if (ModifyAndGetSomeMessageCallState() == 0) {
							func_160(&uLocal_91, 0, player::player_ped_id(), "MICHAEL", 0, 1);
							func_160(&uLocal_91, 3, 0, "DBLIMPOperator", 0, 1);
							cVar0[0] = "DAB_HELLO";
							cVar0[1] = "DAB_MICHAEL";
							cVar0[2] = "DAB_SEND";
							cVar0[3] = "DAB_THANK_M";
							cVar0[4] = "DAB_BYE";
						}
						else if (ModifyAndGetSomeMessageCallState() == 1) {
							func_160(&uLocal_91, 1, player::player_ped_id(), "FRANKLIN", 0, 1);
							func_160(&uLocal_91, 3, 0, "DBLIMPOperator", 0, 1);
							cVar0[0] = "DAB_HELLO";
							cVar0[1] = "DAB_FRANKLIN";
							cVar0[2] = "DAB_SEND";
							cVar0[3] = "DAB_THANK_F";
							cVar0[4] = "DAB_BYE";
						}
						else if (ModifyAndGetSomeMessageCallState() == 2) {
							func_160(&uLocal_91, 2, player::player_ped_id(), "TREVOR", 0, 1);
							func_160(&uLocal_91, 3, 0, "DBLIMPOperator", 0, 1);
							cVar0[0] = "DAB_HELLO";
							cVar0[1] = "DAB_TREVOR";
							cVar0[2] = "DAB_SEND";
							cVar0[3] = "DAB_THANK_T";
							cVar0[4] = "DAB_BYE";
						}
						if (func_216(5, &uLocal_91, 48, "BLIMPAU", &cVar0, &cVar0, 11, 1, 0, 0, 0)) {
							iLocal_83++;
						}
					}
				}
			}
		}
		break;

	case 1:
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (!func_228(48) && !func_134(1)) {
				Global_36332 = *uParam0 + 20000;
				if (!func_133()) {
					iLocal_83 = 3;
				}
			}
			else if (Global_69698 != -1) {
				func_123(0);
			}
		}
		break;

	case 2:
		if (gameplay::get_game_timer() > Global_36332) {
			iLocal_83++;
		}
		break;

	case 3:
		func_206();
		iLocal_83 = 0;
		break;
	}
}

// Position - 0xB59D
int func_206() {
	int iVar0;
	float fVar1;
	int iVar2;
	vector3 vVar3[2];
	vector3 vVar10;

	if (ped::is_ped_injured(player::player_ped_id())) {
		return 0;
	}
	fVar1 = 99999.99f;
	iVar2 = -1;
	vVar10 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	vVar3[0 /*3*/] = {1133.21f, 120.2f, 80.9f};
	vVar3[1 /*3*/] = {-806.31f, -2679.65f, 13.9f};
	iVar0 = 0;
	while (iVar0 < 2) {
		if (gameplay::get_distance_between_coords(vVar10, vVar3[iVar0 /*3*/], 1) < fVar1) {
			fVar1 = gameplay::get_distance_between_coords(vVar10, vVar3[iVar0 /*3*/], 1);
			iVar2 = iVar0;
		}
		iVar0++;
	}
	func_211(60);
	func_211(61);
	if (cam::is_sphere_visible(vVar3[iVar2 /*3*/], 300f) || fVar1 < 300f) {
		if (iVar2 == 0) {
			iVar2 = 1;
		}
		else {
			iVar2 = 0;
		}
	}
	if (iVar2 == 0) {
		func_208(60, 1);
		func_207(60);
		return 1;
	}
	else if (iVar2 == 1) {
		func_208(61, 1);
		func_207(61);
		return 1;
	}
	return 0;
}

// Position - 0xB6AB
void func_207(int iParam0) {
	if (iParam0 == -1) {
		return;
	}
	Global_68531[iParam0] = 0;
	Global_68531.f_69[iParam0] = 0;
}

// Position - 0xB6D0
void func_208(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_210(iParam0, 0)) {
			func_209(iParam0, 1, 0);
			func_209(iParam0, 2, 0);
			func_209(iParam0, 3, 0);
			func_209(iParam0, 4, 0);
			func_209(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_209(iParam0, 0, 0);
	}
}

// Position - 0xB72D
void func_209(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0xB768
int func_210(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0xB78B
void func_211(int iParam0) {
	if (iParam0 == -1) {
		return;
	}
	if (func_212(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
			entity::set_vehicle_as_no_longer_needed(&Global_68531.f_139[iParam0]);
			Global_68531.f_139[iParam0] = 0;
		}
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			func_208(iParam0, 0);
		}
	}
}

// Position - 0xB805
bool func_212(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_214(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_214(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_214(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_214(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_214(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_214(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_214(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_214(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_214(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_223()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_223()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_213(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_213(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_213(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0xCEFE
bool func_213(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0xCF45
int func_214(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_9(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_215(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0xCF87
void func_215(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xD1E3
bool func_216(int iParam0, var *uParam1, int iParam2, char *sParam3, char *sParam4, char *sParam5, int iParam6,
			  int iParam7, int iParam8, int iParam9, int iParam10) {
	func_159(uParam1, iParam2, sParam3, iParam8, iParam9, 0);
	func_219();
	if (iParam7 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	func_218(iParam0);
	return func_217(sParam4, sParam5, iParam6, iParam10);
}

// Position - 0xD221
int func_217(var *uParam0, var *uParam1, int iParam2, bool bParam3) {
	int iVar0;

	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam2 > Global_15747) {
				if (bParam3 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
				}
				else {
					func_158();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_157(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_156();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16741 = Global_16742;
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15364.f_370 = Global_16734;
		Global_15741 = Global_15742;
		Global_15743 = Global_15744;
		if (Global_16003 == 0) {
			Global_15899[0 /*6*/] = {Global_15925[0 /*6*/]};
			Global_15899[1 /*6*/] = {Global_15925[1 /*6*/]};
			Global_15951[0 /*6*/] = {Global_15977[0 /*6*/]};
			Global_15951[1 /*6*/] = {Global_15977[1 /*6*/]};
			Global_15912[0 /*6*/] = {Global_15938[0 /*6*/]};
			Global_15912[1 /*6*/] = {Global_15938[1 /*6*/]};
			Global_15964[0 /*6*/] = {Global_15990[0 /*6*/]};
			Global_15964[1 /*6*/] = {Global_15990[1 /*6*/]};
		}
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (bParam3) {
				func_57();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam2 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_155()) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (Global_16003 == 0) {
						if (entity::is_entity_in_water(player::player_ped_id())) {
							return 0;
						}
						if (player::is_player_climbing(player::player_id())) {
							return 0;
						}
						if (ped::is_ped_planting_bomb(player::player_ped_id())) {
							return 0;
						}
						if (player::is_special_ability_active(player::player_id())) {
							return 0;
						}
					}
				}
			}
			if (func_124()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
			}
			func_154();
			Global_15755 = bParam3;
		}
		Global_15747 = iParam2;
		if (Global_15741 > 0) {
			iVar0 = 0;
			while (iVar0 < Global_15741) {
				StringCopy(&Global_15364.f_6[iVar0 /*6*/], (*uParam0)[iVar0], 24);
				StringCopy(&Global_15364.f_187[iVar0 /*6*/], (*uParam1)[iVar0], 24);
				iVar0++;
			}
		}
		Global_14611 = 0;
		func_153();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam2 < Global_15747 || iParam2 == Global_15747) {
		return 0;
	}
	if (iParam2 == 2) {
	}
	else {
		func_158();
	}
	return 0;
}

// Position - 0xD58B
void func_218(var uParam0) {
	Global_15742 = uParam0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
}

// Position - 0xD5B1
void func_219() {
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_15759 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
}

// Position - 0xD5EA
int func_220() {
	var uVar0[15];
	int iVar16;
	int iVar17;

	iVar16 = ped::get_ped_nearby_vehicles(player::player_ped_id(), &uVar0);
	iVar17 = 0;
	while (iVar17 <= iVar16 - 1) {
		if (entity::get_entity_model(uVar0[iVar17]) == joaat("blimp")) {
			if (!entity::is_entity_dead(uVar0[iVar17], 0) && vehicle::is_vehicle_driveable(uVar0[iVar17], 0)) {
				return 1;
			}
		}
		iVar17++;
	}
	return 0;
}

// Position - 0xD64F
int func_221() {
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
		if (entity::get_entity_model(ped::get_vehicle_ped_is_in(player::player_ped_id(), 1)) == joaat("blimp")) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xD67D
int func_222(int iParam0) {
	if (iParam0 == -1) {
		return 0;
	}
	return Global_68531.f_139[iParam0];
}

// Position - 0xD699
bool func_223() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0xD754
int func_224() { return 0; }

// Position - 0xD75D
int func_225() { return 1; }

// Position - 0xD766
int func_226() { return 1; }

// Position - 0xD76F
int func_227() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0xD788
bool func_228(int iParam0) {
	if (Global_16859 || Global_16858 || Global_16860) {
		if (iParam0 == 130) {
		}
		else {
			return false;
		}
	}
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_14443.f_1 == 10) {
			if (Global_1628 == iParam0) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0xD7EC
void func_229(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		iVar1 = ModifyAndGetSomeMessageCallState();
		if (func_9(iVar1)) {
			if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/].f_2, iVar1)) {
				if (func_228(G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/].f_6)) {
					if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/].f_6]) {
						iVar2 = 0;
						iVar3 = 0;
						while (iVar3 < G_SomeGlobalState.MessageCallStates.f_136 && !iVar2) {
							if (G_SomeGlobalState.MessageCallStates[iVar3 /*15*/] == G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/]) {
								iVar2 = 1;
							}
							iVar3++;
						}
						if (!iVar2) {
							iVar3 = G_SomeGlobalState.MessageCallStates.f_136;
							if (iVar3 < 9) {
								G_SomeGlobalState.MessageCallStates[iVar3 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/]};
								G_SomeGlobalState.MessageCallStates.f_136++;
								iVar4 = 0;
								while (iVar4 < 3) {
									if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar3 /*15*/].f_2, iVar4)) {
										func_8(iVar4);
									}
									iVar4++;
								}
							}
							else {
								return;
							}
						}
						if (func_230(&G_SomeGlobalState.MessageCallStates[iVar3 /*15*/])) {
							LastDispatchedMessageOrCall = iVar3;
							iLocal_82 = -1;
							iLocal_90 = 1;
							G_SomeGlobalState.MessageCallStates.f_913 = 0;
							iLocal_78 = 1;
							if (func_137()) {
								iLocal_81 = 1;
							}
						}
						else {
							func_14(iVar3);
						}
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xD966
bool func_230(var *uParam0) {
	struct<5> Var0;

	if (!CanMessageOrCallBeReceived(uParam0->f_2, uParam0->f_6, uParam0->f_3, uParam0->f_7, uParam0->f_1)) {
		return false;
	}
	if (uParam0->f_6 != 1 && uParam0->f_6 != 2 && uParam0->f_6 != 0) {
		if (func_234(uParam0->f_6)) {
			return false;
		}
	}
	if (uParam0->f_9 != -1) {
		if (!func_79(uParam0->f_9)) {
			return false;
		}
	}
	func_232(uParam0);
	func_78(*uParam0, &Var0);
	if (func_231(&Global_36163, uParam0->f_6, &Var0, &Var0.f_4, 12, 1, 0, 0, 0)) {
		return true;
	}
	func_119();
	return false;
}

// Position - 0xDA09
bool func_231(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8) {
	func_159(uParam0, uParam1, sParam2, iParam6, iParam7, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	if (iParam5 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam8);
}

// Position - 0xDA68
void func_232(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_2, func_185())) {
		switch (ModifyAndGetSomeMessageCallState()) {
		case 0: func_160(&Global_36163, 0, player::player_ped_id(), "MICHAEL", 0, 1); break;

		case 1: func_160(&Global_36163, 1, player::player_ped_id(), "FRANKLIN", 0, 1); break;

		case 2: func_160(&Global_36163, 2, player::player_ped_id(), "TREVOR", 0, 1); break;
		}
	}
	switch (uParam0->f_6) {
	case 0: func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1); break;

	case 1: func_160(&Global_36163, 1, 0, "FRANKLIN", 0, 1); break;

	case 2: func_160(&Global_36163, 2, 0, "TREVOR", 0, 1); break;

	case 4:
		switch (ModifyAndGetSomeMessageCallState()) {
		case 0:
			func_160(&Global_36163, 1, 0, "FRANKLIN", 0, 1);
			func_160(&Global_36163, 2, 0, "TREVOR", 0, 1);
			break;

		case 1:
			func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1);
			func_160(&Global_36163, 2, 0, "TREVOR", 0, 1);
			break;

		case 2:
			func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1);
			func_160(&Global_36163, 1, 0, "FRANKLIN", 0, 1);
			break;
		}
		break;

	case 5:
		func_160(&Global_36163, 1, 0, "FRANKLIN", 0, 1);
		func_160(&Global_36163, 2, 0, "TREVOR", 0, 1);
		break;

	case 8:
		func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1);
		func_160(&Global_36163, 1, 0, "FRANKLIN", 0, 1);
		break;

	case 9:
		func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1);
		func_160(&Global_36163, 2, 0, "TREVOR", 0, 1);
		break;

	case 10:
		func_160(&Global_36163, 0, 0, "MICHAEL", 0, 1);
		func_160(&Global_36163, 3, 0, "STEVE", 0, 1);
		break;

	case 11:
		func_160(&Global_36163, 2, 0, "TREVOR", 0, 1);
		func_160(&Global_36163, 3, 0, "STEVE", 0, 1);
		break;

	default: func_160(&Global_36163, uParam0->f_14, 0, func_233(uParam0->f_6), 0, 1); break;
	}
}

// Position - 0xDC90
char *func_233(int iParam0) {
	switch (iParam0) {
	case 16: return "ABIGAIL";

	case 95: return "KIDNAPPEDFEMALE";

	case 17: return "AMANDA";

	case 21: return "CHENG";

	case 35: return "CHENGSR";

	case 30: return "DAVE";

	case 29: return "DEVIN";

	case 36: return "FRIEDLANDER";

	case 28: return "ESTATEAGENT";

	case 53: return "HAO";

	case 54: return "CLETUS";

	case 14: return "JIMMY";

	case 55: return "JIMMYBOSTON";

	case 19: return "LAMAR";

	case 12: return "LESTER";

	case 31: return "MARTIN";

	case 39: return "ONEIL";

	case 34: return "OSCAR";

	case 40: return "PATRICIA";

	case 20: return "NERVOUSRON";

	case 18: return "SIMEON";

	case 26: return "SOLOMON";

	case 23: return "STEVE";

	case 37: return "STRETCH";

	case 43: return "TANISHA";

	case 15: return "TRACEY";

	case 24: return "WADE";

	case 104: return "JULIET";

	case 105: return "NIKKI";

	case 106: return "CHASTITY";

	case 107: return "CHEETAH";

	case 108: return "SAPPHIRE";

	case 109: return "INFERNUS";

	case 110: return "FUFU";

	case 111: return "PEACH";

	case 94: return "BDOWNHOTCHICK";

	case 112: return "TaxiLiz";

	case 93: return "REHH2Hiker";

	case 46: return "LIEngineer";

	case 50: return "BEVERLY";

	case 51: return "CRIS";

	case 58: return "JOSH";

	case 62: return "MAUDE";

	case 113: return "TaxiDispatch";

	case 123: return "MANAGER";

	case 116: return "MANAGER";

	case 103: return "TONYA";

	default: break;
	}
	return "ERROR";
}

// Position - 0xDF96
bool func_234(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	while (iVar0 < 7) {
		iVar1 = Global_82576[iVar0 /*5*/];
		if (iVar1 != -1) {
			iVar2 = -1;
			iVar2 = G_TextMessageConfig.f_109[Global_82576[iVar0 /*5*/] /*4*/];
			if (iVar2 != -1) {
				if (func_235(Global_82612[iVar2 /*34*/].f_12, iParam0)) {
					return true;
				}
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0xDFF3
bool func_235(int iParam0, int iParam1) {
	switch (iParam1) {
	case 19: return func_237(iParam0, 8);

	case 14: return func_237(iParam0, 16);

	case 17: return func_237(iParam0, 32);
	}
	return func_236(iParam0, iParam1);
}

// Position - 0xE046
int func_236(int iParam0, int iParam1) {
	switch (iParam1) {
	case 0:
	case 1:
	case 2: return gameplay::is_bit_set(iParam0, iParam1);

	default:
	}
	return 0;
}

// Position - 0xE073
bool func_237(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0xE082
void func_238(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (func_228(G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/].f_6)) {
			if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/].f_6]) {
				iVar1 = func_243(G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/]);
				if (iVar1 == -1) {
					iVar1 = G_SomeGlobalState.MessageCallStates.f_136;
					G_SomeGlobalState.MessageCallStates[iVar1 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/]};
					G_SomeGlobalState.MessageCallStates.f_136++;
					iVar2 = 0;
					while (iVar2 < 3) {
						if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/].f_2, iVar2)) {
							func_8(iVar2);
						}
						iVar2++;
					}
				}
				if (DispatchTextOrCall(&G_SomeGlobalState.MessageCallStates[iVar1 /*15*/], &iLocal_80)) {
					LastDispatchedMessageOrCall = iVar0;
					iLocal_82 = -1;
					iLocal_90 = 1;
					G_SomeGlobalState.MessageCallStates.f_913 = 0;
					iLocal_78 = 1;
					if (func_137()) {
						iLocal_81 = 1;
					}
				}
				else {
					func_141(*uParam0, &G_SomeGlobalState.MessageCallStates[iVar1 /*15*/], 0);
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xE1A7
bool DispatchTextOrCall(var *messageOrCall, int *iParam1) {
	struct<9> Var0;
	char[] cVar12[8];
	char[] cVar16[8];
	struct<9> Var20;
	char cVar32[32];

	if (!gameplay::is_bit_set(messageOrCall->f_1, 7) && !gameplay::is_bit_set(messageOrCall->f_1, 8)) {
		return false;
	}
	if (!CanMessageOrCallBeReceived(messageOrCall->f_2, messageOrCall->f_6, messageOrCall->f_3, messageOrCall->f_7, messageOrCall->f_1)) {
		return false;
	}
	if (func_234(messageOrCall->f_6)) {
		return false;
	}
	if (messageOrCall->f_9 != -1) {
		if (!func_79(messageOrCall->f_9)) {
			return false;
		}
	}
	if (func_9(ModifyAndGetSomeMessageCallState())) {
		if (gameplay::is_bit_set(messageOrCall->f_2, func_185())) {
			func_232(messageOrCall);
			if (GetMessageType(*messageOrCall) == 1) {
				SetupPhoneCall(*messageOrCall, &Var0);
				func_241(messageOrCall->f_12, &cVar12);
				func_241(messageOrCall->f_13, &cVar16);
				if (func_240(&Global_36163, messageOrCall->f_6, &Var0, &Var0.f_4, 12, &Var0.f_8, &cVar12, &cVar16, 1, 0, 0,
							 0)) {
					if (gameplay::is_bit_set(messageOrCall->f_1, 13)) {
						*iParam1 = 1;
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
			else {
				func_78(*messageOrCall, &Var20);
				if (gameplay::is_string_null_or_empty(&Var20.f_8)) {
					cVar32 = {Var20.f_4};
				}
				else {
					cVar32 = {Var20.f_8};
				}
				if (func_231(&Global_36163, messageOrCall->f_6, &Var20, &cVar32, 12, 1, 0, 0, 0)) {
					if (gameplay::is_bit_set(messageOrCall->f_1, 13)) {
						*iParam1 = 1;
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0xE30F
bool func_240(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, char *sParam5, char *sParam6,
			  char *sParam7, int iParam8, int iParam9, int iParam10, int iParam11) {
	func_159(uParam0, uParam1, sParam2, iParam9, iParam10, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	if (iParam8 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_15797 = 1;
	Global_15799 = 0;
	StringCopy(&Global_15827, sParam6, 24);
	StringCopy(&Global_15833, sParam7, 24);
	StringCopy(&Global_15893, sParam5, 24);
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam11);
}

// Position - 0xE383
void func_241(int iParam0, char *sParam1) {
	switch (iParam0) {
	case 0: StringCopy(sParam1, "MEFL_C1Y", 16); break;

	case 1: StringCopy(sParam1, "MEFL_C1N", 16); break;

	case 2: StringCopy(sParam1, "MEFL_C2Y", 16); break;

	case 3: StringCopy(sParam1, "MEFL_C2N", 16); break;

	case 4: StringCopy(sParam1, "MEFL_C3Y", 16); break;

	case 5: StringCopy(sParam1, "MEFL_C3N", 16); break;

	case 6: StringCopy(sParam1, "PRP_TAXIYM", 16); break;

	case 7: StringCopy(sParam1, "PRP_TAXINM", 16); break;

	case 8: StringCopy(sParam1, "PRP_TAXIYF", 16); break;

	case 9: StringCopy(sParam1, "OJTX_REJ_F", 16); break;

	case 10: StringCopy(sParam1, "PRP_TAXIYT", 16); break;

	case 11: StringCopy(sParam1, "PRP_TAXINT", 16); break;

	case 12: StringCopy(sParam1, "OJTX_TIE_LOC", 16); break;

	case 13: StringCopy(sParam1, "OJTX_EXC_LOC", 16); break;

	case 14: StringCopy(sParam1, "OJTX_FL_LOC", 16); break;

	case 15: StringCopy(sParam1, "OJTX_FC_LOC", 16); break;

	case 16: StringCopy(sParam1, "OJTX_GB_LOC", 16); break;

	case 17: StringCopy(sParam1, "OJTX_TB_LOC", 16); break;

	case 18: StringCopy(sParam1, "OJTX_CI_LOC", 16); break;

	case 19: StringCopy(sParam1, "OJTX_GN_LOC", 16); break;

	case 20: StringCopy(sParam1, "OJTX_CC_LOC", 16); break;

	default: break;
	}
}

// Position - 0xE4FA
void SetupPhoneCall(int iParam0, var *uParam1) {
	if (GetMessageType(iParam0) == 1) {
		switch (iParam0) {
		// HELP AMANDA CALL
		case 1635046052:
			StringCopy(uParam1, "MEFLAUD", 16);
			StringCopy(&uParam1->f_4, "MEFL_CALL1", 16);
			StringCopy(&uParam1->f_8, "MEFL_C1Q", 16);
			break;

		// HELP JIMMY CALL
		case -464957327:
			StringCopy(uParam1, "MEFLAUD", 16);
			StringCopy(&uParam1->f_4, "MEFL_CALL2", 16);
			StringCopy(&uParam1->f_8, "MEFL_C2Q", 16);
			break;

		// HELP TRACY CALL
		case 178720519:
			StringCopy(uParam1, "MEFLAUD", 16);
			StringCopy(&uParam1->f_4, "MEFL_CALL3", 16);
			StringCopy(&uParam1->f_8, "MEFL_C3Q", 16);
			break;

		case 738411510:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_TIE_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case -100973682:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_EXC_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case 1752783247:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_DL_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case 1016954269:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_FC_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case -456311088:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_GB_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case 2129099422:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_TB_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case 1357642229:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_CI_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case -767033321:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_GN_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		case -1240893790:
			StringCopy(uParam1, "OJTXAUD", 16);
			StringCopy(&uParam1->f_4, "OJTX_CC_OFF", 16);
			StringCopy(&uParam1->f_8, "PROPR_PHONEQ", 16);
			break;

		default: break;
		}
	}
	else {
		return;
	}
}

// Position - 0xE6D8
int func_243(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xE710
void func_244(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_1, 7)) {
			if (func_228(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_6)) {
				if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_6]) {
					if (DispatchTextOrCall(&G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], &iLocal_80)) {
						LastDispatchedMessageOrCall = iVar0;
						iLocal_82 = -1;
						iLocal_90 = 1;
						G_SomeGlobalState.MessageCallStates.f_913 = 0;
						iLocal_78 = 1;
						if (func_137()) {
							iLocal_81 = 1;
						}
					}
					else {
						func_141(*uParam0, &G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], 0);
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xE7C0
void func_245(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_9(ModifyAndGetSomeMessageCallState())) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764 && !iLocal_78) {
		func_265(&G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/]);
		iVar1 = 0;
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_3 >= 5) {
			iVar1 = 1;
		}
		if (*uParam0 >= Global_36332 || gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_1, 21) ||
			iVar1) {
			if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_6] || iVar1) {
				if (*uParam0 >= G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_4) {
					if (func_248(&G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/])) {
						func_246(&G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/]);
						G_SomeGlobalState.MessageCallStates.f_916 = 0;
						func_7(iVar0);
						iLocal_78 = 1;
					}
					else {
						func_141(*uParam0, &G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/], 1);
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xE8E3
void func_246(var *uParam0) {
	if (!func_247(*uParam0)) {
		if (G_SomeGlobalState.MessageCallStates.f_910 < 3) {
			G_SomeGlobalState.MessageCallStates.f_867[G_SomeGlobalState.MessageCallStates.f_910 /*14*/] = {*uParam0};
			G_SomeGlobalState.MessageCallStates.f_910++;
		}
	}
}

// Position - 0xE93E
int func_247(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_910) {
		if (G_SomeGlobalState.MessageCallStates.f_867[iVar0 /*14*/] == iParam0) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xE979
bool func_248(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	struct<2> Var3;
	char cVar7[16];
	char cVar11[16];
	int iVar15;
	int iVar16;
	int iVar17;
	bool bVar18;
	int iVar19;

	if (func_134(0) || IsGlobalFlag1Set() || func_201()) {
		return false;
	}
	if (!CanMessageOrCallBeReceived(uParam0->f_2, uParam0->f_6, uParam0->f_3, uParam0->f_7, uParam0->f_1)) {
		return false;
	}
	if (uParam0->f_9 != -1) {
		if (!func_79(uParam0->f_9)) {
			return false;
		}
	}
	if (uParam0->f_7 != -1) {
		if (func_66(player::player_ped_id(), uParam0->f_7, 0)) {
			return false;
		}
	}
	if (gameplay::is_bit_set(uParam0->f_1, 16)) {
		iVar0 = 0;
	}
	else {
		iVar0 = 1;
		if (gameplay::is_bit_set(uParam0->f_2, 0)) {
			if (func_264(0)) {
				func_263();
			}
		}
		if (gameplay::is_bit_set(uParam0->f_2, 1)) {
			if (func_264(1)) {
				func_263();
			}
		}
		if (gameplay::is_bit_set(uParam0->f_2, 2)) {
			if (func_264(2)) {
				func_263();
			}
		}
	}
	if (gameplay::is_bit_set(uParam0->f_1, 17)) {
		iVar1 = 2;
	}
	else {
		iVar1 = 1;
	}
	if (gameplay::is_bit_set(uParam0->f_1, 1)) {
		iVar2 = 1;
	}
	else {
		iVar2 = 0;
	}
	func_63(*uParam0, &Var3);
	if (uParam0->f_10 != -1) {
		func_262(uParam0->f_10, &cVar7);
		StringConCat(&Var3, &cVar7, 16);
		if (uParam0->f_11 != -1) {
			func_262(uParam0->f_11, &cVar11);
			StringConCat(&Var3, &cVar11, 16);
		}
	}
	if (gameplay::is_bit_set(uParam0->f_2, func_185())) {
		if (func_261(uParam0->f_6, &Var3, iVar1, iVar0, 0, iVar2, 0, 1, 0, uParam0->f_13)) {
			if (!gameplay::is_bit_set(uParam0->f_1, 18)) {
				iVar15 = 0;
				while (iVar15 < 3) {
					if (gameplay::is_bit_set(uParam0->f_2, iVar15) && iVar15 != func_185()) {
						switch (iVar15) {
						case 0: iVar16 = 0; break;

						case 1: iVar16 = 1; break;

						case 2: iVar16 = 2; break;
						}
						if (func_249(uParam0->f_6, iVar16, &Var3, iVar1, 0, 0, iVar2, 0, 0, 0, uParam0->f_13)) {
						}
					}
					iVar15++;
				}
			}
			if (!func_48(4)) {
				if (func_47(1)) {
					switch (ModifyAndGetSomeMessageCallState()) {
					case 0: func_44("AM_H_FTXT", 2, 3000, -1, 7500, 1, 0, 0, 1); break;

					case 1: func_44("AM_H_FTXT", 2, 3000, -1, 7500, 2, 0, 0, 1); break;

					case 2: func_44("AM_H_FTXT", 2, 3000, -1, 7500, 4, 0, 0, 1); break;
					}
					func_43(4);
				}
			}
			return true;
		}
		else {
			return false;
		}
	}
	else if (!gameplay::is_bit_set(uParam0->f_1, 18)) {
		if (uParam0->f_12 >= 2 || gameplay::is_bit_set(uParam0->f_1, 19)) {
			bVar18 = false;
			iVar17 = 0;
			while (iVar17 < 3) {
				if (gameplay::is_bit_set(uParam0->f_2, iVar17)) {
					switch (iVar17) {
					case 0: iVar19 = 0; break;

					case 1: iVar19 = 1; break;

					case 2: iVar19 = 2; break;
					}
					if (func_249(uParam0->f_6, iVar19, &Var3, iVar1, iVar0, 0, iVar2, 0, 0, 0, uParam0->f_13)) {
						bVar18 = true;
					}
				}
				iVar17++;
			}
			if (bVar18) {
				return true;
			}
		}
		else {
			uParam0->f_12++;
			return false;
		}
	}
	return false;
}

// Position - 0xEC97
bool func_249(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, var uParam10) {
	int iVar0;
	char *sVar1;
	int iVar2;
	char *sVar3;
	int iVar4;
	char *sVar5;
	char *sVar6;

	gameplay::clear_bit(&G_SleepModeOnOn25, 10);
	iVar0 = 0;
	sVar1 = "NULL";
	iVar2 = -99;
	sVar3 = "NULL";
	iVar4 = 0;
	sVar5 = "NULL";
	sVar6 = "NULL";
	if (func_250(iParam0, sParam2, iParam3, iVar0, sVar1, sVar3, iVar2, iParam4, iParam5, iParam6, iParam8, iParam9,
				 uParam10, iVar4, sVar5, sVar6, iParam1) == 1) {
		if (iParam8 == 1) {
			Global_3020 = iParam7;
			Global_2923[3 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
			Global_3000 = iParam0;
			gameplay::set_bit(&G_SleepModeOnOn25, 1);
			gameplay::set_bit(&G_SleepModeOnOn25, 7);
		}
		return true;
	}
	return false;
}

// Position - 0xED2C
int func_250(var uParam0, char *sParam1, int iParam2, int iParam3, char *sParam4, char *sParam5, int iParam6,
			 int iParam7, var uParam8, var uParam9, bool bParam10, var uParam11, var uParam12, int iParam13,
			 char *sParam14, char *sParam15, int iParam16) {
	int iVar0;

	if (iParam13 > 99) {
	}
	if (gameplay::are_strings_equal(sParam14, sParam15)) {
	}
	func_57();
	iVar0 = 0;
	switch (iParam16) {
	case 0:
		if (Global_14443 == 0) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	case 2:
		if (Global_14443 == 2) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	case 1:
		if (Global_14443 == 1) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		break;

	default: iVar0 = 0; break;
	}
	if (iVar0 == 0) {
		if (player::is_player_playing(player::player_id())) {
			if (ped::is_ped_swimming_under_water(player::player_ped_id())) {
				return 0;
			}
		}
		if (Global_101700.f_13010[Global_14443 /*20*/].f_17 == 1) {
			return 0;
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("apptextmessage")) > 0) {
			return 0;
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("apptextmessage")) > 0) {
			return 0;
		}
	}
	if (func_260() == 0) {
		func_258();
		return 0;
	}
	func_257(Global_16812);
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/], sParam1, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_17 = uParam0;
	if (iParam2 == 0) {
	}
	else {
		Global_101700.f_13100[Global_16812 /*104*/].f_24 = iParam2;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_25 = iParam7;
	Global_101700.f_13100[Global_16812 /*104*/].f_26 = uParam8;
	Global_101700.f_13100[Global_16812 /*104*/].f_29 = uParam9;
	Global_101700.f_13100[Global_16812 /*104*/].f_30 = uParam12;
	Global_101700.f_13100[Global_16812 /*104*/].f_31 = uParam11;
	Global_101700.f_13100[Global_16812 /*104*/].f_28 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_32 = iParam3;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_33, sParam4, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_49 = iParam6;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_50, sParam5, 64);
	Global_101700.f_13100[Global_16812 /*104*/].f_66 = iParam13;
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_67, sParam14, 64);
	StringCopy(&Global_101700.f_13100[Global_16812 /*104*/].f_83, sParam15, 64);
	if (gameplay::is_bit_set(G_SleepModeOnOn25, 10)) {
		Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 1;
		Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 1;
		Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 1;
		Global_3019 = 4;
		func_256(0);
		func_256(2);
		func_256(1);
	}
	else {
		func_57();
		switch (iParam16) {
		case 3: Global_101700.f_13100[Global_16812 /*104*/].f_99[Global_14443] = 1; break;

		case 0: Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 1; break;

		case 2: Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 1; break;

		case 1: Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 1; break;
		}
		if (iParam16 == 3) {
			switch (Global_14443) {
			case 0:
				func_256(0);
				Global_3019 = 0;
				break;

			case 1:
				func_256(1);
				Global_3019 = 1;
				break;

			case 2:
				func_256(2);
				Global_3019 = 2;
				break;

			case 3:
				func_256(3);
				Global_3019 = 3;
				break;

			default: Global_3019 = 4; break;
			}
		}
	}
	if (iParam7 == 1) {
		if (gameplay::is_bit_set(G_SleepModeOnOn25, 10)) {
			Global_101700.f_13010[0 /*20*/].f_17 = 1;
			Global_101700.f_13010[1 /*20*/].f_17 = 1;
			Global_101700.f_13010[2 /*20*/].f_17 = 1;
		}
		else {
			switch (iParam16) {
			case 3: Global_101700.f_13010[Global_14443 /*20*/].f_17 = 1; break;

			case 0: Global_101700.f_13010[0 /*20*/].f_17 = 1; break;

			case 2: Global_101700.f_13010[2 /*20*/].f_17 = 1; break;

			case 1: Global_101700.f_13010[1 /*20*/].f_17 = 1; break;
			}
		}
	}
	Global_16814[Global_16812] = 0;
	if (bParam10) {
		func_57();
		if (Global_14386) {
			StringCopy(&Global_14432, "Phone_SoundSet_Prologue", 24);
		}
		else {
			switch (Global_14443) {
			case 0: StringCopy(&Global_14432, "Phone_SoundSet_Michael", 24); break;

			case 2: StringCopy(&Global_14432, "Phone_SoundSet_Trevor", 24); break;

			case 1: StringCopy(&Global_14432, "Phone_SoundSet_Franklin", 24); break;

			default: StringCopy(&Global_14432, "Phone_SoundSet_Default", 24); break;
			}
		}
		if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 != 1) {
			if (!func_255()) {
				audio::play_sound_frontend(-1, "Text_Arrive_Tone", &Global_14432, 1);
			}
		}
	}
	if (!Global_14605) {
		if (Global_14443.f_1 == 6) {
			func_254(Global_14424, "SET_DATA_SLOT_EMPTY", 1f, -1082130432, -1082130432, -1082130432, -1082130432);
			func_251(1);
			func_254(Global_14424, "DISPLAY_VIEW", 1f, system::to_float(Global_14423), -1082130432, -1082130432,
					 -1082130432);
		}
	}
	return 1;
}

// Position - 0xF1E3
void func_251(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;

	Global_16813 = 0;
	Global_2918 = iParam0;
	iVar0 = 0;
	while (iVar0 < 9) {
		Global_2882[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		iVar1 = 0;
		if (func_274(14)) {
			while (iVar1 < 34) {
				if (iParam0 == Global_2320[iVar1 /*15*/].f_11) {
					if (iVar0 == Global_2320[iVar1 /*15*/].f_4) {
						if (Global_2882[iVar0] == 0) {
							Global_2846[iVar0] = iVar1;
							if (iVar1 == 3) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 3)) {
									iVar2 = 42;
									Global_14608 = 1;
								}
								else {
									iVar2 = 255;
									Global_14608 = 0;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar2);
								graphics::_pop_scaleform_movie_function_void();
							}
							if (Global_2452520) {
								if (iVar1 == 14) {
									func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(Global_16808), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0,
											 0);
								}
							}
							Global_2882[iVar0] = 1;
						}
					}
				}
				iVar1++;
			}
		}
		else {
			while (iVar1 < 34) {
				if (iParam0 == Global_2320[iVar1 /*15*/].f_11) {
					if (iVar0 == Global_2320[iVar1 /*15*/].f_4) {
						if (Global_2882[iVar0] == 0) {
							Global_2846[iVar0] = iVar1;
							if (iVar1 == 1) {
								iVar3 = 0;
								while (iVar3 < 35) {
									if (Global_101700.f_13100[iVar3 /*104*/].f_24 != 0) {
										if (Global_101700.f_13100[iVar3 /*104*/].f_28 == 0) {
											if (Global_101700.f_13100[iVar3 /*104*/].f_99[Global_14443] == 1) {
												Global_16813++;
											}
										}
									}
									iVar3++;
								}
								func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10),
										 system::to_float(Global_16813), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else if (iVar1 == 7) {
								if (Global_69702) {
									iVar4 = 0;
									iVar4 = Global_2594052;
									iVar5 = 0;
									while (iVar5 < 12) {
										if (Global_2594053[iVar5 /*104*/].f_24 != 0) {
											if (Global_2594053[iVar5 /*104*/].f_28 == 0) {
												if (Global_2594053[iVar5 /*104*/
												]
														.f_99[Global_14443] == 1) {
													iVar4++;
												}
											}
										}
										iVar5++;
									}
									func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(iVar4), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
								}
								else {
									switch (Global_14443) {
									case 0: iVar6 = Global_36917; break;

									case 1: iVar6 = Global_36918; break;

									case 2: iVar6 = Global_36919; break;

									default: break;
									}
									func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1),
											 system::to_float(iVar0), system::to_float(Global_2320[iVar1 /*15*/].f_10),
											 system::to_float(iVar6), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
								}
							}
							else if (iVar1 == 14) {
								func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10),
										 system::to_float(Global_16808), -1f, &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else if (iVar1 == 20) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2319);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 2) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 6)) {
									iVar7 = 42;
								}
								else {
									iVar7 = 255;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar7);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 3) {
								if (gameplay::is_bit_set(G_SleepModeOffOn11, 3)) {
									iVar8 = 42;
									Global_14608 = 1;
								}
								else {
									iVar8 = 255;
									Global_14608 = 0;
								}
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(iVar8);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 8) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(42);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (iVar1 == 23 &&
									 gameplay::are_strings_equal(&Global_2320[iVar1 /*15*/], "CELL_BENWEB") &&
									 gameplay::is_bit_set(G_SleepModeOffOn11, 6)) {
								graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
								graphics::_push_scaleform_movie_function_parameter_int(1);
								graphics::_push_scaleform_movie_function_parameter_int(iVar0);
								graphics::_push_scaleform_movie_function_parameter_int(Global_2320[iVar1 /*15*/].f_10);
								graphics::_push_scaleform_movie_function_parameter_int(0);
								func_253(&Global_2320[iVar1 /*15*/]);
								graphics::_push_scaleform_movie_function_parameter_int(42);
								graphics::_pop_scaleform_movie_function_void();
							}
							else if (Global_2320[iVar1 /*15*/].f_10 == 57 && iVar1 == 23) {
								iVar9 = 0;
								iVar9 = Global_1618161.f_1;
								func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10), system::to_float(iVar9), -1f,
										 &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							else {
								func_252(Global_14424, "SET_DATA_SLOT", system::to_float(1), system::to_float(iVar0),
										 system::to_float(Global_2320[iVar1 /*15*/].f_10), system::to_float(0), -1f,
										 &Global_2320[iVar1 /*15*/], 0, 0, 0, 0);
							}
							Global_2882[iVar0] = 1;
						}
					}
				}
				iVar1++;
			}
		}
		iVar0++;
	}
}

// Position - 0xF789
void func_252(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  char *sParam7, char *sParam8, char *sParam9, char *sParam10, char *sParam11) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	if (!gameplay::is_string_null_or_empty(sParam7)) {
		func_253(sParam7);
	}
	if (!gameplay::is_string_null_or_empty(sParam8)) {
		func_253(sParam8);
	}
	if (!gameplay::is_string_null_or_empty(sParam9)) {
		func_253(sParam9);
	}
	if (!gameplay::is_string_null_or_empty(sParam10)) {
		func_253(sParam10);
	}
	if (!gameplay::is_string_null_or_empty(sParam11)) {
		func_253(sParam11);
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xF83C
void func_253(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0xF84E
void func_254(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xF8B1
bool func_255() { return Global_1315233; }

// Position - 0xF8BD
void func_256(int iParam0) {
	var uVar0;
	var uVar1;

	uVar0 = Global_101700.f_13010[iParam0 /*20*/].f_8;
	uVar0 = uVar0;
	uVar1 = uVar1;
}

// Position - 0xF8DC
void func_257(int iParam0) {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;

	uVar0 = time::get_clock_seconds();
	uVar1 = time::get_clock_minutes();
	uVar2 = time::get_clock_hours();
	uVar3 = time::get_clock_day_of_month();
	uVar4 = time::get_clock_month() + 1;
	uVar5 = time::get_clock_year();
	Global_101700.f_13100[iParam0 /*104*/].f_18 = uVar0;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_1 = uVar1;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_2 = uVar2;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_3 = uVar3;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_4 = uVar4;
	Global_101700.f_13100[iParam0 /*104*/].f_18.f_5 = uVar5;
}

// Position - 0xF96E
void func_258() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (Global_69702) {
		iVar0 = 24;
		iVar1 = 33;
	}
	else {
		iVar0 = 0;
		iVar1 = 20;
	}
	iVar2 = iVar0;
	Global_16812 = 34;
	Global_101700.f_13100[Global_16812 /*104*/].f_18 = -1;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_1 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_2 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_3 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_5 = 99999;
	while (iVar2 < iVar1) {
		if (!func_259(Global_101700.f_13100[iVar2 /*104*/].f_18, Global_101700.f_13100[Global_16812 /*104*/].f_18)) {
			Global_16812 = iVar2;
		}
		iVar2++;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_24 = 1;
}

// Position - 0xFA39
int func_259(struct<6> Param0, struct<6> Param6) {
	struct<4> Var0;
	struct<4> Var6;
	int iVar12;
	int iVar13;

	if (Param0.f_5 < Param6.f_5) {
		return 0;
	}
	if (Param0.f_5 > Param6.f_5) {
		return 1;
	}
	if (Param0.f_5 == Param6.f_5) {
		if (Param0.f_4 < Param6.f_4) {
			return 0;
		}
		if (Param0.f_4 > Param6.f_4) {
			return 1;
		}
		if (Param0.f_4 == Param6.f_4) {
			Var0 = Param0;
			Var0.f_1 = Param0.f_1 * 60;
			Var0.f_2 = Param0.f_2 * 3600;
			Var0.f_3 = Param0.f_3 * 86400;
			iVar12 = Var0 + Var0.f_1 + Var0.f_2 + Var0.f_3;
			Var6 = Param6;
			Var6.f_1 = Param6.f_1 * 60;
			Var6.f_2 = Param6.f_2 * 3600;
			Var6.f_3 = Param6.f_3 * 86400;
			iVar13 = Var6 + Var6.f_1 + Var6.f_2 + Var6.f_3;
			if (iVar12 > iVar13 || iVar12 == iVar13) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
	return 0;
}

// Position - 0xFB24
int func_260() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (Global_69702) {
		iVar0 = 24;
		iVar1 = 33;
	}
	else {
		iVar0 = 0;
		iVar1 = 20;
	}
	iVar2 = iVar0;
	while (iVar2 < iVar1) {
		if (Global_101700.f_13100[iVar2 /*104*/].f_24 == 0) {
			Global_16812 = iVar2;
			return 1;
		}
		iVar2++;
	}
	iVar2 = iVar0;
	Global_16812 = 34;
	Global_101700.f_13100[Global_16812 /*104*/].f_18 = -1;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_1 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_2 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_3 = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_18.f_5 = 99999;
	while (iVar2 < iVar1) {
		if (Global_101700.f_13100[iVar2 /*104*/].f_24 == 0 || Global_101700.f_13100[iVar2 /*104*/].f_24 == 1) {
			if (!func_259(Global_101700.f_13100[iVar2 /*104*/].f_18,
						  Global_101700.f_13100[Global_16812 /*104*/].f_18)) {
				Global_16812 = iVar2;
			}
		}
		iVar2++;
	}
	if (Global_16812 == 34) {
		return 0;
	}
	Global_101700.f_13100[Global_16812 /*104*/].f_99[0] = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_99[1] = 0;
	Global_101700.f_13100[Global_16812 /*104*/].f_99[2] = 0;
	return 1;
}

// Position - 0xFC7B
bool func_261(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, var uParam9) {
	int iVar0;
	char *sVar1;
	int iVar2;
	char *sVar3;
	int iVar4;
	char *sVar5;
	char *sVar6;
	int iVar7;

	gameplay::clear_bit(&G_SleepModeOnOn25, 10);
	iVar0 = 0;
	sVar1 = "NULL";
	iVar2 = -99;
	sVar3 = "NULL";
	iVar4 = 0;
	sVar5 = "NULL";
	sVar6 = "NULL";
	iVar7 = 3;
	if (func_250(iParam0, sParam1, iParam2, iVar0, sVar1, sVar3, iVar2, iParam3, iParam4, iParam5, iParam7, iParam8,
				 uParam9, iVar4, sVar5, sVar6, iVar7) == 1) {
		if (iParam7 == 1) {
			Global_3020 = iParam6;
			Global_2923[3 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
			Global_3000 = iParam0;
			gameplay::set_bit(&G_SleepModeOnOn25, 1);
			gameplay::set_bit(&G_SleepModeOnOn25, 7);
		}
		return true;
	}
	return false;
}

// Position - 0xFD13
void func_262(int iParam0, char *sParam1) {
	switch (iParam0) {
	case 0: StringCopy(sParam1, "JUL_", 16); break;

	case 1: StringCopy(sParam1, "NIK_", 16); break;

	case 2: StringCopy(sParam1, "SAP_", 16); break;

	case 3: StringCopy(sParam1, "INF_", 16); break;

	case 4: StringCopy(sParam1, "TXI_", 16); break;

	case 5: StringCopy(sParam1, "HCH_", 16); break;

	case 6: StringCopy(sParam1, "STP", 16); break;

	case 7: StringCopy(sParam1, "RUD", 16); break;

	case 8: StringCopy(sParam1, "1ST", 16); break;

	case 9: StringCopy(sParam1, "2ND", 16); break;

	case 10: StringCopy(sParam1, "NEED", 16); break;

	case 11: StringCopy(sParam1, "_B", 16); break;

	case 12: StringCopy(sParam1, "_C", 16); break;

	case 13: StringCopy(sParam1, "_D", 16); break;

	case 15: StringCopy(sParam1, "_DD", 16); break;

	case 14: StringCopy(sParam1, "_DW", 16); break;

	case 16: StringCopy(sParam1, "_E", 16); break;

	case 17: StringCopy(sParam1, "_G", 16); break;

	case 18: StringCopy(sParam1, "_GE", 16); break;

	case 19: StringCopy(sParam1, "0", 16); break;

	case 20: StringCopy(sParam1, "1", 16); break;

	case 21: StringCopy(sParam1, "2", 16); break;

	case 22: StringCopy(sParam1, "3", 16); break;

	case 23: StringCopy(sParam1, "4", 16); break;

	case 24: StringCopy(sParam1, "M0", 16); break;

	case 25: StringCopy(sParam1, "M1", 16); break;

	case 26: StringCopy(sParam1, "M2", 16); break;

	case 27: StringCopy(sParam1, "M3", 16); break;

	case 28: StringCopy(sParam1, "M4", 16); break;

	case 29: StringCopy(sParam1, "F0", 16); break;

	case 30: StringCopy(sParam1, "T0", 16); break;

	case 31: StringCopy(sParam1, "T1", 16); break;

	case 32: StringCopy(sParam1, "T2", 16); break;

	case 33: StringCopy(sParam1, "N1", 16); break;

	case 34: StringCopy(sParam1, "N2", 16); break;

	case 35: StringCopy(sParam1, "N3", 16); break;

	case 36: StringCopy(sParam1, "N4", 16); break;

	case 37: StringCopy(sParam1, "N5", 16); break;

	case 38: StringCopy(sParam1, "N6", 16); break;

	case 39: StringCopy(sParam1, "P1", 16); break;

	case 40: StringCopy(sParam1, "P2", 16); break;

	case 41: StringCopy(sParam1, "P3", 16); break;

	case 42: StringCopy(sParam1, "P4", 16); break;

	case 43: StringCopy(sParam1, "P5", 16); break;

	case 44: StringCopy(sParam1, "P6", 16); break;

	case 45: StringCopy(sParam1, "F1", 16); break;

	case 46: StringCopy(sParam1, "F2", 16); break;

	case 47: StringCopy(sParam1, "F3", 16); break;

	case 48: StringCopy(sParam1, "F4", 16); break;

	case 49: StringCopy(sParam1, "F5", 16); break;

	case 50: StringCopy(sParam1, "F6", 16); break;

	case 51: StringCopy(sParam1, "F7", 16); break;

	case 52: StringCopy(sParam1, "F8", 16); break;

	case 53: StringCopy(sParam1, "WS_DL", 16); break;

	case 54: StringCopy(sParam1, "BA_DL", 16); break;

	case 55: StringCopy(sParam1, "BA_GA", 16); break;

	case 56: StringCopy(sParam1, "BA_ST", 16); break;

	case 57: StringCopy(sParam1, "BA_PA", 16); break;

	case 58: StringCopy(sParam1, "PSY_DF", 16); break;

	case 59: StringCopy(sParam1, "TAX_TX", 16); break;

	case 60: StringCopy(sParam1, "CI_PP", 16); break;

	case 61: StringCopy(sParam1, "M_", 16); break;

	case 62: StringCopy(sParam1, "F_", 16); break;

	case 63: StringCopy(sParam1, "T_", 16); break;

	case 64: StringCopy(sParam1, "L_", 16); break;

	case 65: StringCopy(sParam1, "J_", 16); break;

	case 66: StringCopy(sParam1, "A_", 16); break;

	case 67: StringCopy(sParam1, "LOSTa", 16); break;

	case 68: StringCopy(sParam1, "LOSTb", 16); break;

	case 69: StringCopy(sParam1, "LATEa", 16); break;

	case 70: StringCopy(sParam1, "LATEb", 16); break;

	case 71: StringCopy(sParam1, "HOSPa", 16); break;

	case 72: StringCopy(sParam1, "HOSPb", 16); break;

	case 73: StringCopy(sParam1, "PDIEDa", 16); break;

	case 74: StringCopy(sParam1, "PDIEDb", 16); break;

	case 75: StringCopy(sParam1, "PBUSTa", 16); break;

	case 76: StringCopy(sParam1, "PBUSTb", 16); break;

	case 77: StringCopy(sParam1, "GH_", 16); break;

	case 78: StringCopy(sParam1, "AH_", 16); break;

	case 79: StringCopy(sParam1, "BH_", 16); break;

	case 80: StringCopy(sParam1, "C1", 16); break;

	case 81: StringCopy(sParam1, "C2", 16); break;

	case 82: StringCopy(sParam1, "C3", 16); break;

	default: break;
	}
}

// Position - 0x102AA
int func_263() {
	if (Global_101700.f_13010[0 /*20*/].f_17 || Global_101700.f_13010[1 /*20*/].f_17 ||
		Global_101700.f_13010[2 /*20*/].f_17) {
		Global_101700.f_13010[0 /*20*/].f_17 = 0;
		Global_101700.f_13010[1 /*20*/].f_17 = 0;
		Global_101700.f_13010[2 /*20*/].f_17 = 0;
		return 1;
	}
	Global_101700.f_13010[0 /*20*/].f_17 = 0;
	Global_101700.f_13010[1 /*20*/].f_17 = 0;
	Global_101700.f_13010[2 /*20*/].f_17 = 0;
	return 0;
}

// Position - 0x1033B
bool func_264(int iParam0) {
	if (iParam0 != 0 && iParam0 != 1 && iParam0 != 2) {
		return false;
	}
	if (Global_101700.f_13010[iParam0 /*20*/].f_17) {
		return true;
	}
	return false;
}

// Position - 0x10378
void func_265(var *uParam0) {
	if (uParam0->f_3 == 5) {
		if (uParam0->f_4 - gameplay::get_game_timer() > 6000) {
			uParam0->f_4 = gameplay::get_game_timer() + 6000;
		}
	}
}

// Position - 0x103A2
void func_266(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_9(ModifyAndGetSomeMessageCallState())) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136 && !iLocal_78) {
		func_272(&G_SomeGlobalState.MessageCallStates[iVar0 /*15*/]);
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_1, 0)) {
			iVar1 = 0;
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 >= 5) {
				iVar1 = 1;
			}
			if (*uParam0 >= Global_36332 || gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_1, 21) || iVar1) {
				if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 == G_SomeGlobalState.MessageCallStates.f_919[ModifyAndGetSomeMessageCallState()] ||
					!gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, func_185())) {
					if (*uParam0 >= G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_4) {
						if (func_267(&G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], &iLocal_80)) {
							LastDispatchedMessageOrCall = iVar0;
							iLocal_82 = -1;
							iLocal_90 = 1;
							G_SomeGlobalState.MessageCallStates.f_913 = 0;
							iLocal_78 = 1;
							if (func_137()) {
								iLocal_81 = 1;
							}
						}
						else {
							func_141(*uParam0, &G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], 0);
						}
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x104DF
bool func_267(var *uParam0, int *iParam1) {
	int iVar0;
	int iVar1;
	struct<9> Var2;
	char[] cVar14[8];
	char[] cVar18[8];
	struct<5> Var22;

	if (func_134(0) || IsGlobalFlag1Set() || func_201()) {
		return false;
	}
	if (!CanMessageOrCallBeReceived(uParam0->f_2, uParam0->f_6, uParam0->f_3, uParam0->f_7, uParam0->f_1)) {
		return false;
	}
	if (!gameplay::is_bit_set(uParam0->f_1, 13)) {
		if (uParam0->f_9 != -1) {
			if (!func_79(uParam0->f_9)) {
				return false;
			}
		}
	}
	iVar0 = 12;
	if (uParam0->f_3 == 5) {
		iVar0 = 13;
	}
	if (gameplay::is_bit_set(uParam0->f_2, func_185())) {
		func_232(uParam0);
		if (gameplay::is_bit_set(uParam0->f_1, 14)) {
			switch (ModifyAndGetSomeMessageCallState()) {
			case 0: iVar1 = 0; break;

			case 1: iVar1 = 1; break;

			case 2: iVar1 = 2; break;
			}
			if (Global_101700.f_27009[uParam0->f_6 /*29*/].f_12[iVar1] != 1) {
				gameplay::set_bit(&uParam0->f_1, 15);
				func_55(uParam0->f_6, iVar1, 0);
			}
		}
		if (GetMessageType(*uParam0) == 1) {
			SetupPhoneCall(*uParam0, &Var2);
			func_241(uParam0->f_12, &cVar14);
			func_241(uParam0->f_13, &cVar18);
			if (gameplay::is_bit_set(uParam0->f_1, 12)) {
				if (func_271(&Global_36163, uParam0->f_6, &Var2, &Var2.f_4, iVar0, &Var2.f_8, &cVar14, &cVar18, 0, 0,
							 1)) {
					if (uParam0->f_3 == 5 || gameplay::is_bit_set(uParam0->f_1, 12)) {
						func_132(1);
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
			else if (func_270(&Global_36163, uParam0->f_6, &Var2, &Var2.f_4, iVar0, &Var2.f_8, &cVar14, &cVar18, 0, 0,
							  1)) {
				if (uParam0->f_3 == 5 || gameplay::is_bit_set(uParam0->f_1, 12)) {
					func_132(1);
				}
				return true;
			}
			else {
				func_119();
				return false;
			}
		}
		else {
			func_78(*uParam0, &Var22);
			if (gameplay::is_bit_set(uParam0->f_1, 9)) {
				if (func_269(&Global_36163, uParam0->f_6, &Var22, &Var22.f_4, iVar0, 0, 0, 1)) {
					if (uParam0->f_3 == 5 || gameplay::is_bit_set(uParam0->f_1, 12)) {
						func_132(1);
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
			else if (gameplay::is_bit_set(uParam0->f_1, 0)) {
				if (func_231(&Global_36163, uParam0->f_6, &Var22, &Var22.f_4, iVar0, 1, 0, 0, 0)) {
					if (uParam0->f_3 == 5 || gameplay::is_bit_set(uParam0->f_1, 12)) {
						func_132(1);
					}
					if (gameplay::is_bit_set(uParam0->f_1, 13)) {
						*iParam1 = 1;
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
			else if (uParam0->f_3 == 5) {
				if (func_268(&Global_36163, uParam0->f_6, &Var22, &Var22.f_4, iVar0, 0, 0, 1)) {
					func_132(1);
					if (gameplay::is_bit_set(uParam0->f_1, 13)) {
						*iParam1 = 1;
					}
					return true;
				}
				else {
					func_119();
					return false;
				}
			}
			else if (func_269(&Global_36163, uParam0->f_6, &Var22, &Var22.f_4, iVar0, 0, 0, 1)) {
				if (gameplay::is_bit_set(uParam0->f_1, 12)) {
					func_132(1);
				}
				if (gameplay::is_bit_set(uParam0->f_1, 13)) {
					*iParam1 = 1;
				}
				return true;
			}
			else {
				func_119();
				return false;
			}
		}
	}
	return false;
}

// Position - 0x1080F
bool func_268(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	func_159(uParam0, uParam1, sParam2, iParam5, iParam6, 0);
	Global_15793 = 1;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam7);
}

// Position - 0x1085D
bool func_269(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	func_159(uParam0, uParam1, sParam2, iParam5, iParam6, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam7);
}

// Position - 0x108AB
bool func_270(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, char *sParam5, char *sParam6,
			  char *sParam7, int iParam8, int iParam9, int iParam10) {
	func_159(uParam0, uParam1, sParam2, iParam8, iParam9, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 1;
	Global_15799 = 0;
	StringCopy(&Global_15827, sParam6, 24);
	StringCopy(&Global_15833, sParam7, 24);
	StringCopy(&Global_15893, sParam5, 24);
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam10);
}

// Position - 0x1090E
bool func_271(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, char *sParam5, char *sParam6,
			  char *sParam7, int iParam8, int iParam9, int iParam10) {
	func_159(uParam0, uParam1, sParam2, iParam8, iParam9, 0);
	Global_15793 = 1;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 1;
	Global_15799 = 0;
	StringCopy(&Global_15827, sParam6, 24);
	StringCopy(&Global_15833, sParam7, 24);
	StringCopy(&Global_15893, sParam5, 24);
	Global_2621441 = 0;
	return func_152(sParam3, iParam4, iParam10);
}

// Position - 0x10971
void func_272(var *uParam0) {
	if (uParam0->f_3 == 5) {
		if (uParam0->f_4 - gameplay::get_game_timer() > 6000) {
			uParam0->f_4 = gameplay::get_game_timer() + 6000;
		}
	}
}

// Position - 0x1099B
void func_273(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_9(ModifyAndGetSomeMessageCallState())) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136 && !iLocal_78) {
		func_272(&G_SomeGlobalState.MessageCallStates[iVar0 /*15*/]);
		if (!gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_1, 0)) {
			iVar1 = 0;
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 >= 5) {
				iVar1 = 1;
			}
			if (*uParam0 >= Global_36332 || iVar1 || gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_1, 21)) {
				if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 == G_SomeGlobalState.MessageCallStates.f_919[ModifyAndGetSomeMessageCallState()] ||
					!gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, func_185())) {
					if (*uParam0 >= Global_36333[G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_6] || iVar1) {
						if (*uParam0 >= G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_4) {
							if (func_267(&G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], &iLocal_80)) {
								LastDispatchedMessageOrCall = iVar0;
								iLocal_82 = -1;
								iLocal_90 = 1;
								G_SomeGlobalState.MessageCallStates.f_913 = 0;
								iLocal_78 = 1;
								if (func_137()) {
									iLocal_81 = 1;
								}
							}
							else {
								func_141(*uParam0, &G_SomeGlobalState.MessageCallStates[iVar0 /*15*/], 0);
							}
						}
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x10AFA
bool func_274(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x10B08
int IsGlobalFlag2Set() {
	if (Global_35781 == 15) {
		return 0;
	}
	return 1;
}

// Position - 0x10B1D
void func_276() {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	LastDispatchedMessageOrCall = -1;
	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_198) {
		func_12(G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/].f_6);
		iVar16 = iVar15;
		while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_198 - 2) {
			G_SomeGlobalState.MessageCallStates.f_137[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_137[iVar16 + 1 /*15*/]};
			iVar16++;
		}
		G_SomeGlobalState.MessageCallStates.f_137[G_SomeGlobalState.MessageCallStates.f_198 - 1 /*15*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_198--;
		iVar15++;
	}
	script::terminate_this_thread();
}

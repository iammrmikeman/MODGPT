#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
int iLocal_37 = 0;
int iLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
float fLocal_41 = 0f;
float fLocal_42 = 0f;
vector3 vLocal_43 = {0f, 0f, 0f};
vector3 vLocal_46 = {0f, 0f, 0f};
vector3 vLocal_49 = {0f, 0f, 0f};
float fLocal_52 = 0f;
vector3 vLocal_53 = {0f, 0f, 0f};
float fLocal_56 = 0f;
vector3 vLocal_57 = {0f, 0f, 0f};
float fLocal_60 = 0f;
float fLocal_61 = 0f;
float fLocal_62 = 0f;
var *uLocal_63 = NULL;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
#pragma endregion //}

void __EntryFunction__() {
  iLocal_2 = 1;
  iLocal_3 = 134;
  iLocal_4 = 134;
  iLocal_5 = 1;
  iLocal_6 = 1;
  iLocal_7 = 1;
  iLocal_8 = 134;
  iLocal_9 = 1;
  iLocal_10 = 12;
  iLocal_11 = 12;
  fLocal_14 = 0.001f;
  iLocal_17 = -1;
  sLocal_18 = "NULL";
  fLocal_21 = 0f;
  fLocal_25 = -0.0375f;
  fLocal_26 = 0.17f;
  fLocal_30 = 80f;
  fLocal_31 = 140f;
  fLocal_32 = 180f;
  iLocal_35 = 3;
  fLocal_41 = 50f;
  fLocal_42 = 2500f;
  vLocal_43 = {409.1539f, -1626.677f, 28.2928f};
  vLocal_49 = {409.2747f, -1623.022f, 28.29278f};
  fLocal_52 = 202.6928f;
  vLocal_53 = {415.6071f, -1647.604f, 28.2928f};
  fLocal_56 = 85.7173f;
  if (player::has_force_cleanup_occurred(18)) {
    func_27();
  }
  if (script::_get_number_of_instances_of_script_with_name_hash(
          joaat("ambient_tonyacall2")) > 1) {
    script::terminate_this_thread();
  }
  while (true) {
    player::is_player_playing(player::player_id());
    if (func_26(0, 14)) {
      func_27();
    }
    if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
      vLocal_46 = {entity::get_entity_coords(player::player_ped_id(), 1)};
    }
    if (system::vdist2(vLocal_46, vLocal_43) > fLocal_42) {
      func_27();
    }
    switch (iLocal_37) {
    case 0:
      if (func_22()) {
        iLocal_37 = 1;
      }
      break;

    case 1:
      streaming::request_anim_dict(
          "amb@world_human_stand_mobile@female@standing@call@enter");
      streaming::request_anim_dict(
          "amb@world_human_stand_mobile@female@standing@call@base");
      streaming::request_anim_dict(
          "amb@world_human_stand_mobile@female@standing@call@exit");
      streaming::request_model(joaat("prop_phone_ing"));
      if (streaming::has_model_loaded(joaat("prop_phone_ing")) &&
          streaming::has_anim_dict_loaded("amb@world_human_stand_mobile@"
                                          "female@standing@call@enter") &&
          streaming::has_anim_dict_loaded(
              "amb@world_human_stand_mobile@female@standing@call@base") &&
          streaming::has_anim_dict_loaded(
              "amb@world_human_stand_mobile@female@standing@call@exit")) {
        iLocal_37 = 2;
      }
      break;

    case 2:
      if (func_1()) {
        iLocal_37 = 3;
      }
      break;

    case 3: func_27(); break;
    }
    system::wait(0);
  }
}

// Position - 0x1BA
bool func_1() {
  vector3 vVar0;
  vector3 vVar3;
  int iVar6;
  int iVar7;
  float fVar8;

  if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
    vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
  }
  if (!entity::is_entity_dead(iLocal_38, 0)) {
    vVar3 = {entity::get_entity_coords(iLocal_38, 1)};
  }
  else {
    vVar3 = {408.5002f, -1624.583f, 29.2928f};
  }
  if (system::vdist2(vVar0, vVar3) > 10000f ||
      entity::is_entity_dead(iLocal_38, 0) || func_21()) {
    return true;
  }
  switch (iLocal_40) {
  case 0:
    if (entity::does_entity_exist(iLocal_38) &&
        !entity::is_entity_dead(iLocal_38, 0)) {
      if (entity::is_entity_at_coord(iLocal_38, vLocal_57, 1f, 1f, 1f, 0, 1,
                                     0)) {
        ai::clear_sequence_task(&iVar7);
        ai::open_sequence_task(&iVar7);
        ai::task_achieve_heading(0, fLocal_60, 0);
        ai::task_play_anim(
            0, "amb@world_human_stand_mobile@female@standing@call@enter",
            "enter", 4f, -4f, -1, 0, 0, 0, 0, 0);
        ai::task_play_anim(
            0, "amb@world_human_stand_mobile@female@standing@call@base", "base",
            4f, -4f, -1, 1, 0, 0, 0, 0);
        ai::close_sequence_task(iVar7);
        ai::task_perform_sequence(iLocal_38, iVar7);
        ai::clear_sequence_task(&iVar7);
        iLocal_40 = 1;
      }
    }
    break;

  case 1:
    if (entity::does_entity_exist(iLocal_38) &&
        !entity::is_entity_dead(iLocal_38, 0)) {
      if (ai::get_sequence_progress(iLocal_38) == 1) {
        if (!entity::does_entity_exist(iLocal_39)) {
          if (entity::is_entity_playing_anim(iLocal_38,
                                             "amb@world_human_stand_"
                                             "mobile@female@standing@"
                                             "call@enter",
                                             "enter", 3)) {
            fVar8 = entity::get_entity_anim_current_time(
                iLocal_38,
                "amb@world_human_stand_mobile@female@standing@call@"
                "enter",
                "enter");
            if (fVar8 >= 0.157f) {
              iLocal_39 = object::create_object(joaat("prop_phone_ing"), 1f, 1f,
                                                1f, 1, 1, 0);
              entity::attach_entity_to_entity(
                  iLocal_39, iLocal_38,
                  ped::get_ped_bone_index(iLocal_38, 28422), 0f, 0f, 0f, 0f, 0f,
                  0f, 1, 1, 0, 0, 2, 1);
            }
          }
        }
      }
      else if (ai::get_sequence_progress(iLocal_38) == 2) {
        iVar6 = gameplay::get_random_int_in_range(0, 65535) % 2;
        if (iVar6 == 0) {
          if (func_4(&uLocal_63, "TOWAUD", "TONYA_CALL3", 8, 0, 0, 0)) {
            iLocal_40 = 2;
          }
        }
        else if (func_4(&uLocal_63, "TOWAUD", "TONYA_CALL4", 8, 0, 0, 0)) {
          iLocal_40 = 2;
        }
      }
    }
    break;

  case 2:
    if (!entity::is_entity_dead(iLocal_38, 0)) {
      if (!func_3()) {
        ai::clear_sequence_task(&iVar7);
        ai::open_sequence_task(&iVar7);
        ai::task_play_anim(
            0, "amb@world_human_stand_mobile@female@standing@call@exit", "exit",
            4f, -4f, -1, 0, 0, 0, 0, 0);
        ai::task_start_scenario_in_place(0, "WORLD_HUMAN_SMOKING", -1, 1);
        ai::close_sequence_task(iVar7);
        ai::task_perform_sequence(iLocal_38, iVar7);
        ai::clear_sequence_task(&iVar7);
        iLocal_40 = 3;
      }
    }
    break;

  case 3:
    func_2();
    if (system::vdist2(vVar0, vVar3) < 25f) {
      if (cam::_0xEE778F8C7E1142E2(0) != 4) {
        if (func_4(&uLocal_63, "TOWAUD", "TOW_MESS2", 8, 0, 0, 0)) {
          system::settimera(0);
          iLocal_40 = 4;
        }
      }
    }
    break;

  case 4:
    func_2();
    if (system::timera() > 10000) {
      iLocal_40 = 3;
    }
    break;
  }
  return false;
}

// Position - 0x464
void func_2() {
  if (entity::does_entity_exist(iLocal_38) &&
      !entity::is_entity_dead(iLocal_38, 0)) {
    if (ai::get_sequence_progress(iLocal_38) == 1) {
      if (entity::does_entity_exist(iLocal_39)) {
        object::delete_object(&iLocal_39);
        ai::task_look_at_entity(iLocal_38, player::player_ped_id(), -1, 0, 2);
      }
    }
  }
  if (entity::does_entity_exist(iLocal_38) &&
      !entity::is_entity_dead(iLocal_38, 0)) {
    if (entity::does_entity_exist(iLocal_39)) {
      if (ai::get_script_task_status(iLocal_38, 993674639) == 1) {
        object::delete_object(&iLocal_39);
      }
    }
  }
}

// Position - 0x4DC
int func_3() {
  if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
    return 1;
  }
  return 0;
}

// Position - 0x4FE
bool func_4(var *uParam0, char *sParam1, char *sParam2, int iParam3,
            int iParam4, int iParam5, int iParam6) {
  func_20(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
  if (iParam3 > 7) {
    if (iParam3 < 12) {
      iParam3 = 7;
    }
  }
  Global_15752 = 0;
  Global_15754 = 0;
  Global_15759 = 0;
  Global_16736 = 0;
  Global_16738 = 0;
  Global_16742 = 0;
  Global_2621441 = 0;
  return func_5(sParam2, iParam3, 0);
}

// Position - 0x54C
int func_5(char *sParam0, int iParam1, int iParam2) {
  Global_15746 = 0;
  if (Global_15745 == 0 || Global_15747 == 2) {
    if (Global_15745 != 0) {
      if (iParam1 > Global_15747) {
        if (Global_15752 == 0) {
          audio::stop_scripted_conversation(0);
          Global_14443.f_1 = 3;
          Global_15745 = 0;
          Global_15746 = 1;
          Global_15798 = 0;
          Global_15741 = 0;
          Global_15742 = 0;
          Global_15756 = 0;
          Global_15755 = 0;
          Global_14442 = 0;
        }
        else {
          func_19();
          return 0;
        }
      }
      else {
        return 0;
      }
    }
    if (audio::is_scripted_conversation_ongoing()) {
      return 0;
    }
    if (func_18(8, -1)) {
      return 0;
    }
    Global_15821 = {Global_15815};
    func_17();
    Global_15034 = {Global_15199};
    Global_15751 = Global_15752;
    Global_15758 = Global_15759;
    Global_2621442 = Global_2621441;
    Global_15760 = {Global_15776};
    Global_15753 = Global_15754;
    Global_16735 = Global_16736;
    Global_16743 = {Global_16749};
    Global_16737 = Global_16738;
    Global_16739 = Global_16740;
    Global_16741 = Global_16742;
    Global_15364.f_370 = Global_16734;
    Global_15364.f_368 = Global_16732;
    Global_15364.f_369 = Global_16733;
    Global_15741 = Global_15742;
    if (Global_15751) {
      gameplay::clear_bit(&G_SleepModeOnOn25, 20);
      gameplay::clear_bit(&G_SleepModeOffOn11, 17);
      gameplay::clear_bit(&Global_2315, 0);
      if (iParam2) {
        func_10();
        if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
          if (iParam1 == 13) {
          }
          else {
            return 0;
          }
        }
        if (Global_14443.f_1 > 3) {
          return 0;
        }
      }
      if (Global_14409 == 1) {
        return 0;
      }
      if (player::is_player_playing(player::player_id())) {
        if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
          return 0;
        }
        if (func_9()) {
          return 0;
        }
        if (ai::is_ped_sprinting(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_ragdoll(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
          return 0;
        }
        if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(),
                                               joaat("gadget_parachute"))) {
          return 0;
        }
        if (!Global_69702) {
          if (entity::is_entity_in_water(player::player_ped_id())) {
            return 0;
          }
          if (player::is_player_climbing(player::player_id())) {
            return 0;
          }
          if (ped::is_ped_planting_bomb(player::player_ped_id())) {
            return 0;
          }
          if (player::is_special_ability_active(player::player_id())) {
            return 0;
          }
        }
      }
      if (func_8()) {
        return 0;
      }
      else {
        switch (Global_14443.f_1) {
        case 7: return 0;

        case 8: return 0;

        case 9: break;

        case 10: break;

        default: break;
        }
        if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
          return 0;
        }
      }
      func_7();
      Global_15755 = iParam2;
    }
    Global_15747 = iParam1;
    StringCopy(&Global_15364, sParam0, 24);
    Global_14611 = 0;
    func_6();
    return 1;
  }
  if (Global_15745 == 5) {
    return 0;
  }
  if (iParam1 < Global_15747 || iParam1 == Global_15747) {
    return 0;
  }
  if (iParam1 == 2) {
  }
  else {
    func_19();
  }
  return 0;
}

// Position - 0x818
void func_6() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 69) {
    StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
    iVar0++;
  }
  audio::stop_scripted_conversation(0);
  Global_15745 = 1;
}

// Position - 0x849
void func_7() {
  Global_15798 = Global_15797;
  Global_15792 = Global_15793;
  Global_15839 = {Global_15827};
  Global_15845 = {Global_15833};
  Global_15800 = Global_15799;
  Global_15869 = {Global_15851};
  Global_15875 = {Global_15857};
  Global_15881 = {Global_15863};
  Global_15887 = {Global_15893};
  Global_1628 = Global_1629;
  Global_1630 = Global_1631;
  Global_15756 = Global_15757;
  Global_15758 = Global_15759;
  Global_15760 = {Global_15776};
  Global_15749 = Global_15750;
  Global_16761 = 0;
  Global_15794 = 0;
  Global_15795 = 0;
  gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x8DE
bool func_8() {
  if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
    return true;
  }
  return false;
}

// Position - 0x905
bool func_9() {
  int iVar0;
  int iVar1;

  if (Global_69702) {
    iVar0 = 0;
    weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
    if (player::is_player_playing(player::player_id())) {
      if (iVar1 == joaat("weapon_sniperrifle") ||
          iVar1 == joaat("weapon_heavysniper") ||
          iVar1 == joaat("weapon_remotesniper")) {
        iVar0 = 1;
      }
    }
    if (cam::is_aim_cam_active() && iVar0 == 1) {
      return true;
    }
    else {
      return false;
    }
  }
  if (player::is_player_playing(player::player_id())) {
    if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
      return true;
    }
    else {
      return false;
    }
  }
  return true;
}

// Position - 0x99E
void func_10() {
  if (func_16(14)) {
    if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
      if (entity::get_entity_model(player::player_ped_id()) ==
          Global_101700.f_27009[0 /*29*/]) {
        Global_14443 = 0;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[1 /*29*/]) {
        Global_14443 = 1;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[2 /*29*/]) {
        Global_14443 = 2;
      }
      else {
        Global_14443 = 0;
      }
    }
  }
  else {
    Global_14443 = func_11();
    if (Global_14443 == 145) {
      Global_14443 = 3;
    }
    if (Global_69702) {
      Global_14443 = 3;
    }
    if (Global_14443 > 3) {
      Global_14443 = 3;
    }
  }
}

// Position - 0xA40
var func_11() {
  func_12();
  return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0xA59
void func_12() {
  int iVar0;

  if (entity::does_entity_exist(player::player_ped_id())) {
    if (func_15(Global_101700.f_2095.f_539.f_3549) !=
        entity::get_entity_model(player::player_ped_id())) {
      iVar0 = func_14(player::player_ped_id());
      if (func_13(iVar0) && (!func_16(14) || Global_100652)) {
        if (Global_101700.f_2095.f_539.f_3549 != iVar0 &&
            func_13(Global_101700.f_2095.f_539.f_3549)) {
          Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
        }
        Global_101700.f_2095.f_539.f_3551 = iVar0;
        Global_101700.f_2095.f_539.f_3549 = iVar0;
        return;
      }
    }
    else {
      if (Global_101700.f_2095.f_539.f_3549 != 145) {
        Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
      }
      return;
    }
  }
  Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0xB56
bool func_13(int iParam0) { return iParam0 < 3; }

// Position - 0xB62
int func_14(int iParam0) {
  int iVar0;
  int iVar1;

  if (entity::does_entity_exist(iParam0)) {
    iVar1 = entity::get_entity_model(iParam0);
    iVar0 = 0;
    while (iVar0 <= 2) {
      if (func_15(iVar0) == iVar1) {
        return iVar0;
      }
      iVar0++;
    }
  }
  return 145;
}

// Position - 0xB9F
int func_15(int iParam0) {
  if (func_13(iParam0)) {
    return Global_101700.f_27009[iParam0 /*29*/];
  }
  else if (iParam0 != 145) {
  }
  return 0;
}

// Position - 0xBC9
bool func_16(int iParam0) { return Global_35781 == iParam0; }

// Position - 0xBD7
void func_17() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 15) {
    Global_15034[iVar0 /*10*/] = 0;
    StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
    Global_15034[iVar0 /*10*/].f_7 = 0;
    Global_15034[iVar0 /*10*/].f_8 = 0;
    iVar0++;
  }
  Global_15034.f_161 = -99;
  Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0xC2E
bool func_18(int iParam0, int iParam1) {
  switch (iParam0) {
  case 5:
    if (iParam1 > -1) {
      return Global_1353070.f_203[iParam1];
    }
    break;
  }
  return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0xC69
void func_19() {
  audio::restart_scripted_conversation();
  Global_16756 = 0;
  if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 ||
      Global_14442 == 1) {
    audio::stop_scripted_conversation(0);
    Global_15745 = 6;
    Global_14443.f_1 = 3;
    return;
  }
  if (audio::is_scripted_conversation_ongoing()) {
    audio::stop_scripted_conversation(1);
    Global_15745 = 6;
    return;
  }
}

// Position - 0xCC0
void func_20(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4,
             var uParam5) {
  Global_15199 = {*uParam0};
  Global_1629 = iParam1;
  StringCopy(&Global_15815, sParam2, 24);
  Global_16734 = uParam5;
  if (iParam3 == 0) {
    Global_16732 = 1;
    Global_16730 = 0;
  }
  else {
    Global_16732 = 0;
    Global_16730 = 1;
  }
  if (iParam4 == 0) {
    Global_16733 = 1;
    Global_16731 = 0;
  }
  else {
    Global_16733 = 0;
    Global_16731 = 1;
  }
}

// Position - 0xD16
int func_21() {
  if (!entity::is_entity_dead(player::player_ped_id(), 0) &&
      !entity::is_entity_dead(iLocal_38, 0)) {
    if (entity::is_entity_touching_entity(player::player_ped_id(), iLocal_38) ||
        ped::is_ped_shooting(player::player_ped_id())) {
      if (entity::does_entity_exist(iLocal_39)) {
        entity::detach_entity(iLocal_39, 1, 1);
      }
      audio::stop_scripted_conversation(0);
      if (ai::get_script_task_status(iLocal_38, 1805844857) != 1) {
        ped::set_ped_keep_task(iLocal_38, 1);
        ai::task_smart_flee_ped(iLocal_38, player::player_ped_id(), 1000f, -1,
                                0, 0);
        return 1;
      }
    }
  }
  return 0;
}

// Position - 0xD97
bool func_22() {
  vector3 vVar0;
  int iVar3;
  int iVar4;

  if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
    vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
  }
  ped::get_closest_ped(vVar0, fLocal_41, 1, 1, &iVar3, 0, 1, -1);
  if (entity::does_entity_exist(iVar3) && !entity::is_entity_dead(iVar3, 0)) {
    iVar4 = entity::get_entity_model(iVar3);
    if (iVar4 == joaat("ig_tonya")) {
      iLocal_38 = iVar3;
      entity::set_entity_as_mission_entity(iLocal_38, 1, 0);
      ped::set_ped_money(iLocal_38, 0);
      ped::set_ped_can_be_targetted(iLocal_38, 0);
      ped::set_ped_name_debug(iLocal_38, "TONYA");
      ped::set_ped_relationship_group_hash(iLocal_38, 1862763509);
      func_25(&uLocal_63, 3, iLocal_38, "TONYA", 1, 1);
      func_24();
      if (!func_23(vLocal_57)) {
        if (ai::get_script_task_status(iLocal_38, 713668775) != 1) {
          ai::task_follow_nav_mesh_to_coord(iLocal_38, vLocal_57, 1f, -1, 0.25f,
                                            0, fLocal_60);
          ped::set_ped_keep_task(iLocal_38, 1);
        }
        return true;
      }
    }
  }
  return false;
}

// Position - 0xE6E
bool func_23(vector3 vParam0) {
  if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
    return true;
  }
  return false;
}

// Position - 0xE98
void func_24() {
  vector3 vVar0;

  if (entity::does_entity_exist(iLocal_38) &&
      !entity::is_entity_dead(iLocal_38, 0)) {
    vVar0 = {entity::get_entity_coords(iLocal_38, 1)};
    if (func_23(vLocal_57)) {
      fLocal_61 = system::vdist(vVar0, vLocal_49);
      fLocal_62 = system::vdist(vVar0, vLocal_53);
      if (fLocal_61 < fLocal_62) {
        vLocal_57 = {vLocal_49};
        fLocal_60 = fLocal_52;
      }
      else {
        vLocal_57 = {vLocal_53};
        fLocal_60 = fLocal_56;
      }
      if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
        if (entity::is_entity_in_angled_area(
                player::player_ped_id(), 407.4285f, -1626.572f, 27.29278f,
                412.8245f, -1620.167f, 33.29278f, 6f, 0, 1, 0)) {
          vLocal_57 = {vLocal_53};
          fLocal_60 = fLocal_56;
        }
      }
    }
  }
}

// Position - 0xF51
void func_25(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4,
             int iParam5) {
  if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
  }
  (*uParam0)[iParam1 /*10*/] = iParam2;
  StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
  (*uParam0)[iParam1 /*10*/].f_7 = 1;
  (*uParam0)[iParam1 /*10*/].f_8 = iParam4;
  (*uParam0)[iParam1 /*10*/].f_9 = iParam5;
  if (!Global_69702) {
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
        ped::set_ped_can_play_ambient_anims(iParam2, 0);
      }
      else {
        ped::set_ped_can_play_ambient_anims(iParam2, 1);
      }
    }
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
      }
      else {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
      }
    }
  }
}

// Position - 0xFEC
bool func_26(int iParam0, int iParam1) {
  var uVar0;

  if (iParam0 == 11 || iParam0 == -1) {
    return false;
  }
  if (iParam1 < 0 || iParam1 >= 32) {
    return false;
  }
  uVar0 =
      gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
  return uVar0;
}

// Position - 0x1039
void func_27() {
  streaming::remove_anim_dict(
      "amb@world_human_stand_mobile@female@standing@call@enter");
  streaming::remove_anim_dict(
      "amb@world_human_stand_mobile@female@standing@call@base");
  streaming::remove_anim_dict(
      "amb@world_human_stand_mobile@female@standing@call@exit");
  streaming::set_model_as_no_longer_needed(joaat("prop_phone_ing"));
  if (entity::does_entity_exist(iLocal_38)) {
    if (entity::is_entity_occluded(iLocal_38)) {
      ped::delete_ped(&iLocal_38);
    }
    else {
      entity::set_ped_as_no_longer_needed(&iLocal_38);
    }
  }
  script::terminate_this_thread();
}

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
int iLocal_36 = 0;
var *uLocal_37 = NULL;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
var uLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
struct<16> Local_202 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<16> Local_218 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<2> Local_234 = {
	0, 0
};
struct<2> Local_236 = {
	0, 0
};
var uLocal_238 = 0;
var uLocal_239 = 0;
int iLocal_240 = 0;
int iLocal_241 = 0;
vector3 vLocal_242 = {0f, 0f, 0f};
int iLocal_245 = 0;
int iLocal_246 = 0;
int iLocal_247 = 0;
int *iLocal_248 = NULL;
int iLocal_249 = 0;
int iLocal_250 = 0;
int iLocal_251 = 0;
int iLocal_252 = 0;
int iLocal_253 = 0;
int iLocal_254 = 0;
int iLocal_255[20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
var uLocal_276[20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int iLocal_297 = 0;
int *iLocal_298 = NULL;
int iLocal_299[3] = {0, 0, 0};
char *sLocal_303 = NULL;
char cLocal_304[16] = "";
var uLocal_306 = 0;
var uLocal_307 = 0;
struct<4> Local_308 = {
	0, 0, 0, 0
};
struct<4> Local_312 = {
	0, 0, 0, 0
};
struct<4> Local_316 = {
	0, 0, 0, 0
};
struct<4> Local_320 = {
	0, 0, 0, 0
};
char cLocal_324[64] = "";
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
char cLocal_340[64] = "";
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
struct<16> Local_356 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<16> Local_372 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<16> Local_388 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<8> Local_404 = {
	0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
struct<16> Local_420 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
int iLocal_436 = 0;
bool bLocal_437 = 0;
bool bLocal_438 = 0;
int iLocal_439 = 0;
int iLocal_440 = 0;
bool bLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
int iLocal_447 = 0;
int iLocal_448 = 0;
int iLocal_449 = 0;
int iLocal_450 = 0;
int iLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
int iLocal_455 = 0;
int iLocal_456 = 0;
int iLocal_457 = 0;
int iLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 10;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
struct<4> Local_502 = {
	0, 0, 0, 0
};
var uLocal_506 = 0;
bool bLocal_507 = 0;
bool bLocal_508 = 0;
bool bLocal_509 = 0;
struct<18> ScriptParam_0 = {
	0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5
};
var uScriptParam_18 = 0;
var uScriptParam_19 = 0;
var uScriptParam_20 = 0;
var uScriptParam_21 = 0;
var uScriptParam_22 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	char *sVar1;
	char[] cVar5[8];
	char[] cVar9[8];
	char *sVar13;
	int iVar29;
	int iVar30;
	struct<8> Var31;
	int iVar39;
	float fVar40;
	int iVar41;
	bool bVar42;
	float fVar43;
	char cVar44[64];
	char cVar60[64];
	vector3 vVar76;
	int iVar79;
	int iVar80;
	bool bVar81;
	int iVar82;
	int iVar83;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	StringCopy(&Local_202, "", 64);
	StringCopy(&Local_218, "", 64);
	iLocal_245 = -1;
	iLocal_247 = 1;
	iLocal_439 = 1;
	iLocal_447 = 1;
	iLocal_455 = 1;
	iLocal_456 = 65;
	iLocal_457 = 49;
	iLocal_458 = 64;
	vLocal_242 = {ScriptParam_0.f_1[0 /*3*/]};
	func_112();
	if (player::has_force_cleanup_occurred(19)) {
		func_107(0);
	}
	if (func_104(func_106(script::get_this_script_name()))) {
		func_107(0);
	}
	if (!func_103()) {
		func_107(0);
	}
	if (!player::is_player_playing(player::player_id())) {
		func_107(0);
	}
	if (func_102()) {
		func_107(0);
	}
	if (func_101()) {
		func_107(0);
	}
	if (system::vmag2(entity::get_entity_velocity(player::player_ped_id())) > 1369f && !func_100()) {
		func_107(0);
	}
	if (gameplay::get_game_timer() < Global_25450 + 10000 && !func_100()) {
		func_107(0);
	}
	StringCopy(&Local_404, "", 64);
	iLocal_299[0] = 1;
	iLocal_299[1] = 1;
	iLocal_299[2] = 1;
	func_99();
	streaming::request_model(iLocal_36);
	while (!streaming::has_model_loaded(iLocal_36)) {
		system::wait(0);
	}
	if (!iLocal_436) {
		func_107(0);
	}
	streaming::request_anim_dict(&cLocal_324);
	streaming::request_anim_dict(&cLocal_340);
	iLocal_249 = 1;
	while (!streaming::has_anim_dict_loaded(&cLocal_324) || !streaming::has_anim_dict_loaded(&cLocal_340) ||
		   !streaming::has_model_loaded(iLocal_36)) {
		system::wait(0);
	}
	Global_25450 = gameplay::get_game_timer();
	gameplay::clear_area_of_peds(vLocal_242, 0.5f, 0);
	iLocal_240 = ped::create_ped(25, iLocal_36, vLocal_242, ScriptParam_0.f_17[0], 0, 1);
	func_97();
	streaming::set_model_as_no_longer_needed(iLocal_36);
	iLocal_241 = 1;
	if (entity::does_entity_exist(iLocal_240) && func_96(iLocal_240)) {
		ped::set_ped_combat_attributes(iLocal_240, 17, 1);
		ped::set_blocking_of_non_temporary_events(iLocal_240, 1);
	}
	iLocal_297 = 0;
	uLocal_442 = uLocal_442;
	uLocal_443 = uLocal_443;
	uLocal_444 = uLocal_444;
	uLocal_445 = uLocal_445;
	uLocal_446 = uLocal_446;
	MemCopy(&cLocal_304, {Local_234}, 4);
	StringConCat(&cLocal_304, "AUD", 16);
	MemCopy(&Local_308, {Local_234}, 4);
	StringConCat(&Local_308, "_RAND_", 16);
	iLocal_250 = 0;
	iLocal_298 = -1;
	iVar0 = 1;
	iVar30 = 0;
	iVar41 = 0;
	iLocal_253 = iLocal_253;
	uLocal_276[0] = uLocal_276[0];
	iLocal_254 = iLocal_254;
	uLocal_506 = uLocal_506;
	bLocal_507 = bLocal_507;
	func_95(0, 0);
	bLocal_508 = false;
	while (iVar0 == 1) {
		if (!func_96(iLocal_240)) {
			func_91(func_106(script::get_this_script_name()));
			func_107(0);
		}
		if (!brain::is_world_point_within_brain_activation_range()) {
			func_107(1);
		}
		fVar43 = func_90(player::player_ped_id(), iLocal_240);
		if (fVar43 < 10f && func_89()) {
			ped::set_ik_target(iLocal_240, 1, player::player_ped_id(), 31086, 0f, 0f, 0f, 0, -1, -1);
		}
		if (fVar43 < 8f) {
			ped::set_ik_target(player::player_ped_id(), 1, iLocal_240, 31086, 0f, 0f, 0f, 0, -1, -1);
		}
		if (fVar43 < 15f) {
			controls::disable_control_action(0, 46, 1);
		}
		if (bLocal_508) {
			if (bLocal_509) {
				graphics::draw_debug_text_2d("controlledByAnim", 0.02f, 0.5f, 0f, 0, 0, 255, 255);
			}
			else {
				graphics::draw_debug_text_2d("NOT controlledByAnim", 0.02f, 0.5f, 0f, 0, 0, 255, 255);
			}
			if (iLocal_245 == -1) {
				graphics::draw_debug_text_2d("iBlockObject OFF", 0.02f, 0.6f, 0f, 0, 0, 255, 255);
			}
			else {
				graphics::draw_debug_text_2d("iBlockObject ON", 0.02f, 0.6f, 0f, 0, 0, 255, 255);
			}
			if (iLocal_440) {
				graphics::draw_debug_text_2d("MONOLOGUE", 0.02f, 0.65f, 0f, 0, 0, 255, 255);
			}
			else {
				graphics::draw_debug_text_2d("IDLE", 0.02f, 0.65f, 0f, 0, 0, 255, 255);
			}
			StringCopy(&cVar44, "conversation_offset ", 64);
			StringIntConCat(&cVar44, Global_101645[iLocal_251], 64);
			graphics::draw_debug_text_2d(&cVar44, 0.02f, 0.8f, 0f, 0, 0, 255, 255);
			StringCopy(&cVar44, "max_conversation_offset ", 64);
			StringIntConCat(&cVar44, iLocal_252, 64);
			graphics::draw_debug_text_2d(&cVar44, 0.02f, 0.81f, 0f, 0, 0, 255, 255);
			StringCopy(&cVar44, "conversation_split_offset ", 64);
			StringIntConCat(&cVar44, iLocal_297, 64);
			graphics::draw_debug_text_2d(&cVar44, 0.02f, 0.82f, 0f, 0, 0, 255, 255);
			StringCopy(&cVar44, "max_conversation_split_offsets[conversation_offset] ", 64);
			StringIntConCat(&cVar44, iLocal_255[Global_101645[iLocal_251]], 64);
			graphics::draw_debug_text_2d(&cVar44, 0.02f, 0.83f, 0f, 0, 0, 255, 255);
		}
		vVar76 = {entity::get_entity_coords(iLocal_240, 1)};
		if (entity::has_entity_collided_with_anything(iLocal_240) && iLocal_250 != 25 && iLocal_250 != 5 &&
			iLocal_250 != 6) {
			func_88();
			if (func_87()) {
				func_85();
				ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
				iLocal_250 = 25;
			}
			else {
				func_84();
				func_85();
				iLocal_250 = 5;
				iVar41 = gameplay::get_game_timer();
			}
			audio::_play_ambient_speech1(iLocal_240, "GENERIC_CURSE_MED", "SPEECH_PARAMS_FORCE", 1);
		}
		if (func_102() || gameplay::get_mission_flag() || func_101() || !func_103()) {
			if (!func_83() && script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) == 0) {
				if (func_102()) {
				}
				if (gameplay::get_mission_flag()) {
				}
				ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
				iLocal_250 = 25;
			}
		}
		if (player::is_player_playing(player::player_id())) {
			if (player::is_player_free_aiming_at_entity(player::player_id(), iLocal_240) ||
				player::is_player_targetting_entity(player::player_id(), iLocal_240))
				&&fVar43 < 25f && func_82(player::player_ped_id()) != joaat("weapon_unarmed") &&
					func_79(iLocal_240, player::player_ped_id(), 1126825984, 0) {
					if (!func_83()) {
						func_85();
						ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
						iLocal_250 = 24;
					}
				}
		}
		if (ped::is_ped_injured(iLocal_240) || gameplay::is_bullet_in_area(vVar76, 50f, 1) ||
			gameplay::is_bullet_in_area(vVar76, 50f, 0) || gameplay::is_projectile_in_area(vVar76, 20f, 20f, 20f, 0) ||
			fire::is_explosion_in_sphere(-1, vVar76, 50f) || graphics::_0x2F09F7976C512404(vVar76, 1f)) {
			if (!func_83()) {
				func_85();
				ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
				iLocal_250 = 24;
			}
		}
		if (entity::has_entity_been_damaged_by_entity(iLocal_240, player::player_ped_id(), 1)) {
			func_85();
			ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
			iLocal_250 = 24;
		}
		if (func_78(iLocal_240, player::player_ped_id(), 1) < 25f) {
			if (!ui::does_blip_exist(iLocal_248)) {
				func_74(&iLocal_248, &iLocal_240, 0);
			}
		}
		else if (ui::does_blip_exist(iLocal_248)) {
			func_73(&iLocal_248);
		}
		if (!iLocal_439) {
			if (!ped::is_ped_injured(iLocal_240) && !ped::is_ped_injured(player::player_ped_id())) {
				if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
								   entity::get_entity_coords(iLocal_240, 1)) < 16f) {
					iVar79 = gameplay::get_hash_key(script::get_this_script_name());
					iVar80 = func_72(iVar79);
					if (func_71(iVar80)) {
						if (!func_70(iVar80)) {
							func_61(iVar79, 0);
						}
					}
				}
			}
		}
		switch (iLocal_250) {
		case 0:
			graphics::draw_debug_text_2d("SET_IDLING", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			iLocal_297 = 0;
			func_57();
			iLocal_250 = 1;
			if (!func_56()) {
				graphics::draw_debug_text_2d("SET_IDLING SET_PED_IDLING", 0.02f, 0.11f, 0f, 0, 0, 255, 255);
				func_95(0, 1);
			}
			break;

		case 1:
			graphics::draw_debug_text_2d("WAIT_FOR_ANIM_TO_BE_LOADED", 0.02f, 0.15f, 0f, 0, 0, 255, 255);
			bVar38 = func_55();
			if (bLocal_508) {
				if (bVar38) {
					graphics::draw_debug_text_2d("conversationAlreadyOngoing", 0.8f, 0.1f, 0f, 0, 0, 255, 255);
				}
				else {
					graphics::draw_debug_text_2d("NOT conversationAlreadyOngoing", 0.8f, 0.1f, 0f, 0, 0, 255, 255);
				}
			}
			if (func_54() && !bVar38 && !func_53()) {
				iLocal_250 = 3;
			}
			if (!func_56()) {
				func_95(0, 1);
			}
			break;

		case 5:
			graphics::draw_debug_text_2d("START_MOVE_BACK_TO_INITIAL_POSITION", 0.02f, 0.2f, 0f, 0, 0, 255, 255);
			if (gameplay::get_game_timer() - iVar41 > 1) {
				ai::task_follow_nav_mesh_to_coord(iLocal_240, vLocal_242, 1f, -1, 1f, 1024, ScriptParam_0.f_17[0]);
				iLocal_250 = 6;
			}
			break;

		case 6:
			graphics::draw_debug_text_2d("WAIT_MOVE_BACK_TO_INITIAL_POSITION", 0.02f, 0.25f, 0f, 0, 0, 255, 255);
			if (ai::get_script_task_status(iLocal_240, 713668775) != 1 &&
				ai::get_script_task_status(iLocal_240, 713668775) != 0) {
				graphics::draw_debug_text_2d("WAIT_MOVE_BACK_TO_INITIAL_POSITION TASK_PLAY_ANIM", 0.02f, 0.26f, 0f, 0,
											 0, 255, 255);
				ai::task_play_anim(iLocal_240, &cLocal_340, "idle_intro", 4f, -4f, -1, 0, 0, 0, 0, 0);
				ped::_0x2208438012482A1A(iLocal_240, 0, 0);
				func_112();
				iLocal_250 = 0;
			}
			break;

		case 3:
			graphics::draw_debug_text_2d("START_IDLING", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			if (Global_3) {
				fVar40 = 25f;
			}
			else {
				fVar40 = 25f;
			}
			if (func_78(iLocal_240, player::player_ped_id(), 1) < fVar40) {
				if (func_52() == 1) {
					iLocal_250 = 8;
					iLocal_440 = 0;
				}
			}
			if (!func_56()) {
				func_95(0, 1);
			}
			break;

		case 7:
			graphics::draw_debug_text_2d("PRE_PLAY_MONOLOGUE", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			if (func_54()) {
				iLocal_250 = 8;
			}
			if (!func_56()) {
			}
			break;

		case 8:
			graphics::draw_debug_text_2d("PLAY_MONOLOGUE", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			iLocal_252 = iLocal_252;
			if (func_53()) {
				func_85();
				func_95(0, 1);
				iLocal_250 = 0;
			}
			else if (!func_56()) {
				func_48();
				iLocal_440 = 1;
				func_47();
				iLocal_297++;
				iVar39 = 1;
				if (fVar43 > 15f) {
					iVar39 = 0;
					func_85();
					func_95(1, 0);
				}
				if (iLocal_297 < iLocal_255[Global_101645[iLocal_251]] && iVar39) {
					func_57();
					iLocal_250 = 7;
				}
				else {
					iLocal_250 = 9;
				}
			}
			else if (iLocal_440 == 1) {
				if (entity::is_entity_playing_anim(iLocal_240, &Local_372, &Local_356, 3)) {
					func_46(Global_101645[iLocal_251], iLocal_297,
							entity::get_entity_anim_current_time(iLocal_240, &Local_372, &Local_356));
				}
			}
			break;

		case 9:
			graphics::draw_debug_text_2d("MOVE_TO_NEXT_MONOLOGUE", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			iVar36 = func_55();
			iVar37 = func_56();
			func_45(Global_101645[iLocal_251]);
			if (!iVar37 && (!iVar36 || bLocal_437)) {
				if (bLocal_507) {
					Global_101645[iLocal_251] = uLocal_506;
				}
				else {
					Global_101645[iLocal_251]++;
				}
				if (Global_101645[iLocal_251] >= iLocal_252) {
					Global_101645[iLocal_251] = 0;
				}
				func_95(0, 1);
				iLocal_250 = 0;
			}
			else if (!iVar37 && iVar36) {
				graphics::draw_debug_text_2d("CONVERSATION STILL RUNNING", 0.02f, 0.3f, 0f, 0, 0, 255, 255);
				if (!func_56()) {
					func_95(0, 1);
				}
			}
			break;

		case 13:
			graphics::draw_debug_text_2d("NEWSTATE", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			func_44(&sVar1);
			func_43(&uLocal_37, 0, player::player_ped_id(), &sVar1, 0, 1);
			func_43(&uLocal_37, 3, iLocal_240, &Local_236, 0, 1);
			func_42(&cVar5);
			if (func_32(&uLocal_37, &cLocal_304, &cVar5, 3, 0, 0, 0)) {
				iLocal_250 = 14;
			}
			func_31();
			break;

		case 14:
			graphics::draw_debug_text_2d("WAIT_TO_START_CONVERSATION", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			iVar29 = iVar29;
			bVar42 = false;
			if (iLocal_440 == 0) {
				func_31();
				bVar42 = true;
			}
			else {
				if (!func_55()) {
					bVar42 = true;
				}
				func_31();
			}
			if (bVar42) {
				iLocal_246 = iLocal_247;
				if (!bLocal_438) {
					func_30(&cVar9);
					func_44(&sVar1);
				}
				else {
					func_29();
					func_28(&cVar9);
				}
				func_43(&uLocal_37, 0, player::player_ped_id(), &sVar1, 0, 1);
				func_43(&uLocal_37, 3, iLocal_240, &Local_236, 0, 1);
				Global_101645[iLocal_251]++;
				if (Global_101645[iLocal_251] >= iLocal_252) {
					Global_101645[iLocal_251] = 0;
				}
				iLocal_250 = 10;
			}
			break;

		case 10:
			graphics::draw_debug_text_2d("START_LOADING_CONVERSATION", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			if (!bLocal_438) {
				func_26(&Local_404);
				func_25(iLocal_246, &Var31);
				StringConCat(&Local_404, &Var31, 64);
			}
			else {
				func_24(&Local_404);
				func_25(iLocal_246, &Var31);
				StringConCat(&Local_404, &Var31, 64);
			}
			streaming::request_anim_dict(&Local_404);
			iVar35 = 0;
			if (streaming::has_anim_dict_loaded(&Local_404)) {
				if (bLocal_437) {
					iVar35 = 1;
				}
				else if (func_32(&uLocal_37, &cLocal_304, &cVar9, 3, 0, 0, 0)) {
					iVar35 = 1;
				}
				if (iVar35 == 1) {
					iLocal_250 = 11;
				}
			}
			func_31();
			break;

		case 11:
			graphics::draw_debug_text_2d("CHECK_FOR_LOADED_CONVERSATION", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			if (audio::is_scripted_conversation_loaded()) {
				func_22(&sVar13);
				ai::task_play_anim(iLocal_240, &Local_404, &sVar13, 2f, -2f, -1, 0, 0, 0, 0, 0);
				iLocal_250 = 12;
			}
			else {
				func_31();
			}
			break;

		case 12:
			graphics::draw_debug_text_2d("START_CONVERSATION", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			iLocal_246++;
			Local_420 = {Local_404};
			if (iLocal_246 >= func_15() || fVar43 > 10f) {
				if (fVar43 > 10f && func_55()) {
					func_13();
				}
				iLocal_250 = 16;
			}
			else {
				if (!bLocal_438) {
					func_26(&Local_404);
					func_25(iLocal_246, &Var31);
					StringConCat(&Local_404, &Var31, 64);
				}
				else {
					func_24(&Local_404);
					func_25(iLocal_246, &Var31);
					StringConCat(&Local_404, &Var31, 64);
				}
				streaming::request_anim_dict(&Local_404);
				iLocal_250 = 15;
			}
			break;

		case 15:
			graphics::draw_debug_text_2d("WAIT_FOR_CONVERSATION_SECTION_OVER", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			StringCopy(&cVar60, "talking offset:", 64);
			StringIntConCat(&cVar60, iLocal_246, 64);
			graphics::draw_debug_text_2d(&cVar60, 0.02f, 0.9f, 0f, 0, 0, 255, 255);
			IntToString(&cVar60, func_15(), 64);
			graphics::draw_debug_text_2d(&cVar60, 0.03f, 0.9f, 0f, 0, 0, 255, 255);
			if (streaming::has_anim_dict_loaded(&Local_404)) {
				graphics::draw_debug_text_2d("HAS_ANIM_DICT_LOADED", 0.02f, 0.2f, 0f, 0, 0, 255, 255);
				if (!func_56()) {
					graphics::draw_debug_text_2d("NOT IS_ANIM_PLAYING_ON_PED", 0.02f, 0.3f, 0f, 0, 0, 255, 255);
					streaming::remove_anim_dict(&Local_420);
					if (!bLocal_438) {
						func_26(&Local_404);
						func_25(iLocal_246, &Var31);
						StringConCat(&Local_404, &Var31, 64);
					}
					else {
						func_24(&Local_404);
						func_25(iLocal_246, &Var31);
						StringConCat(&Local_404, &Var31, 64);
					}
					func_22(&sVar13);
					ai::task_play_anim(iLocal_240, &Local_404, &sVar13, 1000f, -1000f, -1, 0, 0, 0, 0, 0);
					ped::_0x2208438012482A1A(iLocal_240, 0, 0);
					iLocal_250 = 12;
				}
			}
			else if (!func_56()) {
			}
			break;

		case 16:
			graphics::draw_debug_text_2d("WAIT_FOR_CONVERSATION_TO_END", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			if (!func_56()) {
				func_12(&uLocal_37, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					audio::disable_ped_pain_audio(player::player_ped_id(), 0);
				}
				streaming::remove_anim_dict(&Local_420);
				func_11();
				func_95(0, 1);
				iLocal_250 = 0;
			}
			break;

		case 24:
			graphics::draw_debug_text_2d("WAITING_TO_BLEND_INTO_IDLE_BEFORE_FLEEING", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
			system::wait(1000);
			func_10();
			iVar0 = 0;
			break;

		case 25:
			graphics::draw_debug_text_2d("WAITING_TO_BLEND_INTO_IDLE_BEFORE_WANDERING", 0.02f, 0.1f, 0f, 0, 0, 255,
										 255);
			func_8();
			iVar0 = 0;
			break;
		}
		bVar81 = script::_get_number_of_instances_of_script_with_name_hash(joaat("context_controller")) > 0;
		if (!bVar81) {
		}
		if ((iLocal_250 == 0 || iLocal_250 == 1 || iLocal_250 == 3 || iLocal_250 == 8 || iLocal_250 == 9 ||
			 iLocal_250 == 7) &&
			func_78(iLocal_240, player::player_ped_id(), 1) < 5f && iLocal_436 == 1 &&
			!ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) && iVar30 == 0 && iLocal_439 == 1 && !Global_3 &&
			func_7() && bVar81) {
			if (iLocal_298 == -1) {
				func_6(&iLocal_298, 4, sLocal_303, 0, 0, 0, 0);
			}
			controls::set_input_exclusive(0, 51);
			if (func_4(iLocal_298, 1)) {
				func_44(&sVar1);
				func_42(&cVar5);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					audio::disable_ped_pain_audio(player::player_ped_id(), 1);
				}
				func_85();
				func_95(1, 1);
				iVar30 = 1;
				iLocal_250 = 13;
				iVar29 = 0;
				iVar82 = func_72(gameplay::get_hash_key(script::get_this_script_name()));
				if (func_71(iVar82)) {
					if (!func_70(iVar82)) {
						func_61(gameplay::get_hash_key(script::get_this_script_name()), 0);
					}
				}
				func_2(&iLocal_298);
			}
		}
		else if (iLocal_298 != -1) {
			func_2(&iLocal_298);
		}
		func_1();
		system::wait(0);
	}
	if (iLocal_298 != -1) {
		func_2(&iLocal_298);
	}
	if (ui::does_blip_exist(iLocal_248)) {
		func_73(&iLocal_248);
	}
	iVar83 = 0;
	while (true) {
		graphics::draw_debug_text_2d("do_monologue = FALSE", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
		if (bLocal_508) {
			graphics::draw_debug_text_2d("WAITING TO CLEAN UP", 0.02f, 0.1f, 0f, 0, 0, 255, 255);
		}
		if (!func_96(iLocal_240)) {
			if (!bLocal_441) {
				func_91(func_106(script::get_this_script_name()));
			}
			func_107(0);
		}
		if (entity::has_entity_been_damaged_by_entity(iLocal_240, player::player_ped_id(), 1) && !iVar83) {
			ped::set_blocking_of_non_temporary_events(iLocal_240, 0);
			ai::clear_ped_tasks(iLocal_240);
			ai::task_smart_flee_ped(iLocal_240, player::player_ped_id(), 100f, -1, 0, 0);
			ped::set_ped_keep_task(iLocal_240, 1);
			iVar83 = 1;
		}
		if (entity::is_entity_occluded(iLocal_240) && func_78(iLocal_240, player::player_ped_id(), 1) > 50f &&
			!brain::is_world_point_within_brain_activation_range()) {
			func_107(1);
		}
		system::wait(0);
	}
}

// Position - 0x11FC
void func_1() {
	if (!Global_3 || iLocal_450) {
		return;
	}
	if (entity::does_entity_exist(iLocal_448) && !entity::is_entity_dead(iLocal_448, 0) &&
		!entity::is_entity_dead(iLocal_240, 0)) {
		if (!iLocal_449) {
			if (gameplay::get_distance_between_coords(entity::get_entity_coords(iLocal_240, 1),
													  entity::get_entity_coords(player::player_ped_id(), 1), 1) < 15f) {
				ai::task_flush_route();
				ai::task_extend_route(379.8408f, 152.3401f, 102.0718f);
				ai::task_extend_route(380.4872f, 158.653f, 102.1292f);
				ai::task_extend_route(388.7568f, 179.6577f, 102.1317f);
				ai::task_follow_point_route(iLocal_448, 1f, 0);
				iLocal_449 = 1;
			}
		}
		else {
			ped::set_ik_target(iLocal_448, 1, iLocal_240, 0, 0f, 0f, 0f, 0, -1, -1);
			if (gameplay::get_distance_between_coords(entity::get_entity_coords(iLocal_448, 1), 377.4565f, 154.6708f,
													  102.0838f, 1) > 25f) {
				entity::set_ped_as_no_longer_needed(&iLocal_448);
				iLocal_450 = 1;
			}
			else if (gameplay::get_distance_between_coords(entity::get_entity_coords(iLocal_448, 1),
														   entity::get_entity_coords(iLocal_240, 1), 1) < 3f &&
					 iLocal_451 == 0) {
				iLocal_451 = 1;
			}
		}
	}
}

// Position - 0x1319
void func_2(int *iParam0) {
	int iVar0;

	if (*iParam0 == -1) {
		return;
	}
	iVar0 = func_3(*iParam0);
	if (iVar0 == -1) {
		*iParam0 = -1;
		return;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/].f_7 = 1;
			*iParam0 = -1;
			return;
		}
	}
	*iParam0 = -1;
}

// Position - 0x1370
int func_3(int iParam0) {
	int iVar0;

	if (iParam0 < 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x13AB
bool func_4(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_3(iParam0);
	if (iVar0 == -1) {
		return false;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return false;
	}
	if (func_5(0)) {
		return false;
	}
	if (cutscene::is_cutscene_playing()) {
		return false;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/] == 1 && Global_36484[iVar0 /*32*/].f_4 == 1) {
			if (iParam1) {
				if (Global_36484[iVar0 /*32*/].f_29) {
					return false;
				}
			}
			Global_36484[iVar0 /*32*/].f_5 = 1;
			Global_36484[iVar0 /*32*/].f_29 = 1;
			return true;
		}
		else {
			if (Global_36484[iVar0 /*32*/] == 0) {
			}
			if (Global_36484[iVar0 /*32*/].f_7) {
			}
		}
	}
	return false;
}

// Position - 0x1463
bool func_5(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x14BD
void func_6(int iParam0, int iParam1, char *sParam2, int iParam3, char *sParam4, int iParam5, int iParam6) {
	int iVar0;

	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("context_controller")) < 1) {
	}
	if (streaming::is_player_switch_in_progress()) {
		if (*iParam0 != -1) {
			func_2(iParam0);
		}
		return;
	}
	if (*iParam0 != -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (!Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/] = 1;
			Global_36484[iVar0 /*32*/].f_1 = Global_36685;
			Global_36685++;
			Global_36484[iVar0 /*32*/].f_4 = 0;
			Global_36484[iVar0 /*32*/].f_29 = 0;
			Global_36484[iVar0 /*32*/].f_5 = 0;
			Global_36484[iVar0 /*32*/].f_2 = iParam1;
			StringCopy(&Global_36484[iVar0 /*32*/].f_8, sParam2, 16);
			Global_36484[iVar0 /*32*/].f_6 = iParam3;
			Global_36484[iVar0 /*32*/].f_31 = script::get_id_of_this_thread();
			Global_36484[iVar0 /*32*/].f_7 = 0;
			Global_36484[iVar0 /*32*/].f_3 = iParam5;
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				Global_36484[iVar0 /*32*/].f_12 = 1;
				StringCopy(&Global_36484[iVar0 /*32*/].f_13, sParam4, 64);
				Global_36484[iVar0 /*32*/].f_30 = iParam6;
			}
			else {
				Global_36484[iVar0 /*32*/].f_12 = 0;
				Global_36484[iVar0 /*32*/].f_30 = 0;
			}
			*iParam0 = Global_36484[iVar0 /*32*/].f_1;
			return;
		}
		iVar0++;
	}
}

// Position - 0x15E8
int func_7() { return 1; }

// Position - 0x15F1
void func_8() {
	func_9();
	if (func_96(iLocal_240) && func_96(player::player_ped_id())) {
		ped::set_blocking_of_non_temporary_events(iLocal_240, 0);
		ai::task_wander_standard(iLocal_240, 1193033728, 0);
		ped::set_ped_keep_task(iLocal_240, 1);
	}
}

// Position - 0x162D
void func_9() {
	if (!entity::is_entity_dead(iLocal_240, 0)) {
		audio::_0x18EB48CFC41F2EA0(iLocal_240, 0);
	}
}

// Position - 0x1647
void func_10() {
	func_9();
	if (func_96(iLocal_240) && func_96(player::player_ped_id())) {
		ped::set_blocking_of_non_temporary_events(iLocal_240, 0);
		ai::task_smart_flee_ped(iLocal_240, player::player_ped_id(), 100f, -1, 0, 0);
		ped::set_ped_keep_task(iLocal_240, 1);
		func_85();
	}
}

// Position - 0x168D
void func_11() {}

// Position - 0x1695
void func_12(var *uParam0, int iParam1) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
		(*uParam0)[iParam1 /*10*/].f_7 = 0;
	}
}

// Position - 0x16B2
void func_13() {
	Global_14611 = 0;
	func_14();
}

// Position - 0x16C2
void func_14() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x1719
int func_15() {
	int iVar0;

	iVar0 = func_16();
	if (iVar0 == 2) {
		return 3;
	}
	else if (iVar0 == 0) {
		return 22;
	}
	return 4;
}

// Position - 0x1740
int func_16() {
	func_17();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x1759
void func_17() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_21(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_20(player::player_ped_id());
			if (func_19(iVar0) && (!func_18(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_19(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x1856
bool func_18(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x1864
bool func_19(int iParam0) { return iParam0 < 3; }

// Position - 0x1870
int func_20(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_21(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x18AD
int func_21(int iParam0) {
	if (func_19(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x18D7
void func_22(char *sParam0) {
	struct<16> Var0;

	func_23(&Var0);
	*sParam0 = {Var0};
	StringConCat(sParam0, "_", 64);
	StringIntConCat(sParam0, iLocal_246, 64);
}

// Position - 0x18FD
void func_23(char *sParam0) {
	int iVar0;

	iVar0 = func_16();
	if (iVar0 == 2) {
		StringCopy(sParam0, "pamela_convo_trevor_im_trying_to_get_noticed", 64);
	}
	else if (iVar0 == 0) {
		StringCopy(sParam0, "pamela_ig_2_imterribledarling", 64);
	}
	else if (iVar0 == 1) {
		StringCopy(sParam0, "pamela_ig_5_inthebackdoor", 64);
	}
}

// Position - 0x193B
void func_24(char *sParam0) {
	int iVar0;

	iVar0 = iLocal_254 + 1;
	*sParam0 = {Local_202};
	StringConCat(sParam0, "@", 64);
	StringConCat(sParam0, "CONVO_", 64);
	StringIntConCat(sParam0, iVar0, 64);
	StringConCat(sParam0, "@", 64);
	StringConCat(sParam0, "CONVO_", 64);
	StringIntConCat(sParam0, iVar0, 64);
}

// Position - 0x197F
void func_25(int iParam0, char *sParam1) {
	switch (iParam0) {
	case 0: StringCopy(sParam1, "A", 16); break;

	case 1: StringCopy(sParam1, "B", 16); break;

	case 2: StringCopy(sParam1, "C", 16); break;

	case 3: StringCopy(sParam1, "D", 16); break;

	case 4: StringCopy(sParam1, "E", 16); break;

	case 5: StringCopy(sParam1, "F", 16); break;

	case 6: StringCopy(sParam1, "G", 16); break;

	case 7: StringCopy(sParam1, "H", 16); break;

	case 8: StringCopy(sParam1, "I", 16); break;

	case 9: StringCopy(sParam1, "J", 16); break;

	case 10: StringCopy(sParam1, "K", 16); break;

	case 11: StringCopy(sParam1, "L", 16); break;

	case 12: StringCopy(sParam1, "M", 16); break;

	case 13: StringCopy(sParam1, "N", 16); break;

	case 14: StringCopy(sParam1, "O", 16); break;

	case 15: StringCopy(sParam1, "P", 16); break;

	case 16: StringCopy(sParam1, "Q", 16); break;

	case 17: StringCopy(sParam1, "R", 16); break;

	case 18: StringCopy(sParam1, "S", 16); break;

	case 19: StringCopy(sParam1, "T", 16); break;

	case 20: StringCopy(sParam1, "U", 16); break;

	case 21: StringCopy(sParam1, "V", 16); break;

	case 22: StringCopy(sParam1, "W", 16); break;

	case 23: StringCopy(sParam1, "X", 16); break;

	case 24: StringCopy(sParam1, "Y", 16); break;

	case 25: StringCopy(sParam1, "Z", 16); break;
	}
}

// Position - 0x1B48
void func_26(char *sParam0) {
	char cVar0[64];

	*sParam0 = {Local_202};
	StringConCat(sParam0, "@", 64);
	func_27(&cVar0);
	StringConCat(sParam0, &cVar0, 64);
	StringConCat(sParam0, "@", 64);
	StringConCat(sParam0, &cVar0, 64);
}

// Position - 0x1B7C
void func_27(char *sParam0) {
	struct<4> Var0;

	func_44(&Var0);
	*sParam0 = {Var0};
	StringConCat(sParam0, "_", 16);
	StringIntConCat(sParam0, iLocal_299[func_16()], 16);
}

// Position - 0x1BA7
void func_28(char *sParam0) {
	MemCopy(sParam0, {Local_234}, 4);
	StringConCat(sParam0, "_CONV_", 16);
	StringIntConCat(sParam0, iLocal_254 + 1, 16);
}

// Position - 0x1BC8
void func_29() { iLocal_254 = gameplay::get_random_int_in_range(0, iLocal_253); }

// Position - 0x1BD9
void func_30(char *sParam0) {
	int iVar0;

	MemCopy(sParam0, {Local_234}, 4);
	StringConCat(sParam0, "_CONV_", 16);
	iVar0 = func_16();
	if (iVar0 == 2) {
		StringConCat(sParam0, "T", 16);
	}
	else if (iVar0 == 0) {
		StringConCat(sParam0, "M", 16);
	}
	else {
		StringConCat(sParam0, "F", 16);
	}
	StringIntConCat(sParam0, iLocal_299[func_16()], 16);
}

// Position - 0x1C2F
void func_31() {
	if (!func_56()) {
		func_95(1, 1);
	}
}

// Position - 0x1C45
bool func_32(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_41(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_33(sParam2, iParam3, 0);
}

// Position - 0x1C93
int func_33(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_14();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_40(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_39();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_38();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_37()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_36()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_35();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_34();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_14();
	}
	return 0;
}

// Position - 0x1F5F
void func_34() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x1F8F
void func_35() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x2024
bool func_36() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x204B
bool func_37() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x20E4
void func_38() {
	if (func_18(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_16();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x2186
void func_39() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x21DC
bool func_40(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x2217
void func_41(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, var uParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = uParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x226D
void func_42(char[4] cParam0) {
	int iVar0;

	iVar0 = func_16();
	if (iVar0 == 2) {
		*cParam0 = {Local_316};
	}
	else if (iVar0 == 0) {
		*cParam0 = {Local_312};
	}
	else {
		*cParam0 = {Local_320};
	}
}

// Position - 0x22A8
void func_43(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x2343
void func_44(char *sParam0) {
	int iVar0;

	iVar0 = func_16();
	if (iVar0 == 2) {
		StringCopy(sParam0, "TREVOR", 16);
	}
	else if (iVar0 == 0) {
		StringCopy(sParam0, "MICHAEL", 16);
	}
	else {
		StringCopy(sParam0, "FRANKLIN", 16);
	}
}

// Position - 0x237B
void func_45(var uParam0) {}

// Position - 0x2383
void func_46(var uParam0, int iParam1, var uParam2) {}

// Position - 0x238B
void func_47() { streaming::remove_anim_dict(&Local_388); }

// Position - 0x239A
void func_48() {
	char *sVar0;
	struct<16> Var8;

	func_51(Global_101645[iLocal_251] + 1, &sVar0, &Var8);
	StringConCat(&Var8, "_", 64);
	StringIntConCat(&Var8, iLocal_297, 64);
	Local_356 = {Var8};
	Local_372 = {Local_388};
	func_50(&Local_356);
	ai::task_play_anim(iLocal_240, &Local_388, &Var8, 1000f, -8f, -1, 0, 0, 0, 0, 0);
	ped::_0x2208438012482A1A(iLocal_240, 0, 0);
	func_49(Global_101645[iLocal_251]);
}

// Position - 0x2410
void func_49(var uParam0) {}

// Position - 0x2418
void func_50(char *sParam0) {
	if (gameplay::are_strings_equal(sParam0, sParam0)) {
	}
}

// Position - 0x242B
void func_51(int iParam0, char *sParam1, char *sParam2) {
	StringCopy(sParam1, "Special_Ped@pamela", 32);
	switch (iParam0) {
	case 1: StringCopy(sParam2, "pamela_ig_1_p1_letmetellyoumydarlings", 64); break;

	case 2: StringCopy(sParam2, "pamela_ig_1_p2_thingsweredifferent", 64); break;

	case 3: StringCopy(sParam2, "pamela_ig_1_p3_perhapsyouhaveseentheplay", 64); break;

	case 4: StringCopy(sParam2, "pamela_ig_1_p4_whathappenstothelonelyones", 64); break;

	case 5: StringCopy(sParam2, "IwasThatslut", 64); break;

	case 6: StringCopy(sParam2, "pamela_ig_1_p6_intheolddays", 64); break;

	case 7: StringCopy(sParam2, "pamela_ig_1_p7_ImJustAWiltedFlower", 64); break;

	case 8: StringCopy(sParam2, "pamela_ig_1_p8_WonderfulTimes", 64); break;

	case 9: StringCopy(sParam2, "vinewood_is_cruel", 64); break;

	case 10: StringCopy(sParam2, "you_dont_like_movies_you_dont_like_stars", 64); break;

	case 11: StringCopy(sParam2, "this_town_is_run_by_god_damn_accountants", 64); break;

	case 12: StringCopy(sParam2, "pamela_ig_1_p12_NoWonderThisPlaceIs", 64); break;

	case 13: StringCopy(sParam2, "pamela_ig_1_p13_TheWorldIsFor", 64); break;

	case 14: StringCopy(sParam2, "pamela_ig_1_p14_YourHereToSeeStars", 64); break;
	}
}

// Position - 0x2530
int func_52() {
	struct<4> Var0;
	int iVar4;

	Var0 = {Local_308};
	StringIntConCat(&Var0, Global_101645[iLocal_251] + 1, 16);
	func_43(&uLocal_37, 3, iLocal_240, &Local_236, 0, 1);
	if (bLocal_437) {
		iVar4 = 1;
	}
	else {
		iVar4 = func_32(&uLocal_37, &cLocal_304, &Var0, 3, 0, 0, 0);
	}
	Local_502 = {Var0};
	return iVar4;
}

// Position - 0x2584
bool func_53() { return Global_91543.f_303 > 0; }

// Position - 0x2595
bool func_54() {
	var uVar0;

	uVar0 = streaming::has_anim_dict_loaded(&Local_388);
	return uVar0;
}

// Position - 0x25A8
int func_55() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return 1;
	}
	return 0;
}

// Position - 0x25CA
int func_56() {
	if (ai::get_script_task_status(iLocal_240, -2017877118) != 1 &&
		ai::get_script_task_status(iLocal_240, -2017877118) != 0) {
		return 0;
	}
	return 1;
}

// Position - 0x25F9
void func_57() {
	struct<16> Var0;

	func_58(&Var0);
	streaming::request_anim_dict(&Var0);
	Local_388 = {Var0};
}

// Position - 0x2618
void func_58(char *sParam0) {
	struct<8> Var0;

	*sParam0 = {Local_202};
	StringConCat(sParam0, "@", 64);
	func_60(&Var0);
	StringConCat(sParam0, &Var0, 64);
	StringConCat(sParam0, "@", 64);
	StringConCat(sParam0, &Var0, 64);
	func_59(&Var0);
	StringConCat(sParam0, &Var0, 64);
}

// Position - 0x2658
void func_59(char *sParam0) { func_25(iLocal_297, sParam0); }

// Position - 0x2669
void func_60(char *sParam0) {
	StringCopy(sParam0, "MONOLOGUE_", 16);
	StringIntConCat(sParam0, Global_101645[iLocal_251] + 1, 16);
}

// Position - 0x2687
void func_61(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_72(iParam0);
	if (func_71(iVar0)) {
		func_62(iVar0, iParam1);
	}
}

// Position - 0x26A8
void func_62(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 >= 0 && iVar0 <= 31) {
		if (func_71(iParam0)) {
			if (!func_69(iParam0)) {
				gameplay::set_bit(&Global_101700.f_25393.f_2, iVar0);
				if (!iParam1) {
					func_67(func_68(iParam0));
					if (!func_66(70)) {
						func_63("DI_HLP_SPCL", 2, 0, 20000, 10000, 7, 0, 210, 0);
					}
				}
			}
		}
	}
}

// Position - 0x2719
void func_63(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_64(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x2739
void func_64(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_65();
	}
}

// Position - 0x290B
void func_65() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0x2A2B
int func_66(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		return gameplay::is_bit_set(Global_101700.f_19369.f_150[iVar1], iVar0);
	}
	return 0;
}

// Position - 0x2A6E
void func_67(char *sParam0) {
	ui::_set_notification_text_entry("");
	ui::_set_notification_message_3("CHAR_ACTING_UP", "CHAR_ACTING_UP", 0, 0, "DI_FEED_CHAR", sParam0);
}

// Position - 0x2A91
char *func_68(int iParam0) {
	switch (iParam0) {
	case 0: return "CM_SPEAND";

	case 1: return "CM_SPEBAY";

	case 2: return "CM_SPEBIL";

	case 3: return "CM_SPECLI";

	case 4: return "CM_SPEGRI";

	case 5: return "CM_SPEJAN";

	case 6: return "CM_SPEJER";

	case 7: return "CM_SPEJES";

	case 8: return "CM_SPEMAN";

	case 9: return "CM_SPEMIM";

	case 10: return "CM_SPEPAM";

	case 11: return "CM_SPEIMP";

	case 12: return "CM_SPEZOM";
	}
	return "ERROR!";
}

// Position - 0x2B74
int func_69(int iParam0) {
	if (func_71(iParam0)) {
		return gameplay::is_bit_set(Global_101700.f_25393.f_2, iParam0);
	}
	return 0;
}

// Position - 0x2B9B
int func_70(int iParam0) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 >= 0 && iVar0 <= 31) {
		return gameplay::is_bit_set(Global_101700.f_25393.f_2, iVar0);
	}
	return 0;
}

// Position - 0x2BCE
bool func_71(int iParam0) {
	if (iParam0 == -1 || iParam0 == 13 || iParam0 == 9) {
		return false;
	}
	return true;
}

// Position - 0x2BF8
int func_72(int iParam0) {
	switch (iParam0) {
	case joaat("gpb_andymoon"): return 0;

	case joaat("gpb_baygor"): return 1;

	case joaat("gpb_billbinder"): return 2;

	case joaat("gpb_clinton"): return 3;

	case joaat("gpb_griff"): return 4;

	case joaat("gpb_jane"): return 5;

	case joaat("gpb_jerome"): return 6;

	case joaat("gpb_jesse"): return 7;

	case joaat("gpb_mani"): return 8;

	case joaat("gpb_mime"): return 9;

	case joaat("gpb_pameladrake"): return 10;

	case joaat("gpb_superhero"): return 11;

	case joaat("gpb_zombie"): return 12;
	}
	return -1;
}

// Position - 0x2CB6
void func_73(int *iParam0) {
	if (iLocal_447 == 1) {
		if (ui::does_blip_exist(*iParam0)) {
			ui::remove_blip(iParam0);
		}
	}
}

// Position - 0x2CD5
void func_74(int *iParam0, int iParam1, int iParam2) {
	if (iLocal_447 == 1) {
		if (!ui::does_blip_exist(*iParam0)) {
			if (entity::does_entity_exist(*iParam1)) {
				if (!ped::is_ped_injured(*iParam1)) {
					*iParam0 = func_75(*iParam1, iParam2, 145);
					if (iParam2 == 0) {
						ui::set_blip_priority(*iParam0, 7);
					}
					ui::set_blip_colour(*iParam0, 3);
				}
			}
		}
	}
}

// Position - 0x2D28
int func_75(int iParam0, bool bParam1, int iParam2) {
	int iVar0;

	iVar0 = func_76(iParam0, !bParam1, 0);
	if (iParam2 != 145 && ui::does_blip_exist(iVar0) &&
		ui::does_text_label_exist(&Global_101700.f_27009[iParam2 /*29*/].f_3)) {
		ui::set_blip_name_from_text_file(iVar0, &Global_101700.f_27009[iParam2 /*29*/].f_3);
	}
	return iVar0;
}

// Position - 0x2D7A
int func_76(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	iVar0 = ui::add_blip_for_entity(iParam0);
	if (entity::is_entity_a_vehicle(iParam0)) {
		ui::set_blip_scale(iVar0, func_77(network::network_is_game_in_progress(), 1f, 1f));
		if (!iParam2) {
			ui::set_blip_as_friendly(iVar0, iParam1);
		}
		else {
			ui::set_blip_colour(iVar0, 2);
		}
	}
	else if (entity::is_entity_a_ped(iParam0)) {
		ui::set_blip_scale(iVar0, func_77(network::network_is_game_in_progress(), 0.7f, 0.7f));
		ui::set_blip_as_friendly(iVar0, iParam1);
	}
	else if (entity::is_entity_an_object(iParam0)) {
		ui::set_blip_scale(iVar0, func_77(network::network_is_game_in_progress(), 0.7f, 0.7f));
	}
	return iVar0;
}

// Position - 0x2E1E
var func_77(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x2E35
float func_78(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x2E93
int func_79(int iParam0, int iParam1, float fParam2, int iParam3) {
	vector3 vVar0;
	vector3 vVar3;
	float fVar6;

	vVar0 = {func_81(entity::get_entity_coords(iParam1, 1) - entity::get_entity_coords(iParam0, 1))};
	if (fParam2 < 0.1f || fParam2 > 360f) {
		return 1;
	}
	if (iParam3 == 0) {
		vVar3 = {entity::get_entity_forward_vector(iParam0)};
	}
	else {
		vVar3 = {func_81(ped::get_ped_bone_coords(iParam0, 31086, 0f, 5f, 0f) -
						 ped::get_ped_bone_coords(iParam0, 31086, 0f, 0f, 0f))};
	}
	fVar6 = func_80(vVar3, vVar0);
	if (fVar6 <= system::cos(fParam2 / 2f)) {
		return 0;
	}
	return 1;
}

// Position - 0x2F24
float func_80(vector3 vParam0, vector3 vParam3) {
	return vParam0.x * vParam3.x + vParam0.y * vParam3.y + vParam0.z * vParam3.z;
}

// Position - 0x2F45
Vector3 func_81(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x2F84
int func_82(int iParam0) {
	var uVar0;

	weapon::get_current_ped_weapon(iParam0, &uVar0, 1);
	return uVar0;
}

// Position - 0x2F98
int func_83() {
	if (iLocal_250 == 24 || iLocal_250 == 25) {
		return 1;
	}
	return 0;
}

// Position - 0x2FB8
void func_84() {
	if (iLocal_245 != -1) {
		if (pathfind::does_navmesh_blocking_object_exist(iLocal_245)) {
			pathfind::remove_navmesh_blocking_object(iLocal_245);
		}
		iLocal_245 = -1;
	}
}

// Position - 0x2FD8
void func_85() {
	Global_14611 = 0;
	func_86();
}

// Position - 0x2FE8
void func_86() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0x3009
bool func_87() { return false; }

// Position - 0x3012
void func_88() {}

// Position - 0x301A
int func_89() { return 1; }

// Position - 0x3023
var func_90(int iParam0, int iParam1) { return func_78(iParam0, iParam1, 1); }

// Position - 0x3034
void func_91(int iParam0) {
	int iVar0;

	func_94(&Global_101700.f_19076, iParam0);
	iVar0 = func_92(iParam0);
	if (func_71(iVar0)) {
		func_62(func_92(iParam0), 0);
	}
}

// Position - 0x3065
int func_92(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 13) {
		iVar1 = iVar0;
		if (func_93(iVar1, 1) == iParam0) {
			return iVar1;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x3096
int func_93(int iParam0, int iParam1) {
	if (!func_71(iParam0)) {
		if (!iParam1) {
		}
		return 0;
	}
	switch (iParam0) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;

	case 3: return 8;

	case 4: return 16;

	case 5: return 64;

	case 6: return 128;

	case 7: return 256;

	case 8: return 512;

	case 10: return 2048;

	case 11: return 4096;

	case 12: return 8192;

	default:
	}
	if (!iParam1) {
	}
	return 0;
}

// Position - 0x3149
void func_94(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x315A
void func_95(int iParam0, int iParam1) {
	if (iParam0 == 1) {
		ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 2f, -2f, -1, 0, 0, 0, 0, 0);
	}
	else {
		ai::task_play_anim(iLocal_240, &cLocal_324, &Local_218, 1000f, 1000f, -1, 0, 0, 0, 0, 0);
	}
	Local_356 = {Local_218};
	if (iParam1) {
		if (!ped::is_ped_injured(iLocal_240) && !ped::is_ped_dead_or_dying(iLocal_240, 1)) {
			ped::_0x2208438012482A1A(iLocal_240, 0, 0);
		}
	}
}

// Position - 0x31CC
int func_96(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x31ED
void func_97() { func_98(); }

// Position - 0x31F9
void func_98() {
	ped::set_ped_prop_index(iLocal_240, 1, 0, 0, 0);
	if (!Global_3 || iLocal_450) {
		return;
	}
	streaming::request_model(joaat("a_m_m_business_01"));
	while (!streaming::has_model_loaded(joaat("a_m_m_business_01"))) {
		system::wait(0);
	}
	iLocal_448 = ped::create_ped(4, joaat("a_m_m_business_01"), 396.8498f, 143.3195f, 101.4659f, 360f, 1, 1);
	if (entity::does_entity_exist(iLocal_448) && !entity::is_entity_dead(iLocal_448, 0) &&
		!entity::is_entity_dead(iLocal_240, 0)) {
		ped::set_ik_target(iLocal_448, 1, iLocal_240, 0, 0f, 0f, 0f, 0, -1, -1);
	}
	if (!entity::is_entity_dead(iLocal_240, 0)) {
		audio::_dynamic_mixer_related_fn(iLocal_240, "MAG_2_PAM_PED_GROUP", 0);
	}
}

// Position - 0x32AB
void func_99() {
	iLocal_36 = joaat("u_f_o_moviestar");
	StringCopy(&Local_234, "PBPD", 8);
	StringCopy(&Local_236, "PAMELADRAKE", 16);
	StringCopy(&Local_202, "Special_Ped@pamela", 64);
	StringCopy(&Local_218, "Base", 64);
	iLocal_436 = 1;
	iLocal_252 = 14;
	sLocal_303 = "PBPD_INTERACT";
	StringCopy(&Local_312, "PBPD_CONV_GM", 16);
	StringCopy(&Local_316, "PBPD_CONV_GT", 16);
	StringCopy(&Local_320, "PBPD_CONV_GF", 16);
	StringCopy(&cLocal_324, "special_ped@pamela@base", 64);
	StringCopy(&cLocal_340, "special_ped@pamela@intro", 64);
	iLocal_251 = 10;
	iLocal_255[0] = 8;
	iLocal_255[1] = 8;
	iLocal_255[2] = 8;
	iLocal_255[3] = 12;
	iLocal_255[4] = 9;
	iLocal_255[5] = 8;
	iLocal_255[6] = 8;
	iLocal_255[7] = 9;
	iLocal_255[8] = 9;
	iLocal_255[9] = 8;
	iLocal_255[10] = 5;
	iLocal_255[11] = 7;
	iLocal_255[12] = 7;
	iLocal_255[13] = 6;
}

// Position - 0x337C
int func_100() {
	if (gameplay::is_pc_version()) {
		if (gameplay::_0xD10282B6E3751BA0() == 1f) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x3399
bool func_101() {
	if (Global_88746 != -1) {
		return gameplay::is_bit_set(Global_82612[Global_88746 /*34*/].f_15, 13);
	}
	return false;
}

// Position - 0x33BF
bool func_102() {
	if (Global_35781 == 15) {
		return false;
	}
	return true;
}

// Position - 0x33D4
int func_103() { return 1; }

// Position - 0x33DD
bool func_104(int iParam0) { return func_105(Global_101700.f_19076, iParam0); }

// Position - 0x33F2
bool func_105(var uParam0, var uParam1) { return (uParam0 & uParam1) != 0; }

// Position - 0x3401
int func_106(char *sParam0) {
	if (gameplay::is_string_null_or_empty(sParam0)) {
		return 0;
	}
	if (gameplay::are_strings_equal(sParam0, "gpb_AndyMoon")) {
		return 1;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Baygor")) {
		return 2;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_BillBinder")) {
		return 4;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Clinton")) {
		return 8;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Griff")) {
		return 16;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Jane")) {
		return 64;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Jerome")) {
		return 128;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Jesse")) {
		return 256;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Mani")) {
		return 512;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Mime")) {
		return 1024;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_PamelaDrake")) {
		return 2048;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Superhero")) {
		return 4096;
	}
	else if (gameplay::are_strings_equal(sParam0, "gpb_Zombie")) {
		return 8192;
	}
	return 0;
}

// Position - 0x3528
void func_107(int iParam0) {
	var uVar0;

	func_110();
	if (iLocal_241) {
		MemCopy(&uVar0, {func_109()}, 4);
		if (gameplay::are_strings_equal(&uVar0, &Local_502)) {
			func_13();
		}
		if (iParam0 == 1) {
			ped::delete_ped(&iLocal_240);
		}
		else {
			entity::set_ped_as_no_longer_needed(&iLocal_240);
		}
		iLocal_241 = 0;
	}
	if (!gameplay::is_string_null_or_empty(&Local_404)) {
		streaming::remove_anim_dict(&Local_404);
	}
	if (iLocal_249 == 1) {
		if (!gameplay::is_string_null_or_empty(&cLocal_324)) {
			if (streaming::has_anim_dict_loaded(&cLocal_324)) {
				streaming::remove_anim_dict(&cLocal_324);
			}
		}
		if (!gameplay::is_string_null_or_empty(&cLocal_340)) {
			if (streaming::has_anim_dict_loaded(&cLocal_340)) {
				streaming::remove_anim_dict(&cLocal_340);
			}
		}
	}
	if (iLocal_298 != -1) {
		func_2(&iLocal_298);
	}
	if (ui::does_blip_exist(iLocal_248)) {
		func_108(&iLocal_248);
	}
	func_84();
	if (!ped::is_ped_injured(player::player_ped_id())) {
		audio::disable_ped_pain_audio(player::player_ped_id(), 0);
	}
	script::terminate_this_thread();
}

// Position - 0x35F7
void func_108(int *iParam0) {
	if (ui::does_blip_exist(*iParam0)) {
		ui::set_blip_route(*iParam0, 0);
		ui::remove_blip(iParam0);
	}
}

// Position - 0x3617
struct<6> func_109() {
	struct<6> Var0;

	StringCopy(&Var0, "NULL", 24);
	if (Global_15745 == 4) {
		return Global_15364;
	}
	return Var0;
}

//Position - 0x363B
void func_110()
{
	func_111();
}

// Position - 0x3647
void func_111() {
	if (!Global_3) {
		return;
	}
	if (entity::does_entity_exist(iLocal_448)) {
		entity::set_ped_as_no_longer_needed(&iLocal_448);
	}
}

// Position - 0x366A
void func_112() {
	if (iLocal_245 == -1) {
		iLocal_245 = pathfind::add_navmesh_blocking_object(vLocal_242, 2f, 2f, 2f, 0f, 0, 1);
	}
}

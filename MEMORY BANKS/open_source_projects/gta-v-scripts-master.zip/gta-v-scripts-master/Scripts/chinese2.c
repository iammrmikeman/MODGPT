#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
int iLocal_31 = 0;
var uLocal_32 = 0;
var uLocal_33 = 0;
float fLocal_34 = 0f;
float fLocal_35 = 0f;
float fLocal_36 = 0f;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
var uLocal_40 = 0;
var uLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int iLocal_44 = 0;
int iLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
char *sLocal_51 = NULL;
int iLocal_52 = 0;
int iLocal_53 = 0;
bool bLocal_54 = 0;
int iLocal_55 = 0;
bool bLocal_56 = 0;
int iLocal_57 = 0;
int iLocal_58 = 0;
int iLocal_59 = 0;
int iLocal_60 = 0;
int iLocal_61 = 0;
int iLocal_62 = 0;
int iLocal_63 = 0;
int iLocal_64 = 0;
int iLocal_65 = 0;
int iLocal_66 = 0;
int iLocal_67 = 0;
int iLocal_68 = 0;
int iLocal_69 = 0;
var uLocal_70 = 0;
vector3 vLocal_71 = {0f, 0f, 0f};
float fLocal_74 = 0f;
int iLocal_75 = 0;
int iLocal_76 = 0;
bool bLocal_77 = 0;
int iLocal_78[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
struct<165> Local_89 = {
	16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
char[] cLocal_254[8] = 0;
int iLocal_255 = 0;
int iLocal_256 = 0;
int iLocal_257 = 0;
bool bLocal_258 = 0;
int iLocal_259 = 0;
int iLocal_260 = 0;
bool bLocal_261 = 0;
int iLocal_262 = 0;
int iLocal_263 = 0;
int iLocal_264 = 0;
bool bLocal_265 = 0;
int iLocal_266 = 0;
int iLocal_267 = 0;
int iLocal_268 = 0;
int iLocal_269 = 0;
int iLocal_270 = 0;
int iLocal_271 = 0;
float fLocal_272 = 0f;
float fLocal_273 = 0f;
vector3 vLocal_274 = {0f, 0f, 0f};
vector3 vLocal_277 = {0f, 0f, 0f};
int iLocal_280 = 0;
struct<5> Local_281[31];
int iLocal_437 = 0;
int iLocal_438 = 0;
int iLocal_439 = 0;
int iLocal_440 = 0;
int iLocal_441 = 0;
int iLocal_442 = 0;
int iLocal_443 = 0;
struct<5> Local_444[61];
float fLocal_750 = 0f;
int iLocal_751 = 0;
vector3 vLocal_752 = {0f, 0f, 0f};
struct<33> Local_755[26];
int iLocal_1614 = 0;
int iLocal_1615 = 0;
int iLocal_1616 = 0;
int iLocal_1617 = 0;
int iLocal_1618 = 0;
struct<24> Local_1619[26];
vector3 vLocal_2244 = {0f, 0f, 0f};
vector3 vLocal_2247 = {0f, 0f, 0f};
vector3 vLocal_2250 = {0f, 0f, 0f};
vector3 vLocal_2253 = {0f, 0f, 0f};
vector3 vLocal_2256 = {0f, 0f, 0f};
vector3 vLocal_2259 = {0f, 0f, 0f};
vector3 vLocal_2262 = {0f, 0f, 0f};
vector3 vLocal_2265 = {0f, 0f, 0f};
vector3 vLocal_2268 = {0f, 0f, 0f};
vector3 vLocal_2271 = {0f, 0f, 0f};
vector3 vLocal_2274[21] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
char[] cLocal_2338[8] = 0;
bool bLocal_2339 = 0;
int iLocal_2340 = 0;
bool bLocal_2341 = 0;
int iLocal_2342 = 0;
struct<6> Local_2343[6];
struct<18> Local_2380[4];
float fLocal_2453 = 0f;
int iLocal_2454 = 0;
int iLocal_2455[4] = {0, 0, 0, 0};
int iLocal_2460[4] = {0, 0, 0, 0};
vector3 vLocal_2465[13] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						   {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
int iLocal_2505 = 0;
int iLocal_2506 = 0;
int iLocal_2507 = 0;
int iLocal_2508 = 0;
int iLocal_2509 = 0;
int iLocal_2510 = 0;
int iLocal_2511 = 0;
int iLocal_2512 = 0;
char *sLocal_2513 = NULL;
bool bLocal_2514 = 0;
struct<6> Local_2515[20];
int iLocal_2636 = 0;
int iLocal_2637 = 0;
int iLocal_2638 = 0;
float fLocal_2639 = 0f;
int iLocal_2640 = 0;
int iLocal_2641 = 0;
int iLocal_2642 = 0;
int iLocal_2643 = 0;
int iLocal_2644 = 0;
int iLocal_2645 = 0;
int iLocal_2646 = 0;
int iLocal_2647 = 0;
int iLocal_2648 = 0;
int iLocal_2649 = 0;
var *uLocal_2650 = NULL;
int iLocal_2651[5] = {0, 0, 0, 0, 0};
int iLocal_2657[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int iLocal_2668 = 0;
vector3 vLocal_2669 = {0f, 0f, 0f};
var uLocal_2672 = 0;
int iLocal_2673 = 0;
float fLocal_2674 = 0f;
var *uLocal_2675 = NULL;
int iLocal_2676 = 0;
int iLocal_2677 = 0;
int iLocal_2678 = 0;
int iLocal_2679 = 0;
int iLocal_2680 = 0;
int iLocal_2681 = 0;
int iLocal_2682 = 0;
struct<7> Local_2683 = {
	0, 3, 0, 0, 0, 0, 0
};
var uLocal_2690 = 1092616192;
var uLocal_2691 = 1101004800;
var uLocal_2692 = 0;
var uLocal_2693 = 0;
var uLocal_2694 = 0;
var uLocal_2695 = 0;
var uLocal_2696 = 0;
var uLocal_2697 = 0;
var uLocal_2698 = 0;
var uLocal_2699 = 0;
var uLocal_2700 = 3;
var uLocal_2701 = 0;
var uLocal_2702 = 0;
var uLocal_2703 = 0;
var uLocal_2704 = 0;
var uLocal_2705 = 0;
var uLocal_2706 = 0;
var uLocal_2707 = 0;
var *uLocal_2708 = NULL;
var uLocal_2709 = 0;
var uLocal_2710 = 0;
var uLocal_2711 = 0;
var uLocal_2712 = 0;
var uLocal_2713 = 0;
var uLocal_2714 = 0;
var uLocal_2715 = 0;
var uLocal_2716 = 0;
var uLocal_2717 = 0;
var uLocal_2718 = 0;
var uLocal_2719 = 0;
var uLocal_2720 = 0;
var uLocal_2721 = 0;
var uLocal_2722 = 0;
var uLocal_2723 = 0;
var uLocal_2724 = 0;
var uLocal_2725 = 0;
var uLocal_2726 = 0;
var uLocal_2727 = 0;
var uLocal_2728 = 0;
var uLocal_2729 = 0;
var uLocal_2730 = 0;
var uLocal_2731 = 0;
var uLocal_2732 = 0;
var uLocal_2733 = 0;
var uLocal_2734 = 0;
var uLocal_2735 = 0;
var uLocal_2736 = 0;
var uLocal_2737 = 0;
var uLocal_2738 = 0;
var uLocal_2739 = 0;
var uLocal_2740 = 0;
var uLocal_2741 = 0;
var uLocal_2742 = 0;
var uLocal_2743 = 0;
var uLocal_2744 = 0;
var uLocal_2745 = 0;
var uLocal_2746 = 0;
var uLocal_2747 = 0;
var uLocal_2748 = 0;
var uLocal_2749 = 0;
var uLocal_2750 = 0;
var uLocal_2751 = 0;
var uLocal_2752 = 0;
var uLocal_2753 = 0;
var uLocal_2754 = 0;
var uLocal_2755 = 0;
var uLocal_2756 = 0;
var uLocal_2757 = 0;
var uLocal_2758 = 0;
var uLocal_2759 = 0;
var uLocal_2760 = 0;
var uLocal_2761 = 0;
var uLocal_2762 = 0;
var uLocal_2763 = 0;
var uLocal_2764 = 0;
var uLocal_2765 = 0;
var uLocal_2766 = 0;
var uLocal_2767 = 0;
var uLocal_2768 = 0;
var uLocal_2769 = 0;
var uLocal_2770 = 0;
var uLocal_2771 = 0;
var uLocal_2772 = 0;
var uLocal_2773 = 0;
var uLocal_2774 = 0;
var uLocal_2775 = 0;
var uLocal_2776 = 0;
var uLocal_2777 = 0;
var uLocal_2778 = 0;
var uLocal_2779 = 0;
var uLocal_2780 = 0;
var uLocal_2781 = 0;
var uLocal_2782 = 0;
var uLocal_2783 = 0;
var uLocal_2784 = 0;
var uLocal_2785 = 0;
var uLocal_2786 = 0;
var uLocal_2787 = 0;
var uLocal_2788 = 0;
var uLocal_2789 = 0;
var uLocal_2790 = 0;
var uLocal_2791 = 0;
var uLocal_2792 = 0;
var uLocal_2793 = 0;
var uLocal_2794 = 0;
var uLocal_2795 = 0;
var uLocal_2796 = 0;
var uLocal_2797 = 0;
var uLocal_2798 = 0;
var uLocal_2799 = 0;
var uLocal_2800 = 0;
var uLocal_2801 = 0;
var uLocal_2802 = 0;
var uLocal_2803 = 0;
var uLocal_2804 = 0;
var uLocal_2805 = 0;
var uLocal_2806 = 0;
var uLocal_2807 = 0;
var uLocal_2808 = 0;
var uLocal_2809 = 0;
var uLocal_2810 = 0;
var uLocal_2811 = 0;
var uLocal_2812 = 0;
var uLocal_2813 = 0;
var uLocal_2814 = 0;
var uLocal_2815 = 0;
var uLocal_2816 = 0;
var uLocal_2817 = 0;
var uLocal_2818 = 0;
var uLocal_2819 = 0;
var uLocal_2820 = 0;
var uLocal_2821 = 0;
var uLocal_2822 = 0;
var uLocal_2823 = 0;
var uLocal_2824 = 0;
var uLocal_2825 = 0;
var uLocal_2826 = 0;
var uLocal_2827 = 0;
var uLocal_2828 = 0;
var uLocal_2829 = 0;
var uLocal_2830 = 0;
var uLocal_2831 = 0;
var uLocal_2832 = 0;
var uLocal_2833 = 0;
var uLocal_2834 = 0;
var uLocal_2835 = 0;
var uLocal_2836 = 0;
var uLocal_2837 = 0;
var uLocal_2838 = 0;
var uLocal_2839 = 0;
var uLocal_2840 = 0;
var uLocal_2841 = 0;
var uLocal_2842 = 0;
var uLocal_2843 = 0;
var uLocal_2844 = 0;
var uLocal_2845 = 0;
var uLocal_2846 = 0;
var uLocal_2847 = 0;
var uLocal_2848 = 0;
var uLocal_2849 = 0;
var uLocal_2850 = 0;
var uLocal_2851 = 0;
var uLocal_2852 = 0;
var uLocal_2853 = 0;
var uLocal_2854 = 0;
var uLocal_2855 = 0;
var uLocal_2856 = 0;
var uLocal_2857 = 0;
var uLocal_2858 = 0;
var uLocal_2859 = 0;
var uLocal_2860 = 0;
var uLocal_2861 = 0;
var uLocal_2862 = 0;
var uLocal_2863 = 0;
var uLocal_2864 = 0;
var uLocal_2865 = 0;
var uLocal_2866 = 0;
var uLocal_2867 = 0;
var uLocal_2868 = 0;
var uLocal_2869 = 0;
var uLocal_2870 = 0;
var uLocal_2871 = 0;
var uLocal_2872 = 0;
int iLocal_2873 = 0;
int iLocal_2874 = 0;
int iLocal_2875 = 0;
int iLocal_2876 = 0;
int iLocal_2877 = 0;
int iLocal_2878 = 0;
int iLocal_2879 = 0;
int iLocal_2880 = 0;
int iLocal_2881 = 0;
int iLocal_2882 = 0;
int iLocal_2883 = 0;
int iLocal_2884 = 0;
int iLocal_2885 = 0;
int iLocal_2886 = 0;
int iLocal_2887 = 0;
int iLocal_2888 = 0;
vector3 vLocal_2889[9] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f},
						  {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
struct<10> Local_2917[20];
bool bLocal_3118 = 0;
int *iLocal_3119 = NULL;
struct<8> Local_3120[27];
struct<4> Local_3337[5];
struct<7> Local_3358[17];
vector3 vLocal_3478[4] = {{0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}, {0f, 0f, 0f}};
int iLocal_3491 = 0;
vector3 vLocal_3492[24] = "";
var uLocal_3495 = 0;
var uLocal_3496 = 0;
var uLocal_3497 = 0;
vector3 vLocal_3498 = {0f, 0f, 0f};
var uLocal_3501 = 0;
var uLocal_3502 = 0;
var uLocal_3503 = 0;
int iLocal_3504 = 0;
int iLocal_3505 = 0;
int iLocal_3506 = 0;
int iLocal_3507 = 0;
int iLocal_3508 = 0;
char *sLocal_3509 = NULL;
char *sLocal_3510 = NULL;
int iLocal_3511[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
var *uLocal_3522 = NULL;
var uLocal_3523 = 0;
var uLocal_3524 = 0;
var uLocal_3525 = 0;
var uLocal_3526 = 0;
var uLocal_3527 = 0;
var uLocal_3528 = 0;
var uLocal_3529 = 0;
var uLocal_3530 = 0;
var uLocal_3531 = 0;
var uLocal_3532 = 0;
var uLocal_3533 = 0;
var uLocal_3534 = 0;
var uLocal_3535 = 0;
var uLocal_3536 = 0;
var uLocal_3537 = 0;
var uLocal_3538 = 0;
var uLocal_3539 = 0;
var uLocal_3540 = 0;
var uLocal_3541 = 0;
var uLocal_3542 = 0;
var uLocal_3543 = 0;
var uLocal_3544 = 0;
var uLocal_3545 = 0;
var uLocal_3546 = 0;
var uLocal_3547 = 0;
var uLocal_3548 = 0;
var uLocal_3549 = 0;
var uLocal_3550 = 0;
var uLocal_3551 = 0;
var uLocal_3552 = 0;
var uLocal_3553 = 0;
var uLocal_3554 = 0;
var uLocal_3555 = 0;
var uLocal_3556 = 0;
var uLocal_3557 = 0;
var uLocal_3558 = 0;
var uLocal_3559 = 0;
var uLocal_3560 = 0;
var uLocal_3561 = 0;
var uLocal_3562 = 0;
var uLocal_3563 = 0;
var uLocal_3564 = 0;
var uLocal_3565 = 0;
var uLocal_3566 = 0;
var uLocal_3567 = 0;
var uLocal_3568 = 0;
var uLocal_3569 = 0;
var uLocal_3570 = 0;
var uLocal_3571 = 0;
var uLocal_3572 = 0;
var uLocal_3573 = 0;
var uLocal_3574 = 0;
var uLocal_3575 = 0;
var uLocal_3576 = 0;
var uLocal_3577 = 0;
var uLocal_3578 = 0;
var uLocal_3579 = 0;
var uLocal_3580 = 0;
var uLocal_3581 = 0;
var uLocal_3582 = 0;
var uLocal_3583 = 0;
var uLocal_3584 = 0;
var uLocal_3585 = 0;
var uLocal_3586 = 0;
var uLocal_3587 = 0;
var uLocal_3588 = 0;
var uLocal_3589 = 0;
var uLocal_3590 = 0;
var uLocal_3591 = 0;
var uLocal_3592 = 0;
var uLocal_3593 = 0;
var uLocal_3594 = 0;
var uLocal_3595 = 0;
var uLocal_3596 = 0;
var uLocal_3597 = 0;
var uLocal_3598 = 0;
var uLocal_3599 = 0;
var uLocal_3600 = 0;
var uLocal_3601 = 0;
var uLocal_3602 = 0;
var uLocal_3603 = 0;
var uLocal_3604 = 0;
var uLocal_3605 = 0;
var uLocal_3606 = 0;
var uLocal_3607 = 0;
var uLocal_3608 = 0;
var uLocal_3609 = 0;
var uLocal_3610 = 0;
var uLocal_3611 = 0;
var uLocal_3612 = 0;
var uLocal_3613 = 0;
var uLocal_3614 = 0;
var uLocal_3615 = 0;
var uLocal_3616 = 0;
var uLocal_3617 = 0;
var uLocal_3618 = 0;
var uLocal_3619 = 0;
var uLocal_3620 = 0;
var uLocal_3621 = 0;
var uLocal_3622 = 0;
var uLocal_3623 = 0;
var uLocal_3624 = 0;
var uLocal_3625 = 0;
var uLocal_3626 = 0;
var uLocal_3627 = 0;
var uLocal_3628 = 0;
var uLocal_3629 = 0;
var uLocal_3630 = 0;
var uLocal_3631 = 0;
var uLocal_3632 = 0;
var uLocal_3633 = 0;
var uLocal_3634 = 0;
var uLocal_3635 = 0;
var uLocal_3636 = 0;
var uLocal_3637 = 0;
var uLocal_3638 = 0;
var uLocal_3639 = 0;
var uLocal_3640 = 0;
var uLocal_3641 = 0;
var uLocal_3642 = 0;
var uLocal_3643 = 0;
var uLocal_3644 = 0;
var uLocal_3645 = 0;
var uLocal_3646 = 0;
var uLocal_3647 = 0;
var uLocal_3648 = 0;
var uLocal_3649 = 0;
var uLocal_3650 = 0;
var uLocal_3651 = 0;
var uLocal_3652 = 0;
var uLocal_3653 = 0;
var uLocal_3654 = 0;
var uLocal_3655 = 0;
var uLocal_3656 = 0;
var uLocal_3657 = 0;
var uLocal_3658 = 0;
var uLocal_3659 = 0;
var uLocal_3660 = 0;
var uLocal_3661 = 0;
var uLocal_3662 = 0;
var uLocal_3663 = 0;
var uLocal_3664 = 0;
var uLocal_3665 = 0;
var uLocal_3666 = 0;
var uLocal_3667 = 0;
var uLocal_3668 = 0;
var uLocal_3669 = 0;
var uLocal_3670 = 0;
var uLocal_3671 = 0;
var uLocal_3672 = 0;
var uLocal_3673 = 0;
var uLocal_3674 = 0;
var uLocal_3675 = 0;
var uLocal_3676 = 0;
var uLocal_3677 = 0;
var uLocal_3678 = 0;
var uLocal_3679 = 0;
var uLocal_3680 = 0;
var uLocal_3681 = 0;
var uLocal_3682 = 0;
var uLocal_3683 = 0;
var uLocal_3684 = 0;
var uLocal_3685 = 0;
var uLocal_3686 = 0;
int iLocal_3687 = 0;
int iLocal_3688 = 0;
int iLocal_3689 = 0;
int iLocal_3690 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	iLocal_31 = 3;
	fLocal_34 = 80f;
	fLocal_35 = 140f;
	fLocal_36 = 180f;
	iLocal_42 = 1;
	iLocal_43 = 65;
	iLocal_44 = 49;
	iLocal_45 = 64;
	uLocal_49 = ui::_0x4A9923385BDB9DAD();
	uLocal_50 = ui::_get_blip_info_id_iterator();
	iLocal_61 = -1;
	iLocal_62 = -1;
	bLocal_77 = true;
	iLocal_266 = -1;
	iLocal_269 = -1;
	fLocal_272 = 0.5f;
	fLocal_273 = 0f;
	iLocal_438 = 1;
	fLocal_750 = 160f;
	cLocal_2338 = "CHI2AUD";
	iLocal_2676 = -1;
	iLocal_2884 = -1;
	gameplay::set_mission_flag(1);
	if (player::has_force_cleanup_occurred(3)) {
		func_414();
		func_413(2);
	}
	fLocal_750 = 160f;
	while (true) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			func_129();
			func_127();
			if (iLocal_2511 >= 7) {
				func_119();
			}
			func_117();
			func_78();
			func_3();
			func_2();
			func_1();
			unk1::_0x208784099002BC30("m_Chinese2", 0);
		}
		iLocal_3687 = 0;
		system::wait(0);
	}
}

// Position - 0x11D
void func_1() {
	if (iLocal_3505) {
		if (interior::is_interior_ready(iLocal_3504)) {
			interior::_load_interior(iLocal_3504);
			iLocal_3505 = 0;
		}
	}
}

// Position - 0x140
int func_2() {
	if (iLocal_3506) {
		if (iLocal_3507) {
			if (audio::prepare_music_event(sLocal_3509)) {
				if (audio::trigger_music_event(sLocal_3509)) {
					iLocal_3506 = 0;
					iLocal_3507 = 0;
					return 1;
				}
			}
		}
		else if (audio::trigger_music_event(sLocal_3509)) {
			iLocal_3506 = 0;
			return 1;
		}
	}
	else if (iLocal_3508) {
		if (audio::prepare_music_event(sLocal_3510)) {
			iLocal_3508 = 0;
		}
	}
	return 0;
}

// Position - 0x1A1
void func_3() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 1) {
			switch (Local_2515[iVar0 /*6*/]) {
			case 0:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					if (cutscene::is_cutscene_playing()) {
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 1:
					func_69(1992.804f, 3053.31f, 45.77715f, 1989.681f, 3055.295f, 49.09001f, 3.25f, 1995.202f,
							3062.156f, 46.0491f, 59.7235f, 10f, 20f, 9f, 1, 1, 1, 0, 0);
					func_69(1994.427f, 3045.136f, 45.34013f, 1981.903f, 3053.235f, 49.79153f, 9.5f, 1995.202f,
							3062.156f, 46.0491f, 59.7235f, 10f, 20f, 9f, 1, 1, 1, 0, 0);
					func_69(1985.404f, 3075.057f, 44.84953f, 2017.102f, 3057.435f, 53.71896f, 33f, 1995.202f, 3062.156f,
							46.0491f, 59.7235f, 10f, 20f, 9f, 1, 1, 1, 0, 0);
					iLocal_2506 = player::get_players_last_vehicle();
					if (func_68(iLocal_2506) && func_67(iLocal_2506, 1995.202f, 3062.156f, 46.0491f, 1) < 5f) {
						vehicle::request_vehicle_asset(entity::get_entity_model(iLocal_2506), 3);
					}
					Local_2515[iVar0 /*6*/].f_1 = 0;
					break;
				}
				break;

			case 2:
				if (iLocal_2511 >= 3) {
					Local_2515[iVar0 /*6*/].f_2 = -1;
				}
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -1:
					func_66();
					func_64();
					break;

				case 0:
					if (func_67(player::player_ped_id(), 2442.55f, 4967.51f, 54.35f, 1) < 1300f || func_63(39)) {
						if (func_67(player::player_ped_id(), 2442.55f, 4967.51f, 54.35f, 1) > 500f) {
							Local_2515[iVar0 /*6*/].f_2++;
						}
					}
					break;

				case 1:
					if (func_60("PHN2", 1, player::player_ped_id(), "Trevor", 8, 0, "ONEIL", -1, 0, 0)) {
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 2:
					if (!func_59()) {
						if (func_35("CHI2_ONEILPH", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0, -1, 0, 0,
									8)) {
							Local_2515[iVar0 /*6*/].f_1 = 0;
						}
					}
					break;
				}
				break;

			case 3:
				if (iLocal_2511 >= 3) {
					Local_2515[iVar0 /*6*/].f_2 = -1;
					Local_2515[iVar0 /*6*/].f_1 = 0;
				}
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					if (func_35("CHI2_boom", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
						Local_2515[iVar0 /*6*/].f_2++;
					}
					iLocal_2888 = 0;
					Local_2515[iVar0 /*6*/].f_5 = gameplay::get_game_timer() + 3000;
					break;

				case 1:
					if (!func_59()) {
						if (!func_34()) {
							if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
								if (gameplay::get_game_timer() > Local_2515[iVar0 /*6*/].f_5) {
									if (iLocal_2888 < 13) {
										if (func_35("DRI1", 2, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0,
													-1, 0, 0, 8)) {
											iLocal_2888++;
											Local_2515[iVar0 /*6*/].f_5 =
												gameplay::get_game_timer() +
												gameplay::get_random_int_in_range(4000, 10000);
										}
									}
									else {
										Local_2515[iVar0 /*6*/].f_1 = 0;
									}
								}
							}
						}
					}
					break;
				}
				break;

			case 4:
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					iVar1 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
					if (!entity::is_entity_in_air(iVar1)) {
						if (func_33(6f, 2)) {
							ai::task_leave_any_vehicle(player::player_ped_id(), 0, 0);
							Local_2515[iVar0 /*6*/].f_1 = 0;
						}
					}
				}
				else {
					Local_2515[iVar0 /*6*/].f_1 = 0;
				}
				break;

			case 5:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -20:
					if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
															  2460.073f, 4964.176f, 46.2405f, 1) < 250f) {
						streaming::request_model(joaat("a_m_m_hillbilly_01"));
						streaming::request_model(-1853453107);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case -19:
					if (streaming::has_model_loaded(joaat("a_m_m_hillbilly_01")) &&
						streaming::has_model_loaded(-1853453107)) {
						streaming::request_model(joaat("a_m_m_hillbilly_02"));
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case -18:
					if (streaming::has_model_loaded(joaat("a_m_m_hillbilly_02"))) {
						streaming::request_model(joaat("burrito"));
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case -17:
					if (streaming::has_model_loaded(joaat("burrito"))) {
						streaming::request_model(joaat("a_m_y_methhead_01"));
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case -16:
					if (streaming::has_model_loaded(joaat("a_m_y_methhead_01"))) {
						streaming::request_model(joaat("prop_ld_can_01"));
						streaming::request_model(joaat("prop_cs_fertilizer"));
						streaming::request_model(joaat("prop_cs_beer_bot_01"));
						streaming::request_model(joaat("prop_phone_ing"));
						streaming::request_model(joaat("dubsta"));
						streaming::request_anim_dict("misschinese2_bank5");
						streaming::request_anim_dict("misschinese2_bank1");
						streaming::request_anim_dict("reaction@male_stand@big_variations@b");
						streaming::request_anim_dict("reaction@male_stand@big_intro@left");
						streaming::request_anim_dict("reaction@male_stand@big_intro@right");
						streaming::request_anim_dict("reaction@male_stand@big_intro@backward");
						streaming::request_anim_dict("misschinese2_barrelRoll");
						streaming::request_anim_set("move_m@gangster@var_e");
						streaming::request_anim_set("move_m@gangster@var_f");
						streaming::request_anim_set("move_m@gangster@generic");
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case -15:
					if (streaming::has_model_loaded(joaat("dubsta"))) {
						func_32(22, 0);
						func_32(8, 0);
						pathfind::set_roads_in_area(Vector(44.8113f, 4961.045f, 2469.985f) - Vector(100f, 100f, 100f),
													Vector(44.8113f, 4961.045f, 2469.985f) + Vector(100f, 100f, 100f),
													0, 1);
						Local_2515[iVar0 /*6*/].f_2 = 1;
					}
					break;

				case 0:
					if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
															  2460.073f, 4964.176f, 46.2405f, 1) < 250f) {
						streaming::request_model(joaat("a_m_m_hillbilly_01"));
						streaming::request_model(joaat("a_m_m_hillbilly_02"));
						streaming::request_model(joaat("a_m_y_methhead_01"));
						streaming::request_model(joaat("prop_ld_can_01"));
						streaming::request_model(joaat("prop_cs_fertilizer"));
						streaming::request_model(joaat("burrito"));
						streaming::request_model(joaat("prop_cs_beer_bot_01"));
						if (iLocal_2511 <= 3) {
							streaming::request_model(joaat("prop_phone_ing"));
							streaming::request_model(joaat("dubsta"));
						}
						streaming::request_anim_dict("misschinese2_bank5");
						streaming::request_anim_dict("misschinese2_bank1");
						streaming::request_anim_dict("reaction@male_stand@big_variations@b");
						streaming::request_anim_dict("reaction@male_stand@big_intro@left");
						streaming::request_anim_dict("reaction@male_stand@big_intro@right");
						streaming::request_anim_dict("reaction@male_stand@big_intro@backward");
						streaming::request_anim_dict("misschinese2_barrelRoll");
						streaming::request_anim_set("move_m@gangster@var_e");
						streaming::request_anim_set("move_m@gangster@var_f");
						streaming::request_anim_set("move_m@gangster@generic");
						func_32(22, 0);
						func_32(8, 0);
						pathfind::set_roads_in_area(Vector(44.8113f, 4961.045f, 2469.985f) - Vector(100f, 100f, 100f),
													Vector(44.8113f, 4961.045f, 2469.985f) + Vector(100f, 100f, 100f),
													0, 1);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 1:
					if (streaming::has_model_loaded(joaat("a_m_m_hillbilly_01")) &&
						streaming::has_model_loaded(joaat("a_m_m_hillbilly_02")) &&
						streaming::has_model_loaded(joaat("a_m_y_methhead_01")) &&
						streaming::has_model_loaded(joaat("burrito")) &&
						streaming::has_model_loaded(joaat("prop_cs_fertilizer")) &&
						streaming::has_model_loaded(joaat("prop_cs_beer_bot_01")) &&
						streaming::has_model_loaded(joaat("prop_ld_can_01")) &&
						streaming::has_anim_dict_loaded("misschinese2_bank5") &&
						streaming::has_anim_dict_loaded("misschinese2_bank1") &&
						streaming::has_anim_dict_loaded("misschinese2_barrelRoll") &&
						streaming::has_anim_dict_loaded("reaction@male_stand@big_variations@b") &&
						streaming::has_anim_dict_loaded("reaction@male_stand@big_intro@left") &&
						streaming::has_anim_dict_loaded("reaction@male_stand@big_intro@right") &&
						streaming::has_anim_dict_loaded("reaction@male_stand@big_intro@backward") &&
						(iLocal_2511 <= 3 && streaming::has_model_loaded(joaat("prop_phone_ing")) || iLocal_2511 > 3) &&
						(iLocal_2511 <= 3 && streaming::has_model_loaded(joaat("dubsta")) || iLocal_2511 > 3)) {
						Local_2515[iVar0 /*6*/].f_2 = 4;
					}
					if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
															  2460.073f, 4964.176f, 46.2405f, 1) > 300f) {
						streaming::set_model_as_no_longer_needed(joaat("a_m_m_hillbilly_01"));
						streaming::set_model_as_no_longer_needed(joaat("a_m_m_hillbilly_02"));
						streaming::set_model_as_no_longer_needed(joaat("a_m_y_methhead_01"));
						streaming::set_model_as_no_longer_needed(joaat("burrito"));
						streaming::set_model_as_no_longer_needed(joaat("prop_cs_fertilizer"));
						streaming::set_model_as_no_longer_needed(joaat("prop_cs_beer_bot_01"));
						streaming::set_model_as_no_longer_needed(joaat("prop_ld_can_01"));
						streaming::remove_anim_dict("misschinese2_bank5");
						streaming::remove_anim_dict("misschinese2_bank1");
						streaming::remove_anim_dict("reaction@male_stand@big_variations@b");
						streaming::remove_anim_dict("reaction@male_stand@big_intro@left");
						streaming::remove_anim_dict("reaction@male_stand@big_intro@right");
						streaming::remove_anim_dict("reaction@male_stand@big_intro@backward");
						streaming::remove_anim_dict("misschinese2_barrelRoll");
						streaming::remove_anim_set("move_m@gangster@var_e");
						streaming::remove_anim_set("move_m@gangster@var_f");
						streaming::remove_anim_set("move_m@gangster@generic");
						streaming::set_model_as_no_longer_needed(joaat("prop_phone_ing"));
						streaming::set_model_as_no_longer_needed(joaat("dubsta"));
						pathfind::set_roads_in_area(Vector(44.8113f, 4961.045f, 2469.985f) - Vector(100f, 100f, 100f),
													Vector(44.8113f, 4961.045f, 2469.985f) + Vector(100f, 100f, 100f),
													1, 1);
						func_31(22, 1);
						func_31(8, 1);
						if (iLocal_2678 != 0) {
							interior::unpin_interior(iLocal_2678);
							iLocal_2678 = 0;
						}
						Local_2515[iVar0 /*6*/].f_2 = -20;
					}
					break;

				case 4:
					if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
															  2460.073f, 4964.176f, 46.2405f, 1) > 300f) {
						Local_2515[iVar0 /*6*/].f_2 = 1;
					}
					else if (iLocal_2511 >= 3 && !func_30(22)) {
						func_27();
						Local_2515[iVar0 /*6*/].f_1 = 0;
					}
					break;

				case 5: break;
				}
				break;

			case 22:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -1:
					if (iLocal_2678 != 0) {
						interior::unpin_interior(iLocal_2678);
					}
					iLocal_2678 = 0;
					break;

				case 0:
					iLocal_2678 = interior::get_interior_at_coords(2440.492f, 4969.948f, 52.5247f);
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1:
					if (!interior::is_valid_interior(iLocal_2678)) {
						iLocal_2678 = interior::get_interior_at_coords(2440.492f, 4969.948f, 52.5247f);
					}
					else {
						interior::_load_interior(iLocal_2678);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 2: Local_2515[iVar0 /*6*/].f_1 = 0; break;
				}
				break;

			case 6:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					func_19(50, 0, 0, 1, 0);
					func_19(51, 0, 0, 1, 0);
					func_19(52, 0, 0, 1, 0);
					func_19(53, 0, 0, 1, 0);
					func_19(54, 1, 0, 1, 0);
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1: break;
				}
				break;

			case 7:
				if (Local_2515[iVar0 /*6*/].f_2 == 0) {
					iVar2 = func_18(8);
					if (iVar2 != -1) {
						if (!ped::is_ped_injured(Local_755[iVar2 /*33*/])) {
							if (ai::get_script_task_status(Local_755[iVar2 /*33*/], 1785177548) == 7) {
								iVar2 = func_18(9);
								if (iVar2 != -1) {
									if (!ped::is_ped_injured(Local_755[iVar2 /*33*/])) {
										if (ai::get_script_task_status(Local_755[iVar2 /*33*/], 1785177548) == 7) {
											streaming::remove_anim_dict("misschinese2_bank5");
											Local_2515[iVar0 /*6*/].f_1 = 0;
										}
									}
								}
							}
						}
						else {
							iVar2 = func_18(9);
							if (iVar2 != -1) {
								if (!ped::is_ped_injured(Local_755[iVar2 /*33*/])) {
									if (ai::get_script_task_status(Local_755[iVar2 /*33*/], 1785177548) == 7) {
										streaming::remove_anim_dict("misschinese2_bank5");
										Local_2515[iVar0 /*6*/].f_1 = 0;
									}
								}
								else {
									streaming::remove_anim_dict("misschinese2_bank5");
								}
							}
						}
					}
				}
				break;

			case 8:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -1: ped::remove_scenario_blocking_areas(); break;

				case 0:
					ped::add_scenario_blocking_area(Vector(58.6179f, 4972.897f, 2445.654f) - Vector(100f, 100f, 100f),
													Vector(58.6179f, 4972.897f, 2445.654f) + Vector(100f, 100f, 100f),
													0, 1, 1, 1);
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1:
					if (!ped::is_ped_injured(player::player_ped_id())) {
						if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 0),
																  2473.061f, 4981.482f, 24.64584f, 1) < 250f) {
							Local_2515[iVar0 /*6*/].f_2++;
						}
					}
					break;

				case 2:
					ped::set_ped_density_multiplier_this_frame(0f);
					vehicle::set_vehicle_density_multiplier_this_frame(0f);
					ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
					if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 0),
															  2473.061f, 4981.482f, 24.64584f, 1) > 250f) {
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;
				}
				break;

			case 9:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -1:
					gameplay::enable_dispatch_service(3, 1);
					gameplay::enable_dispatch_service(5, 1);
					gameplay::enable_dispatch_service(1, 1);
					gameplay::enable_dispatch_service(7, 1);
					break;

				case 0:
					if (func_67(player::player_ped_id(), 2578.523f, 4982.284f, 51.4416f, 1) < 500f) {
						gameplay::enable_dispatch_service(3, 0);
						gameplay::enable_dispatch_service(5, 0);
						gameplay::enable_dispatch_service(1, 0);
						gameplay::enable_dispatch_service(7, 0);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 1:
					if (func_67(player::player_ped_id(), 2578.523f, 4982.284f, 51.4416f, 1) > 500f) {
						gameplay::enable_dispatch_service(3, 1);
						gameplay::enable_dispatch_service(5, 1);
						gameplay::enable_dispatch_service(1, 1);
						gameplay::enable_dispatch_service(7, 1);
						Local_2515[iVar0 /*6*/].f_2 = 0;
					}
					break;
				}
				break;

			case 25:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					func_17(player::player_ped_id(), 149);
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1:
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						iVar3 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						func_17(iVar3, 152);
						func_16(iVar3, -1);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 2:
					if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						func_17(0, 152);
						func_16(0, -1);
						Local_2515[iVar0 /*6*/].f_2 = 1;
					}
					break;
				}
				break;

			case 10: break;

			case 11: break;

			case 14:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					Local_2515[iVar0 /*6*/].f_5 = gameplay::get_game_timer() + 7000;
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1:
					if (gameplay::get_game_timer() > Local_2515[iVar0 /*6*/].f_5) {
						entity::set_entity_coords(player::player_ped_id(), 2466.385f, 4953.096f, 44.1228f, 1, 0, 0, 1);
						entity::set_entity_heading(player::player_ped_id(), 221f);
						ai::task_go_straight_to_coord(player::player_ped_id(), 2475.075f, 4945.965f, 44.0228f, 1f,
													  20000, 1193033728, 1056964608);
						ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 0, 0);
						Local_2515[iVar0 /*6*/].f_1 = 0;
					}
					break;
				}
				break;

			case 13:
				if (audio::load_stream("CHINESE2_FARMHOUSE_EXPLOSION_MOLOTOV_MASTER", 0)) {
					audio::play_stream_frontend();
					Local_2515[iVar0 /*6*/].f_1 = 0;
				}
				break;

			case 12:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 0:
					uLocal_2672 = object::_get_des_object(2457.15f, 4968.79f, 48.677f, 45f, "DES_FarmHs");
					if (object::_does_des_object_exist(uLocal_2672)) {
						object::_set_des_object_state(uLocal_2672, 2);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 1:
					if (object::_get_des_object_state(uLocal_2672) == 3) {
						object::_set_des_object_state(uLocal_2672, 4);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 2:
					if (iLocal_2673 == 1) {
						if (object::_get_des_object_state(uLocal_2672) == 5) {
							object::_set_des_object_state(uLocal_2672, 6);
							audio::start_audio_scene("CHI_2_RAYFIRE");
							entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 965837842, 1);
							entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 247384786, 1);
							entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, -247908770, 0);
							Local_2515[iVar0 /*6*/].f_2++;
						}
					}
					break;

				case 3:
					func_15("CHN2_EXPLODE", 1, "CHN2_EXPLODE");
					Local_2515[iVar0 /*6*/].f_1 = 0;
					break;
				}
				break;

			case 16:
				if (Local_2515[iVar0 /*6*/].f_2 != -1) {
					if (!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0) ||
						!object::does_pickup_exist(uLocal_2675)) {
						iLocal_2679 = object::get_closest_object_of_type(
							entity::get_entity_coords(player::player_ped_id(), 1), 20f,
							weapon::get_weapontype_model(joaat("weapon_petrolcan")), 0, 0, 1);
						if (iLocal_2679 != 0) {
							if (ui::does_blip_exist(iLocal_2677)) {
								ui::remove_blip(&iLocal_2677);
							}
							iLocal_2677 = func_13(iLocal_2679);
							func_12(1);
							func_11(0, 157);
						}
					}
					else {
						Local_2515[iVar0 /*6*/].f_5 = 0;
						func_12(0);
						if (ui::does_blip_exist(iLocal_2677)) {
							ui::remove_blip(&iLocal_2677);
						}
						func_10(157, 0);
						if (iLocal_2649 == 0) {
							iLocal_2649 =
								weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_petrolcan"));
						}
						else {
							func_9(158,
								   iLocal_2649 - weapon::get_ammo_in_ped_weapon(player::player_ped_id(),
																				joaat("weapon_petrolcan")),
								   1);
						}
					}
					if (func_8()) {
						func_11(0, 157);
						Local_2515[iVar0 /*6*/].f_1 = 0;
						func_32(17, 0);
					}
				}
				break;

			case 18: break;

			case 17:
				if (entity::is_entity_in_angled_area(player::player_ped_id(), 2447.671f, 4951.438f, 43.25576f,
													 2454.664f, 4957.856f, 47.89117f, 6.8125f, 0, 1, 0) &&
					gameplay::get_game_timer() > Local_2515[iVar0 /*6*/].f_5) {
					if (ui::does_blip_exist(iLocal_2677)) {
						ui::remove_blip(&iLocal_2677);
					}
					Local_2515[iVar0 /*6*/].f_1 = 0;
				}
				else {
					switch (Local_2515[iVar0 /*6*/].f_2) {
					case 0:
						if (!func_59()) {
							func_7("FRMSHP", 7500, 1);
							Local_2515[iVar0 /*6*/].f_5 = gameplay::get_game_timer() + 2000;
							iLocal_2677 = func_5(2450f, 4954f, 45f, 0);
							Local_2515[iVar0 /*6*/].f_2++;
						}
						break;
					}
				}
				break;

			case 20:
				if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 0)) {
					iLocal_2885 = func_18(4);
					if (iLocal_2885 != -1) {
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 0);
					}
				}
				else if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 1)) {
					if (!ped::is_ped_injured(Local_755[iLocal_2885 /*33*/]) &&
						entity::does_entity_exist(Local_755[iLocal_2885 /*33*/].f_20)) {
						if (entity::is_entity_playing_anim(Local_755[iLocal_2885 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_B", 3) &&
							entity::is_entity_attached(Local_755[iLocal_2885 /*33*/].f_20)) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 1);
						}
					}
				}
				else if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 2)) {
					if (ped::is_ped_injured(Local_755[iLocal_2885 /*33*/])) {
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 2);
					}
					if (!ped::is_ped_injured(Local_755[iLocal_2885 /*33*/])) {
						if (!entity::is_entity_playing_anim(Local_755[iLocal_2885 /*33*/], "misschinese2_barrelroll",
															"barrel_roll_loop_B", 3)) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 2);
						}
						if (ai::get_script_task_status(Local_755[iLocal_2885 /*33*/], -2017877118) == 2 ||
							ai::get_script_task_status(Local_755[iLocal_2885 /*33*/], -2017877118) == 7) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 2);
						}
						if (ped::is_ped_in_combat(Local_755[iLocal_2885 /*33*/], player::player_ped_id()) ||
							Local_1619[iLocal_2885 /*24*/].f_3 > 3) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 2);
						}
					}
				}
				else if (entity::does_entity_exist(Local_755[iLocal_2885 /*33*/].f_20) &&
						 entity::is_entity_attached(Local_755[iLocal_2885 /*33*/].f_20)) {
					entity::detach_entity(Local_755[iLocal_2885 /*33*/].f_20, 0, 0);
				}
				if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 4)) {
					iLocal_2886 = func_18(5);
					if (iLocal_2886 != -1) {
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 4);
					}
				}
				else if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 5)) {
					if (!ped::is_ped_injured(Local_755[iLocal_2886 /*33*/])) {
						if (entity::does_entity_exist(Local_755[iLocal_2886 /*33*/].f_20)) {
							if (entity::is_entity_playing_anim(Local_755[iLocal_2886 /*33*/], "misschinese2_barrelroll",
															   "barrel_roll_loop_A", 3)) {
								if (entity::is_entity_attached(Local_755[iLocal_2886 /*33*/].f_20)) {
									gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 5);
								}
							}
						}
					}
				}
				else if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 6)) {
					if (ped::is_ped_injured(Local_755[iLocal_2886 /*33*/])) {
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 6);
					}
					if (!ped::is_ped_injured(Local_755[iLocal_2886 /*33*/])) {
						if (!entity::is_entity_playing_anim(Local_755[iLocal_2886 /*33*/], "misschinese2_barrelroll",
															"barrel_roll_loop_A", 3)) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 6);
						}
						if (ai::get_script_task_status(Local_755[iLocal_2886 /*33*/], -2017877118) == 2 ||
							ai::get_script_task_status(Local_755[iLocal_2886 /*33*/], -2017877118) == 7) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 6);
						}
						if (ped::is_ped_in_combat(Local_755[iLocal_2886 /*33*/], player::player_ped_id()) ||
							Local_1619[iLocal_2886 /*24*/].f_3 > 3) {
							gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 6);
						}
					}
				}
				else if (entity::does_entity_exist(Local_755[iLocal_2886 /*33*/].f_20) &&
						 entity::is_entity_attached(Local_755[iLocal_2886 /*33*/].f_20)) {
					entity::detach_entity(Local_755[iLocal_2886 /*33*/].f_20, 0, 0);
				}
				break;

			case 21: break;

			case 23:
				iVar4 = 0;
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case 1:
					iLocal_2657[0] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.496f, 4970.916f,
																	 44.5112f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[0], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[1] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.863f, 4970.595f,
																	 44.5425f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[1], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[2] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.896f, 4970.417f,
																	 44.5475f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[2], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[3] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.795f, 4970.246f,
																	 44.5525f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[3], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[4] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.204f, 4970.269f,
																	 44.5201f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[4], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[5] =
						object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.372f, 4970.744f, 44.51f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[5], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[6] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.372f, 4971.092f,
																	 44.4987f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[6], -3.44f, 0f, 38.88f, 2, 1);
					iLocal_2657[7] =
						object::create_object_no_offset(joaat("prop_ld_can_01"), 2493.77f, 4971f, 44.6287f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[7], 3.955f, 0f, 139.68f, 2, 1);
					iLocal_2657[8] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2493.98f, 4971.279f,
																	 44.6038f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[8], 3.955f, 0f, 139.68f, 2, 1);
					iLocal_2657[9] = object::create_object_no_offset(joaat("prop_ld_can_01"), 2494.104f, 4971.438f,
																	 44.5826f, 1, 1, 0);
					entity::set_entity_rotation(iLocal_2657[9], 3.955f, 0f, 139.68f, 2, 1);
					iVar4 = 0;
					while (iVar4 < iLocal_2657) {
						entity::set_entity_dynamic(iLocal_2657[iVar4], 1);
						entity::freeze_entity_position(iLocal_2657[iVar4], 1);
						iVar4++;
					}
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 0:
					if (!entity::does_entity_exist(iLocal_2680) && !entity::does_entity_exist(iLocal_2681)) {
						if (object::does_object_of_type_exist_at_coords(2493.5f, 4969.2f, 43.9f, 1f, -921781850, 0) &&
							object::does_object_of_type_exist_at_coords(2493.4f, 4971.8f, 43.6f, 1f, -1853453107, 0)) {
							iLocal_2680 =
								object::get_closest_object_of_type(2493.5f, 4969.2f, 43.9f, 1f, -921781850, 1, 0, 1);
							entity::freeze_entity_position(iLocal_2680, 1);
							entity::create_model_hide(2493.4f, 4971.8f, 43.6f, 1f, -1853453107, 0);
							iLocal_2681 = object::create_object(-1853453107, 2493.427f, 4971.729f, 43.54362f, 1, 1, 0);
							entity::set_entity_rotation(iLocal_2681, -1.436373f, 0.176147f, -36.6601f, 2, 1);
							entity::freeze_entity_position(iLocal_2681, 1);
							func_32(24, 0);
							Local_2515[iVar0 /*6*/].f_2++;
						}
					}
					else {
						object::delete_object(&iLocal_2681);
						iLocal_2681 = object::create_object(-1853453107, 2493.427f, 4971.729f, 43.54362f, 1, 1, 0);
						entity::set_entity_rotation(iLocal_2681, -1.436373f, 0.176147f, -36.6601f, 2, 1);
						entity::freeze_entity_position(iLocal_2681, 1);
						func_32(24, 0);
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 2:
					iVar4 = 0;
					iVar4 = 0;
					while (iVar4 < iLocal_2657) {
						if (entity::does_entity_exist(iLocal_2657[iVar4])) {
							entity::freeze_entity_position(iLocal_2657[iVar4], 0);
						}
						iVar4++;
					}
					Local_2515[iVar0 /*6*/].f_1 = 0;
					Local_2515[iVar0 /*6*/].f_1 = 0;
					break;
				}
				break;

			case 24:
				if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 0)) {
					if (entity::does_entity_exist(iLocal_2680)) {
						if (!ped::is_ped_injured(player::player_ped_id())) {
							if (entity::has_entity_been_damaged_by_entity(iLocal_2680, player::player_ped_id(), 1) ||
								func_4(player::player_ped_id(), iLocal_2680, 1) < 30f) {
								entity::freeze_entity_position(iLocal_2680, 0);
								gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 0);
							}
						}
					}
				}
				if (!gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 1)) {
					if (entity::does_entity_exist(iLocal_2681)) {
						if (!ped::is_ped_injured(player::player_ped_id())) {
							if (entity::has_entity_been_damaged_by_entity(iLocal_2681, player::player_ped_id(), 1) ||
								func_4(player::player_ped_id(), iLocal_2681, 1) < 30f) {
								entity::freeze_entity_position(iLocal_2681, 0);
								gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 1);
							}
						}
					}
				}
				if (gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 0) &&
						gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 1) ||
					iLocal_2511 == 6) {
					if (entity::does_entity_exist(iLocal_2680)) {
						entity::freeze_entity_position(iLocal_2680, 0);
					}
					if (entity::does_entity_exist(iLocal_2681)) {
						entity::freeze_entity_position(iLocal_2681, 0);
					}
					Local_2515[iVar0 /*6*/].f_1 = 0;
				}
				break;

			case 26:
				switch (Local_2515[iVar0 /*6*/].f_2) {
				case -1:
					if (entity::does_entity_exist(Local_755[12 /*33*/])) {
						ped::delete_ped(&Local_755[12 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[13 /*33*/])) {
						ped::delete_ped(&Local_755[13 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[14 /*33*/])) {
						ped::delete_ped(&Local_755[14 /*33*/]);
					}
					streaming::set_model_as_no_longer_needed(joaat("ig_janet"));
					streaming::set_model_as_no_longer_needed(joaat("ig_old_man1a"));
					streaming::set_model_as_no_longer_needed(joaat("ig_old_man2"));
					Local_2515[iVar0 /*6*/].f_1 = 0;
					break;

				case 0:
					streaming::request_anim_dict("MISSChinese2_crystalMazeMCS1_IG");
					Local_2515[iVar0 /*6*/].f_2++;
					break;

				case 1:
					if (streaming::has_anim_dict_loaded("MISSChinese2_crystalMazeMCS1_IG")) {
						if (cutscene::has_cutscene_finished() || !cutscene::is_cutscene_playing()) {
							if (entity::does_entity_exist(Local_755[13 /*33*/]) &&
								!ped::is_ped_injured(Local_755[13 /*33*/])) {
								entity::set_entity_coords(Local_755[13 /*33*/], 1986.06f, 3051.708f, 46.2151f, 1, 0, 0,
														  1);
							}
							if (entity::does_entity_exist(Local_755[14 /*33*/]) &&
								!ped::is_ped_injured(Local_755[14 /*33*/])) {
								entity::set_entity_coords(Local_755[14 /*33*/], 1986.105f, 3051.659f, 46.2151f, 1, 0, 0,
														  1);
							}
							Local_2515[iVar0 /*6*/].f_2++;
						}
					}
					break;

				case 2:
					if (ai::does_scenario_exist_in_area(1984.89f, 3052.46f, 46.98f, 0.3f, 1) &&
						ai::does_scenario_exist_in_area(1985.322f, 3053.087f, 46.98f, 0.3f, 1)) {
						if (!entity::does_entity_exist(Local_755[13 /*33*/])) {
							Local_755[13 /*33*/] =
								ped::create_ped(26, joaat("ig_old_man1a"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
						}
						if (!entity::does_entity_exist(Local_755[14 /*33*/])) {
							Local_755[14 /*33*/] =
								ped::create_ped(26, joaat("ig_old_man2"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
						}
						if (!entity::does_entity_exist(Local_755[12 /*33*/])) {
							Local_755[12 /*33*/] =
								ped::create_ped(26, joaat("ig_janet"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
						}
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 1);
						ai::task_use_nearest_scenario_to_coord_warp(Local_755[14 /*33*/], 1984.89f, 3052.46f, 46.98f,
																	0.3f, 0);
						ped::_0x2208438012482A1A(Local_755[14 /*33*/], 1, 1);
						ped::set_blocking_of_non_temporary_events(Local_755[14 /*33*/], 0);
						gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 0);
						ai::task_use_nearest_scenario_to_coord_warp(Local_755[13 /*33*/], 1985.322f, 3053.087f, 46.98f,
																	0.3f, 0);
						ped::_0x2208438012482A1A(Local_755[13 /*33*/], 1, 1);
						ped::set_blocking_of_non_temporary_events(Local_755[13 /*33*/], 0);
						if (!ped::is_synchronized_scene_running(Local_2515[iVar0 /*6*/].f_5)) {
							Local_2515[iVar0 /*6*/].f_5 =
								ped::create_synchronized_scene(1987.231f, 3052.741f, 46.214f, 0f, 0f, 57.6f, 2);
							ped::set_synchronized_scene_looped(Local_2515[iVar0 /*6*/].f_5, 1);
						}
						ai::task_synchronized_scene(Local_755[12 /*33*/], Local_2515[iVar0 /*6*/].f_5,
													"MISSChinese2_crystalMazeMCS1_IG", "bar_peds_action_janet", 1000f,
													-1000f, 1, 0, 1148846080, 0);
						ped::_0x2208438012482A1A(Local_755[12 /*33*/], 1, 1);
						ped::set_blocking_of_non_temporary_events(Local_755[12 /*33*/], 0);
						Local_2515[iVar0 /*6*/].f_5 = 0;
						Local_2515[iVar0 /*6*/].f_2++;
					}
					break;

				case 3:
					if (cutscene::has_cutscene_finished() || !cutscene::is_cutscene_playing()) {
					}
					if (!ped::is_ped_injured(Local_755[13 /*33*/]) && !ped::is_ped_injured(Local_755[14 /*33*/])) {
						ped::set_ped_config_flag(Local_755[13 /*33*/], 152, 1);
						ped::set_ped_config_flag(Local_755[14 /*33*/], 152, 1);
						if (gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 0) &&
							gameplay::is_bit_set(Local_2515[iVar0 /*6*/].f_5, 1)) {
							Local_2515[iVar0 /*6*/].f_2++;
						}
						else {
							if (ai::get_script_task_status(Local_755[13 /*33*/], 993674639) != 1) {
								if (ai::does_scenario_exist_in_area(1984.89f, 3052.46f, 46.98f, 0.3f, 1)) {
									gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 0);
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[13 /*33*/], 1984.89f,
																				3052.46f, 46.98f, 0.3f, 0);
									ped::set_blocking_of_non_temporary_events(Local_755[13 /*33*/], 0);
								}
							}
							else {
								gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 0);
							}
							if (ai::get_script_task_status(Local_755[14 /*33*/], 993674639) != 1) {
								if (ai::does_scenario_exist_in_area(1985.322f, 3053.087f, 46.98f, 0.3f, 1)) {
									gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 1);
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[14 /*33*/], 1985.322f,
																				3053.087f, 46.98f, 0.3f, 0);
									ped::set_blocking_of_non_temporary_events(Local_755[14 /*33*/], 0);
								}
							}
							else {
								gameplay::set_bit(&Local_2515[iVar0 /*6*/].f_5, 1);
							}
						}
					}
					break;

				case 4:
					if (func_67(player::player_ped_id(), 1991.419f, 3054.915f, 47.533f, 1) > 150f) {
						Local_2515[iVar0 /*6*/].f_2 = -1;
					}
					break;

				case 6:
					if (!ped::is_ped_injured(Local_755[12 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[12 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[12 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[12 /*33*/]);
					}
					if (!ped::is_ped_injured(Local_755[13 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[13 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[13 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[13 /*33*/]);
					}
					if (!ped::is_ped_injured(Local_755[14 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[14 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[14 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[14 /*33*/]);
					}
					Local_2515[iVar0 /*6*/].f_2 = 7;
					break;

				case 7:
					if (func_67(player::player_ped_id(), 1991.419f, 3054.915f, 47.533f, 1) > 150f) {
						Local_2515[iVar0 /*6*/].f_2 = -1;
					}
					break;
				}
				break;

			case 27:
				entity::create_forced_object(2444.176f, 4974.077f, 56.4066f, 30f, 1194028902, 1);
				entity::create_forced_object(2444.176f, 4974.077f, 56.4066f, 30f, joaat("v_ilev_fh_frntdoor"), 1);
				Local_2515[iVar0 /*6*/].f_1 = 0;
				break;

			case 29: break;
			}
			if (Local_2515[iVar0 /*6*/].f_2 == -1) {
				Local_2515[iVar0 /*6*/].f_1 = 0;
				Local_2515[iVar0 /*6*/].f_2 = 0;
				Local_2515[iVar0 /*6*/].f_3 = 0;
				Local_2515[iVar0 /*6*/].f_4 = 0;
				Local_2515[iVar0 /*6*/].f_5 = 0;
			}
		}
		iVar0++;
	}
}

// Position - 0x2444
float func_4(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x24A2
int func_5(vector3 vParam0, int iParam3) {
	int iVar0;

	iVar0 = ui::add_blip_for_coord(vParam0);
	ui::set_blip_scale(iVar0, func_6(network::network_is_game_in_progress(), 1f, 1f));
	ui::set_blip_route(iVar0, iParam3);
	return iVar0;
}

// Position - 0x24CE
var func_6(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x24E5
void func_7(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 0);
}

// Position - 0x24FE
bool func_8() {
	if (iLocal_269 == 0) {
		return true;
	}
	return false;
}

// Position - 0x2512
void func_9(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_67917) {
		if (Global_67918[iVar0 /*9*/] == iParam0) {
			if (iParam2) {
				Global_67918[iVar0 /*9*/].f_1 = iParam1;
			}
			else {
				Global_67918[iVar0 /*9*/].f_1 += iParam1;
			}
			return;
		}
		iVar0++;
	}
	if (Global_67918[iVar0 /*9*/] != -1) {
		if (MissionObjectives[Global_67918[iVar0 /*9*/] /*13*/] == 3) {
			if (Global_67918[iVar0 /*9*/].f_1 > 1) {
				Global_67918[iVar0 /*9*/].f_1 = 1;
			}
			if (Global_67918[iVar0 /*9*/].f_1 < 0) {
				Global_67918[iVar0 /*9*/].f_1 = 0;
			}
		}
	}
}

// Position - 0x25BC
void func_10(int iParam0, int iParam1) {
	int iVar0;

	Global_55832 = iParam0;
	if (!Global_55830) {
		Global_55830 = 1;
	}
	if (iParam1) {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (Global_67918[iVar0 /*9*/] == iParam0) {
				Global_67918[iVar0 /*9*/].f_1 = 0;
			}
			iVar0++;
		}
	}
}

// Position - 0x2606
void func_11(int iParam0, int iParam1) {
	int iVar0;

	if (Global_55830) {
	}
	Global_55830 = 0;
	if (iParam0) {
		Global_55831 = 1;
	}
	iVar0 = 0;
	if (iParam1 == -1) {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (MissionObjectives[Global_67918[iVar0 /*9*/] /*13*/] == 4) {
				Global_67918[iVar0 /*9*/].f_5 = 0;
				return;
			}
			iVar0++;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < Global_67917) {
			if (Global_67918[iVar0 /*9*/] > 0) {
				if (Global_67918[iVar0 /*9*/] == iParam1) {
					Global_67918[iVar0 /*9*/].f_5 = 0;
					return;
				}
			}
			iVar0++;
		}
	}
}

// Position - 0x26A0
void func_12(int iParam0) {
	int iVar0;

	if (iParam0 == 1) {
		if (iLocal_262 == 0) {
			iVar0 = 0;
			while (iVar0 < Local_444) {
				if (ui::does_blip_exist(Local_444[iVar0 /*5*/].f_3)) {
					if (ui::get_blip_alpha(Local_444[iVar0 /*5*/].f_3) < 255) {
						ui::remove_blip(&Local_444[iVar0 /*5*/].f_3);
					}
					else {
						ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 0);
					}
				}
				iVar0++;
			}
			iLocal_262 = 1;
		}
	}
	else if (iLocal_262) {
		iVar0 = 0;
		while (iVar0 < Local_444) {
			if (ui::does_blip_exist(Local_444[iVar0 /*5*/].f_3)) {
				ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 255);
			}
			else {
				Local_444[iVar0 /*5*/].f_3 = func_5(Local_444[iVar0 /*5*/], 0);
				ui::_0x54318C915D27E4CE(Local_444[iVar0 /*5*/].f_3, 1);
				ui::set_blip_scale(Local_444[iVar0 /*5*/].f_3, 0.4f);
				ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 0);
				ui::set_blip_colour(Local_444[iVar0 /*5*/].f_3, 5);
				ui::_0x75A16C3DA34F1245(Local_444[iVar0 /*5*/].f_3, 0);
			}
			iVar0++;
		}
		iLocal_262 = 0;
	}
}

// Position - 0x27B1
int func_13(int iParam0) { return func_14(iParam0, 1, 0); }

// Position - 0x27C1
int func_14(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	iVar0 = ui::add_blip_for_entity(iParam0);
	if (entity::is_entity_a_vehicle(iParam0)) {
		ui::set_blip_scale(iVar0, func_6(network::network_is_game_in_progress(), 1f, 1f));
		if (!iParam2) {
			ui::set_blip_as_friendly(iVar0, iParam1);
		}
		else {
			ui::set_blip_colour(iVar0, 2);
		}
	}
	else if (entity::is_entity_a_ped(iParam0)) {
		ui::set_blip_scale(iVar0, func_6(network::network_is_game_in_progress(), 0.7f, 0.7f));
		ui::set_blip_as_friendly(iVar0, iParam1);
	}
	else if (entity::is_entity_an_object(iParam0)) {
		ui::set_blip_scale(iVar0, func_6(network::network_is_game_in_progress(), 0.7f, 0.7f));
	}
	return iVar0;
}

// Position - 0x2865
void func_15(char *sParam0, int iParam1, char *sParam2) {
	iLocal_3506 = 1;
	iLocal_3507 = iParam1;
	sLocal_3509 = sParam0;
	sLocal_3510 = sParam2;
}

// Position - 0x2880
void func_16(int iParam0, int iParam1) {
	Global_55833 = iParam0;
	Global_55834 = iParam1;
}

// Position - 0x2892
void func_17(int iParam0, int iParam1) {
	int iVar0;

	Global_55835 = iParam0;
	iVar0 = 0;
	while (iVar0 < Global_67917) {
		if (iParam1 == -1 || Global_67918[iVar0 /*9*/] == iParam1) {
			if (Global_67918[iVar0 /*9*/].f_6 != iParam0) {
				Global_67918[iVar0 /*9*/].f_6 = iParam0;
				Global_67918[iVar0 /*9*/].f_7 = 1;
				Global_67918[iVar0 /*9*/].f_8 = 0;
			}
		}
		iVar0++;
	}
}

// Position - 0x28FD
int func_18(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_755) {
		if (Local_755[iVar0 /*33*/].f_2 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x292D
void func_19(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (iParam0 != 198) {
		if (Global_69702) {
			Global_2433125.f_74.f_227[iParam0] = iParam1;
		}
		else {
			Global_101700.f_6220.f_227[iParam0] = iParam1;
		}
		Global_32749[iParam0] = iParam2;
		Global_32948[iParam0] = 1;
		func_22(iParam0, iParam3, iParam4, 0);
		func_20(iParam0, iParam1);
	}
}

// Position - 0x2988
void func_20(int iParam0, int iParam1) {
	switch (iParam0) {
	case 12:
		if (iParam1 == 0) {
			audio::set_ambient_zone_state_persistent("AZ_PORT_OF_LS_UNDERWATER_CREAKS", 0, 0);
		}
		else {
			audio::set_ambient_zone_state_persistent("AZ_PORT_OF_LS_UNDERWATER_CREAKS", 1, 0);
		}
		break;

	case 71:
		if (iParam1 != 1) {
			audio::set_ambient_zone_list_state_persistent("HEIST_SWEATSHOP_ZONES", 0, 0);
		}
		else {
			audio::set_ambient_zone_list_state_persistent("HEIST_SWEATSHOP_ZONES", 1, 0);
		}
		break;

	case 65:
		if (iParam1 == 1) {
			func_21(0, 0);
		}
		else {
			func_21(0, 1);
		}
		break;

	case 6:
		if (iParam1 == 1) {
			audio::set_ambient_zone_state_persistent("AZ_UNDERWATER_EXILE_01_PLANE_WRECK", 1, 0);
		}
		else {
			audio::set_ambient_zone_state_persistent("AZ_UNDERWATER_EXILE_01_PLANE_WRECK", 0, 0);
		}
		break;

	case 174:
		if (iParam1 == 2) {
			audio::_0xB4BBFD9CD8B3922B("V_CARSHOWROOM_PS_WINDOW_UNBROKEN");
		}
		break;

	case 37:
		if (iParam1 == 1) {
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_STAGE_RADIO", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_01", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_02", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_03", 0);
		}
		break;
	}
}

// Position - 0x2A71
void func_21(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_100340, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_100340, iParam0);
	}
	Global_100339 = 1;
}

// Position - 0x2A9A
bool func_22(int iParam0, bool bParam1, int iParam2, int iParam3) {
	bool bVar0;
	int iVar1;
	int iVar2;
	struct<5> Var3;
	var uVar98;
	bool bVar99;
	int iVar100;

	bVar0 = false;
	Var3.f_4 = 3;
	Var3.f_8 = 3;
	Var3.f_64 = 3;
	Var3.f_75 = 3;
	Var3.f_91 = 3;
	func_26(&Var3, iParam0);
	if (func_23()) {
		iVar1 = Global_101700.f_6220.f_227[iParam0];
	}
	else {
		iVar1 = Global_2433125.f_74.f_227[iParam0];
	}
	iVar2 = Global_33147[iParam0];
	if (ped::is_ped_injured(player::player_ped_id()) && !iParam3) {
	}
	else {
		bVar99 = true;
		if (gameplay::get_hash_key(script::get_this_script_name()) != gameplay::get_hash_key("standard_global_reg")) {
			if (iParam2 == 0) {
				if (Global_32749[iParam0] &&
					gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 0), Var3,
														  1) < 200f) {
					bVar99 = false;
				}
				if (!player::is_player_playing(player::player_id()) ||
					ai::is_ped_being_arrested(player::player_ped_id())) {
					if (!cam::is_screen_faded_out()) {
						bVar99 = false;
					}
				}
			}
		}
		if (streaming::is_new_load_scene_active() &&
			(!streaming::is_player_switch_in_progress() || streaming::get_player_switch_state() != 5)) {
			bVar99 = false;
		}
		if (bVar99) {
			switch (Var3.f_3) {
			case 0:
				if (iVar1 == 2) {
				}
				else {
					if (Var3.f_4[iVar1] != 0) {
						entity::remove_model_hide(Var3, 10f, Var3.f_4[iVar1], 0);
					}
					if (Var3.f_4[iVar2] != 0) {
						entity::create_model_hide(Var3, 10f, Var3.f_4[iVar2], 1);
					}
					Global_34343[iParam0] = 1;
				}
				bVar0 = true;
				break;

			case 1:
				if (iVar1 == 0) {
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_34)) {
							streaming::request_ipl(&Var3.f_34);
						}
					}
				}
				else if (iVar1 == 1) {
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (streaming::is_ipl_active(&Var3.f_34)) {
							streaming::remove_ipl(&Var3.f_34);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
				}
				else if (iVar1 == 2) {
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (streaming::is_ipl_active(&Var3.f_34)) {
							streaming::remove_ipl(&Var3.f_34);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES")) {
						if (!streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
				}
				Global_34144[iParam0] = 1;
				Global_34343[iParam0] = 1;
				bVar0 = true;
				break;

			case 2:
				iVar100 = interior::get_interior_at_coords_with_type(Var3, &Var3.f_42);
				if (iVar100 != 0) {
					if (gameplay::get_hash_key(&Var3.f_50) != gameplay::get_hash_key("")) {
						if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_50)) {
							interior::_disable_interior_prop(iVar100, &Var3.f_50);
						}
					}
					if (iVar1 == 0) {
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) !=
								gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
					}
					else if (iVar1 == 1) {
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) !=
								gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
					}
					else if (iVar1 == 2) {
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
					}
					if (bParam1) {
						interior::refresh_interior(iVar100);
					}
				}
				Global_34343[iParam0] = 1;
				Global_34144[iParam0] = 1;
				bVar0 = true;
				break;

			case 3:
				if (gameplay::get_distance_between_coords(Var3, entity::get_entity_coords(player::player_ped_id(), 0),
														  1) < 250f) {
					uVar98 = object::_get_des_object(Var3, 25f, &Var3.f_8[0 /*8*/]);
					if (object::_does_des_object_exist(uVar98)) {
						if (iVar1 == 0) {
							object::_set_des_object_state(uVar98, 3);
							Global_34343[iParam0] = 1;
							bVar0 = true;
						}
						else if (iVar1 == 1) {
							if (object::_get_des_object_state(uVar98) != 6 &&
								object::_get_des_object_state(uVar98) != 7 &&
								object::_get_des_object_state(uVar98) != 8) {
								object::_set_des_object_state(uVar98, 10);
								Global_34343[iParam0] = 1;
								bVar0 = true;
							}
						}
						else if (iVar1 == 2) {
							bVar0 = true;
						}
					}
				}
				break;

			case 4:
				if (iVar1 == 0) {
					entity::remove_model_swap(Var3, 50f, Var3.f_4[1], Var3.f_4[0], 0);
					gameplay::clear_bit(&Global_32495[iParam0 / 32], iParam0 % 32);
				}
				else if (iVar1 == 1) {
					entity::create_model_swap(Var3, 50f, Var3.f_4[0], Var3.f_4[1], 1);
					gameplay::set_bit(&Global_32495[iParam0 / 32], iParam0 % 32);
				}
				bVar0 = true;
				break;
			}
			if (bVar0) {
				Global_32948[iParam0] = 0;
				Global_33147[iParam0] = iVar1;
				if (!func_23()) {
					if (!Global_33744[iParam0]) {
						Global_33744[iParam0] = 1;
						Global_33943++;
					}
				}
			}
		}
	}
	return bVar0;
}

// Position - 0x33D5
bool func_23() {
	if ((func_25() == -1 || func_25() == 999) && func_24() != 0) {
		return true;
	}
	return false;
}

// Position - 0x3405
int func_24() { return Global_25191; }

// Position - 0x3410
int func_25() { return Global_25190; }

// Position - 0x341B
int func_26(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		uParam0->f_4[iVar0] = 0;
		StringCopy(&uParam0->f_8[iVar0 /*8*/], "", 32);
		uParam0->f_64[iVar0] = 0;
		uParam0->f_75[iVar0] = 0;
		uParam0->f_91[iVar0] = 0;
		iVar0++;
	}
	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0;
	uParam0->f_33 = 0;
	StringCopy(&uParam0->f_34, "", 32);
	StringCopy(&uParam0->f_42, "", 32);
	StringCopy(&uParam0->f_50, "", 32);
	uParam0->f_58 = {0f, 0f, 0f};
	uParam0->f_61 = {0f, 0f, 0f};
	uParam0->f_68 = {0f, 0f, 0f};
	uParam0->f_71 = {0f, 0f, 0f};
	uParam0->f_74 = 0f;
	uParam0->f_79 = {0f, 0f, 0f};
	uParam0->f_82 = {0f, 0f, 0f};
	uParam0->f_85 = {0f, 0f, 0f};
	uParam0->f_88 = {0f, 0f, 0f};
	switch (iParam1) {
	case 3:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "TRV1_Trail_start", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "TRV1_Trail_end", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "TRV1_Trail_Finish", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-24.685f, 3032.92f, 40.331f};
		break;

	case 4:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS3_05_water_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS3_05_water_grp2", 32);
		*uParam0 = {-24.685f, 3032.92f, 40.331f};
		break;

	case 0:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "gasstation_ipl_group1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "gasstation_ipl_group2", 32);
		*uParam0 = {-93.4f, 6410.9f, 36.8f};
		break;

	case 1:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DES_Smash2_startimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_Smash2_endimap", 32);
		*uParam0 = {890.3647f, -2367.289f, 28.10582f};
		break;

	case 2:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DES_StiltHouse_imapstart", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_StiltHouse_imapend", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "des_stilthouse_rebuild", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1020.5f, 663.41f, 154.75f};
		uParam0->f_58 = {-1018.913f, 603.2904f, 105.6611f};
		uParam0->f_61 = {-1038.913f, 639.2904f, 135.6611f};
		uParam0->f_64[0] = 1;
		uParam0->f_64[1] = 0;
		break;

	case 5:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "bnkheist_apt_norm", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bnkheist_apt_dest", 32);
		break;

	case 196:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bnkheist_apt_dest_vfx", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		break;

	case 6:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "crashed_cargoplane", 32);
		break;

	case 7:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_jb700_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 8:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_entityXF_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 9:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_cheetah_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 10:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_ztype_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 11:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "BH1_48_Killed_Michael", 32);
		break;

	case 12:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "cargoship", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "sunkcargoship", 32);
		uParam0->f_68 = {-162.8918f, -2365.769f, 0f};
		uParam0->f_71 = {190.75f, 31.25f, 21f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		break;

	case 13:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ship_occ_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ship_occ_grp2", 32);
		break;

	case 14:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "smboat", 32);
		break;

	case 15:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "gasparticle_grp2", 32);
		*uParam0 = {-95.2f, 6411.3f, 31.5f};
		break;

	case 16:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS1_02_cf_offmission", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission1", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 17:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission2", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 18:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission3", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 19:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission4", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 20:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "jetstealtunnel", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {801.7f, -1810.8f, 23.3f};
		break;

	case 21:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Jetsteal_ipl_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Jetsteal_ipl_grp2", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {787.3967f, -1808.858f, 29.8532f};
		uParam0->f_58 = {814f, -1750f, 20f};
		uParam0->f_61 = {790f, -1899f, 35f};
		uParam0->f_64[0] = 1;
		uParam0->f_64[1] = 0;
		uParam0->f_64[2] = 0;
		break;

	case 22:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "BH1_47_JoshHse_UnBurnt", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "BH1_47_JoshHse_Burnt", 32);
		break;

	case 23:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bh1_47_joshhse_firevfx", 32);
		break;

	case 24:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_30_Keep_Closed", 32);
		break;

	case 25:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "triathlon2_VBprops", 32);
		break;

	case 26:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_REQUEST", 32);
		*uParam0 = {163.4f, -745.7f, 251f};
		break;

	case 27:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FBI_colPLUG", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 28:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FBI_repair", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 29:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = joaat("dt1_05_build1_h");
		uParam0->f_4[1] = joaat("dt1_05_build1_damage");
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 30:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = -112041596;
		uParam0->f_4[1] = joaat("dt1_05_build1_damage_lod");
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 31:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = -186270611;
		uParam0->f_4[1] = joaat("dt1_05_damage_slod");
		*uParam0 = {178.534f, -668.835f, 37.2113f};
		break;

	case 32:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FIB_heist_lights", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 33:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FIB_heist_dmg", 32);
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 34:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_rubble", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 35:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FIBlobbyfake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FIBlobby", 32);
		*uParam0 = {105.4557f, -745.4835f, 44.7548f};
		break;

	case 36:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_05_HC_REMOVE", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_HC_REQ", 32);
		*uParam0 = {169f, -670.3f, 41.9f};
		break;

	case 37:
		uParam0->f_3 = 1;
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		uParam0->f_79 = {16.9757f, 3614.307f, 30.0677f};
		uParam0->f_82 = {145.2451f, 3748.912f, 49.6958f};
		uParam0->f_85 = {16.9757f, 3614.307f, 30.0677f};
		uParam0->f_88 = {145.2451f, 3748.912f, 49.6958f};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		break;

	case 38:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkA_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkA_grp2", 32);
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		break;

	case 39:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerA_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		break;

	case 40:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkB_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkB_grp2", 32);
		*uParam0 = {106.7f, 3732.1f, 40.8f};
		break;

	case 41:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerB_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {106.7f, 3732.1f, 40.8f};
		break;

	case 42:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkC_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkC_grp2", 32);
		*uParam0 = {72.7f, 3695.4f, 42f};
		break;

	case 43:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerC_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {72.7f, 3695.4f, 42f};
		break;

	case 44:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkD_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkD_grp2", 32);
		*uParam0 = {43.8f, 3699.7f, 41.3f};
		break;

	case 45:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerD_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {43.8f, 3699.7f, 41.3f};
		break;

	case 46:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkE_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkE_grp2", 32);
		*uParam0 = {28.5f, 3668f, 40.4f};
		break;

	case 47:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerE_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {28.5f, 3668f, 40.4f};
		break;

	case 48:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_34, "des_methtrailer", 32);
		StringCopy(&uParam0->f_8[0 /*8*/], "methtrailer_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "methtrailer_grp2", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "methtrailer_grp3", 32);
		uParam0->f_33 = 1;
		*uParam0 = {29.4838f, 3735.593f, 38.688f};
		uParam0->f_68 = {31.134f, 3738.783f, 39.062f};
		uParam0->f_71 = {13.6f, 20f, 8.9f};
		uParam0->f_74 = 48f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 1;
		break;

	case 49:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_meth_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {29.4838f, 3735.593f, 38.688f};
		break;

	case 50:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhs_startimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhs_endimap", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2450.595f, 4959.929f, 44.2575f};
		uParam0->f_79 = {2383.756f, 4929.988f, 39.52461f};
		uParam0->f_82 = {2505.756f, 5023.988f, 67.52461f};
		break;

	case 55:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhs_start_occl", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhs_end_occl", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {2450.595f, 4959.929f, 44.2575f};
		break;

	case 51:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farm", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "farm", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "farm_burnt", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2444.8f, 4976.4f, 50.5f};
		break;

	case 52:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farm_props", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "farm_burnt_props", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 53:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhouse", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhouse", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 54:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farmint_cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "farmint", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 56:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "tankerexp_grp0", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp3", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 57:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp1", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 58:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp2", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 59:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_tankerexp", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 60:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "dockcrane1", 32);
		*uParam0 = {889.3f, -2910.9f, 40f};
		break;

	case 61:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CanyonRvrShallow", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CanyonRvrDeep", 32);
		*uParam0 = {-1600.619f, 4443.457f, 0.725f};
		break;

	case 62:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Garage_door_locked", 32);
		*uParam0 = {966.1f, -114.8f, 75.2f};
		break;

	case 63:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ch1_02_closed", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ch1_02_open", 32);
		*uParam0 = {-3086.428f, 339.2523f, 6.3717f};
		break;

	case 64:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ferris_finale_Anim", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-1675.178f, -1143.605f, 12.0175f};
		break;

	case 65:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "railing_start", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "railing_end", 32);
		*uParam0 = {-532.1309f, 4526.187f, 88.7955f};
		break;

	case 66:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "canyonriver01", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "canyonriver01_traincrash", 32);
		*uParam0 = {-532.1309f, 4526.187f, 88.7955f};
		break;

	case 67:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_05_WOFFM", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_FIB2_Mission", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "DT1_05_WOFFM", 32);
		*uParam0 = {131.29f, -631.22f, 261.85f};
		break;

	case 68:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "coronertrash", 32);
		*uParam0 = {233.9f, -1355f, 30.3f};
		break;

	case 69:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Coroner_Int_off", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Coroner_Int_on", 32);
		*uParam0 = {234.4f, -1355.6f, 40.5f};
		break;

	case 70:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "id2_14_pre_no_int", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 71:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_during1", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "id2_14_during2", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 72:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_on_fire", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "id2_14_post_no_int", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 73:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_during_door", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 74:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "burnt_switch_off", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 75:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "RC12B_Default", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "RC12B_Destroyed", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "RC12B_Fixed", 32);
		uParam0->f_33 = 0;
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 76:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "RC12B_HospitalInterior", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 105:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SM_15_BldGRAF1", 32);
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 106:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CH3_RD2_BishopsChickenGraffiti", 32);
		*uParam0 = {1861.28f, 2402.11f, 58.53f};
		break;

	case 107:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FruitBB", 32);
		*uParam0 = {-1327.46f, -274.82f, 54.25f};
		break;

	case 108:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS5_04_MazeBillboardGraffiti", 32);
		*uParam0 = {2697.32f, 3162.18f, 58.1f};
		break;

	case 109:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS5_Roads_RonOilGraffiti", 32);
		*uParam0 = {2119.12f, 3058.21f, 53.25f};
		break;

	case 110:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ap1_03_bbrd_dcl", 32);
		*uParam0 = {-804.25f, -2276.88f, 23.59f};
		break;

	case 111:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "HW1_02_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "HW1_02_NewBill", 32);
		*uParam0 = {296.5f, 173.3f, 100.4f};
		break;

	case 112:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "HW1_Emissive_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "HW1_Emissive_NewBill", 32);
		*uParam0 = {296.5f, 173.3f, 100.4f};
		break;

	case 77:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {480.9554f, -1321.21f, 28.2037f};
		uParam0->f_85 = {508.3f, -1299.3f, 39.4f};
		uParam0->f_88 = {459.9f, -1363.2f, 21.4f};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		uParam0->f_91[2] = 0;
		break;

	case 78:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "TrevorsTrailer", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "TrevorsTrailerTrash", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "TrevorsTrailerTidy", 32);
		*uParam0 = {1973f, 3815f, 34f};
		uParam0->f_33 = 0;
		break;

	case 79:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "scafstartimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "scafendimap", 32);
		*uParam0 = {-1088.6f, -1650.6f, 6.4f};
		break;

	case 80:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "chop_props", 32);
		*uParam0 = {-13.83f, -1455.45f, 31.81f};
		break;

	case 113:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "AP1_04_TriAf01", 32);
		*uParam0 = {-1277.629f, -2030.913f, 1.2823f};
		break;

	case 114:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS2_06_TriAf02", 32);
		*uParam0 = {2384.969f, 4277.583f, 30.379f};
		break;

	case 115:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS4_04_TriAf03", 32);
		*uParam0 = {1577.881f, 3836.107f, 30.7717f};
		break;

	case 87:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_21_prop_lift_on", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-180.5771f, -1016.928f, 28.2893f};
		break;

	case 88:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "jewel2fake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "post_hiest_unload", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "bh1_16_refurb", 32);
		*uParam0 = {-630.4205f, -236.7843f, 37.057f};
		uParam0->f_79 = {-623.6868f - 11f, -231.935f - 11f, 40.30703f - 3.25f};
		uParam0->f_82 = {-623.6868f + 11f, -231.935f + 11f, 40.30703f + 3.25f};
		break;

	case 89:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "bh1_16_doors_shut", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "refit_unload", 32);
		*uParam0 = {-583.1606f, -282.3967f, 35.394f};
		break;

	case 90:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "v_tunnel_hole_swap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "v_tunnel_hole", 32);
		*uParam0 = {-14.651f, -604.3639f, 25.1823f};
		break;

	case 91:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "cs5_4_trains", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2773.61f, 2835.327f, 35.1903f};
		break;

	case 94:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "airfield", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {1743.682f, 3286.251f, 40.0875f};
		break;

	case 95:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {1222.9f, 1877.9f, 79.9f};
		uParam0->f_58 = {1206.8f, 1803f, 43.9f};
		uParam0->f_61 = {1329f, 2060.4f, 143.9f};
		uParam0->f_64[0] = 0;
		uParam0->f_64[1] = 1;
		uParam0->f_64[2] = 0;
		break;

	case 104:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_01_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SC1_01_NewBill", 32);
		*uParam0 = {-351f, -1324f, 44.02f};
		break;

	case 103:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_17_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_17_NewBill", 32);
		*uParam0 = {391.81f, -962.71f, 41.97f};
		break;

	case 102:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_14_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SC1_14_NewBill", 32);
		*uParam0 = {424.2f, -1944.31f, 33.09f};
		break;

	case 92:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ld_rail_01_track", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2626.374f, 2949.869f, 39.1409f};
		break;

	case 93:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ld_rail_02_track", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2626.374f, 2949.869f, 39.1409f};
		break;

	case 118:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_M_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_M_moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-811.2679f, 179.3344f, 75.7408f};
		break;

	case 116:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_D_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_D_Moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-802.0311f, 172.9131f, 75.7408f};
		break;

	case 117:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_S_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_S_items_swap", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 119:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_L_Items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_L_Moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 120:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_M_items_swap", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 122:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_FameShame", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-802.0311f, 172.9131f, 75.7408f};
		break;

	case 121:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_JewelHeist", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 123:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Michael_premier", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 124:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_plane_ticket", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 170:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "burgershot_yoga", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 171:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_Scuba", 32);
		StringCopy(&uParam0->f_42, "V_Michael_Garage", 32);
		*uParam0 = {-810.5301f, 187.7868f, 71.4786f};
		break;

	case 125:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_bed_tidy", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_bed_Messy", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-811.2679f, 179.3344f, 75.7408f};
		break;

	case 164:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Jewel_Gasmasks", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 165:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_53_Agency _Overalls", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 166:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_53_Agency_Blueprint", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 167:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_KitBag", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 168:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_Body_Armour", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 169:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_Fireman", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 126:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 127:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 128:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 129:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 130:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 131:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 132:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 133:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 134:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 179:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "shutter_open", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "shutter_closed", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-30.8793f, -1088.336f, 25.4221f};
		uParam0->f_68 = {-29.3f, -1086.35f, 25.57f};
		uParam0->f_71 = {5.5f, 3f, 2f};
		uParam0->f_74 = -10f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		break;

	case 174:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "csr_beforeMission", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "csr_afterMissionA", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "csr_afterMissionB", 32);
		StringCopy(&uParam0->f_50, "csr_inMission", 32);
		uParam0->f_33 = 0;
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 175:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-49.21f, -1090.28f, 25.42f};
		uParam0->f_68 = {-49.21f, -1090.28f, 25.42f};
		uParam0->f_71 = {2.5f, 3f, 3f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 176:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-49.28f, -1092.66f, 25.42f};
		uParam0->f_68 = {-49.28f, -1092.66f, 25.42f};
		uParam0->f_71 = {3f, 1f, 3f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 177:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-53.07f, -1096.73f, 25.5f};
		uParam0->f_68 = {-53.07f, -1096.73f, 25.5f};
		uParam0->f_71 = {1f, 3f, 2f};
		uParam0->f_74 = -45f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 178:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "carshowroom_broken", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "carshowroom_boarded", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 173:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "shr_int", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "fakeint", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 180:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_03_Shutter", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "", 32);
		*uParam0 = {23.9346f, -669.7552f, 30.8853f};
		break;

	case 181:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "Hospitaldoorsanim", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "Hospitaldoorsfixed", 32);
		StringCopy(&uParam0->f_42, "v_hospital", 32);
		uParam0->f_33 = 0;
		*uParam0 = {300.9423f, -586.1784f, 42.2919f};
		break;

	case 135:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_clean_apt", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_A", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 136:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_B", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 137:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_C", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 138:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_sextoys_a", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 139:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_wade_shit", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 140:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_wade_sofa_A", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 141:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "layer_debra_pic", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 142:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_torture", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 143:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_sofa_A", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_sofa_B", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 144:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_whiskey", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 145:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_mrJam_A", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_mrJam_B", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 146:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_mrJam_C", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 147:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "vb_30_emissive", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "vb_30_murder", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1150.039f, -1521.761f, 9.6331f};
		break;

	case 148:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "vb_30_crimetape", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1150.039f, -1521.761f, 9.6331f};
		break;

	case 149:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "sheriff_cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {1856.029f, 3682.998f, 33.2675f};
		break;

	case 150:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS1_16_Sheriff_Cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-440.5073f, 6018.766f, 30.49f};
		break;

	case 151:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ufo", 32);
		uParam0->f_33 = 0;
		*uParam0 = {487.31f, 5588.386f, 793.0532f};
		break;

	case 152:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ufo_eye", 32);
		uParam0->f_33 = 0;
		*uParam0 = {487.31f, 5588.386f, 793.0532f};
		break;

	case 153:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_57_FranklinStuff", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_Franklin_LEFT", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 154:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_GangBandana", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 155:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_Safari", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 172:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_19_Trevor_Mess", 32);
		StringCopy(&uParam0->f_42, "v_strip3", 32);
		*uParam0 = {96.4811f, -1291.294f, 28.2688f};
		break;

	case 182:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {139.5795f, -3092.962f, 8.64631f};
		uParam0->f_79 = {Vector(8.64631f, -3092.962f, 139.5795f) - Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_82 = {Vector(8.64631f, -3092.962f, 139.5795f) + Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_85 = {Vector(8.64631f, -3092.962f, 139.5795f) - Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_88 = {Vector(8.64631f, -3092.962f, 139.5795f) + Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		uParam0->f_91[2] = 1;
		break;

	case 183:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {203.7784f, -3131.767f, 7.041344f};
		uParam0->f_79 = {Vector(7.041344f, -3131.767f, 203.7784f) - Vector(2.5625f, 2.75f, 4.875f)};
		uParam0->f_82 = {Vector(7.041344f, -3131.767f, 203.7784f) + Vector(2.5625f, 2.75f, 4.875f)};
		break;

	case 184:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {144.7706f, -2982.659f, 7.952507f};
		uParam0->f_79 = {Vector(7.952507f, -2982.659f, 144.7706f) - Vector(3.125f, 3.4375f, 5.3125f)};
		uParam0->f_82 = {Vector(7.952507f, -2982.659f, 144.7706f) + Vector(3.125f, 3.4375f, 5.3125f)};
		break;

	case 185:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1154.965f, -1520.983f, 9.132731f};
		uParam0->f_79 = {-1154.965f, -1520.983f, 9.132731f};
		uParam0->f_82 = {-1158.965f, -1524.983f, 11.63273f};
		break;

	case 187:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1052.204f, 371.9537f, 67.914f};
		uParam0->f_79 = {-1052.204f, 371.9537f, 67.914f};
		uParam0->f_82 = {-1048.064f, 368.0221f, 70.9128f};
		break;

	case 186:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {1954.984f, 3792.991f, 30.3086f};
		uParam0->f_79 = {1954.984f, 3792.991f, 30.3086f};
		uParam0->f_82 = {1983.45f, 3830.78f, 36.2726f};
		break;

	case 188:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1122.202f, 48.5724f, 51.4652f};
		uParam0->f_79 = {-1122.202f, 48.5724f, 51.4652f};
		uParam0->f_82 = {-1076.233f, 92.1041f, 60.0617f};
		break;

	case 81:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "KorizTempWalls", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-2199.138f, 223.4648f, 181.1118f};
		break;

	case 82:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "mic3_chopper_debris", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-2242.785f, 263.4779f, 173.6154f};
		break;

	case 83:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "chemgrill_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {3832.9f, 3665.5f, -23.4f};
		break;

	case 84:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Plane_crash_trench", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {2814.7f, 4758.5f, 47.9f};
		break;

	case 85:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "golfflags", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-1096.505f, 4.5754f, 49.8103f};
		break;

	case 86:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "yogagame", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-781.6566f, 186.8937f, 71.8352f};
		break;

	case 189:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Carwash_with_spinners", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Carwash_without_spinners", 32);
		uParam0->f_33 = 0;
		*uParam0 = {55.7f, -1391.3f, 30.5f};
		break;

	case 190:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "KT_CarWash", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "KT_CarWash_NoBrush", 32);
		uParam0->f_33 = 0;
		*uParam0 = {700.091f, -933.641f, 20.308f};
		break;

	case 191:
		uParam0->f_3 = 1;
		*uParam0 = {-1096.381f, -836.17f, 36.6755f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 192:
		uParam0->f_3 = 1;
		*uParam0 = {449.6558f, -980.1375f, 42.6918f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 193:
		uParam0->f_3 = 1;
		*uParam0 = {363.0175f, -1598.079f, 35.9502f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 194:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS3_07_MPGates", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {-1601.424f, 2808.213f, 16.2598f};
		break;

	case 97:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_03_Gr_Closed", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {23.7318f, -647.2123f, 37.9549f};
		break;

	case 98:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FINBANK", 32);
		*uParam0 = {12.9689f, -648.4698f, 9.7693f};
		break;

	case 99:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "PAPER1_RCM_ALT", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "PAPER1_RCM", 32);
		*uParam0 = {-1459.127f, 486.1281f, 115.2016f};
		break;

	case 100:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SP1_10_fake_interior", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SP1_10_real_interior", 32);
		*uParam0 = {-248.4916f, -2010.509f, 34.5743f};
		break;

	case 101:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "facelobbyfake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "facelobby", 32);
		*uParam0 = {-1081.347f, -263.1502f, 38.7152f};
		break;

	case 195:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "atriumglstatic", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "atriumglmission", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "atriumglcut", 32);
		*uParam0 = {136.1795f, -750.701f, 262.0516f};
		break;

	case 197:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "racetrack01", 32);
		*uParam0 = {2096f, 3168.7f, 42.9f};
		break;
	}
	switch (iParam1) {
	case 156:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "showhome_only", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 157:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "franklin_unpacking", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 158:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "franklin_settled", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 163:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_tshirt", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 159:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bong_and_wine", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 161:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_flyer", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 162:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_tux", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 160:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "locked", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "unlocked", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 96:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "chophillskennel", 32);
		*uParam0 = {19.0568f, 536.4818f, 169.6277f};
		break;
	}
	return 1;
}

// Position - 0x6C5C
void func_27() {
	int iVar0;

	func_32(27, 0);
	gameplay::clear_area(2479.875f, 4980.868f, 44.82052f, 60f, 1, 0, 0, 0);
	iLocal_2507 = vehicle::create_vehicle(joaat("burrito"), 2479.579f, 4980.503f, 44.8051f, 341.8158f, 1, 1);
	vehicle::set_vehicle_colour_combination(iLocal_2507, 1);
	vehicle::set_vehicle_livery(iLocal_2507, 2);
	vehicle::set_vehicle_on_ground_properly(iLocal_2507, 1084227584);
	if (iLocal_2511 < 5) {
		func_29(1, 1, 4);
		func_29(1, 1, 5);
		func_29(1, 1, 2);
		func_29(1, 1, 1);
		func_29(1, 1, 6);
		func_29(1, 1, 7);
		func_29(1, 1, 3);
		func_29(1, 1, 0);
		func_29(1, 1, 8);
		func_29(1, 1, 9);
	}
	if (iLocal_2511 < 6) {
		func_29(2, 1, 10);
		func_29(2, 1, 11);
		func_29(2, 1, 18);
		func_29(2, 1, 19);
	}
	if (iLocal_2511 < 7) {
		func_29(2, 1, 12);
		func_29(2, 1, 13);
		func_29(2, 1, 14);
		func_29(2, 1, 15);
		func_29(2, 1, 16);
		func_29(2, 1, 17);
		func_29(2, 1, 20);
		func_29(5, 1, 23);
	}
	if (iLocal_2511 == 7) {
		streaming::request_anim_dict("DEAD");
		while (!streaming::has_anim_dict_loaded("DEAD")) {
			func_28(323, 1);
		}
		Local_755[15 /*33*/] =
			ped::create_ped(26, joaat("a_m_y_methhead_01"), 2436.901f, 4959.1f, 45.8106f, 209.7559f, 1, 1);
		ai::task_play_anim(Local_755[15 /*33*/], "DEAD", "DEAD_C", 1000f, -1000f, -1, 1, 0, 0, 0, 0);
		ped::_0x2208438012482A1A(Local_755[15 /*33*/], 1, 0);
		audio::disable_ped_pain_audio(Local_755[15 /*33*/], 1);
		Local_755[16 /*33*/] =
			ped::create_ped(26, joaat("a_m_m_hillbilly_01"), 2440.266f, 4970.705f, 45.8306f, 15.7982f, 1, 1);
		ai::task_play_anim(Local_755[16 /*33*/], "DEAD", "DEAD_D", 1000f, -1000f, -1, 1, 0, 0, 0, 0);
		ped::_0x2208438012482A1A(Local_755[16 /*33*/], 1, 0);
		audio::disable_ped_pain_audio(Local_755[16 /*33*/], 1);
		Local_755[17 /*33*/] =
			ped::create_ped(26, joaat("a_m_m_hillbilly_02"), 2443.42f, 4974.523f, 45.8106f, 121.834f, 1, 1);
		ai::task_play_anim(Local_755[17 /*33*/], "DEAD", "DEAD_E", 1000f, -1000f, -1, 1, 0, 0, 0, 0);
		ped::_0x2208438012482A1A(Local_755[17 /*33*/], 1, 0);
		audio::disable_ped_pain_audio(Local_755[17 /*33*/], 1);
		Local_755[18 /*33*/] =
			ped::create_ped(26, joaat("a_m_y_methhead_01"), 2448.888f, 4971.561f, 45.8106f, 194.7676f, 1, 1);
		ai::task_play_anim(Local_755[18 /*33*/], "DEAD", "DEAD_G", 1000f, -1000f, -1, 1, 0, 0, 0, 0);
		ped::_0x2208438012482A1A(Local_755[18 /*33*/], 1, 0);
		audio::disable_ped_pain_audio(Local_755[18 /*33*/], 1);
		while (!entity::is_entity_playing_anim(Local_755[15 /*33*/], "DEAD", "DEAD_C", 3) ||
			   !entity::is_entity_playing_anim(Local_755[16 /*33*/], "DEAD", "DEAD_D", 3) ||
			   !entity::is_entity_playing_anim(Local_755[17 /*33*/], "DEAD", "DEAD_E", 3) ||
			   !entity::is_entity_playing_anim(Local_755[18 /*33*/], "DEAD", "DEAD_G", 3)) {
			func_28(54343, 1);
			if (!ped::is_ped_injured(Local_755[15 /*33*/]) && !ped::is_ped_injured(Local_755[16 /*33*/]) &&
				!ped::is_ped_injured(Local_755[17 /*33*/]) && !ped::is_ped_injured(Local_755[18 /*33*/])) {
			}
		}
		entity::set_entity_health(Local_755[15 /*33*/], 0);
		entity::set_entity_health(Local_755[16 /*33*/], 0);
		entity::set_entity_health(Local_755[17 /*33*/], 0);
		entity::set_entity_health(Local_755[18 /*33*/], 0);
		streaming::remove_anim_dict("DEAD");
	}
	func_32(23, 0);
	iVar0 = 0;
	gameplay::set_bit(&iVar0, 3);
	gameplay::set_bit(&iVar0, 8);
	gameplay::set_bit(&iVar0, 1);
	gameplay::set_bit(&iVar0, 2);
	gameplay::set_bit(&iVar0, 4);
	uLocal_2650 =
		object::create_pickup(joaat("pickup_health_standard"), 2446.896f, 4990.972f, 45.5477f, iVar0, -1, 1, 0);
	if (!pathfind::does_navmesh_blocking_object_exist(iLocal_2510)) {
		iLocal_2510 =
			pathfind::add_navmesh_blocking_object(2464.956f, 4990.051f, 44.48415f, 2.5f, 3.125f, 2.0625f, 0f, 0, 7);
	}
	iLocal_2651[0] = object::create_pickup_rotate(joaat("pickup_health_standard"), 2444.497f, 4975.956f, 50.565f, 0f,
												  0f, 100f, iVar0, -1, 2, 1, 0);
	interior::add_pickup_to_interior_room_by_name(iLocal_2651[0], "V_8_Bed1Rm");
	iLocal_2651[1] = object::create_pickup_rotate(joaat("pickup_health_standard"), 2443.4f, 4978.52f, 46.8107f, 0f, 0f,
												  100f, iVar0, -1, 2, 1, 0);
	interior::add_pickup_to_interior_room_by_name(iLocal_2651[1], "V_8_KitchnRm");
	iLocal_2651[3] = object::create_pickup_rotate(joaat("pickup_health_standard"), 2441.028f, 4963.851f, 46.5605f, 0f,
												  0f, -80.6f, iVar0, -1, 2, 1, 0);
	interior::add_pickup_to_interior_room_by_name(iLocal_2651[3], "V_8_StudyRm");
	iLocal_2651[4] = object::create_pickup_rotate(joaat("pickup_health_standard"), 2435.165f, 4971.467f, 45.91f, 0f, 0f,
												  -50.4f, iVar0, -1, 2, 1, 0);
	interior::add_pickup_to_interior_room_by_name(iLocal_2651[4], "V_8_Hall2Rm");
	iVar0 = 0;
	gameplay::set_bit(&iVar0, 2);
	gameplay::set_bit(&iVar0, 1);
	gameplay::set_bit(&iVar0, 3);
	iLocal_2651[2] = object::create_pickup_rotate(joaat("pickup_weapon_sawnoffshotgun"), 2438.788f, 4970.79f, 50.565f,
												  0f, 0f, 0f, iVar0, -1, 2, 1, 0);
	interior::add_pickup_to_interior_room_by_name(iLocal_2651[2], "V_8_Bed1Rm");
}

// Position - 0x71DC
void func_28(int iParam0, int iParam1) {
	iParam0 = iParam0;
	iParam1 = iParam1;
	system::wait(0);
}

// Position - 0x71F1
void func_29(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam2;
	Local_755[iVar0 /*33*/].f_1 = iParam0;
	Local_755[iVar0 /*33*/].f_3 = iParam1;
	Local_755[iVar0 /*33*/].f_2 = iParam2;
	Local_755[iVar0 /*33*/].f_5 = 0;
}

// Position - 0x7228
bool func_30(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 1) {
			if (Local_2515[iVar0 /*6*/] == iParam0) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x7262
int func_31(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/] == iParam0) {
			Local_2515[iVar0 /*6*/].f_2 = -1;
			if (!iParam1) {
				Local_2515[iVar0 /*6*/].f_1 = 0;
			}
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x72A9
int func_32(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 1) {
			if (Local_2515[iVar0 /*6*/] == iParam0) {
				return 0;
			}
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 0) {
			Local_2515[iVar0 /*6*/].f_1 = 1;
			Local_2515[iVar0 /*6*/] = iParam0;
			Local_2515[iVar0 /*6*/].f_2 = 0;
			Local_2515[iVar0 /*6*/].f_3 = iParam1;
			Local_2515[iVar0 /*6*/].f_4 = 0;
			Local_2515[iVar0 /*6*/].f_5 = 0;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x7344
bool func_33(float fParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		return true;
	}
	iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
	if (vehicle::is_vehicle_driveable(iVar0, 0)) {
		if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) == player::player_ped_id()) {
			if (!vehicle::is_vehicle_stopped(iVar0)) {
				vehicle::_set_vehicle_halt(iVar0, fParam0, iParam1, 0);
				return false;
			}
		}
		else {
			return true;
		}
	}
	if (ped::is_ped_stopped(player::player_ped_id())) {
		return true;
	}
	if (vehicle::is_vehicle_driveable(iVar0, 0)) {
		if (vehicle::is_vehicle_stopped(iVar0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x73C8
bool func_34() { return Global_91543.f_303 > 0; }

// Position - 0x73D9
bool func_35(char *sParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5, char *sParam6,
			 int iParam7, int iParam8, char *sParam9, int iParam10, int iParam11, char *sParam12, int iParam13) {
	if (!iLocal_3687) {
		iLocal_3687 = 1;
		vLocal_3478[0 /*3*/] = iParam1;
		vLocal_3478[0 /*3*/].f_1 = iParam2;
		vLocal_3478[0 /*3*/].f_2 = sParam3;
		vLocal_3478[1 /*3*/] = iParam4;
		vLocal_3478[1 /*3*/].f_1 = iParam5;
		vLocal_3478[1 /*3*/].f_2 = sParam6;
		vLocal_3478[2 /*3*/] = iParam7;
		vLocal_3478[2 /*3*/].f_1 = iParam8;
		vLocal_3478[2 /*3*/].f_2 = sParam9;
		vLocal_3478[3 /*3*/] = iParam10;
		vLocal_3478[3 /*3*/].f_1 = iParam11;
		vLocal_3478[3 /*3*/].f_2 = sParam12;
		func_58(sParam0, iParam1, iParam4, iParam7, iParam10);
		func_55(iParam1, iParam2, sParam3);
		if (iParam4 != -1) {
			func_55(iParam4, iParam5, sParam6);
		}
		if (iParam7 != -1) {
			func_55(iParam7, iParam8, sParam9);
		}
		if (iParam10 != -1) {
			func_55(iParam10, iParam11, sParam12);
		}
		if (!func_53()) {
			if (ui::is_message_being_displayed() && ui::is_subtitle_preference_switched_on()) {
				if (func_36(&uLocal_3522, "CHI2AUD", sParam0, iParam13, 1, 0, 0)) {
					iLocal_3491 = 1;
					return true;
				}
			}
			else if (func_36(&uLocal_3522, "CHI2AUD", sParam0, iParam13, 0, 0, 0)) {
				iLocal_3491 = 0;
				return true;
			}
		}
	}
	return false;
}

// Position - 0x74F6
bool func_36(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_52(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_37(sParam2, iParam3, 0);
}

// Position - 0x7544
int func_37(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_51();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_50(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_49();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_42();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_41()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_40()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_39();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_38();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_51();
	}
	return 0;
}

// Position - 0x7810
void func_38() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x7842
void func_39() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x78D7
bool func_40() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x78FE
bool func_41() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x7997
void func_42() {
	if (func_48(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_43();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x7A39
int func_43() {
	func_44();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x7A52
void func_44() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_47(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_46(player::player_ped_id());
			if (func_45(iVar0) && (!func_48(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_45(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x7B4F
bool func_45(int iParam0) { return iParam0 < 3; }

// Position - 0x7B5B
int func_46(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_47(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x7B98
int func_47(int iParam0) {
	if (func_45(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x7BC2
bool func_48(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x7BD0
void func_49() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x7C28
bool func_50(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x7C63
void func_51() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x7CBA
void func_52(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x7D10
int func_53() {
	vector3 vVar0;

	if (Global_14443.f_1 > 3) {
		return 1;
	}
	if (func_54()) {
		vVar0 = {0f, -500f, 0f};
		mobile::get_mobile_phone_position(&vVar0);
		if (Global_14388 == 0) {
			if (vVar0.y > -119f) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else if (vVar0.y > -101f) {
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x7D7E
bool func_54() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	return false;
}

// Position - 0x7D98
void func_55(int iParam0, int iParam1, char *sParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iLocal_3511) {
		if (iLocal_3511[iVar0] == iParam1) {
			func_57(&uLocal_3522, iVar0);
			iLocal_3511[iVar0] = 0;
		}
		iVar0++;
	}
	if (iLocal_3511[iParam0] != 0) {
		func_57(&uLocal_3522, iParam0);
	}
	func_56(&uLocal_3522, iParam0, iParam1, sParam2, 0, 1);
	iLocal_3511[iParam0] = iParam1;
}

// Position - 0x7DFD
void func_56(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x7E98
void func_57(var *uParam0, int iParam1) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
		(*uParam0)[iParam1 /*10*/].f_7 = 0;
	}
}

// Position - 0x7EB5
void func_58(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (gameplay::is_string_null_or_empty(sLocal_51) || !gameplay::are_strings_equal(sLocal_51, sParam0)) {
		sLocal_51 = sParam0;
		iVar0 = 0;
		while (iVar0 <= 15) {
			if (Local_89[iVar0 /*10*/].f_7) {
				if (iVar0 != iParam1 && iVar0 != iParam2 && iVar0 != iParam3 && iVar0 != iParam4) {
					func_57(&Local_89, iVar0);
				}
			}
			iVar0++;
		}
	}
}

// Position - 0x7F25
bool func_59() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return true;
	}
	return false;
}

// Position - 0x7F47
bool func_60(char *sParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5, char *sParam6,
			 int iParam7, int iParam8, char *sParam9) {
	if (!ui::is_message_being_displayed() || ui::is_subtitle_preference_switched_on()) {
		if (func_62(iParam1) != iParam2 || iParam2 == 0) {
			func_55(iParam1, iParam2, sParam3);
		}
		if (iParam4 != -1) {
			if (func_62(iParam4) != iParam5 || iParam5 == 0) {
				func_55(iParam4, iParam5, sParam6);
			}
		}
		if (iParam7 != -1) {
			if (func_62(iParam7) != iParam8 || iParam8 == 0) {
				func_55(iParam7, iParam8, sParam9);
			}
		}
		if (func_61(&uLocal_3522, 39, "CHI2AUD", sParam0, 9, 0, 0, 1)) {
			return true;
		}
	}
	return false;
}

// Position - 0x7FE7
bool func_61(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7) {
	func_52(uParam0, iParam1, sParam2, iParam5, iParam6, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	Global_2621441 = 0;
	return func_37(sParam3, iParam4, iParam7);
}

// Position - 0x8036
int func_62(int iParam0) { return iLocal_3511[iParam0]; }

// Position - 0x8045
int func_63(int iParam0) {
	if (Global_16859 || Global_16858 || Global_16860) {
		if (iParam0 == 130) {
		}
		else {
			return 0;
		}
	}
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_14443.f_1 == 10) {
			if (Global_1628 == iParam0) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x80A9
void func_64() {
	Global_14611 = 0;
	func_65();
}

// Position - 0x80B9
void func_65() {
	if (audio::is_mobile_phone_call_ongoing() || Global_14442 == 1) {
		audio::restart_scripted_conversation();
		Global_16756 = 0;
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = Global_14445;
		return;
	}
}

// Position - 0x80F0
void func_66() {
	Global_14611 = 0;
	func_51();
}

// Position - 0x8100
float func_67(int iParam0, vector3 vParam1, int iParam4) {
	vector3 vVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vParam1, iParam4);
}

// Position - 0x813A
bool func_68(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x815A
void func_69(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, vector3 vParam11,
			 int iParam14, int iParam15, int iParam16, int iParam17, int iParam18) {
	func_70(vParam0, vParam3, fParam6, vParam7, fParam10, vParam11, iParam14, iParam15, iParam16, iParam17, iParam18);
}

// Position - 0x8184
void func_70(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, vector3 vParam11,
			 bool bParam14, int iParam15, bool bParam16, bool bParam17, bool bParam18) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	int iVar3;
	vector3 vVar4;
	vector3 vVar7;
	vector3 vVar10;
	int iVar13;
	int iVar14;
	int iVar15;

	if (iParam15) {
		iParam15 = 0;
	}
	bVar2 = true;
	iVar3 = 0;
	iVar0 = player::get_players_last_vehicle();
	if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_a_mission_entity(iVar0)) {
			entity::set_entity_as_mission_entity(iVar0, 1, 0);
			iVar3 = 1;
		}
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			if (bParam18) {
				func_77(iVar0);
			}
			if (entity::is_entity_in_angled_area(iVar0, vParam0, vParam3, fParam6, 0, 1, 0)) {
				bVar1 = true;
			}
			else {
				vVar10 = {entity::get_entity_coords(iVar0, 1)};
				if (vVar10.z > vParam0.z && vVar10.z < vParam3.z || vVar10.z > vParam3.z && vVar10.z < vParam0.z) {
					if (func_74(iVar0, vParam0, vParam3, fParam6)) {
						bVar1 = true;
					}
				}
			}
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (vehicle::is_vehicle_model(iVar0, joaat("taxi"))) {
					if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != player::player_ped_id() &&
						vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != 0) {
						if (gameplay::get_distance_between_coords(vParam0 + vParam3 / FtoV(2f),
																  entity::get_entity_coords(iVar0, 1), 1) < 20f) {
							bVar1 = true;
							bVar2 = false;
						}
					}
				}
			}
			if (bParam16) {
				if (func_72(iVar0, func_43(), 1)) {
					bVar1 = false;
				}
			}
			if (bVar1) {
				if (!func_71(vParam11)) {
					if (vehicle::is_vehicle_driveable(iVar0, 0)) {
						iVar13 = entity::get_entity_model(iVar0);
						vehicle::_0xDF7E3EEB29642C38(iVar0, &vVar4, &vVar7);
						if (vehicle::is_this_model_a_heli(iVar13)) {
							vParam11.x += 3f;
							vParam11.y += 3f;
						}
						if (iVar13 == joaat("zentorno") || iVar13 == joaat("btype") || iVar13 == joaat("dubsta3") ||
							iVar13 == joaat("monster")) {
							vParam11 = {vParam11 * FtoV(1.1f)};
						}
						else if (iVar13 == joaat("t20") || iVar13 == joaat("virgo")) {
							vParam11 = {vParam11 * FtoV(1.2f)};
						}
						if (vVar7.x - vVar4.x > vParam11.x) {
							bVar2 = false;
						}
						else if (vVar7.y - vVar4.y > vParam11.y) {
							bVar2 = false;
						}
						else if (vVar7.z - vVar4.z > vParam11.z) {
							bVar2 = false;
						}
					}
				}
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (bVar2) {
						gameplay::clear_area_of_vehicles(vParam7, 5f, 0, 0, 0, 0, 0);
						entity::set_entity_heading(iVar0, fParam10);
						entity::set_entity_coords(iVar0, vParam7, 1, 0, 0, 1);
						vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
						if (bParam17) {
							vehicle::set_vehicle_engine_on(iVar0, 0, 1, 0);
							vehicle::set_vehicle_doors_shut(iVar0, 1);
						}
					}
					else {
						if (!entity::is_entity_a_mission_entity(iVar0) ||
							!entity::does_entity_belong_to_this_script(iVar0, 1)) {
							entity::set_entity_as_mission_entity(iVar0, 1, 1);
						}
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
							entity::set_entity_coords(player::player_ped_id(), entity::get_entity_coords(iVar0, 1), 1,
													  0, 0, 1);
						}
						vehicle::delete_vehicle(&iVar0);
					}
				}
			}
			if (bParam14) {
				gameplay::clear_angled_area_of_vehicles(vParam0, vParam3, fParam6, 0, 0, 0, 0, 0);
			}
			if (iVar3 == 1) {
				if (entity::does_entity_exist(iVar0)) {
					if (entity::is_entity_a_mission_entity(iVar0)) {
						entity::set_vehicle_as_no_longer_needed(&iVar0);
					}
				}
			}
		}
		else {
			if (!entity::is_entity_a_mission_entity(iVar0)) {
				entity::set_entity_as_mission_entity(iVar0, 1, 0);
			}
			iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0);
			if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
				entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
			}
			iVar15 = vehicle::get_vehicle_model_number_of_seats(entity::get_entity_model(iVar0));
			if (iVar15 <= 2) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			if (iVar15 <= 4) {
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 1, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
				iVar14 = vehicle::get_ped_in_vehicle_seat(iVar0, 2, 0);
				if (entity::does_entity_exist(iVar14) && !ped::is_ped_injured(iVar14)) {
					entity::set_entity_coords(iVar14, entity::get_entity_coords(iVar14, 1), 1, 0, 0, 1);
				}
			}
			vehicle::delete_vehicle(&iVar0);
		}
	}
}

// Position - 0x8576
bool func_71(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return true;
	}
	return false;
}

// Position - 0x85A0
bool func_72(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_73(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x8611
bool func_73(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x86EA
bool func_74(int iParam0, vector3 vParam1, vector3 vParam4, float fParam7) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18[4];
	struct<2> Var31;
	struct<2> Var34;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		vParam1.z = vParam4.z;
		vVar0 = {func_76(vParam1 - vParam4)};
		vVar3 = {vVar0};
		vVar0.x = -vVar3.y;
		vVar0.y = vVar3.x;
		vVar0.z = 0f;
		vVar6 = {vParam1 - vVar0 * FtoV(fParam7 / 2f)};
		vVar9 = {vParam1 + vVar0 * FtoV(fParam7 / 2f)};
		vVar12 = {vParam4 - vVar0 * FtoV(fParam7 / 2f)};
		vVar15 = {vParam4 + vVar0 * FtoV(fParam7 / 2f)};
		gameplay::get_model_dimensions(entity::get_entity_model(iParam0), &Var31, &Var34);
		vVar18[0 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var31.f_1, 0f)};
		vVar18[1 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var31, Var34.f_1, 0f)};
		vVar18[2 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var31.f_1, 0f)};
		vVar18[3 /*3*/] = {entity::get_offset_from_entity_in_world_coords(iParam0, Var34, Var34.f_1, 0f)};
		if (func_75(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar9) ||
			func_75(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar9, vVar15) ||
			func_75(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar12, vVar15) ||
			func_75(vVar18[0 /*3*/], vVar18[1 /*3*/], vVar6, vVar12) ||
			func_75(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar9) ||
			func_75(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar9, vVar15) ||
			func_75(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar12, vVar15) ||
			func_75(vVar18[1 /*3*/], vVar18[3 /*3*/], vVar6, vVar12) ||
			func_75(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar9) ||
			func_75(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar9, vVar15) ||
			func_75(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar12, vVar15) ||
			func_75(vVar18[3 /*3*/], vVar18[2 /*3*/], vVar6, vVar12) ||
			func_75(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar9) ||
			func_75(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar9, vVar15) ||
			func_75(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar12, vVar15) ||
			func_75(vVar18[2 /*3*/], vVar18[0 /*3*/], vVar6, vVar12)) {
			return true;
		}
	}
	return false;
}

// Position - 0x89E0
int func_75(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5, struct<2> Param6, var uParam8,
			struct<2> Param9, var uParam11) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;

	fVar0 = Param0;
	fVar1 = Param0.f_1;
	fVar2 = Param3;
	fVar3 = Param3.f_1;
	fVar4 = Param6;
	fVar5 = Param6.f_1;
	fVar6 = Param9;
	fVar7 = Param9.f_1;
	fVar8 = fVar2 - fVar0;
	fVar9 = fVar3 - fVar1;
	fVar10 = fVar6 - fVar4;
	fVar11 = fVar7 - fVar5;
	fVar12 = (-fVar9 * (fVar0 - fVar4) + fVar8 * (fVar1 - fVar5)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	fVar13 = (fVar10 * (fVar1 - fVar5) - fVar11 * (fVar0 - fVar4)) / (-fVar10 * fVar9 + fVar8 * fVar11);
	if (fVar12 >= 0f && fVar12 <= 1f && fVar13 >= 0f && fVar13 <= 1f) {
		return 1;
	}
	return 0;
}

// Position - 0x8A94
Vector3 func_76(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x8AD3
void func_77(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_vehicle_engine_health(iParam0) <= 200f) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
			if (vehicle::get_vehicle_petrol_tank_health(iParam0) <= 700f) {
				vehicle::set_vehicle_engine_health(iParam0, 900f);
			}
			if (entity::get_entity_health(iParam0) < 200) {
				vehicle::set_vehicle_engine_health(iParam0, 500f);
			}
		}
	}
}

// Position - 0x8B38
void func_78() {
	if (iLocal_2511 >= 3) {
		if (iLocal_2511 > 3) {
			func_103(&Local_1619, &vLocal_2274, vLocal_2253, vLocal_2256, vLocal_2259, vLocal_2262, vLocal_2250,
					 vLocal_2271, vLocal_2244, vLocal_2247, vLocal_2265, vLocal_2268);
		}
		func_79();
	}
}

// Position - 0x8B8E
void func_79() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = 0;
	while (iVar0 < Local_1619) {
		if (!ped::is_ped_injured(Local_755[iVar0 /*33*/]) && !ped::is_ped_dead_or_dying(Local_755[iVar0 /*33*/], 1) ||
			Local_1619[iVar0 /*24*/].f_3 == 1) {
			switch (Local_1619[iVar0 /*24*/].f_3) {
			case 1:
				switch (Local_755[iVar0 /*33*/].f_1) {
				case 1:
					switch (Local_755[iVar0 /*33*/].f_2) {
					case 2:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2451.818f, 4985.704f, 50.5678f, 227.842f,
									 joaat("weapon_assaultrifle"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
							func_99(iVar0, 5, 0, 0);
						}
						break;

					case 1:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2455.085f, 4974.466f, 50.5677f, 246.051f,
									 joaat("weapon_assaultrifle"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
							func_99(iVar0, 14, 0, 0);
						}
						break;

					case 6:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2461.609f, 4993.675f, 44.9821f, -90f,
									 joaat("weapon_assaultrifle"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							func_99(iVar0, 7, 0, 0);
							Local_755[iVar0 /*33*/].f_4 = 7;
						}
						break;

					case 7:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2462.887f, 4993.614f, 44.9474f, 89.8899f,
									 joaat("weapon_assaultrifle"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							func_99(iVar0, 7, 1, 0);
							Local_755[iVar0 /*33*/].f_4 = 7;
						}
						break;

					case 3:
						if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2460.651f, 4970.813f, 45.5765f, 240.2054f,
									 joaat("weapon_assaultrifle"), 0, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 0, 0);
							func_99(iVar0, 16, 0, 0);
						}
						break;

					case 0:
						if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2443.138f, 4966.709f, 50.5677f, 246.051f,
									 joaat("weapon_assaultrifle"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 1, 0);
							func_99(iVar0, 15, 0, 0);
						}
						break;

					case 4:
						if (iLocal_2511 == 3) {
							if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2457.098f, 4954.283f, 44.1304f, 316.5498f,
										 joaat("weapon_pistol"), 0, 0)) {
								Local_755[iVar0 /*33*/].f_20 = object::create_object(
									joaat("prop_cs_fertilizer"), 2460.098f, 4957.283f, 44.1304f, 1, 1, 0);
								Local_755[iVar0 /*33*/].f_5 = 1;
								func_99(iVar0, 3, 0, 0);
							}
						}
						else if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2478.32f, 4982.325f, 44.8913f, 49.5021f,
										  joaat("weapon_pistol"), 0, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							Local_755[iVar0 /*33*/].f_20 = object::create_object(joaat("prop_cs_fertilizer"), 2478.444f,
																				 4976.921f, 44.5614f, 1, 1, 0);
							Local_755[iVar0 /*33*/].f_5 = 1;
							func_99(iVar0, 2, 0, 0);
						}
						break;

					case 5:
						if (iLocal_2511 == 3) {
							if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2454.753f, 4951.719f, 44.1445f, 316.5541f,
										 joaat("weapon_pistol"), 0, 0)) {
								Local_755[iVar0 /*33*/].f_20 = object::create_object(
									joaat("prop_cs_fertilizer"), 2455.753f, 4952.719f, 44.1445f, 1, 1, 0);
								Local_755[iVar0 /*33*/].f_5 = 1;
								func_99(iVar0, 3, 0, 0);
							}
						}
						else if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2475.873f, 4984.426f, 45.0916f, 45.8993f,
										  joaat("weapon_pistol"), 0, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							Local_755[iVar0 /*33*/].f_20 = object::create_object(joaat("prop_cs_fertilizer"), 2476.582f,
																				 4978.492f, 44.5734f, 1, 1, 0);
							Local_755[iVar0 /*33*/].f_5++;
							func_99(iVar0, 2, 0, 0);
						}
						break;

					case 8:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2505.451f, 4970.663f, 43.548f, 49.5021f,
									 joaat("weapon_pistol"), 1, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							Local_755[iVar0 /*33*/].f_14 =
								ped::create_synchronized_scene(2505.451f, 4970.663f, 43.548f, 0f, 0f, 88.725f, 2);
							func_98(Local_755[iVar0 /*33*/], 20f, 5f, 90f, -90f, 60f);
							audio::set_ambient_voice_name(Local_755[iVar0 /*33*/], "A_M_M_HillBilly_02_WHITE_MINI_02");
							ai::task_synchronized_scene(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_14,
														"misschinese2_bank5", "peds_shootcans_a", 1000f, -4f, 1, 0,
														1148846080, 0);
							ped::set_synchronized_scene_looped(Local_755[iVar0 /*33*/].f_14, 1);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							func_99(iVar0, 4, 0, Local_755[iVar0 /*33*/].f_14);
							func_32(7, 0);
						}
						break;

					case 9:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2505.451f, 4970.663f, 43.548f, 49.5021f,
									 joaat("weapon_pistol"), 1, 0)) {
							Local_755[iVar0 /*33*/].f_14 =
								ped::create_synchronized_scene(2507.879f, 4970.188f, 43.5f, 0f, 0f, 93.42f, 2);
							ped::set_synchronized_scene_looped(Local_755[iVar0 /*33*/].f_14, 1);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							ai::task_synchronized_scene(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_14,
														"misschinese2_bank5", "peds_shootcans_b", 1000f, -4f, 1, 0,
														1148846080, 0);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							func_99(iVar0, 4, 0, Local_755[iVar0 /*33*/].f_14);
						}
						break;
					}
					if (entity::does_entity_exist(Local_755[iVar0 /*33*/])) {
						entity::set_entity_load_collision_flag(Local_755[iVar0 /*33*/], 1);
						ped::set_ped_to_load_cover(Local_755[iVar0 /*33*/], 1);
					}
					break;

				case 2:
					switch (Local_755[iVar0 /*33*/].f_2) {
					case 10:
						if (iLocal_2511 < 5) {
							if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2458.57f, 4987.584f, 45.8107f, 233.842f,
										 joaat("weapon_pistol"), 0, 0)) {
								func_99(iVar0, 14, 0, 0);
								func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
							}
						}
						else if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2454.627f, 4995.726f, 45.2011f, 233.842f,
										  joaat("weapon_pistol"), 0, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
							func_99(iVar0, 23, 0, 0);
						}
						break;

					case 11:
						if (iLocal_2511 < 5) {
							if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2442.994f, 4985.164f, 45.8103f, 303.409f,
										 joaat("weapon_microsmg"), 0, 0)) {
								func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 1, 0);
								func_99(iVar0, 14, 0, 0);
							}
						}
						else if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2450.371f, 4995.103f, 44.9282f, 303.409f,
										  joaat("weapon_microsmg"), 0, 0)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 1, 0);
							func_99(iVar0, 23, 0, 0);
						}
						break;

					case 12:
						if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2433.124f, 4967.804f, 46.293f, 63.7673f,
									 joaat("weapon_pumpshotgun"), 0, 1)) {
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 13:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2432.091f, 4968.833f, 46.298f, 63.7673f,
									 joaat("weapon_pistol"), 0, 1)) {
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 14:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2431.485f, 4964.779f, 45.8106f, -137.5f,
									 joaat("weapon_pistol"), 0, 1)) {
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 15:
						if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2440.385f, 4965.429f, 45.8106f, 63.7673f,
									 joaat("weapon_pumpshotgun"), 0, 1)) {
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 16:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2439.741f, 4964.89f, 45.8106f, 130.3988f,
									 joaat("weapon_microsmg"), 0, 1)) {
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 17:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2438.707f, 4964.094f, 45.8106f, 127.6523f,
									 joaat("weapon_pistol"), 0, 1)) {
							ped::set_ped_accuracy(Local_755[iVar0 /*33*/], 5);
							func_99(iVar0, 25, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 1, 0);
						}
						break;

					case 18:
						if (iLocal_2511 < 5) {
							if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2440.929f, 4976.921f, 45.8106f, -130f,
										 joaat("weapon_pistol"), 0, 1)) {
								func_99(iVar0, 7, 0, 0);
								Local_755[iVar0 /*33*/].f_4 = 7;
								func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							}
						}
						else if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2452.052f, 4956.689f, 43.8957f, 230.7673f,
										  joaat("weapon_pistol"), 0, 1)) {
							func_99(iVar0, 23, 0, 0);
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
						}
						break;

					case 19:
						if (iLocal_2511 < 5) {
							if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2442.926f, 4975.148f, 45.8106f, 46.7673f,
										 joaat("weapon_pistol"), 0, 1)) {
								func_99(iVar0, 7, 0, 0);
								func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
								Local_755[iVar0 /*33*/].f_4 = 7;
							}
						}
						else if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2449.338f, 4954.127f, 43.9299f, 46.7673f,
										  joaat("weapon_pistol"), 0, 1)) {
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 0, 0, 0);
							func_99(iVar0, 23, 0, 0);
						}
						break;

					case 20:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2449.114f, 4981.984f, 45.8102f, 130.7673f,
									 joaat("weapon_microsmg"), 0, 1)) {
							func_99(iVar0, 7, 0, 0);
							Local_755[iVar0 /*33*/].f_4 = 32;
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 0, 0);
						}
						break;

					case 21:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_02"), 2447.553f, 4980.515f, 45.8096f, 311.7673f,
									 joaat("weapon_microsmg"), 0, 1)) {
							func_99(iVar0, 7, 0, 0);
							Local_755[iVar0 /*33*/].f_4 = 7;
							func_100(&Local_1619, iVar0, Local_755[iVar0 /*33*/], 1, 0, 0);
						}
						break;
					}
					if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
						entity::set_entity_load_collision_flag(Local_755[iVar0 /*33*/], 1);
					}
					break;

				case 5:
					switch (Local_755[iVar0 /*33*/].f_2) {
					case 22:
						if (func_101(iVar0, joaat("a_m_m_hillbilly_01"), 2439.258f, 4976.201f, 45.8106f, 116.815f,
									 joaat("weapon_unarmed"), 0, 1)) {
							func_99(iVar0, 28, 0, 0);
						}
						break;

					case 23:
						if (func_101(iVar0, joaat("a_m_y_methhead_01"), 2433.292f, 4968.534f, 42.348f, 105.5f,
									 joaat("weapon_unarmed"), 0, 1)) {
							func_99(iVar0, 30, 0, 0);
						}
						break;
					}
					break;
				}
				if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
					entity::_set_entity_register(Local_755[iVar0 /*33*/], 1);
					Local_1619[iVar0 /*24*/].f_3 = 3;
					iVar0--;
				}
				break;

			case 3:
				if (Local_1619[iVar0 /*24*/].f_3 <= 3) {
					switch (Local_755[iVar0 /*33*/].f_3) {
					case 3:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
								if (entity::does_entity_have_drawable(Local_755[iVar0 /*33*/].f_20) &&
									entity::does_entity_have_physics(Local_755[iVar0 /*33*/].f_20)) {
									entity::attach_entity_to_entity(
										Local_755[iVar0 /*33*/].f_20, Local_755[iVar0 /*33*/],
										ped::get_ped_bone_index(Local_755[iVar0 /*33*/], 60309), 0f, 0f, 0f, 0f, 0f, 0f,
										1, 1, 0, 0, 2, 1);
									Local_755[iVar0 /*33*/].f_5++;
								}
								if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
									if (Local_755[iVar0 /*33*/].f_2 == 4) {
										ai::task_play_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_B", 1000f, -1f, -1, 1, 0, 0, 0, 0);
									}
									else {
										ai::task_play_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_A", 1000f, -1f, -1, 1, 0, 0, 0, 0);
									}
									entity::set_entity_load_collision_flag(Local_755[iVar0 /*33*/], 1);
									ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 1: break;
						}
						break;

					case 2:
						if (Local_755[iVar0 /*33*/].f_5 < 7) {
							func_97(Local_755[iVar0 /*33*/], &Local_755[iVar0 /*33*/].f_25, -1, 0, 1, 0, -1082130432, 0,
									-1, -1, 1);
						}
						if (entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_B", 3)) {
							entity::set_entity_anim_speed(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														  "barrel_roll_loop_B", 1.4f);
						}
						if (entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_A", 3)) {
							entity::set_entity_anim_speed(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														  "barrel_roll_loop_A", 1.4f);
						}
						if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
							if (Local_755[iVar0 /*33*/].f_5 > 2 && Local_755[iVar0 /*33*/].f_5 <= 6) {
								if (entity::is_entity_attached(Local_755[iVar0 /*33*/].f_20)) {
									Local_755[iVar0 /*33*/].f_12 =
										func_96(entity::get_entity_coords(Local_755[iVar0 /*33*/], 1),
												Local_755[iVar0 /*33*/].f_6, 1) -
										entity::get_entity_heading(Local_755[iVar0 /*33*/]);
									Local_755[iVar0 /*33*/].f_12 =
										func_95(Local_755[iVar0 /*33*/].f_12 / 4f, -15f, 15f);
									if (!ped::is_ped_ragdoll(Local_755[iVar0 /*33*/])) {
										entity::set_entity_heading(Local_755[iVar0 /*33*/],
																   entity::get_entity_heading(Local_755[iVar0 /*33*/]) +
																	   system::timestep() *
																		   Local_755[iVar0 /*33*/].f_12);
									}
								}
							}
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
								if (entity::does_entity_have_drawable(Local_755[iVar0 /*33*/].f_20) &&
									entity::does_entity_have_physics(Local_755[iVar0 /*33*/].f_20)) {
									entity::attach_entity_to_entity(
										Local_755[iVar0 /*33*/].f_20, Local_755[iVar0 /*33*/],
										ped::get_ped_bone_index(Local_755[iVar0 /*33*/], 60309), 0f, 0f, 0f, 0f, 0f, 0f,
										1, 1, 0, 0, 2, 1);
									func_32(20, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
							}

						case 1:
							if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
								if (func_67(Local_755[iVar0 /*33*/], 2495.779f, 5004.715f, 43.87337f, 1) < 99f) {
									if (Local_755[iVar0 /*33*/].f_2 == 4) {
										ai::task_play_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_B", 1000f, -1f, -1, 1, 0, 0, 0, 0);
									}
									else {
										ai::task_play_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
														   "barrel_roll_loop_A", 1000f, -1f, -1, 1, 0, 0, 0, 0);
									}
									ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
									entity::set_entity_load_collision_flag(Local_755[iVar0 /*33*/], 1);
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 2:
							if (entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
															   "barrel_roll_loop_B", 3) ||
								entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
															   "barrel_roll_loop_A", 3)) {
								Local_755[iVar0 /*33*/].f_6 = {2466.903f, 4996.254f, 45.5443f};
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 3:
							if (entity::is_entity_at_coord(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_6, 1.5f,
														   1.5f, 2f, 0, 1, 0)) {
								Local_755[iVar0 /*33*/].f_6 = {2461.332f, 4998.94f, 45.359f};
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 4:
							if (entity::is_entity_at_coord(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_6, 1.5f,
														   1.5f, 2f, 0, 1, 0)) {
								Local_755[iVar0 /*33*/].f_6 = {2455.984f, 4997.404f, 45.2645f};
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 5:
							if (entity::is_entity_at_coord(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_6, 1.5f,
														   1.5f, 2f, 0, 1, 0)) {
								if (Local_755[iVar0 /*33*/].f_2 == 5) {
									Local_755[iVar0 /*33*/].f_6 = {2452.091f, 4993.674f, 45.1404f};
									Local_755[iVar0 /*33*/].f_5++;
								}
								else {
									Local_755[iVar0 /*33*/].f_6 = {2454.091f, 4995.674f, 45.1404f};
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 6:
							if (entity::is_entity_at_coord(Local_755[iVar0 /*33*/], Local_755[iVar0 /*33*/].f_6, 1.5f,
														   1.5f, 2f, 0, 1, 0)) {
								if (entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
																   "barrel_roll_loop_B", 3)) {
									ai::stop_anim_task(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
													   "barrel_roll_loop_B", -1.5f);
								}
								if (entity::is_entity_playing_anim(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
																   "barrel_roll_loop_A", 3)) {
									ai::stop_anim_task(Local_755[iVar0 /*33*/], "misschinese2_barrelroll",
													   "barrel_roll_loop_A", -1.5f);
								}
								Local_755[iVar0 /*33*/].f_6 = {0f, 0f, 0f};
								if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
									entity::detach_entity(Local_755[iVar0 /*33*/].f_20, 0, 1);
								}
								if (func_68(iLocal_2507)) {
									if (Local_755[iVar0 /*33*/].f_2 == 4) {
										ped::set_ped_movement_clipset(Local_755[iVar0 /*33*/], "move_m@gangster@var_e",
																	  1048576000);
										ai::task_enter_vehicle(Local_755[iVar0 /*33*/], iLocal_2507, -1, -1, 1f, 1, 0);
										func_99(func_18(6), 14, 0, 0);
										func_99(func_18(7), 33, 0, 0);
									}
									else {
										ped::set_ped_movement_clipset(Local_755[iVar0 /*33*/], "move_m@gangster@var_f",
																	  1048576000);
										ai::task_enter_vehicle(Local_755[iVar0 /*33*/], iLocal_2507, -1, 0, 1f, 1, 0);
									}
								}
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_14 = 0;
								Local_755[iVar0 /*33*/].f_15 = 0;
							}
							break;

						case 7:
							func_94(iVar0);
							if (ped::is_ped_in_any_vehicle(Local_755[iVar0 /*33*/], 0)) {
								entity::set_entity_load_collision_flag(Local_755[iVar0 /*33*/], 0);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 8:
							if (func_68(iLocal_2507)) {
								if (!vehicle::is_vehicle_seat_free(iLocal_2507, -1, 0)) {
									if (Local_755[iVar0 /*33*/].f_2 == 4) {
										if (!vehicle::is_vehicle_seat_free(iLocal_2507, 0, 0)) {
											iVar1 = func_18(5);
											if (iVar1 >= 0) {
												if (!ped::is_ped_injured(Local_755[iVar1 /*33*/])) {
													if (ped::is_ped_sitting_in_any_vehicle(Local_755[iVar1 /*33*/
													])) {
														func_93();
														ai::task_vehicle_drive_to_coord(
															0, iLocal_2507, 2367.668f, 5098.645f, 46.8185f, 12f, 0,
															joaat("burrito"), 786599, 5f, 5f);
														ai::task_vehicle_drive_wander(0, iLocal_2507, 19f, 786599);
														func_92(&Local_755[iVar0 /*33*/], 0);
														func_91(25, 1);
														Local_755[iVar0 /*33*/].f_5++;
													}
												}
											}
										}
									}
								}
								if (!vehicle::is_vehicle_seat_free(iLocal_2507, 0, 0)) {
									if (Local_755[iVar0 /*33*/].f_2 == 5) {
										Local_755[iVar0 /*33*/].f_5++;
									}
								}
							}
							break;

						case 9: break;
						}
						break;

					case 5:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							func_93();
							ai::task_follow_nav_mesh_to_coord(0, 2459.646f, 4977.735f, 50.5678f, 1f, 20000, 1048576000,
															  0, 1193033728);
							ai::task_follow_nav_mesh_to_coord(0, 2456.221f, 4974.685f, 50.5678f, 1f, 20000, 1048576000,
															  0, 1193033728);
							ai::task_ped_slide_to_coord(0, 2456.221f, 4974.685f, 50.5678f, 92.5678f, 1061158912);
							ai::task_achieve_heading(0, 92.5678f, 0);
							func_92(&Local_755[iVar0 /*33*/], 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 242628503) == 7) {
								func_99(iVar0, 7, 0, 9000);
								iVar2 = 1;
								if (iVar2 != -1) {
									func_99(iVar2, 7, 0, 9000);
								}
							}
							break;

						case 2:
							func_93();
							ai::task_follow_nav_mesh_to_coord(0, 2450.491f, 4986.83f, 50.5677f, 1f, 20000, 1048576000,
															  0, 1193033728);
							ai::task_achieve_heading(0, 309.5567f, 0);
							ai::task_pause(0, 2000);
							func_92(&Local_755[iVar0 /*33*/], 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 3:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 242628503) == 7) {
								Local_755[iVar0 /*33*/].f_5 = 0;
							}
							break;
						}
						break;

					case 6:
						if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 993674639) == 7 &&
							Local_755[iVar0 /*33*/].f_5 > 1) {
							Local_755[iVar0 /*33*/].f_5 = 0;
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							weapon::set_current_ped_weapon(Local_755[iVar0 /*33*/], joaat("weapon_unarmed"), 1);
							ai::task_achieve_heading(Local_755[iVar0 /*33*/], 219f, 1500);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 1920390111) == 7) {
								ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/],
																 "WORLD_HUMAN_GUARD_STAND_ARMY", 0, 0);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;
						}
						break;

					case 32:
						if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
							if (Local_755[iVar0 /*33*/].f_1 == 1 ||
								func_4(player::player_ped_id(), Local_755[iVar0 /*33*/], 1) < 20f) {
								func_97(Local_755[iVar0 /*33*/], &Local_755[iVar0 /*33*/].f_25, -1, 0, 1, 0,
										-1082130432, 0, -1, -1, 1);
							}
							if (Local_755[iVar0 /*33*/].f_5 < 10) {
							}
							switch (Local_755[iVar0 /*33*/].f_5) {
							case 0:
								ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_AA_SMOKE",
																 Local_755[iVar0 /*33*/].f_14, 0);
								Local_755[iVar0 /*33*/].f_5++;
								break;

							case 1:
								if (func_4(player::player_ped_id(), Local_755[iVar0 /*33*/], 1) < 10f) {
									iVar3 = gameplay::get_random_int_in_range(0, 3);
									if (iVar3 == 0) {
										audio::_play_ambient_speech_with_voice(
											Local_755[iVar0 /*33*/], "GENERIC_CURSE_MED",
											"A_M_M_Hillbilly_01_White_mini_03", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
									}
									else if (iVar3 == 1) {
										audio::_play_ambient_speech_with_voice(
											Local_755[iVar0 /*33*/], "GENERIC_INSULT_MED",
											"A_M_M_Hillbilly_01_White_mini_03", "SPEECH_PARAMS_FORCE_SHOUTED", 0);
									}
									else {
										audio::_play_ambient_speech_with_voice(Local_755[iVar0 /*33*/], "CHAT_STATE",
																			   "A_M_M_Hillbilly_01_White_mini_03",
																			   "SPEECH_PARAMS_FORCE_SHOUTED", 0);
									}
									Local_755[iVar0 /*33*/].f_5++;
									Local_755[iVar0 /*33*/].f_14 =
										gameplay::get_game_timer() + gameplay::get_random_int_in_range(5000, 10000);
								}
								break;

							case 2:
								if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
									Local_755[iVar0 /*33*/].f_5 = 1;
								}
								break;

							case 10:
								if (func_35("CHI2_hear", 8, Local_755[iVar0 /*33*/], "ONEILGUARD1", -1, 0, 0, -1, 0, 0,
											-1, 0, 0, 8)) {
									Local_755[iVar0 /*33*/].f_5++;
									Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 1000;
								}
								break;

							case 11:
								if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
									ai::task_turn_ped_to_face_coord(
										Local_755[iVar0 /*33*/], entity::get_entity_coords(player::player_ped_id(), 1),
										5000);
									Local_755[iVar0 /*33*/].f_5++;
									Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 5000;
								}
								break;

							case 12:
								if (player::can_ped_hear_player(player::player_id(), Local_755[iVar0 /*33*/]) &&
									func_67(Local_755[iVar0 /*33*/], 2448.003f, 4982.305f, 45.8519f, 1) < 10f) {
									if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14 - 3000) {
										ai::task_follow_nav_mesh_to_coord(
											Local_755[iVar0 /*33*/],
											entity::get_entity_coords(player::player_ped_id(), 1), 1f, 20000,
											1048576000, 0, 1193033728);
										Local_755[iVar0 /*33*/].f_5 = 15;
									}
								}
								else if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
									if (func_35("CHI2_nope", 8, Local_755[iVar0 /*33*/], "ONEILGUARD1", -1, 0, 0, -1, 0,
												0, -1, 0, 0, 8)) {
										Local_755[iVar0 /*33*/].f_5++;
									}
								}
								break;

							case 13:
								func_93();
								ai::task_follow_nav_mesh_to_coord(0, 2449.114f, 4981.984f, 45.8102f, 1f, 20000,
																  1048576000, 0, 1193033728);
								ai::task_achieve_heading(0, 127.6328f, 3000);
								func_92(&Local_755[iVar0 /*33*/], 0);
								Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 3000;
								Local_755[iVar0 /*33*/].f_5++;
								break;

							case 14:
								if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14 ||
									ai::get_script_task_status(Local_755[iVar0 /*33*/], 242628503) == 7) {
									Local_755[iVar0 /*33*/].f_5 = 0;
								}
								break;

							case 15:
								if (func_35("CHI2_hear", 8, Local_755[iVar0 /*33*/], "ONEILGUARD1", -1, 0, 0, -1, 0, 0,
											-1, 0, 0, 8)) {
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 16:
								if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 713668775) == 7) {
									Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 3000;
									Local_755[iVar0 /*33*/].f_5 = 12;
								}
								break;
							}
						}
						break;

					case 33:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 3000;
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
								if (func_68(iLocal_2507)) {
									ai::task_enter_vehicle(Local_755[iVar0 /*33*/], iLocal_2507, 20000, 1, 1f, 1, 0);
									Local_755[iVar0 /*33*/].f_5++;
									Local_755[iVar0 /*33*/].f_14 = 0;
									Local_755[iVar0 /*33*/].f_15 = 0;
								}
							}
							break;

						case 2: func_94(iVar0); break;
						}
						break;

					case 7:
						if (Local_755[iVar0 /*33*/].f_1 == 1 ||
							func_4(player::player_ped_id(), Local_755[iVar0 /*33*/], 1) < 20f) {
							func_97(Local_755[iVar0 /*33*/], &Local_755[iVar0 /*33*/].f_25, -1, 0, 1, 0, -1082130432, 0,
									-1, -1, 1);
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							iVar4 = joaat("weapon_unarmed");
							if (weapon::get_current_ped_weapon(Local_755[iVar0 /*33*/], &iVar4, 1)) {
								ai::task_swap_weapon(Local_755[iVar0 /*33*/], 0);
							}
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (!weapon::get_current_ped_weapon(Local_755[iVar0 /*33*/], &iVar4, 1)) {
								func_93();
								if (iVar0 == 1) {
									if (!ped::is_ped_injured(Local_755[2 /*33*/])) {
										ai::task_turn_ped_to_face_entity(0, Local_755[2 /*33*/], 2000);
									}
								}
								else if (iVar0 == 2) {
									if (!ped::is_ped_injured(Local_755[1 /*33*/])) {
										ai::task_turn_ped_to_face_entity(0, Local_755[1 /*33*/], 2000);
									}
								}
								else if (iVar0 == 6) {
									if (!ped::is_ped_injured(Local_755[7 /*33*/])) {
										ai::task_turn_ped_to_face_entity(0, Local_755[7 /*33*/], 2000);
									}
								}
								else if (iVar0 == 7) {
									if (!ped::is_ped_injured(Local_755[6 /*33*/])) {
										ai::task_turn_ped_to_face_entity(0, Local_755[6 /*33*/], 2000);
									}
								}
								if (Local_755[iVar0 /*33*/].f_14 != 0) {
									ai::task_start_scenario_in_place(0, "WORLD_HUMAN_HANG_OUT_STREET",
																	 Local_755[iVar0 /*33*/].f_14, 0);
								}
								else {
									ai::task_start_scenario_in_place(0, "WORLD_HUMAN_HANG_OUT_STREET", 0, 0);
								}
								func_92(&Local_755[iVar0 /*33*/], 0);
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_15 = gameplay::get_game_timer() + 15000;
							}
							break;

						case 2:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 242628503) == 7 ||
								gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_15) {
								ai::clear_ped_tasks(Local_755[iVar0 /*33*/]);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 3:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 242628503) == 7) {
								if (Local_755[iVar0 /*33*/].f_4 == 5) {
									ai::task_swap_weapon(Local_755[iVar0 /*33*/], 1);
									Local_755[iVar0 /*33*/].f_5++;
								}
								else {
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 4:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 716706914) == 7) {
								if (Local_755[iVar0 /*33*/].f_4 == 5) {
									func_99(iVar0, Local_755[iVar0 /*33*/].f_4, 2, 0);
								}
								else {
									func_99(iVar0, Local_755[iVar0 /*33*/].f_4, 0, 0);
								}
							}
							break;
						}
						break;

					case 13:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_GUARD_STAND", 0, 0);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;
						}
						break;

					case 14:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_AA_SMOKE", 0, 0);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 993674639) == 7) {
								Local_755[iVar0 /*33*/].f_5 = 0;
							}
							break;
						}
						break;

					case 15:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_BINOCULARS", 0, 0);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;
						}
						break;

					case 16:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_DRINKING", 0, 0);
							ped::_0x2208438012482A1A(Local_755[iVar0 /*33*/], 0, 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;
						}
						break;

					case 17:
						if (Local_755[iVar0 /*33*/].f_5 < 10) {
							if (player::can_ped_hear_player(player::player_id(), Local_755[iVar0 /*33*/])) {
								Local_755[iVar0 /*33*/].f_5 = 10;
							}
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							streaming::request_anim_dict("misscarsteal2peeing");
							Local_755[iVar0 /*33*/].f_5++;
							Local_755[iVar0 /*33*/].f_14 = 0;
							break;

						case 1:
							if (streaming::has_anim_dict_loaded("misscarsteal2peeing")) {
								ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_DRINKING", 0, 1);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 2:
							if (func_4(player::player_ped_id(), Local_755[iVar0 /*33*/], 1) < 21.6f) {
								ai::task_play_anim(Local_755[iVar0 /*33*/], "misscarsteal2peeing", "peeing_loop", 8f,
												   -8f, 25000, 1, 0, 0, 0, 0);
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 23000;
							}
							break;

						case 3:
							if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
								Local_755[iVar0 /*33*/].f_14 = -1;
								ai::task_start_scenario_in_place(Local_755[iVar0 /*33*/], "WORLD_HUMAN_DRINKING", 0, 1);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;
						}
						break;

					case 18:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							func_93();
							ai::task_follow_nav_mesh_to_coord(0, 2434.891f, 4973.864f, 50.5679f, 1f, 20000, 1048576000,
															  0, 1193033728);
							ai::task_start_scenario_in_place(0, "WORLD_HUMAN_BINOCULARS", 0, 0);
							func_92(&Local_755[iVar0 /*33*/], 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;
						}
						break;

					case 25:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							switch (Local_755[iVar0 /*33*/].f_2) {
							case 12:
								if (ai::does_scenario_exist_in_area(2433.04f, 4967.87f, 46.28f, 0.8f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2433.04f,
																				4967.87f, 46.28f, 0.8f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 13:
								if (ai::does_scenario_exist_in_area(2432.56f, 4968.38f, 46.27f, 0.8f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2432.56f,
																				4968.38f, 46.27f, 0.8f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 14:
								if (ai::does_scenario_exist_in_area(2433.12f, 4965.59f, 46.27f, 0.8f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2433.12f,
																				4965.59f, 46.27f, 0.8f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 15:
								if (ai::does_scenario_exist_in_area(2439.61f, 4960.99f, 46.27f, 0.4f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2439.697f,
																				4960.996f, 46.28f, 0.4f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 16:
								if (ai::does_scenario_exist_in_area(2440.16f, 4962.99f, 46.27f, 0.4f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2440.16f,
																				4962.99f, 46.27f, 0.4f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;

							case 17:
								if (ai::does_scenario_exist_in_area(2438.23f, 4962.25f, 46.27f, 0.4f, 0)) {
									ai::task_use_nearest_scenario_to_coord_warp(Local_755[iVar0 /*33*/], 2438.23f,
																				4962.25f, 46.27f, 0.4f, 0);
									Local_755[iVar0 /*33*/].f_5++;
								}
								break;
							}
							break;

						case 1:
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 1647992574) == 7) {
								Local_755[iVar0 /*33*/].f_5 = 0;
							}
							break;
						}
						break;

					case 28:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							if (player::is_player_targetting_entity(player::player_id(), Local_755[iVar0 /*33*/]) ||
								func_90(entity::get_entity_coords(Local_755[iVar0 /*33*/], 1), 1f, 1120403456) &&
									entity::is_entity_in_angled_area(player::player_ped_id(), 2448.583f, 4969.292f,
																	 45.1856f, 2439.538f, 4978.061f, 46.82762f, 5.75f,
																	 0, 1, 0)) {
								ai::task_hands_up(Local_755[iVar0 /*33*/], 20000, 0, -1, 0);
								Local_755[iVar0 /*33*/].f_5 = 2;
							}
							break;

						case 2:
							if (func_35("WRK1", 1, Local_755[iVar0 /*33*/], "CHIN2Goon2", -1, 0, 0, -1, 0, 0, -1, 0, 0,
										8)) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 3:
							if (player::is_player_targetting_entity(player::player_id(), Local_755[iVar0 /*33*/]) ||
								func_90(entity::get_entity_coords(Local_755[iVar0 /*33*/], 1), 1f, 1120403456) &&
									entity::is_entity_in_angled_area(player::player_ped_id(), 2448.583f, 4969.292f,
																	 45.1856f, 2439.538f, 4978.061f, 46.82762f, 5.75f,
																	 0, 1, 0)) {
								if (func_35("TRV1", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0,
											8)) {
									Local_755[iVar0 /*33*/].f_5++;
									Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 2000;
								}
							}
							else {
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 2000;
							}
							break;

						case 4:
							if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
								ai::task_smart_flee_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 200f, 200000,
														0, 0);
								ped::set_ped_keep_task(Local_755[iVar0 /*33*/], 1);
								entity::set_ped_as_no_longer_needed(&Local_755[iVar0 /*33*/]);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;
						}
						break;

					case 30:
						if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
							if (Local_755[iVar0 /*33*/].f_5 < 8) {
								if (weapon::has_ped_been_damaged_by_weapon(Local_755[iVar0 /*33*/], 0, 2)) {
									if (!weapon::has_ped_got_weapon(Local_755[iVar0 /*33*/], 0, 2)) {
										weapon::give_weapon_to_ped(Local_755[iVar0 /*33*/], joaat("weapon_pistol"), -1,
																   0, 1);
										ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
										func_88();
										ped::set_blocking_of_non_temporary_events(Local_755[iVar0 /*33*/], 0);
										ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
										ped::set_ped_relationship_group_hash(Local_755[iVar0 /*33*/], iLocal_1616);
										Local_755[iVar0 /*33*/].f_5 = 999;
									}
								}
							}
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							streaming::request_anim_dict("misschinese2_crystalmaze");
							weapon::request_weapon_asset(joaat("weapon_sawnoffshotgun"), 31, 0);
							ped::set_blocking_of_non_temporary_events(Local_755[iVar0 /*33*/], 1);
							ped::set_ped_relationship_group_hash(Local_755[iVar0 /*33*/], iLocal_1616);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 1:
							if (streaming::has_anim_dict_loaded("misschinese2_crystalmaze") &&
								weapon::has_weapon_asset_loaded(joaat("weapon_sawnoffshotgun"))) {
								if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
									iLocal_2875 =
										ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
									ped::set_synchronized_scene_looped(iLocal_2875, 1);
									ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2875,
																"misschinese2_crystalmaze", "_cower_loop", 1000f, -8f,
																0, 0, 1148846080, 0);
									if (!entity::does_entity_exist(iLocal_2878)) {
										iLocal_2878 =
											weapon::create_weapon_object(joaat("weapon_sawnoffshotgun"), 40, 2433.59f,
																		 4969.7f, 42.1854f, 1, 1065353216, 0, 0, 1);
										entity::set_entity_rotation(iLocal_2878, 90f, 0f, 0f, 2, 1);
									}
									ai::task_look_at_entity(Local_755[iVar0 /*33*/], player::player_ped_id(), -1, 0, 2);
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 2:
							if (iLocal_2511 == 4 || iLocal_2511 == 5 || iLocal_2511 == 6) {
								if (func_87(11)) {
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							if (iLocal_2511 > 6) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 3:
							iLocal_2874 =
								ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
							ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2874,
														"misschinese2_crystalmaze", "_cower_to_stand", 4f, -8f, 0, 0,
														1148846080, 0);
							ai::task_look_at_entity(Local_755[iVar0 /*33*/], player::player_ped_id(), -1, 0, 2);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 4:
							if (func_35("CHI2_DALE", 4, Local_755[iVar0 /*33*/], "ONEIL", -1, 0, 0, -1, 0, 0, -1, 0, 0,
										8)) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							if (ped::is_synchronized_scene_running(iLocal_2874) &&
									ped::get_synchronized_scene_phase(iLocal_2874) > 0.98f ||
								!ped::is_synchronized_scene_running(iLocal_2874)) {
								Local_755[iVar0 /*33*/].f_5 = 5;
							}
							break;

						case 5:
							if (ped::is_synchronized_scene_running(iLocal_2874) &&
									ped::get_synchronized_scene_phase(iLocal_2874) > 0.98f ||
								!ped::is_synchronized_scene_running(iLocal_2874)) {
								iLocal_2873 =
									ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
								ped::set_synchronized_scene_looped(iLocal_2873, 1);
								ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2873,
															"misschinese2_crystalmaze", "_stand_loop", 4f, -8f, 0, 0,
															1148846080, 0);
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_14 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(1000, 2000);
							}
							break;

						case 6:
							if (!ped::is_synchronized_scene_running(iLocal_2876) || iLocal_2876 == 0) {
								if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
									iLocal_2876 =
										ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
									if (gameplay::get_random_int_in_range(0, 2) == 1) {
										ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2876,
																	"misschinese2_crystalmaze", "_stand_loop_a", 4f,
																	-8f, 0, 0, 1148846080, 0);
									}
									else {
										ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2876,
																	"misschinese2_crystalmaze", "_stand_loop_b", 4f,
																	-8f, 0, 0, 1148846080, 0);
									}
								}
							}
							if (!ped::is_synchronized_scene_running(iLocal_2873) || iLocal_2873 == 0) {
								if (ped::is_synchronized_scene_running(iLocal_2876) &&
										ped::get_synchronized_scene_phase(iLocal_2876) > 0.98f ||
									!ped::is_synchronized_scene_running(iLocal_2876)) {
									iLocal_2873 =
										ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
									ped::set_synchronized_scene_looped(iLocal_2873, 1);
									ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2873,
																"misschinese2_crystalmaze", "_stand_loop", 4f, -8f, 0,
																0, 1148846080, 0);
									Local_755[iVar0 /*33*/].f_14 =
										gameplay::get_game_timer() + gameplay::get_random_int_in_range(1000, 2000);
								}
							}
							if (!func_59() ||
								func_67(player::player_ped_id(), 2430.09f, 4965.93f, 41.55f, 1) > 3.438f &&
									!entity::is_entity_in_angled_area(player::player_ped_id(), 2427.079f, 4964.971f,
																	  41.81169f, 2432.589f, 4959.331f, 48.7548f,
																	  3.3125f, 0, 1, 0)) {
								func_85();
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 7:
							if (func_35("CHI2_DALEG", 4, Local_755[iVar0 /*33*/], "ONEIL", -1, 0, 0, -1, 0, 0, -1, 0, 0,
										8)) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 8:
							iLocal_2877 =
								ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
							ai::task_synchronized_scene(Local_755[iVar0 /*33*/], iLocal_2877,
														"misschinese2_crystalmaze", "_stand_to_aim", 4f, -8f, 0, 0,
														1148846080, 0);
							weapon::give_weapon_object_to_ped(iLocal_2878, Local_755[iVar0 /*33*/]);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 9:
							if (ped::is_synchronized_scene_running(iLocal_2877) &&
									ped::get_synchronized_scene_phase(iLocal_2877) > 0.98f ||
								!ped::is_synchronized_scene_running(iLocal_2877)) {
								ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
								ai::clear_ped_tasks(Local_755[iVar0 /*33*/]);
								ai::task_aim_gun_at_entity(Local_755[iVar0 /*33*/], player::player_ped_id(), -1, 1);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 10:
							if (!func_59()) {
								if (func_35("CHI2_DALEA", 4, Local_755[iVar0 /*33*/], "ONEIL", -1, 0, 0, -1, 0, 0, -1,
											0, 0, 8)) {
									ped::set_blocking_of_non_temporary_events(Local_755[iVar0 /*33*/], 0);
									ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
									Local_755[iVar0 /*33*/].f_14 =
										gameplay::get_game_timer() + gameplay::get_random_int_in_range(3000, 4000);
									Local_755[iVar0 /*33*/].f_15 = 0;
									Local_755[iVar0 /*33*/].f_5++;
								}
							}
							break;

						case 11:
							if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
								if (Local_755[iVar0 /*33*/].f_15 < 4) {
									if (func_35("CHI2_DALEA", 4, Local_755[iVar0 /*33*/], "ONEIL", -1, 0, 0, -1, 0, 0,
												-1, 0, 0, 8)) {
										Local_755[iVar0 /*33*/].f_5++;
										Local_755[iVar0 /*33*/].f_14 =
											gameplay::get_game_timer() + gameplay::get_random_int_in_range(3000, 4000);
										Local_755[iVar0 /*33*/].f_15++;
									}
								}
							}
							break;

						case 999:
							if (func_35("CHI2_DALEA", 4, Local_755[iVar0 /*33*/], "ONEIL", -1, 0, 0, -1, 0, 0, -1, 0, 0,
										8)) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;
						}
						break;

					case 31:
						if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
							if (gameplay::is_bullet_in_area(entity::get_entity_coords(Local_755[iVar0 /*33*/], 1), 2f,
															1)) {
								Local_755[iVar0 /*33*/].f_5 = 5;
							}
						}
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							if (func_84("FRMFLC", 0, 0)) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 1:
							if (func_35("WRK2", 1, Local_755[iVar0 /*33*/], "oneilcook", 2, player::player_ped_id(),
										"trevor", -1, 0, 0, -1, 0, 0, 8)) {
								Local_755[iVar0 /*33*/].f_5++;
								Local_755[iVar0 /*33*/].f_14 = gameplay::get_game_timer() + 1300;
							}
							break;

						case 2:
							if (gameplay::get_game_timer() > Local_755[iVar0 /*33*/].f_14) {
								ai::task_hands_up(Local_755[iVar0 /*33*/], 20000, 0, -1, 0);
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 3:
							if (!func_59()) {
								Local_755[iVar0 /*33*/].f_5++;
							}
							break;

						case 4:
							if (!func_59()) {
								func_99(iVar0, 27, 0, 0);
							}
							break;

						case 5:
							ai::task_smart_flee_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 50f, 1000, 0, 0);
							Local_755[iVar0 /*33*/].f_5++;
							break;

						case 6:
							if (func_82("WRK2")) {
								if (audio::get_current_scripted_conversation_line() == 1 ||
									audio::get_current_scripted_conversation_line() == 5) {
									func_81(0);
								}
								else {
									func_81(1);
								}
							}
							func_99(iVar0, 27, 0, 0);
							break;
						}
						break;

					case 27:
						switch (Local_755[iVar0 /*33*/].f_5) {
						case 0:
							func_93();
							ai::task_set_blocking_of_non_temporary_events(0, 1);
							ai::task_smart_flee_ped(0, player::player_ped_id(), 200f, 999999, 0, 0);
							ai::task_cower(0, -1);
							func_92(&Local_755[iVar0 /*33*/], 0);
							ped::set_ped_keep_task(Local_755[iVar0 /*33*/], 1);
							entity::set_ped_as_no_longer_needed(&Local_755[iVar0 /*33*/]);
							if (ui::does_blip_exist(Local_755[iVar0 /*33*/].f_19)) {
								ui::remove_blip(&Local_755[iVar0 /*33*/].f_19);
							}
							Local_755[iVar0 /*33*/].f_5++;
							break;
						}
						break;

					case 4:
						if (iLocal_2881 == 1) {
							if (ped::is_synchronized_scene_running(Local_755[iVar0 /*33*/].f_14)) {
								ped::set_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14, 0.69f);
							}
							if (iVar0 == 9) {
								iLocal_2881 = 0;
							}
						}
						if (iLocal_2882 == 1) {
							if (ped::is_synchronized_scene_running(Local_755[iVar0 /*33*/].f_14)) {
								ped::set_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14, 0f);
							}
							if (iVar0 == 9) {
								iLocal_2882 = 0;
							}
							Local_755[iVar0 /*33*/].f_5 = 0;
						}
						if (Local_755[iVar0 /*33*/].f_2 == 8) {
							if (ped::is_synchronized_scene_running(Local_755[iVar0 /*33*/].f_14)) {
								if (Local_755[iVar0 /*33*/].f_5 == 0) {
									if (!func_30(23) || iLocal_2511 == 3) {
										if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 1785177548) == 1) {
											if (ped::get_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14) >
													0.024f &&
												ped::get_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14) <
													0.033f) {
												iVar5 = 0;
												if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
													iVar6 = joaat("weapon_unarmed");
													if (weapon::get_current_ped_weapon(Local_755[iVar0 /*33*/
													],
																					   &iVar6, 1)) {
														ped::set_ped_accuracy(Local_755[iVar0 /*33*/], 100);
														if (iVar6 == joaat("weapon_"
																		   "pistol")) {
															if (func_80(&iVar5)) {
																weapon::set_ammo_in_clip(Local_755[iVar0 /*33*/
																],
																						 joaat("weap"
																							   "on_"
																							   "pist"
																							   "ol"),
																						 12);
																ped::set_ped_shoots_at_coord(
																	Local_755[iVar0 /*33*/
																],
																	entity::get_entity_coords(iLocal_2657[iVar5], 1),
																	0);
																func_97(Local_755[iVar0 /*33*/
																],
																		&Local_755[iVar0 /*33*/
																]
																			 .f_25,
																		-1, 0, 1, 0, -1082130432, 0, -1, -1, 1);
																Local_755[iVar0 /*33*/
																]
																	.f_5 = 1;
															}
															else {
																weapon::set_ammo_in_clip(Local_755[iVar0 /*33*/
																],
																						 joaat("weap"
																							   "on_"
																							   "pist"
																							   "ol"),
																						 12);
																ped::set_ped_shoots_at_coord(Local_755[iVar0 /*33*/
																],
																							 2493.1f, 4971f, 44.9f, 0);
																func_97(Local_755[iVar0 /*33*/
																],
																		&Local_755[iVar0 /*33*/
																]
																			 .f_25,
																		-1, 0, 1, 0, -1082130432, 0, -1, -1, 1);
																Local_755[iVar0 /*33*/
																]
																	.f_5 = 1;
															}
														}
													}
												}
											}
										}
									}
								}
								else if (Local_755[iVar0 /*33*/].f_5 == 1) {
									if (ped::get_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14) > 0.04f) {
										Local_755[iVar0 /*33*/].f_5 = 2;
										if (iLocal_2879 == 0) {
											audio::_play_ambient_speech_with_voice(Local_755[iVar0 /*33*/],
																				   "generic_cheer",
																				   "A_M_M_Hillbilly_01_White_"
																				   "mini_02",
																				   "SPEECH_PARAMS_FORCE_"
																				   "SHOUTED",
																				   0);
										}
									}
								}
								else if (Local_755[iVar0 /*33*/].f_5 == 2) {
									if (ped::get_synchronized_scene_phase(Local_755[iVar0 /*33*/].f_14) > 0.6f) {
										Local_755[iVar0 /*33*/].f_5 = 0;
									}
								}
							}
						}
						if (Local_755[iVar0 /*33*/].f_5 == 3) {
							if (ai::get_script_task_status(Local_755[iVar0 /*33*/], 2106541073) == 7) {
								func_99(iVar0, 7, 0, 0);
							}
						}
						break;
					}
				}
				break;

			case 5:
			case 6:
				if (Local_1619[iVar0 /*24*/].f_20) {
					switch (Local_755[iVar0 /*33*/].f_2) {
					case 20:
					case 21:
					case 16:
					case 12:
					case 13:
					case 14:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2431.704f, 4961.62f, 45.33136f,
															   2455.376f, 4985.934f, 48.68555f, 13.5625f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							ped::set_ped_combat_attributes(Local_755[iVar0 /*33*/], 50, 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;
						}
						break;

					case 17:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2431.704f, 4961.62f, 45.33136f,
															   2455.376f, 4985.934f, 48.68555f, 13.5625f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							ped::set_ped_combat_attributes(Local_755[iVar0 /*33*/], 50, 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;
						}
						break;

					case 15:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2437.982f, 4959.021f, 45.31057f,
															   2432.93f, 4961.941f, 48.69256f, 3.1875f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;

						case 2:
							if (func_87(18)) {
								ped::remove_ped_defensive_area(Local_755[iVar0 /*33*/], 0);
								Local_1619[iVar0 /*24*/].f_4++;
							}
							break;
						}
						break;

					case 10:
					case 18:
					case 19:
					case 11:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							ped::set_ped_combat_attributes(Local_755[iVar0 /*33*/], 50, 1);
							if (iLocal_1614 == 0) {
								ped::remove_ped_defensive_area(Local_755[iVar0 /*33*/], 0);
								ped::set_ped_sphere_defensive_area(Local_755[iVar0 /*33*/], 2451.677f, 4954.251f,
																   44.988f, 3f, 0, 0);
								iLocal_1614++;
								Local_1619[iVar0 /*24*/].f_4++;
							}
							else {
								Local_1619[iVar0 /*24*/].f_4 = gameplay::get_game_timer() + iLocal_1614 * 4000;
								iLocal_1614++;
							}
							Local_755[iVar0 /*33*/].f_1 = 1;
							break;

						case 2:
							if (func_67(Local_755[iVar0 /*33*/], 2451.677f, 4954.251f, 44.988f, 1) < 3f) {
								ped::remove_ped_defensive_area(Local_755[iVar0 /*33*/], 0);
								Local_1619[iVar0 /*24*/].f_4++;
							}
							break;

						case 3: break;

						default:
							if (gameplay::get_game_timer() > Local_1619[iVar0 /*24*/].f_4) {
								ped::remove_ped_defensive_area(Local_755[iVar0 /*33*/], 0);
								ped::set_ped_sphere_defensive_area(Local_755[iVar0 /*33*/], 2451.677f, 4954.251f,
																   44.988f, 3f, 0, 0);
								Local_1619[iVar0 /*24*/].f_4 = 2;
							}
							break;
						}
						break;

					case 1:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2453.084f, 4969.897f, 50.44285f,
															   2460.996f, 4977.822f, 53.38035f, 2.9375f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;
						}
						break;

					case 0:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2442.963f, 4964.217f, 50.44285f,
															   2449.251f, 4970.534f, 53.38035f, 2f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;
						}
						break;

					case 2:
						switch (Local_1619[iVar0 /*24*/].f_4) {
						case 1:
							ped::set_ped_angled_defensive_area(Local_755[iVar0 /*33*/], 2461.362f, 4976.084f, 50.44285f,
															   2448.743f, 4988.774f, 53.60143f, 2f, 0, 0);
							ai::task_combat_ped(Local_755[iVar0 /*33*/], player::player_ped_id(), 0, 16);
							ped::set_ped_target_loss_response(Local_755[iVar0 /*33*/], 1);
							Local_1619[iVar0 /*24*/].f_4++;
							break;
						}
						break;
					}
				}
				break;
			}
		}
		iVar0++;
	}
}

// Position - 0xC37F
bool func_80(int *iParam0) {
	int iVar0;
	int iVar1;

	*iParam0 = 0;
	iVar0 = 0;
	*iParam0 = gameplay::get_random_int_in_range(0, 10);
	iVar1 = 0;
	while (!iVar1) {
		if (entity::does_entity_exist(iLocal_2657[*iParam0]) &&
			entity::is_entity_in_angled_area(iLocal_2657[*iParam0], 2495.017f, 4970.17f, 44.21808f, 2493.501f,
											 4971.556f, 45.40248f, 1.375f, 0, 1, 0)) {
			return true;
		}
		else {
			*iParam0++;
			iVar0++;
			if (*iParam0 == iLocal_2657) {
				*iParam0 = 0;
			}
		}
		if (iVar0 == 10) {
			return false;
		}
	}
	return false;
}

// Position - 0xC418
void func_81(int iParam0) {
	iLocal_3491 = 0;
	if (iParam0) {
		func_85();
	}
	else {
		func_88();
	}
}

// Position - 0xC434
bool func_82(char *sParam0) {
	struct<6> Var0;

	Var0 = {func_83()};
	if (gameplay::are_strings_equal(&Var0, sParam0)) {
		return true;
	}
	return false;
}

// Position - 0xC454
struct<6> func_83() {
	struct<6> Var0;

	StringCopy(&Var0, "NULL", 24);
	if (Global_15745 == 4) {
		return Global_15364;
	}
	return Var0;
}

//Position - 0xC478
bool func_84(char* sParam0, int iParam1, char* sParam2)
{
	ui::begin_text_command_is_message_displayed(sParam0);
	if (iParam1 == 1) {
		ui::add_text_component_substring_text_label(sParam2);
	}
	return ui::end_text_command_is_message_displayed();
}

// Position - 0xC496
void func_85() {
	Global_14611 = 0;
	func_86();
}

// Position - 0xC4A6
void func_86() {
	if (audio::is_scripted_conversation_ongoing()) {
		audio::restart_scripted_conversation();
		Global_16756 = 0;
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0xC4CA
bool func_87(int iParam0) {
	int iVar0;

	iVar0 = iParam0 - Local_3120[0 /*8*/];
	if (iVar0 >= 0 && iVar0 < Local_3120) {
		if (Local_3120[iVar0 /*8*/] == iParam0) {
			if (Local_3120[iVar0 /*8*/].f_2) {
				return true;
			}
		}
		else if (Local_3120[iVar0 /*8*/] != 0) {
		}
	}
	return false;
}

// Position - 0xC51A
void func_88() {
	Global_14611 = 0;
	func_89();
}

// Position - 0xC52A
void func_89() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0xC54B
bool func_90(vector3 vParam0, float fParam3, float fParam4) {
	if (cam::is_sphere_visible(vParam0, fParam3)) {
		if (!entity::is_entity_at_coord(player::player_ped_id(), vParam0, fParam4, fParam4, fParam4, 0, 0, 0)) {
			return false;
		}
		else if (cam::is_screen_faded_out()) {
			return false;
		}
		else {
			return true;
		}
	}
	return false;
}

// Position - 0xC593
int func_91(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_3120) {
		if (iParam0 == Local_3120[iVar0 /*8*/]) {
			if (iParam1 == 1) {
				Local_3120[iVar0 /*8*/].f_2 = 1;
			}
			else {
				Local_3120[iVar0 /*8*/].f_2 = 0;
			}
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xC5DD
void func_92(int iParam0, int iParam1) {
	if (iParam1) {
		ai::set_sequence_to_repeat(iLocal_257, 1);
	}
	ai::close_sequence_task(iLocal_257);
	if (!ped::is_ped_dead_or_dying(*iParam0, 1)) {
		ai::task_perform_sequence(*iParam0, iLocal_257);
	}
	ai::clear_sequence_task(&iLocal_257);
}

// Position - 0xC616
void func_93() { ai::open_sequence_task(&iLocal_257); }

// Position - 0xC625
void func_94(int iParam0) {
	Local_755[iParam0 /*33*/].f_15 += system::floor(system::timestep() * 1000f);
	switch (Local_755[iParam0 /*33*/].f_2) {
	case 7:
		if (Local_755[iParam0 /*33*/].f_15 > 2000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 0)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2505.634f, 4996.994f, 46.6624f, 4000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 0);
		}
		else if (Local_755[iParam0 /*33*/].f_15 > 8000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 1)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2472.297f, 4962.687f, 47.2297f, 6000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 1);
		}
		break;

	case 5:
		if (Local_755[iParam0 /*33*/].f_15 > 3000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 0)) {
			if (!ped::is_ped_injured(Local_755[6 /*33*/])) {
				ai::task_look_at_entity(Local_755[iParam0 /*33*/], Local_755[6 /*33*/], 4000, 0, 2);
				gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 0);
			}
		}
		else if (Local_755[iParam0 /*33*/].f_15 > 11000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 1)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2494.634f, 5001.994f, 46.6624f, 7000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 1);
		}
		else if (Local_755[iParam0 /*33*/].f_15 > 20000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 2)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2477.634f, 4966.994f, 46.6624f, 7000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 2);
		}
		break;

	case 4:
		if (Local_755[iParam0 /*33*/].f_15 > 3000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 0)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2505.634f, 4996.994f, 46.6624f, 5000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 0);
		}
		else if (Local_755[iParam0 /*33*/].f_15 > 10000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 1)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2461.449f, 4977.48f, 51.7483f, 6000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 1);
		}
		else if (Local_755[iParam0 /*33*/].f_15 > 18000 && !gameplay::is_bit_set(Local_755[iParam0 /*33*/].f_14, 2)) {
			ai::task_look_at_coord(Local_755[iParam0 /*33*/], 2505.634f, 4996.994f, 46.6624f, 6000, 0, 2);
			gameplay::set_bit(&Local_755[iParam0 /*33*/].f_14, 2);
		}
		break;
	}
}

// Position - 0xC913
float func_95(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0xC93A
float func_96(struct<2> Param0, float fParam2, struct<2> Param3, float fParam5, int iParam6) {
	float fVar0;
	float fVar1;
	float fVar2;

	fVar1 = Param3 - Param0;
	fVar2 = Param3.f_1 - Param0.f_1;
	if (fVar2 != 0f) {
		fVar0 = gameplay::atan2(fVar1, fVar2);
	}
	else if (fVar1 < 0f) {
		fVar0 = -90f;
	}
	else {
		fVar0 = 90f;
	}
	if (iParam6 == 1) {
		fVar0 *= -1f;
		if (fVar0 < 0f) {
			fVar0 += 360f;
		}
	}
	return fVar0;
}

// Position - 0xC99F
int func_97(int iParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5, float fParam6, char *sParam7,
			int iParam8, int iParam9, int iParam10) {
	if (iParam3 == 0) {
		iParam3 = player::get_player_index();
	}
	if (fParam6 < 0f) {
		fParam6 = 100f;
	}
	if (!ped::is_ped_injured(iParam0)) {
		if (!ui::does_ped_have_ai_blip(iParam0)) {
			if (iParam8 == -1) {
				ui::_set_ped_enemy_ai_blip(iParam0, 1);
			}
			else {
				unk_0xB13DCB4C6FAAD238(iParam0, 1, iParam8);
			}
			uParam1->f_7 = iParam0;
			ui::_0xE52B8E7F85D39A08(iParam0, iParam2);
			ui::_set_ai_blip_max_distance(iParam0, fParam6);
			if (ui::does_blip_exist(*uParam1)) {
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (iParam9 != -1) {
			unk_0xFCFACD0DB9D7A57D(iParam0, iParam9);
		}
		ui::_0x0C4BBF625CA98C4E(iParam0, iParam4);
		ui::hide_special_ability_lockon_operation(iParam0, iParam5);
		*uParam1 = ui::_0x7CD934010E115C2C(iParam0);
		if (iParam9 != -1) {
			if (ui::does_blip_exist(*uParam1)) {
				if (iParam8 != -1) {
					ui::set_blip_colour(*uParam1, iParam8);
				}
				ui::begin_text_command_set_blip_name("STRING");
				if (iParam10) {
					ui::add_text_component_substring_player_name(sParam7);
				}
				else {
					ui::add_text_component_substring_text_label(sParam7);
				}
				ui::end_text_command_set_blip_name(*uParam1);
				ui::set_blip_priority(*uParam1, 7);
			}
		}
		if (!gameplay::is_bit_set(uParam1->f_6, 2)) {
			if (ui::does_blip_exist(*uParam1)) {
				if (!gameplay::is_string_null_or_empty(sParam7)) {
					ui::begin_text_command_set_blip_name("STRING");
					if (iParam10) {
						ui::add_text_component_substring_player_name(sParam7);
					}
					else {
						ui::add_text_component_substring_text_label(sParam7);
					}
					ui::end_text_command_set_blip_name(*uParam1);
				}
				gameplay::set_bit(&uParam1->f_6, 2);
			}
		}
		if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			uParam1->f_1 = ui::_0x56176892826A4FE8(iParam0);
			if (!gameplay::is_bit_set(uParam1->f_6, 3)) {
				if (ui::does_blip_exist(uParam1->f_1)) {
					ui::set_blip_priority(uParam1->f_1, 7);
					gameplay::set_bit(&uParam1->f_6, 3);
				}
			}
		}
		else if (ui::does_blip_exist(uParam1->f_1)) {
			uParam1->f_1 = 0;
			gameplay::clear_bit(&uParam1->f_6, 3);
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0xCB3C
void func_98(int iParam0, float fParam1, float fParam2, float fParam3, float fParam4, float fParam5) {
	if (!ped::is_ped_injured(iParam0)) {
		ped::set_ped_seeing_range(iParam0, fParam1);
		ped::set_ped_visual_field_peripheral_range(iParam0, fParam2);
		ped::set_ped_visual_field_center_angle(iParam0, fParam3 / 2f);
		ped::set_ped_visual_field_min_angle(iParam0, fParam4);
		ped::set_ped_visual_field_max_angle(iParam0, fParam5);
	}
}

// Position - 0xCB78
void func_99(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (!ped::is_ped_injured(Local_755[iParam0 /*33*/])) {
		if (iParam0 >= 0) {
			Local_755[iParam0 /*33*/].f_4 = Local_755[iParam0 /*33*/].f_3;
			Local_755[iParam0 /*33*/].f_3 = iParam1;
			Local_755[iParam0 /*33*/].f_5 = iParam2;
			Local_755[iParam0 /*33*/].f_6 = {0f, 0f, 0f};
			Local_755[iParam0 /*33*/].f_9 = {0f, 0f, 0f};
			Local_755[iParam0 /*33*/].f_12 = 0f;
			Local_755[iParam0 /*33*/].f_13 = 0f;
			Local_755[iParam0 /*33*/].f_14 = iParam3;
			Local_755[iParam0 /*33*/].f_15 = 0;
			Local_1619[iParam0 /*24*/].f_3 = 3;
		}
	}
}

// Position - 0xCC0C
void func_100(int iParam0, int iParam1, var uParam2, int iParam3, int iParam4, int iParam5) {
	(*iParam0)[iParam1 /*24*/] = uParam2;
	(*iParam0)[iParam1 /*24*/].f_8 = iParam3;
	(*iParam0)[iParam1 /*24*/].f_20 = iParam4;
	(*iParam0)[iParam1 /*24*/].f_21 = iParam5;
	if (iParam1 > iLocal_52) {
		iLocal_52 = iParam1 + 1;
	}
}

// Position - 0xCC47
bool func_101(int iParam0, int iParam1, vector3 vParam2, float fParam5, int iParam6, int iParam7, int iParam8) {
	int iVar0;

	iParam1 = iParam1;
	iParam8 = iParam8;
	if (Local_755[iParam0 /*33*/].f_1 != 1 && Local_755[iParam0 /*33*/].f_1 != 0) {
		iVar0 = interior::get_interior_at_coords(vParam2);
		if (iVar0 == 0) {
			return false;
		}
		else if (!interior::is_interior_ready(iVar0)) {
			return false;
		}
	}
	switch (iLocal_751) {
	case 0:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 1, 0);
		break;

	case 1:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 1, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 1, 0);
		break;

	case 2:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 0, 0);
		break;

	case 3:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 1, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 0, 0);
		break;

	case 4:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 0, 0);
		break;

	case 5:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 2, 0);
		break;

	case 6:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 1, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 1, 0);
		break;

	case 7:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 2, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 2, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 2, 0);
		break;

	case 8:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 0, 0);
		break;

	case 9:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 2, 0);
		break;

	case 10:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 1, 0);
		break;

	case 11:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 2, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 2, 2, 0);
		break;

	case 12:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 2, 0);
		break;

	case 13:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 1, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 2, 0);
		break;

	case 14:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 2, 0);
		break;

	case 15:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 2, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 2, 0);
		break;

	case 16:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 0, 1, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 1, 1, 0);
		break;

	case 17:
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_m_hillbilly_02"), vParam2, fParam5, 1, 1);
		ped::set_ped_default_component_variation(Local_755[iParam0 /*33*/]);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 0, 0, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 2, 2, 0, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 3, 1, 2, 0);
		ped::set_ped_component_variation(Local_755[iParam0 /*33*/], 4, 0, 1, 0);
		break;
	}
	if (iLocal_751 > 17) {
		Local_755[iParam0 /*33*/] = ped::create_ped(26, joaat("a_m_y_methhead_01"), vParam2, fParam5, 1, 1);
		ped::set_ped_random_component_variation(Local_755[iParam0 /*33*/], 0);
	}
	iLocal_751++;
	if (Local_755[iParam0 /*33*/].f_1 == 5) {
		ped::set_blocking_of_non_temporary_events(Local_755[iParam0 /*33*/], 1);
		ped::set_ped_relationship_group_hash(Local_755[iParam0 /*33*/], iLocal_1617);
	}
	else {
		weapon::give_weapon_to_ped(Local_755[iParam0 /*33*/], iParam6, 3000, iParam7, 1);
		ped::set_ped_relationship_group_hash(Local_755[iParam0 /*33*/], iLocal_1616);
		ped::set_ped_as_enemy(Local_755[iParam0 /*33*/], 1);
		ped::set_ped_combat_attributes(Local_755[iParam0 /*33*/], 9, 1);
		ped::set_ped_hearing_range(Local_755[iParam0 /*33*/], 120f);
		ped::set_ped_seeing_range(Local_755[iParam0 /*33*/], 22f);
		ped::set_ped_id_range(Local_755[iParam0 /*33*/], 22f);
		ped::set_ped_config_flag(Local_755[iParam0 /*33*/], 118, 0);
		ped::set_combat_float(Local_755[iParam0 /*33*/], 14, 3f);
		if (Local_755[iParam0 /*33*/].f_1 == 2) {
			ped::set_ped_accuracy(Local_755[iParam0 /*33*/], 12);
		}
		else {
			ped::set_ped_accuracy(Local_755[iParam0 /*33*/], 45);
		}
		ped::set_ped_dies_when_injured(Local_755[iParam0 /*33*/], 1);
		entity::set_entity_only_damaged_by_player(Local_755[iParam0 /*33*/], 1);
		ped::set_ped_combat_attributes(Local_755[iParam0 /*33*/], 15, 0);
		ped::set_ped_combat_attributes(Local_755[iParam0 /*33*/], 17, 0);
		func_102(Local_755[iParam0 /*33*/], 1);
	}
	ped::stop_ped_weapon_firing_when_dropped(Local_755[iParam0 /*33*/]);
	entity::_set_entity_register(Local_755[iParam0 /*33*/], 1);
	ped::_0xEC6935EBE0847B90(Local_755[iParam0 /*33*/], 0f, 0f, 0f);
	ped::_0x5B6010B3CBC29095(Local_755[iParam0 /*33*/], 1);
	ped::_0xCEDA60A74219D064(Local_755[iParam0 /*33*/], 1);
	entity::set_entity_health(Local_755[iParam0 /*33*/], 150);
	return true;
}

// Position - 0xD478
void func_102(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	if (iParam1) {
		iVar0 = 0;
		while (iVar0 < 64) {
			if (Global_55852[iVar0 /*2*/] != 0) {
				if (Global_55852[iVar0 /*2*/] == iParam0) {
					return;
				}
			}
			iVar0++;
		}
	}
	if (64 == Global_55851) {
		return;
	}
	iVar1 = -1;
	iVar2 = 0;
	while (iVar1 == -1 && iVar2 != 64) {
		if (Global_55852[iVar2 /*2*/] == 0) {
			iVar1 = iVar2;
		}
		iVar2++;
	}
	if (iVar1 == -1) {
		return;
	}
	Global_55852[iVar1 /*2*/] = iParam0;
	Global_55852[iVar1 /*2*/].f_1 = 7;
	Global_55851++;
}

// Position - 0xD513
void func_103(var *uParam0, var *uParam1, vector3 vParam2, vector3 vParam5, vector3 vParam8, vector3 vParam11,
			  vector3 vParam14, vector3 vParam17, vector3 vParam20, vector3 vParam23, vector3 vParam26,
			  vector3 vParam29) {
	if (iLocal_52 > 0) {
		func_115(uParam0, vParam20, vParam23, vParam14, vParam17);
		func_107(uParam0, uParam1, vParam2, vParam5, vParam8);
		func_104(uParam0, vParam11, vParam14, vParam17, vParam20, vParam23, vParam26, vParam29);
	}
}

// Position - 0xD56D
void func_104(var *uParam0, vector3 vParam1, vector3 vParam4, vector3 vParam7, vector3 vParam10, vector3 vParam13,
			  vector3 vParam16, vector3 vParam19) {
	if (cam::is_gameplay_cam_rendering()) {
		if (bLocal_77) {
			if (iLocal_60 > iLocal_68 || iLocal_69 != iLocal_61 || iLocal_60 < iLocal_68 && iLocal_60 == 8 ||
				iLocal_60 == 10 && iLocal_53 == 0) {
				iLocal_67 = 1;
				iLocal_68 = iLocal_60;
				iLocal_69 = iLocal_61;
			}
			switch (iLocal_67) {
			case 1:
				if (iLocal_61 > -1) {
					if (!ped::is_ped_dead_or_dying((*uParam0)[iLocal_61 /*24*/], 1)) {
						switch (iLocal_60) {
						case 8:
							if (!iLocal_53) {
								if (!bLocal_56) {
									if (!iLocal_76) {
										if (!func_82(vParam13.y)) {
											func_88();
											if (func_105(vParam13.y, vParam13.z, (*uParam0)[iLocal_61 /*24*/],
														 vParam13.x, -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
												iLocal_67 = 2;
											}
										}
									}
									else {
										iLocal_67 = 2;
									}
								}
								else if (!func_82(vParam10.y)) {
									func_88();
									if (func_105(vParam10.y, vParam10.z, (*uParam0)[iLocal_61 /*24*/], vParam10.x, -1,
												 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
										iLocal_67 = 2;
									}
								}
							}
							else {
								iLocal_67 = 2;
							}
							break;

						case 7:
							iLocal_76 = 0;
							func_88();
							if (func_105(vParam1.y, vParam1.z, (*uParam0)[iLocal_61 /*24*/], vParam1.x, -1, 0, 0, -1, 0,
										 0, -1, 0, 0, 8)) {
								iLocal_67 = 2;
							}
							break;

						case 5:
							iLocal_76 = 0;
							func_88();
							if (func_105(vParam16.y, vParam16.z, (*uParam0)[iLocal_61 /*24*/], vParam16.x, -1, 0, 0, -1,
										 0, 0, -1, 0, 0, 8)) {
								iLocal_67 = 2;
							}
							break;

						case 3:
							if (!iLocal_53 && !iLocal_76) {
								func_88();
								if (func_105(vParam19.y, vParam19.z, (*uParam0)[iLocal_61 /*24*/], vParam19.x, -1, 0, 0,
											 -1, 0, 0, -1, 0, 0, 8)) {
									iLocal_67 = 2;
								}
							}
							else {
								iLocal_67 = 2;
							}
							break;

						case 6:
							if (!bLocal_56) {
								if (!func_82(vParam4.y) && !func_82(vParam7.y) && !func_82(vParam10.y) &&
									!func_82(vParam13.y)) {
									iLocal_76 = 0;
									func_88();
									if (func_105(vParam4.y, vParam4.z, (*uParam0)[iLocal_61 /*24*/], vParam4.x, -1, 0,
												 0, -1, 0, 0, -1, 0, 0, 8)) {
										iLocal_67 = 2;
									}
								}
							}
							else {
								iLocal_67 = 2;
							}
							break;

						case 10:
						case 9:
							if (!bLocal_56) {
								if (!func_82(vParam4.y) && !func_82(vParam7.y) && !func_82(vParam10.y) &&
									!func_82(vParam13.y)) {
									iLocal_76 = 0;
									func_88();
									if (func_105(vParam7.y, vParam7.z, (*uParam0)[iLocal_61 /*24*/], vParam7.x, -1, 0,
												 0, -1, 0, 0, -1, 0, 0, 8)) {
										iLocal_67 = 2;
									}
								}
							}
							else {
								if (!iLocal_53) {
									if (func_105(vParam10.y, vParam10.z, (*uParam0)[iLocal_61 /*24*/], vParam10.x, -1,
												 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
										iLocal_76 = 0;
										iLocal_67 = 2;
									}
								}
								iLocal_67 = 2;
							}
							break;
						}
					}
					else {
						iLocal_67 = 2;
					}
				}
				else {
					iLocal_67 = 2;
				}
				break;

			case 2:
				if (!func_59()) {
					iLocal_67 = 0;
				}
				break;
			}
		}
	}
}

// Position - 0xD87A
bool func_105(char *sParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5, char *sParam6,
			  int iParam7, int iParam8, char *sParam9, int iParam10, int iParam11, char *sParam12, int iParam13) {
	func_58(sParam0, iParam1, iParam4, iParam7, iParam10);
	func_106(iParam1, iParam2, sParam3);
	if (iParam4 != -1) {
		func_106(iParam4, iParam5, sParam6);
	}
	if (iParam7 != -1) {
		func_106(iParam7, iParam8, sParam9);
	}
	if (iParam10 != -1) {
		func_106(iParam10, iParam11, sParam12);
	}
	if (!func_53()) {
		if (!ui::is_message_being_displayed()) {
			if (func_36(&Local_89, cLocal_254, sParam0, iParam13, 0, 0, 0)) {
				iLocal_256 = 0;
				return true;
			}
			else if (iLocal_255 != gameplay::get_game_timer()) {
				iLocal_256++;
				iLocal_255 = gameplay::get_game_timer();
				if (iLocal_256 >= 10) {
					iLocal_256 = 0;
					return true;
				}
			}
		}
		else {
			return true;
		}
	}
	else {
		return true;
	}
	return false;
}

// Position - 0xD92D
void func_106(int iParam0, int iParam1, char *sParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iLocal_78) {
		if (iLocal_78[iVar0] == iParam1) {
			func_57(&Local_89, iVar0);
			iLocal_78[iVar0] = 0;
		}
		iVar0++;
	}
	if (iLocal_78[iParam0] != 0) {
		func_57(&Local_89, iParam0);
	}
	func_56(&Local_89, iParam0, iParam1, sParam2, 0, 1);
	iLocal_78[iParam0] = iParam1;
}

// Position - 0xD98A
void func_107(var *uParam0, var *uParam1, vector3 vParam2, vector3 vParam5, vector3 vParam8) {
	int iVar0;
	float fVar1;
	int iVar2;
	vector3 vVar3;
	int iVar6;
	vector3 vVar7;
	vector3 vVar10;
	float fVar13;
	int iVar14;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1) &&
			!ped::is_ped_being_stealth_killed((*uParam0)[iVar0 /*24*/])) {
			if (!(*uParam0)[iVar0 /*24*/].f_21) {
				switch ((*uParam0)[iVar0 /*24*/].f_3) {
				case 4:
					if (ped::is_ped_using_scenario((*uParam0)[iVar0 /*24*/], "PROP_HUMAN_SEAT_CHAIR") ||
						ped::is_ped_using_scenario((*uParam0)[iVar0 /*24*/], "PROP_HUMAN_SEAT_ARMCHAIR") ||
						ai::get_script_task_status((*uParam0)[iVar0 /*24*/], 1785177548) == 1) {
						if (!ped::is_ped_injured((*uParam0)[iVar0 /*24*/])) {
							ai::clear_ped_tasks((*uParam0)[iVar0 /*24*/]);
						}
						if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1)) {
							ped::_0xF1C03A5352243A30((*uParam0)[iVar0 /*24*/]);
						}
					}
					else if (ai::get_script_task_status((*uParam0)[iVar0 /*24*/], 1647992574) == 7) {
						switch ((*uParam0)[iVar0 /*24*/].f_4) {
						case 0:
							if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1)) {
								ped::_0xF1C03A5352243A30((*uParam0)[iVar0 /*24*/]);
							}
							if (!ped::is_ped_using_scenario((*uParam0)[iVar0 /*24*/], "PROP_HUMAN_SEAT_CHAIR") &&
								!ped::is_ped_using_scenario((*uParam0)[iVar0 /*24*/], "PROP_HUMAN_SEAT_ARMCHAIR")) {
								if (ped::is_ped_in_any_vehicle((*uParam0)[iVar0 /*24*/], 0)) {
									iVar2 = ped::get_vehicle_ped_is_using((*uParam0)[iVar0 /*24*/]);
									if (vehicle::is_vehicle_driveable(iVar2, 0)) {
										if (vehicle::is_playback_going_on_for_vehicle(iVar2)) {
											vVar3 = {entity::get_entity_velocity(iVar2)};
											vehicle::stop_playback_recorded_vehicle(iVar2);
											entity::set_entity_velocity(iVar2, vVar3);
											ai::task_leave_any_vehicle((*uParam0)[iVar0 /*24*/], 0, 0);
										}
									}
								}
								if (!ped::is_ped_in_any_vehicle((*uParam0)[iVar0 /*24*/], 0)) {
									switch ((*uParam0)[iVar0 /*24*/].f_1) {
									case 2:
										switch ((*uParam0)[iVar0 /*24*/].f_5) {
										case 0:
											if ((*uParam0)[iVar0 /*24*/].f_10 >= 0) {
												if (entity::does_entity_exist(
														(*uParam0)[(*uParam0)[iVar0 /*24*/].f_10 /*24*/
												])) {
													fVar1 = func_113((*uParam0)[iVar0 /*24*/],
																	 (*uParam0)[(*uParam0)[iVar0 /*24*/].f_10 /*24*/
													]);
													if (fVar1 > -45f && fVar1 < 45f) {
														(*uParam0)[iVar0 /*24*/].f_5 = 1;
													}
													else if (fVar1 > -135f && fVar1 <= -45f) {
														(*uParam0)[iVar0 /*24*/].f_5 = 2;
													}
													else if (fVar1 >= 45f && fVar1 <= 135f) {
														(*uParam0)[iVar0 /*24*/].f_5 = 3;
													}
													else {
														(*uParam0)[iVar0 /*24*/].f_5 = 4;
													}
													(*uParam0)[iVar0 /*24*/].f_11 = gameplay::get_game_timer() + 500;
												}
												else {
													(*uParam0)[iVar0 /*24*/].f_1 = 0;
												}
											}
											break;

										case 1:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_11) {
												func_93();
												ai::task_set_blocking_of_non_temporary_events(0, 1);
												ai::task_play_anim(0, "misschinese2_bank1",
																   "react_forward_small_intro_"
																   "a",
																   4f, -4f, -1, 0, 0, 0, 0, 0);
												ai::task_set_blocking_of_non_temporary_events(0, 0);
												func_92(&(*uParam0)[iVar0 /*24*/], 0);
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											break;

										case 2:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_11) {
												func_93();
												ai::task_set_blocking_of_non_temporary_events(0, 1);
												ai::task_play_anim(0, "misschinese2_bank1", "react_left_small_intro_a",
																   4f, -4f, -1, 0, 0, 0, 0, 0);
												ai::task_set_blocking_of_non_temporary_events(0, 0);
												func_92(&(*uParam0)[iVar0 /*24*/], 0);
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											break;

										case 3:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_11) {
												func_93();
												ai::task_set_blocking_of_non_temporary_events(0, 1);
												ai::task_play_anim(0, "misschinese2_bank1", "react_right_small_intro_a",
																   4f, -4f, -1, 0, 0, 0, 0, 0);
												ai::task_set_blocking_of_non_temporary_events(0, 0);
												func_92(&(*uParam0)[iVar0 /*24*/], 0);
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											break;

										case 4:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_11) {
												func_93();
												ai::task_set_blocking_of_non_temporary_events(0, 1);
												ai::task_play_anim(0, "misschinese2_bank1",
																   "react_backward_small_"
																   "intro_a",
																   4f, -4f, -1, 0, 0, 0, 0, 0);
												ai::task_set_blocking_of_non_temporary_events(0, 0);
												func_92(&(*uParam0)[iVar0 /*24*/], 0);
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											break;
										}
										break;

									case 7:
										if ((*uParam0)[iVar0 /*24*/].f_5 < 2) {
											ai::clear_ped_tasks((*uParam0)[iVar0 /*24*/]);
											(*uParam0)[iVar0 /*24*/].f_5 = iLocal_63;
											iLocal_63++;
											if (iLocal_63 == 2) {
												iLocal_63 = 0;
											}
										}
										switch ((*uParam0)[iVar0 /*24*/].f_5) {
										case 0:
											weapon::set_current_ped_weapon(
												(*uParam0)[iVar0 /*24*/],
												weapon::get_best_ped_weapon((*uParam0)[iVar0 /*24*/], 0), 1);
											func_93();
											if (!ped::is_ped_in_any_vehicle((*uParam0)[iVar0 /*24*/], 1)) {
												ai::task_set_blocking_of_non_temporary_events(0, 1);
												ai::task_play_anim(0, "misschinese2_bank1", "buddy_shot_b", 4f, -4f, -1,
																   0, 0, 0, 0, 0);
												ai::task_set_blocking_of_non_temporary_events(0, 0);
											}
											else {
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											ai::task_combat_hated_targets_around_ped(0, 200f, 0);
											func_92(&(*uParam0)[iVar0 /*24*/], 0);
											(*uParam0)[iVar0 /*24*/].f_5 = gameplay::get_game_timer() + 3000;
											break;

										case 1:
											func_93();
											ai::task_set_blocking_of_non_temporary_events(0, 1);
											iVar6 = func_112();
											ai::task_set_blocking_of_non_temporary_events(0, 0);
											ai::task_combat_hated_targets_around_ped(0, 200f, 0);
											func_92(&(*uParam0)[iVar0 /*24*/], 0);
											(*uParam0)[iVar0 /*24*/].f_5 = gameplay::get_game_timer() + iVar6;
											break;

										default:
											if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/],
																			   "misschinese2_bank1", "buddy_shot_b",
																			   3)) {
												if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																						 "misschinese2_"
																						 "bank1",
																						 "buddy_shot_b") < 0.2f) {
													entity::set_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																						 "misschinese2_"
																						 "bank1",
																						 "buddy_shot_b", 0.2f);
												}
											}
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_5) {
												(*uParam0)[iVar0 /*24*/].f_4++;
											}
											break;
										}
										break;

									case 5:
										if ((*uParam0)[iVar0 /*24*/].f_5 <= 2) {
											(*uParam0)[iVar0 /*24*/].f_5 = iLocal_64;
											iLocal_64++;
											if (iLocal_64 == 2) {
												iLocal_64 = 0;
											}
										}
										if (!ped::is_ped_in_any_vehicle((*uParam0)[iVar0 /*24*/], 1)) {
											switch ((*uParam0)[iVar0 /*24*/].f_5) {
											case 0:
												ped::set_blocking_of_non_temporary_events((*uParam0)[iVar0 /*24*/], 1);
												ai::task_play_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "alert_gunshot", 4f, -4f, -1, 8, 0, 0, 0, 0);
												(*uParam0)[iVar0 /*24*/].f_5 = 3;
												break;

											case 1:
												ped::set_blocking_of_non_temporary_events((*uParam0)[iVar0 /*24*/], 1);
												ai::task_play_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "buddy_shot_b", 4f, -4f, -1, 8, 0, 0, 0, 0);
												weapon::set_current_ped_weapon(
													(*uParam0)[iVar0 /*24*/],
													weapon::get_best_ped_weapon((*uParam0)[iVar0 /*24*/], 0), 1);
												(*uParam0)[iVar0 /*24*/].f_5 = 3;
												break;

											case 3:
												if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/],
																				   "misschinese2_"
																				   "bank1",
																				   "alert_gunshot", 3)) {
													if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/
													],
																							 "misschinese2_"
																							 "bank1",
																							 "alert_"
																							 "gunshot") > 0.95f) {
														if (func_110(iVar0, uParam0, 0)) {
															(*uParam0)[iVar0 /*24*/].f_5 = 4;
														}
														else {
															ai::task_play_anim(
																(*uParam0)[iVar0 /*24*/
															],
																"reaction@male_"
																"stand@big_"
																"variations@b",
																"react_big_"
																"variations_d",
																4f, -2f, gameplay::get_random_int_in_range(4000, 6000),
																8, 0, 0, 0, 0);
															(*uParam0)[iVar0 /*24*/].f_5 = 6;
														}
													}
												}
												if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/],
																				   "misschinese2_"
																				   "bank1",
																				   "buddy_shot_b", 3)) {
													if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/
													],
																							 "misschinese2_"
																							 "bank1",
																							 "buddy_shot_"
																							 "b") > 0.95f) {
														if (func_110(iVar0, uParam0, 0)) {
															(*uParam0)[iVar0 /*24*/].f_5 = 5;
														}
														else {
															ai::task_play_anim(
																(*uParam0)[iVar0 /*24*/
															],
																"reaction@male_"
																"stand@big_"
																"variations@b",
																"react_big_"
																"variations_e",
																4f, -2f, gameplay::get_random_int_in_range(4000, 6000),
																8, 0, 0, 0, 0);
															(*uParam0)[iVar0 /*24*/].f_5 = 6;
														}
													}
												}
												break;

											case 4:
												if (gameplay::absf(entity::get_entity_heading((*uParam0)[iVar0 /*24*/
												]) - (*uParam0)[iVar0 /*24*/].f_18) < 10f) {
													ai::task_play_anim((*uParam0)[iVar0 /*24*/],
																	   "reaction@male_stand@"
																	   "big_variations@b",
																	   "react_big_variations_"
																	   "d",
																	   4f, -2f,
																	   gameplay::get_random_int_in_range(6000, 9000), 8,
																	   0, 0, 0, 0);
													(*uParam0)[iVar0 /*24*/].f_5 = 6;
												}
												break;

											case 5:
												if (gameplay::absf(entity::get_entity_heading((*uParam0)[iVar0 /*24*/
												]) - (*uParam0)[iVar0 /*24*/].f_18) < 10f) {
													ai::task_play_anim((*uParam0)[iVar0 /*24*/],
																	   "reaction@male_stand@"
																	   "big_variations@b",
																	   "react_big_variations_"
																	   "f",
																	   4f, -2f,
																	   gameplay::get_random_int_in_range(6000, 9000), 8,
																	   0, 0, 0, 0);
													(*uParam0)[iVar0 /*24*/].f_5 = 6;
												}
												break;

											case 6:
												if (ai::get_script_task_status((*uParam0)[iVar0 /*24*/], -2017877118) ==
													7) {
													(*uParam0)[iVar0 /*24*/].f_5 = 0;
													(*uParam0)[iVar0 /*24*/].f_4++;
												}
												break;
											}
										}
										else {
											(*uParam0)[iVar0 /*24*/].f_5 = 0;
											(*uParam0)[iVar0 /*24*/].f_4++;
										}
										break;

									case 4:
										switch ((*uParam0)[iVar0 /*24*/].f_5) {
										case 0:
											(*uParam0)[iVar0 /*24*/].f_5 =
												gameplay::get_game_timer() + gameplay::get_random_int_in_range(0, 2000);
											break;

										default:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_5) {
												(*uParam0)[iVar0 /*24*/].f_3 = 5;
												(*uParam0)[iVar0 /*24*/].f_1 = 0;
												(*uParam0)[iVar0 /*24*/].f_4 = 0;
											}
											break;
										}
										break;

									case 8:
										if ((*uParam0)[iVar0 /*24*/].f_3 != 6 && (*uParam0)[iVar0 /*24*/].f_3 != 5) {
											(*uParam0)[iVar0 /*24*/].f_3 = 5;
											(*uParam0)[iVar0 /*24*/].f_4 = 0;
										}
										break;

									case 10:
										if ((*uParam0)[iVar0 /*24*/].f_3 != 6) {
											(*uParam0)[iVar0 /*24*/].f_3 = 6;
											(*uParam0)[iVar0 /*24*/].f_4 = 0;
										}
										break;

									case 3:
										switch ((*uParam0)[iVar0 /*24*/].f_5) {
										case 0:
											(*uParam0)[iVar0 /*24*/].f_5 =
												gameplay::get_game_timer() + gameplay::get_random_int_in_range(0, 2000);
											break;

										default:
											if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_5) {
												if ((*uParam0)[iVar0 /*24*/].f_3 != 6 &&
													(*uParam0)[iVar0 /*24*/].f_3 != 5) {
													(*uParam0)[iVar0 /*24*/].f_3 = 5;
													(*uParam0)[iVar0 /*24*/].f_1 = 0;
													(*uParam0)[iVar0 /*24*/].f_4 = 0;
												}
											}
											break;
										}
										break;

									case 1:
										iLocal_62 = iVar0;
										if (func_109(iVar0, uParam0, "", vParam2, vParam5, vParam8, 0)) {
											(*uParam0)[iVar0 /*24*/].f_3 = 5;
											(*uParam0)[iVar0 /*24*/].f_1 = 0;
											(*uParam0)[iVar0 /*24*/].f_4 = 0;
										}
										break;

									case 6:
										switch ((*uParam0)[iVar0 /*24*/].f_5) {
										case 0:
											if (iLocal_65 == 0) {
												if (!ped::is_ped_in_any_vehicle((*uParam0)[iVar0 /*24*/], 1)) {
													vVar7 = {entity::get_entity_coords((*uParam0)[iVar0 /*24*/
													],
																					   1)};
													vVar10 = {entity::get_entity_coords(player::player_ped_id(), 1)};
													fVar13 = gameplay::atan(
														(vVar10.z - vVar7.z) /
														func_4((*uParam0)[iVar0 /*24*/], player::player_ped_id(), 0));
													if (fVar13 > 20f) {
														(*uParam0)[iVar0 /*24*/].f_5 = 1;
													}
													else if (fVar13 < -20f) {
														(*uParam0)[iVar0 /*24*/].f_5 = 2;
													}
													else {
														(*uParam0)[iVar0 /*24*/].f_5 = 3;
													}
												}
												else {
													(*uParam0)[iVar0 /*24*/].f_3 = 6;
													(*uParam0)[iVar0 /*24*/].f_1 = 10;
													(*uParam0)[iVar0 /*24*/].f_4 = 0;
												}
												iLocal_65++;
											}
											else {
												(*uParam0)[iVar0 /*24*/].f_3 = 6;
												(*uParam0)[iVar0 /*24*/].f_1 = 10;
												(*uParam0)[iVar0 /*24*/].f_4 = 0;
											}
											break;

										case 1:
											func_93();
											ai::task_set_blocking_of_non_temporary_events(0, 1);
											ai::task_turn_ped_to_face_entity(0, player::player_ped_id(), 1000);
											ai::task_play_anim(0, "misschinese2_bank1", "spot_high", 4f, -8f, -1, 0, 0,
															   0, 0, 0);
											ai::task_set_blocking_of_non_temporary_events(0, 0);
											func_92(&(*uParam0)[iVar0 /*24*/], 0);
											(*uParam0)[iVar0 /*24*/].f_5 = 4;
											break;

										case 2:
											func_93();
											ai::task_set_blocking_of_non_temporary_events(0, 1);
											ai::task_turn_ped_to_face_entity(0, player::player_ped_id(), 1000);
											ai::task_play_anim(0, "misschinese2_bank1", "spot_low", 4f, -8f, -1, 0, 0,
															   0, 0, 0);
											ai::task_set_blocking_of_non_temporary_events(0, 0);
											func_92(&(*uParam0)[iVar0 /*24*/], 0);
											(*uParam0)[iVar0 /*24*/].f_5 = 4;
											break;

										case 3:
											func_93();
											ai::task_set_blocking_of_non_temporary_events(0, 1);
											ai::task_turn_ped_to_face_entity(0, player::player_ped_id(), 1000);
											ai::task_play_anim(0, "misschinese2_bank1", "spot_mid", 4f, -8f, -1, 0, 0,
															   0, 0, 0);
											ai::task_set_blocking_of_non_temporary_events(0, 0);
											func_92(&(*uParam0)[iVar0 /*24*/], 0);
											(*uParam0)[iVar0 /*24*/].f_5 = 4;
											break;

										case 4:
											if (bLocal_56) {
												if (gameplay::absf(func_113((*uParam0)[iVar0 /*24*/],
																			player::player_ped_id())) < 20f) {
													if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/
													],
																					   "misschinese2_"
																					   "bank1",
																					   "spot_high", 3)) {
														if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/
														],
																								 "misschines"
																								 "e2_bank1",
																								 "spot_"
																								 "high") >
															func_108((func_4((*uParam0)[iVar0 /*24*/
														],
																			 player::player_ped_id(), 1) +
																	  5f) /
																		 35f,
																	 0.27f, 0.9f)) {
															(*uParam0)[iVar0 /*24*/].f_3 = 6;
															(*uParam0)[iVar0 /*24*/].f_1 = 10;
															(*uParam0)[iVar0 /*24*/].f_4 = 0;
														}
													}
													if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/
													],
																					   "misschinese2_"
																					   "bank1",
																					   "spot_mid", 3)) {
														if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/
														],
																								 "misschines"
																								 "e2_bank1",
																								 "spot_"
																								 "mid") >
															func_108((func_4((*uParam0)[iVar0 /*24*/
														],
																			 player::player_ped_id(), 1) +
																	  5f) /
																		 35f,
																	 0.27f, 0.9f)) {
															(*uParam0)[iVar0 /*24*/].f_3 = 6;
															(*uParam0)[iVar0 /*24*/].f_1 = 10;
															(*uParam0)[iVar0 /*24*/].f_4 = 0;
														}
													}
													if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/
													],
																					   "misschinese2_"
																					   "bank1",
																					   "spot_low", 3)) {
														if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/
														],
																								 "misschines"
																								 "e2_bank1",
																								 "spot_"
																								 "low") >
															func_108((func_4((*uParam0)[iVar0 /*24*/
														],
																			 player::player_ped_id(), 1) +
																	  5f) /
																		 35f,
																	 0.27f, 0.9f)) {
															(*uParam0)[iVar0 /*24*/].f_3 = 6;
															(*uParam0)[iVar0 /*24*/].f_1 = 10;
															(*uParam0)[iVar0 /*24*/].f_4 = 0;
														}
													}
												}
												else {
													(*uParam0)[iVar0 /*24*/].f_3 = 6;
													(*uParam0)[iVar0 /*24*/].f_1 = 10;
													(*uParam0)[iVar0 /*24*/].f_4 = 0;
												}
											}
											break;
										}
										break;
									}
								}
								else {
									(*uParam0)[iVar0 /*24*/].f_4++;
								}
							}
							break;

						case 1:
							if (!(*uParam0)[iVar0 /*24*/].f_21) {
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "alert_gunshot", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time(
											(*uParam0)[iVar0 /*24*/], "misschinese2_bank1", "alert_gunshot") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "buddy_shot_b", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time(
											(*uParam0)[iVar0 /*24*/], "misschinese2_bank1", "buddy_shot_b") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "reaction_forward_big_intro_a", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																			 "misschinese2_bank1",
																			 "reaction_forward_big_intro_a") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "alert_body", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time(
											(*uParam0)[iVar0 /*24*/], "misschinese2_bank1", "alert_body") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "react_forward_small_intro_a", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																			 "misschinese2_bank1",
																			 "react_forward_small_intro_a") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "react_backward_small_intro_a", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																			 "misschinese2_bank1",
																			 "react_backward_small_intro_a") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "react_left_small_intro_a", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																			 "misschinese2_bank1",
																			 "react_left_small_intro_a") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (entity::is_entity_playing_anim((*uParam0)[iVar0 /*24*/], "misschinese2_bank1",
																   "react_right_small_intro_a", 3)) {
									iVar14 = 1;
									if (entity::get_entity_anim_current_time((*uParam0)[iVar0 /*24*/],
																			 "misschinese2_bank1",
																			 "react_right_small_intro_a") > 0.9f) {
										iVar14 = 0;
									}
								}
								if (!iVar14) {
									(*uParam0)[iVar0 /*24*/].f_4 = 2;
									(*uParam0)[iVar0 /*24*/].f_5 = gameplay::get_game_timer() + 2000;
									ai::task_combat_ped((*uParam0)[iVar0 /*24*/], player::player_ped_id(), 0, 16);
									entity::set_entity_load_collision_flag((*uParam0)[iVar0 /*24*/], 1);
									ped::set_ped_target_loss_response((*uParam0)[iVar0 /*24*/], 1);
								}
							}
							break;

						case 2:
							if (gameplay::get_game_timer() > (*uParam0)[iVar0 /*24*/].f_5) {
								(*uParam0)[iVar0 /*24*/].f_3 = 5;
								(*uParam0)[iVar0 /*24*/].f_1 = 0;
								(*uParam0)[iVar0 /*24*/].f_4 = 0;
							}
							break;
						}
					}
					break;

				case 5:
				case 6:
					if (ped::is_ped_using_scenario((*uParam0)[iVar0 /*24*/], "PROP_HUMAN_SEAT_CHAIR") ||
						ped::is_ped_using_any_scenario((*uParam0)[iVar0 /*24*/])) {
						if (!ped::is_ped_injured((*uParam0)[iVar0 /*24*/])) {
							ai::clear_ped_tasks((*uParam0)[iVar0 /*24*/]);
						}
					}
					else {
						switch ((*uParam0)[iVar0 /*24*/].f_4) {
						case 0:
							(*uParam0)[iVar0 /*24*/].f_11 = 0;
							if (iVar0 == 12 || iVar0 == 13 || iVar0 == 14) {
							}
							weapon::set_current_ped_weapon((*uParam0)[iVar0 /*24*/],
														   weapon::get_best_ped_weapon((*uParam0)[iVar0 /*24*/], 0), 1);
							ped::set_blocking_of_non_temporary_events((*uParam0)[iVar0 /*24*/], 0);
							ped::_0xA3A9299C4F2ADB98((*uParam0)[iVar0 /*24*/]);
							ped::set_ped_combat_attributes((*uParam0)[iVar0 /*24*/], 50, 1);
							ped::set_ped_flee_attributes((*uParam0)[iVar0 /*24*/], 512, 1);
							(*uParam0)[iVar0 /*24*/].f_4++;
							break;

						case 1:
							if (!(*uParam0)[iVar0 /*24*/].f_20) {
								(*uParam1)[0 /*3*/] = {(*uParam1)[0 /*3*/]};
								iLocal_66 = iLocal_66;
								uLocal_70 = uLocal_70;
								ai::task_combat_ped((*uParam0)[iVar0 /*24*/], player::player_ped_id(), 0, 16);
								entity::set_entity_load_collision_flag((*uParam0)[iVar0 /*24*/], 1);
								ped::set_ped_target_loss_response((*uParam0)[iVar0 /*24*/], 1);
								(*uParam0)[iVar0 /*24*/].f_4++;
								(*uParam0)[iVar0 /*24*/].f_11 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(20000, 35000);
							}
							break;
						}
					}
					break;
				}
			}
		}
		iVar0++;
	}
}

// Position - 0xEA6A
float func_108(float fParam0, float fParam1, float fParam2) {
	if (fParam0 < fParam1) {
		return fParam1;
	}
	if (fParam0 > fParam2) {
		return fParam2;
	}
	return fParam0;
}

// Position - 0xEA8E
bool func_109(int iParam0, var *uParam1, char *sParam2, vector3 vParam3, vector3 vParam6, vector3 vParam9,
			  int iParam12) {
	switch ((*uParam1)[iParam0 /*24*/].f_5) {
	case 0:
		if (!gameplay::are_strings_equal("chi2_hear", vParam3.y)) {
			if (func_59()) {
				if (!func_82(vParam3.y)) {
					func_85();
				}
			}
			if (func_105(vParam3.y, vParam3.z, (*uParam1)[iParam0 /*24*/], vParam3.x, -1, 0, 0, -1, 0, 0, -1, 0, 0,
						 8)) {
				(*uParam1)[iParam0 /*24*/].f_12 = {entity::get_entity_coords((*uParam1)[iParam0 /*24*/], 1)};
				(*uParam1)[iParam0 /*24*/].f_18 = entity::get_entity_heading((*uParam1)[iParam0 /*24*/]);
				(*uParam1)[iParam0 /*24*/].f_5 = 0;
				(*uParam1)[iParam0 /*24*/].f_5++;
				(*uParam1)[iParam0 /*24*/].f_11 = gameplay::get_game_timer() + 1000;
			}
		}
		else {
			(*uParam1)[iParam0 /*24*/].f_12 = {entity::get_entity_coords((*uParam1)[iParam0 /*24*/], 1)};
			(*uParam1)[iParam0 /*24*/].f_18 = entity::get_entity_heading((*uParam1)[iParam0 /*24*/]);
			(*uParam1)[iParam0 /*24*/].f_5++;
		}
		break;

	case 1:
		if (gameplay::get_game_timer() > (*uParam1)[iParam0 /*24*/].f_11) {
			ai::task_turn_ped_to_face_coord((*uParam1)[iParam0 /*24*/],
											entity::get_entity_coords(player::player_ped_id(), 1), 5000);
			(*uParam1)[iParam0 /*24*/].f_5++;
			(*uParam1)[iParam0 /*24*/].f_11 = gameplay::get_game_timer() + 5000;
		}
		break;

	case 2:
		if (!gameplay::are_strings_equal("chi2_hear", vParam3.y)) {
			if ((player::can_ped_hear_player(player::player_id(), (*uParam1)[iParam0 /*24*/]) || iLocal_75 == 1) &&
				func_67((*uParam1)[iParam0 /*24*/], (*uParam1)[iParam0 /*24*/].f_12, 1) <
					(*uParam1)[iParam0 /*24*/].f_19) {
				if (gameplay::get_game_timer() > (*uParam1)[iParam0 /*24*/].f_11 - 3000) {
					ai::task_follow_nav_mesh_to_coord((*uParam1)[iParam0 /*24*/],
													  entity::get_entity_coords(player::player_ped_id(), 1), 1f, 20000,
													  0.1f, 0, 1193033728);
					(*uParam1)[iParam0 /*24*/].f_15 = {entity::get_entity_coords(player::player_ped_id(), 1)};
					(*uParam1)[iParam0 /*24*/].f_5 = 5;
				}
			}
			else if (gameplay::get_game_timer() > (*uParam1)[iParam0 /*24*/].f_11) {
				if (func_105(vParam9.y, vParam9.z, (*uParam1)[iParam0 /*24*/], vParam9.x, -1, 0, 0, -1, 0, 0, -1, 0, 0,
							 8)) {
					if (iParam12) {
					}
					(*uParam1)[iParam0 /*24*/].f_5++;
				}
			}
		}
		else if (gameplay::get_game_timer() > (*uParam1)[iParam0 /*24*/].f_11) {
			ai::task_achieve_heading((*uParam1)[iParam0 /*24*/], (*uParam1)[iParam0 /*24*/].f_18, 2000);
			(*uParam1)[iParam0 /*24*/].f_5 = 4;
		}
		break;

	case 3:
		func_93();
		ai::task_follow_nav_mesh_to_coord(0, (*uParam1)[iParam0 /*24*/].f_12, 1f, 20000, 0.2f, 4096, 1193033728);
		ai::task_achieve_heading(0, (*uParam1)[iParam0 /*24*/].f_18, 2000);
		func_92(&(*uParam1)[iParam0 /*24*/], 0);
		(*uParam1)[iParam0 /*24*/].f_11 = gameplay::get_game_timer() + 3000;
		(*uParam1)[iParam0 /*24*/].f_5++;
		break;

	case 4:
		if (ai::get_script_task_status((*uParam1)[iParam0 /*24*/], 242628503) == 7 ||
			gameplay::are_strings_equal("chi2_hear", vParam3.y) &&
				ai::get_script_task_status((*uParam1)[iParam0 /*24*/], 1920390111) == 7) {
			if (!gameplay::are_strings_equal(sParam2, "")) {
				ai::task_start_scenario_in_place((*uParam1)[iParam0 /*24*/], sParam2, 0, 1);
			}
			(*uParam1)[iParam0 /*24*/].f_4 = 0;
			(*uParam1)[iParam0 /*24*/].f_5 = 0;
			(*uParam1)[iParam0 /*24*/].f_1 = 0;
			(*uParam1)[iParam0 /*24*/].f_2 = 0;
			if (gameplay::are_strings_equal("chi2_hear", vParam3.y)) {
				(*uParam1)[iParam0 /*24*/].f_3 = 3;
			}
			else {
				(*uParam1)[iParam0 /*24*/].f_3 = 2;
			}
			iLocal_62 = -1;
		}
		break;

	case 5:
		if (func_105(vParam3.y, vParam6.z, (*uParam1)[iParam0 /*24*/], vParam3.x, -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
			(*uParam1)[iParam0 /*24*/].f_5++;
		}
		break;

	case 6:
		if (func_67((*uParam1)[iParam0 /*24*/], (*uParam1)[iParam0 /*24*/].f_15, 1) < 2f ||
			ai::get_script_task_status((*uParam1)[iParam0 /*24*/], 713668775) == 7) {
			if (!ped::is_ped_injured((*uParam1)[iParam0 /*24*/])) {
				ai::clear_ped_tasks((*uParam1)[iParam0 /*24*/]);
				func_93();
				ai::task_look_at_coord(
					0, entity::get_offset_from_entity_in_world_coords((*uParam1)[iParam0 /*24*/], -5f, 3f, 0f), 2500, 0,
					2);
				ai::task_look_at_coord(
					0, entity::get_offset_from_entity_in_world_coords((*uParam1)[iParam0 /*24*/], 5f, 3f, 0f), 2500, 0,
					2);
				func_92(&(*uParam1)[iParam0 /*24*/], 0);
				(*uParam1)[iParam0 /*24*/].f_11 = gameplay::get_game_timer() + 3000;
				(*uParam1)[iParam0 /*24*/].f_5 = 2;
			}
		}
		break;
	}
	return false;
}

// Position - 0xEEF2
bool func_110(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar1 = 1000f;
	iVar3 = -1;
	if (!ped::is_ped_dead_or_dying((*uParam1)[iParam0 /*24*/], 1)) {
		iVar0 = 0;
		while (iVar0 < *uParam1) {
			if (ped::is_ped_dead_or_dying((*uParam1)[iVar0 /*24*/], 1) &&
				entity::does_entity_exist((*uParam1)[iVar0 /*24*/])) {
				fVar2 = func_4((*uParam1)[iVar0 /*24*/], (*uParam1)[iParam0 /*24*/], 1);
				if (fVar2 < fVar1) {
					fVar1 = fVar2;
					iVar3 = iVar0;
				}
			}
			iVar0++;
		}
		if (iVar3 == -1) {
			return false;
		}
		else {
			(*uParam1)[iParam0 /*24*/].f_18 = func_113((*uParam1)[iParam0 /*24*/], (*uParam1)[iVar3 /*24*/]);
			if (gameplay::absf((*uParam1)[iParam0 /*24*/].f_18) > 20f) {
				if (iParam2) {
					ai::task_turn_ped_to_face_entity(0, (*uParam1)[iVar3 /*24*/], 0);
				}
				else {
					ai::task_turn_ped_to_face_entity((*uParam1)[iParam0 /*24*/], (*uParam1)[iVar3 /*24*/], 0);
				}
				(*uParam1)[iParam0 /*24*/].f_18 = func_111((*uParam1)[iParam0 /*24*/], (*uParam1)[iVar3 /*24*/], 1);
				return true;
			}
		}
	}
	return false;
}

// Position - 0xEFE4
float func_111(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	vVar0 = {entity::get_entity_coords(iParam0, 0)};
	vVar3 = {entity::get_entity_coords(iParam1, 0)};
	return func_96(vVar0, vVar3, iParam2);
}

// Position - 0xF010
int func_112() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar1 = -1;
	ai::task_play_anim(0, "misschinese2_bank1", "reaction_forward_big_intro_a", 4f, -2f, 1400, 0, 0, 0, 0, 0);
	iVar0 = 0;
	while (iVar0 <= 3) {
		iVar2 = gameplay::get_random_int_in_range(0, 3);
		iVar3 = gameplay::get_random_int_in_range(1100, 1800);
		iVar4 += iVar3;
		if (iVar2 == iVar1) {
			iVar2++;
			if (iVar2 > 2) {
				iVar2 = 0;
			}
		}
		iVar1 = iVar2;
		switch (iVar2) {
		case 0:
			iVar2 = gameplay::get_random_int_in_range(0, 4);
			switch (iVar2) {
			case 0:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@left", "reaction_left_big_intro_a", 4f, -2f, iVar3,
								   0, 0, 0, 0, 0);
				break;

			case 1:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@left", "reaction_left_big_intro_b", 4f, -2f, iVar3,
								   0, 0, 0, 0, 0);
				break;

			case 2:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@left", "reaction_left_big_intro_c", 4f, -2f, iVar3,
								   0, 0, 0, 0, 0);
				break;
			}
			break;

		case 1:
			iVar2 = gameplay::get_random_int_in_range(0, 4);
			switch (iVar2) {
			case 0:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@right", "reaction_right_big_intro_a", 4f, -2f,
								   iVar3, 0, 0, 0, 0, 0);
				break;

			case 1:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@right", "reaction_right_big_intro_b", 4f, -2f,
								   iVar3, 0, 0, 0, 0, 0);
				break;

			case 2:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@right", "reaction_right_big_intro_c", 4f, -2f,
								   iVar3, 0, 0, 0, 0, 0);
				break;
			}
			break;

		case 2:
			iVar2 = gameplay::get_random_int_in_range(0, 4);
			switch (iVar2) {
			case 0:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@backward", "reaction_backward_big_intro_a", 4f,
								   -2f, iVar3, 0, 0, 0, 0, 0);
				break;

			case 1:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@backward", "reaction_backward_big_intro_b", 4f,
								   -2f, iVar3, 0, 0, 0, 0, 0);
				break;

			case 2:
				ai::task_play_anim(0, "reaction@male_stand@big_intro@backward", "reaction_backward_big_intro_c", 4f,
								   -2f, iVar3, 0, 0, 0, 0, 0);
				break;
			}
			break;
		}
		iVar0++;
	}
	return iVar4;
}

// Position - 0xF1FF
float func_113(int iParam0, int iParam1) {
	if (entity::does_entity_exist(iParam0) && entity::does_entity_exist(iParam1)) {
		return func_114(iParam0, entity::get_entity_coords(iParam1, 0));
	}
	return 0f;
}

// Position - 0xF22C
float func_114(int iParam0, vector3 vParam1) {
	float fVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			fVar0 = func_96(entity::get_entity_coords(iParam0, 0), vParam1, 1);
			return fVar0 - entity::get_entity_heading(iParam0);
		}
	}
	return 0f;
}

// Position - 0xF26A
void func_115(var *uParam0, struct<2> Param1, var uParam3, struct<2> Param4, var uParam6, struct<2> Param7, var uParam9,
			  struct<2> Param10, var uParam12) {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar3;
	vector3 vVar6;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	float fVar16;
	int iVar17;

	if (!iLocal_53 == 1) {
		bLocal_258 = false;
		if (ped::is_ped_shooting(player::player_ped_id()) || controls::is_control_pressed(0, 24)) {
			iVar0 = 0;
			while (iVar0 < *uParam0) {
				if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1)) {
					iVar1++;
				}
				iVar0++;
			}
			if (iLocal_259 == 0) {
				iLocal_259 = iVar1;
			}
			if (iVar1 < iLocal_259) {
				iLocal_259 = iVar1;
				bLocal_258 = true;
			}
		}
		iVar2 = 4;
		while (iVar2 > 0) {
			if (!ped::is_ped_dead_or_dying((*uParam0)[iLocal_58 /*24*/], 1)) {
				if ((*uParam0)[iLocal_58 /*24*/].f_3 > 3 && (*uParam0)[iLocal_58 /*24*/].f_1 > 1) {
					iVar0 = 0;
					while (iVar0 < *uParam0) {
						if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1)) {
							if (iVar0 != iLocal_58) {
								if ((*uParam0)[iVar0 /*24*/].f_3 <= 4) {
									if (func_4((*uParam0)[iVar0 /*24*/], (*uParam0)[iLocal_58 /*24*/], 1) < 8f) {
										if (interior::get_interior_from_entity((*uParam0)[iLocal_58 /*24*/]) != 0 &&
												interior::get_interior_from_entity((*uParam0)[iVar0 /*24*/
										]) != 0 ||
											interior::get_interior_from_entity((*uParam0)[iLocal_58 /*24*/]) == 0 &&
												interior::get_interior_from_entity((*uParam0)[iVar0 /*24*/
										]) == 0) {
											vVar3 = {entity::get_entity_coords((*uParam0)[iVar0 /*24*/], 1)};
											vVar6 = {entity::get_entity_coords((*uParam0)[iLocal_58 /*24*/], 0)};
											if (gameplay::absf(vVar3.z - vVar6.z) < 2f) {
												(*uParam0)[iVar0 /*24*/].f_7 = 1;
												(*uParam0)[iVar0 /*24*/].f_10 = iLocal_58;
											}
										}
									}
								}
							}
						}
						iVar0++;
					}
				}
				else {
					fVar9 = 10f;
					fVar10 = 11f;
					(*uParam0)[iLocal_58 /*24*/].f_22 = -1;
					(*uParam0)[iLocal_58 /*24*/].f_23 = -1;
					iVar0 = 0;
					while (iVar0 < *uParam0) {
						if (iVar0 != iLocal_58) {
							if (entity::does_entity_exist((*uParam0)[iVar0 /*24*/])) {
								fVar11 = func_4((*uParam0)[iVar0 /*24*/], (*uParam0)[iLocal_58 /*24*/], 1);
								if (fVar11 < 10f) {
									fVar12 = func_113((*uParam0)[iLocal_58 /*24*/], (*uParam0)[iVar0 /*24*/]);
									if (fVar12 > -90f && fVar12 < 90f) {
										if (fVar11 < fVar9) {
											(*uParam0)[iLocal_58 /*24*/].f_23 = (*uParam0)[iLocal_58 /*24*/].f_22;
											(*uParam0)[iLocal_58 /*24*/].f_22 = iVar0;
											fVar10 = fVar9;
											fVar9 = fVar11;
										}
										else if (fVar11 < fVar10) {
											fVar10 = fVar11;
											(*uParam0)[iLocal_58 /*24*/].f_23 = iVar0;
										}
									}
								}
							}
						}
						iVar0++;
					}
				}
			}
			iLocal_58++;
			if (iLocal_58 >= *uParam0) {
				iLocal_58 = 0;
			}
			iVar2--;
		}
	}
	if (ped::is_ped_in_any_heli(player::player_ped_id())) {
		iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (vehicle::is_vehicle_driveable(iVar13, 0)) {
			if (vehicle::get_is_vehicle_engine_running(iVar13)) {
				iVar14 = 1;
			}
		}
	}
	if (fire::is_explosion_in_sphere(-1, vLocal_71, fLocal_74)) {
		bLocal_54 = true;
	}
	if (!iLocal_55) {
		if (func_82(Param1.f_1) || func_82(Param4.f_1)) {
			iLocal_59 = gameplay::get_game_timer() + 1000;
			iLocal_55 = 1;
		}
		if (func_82(Param7.f_1) || func_82(Param10.f_1)) {
			iLocal_59 = gameplay::get_game_timer() + 1000;
			iLocal_55 = 1;
		}
	}
	else if (!func_82(Param1.f_1) && !func_82(Param4.f_1) && !func_82(Param7.f_1) && !func_82(Param10.f_1)) {
		iLocal_55 = 0;
	}
	else if (gameplay::get_game_timer() > iLocal_59) {
		if (func_82(Param1.f_1) || func_82(Param4.f_1)) {
			iLocal_53 = 1;
		}
		if (func_82(Param7.f_1) || func_82(Param10.f_1)) {
			bLocal_56 = true;
		}
	}
	iLocal_60 = 0;
	iVar15 = -1;
	fVar16 = 13f;
	iLocal_57 = 0;
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		iVar17 = ped::get_vehicle_ped_is_using(player::player_ped_id());
	}
	if (iLocal_62 == -1) {
		iLocal_75 = 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (!ped::is_ped_dead_or_dying((*uParam0)[iVar0 /*24*/], 1)) {
			if ((*uParam0)[iVar0 /*24*/].f_3 != 7) {
				(*uParam0)[iVar0 /*24*/].f_2 = (*uParam0)[iVar0 /*24*/].f_1;
				(*uParam0)[iVar0 /*24*/].f_1 = 0;
				if ((*uParam0)[iVar0 /*24*/].f_3 <= 4) {
					if (iLocal_62 == -1) {
						if (vehicle::is_vehicle_driveable(iVar17, 0)) {
							if (vehicle::get_is_vehicle_engine_running(iVar17)) {
								iLocal_75 = 1;
								fVar16 = 20f;
							}
							if (vehicle::is_vehicle_siren_on(iVar17)) {
								iLocal_75 = 1;
								fVar16 = 50f;
							}
						}
						if (player::can_ped_hear_player(player::player_id(), (*uParam0)[iVar0 /*24*/]) ||
							vehicle::is_vehicle_driveable(iVar17, 0) &&
								vehicle::get_is_vehicle_engine_running(iVar17)) {
							if (func_4(player::player_ped_id(), (*uParam0)[iVar0 /*24*/], 1) < fVar16) {
								if ((*uParam0)[iVar0 /*24*/].f_8) {
									if (interior::get_interior_from_entity(player::player_ped_id()) ==
										interior::get_interior_from_entity((*uParam0)[iVar0 /*24*/])) {
										fVar16 = func_4(player::player_ped_id(), (*uParam0)[iVar0 /*24*/], 1);
										iVar15 = iVar0;
										(*uParam0)[iVar0 /*24*/].f_1 = 1;
										(*uParam0)[iVar0 /*24*/].f_19 = fVar16 + 5f;
									}
								}
							}
						}
					}
					if ((*uParam0)[iVar0 /*24*/].f_7) {
						(*uParam0)[iVar0 /*24*/].f_7 = 0;
						(*uParam0)[iVar0 /*24*/].f_1 = 2;
					}
					if (bLocal_54) {
						(*uParam0)[iVar0 /*24*/].f_1 = 3;
					}
					if (iLocal_53) {
						(*uParam0)[iVar0 /*24*/].f_1 = 4;
					}
					if (bLocal_258) {
					}
					if (!bLocal_258 && !ped::is_ped_ragdoll((*uParam0)[iVar0 /*24*/])) {
						if (ped::is_ped_responding_to_event((*uParam0)[iVar0 /*24*/], 123)) {
							(*uParam0)[iVar0 /*24*/].f_1 = 7;
						}
						if (ped::has_ped_received_event((*uParam0)[iVar0 /*24*/], 123)) {
							(*uParam0)[iVar0 /*24*/].f_1 = 7;
							if (ped::is_ped_responding_to_event((*uParam0)[iVar0 /*24*/], 17)) {
							}
						}
						if ((*uParam0)[iVar0 /*24*/].f_9) {
							if (gameplay::has_bullet_impacted_in_area(
									entity::get_entity_coords((*uParam0)[iVar0 /*24*/], 1), 4f, 1, 1)) {
								(*uParam0)[iVar0 /*24*/].f_1 = 7;
							}
						}
						else if (gameplay::has_bullet_impacted_in_area(
									 entity::get_entity_coords((*uParam0)[iVar0 /*24*/], 1), 6f, 1, 1)) {
							(*uParam0)[iVar0 /*24*/].f_1 = 7;
						}
						if (ped::is_ped_responding_to_event((*uParam0)[iVar0 /*24*/], 124)) {
							(*uParam0)[iVar0 /*24*/].f_1 = 7;
						}
						if (gameplay::is_bullet_in_area(entity::get_entity_coords((*uParam0)[iVar0 /*24*/], 1), 1f,
														1)) {
							(*uParam0)[iVar0 /*24*/].f_1 = 7;
						}
					}
					if ((*uParam0)[iVar0 /*24*/].f_3 < 4) {
						if ((*uParam0)[iVar0 /*24*/].f_22 != -1) {
							if (entity::does_entity_exist((*uParam0)[(*uParam0)[iVar0 /*24*/].f_22 /*24*/])) {
								if (ped::is_ped_dead_or_dying((*uParam0)[(*uParam0)[iVar0 /*24*/].f_22 /*24*/], 1)) {
									if (entity::has_entity_clear_los_to_entity_in_front(
											(*uParam0)[iVar0 /*24*/],
											(*uParam0)[(*uParam0)[iVar0 /*24*/].f_22 /*24*/])) {
										(*uParam0)[iVar0 /*24*/].f_1 = 5;
									}
								}
							}
						}
						if ((*uParam0)[iVar0 /*24*/].f_23 != -1) {
							if (entity::does_entity_exist((*uParam0)[(*uParam0)[iVar0 /*24*/].f_23 /*24*/])) {
								if (ped::is_ped_dead_or_dying((*uParam0)[(*uParam0)[iVar0 /*24*/].f_23 /*24*/], 1)) {
									if (entity::has_entity_clear_los_to_entity_in_front(
											(*uParam0)[iVar0 /*24*/],
											(*uParam0)[(*uParam0)[iVar0 /*24*/].f_23 /*24*/])) {
										(*uParam0)[iVar0 /*24*/].f_1 = 5;
									}
								}
							}
						}
					}
				}
				if ((*uParam0)[iVar0 /*24*/].f_3 <= 5) {
					if ((*uParam0)[iVar0 /*24*/].f_1 == 0) {
						if (*uParam0)
							[iVar0 /*24*/].f_3 > 4 || ped::is_ped_in_combat((*uParam0)[iVar0 /*24*/], 0) {
								(*uParam0)[iVar0 /*24*/].f_1 = 8;
							}
					}
					if (ped::is_ped_responding_to_event((*uParam0)[iVar0 /*24*/], 1) ||
						ped::has_ped_received_event((*uParam0)[iVar0 /*24*/], 1) ||
						ped::is_ped_in_combat((*uParam0)[iVar0 /*24*/], 0) &&
							ped::can_ped_in_combat_see_target((*uParam0)[iVar0 /*24*/], player::player_ped_id()) ||
						func_116((*uParam0)[iVar0 /*24*/]) &&
							ped::has_ped_received_event((*uParam0)[iVar0 /*24*/], 1)) {
						if ((*uParam0)[iVar0 /*24*/].f_3 > 4) {
							(*uParam0)[iVar0 /*24*/].f_1 = 9;
						}
						else {
							(*uParam0)[iVar0 /*24*/].f_1 = 6;
						}
					}
				}
				if (iVar14 && func_4(player::player_ped_id(), (*uParam0)[iVar0 /*24*/], 1) < 50f) {
					(*uParam0)[iVar0 /*24*/].f_1 = 6;
				}
				if ((*uParam0)[iVar0 /*24*/].f_3 <= 6) {
					if (bLocal_56) {
						(*uParam0)[iVar0 /*24*/].f_1 = 10;
					}
				}
				if ((*uParam0)[iVar0 /*24*/].f_1 <= (*uParam0)[iVar0 /*24*/].f_2) {
					(*uParam0)[iVar0 /*24*/].f_1 = (*uParam0)[iVar0 /*24*/].f_2;
				}
				else {
					(*uParam0)[iVar0 /*24*/].f_3 = 4;
					(*uParam0)[iVar0 /*24*/].f_4 = 0;
					(*uParam0)[iVar0 /*24*/].f_5 = 0;
				}
				if ((*uParam0)[iVar0 /*24*/].f_1 > iLocal_60) {
					iLocal_60 = (*uParam0)[iVar0 /*24*/].f_1;
					iLocal_61 = iVar0;
				}
			}
			else {
				(*uParam0)[iVar0 /*24*/].f_3 = 0;
				(*uParam0)[iVar0 /*24*/].f_1 = 0;
			}
			if ((*uParam0)[iVar0 /*24*/].f_3 > 3) {
				iLocal_57 = 1;
			}
		}
		iVar0++;
	}
	if (iLocal_62 == -1) {
		if (iVar15 != -1) {
			if (1 > (*uParam0)[iVar15 /*24*/].f_1) {
				(*uParam0)[iVar15 /*24*/].f_1 = 1;
				iLocal_62 = iVar15;
			}
		}
	}
	else if (ped::is_ped_dead_or_dying((*uParam0)[iLocal_62 /*24*/], 1)) {
		iLocal_62 = -1;
	}
}

// Position - 0xFAAE
int func_116(int iParam0) {
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "alert_gunshot", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "buddy_shot_b", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "reaction_forward_big_intro_a", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "alert_body", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "react_forward_small_intro_a", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "react_backward_small_intro_a", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "react_left_small_intro_a", 3)) {
		return 1;
	}
	if (entity::is_entity_playing_anim(iParam0, "misschinese2_bank1", "react_right_small_intro_a", 3)) {
		return 1;
	}
	return 0;
}

// Position - 0xFB5F
void func_117() {
	if (iLocal_3491) {
		if (gameplay::is_string_null_or_empty(&vLocal_3498)) {
			if (func_59()) {
				if (audio::is_scripted_conversation_ongoing()) {
					if (!ui::is_message_being_displayed()) {
						cLocal_3492 = {func_118()};
						vLocal_3498 = {func_83()};
						StringCopy(&vLocal_3498, "", 24);
						if (!gameplay::is_string_null_or_empty(&cLocal_3492) &&
							!gameplay::are_strings_equal(&cLocal_3492, "NULL")) {
							vLocal_3498 = {func_83()};
							func_85();
						}
						else {
							iLocal_3491 = 0;
							StringCopy(&vLocal_3498, "", 24);
							StringCopy(&cLocal_3492, "", 24);
						}
					}
				}
			}
			else {
				iLocal_3491 = 0;
				StringCopy(&vLocal_3498, "", 24);
				StringCopy(&cLocal_3492, "", 24);
			}
		}
		else {
			if (audio::is_scripted_conversation_ongoing()) {
				if (!func_82(&vLocal_3498)) {
					iLocal_3491 = 0;
					StringCopy(&vLocal_3498, "", 24);
					StringCopy(&cLocal_3492, "", 24);
				}
			}
			if (!gameplay::is_string_null_or_empty(&vLocal_3498)) {
				vLocal_3478[0 /*3*/] = {vLocal_3478[0 /*3*/]};
			}
		}
	}
}

// Position - 0xFC47
struct<6> func_118() {
	struct<6> Var0;
	int iVar6;
	int iVar7;
	int iVar8;

	StringCopy(&Var0, "NULL", 24);
	if (Global_15745 == 4) {
		iVar6 = audio::get_current_scripted_conversation_line();
		iVar6 += Global_16755;
		iVar7 = iVar6 + 1;
		if (iVar7 > -1 && iVar6 > -1) {
			if (ui::does_text_label_exist(&Global_14613[iVar7 /*6*/])) {
				return Global_14613[iVar7 /*6*/];
			}
			else {
				iVar8 = iVar7;
				while (iVar8 < 70) {
					if (ui::does_text_label_exist(&Global_14613[iVar8 /*6*/])) {
						return Global_14613[iVar8 /*6*/];
						iVar8 = 70;
					}
					iVar8++;
				}
				return Var0;
			}
			return Global_14613[iVar6 /*6*/];
		}
		else {
			return Var0;
		}
	}
	return Var0;
}

//Position - 0xFCF3
void func_119()
{
	if (!ped::is_ped_injured(player::player_ped_id())) {
		func_126();
		func_125();
		func_123();
		func_120();
	}
}

// Position - 0xFD17
void func_120() {
	int iVar0;
	vector3 vVar1;
	float fVar4;
	int iVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;

	vVar1 = {0f, 0f, 0f};
	if (iLocal_437 == 0) {
		if (fire::get_closest_fire_pos(&vVar1, Local_444[0 /*5*/])) {
			fVar4 = 0f;
			fVar7 = 999999f;
			iVar0 = 0;
			while (iVar0 < Local_444) {
				if (iVar0 > 0) {
					fVar4 +=
						gameplay::get_distance_between_coords(Local_444[iVar0 - 1 /*5*/], Local_444[iVar0 /*5*/], 1);
				}
				if (Local_444[iVar0 /*5*/].f_4) {
					if (fire::get_closest_fire_pos(&vVar1, Local_444[iVar0 /*5*/])) {
						fVar6 = gameplay::get_distance_between_coords(Local_444[iVar0 /*5*/], vVar1, 1);
						if (fVar6 < fVar7) {
							fVar7 = fVar6;
							fVar8 = fVar4;
							iVar5 = iVar0;
						}
					}
				}
				iVar0++;
			}
			if (fVar7 < fLocal_272) {
				iVar5 = iVar5;
				iLocal_437 = 1;
				iLocal_439 = gameplay::get_game_timer();
				fVar8 = fVar8;
				vLocal_277 = {Local_444[iVar5 /*5*/]};
				iLocal_280 = iVar5;
				iLocal_440 = iVar5 * 2;
				iLocal_442 = iLocal_440;
				iLocal_443 = iLocal_440;
				if (iLocal_443 < 0) {
					iLocal_443 = 0;
				}
				if (iLocal_442 >= Local_444 * 2) {
					iLocal_442 = Local_444 * 2 - 1;
				}
			}
		}
	}
	if (iLocal_437 == 1) {
		graphics::_0xD9454B5752C857DC();
		fVar9 = system::to_float(gameplay::get_game_timer() - iLocal_439) / fLocal_750;
		iVar10 = system::floor(fVar9 / (1f / 2f)) - 1;
		iVar11 = iLocal_440 + iVar10;
		iVar12 = iLocal_440 - iVar10;
		if (iVar11 >= 122) {
			iVar11 = 121;
		}
		if (iVar12 < 0) {
			iVar12 = 0;
		}
		if (iVar11 > iLocal_442) {
			iVar0 = iLocal_442 + 1;
			while (iVar0 <= iVar11) {
				iVar13 = iVar0 / 2;
				if (iVar13 < Local_444) {
					if (Local_444[iVar13 /*5*/].f_4) {
						func_121(iVar0, 1);
					}
					else {
						iVar11 = iVar0 - 1;
						iVar0 = iVar11 + 1;
					}
				}
				iVar0++;
			}
			iLocal_442 = iVar11;
		}
		if (iVar12 < iLocal_443) {
			iVar0 = iLocal_443 - 1;
			while (iVar0 >= iVar12) {
				iVar13 = iVar0 / 2;
				if (iVar13 < Local_444) {
					if (Local_444[iVar13 /*5*/].f_4) {
						func_121(iVar0, 1);
					}
					else {
						iVar12 = iVar0 + 1;
						iVar0 = iVar12 - 1;
					}
				}
				iVar0 += -1;
			}
			iLocal_443 = iVar12;
		}
		iVar0 = 0;
		while (iVar0 < Local_281) {
			if (gameplay::get_game_timer() - Local_281[iVar0 /*5*/].f_4 > 1000) {
				graphics::fade_decals_in_range(Local_281[iVar0 /*5*/].f_1, 0.4f, 1f);
			}
			if (gameplay::get_game_timer() - Local_281[iVar0 /*5*/].f_4 > 6000) {
				fire::remove_script_fire(Local_281[iVar0 /*5*/]);
			}
			iVar0++;
		}
	}
}

// Position - 0xFF7B
void func_121(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 >= 0) {
		if (iParam0 % 2 == 1) {
			iVar0 = iParam0 / 2;
			if (iVar0 + 1 < 61) {
				func_122(Local_444[iParam0 / 2 /*5*/] + Local_444[iParam0 / 2 + 1 /*5*/] / FtoV(2f) + FtoV(fLocal_273),
						 iParam1);
			}
		}
		else if (iParam0 / 2 < 61) {
			func_122(Local_444[iParam0 / 2 /*5*/] + FtoV(fLocal_273), iParam1);
		}
	}
}

// Position - 0xFFE9
void func_122(vector3 vParam0, int iParam3) {
	if (iLocal_438 == 0) {
		iParam3 = 0;
	}
	fire::remove_script_fire(Local_281[iLocal_441 /*5*/]);
	if (Local_281[iLocal_441 /*5*/].f_4 != 0) {
		graphics::fade_decals_in_range(Local_281[iLocal_441 /*5*/].f_1, 0.4f, 1f);
	}
	Local_281[iLocal_441 /*5*/].f_4 = gameplay::get_game_timer();
	Local_281[iLocal_441 /*5*/].f_1 = {vParam0};
	Local_281[iLocal_441 /*5*/] = fire::start_script_fire(vParam0, iLocal_270, iParam3);
	iLocal_441++;
	if (iLocal_441 >= 31) {
		iLocal_441 = 0;
	}
}

// Position - 0x10074
void func_123() {
	int iVar0;
	int iVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	int iVar5;
	int iVar6;

	if (bLocal_265) {
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (iVar1 == joaat("weapon_petrolcan")) {
			if (controls::is_control_pressed(0, 24) && ped::is_ped_shooting(player::player_ped_id())) {
				if (iLocal_271 == 0) {
					unk1::_0x293220DA1B46CEBC(2f, 8f, 4);
					iLocal_271 = gameplay::get_game_timer() + 250;
				}
				if (gameplay::get_game_timer() > iLocal_271) {
					if (!bLocal_261) {
						fVar4 = 9999.9f;
						vLocal_274 = {func_124()};
						iVar0 = 0;
						while (iVar0 < Local_444) {
							if (ui::does_blip_exist(Local_444[iVar0 /*5*/].f_3)) {
								fVar2 = gameplay::get_distance_between_coords(
									vLocal_274, ui::get_blip_coords(Local_444[iVar0 /*5*/].f_3), 1);
								fVar3 = gameplay::get_distance_between_coords(
									Local_444[iVar0 /*5*/], ui::get_blip_coords(Local_444[iVar0 /*5*/].f_3), 1);
								if (fVar3 == 0f || fVar2 < fVar3) {
									if (fVar2 < 2f) {
										Local_444[iVar0 /*5*/] = {vLocal_274};
									}
								}
								if (fVar2 < fVar4) {
									fVar4 = fVar2;
									iVar5 = iVar0;
								}
							}
							iVar0++;
						}
						if (fVar4 < 2f) {
							if (iLocal_267 != -1) {
								if (gameplay::absi(iLocal_268 - iVar5) > 1) {
									iLocal_268 = -1;
								}
								if (iLocal_268 == -1) {
									iLocal_268 = iLocal_267;
								}
								if (gameplay::absi(iLocal_268 - iVar5) < 3 && gameplay::absi(iLocal_268 - iVar5) > 0) {
									if (iLocal_268 < iVar5) {
										iVar6 = iLocal_268;
										while (iVar6 <= iVar5 - 1) {
											if (ui::does_blip_exist(Local_444[iVar6 /*5*/].f_3)) {
												if (ui::get_blip_alpha(Local_444[iVar6 /*5*/].f_3) > 0) {
													ui::set_blip_alpha(Local_444[iVar6 /*5*/].f_3, 0);
													Local_444[iVar6 /*5*/].f_4 = 1;
													iLocal_269--;
												}
											}
											iVar6++;
										}
									}
									else {
										iVar6 = iVar5 + 1;
										while (iVar6 <= iLocal_268) {
											if (ui::does_blip_exist(Local_444[iVar6 /*5*/].f_3)) {
												if (ui::get_blip_alpha(Local_444[iVar6 /*5*/].f_3) > 0) {
													ui::set_blip_alpha(Local_444[iVar6 /*5*/].f_3, 0);
													Local_444[iVar6 /*5*/].f_4 = 1;
													iLocal_269--;
												}
											}
											iVar6++;
										}
									}
									iLocal_268 = iLocal_267;
								}
								if (iVar5 == 0) {
									if (ui::does_blip_exist(Local_444[iVar5 /*5*/].f_3)) {
										if (ui::get_blip_alpha(Local_444[iVar5 /*5*/].f_3) > 0) {
											ui::set_blip_alpha(Local_444[iVar5 /*5*/].f_3, 0);
											Local_444[iVar5 /*5*/].f_4 = 1;
											iLocal_269--;
										}
									}
								}
								if (iVar5 == 60) {
									if (ui::does_blip_exist(Local_444[iVar5 /*5*/].f_3)) {
										if (ui::get_blip_alpha(Local_444[iVar5 /*5*/].f_3) > 0) {
											ui::set_blip_alpha(Local_444[iVar5 /*5*/].f_3, 0);
											Local_444[iVar5 /*5*/].f_4 = 1;
											iLocal_269--;
										}
									}
								}
								if (iVar5 < 60) {
									if (func_71(Local_444[iVar5 + 1 /*5*/])) {
										if (ui::does_blip_exist(Local_444[iVar5 /*5*/].f_3)) {
											if (ui::get_blip_alpha(Local_444[iVar5 /*5*/].f_3) > 0) {
												ui::set_blip_alpha(Local_444[iVar5 /*5*/].f_3, 0);
												Local_444[iVar5 /*5*/].f_4 = 1;
												iLocal_269--;
											}
										}
									}
								}
							}
							iLocal_267 = iVar5;
						}
					}
				}
			}
			else {
				iLocal_267 = -1;
				iLocal_268 = -1;
				iLocal_271 = 0;
			}
		}
	}
}

// Position - 0x10387
Vector3 func_124() {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	var uVar8;

	iVar0 = weapon::get_current_ped_weapon_entity_index(player::player_ped_id());
	if (entity::does_entity_exist(iVar0)) {
		iVar1 = entity::get_entity_bone_index_by_name(iVar0, "Gun_Nuzzle");
		iVar1 = 1;
		vVar2 = {entity::get_world_position_of_entity_bone(iVar0, iVar1)};
		vVar2 = {object::_get_object_offset_from_coords(vVar2, entity::get_entity_heading(iVar0), 0.35f, 0f, -0.15f)};
		gameplay::get_ground_z_for_3d_coord(vVar2, &uVar8, 0);
		vVar5 = {vVar2.x, vVar2.y, uVar8};
	}
	return vVar5;
}

// Position - 0x103F6
void func_125() {
	int iVar0;

	if (iLocal_263) {
		if (iLocal_437) {
			iVar0 = 0;
			while (iVar0 < Local_281) {
				fire::remove_script_fire(Local_281[iVar0 /*5*/]);
				iVar0++;
			}
		}
		iLocal_263 = 0;
		iLocal_437 = 1;
		iLocal_439 = gameplay::get_game_timer();
		iVar0 = 0;
		while (iVar0 < Local_444) {
			Local_444[iVar0 /*5*/].f_4 = 1;
			iVar0++;
		}
		if (iLocal_266 != -1) {
			iLocal_443 = iLocal_266;
			iLocal_442 = iLocal_266;
			iLocal_440 = iLocal_266;
		}
		else {
			iLocal_443 = -1;
			iLocal_442 = -1;
			iLocal_440 = iLocal_266;
		}
		iLocal_441 = 1;
	}
}

// Position - 0x10484
void func_126() {
	if (!iLocal_264) {
		iLocal_264 = 1;
	}
}

// Position - 0x10497
void func_127() {
	int iVar0;

	if (iLocal_2511 >= 4) {
		iVar0 = 0;
		while (iVar0 < Local_755) {
			if (entity::does_entity_exist(Local_755[iVar0 /*33*/])) {
				if (!Local_755[iVar0 /*33*/].f_23) {
					if (ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
						Local_755[iVar0 /*33*/].f_23 = 1;
						func_9(151, 1, 0);
					}
				}
				if (ped::get_ped_relationship_group_hash(Local_755[iVar0 /*33*/]) == iLocal_1616) {
					func_97(Local_755[iVar0 /*33*/], &Local_755[iVar0 /*33*/].f_25, -1, 0, 0, 0, -1082130432, 0, -1, -1,
							1);
				}
			}
			else if (Local_755[iVar0 /*33*/] != 0) {
				func_128(&Local_755[iVar0 /*33*/].f_25);
				Local_755[iVar0 /*33*/] = 0;
			}
			iVar0++;
		}
	}
}

// Position - 0x1054B
void func_128(int *iParam0) {
	bool bVar0;
	struct<8> Var1;

	if (ui::does_blip_exist(*uParam0)) {
		ui::remove_blip(uParam0);
		bVar0 = true;
	}
	if (ui::does_blip_exist(iParam0->f_1)) {
		ui::remove_blip(&iParam0->f_1);
		bVar0 = true;
	}
	if (entity::does_entity_exist(iParam0->f_7)) {
		if (!ped::is_ped_injured(iParam0->f_7)) {
			if (ui::does_ped_have_ai_blip(iParam0->f_7)) {
				ui::_set_ped_enemy_ai_blip(iParam0->f_7, 0);
			}
		}
		bVar0 = true;
	}
	if (bVar0) {
		*iParam0 = {Var1};
	}
}

// Position - 0x105B9
void func_129() {
	int iVar0;

	iVar0 = iLocal_2511;
	func_351();
	switch (iLocal_2511) {
	case 0: func_264(); break;

	case 1: func_261(); break;

	case 2: func_216(); break;

	case 3: func_201(); break;

	case 4: func_200(); break;

	case 5: func_200(); break;

	case 6: func_200(); break;

	case 7: func_196(); break;

	case 8: func_175(); break;

	case 9: func_143(); break;
	}
	if (iLocal_2511 != iVar0) {
		iLocal_2512 = 0;
	}
	if (bLocal_2514) {
		func_130(0);
	}
}

// Position - 0x1066B
void func_130(char *sParam0) {
	while (!audio::trigger_music_event("CHN2_MISSION_FAIL")) {
		func_28(21, 1);
	}
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		sLocal_2513 = sParam0;
	}
	if (gameplay::is_string_null(sLocal_2513)) {
		sLocal_2513 = "CHFAIL";
	}
	func_132(sLocal_2513);
	while (!func_131()) {
		func_28(2, 0);
	}
	func_413(1);
}

// Position - 0x106C6
int func_131() {
	if (Global_3) {
		return 1;
	}
	if (Global_91491 == 7 || Global_91491 == 8) {
		return 1;
	}
	return 0;
}

// Position - 0x106F3
void func_132(char *sParam0) {
	func_142(sParam0);
	func_133(0);
}

// Position - 0x10706
void func_133(int iParam0) {
	int iVar0;

	if (Global_101700.f_8044 || func_141(0)) {
		iVar0 = func_140();
		if (!func_134(iVar0)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
		Global_91527 = iParam0;
	}
}

// Position - 0x1074B
int func_134(int iParam0) {
	int iVar0;
	int iVar1;

	func_139();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_138(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_135(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0x10862
void func_135(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_137(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_136(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0x10A2B
void func_136(int *iParam0) { *iParam0 = -15; }

// Position - 0x10A39
int func_137(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_137(8, uParam1, fParam2);

	case 10: return func_137(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0x113A8
void func_138(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x113E6
void func_139() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_43()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_43()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x114D5
int func_140() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1150A
bool func_141(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x11535
void func_142(char *sParam0) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (ui::get_length_of_literal_string(sParam0) <= 16) {
			StringCopy(&Global_69934, sParam0, 16);
			StringCopy(&Global_69938, "", 16);
			if (unk1::_is_recording()) {
				unk1::_stop_recording_and_save_clip();
			}
		}
	}
}

// Position - 0x11575
void func_143() {
	func_170(46, 52);
	func_160(1, 49, 0, 2, 48, 1, 0, 1, 0, 1, 0);
	func_160(2, 52, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(3, 53, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(4, 54, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(5, 55, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(0, 27, 0, 0, 1, 0, 1, 0, 1, 0);
	func_149(0, 12, 0, 0, 1, 0, 1, 0);
	func_148();
	if (func_147(1, 49)) {
		func_144();
	}
}

// Position - 0x11603
void func_144() {
	ui::clear_prints();
	func_145(0, 0);
	func_413(0);
}

// Position - 0x1161A
void func_145(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (!Global_55824) {
		Global_55824 = iParam1;
	}
	if (iParam0) {
		if (func_141(0) && Global_69948.f_1 == 1 && func_146(Global_69948)) {
		}
		else {
			Global_55822 = 1;
		}
	}
	if (Global_101700.f_8044 || func_141(0)) {
		iVar0 = func_140();
		iVar1 = Global_82576[iVar0 /*5*/];
		uVar2 = G_TextMessageConfig.f_109[iVar1 /*4*/];
		if (iVar0 == -1) {
			if (Global_101700.f_8044) {
			}
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 4)) {
			return;
		}
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 5)) {
			return;
		}
		gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 4);
		gameplay::set_bit(&Global_69950, 1);
		Global_69966 = uVar2;
		Global_69967 = gameplay::get_game_timer();
	}
}

// Position - 0x116F0
int func_146(int iParam0) {
	switch (iParam0) {
	case 71: return 1;

	case 86: return 1;

	case 91: return 1;

	default: return 0;
	}
	return 0;
}

// Position - 0x1172E
bool func_147(int iParam0, int iParam1) {
	if (Local_2917[iParam0 /*10*/] == iParam1) {
		if (Local_2917[iParam0 /*10*/].f_3 == 1) {
			return true;
		}
	}
	return false;
}

// Position - 0x11754
void func_148() {
	vector3 vVar0;

	vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	if (entity::is_entity_in_angled_area(player::player_ped_id(), 2432.476f, 4953.242f, 43.05545f, 2466.34f, 4986.15f,
										 57.25303f, 14.4375f, 0, 1, 0)) {
		if (vVar0.z < 50f) {
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2436.762f, 4956.011f, 44.49009f, 2443.38f,
												 4962.625f, 48.2233f, 1.5f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2447.669f, 4966.554f, 44.95141f, 2452.497f,
												 4969.825f, 48.89074f, 2.3125f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2454.863f, 4968.686f, 44.95141f, 2460.505f,
												 4974.409f, 48.82641f, 1.6875f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2459.058f, 4977.546f, 44.95141f, 2460.411f,
												 4979.302f, 48.82641f, 1.6875f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2457.602f, 4984.746f, 44.73669f, 2461.977f,
												 4989.49f, 48.47844f, 1.6875f, 0, 1, 0)) {
				if (!fire::is_entity_on_fire(player::player_ped_id())) {
					fire::start_entity_fire(player::player_ped_id());
				}
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 2454.179f, 4995.281f, 44.54151f, 2453.096f,
												  4993.905f, 48.32043f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2449.401f, 4990.354f, 44.92924f, 2447.717f,
												  4988.865f, 48.82129f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2443.906f, 4990.104f, 44.4446f, 2439.007f,
												  4985.271f, 48.30458f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2439.602f, 4982.387f, 44.95141f, 2440.797f,
												  4981.365f, 48.82642f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2440.259f, 4980.671f, 44.95142f, 2434.769f,
												  4975.055f, 48.82642f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2432.165f, 4972.586f, 44.29909f, 2430.114f,
												  4970.545f, 48.21086f, 1.6875f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2428.46f, 4968.569f, 44.81597f, 2426.632f,
												  4966.603f, 48.29342f, 1.6875f, 0, 1, 0)) {
			if (!fire::is_entity_on_fire(player::player_ped_id())) {
				fire::start_entity_fire(player::player_ped_id());
			}
		}
	}
	else if (entity::is_entity_in_angled_area(player::player_ped_id(), 2455.487f, 4997.566f, 43.1101f, 2423.653f,
											  4962.837f, 57.34888f, 14.4375f, 0, 1, 0)) {
		if (vVar0.z < 50f) {
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2442.913f, 4965.273f, 50.15687f, 2444.49f,
												 4967.41f, 53.81783f, 1.6875f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2445.239f, 4969.07f, 49.94284f, 2450.365f,
												 4972.188f, 54.03251f, 2.375f, 0, 1, 0) ||
				entity::is_entity_in_angled_area(player::player_ped_id(), 2452.332f, 4971.817f, 49.94283f, 2457.977f,
												 4977.583f, 53.88097f, 2.375f, 0, 1, 0)) {
				if (!fire::is_entity_on_fire(player::player_ped_id())) {
					fire::start_entity_fire(player::player_ped_id());
				}
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 2457.621f, 4978.462f, 49.94283f, 2453.932f,
												  4982.161f, 53.81783f, 2.375f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2452.054f, 4984.156f, 49.94283f, 2448.12f,
												  4987.809f, 53.81316f, 2.375f, 0, 1, 0) ||
				 entity::is_entity_in_angled_area(player::player_ped_id(), 2442.014f, 4980.539f, 49.94283f, 2435.796f,
												  4971.945f, 53.90388f, 2.375f, 0, 1, 0)) {
			if (!fire::is_entity_on_fire(player::player_ped_id())) {
				fire::start_entity_fire(player::player_ped_id());
			}
		}
	}
}

// Position - 0x11BDE
void func_149(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	int iVar1;

	if (Local_3337[iParam0 /*4*/] != iParam1) {
		Local_3337[iParam0 /*4*/].f_1 = 0;
		Local_3337[iParam0 /*4*/] = iParam1;
	}
	if (!Local_3337[iParam0 /*4*/].f_1) {
		if (func_152(iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, 1, 0)) {
			switch (Local_3337[iParam0 /*4*/]) {
			case 0: break;

			case 1:
				if (!ui::is_help_message_being_displayed()) {
					player::set_special_ability_multiplier(2f);
					Local_3337[iParam0 /*4*/].f_1 = 1;
				}
				break;

			case 4:
				if (player::is_special_ability_meter_full(player::player_id())) {
					if (controls::_is_input_disabled(0)) {
						func_151("USESPEC_KM", -1);
					}
					else {
						func_151("USESPEC", -1);
					}
				}
				Local_3337[iParam0 /*4*/].f_1 = 1;
				break;

			case 3:
				switch (Local_3337[iParam0 /*4*/].f_2) {
				case 0:
					func_151("FRMFLE", -1);
					Local_3337[iParam0 /*4*/].f_1 = 1;
					break;
				}
				break;

			case 5:
				if (!func_59() && !ui::is_message_being_displayed()) {
					func_7("FRMLK", 7500, 1);
					Local_3337[iParam0 /*4*/].f_1 = 1;
				}
				break;

			case 2:
				func_7("FRMSNP", 7500, 1);
				Local_3337[iParam0 /*4*/].f_1 = 1;
				break;

			case 11:
				switch (Local_3337[iParam0 /*4*/].f_2) {
				case 0:
					if (ped::get_ped_stealth_movement(player::player_ped_id())) {
						Local_3337[iParam0 /*4*/].f_3 = gameplay::get_game_timer() + 1000;
						Local_3337[iParam0 /*4*/].f_2++;
					}
					break;

				case 1:
					if (gameplay::get_game_timer() > Local_3337[iParam0 /*4*/].f_3) {
						if (controls::_is_input_disabled(0)) {
							func_151("FRMSTLTH_KM", -1);
						}
						else {
							func_151("FRMSTLTH", -1);
						}
						Local_3337[iParam0 /*4*/].f_1 = 1;
					}
					break;
				}
				break;

			case 6:
				switch (Local_3337[iParam0 /*4*/].f_2) {
				case 0:
					if (gameplay::get_profile_setting(211) != 0) {
						Local_3337[iParam0 /*4*/].f_3 = gameplay::get_game_timer() + 4000;
						Local_3337[iParam0 /*4*/].f_2++;
					}
					break;

				case 1:
					if (gameplay::get_game_timer() > Local_3337[iParam0 /*4*/].f_3) {
						iVar0 = joaat("weapon_unarmed");
						weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1);
						if (iVar0 != joaat("weapon_sniperrifle") && iVar0 != joaat("weapon_heavysniper") &&
							iVar0 != joaat("weapon_unarmed")) {
							if (!ui::is_message_being_displayed() && !ui::is_help_message_being_displayed()) {
								if (!func_59()) {
									if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
										func_151("FRMSHOT", -1);
										Local_3337[iParam0 /*4*/].f_1 = 1;
									}
								}
							}
						}
					}
					break;
				}
				break;

			case 7:
				func_7("FRMFLC", 7500, 1);
				ui::set_blip_name_from_text_file(iLocal_2677, "FRMBLIPB");
				Local_3337[iParam0 /*4*/].f_1 = 1;
				break;

			case 8:
				switch (Local_3337[iParam0 /*4*/].f_2) {
				case 0:
					func_151("FRMPET2", -1);
					Local_3337[iParam0 /*4*/].f_2++;
					break;

				case 1:
					if (!func_59()) {
						func_150("FRMTRL", 7500, 1);
						Local_3337[iParam0 /*4*/].f_2++;
					}
					break;

				case 2:
					iVar1 = joaat("weapon_unarmed");
					if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1)) {
						if (iVar1 == joaat("weapon_petrolcan")) {
							if (controls::is_control_pressed(0, 24)) {
								ui::clear_help(1);
							}
						}
					}
					if (!ui::is_help_message_being_displayed()) {
						func_151("FRMTRL2", -1);
						Local_3337[iParam0 /*4*/].f_2++;
					}
					break;

				case 3:
					if (func_8()) {
						if (!func_59()) {
							if (interior::get_interior_from_entity(player::player_ped_id()) != 0) {
								if (!ui::does_blip_exist(iLocal_2677)) {
									ui::clear_prints();
									func_7("FRMSHP", 7500, 1);
									iLocal_2677 = func_5(2454.895f, 4950.895f, 44.1488f, 0);
								}
							}
							else if (func_67(player::player_ped_id(), 2454.895f, 4950.895f, 44.1488f, 1) < 5f) {
								ui::clear_prints();
								if (ui::does_blip_exist(iLocal_2677)) {
									ui::remove_blip(&iLocal_2677);
								}
								func_7("FRMIGN", 7500, 1);
								audio::start_audio_scene("CHI_2_SHOOT_GAS");
								Local_3337[iParam0 /*4*/].f_2++;
							}
						}
					}
					break;

				case 4:
					if (func_87(37)) {
						if (func_84("FRMIGN", 0, 0)) {
							ui::clear_prints();
						}
					}
					if (interior::get_interior_from_entity(player::player_ped_id()) != 0) {
						Local_3337[iParam0 /*4*/].f_2 = 3;
					}
					break;
				}
				break;

			case 9:
				func_151("FRMMISS", -1);
				Local_3337[iParam0 /*4*/].f_1 = 1;
				break;

			case 10:
				if (func_87(34)) {
					func_7("FRMFRH", 7500, 1);
				}
				else {
					func_7("FRMFRG", 7500, 1);
				}
				Local_3337[iParam0 /*4*/].f_1 = 1;
				break;

			case 12:
				func_7("FRMLEAVE", 1, 1);
				if (func_87(48)) {
					ui::clear_prints();
					Local_3337[iParam0 /*4*/].f_1 = 1;
				}
				break;

			case 13: func_7("LOSE_WANTED", 7500, 1); break;
			}
		}
	}
}

// Position - 0x120F5
void func_150(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 1);
}

// Position - 0x1210E
void func_151(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x12125
bool func_152(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	bLocal_3118 = false;
	iLocal_3119 = 0;
	if (func_153(&bLocal_3118, &iLocal_3119, iParam0, iParam1)) {
		if (func_153(&bLocal_3118, &iLocal_3119, iParam2, iParam3)) {
			if (func_153(&bLocal_3118, &iLocal_3119, iParam4, iParam5)) {
				if (func_153(&bLocal_3118, &iLocal_3119, iParam6, iParam7)) {
				}
			}
		}
	}
	if (bLocal_3118) {
		return true;
	}
	return false;
}

// Position - 0x12184
bool func_153(int *iParam0, int *iParam1, int iParam2, int iParam3) {
	switch (iParam2) {
	case 0: *iParam0 = 1; break;

	case 1: return false;

	case 2:
		if (iParam3 == 0 || iParam3 != 0 && func_87(iParam3)) {
			*iParam0 = 1;
		}
		break;

	case 3:
		if (iParam3 == 0 || iParam3 != 0 && func_156(iParam3)) {
			*iParam0 = 1;
		}
		break;

	case 6:
		if (iParam3 == 0 || iParam3 != 0 && func_87(iParam3)) {
			*iParam0 = 1;
		}
		break;

	case 8:
		if (*iParam0) {
			return false;
		}
		else {
			*iParam1 = 1;
			if (iParam3 == 0 || iParam3 != 0 && func_87(iParam3)) {
				*iParam0 = 1;
			}
		}
		break;

	case 4:
		if (iParam3 != 0 && func_156(iParam3)) {
			*iParam0 = 0;
		}
		break;

	case 5:
		if (iParam3 != 0 && func_87(iParam3)) {
			*iParam0 = 0;
		}
		break;

	case 7:
		if (func_155(iParam3)) {
			if (func_156(iParam3)) {
				*iParam0 = 1;
			}
			else {
				*iParam0 = 0;
			}
		}
		else {
			if (func_87(iParam3)) {
				func_154(iParam3);
			}
			*iParam0 = 0;
		}
		break;
	}
	return true;
}

// Position - 0x122DD
void func_154(int iParam0) {
	int iVar0;

	iVar0 = iParam0 - Local_3120[0 /*8*/];
	if (Local_3120[iVar0 /*8*/] == iParam0) {
		Local_3120[iVar0 /*8*/].f_3 = 1;
	}
}

// Position - 0x12309
bool func_155(int iParam0) {
	int iVar0;

	iVar0 = iParam0 - Local_3120[0 /*8*/];
	if (Local_3120[iVar0 /*8*/] == iParam0) {
		if (Local_3120[iVar0 /*8*/].f_3) {
			return true;
		}
	}
	return false;
}

// Position - 0x1233C
bool func_156(int iParam0) {
	int iVar0;

	iVar0 = iParam0 - Local_3120[0 /*8*/];
	if (iVar0 >= 0 && iVar0 < Local_3120) {
		if (Local_3120[iVar0 /*8*/] == iParam0) {
			if (!Local_3120[iVar0 /*8*/].f_2) {
				return true;
			}
		}
		else if (Local_3120[iVar0 /*8*/] != 0) {
		}
	}
	else {
		return true;
	}
	return false;
}

// Position - 0x12394
void func_157(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9) {
	int *iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	float fVar4;
	float fVar5;
	int iVar6;

	if (Local_3358[iParam0 /*7*/] != iParam1) {
		Local_3358[iParam0 /*7*/].f_1 = 0;
		Local_3358[iParam0 /*7*/] = iParam1;
	}
	if (!Local_3358[iParam0 /*7*/].f_1) {
		if (func_152(iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8, iParam9)) {
			if (!Local_3358[iParam0 /*7*/].f_2) {
				Local_3358[iParam0 /*7*/].f_2 = 1;
			}
			switch (Local_3358[iParam0 /*7*/]) {
			case 0: break;

			case 1:
				if (func_35("TRV_WTF", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 2:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					Local_3358[iParam0 /*7*/].f_4 = gameplay::get_game_timer() + 2000;
					Local_3358[iParam0 /*7*/].f_3++;
					break;

				case 1:
					if (gameplay::get_game_timer() > Local_3358[iParam0 /*7*/].f_4) {
						if (func_59()) {
							Local_3358[iParam0 /*7*/].f_4 = gameplay::get_game_timer() + 2000;
						}
						else {
							iVar0 = 0;
							if (func_159(&iVar0, 2, 1)) {
								if (func_35("RAGE", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0, -1, 0, 0,
											8)) {
									Local_3358[iParam0 /*7*/].f_4 =
										gameplay::get_game_timer() + gameplay::get_random_int_in_range(8000, 14000);
								}
							}
							else {
								Local_3358[iParam0 /*7*/].f_1 = 1;
							}
						}
					}
					break;
				}
				break;

			case 4:
				Local_3358[iParam0 /*7*/].f_4 = func_18(23);
				if (Local_3358[iParam0 /*7*/].f_4 != -1) {
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("COOKSEE", 3, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILCOOK", -1, 0,
									0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
				}
				break;

			case 3:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					Local_3358[iParam0 /*7*/].f_4 = func_18(15);
					Local_3358[iParam0 /*7*/].f_5 = func_18(16);
					if (Local_3358[iParam0 /*7*/].f_4 != -1 && Local_3358[iParam0 /*7*/].f_5 != -1) {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					break;

				case 1:
					if (ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						Local_3358[iParam0 /*7*/].f_4 = Local_3358[iParam0 /*7*/].f_5;
						if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
						else {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					break;

				case 2:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD8", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD1",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;

				case 3:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD9", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD1",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;

				case 4:
					if (func_159(&iVar1, 2, 1)) {
						if (iVar1 != Local_3358[iParam0 /*7*/].f_4) {
							Local_3358[iParam0 /*7*/].f_4 = iVar1;
							Local_3358[iParam0 /*7*/].f_3++;
						}
						else {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;

				case 5:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD10", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD2",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;
				}
				break;

			case 5:
				Local_3358[iParam0 /*7*/].f_4 = func_18(23);
				if (Local_3358[iParam0 /*7*/].f_4 != -1) {
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD11", 6, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD2",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
				}
				break;

			case 6:
				Local_3358[iParam0 /*7*/].f_4 = func_18(23);
				if (Local_3358[iParam0 /*7*/].f_4 != -1) {
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD12", 6, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD2",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
				}
				break;

			case 7:
				if (func_35("CHI2_drive", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 9:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						Local_3358[iParam0 /*7*/].f_3 = gameplay::get_random_int_in_range(1, 3);
					}
					break;

				case 1:
					if (func_35("SEETREVOR", 3, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "CHIN2goon1", -1, 0, 0,
								-1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;

				case 2:
					if (func_35("GOON2TREV", 4, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "CHIN2goon2", -1, 0, 0,
								-1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;
				}
				break;

			case 10:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (gameplay::get_game_timer() > Local_3358[iParam0 /*7*/].f_4) {
						if (func_159(&Local_3358[iParam0 /*7*/].f_5, 1, 1)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/])) {
						if (Local_3358[iParam0 /*7*/].f_6 < 3) {
							if (func_35("ONEILGUARD5", 5, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/],
										"ONEILGUARD1", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(7000, 12000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
						}
						else if (Local_3358[iParam0 /*7*/].f_6 < 6) {
							if (func_35("ONEILGUARD6", 6, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/],
										"ONEILGUARD2", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(7000, 12000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
						}
						else {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_3 = 0;
					}
					break;
				}
				break;

			case 11:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (gameplay::get_game_timer() > Local_3358[iParam0 /*7*/].f_4) {
						if (func_159(&Local_3358[iParam0 /*7*/].f_5, 1, 1)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/])) {
						switch (Local_3358[iParam0 /*7*/].f_6) {
						case 0:
						case 2:
						case 5:
						case 9:
							if (func_35("COOKATT", 3, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "oneilcook", -1,
										0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(7000, 12000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 1:
						case 6:
						case 8:
						case 11:
							if (func_35("GOONATT", 3, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "chin2goon1", -1,
										0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(7000, 12000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 3:
						case 4:
						case 7:
						case 10:
							if (func_35("GOON2ATTO", 4, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "chin2goon2",
										-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(7000, 12000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 12: Local_3358[iParam0 /*7*/].f_1 = 1; break;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_3 = 0;
					}
					break;
				}
				break;

			case 12:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (gameplay::get_game_timer() > Local_3358[iParam0 /*7*/].f_4) {
						if (func_159(&Local_3358[iParam0 /*7*/].f_5, 2, 1)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/])) {
						switch (Local_3358[iParam0 /*7*/].f_6) {
						case 0:
						case 2:
						case 5:
						case 9:
							if (func_35("GOONIN", 3, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "chin2goon1", -1,
										0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(6000, 10000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 1:
						case 6:
						case 8:
						case 11:
							if (func_35("GOON2ATTI", 4, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "chin2goon2",
										-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(6000, 10000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 3:
						case 4:
						case 7:
						case 10:
							if (func_35("ATTACKIN", 3, Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/], "ONEILCOOK", -1,
										0, 0, -1, 0, 0, -1, 0, 0, 8)) {
								Local_3358[iParam0 /*7*/].f_4 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(6000, 10000);
								Local_3358[iParam0 /*7*/].f_6++;
								Local_3358[iParam0 /*7*/].f_3 = 0;
							}
							break;

						case 12: Local_3358[iParam0 /*7*/].f_1 = 1; break;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_3 = 0;
					}
					break;
				}
				break;

			case 14:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					iVar2 = 0;
					while (iVar2 < Local_755) {
						if (Local_755[iVar2 /*33*/].f_1 == 2) {
							if (!ped::is_ped_injured(Local_755[iVar2 /*33*/])) {
								if (ped::is_ped_in_combat(Local_755[iVar2 /*33*/], 0)) {
									if (ped::can_ped_in_combat_see_target(Local_755[iVar2 /*33*/],
																		  player::player_ped_id())) {
										Local_3358[iParam0 /*7*/].f_4 = iVar2;
										Local_3358[iParam0 /*7*/].f_3++;
									}
								}
							}
						}
						iVar2++;
					}
					break;

				case 1:
					if (func_35("G2TREVIN", 4, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "chin2goon2", -1, 0, 0,
								-1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;
				}
				break;

			case 15:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD3", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD1",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("ONEILGUARD1", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "ONEILGUARD1",
									-1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					break;
				}
				break;

			case 16:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (func_159(&Local_3358[iParam0 /*7*/].f_4, 1, 1)) {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					break;

				case 1:
					if (func_35("ONEILGUARD7", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "oneilguard2", -1, 0,
								0, -1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					break;

				case 2:
					if (func_35("CHI2_app", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;
				}
				break;

			case 17:
				if (func_35("CHI2_app", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 19:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (func_82("ONEILGUARD4") || func_82("SEETREVOR")) {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					break;

				case 1:
					if (func_35("CHI2_HARD", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
					break;
				}
				break;

			case 20:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					if (gameplay::get_game_timer() > Local_3358[iParam0 /*7*/].f_5) {
						fVar4 = 999f;
						Local_3358[iParam0 /*7*/].f_4 = -1;
						iVar3 = 0;
						while (iVar3 < Local_755) {
							if (Local_755[iVar3 /*33*/].f_1 == 2) {
								if (!ped::is_ped_injured(Local_755[iVar3 /*33*/])) {
									fVar5 = func_4(player::player_ped_id(), Local_755[iVar3 /*33*/], 1);
									if (fVar5 < fVar4) {
										fVar4 = fVar5;
										Local_3358[iParam0 /*7*/].f_4 = iVar3;
									}
								}
							}
							iVar3++;
						}
						if (Local_3358[iParam0 /*7*/].f_4 == -1) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
						else {
							Local_3358[iParam0 /*7*/].f_3++;
						}
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (func_35("CHI2_outs", 5, Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], "Oneilguard1", -1,
									0, 0, -1, 0, 0, -1, 0, 0, 8)) {
							Local_3358[iParam0 /*7*/].f_1 = 1;
						}
					}
					else {
						Local_3358[iParam0 /*7*/].f_5 = gameplay::get_game_timer() + 6000;
						Local_3358[iParam0 /*7*/].f_3 = 0;
					}
					break;
				}
				break;

			case 18:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					iVar6 = 0;
					while (iVar6 < Local_755) {
						if (Local_755[iVar6 /*33*/].f_2 == 8) {
							Local_3358[iParam0 /*7*/].f_4 = iVar6;
						}
						if (Local_755[iVar6 /*33*/].f_2 == 9) {
							Local_3358[iParam0 /*7*/].f_5 = iVar6;
						}
						iVar6++;
					}
					Local_3358[iParam0 /*7*/].f_3++;
					break;

				case 1:
					if (!func_59()) {
						if (ped::is_synchronized_scene_running(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/].f_14)) {
							if (ped::get_synchronized_scene_phase(
									Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/].f_14) > 0.15f) {
								if (ped::get_synchronized_scene_phase(
										Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/].f_14) < 0.65f) {
									if (func_4(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/], player::player_ped_id(),
											   1) < 30f) {
										Local_3358[iParam0 /*7*/].f_3 = 3;
									}
								}
							}
						}
					}
					break;

				case 2:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						Local_3358[iParam0 /*7*/].f_3++;
					}
					else {
						Local_3358[iParam0 /*7*/].f_3 = 1;
					}
					break;

				case 3:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/])) {
						audio::_play_ambient_speech_with_voice(Local_755[Local_3358[iParam0 /*7*/].f_5 /*33*/],
															   "generic_cheer", "A_M_M_Hillbilly_01_White_mini_03",
															   "SPEECH_PARAMS_FORCE_SHOUTED", 0);
						Local_3358[iParam0 /*7*/].f_3++;
					}
					else {
						Local_3358[iParam0 /*7*/].f_3 = 1;
					}
					break;

				case 4:
					if (!ped::is_ped_injured(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/])) {
						if (ped::is_synchronized_scene_running(Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/].f_14)) {
							if (ped::get_synchronized_scene_phase(
									Local_755[Local_3358[iParam0 /*7*/].f_4 /*33*/].f_14) > 0.75f) {
								Local_3358[iParam0 /*7*/].f_3 = 1;
							}
						}
					}
					break;
				}
				break;

			case 21:
				if (func_35("CHI2_find", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					unk1::_0x293220DA1B46CEBC(5f, 8f, 4);
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 26:
				if (func_158()) {
					if (func_35("CHI2_pourmis", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0,
								8)) {
						Local_3358[iParam0 /*7*/].f_1 = 1;
					}
				}
				break;

			case 27:
				if (func_35("CHI2_boom", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 22:
				switch (Local_3358[iParam0 /*7*/].f_3) {
				case 0:
					Local_3358[iParam0 /*7*/].f_4 = 2500;
					Local_3358[iParam0 /*7*/].f_5 = 0;
					Local_3358[iParam0 /*7*/].f_3 = 1;
					break;

				case 1:
					Local_3358[iParam0 /*7*/].f_4 -= system::floor(system::timestep() * 1000f);
					if (Local_3358[iParam0 /*7*/].f_4 <= 0) {
						Local_3358[iParam0 /*7*/].f_3 = 2;
					}
					break;

				case 2:
					if (Local_3358[iParam0 /*7*/].f_5 < 14) {
						if (func_35("CHI2_pour", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0,
									8)) {
							Local_3358[iParam0 /*7*/].f_3 = 1;
							Local_3358[iParam0 /*7*/].f_4 = 12000 + gameplay::get_random_int_in_range(3000, 5000);
							Local_3358[iParam0 /*7*/].f_5++;
						}
					}
					break;
				}
				break;

			case 23:
				if (func_35("CHI2_light", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 24:
				if (func_35("CHI2_boom", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;

			case 25:
				if (func_35("CHI2_burn", 1, player::player_ped_id(), "TREVOR", -1, 0, 0, -1, 0, 0, -1, 0, 0, 8)) {
					Local_3358[iParam0 /*7*/].f_1 = 1;
				}
				break;
			}
		}
	}
}

// Position - 0x137CA
bool func_158() {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	while (iVar0 < Local_444) {
		if (Local_444[iVar0 /*5*/].f_4 == 1) {
			if (iVar2 == 0) {
				iVar2 = 1;
				iVar1++;
				if (iVar1 > 1) {
					return true;
				}
			}
		}
		else if (iVar2 == 1) {
			iVar2 = 0;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x13819
bool func_159(int *iParam0, int iParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;

	fVar2 = 9999f;
	*iParam0 = -1;
	iVar0 = 0;
	while (iVar0 < Local_755) {
		if (Local_755[iVar0 /*33*/].f_1 == iParam1) {
			if (iParam2 == 0 || iParam2 == 1 && !ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
				fVar1 = func_4(player::player_ped_id(), Local_755[iVar0 /*33*/], 1);
				if (fVar1 < fVar2) {
					fVar2 = fVar1;
					*iParam0 = iVar0;
				}
			}
		}
		iVar0++;
	}
	if (*iParam0 != -1) {
		return true;
	}
	return false;
}

// Position - 0x1389F
void func_160(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	if (Local_2917[iParam0 /*10*/] != iParam1 || Local_2917[iParam0 /*10*/].f_1 == 0) {
		Local_2917[iParam0 /*10*/] = iParam1;
		Local_2917[iParam0 /*10*/].f_1 = 1;
		Local_2917[iParam0 /*10*/].f_3 = 0;
		Local_2917[iParam0 /*10*/].f_6 = 0;
		Local_2917[iParam0 /*10*/].f_4 = 0;
		Local_2917[iParam0 /*10*/].f_7 = 0;
		Local_2917[iParam0 /*10*/].f_8 = 0;
		Local_2917[iParam0 /*10*/].f_9 = 0f;
	}
	if (Local_2917[iParam0 /*10*/].f_2 && iParam2 == 0) {
		iVar0 = 1;
	}
	else {
		iVar0 = func_152(iParam3, iParam4, iParam5, iParam6, iParam7, iParam8, iParam9, iParam10);
	}
	if (iParam2 == 1 && !iVar0) {
		Local_2917[iParam0 /*10*/].f_2 = 0;
	}
	if (Local_2917[iParam0 /*10*/].f_3 == 0 || Local_2917[iParam0 /*10*/].f_6 == -1) {
		if (iVar0 == 1) {
			if (!Local_2917[iParam0 /*10*/].f_2) {
				Local_2917[iParam0 /*10*/].f_2 = 1;
			}
			switch (Local_2917[iParam0 /*10*/]) {
			case 1: break;

			case 2:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					audio::start_audio_scene("CHI_2_DRIVE_TO_FARMHOUSE");
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						audio::stop_audio_scene("CHI_2_DRIVE_TO_FARMHOUSE");
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				break;

			case 3:
				if (func_67(player::player_ped_id(), 1991.05f, 3054.262f, 46.2147f, 1) > 250f) {
					if (entity::does_entity_exist(Local_755[11 /*33*/])) {
						ped::delete_ped(&Local_755[11 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[10 /*33*/])) {
						ped::delete_ped(&Local_755[10 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[12 /*33*/])) {
						ped::delete_ped(&Local_755[12 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[13 /*33*/])) {
						ped::delete_ped(&Local_755[13 /*33*/]);
					}
					if (entity::does_entity_exist(Local_755[14 /*33*/])) {
						ped::delete_ped(&Local_755[14 /*33*/]);
					}
					streaming::set_model_as_no_longer_needed(joaat("ig_janet"));
					streaming::set_model_as_no_longer_needed(joaat("ig_janet"));
					streaming::set_model_as_no_longer_needed(joaat("ig_old_man1a"));
					streaming::set_model_as_no_longer_needed(joaat("ig_old_man2"));
					streaming::set_model_as_no_longer_needed(joaat("ig_taocheng"));
					streaming::set_model_as_no_longer_needed(joaat("ig_taostranslator"));
					streaming::remove_anim_dict("misschinese2_crystalmaze");
					streaming::remove_anim_dict("MISSChinese2_crystalMazeMCS1_IG");
					streaming::remove_anim_dict("missrampageintrooutro");
					if (iLocal_2884 != -1) {
						if (pathfind::does_navmesh_blocking_object_exist(iLocal_2884)) {
							pathfind::remove_navmesh_blocking_object(iLocal_2884);
						}
					}
					ped::clear_ped_non_creation_area();
					func_31(26, 1);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 5:
				if (audio::load_stream("CHI_2_FARMHOUSE_INTRO", "CHINESE2_FARMHOUSE_INTRODUCTION")) {
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 4:
				if (func_67(player::player_ped_id(), 2457.49f, 4977.095f, 50.56783f, 1) < 400f) {
					func_32(27, 0);
					streaming::set_vehicle_population_budget(1);
					streaming::set_ped_population_budget(1);
					streaming::prefetch_srl("chinese2_farmhouse_cutscene");
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 7:
				if (!ped::is_ped_injured(Local_755[12 /*33*/]) && !ped::is_ped_injured(Local_755[13 /*33*/]) &&
					!ped::is_ped_injured(Local_755[14 /*33*/])) {
					if (func_169(6, 6) < 2) {
						if (entity::is_entity_in_angled_area(player::player_ped_id(), 1981.257f, 3050.721f, 41.08995f,
															 1984.257f, 3055.543f, 49.47314f, 3.0625f, 0, 1, 0)) {
							if (ai::get_script_task_status(Local_755[12 /*33*/], 150319005) == 7) {
								ai::task_look_at_entity(Local_755[13 /*33*/], player::player_ped_id(), -1, 0, 2);
								ai::task_look_at_entity(Local_755[14 /*33*/], player::player_ped_id(), -1, 0, 2);
								ai::task_look_at_entity(Local_755[12 /*33*/], player::player_ped_id(), -1, 0, 2);
							}
						}
					}
				}
				break;

			case 8:
				fVar1 = func_67(player::player_ped_id(), 2450.214f, 4979.208f, 60.8422f, 1);
				if (fVar1 < 900f) {
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						iVar4 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (vehicle::is_vehicle_driveable(iVar4, 0)) {
							if (vehicle::is_this_model_a_heli(entity::get_entity_model(iVar4)) ||
								vehicle::is_this_model_a_plane(entity::get_entity_model(iVar4))) {
								fVar2 = 900f - fVar1;
								if (fVar2 < 0f) {
									fVar2 = 0f;
								}
								fVar2 /= 900f;
								fVar2 *= 10000f;
								fVar3 = entity::get_entity_speed(iVar4);
								fVar2 *= fVar3 / 35f;
								if (fVar3 > 35f) {
									entity::apply_force_to_entity_center_of_mass(iVar4, 1, 0f, -fVar2, 0f, 0, 1, 0, 0);
								}
							}
						}
					}
				}
				break;

			case 9:
				if (entity::is_entity_playing_anim(player::player_ped_id(), "missrampageintrooutro",
												   "trvram_6_1h_run_outro", 3)) {
					Local_2917[iParam0 /*10*/].f_6 = 1;
					ped::set_ped_reset_flag(player::player_ped_id(), 321, 1);
					if (entity::has_anim_event_fired(player::player_ped_id(),
													 gameplay::get_hash_key("walkinterruptible"))) {
						ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 0, 0, 0);
						if (func_168()) {
							ai::clear_ped_tasks(player::player_ped_id());
							Local_2917[iParam0 /*10*/].f_3 = 1;
						}
					}
				}
				else if (Local_2917[iParam0 /*10*/].f_6 == 1) {
					streaming::remove_anim_dict("missrampageintrooutro");
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 6:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					if (!ped::is_ped_injured(Local_755[12 /*33*/]) && !ped::is_ped_injured(Local_755[13 /*33*/]) &&
						!ped::is_ped_injured(Local_755[14 /*33*/])) {
						ped::set_ped_relationship_group_hash(Local_755[12 /*33*/], iLocal_2636);
						ped::set_ped_relationship_group_hash(Local_755[13 /*33*/], iLocal_2636);
						ped::set_ped_relationship_group_hash(Local_755[14 /*33*/], iLocal_2636);
						ped::set_ped_combat_attributes(Local_755[12 /*33*/], 17, 1);
						ped::set_ped_combat_attributes(Local_755[13 /*33*/], 17, 1);
						ped::set_ped_combat_attributes(Local_755[14 /*33*/], 17, 1);
						entity::clear_entity_last_damage_entity(Local_755[12 /*33*/]);
						entity::clear_entity_last_damage_entity(Local_755[13 /*33*/]);
						entity::clear_entity_last_damage_entity(Local_755[14 /*33*/]);
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 1:
					if (ped::is_ped_injured(Local_755[12 /*33*/]) || ped::is_ped_injured(Local_755[13 /*33*/]) ||
						ped::is_ped_injured(Local_755[14 /*33*/])) {
						Local_2917[iParam0 /*10*/].f_6++;
					}
					if (!ped::is_ped_injured(Local_755[12 /*33*/])) {
						if (entity::has_entity_been_damaged_by_any_ped(Local_755[12 /*33*/])) {
							Local_2917[iParam0 /*10*/].f_6 = 2;
						}
					}
					if (!ped::is_ped_injured(Local_755[13 /*33*/])) {
						if (entity::has_entity_been_damaged_by_any_ped(Local_755[13 /*33*/])) {
							Local_2917[iParam0 /*10*/].f_6 = 2;
						}
					}
					if (!ped::is_ped_injured(Local_755[14 /*33*/])) {
						if (entity::has_entity_been_damaged_by_any_ped(Local_755[14 /*33*/])) {
							Local_2917[iParam0 /*10*/].f_6 = 2;
						}
					}
					break;

				case 2:
					if (!ped::is_ped_injured(Local_755[12 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[12 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[12 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[12 /*33*/]);
					}
					if (!ped::is_ped_injured(Local_755[13 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[13 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[13 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[13 /*33*/]);
					}
					if (!ped::is_ped_injured(Local_755[14 /*33*/])) {
						ai::task_smart_flee_ped(Local_755[14 /*33*/], player::player_ped_id(), 100f, -1, 0, 0);
						ped::set_ped_keep_task(Local_755[14 /*33*/], 1);
						entity::set_ped_as_no_longer_needed(&Local_755[14 /*33*/]);
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				break;

			case 10:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					streaming::prefetch_srl("chinese2_explosion_cutscene");
					audio::stop_stream();
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (iLocal_2648 == 1) {
						if (audio::load_stream("CHINESE2_FARMHOUSE_EXPLOSION_MOLOTOV_MASTER", 0)) {
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					if (iLocal_2648 == 2) {
						if (audio::load_stream("CHINESE2_FARMHOUSE_EXPLOSION_"
											   "STICKY_BOMB_MASTER",
											   0)) {
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					if (iLocal_2648 == 3) {
						if (audio::load_stream("CHINESE2_FARMHOUSE_EXPLOSION_"
											   "SHOOT_GASOLINE_MASTER",
											   0)) {
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					break;

				case 2:
					if (streaming::is_srl_loaded()) {
						Local_2917[iParam0 /*10*/].f_6 = 10;
					}
					break;
				}
				break;

			case 11:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 1:
					if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_7) {
						if (interior::is_valid_interior(interior::get_interior_from_entity(player::player_ped_id()))) {
							fire::add_explosion(entity::get_entity_coords(player::player_ped_id(), 1) +
													Vector(0f, gameplay::get_random_float_in_range(0f, 4f),
														   gameplay::get_random_float_in_range(0f, 4f)),
												16, 1.5f, 1, 0, 1f, 0);
							Local_2917[iParam0 /*10*/].f_9--;
							Local_2917[iParam0 /*10*/].f_7 =
								gameplay::get_game_timer() + gameplay::get_random_int_in_range(250, 520);
						}
						else {
							Local_2917[iParam0 /*10*/].f_6 = 2;
						}
					}
					break;

				case 2: break;

				default:
					iVar5 = 0;
					while (iVar5 < vLocal_2889.x) {
						if (!gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_7, iVar5)) {
							if (fire::is_explosion_in_sphere(-1, vLocal_2889[iVar5 /*3*/], 5f)) {
								gameplay::set_bit(&Local_2917[iParam0 /*10*/].f_7, iVar5);
								if (Local_2917[iParam0 /*10*/].f_6 == 0) {
									Local_2917[iParam0 /*10*/].f_6 = gameplay::get_game_timer() + 1500;
								}
							}
						}
						iVar5++;
					}
					if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_8) {
						Local_2917[iParam0 /*10*/].f_8 = 0;
						iVar5 = 0;
						while (iVar5 < vLocal_2889.x) {
							if (!gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_7, iVar5 + 9) &&
								gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_7, iVar5)) {
								fire::add_explosion(vLocal_2889[iVar5 /*3*/], 16, 1.5f, 1, 0, 1f, 0);
								gameplay::set_bit(&Local_2917[iParam0 /*10*/].f_7, iVar5 + 9);
								iVar5 = 8;
								Local_2917[iParam0 /*10*/].f_8 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(150, 320);
							}
							iVar5++;
						}
					}
					if (Local_2917[iParam0 /*10*/].f_6 != 0) {
						if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_6) {
							Local_2917[iParam0 /*10*/].f_6 = 1;
							Local_2917[iParam0 /*10*/].f_7 = gameplay::get_game_timer() + 300;
							Local_2917[iParam0 /*10*/].f_9 = 16f;
						}
					}
					break;
				}
				break;

			case 12:
				iVar6 = func_18(8);
				iVar7 = func_18(9);
				func_99(iVar6, 20, 0, 0);
				func_99(iVar7, 20, 0, 0);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 42:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					audio::set_initial_player_station("RADIO_01_CLASS_ROCK");
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						if (audio::_0x109697E2FFBAC8A1()) {
							iLocal_2506 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
							if (vehicle::is_vehicle_driveable(iLocal_2506, 0)) {
								if (!vehicle::get_is_vehicle_engine_running(iLocal_2506)) {
									Local_2917[iParam0 /*10*/].f_6++;
								}
							}
						}
					}
					break;

				case 2:
					if (audio::prepare_music_event("CHN2_TREV_RADIO_1_FRTA")) {
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;
					break;

				case 3:
					if (audio::trigger_music_event("CHN2_TREV_RADIO_1_FRTA")) {
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 4:
					if (func_68(iLocal_2506)) {
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_2506, 0)) {
							if (vehicle::get_is_vehicle_engine_running(iLocal_2506)) {
								Local_2917[iParam0 /*10*/].f_7 += gameplay::get_game_timer() + 7000;
								Local_2917[iParam0 /*10*/].f_6++;
							}
						}
					}
					break;

				case 5:
					if (func_68(iLocal_2506)) {
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_2506, 0)) {
							if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_7) {
								if (audio::get_player_radio_station_genre() != 6 &&
									audio::get_player_radio_station_genre() != 0) {
									if (audio::_0x3A48AB4445D499BE() != 0) {
										if (func_35("CHI2_rad", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0,
													0, -1, 0, 0, 8)) {
											Local_2917[iParam0 /*10*/].f_6++;
										}
									}
									else {
										Local_2917[iParam0 /*10*/].f_6++;
									}
								}
								else {
									Local_2917[iParam0 /*10*/].f_7 = gameplay::get_game_timer() + 5000;
								}
							}
						}
					}
					break;

				case 6:
					if (func_82("CHI2_rad")) {
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 7:
					if (!func_82("CHI2_rad")) {
						if (func_68(iLocal_2506)) {
							if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_2506, 0)) {
								if (!controls::is_control_pressed(0, 85)) {
									if (audio::get_player_radio_station_genre() != 6) {
										if (iLocal_2676 == -1) {
											iLocal_2676 = audio::get_sound_id();
											audio::play_sound_frontend(iLocal_2676, "Change_Station_Loud",
																	   "Radio_Soundset", 1);
											Local_2917[iParam0 /*10*/].f_6++;
										}
									}
									else {
										Local_2917[iParam0 /*10*/].f_6 = 9;
									}
								}
							}
						}
					}
					break;

				case 8:
					if (!controls::is_control_pressed(0, 85)) {
						if (audio::trigger_music_event("CHN2_TREV_RADIO_2_FRTA")) {
							audio::start_audio_scene("CHI_2_DRIVE_ROCK_RADIO");
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					break;

				case 9:
					if (func_68(iLocal_2506)) {
						if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_2506, 0)) {
							if (audio::get_player_radio_station_genre() == 6) {
								if (audio::_0x3A48AB4445D499BE() != 0) {
									if (func_35("CHI2_radb", 1, player::player_ped_id(), "Trevor", -1, 0, 0, -1, 0, 0,
												-1, 0, 0, 8)) {
										Local_2917[iParam0 /*10*/].f_6++;
									}
								}
								else {
									Local_2917[iParam0 /*10*/].f_6++;
								}
							}
						}
					}
					break;
				}
				break;

			case 48:
				func_31(9, 1);
				player::set_wanted_level_multiplier(1f);
				player::set_player_wanted_level(player::player_id(), 2, 0);
				player::set_player_wanted_level_now(player::player_id(), 0);
				player::set_max_wanted_level(5);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 49:
				if (!func_90(2448.25f, 4974.92f, 55.11f, 20f, 500f) || func_87(49)) {
					if (iLocal_2678 != 0) {
						interior::unpin_interior(iLocal_2678);
					}
					iLocal_2678 = 0;
					func_19(50, 2, 0, 1, 0);
					func_19(51, 2, 0, 1, 0);
					func_19(52, 2, 0, 1, 0);
					func_19(53, 2, 0, 1, 0);
					func_19(54, 1, 0, 1, 0);
					func_19(55, 1, 0, 1, 0);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 50:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
						Local_2917[iParam0 /*10*/].f_7 =
							weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_petrolcan"));
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 1:
					if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
						iVar8 = weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_petrolcan"));
						if (iVar8 > Local_2917[iParam0 /*10*/].f_7) {
							Local_2917[iParam0 /*10*/].f_7 = iVar8;
						}
						else if (iVar8 < Local_2917[iParam0 /*10*/].f_7) {
							func_9(158, Local_2917[iParam0 /*10*/].f_7 - iVar8, 0);
							Local_2917[iParam0 /*10*/].f_7 = iVar8;
						}
					}
					if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar9, 1)) {
						if (iVar9 == joaat("weapon_petrolcan")) {
							if (controls::is_control_pressed(0, 24)) {
								if (Local_2917[iParam0 /*10*/].f_8 == 0) {
									func_10(157, 0);
									Local_2917[iParam0 /*10*/].f_8 = 1;
								}
							}
							else if (Local_2917[iParam0 /*10*/].f_8 == 1) {
								func_11(0, 157);
								Local_2917[iParam0 /*10*/].f_8 = 0;
							}
						}
						else if (Local_2917[iParam0 /*10*/].f_8 == 1) {
							func_11(0, 157);
							Local_2917[iParam0 /*10*/].f_8 = 0;
						}
					}
					else if (Local_2917[iParam0 /*10*/].f_8 == 1) {
						func_11(0, 157);
						Local_2917[iParam0 /*10*/].f_8 = 0;
					}
					break;
				}
				break;

			case 51:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					Local_2917[iParam0 /*10*/].f_7 = -1;
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar10, 1)) {
						if (iVar10 == joaat("weapon_petrolcan")) {
							if (controls::is_control_pressed(0, 24)) {
								if (Local_2917[iParam0 /*10*/].f_7 == -1) {
									Local_2917[iParam0 /*10*/].f_7 = weapon::get_ammo_in_ped_weapon(
										player::player_ped_id(), joaat("weapon_petrolcan"));
								}
								if (iLocal_269 == 0) {
									Local_2917[iParam0 /*10*/].f_9 += system::timestep() * 2f;
								}
								else if (iLocal_269 < 30 && Local_2917[iParam0 /*10*/].f_9 < 70f) {
									Local_2917[iParam0 /*10*/].f_9 += system::timestep() * 1.5f;
								}
								else {
									Local_2917[iParam0 /*10*/].f_9 += system::timestep();
								}
								iVar11 = system::floor(IntToFloat(Local_2917[iParam0 /*10*/].f_7) *
													   (1f - Local_2917[iParam0 /*10*/].f_9 / 90f));
								if (iVar11 > 0) {
									weapon::set_ped_ammo(player::player_ped_id(), iVar10, iVar11, 0);
								}
								else {
									weapon::set_ped_ammo(player::player_ped_id(), iVar10, 0, 0);
								}
							}
						}
					}
					break;
				}
				break;

			case 52:
				func_15("CHN2_STOP_TRACK", 0, func_167());
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 53:
				audio::set_ambient_zone_list_state("AZL_CHN2_METH_LAB_FARM_FIRE", 1, 1);
				func_166(1);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 54:
				func_166(0);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 55:
				streaming::set_vehicle_population_budget(3);
				streaming::set_ped_population_budget(3);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 56:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					if (entity::does_entity_exist(Local_755[4 /*33*/].f_20)) {
						entity::set_object_as_no_longer_needed(&Local_755[4 /*33*/].f_20);
					}
					if (entity::does_entity_exist(Local_755[5 /*33*/].f_20)) {
						entity::set_object_as_no_longer_needed(&Local_755[5 /*33*/].f_20);
					}
					iVar12 = 0;
					while (iVar12 < iLocal_2657) {
						if (entity::does_entity_exist(iLocal_2657[iVar12])) {
							entity::set_object_as_no_longer_needed(&iLocal_2657[iVar12]);
						}
						iVar12++;
					}
					streaming::set_model_as_no_longer_needed(joaat("prop_cs_beer_bot_01"));
					streaming::set_model_as_no_longer_needed(joaat("prop_ld_can_01"));
					streaming::set_model_as_no_longer_needed(joaat("prop_cs_fertilizer"));
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (ped::is_ped_injured(Local_755[23 /*33*/])) {
						if (entity::does_entity_exist(iLocal_2878)) {
							entity::set_object_as_no_longer_needed(&iLocal_2878);
							weapon::remove_weapon_asset(joaat("weapon_sawnoffshotgun"));
							Local_2917[iParam0 /*10*/].f_3 = 1;
						}
					}
					break;
				}
				break;

			case 47:
				if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
					if (!audio::is_ambient_speech_playing(Local_755[11 /*33*/])) {
						if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_7) {
							if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
								audio::_play_ambient_speech_with_voice(Local_755[11 /*33*/], "WHIMPER",
																	   "WAVELOAD_PAIN_MALE",
																	   "SPEECH_PARAMS_FORCE_NORMAL", 0);
								Local_2917[iParam0 /*10*/].f_7 =
									gameplay::get_game_timer() + gameplay::get_random_int_in_range(3500, 5000);
							}
						}
					}
				}
				break;

			case 41:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					streaming::request_model(joaat("ig_taocheng"));
					streaming::request_model(joaat("ig_taostranslator"));
					streaming::request_anim_dict("misschinese2_crystalmaze");
					if (iLocal_2884 == -1 ||
						iLocal_2884 != -1 && !pathfind::does_navmesh_blocking_object_exist(iLocal_2884)) {
						iLocal_2884 = pathfind::add_navmesh_blocking_object(1991.081f, 3054.517f, 46.71474f, 4f, 4f, 4f,
																			0f, 0, 3);
					}
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (streaming::has_anim_dict_loaded("misschinese2_crystalmaze") &&
						streaming::has_model_loaded(joaat("ig_taocheng")) &&
						streaming::has_model_loaded(joaat("ig_taostranslator"))) {
						if (!entity::does_entity_exist(Local_755[11 /*33*/])) {
							Local_755[11 /*33*/] =
								ped::create_ped(26, joaat("ig_taocheng"), 1991.988f, 3054.51f, 46.215f, 0f, 1, 1);
							ped::set_ped_relationship_group_hash(Local_755[11 /*33*/], iLocal_1618);
							ped::set_ped_can_be_targetted(Local_755[11 /*33*/], 0);
						}
						else if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
							ped::set_ped_relationship_group_hash(Local_755[11 /*33*/], iLocal_1618);
							ped::set_ped_can_be_targetted(Local_755[11 /*33*/], 0);
						}
						if (!entity::does_entity_exist(Local_755[10 /*33*/])) {
							Local_755[10 /*33*/] =
								ped::create_ped(26, joaat("ig_taostranslator"), 1991.988f, 3054.51f, 46.215f, 0f, 1, 1);
							ped::set_ped_relationship_group_hash(Local_755[10 /*33*/], iLocal_1618);
							ped::set_ped_can_be_targetted(Local_755[10 /*33*/], 0);
							ped::set_ped_prop_index(Local_755[10 /*33*/], 1, 0, 1, 0);
						}
						else if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
							ped::set_ped_relationship_group_hash(Local_755[10 /*33*/], iLocal_1618);
							ped::set_ped_can_be_targetted(Local_755[10 /*33*/], 0);
						}
						if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
							if (!ped::is_synchronized_scene_running(Local_2917[iParam0 /*10*/].f_7)) {
								Local_2917[iParam0 /*10*/].f_7 =
									ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
								ped::_set_synchronized_scene_occlusion_portal(Local_2917[iParam0 /*10*/].f_7, 1);
							}
							ai::task_synchronized_scene(Local_755[11 /*33*/], Local_2917[iParam0 /*10*/].f_7,
														"misschinese2_crystalmaze", "2int_Loop_A_TaoCheng", 1000f, -4f,
														257, 16, 1148846080, 0);
						}
						if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
							if (!ped::is_synchronized_scene_running(Local_2917[iParam0 /*10*/].f_7)) {
								Local_2917[iParam0 /*10*/].f_7 =
									ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
								ped::_set_synchronized_scene_occlusion_portal(Local_2917[iParam0 /*10*/].f_7, 1);
							}
							ai::task_synchronized_scene(Local_755[10 /*33*/], Local_2917[iParam0 /*10*/].f_7,
														"misschinese2_crystalmaze", "2int_Loop_A_taotranslator", 1000f,
														-4f, 257, 16, 1148846080, 0);
						}
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 2:
					if (!ped::is_ped_injured(Local_755[10 /*33*/]) && !ped::is_ped_injured(Local_755[11 /*33*/])) {
						ped::set_ped_component_variation(Local_755[10 /*33*/], 0, 0, 0, 0);
						ped::set_blocking_of_non_temporary_events(Local_755[11 /*33*/], 1);
						ped::set_blocking_of_non_temporary_events(Local_755[10 /*33*/], 1);
						if (!ped::is_synchronized_scene_running(Local_2917[iParam0 /*10*/].f_7)) {
							Local_2917[iParam0 /*10*/].f_7 =
								ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
							ai::task_synchronized_scene(Local_755[11 /*33*/], Local_2917[iParam0 /*10*/].f_7,
														"misschinese2_crystalmaze", "2int_Loop_A_TaoCheng", 1000f, -4f,
														257, 16, 1148846080, 0);
							ai::task_synchronized_scene(Local_755[10 /*33*/], Local_2917[iParam0 /*10*/].f_7,
														"misschinese2_crystalmaze", "2int_Loop_A_taotranslator", 1000f,
														-4f, 257, 16, 1148846080, 0);
							ped::_set_synchronized_scene_occlusion_portal(Local_2917[iParam0 /*10*/].f_7, 1);
						}
						ped::set_ped_config_flag(Local_755[11 /*33*/], 118, 0);
						ped::set_ped_config_flag(Local_755[11 /*33*/], 208, 1);
						ped::set_ped_config_flag(Local_755[10 /*33*/], 118, 0);
						ped::set_ped_config_flag(Local_755[10 /*33*/], 208, 1);
						Local_2917[iParam0 /*10*/].f_6 = 900;
					}
					break;

				case 900:
					if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
						if (!ped::is_ped_ragdoll(Local_755[11 /*33*/])) {
							if (ped::is_synchronized_scene_running(Local_2917[iParam0 /*10*/].f_7)) {
								if (ped::get_synchronized_scene_phase(Local_2917[iParam0 /*10*/].f_7) == 1f) {
									Local_2917[iParam0 /*10*/].f_7 =
										ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
									ped::_set_synchronized_scene_occlusion_portal(Local_2917[iParam0 /*10*/].f_7, 1);
									if (gameplay::get_random_int_in_range(0, 3) < 2) {
										ai::task_synchronized_scene(
											Local_755[11 /*33*/], Local_2917[iParam0 /*10*/].f_7,
											"misschinese2_crystalmaze", "2int_Loop_Base_TaoCheng", 1000f, -4f, 257, 16,
											1148846080, 0);
										if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
											if (!ped::is_ped_ragdoll(Local_755[10 /*33*/])) {
												if (!gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_8, 0)) {
													ai::task_synchronized_scene(Local_755[10 /*33*/],
																				Local_2917[iParam0 /*10*/].f_7,
																				"misschinese2_"
																				"crystalmaze",
																				"2int_Loop_Base_"
																				"taotranslator",
																				1000f, -4f, 257, 16, 1148846080, 0);
												}
											}
										}
									}
									else {
										ai::task_synchronized_scene(Local_755[11 /*33*/],
																	Local_2917[iParam0 /*10*/].f_7,
																	"misschinese2_crystalmaze", "2int_Loop_A_TaoCheng",
																	1000f, -4f, 257, 16, 1148846080, 0);
										if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
											if (!ped::is_ped_ragdoll(Local_755[10 /*33*/])) {
												if (!gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_8, 0)) {
													ai::task_synchronized_scene(Local_755[10 /*33*/],
																				Local_2917[iParam0 /*10*/].f_7,
																				"misschinese2_"
																				"crystalmaze",
																				"2int_Loop_A_"
																				"taotranslator",
																				1000f, -4f, 257, 16, 1148846080, 0);
												}
											}
										}
									}
								}
							}
							else {
								Local_2917[iParam0 /*10*/].f_7 =
									ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
								ai::task_synchronized_scene(Local_755[11 /*33*/], Local_2917[iParam0 /*10*/].f_7,
															"misschinese2_crystalmaze", "2int_Loop_A_TaoCheng", 1000f,
															-4f, 257, 16, 1148846080, 0);
								ped::_set_synchronized_scene_occlusion_portal(Local_2917[iParam0 /*10*/].f_7, 1);
							}
						}
					}
					if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
						if (entity::has_entity_been_damaged_by_entity(Local_755[10 /*33*/], player::player_ped_id(),
																	  1) ||
							ped::is_ped_ragdoll(Local_755[10 /*33*/]) || ped::is_ped_injured(Local_755[11 /*33*/]) ||
							!ped::is_ped_injured(Local_755[10 /*33*/]) &&
								ai::get_script_task_status(Local_755[10 /*33*/], 1785177548) == 2) {
							if (!gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_8, 0)) {
								ai::clear_ped_tasks(Local_755[10 /*33*/]);
								func_93();
								ai::task_smart_flee_ped(0, player::player_ped_id(), 30f, 20000, 0, 0);
								ai::task_cower(0, -1);
								func_92(&Local_755[10 /*33*/], 0);
								gameplay::set_bit(&Local_2917[iParam0 /*10*/].f_8, 0);
							}
						}
					}
					if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
						if (entity::has_entity_been_damaged_by_entity(Local_755[11 /*33*/], player::player_ped_id(),
																	  1) ||
							ped::is_ped_ragdoll(Local_755[11 /*33*/]) ||
							gameplay::is_bit_set(Local_2917[iParam0 /*10*/].f_8, 1) ||
							!ped::is_ped_injured(Local_755[11 /*33*/]) &&
								ai::get_script_task_status(Local_755[11 /*33*/], 1785177548) == 2) {
							entity::set_entity_health(Local_755[11 /*33*/], 0);
							if (!ped::is_ped_ragdoll(Local_755[11 /*33*/])) {
							}
						}
					}
					if (func_67(player::player_ped_id(), 1991.988f, 3054.51f, 46.215f, 1) > 200f) {
						if (entity::does_entity_exist(Local_755[11 /*33*/]) &&
							entity::does_entity_exist(Local_755[10 /*33*/])) {
							ped::delete_ped(&Local_755[11 /*33*/]);
							ped::delete_ped(&Local_755[10 /*33*/]);
						}
						streaming::set_model_as_no_longer_needed(joaat("ig_taocheng"));
						streaming::set_model_as_no_longer_needed(joaat("ig_taostranslator"));
						streaming::remove_anim_dict("misschinese2_crystalmaze");
						if (iLocal_2884 != -1) {
							if (pathfind::does_navmesh_blocking_object_exist(iLocal_2884)) {
								pathfind::remove_navmesh_blocking_object(iLocal_2884);
							}
						}
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				if (func_67(player::player_ped_id(), 1995.169f, 3062.162f, 46.049f, 1) < 7f) {
					if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
						if (ai::get_script_task_status(Local_755[11 /*33*/], 150319005) != 1) {
							ai::task_look_at_entity(Local_755[11 /*33*/], player::player_ped_id(), 4000, 2096, 2);
						}
					}
					if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
						if (ai::get_script_task_status(Local_755[10 /*33*/], 150319005) != 1) {
							ai::task_look_at_entity(Local_755[10 /*33*/], player::player_ped_id(), 4000, 2096, 2);
						}
					}
				}
				break;

			case 13:
				iVar13 = 0;
				iLocal_2887 = 0;
				iVar13 = 0;
				while (iVar13 < Local_755) {
					if (entity::does_entity_exist(Local_755[iVar13 /*33*/])) {
						if (ped::is_ped_injured(Local_755[iVar13 /*33*/])) {
							if (Local_755[iVar13 /*33*/].f_21 == 0) {
								if (ped::get_ped_cause_of_death(Local_755[iVar13 /*33*/]) == 392730790 ||
									ped::get_ped_cause_of_death(Local_755[iVar13 /*33*/]) ==
										joaat("weapon_heavysniper") ||
									ped::get_ped_cause_of_death(Local_755[iVar13 /*33*/]) ==
										joaat("weapon_remotesniper") ||
									ped::get_ped_cause_of_death(Local_755[iVar13 /*33*/]) ==
										joaat("weapon_sniperrifle")) {
									iLocal_2887++;
								}
								Local_755[iVar13 /*33*/].f_21 = 1;
							}
						}
					}
					iVar13++;
				}
				if (iLocal_2887 > 0) {
				}
				if (iLocal_2887 > 1) {
					func_165(150);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 14:
				func_15("CHN2_SNIPE_START", 0, "CHN2_EXPLODE");
				unk1::_0x293220DA1B46CEBC(4f, 15f, 4);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 15:
				if (func_87(9)) {
					func_15("CHN2_SPOTTED", 0, "CHN2_EXPLODE");
				}
				else {
					func_15("CHN2_TO_HOUSE", 0, "CHN2_EXPLODE");
				}
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 16:
				if (object::does_pickup_exist(uLocal_2675)) {
					object::remove_pickup(uLocal_2675);
				}
				iVar14 = 0;
				gameplay::set_bit(&iVar14, 3);
				gameplay::set_bit(&iVar14, 8);
				gameplay::set_bit(&iVar14, 1);
				if (!object::does_pickup_exist(uLocal_2675)) {
					uLocal_2675 = object::create_pickup(joaat("pickup_weapon_petrolcan"), 2436.775f, 4967.487f, 41.4f,
														iVar14, -1, 1, 0);
					interior::add_pickup_to_interior_room_by_name(uLocal_2675, "V_8_BasementRm");
					iLocal_2677 = func_164(uLocal_2675);
					ui::set_blip_name_from_text_file(iLocal_2677, "FRMBLIP");
				}
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 17:
				if (!func_30(5)) {
					func_166(1);
					audio::start_audio_scene("CHI_2_SHOOTOUT_STEALTH");
					gameplay::_set_unk_map_flag(1);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 19:
				streaming::remove_anim_dict("misschinese2_barrelRoll");
				streaming::remove_anim_set("move_m@gangster@var_e");
				streaming::remove_anim_set("move_m@gangster@var_f");
				streaming::remove_anim_set("move_m@gangster@generic");
				streaming::remove_anim_dict("misschinese2_bank5");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 20:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					Local_2917[iParam0 /*10*/].f_7 = gameplay::get_game_timer() + 4000;
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (gameplay::get_game_timer() > Local_2917[iParam0 /*10*/].f_7) {
						Local_2917[iParam0 /*10*/].f_7 = 0;
						while (Local_2917[iParam0 /*10*/].f_7 < Local_755) {
							if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
								if (interior::get_interior_from_entity(
										Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/]) == 0) {
									Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/].f_1 = 5;
									Local_1619[Local_2917[iParam0 /*10*/].f_7 /*24*/].f_3 = 7;
									Local_1619[Local_2917[iParam0 /*10*/].f_7 /*24*/].f_4 = 0;
									Local_1619[Local_2917[iParam0 /*10*/].f_7 /*24*/].f_5 = 0;
									func_99(Local_2917[iParam0 /*10*/].f_7, 27, 0, 0);
									ped::set_ped_relationship_group_hash(
										Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/], iLocal_1617);
									func_128(&Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/].f_25);
								}
							}
							Local_2917[iParam0 /*10*/].f_7++;
						}
					}
					break;
				}
				break;

			case 21:
				Local_2917[iParam0 /*10*/].f_7 = 0;
				while (Local_2917[iParam0 /*10*/].f_7 < Local_755) {
					if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
						if (entity::is_entity_in_angled_area(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/],
															 2457.885f, 4981.169f, 50.00518f, 2441.58f, 4965.088f,
															 56.24006f, 34.3125f, 0, 1, 0)) {
							ped::delete_ped(&Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/]);
						}
					}
					Local_2917[iParam0 /*10*/].f_7++;
				}
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 22:
				func_15("CHN2_ENTER_HOUSE", 0, "CHN2_EXPLODE");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 23:
				iVar15 = 0;
				while (iVar15 < Local_755) {
					if (!ped::is_ped_injured(Local_755[iVar15 /*33*/])) {
						if (interior::get_room_key_from_entity(Local_755[iVar15 /*33*/]) !=
							gameplay::get_hash_key("V_8_BasementRm")) {
							func_99(iVar15, 27, 0, 0);
							Local_755[iVar15 /*33*/].f_1 = 5;
							Local_1619[iVar15 /*24*/].f_3 = 7;
							Local_755[iVar15 /*33*/].f_5 = 0;
						}
					}
					iVar15++;
				}
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 24:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					Local_2917[iParam0 /*10*/].f_7 = func_18(10);
					if (Local_2917[iParam0 /*10*/].f_7 != -1) {
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 1:
					if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
						func_99(Local_2917[iParam0 /*10*/].f_7, 18, 0, 0);
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					else {
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				break;

			case 25:
				if (ped::is_ped_shooting(player::player_ped_id()) || func_87(9)) {
					ped::set_ped_using_action_mode(player::player_ped_id(), 1, -1, 0);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 26:
				audio::stop_audio_scene("CHI_2_SHOOTOUT_STEALTH");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 27:
				audio::start_audio_scene("CHI_2_SHOOTOUT_ENEMIES_ALERTED");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 28:
				if (audio::is_audio_scene_active("CHI_2_SHOOTOUT_ENEMIES_ALERTED")) {
					audio::stop_audio_scene("CHI_2_SHOOTOUT_ENEMIES_ALERTED");
				}
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 44:
				if (!audio::is_audio_scene_active("CHI_2_SHOOTOUT_IN_HOUSE")) {
					if (func_87(12)) {
						audio::start_audio_scene("CHI_2_SHOOTOUT_IN_HOUSE");
					}
				}
				else if (func_156(12)) {
					audio::stop_audio_scene("CHI_2_SHOOTOUT_IN_HOUSE");
				}
				break;

			case 45:
				if (func_87(9) ||
					!ped::is_ped_injured(Local_755[8 /*33*/]) && ped::is_ped_in_combat(Local_755[8 /*33*/], 0) ||
					!ped::is_ped_injured(Local_755[9 /*33*/]) && ped::is_ped_in_combat(Local_755[9 /*33*/], 0)) {
					if (!ped::is_ped_injured(Local_755[8 /*33*/])) {
						ped::set_ped_accuracy(Local_755[8 /*33*/], 45);
					}
					if (!ped::is_ped_injured(Local_755[9 /*33*/])) {
						ped::set_ped_accuracy(Local_755[9 /*33*/], 45);
					}
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;

			case 29:
				if (func_87(9)) {
					Local_2917[iParam0 /*10*/].f_7 = 0;
					while (Local_2917[iParam0 /*10*/].f_7 < Local_755) {
						if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
							ped::set_ped_seeing_range(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/], 60f);
						}
						Local_2917[iParam0 /*10*/].f_7++;
					}
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				else {
					switch (Local_2917[iParam0 /*10*/].f_6) {
					case 0:
						if (func_87(12)) {
							Local_2917[iParam0 /*10*/].f_7 = 0;
							while (Local_2917[iParam0 /*10*/].f_7 < Local_755) {
								if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
									if (Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/].f_1 == 1) {
										ped::set_ped_seeing_range(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/], 5f);
									}
								}
								Local_2917[iParam0 /*10*/].f_7++;
							}
							Local_2917[iParam0 /*10*/].f_6++;
						}
						break;

					case 1:
						if (func_156(12)) {
							Local_2917[iParam0 /*10*/].f_7 = 0;
							while (Local_2917[iParam0 /*10*/].f_7 < Local_755) {
								if (!ped::is_ped_injured(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/])) {
									if (Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/].f_1 == 1) {
										ped::set_ped_seeing_range(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/],
																  30f);
									}
								}
								Local_2917[iParam0 /*10*/].f_7++;
							}
							Local_2917[iParam0 /*10*/].f_6 = 0;
						}
						break;
					}
				}
				break;

			case 46:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					streaming::request_anim_dict("misschinese2_crystalmaze");
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (streaming::has_anim_dict_loaded("misschinese2_crystalmaze")) {
						if (!ped::is_ped_injured(Local_755[23 /*33*/])) {
							Local_2917[iParam0 /*10*/].f_7 =
								ped::create_synchronized_scene(2435.312f, 4967.087f, 41.35f, 0f, 0f, 11.4f, 2);
							ped::set_synchronized_scene_looped(Local_2917[iParam0 /*10*/].f_7, 1);
							ai::task_synchronized_scene(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/],
														Local_2917[iParam0 /*10*/].f_8, "misschinese2_crystalmaze",
														"_stand_to_aim", 1000f, -8f, 0, 0, 1148846080, 0);
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					break;

				case 2: break;
				}
				break;

			case 30:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					streaming::request_model(joaat("blazer"));
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (streaming::has_model_loaded(joaat("blazer"))) {
						iLocal_2508 =
							vehicle::create_vehicle(joaat("blazer"), 2478.587f, 4941.803f, 43.6736f, 227.2903f, 1, 1);
						vehicle::set_vehicle_on_ground_properly(iLocal_2508, 1084227584);
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				break;

			case 31:
				ped::set_ped_using_action_mode(player::player_ped_id(), 0, -1, 0);
				func_163(0);
				func_161();
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 32:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					if (func_87(29)) {
						if (ui::does_blip_exist(iLocal_2677)) {
							ui::remove_blip(&iLocal_2677);
						}
						func_12(0);
						if (func_84("FRMFLC", 0, 0)) {
							ui::clear_prints();
						}
						func_10(157, 0);
						unk1::_0x293220DA1B46CEBC(3f, 10f, 4);
						if (iLocal_2649 == 0) {
							iLocal_2649 =
								weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_petrolcan"));
						}
						Local_2917[iParam0 /*10*/].f_6++;
					}
					break;

				case 1:
					if (!func_87(29)) {
						func_9(158,
							   iLocal_2649 -
								   weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_petrolcan")),
							   1);
						iLocal_2679 = object::get_closest_object_of_type(
							entity::get_entity_coords(player::player_ped_id(), 1), 20f,
							weapon::get_weapontype_model(joaat("weapon_petrolcan")), 0, 0, 1);
						if (iLocal_2679 != 0) {
							if (ui::does_blip_exist(iLocal_2677)) {
								ui::remove_blip(&iLocal_2677);
							}
							iLocal_2677 = func_13(iLocal_2679);
							func_12(1);
							func_11(0, 157);
						}
						Local_2917[iParam0 /*10*/].f_6 = 0;
					}
					break;
				}
				if (func_8()) {
					func_11(0, 157);
					Local_2917[iParam0 /*10*/].f_3 = 1;
					func_32(17, 0);
				}
				break;

			case 33:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					ai::request_waypoint_recording("arm2_30");
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (ai::get_is_waypoint_recording_loaded("arm2_30")) {
						if (func_87(29)) {
							ai::use_waypoint_recording_as_assisted_movement_route("arm2_30", 1, 1f, 0.5f);
							ai::assisted_movement_set_route_properties("arm2_30", 2);
							Local_2917[iParam0 /*10*/].f_6++;
						}
					}
					break;

				case 2:
					if (!func_87(29)) {
						ai::use_waypoint_recording_as_assisted_movement_route("arm2_30", 0, 1f, 0.5f);
						Local_2917[iParam0 /*10*/].f_6 = 1;
					}
					break;
				}
				break;

			case 34:
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (interior::get_interior_from_entity(player::player_ped_id()) == 0) {
						if (func_67(player::player_ped_id(), 2451.08f, 4961.463f, 44.4392f, 1) < 20f) {
							ui::set_radar_as_interior_this_frame(0, 0f, 0f, 0, 0);
						}
					}
				}
				break;

			case 35:
				func_15("CHN2_JERRY_CAN", 0, "CHN2_EXPLODE");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 36:
				func_15("CHN2_EXIT_HOUSE", 0, "CHN2_EXPLODE");
				audio::play_sound_from_coord(iLocal_2668, "FarmhouseFire_Ignite", vLocal_2669, "CHINESE2_SOUNDS", 0, 0,
											 0);
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 37:
				audio::start_audio_scene("CHI_2_POUR_GAS");
				Local_2917[iParam0 /*10*/].f_3 = 1;
				break;

			case 38:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					audio::request_script_audio_bank("FARMHOUSE_FIRE", 0, -1);
					audio::request_script_audio_bank("FARMHOUSE_FIRE_BG", 0, -1);
					break;
				}
				break;

			case 39:
				switch (Local_2917[iParam0 /*10*/].f_6) {
				case 0:
					Local_2917[iParam0 /*10*/].f_7 = func_18(4);
					Local_2917[iParam0 /*10*/].f_6++;
					break;

				case 1:
					if (func_67(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/], 2454.895f, 4950.895f, 44.1488f, 1) >
							100f &&
						func_4(Local_755[Local_2917[iParam0 /*10*/].f_7 /*33*/], player::player_ped_id(), 1) > 100f) {
						iVar16 = func_18(4);
						func_128(&Local_755[iVar16 /*33*/].f_25);
						if (!ped::is_ped_injured(Local_755[iVar16 /*33*/])) {
							ped::set_ped_keep_task(Local_755[iVar16 /*33*/], 1);
							entity::set_ped_as_no_longer_needed(&Local_755[iVar16 /*33*/]);
						}
						Local_755[iVar16 /*33*/] = 0;
						iVar16 = func_18(5);
						func_128(&Local_755[iVar16 /*33*/].f_25);
						if (!ped::is_ped_injured(Local_755[iVar16 /*33*/])) {
							ped::set_ped_keep_task(Local_755[iVar16 /*33*/], 1);
							entity::set_ped_as_no_longer_needed(&Local_755[iVar16 /*33*/]);
						}
						Local_755[iVar16 /*33*/] = 0;
						iVar16 = func_18(7);
						if (!ped::is_ped_injured(Local_755[iVar16 /*33*/])) {
							ped::set_ped_keep_task(Local_755[iVar16 /*33*/], 1);
							entity::set_ped_as_no_longer_needed(&Local_755[iVar16 /*33*/]);
						}
						func_128(&Local_755[iVar16 /*33*/].f_25);
						Local_755[iVar16 /*33*/] = 0;
						if (vehicle::is_vehicle_driveable(iLocal_2507, 0)) {
							entity::set_vehicle_as_no_longer_needed(&iLocal_2507);
						}
						Local_2917[iParam0 /*10*/].f_3 = 1;
					}
					break;
				}
				break;

			case 40:
				if (func_101(24, joaat("a_m_m_hillbilly_01"), 2433.123f, 4960.47f, 45.8218f, 301f, joaat("weapon_smg"),
							 1, 1)) {
					ped::set_ped_accuracy(Local_755[24 /*33*/], 100);
					if (!ped::is_ped_injured(Local_755[15 /*33*/])) {
						ped::set_ped_accuracy(Local_755[15 /*33*/], 100);
					}
					if (!ped::is_ped_injured(Local_755[16 /*33*/])) {
						ped::set_ped_accuracy(Local_755[16 /*33*/], 100);
					}
					if (!ped::is_ped_injured(Local_755[17 /*33*/])) {
						ped::set_ped_accuracy(Local_755[17 /*33*/], 100);
					}
					ai::task_combat_ped(Local_755[24 /*33*/], player::player_ped_id(), 0, 16);
					ped::set_ped_target_loss_response(Local_755[24 /*33*/], 1);
					entity::set_entity_health(Local_755[24 /*33*/], 200);
					Local_2917[iParam0 /*10*/].f_3 = 1;
				}
				break;
			}
			if (Local_2917[iParam0 /*10*/].f_6 == -1) {
				Local_2917[iParam0 /*10*/].f_3 = 1;
				Local_2917[iParam0 /*10*/].f_6 = 0;
				Local_2917[iParam0 /*10*/].f_1 = 0;
			}
		}
	}
}

// Position - 0x16373
void func_161() {
	int iVar0;
	int iVar1;
	vector3 vVar2;

	iVar0 = 0;
	while (iVar0 < Local_444) {
		if (!func_162(Local_444[iVar0 /*5*/], 0f, 0f, 0f, 0)) {
			fire::stop_fire_in_range(Local_444[iVar0 /*5*/], 4f);
			gameplay::clear_area(Local_444[iVar0 /*5*/], 2f, 1, 0, 0, 0);
			iVar1 = 0;
			while (iVar1 < Local_755) {
				if (entity::does_entity_exist(Local_755[iVar1 /*33*/])) {
					vVar2 = {entity::get_entity_coords(Local_755[iVar1 /*33*/], 0)};
					if (system::vdist2(vVar2, Local_444[iVar0 /*5*/]) < 2f && vVar2.z > 43.9f) {
						ped::delete_ped(&Local_755[iVar1 /*33*/]);
					}
				}
				iVar1++;
			}
		}
		iVar0++;
	}
}

// Position - 0x16426
bool func_162(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x1646D
void func_163(int iParam0) {
	int iVar0;

	bLocal_265 = true;
	iLocal_269 = 0;
	iLocal_267 = -1;
	iLocal_443 = 0;
	iLocal_443 = 0;
	iLocal_437 = 0;
	if (iParam0 == 0) {
		iLocal_262 = 1;
	}
	iVar0 = 0;
	while (iVar0 < Local_444) {
		graphics::remove_decals_in_range(Local_444[iVar0 /*5*/], 1f);
		if (!ui::does_blip_exist(Local_444[iVar0 /*5*/].f_3)) {
			if (!func_162(Local_444[iVar0 /*5*/], 0f, 0f, 0f, 0)) {
				iLocal_269++;
				Local_444[iVar0 /*5*/].f_3 = func_5(Local_444[iVar0 /*5*/], 0);
				ui::_0x54318C915D27E4CE(Local_444[iVar0 /*5*/].f_3, 1);
				ui::set_blip_scale(Local_444[iVar0 /*5*/].f_3, 0.4f);
				ui::_0x75A16C3DA34F1245(Local_444[iVar0 /*5*/].f_3, 0);
				if (!iParam0) {
					ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 0);
				}
				ui::set_blip_colour(Local_444[iVar0 /*5*/].f_3, 5);
			}
		}
		else {
			Local_444[iVar0 /*5*/] = {ui::get_blip_coords(Local_444[iVar0 /*5*/].f_3)};
			if (!iParam0) {
				ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 0);
			}
			else {
				ui::set_blip_alpha(Local_444[iVar0 /*5*/].f_3, 255);
			}
			iLocal_269++;
		}
		Local_444[iVar0 /*5*/].f_4 = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_281) {
		Local_281[iVar0 /*5*/].f_1 = {0f, 0f, 0f};
		Local_281[iVar0 /*5*/].f_4 = 0;
		iVar0++;
	}
}

// Position - 0x165CB
int func_164(var *uParam0) {
	int iVar0;

	if (!object::does_pickup_exist(uParam0)) {
		return 0;
	}
	iVar0 = ui::add_blip_for_pickup(uParam0);
	ui::set_blip_scale(iVar0, func_6(network::network_is_game_in_progress(), 0.7f, 0.7f));
	return iVar0;
}

// Position - 0x16603
void func_165(int iParam0) {
	int iVar0;
	int iVar1;

	Global_55823 = 0;
	if (MissionObjectives[iParam0 /*13*/] != 3) {
		return;
	}
	iVar0 = 0;
	iVar1 = 0;
	iVar1 = 0;
	while (iVar1 < Global_67917) {
		if (Global_67918[iVar1 /*9*/] == iParam0) {
			iVar0 = 1;
			Global_67918[iVar1 /*9*/].f_1 = 1;
			Global_67918[iVar1 /*9*/].f_2 = 0f;
			if (Global_67918[iVar1 /*9*/].f_3 == 2) {
			}
		}
		iVar1++;
	}
	if (!iVar0) {
	}
}

// Position - 0x16674
void func_166(int iParam0) {
	if (iParam0) {
		StringCopy(&Global_100756, script::get_this_script_name(), 24);
		Global_100750 = 1;
	}
	else {
		StringCopy(&Global_100756, "NULL", 24);
		Global_100750 = 0;
	}
}

// Position - 0x166A0
char *func_167() {
	var uVar0;

	return uVar0;
}

// Position - 0x166AA
bool func_168() {
	if (controls::get_control_value(2, 30) != 127 || controls::get_control_value(2, 31) != 127 ||
		controls::is_control_pressed(2, 24) || controls::is_control_pressed(2, 25) ||
		controls::get_control_value(2, 2) != 127 || controls::get_control_value(2, 1) != 127) {
		return true;
	}
	return false;
}

// Position - 0x1670C
int func_169(int iParam0, int iParam1) {
	if (Local_2917[iParam0 /*10*/] == iParam1) {
		return Local_2917[iParam0 /*10*/].f_6;
	}
	return -1;
}

// Position - 0x1672D
void func_170(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	bool bVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	bool bVar10;
	int iVar11;
	int iVar12;

	iVar0 = iParam1 - iParam0;
	if (Local_3120[0 /*8*/] != iParam0 && Local_3120[iVar0 /*8*/] != iParam1) {
		iVar2 = 0;
		iVar1 = 0;
		while (iVar1 < Local_3120) {
			if (iVar1 <= iVar0) {
				Local_3120[iVar1 /*8*/] = iParam0 + iVar2;
				Local_3120[iVar1 /*8*/].f_1 = 1;
				Local_3120[iVar1 /*8*/].f_2 = 0;
				Local_3120[iVar1 /*8*/].f_3 = 0;
				iVar2++;
			}
			else {
				Local_3120[iVar1 /*8*/].f_1 = 0;
			}
			iVar1++;
		}
	}
	iVar3 = 0;
	while (iVar3 < Local_3120) {
		switch (Local_3120[iVar3 /*8*/]) {
		case 2:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (Local_3120[iVar3 /*8*/].f_4 == 0) {
					if (func_84("FRMCHSE_1", 0, 0)) {
						Local_3120[iVar3 /*8*/].f_4 = 1;
					}
				}
				else if (!func_84("FRMCHSE_1", 0, 0)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 3:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 6:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_156(7)) {
					if (gameplay::has_bullet_impacted_in_area(2493.155f, 4970.315f, 43.88038f, 3.25f, 1, 1) ||
						gameplay::is_bullet_in_area(2493.155f, 4970.315f, 43.88038f, 3.25f, 1)) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
				else {
					Local_3120[iVar3 /*8*/].f_1 = 0;
				}
			}
			break;

		case 7:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				switch (Local_3120[iVar3 /*8*/].f_4) {
				case 0:
					Local_3120[iVar3 /*8*/].f_5 = func_18(8);
					Local_3120[iVar3 /*8*/].f_6 = func_18(9);
					Local_3120[iVar3 /*8*/].f_4++;
					break;

				case 1:
					if (Local_3120[iVar3 /*8*/].f_5 != -1 && Local_3120[iVar3 /*8*/].f_6 != -1) {
						if (entity::does_entity_exist(Local_755[Local_3120[iVar3 /*8*/].f_5 /*33*/]) &&
							entity::does_entity_exist(Local_755[Local_3120[iVar3 /*8*/].f_6 /*33*/])) {
							if (ped::is_ped_injured(Local_755[Local_3120[iVar3 /*8*/].f_5 /*33*/]) ||
								ped::is_ped_injured(Local_755[Local_3120[iVar3 /*8*/].f_6 /*33*/])) {
								Local_3120[iVar3 /*8*/].f_2 = 1;
							}
						}
					}
					break;
				}
			}
			break;

		case 9:
			if (iLocal_53) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
				Local_3120[iVar3 /*8*/].f_1 = 0;
			}
			break;

		case 11:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (interior::get_room_key_from_entity(player::player_ped_id()) ==
				gameplay::get_hash_key("V_8_BasementRm")) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 12:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (interior::get_interior_from_entity(player::player_ped_id()) != 0 &&
				entity::is_entity_in_angled_area(player::player_ped_id(), 2421.331f, 4954.833f, 25.32829f, 2466.796f,
												 4996.822f, 66.07018f, 37.1875f, 0, 1, 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 13:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (func_87(12)) {
				if (!entity::is_entity_in_angled_area(player::player_ped_id(), 2457.885f, 4981.169f, 50.00518f,
													  2441.58f, 4965.088f, 56.24006f, 34.3125f, 0, 1, 0)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 14:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_67(player::player_ped_id(), 2451.517f, 4973.122f, 44.2646f, 1) < 50f) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 15:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				Local_3120[iVar3 /*8*/].f_5 = func_18(17);
				if (Local_3120[iVar3 /*8*/].f_5 != -1) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;

			case 1:
				if (entity::does_entity_exist(Local_755[Local_3120[iVar3 /*8*/].f_5 /*33*/])) {
					if (ped::is_ped_injured(Local_755[Local_3120[iVar3 /*8*/].f_5 /*33*/])) {
						if (func_67(Local_755[Local_3120[iVar3 /*8*/].f_5 /*33*/], 2427.851f, 4964.972f, 43.1704f, 1) <
							3f) {
							Local_3120[iVar3 /*8*/].f_2 = 1;
							Local_3120[iVar3 /*8*/].f_4++;
						}
						else {
							Local_3120[iVar3 /*8*/].f_1 = 0;
						}
					}
				}
				break;
			}
			break;

		case 16:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				switch (Local_3120[iVar3 /*8*/].f_4) {
				case 0:
					if (!func_30(5)) {
						Local_3120[iVar3 /*8*/].f_4++;
					}
					break;

				case 1:
					iVar5 = 0;
					bVar6 = false;
					iVar4 = 0;
					while (iVar4 < Local_755) {
						if (!ped::is_ped_injured(Local_755[iVar4 /*33*/])) {
							iVar5 = 1;
							if (Local_755[iVar4 /*33*/].f_1 == 1) {
								bVar6 = true;
								iVar4 = Local_755;
							}
						}
						iVar4++;
					}
					if (!iVar5) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
					else {
						Local_3120[iVar3 /*8*/].f_2 = 0;
					}
					if (bVar6) {
						func_91(10, 0);
					}
					else {
						func_91(10, 1);
					}
					break;
				}
			}
			break;

		case 23:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_87(9)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
					iVar8 = 0;
					iVar7 = 0;
					while (iVar7 < Local_755) {
						if (Local_755[iVar7 /*33*/].f_1 == 1) {
							if (!ped::is_ped_injured(Local_755[iVar7 /*33*/])) {
								iVar8++;
								if (iVar8 > 1) {
									Local_3120[iVar3 /*8*/].f_2 = 0;
									iVar7 = Local_755;
								}
							}
						}
						iVar7++;
					}
				}
			}
			break;

		case 24:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				if (func_67(player::player_ped_id(), 2446.674f, 4977.788f, 57.4583f, 1) < 250f) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;

			case 1:
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					iVar9 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
					if (vehicle::is_this_model_a_heli(entity::get_entity_model(iVar9)) ||
						vehicle::is_this_model_a_plane(entity::get_entity_model(iVar9))) {
						if (func_67(player::player_ped_id(), 2446.674f, 4977.788f, 57.4583f, 0) > 700f) {
							Local_3120[iVar3 /*8*/].f_2 = 1;
						}
					}
					else {
						bVar10 = true;
					}
				}
				else {
					bVar10 = true;
				}
				if (bVar10) {
					if (func_67(player::player_ped_id(), 2446.674f, 4977.788f, 57.4583f, 1) > 250f) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
				break;
			}
			break;

		case 26:
			if (func_67(player::player_ped_id(), 2441.065f, 4968.819f, 45.83075f, 1) < 2.75f) {
				if (!ped::is_ped_injured(Local_755[15 /*33*/])) {
					if (func_67(Local_755[15 /*33*/], 2439.386f, 4962.049f, 45.9047f, 1) < 3f) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
				if (!ped::is_ped_injured(Local_755[16 /*33*/])) {
					if (func_67(Local_755[16 /*33*/], 2439.386f, 4962.049f, 45.9047f, 1) < 3f) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
				if (!ped::is_ped_injured(Local_755[17 /*33*/])) {
					if (func_67(Local_755[17 /*33*/], 2439.386f, 4962.049f, 45.9047f, 1) < 3f) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
				Local_3120[iVar3 /*8*/].f_1 = 0;
			}
			break;

		case 27:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				if (!ped::is_ped_injured(Local_755[4 /*33*/]) &&
					ped::is_ped_sitting_in_any_vehicle(Local_755[4 /*33*/])) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				if (!ped::is_ped_injured(Local_755[5 /*33*/]) &&
					ped::is_ped_sitting_in_any_vehicle(Local_755[5 /*33*/])) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				if (!ped::is_ped_injured(Local_755[7 /*33*/]) &&
					ped::is_ped_sitting_in_any_vehicle(Local_755[7 /*33*/])) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				Local_3120[iVar3 /*8*/].f_5 = gameplay::get_game_timer() + 8000;
				break;

			case 1:
				if (vehicle::is_vehicle_driveable(iLocal_2507, 0)) {
					if (func_90(entity::get_entity_coords(iLocal_2507, 1), 5f, 150f)) {
						Local_3120[iVar3 /*8*/].f_6 += system::floor(system::timestep() * 1000f);
					}
				}
				if (Local_3120[iVar3 /*8*/].f_6 > 1500) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
				if (gameplay::get_game_timer() > Local_3120[iVar3 /*8*/].f_5) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;
			}
			break;

		case 30:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				if (object::does_pickup_exist(uLocal_2675)) {
					if (object::does_pickup_object_exist(uLocal_2675)) {
						Local_3120[iVar3 /*8*/].f_4++;
					}
				}
				break;

			case 1:
				if (object::does_pickup_exist(uLocal_2675)) {
					if (!object::does_pickup_object_exist(uLocal_2675)) {
						if (fire::is_explosion_in_sphere(-1, 2435.252f, 4966.748f, 41.3476f, 4f)) {
							Local_3120[iVar3 /*8*/].f_2 = 1;
						}
						Local_3120[iVar3 /*8*/].f_4++;
					}
				}
				break;
			}
			break;

		case 8:
			if (iLocal_57 && !iLocal_53) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 17:
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2442.819f, 4970.283f, 45.2481f, 2439.625f,
												 4966.862f, 48.14596f, 3.4375f, 0, 1, 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 18:
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2434.671f, 4959.104f, 44.85109f, 2440.5f,
												 4965.189f, 48.1231f, 3.625f, 0, 1, 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 19:
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2432.467f, 4959.473f, 44.94133f, 2430.797f,
												 4961.173f, 48.30901f, 1.5625f, 0, 1, 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 21:
			if (bLocal_56) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
				Local_3120[iVar3 /*8*/].f_1 = 0;
			}
			break;

		case 32:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (entity::is_entity_in_angled_area(player::player_ped_id(), 2447.671f, 4951.438f, 43.25576f, 2454.664f,
												 4957.856f, 47.89117f, 6.8125f, 0, 1, 0)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 33:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;

			case 1:
				if (!weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
				break;
			}
			break;

		case 29:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			switch (Local_3120[iVar3 /*8*/].f_5) {
			case 0:
				if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
					Local_3120[iVar3 /*8*/].f_5 = 10;
				}
				else {
					Local_3120[iVar3 /*8*/].f_5 = 20;
				}
				break;
			}
			if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
				if (Local_3120[iVar3 /*8*/].f_5 == 20) {
				}
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 34:
			if (!Local_3120[iVar3 /*8*/].f_2 == 1) {
				if (func_8()) {
					func_11(0, 157);
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 35:
			if (Local_444[0 /*5*/].f_4 == 1) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 36:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			iVar11 = joaat("weapon_unarmed");
			if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar11, 1)) {
				if (iVar11 == joaat("weapon_petrolcan")) {
					if (controls::is_control_pressed(0, 24)) {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
				}
			}
			break;

		case 44:
			if (fire::is_explosion_in_angled_area(-1, 2435.776f, 4963.067f, 39.34265f, 2428.118f, 4971.287f, 43.67327f,
												  11.875f)) {
				if (!fire::is_explosion_in_angled_area(24, 2435.776f, 4963.067f, 39.34265f, 2428.118f, 4971.287f,
													   43.67327f, 11.875f) &&
					!fire::is_explosion_in_angled_area(22, 2435.776f, 4963.067f, 39.34265f, 2428.118f, 4971.287f,
													   43.67327f, 11.875f)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 41:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				if (func_174()) {
					iVar12 = func_173();
					if (iVar12 <= 17) {
						func_91(37, 1);
					}
					else {
						Local_3120[iVar3 /*8*/].f_2 = 1;
					}
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;
			}
			break;

		case 38:
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_172(17)) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 40:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (interior::get_interior_from_entity(player::player_ped_id()) != 0) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 42:
			if (func_67(player::player_ped_id(), 2439.52f, 4969.67f, 52.65f, 1) > 42.5f) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 43:
			if (func_67(player::player_ped_id(), 2439.52f, 4969.67f, 52.65f, 1) > 60f) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 39:
			if (func_171()) {
				if (!func_174()) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 47:
			switch (Local_3120[iVar3 /*8*/].f_4) {
			case 0:
				Local_3120[iVar3 /*8*/].f_5 = gameplay::get_game_timer() + 30000;
				Local_3120[iVar3 /*8*/].f_4++;
				break;

			case 1:
				if (gameplay::get_game_timer() > Local_3120[iVar3 /*8*/].f_5) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
					Local_3120[iVar3 /*8*/].f_4++;
				}
				break;
			}
			break;

		case 48:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_67(player::player_ped_id(), 2448.25f, 4974.92f, 55.11f, 1) > 300f) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 51:
			if (func_147(1, 49)) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;

		case 49:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (!Local_3120[iVar3 /*8*/].f_2) {
				if (func_67(player::player_ped_id(), 2448.25f, 4974.92f, 55.11f, 1) > 500f) {
					Local_3120[iVar3 /*8*/].f_2 = 1;
				}
			}
			break;

		case 50:
			Local_3120[iVar3 /*8*/].f_2 = 0;
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				Local_3120[iVar3 /*8*/].f_2 = 1;
			}
			break;
		}
		iVar3++;
	}
}

// Position - 0x176C6
bool func_171() {
	if (iLocal_437 == 1) {
		return true;
	}
	return false;
}

// Position - 0x176DA
bool func_172(int iParam0) {
	if (fire::get_number_of_fires_in_range(Local_444[iParam0 /*5*/], 0.6f) > 0) {
		return true;
	}
	return false;
}

// Position - 0x176FD
int func_173() { return iLocal_280; }

// Position - 0x17708
bool func_174() {
	int iVar0;

	iVar0 = Local_444 - 1;
	while (iVar0 >= 0) {
		if (Local_444[iVar0 /*5*/].f_4) {
			if (fire::get_number_of_fires_in_range(Local_444[iVar0 /*5*/], 0.6f) > 0) {
				vLocal_277 = {Local_444[iVar0 /*5*/]};
				iLocal_280 = iVar0;
				return true;
			}
		}
		else {
			return false;
		}
		iVar0 += -1;
	}
	return false;
}

// Position - 0x17767
void func_175() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	graphics::_0x27CFB1B1E078CB2D();
	if (func_195() && iLocal_2512 > 0 && gameplay::get_game_timer() > iLocal_2641) {
		while (!cam::is_screen_faded_out()) {
			cam::do_screen_fade_out(1000);
			func_28(28, 1);
		}
		iLocal_3690 = 0;
		while (!func_194()) {
			func_28(32322, 1);
		}
		entity::set_entity_coords(player::player_ped_id(), 2474.97f, 4946.047f, 44.0297f, 1, 0, 0, 1);
		entity::set_entity_heading(player::player_ped_id(), 230.6937f);
		ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
		ped::set_ped_using_action_mode(player::player_ped_id(), 0, -1, 0);
		weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
		ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
		func_186(0, 1, 1, 0);
		cam::destroy_all_cams(0);
		cam::render_script_cams(0, 0, 3000, 1, 0, 0);
		player::set_player_control(player::player_id(), 1, 0);
		cam::set_gameplay_cam_relative_heading(0f);
		cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		ui::clear_prints();
		audio::_0xDDC635D5B3262C56("SLOW_MO_METH_HOUSE_RAYFIRE");
		uLocal_2672 = object::_get_des_object(2457.15f, 4968.79f, 48.677f, 45f, "DES_FarmHs");
		func_31(12, 1);
		iLocal_2640 = 0;
		iLocal_2645 = iLocal_2645;
		iLocal_2645 = 99;
		iLocal_2512 = 99;
		iLocal_2454 = 3;
		fLocal_2453 = 10000f;
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 965837842, 1);
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 247384786, 1);
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, -247908770, 0);
		audio::stop_stream();
		unk1::_0x81CBAE94390F9F89();
		iLocal_2647 = 1;
	}
	ui::hide_hud_and_radar_this_frame();
	switch (iLocal_2512) {
	case 0:
		func_194();
		iLocal_2647 = 0;
		iVar0 = 49;
		while (iVar0 <= 55) {
			Local_444[iVar0 /*5*/] = {Local_444[iVar0 /*5*/] + Vector(0.6f, 0f, 0f)};
			iVar0++;
		}
		if (audio::is_audio_scene_active("CHI_2_POUR_GAS")) {
			audio::stop_audio_scene("CHI_2_POUR_GAS");
		}
		if (audio::is_audio_scene_active("CHI_2_SHOOT_GAS")) {
			audio::stop_audio_scene("CHI_2_SHOOT_GAS");
		}
		audio::start_audio_scene("CHI_2_GAS_TRAIL_FIRE");
		iLocal_2641 = gameplay::get_game_timer() + 1000;
		gameplay::clear_area(2570.53f, 4982.057f, 50.6819f, 100f, 1, 0, 0, 0);
		player::set_player_control(player::player_id(), 0, 0);
		weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
		func_81(0);
		iLocal_3491 = 0;
		func_81(1);
		ui::clear_prints();
		func_185(2467.775f, 4954.415f, 42.87803f, 2477.089f, 4945.079f, 46.16654f, 4.0625f, 2486.854f, 4939.086f,
				 43.2578f, 230f, 1, 1, 1, 0, 0);
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			entity::set_entity_coords(player::player_ped_id(), 2455.941f, 4952.801f, 44.112f, 1, 0, 0, 1);
		}
		gameplay::set_time_scale(1f);
		streaming::remove_anim_dict("misschinese2_barrelRoll");
		streaming::remove_anim_set("move_m@gangster@var_e");
		streaming::remove_anim_set("move_m@gangster@var_f");
		streaming::remove_anim_set("move_m@gangster@generic");
		streaming::remove_anim_dict("misschinese2_bank5");
		streaming::remove_anim_dict("misschinese2_bank1");
		streaming::remove_anim_dict("reaction@male_stand@big_variations@b");
		streaming::remove_anim_dict("reaction@male_stand@big_intro@left");
		streaming::remove_anim_dict("reaction@male_stand@big_intro@right");
		streaming::remove_anim_dict("reaction@male_stand@big_intro@backward");
		streaming::set_model_as_no_longer_needed(joaat("a_m_m_hillbilly_02"));
		streaming::set_model_as_no_longer_needed(joaat("a_m_y_methhead_01"));
		streaming::set_model_as_no_longer_needed(joaat("prop_cs_fertilizer"));
		streaming::set_model_as_no_longer_needed(joaat("burrito"));
		streaming::set_model_as_no_longer_needed(joaat("prop_cs_beer_bot_01"));
		ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
		iVar1 = 0;
		while (iVar1 < Local_755) {
			if (entity::does_entity_exist(Local_755[iVar1 /*33*/])) {
				ped::delete_ped(&Local_755[iVar1 /*33*/]);
			}
			if (entity::does_entity_exist(Local_755[iVar1 /*33*/].f_20)) {
				object::delete_object(&Local_755[iVar1 /*33*/].f_20);
			}
			iVar1++;
		}
		iLocal_2512++;
		break;

	case 1:
		if (cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			cam::do_screen_fade_in(1000);
		}
		iLocal_2512++;
		break;
	}
	if (iLocal_2342) {
		iLocal_2342 = 0;
		iVar2 = 0;
		while (iVar2 < Local_2380) {
			iVar2++;
		}
		iVar2 = 0;
		while (iVar2 < Local_2343) {
			iVar2++;
		}
	}
	iVar2 = 0;
	while (iVar2 < Local_2380) {
		if (iLocal_2455[iVar2]) {
			iLocal_2455[iVar2] = 0;
			Local_2380[iVar2 /*18*/] = {cam::get_cam_coord(cam::get_rendering_cam())};
			Local_2380[iVar2 /*18*/].f_3 = {cam::get_cam_rot(cam::get_rendering_cam(), 2)};
			Local_2380[iVar2 /*18*/].f_14 = cam::get_cam_fov(cam::get_rendering_cam());
		}
		if (iLocal_2460[iVar2]) {
			iLocal_2460[iVar2] = 0;
			Local_2380[iVar2 /*18*/].f_6 = {cam::get_cam_coord(cam::get_rendering_cam())};
			Local_2380[iVar2 /*18*/].f_9 = {cam::get_cam_rot(cam::get_rendering_cam(), 2)};
			Local_2380[iVar2 /*18*/].f_15 = cam::get_cam_fov(cam::get_rendering_cam());
		}
		iVar2++;
	}
	if (iLocal_2340) {
		iLocal_2340 = 0;
		bLocal_2341 = false;
		iLocal_2673 = 0;
		gameplay::clear_area(2431.097f, 4967.043f, 41.3476f, 20f, 1, 0, 0, 0);
		func_184();
	}
	if (!bLocal_2341) {
		if (streaming::is_srl_loaded()) {
			streaming::_0xBEB2D9A1D9A8F55A(5, 5, 5, 5);
			streaming::begin_srl();
			iLocal_2454 = -1;
			cam::destroy_all_cams(0);
			func_186(1, 1, 1, 0);
			streaming::request_anim_dict("misschinese2_crystalmaze");
			bLocal_2341 = true;
			Local_2343[0 /*6*/] = 0;
			Local_2343[1 /*6*/] = 0;
			Local_2343[2 /*6*/] = 0;
			Local_2343[3 /*6*/] = 0;
			Local_2343[0 /*6*/].f_4 = 0;
			Local_2343[0 /*6*/].f_5 = 0;
			Local_2343[1 /*6*/].f_4 = 0;
			Local_2343[1 /*6*/].f_5 = 0;
			Local_2343[2 /*6*/].f_4 = 0;
			Local_2343[2 /*6*/].f_5 = 0;
			Local_2343[3 /*6*/].f_4 = 0;
			Local_2343[3 /*6*/].f_5 = 0;
			func_32(12, 0);
			audio::play_stream_frontend();
			unk1::_0x48621C9FCA3EBD28(4);
			switch (iLocal_2648) {
			case 3: system::settimera(0); break;

			case 2:
				Local_2343[0 /*6*/] = 1;
				Local_2343[1 /*6*/] = 1;
				system::settimera(10900);
				iLocal_2454 = 2;
				fLocal_2453 = 10000f;
				break;

			case 1:
				Local_2343[0 /*6*/] = 1;
				system::settimera(6400);
				iLocal_2454 = 1;
				fLocal_2453 = 10000f;
				break;
			}
			iLocal_2505 = 0;
		}
	}
	if (bLocal_2341) {
		streaming::set_srl_time(system::to_float(system::timera()));
	}
	if (bLocal_2341) {
		fLocal_2453 += system::timestep();
		if (iLocal_2454 == -1 ||
			iLocal_2454 != -1 && iLocal_2454 < 4 && fLocal_2453 > Local_2380[iLocal_2454 /*18*/].f_13 / 1000f) {
			iLocal_2454++;
			if (iLocal_2454 == 3) {
				if (streaming::has_anim_dict_loaded("misschinese2_crystalmaze")) {
					iLocal_2637 = cam::create_camera(964613260, 1);
					iLocal_2638 = ped::create_synchronized_scene(2452.914f, 4962.096f, 45.585f, 0f, 0f, 45f, 2);
					cam::play_synchronized_cam_anim(iLocal_2637, iLocal_2638, "trevor_barn_walk_cam",
													"misschinese2_crystalmaze");
					if (!ped::is_ped_injured(player::player_ped_id())) {
						ai::task_synchronized_scene(player::player_ped_id(), iLocal_2638, "misschinese2_crystalmaze",
													"trevor_barn_walk", 1000f, -8f, 0, 0, 1148846080, 0);
					}
					cam::render_script_cams(1, 0, 3000, 1, 0, 0);
					func_184();
					streaming::set_game_pauses_for_streaming(1);
					fLocal_2453 = 0f;
				}
			}
			else if (iLocal_2454 < 4) {
				cam::destroy_all_cams(0);
				iLocal_2637 = cam::create_cam_with_params("DEFAULT_SCRIPTED_CAMERA", Local_2380[iLocal_2454 /*18*/],
														  Local_2380[iLocal_2454 /*18*/].f_3,
														  Local_2380[iLocal_2454 /*18*/].f_14, 1, 2);
				cam::set_cam_params(iLocal_2637, Local_2380[iLocal_2454 /*18*/].f_6, Local_2380[iLocal_2454 /*18*/].f_9,
									Local_2380[iLocal_2454 /*18*/].f_15,
									system::floor(Local_2380[iLocal_2454 /*18*/].f_12),
									Local_2380[iLocal_2454 /*18*/].f_16, 1, 2);
				cam::render_script_cams(1, 0, 3000, 1, 0, 0);
				if (iLocal_2454 < 2) {
					func_183(Local_2380[iLocal_2454 /*18*/].f_17, 1, 1);
				}
				else {
					func_183(Local_2380[iLocal_2454 /*18*/].f_17, 1, 0);
				}
				fLocal_2453 = 0f;
			}
			else if (!bLocal_2339) {
				cam::destroy_all_cams(0);
				cam::render_script_cams(0, 0, 3000, 1, 0, 0);
				if (func_182() && !iLocal_2647) {
					graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
					audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
				}
				player::set_player_control(player::player_id(), 1, 0);
				streaming::set_game_pauses_for_streaming(0);
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
				func_181(0, 0, 1, 0);
				audio::stop_audio_scene("CHI_2_GAS_TRAIL_FIRE");
				object::_set_des_object_state(uLocal_2672, 9);
				gameplay::set_time_scale(1f);
				streaming::end_srl();
				if (cam::is_screen_faded_out()) {
					while (object::_get_des_object_state(uLocal_2672) != 10) {
						func_28(29, 1);
					}
					cam::do_screen_fade_in(1000);
				}
				unk1::_0x81CBAE94390F9F89();
				func_176(9);
			}
		}
		iVar3 = 0;
		while (iVar3 < Local_2343) {
			if (!Local_2343[iVar3 /*6*/]) {
				if (iLocal_2454 == Local_2343[iVar3 /*6*/].f_1 && fLocal_2453 > Local_2343[iVar3 /*6*/].f_2 / 1000f) {
					switch (iVar3) {
					case 0:
						switch (Local_2343[iVar3 /*6*/].f_4) {
						case 0:
							iLocal_2505 = 0;
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/], 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								Local_2343[iVar3 /*6*/].f_4++;
							}
							break;

						case 1:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/] + vLocal_2465[iLocal_2505 + 1 /*3*/] / FtoV(2f),
										 0);
								iLocal_2505++;
								if (iLocal_2505 >= 12) {
									Local_2343[iVar3 /*6*/].f_4 = 10;
									Local_2343[iVar3 /*6*/] = 1;
								}
								else {
									Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
									Local_2343[iVar3 /*6*/].f_4 = 2;
								}
							}
							break;

						case 2:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/], 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								if (iLocal_2505 == 2) {
									Local_2343[iVar3 /*6*/].f_4 = 3;
								}
								else {
									Local_2343[iVar3 /*6*/].f_4 = 1;
								}
							}
							break;

						case 3:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/] + vLocal_2465[iLocal_2505 + 1 /*3*/] / FtoV(2f),
										 0);
								func_122(vLocal_2465[iLocal_2505 /*3*/] + vLocal_2465[iLocal_2505 + 2 /*3*/] / FtoV(2f),
										 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								Local_2343[iVar3 /*6*/].f_4 = 4;
								iLocal_2505 = 3;
							}
							break;

						case 4:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/], 0);
								func_122(vLocal_2465[iLocal_2505 + 1 /*3*/], 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								Local_2343[iVar3 /*6*/].f_4 = 5;
							}
							break;

						case 5:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/] + vLocal_2465[iLocal_2505 + 2 /*3*/] / FtoV(2f),
										 0);
								func_122(vLocal_2465[iLocal_2505 + 1 /*3*/] +
											 vLocal_2465[iLocal_2505 + 3 /*3*/] / FtoV(2f),
										 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								Local_2343[iVar3 /*6*/].f_4 = 6;
								iLocal_2505 = 5;
							}
							break;

						case 6:
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								func_122(vLocal_2465[iLocal_2505 /*3*/], 0);
								func_122(vLocal_2465[iLocal_2505 + 1 /*3*/], 0);
								Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 200;
								Local_2343[iVar3 /*6*/].f_4 = 2;
								iLocal_2505 = 7;
							}
							break;
						}
						break;

					case 1:
						fire::add_explosion(2432.534f, 4968.383f, 42.2389f, 4, 0.5f, 1, 0, 1f, 0);
						Local_2343[iVar3 /*6*/] = 1;
						break;

					case 2:
						iLocal_2673 = 1;
						Local_2343[iVar3 /*6*/] = 1;
						break;

					case 3:
						if (cam::does_cam_exist(iLocal_2637)) {
							cam::shake_cam(iLocal_2637, "LARGE_EXPLOSION_SHAKE", fLocal_2639);
							cam::set_cam_motion_blur_strength(iLocal_2637, 0.1f);
							Local_2343[iVar3 /*6*/] = 1;
						}
						break;

					case 4:
						switch (Local_2343[iVar3 /*6*/].f_4) {
						case 0:
							entity::set_entity_coords(player::player_ped_id(), 2473.208f, 4947.625f, 44.0664f, 1, 0, 0,
													  1);
							entity::set_entity_heading(player::player_ped_id(), 223.493f);
							cam::set_gameplay_cam_relative_heading(0f);
							cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
							if (func_182()) {
								ped::force_ped_motion_state(player::player_ped_id(), 1063765679, 1, 0, 0);
								player::simulate_player_input_gait(player::player_id(), 1f, 3000, 0, 1, 0);
							}
							else {
								ped::force_ped_motion_state(player::player_ped_id(), -668482597, 1, 0, 0);
								player::simulate_player_input_gait(player::player_id(), 1f, 500, 0, 1, 0);
							}
							Local_2343[iVar3 /*6*/].f_4++;
							break;

						case 1: break;
						}
						break;

					case 5:
						switch (Local_2343[iVar3 /*6*/].f_4) {
						case 0:
							fLocal_2674 = 1f;
							Local_2343[iVar3 /*6*/].f_4++;
							Local_2343[iVar3 /*6*/].f_5 = gameplay::get_game_timer() + 1300;
							audio::_0xD01005D2BA2EB778("SLOW_MO_METH_HOUSE_RAYFIRE");
							break;

						case 1:
							fLocal_2674 -= system::timestep() * 1f;
							if (fLocal_2674 < 0.2f) {
								fLocal_2674 = 0.2f;
							}
							gameplay::set_time_scale(fLocal_2674);
							if (gameplay::get_game_timer() > Local_2343[iVar3 /*6*/].f_5) {
								Local_2343[iVar3 /*6*/].f_4++;
							}
							break;

						case 2:
							fLocal_2674 += system::timestep() * 1f;
							if (fLocal_2674 > 1f) {
								fLocal_2674 = 1f;
								Local_2343[iVar3 /*6*/].f_4++;
								Local_2343[iVar3 /*6*/] = 1;
							}
							audio::_0xDDC635D5B3262C56("SLOW_MO_METH_HOUSE_RAYFIRE");
							gameplay::set_time_scale(fLocal_2674);
							break;
						}
						break;
					}
				}
			}
			iVar3++;
		}
	}
}

// Position - 0x18505
void func_176(int iParam0) {
	func_180();
	func_179();
	func_178();
	func_177();
	if (iParam0 == 11) {
		iLocal_2511++;
	}
	else {
		iLocal_2511 = iParam0;
	}
}

// Position - 0x18534
void func_177() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_3358) {
		Local_3358[iVar0 /*7*/] = 0;
		Local_3358[iVar0 /*7*/].f_1 = 0;
		Local_3358[iVar0 /*7*/].f_3 = 0;
		Local_3358[iVar0 /*7*/].f_2 = 0;
		Local_3358[iVar0 /*7*/].f_4 = 0;
		Local_3358[iVar0 /*7*/].f_5 = 0;
		Local_3358[iVar0 /*7*/].f_6 = 0;
		iVar0++;
	}
}

// Position - 0x18594
void func_178() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_2917) {
		if (Local_2917[iVar0 /*10*/].f_4) {
			Local_2917[iVar0 /*10*/].f_1 = 1;
			Local_2917[iVar0 /*10*/].f_6 = -1;
			func_160(iVar0, Local_2917[iVar0 /*10*/], 0, 0, 0, 1, 0, 1, 0, 1, 0);
		}
		Local_2917[iVar0 /*10*/] = 0;
		Local_2917[iVar0 /*10*/].f_1 = 0;
		Local_2917[iVar0 /*10*/].f_2 = 0;
		Local_2917[iVar0 /*10*/].f_3 = 0;
		Local_2917[iVar0 /*10*/].f_6 = 0;
		Local_2917[iVar0 /*10*/].f_4 = 0;
		Local_2917[iVar0 /*10*/].f_5 = 0;
		Local_2917[iVar0 /*10*/].f_7 = 0;
		Local_2917[iVar0 /*10*/].f_8 = 0;
		Local_2917[iVar0 /*10*/].f_9 = 0f;
		iVar0++;
	}
}

// Position - 0x18648
void func_179() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_3120) {
		Local_3120[iVar0 /*8*/] = 0;
		Local_3120[iVar0 /*8*/].f_1 = 0;
		Local_3120[iVar0 /*8*/].f_2 = 0;
		Local_3120[iVar0 /*8*/].f_3 = 0;
		Local_3120[iVar0 /*8*/].f_4 = 0;
		Local_3120[iVar0 /*8*/].f_5 = 0;
		iVar0++;
	}
}

// Position - 0x1869E
void func_180() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_3337) {
		Local_3337[iVar0 /*4*/] = 0;
		Local_3337[iVar0 /*4*/].f_1 = 0;
		Local_3337[iVar0 /*4*/].f_2 = 0;
		Local_3337[iVar0 /*4*/].f_3 = 0;
		iVar0++;
	}
}

// Position - 0x186E0
int func_181(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && iParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x18713
bool func_182() {
	if (cam::_0xEE778F8C7E1142E2(cam::_0x19CAFA3C87F7C2FF()) == 4) {
		return true;
	}
	return false;
}

// Position - 0x1872C
void func_183(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iLocal_438 = iParam2;
	if (iParam0 > -1) {
		iLocal_437 = 1;
		iLocal_439 = gameplay::get_game_timer();
		iLocal_440 = iParam0 * 2;
		iLocal_442 = iLocal_440;
		if (iParam1) {
			iLocal_443 = 0;
		}
		else {
			iLocal_443 = iLocal_440;
		}
		iVar0 = 0;
		while (iVar0 < Local_444) {
			Local_444[iVar0 /*5*/].f_4 = 1;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < Local_281) {
			fire::remove_script_fire(Local_281[iVar0 /*5*/]);
			if (Local_281[iVar0 /*5*/].f_4 != 0) {
				graphics::fade_decals_in_range(Local_281[iVar0 /*5*/].f_1, 0.4f, 1f);
			}
			Local_281[iVar0 /*5*/].f_4 = 0;
			iVar0++;
		}
	}
}

// Position - 0x187D2
void func_184() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_281) {
		fire::remove_script_fire(Local_281[iVar0 /*5*/]);
		Local_281[iVar0 /*5*/].f_4 = 0;
		iVar0++;
	}
	func_163(0);
	iVar0 = 0;
	while (iVar0 < Local_444) {
		if (ui::does_blip_exist(Local_444[iVar0 /*5*/].f_3)) {
			ui::remove_blip(&Local_444[iVar0 /*5*/].f_3);
		}
		Local_444[iVar0 /*5*/].f_4 = 0;
		iVar0++;
	}
	iLocal_269 = -1;
}

// Position - 0x18847
void func_185(vector3 vParam0, vector3 vParam3, float fParam6, vector3 vParam7, float fParam10, int iParam11,
			  int iParam12, int iParam13, int iParam14, int iParam15) {
	func_70(vParam0, vParam3, fParam6, vParam7, fParam10, 0f, 0f, 0f, iParam11, iParam12, iParam13, iParam14, iParam15);
}

// Position - 0x18870
void func_186(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_193(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_40()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_181(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_193(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_181(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_191(player::player_id()) &&
				!func_188(player::player_id(), 0) && !func_187()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_191(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0x18989
bool func_187() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0x189A6
bool func_188(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_189(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x189F1
int func_189(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_190();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x18A32
var func_190() { return Global_1312735; }

// Position - 0x18A3E
int func_191(int iParam0) {
	if (func_188(iParam0, 0)) {
		return 1;
	}
	if (func_192()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0x18A80
bool func_192() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x18A91
void func_193(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0x18AB4
int func_194() {
	switch (iLocal_3690) {
	case 0:
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent001"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent002"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent003"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent004"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent005"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent006"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent007"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent008"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent009"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent010"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent011"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent012"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent013"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent014"));
		streaming::request_model(joaat("cs2_03_fmhse_vfx_parent015"));
		iLocal_3690++;
		break;

	case 1:
		if (streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent001")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent002")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent003")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent004")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent005")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent006")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent007")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent008")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent009")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent010")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent011")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent012")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent013")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent014")) &&
			streaming::has_model_loaded(joaat("cs2_03_fmhse_vfx_parent015"))) {
			return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x18C51
int func_195() {
	if (ui::is_pause_menu_active()) {
		return 0;
	}
	if (controls::is_control_just_pressed(0, 18) || controls::is_control_just_pressed(2, 18)) {
		return 1;
	}
	return 0;
}

// Position - 0x18C83
void func_196() {
	graphics::_0x27CFB1B1E078CB2D();
	func_170(28, 45);
	func_149(0, 7, 0, 0, 1, 0, 1, 0);
	func_149(1, 8, 2, 29, 1, 0, 1, 0);
	func_149(2, 9, 2, 35, 5, 34, 1, 0);
	func_149(3, 10, 2, 42, 1, 0, 1, 0);
	func_157(0, 21, 2, 29, 1, 0, 1, 0, 1, 0);
	func_157(1, 22, 2, 36, 5, 34, 1, 0, 1, 0);
	func_157(2, 26, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(3, 23, 2, 37, 1, 0, 1, 0, 1, 0);
	func_198(4, 25, 3, 23, 1, 0, 1, 0, 1, 0);
	func_160(0, 30, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(1, 31, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(2, 32, 1, 3, 34, 1, 0, 1, 0, 1, 0);
	func_160(3, 33, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(4, 34, 1, 3, 34, 1, 0, 1, 0, 1, 0);
	func_160(5, 35, 0, 2, 29, 1, 0, 1, 0, 1, 0);
	func_160(6, 36, 0, 2, 37, 1, 0, 1, 0, 1, 0);
	func_160(7, 37, 0, 2, 29, 1, 0, 1, 0, 1, 0);
	func_160(8, 38, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(9, 56, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(10, 11, 0, 2, 44, 1, 0, 1, 0, 1, 0);
	func_160(11, 50, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(12, 51, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_197(0, 2, 33, 5, 34);
	func_197(4, 2, 43, 1, 0);
	func_197(2, 2, 39, 1, 0);
	if (iLocal_2648 == 0) {
		if (func_87(37) && !func_87(44)) {
			iLocal_2648 = 3;
		}
		if (func_87(41) && !func_87(44)) {
			iLocal_2646 = 1;
			iLocal_2648 = 1;
		}
		if (func_169(10, 11) == 2) {
			iLocal_2648 = 2;
			iLocal_2646 = 1;
		}
	}
	func_160(13, 10, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	if (func_87(37) && func_87(38) || iLocal_2646)
		&&func_169(13, 10) == 10 && !func_82("CHI2_light") {
			func_197(1, 2, 40, 1, 0);
			if (ui::does_blip_exist(iLocal_2677)) {
				ui::remove_blip(&iLocal_2677);
			}
			unk1::_0x293220DA1B46CEBC(10f, 5f, 4);
			func_12(1);
			func_176(11);
		}
}

// Position - 0x18EDD
void func_197(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (func_152(iParam1, iParam2, iParam3, iParam4, 1, 0, 1, 0)) {
		switch (iParam0) {
		case 0: func_130("CHFAIL1"); break;

		case 1: func_130("FRMSOON"); break;

		case 2: func_130("FRMTRAI"); break;

		case 3:
			if (entity::does_entity_exist(Local_755[11 /*33*/])) {
				if (ped::is_ped_injured(Local_755[11 /*33*/])) {
					func_130("FRMCHI");
				}
			}
			if (entity::does_entity_exist(Local_755[10 /*33*/])) {
				if (ped::is_ped_injured(Local_755[10 /*33*/])) {
					func_130("FRMCHI2");
				}
			}
			break;

		case 4: func_130("CHFAIL2"); break;

		case 5: func_130("FRMGASF"); break;
		}
	}
}

// Position - 0x18FA5
void func_198(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9) {
	if (!Local_3358[iParam0 /*7*/].f_1) {
		if (func_199(iParam2, iParam3)) {
			func_157(iParam0, iParam1, iParam4, iParam5, iParam6, iParam7, iParam8, iParam9, 1, 0);
		}
	}
}

// Position - 0x18FDB
bool func_199(int iParam0, int iParam1) {
	if (Local_3358[iParam0 /*7*/] == iParam1) {
		if (Local_3358[iParam0 /*7*/].f_1) {
			return true;
		}
	}
	else if (Local_3358[iParam0 /*7*/] != 0) {
	}
	return false;
}

// Position - 0x1900E
void func_200() {
	func_170(5, 31);
	func_149(0, 2, 0, 0, 1, 0, 1, 0);
	func_149(1, 3, 2, 8, 1, 0, 1, 0);
	func_149(2, 5, 2, 9, 1, 0, 1, 0);
	func_149(3, 11, 0, 0, 1, 0, 1, 0);
	func_149(4, 4, 2, 12, 1, 0, 1, 0);
	func_160(0, 17, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(1, 13, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(2, 14, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(3, 16, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(4, 15, 0, 2, 14, 6, 9, 1, 0, 1, 0);
	func_160(7, 19, 0, 2, 9, 1, 0, 1, 0, 1, 0);
	func_160(8, 20, 0, 2, 12, 4, 9, 1, 0, 1, 0);
	func_160(9, 21, 0, 2, 12, 4, 13, 1, 0, 1, 0);
	func_160(10, 22, 0, 2, 12, 1, 0, 1, 0, 1, 0);
	func_160(11, 23, 0, 2, 11, 1, 0, 1, 0, 1, 0);
	func_160(12, 24, 0, 2, 14, 1, 0, 1, 0, 1, 0);
	func_160(5, 26, 0, 2, 11, 6, 16, 6, 9, 1, 0);
	func_160(6, 27, 0, 2, 9, 1, 0, 1, 0, 1, 0);
	func_160(14, 40, 0, 2, 26, 1, 0, 1, 0, 1, 0);
	func_160(13, 39, 0, 2, 25, 1, 0, 1, 0, 1, 0);
	func_160(15, 28, 0, 2, 11, 6, 16, 1, 0, 1, 0);
	func_160(16, 29, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(17, 43, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(18, 44, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(19, 45, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(0, 1, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(2, 2, 2, 21, 5, 16, 1, 0, 1, 0);
	func_157(3, 3, 2, 12, 4, 17, 1, 0, 1, 0);
	func_157(4, 5, 2, 18, 1, 0, 1, 0, 1, 0);
	func_157(5, 6, 2, 19, 1, 0, 1, 0, 1, 0);
	func_157(6, 7, 2, 27, 5, 9, 1, 0, 1, 0);
	func_157(7, 10, 2, 9, 5, 21, 5, 12, 1, 0);
	func_157(8, 11, 2, 9, 4, 21, 5, 12, 1, 0);
	func_157(9, 14, 2, 9, 4, 12, 1, 0, 1, 0);
	func_157(10, 12, 2, 9, 4, 12, 1, 0, 1, 0);
	func_157(11, 13, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(12, 16, 2, 9, 4, 23, 5, 12, 1, 0);
	func_157(13, 17, 2, 14, 5, 12, 4, 9, 1, 0);
	func_157(14, 18, 3, 20, 1, 0, 1, 0, 1, 0);
	func_157(15, 19, 0, 0, 1, 0, 1, 0, 1, 0);
	func_157(16, 20, 2, 9, 4, 10, 4, 14, 5, 12);
	func_197(4, 2, 24, 1, 0);
	func_197(5, 2, 30, 1, 0);
	if (func_87(11) && func_87(29)) {
		func_176(7);
	}
}

// Position - 0x192E3
void func_201() {
	vector3 vVar0;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	vehicle::_0x9A75585FB2E54FAD(2004.447f, 3076.807f, 46.6069f, 10f);
	cutscene::_0xE36A98D8AB3D3C66(1);
	if (func_195() && iLocal_2512 > 0 && iLocal_2512 < 7 && gameplay::get_game_timer() > iLocal_2641) {
		iLocal_2512 = 10;
		iLocal_2640 = 0;
		iLocal_2647 = 1;
	}
	if (iLocal_2512 < 10) {
		if (cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			cam::do_screen_fade_in(1000);
		}
	}
	if (iLocal_2880) {
		streaming::set_srl_time(system::to_float(system::timera()));
	}
	ui::hide_hud_and_radar_this_frame();
	switch (iLocal_2512) {
	case 0:
		if (streaming::is_srl_loaded()) {
			cutscene::request_cutscene("CHI_2_MCS_5", 8);
			iLocal_2879 = 1;
			iLocal_2647 = 0;
			streaming::_0xBEB2D9A1D9A8F55A(5, 5, 5, 5);
			streaming::begin_srl();
			graphics::_set_far_shadows_suppressed(0);
			iLocal_2883 = 0;
			iLocal_2880 = 1;
			vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
			fVar3 = func_96(2458.223f, 4986.042f, 49.05241f, vVar0, 1);
			if (fVar3 > 180f) {
				fVar3 -= 360f;
			}
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iVar4 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			}
			if (vehicle::is_vehicle_driveable(iVar4, 0) &&
					vehicle::is_this_model_a_heli(entity::get_entity_model(iVar4)) && entity::is_entity_in_air(iVar4) ||
				vehicle::is_vehicle_driveable(iVar4, 0) &&
					vehicle::is_this_model_a_plane(entity::get_entity_model(iVar4)) &&
					entity::is_entity_in_air(iVar4)) {
				if (fVar3 < func_215(-2.5f) && fVar3 > func_215(0.5f)) {
					iLocal_2512 = 6;
					system::settimera(30000);
					streaming::set_srl_time(30000f);
					iLocal_2640 = 36000;
				}
				else {
					iLocal_2512 = 7;
					system::settimera(36000);
					streaming::set_srl_time(36000f);
					iLocal_2640 = 42000;
				}
			}
			else {
				if (entity::does_entity_exist(iVar4)) {
					if (vehicle::is_vehicle_driveable(iVar4, 0)) {
						if (!(vehicle::is_this_model_a_heli(entity::get_entity_model(iVar4)) &&
							  entity::is_entity_in_air(iVar4)) &&
							!(vehicle::is_this_model_a_plane(entity::get_entity_model(iVar4)) &&
							  entity::is_entity_in_air(iVar4))) {
							vehicle::set_vehicle_on_ground_properly(iVar4, 1084227584);
						}
					}
				}
				if (fVar3 < func_215(-1.33f) && fVar3 > func_215(-1.92f)) {
					iLocal_2512 = 1;
					system::settimera(0);
					streaming::set_srl_time(0f);
					iLocal_2640 = 6000;
				}
				else if (fVar3 < func_215(0.96f) && fVar3 > func_215(-1.33f)) {
					iLocal_2512 = 2;
					system::settimera(6000);
					streaming::set_srl_time(6000f);
					iLocal_2640 = 12000;
				}
				else if (fVar3 < func_215(2.29f) && fVar3 > func_215(0.96f)) {
					iLocal_2512 = 3;
					system::settimera(12000);
					streaming::set_srl_time(12000f);
					iLocal_2640 = 18000;
				}
				else if (fVar3 < func_215(-2.81f) || fVar3 > func_215(2.29f)) {
					iLocal_2512 = 4;
					system::settimera(18000);
					streaming::set_srl_time(18000f);
					iLocal_2640 = 24000;
				}
				else {
					system::settimera(24000);
					streaming::set_srl_time(24000f);
					iLocal_2640 = 30000;
					iLocal_2512 = 5;
				}
			}
			iLocal_2881 = 1;
			cam::destroy_all_cams(0);
			func_210(&Local_2683, 1, 0);
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iLocal_260 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
				vLocal_752 = {entity::get_entity_velocity(iLocal_260)};
				entity::freeze_entity_position(iLocal_260, 1);
				entity::set_entity_visible(iLocal_260, 0, 0);
			}
			audio::play_stream_frontend();
			if (iLocal_2512 == 1) {
				iLocal_2883 = 1;
				func_69(2559.012f, 4958.518f, 36.02959f, 2585.447f, 4993.435f, 64.62565f, 48f, 2594.651f, 4948.114f,
						38.0899f, 283.7287f, 22f, 22f, 15f, 1, 1, 1, 0, 0);
				if (entity::does_entity_exist(iVar4)) {
					if (vehicle::is_vehicle_driveable(iVar4, 0)) {
						vehicle::set_vehicle_engine_on(iVar4, 0, 1, 0);
					}
				}
				gameplay::clear_area(2445.139f, 4978.642f, 52.1489f, 150f, 1, 1, 0, 0);
				gameplay::clear_area(2578.523f, 4982.284f, 51.4416f, 13f, 1, 0, 0, 0);
				entity::set_entity_coords(player::player_ped_id(), 2578.419f, 4981.901f, 50.587f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 49.2184f);
				ai::clear_ped_tasks_immediately(player::player_ped_id());
				ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
				ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
				ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 0, 0);
				ai::open_sequence_task(&iVar5);
				ai::task_go_straight_to_coord(0, 2570.543f, 4982.002f, 50.6795f, 1f, 20000, 1193033728, 1056964608);
				ai::task_achieve_heading(0, 88.7065f, 0);
				ai::close_sequence_task(iVar5);
				ai::task_perform_sequence(player::player_ped_id(), iVar5);
				ai::clear_sequence_task(&iVar5);
				iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
				cam::add_cam_spline_node(iLocal_2637, 2538.6f, 4976.9f, 50.6f, -1.8f, 0f, 93.2f, 5000, 3, 2);
				cam::add_cam_spline_node(iLocal_2637, 2536.153f, 4976.7f, 50.5267f, -1.8f, 0f, 93.2f, 6000, 3, 2);
				cam::set_cam_fov(iLocal_2637, 34.9f);
				cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
			}
			else {
				switch (iLocal_2512) {
				case 2:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2426.8f, 5088.3f, 51.2f, 0f, 0f, -169f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, 2427.8f, 5087.2f, 51.2f, 0f, 0f, -169.7f, 6000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 28.5f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;

				case 3:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2326.3f, 4985.6f, 51.5f, 0f, 0f, -89.1f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, 2328f, 4985.4f, 52.1f, 0f, 0f, -89.1f, 6000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 28.5f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;

				case 4:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2403.6f, 4889.7f, 47.5f, 3.4f, 0f, -19.5f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, Vector(47.5f, 4889.7f, 2403.6f) + Vector(0.07f, 2.15f, 0.8f),
											 3.4f, 0f, -19.5f, 6000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 29.8f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;

				case 5:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2493.4f, 4934.8f, 45.7f, 5.2f, 0f, 48f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, Vector(45.7f, 4934.8f, 2493.4f) + Vector(0f, 1f, -1f), 5.2f,
											 0f, 48f, 6000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 28.5f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;

				case 6:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2570.6f, 4982f, 151.6f, -47.9f, 0f, 88.1f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, 2487.8f, 4896.9f, 151.9f, -47.2f, 0f, 28.8f, 15000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 28.5f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;

				case 7:
					iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
					cam::add_cam_spline_node(iLocal_2637, 2487.8f, 4896.9f, 151.9f, -47.2f, 0f, 28.8f, 5000, 3, 2);
					cam::add_cam_spline_node(iLocal_2637, 2570.6f, 4982f, 151.6f, -47.9f, 0f, 88.1f, 15000, 3, 2);
					cam::set_cam_fov(iLocal_2637, 28.5f);
					cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
					break;
				}
			}
			if (iLocal_2512 < 6) {
				cam::shake_cam(iLocal_2637, "Hand_shake", 0.2f);
			}
			else {
				cam::shake_cam(iLocal_2637, "Hand_shake", 0.7f);
			}
			cam::set_cam_active(iLocal_2637, 1);
			cam::render_script_cams(1, 0, 3000, 1, 0, 0);
			unk1::_0x48621C9FCA3EBD28(4);
			audio::start_audio_scene("CHI_2_FARMHOUSE_OVERVIEW");
			func_205(1);
			player::set_wanted_level_multiplier(0f);
			player::set_max_wanted_level(0);
			ui::clear_prints();
			ui::clear_help(1);
			player::set_player_control(player::player_id(), 0, 32);
			func_186(1, 1, 1, 0);
			ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
			iLocal_2641 = gameplay::get_game_timer() + 1000;
			iVar6 = 0;
			while (iVar6 < Local_755) {
				if (!ped::is_ped_injured(Local_755[iVar6 /*33*/])) {
					audio::stop_ped_speaking(Local_755[iVar6 /*33*/], 1);
				}
				iVar6++;
			}
			iLocal_2642 =
				ped::create_ped(26, joaat("a_m_y_methhead_01"), 2460.449f, 4976.938f, 45.5765f, 243.4917f, 1, 1);
			weapon::give_weapon_to_ped(iLocal_2642, joaat("weapon_microsmg"), -1, 1, 1);
			if (!ped::is_ped_injured(iLocal_2642)) {
				func_93();
				ai::task_set_blocking_of_non_temporary_events(0, 1);
				ai::task_follow_nav_mesh_to_coord(0, 2463.016f, 4974.97f, 45.5765f, 1f, -1, 0.5f, 1, 1193033728);
				ai::task_follow_nav_mesh_to_coord(0, 2452.833f, 4964.785f, 45.5765f, 1f, -1, 0.5f, 1, 1193033728);
				ai::task_pause(0, 500);
				ai::task_follow_nav_mesh_to_coord(0, 2460.449f, 4976.938f, 45.5765f, 1f, -1, 0.5f, 0, 1193033728);
				func_92(&iLocal_2642, 1);
			}
			iLocal_2509 = vehicle::create_vehicle(joaat("dubsta"), 2479.961f, 4990f, 45.8f, -5.37f, 1, 1);
			func_15("CHN2_MISSION_START", 1, "CHN2_EXPLODE");
			iLocal_2512 = 3;
		}
		break;

	case 3:
		if (system::timera() > iLocal_2640) {
			cam::destroy_all_cams(0);
			iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
			cam::add_cam_spline_node(iLocal_2637, 2445.944f, 4962.986f, 51.4782f, 7.9159f, 0f, 34.5909f, 5000, 3, 2);
			cam::add_cam_spline_node(iLocal_2637, 2445.684f, 4963.368f, 51.6659f, 3.6033f, 0f, 34.5909f, 3500, 3, 2);
			cam::set_cam_fov(iLocal_2637, 34f);
			cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
			cam::shake_cam(iLocal_2637, "Hand_shake", 0.5f);
			iLocal_2640 += 3500;
			iLocal_2512++;
		}
		break;

	case 4:
		if (system::timera() > iLocal_2640) {
			cam::destroy_all_cams(0);
			iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
			cam::add_cam_spline_node(iLocal_2637, 2465.07f, 4946.688f, 45.3372f, 7.1461f, 0f, 30.9281f, 5000, 3, 2);
			cam::add_cam_spline_node(iLocal_2637, 2466.011f, 4947.377f, 45.3509f, 7.1461f, 0f, 32.3761f, 3000, 3, 2);
			cam::set_cam_fov(iLocal_2637, 34f);
			cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
			cam::shake_cam(iLocal_2637, "Hand_shake", 0.5f);
			iLocal_2640 += 3000;
			iLocal_2512++;
		}
		break;

	case 5:
		iLocal_2882 = 1;
		if (system::timera() > iLocal_2640) {
			iLocal_2882 = 1;
			cam::destroy_all_cams(0);
			iLocal_2637 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 1);
			cam::add_cam_spline_node(iLocal_2637, 2509.691f, 4971.024f, 44.1325f, 7.2578f, 0f, 88.5226f, 5000, 3, 2);
			cam::add_cam_spline_node(iLocal_2637, 2509.415f, 4971.163f, 44.1674f, 6.6554f, 0f, 89.4229f, 2500, 3, 2);
			cam::set_cam_fov(iLocal_2637, 37.34f);
			cam::_0xD1B0F412F109EA5D(iLocal_2637, 0);
			cam::shake_cam(iLocal_2637, "Hand_shake", 0.5f);
			iLocal_2640 += 2500;
			iLocal_2512++;
		}
		break;

	case 6:
		if (system::timera() > iLocal_2640) {
			if (func_204()) {
				ui::clear_prints();
				ui::clear_help(1);
				cam::_0x70894BD0915C5BCA(6.818f);
				if (vehicle::is_vehicle_driveable(iLocal_2509, 0)) {
					cutscene::register_entity_for_cutscene(iLocal_2509, "EXL_2_abandoned_car", 1, joaat("dubsta"), 0);
				}
				cutscene::start_cutscene(0);
				iLocal_2879 = 0;
				iLocal_2512 = 11;
			}
		}
		break;

	case 10:
		if (entity::does_entity_exist(iLocal_260) && vehicle::is_vehicle_driveable(iLocal_260, 0)) {
			vehicle::request_vehicle_high_detail_model(iLocal_260);
		}
		if (!cam::is_screen_faded_out() && !cam::is_screen_fading_out()) {
			cam::do_screen_fade_out(500);
		}
		if (cam::is_screen_faded_out() && !cutscene::is_cutscene_playing() ||
			cutscene::is_cutscene_active() && cutscene::can_set_exit_state_for_camera(1)) {
			iLocal_2512++;
		}
		break;

	case 11:
		if (entity::does_entity_exist(iLocal_260) && vehicle::is_vehicle_driveable(iLocal_260, 0)) {
			vehicle::request_vehicle_high_detail_model(iLocal_260);
		}
		if (cam::is_screen_faded_out() && !cutscene::is_cutscene_playing() ||
			cutscene::is_cutscene_active() && cutscene::can_set_exit_state_for_camera(1)) {
			cam::destroy_all_cams(0);
			cam::render_script_cams(0, 0, 3000, 1, 0, 0);
			if (func_182() && !iLocal_2647) {
				graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
				audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
			}
			unk1::_0x81CBAE94390F9F89();
			if (func_67(player::player_ped_id(), 2570.543f, 4982.002f, 50.6795f, 1) < 15f &&
				func_67(player::player_ped_id(), 2570.543f, 4982.002f, 50.6795f, 1) > 1f) {
				entity::set_entity_coords(player::player_ped_id(), 2570.543f, 4982.002f, 50.6795f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 98.21f);
			}
			else if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				entity::set_entity_heading(
					player::player_ped_id(),
					func_96(entity::get_entity_coords(player::player_ped_id(), 1), 2458.223f, 4986.042f, 49.05241f, 1));
			}
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-6.3f, 1065353216);
			cam::_0x70894BD0915C5BCA(6.818f);
			ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
			audio::stop_stream();
			audio::stop_audio_scene("CHI_2_FARMHOUSE_OVERVIEW");
			ui::clear_prints();
			ui::clear_help(1);
			player::set_player_control(player::player_id(), 1, 0);
			func_205(0);
			if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_sniperrifle"), 0)) {
				if (weapon::get_ammo_in_ped_weapon(player::player_ped_id(), joaat("weapon_sniperrifle")) < 15) {
					weapon::add_ammo_to_ped(player::player_ped_id(), joaat("weapon_sniperrifle"), 50);
				}
			}
			func_186(0, 1, 1, 0);
			if (entity::does_entity_exist(iLocal_2642)) {
				ped::delete_ped(&iLocal_2642);
			}
			iLocal_2885 = func_18(4);
			if (iLocal_2885 != -1) {
				if (!ped::is_ped_injured(Local_755[iLocal_2885 /*33*/])) {
					ped::delete_ped(&Local_755[iLocal_2885 /*33*/]);
				}
				if (entity::does_entity_exist(Local_755[iLocal_2885 /*33*/].f_20)) {
					object::delete_object(&Local_755[iLocal_2885 /*33*/].f_20);
				}
				Local_1619[iLocal_2885 /*24*/].f_3 = 1;
				Local_755[iLocal_2885 /*33*/].f_5 = 0;
				Local_755[iLocal_2885 /*33*/].f_14 = 0;
				Local_755[iLocal_2885 /*33*/].f_3 = 2;
			}
			iLocal_2886 = func_18(5);
			if (iLocal_2886 != -1) {
				if (!ped::is_ped_injured(Local_755[iLocal_2886 /*33*/])) {
					ped::delete_ped(&Local_755[iLocal_2886 /*33*/]);
				}
				if (entity::does_entity_exist(Local_755[iLocal_2886 /*33*/].f_20)) {
					object::delete_object(&Local_755[iLocal_2886 /*33*/].f_20);
				}
				Local_1619[iLocal_2886 /*24*/].f_3 = 1;
				Local_755[iLocal_2886 /*33*/].f_5 = 0;
				Local_755[iLocal_2886 /*33*/].f_14 = 0;
				Local_755[iLocal_2886 /*33*/].f_3 = 2;
			}
			func_31(20, 0);
			if (!ped::is_ped_injured(iLocal_2643)) {
				ped::delete_ped(&iLocal_2643);
			}
			if (!ped::is_ped_injured(iLocal_2644)) {
				ped::delete_ped(&iLocal_2644);
			}
			if (func_68(iLocal_2509)) {
				vehicle::delete_vehicle(&iLocal_2509);
			}
			if (entity::does_entity_exist(iLocal_2682)) {
				object::delete_object(&iLocal_2682);
			}
			func_202();
			iLocal_751 = 0;
			func_27();
			streaming::set_model_as_no_longer_needed(joaat("prop_phone_ing"));
			streaming::set_model_as_no_longer_needed(joaat("dubsta"));
			iVar7 = 0;
			while (iVar7 < Local_755) {
				if (!ped::is_ped_injured(Local_755[iVar7 /*33*/])) {
					audio::stop_ped_speaking(Local_755[iVar7 /*33*/], 0);
				}
				iVar7++;
			}
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-6.3f, 1065353216);
			if (entity::does_entity_exist(iLocal_260)) {
				if (vehicle::is_vehicle_driveable(iLocal_260, 0)) {
					entity::freeze_entity_position(iLocal_260, 0);
					if (vehicle::is_this_model_a_plane(entity::get_entity_model(iLocal_260))) {
						entity::set_entity_velocity(iLocal_260, vLocal_752);
						ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_260, -1);
					}
					vehicle::set_vehicle_engine_on(iLocal_260, 1, 1, 0);
					if (vehicle::is_this_model_a_heli(entity::get_entity_model(iLocal_260))) {
						entity::set_entity_rotation(iLocal_260, 0f, 0f, entity::get_entity_heading(iLocal_260), 2, 1);
						vehicle::set_heli_blades_full_speed(iLocal_260);
						entity::set_entity_velocity(iLocal_260, 1f, 1f, 1f);
						ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_260, -1);
					}
					if (iLocal_2883 == 0) {
						ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_260, -1);
					}
					entity::set_entity_visible(iLocal_260, 1, 0);
				}
			}
			entity::set_entity_visible(player::player_ped_id(), 1, 0);
			player::special_ability_fill_meter(player::player_id(), 1);
			streaming::end_srl();
			if (cam::is_screen_faded_out()) {
				cam::do_screen_fade_in(1000);
			}
			graphics::_set_far_shadows_suppressed(1);
			func_176(11);
		}
		break;
	}
}

// Position - 0x1A36A
void func_202() {
	int iVar0;

	if (entity::does_entity_exist(iLocal_2507)) {
		vehicle::delete_vehicle(&iLocal_2507);
	}
	iVar0 = 0;
	while (iVar0 < Local_755) {
		if (entity::does_entity_exist(Local_755[iVar0 /*33*/])) {
			ped::delete_ped(&Local_755[iVar0 /*33*/]);
		}
		if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
			object::delete_object(&Local_755[iVar0 /*33*/].f_20);
		}
		Local_755[iVar0 /*33*/].f_3 = 0;
		Local_755[iVar0 /*33*/].f_4 = 0;
		Local_755[iVar0 /*33*/].f_6 = {0f, 0f, 0f};
		Local_755[iVar0 /*33*/].f_9 = {0f, 0f, 0f};
		Local_755[iVar0 /*33*/].f_2 = 25;
		Local_755[iVar0 /*33*/].f_5 = 0;
		Local_755[iVar0 /*33*/].f_12 = 0f;
		Local_755[iVar0 /*33*/].f_13 = 0f;
		Local_755[iVar0 /*33*/].f_14 = 0;
		Local_755[iVar0 /*33*/].f_15 = 0;
		Local_755[iVar0 /*33*/].f_17 = 0;
		Local_755[iVar0 /*33*/].f_16 = 0;
		Local_755[iVar0 /*33*/].f_21 = 0;
		Local_755[iVar0 /*33*/].f_22 = 0;
		Local_1619[iVar0 /*24*/].f_3 = 1;
		iVar0++;
	}
	if (object::does_pickup_exist(uLocal_2650)) {
		object::remove_pickup(uLocal_2650);
	}
	iVar0 = 0;
	while (iVar0 < iLocal_2651) {
		if (object::does_pickup_exist(iLocal_2651[iVar0])) {
			object::remove_pickup(iLocal_2651[iVar0]);
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < iLocal_2657) {
		if (entity::does_entity_exist(iLocal_2657[iVar0])) {
			object::delete_object(&iLocal_2657[iVar0]);
		}
		iVar0++;
	}
	func_203(&Local_1619, &uLocal_2708, cLocal_2338, 12f, 2482.197f, 4975.367f, 44.7288f, 121f, 1);
}

// Position - 0x1A4FE
void func_203(var *uParam0, var *uParam1, char *sParam2, float fParam3, vector3 vParam4, float fParam7, int iParam8) {
	int iVar0;

	iLocal_57 = iLocal_57;
	uLocal_70 = fParam3;
	vLocal_71 = {vParam4};
	fLocal_74 = fParam7;
	Local_89 = {*uParam1};
	cLocal_254 = sParam2;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0 /*24*/].f_1 = 0;
		(*uParam0)[iVar0 /*24*/].f_2 = 0;
		(*uParam0)[iVar0 /*24*/].f_3 = iParam8;
		(*uParam0)[iVar0 /*24*/].f_4 = 0;
		(*uParam0)[iVar0 /*24*/].f_5 = 0;
		(*uParam0)[iVar0 /*24*/].f_7 = 0;
		(*uParam0)[iVar0 /*24*/].f_8 = 0;
		(*uParam0)[iVar0 /*24*/].f_10 = 0;
		(*uParam0)[iVar0 /*24*/].f_11 = 0;
		(*uParam0)[iVar0 /*24*/].f_12 = {0f, 0f, 0f};
		(*uParam0)[iVar0 /*24*/].f_15 = {0f, 0f, 0f};
		(*uParam0)[iVar0 /*24*/].f_18 = 0f;
		iVar0++;
	}
	iLocal_53 = 0;
	bLocal_54 = false;
	iLocal_55 = 0;
	bLocal_56 = false;
	iLocal_57 = 0;
	bLocal_77 = true;
	iLocal_76 = 0;
	iLocal_58 = 0;
	iLocal_60 = 0;
	iLocal_61 = -1;
	iLocal_62 = -1;
	iLocal_63 = 0;
	iLocal_64 = 0;
	iLocal_65 = 0;
	iLocal_66 = 0;
	iLocal_67 = 0;
	iLocal_68 = 0;
	iLocal_69 = 0;
	decisionevent::block_decision_maker_event(-455129387, 31);
	iLocal_52 = 0;
}

// Position - 0x1A5F5
bool func_204() {
	bool bVar0;

	bVar0 = cutscene::has_cutscene_loaded();
	if (!Global_69701) {
		if (!bVar0) {
			Global_69701 = 1;
		}
	}
	return bVar0;
}

// Position - 0x1A618
void func_205(int iParam0) {
	if (iParam0) {
		func_209();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_208(0)) {
			func_206(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x1A67B
void func_206(int iParam0) {
	if (Global_14604) {
		func_207(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_40()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x1A6EB
void func_207(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_208(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x1A75F
bool func_208(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x1A7B9
void func_209() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x1A7E2
void func_210(int *iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (gameplay::is_bit_set(uParam0->f_13, 30)) {
		iParam1 = 1;
	}
	func_214(uParam0);
	iVar0 = 0;
	while (iVar0 < 3) {
		if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
			ui::remove_blip(&uParam0->f_1[iVar0]);
		}
		func_213(iVar0, uParam0);
		func_212(iVar0, uParam0);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 31) {
		if (iVar0 != 8) {
			gameplay::clear_bit(&uParam0->f_13, iVar0);
			gameplay::clear_bit(&uParam0->f_14, iVar0);
		}
		iVar0++;
	}
	if (ui::does_blip_exist(*uParam0)) {
		ui::remove_blip(uParam0);
	}
	iParam0->f_6 = 0;
	iParam0->f_12 = 0;
	iParam0->f_15 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(iParam0->f_17[iVar0])) {
			ped::set_ped_can_play_ambient_anims(iParam0->f_17[iVar0], 1);
			ped::set_ped_can_play_ambient_base_anims(iParam0->f_17[iVar0], 1);
			if (iParam2) {
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 32, 1);
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 305, 0);
			}
			ped::set_ped_config_flag(iParam0->f_17[iVar0], 268, 0);
			if (iParam1) {
				if (ped::is_ped_group_member(iParam0->f_17[iVar0], func_211()) &&
					iParam0->f_17[iVar0] != player::player_ped_id()) {
					ped::remove_ped_from_group(iParam0->f_17[iVar0]);
				}
			}
			if (!gameplay::is_bit_set(iParam0->f_13, 29)) {
				ped::set_ped_using_action_mode(iParam0->f_17[iVar0], 0, -1, 0);
			}
			iParam0->f_17[iVar0] = 0;
		}
		iVar0++;
	}
	if (player::is_player_playing(player::player_id())) {
		ped::set_ped_can_play_ambient_anims(player::player_ped_id(), 1);
		ped::set_ped_can_play_ambient_base_anims(player::player_ped_id(), 1);
	}
	if (player::is_player_playing(player::player_id())) {
		if (iParam2) {
			ped::set_ped_config_flag(player::player_ped_id(), 32, 1);
		}
	}
	iParam0->f_21 = 0;
}

// Position - 0x1A993
var func_211() { return player::get_player_group(player::get_player_index()); }

// Position - 0x1A9A3
void func_212(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 17); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 18); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 19); break;
	}
}

// Position - 0x1A9EB
void func_213(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 14); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 15); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 16); break;
	}
}

// Position - 0x1AA33
void func_214(var *uParam0) {
	if (ui::does_blip_exist(uParam0->f_5)) {
		ui::remove_blip(&uParam0->f_5);
	}
}

// Position - 0x1AA4E
float func_215(float fParam0) { return fParam0 * 57.29578f; }

// Position - 0x1AA5E
void func_216() {
	int iVar0;

	func_170(1, 4);
	func_160(0, 2, 0, 2, 3, 1, 0, 1, 0, 1, 0);
	func_160(1, 3, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(2, 41, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(3, 42, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(4, 47, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(5, 4, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(6, 6, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(7, 7, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(8, 8, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(9, 9, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_160(10, 5, 0, 0, 0, 1, 0, 1, 0, 1, 0);
	func_149(0, 1, 2, 2, 1, 0, 1, 0);
	func_197(3, 0, 0, 1, 0);
	if (func_67(player::player_ped_id(), 2458.223f, 4986.042f, 49.05241f, 0) < 107.9f ||
		entity::is_entity_in_angled_area(player::player_ped_id(), 2374.441f, 4930.564f, 34.73784f, 2478.099f, 5077.488f,
										 60.63246f, 185f, 0, 0, 0) ||
		entity::is_entity_in_angled_area(player::player_ped_id(), 2396.726f, 4887.434f, 33.85329f, 2510.54f, 5003.356f,
										 58.01184f, 158.25f, 0, 0, 0)) {
		if (ui::does_blip_exist(Local_2683.f_5)) {
			ui::set_blip_route(Local_2683.f_6, 0);
		}
		func_176(11);
	}
	else {
		switch (iLocal_2512) {
		case 0:
			func_32(2, 0);
			func_32(3, 0);
			func_32(1, 0);
			func_32(5, 0);
			func_260(5, -20);
			player::set_wanted_level_multiplier(0f);
			player::set_max_wanted_level(0);
			iLocal_2512++;
			break;

		case 1:
			if (func_220(&Local_2683, 2608.151f, 4949.754f, 39.4f, 9f, 9f, 2f, 1, "FRMCHSE_1", 1, 1, -1)) {
				unk1::_0x293220DA1B46CEBC(6f, 6f, 3);
				iLocal_2512++;
				func_210(&Local_2683, 1, 0);
				func_31(3, 1);
				if (audio::is_audio_scene_active("CHI_2_DRIVE_TO_FARMHOUSE")) {
					audio::stop_audio_scene("CHI_2_DRIVE_TO_FARMHOUSE");
				}
				if (audio::is_audio_scene_active("CHI_2_DRIVE_ROCK_RADIO")) {
					audio::stop_audio_scene("CHI_2_DRIVE_ROCK_RADIO");
				}
			}
			break;

		case 2:
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
				iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
				if (func_218(iVar0, 10f, 2, 1056964608, 0, 1, 0)) {
					if (func_217(5) > 2) {
						iLocal_2512++;
					}
				}
			}
			else {
				iLocal_2512++;
			}
			break;

		case 3:
			if (func_220(&Local_2683, 2573.63f, 4983.677f, 50.6978f, 12f, 12f, 2f, 0, "FRMCHSE_5", 1, 1, -1)) {
				if (audio::is_audio_scene_active("CHI_2_DRIVE_ROCK_RADIO")) {
					audio::stop_audio_scene("CHI_2_DRIVE_ROCK_RADIO");
				}
				unk1::_0x293220DA1B46CEBC(5f, 10f, 4);
				func_176(11);
			}
			if (ui::does_blip_exist(Local_2683.f_5)) {
				ui::set_blip_route(Local_2683.f_6, 0);
			}
			break;
		}
	}
}

// Position - 0x1AD57
int func_217(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 1) {
			if (Local_2515[iVar0 /*6*/] == iParam0) {
				return Local_2515[iVar0 /*6*/].f_2;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1AD99
bool func_218(int iParam0, float fParam1, int iParam2, float fParam3, int iParam4, int iParam5, int iParam6) {
	controls::disable_control_action(0, 71, 1);
	controls::disable_control_action(0, 72, 1);
	controls::disable_control_action(0, 76, 1);
	controls::disable_control_action(0, 73, 1);
	controls::disable_control_action(0, 59, 1);
	controls::disable_control_action(0, 60, 1);
	if (iParam5) {
		controls::disable_control_action(0, 75, 1);
	}
	controls::disable_control_action(0, 80, 1);
	if (!iParam6) {
		controls::disable_control_action(0, 69, 1);
		controls::disable_control_action(0, 70, 1);
		controls::disable_control_action(0, 68, 1);
	}
	controls::disable_control_action(0, 74, 1);
	controls::disable_control_action(0, 86, 1);
	controls::disable_control_action(0, 81, 1);
	controls::disable_control_action(0, 82, 1);
	controls::disable_control_action(0, 138, 1);
	controls::disable_control_action(0, 136, 1);
	controls::disable_control_action(0, 114, 1);
	controls::disable_control_action(0, 107, 1);
	controls::disable_control_action(0, 110, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 89, 1);
	controls::disable_control_action(0, 87, 1);
	controls::disable_control_action(0, 88, 1);
	controls::disable_control_action(0, 113, 1);
	controls::disable_control_action(0, 115, 1);
	controls::disable_control_action(0, 116, 1);
	controls::disable_control_action(0, 117, 1);
	controls::disable_control_action(0, 118, 1);
	controls::disable_control_action(0, 119, 1);
	controls::disable_control_action(0, 131, 1);
	controls::disable_control_action(0, 132, 1);
	controls::disable_control_action(0, 123, 1);
	controls::disable_control_action(0, 126, 1);
	controls::disable_control_action(0, 129, 1);
	controls::disable_control_action(0, 130, 1);
	controls::disable_control_action(0, 133, 1);
	controls::disable_control_action(0, 134, 1);
	cam::_0x17FCA7199A530203();
	func_219(iParam0);
	if (gameplay::get_game_timer() - Global_29 > 500) {
		vehicle::_set_vehicle_halt(iParam0, fParam1, iParam2, iParam4);
	}
	Global_29 = gameplay::get_game_timer();
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (gameplay::absf(entity::get_entity_speed(iParam0)) <= fParam3) {
			return true;
		}
	}
	return false;
}

// Position - 0x1AF28
void func_219(int iParam0) {
	if (vehicle::_get_has_vehicle_got_rocket_boost(iParam0)) {
		if (vehicle::_is_vehicle_rocket_boost_active(iParam0)) {
			vehicle::_set_rocket_boost_active(iParam0, 0);
		}
	}
}

// Position - 0x1AF49
bool func_220(var *uParam0, vector3 vParam1, vector3 vParam4, int iParam7, char *sParam8, int iParam9, int iParam10,
			  int iParam11) {
	return func_221(uParam0, vParam1, vParam4, func_259(), func_259(), iParam7, 1, 0, 0, 0, 0, sParam8, func_167(),
					func_167(), func_167(), func_167(), func_167(), 0, iParam9, func_167(), 0, 0, iParam10, iParam11, 0,
					0, 0, 1, 1065353216);
}

// Position - 0x1AF9A
int func_221(int *iParam0, vector3 vParam1, vector3 vParam4, vector3 vParam7, vector3 vParam10, int iParam13,
			 int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, char *sParam19, char *sParam20,
			 char *sParam21, char *sParam22, char *sParam23, char *sParam24, int iParam25, bool bParam26,
			 char *sParam27, int iParam28, int iParam29, bool bParam30, int iParam31, int iParam32, int iParam33,
			 int iParam34, int iParam35, float fParam36) {
	int iVar0;
	bool bVar1;
	int iVar2;
	vector3 vVar3;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;

	vVar3 = {vParam1 + Vector(1f, 0f, 0f)};
	uParam0->f_17[0] = iParam15;
	uParam0->f_17[1] = iParam16;
	uParam0->f_17[2] = iParam17;
	uParam0->f_16 = iParam15;
	func_258(uParam0);
	func_257(uParam0);
	func_256();
	if (func_240(uParam0, uParam0->f_17[0], uParam0->f_17[1], uParam0->f_17[2], sParam20, sParam21, sParam22, sParam23,
				 uParam0->f_8, iParam25, iParam18, 0, 0, iParam32, iParam33, iParam34, iParam14, bParam26)) {
		func_239(sParam20);
		func_239(sParam21);
		func_239(sParam22);
		func_239(sParam23);
		if (cam::is_screen_faded_in()) {
			bVar1 = false;
			if (vehicle::is_vehicle_driveable(iParam18, 0)) {
				if (ped::is_ped_in_vehicle(player::player_ped_id(), iParam18, 0)) {
					gameplay::set_bit(&uParam0->f_13, 3);
					if (!gameplay::is_bit_set(uParam0->f_13, 9)) {
						gameplay::clear_bit(&uParam0->f_13, 4);
					}
					if (gameplay::is_bit_set(uParam0->f_13, 23)) {
						gameplay::clear_bit(&uParam0->f_13, 23);
					}
					gameplay::set_bit(&uParam0->f_13, 9);
					bVar1 = true;
				}
			}
			else if (iParam14 == 4 || iParam14 == 5) {
				if (func_237(uParam0, iParam29)) {
					gameplay::set_bit(&uParam0->f_13, 3);
					if (!gameplay::is_bit_set(uParam0->f_13, 9)) {
						gameplay::clear_bit(&uParam0->f_13, 4);
					}
					gameplay::set_bit(&uParam0->f_13, 9);
					bVar1 = true;
				}
			}
			else {
				bVar1 = true;
			}
			if (bVar1) {
				func_239(sParam24);
				func_239(sParam27);
				func_239("MORE_SEATS");
				if (bParam26 && player::is_player_wanted_level_greater(player::player_id(), 0)) {
					if (ui::does_blip_exist(uParam0->f_5)) {
						ui::remove_blip(&uParam0->f_5);
						func_239(sParam19);
					}
					if (ui::does_blip_exist(*uParam0)) {
						ui::remove_blip(uParam0);
					}
					if (!func_234(iParam0, 1) && !func_233(iParam0) && !gameplay::is_bit_set(iParam0->f_13, 0)) {
						if (bParam30) {
							func_232(iParam0, "LOSE_WANTED", 0);
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_230(iParam0->f_17[0], "VEHICLE_POLICE_PURSUIT", 3);
							}
						}
						gameplay::set_bit(&iParam0->f_13, 0);
						gameplay::clear_bit(&iParam0->f_13, 1);
					}
				}
				else {
					if (gameplay::is_bit_set(iParam0->f_13, 0)) {
						func_239("LOSE_WANTED");
						gameplay::clear_bit(&iParam0->f_13, 0);
						gameplay::set_bit(&iParam0->f_13, 1);
					}
					if (gameplay::is_bit_set(iParam0->f_13, 1)) {
						if (!func_234(iParam0, 1)) {
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_230(iParam0->f_17[0], "LOSE_WANTED_LEVEL", 3);
							}
							gameplay::clear_bit(&iParam0->f_13, 1);
						}
					}
					if (!ui::does_blip_exist(iParam0->f_5)) {
						if (ui::does_blip_exist(*iParam0)) {
							ui::remove_blip(iParam0);
						}
						iParam0->f_5 = func_5(vVar3, 0);
						if (iParam31 != -1) {
							ui::set_blip_sprite(iParam0->f_5, iParam31);
						}
						if (iParam35) {
							func_229(iParam0->f_5, iParam0);
						}
					}
					else if (!func_228(vVar3, ui::get_blip_coords(iParam0->f_5), 0.1f, 0)) {
						ui::set_blip_coords(iParam0->f_5, vVar3);
						if (iParam35) {
							func_229(iParam0->f_5, iParam0);
						}
					}
					if (!func_234(iParam0, 2)) {
						if (!gameplay::is_bit_set(iParam0->f_13, 2)) {
							func_232(iParam0, sParam19, 0);
							gameplay::set_bit(&iParam0->f_13, 2);
						}
					}
					if (iParam14 == 4 || iParam14 == 5) {
						if (gameplay::is_bit_set(iParam0->f_13, 13)) {
							iParam13 = 0;
						}
					}
					bVar1 = false;
					iVar6 = 0;
					iVar7 = 0;
					if (iParam14 == 1 || iParam14 == 3 || iParam14 == 5) {
						iVar6 = 1;
					}
					if (iParam14 == 2 || iParam14 == 3) {
						iVar7 = 1;
					}
					else if (iParam14 == 4 || iParam14 == 5) {
						iVar7 = 2;
					}
					if (iParam28) {
						entity::is_entity_at_coord(player::player_ped_id(), vParam1, vParam4, iParam13, iVar6, iVar7);
						if (entity::is_entity_in_angled_area(player::player_ped_id(), vParam7, vParam10, fParam36, 0,
															 iVar6, iVar7)) {
							bVar1 = true;
						}
					}
					else if (entity::is_entity_at_coord(player::player_ped_id(), vParam1, vParam4, iParam13, iVar6,
														iVar7)) {
						bVar1 = true;
					}
					if (bVar1) {
						bVar1 = true;
						iVar2 = 0;
						while (iVar2 < 3) {
							if (!ped::is_ped_injured(iParam0->f_17[iVar2])) {
								if (iParam14 == 4 || iParam14 == 5) {
									iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
									if (!ped::is_ped_in_vehicle(iParam0->f_17[iVar2], iVar0, 0)) {
										bVar1 = false;
									}
								}
								else if (iParam18 != 0) {
									if (!ped::is_ped_in_vehicle(iParam0->f_17[iVar2], iParam18, 0)) {
										bVar1 = false;
									}
								}
								else if (!ped::is_ped_group_member(iParam0->f_17[iVar2], func_211()) ||
										 !func_226(iParam0->f_17[iVar2], 1)) {
									bVar1 = false;
								}
							}
							iVar2++;
						}
						if (bVar1) {
							if (func_223(iParam0)) {
								func_239(sParam19);
								func_239(sParam24);
								func_239(sParam20);
								func_239(sParam21);
								func_239(sParam22);
								func_239(sParam23);
								func_239("LOSE_WANTED");
								func_239("MORE_SEATS");
								func_239(sParam27);
								func_210(iParam0, 1, 0);
								return 1;
							}
						}
					}
				}
			}
			else if (entity::does_entity_exist(iParam18)) {
				if (bParam26 && player::is_player_wanted_level_greater(player::player_id(), 0) &&
					!gameplay::is_bit_set(iParam0->f_13, 9) && !gameplay::is_bit_set(iParam0->f_13, 22)) {
					func_239(sParam24);
					func_239(sParam27);
					if (ui::does_blip_exist(iParam0->f_5) || ui::does_blip_exist(*iParam0)) {
						ui::remove_blip(&iParam0->f_5);
						ui::remove_blip(iParam0);
						func_239(sParam19);
					}
					if (!func_234(iParam0, 1) && !func_233(iParam0) && !gameplay::is_bit_set(iParam0->f_13, 0)) {
						if (bParam30) {
							func_232(iParam0, "LOSE_WANTED", 0);
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_230(iParam0->f_17[0], "VEHICLE_POLICE_PURSUIT", 3);
							}
						}
						gameplay::set_bit(&iParam0->f_13, 0);
						gameplay::clear_bit(&iParam0->f_13, 1);
					}
				}
				else {
					if (gameplay::is_bit_set(iParam0->f_13, 0)) {
						func_239("LOSE_WANTED");
						gameplay::clear_bit(&iParam0->f_13, 0);
						gameplay::set_bit(&iParam0->f_13, 1);
					}
					if (gameplay::is_bit_set(iParam0->f_13, 1)) {
						if (!func_234(iParam0, 1)) {
							if (!ped::is_ped_injured(iParam0->f_17[0])) {
								func_230(iParam0->f_17[0], "LOSE_WANTED_LEVEL", 3);
							}
							gameplay::clear_bit(&iParam0->f_13, 1);
						}
					}
					if (vehicle::is_vehicle_driveable(iParam18, 0)) {
						if (!ui::does_blip_exist(*iParam0)) {
							if (ui::does_blip_exist(iParam0->f_5)) {
								ui::remove_blip(&iParam0->f_5);
								func_239(sParam19);
							}
							*iParam0 = func_222(iParam18, 0, 0);
							ui::set_blip_display(*iParam0, 2);
							if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								func_229(*iParam0, iParam0);
							}
						}
						if (!func_234(iParam0, 2)) {
							if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
								func_232(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 3);
								gameplay::clear_bit(&iParam0->f_13, 4);
							}
							else if (gameplay::is_bit_set(iParam0->f_13, 9)) {
								if (!gameplay::is_string_null(sParam27)) {
									if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
										func_232(iParam0, sParam27, 0);
										gameplay::set_bit(&iParam0->f_13, 4);
									}
								}
								else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
									func_232(iParam0, sParam24, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
								if (!gameplay::is_bit_set(iParam0->f_13, 23)) {
									if (!ped::is_ped_injured(iParam0->f_17[0])) {
										func_230(iParam0->f_17[0], "GET_IN_CAR", 3);
									}
									gameplay::set_bit(&iParam0->f_13, 23);
								}
							}
						}
					}
				}
			}
			else {
				if (ui::does_blip_exist(iParam0->f_5)) {
					ui::remove_blip(&iParam0->f_5);
					func_239(sParam19);
				}
				if (iParam14 == 4 || iParam14 == 5) {
					if (iParam29 > 0) {
						if (!func_234(iParam0, 2)) {
							if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
								if (!gameplay::is_bit_set(iParam0->f_13, 13)) {
									iVar8 = 0;
									iVar9 = 0;
									iVar2 = 0;
									while (iVar2 < 3) {
										if (!ped::is_ped_injured(iParam0->f_17[iVar2])) {
											iVar8++;
										}
										iVar2++;
									}
									iVar9 = gameplay::get_random_int_in_range(0, iVar8);
									if (!ped::is_ped_injured(iParam0->f_17[iVar9])) {
										func_230(iParam0->f_17[iVar9], "NEED_A_BIGGER_VEHICLE", 3);
									}
									func_232(iParam0, "MORE_SEATS", 0);
									gameplay::set_bit(&iParam0->f_13, 13);
								}
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
								func_232(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 3);
								gameplay::clear_bit(&iParam0->f_13, 4);
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								if (gameplay::is_bit_set(iParam0->f_13, 9)) {
									func_232(iParam0, sParam27, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
							}
						}
					}
					else if (!func_234(iParam0, 2)) {
						if (!gameplay::is_bit_set(iParam0->f_13, 3)) {
							func_232(iParam0, sParam24, 0);
							gameplay::set_bit(&iParam0->f_13, 3);
							gameplay::clear_bit(&iParam0->f_13, 4);
						}
						else if (gameplay::is_bit_set(iParam0->f_13, 9)) {
							if (!gameplay::is_string_null(sParam27)) {
								if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
									func_232(iParam0, sParam27, 0);
									gameplay::set_bit(&iParam0->f_13, 4);
								}
							}
							else if (!gameplay::is_bit_set(iParam0->f_13, 4)) {
								func_232(iParam0, sParam24, 0);
								gameplay::set_bit(&iParam0->f_13, 4);
							}
						}
					}
				}
			}
		}
	}
	else {
		if (gameplay::is_bit_set(iParam0->f_13, 0)) {
			gameplay::clear_bit(&iParam0->f_13, 0);
		}
		func_239(sParam19);
		func_239(sParam24);
		func_239(sParam27);
		func_239(sParam24);
		func_239("LOSE_WANTED");
		if (ui::does_blip_exist(iParam0->f_5)) {
			ui::remove_blip(&iParam0->f_5);
		}
		if (ui::does_blip_exist(*iParam0)) {
			ui::remove_blip(iParam0);
		}
	}
	gameplay::clear_bit(&iParam0->f_13, 11);
	gameplay::clear_bit(&iParam0->f_13, 12);
	return 0;
}

// Position - 0x1B902
int func_222(int iParam0, int iParam1, int iParam2) { return func_14(iParam0, !iParam1, iParam2); }

// Position - 0x1B915
bool func_223(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_13, 12)) {
		if (func_225(player::player_ped_id())) {
			if (func_224(1, 0, 1) || gameplay::is_bit_set(uParam0->f_13, 7)) {
				return true;
			}
		}
	}
	else if (func_224(1, 0, 1) || gameplay::is_bit_set(uParam0->f_13, 7)) {
		return true;
	}
	return false;
}

// Position - 0x1B973
int func_224(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (gameplay::is_minigame_in_progress()) {
		return 0;
	}
	if (iParam0) {
		if (entity::is_entity_dead(player::player_ped_id(), 0)) {
			return 0;
		}
	}
	iVar0 = 0;
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
			return 0;
		}
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (iParam0) {
			if (entity::is_entity_dead(iVar0, 0)) {
				return 0;
			}
		}
		if (iParam2) {
			if (!entity::is_entity_dead(iVar0, 0)) {
				if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) != player::player_ped_id()) {
					return 0;
				}
			}
		}
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::get_entity_upright_value(iVar0) < 0.95f || entity::get_entity_upright_value(iVar0) > 1.011f) {
				return 0;
			}
		}
	}
	else if (iParam1) {
		return 0;
	}
	if (!player::is_player_ready_for_cutscene(player::player_id())) {
		return 0;
	}
	if (!player::can_player_start_mission(player::player_id())) {
		return 0;
	}
	return 1;
}

// Position - 0x1BA58
bool func_225(int iParam0) {
	float fVar0;

	if (!ped::is_ped_injured(iParam0)) {
		fVar0 = entity::get_entity_speed(iParam0);
		if (fVar0 > -0.5f && fVar0 < 0.5f) {
			return true;
		}
	}
	return false;
}

// Position - 0x1BA8F
int func_226(int iParam0, int iParam1) {
	if (!ped::is_ped_injured(iParam0)) {
		if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) && iParam1) {
			if (func_227(player::player_ped_id(), iParam0)) {
				ped::set_group_separation_range(func_211(), 50f);
				return 1;
			}
		}
		else if (ped::is_ped_group_member(iParam0, func_211())) {
			ped::set_group_separation_range(func_211(), 50f);
			return 1;
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0x1BAFA
bool func_227(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (ped::is_ped_sitting_in_any_vehicle(iParam0)) {
			iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (!ped::is_ped_injured(iParam1)) {
					if (ped::is_ped_sitting_in_vehicle(iParam1, iVar0)) {
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x1BB42
int func_228(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return 1;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1BBBD
void func_229(int iParam0, var *uParam1) {
	if (ui::does_blip_exist(iParam0)) {
		if (ui::does_blip_exist(uParam1->f_6)) {
			ui::set_blip_route(uParam1->f_6, 0);
		}
		ui::_0x3DDA37128DD1ACA8(0);
		ui::_0x67EEDEA1B9BAFD94();
		uParam1->f_6 = iParam0;
		ui::set_blip_route(iParam0, 1);
	}
}

// Position - 0x1BBF8
void func_230(int iParam0, char *sParam1, int iParam2) {
	audio::_play_ambient_speech1(iParam0, sParam1, func_231(iParam2), 1);
}

// Position - 0x1BC0F
int func_231(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: return "SPEECH_PARAMS_STANDARD";

	case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

	case 2: return "SPEECH_PARAMS_BEAT";

	case 3: return "SPEECH_PARAMS_FORCE";

	case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

	case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

	case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

	case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

	case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

	case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

	case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

	case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

	case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

	case 13: return "SPEECH_PARAMS_MEGAPHONE";

	case 14: return "SPEECH_PARAMS_HELI";

	case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

	case 16: return "SPEECH_PARAMS_FORCE_HELI";

	case 17: return "SPEECH_PARAMS_INTERRUPT";

	case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

	case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

	case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

	case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

	case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

	case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

	case 24: return "SPEECH_PARAMS_ADD_BLIP";

	case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

	case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

	case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

	case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

	case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

	case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

	case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

	case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

	case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

	case 34: return "SPEECH_PARAMS_SHOUTED";

	case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

	case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

	default:
	}
	iVar0 = 0;
	return iVar0;
}

// Position - 0x1BE04
void func_232(var *uParam0, char *sParam1, int iParam2) {
	if (!iParam2) {
		if (!gameplay::is_string_null(sParam1)) {
			if (!gameplay::are_strings_equal(sParam1, "")) {
				func_150(sParam1, 7500, 1);
			}
		}
	}
	uParam0->f_10 = gameplay::get_game_timer();
}

// Position - 0x1BE3C
int func_233(int *iParam0) {
	if (!ped::is_ped_injured(iParam0->f_16)) {
		if (audio::is_ambient_speech_playing(iParam0->f_16)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1BE60
int func_234(int *iParam0, int iParam1) {
	if (iParam1 != 1 || ui::is_subtitle_preference_switched_on()) {
		if (ui::is_message_being_displayed()) {
			return 1;
		}
		if (func_236(iParam0)) {
			return 1;
		}
	}
	if (iParam1 != 2 || ui::is_subtitle_preference_switched_on()) {
		if (func_59() && !func_235()) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1BEB8
int func_235() {
	if (Global_16756 == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x1BECF
bool func_236(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar1 = gameplay::get_game_timer();
	iVar0 = iVar1 - uParam0->f_10;
	if (iVar0 < 35) {
		return true;
	}
	return false;
}

// Position - 0x1BEF2
bool func_237(var *uParam0, int iParam1) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (func_238(iVar0, uParam0, iParam1)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1BF23
bool func_238(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		iVar2 = 0;
		while (iVar2 < 3) {
			if (entity::does_entity_exist(uParam1->f_17[iVar2])) {
				iVar0++;
			}
			iVar2++;
		}
		iVar1 = vehicle::get_vehicle_max_number_of_passengers(iParam0);
		if (iParam2 > 0) {
			if (iVar1 >= iParam2) {
				if (iParam2 > 1) {
					if (!vehicle::_0xF7F203E31F96F6A1(iParam0, 1)) {
						return true;
					}
				}
				else {
					return true;
				}
			}
		}
		else if (iVar1 >= iVar0) {
			if (iVar0 > 1) {
				if (!vehicle::_0xF7F203E31F96F6A1(iParam0, 1)) {
					return true;
				}
			}
			else {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1BFB7
void func_239(char *sParam0) {
	if (!gameplay::is_string_null(sParam0)) {
		ui::clear_this_print(sParam0);
	}
}

// Position - 0x1BFCF
bool func_240(var *uParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, char *sParam7,
			  float fParam8, bool bParam9, int iParam10, int iParam11, int iParam12, var uParam13, var uParam14,
			  var uParam15, int iParam16, bool bParam17) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7[3];
	bool bVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	var uVar15[3];
	var uVar19[3];
	bool bVar23;
	int iVar24;
	int iVar25;
	int iVar26;
	int iVar27;
	vector3 vVar28;
	int iVar31;
	int iVar32;

	iVar4 = 0;
	uParam0->f_17[0] = uParam1;
	uParam0->f_17[1] = uParam2;
	uParam0->f_17[2] = uParam3;
	uParam0->f_16 = uParam1;
	uVar15[0] = uParam4;
	uVar15[1] = uParam5;
	uVar15[2] = uParam6;
	uVar19[0] = uParam13;
	uVar19[1] = uParam14;
	uVar19[2] = uParam15;
	iVar6 = 1;
	iVar1 = 0;
	iVar2 = 0;
	iVar3 = 0;
	iVar7[0] = 0;
	iVar7[1] = 0;
	iVar7[2] = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
			iVar3++;
		}
		if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
			if (!gameplay::is_bit_set(uParam0->f_13, 29) && !gameplay::is_bit_set(uParam0->f_13, 28)) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					ped::set_ped_using_action_mode(uParam0->f_17[iVar0], 1, -1, 0);
				}
				if (iVar0 == 2) {
					gameplay::set_bit(&uParam0->f_13, 28);
				}
			}
		}
		else if (!gameplay::is_bit_set(uParam0->f_13, 29) && gameplay::is_bit_set(uParam0->f_13, 28)) {
			if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
				ped::set_ped_using_action_mode(uParam0->f_17[iVar0], 0, -1, 0);
			}
			if (iVar0 == 2) {
				gameplay::clear_bit(&uParam0->f_13, 28);
			}
		}
		iVar0++;
	}
	if (iVar3 == 0) {
		return true;
	}
	if (gameplay::is_bit_set(uParam0->f_13, 26)) {
		bVar23 = false;
		if (!entity::does_entity_exist(uParam0->f_21)) {
			iVar25 = 64;
			iVar25 |= 65536;
			iVar25 |= 2048;
			iVar25 |= 1;
			iVar25 |= 2;
			iVar25 |= 4;
			iVar25 |= 32;
			iVar25 |= 16;
			iVar25 |= 8;
			iVar24 =
				vehicle::get_closest_vehicle(entity::get_entity_coords(player::player_ped_id(), 1), 50f, 0, iVar25);
			if (vehicle::is_vehicle_driveable(iVar24, 0)) {
				uParam0->f_21 = iVar24;
			}
		}
		if (vehicle::is_vehicle_driveable(uParam0->f_21, 0)) {
			if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
							   entity::get_entity_coords(uParam0->f_21, 1)) < 400f) {
				if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
					if (!player::is_player_wanted_level_greater(player::player_id(), 0) || !bParam17) {
						if (func_238(uParam0->f_21, uParam0, iVar3)) {
							iVar0 = 0;
							while (iVar0 < 3) {
								if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
									ped::set_ped_max_move_blend_ratio(uParam0->f_17[iVar0], 1f);
									if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
										ped::remove_ped_from_group(uParam0->f_17[iVar0]);
									}
									if (ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470) == 7 &&
										!func_255(uParam0->f_17[iVar0], uParam0->f_21)) {
										if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0])) {
											ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 1);
											ai::task_enter_vehicle(uParam0->f_17[iVar0], uParam0->f_21, 60000, iVar0,
																   1f, 1, 0);
											ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], iVar0);
										}
									}
								}
								iVar0++;
							}
							return true;
						}
						else {
							bVar23 = true;
						}
					}
					else {
						bVar23 = true;
					}
				}
				else {
					bVar23 = true;
				}
			}
			else {
				bVar23 = true;
			}
		}
		else {
			bVar23 = true;
		}
		if (bVar23) {
			gameplay::clear_bit(&uParam0->f_13, 26);
			iVar0 = 0;
			while (iVar0 < 3) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					if (!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0]) && !uParam0->f_15) {
						ai::clear_ped_tasks(uParam0->f_17[iVar0]);
					}
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
						if (func_253(uParam0, uParam0->f_17[iVar0], fParam8, 1)) {
							ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_211());
						}
					}
				}
				iVar0++;
			}
		}
	}
	if (!gameplay::is_bit_set(uParam0->f_13, 26)) {
		if (!func_252(uParam0) && ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) &&
			!entity::does_entity_exist(iParam10)) {
			iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			if (vehicle::is_vehicle_driveable(iVar13, 0)) {
				if (!gameplay::is_bit_set(uParam0->f_13, 13)) {
					if (iParam16 == 4 || iParam16 == 5) {
					}
					if (!func_234(uParam0, 2)) {
						iVar26 = 0;
						iVar27 = 0;
						iVar0 = 0;
						while (iVar0 < 3) {
							if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
								iVar26++;
							}
							iVar0++;
						}
						iVar27 = gameplay::get_random_int_in_range(0, iVar26);
						if (!ped::is_ped_injured(uParam0->f_17[iVar27])) {
							func_230(uParam0->f_17[iVar27], "NEED_A_BIGGER_VEHICLE", 3);
						}
						func_232(uParam0, "MORE_SEATS", 0);
						gameplay::set_bit(&uParam0->f_13, 13);
					}
				}
				iVar12 = 1;
			}
		}
		else {
			iVar12 = 0;
			gameplay::clear_bit(&uParam0->f_13, 13);
			func_239("MORE_SEATS");
		}
		if (!entity::does_entity_exist(iParam10)) {
			if (!ped::is_ped_injured(uParam0->f_17[0]) || !ped::is_ped_injured(uParam0->f_17[1]) ||
				!ped::is_ped_injured(uParam0->f_17[2])) {
				if (!gameplay::is_bit_set(uParam0->f_13, 31)) {
					if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id()) && !func_234(uParam0, 2)) {
						iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (func_251(iVar13, uParam0)) {
							func_232(uParam0, "CMN_VEHSUIT", 0);
							gameplay::set_bit(&uParam0->f_13, 31);
						}
					}
				}
				else if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
					gameplay::clear_bit(&uParam0->f_13, 31);
					func_239("CMN_VEHSUIT");
				}
			}
		}
		if (vehicle::is_vehicle_driveable(iParam10, 0)) {
			if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iParam10)) {
				if (controls::is_control_just_pressed(0, 75)) {
					gameplay::set_bit(&uParam0->f_13, 21);
				}
			}
			else if (gameplay::is_bit_set(uParam0->f_13, 21)) {
				gameplay::clear_bit(&uParam0->f_13, 21);
			}
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
						ped::set_ped_dies_in_water(uParam0->f_17[iVar0], 1);
					}
					else {
						ped::set_ped_dies_in_water(uParam0->f_17[iVar0], 0);
					}
					if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
						iVar13 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						if (vehicle::is_vehicle_driveable(iVar13, 0)) {
							if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
								if (!func_252(uParam0) && ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
									if (!func_250(uParam0->f_17[iVar0])) {
										ped::remove_ped_from_group(uParam0->f_17[iVar0]);
									}
								}
							}
						}
						if (iVar13 != iParam10 && !entity::is_entity_dead(iVar13, 0)) {
							if (ped::is_ped_sitting_in_vehicle(uParam0->f_17[iVar0], iVar13)) {
								if (entity::is_entity_in_water(iVar13) && !vehicle::is_vehicle_on_all_wheels(iVar13)) {
									vVar28 = {entity::get_entity_coords(iVar13, 1)};
									if (vVar28.z < -1f) {
										ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
									}
								}
							}
						}
					}
					bVar11 = true;
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
						if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
							iVar13 = ped::get_vehicle_ped_is_in(uParam0->f_17[iVar0], 0);
							if (!entity::is_entity_dead(iVar13, 0)) {
								if (vehicle::is_vehicle_driveable(iParam10, 0)) {
									if (iVar13 != iParam10) {
										if (!ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iVar13)) {
											if (entity::get_entity_speed(iVar13) > 5f) {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 4160);
											}
											else {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
											}
											bVar11 = false;
										}
									}
								}
								else {
									if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
										iVar31 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
									}
									if (vehicle::is_vehicle_driveable(iVar31, 0)) {
										if (iVar13 != iVar31) {
											if (entity::get_entity_speed(iVar13) > 5f) {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 4160);
											}
											else {
												ai::task_leave_vehicle(uParam0->f_17[iVar0], iVar13, 64);
											}
											bVar11 = false;
										}
									}
								}
							}
						}
					}
					if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
						iVar32 = ped::get_vehicle_ped_is_using(player::player_ped_id());
						if (entity::does_entity_exist(iVar32)) {
							if (func_238(iVar32, uParam0, 0)) {
								if (func_249(iVar0, uParam0) || !gameplay::is_bit_set(uParam0->f_13, 27)) {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], iVar0);
									func_212(iVar0, uParam0);
									iVar4++;
									if (iVar4 >= iVar3) {
										gameplay::set_bit(&uParam0->f_13, 27);
									}
								}
							}
							else if (!func_249(iVar0, uParam0)) {
								if (entity::get_entity_model(iVar32) == joaat("sentinel2")) {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], 4);
								}
								else {
									ped::set_ped_group_member_passenger_index(uParam0->f_17[iVar0], 2);
								}
								func_248(iVar0, uParam0);
							}
						}
					}
					if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211()) &&
						!func_247(uParam0->f_17[iVar0], iParam10) && !func_246(uParam0->f_17[iVar0], iParam10)) {
						if (func_253(uParam0, uParam0->f_17[iVar0], fParam8, iParam11)) {
							if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
								if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
									!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
									!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
									!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0])) {
									iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
									if (iVar14 == 7) {
										ai::clear_ped_tasks(uParam0->f_17[iVar0]);
									}
									ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_211());
									bVar11 = false;
								}
							}
						}
						if (bVar11) {
							if (!ui::does_blip_exist(uParam0->f_1[iVar0])) {
								uParam0->f_11 = gameplay::get_game_timer();
								uParam0->f_1[iVar0] = func_222(uParam0->f_17[iVar0], 0, 0);
								ui::set_blip_display(uParam0->f_1[iVar0], 2);
								if (bParam9) {
									func_229(uParam0->f_1[iVar0], uParam0);
								}
							}
						}
						iVar6 = 0;
					}
					else if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
						if (func_226(uParam0->f_17[iVar0], 1) || func_247(uParam0->f_17[iVar0], iParam10) || iParam12 ||
							vehicle::is_vehicle_driveable(iParam10, 0) &&
								!ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0)) {
							if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
								ui::remove_blip(&uParam0->f_1[iVar0]);
								func_239(uVar15[iVar0]);
							}
						}
						else {
							if (bParam9) {
								func_229(uParam0->f_1[iVar0], uParam0);
							}
							iVar6 = 0;
						}
					}
					else if (vehicle::is_vehicle_driveable(iParam10, 0)) {
						if (!ped::is_ped_sitting_in_vehicle(uParam0->f_17[iVar0], iParam10)) {
							if (entity::is_entity_at_entity(uParam0->f_17[iVar0], iParam10, 20f, 20f, 5f, 0, 1, 0) &&
								!gameplay::is_bit_set(uParam0->f_13, 11) &&
								!(bParam17 && player::is_player_wanted_level_greater(player::player_id(), 0) &&
								  !ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0))) {
								if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
									if (!ped::is_ped_in_vehicle(uParam0->f_17[iVar0], iParam10, 0)) {
										if (!func_226(uParam0->f_17[iVar0], 1)) {
											if (func_225(uParam0->f_17[iVar0])) {
												iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], 451360105);
												if (iVar14 == 7) {
													ai::task_leave_any_vehicle(uParam0->f_17[iVar0], 0, 0);
												}
											}
										}
									}
								}
								else {
									if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
										if (!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
											!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
											!ped::is_ped_getting_into_a_vehicle(uParam0->f_17[iVar0]) &&
											!fire::is_entity_on_fire(iParam10)) {
											ped::remove_ped_from_group(uParam0->f_17[iVar0]);
										}
									}
									iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
									if (iVar14 == 7 && !func_255(uParam0->f_17[iVar0], iParam10)) {
										if (!ped::is_ped_jumping_out_of_vehicle(uParam0->f_17[iVar0]) &&
											!ped::is_ped_jumping_out_of_vehicle(player::player_ped_id()) &&
											!func_245(uParam0->f_17[iVar0], 2f) &&
											!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
											!ai::is_ped_getting_up(uParam0->f_17[iVar0]) &&
											!fire::is_entity_on_fire(iParam10)) {
											ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 1);
											if (gameplay::is_bit_set(uParam0->f_13, 10)) {
												ped::set_ped_max_move_blend_ratio(uParam0->f_17[iVar0], 1f);
											}
											ai::task_enter_vehicle(uParam0->f_17[iVar0], iParam10, 60000, iVar0, 2f, 1,
																   0);
											ped::set_ped_get_out_upside_down_vehicle(uParam0->f_17[iVar0], 0);
										}
									}
									else if (ped::is_ped_in_vehicle(player::player_ped_id(), iParam10, 0)) {
										uParam0->f_1[iVar0] = func_222(uParam0->f_17[iVar0], 0, 0);
										ui::set_blip_display(uParam0->f_1[iVar0], 2);
										iVar6 = 0;
									}
								}
							}
							else if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
								if (func_253(uParam0, uParam0->f_17[iVar0], fParam8, iParam11)) {
									if (!ped::is_ped_ragdoll(uParam0->f_17[iVar0]) &&
										!ai::is_ped_getting_up(uParam0->f_17[iVar0])) {
										iVar14 = ai::get_script_task_status(uParam0->f_17[iVar0], -1794415470);
										if (iVar14 == 7) {
											ai::clear_ped_tasks(uParam0->f_17[iVar0]);
										}
										ped::set_blocking_of_non_temporary_events(uParam0->f_17[iVar0], 0);
										ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_211());
									}
								}
							}
						}
						else if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iParam10)) {
							if (!ped::is_ped_group_member(uParam0->f_17[iVar0], func_211())) {
								if (!gameplay::is_bit_set(uParam0->f_13, 21)) {
									ped::set_ped_as_group_member(uParam0->f_17[iVar0], func_211());
								}
							}
							else if (gameplay::is_bit_set(uParam0->f_13, 21)) {
								ped::remove_ped_from_group(uParam0->f_17[iVar0]);
								gameplay::set_bit(&uParam0->f_13, 21);
							}
						}
						else if (ped::is_ped_group_member(uParam0->f_17[iVar0], func_211()) &&
								 !fire::is_entity_on_fire(iParam10)) {
							ped::remove_ped_from_group(uParam0->f_17[iVar0]);
						}
					}
				}
				else if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
					ui::remove_blip(&uParam0->f_1[iVar0]);
					func_239(uVar15[iVar0]);
				}
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
				iVar7[iVar0] = 1;
				iVar1++;
			}
			iVar0++;
		}
		if (!func_234(uParam0, 2)) {
			if (iVar1 > 0) {
				iVar0 = 0;
				while (iVar0 < 3) {
					if (iVar7[iVar0]) {
						if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
							if (func_250(uParam0->f_17[iVar0]) ||
								entity::is_entity_at_entity(uParam0->f_17[iVar0], player::player_ped_id(), uParam0->f_8,
															uParam0->f_8, uParam0->f_8, 0, 1, 0)) {
								iVar1--;
								iVar7[iVar0] = 0;
							}
						}
					}
					else if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
						if (!entity::is_entity_at_entity(uParam0->f_17[iVar0], player::player_ped_id(),
														 uParam0->f_8 * 0.85f, uParam0->f_8 * 0.85f, uParam0->f_8, 0, 1,
														 0) &&
							!func_250(uParam0->f_17[iVar0])) {
						}
					}
					iVar0++;
				}
			}
			iVar5 = gameplay::get_game_timer();
			if (iVar5 - uParam0->f_11 > 1500 || iVar3 == 1) {
				if (iVar1 > 0) {
					if (uParam0->f_12 < iVar1) {
						if ((iVar1 == iVar3 || iVar2 + iVar1 == iVar3) && iVar3 > 1) {
							if (!gameplay::is_bit_set(uParam0->f_13, 5)) {
								func_232(uParam0, sParam7, 0);
								gameplay::set_bit(&uParam0->f_13, 5);
								uParam0->f_12 = iVar1;
							}
							else {
								uParam0->f_12 = iVar1;
							}
						}
						else {
							iVar0 = 0;
							while (iVar0 < 3) {
								if (iVar7[iVar0]) {
									if (!func_244(iVar0, uParam0)) {
										if (!gameplay::is_string_null(uVar19[iVar0])) {
											if (!gameplay::are_strings_equal(uVar19[iVar0], "")) {
												func_242(uParam0, uVar15[iVar0], uVar19[iVar0], 0);
												func_241(iVar0, uParam0);
												uParam0->f_12 = iVar1;
											}
										}
										if (!func_244(iVar0, uParam0)) {
											func_232(uParam0, uVar15[iVar0], 0);
											func_241(iVar0, uParam0);
											uParam0->f_12 = iVar1;
										}
									}
									else {
										uParam0->f_12 = iVar1;
									}
								}
								iVar0++;
							}
						}
					}
				}
				else {
					uParam0->f_12 = 0;
				}
			}
		}
		gameplay::clear_bit(&uParam0->f_13, 10);
		if (iVar6 && !iVar12) {
			iVar0 = 0;
			while (iVar0 < 3) {
				if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
					ui::remove_blip(&uParam0->f_1[iVar0]);
					func_239(uVar15[iVar0]);
				}
				iVar0++;
			}
			func_239("MORE_SEATS");
			return true;
		}
	}
	return false;
}

// Position - 0x1D045
void func_241(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::set_bit(&uParam1->f_13, 14); break;

	case 1: gameplay::set_bit(&uParam1->f_13, 15); break;

	case 2: gameplay::set_bit(&uParam1->f_13, 16); break;
	}
}

// Position - 0x1D08D
void func_242(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	if (!iParam3) {
		if (!gameplay::is_string_null(sParam1)) {
			if (!gameplay::are_strings_equal(sParam1, "")) {
				func_243(sParam1, sParam2, 7500, 1);
			}
		}
	}
	uParam0->f_10 = gameplay::get_game_timer();
}

// Position - 0x1D0C7
void func_243(char *sParam0, char *sParam1, int iParam2, int iParam3) {
	iParam3 = iParam3;
	ui::begin_text_command_print(sParam0);
	ui::add_text_component_substring_text_label(sParam1);
	ui::end_text_command_print(iParam2, 1);
}

// Position - 0x1D0E6
int func_244(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: return gameplay::is_bit_set(uParam1->f_13, 14);

	case 1: return gameplay::is_bit_set(uParam1->f_13, 15);

	case 2: return gameplay::is_bit_set(uParam1->f_13, 16);

	default:
	}
	return 0;
}

// Position - 0x1D12F
int func_245(int iParam0, float fParam1) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
		iVar0 = ped::get_vehicle_ped_is_in(iParam0, 0);
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::get_entity_speed(iVar0) > fParam1) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x1D166
int func_246(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (!ped::is_ped_group_member(iParam0, func_211())) {
			iVar0 = ped::set_exclusive_phone_relationships(iParam0);
			if (vehicle::is_vehicle_driveable(iParam1, 0)) {
				if (entity::is_entity_at_entity(iParam0, iParam1, 20f + 10f, 20f + 10f, 10f, 0, 1, 0)) {
					if (iVar0 == iParam1) {
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x1D1CD
int func_247(int iParam0, int iParam1) {
	if (!ped::is_ped_injured(iParam0)) {
		if (entity::does_entity_exist(iParam1)) {
			if (vehicle::is_vehicle_driveable(iParam1, 0)) {
				if (ped::is_ped_sitting_in_vehicle(iParam0, iParam1)) {
					return 1;
				}
			}
		}
	}
	return 0;
}

// Position - 0x1D202
void func_248(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::set_bit(&uParam1->f_13, 17); break;

	case 1: gameplay::set_bit(&uParam1->f_13, 18); break;

	case 2: gameplay::set_bit(&uParam1->f_13, 19); break;
	}
}

// Position - 0x1D24A
int func_249(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: return gameplay::is_bit_set(uParam1->f_13, 17);

	case 1: return gameplay::is_bit_set(uParam1->f_13, 18);

	case 2: return gameplay::is_bit_set(uParam1->f_13, 19);

	default:
	}
	return 0;
}

// Position - 0x1D293
int func_250(int iParam0) {
	int iVar0;
	int iVar1;

	if (player::is_player_playing(player::player_id())) {
		iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			if (!ped::is_ped_injured(iParam0)) {
				iVar1 = ped::get_vehicle_ped_is_using(iParam0);
				if (vehicle::is_vehicle_driveable(iVar1, 0)) {
					if (iVar0 == iVar1) {
						if (entity::is_entity_at_entity(player::player_ped_id(), iParam0, 20f, 20f, 20f, 0, 1, 0) &&
							entity::is_entity_at_entity(iParam0, iVar1, 20f, 20f, 20f, 0, 1, 0)) {
							return 1;
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x1D320
bool func_251(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (entity::get_entity_model(iParam0) == joaat("bus") || entity::get_entity_model(iParam0) == joaat("coach")) {
			iVar0 = 0;
			iVar1 = 0;
			iVar2 = 0;
			iVar2 = 0;
			while (iVar2 < 3) {
				if (!ped::is_ped_injured(uParam1->f_17[iVar2])) {
					iVar0++;
				}
				iVar2++;
			}
			iVar3 = vehicle::get_ped_in_vehicle_seat(iParam0, 0, 0);
			if (!ped::is_ped_injured(iVar3)) {
				if (iVar3 == uParam1->f_17[0] || iVar3 == uParam1->f_17[1] || iVar3 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			iVar4 = vehicle::get_ped_in_vehicle_seat(iParam0, 1, 0);
			if (!ped::is_ped_injured(iVar4)) {
				if (iVar4 == uParam1->f_17[0] || iVar4 == uParam1->f_17[1] || iVar4 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			iVar5 = vehicle::get_ped_in_vehicle_seat(iParam0, 2, 0);
			if (!ped::is_ped_injured(iVar5)) {
				if (iVar5 == uParam1->f_17[0] || iVar5 == uParam1->f_17[1] || iVar5 == uParam1->f_17[2]) {
					iVar1++;
				}
			}
			else {
				iVar1++;
			}
			if (iVar1 < iVar0) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1D480
bool func_252(var *uParam0) {
	int iVar0;

	if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		if (func_238(iVar0, uParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1D4AF
bool func_253(var *uParam0, int iParam1, float fParam2, int iParam3) {
	int iVar0;

	if (!ped::is_ped_injured(iParam1)) {
		if (ped::is_ped_sitting_in_any_vehicle(iParam1)) {
			iVar0 = ped::get_vehicle_ped_is_in(iParam1, 0);
			if (!entity::is_entity_dead(iVar0, 0)) {
				if (vehicle::is_vehicle_driveable(iVar0, 0)) {
					if (ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iVar0)) {
						if (func_252(uParam0)) {
							return true;
						}
					}
					else if (iParam3) {
						return true;
					}
				}
				else if (entity::is_entity_at_entity(player::player_ped_id(), iParam1, fParam2, fParam2, 3f, 0, 1, 0)) {
					return true;
				}
			}
		}
		else if (entity::is_entity_at_entity(player::player_ped_id(), iParam1, fParam2, fParam2, 3f, 0, 1, 0)) {
			if (!iParam3) {
				iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
				if (entity::does_entity_exist(iVar0)) {
					if (func_238(iVar0, uParam0, 0)) {
						if (vehicle::is_vehicle_driveable(iVar0, 0)) {
							if (func_254(iVar0)) {
								return true;
							}
						}
					}
				}
				else {
					return true;
				}
			}
			else {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1D58D
bool func_254(int iParam0) {
	float fVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		fVar0 = entity::get_entity_speed(iParam0);
		if (fVar0 > -0.5f && fVar0 < 0.5f) {
			return true;
		}
	}
	return false;
}

// Position - 0x1D5C5
int func_255(int iParam0, int iParam1) {
	int iVar0;

	if (!ped::is_ped_injured(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam1, 0)) {
			iVar0 = ped::get_vehicle_ped_is_using(iParam0);
			if (iVar0 == iParam1) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x1D5F5
void func_256() {
	int iVar0;
	int iVar1;

	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
		iVar0 = ped::set_exclusive_phone_relationships(player::player_ped_id());
		if (vehicle::is_vehicle_driveable(iVar0, 0)) {
			iVar1 = vehicle::get_ped_in_vehicle_seat(iVar0, 0, 0);
			if (!ped::is_ped_injured(iVar1)) {
				if (iVar1 != player::player_ped_id()) {
					if (entity::is_entity_a_mission_entity(iVar1)) {
						if (!ped::is_ped_headtracking_entity(iVar1, player::player_ped_id())) {
							ai::task_look_at_entity(iVar1, player::player_ped_id(), 2000, 2048, 2);
						}
					}
				}
			}
		}
	}
}

// Position - 0x1D662
void func_257(var *uParam0) {
	int iVar0;

	if (!gameplay::is_bit_set(uParam0->f_13, 25)) {
		if (player::is_player_playing(player::player_id())) {
			ped::set_ped_config_flag(player::player_ped_id(), 32, 0);
		}
		iVar0 = 0;
		while (iVar0 < 3) {
			if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
				if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 32, 0);
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 305, 1);
					ped::set_ped_config_flag(uParam0->f_17[iVar0], 268, 1);
					ped::set_ped_get_out_upside_down_vehicle(uParam0->f_17[iVar0], 0);
				}
			}
			iVar0++;
		}
		gameplay::set_bit(&uParam0->f_13, 25);
	}
}

// Position - 0x1D705
void func_258(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(uParam0->f_17[iVar0])) {
			if (!ped::is_ped_injured(uParam0->f_17[iVar0])) {
				if (ped::is_ped_sitting_in_any_vehicle(uParam0->f_17[iVar0])) {
					ped::set_ped_can_play_ambient_anims(uParam0->f_17[iVar0], 0);
					ped::set_ped_can_play_ambient_base_anims(uParam0->f_17[iVar0], 0);
				}
			}
		}
		iVar0++;
	}
	if (player::is_player_playing(player::player_id())) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
				ped::set_ped_can_play_ambient_anims(player::player_ped_id(), 0);
				ped::set_ped_can_play_ambient_base_anims(player::player_ped_id(), 0);
			}
		}
	}
}

// Position - 0x1D79B
Vector3 func_259() {
	vector3 vVar0;

	return vVar0;
}

// Position - 0x1D7A7
int func_260(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 19) {
		if (Local_2515[iVar0 /*6*/] == iParam0) {
			if (Local_2515[iVar0 /*6*/].f_1 == 1) {
				Local_2515[iVar0 /*6*/].f_2 = iParam1;
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1D7EB
void func_261() {
	int iVar0;
	int iVar1;

	ped::set_ped_density_multiplier_this_frame(0f);
	ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
	switch (iLocal_2512) {
	case 0:
		iLocal_2506 = player::get_players_last_vehicle();
		player::set_player_control(player::player_id(), 0, 0);
		if (func_204()) {
			streaming::request_anim_dict("MISSChinese2_crystalMazeMCS1_IG");
			streaming::request_model(joaat("ig_old_man2"));
			streaming::request_model(joaat("ig_old_man1a"));
			streaming::request_model(joaat("ig_janet"));
			streaming::request_model(joaat("ig_taocheng"));
			streaming::request_model(joaat("ig_taostranslator"));
			streaming::request_anim_dict("misschinese2_crystalmaze");
			streaming::request_anim_dict("missrampageintrooutro");
			ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
			func_186(1, 1, 1, 0);
			if (entity::does_entity_exist(Global_88321.f_9[0])) {
				Local_755[14 /*33*/] = Global_88321.f_9[2];
				Local_755[13 /*33*/] = Global_88321.f_9[1];
				Local_755[11 /*33*/] = Global_88321.f_9[4];
				Local_755[10 /*33*/] = Global_88321.f_9[3];
				Local_755[12 /*33*/] = Global_88321.f_9[0];
				entity::set_entity_as_mission_entity(Local_755[14 /*33*/], 1, 1);
				entity::set_entity_as_mission_entity(Local_755[13 /*33*/], 1, 1);
				entity::set_entity_as_mission_entity(Local_755[11 /*33*/], 1, 1);
				entity::set_entity_as_mission_entity(Local_755[10 /*33*/], 1, 1);
				entity::set_entity_as_mission_entity(Local_755[12 /*33*/], 1, 1);
				if (!ped::is_ped_injured(Local_755[13 /*33*/])) {
					cutscene::register_entity_for_cutscene(Local_755[13 /*33*/], "Old_Man1A", 0, joaat("ig_old_man1a"),
														   0);
				}
				if (!ped::is_ped_injured(Local_755[14 /*33*/])) {
					cutscene::register_entity_for_cutscene(Local_755[14 /*33*/], "Old_Man2", 0, joaat("ig_old_man2"),
														   0);
				}
				if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
					cutscene::register_entity_for_cutscene(Local_755[11 /*33*/], "tao", 0, joaat("ig_taocheng"), 0);
				}
				if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
					cutscene::register_entity_for_cutscene(Local_755[10 /*33*/], "Taos_Translator", 0,
														   joaat("ig_taostranslator"), 0);
				}
				if (!ped::is_ped_injured(Local_755[12 /*33*/])) {
					cutscene::register_entity_for_cutscene(Local_755[12 /*33*/], "Janet", 0, joaat("ig_janet"), 0);
				}
			}
			else {
				Local_755[13 /*33*/] =
					ped::create_ped(26, joaat("ig_old_man1a"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
				cutscene::register_entity_for_cutscene(Local_755[13 /*33*/], "Old_Man1A", 0, joaat("ig_old_man1a"), 0);
				Local_755[14 /*33*/] =
					ped::create_ped(26, joaat("ig_old_man2"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
				cutscene::register_entity_for_cutscene(Local_755[14 /*33*/], "Old_Man2", 0, joaat("ig_old_man2"), 0);
				if (entity::does_entity_exist(Local_755[11 /*33*/])) {
					if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
						cutscene::register_entity_for_cutscene(Local_755[11 /*33*/], "tao", 0, joaat("ig_taocheng"), 0);
					}
				}
				else {
					cutscene::register_entity_for_cutscene(Local_755[11 /*33*/], "tao", 2, joaat("ig_taocheng"), 0);
				}
				cutscene::register_entity_for_cutscene(Local_755[10 /*33*/], "Taos_Translator", 2,
													   joaat("ig_taostranslator"), 0);
				Local_755[12 /*33*/] = ped::create_ped(26, joaat("ig_janet"), 1987.231f, 3052.741f, 46.214f, 0f, 1, 1);
				cutscene::register_entity_for_cutscene(Local_755[12 /*33*/], "Janet", 0, joaat("ig_janet"), 0);
			}
			func_263();
			cutscene::start_cutscene(0);
			unk1::_0x48621C9FCA3EBD28(4);
			gameplay::clear_area_of_peds(1991.22f, 3054.884f, 50.27741f, 87f, 0);
			gameplay::clear_area_of_projectiles(1991.22f, 3054.884f, 50.27741f, 87f, 0);
			ped::add_scenario_blocking_area(Vector(50.27741f, 3054.884f, 1991.22f) - Vector(40f, 40f, 40f),
											Vector(50.27741f, 3054.884f, 1991.22f) + Vector(40f, 40f, 40f), 0, 1, 1, 1);
			ped::set_ped_non_creation_area(Vector(50.27741f, 3054.884f, 1991.22f) - Vector(40f, 40f, 40f),
										   Vector(50.27741f, 3054.884f, 1991.22f) + Vector(0f, 40f, 40f));
			func_32(0, 0);
			func_32(26, 0);
			iLocal_3689 = 0;
			iLocal_2512++;
		}
		break;

	case 1:
		if (cutscene::is_cutscene_playing()) {
			if (cam::is_screen_faded_out()) {
				cam::do_screen_fade_in(1000);
			}
			iLocal_2512++;
		}
		break;

	case 2:
		if (cutscene::is_cutscene_playing()) {
			if (iLocal_3689 == 0) {
				func_262(13);
				iLocal_3689++;
			}
		}
		if (!entity::does_entity_exist(Local_755[13 /*33*/])) {
			if (cutscene::can_set_exit_state_for_registered_entity("Old_Man1A", 0)) {
				Local_755[13 /*33*/] = entity::get_ped_index_from_entity_index(
					cutscene::get_entity_index_of_registered_entity("Old_Man1A", 0));
			}
		}
		if (!entity::does_entity_exist(Local_755[14 /*33*/])) {
			if (cutscene::can_set_exit_state_for_registered_entity("Old_Man2", 0)) {
				Local_755[14 /*33*/] = entity::get_ped_index_from_entity_index(
					cutscene::get_entity_index_of_registered_entity("Old_Man2", 0));
			}
		}
		if (!entity::does_entity_exist(Local_755[11 /*33*/])) {
			if (cutscene::can_set_exit_state_for_registered_entity("tao", 0)) {
				Local_755[11 /*33*/] =
					entity::get_ped_index_from_entity_index(cutscene::get_entity_index_of_registered_entity("tao", 0));
			}
		}
		if (!entity::does_entity_exist(Local_755[10 /*33*/])) {
			if (cutscene::can_set_exit_state_for_registered_entity("Taos_Translator", 0)) {
				Local_755[10 /*33*/] = entity::get_ped_index_from_entity_index(
					cutscene::get_entity_index_of_registered_entity("Taos_Translator", 0));
			}
		}
		if (!entity::does_entity_exist(Local_755[12 /*33*/])) {
			if (cutscene::can_set_exit_state_for_registered_entity("Janet", 0)) {
				Local_755[12 /*33*/] = entity::get_ped_index_from_entity_index(
					cutscene::get_entity_index_of_registered_entity("Janet", 0));
			}
		}
		if (cutscene::can_set_exit_state_for_registered_entity("tao", 0)) {
			if (!ped::is_ped_injured(Local_755[11 /*33*/])) {
				ped::set_ped_relationship_group_hash(Local_755[11 /*33*/], iLocal_1618);
				ped::set_ped_can_be_targetted(Local_755[11 /*33*/], 0);
				iVar0 = ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
				ai::task_synchronized_scene(Local_755[11 /*33*/], iVar0, "misschinese2_crystalmaze",
											"2int_Loop_A_TaoCheng", 1000f, -4f, 1, 16, 1148846080, 0);
			}
		}
		if (cutscene::can_set_exit_state_for_registered_entity("Taos_Translator", 0)) {
			if (!ped::is_ped_injured(Local_755[10 /*33*/])) {
				ped::set_ped_relationship_group_hash(Local_755[10 /*33*/], iLocal_1618);
				ped::set_ped_can_be_targetted(Local_755[10 /*33*/], 0);
				iVar1 = ped::create_synchronized_scene(1991.988f, 3054.51f, 46.215f, 0f, 0f, 50.76f, 2);
				ai::task_synchronized_scene(Local_755[10 /*33*/], iVar1, "misschinese2_crystalmaze",
											"2int_Loop_A_taotranslator", 1000f, -4f, 1, 16, 1148846080, 0);
			}
		}
		if (cutscene::can_set_exit_state_for_registered_entity("Trevor", 0)) {
			iLocal_2506 = player::get_players_last_vehicle();
			if (func_68(iLocal_2506) && func_67(iLocal_2506, 1995.202f, 3062.156f, 46.0491f, 1) < 5f) {
				ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2506, -1);
				ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
				vehicle::remove_vehicle_asset(entity::get_entity_model(iLocal_2506));
			}
			else if (streaming::has_anim_dict_loaded("missrampageintrooutro")) {
				entity::set_entity_coords(player::player_ped_id(), 1992.135f, 3057.467f, 46.06f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 325.4678f);
				ai::task_play_anim(player::player_ped_id(), "missrampageintrooutro", "trvram_6_1h_run_outro", 1000f,
								   -4f, -1, 0, 0.1f, 0, 0, 0);
				ped::_0x2208438012482A1A(player::player_ped_id(), 1, 0);
			}
			else {
				entity::set_entity_coords(player::player_ped_id(), 1992.919f, 3057.906f, 46.0567f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 337.2537f);
				ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 0, 0);
				ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
				ped::_0x2208438012482A1A(player::player_ped_id(), 1, 0);
			}
		}
		if (cutscene::can_set_exit_state_for_camera(0)) {
			graphics::_0xE3E2C1B4C59DBC77(6);
			func_186(0, 1, 1, 0);
			player::set_player_control(player::player_id(), 1, 0);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
			if (cam::is_screen_faded_out()) {
				streaming::load_scene(1992.135f, 3057.467f, 46.06f);
			}
			unk1::_0x81CBAE94390F9F89();
			unk1::_0x293220DA1B46CEBC(0f, 7f, 3);
			func_176(11);
		}
		break;
	}
}

// Position - 0x1DF60
void func_262(int iParam0) {
	if (Global_88746 != -1) {
		if (iParam0 == Global_88746) {
			Global_88750 = 1;
			return;
		}
	}
}

// Position - 0x1DF84
void func_263() {
	int iVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		entity::set_entity_proofs(player::player_ped_id(), 0, 0, 0, 0, 0, 0, 0, 0);
		ped::set_ped_config_flag(player::player_ped_id(), 157, 1);
		entity::set_entity_invincible(player::player_ped_id(), 0);
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89193[iVar0])) {
			if (!entity::is_entity_dead(Global_89193[iVar0], 0)) {
				entity::set_entity_proofs(Global_89193[iVar0], 0, 0, 0, 0, 0, 0, 0, 0);
				entity::set_entity_invincible(Global_89193[iVar0], 0);
			}
		}
		iVar0++;
	}
	if (Global_35781 != 0 && Global_35781 != 3 && Global_35781 != 2) {
		player::set_max_wanted_level(5);
		player::set_wanted_level_multiplier(1f);
	}
}

// Position - 0x1E037
void func_264() {
	int iVar0;

	switch (iLocal_2512) {
	case 0:
		ui::request_additional_text("FRMCHSE", 0);
		while (!ui::has_additional_text_loaded(0)) {
			func_28(27, 1);
		}
		func_56(&uLocal_2708, 0, player::player_ped_id(), "TREVOR", 0, 1);
		func_56(&uLocal_2708, 8, 0, "PED8", 0, 1);
		func_32(9, 1);
		func_32(29, 1);
		func_32(21, 1);
		func_350();
		fire::stop_fire_in_range(2442.69f, 4970.348f, 46.33f, 30f);
		gameplay::_set_weather_type_over_time("EXTRASUNNY", 120f);
		vLocal_2889[0 /*3*/] = {2428.47f, 4968.91f, 42.11f};
		vLocal_2889[1 /*3*/] = {2431.14f, 4972.06f, 42.19f};
		vLocal_2889[2 /*3*/] = {2433.05f, 4969.22f, 42.26f};
		vLocal_2889[3 /*3*/] = {2437.71f, 4968.13f, 42.45f};
		vLocal_2889[4 /*3*/] = {2436.12f, 4964.76f, 42.19f};
		vLocal_2889[5 /*3*/] = {2432.13f, 4961.97f, 41.35f};
		vLocal_2889[6 /*3*/] = {2430.07f, 4963.78f, 41.35f};
		vLocal_2889[7 /*3*/] = {2434f, 4963.04f, 41.53f};
		vLocal_2889[8 /*3*/] = {2435.637f, 4969.699f, 42.19639f};
		Local_444[0 /*5*/] = {2450.376f, 4955.83f, 43.9394f};
		Local_444[1 /*5*/] = {2449.815f, 4956.678f, 43.9894f};
		Local_444[2 /*5*/] = {2449.606f, 4957.675f, 44.0646f};
		Local_444[3 /*5*/] = {2449.739f, 4958.731f, 44.1544f};
		Local_444[4 /*5*/] = {2450.141f, 4959.745f, 44.2487f};
		Local_444[5 /*5*/] = {2450.685f, 4960.582f, 44.3219f};
		Local_444[6 /*5*/] = {2451.492f, 4961.333f, 44.4439f};
		Local_444[7 /*5*/] = {2452.174f, 4962.099f, 44.5787f};
		Local_444[8 /*5*/] = {2452.717f, 4962.906f, 44.9141f};
		Local_444[9 /*5*/] = {2453.35f, 4963.579f, 45.3558f};
		Local_444[10 /*5*/] = {2453.754f, 4964.565f, 45.5766f};
		Local_444[11 /*5*/] = {2453.226f, 4965.539f, 45.5766f};
		Local_444[12 /*5*/] = {2452.472f, 4966.293f, 45.5766f};
		Local_444[13 /*5*/] = {2451.869f, 4967.104f, 45.5766f};
		Local_444[14 /*5*/] = {2451.529f, 4968.083f, 45.5766f};
		Local_444[15 /*5*/] = {2452.327f, 4968.712f, 45.5766f};
		Local_444[16 /*5*/] = {2452.796f, 4969.643f, 45.8107f};
		Local_444[17 /*5*/] = {2453.261f, 4970.541f, 45.8106f};
		Local_444[18 /*5*/] = {2453.58f, 4971.548f, 45.8104f};
		Local_444[19 /*5*/] = {2452.808f, 4972.267f, 45.8306f};
		Local_444[20 /*5*/] = {2452.049f, 4972.928f, 45.8306f};
		Local_444[21 /*5*/] = {2451.241f, 4973.599f, 45.8306f};
		Local_444[22 /*5*/] = {2450.248f, 4973.889f, 45.8306f};
		Local_444[23 /*5*/] = {2449.207f, 4973.784f, 45.8105f};
		Local_444[24 /*5*/] = {2448.172f, 4973.814f, 45.8106f};
		Local_444[25 /*5*/] = {2447.153f, 4973.771f, 45.8106f};
		Local_444[26 /*5*/] = {2446.138f, 4973.724f, 45.8106f};
		Local_444[27 /*5*/] = {2445.128f, 4973.689f, 45.8106f};
		Local_444[28 /*5*/] = {2444.256f, 4973.056f, 45.8106f};
		Local_444[29 /*5*/] = {2443.669f, 4972.194f, 45.8106f};
		Local_444[30 /*5*/] = {2443.119f, 4971.275f, 45.8106f};
		Local_444[31 /*5*/] = {2442.661f, 4970.359f, 45.8106f};
		Local_444[32 /*5*/] = {2442.267f, 4969.425f, 45.8106f};
		Local_444[33 /*5*/] = {2441.708f, 4968.502f, 45.8306f};
		Local_444[34 /*5*/] = {2441.264f, 4967.534f, 45.8106f};
		Local_444[35 /*5*/] = {2440.873f, 4966.538f, 45.8106f};
		Local_444[36 /*5*/] = {2440.382f, 4965.634f, 45.8106f};
		Local_444[37 /*5*/] = {2439.71f, 4964.882f, 45.8106f};
		Local_444[38 /*5*/] = {2438.933f, 4964.146f, 45.8106f};
		Local_444[39 /*5*/] = {2438.166f, 4963.502f, 45.8106f};
		Local_444[40 /*5*/] = {2437.555f, 4962.709f, 45.8106f};
		Local_444[41 /*5*/] = {2436.901f, 4961.95f, 45.8106f};
		Local_444[42 /*5*/] = {2436.075f, 4961.257f, 45.8106f};
		Local_444[43 /*5*/] = {2435.08f, 4961.004f, 45.8118f};
		Local_444[44 /*5*/] = {2434.066f, 4960.713f, 45.8181f};
		Local_444[45 /*5*/] = {2433.045f, 4960.594f, 45.8192f};
		Local_444[46 /*5*/] = {2432.065f, 4960.25f, 45.813f};
		Local_444[47 /*5*/] = {2431.233f, 4960.809f, 45.8089f};
		Local_444[48 /*5*/] = {2430.575f, 4961.574f, 45.5917f};
		Local_444[49 /*5*/] = {2429.889f, 4962.028f, 44.9345f};
		Local_444[50 /*5*/] = {2429.26f, 4962.595f, 44.2774f};
		Local_444[51 /*5*/] = {2428.691f, 4963.279f, 43.6202f};
		Local_444[52 /*5*/] = {2428.073f, 4963.911f, 42.9631f};
		Local_444[53 /*5*/] = {2428.239f, 4964.922f, 42.9631f};
		Local_444[54 /*5*/] = {2428.961f, 4965.455f, 42.3059f};
		Local_444[55 /*5*/] = {2429.45f, 4966.224f, 41.8679f};
		Local_444[56 /*5*/] = {2430.073f, 4966.82f, 41.3476f};
		Local_444[57 /*5*/] = {2431.097f, 4967.043f, 41.3476f};
		Local_444[58 /*5*/] = {2431.89f, 4966.403f, 41.3476f};
		Local_444[59 /*5*/] = {2432.768f, 4965.902f, 41.3476f};
		Local_444[60 /*5*/] = {2433.776f, 4965.613f, 41.3476f};
		Local_2343[0 /*6*/].f_3 = "Table Flames";
		Local_2343[0 /*6*/] = 0;
		Local_2343[1 /*6*/].f_3 = "Table Explosion";
		Local_2343[1 /*6*/] = 0;
		Local_2343[2 /*6*/].f_3 = "House Explosion";
		Local_2343[2 /*6*/] = 0;
		Local_2343[3 /*6*/].f_3 = "Cam Shake";
		Local_2343[3 /*6*/] = 0;
		Local_2343[4 /*6*/].f_3 = "Position player";
		Local_2343[4 /*6*/] = 0;
		Local_2343[5 /*6*/].f_3 = "Slow mo";
		Local_2343[5 /*6*/] = 0;
		Local_2343[0 /*6*/].f_1 = 2;
		Local_2343[0 /*6*/].f_2 = 1000f;
		Local_2343[1 /*6*/].f_1 = 2;
		Local_2343[1 /*6*/].f_2 = 4200f;
		Local_2343[2 /*6*/].f_1 = 3;
		Local_2343[2 /*6*/].f_2 = 0f;
		Local_2343[3 /*6*/].f_1 = 3;
		Local_2343[3 /*6*/].f_2 = 0f;
		Local_2343[4 /*6*/].f_1 = 3;
		Local_2343[4 /*6*/].f_2 = 3200f;
		Local_2343[5 /*6*/].f_1 = 3;
		Local_2343[5 /*6*/].f_2 = 700f;
		Local_2380[0 /*18*/] = {2454.83f, 4974.96f, 46.4489f};
		Local_2380[0 /*18*/].f_3 = {2.9627f, 0.077f, 115.874f};
		Local_2380[0 /*18*/].f_14 = 39.703f;
		Local_2380[0 /*18*/].f_6 = {2454.41f, 4974.93f, 46.4691f};
		Local_2380[0 /*18*/].f_9 = {2.6238f, 0.077f, 114.001f};
		Local_2380[0 /*18*/].f_15 = 39.703f;
		Local_2380[0 /*18*/].f_12 = 2500f;
		Local_2380[0 /*18*/].f_13 = 2500f;
		Local_2380[0 /*18*/].f_16 = 0;
		Local_2380[0 /*18*/].f_17 = 18;
		Local_2380[1 /*18*/] = {2435.41f, 4960.94f, 45.9568f};
		Local_2380[1 /*18*/].f_3 = {6.677f, 0f, -49.4853f};
		Local_2380[1 /*18*/].f_14 = 58.9114f;
		Local_2380[1 /*18*/].f_6 = {2435.11f, 4960.62f, 45.9441f};
		Local_2380[1 /*18*/].f_9 = {6.3596f, 0f, -44.8248f};
		Local_2380[1 /*18*/].f_15 = 58.9114f;
		Local_2380[1 /*18*/].f_12 = 3200f;
		Local_2380[1 /*18*/].f_13 = 1900f;
		Local_2380[1 /*18*/].f_16 = 0;
		Local_2380[1 /*18*/].f_17 = 34;
		Local_2380[2 /*18*/] = {2434.77f, 4969.56f, 42.3654f};
		Local_2380[2 /*18*/].f_3 = {5.2773f, -0.1511f, 132.167f};
		Local_2380[2 /*18*/].f_14 = 35.1297f;
		Local_2380[2 /*18*/].f_6 = {2434.66f, 4969.68f, 42.3657f};
		Local_2380[2 /*18*/].f_9 = {5.2773f, -0.1511f, 132.167f};
		Local_2380[2 /*18*/].f_15 = 35.1297f;
		Local_2380[2 /*18*/].f_12 = 3500f;
		Local_2380[2 /*18*/].f_13 = 4500f;
		Local_2380[2 /*18*/].f_16 = 3;
		Local_2380[2 /*18*/].f_17 = 49;
		Local_2380[3 /*18*/] = {2472.1f, 4943.1f, 45.3f};
		Local_2380[3 /*18*/].f_3 = {6f, 0f, 25.3f};
		Local_2380[3 /*18*/].f_14 = 33.1297f;
		Local_2380[3 /*18*/].f_6 = {2472.1f, 4943.1f, 45.3f};
		Local_2380[3 /*18*/].f_9 = {5.5f, 0f, 35.6f};
		Local_2380[3 /*18*/].f_15 = 33.1297f;
		Local_2380[3 /*18*/].f_12 = 3500f;
		Local_2380[3 /*18*/].f_13 = 3500f;
		Local_2380[3 /*18*/].f_16 = 0;
		Local_2380[3 /*18*/].f_17 = -1;
		fLocal_2639 = 0.06f;
		func_166(1);
		vLocal_2465[0 /*3*/] = {2432.74f, 4963.43f, 41.35f};
		vLocal_2465[1 /*3*/] = {2432.02f, 4962.61f, 41.35f};
		vLocal_2465[2 /*3*/] = {2431.06f, 4961.83f, 41.35f};
		vLocal_2465[3 /*3*/] = {2430.84f, 4961.08f, 42.09f};
		vLocal_2465[4 /*3*/] = {2430.53f, 4962.47f, 42f};
		vLocal_2465[5 /*3*/] = {2430.81f, 4961.1f, 42.8f};
		vLocal_2465[6 /*3*/] = {2429.74f, 4961.98f, 42.32f};
		vLocal_2465[7 /*3*/] = {2433.5f, 4966.76f, 41.35f};
		vLocal_2465[8 /*3*/] = {2433.24f, 4967.42f, 41.35f};
		vLocal_2465[9 /*3*/] = {2433.15f, 4967.43f, 42.19f};
		vLocal_2465[10 /*3*/] = {2432.53f, 4967.89f, 42.4f};
		vLocal_2465[11 /*3*/] = {2432.48f, 4969.07f, 42.19f};
		vLocal_2465[12 /*3*/] = {2433.36f, 4969.44f, 42.31f};
		vLocal_2274[0 /*3*/] = {2552.692f, 4978.566f, 45.32309f};
		vLocal_2274[1 /*3*/] = {2562.534f, 5013.502f, 47.46302f};
		vLocal_2274[2 /*3*/] = {2553.885f, 4945.661f, 47.49305f};
		vLocal_2274[3 /*3*/] = {2515.545f, 4936.428f, 42.88382f};
		vLocal_2274[4 /*3*/] = {2497.318f, 4967.818f, 43.59557f};
		vLocal_2274[5 /*3*/] = {2481.376f, 4951.766f, 43.99859f};
		vLocal_2274[6 /*3*/] = {2522.044f, 4956.372f, 43.71605f};
		vLocal_2274[7 /*3*/] = {2529.048f, 4985.627f, 43.86848f};
		vLocal_2274[8 /*3*/] = {2502.503f, 4987.245f, 46.62669f};
		vLocal_2274[9 /*3*/] = {2464.891f, 4939.949f, 44.25646f};
		vLocal_2274[10 /*3*/] = {2447.16f, 4940.272f, 44.15766f};
		vLocal_2274[11 /*3*/] = {2376.537f, 4946.399f, 41.77232f};
		vLocal_2274[12 /*3*/] = {2395.232f, 4995.63f, 44.68909f};
		vLocal_2274[13 /*3*/] = {2419.819f, 4991.936f, 45.36976f};
		vLocal_2274[14 /*3*/] = {2436.319f, 5011.725f, 45.84694f};
		vLocal_2274[15 /*3*/] = {2407.765f, 5023.079f, 47.77091f};
		vLocal_2274[16 /*3*/] = {2479.016f, 5028.829f, 42.98806f};
		vLocal_2274[17 /*3*/] = {2434.704f, 5042.713f, 45.34462f};
		vLocal_2274[18 /*3*/] = {2513.93f, 5039.333f, 51.02121f};
		vLocal_2274[19 /*3*/] = {2477.882f, 4986.437f, 44.99511f};
		vLocal_2274[20 /*3*/] = {2450.058f, 5011.858f, 44.89032f};
		func_203(&Local_1619, &uLocal_2708, cLocal_2338, 12f, 2482.197f, 4975.367f, 44.7288f, 121f, 1);
		func_349(&vLocal_2244, "ONEILGUARD4", 5, "ONEILGUARD1");
		func_349(&vLocal_2247, "ONEILGUARD4", 5, "ONEILGUARD1");
		func_349(&vLocal_2259, "CHI2_nope", 8, "ONEILGUARD1");
		func_349(&vLocal_2250, "SEETREVOR", 3, "chin2goon1");
		func_349(&vLocal_2253, "CHI2_hear", 8, "ONEILGUARD1");
		func_349(&vLocal_2256, "CHI2_hear", 8, "ONEILGUARD1");
		func_349(&vLocal_2262, "ONEILGUARD3", 5, "ONEILGUARD1");
		func_349(&vLocal_2265, "ONEILGUARD2", 5, "ONEILGUARD1");
		func_349(&vLocal_2268, "ONEILGUARD4", 5, "ONEILGUARD1");
		func_349(&vLocal_2271, "GOON2TREV", 4, "CHIN2goon2");
		func_32(6, 1);
		func_32(25, 1);
		iLocal_2506 = vehicle::get_last_driven_vehicle();
		vehicle::set_vehicle_model_is_suppressed(joaat("bodhi2"), 1);
		ped::add_relationship_group("TAOGROUP", &iLocal_1618);
		ped::set_relationship_between_groups(1, iLocal_1618, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, iLocal_1618);
		func_17(0, -1);
		ai::set_scenario_group_enabled("Chinese2_Lunch", 0);
		ai::set_scenario_group_enabled("CHINESE2_HILLBILLIES", 0);
		if (func_348()) {
			iVar0 = func_347();
			if (Global_86001 == 1) {
				iVar0++;
			}
			switch (iVar0) {
			case 0:
				func_265(2, 1, 0);
				cam::do_screen_fade_in(1000);
				break;

			case 1:
				if (Global_86001 == 1) {
					func_265(3, 1, 0);
				}
				else {
					func_265(4, 1, 0);
					cam::do_screen_fade_in(1000);
				}
				break;

			case 2:
				func_265(6, 1, 0);
				cam::do_screen_fade_in(1000);
				break;

			case 3:
				func_265(7, 1, 0);
				cam::do_screen_fade_in(1000);
				break;

			case 4:
				if (Global_86001 == 1) {
					func_265(8, 1, 0);
				}
				else {
					func_265(9, 1, 0);
					cam::do_screen_fade_in(1000);
				}
				break;

			case 5:
				func_265(10, 1, 0);
				cam::do_screen_fade_in(1000);
				func_144();
				break;
			}
		}
		else if (func_141(0)) {
			func_265(1, 0, 1);
		}
		else {
			func_176(11);
		}
		break;
	}
}

// Position - 0x1F013
void func_265(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	func_342(3);
	func_32(6, 0);
	iLocal_2512 = 0;
	iLocal_2511 = iParam0;
	switch (iParam0) {
	case 0: break;

	case 1:
		streaming::request_model(joaat("ig_old_man2"));
		streaming::request_model(joaat("ig_old_man1a"));
		streaming::request_model(joaat("ig_janet"));
		streaming::request_model(joaat("ig_taocheng"));
		streaming::request_model(joaat("ig_taostranslator"));
		cutscene::request_cutscene("chinese_2_int", 8);
		while (!streaming::has_model_loaded(joaat("ig_old_man2")) ||
			   !streaming::has_model_loaded(joaat("ig_old_man1a")) || !streaming::has_model_loaded(joaat("ig_janet")) ||
			   !streaming::has_model_loaded(joaat("ig_taocheng")) ||
			   !streaming::has_model_loaded(joaat("ig_taostranslator")) || !cutscene::has_cutscene_loaded()) {
			func_28(323, 1);
		}
		while (!func_339(&Local_755[11 /*33*/], 21, 1985.666f, 3052.661f, 46.2151f, 0, 1)) {
			system::wait(0);
		}
		entity::set_entity_coords(player::player_ped_id(), 1992.878f, 3057.846f, 46.0568f, 1, 0, 0, 1);
		entity::set_entity_heading(player::player_ped_id(), 311f);
		ped::set_ped_component_variation(Local_755[11 /*33*/], 9, 1, 0, 0);
		break;

	case 2:
		if (iParam1) {
			func_338(1992.878f, 3057.846f, 46.0568f, 311f, 1, 0);
		}
		else {
			if (func_68(iLocal_2506)) {
				entity::set_entity_coords(iLocal_2506, 1994.387f, 3061.94f, 46.0491f, 1, 0, 0, 1);
				entity::set_entity_heading(iLocal_2506, 50.7724f);
			}
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
			streaming::load_scene(1992.878f, 3057.846f, 46.0568f);
		}
		ped::add_scenario_blocking_area(Vector(50.27741f, 3054.884f, 1991.22f) - Vector(40f, 40f, 40f),
										Vector(50.27741f, 3054.884f, 1991.22f) + Vector(40f, 40f, 40f), 0, 1, 1, 1);
		ped::set_ped_non_creation_area(Vector(50.27741f, 3054.884f, 1991.22f) - Vector(40f, 40f, 40f),
									   Vector(50.27741f, 3054.884f, 1991.22f) + Vector(0f, 40f, 40f));
		gameplay::clear_area(1984.997f, 3052.905f, 46.8556f, 10f, 1, 0, 0, 0);
		func_277(1, 0, iParam2);
		streaming::request_model(joaat("ig_taocheng"));
		streaming::request_model(joaat("ig_taostranslator"));
		streaming::request_model(joaat("ig_old_man1a"));
		streaming::request_model(joaat("ig_old_man2"));
		streaming::request_model(joaat("ig_janet"));
		streaming::request_anim_dict("misschinese2_crystalmaze");
		while (!streaming::has_model_loaded(joaat("ig_taocheng")) ||
			   !streaming::has_model_loaded(joaat("ig_taostranslator")) ||
			   !streaming::has_model_loaded(joaat("ig_old_man1a")) ||
			   !streaming::has_model_loaded(joaat("ig_old_man2")) || !streaming::has_model_loaded(joaat("ig_janet")) ||
			   !streaming::has_anim_dict_loaded("misschinese2_crystalmaze")) {
			func_28(3, 1);
		}
		if (!iParam1) {
			if (func_68(iLocal_2506)) {
				ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2506, -1);
				entity::set_entity_coords(iLocal_2506, 1994.387f, 3061.94f, 46.0491f, 1, 0, 0, 1);
				entity::set_entity_heading(iLocal_2506, 50.7724f);
			}
			else {
				entity::set_entity_coords(player::player_ped_id(), 1992.878f, 3057.846f, 46.0568f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 311f);
			}
		}
		func_28(85, 1);
		func_160(2, 41, 0, 0, 0, 1, 0, 1, 0, 1, 0);
		while (func_169(2, 41) != 900) {
			func_160(2, 41, 0, 0, 0, 1, 0, 1, 0, 1, 0);
			func_28(4, 1);
		}
		func_32(26, 0);
		if (iParam1) {
			if (func_68(iLocal_2506)) {
				func_274(iLocal_2506, -1, 1);
			}
			else {
				func_274(0, -1, 1);
			}
		}
		break;

	case 3:
		if (iParam1) {
			func_338(2574.049f, 4981.824f, 50.44f, 50f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2570.543f, 4982.002f, 50.6795f, 0, 1, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 98.21f);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
			streaming::load_scene(2458.508f, 4984.504f, 52.3461f);
			func_28(323, 1);
		}
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		player::set_wanted_level_multiplier(0f);
		func_277(0, 0, 0);
		streaming::prefetch_srl("chinese2_farmhouse_cutscene");
		func_28(34, 1);
		func_32(5, 0);
		while (func_30(5)) {
			func_3();
			func_28(5, 1);
		}
		while (!func_224(1, 0, 1)) {
			func_28(6, 1);
		}
		func_15("CHN2_MISSION_START", 1, "CHN2_EXPLODE");
		while (!func_2()) {
			func_28(7, 1);
		}
		while (!streaming::is_srl_loaded()) {
			func_28(878, 1);
		}
		if (iParam1) {
			func_274(0, -1, 1);
		}
		func_160(10, 5, 0, 0, 0, 1, 0, 1, 0, 1, 0);
		while (!func_147(10, 5)) {
			func_160(10, 5, 0, 0, 0, 1, 0, 1, 0, 1, 0);
			func_28(234, 1);
		}
		break;

	case 4:
		if (iParam1) {
			func_338(func_273(), func_272(), 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2570.543f, 4982.002f, 50.6795f, 0, 1, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 98.21f);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
			streaming::load_scene(2570.543f, 4982.002f, 50.6795f);
			func_28(323, 1);
		}
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		func_277(0, 1, 0);
		player::set_wanted_level_multiplier(0f);
		func_32(5, 0);
		while (func_30(5)) {
			func_3();
			func_28(8, 1);
		}
		iVar0 = func_271(2);
		if (iVar0 != 0 && iVar0 != joaat("weapon_unarmed")) {
			if (weapon::has_ped_got_weapon(player::player_ped_id(), iVar0, 0)) {
				weapon::set_current_ped_weapon(player::player_ped_id(), iVar0, 1);
			}
		}
		func_15("CHN2_MISSION_START", 1, "CHN2_EXPLODE");
		while (!func_2()) {
			func_28(9, 1);
		}
		if (iParam1) {
			if (entity::does_entity_exist(iLocal_2506) && vehicle::is_vehicle_driveable(iLocal_2506, 0) && func_270()) {
				func_274(iLocal_2506, -1, 1);
				if (vehicle::is_vehicle_driveable(iLocal_2506, 0)) {
					vehicle::set_vehicle_engine_on(iLocal_2506, 1, 1, 0);
					if (vehicle::is_this_model_a_plane(entity::get_entity_model(iLocal_2506))) {
						vehicle::set_vehicle_forward_speed(iLocal_2506, 15f);
					}
					if (vehicle::is_this_model_a_heli(entity::get_entity_model(iLocal_2506))) {
						vehicle::set_heli_blades_full_speed(iLocal_2506);
						entity::set_entity_velocity(iLocal_2506, 1f, 1f, 1f);
					}
				}
			}
			else {
				func_274(0, -1, 1);
			}
		}
		if (gameplay::get_distance_between_coords(func_273(), 2570.538f, 4982.031f, 50.6239f, 1) < 10f) {
			entity::set_entity_coords(player::player_ped_id(), 2570.538f, 4982.031f, 50.6239f, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 98f);
		}
		if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			func_268(player::player_ped_id(), entity::get_entity_coords(player::player_ped_id(), 1));
		}
		break;

	case 5:
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		entity::set_entity_coords(player::player_ped_id(), 2572.01f, 4981.678f, 50.6698f, 1, 0, 0, 1);
		entity::set_entity_heading(player::player_ped_id(), 90.3911f);
		cam::set_gameplay_cam_relative_heading(0f);
		cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		player::set_wanted_level_multiplier(0f);
		func_32(5, 0);
		func_166(1);
		while (func_30(5)) {
			func_3();
			func_28(10, 1);
		}
		func_277(0, 0, 0);
		func_15("CHN2_TO_HOUSE_RESTART", 0, "CHN2_EXPLODE");
		while (!func_2()) {
			func_28(11, 1);
		}
		func_267(0, 1, 1);
		cam::set_gameplay_cam_relative_heading(0f);
		cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
		break;

	case 6:
		if (iParam1) {
			func_338(2450.871f, 4960.999f, 44.3759f, 351f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2450.871f, 4960.999f, 44.3759f, 0, 1, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 351.3911f);
			streaming::load_scene(2432.982f, 4964.823f, 41.3476f);
			func_28(325, 1);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
		}
		func_277(0, 0, 0);
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		system::wait(1);
		func_32(5, 0);
		func_166(1);
		while (func_30(5)) {
			func_3();
			func_28(12, 1);
		}
		player::set_wanted_level_multiplier(0f);
		func_15("CHN2_ENTER_HOUSE_RESTART", 0, "CHN2_EXPLODE");
		while (!func_2()) {
			func_28(13, 1);
		}
		func_267(0, 1, 1);
		if (iParam1) {
			func_274(0, -1, 1);
		}
		if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			func_268(player::player_ped_id(), entity::get_entity_coords(player::player_ped_id(), 1));
		}
		break;

	case 7:
		if (iParam1) {
			func_338(2435.319f, 4966.153f, 41.3476f, 104.2964f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2435.319f, 4966.153f, 41.3476f, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 104.2964f);
			streaming::load_scene(2432.982f, 4964.823f, 41.3476f);
			system::wait(1);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
		}
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		func_166(1);
		func_277(0, 0, 0);
		entity::freeze_entity_position(player::player_ped_id(), 1);
		iLocal_2678 = interior::get_interior_at_coords(2432.982f, 4964.823f, 41.3476f);
		while (!interior::is_valid_interior(iLocal_2678)) {
			iLocal_2678 = interior::get_interior_at_coords(2432.982f, 4964.823f, 41.3476f);
			func_28(14, 1);
		}
		while (!interior::is_interior_ready(iLocal_2678)) {
			func_28(15, 1);
		}
		streaming::set_interior_active(iLocal_2678, 1);
		interior::unpin_interior(iLocal_2678);
		iLocal_2678 = 0;
		weapon::request_weapon_asset(joaat("weapon_petrolcan"), 31, 0);
		streaming::request_anim_dict("misschinese2_crystalmaze");
		while (!weapon::has_weapon_asset_loaded(joaat("weapon_petrolcan")) ||
			   !streaming::has_anim_dict_loaded("misschinese2_crystalmaze")) {
			func_28(16, 1);
		}
		func_32(11, 0);
		entity::freeze_entity_position(player::player_ped_id(), 0);
		func_32(5, 0);
		while (func_30(5)) {
			func_3();
			func_28(17, 1);
		}
		player::set_wanted_level_multiplier(0f);
		streaming::request_model(joaat("blazer"));
		while (!streaming::has_model_loaded(joaat("blazer"))) {
			func_28(18, 1);
		}
		func_266(0, 7, 1);
		weapon::give_weapon_to_ped(player::player_ped_id(), joaat("weapon_petrolcan"), 4500, 1, 1);
		func_163(0);
		func_15("CHN2_PETROL_RESTART", 0, "CHN2_EXPLODE");
		while (!func_2()) {
			func_28(19, 1);
		}
		if (iParam1) {
			func_274(0, -1, 1);
		}
		break;

	case 8:
		if (iParam1) {
			func_338(2453.124f, 4952.071f, 45.125f, 285f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2453.124f, 4952.071f, 45.125f, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 285.8625f);
			streaming::load_scene(2453.124f, 4952.071f, 45.125f);
			system::wait(1);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
		}
		func_277(0, 0, 0);
		if (!streaming::is_srl_loaded()) {
			streaming::prefetch_srl("chinese2_explosion_cutscene");
		}
		streaming::set_vehicle_population_budget(1);
		streaming::set_ped_population_budget(1);
		streaming::request_model(joaat("blazer"));
		while (!streaming::has_model_loaded(joaat("blazer"))) {
			func_28(20, 1);
		}
		iLocal_2508 = vehicle::create_vehicle(joaat("blazer"), 2478.587f, 4941.803f, 43.6736f, 227.2903f, 1, 1);
		vehicle::set_vehicle_on_ground_properly(iLocal_2508, 1084227584);
		iLocal_2678 = interior::get_interior_at_coords(2432.982f, 4964.823f, 41.3476f);
		while (!interior::is_valid_interior(iLocal_2678)) {
			iLocal_2678 = interior::get_interior_at_coords(2432.982f, 4964.823f, 41.3476f);
			func_28(21, 1);
		}
		while (!interior::is_interior_ready(iLocal_2678)) {
			func_28(22, 1);
		}
		iLocal_2648 = 3;
		streaming::set_interior_active(iLocal_2678, 1);
		interior::unpin_interior(iLocal_2678);
		iLocal_2678 = 0;
		while (!streaming::has_model_loaded(joaat("blazer")) || !streaming::is_srl_loaded()) {
			func_28(24, 1);
		}
		if (iParam1) {
			func_274(0, -1, 1);
		}
		while (!audio::load_stream("CHINESE2_FARMHOUSE_EXPLOSION_SHOOT_GASOLINE_MASTER", 0)) {
			func_28(23, 1);
		}
		break;

	case 9:
		if (iParam1) {
			func_338(2472.3f, 4948.181f, 44.0937f, 220f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2472.3f, 4948.181f, 44.0937f, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 220.8569f);
			streaming::load_scene(2453.124f, 4952.071f, 45.125f);
			system::wait(1);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
		}
		func_31(6, 0);
		streaming::set_vehicle_population_budget(3);
		streaming::set_ped_population_budget(3);
		streaming::request_model(joaat("blazer"));
		while (!streaming::has_model_loaded(joaat("blazer")) ||
			   !audio::request_script_audio_bank("FARMHOUSE_FIRE", 0, -1) ||
			   !audio::request_script_audio_bank("FARMHOUSE_FIRE_BG", 0, -1)) {
			func_28(25, 1);
		}
		iLocal_2508 = vehicle::create_vehicle(joaat("blazer"), 2478.587f, 4941.803f, 43.6736f, 227.2903f, 1, 1);
		vehicle::set_vehicle_on_ground_properly(iLocal_2508, 1084227584);
		func_277(0, 0, 0);
		streaming::load_scene(2453.124f, 4952.071f, 45.125f);
		func_19(50, 0, 0, 1, 0);
		func_19(51, 0, 0, 1, 0);
		func_19(52, 0, 0, 1, 0);
		func_19(53, 0, 0, 1, 0);
		func_19(54, 1, 0, 1, 0);
		func_19(55, 1, 0, 1, 0);
		uLocal_2672 = object::_get_des_object(2457.15f, 4968.79f, 48.677f, 45f, "DES_FarmHs");
		while (!object::_does_des_object_exist(uLocal_2672)) {
			func_28(161, 1);
		}
		object::_set_des_object_state(uLocal_2672, 9);
		entity::remove_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 965837842, 0);
		entity::remove_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 247384786, 0);
		entity::remove_model_hide(2457.15f, 4968.79f, 48.677f, 100f, -247908770, 0);
		if (iParam1) {
			func_274(0, -1, 1);
		}
		break;

	case 10:
		func_31(6, 0);
		if (iParam1) {
			func_338(2625.776f, 4802.217f, 32.5747f, 206f, 1, 0);
		}
		else {
			entity::set_entity_coords(player::player_ped_id(), 2625.776f, 4802.217f, 32.5747f, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), 206.4254f);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(-7f, 1065353216);
			streaming::load_scene(2625.776f, 4802.217f, 32.5747f);
		}
		streaming::set_vehicle_population_budget(3);
		streaming::set_ped_population_budget(3);
		object::_set_des_object_state(uLocal_2672, 9);
		func_19(50, 2, 0, 1, 0);
		func_19(51, 2, 0, 1, 0);
		func_19(52, 2, 0, 1, 0);
		func_19(53, 2, 0, 1, 0);
		func_19(54, 1, 0, 1, 0);
		func_19(55, 1, 0, 1, 0);
		if (iParam1) {
			func_274(0, -1, 1);
		}
		break;
	}
}

// Position - 0x1FF22
void func_266(int iParam0, int iParam1, int iParam2) {
	Local_3337[iParam0 /*4*/].f_1 = iParam2;
	Local_3337[iParam0 /*4*/] = iParam1;
}

// Position - 0x1FF3E
void func_267(int iParam0, int iParam1, int iParam2) {
	Local_3358[iParam0 /*7*/].f_1 = iParam2;
	Local_3358[iParam0 /*7*/] = iParam1;
}

// Position - 0x1FF5A
Vector3 func_268(int iParam0, vector3 vParam1) {
	var uVar0;

	vParam1.z += 0.15f;
	if (gameplay::get_ground_z_for_3d_coord(vParam1, &uVar0, 0)) {
		vParam1.z = uVar0;
	}
	if (func_269(iParam0)) {
		entity::set_entity_coords(iParam0, vParam1, 1, 0, 0, 1);
	}
	return vParam1;
}

// Position - 0x1FF9F
bool func_269(int iParam0) {
	if (!entity::does_entity_exist(iParam0)) {
		return false;
	}
	return !entity::is_entity_dead(iParam0, 0);
}

// Position - 0x1FFBD
bool func_270() { return Global_96040.f_2311.f_8; }

// Position - 0x1FFCE
var func_271(int iParam0) {
	if (Global_91528 > 0) {
		return Global_96040.f_21[iParam0];
	}
	return Global_93635.f_21[iParam0];
}

// Position - 0x1FFF8
float func_272() { return Global_96040.f_2305.f_3; }

// Position - 0x2000C
Vector3 func_273() { return Global_96040.f_2305; }

// Position - 0x2001D
void func_274(int iParam0, int iParam1, int iParam2) {
	if (func_348() && func_276()) {
		while (Global_91486 != 6) {
			system::wait(0);
		}
		gameplay::set_game_paused(0);
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::clear_ped_wetness(player::player_ped_id());
			}
		}
		if (iParam0 != 0) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (entity::does_entity_exist(iParam0)) {
					if (vehicle::is_vehicle_driveable(iParam0, 0)) {
						if (!ped::is_ped_in_vehicle(player::player_ped_id(), iParam0, 0)) {
							ped::set_ped_into_vehicle(player::player_ped_id(), iParam0, iParam1);
							cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
							cam::set_gameplay_cam_relative_heading(0f);
							system::wait(0);
						}
					}
				}
			}
		}
		if (iParam2 == 1) {
			if (player::is_player_playing(player::player_id())) {
				player::set_player_control(player::player_id(), 1, 0);
			}
		}
		graphics::_stop_all_screen_effects();
		func_275(0);
	}
}

// Position - 0x200E1
void func_275(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&Global_91491.f_20, 13);
	}
	else {
		gameplay::clear_bit(&Global_91491.f_20, 13);
	}
}

// Position - 0x2010A
var func_276() { return gameplay::is_bit_set(Global_91491.f_20, 13); }

// Position - 0x2011E
void func_277(int iParam0, int iParam1, int iParam2) {
	if (iParam0) {
		if (func_337()) {
			if (func_334(func_336(), 10f, 20f, 9f, 1)) {
				func_333();
				while (!func_332()) {
					func_28(54455, 1);
				}
				if (iParam2) {
					iLocal_2506 = func_331(1994.387f, 3061.94f, 46.0491f, 50f);
				}
				else {
					iLocal_2506 = func_331(0f, 0f, 0f, 0f);
				}
			}
		}
	}
	else if (func_330()) {
		func_328();
		while (!func_327()) {
			func_28(544, 1);
		}
		iLocal_2506 = func_278(0f, 0f, 0f, 0f);
	}
	if (iParam1) {
		if (func_270()) {
			if (vehicle::is_vehicle_driveable(iLocal_2506, 0)) {
				ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2506, -1);
			}
		}
	}
}

// Position - 0x201E2
int func_278(vector3 vParam0, float fParam3) { return func_279(&Global_96040.f_2311, vParam0, fParam3, 0); }

// Position - 0x201FC
int func_279(var *uParam0, vector3 vParam1, float fParam4, int iParam5) {
	int iVar0;
	vector3 vVar1;
	bool bVar4;
	var uVar5;
	int iVar8;

	if (func_326(uParam0)) {
		if (func_162(vParam1, 0f, 0f, 0f, 0)) {
			vParam1 = {*uParam0};
			fParam4 = uParam0->f_6;
		}
		if (uParam0->f_12.f_66 == joaat("monster") || uParam0->f_12.f_66 == joaat("marshall")) {
			if (object::is_point_in_angled_area(vParam1, -816.8716f, 185.6238f, 71.40275f, -807.4894f, 189.3762f,
												75.27323f, 6.5f, 0, 1)) {
				vParam1 = {-850.93f, 158.82f, 65.7f};
				fParam4 = 89.5f;
			}
		}
		if (func_325(uParam0)) {
			gameplay::clear_area(vParam1, 5f, 1, 0, 0, 0);
			func_324(vParam1, 5f, 0);
			iVar0 = vehicle::create_vehicle(uParam0->f_12.f_66, vParam1, fParam4, 1, 1);
			if (entity::does_entity_exist(iVar0)) {
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
				if (system::vdist2(vVar1, -1151.15f, -1530.32f, 7.48925f) <= 3f) {
					entity::set_entity_coords_no_offset(iVar0, vParam1, 0, 0, 1);
				}
				func_316(iVar0, &uParam0->f_12, 0, 1);
				bVar4 = true;
				if (vehicle::is_this_model_a_boat(uParam0->f_12.f_66) ||
					vehicle::_is_this_model_an_emergency_boat(uParam0->f_12.f_66)) {
					if (!water::test_probe_against_water(vParam1.x, vParam1.y, vParam1.z + 30f, vParam1.x, vParam1.y,
														 vParam1.z - 30f, &uVar5)) {
						bVar4 = false;
					}
				}
				if (bVar4) {
					vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
				}
				if (uParam0->f_7 == 1) {
					if (iParam5) {
						if (vehicle::is_this_model_a_car(entity::get_entity_model(iVar0))) {
							func_315(uParam0->f_11, 1);
						}
						else if (vehicle::is_this_model_a_bike(entity::get_entity_model(iVar0))) {
							func_315(uParam0->f_11, 2);
						}
					}
					vehicle::_0xAB04325045427AAE(iVar0, 0);
					vehicle::_0x428BACCDF5E26EAD(iVar0, 0);
					vehicle::set_vehicle_has_strong_axles(iVar0, 1);
					func_314(iVar0, uParam0->f_11);
				}
				else if (!func_312(iVar0, uParam0->f_3, uParam0->f_8) && uParam0->f_10 &&
						 gameplay::are_strings_equal(script::get_this_script_name(), "startup_positioning")) {
					iVar8 = func_311(iVar0);
					if (iVar8 == -1) {
						uParam0->f_10 = 0;
					}
					else {
						func_304(iVar8);
					}
				}
				if (Global_91491 != 13 && Global_91491 != 10 && Global_91491 != 11 && Global_91491 != 12) {
					if (gameplay::get_hash_key(&Global_91491.f_3) == Global_69519) {
						if (uParam0->f_12.f_66 == Global_101700.f_31389.f_69[21 /*78*/].f_66) {
							func_301(24, 0);
							func_304(24);
						}
					}
				}
				if (uParam0->f_9 == 1) {
					func_280(iVar0, uParam0->f_11);
				}
				streaming::set_model_as_no_longer_needed(uParam0->f_12.f_66);
				vVar1 = {entity::get_entity_coords(iVar0, 1)};
			}
			return iVar0;
		}
	}
	return iVar0;
}

// Position - 0x204AD
void func_280(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_285(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_281(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x206AF
void func_281(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_284(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_283(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_282(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0x2095B
int func_282(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0x20A0B
int func_283(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x20AE5
void func_284(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0x20B96
int func_285(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_72(iParam0, 0, 0) ||
		func_72(iParam0, 1, 0) || func_72(iParam0, 2, 0) || func_300(iParam0) != 145 || func_299(iParam0) ||
		func_298(iParam0) || func_297(iParam0) || func_296(iParam0) || !func_286(entity::get_entity_model(iParam0))) {
		if (func_298(iParam0)) {
		}
		if (func_298(iParam0)) {
		}
		if (func_72(iParam0, 0, 0)) {
		}
		if (func_72(iParam0, 1, 0)) {
		}
		if (func_72(iParam0, 2, 0)) {
		}
		if (func_300(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x20C73
int func_286(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_287(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x20E24
int func_287(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_295()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_294() && !func_293() && !func_292() && !func_291() && !func_295()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_292()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_290(iParam0)) {
			return 0;
		}
	}
	if (!func_288(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x20FB2
int func_288(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_289()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x2107E
int func_289() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x21092
int func_290(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x21DD5
int func_291() { return 0; }

// Position - 0x21DDE
int func_292() { return 1; }

// Position - 0x21DE7
int func_293() { return 1; }

// Position - 0x21DF0
int func_294() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x21E09
bool func_295() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x21EC4
int func_296(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_287(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x21F0A
int func_297(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x21F45
bool func_298(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x21FC1
int func_299(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x220A9
int func_300(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x2210C
void func_301(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_303(iParam0, 0)) {
			func_302(iParam0, 1, 0);
			func_302(iParam0, 2, 0);
			func_302(iParam0, 3, 0);
			func_302(iParam0, 4, 0);
			func_302(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_302(iParam0, 0, 0);
	}
}

// Position - 0x22169
void func_302(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0x221A4
int func_303(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x221C7
void func_304(int iParam0) {
	bool bVar0;

	if (iParam0 == -1) {
		return;
	}
	if (func_308(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			bVar0 = true;
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (vehicle::is_vehicle_driveable(Global_68531.f_139[iParam0], 0)) {
					if (ped::is_ped_in_vehicle(player::player_ped_id(), Global_68531.f_139[iParam0], 0)) {
						bVar0 = false;
					}
				}
			}
			if (bVar0) {
				entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
				vehicle::delete_vehicle(&Global_68531.f_139[iParam0]);
			}
		}
		Global_68531[iParam0] = 1;
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			if (iParam0 == 24 && func_303(iParam0, 0) && Global_69440.f_66 == 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] != 0 &&
				Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] > 3 &&
				(!func_306(0, Global_68531.f_555[0 /*21*/].f_12) || !func_306(1, Global_68531.f_555[0 /*21*/].f_12))) {
				func_305(&Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/], &Global_69440);
				Global_69518 = Global_101700.f_31389.f_5591;
			}
			func_301(iParam0, 0);
		}
	}
}

// Position - 0x22339
void func_305(var *uParam0, var *uParam1) {
	uParam1->f_66 = uParam0->f_66;
	*uParam1 = *uParam0;
	uParam1->f_1 = {uParam0->f_1};
	uParam1->f_5 = uParam0->f_5;
	uParam1->f_6 = uParam0->f_6;
	uParam1->f_7 = uParam0->f_7;
	uParam1->f_8 = uParam0->f_8;
	uParam1->f_9 = {uParam0->f_9};
	uParam1->f_59 = {uParam0->f_59};
	uParam1->f_62 = uParam0->f_62;
	uParam1->f_63 = uParam0->f_63;
	uParam1->f_64 = uParam0->f_64;
	uParam1->f_65 = uParam0->f_65;
	uParam1->f_77 = uParam0->f_77;
	uParam1->f_67 = uParam0->f_67;
	uParam1->f_69 = uParam0->f_69;
	uParam1->f_68 = uParam0->f_68;
	uParam1->f_71 = uParam0->f_71;
	uParam1->f_72 = uParam0->f_72;
	uParam1->f_73 = uParam0->f_73;
	uParam1->f_74 = uParam0->f_74;
	uParam1->f_75 = uParam0->f_75;
	uParam1->f_76 = uParam0->f_76;
}

// Position - 0x22405
int func_306(int iParam0, int iParam1) {
	int iVar0;

	switch (iParam1) {
	case 0: iVar0 = 0; break;

	case 1: iVar0 = 1; break;

	case 2: iVar0 = 2; break;
	}
	if (iParam0 < 0 || iParam0 >= func_307(&Global_101700.f_31389.f_5038[iVar0 /*157*/])) {
		return 0;
	}
	return func_287(Global_101700.f_31389.f_5038[iVar0 /*157*/][iParam0 /*78*/].f_66, 0);
}

// Position - 0x22477
int func_307(var *uParam0) { return *uParam0; }

// Position - 0x22482
bool func_308(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_309(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_309(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_309(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_309(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_309(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_309(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_309(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_309(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_309(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_295()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_295()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_162(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_162(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_162(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0x23B7A
int func_309(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_45(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_310(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x23BBC
void func_310(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0x23E18
int func_311(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0]) &&
			!entity::is_entity_dead(Global_68531.f_484[iVar0], 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[iVar0], 0)) {
			vehicle::get_vehicle_colours(iParam0, &iVar1, &iVar2);
			vehicle::get_vehicle_colours(Global_68531.f_484[iVar0], &iVar3, &iVar4);
			if (entity::get_entity_model(iParam0) == entity::get_entity_model(Global_68531.f_484[iVar0]) &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[iVar0]) &&
				iVar1 == iVar2 && iVar3 == iVar4) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x23EDB
int func_312(int iParam0, vector3 vParam1, bool bParam4) {
	int iVar0;
	var uVar1[3];
	int iVar5;
	int iVar6;

	iVar0 = entity::get_entity_model(iParam0);
	switch (iVar0) {
	case joaat("cargobob"):
		if (func_313(iParam0, Global_68531.f_139[38], 0)) {
			func_304(38);
			return 1;
		}
		break;

	case joaat("firetruk"):
		if (func_313(iParam0, Global_68531.f_139[43], 1)) {
			func_304(43);
			return 1;
		}
		break;

	case joaat("cuban800"):
		iVar5 = ped::get_ped_nearby_vehicles(player::player_ped_id(), &uVar1);
		iVar6 = 0;
		while (iVar6 <= iVar5 - 1) {
			if (func_313(iParam0, uVar1[iVar6], 1) &&
				func_228(entity::get_entity_coords(uVar1[iVar6], 1), 2136.133f, 4780.563f, 39.9702f, 5f, 0)) {
				if (!bParam4 || func_162(vParam1, 0f, 0f, 0f, 0) ||
					gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1),
														  entity::get_entity_coords(uVar1[iVar6], 1), 1) < 10f) {
					vehicle::delete_vehicle(&iParam0);
					return 1;
				}
				else {
					return 0;
				}
			}
			iVar6++;
		}
		break;

	case joaat("luxor2"):
		if (entity::does_entity_exist(Global_68531.f_484[14]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[14], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[14]) == joaat("luxor2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[14])) {
				func_304(14);
				return 1;
			}
		}
		break;

	case joaat("swift2"):
		if (entity::does_entity_exist(Global_68531.f_484[20]) && vehicle::is_vehicle_driveable(iParam0, 0) &&
			vehicle::is_vehicle_driveable(Global_68531.f_484[20], 0)) {
			if (entity::get_entity_model(Global_68531.f_484[20]) == joaat("swift2") &&
				vehicle::get_vehicle_livery(iParam0) == vehicle::get_vehicle_livery(Global_68531.f_484[20])) {
				func_304(20);
				return 1;
			}
		}
		break;
	}
	return 0;
}

// Position - 0x240E4
bool func_313(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam1) && !entity::is_entity_dead(iParam1, 0) &&
		vehicle::is_vehicle_driveable(iParam1, 0)) {
		if (iParam2) {
			vehicle::get_vehicle_colours(iParam0, &iVar0, &iVar1);
			vehicle::get_vehicle_colours(iParam1, &iVar2, &iVar3);
			if (iVar0 == iVar2 && iVar1 == iVar3) {
				return true;
			}
		}
		else {
			return true;
		}
	}
	return false;
}

// Position - 0x24145
void func_314(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (!entity::does_entity_exist(Global_89155[iVar0])) {
			Global_89155[iVar0] = iParam0;
			Global_89165[iVar0] = iParam1;
			Global_89175[iVar0] = entity::get_entity_model(iParam0);
			if (vehicle::is_this_model_a_car(Global_89175[iVar0])) {
				Global_89203[iParam1 /*3*/][0] = -1;
			}
			else {
				Global_89203[iParam1 /*3*/][1] = -1;
			}
			iVar0 = 9;
		}
		if (iVar0 == 8) {
		}
		iVar0++;
	}
}

// Position - 0x241C7
void func_315(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (iParam0 == 145 || Global_89165[iVar0] == iParam0) {
				if (iParam1 == 0 || entity::get_entity_model(Global_89155[iVar0]) == func_309(iParam0, iParam1)) {
					if (!ped::is_ped_in_vehicle(player::player_ped_id(), Global_89155[iVar0], 0)) {
						entity::set_entity_as_mission_entity(Global_89155[iVar0], 0, 1);
						vehicle::delete_vehicle(&Global_89155[iVar0]);
						Global_89165[iVar0] = 145;
					}
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x24265
void func_316(int iParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (gameplay::get_hash_key(&uParam1->f_1) != 0) {
			vehicle::set_vehicle_number_plate_text(iParam0, &uParam1->f_1);
		}
		if (*uParam1 >= 0 && *uParam1 < vehicle::get_number_of_vehicle_number_plates()) {
			vehicle::set_vehicle_number_plate_text_index(iParam0, *uParam1);
		}
		if (uParam1->f_66 == joaat("sovereign")) {
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 111;
		}
		else if (uParam1->f_66 == joaat("casco")) {
			iVar0 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_282(iVar0 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_282(iVar0 + 1));
			}
		}
		else if (uParam1->f_66 == joaat("sandking") || uParam1->f_66 == joaat("sandking2")) {
			iVar1 = 1;
			if (gameplay::is_bit_set(uParam1->f_77, func_282(iVar1 + 1))) {
			}
			else {
				gameplay::set_bit(&uParam1->f_77, func_282(iVar1 + 1));
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 13)) {
			vehicle::set_vehicle_custom_primary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_primary_colour(iParam0);
		}
		if (gameplay::is_bit_set(uParam1->f_77, 12)) {
			vehicle::set_vehicle_custom_secondary_colour(iParam0, uParam1->f_71, uParam1->f_72, uParam1->f_73);
		}
		else {
			vehicle::clear_vehicle_custom_secondary_colour(iParam0);
		}
		vehicle::set_vehicle_colours(iParam0, uParam1->f_5, uParam1->f_6);
		if (uParam1->f_7 < 0) {
			uParam1->f_7 = 0;
		}
		if (uParam1->f_8 < 0) {
			uParam1->f_8 = 0;
		}
		vehicle::set_vehicle_extra_colours(iParam0, uParam1->f_7, uParam1->f_8);
		if (gameplay::is_bit_set(uParam1->f_77, 15) || func_323(iParam0) ||
			uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0 && uParam1->f_9[20] > 0)
			&&func_322() {
				uParam1->f_62 = 0;
				uParam1->f_63 = 0;
				uParam1->f_64 = 0;
			}
		else if (uParam1->f_62 == 0 && uParam1->f_63 == 0 && uParam1->f_64 == 0) {
			uParam1->f_62 = 255;
			uParam1->f_63 = 255;
			uParam1->f_64 = 255;
		}
		vehicle::set_vehicle_tyre_smoke_color(iParam0, uParam1->f_62, uParam1->f_63, uParam1->f_64);
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			vehicle::set_vehicle_window_tint(iParam0, 0);
		}
		else {
			vehicle::set_vehicle_window_tint(iParam0, 0);
			vehicle::set_vehicle_window_tint(iParam0, uParam1->f_65);
		}
		vehicle::set_vehicle_tyres_can_burst(iParam0, !gameplay::is_bit_set(uParam1->f_77, 9));
		if (iParam2) {
			vehicle::set_vehicle_doors_locked(iParam0, uParam1->f_70);
		}
		vehicle::_set_vehicle_neon_lights_colour(iParam0, uParam1->f_74, uParam1->f_75, uParam1->f_76);
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 2, gameplay::is_bit_set(uParam1->f_77, 28));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 3, gameplay::is_bit_set(uParam1->f_77, 29));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 0, gameplay::is_bit_set(uParam1->f_77, 30));
		vehicle::_set_vehicle_neon_light_enabled(iParam0, 1, gameplay::is_bit_set(uParam1->f_77, 31));
		vehicle::set_vehicle_is_stolen(iParam0, gameplay::is_bit_set(uParam1->f_77, 10));
		if (vehicle::get_vehicle_livery_count(iParam0) > 1 && uParam1->f_67 >= 0) {
			vehicle::set_vehicle_livery(iParam0, uParam1->f_67);
		}
		if (uParam1->f_69 > -1 && uParam1->f_69 < 255) {
			if (!vehicle::is_this_model_a_bicycle(entity::get_entity_model(iParam0))) {
				if (vehicle::is_this_model_a_bike(entity::get_entity_model(iParam0))) {
					if (uParam1->f_69 == 6) {
						func_321(iParam0, uParam1->f_69);
					}
				}
				else {
					func_321(iParam0, uParam1->f_69);
				}
			}
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			if (uParam1->f_68 == 0 || uParam1->f_68 == 3 || uParam1->f_68 == 5) {
				vehicle::raise_convertible_roof(iParam0, 1);
			}
			else {
				vehicle::lower_convertible_roof(iParam0, 1);
			}
		}
		if (iParam3) {
			func_317(&iParam0, &uParam1->f_9, &uParam1->f_59);
		}
		if (!vehicle::is_this_model_a_heli(uParam1->f_66) && !vehicle::is_this_model_a_boat(uParam1->f_66)) {
			iVar2 = 0;
			while (iVar2 <= 11) {
				if (gameplay::is_bit_set(uParam1->f_77, func_282(iVar2 + 1))) {
					if (!vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
						vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 0);
					}
				}
				else if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar2 + 1)) {
					vehicle::set_vehicle_extra(iParam0, iVar2 + 1, 1);
				}
				iVar2++;
			}
		}
		if (entity::get_entity_model(iParam0) == joaat("sheava") ||
			entity::get_entity_model(iParam0) == joaat("omnis") || entity::get_entity_model(iParam0) == joaat("le7b")) {
			if (vehicle::get_vehicle_mod(iParam0, 0) == -1) {
				vehicle::set_vehicle_extra(iParam0, 1, 0);
			}
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (!gameplay::is_bit_set(uParam1->f_77, 23)) {
				if (gameplay::is_bit_set(uParam1->f_77, 22)) {
					vehicle::control_landing_gear(iParam0, 2);
				}
				else {
					vehicle::control_landing_gear(iParam0, 3);
				}
			}
			else {
				vehicle::control_landing_gear(iParam0, 4);
			}
		}
		if (gameplay::is_bit_set(uParam1->f_77, 27)) {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 1);
		}
		else {
			decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 0);
		}
	}
}

// Position - 0x24713
int func_317(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	vehicle::set_vehicle_mod_kit(*iParam0, 0);
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			vehicle::toggle_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] > 0);
		}
		else if (vehicle::get_vehicle_mod(*iParam0, iVar1) != (*uParam1)[iVar0] - 1) {
			vehicle::remove_vehicle_mod(*iParam0, iVar1);
			if ((*uParam1)[iVar0] > 0) {
				if (iVar0 == 23) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[0] > 0);
				}
				else if (iVar0 == 24) {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, (*uParam2)[1] > 0);
				}
				else {
					vehicle::set_vehicle_mod(*iParam0, iVar1, (*uParam1)[iVar0] - 1, 0);
				}
			}
		}
		iVar0++;
	}
	if (func_320(entity::get_entity_model(*iParam0), 1) &&
		vehicle::get_vehicle_mod(*iParam0, 24) != func_319(*iParam0, (*uParam1)[38] - 1)) {
		vehicle::set_vehicle_mod(*iParam0, 24, func_319(*iParam0, (*uParam1)[38] - 1), 0);
	}
	if (func_318(*iParam0)) {
		vehicle::set_vehicle_strong(*iParam0, 1);
		vehicle::set_vehicle_has_strong_axles(*iParam0, 1);
	}
	return 1;
}

// Position - 0x2488B
bool func_318(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	char cVar3[16];

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0) &&
		vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = 0;
		while (iVar0 < 49) {
			iVar1 = iVar0;
			if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			}
			else if (vehicle::get_vehicle_mod(iParam0, iVar1) != -1) {
				StringCopy(&cVar3,
						   vehicle::get_mod_text_label(iParam0, iVar1, vehicle::get_vehicle_mod(iParam0, iVar1)), 16);
				iVar2 = gameplay::get_hash_key(&cVar3);
				if (iVar2 != 0) {
					if (iVar2 == gameplay::get_hash_key("MNU_CAGE") || iVar2 == gameplay::get_hash_key("SABRE_CAG")) {
						return true;
					}
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x24967
int func_319(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	float fVar2;
	int iVar3;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		switch (entity::get_entity_model(iParam0)) {
		case joaat("tornado5"):
			switch (iParam1) {
			case 0: return 0;

			case 1: return 1;

			case 2: return 2;

			case 3: return 3;

			case 4: return 4;

			case 5: return 4;
			}
			break;

		case joaat("faction3"): return 3;
		}
		iVar0 = vehicle::get_num_vehicle_mods(iParam0, 38);
		iVar1 = vehicle::get_num_vehicle_mods(iParam0, 24);
		fVar2 = system::to_float(iParam1 + 1) / system::to_float(iVar0);
		iVar3 = system::floor(system::to_float(iVar1) * fVar2) - 1;
		if (iVar3 < 0) {
			iVar3 = 0;
		}
		if (iVar3 >= iVar0) {
			iVar3 = iVar0 - 1;
		}
		return iVar3;
	}
	return 0;
}

// Position - 0x24A4C
int func_320(int iParam0, int iParam1) {
	switch (iParam0) {
	case joaat("faction2"):
	case joaat("buccaneer2"):
	case joaat("chino2"):
	case joaat("moonbeam2"):
	case joaat("primo2"):
	case joaat("voodoo"): return 1;

	case joaat("sabregt2"):
		if (!Global_262145.f_12339) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("tornado5"):
		if (!Global_262145.f_12340) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("virgo2"):
		if (!Global_262145.f_12338) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("minivan2"):
		if (!Global_262145.f_12341) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("slamvan3"):
		if (!Global_262145.f_12343) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("faction3"):
		if (!Global_262145.f_12342) {
			return 0;
		}
		else {
			return 1;
		}
		break;

	case joaat("sultanrs"):
	case joaat("banshee2"):
		if ((iParam1 & 1) != 0) {
			return 0;
		}
		return 1;

	case joaat("comet3"):
		if (Global_262145.f_16780) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("diablous2"):
		if (Global_262145.f_16782) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("fcr2"):
		if (Global_262145.f_16786) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("elegy"):
		if (Global_262145.f_16783) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("nero2"):
		if (Global_262145.f_16790) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("italigtb2"):
		if (Global_262145.f_16788) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;

	case joaat("specter2"):
		if (Global_262145.f_16793) {
			if ((iParam1 & 1) != 0) {
				return 0;
			}
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x24C71
void func_321(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (vehicle::get_num_mod_kits(iParam0) > 0) {
		vehicle::set_vehicle_mod_kit(iParam0, 0);
		iVar0 = vehicle::get_vehicle_mod(iParam0, 24);
		iVar1 = vehicle::get_vehicle_mod_variation(iParam0, 24);
		vehicle::set_vehicle_wheel_type(iParam0, iParam1);
		if (entity::get_entity_model(iParam0) == joaat("tornado6")) {
			return;
		}
		if (iVar0 == -1) {
			vehicle::remove_vehicle_mod(iParam0, 24);
		}
		else {
			vehicle::set_vehicle_mod(iParam0, 24, iVar0, iVar1 == 1);
		}
	}
}

// Position - 0x24CD6
var func_322() { return dlc2::is_dlc_present(-1691188696); }

// Position - 0x24CE7
int func_323(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (decorator::decor_is_registered_as_type("MPBitset", 3)) {
				if (decorator::decor_exist_on(iParam0, "MPBitset")) {
					iVar0 = decorator::decor_get_int(iParam0, "MPBitset");
				}
				return gameplay::is_bit_set(iVar0, 4);
			}
		}
	}
	return 0;
}

// Position - 0x24D32
void func_324(vector3 vParam0, float fParam3, int iParam4) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (func_308(&Global_68531.f_555[0 /*21*/], iVar0)) {
			if (gameplay::get_distance_between_coords(vParam0, Global_68531.f_555[0 /*21*/], iParam4) <= fParam3) {
				func_304(iVar0);
			}
		}
		iVar0++;
	}
}

// Position - 0x24D82
bool func_325(var *uParam0) {
	if (func_326(uParam0)) {
		if (streaming::has_model_loaded(uParam0->f_12.f_66)) {
			return true;
		}
		else {
			return false;
		}
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x24DB7
bool func_326(var *uParam0) {
	if (uParam0->f_12.f_66 == 0) {
		return false;
	}
	if (!func_287(uParam0->f_12.f_66, 0)) {
		return false;
	}
	if (uParam0->f_12.f_66 == joaat("stunt") && func_228(*uParam0, 1694.62f, 3276.27f, 41.31f, 1056964608, 0)) {
		return false;
	}
	return true;
}

// Position - 0x24E16
bool func_327() { return func_325(&Global_96040.f_2311); }

// Position - 0x24E29
void func_328() { func_329(&Global_96040.f_2311); }

// Position - 0x24E3C
void func_329(var *uParam0) {
	if (func_326(uParam0)) {
		streaming::request_model(uParam0->f_12.f_66);
	}
}

// Position - 0x24E5A
bool func_330() { return func_326(&Global_96040.f_2311); }

// Position - 0x24E6D
int func_331(vector3 vParam0, float fParam3) { return func_279(&Global_93635.f_2311, vParam0, fParam3, 0); }

// Position - 0x24E87
int func_332() { return func_325(&Global_93635.f_2311); }

// Position - 0x24E9A
void func_333() { func_329(&Global_93635.f_2311); }

// Position - 0x24EAD
bool func_334(int iParam0, vector3 vParam1, int iParam4) {
	vector3 vVar0;
	vector3 vVar3;

	if (iParam0 == 0) {
		return false;
	}
	if (iParam4 == 1) {
		vParam1 = {func_335()};
	}
	gameplay::get_model_dimensions(iParam0, &vVar0, &vVar3);
	if (vVar3.x - vVar0.x > vParam1.x) {
		return false;
	}
	else if (vVar3.y - vVar0.y > vParam1.y) {
		return false;
	}
	else if (vVar3.z - vVar0.z > vParam1.z) {
		return false;
	}
	return true;
}

// Position - 0x24F17
Vector3 func_335() { return 2.55f, 5.665f, 2.55f; }

// Position - 0x24F2E
int func_336() { return Global_93635.f_2311.f_12.f_66; }

// Position - 0x24F41
bool func_337() { return func_326(&Global_93635.f_2311); }

// Position - 0x24F54
void func_338(vector3 vParam0, float fParam3, int iParam4, int iParam5) {
	if (func_348()) {
		gameplay::set_this_script_can_be_paused(0);
		gameplay::clear_bit(&Global_91491.f_20, 2);
		gameplay::set_game_paused(1);
		if (player::is_player_playing(player::player_id())) {
			player::set_player_control(player::player_id(), 0, 0);
		}
		Global_91487 = {vParam0};
		Global_91490 = fParam3;
		Global_91486 = 1;
		if (iParam4 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 14);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 14);
		}
		if (iParam5 == 1) {
			gameplay::set_bit(&Global_91491.f_20, 24);
		}
		else {
			gameplay::clear_bit(&Global_91491.f_20, 24);
		}
		func_275(1);
	}
}

// Position - 0x24FE9
int func_339(int iParam0, int iParam1, vector3 vParam2, float fParam5, int iParam6) {
	int iVar0;

	if (!func_45(iParam1)) {
		iVar0 = func_341(iParam1);
		streaming::request_model(iVar0);
		if (streaming::has_model_loaded(iVar0)) {
			if (entity::does_entity_exist(*uParam0)) {
				ped::delete_ped(uParam0);
			}
			*iParam0 = ped::create_ped(26, iVar0, vParam2, fParam5, 0, 0);
			ped::set_ped_default_component_variation(*iParam0);
			if (iVar0 == joaat("ig_lamardavis")) {
				if (ped::get_ped_drawable_variation(*iParam0, 3) == 0) {
					ped::set_ped_component_variation(*iParam0, 5, 2, 0, 0);
				}
			}
			func_340(*iParam0, iParam1);
			if (iParam6) {
				streaming::set_model_as_no_longer_needed(iVar0);
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x25077
int func_340(var uParam0, int iParam1) {
	int iVar0;

	iVar0 = 7;
	if (iParam1 == 19) {
		iVar0 = 3;
	}
	else if (iParam1 == 14) {
		iVar0 = 4;
	}
	else if (iParam1 == 17) {
		iVar0 = 5;
	}
	else {
		iVar0 = 7;
		return 0;
	}
	Global_87658[iVar0 - 3] = uParam0;
	return 1;
}

// Position - 0x250BD
int func_341(int iParam0) {
	if (!func_45(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x250E8
void func_342(int iParam0) {
	int iVar0;
	int iVar1;

	func_178();
	func_179();
	func_180();
	func_177();
	streaming::end_srl();
	streaming::set_vehicle_population_budget(3);
	streaming::set_ped_population_budget(3);
	iLocal_3491 = 0;
	iLocal_2649 = 0;
	iLocal_2645 = 0;
	iLocal_2512 = 0;
	iLocal_1614 = 0;
	iLocal_2646 = 0;
	iLocal_2879 = 0;
	iLocal_2880 = 0;
	while (cutscene::is_cutscene_active()) {
		if (cutscene::is_cutscene_playing()) {
			cutscene::stop_cutscene(1);
		}
		else {
			cutscene::remove_cutscene();
		}
		func_28(0, 0);
	}
	if (object::does_pickup_exist(uLocal_2650)) {
		object::remove_pickup(uLocal_2650);
	}
	iVar0 = 0;
	while (iVar0 < iLocal_2651) {
		if (object::does_pickup_exist(iLocal_2651[iVar0])) {
			object::remove_pickup(iLocal_2651[iVar0]);
		}
		iVar0++;
	}
	iLocal_3506 = 0;
	iLocal_3507 = 0;
	iLocal_3508 = 0;
	sLocal_3509 = "";
	sLocal_3510 = "";
	func_184();
	iLocal_63 = 0;
	iLocal_64 = 0;
	iLocal_65 = 0;
	player::set_special_ability_multiplier(1f);
	func_346();
	cam::render_script_cams(0, 0, 3000, 1, 0, 0);
	cam::destroy_all_cams(0);
	func_186(0, 1, 1, 0);
	func_28(32, 0);
	gameplay::set_time_scale(1f);
	ui::clear_prints();
	func_210(&Local_2683, 1, 0);
	func_66();
	func_64();
	ped::remove_scenario_blocking_areas();
	gameplay::_set_unk_map_flag(0);
	pathfind::set_roads_back_to_original(Vector(44.8113f, 4961.045f, 2469.985f) - Vector(100f, 100f, 100f),
										 Vector(44.8113f, 4961.045f, 2469.985f) + Vector(100f, 100f, 100f), 1);
	if (iParam0 == 0) {
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 965837842, 1);
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, 247384786, 1);
		entity::create_model_hide(2457.15f, 4968.79f, 48.677f, 100f, -247908770, 0);
		Global_33944 = 1;
	}
	audio::set_ambient_zone_list_state("AZL_CHN2_METH_LAB_FARM_FIRE", 0, 1);
	if (iParam0 != 3) {
		ai::set_scenario_group_enabled("Chinese2_Lunch", 1);
		ai::set_scenario_group_enabled("CHINESE2_HILLBILLIES", 0);
	}
	player::set_player_control(player::player_id(), 1, 0);
	if (iLocal_2884 != -1) {
		if (pathfind::does_navmesh_blocking_object_exist(iLocal_2884)) {
			pathfind::remove_navmesh_blocking_object(iLocal_2884);
		}
	}
	if (iParam0 == 1 || iParam0 == 2) {
		func_344(player::player_ped_id(), 2);
	}
	iVar0 = 0;
	while (iVar0 < Local_755) {
		if (iVar0 == 14) {
		}
		if (entity::does_entity_exist(Local_755[iVar0 /*33*/])) {
			if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
				if (iParam0 == 3) {
					ai::clear_ped_tasks_immediately(Local_755[iVar0 /*33*/]);
				}
			}
			if (iParam0 == 0 || iParam0 == 2) {
				if (iVar0 == 14) {
				}
				if (!ped::is_ped_injured(Local_755[iVar0 /*33*/])) {
					ped::set_ped_keep_task(Local_755[iVar0 /*33*/], 1);
					entity::set_ped_as_no_longer_needed(&Local_755[iVar0 /*33*/]);
				}
			}
			else {
				if (iVar0 == 14) {
				}
				ped::delete_ped(&Local_755[iVar0 /*33*/]);
			}
		}
		Local_755[iVar0 /*33*/].f_3 = 0;
		Local_755[iVar0 /*33*/].f_4 = 0;
		Local_755[iVar0 /*33*/].f_6 = {0f, 0f, 0f};
		Local_755[iVar0 /*33*/].f_9 = {0f, 0f, 0f};
		Local_755[iVar0 /*33*/].f_2 = 25;
		Local_755[iVar0 /*33*/].f_5 = 0;
		Local_755[iVar0 /*33*/].f_12 = 0f;
		Local_755[iVar0 /*33*/].f_13 = 0f;
		Local_755[iVar0 /*33*/].f_14 = 0;
		Local_755[iVar0 /*33*/].f_15 = 0;
		Local_755[iVar0 /*33*/].f_17 = 0;
		Local_755[iVar0 /*33*/].f_16 = 0;
		Local_755[iVar0 /*33*/].f_21 = 0;
		Local_755[iVar0 /*33*/].f_22 = 0;
		Local_1619[iVar0 /*24*/].f_3 = 1;
		if (entity::does_entity_exist(Local_755[iVar0 /*33*/].f_20)) {
			object::delete_object(&Local_755[iVar0 /*33*/].f_20);
		}
		ped::remove_relationship_group(Local_755[iVar0 /*33*/].f_24);
		iVar0++;
	}
	if (iParam0 != 3) {
		func_343();
	}
	else {
		func_203(&Local_1619, &uLocal_2708, cLocal_2338, 12f, 2482.197f, 4975.367f, 44.7288f, 121f, 1);
	}
	if (entity::does_entity_exist(iLocal_2878)) {
		object::delete_object(&iLocal_2878);
	}
	if (iParam0 != 0 && iParam0 != 2) {
		gameplay::clear_area(2438.433f, 4970.416f, 53.1778f, 450f, 1, 0, 0, 0);
		fire::stop_fire_in_range(2442.69f, 4970.348f, 46.33f, 30f);
	}
	iVar0 = 0;
	while (iVar0 < Local_2515) {
		if (Local_2515[iVar0 /*6*/].f_1 == 1 && Local_2515[iVar0 /*6*/].f_3 == 0 || Local_2515[iVar0 /*6*/].f_3 == 0) {
			Local_2515[iVar0 /*6*/].f_2 = -1;
			Local_2515[iVar0 /*6*/].f_4 = 0;
			Local_2515[iVar0 /*6*/].f_5 = 0;
			Local_2515[iVar0 /*6*/].f_1 = 0;
		}
		iVar0++;
	}
	func_3();
	if (ui::does_blip_exist(iLocal_2677)) {
		ui::remove_blip(&iLocal_2677);
	}
	iVar1 = 0;
	while (iVar1 < iLocal_2657) {
		if (entity::does_entity_exist(iLocal_2657[iVar1])) {
			object::delete_object(&iLocal_2657[iVar1]);
		}
		iVar1++;
	}
	if (entity::does_entity_exist(iLocal_2506)) {
		if (iParam0 != 0 && iParam0 != 2) {
			if (vehicle::is_vehicle_driveable(iLocal_2506, 0)) {
				if (entity::does_entity_belong_to_this_script(iLocal_2506, 1)) {
					if (ped::is_ped_injured(player::player_ped_id())) {
						entity::set_vehicle_as_no_longer_needed(&iLocal_2506);
					}
					else {
						entity::set_vehicle_as_no_longer_needed(&iLocal_2506);
					}
				}
			}
		}
	}
	if (entity::does_entity_exist(iLocal_2507)) {
		if (iParam0 != 0) {
			if (ped::is_ped_injured(player::player_ped_id())) {
				entity::set_vehicle_as_no_longer_needed(&iLocal_2507);
			}
			else {
				entity::set_vehicle_as_no_longer_needed(&iLocal_2507);
			}
		}
		else {
			entity::set_vehicle_as_no_longer_needed(&iLocal_2507);
		}
	}
	if (entity::does_entity_exist(iLocal_2508)) {
		if (func_68(iLocal_2508)) {
			entity::set_vehicle_as_no_longer_needed(&iLocal_2508);
		}
	}
	if (object::does_pickup_exist(uLocal_2675)) {
		object::remove_pickup(uLocal_2675);
	}
	if (iParam0 == 0) {
		if (entity::does_entity_exist(iLocal_2680)) {
			entity::freeze_entity_position(iLocal_2680, 0);
			entity::set_object_as_no_longer_needed(&iLocal_2680);
		}
		if (entity::does_entity_exist(iLocal_2681)) {
			entity::freeze_entity_position(iLocal_2681, 0);
			entity::set_object_as_no_longer_needed(&iLocal_2681);
		}
	}
	if (entity::does_entity_exist(iLocal_2642)) {
		ped::delete_ped(&iLocal_2642);
	}
	graphics::remove_decals_in_range(2439.687f, 4971.541f, 45.9442f, 150f);
	if (iParam0 != 2) {
		if (entity::does_entity_exist(Local_755[12 /*33*/])) {
			ped::delete_ped(&Local_755[12 /*33*/]);
		}
		if (entity::does_entity_exist(Local_755[13 /*33*/])) {
			ped::delete_ped(&Local_755[13 /*33*/]);
		}
		if (entity::does_entity_exist(Local_755[14 /*33*/])) {
			ped::delete_ped(&Local_755[14 /*33*/]);
		}
		if (entity::does_entity_exist(Local_755[11 /*33*/])) {
			ped::delete_ped(&Local_755[11 /*33*/]);
		}
		if (entity::does_entity_exist(Local_755[10 /*33*/])) {
			ped::delete_ped(&Local_755[10 /*33*/]);
		}
	}
	streaming::set_model_as_no_longer_needed(joaat("a_m_m_hillbilly_01"));
	streaming::set_model_as_no_longer_needed(joaat("a_m_m_hillbilly_02"));
	streaming::set_model_as_no_longer_needed(joaat("prop_cs_fertilizer"));
	streaming::set_model_as_no_longer_needed(joaat("burrito"));
	streaming::set_model_as_no_longer_needed(joaat("ig_janet"));
	streaming::set_model_as_no_longer_needed(joaat("ig_old_man1a"));
	streaming::set_model_as_no_longer_needed(joaat("ig_old_man2"));
	streaming::set_model_as_no_longer_needed(joaat("ig_taocheng"));
	streaming::set_model_as_no_longer_needed(joaat("ig_taostranslator"));
	streaming::set_model_as_no_longer_needed(joaat("ig_janet"));
	streaming::remove_anim_set("move_m@gangster@var_e");
	streaming::remove_anim_set("move_m@gangster@var_f");
	streaming::remove_anim_set("move_m@gangster@generic");
	streaming::remove_anim_dict("misschinese2_barrelRoll");
	streaming::remove_anim_dict("reaction@male_stand@big_variations@b");
	streaming::remove_anim_dict("reaction@male_stand@big_intro@left");
	streaming::remove_anim_dict("reaction@male_stand@big_intro@right");
	streaming::remove_anim_dict("reaction@male_stand@big_intro@backward");
	streaming::remove_anim_dict("misschinese2_bank1");
	streaming::remove_anim_dict("misschinese2_bank5");
	streaming::remove_anim_dict("misschinese2_crystalmazemcs1_ig");
	if (iParam0 != 3) {
		if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
			weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_petrolcan"));
		}
	}
	iLocal_2641 = 0;
	iLocal_751 = 0;
	if (audio::is_audio_scene_active("CHI_2_DRIVE_TO_FARMHOUSE")) {
		audio::stop_audio_scene("CHI_2_DRIVE_TO_FARMHOUSE");
	}
	if (audio::is_audio_scene_active("CHI_2_DRIVE_ROCK_RADIO")) {
		audio::stop_audio_scene("CHI_2_DRIVE_ROCK_RADIO");
	}
	if (audio::is_audio_scene_active("CHI_2_FARMHOUSE_OVERVIEW")) {
		audio::stop_audio_scene("CHI_2_FARMHOUSE_OVERVIEW");
	}
	if (audio::is_audio_scene_active("CHI_2_SHOOTOUT_STEALTH")) {
		audio::stop_audio_scene("CHI_2_SHOOTOUT_STEALTH");
	}
	if (audio::is_audio_scene_active("CHI_2_SHOOTOUT_ENEMIES_ALERTED")) {
		audio::stop_audio_scene("CHI_2_SHOOTOUT_ENEMIES_ALERTED");
	}
	if (audio::is_audio_scene_active("CHI_2_POUR_GAS")) {
		audio::stop_audio_scene("CHI_2_POUR_GAS");
	}
	if (audio::is_audio_scene_active("CHI_2_SHOOT_GAS")) {
		audio::stop_audio_scene("CHI_2_SHOOT_GAS");
	}
	if (audio::is_audio_scene_active("CHI_2_GAS_TRAIL_FIRE")) {
		audio::stop_audio_scene("CHI_2_GAS_TRAIL_FIRE");
	}
	if (audio::is_audio_scene_active("CHI_2_RAYFIRE")) {
		audio::stop_audio_scene("CHI_2_RAYFIRE");
	}
	audio::stop_stream();
	if (iParam0 != 0) {
		func_15("CHN2_STOP_TRACK", 0, func_167());
		while (!func_2()) {
			func_28(0, 0);
		}
	}
	if (iParam0 != 3) {
		func_166(0);
	}
	if (iParam0 != 0) {
		uLocal_2672 = object::_get_des_object(2457.15f, 4968.79f, 48.677f, 45f, "DES_FarmHs");
		if (iLocal_2673) {
			if (object::_does_des_object_exist(uLocal_2672)) {
				object::_set_des_object_state(uLocal_2672, 2);
			}
			iLocal_2673 = 0;
		}
	}
}

// Position - 0x2592A
void func_343() { decisionevent::unblock_decision_maker_event(-455129387, 31); }

// Position - 0x2593D
void func_344(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	if (entity::does_entity_exist(iParam0)) {
		if (weapon::get_current_ped_weapon(iParam0, &iVar0, 0)) {
			if (iVar0 != 0 && iVar0 != joaat("weapon_unarmed")) {
				if (!func_345(iParam1, iVar0)) {
					iVar0 = 0;
				}
			}
		}
	}
	if (Global_91528 > 0) {
		Global_96040.f_21[iParam1] = iVar0;
	}
	else {
		Global_93635.f_21[iParam1] = iVar0;
	}
}

// Position - 0x259A3
int func_345(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	if (Global_91528 > 0) {
		iVar0 = 0;
		while (iVar0 < 44) {
			if (Global_96040.f_812[iParam0 /*284*/][iVar0 /*3*/] == iParam1) {
				if (Global_96040.f_812[iParam0 /*284*/][iVar0 /*3*/].f_1 > 0) {
					return 1;
				}
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			if (Global_96040.f_812[iParam0 /*284*/].f_133[iVar0 /*3*/] == iParam1) {
				if (Global_96040.f_812[iParam0 /*284*/].f_133[iVar0 /*3*/].f_1 > 0) {
					return 1;
				}
			}
			iVar0++;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < 44) {
			if (Global_93635.f_812[iParam0 /*284*/][iVar0 /*3*/] == iParam1) {
				if (Global_93635.f_812[iParam0 /*284*/][iVar0 /*3*/].f_1 > 0) {
					return 1;
				}
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			if (Global_93635.f_812[iParam0 /*284*/].f_133[iVar0 /*3*/] == iParam1) {
				if (Global_93635.f_812[iParam0 /*284*/].f_133[iVar0 /*3*/].f_1 > 0) {
					return 1;
				}
			}
			iVar0++;
		}
	}
	return 0;
}

// Position - 0x25AD6
void func_346() {
	int iVar0;

	Global_55851 = 0;
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 64) {
		Global_55852[iVar0 /*2*/] = 0;
		iVar0++;
	}
}

// Position - 0x25B00
int func_347() {
	if (Global_91491 != 10 && Global_91491 != 9) {
		return 0;
	}
	return Global_91491.f_2;
}

// Position - 0x25B2A
bool func_348() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return true;
	}
	return false;
}

// Position - 0x25B4E
void func_349(var *uParam0, char *sParam1, int iParam2, char *sParam3) {
	*uParam0 = sParam3;
	uParam0->f_1 = sParam1;
	uParam0->f_2 = iParam2;
}

// Position - 0x25B67
void func_350() {
	ped::add_relationship_group("MYFRIEND", &iLocal_1615);
	ped::add_relationship_group("FOE", &iLocal_1616);
	ped::add_relationship_group("IGNORE", &iLocal_1617);
	ped::add_relationship_group("BARpeds", &iLocal_2636);
	ped::set_relationship_between_groups(3, iLocal_2636, 1862763509);
	ped::set_relationship_between_groups(5, ped::get_ped_relationship_group_hash(player::player_ped_id()), iLocal_1616);
	ped::set_relationship_between_groups(5, iLocal_1616, ped::get_ped_relationship_group_hash(player::player_ped_id()));
	ped::set_relationship_between_groups(2, iLocal_1615, iLocal_1617);
	ped::set_relationship_between_groups(2, iLocal_1616, iLocal_1617);
	ped::set_relationship_between_groups(2, iLocal_1617, ped::get_ped_relationship_group_hash(player::player_ped_id()));
	ped::set_relationship_between_groups(2, iLocal_1617, iLocal_1616);
}

// Position - 0x25BFD
void func_351() {
	switch (iLocal_3688) {
	case 0:
		if (iLocal_2511 >= 4) {
			func_352(1, "Snipe from hill", 0, 0, 0, 1);
			iLocal_3688++;
		}
		break;

	case 1:
		if (iLocal_2511 >= 4 && iLocal_2511 < 7) {
			if (func_87(12) || iLocal_2511 == 6) {
				func_352(2, "Inside House", 0, 0, 0, 1);
				iLocal_3688++;
			}
		}
		else if (iLocal_2511 == 7) {
			if (weapon::has_ped_got_weapon(player::player_ped_id(), joaat("weapon_petrolcan"), 0)) {
				func_352(2, "Inside House", 0, 0, 0, 1);
				iLocal_3688++;
			}
		}
		else if (iLocal_2511 > 7) {
			func_352(2, "Inside House", 0, 0, 0, 1);
			iLocal_3688++;
		}
		break;

	case 2:
		if (iLocal_2511 >= 7) {
			func_352(3, "Pour petrol trail", 0, 0, 0, 1);
			iLocal_3688++;
		}
		break;

	case 3:
		if (iLocal_2511 == 9) {
			func_352(4, "Leave the farm house", 1, 0, 0, 1);
			iLocal_3688++;
		}
		break;
	}
}

// Position - 0x25D10
void func_352(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char[] cVar3[8];
	int iVar5;
	var uVar6;
	int iVar10;

	if (iParam3 == 1) {
		if (!gameplay::are_strings_equal("FinaleC2", script::get_this_script_name())) {
		}
	}
	iVar0 = 0;
	if (iParam3 == 1) {
		if (iParam0 != Global_91528) {
			iVar0 = 1;
		}
	}
	else if (iParam0 > Global_91528) {
		iVar0 = 1;
	}
	if (iVar0 == 1) {
		func_412(1);
		if (iParam0 <= Global_91528) {
		}
		iVar1 = func_410(script::get_this_script_name(), 1);
		if (iVar1 != -1 && iVar1 != 94) {
			Global_101700.f_8044.f_330[iVar1 /*6*/].f_1 = 0;
			iVar2 = func_408(iVar1);
			cVar3 = {Global_82612[iVar1 /*34*/].f_8};
			if (iVar1 == 90) {
				switch (Global_101700.f_8044.f_99.f_205[7]) {
				case 1: StringConCat(&cVar3, "A", 8); break;

				case 2: StringConCat(&cVar3, "B", 8); break;
				}
			}
			stats::playstats_mission_checkpoint(&cVar3, iVar2, Global_91528, iParam0);
		}
		else {
			iVar5 = func_403(script::get_this_script_name(), 1);
			if (iVar5 != -1) {
				Global_101700.f_17533[iVar5 /*6*/].f_4 = 0;
				MemCopy(&uVar6, {func_402(iVar5)}, 4);
				stats::playstats_mission_checkpoint(&uVar6, 0, Global_91528, iParam0);
			}
			else {
				iVar10 = func_401(&Global_91491.f_3);
				if (iVar10 > -1) {
					Global_101700.f_23945.f_4[iVar10] = 0;
				}
			}
		}
		Global_86002 = iParam2;
		Global_91528 = iParam0;
		func_353(iParam0, sParam1, iParam4, iParam5);
		if (gameplay::are_strings_equal(sParam1, "")) {
		}
	}
	else if (iParam0 < Global_91528) {
	}
}

// Position - 0x25E86
void func_353(int iParam0, var uParam1, int iParam2, int iParam3) {
	func_354(&Global_96040, script::get_this_script_name(), iParam0, uParam1, iParam3, iParam2);
}

// Position - 0x25EA2
void func_354(var *uParam0, var uParam1, var uParam2, var uParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;

	*uParam0 = func_43();
	uParam0->f_1 = func_390();
	gameplay::_get_weather_type_transition(&uParam0->f_6, &uParam0->f_7, &uParam0->f_8);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		func_377(&uParam0->f_2305, 0);
		func_376(player::player_ped_id());
		func_370(player::player_ped_id(), 0);
		weapon::get_current_ped_weapon(player::player_ped_id(), &uParam0->f_2, 1);
		if (uParam0->f_2 == 0 || uParam0->f_2 == joaat("object")) {
			uParam0->f_2 = joaat("weapon_unarmed");
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		uParam0->f_17[iVar1] = Global_101700.f_2095.f_539.f_294[iVar1];
		if (iVar1 == func_369()) {
			func_363(player::player_ped_id(), &uParam0->f_616[iVar1 /*65*/], 1);
		}
		else {
			iVar0 = 0;
			while (iVar0 < 12) {
				uParam0->f_616[iVar1 /*65*/][iVar0] = Global_91281[iVar1 /*65*/][iVar0];
				uParam0->f_616[iVar1 /*65*/].f_13[iVar0] = Global_91281[iVar1 /*65*/].f_13[iVar0];
				iVar0++;
			}
			uParam0->f_616[iVar1 /*65*/].f_59 = Global_91281[iVar1 /*65*/].f_59;
			uParam0->f_616[iVar1 /*65*/].f_60 = Global_91281[iVar1 /*65*/].f_60;
			uParam0->f_616[iVar1 /*65*/].f_61 = Global_91281[iVar1 /*65*/].f_61;
			uParam0->f_616[iVar1 /*65*/].f_62 = Global_91281[iVar1 /*65*/].f_62;
			uParam0->f_616[iVar1 /*65*/].f_63 = Global_91281[iVar1 /*65*/].f_63;
			uParam0->f_616[iVar1 /*65*/].f_64 = Global_91281[iVar1 /*65*/].f_64;
			iVar0 = 0;
			while (iVar0 < 9) {
				uParam0->f_616[iVar1 /*65*/].f_39[iVar0] = Global_91281[iVar1 /*65*/].f_39[iVar0];
				uParam0->f_616[iVar1 /*65*/].f_49[iVar0] = Global_91281[iVar1 /*65*/].f_49[iVar0];
				iVar0++;
			}
		}
		iVar0 = 0;
		while (iVar0 < 44) {
			uParam0->f_812[iVar1 /*284*/][iVar0 /*3*/] = {Global_101700.f_2095.f_539.f_298[iVar1 /*284*/][iVar0 /*3*/]};
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			uParam0->f_812[iVar1 /*284*/].f_133[iVar0 /*3*/] = {
				Global_101700.f_2095.f_539.f_298[iVar1 /*284*/].f_133[iVar0 /*3*/]};
			iVar0++;
		}
		switch (iVar1) {
		case 0:
			stats::stat_get_int(joaat("sp0_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp0_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 1:
			stats::stat_get_int(joaat("sp1_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp1_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 2:
			stats::stat_get_int(joaat("sp2_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp2_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;
		}
		uParam0->f_9[iVar1] = Global_101700.f_19523.f_233[iVar1 /*69*/].f_1;
		uParam0->f_13[iVar1] = Global_52996[iVar1];
		uParam0->f_25[0 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[0 /*295*/][iVar1 /*98*/]};
		uParam0->f_25[1 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[1 /*295*/][iVar1 /*98*/]};
		iVar0 = 0;
		while (iVar0 <= 3) {
			uParam0->f_2259[iVar1 /*15*/][iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/][iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_5[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_5[iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_10[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_10[iVar0];
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 2) {
			uParam0->f_1766[iVar1 /*164*/][iVar0] = Global_101700.f_2095[iVar1 /*164*/][iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_4[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_4[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_8[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_8[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_12[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_12[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_16[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_16[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_20[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_20[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_24[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_24[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_28[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_28[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_32[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_32[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_36[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_36[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_40[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_40[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_44[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_44[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_48[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_48[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_52[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_52[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_56[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_56[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_60[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_60[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_64[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_64[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_68[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_68[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_72[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_72[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_76[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_76[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_80[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_80[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_84[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_84[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_88[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_88[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_92[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_92[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_96[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_96[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_100[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_100[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_104[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_104[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_108[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_108[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_112[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_112[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_116[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_116[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_120[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_120[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_124[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_124[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_128[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_128[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_132[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_132[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_136[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_136[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_140[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_140[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_144[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_144[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_148[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_148[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_152[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_152[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_156[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_156[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_160[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_160[iVar0];
			iVar0++;
		}
		iVar1++;
	}
	stats::stat_get_int(joaat("sp0_special_ability"), &uParam0->f_1762[0], -1);
	stats::stat_get_int(joaat("sp1_special_ability"), &uParam0->f_1762[1], -1);
	stats::stat_get_int(joaat("sp2_special_ability"), &uParam0->f_1762[2], -1);
	uParam0->f_5 = 145;
	if (iParam4 == 1) {
		func_356(&uParam0->f_2311, uParam0, iParam5, 1, 1, 0);
	}
	func_355(&uParam0->f_2401);
	uParam3 = uParam3;
	uParam2 = uParam2;
}

// Position - 0x26D2A
int func_355(var *uParam0) {
	*uParam0 = Global_87673;
	uParam0->f_1 = Global_87674;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	return 1;
}

// Position - 0x26D4C
void func_356(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (iParam2 == 0) {
		iParam2 = player::player_ped_id();
	}
	if (entity::does_entity_exist(iParam2)) {
		uParam1->f_5 = func_46(iParam2);
	}
	if (func_362(iParam2, &iVar0, iParam3, iParam5)) {
		func_357(uParam0, uParam1, iVar0, iParam4);
	}
	else if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (vehicle::is_vehicle_model(iVar0, joaat("skylift")) &&
				ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
				func_357(uParam0, uParam1, iVar0, iParam4);
			}
		}
	}
}

// Position - 0x26DD4
int func_357(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (vehicle::is_vehicle_driveable(iParam2, 0)) {
		func_359(uParam0, iParam2, iParam3);
		uParam1->f_4 = iParam2;
		if (func_358(iParam2)) {
			uParam1->f_3 = 1;
		}
		else {
			uParam1->f_3 = 0;
		}
		return 1;
	}
	return 0;
}

// Position - 0x26E14
bool func_358(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 6) {
		if (Global_91491.f_22[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x26E42
void func_359(var *uParam0, int iParam1, int iParam2) {
	func_281(iParam1, &uParam0->f_12);
	uParam0->f_7 = func_361(iParam1, 145, 0);
	uParam0->f_11 = func_300(iParam1);
	if (!uParam0->f_7) {
		if (!uParam0->f_10) {
			uParam0->f_10 = func_360(iParam1);
		}
	}
	if (iParam2 == 1) {
		*uParam0 = {entity::get_entity_coords(iParam1, 1)};
		uParam0->f_6 = entity::get_entity_heading(iParam1);
		uParam0->f_3 = {entity::get_entity_velocity(iParam1)};
		if (entity::is_entity_in_angled_area(iParam1, -1154.326f, -1523.871f, 3.262189f, -1158.453f, -1517.75f,
											 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_6 = 305.6424f;
		}
		if (Global_69436 == iParam1) {
			uParam0->f_9 = 1;
		}
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		uParam0->f_8 = 1;
	}
	else {
		uParam0->f_8 = 0;
	}
}

// Position - 0x26F1E
int func_360(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iParam0 == Global_68531.f_484[iVar0]) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x26F60
int func_361(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				if (iParam1 == 145 || iParam1 == Global_89165[iVar0]) {
					if (iParam2 == 0 || entity::get_entity_model(iParam0) == func_309(iParam1, iParam2)) {
						return 1;
					}
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x26FEE
bool func_362(int iParam0, var *uParam1, int iParam2, int iParam3) {
	char *sVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (iParam0 == player::player_ped_id()) {
				*uParam1 = player::get_players_last_vehicle();
			}
			else {
				*uParam1 = ped::get_vehicle_ped_is_in(iParam0, 1);
			}
			if (entity::does_entity_exist(*uParam1)) {
				if (vehicle::is_vehicle_driveable(*uParam1, 0)) {
					if (iParam2 == 0 ||
						gameplay::get_distance_between_coords(entity::get_entity_coords(*uParam1, 1),
															  entity::get_entity_coords(iParam0, 1), 1) < 100f) {
						if (vehicle::is_vehicle_model(*uParam1, joaat("taxi"))) {
							if (vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != iParam0 &&
								vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != 0) {
								return false;
							}
						}
						if (func_72(*uParam1, func_43(), 1)) {
							sVar0 = script::get_this_script_name();
							if (!gameplay::are_strings_equal(sVar0, "save_anywhere")) {
								return false;
							}
							else if (!ped::is_ped_in_any_vehicle(iParam0, 1)) {
								return false;
							}
						}
						if (iParam3 == 1) {
							if (decorator::decor_exist_on(*uParam1, "IgnoredByQuickSave")) {
								if (decorator::decor_get_bool(*uParam1, "IgnoredByQuickSave")) {
									return false;
								}
							}
						}
						else if (vehicle::is_vehicle_model(*uParam1, joaat("blimp"))) {
							return false;
						}
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x2711D
void func_363(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = func_46(iParam0);
		iVar1 = 0;
		while (iVar1 < 12) {
			func_368(iParam0, iVar1, &uParam1->f_13[iVar1], &(*uParam1)[iVar1], &uParam1->f_26[iVar1], iParam2, 145);
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 9) {
			func_367(iParam0, iVar1, &uParam1->f_39[iVar1], &uParam1->f_49[iVar1], iParam2, 145);
			iVar1++;
		}
		if (func_45(iVar0)) {
			uParam1->f_59 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_59;
			uParam1->f_60 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_60;
			uParam1->f_61 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_61;
			uParam1->f_62 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_62;
			uParam1->f_63 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_63;
			uParam1->f_64 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_64;
		}
		else if (network::network_is_game_in_progress() &&
				 entity::get_entity_model(iParam0) == entity::get_entity_model(player::player_ped_id())) {
			if (func_366(161, -1)) {
				uParam1->f_59 = func_364(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_364(747, Global_69521, 0);
			}
			uParam1->f_60 = func_364(748, Global_69521, 0);
			uParam1->f_61 = func_364(749, Global_69521, 0);
		}
		if (network::network_is_game_in_progress() && iParam0 == player::player_ped_id()) {
			if (func_366(161, -1)) {
				uParam1->f_59 = func_364(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_364(747, Global_69521, 0);
			}
		}
	}
}

// Position - 0x272C7
int func_364(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_365(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x272F9
int func_365(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_190();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x2732D
bool func_366(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_365(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return false;
}

// Position - 0x27359
void func_367(int iParam0, int iParam1, int *iParam2, int *iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_prop_index(iParam0, iParam1);
		*iParam3 = ped::get_ped_prop_texture_index(iParam0, iParam1);
	}
	else {
		iVar0 = iParam5;
	}
	if (iParam4 == 0) {
		return;
	}
	if (iParam1 == 0) {
		if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
			if (iParam0 != 0) {
				if (ped::is_ped_wearing_helmet(iParam0) && ped::_0x451294E859ECC018(iParam0) != -1) {
					*iParam2 = ped::_0x451294E859ECC018(iParam0);
					*iParam3 = ped::_0x9D728C1E12BF5518(iParam0);
				}
			}
		}
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 0) {
			if (*iParam2 == 7) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 28) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		else if (iParam1 == 1) {
			if (*iParam2 == 1) {
				if ((iParam4 & 2) != 0 || (iParam4 & 64) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 0) {
			if (*iParam2 == 2) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 4) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 6) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 17) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 20) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 8 && *iParam2 <= 14) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 0) {
			if (*iParam2 == 9) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 12) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20 || *iParam2 == 2) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;
	}
}

// Position - 0x278A1
void func_368(int iParam0, int iParam1, int *iParam2, int *iParam3, var *uParam4, int iParam5, int iParam6) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_drawable_variation(iParam0, iParam1);
		*iParam3 = ped::get_ped_texture_variation(iParam0, iParam1);
		*uParam4 = ped::get_ped_palette_variation(iParam0, iParam1);
	}
	else {
		iVar0 = iParam6;
	}
	if (iParam5 == 0) {
		return;
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 15) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 3 || *iParam2 == 22) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 8) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 1 || *iParam2 == 10) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 19) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 3) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if (*iParam2 >= 5 && *iParam2 <= 7) {
				if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0x27AE2
int func_369() {
	func_44();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x27AFB
void func_370(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_46(iParam0);
	if (func_45(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			func_371(iParam0, &Global_101700.f_2095.f_539.f_298[iVar0 /*284*/]);
			iVar2 = 0;
			while (iVar2 <= 8 - 1) {
				Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] = ui::_0xA13E93403F26C812(iVar2);
				if (iParam1) {
					iVar1 = ui::_0xA48931185F0536FE();
					if (Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] == iVar1) {
						Global_101700.f_2095.f_539.f_1184 = iVar2;
					}
				}
				iVar2++;
			}
			player::get_player_parachute_pack_tint_index(player::player_id(), &iVar3);
			if (iVar0 == 0) {
				stats::stat_set_int(joaat("sp0_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 1) {
				stats::stat_set_int(joaat("sp1_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 2) {
				stats::stat_set_int(joaat("sp2_parachute_current_tint"), iVar3, 1);
			}
		}
	}
}

// Position - 0x27BEE
void func_371(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	int iVar7;
	int iVar8;
	struct<2> Var9;
	struct<4> Var48;
	int iVar70;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			(*uParam1)[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			iVar3 = func_375(iVar0);
			if (iVar3 != 0) {
				vVar4.x = weapon::get_ped_weapontype_in_slot(iParam0, func_375(iVar0));
				vVar4.y = 0;
				vVar4.z = 0;
				if (vVar4.x != 0 && vVar4.x != joaat("weapon_unarmed")) {
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (vVar4.x == joaat("gadget_parachute")) {
						vVar4.y = 1;
					}
					gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					(*uParam1)[iVar0 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					iVar2 = func_373(vVar4.x, iVar1);
					while (iVar2 != 0) {
						if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, iVar2)) {
							gameplay::set_bit(&vVar4.f_2, iVar1);
						}
						iVar1++;
						iVar2 = func_373(vVar4.x, iVar1);
					}
				}
				(*uParam1)[iVar0 /*3*/] = {vVar4};
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 50 - 1) {
			uParam1->f_133[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar8 = dlc1::get_num_dlc_weapons();
		iVar7 = 0;
		while (iVar7 < iVar8) {
			if (dlc1::get_dlc_weapon_data(iVar7, &Var9) && !func_372(Var9.f_1) && iVar70 < 50) {
				if (!dlc1::_is_dlc_data_empty(Var9)) {
					vVar4.x = Var9.f_1;
					vVar4.y = 0;
					vVar4.z = 0;
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					}
					else {
						gameplay::set_bit(&vVar4.f_2, 20);
					}
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					uParam1->f_133[iVar70 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					while (iVar1 < dlc1::get_num_dlc_weapon_components(iVar7)) {
						if (dlc1::get_dlc_weapon_component_data(iVar7, iVar1, &Var48)) {
							if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, Var48.f_3)) {
								gameplay::set_bit(&vVar4.f_2, iVar1);
							}
						}
						iVar1++;
					}
				}
				if (vVar4.x != 0) {
					if (!weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						vVar4.x = 0;
						vVar4.y = 0;
					}
				}
				uParam1->f_133[iVar70 /*3*/] = {vVar4};
				iVar70++;
			}
			iVar7++;
		}
	}
}

// Position - 0x27E52
int func_372(int iParam0) {
	if (network::network_is_game_in_progress()) {
	}
	else {
		switch (iParam0) {
		case joaat("weapon_pistol50"):
		case joaat("weapon_bullpupshotgun"):
		case joaat("weapon_assaultsmg"): return 0;

		case joaat("weapon_bottle"):
		case joaat("weapon_snspistol"):
		case joaat("weapon_gusenberg"): return 0;

		case joaat("weapon_heavypistol"):
		case joaat("weapon_specialcarbine"): return 0;

		case joaat("weapon_bullpuprifle"): return 0;

		case joaat("weapon_dagger"):
		case joaat("weapon_vintagepistol"): return 0;

		case joaat("weapon_firework"):
		case joaat("weapon_musket"): return 0;

		case joaat("weapon_heavyshotgun"):
		case joaat("weapon_marksmanrifle"): return 0;

		case joaat("weapon_hominglauncher"):
		case joaat("weapon_proxmine"): return 0;

		case joaat("weapon_combatpdw"):
		case joaat("weapon_knuckle"):
		case joaat("weapon_marksmanpistol"): return 0;

		case -947031628:
		case -572349828:
		case 392730790:
		case -1523701417:
		case -2112826155:
		case -664359727:
		case -1887867191:
		case -837150131:
		case -344484024:
		case joaat("weapon_flaregun"):
		case joaat("weapon_handcuffs"):
		case joaat("weapon_snowball"):
		case joaat("weapon_garbagebag"):
		case joaat("weapon_flashlight"):
		case joaat("weapon_switchblade"):
		case joaat("weapon_revolver"):
		case joaat("weapon_dbshotgun"):
		case joaat("weapon_compactrifle"):
		case 317205821:
		case -1121678507:
		case 125959754:
		case -853065399:
		case -1169823560:
		case -1810795771:
		case 419712736: return 1;
		}
	}
	return 0;
}

// Position - 0x27FC0
int func_373(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var *uVar2;
	struct<4> Var41;

	iVar0 = 0;
	switch (iParam0) {
	case joaat("weapon_pistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpistol_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_combatpistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_appistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_appistol_clip_01"); break;

		case 1: iVar0 = joaat("component_appistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_appistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_microsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_microsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_microsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_microsmg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_smg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_smg_clip_01"); break;

		case 1: iVar0 = joaat("component_smg_clip_02"); break;

		case 2: iVar0 = joaat("component_smg_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_pi_supp"); break;

		case 5: iVar0 = joaat("component_at_scope_macro_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_smg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_assaultrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_assaultrifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_at_ar_flsh"); break;

		case 5: iVar0 = joaat("component_at_scope_macro"); break;

		case 6: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 7: iVar0 = joaat("component_assaultrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_carbinerifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_carbinerifle_clip_01"); break;

		case 1: iVar0 = joaat("component_carbinerifle_clip_02"); break;

		case 2: iVar0 = joaat("component_carbinerifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_railcover_01"); break;

		case 4: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 5: iVar0 = joaat("component_at_ar_flsh"); break;

		case 6: iVar0 = joaat("component_at_scope_medium"); break;

		case 7: iVar0 = joaat("component_at_ar_supp"); break;

		case 8: iVar0 = joaat("component_carbinerifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_advancedrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_advancedrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_advancedrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_advancedrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_mg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_mg_clip_01"); break;

		case 1: iVar0 = joaat("component_mg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_scope_small_02"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_mg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_combatmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatmg_clip_01"); break;

		case 1: iVar0 = joaat("component_combatmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_scope_medium"); break;

		case 4: iVar0 = joaat("component_combatmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_pumpshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_sr_supp"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_pumpshotgun_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_assaultshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultshotgun_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultshotgun_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;
		}
		break;

	case joaat("weapon_sniperrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sniperrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_sniperrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_heavysniper"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_heavysniper_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;
		}
		break;

	case joaat("weapon_grenadelauncher"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_scope_small"); break;
		}
		break;

	case joaat("weapon_minigun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_minigun_clip_01"); break;
		}
		break;

	case joaat("weapon_assaultsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_assaultsmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_ar_supp_02"); break;
		}
		break;

	case joaat("weapon_pistol50"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol50_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol50_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol50_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpdw"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpdw_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpdw_clip_02"); break;

		case 2: iVar0 = joaat("component_combatpdw_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_small"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sawnoffshotgun_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_bullpuprifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_bullpuprifle_clip_01"); break;

		case 1: iVar0 = joaat("component_bullpuprifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 6: iVar0 = joaat("component_bullpuprifle_varmod_low"); break;
		}
		break;

	case joaat("weapon_snspistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_snspistol_clip_01"); break;

		case 1: iVar0 = joaat("component_snspistol_clip_02"); break;

		case 2: iVar0 = joaat("component_snspistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_specialcarbine"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_specialcarbine_clip_01"); break;

		case 1: iVar0 = joaat("component_specialcarbine_clip_02"); break;

		case 2: iVar0 = joaat("component_specialcarbine_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_medium"); break;

		case 5: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_specialcarbine_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_knuckle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_knuckle_varmod_pimp"); break;

		case 1: iVar0 = joaat("component_knuckle_varmod_ballas"); break;

		case 2: iVar0 = joaat("component_knuckle_varmod_dollar"); break;

		case 3: iVar0 = joaat("component_knuckle_varmod_diamond"); break;

		case 4: iVar0 = joaat("component_knuckle_varmod_hate"); break;

		case 5: iVar0 = joaat("component_knuckle_varmod_love"); break;

		case 6: iVar0 = joaat("component_knuckle_varmod_player"); break;

		case 7: iVar0 = joaat("component_knuckle_varmod_king"); break;

		case 8: iVar0 = joaat("component_knuckle_varmod_vagos"); break;
		}
		break;

	case joaat("weapon_machinepistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_machinepistol_clip_01"); break;

		case 1: iVar0 = joaat("component_machinepistol_clip_02"); break;

		case 2: iVar0 = joaat("component_machinepistol_clip_03"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;
		}
		break;

	case joaat("weapon_switchblade"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_switchblade_varmod_var1"); break;

		case 1: iVar0 = joaat("component_switchblade_varmod_var2"); break;
		}
		break;

	case joaat("weapon_revolver"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_revolver_clip_01"); break;

		case 1: iVar0 = joaat("component_revolver_varmod_boss"); break;

		case 2: iVar0 = joaat("component_revolver_varmod_goon"); break;
		}
		break;

	case -1121678507:
		switch (iParam1) {
		case 0: iVar0 = -2067221805; break;

		case 1: iVar0 = -1820405577; break;
		}
		break;

	default:
		if (iParam0 != 0) {
			iVar1 = func_374(iParam0, &uVar2);
			if (iVar1 != -1) {
				if (iParam1 < dlc1::get_num_dlc_weapon_components(iVar1)) {
					if (dlc1::get_dlc_weapon_component_data(iVar1, iParam1, &Var41)) {
						return Var41.f_3;
					}
				}
			}
		}
		break;
	}
	return iVar0;
}

// Position - 0x28AE2
int func_374(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x28B1D
int func_375(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (iParam0) {
	case 0: iVar0 = 1993361168; break;

	case 1: iVar0 = 1277010230; break;

	case 2: iVar0 = 932043479; break;

	case 3: iVar0 = -690654591; break;

	case 4: iVar0 = -1459198205; break;

	case 5: iVar0 = 195782970; break;

	case 6: iVar0 = -438797331; break;

	case 7: iVar0 = 896793492; break;

	case 8: iVar0 = 495159329; break;

	case 9: iVar0 = -1155528315; break;

	case 10: iVar0 = -515636489; break;

	case 11: iVar0 = -871913299; break;

	case 12: iVar0 = -1352759032; break;

	case 13: iVar0 = -542958961; break;

	case 14: iVar0 = 1682645887; break;

	case 15: iVar0 = -859470162; break;

	case 16: iVar0 = -2125426402; break;

	case 17: iVar0 = 2067210266; break;

	case 18: iVar0 = -538172856; break;

	case 19: iVar0 = 1783244476; break;

	case 20: iVar0 = 439844898; break;

	case 21: iVar0 = -24829327; break;

	case 22: iVar0 = 1949306232; break;

	case 23: iVar0 = -1941230881; break;

	case 24: iVar0 = -1033554448; break;

	case 25: iVar0 = 320513715; break;

	case 26: iVar0 = -695165975; break;

	case 27: iVar0 = -281028447; break;

	case 28: iVar0 = -686713772; break;

	case 29: iVar0 = 347509793; break;

	case 30: iVar0 = 1769089473; break;

	case 31: iVar0 = 189935548; break;

	case 33: iVar0 = 248801358; break;

	case 34: iVar0 = 386596758; break;

	case 35: iVar0 = -157212362; break;

	case 36: iVar0 = 436985596; break;

	case 37: iVar0 = -47957369; break;

	case 38: iVar0 = 575938238; break;
	}
	return iVar0;
}

// Position - 0x28D91
void func_376(int iParam0) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (func_45(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_294[iVar0] = ped::get_ped_armour(iParam0);
	}
}

// Position - 0x28DCD
void func_377(var *uParam0, int iParam1) {
	int iVar0;
	vector3 vVar1;
	float *fVar4;
	int iVar5;

	*uParam0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	uParam0->f_3 = entity::get_entity_heading(player::player_ped_id());
	uParam0->f_5 = ped::get_ped_parachute_state(player::player_ped_id());
	if (player::is_player_playing(player::player_id())) {
		uParam0->f_4 = player::get_player_wanted_level(player::player_id());
	}
	if (system::vdist(*uParam0, 320.9934f, 265.2515f, 82.1221f) < 10f) {
		*uParam0 = {301.2162f, 202.1357f, 103.3797f};
		uParam0->f_3 = 156.5144f;
	}
	else if (system::vdist(*uParam0, 377.153f, -717.567f, 10.0536f) < 10f) {
		*uParam0 = {394.2567f, -713.5439f, 28.2853f};
		uParam0->f_3 = 276.6273f;
	}
	else if (system::vdist(*uParam0, -1425.564f, -244.3f, 15.8053f) < 10f) {
		*uParam0 = {-1423.472f, -214.2539f, 45.5004f};
		uParam0->f_3 = 353.8757f;
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("finale_choice")) > 0) {
		*uParam0 = {4.2587f, 525.0214f, 173.6281f};
		uParam0->f_3 = 203.6746f;
	}
	else if (gameplay::is_bit_set(Global_69950, 4)) {
		*uParam0 = {452.0255f, 5571.85f, 780.1859f};
		uParam0->f_3 = 78.9858f;
	}
	else if (gameplay::is_bit_set(Global_69950, 5)) {
		*uParam0 = {-745.4462f, 5595.146f, 40.6594f};
		uParam0->f_3 = 261.747f;
	}
	else if (gameplay::is_bit_set(Global_69950, 6)) {
		*uParam0 = {-1675.521f, -1125.59f, 12.091f};
		uParam0->f_3 = 271.8208f;
	}
	else if (gameplay::is_bit_set(Global_69950, 7)) {
		*uParam0 = {-1631.219f, -1112.805f, 12.0212f};
		uParam0->f_3 = 316.8879f;
	}
	else if (interior::get_interior_from_entity(player::player_ped_id()) ==
			 interior::get_interior_at_coords_with_type(1272.659f, -1715.467f, 53.7715f, "v_lesters")) {
		*uParam0 = {1276.956f, -1725.189f, 53.6551f};
		uParam0->f_3 = 204.1703f;
	}
	else if (entity::is_entity_in_angled_area(player::player_ped_id(), -415.4365f, 2068.289f, 113.3002f, -564.9516f,
											  1884.703f, 134.0403f, 258.75f, 0, 1, 0) ||
			 entity::is_entity_in_angled_area(player::player_ped_id(), -596.4706f, 2089.921f, 125.4128f, -581.2134f,
											  2036.256f, 136.2836f, 9.5f, 0, 1, 0)) {
		*uParam0 = {-601.59f, 2099.197f, 128.8928f};
		uParam0->f_3 = 204.7498f;
	}
	else if (system::vdist(*uParam0, -1007.393f, -477.9584f, 52.5357f) < 8f) {
		*uParam0 = {-1018.376f, -483.9436f, 36.0964f};
		uParam0->f_3 = 114.7664f;
	}
	else if (system::vdist(*uParam0, 480.6662f, -1317.808f, 28.20303f) < 15f) {
		*uParam0 = {497.7238f, -1310.932f, 28.2372f};
		uParam0->f_3 = 289.3663f;
	}
	else if (system::vdist(*uParam0, 2329.527f, 2571.311f, 45.6779f) < 5f) {
		*uParam0 = {2316.93f, 2594.153f, 45.7199f};
		uParam0->f_3 = 348.1325f;
	}
	if (iParam1 == 1) {
		if (func_380(&iVar0)) {
			if (func_379(iVar0, &vVar1, &fVar4)) {
				vVar1.z++;
				*uParam0 = {vVar1};
				uParam0->f_3 = fVar4;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 207.4336f, -1019.795f, -100.4728f, 189.9338f,
												  -1019.623f, -95.56883f, 17.1875f, 0, 1, 0)) {
			iVar5 = func_43();
			if (iVar5 == 0) {
				*uParam0 = {-65.1234f, 81.2517f, 70.5644f};
				uParam0->f_3 = 71.6237f;
			}
			else if (iVar5 == 1) {
				*uParam0 = {-68.5531f, -1824.377f, 25.9424f};
				uParam0->f_3 = 215.8295f;
			}
			else if (iVar5 == 2) {
				*uParam0 = {-220.8189f, -1162.302f, 22.0242f};
				uParam0->f_3 = 70.2711f;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 483.7175f, -1326.63f, 28.2135f, 474.9644f,
												  -1307.998f, 34.49498f, 12f, 0, 1, 0)) {
			*uParam0 = {495.4108f, -1306.08f, 29.2883f};
			uParam0->f_3 = 213.6273f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), -1146.77f, -1534.22f, 3.37f, -1158.453f,
												  -1517.75f, 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_3 = 305.6424f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 439.5432f, -996.9769f, 24.88307f, 428.2935f,
												  -997.0192f, 28.57458f, 8.5f, 0, 1, 0)) {
			*uParam0 = {431.8853f, -1013.133f, 28.7907f};
			uParam0->f_3 = 186.6814f;
		}
		else if (func_378(*uParam0, "v_hospital", 307.3065f, -589.9595f, 43.302f)) {
			*uParam0 = {279.4137f, -585.8815f, 43.2502f};
			uParam0->f_3 = 48.8028f;
		}
	}
}

// Position - 0x29328
bool func_378(vector3 vParam0, char *sParam3, vector3 vParam4) {
	int iVar0;
	int iVar1;

	if (!interior::_are_coords_colliding_with_exterior(vParam0)) {
		iVar0 = interior::get_interior_at_coords_with_type(vParam4, sParam3);
		if (!interior::is_valid_interior(iVar0)) {
			return false;
		}
		iVar1 = interior::get_interior_from_collision(vParam0);
		if (iVar1 == iVar0) {
			return true;
		}
	}
	return false;
}

// Position - 0x2936C
bool func_379(int iParam0, var *uParam1, float *fParam2) {
	*uParam1 = {0f, 0f, 0f};
	*fParam2 = 0f;
	switch (iParam0) {
	case 0:
		*uParam1 = {-829.842f, -191.7454f, 36.4386f};
		*fParam2 = 29.5061f;
		break;

	case 1:
		*uParam1 = {129.8484f, -1716.528f, 28.0702f};
		*fParam2 = 50.3483f;
		break;

	case 2:
		*uParam1 = {-1296.913f, -1120.999f, 5.3951f};
		*fParam2 = 0.9933f;
		break;

	case 3:
		*uParam1 = {1938.028f, 3718.736f, 31.3154f};
		*fParam2 = 118.2305f;
		break;

	case 4:
		*uParam1 = {1197.866f, -469.3809f, 65.0885f};
		*fParam2 = 346.4477f;
		break;

	case 5:
		*uParam1 = {-32.2161f, -135.8212f, 56.0532f};
		*fParam2 = 186.0052f;
		break;

	case 6:
		*uParam1 = {-287.7696f, 6238.081f, 30.2902f};
		*fParam2 = 316.1349f;
		break;

	case 7:
		*uParam1 = {99.2876f, -1395.16f, 28.2759f};
		*fParam2 = 320.2739f;
		break;

	case 8:
		*uParam1 = {1679.445f, 4819.056f, 41.0035f};
		*fParam2 = 4.6192f;
		break;

	case 9:
		*uParam1 = {411.3063f, -809.1863f, 28.1554f};
		*fParam2 = 1.8972f;
		break;

	case 10:
		*uParam1 = {-1088.054f, 2699.167f, 19.2748f};
		*fParam2 = 129.7382f;
		break;

	case 11:
		*uParam1 = {1194.163f, 2695.644f, 36.9225f};
		*fParam2 = 1.1454f;
		break;

	case 12:
		*uParam1 = {-821.2829f, -1088.027f, 10.0499f};
		*fParam2 = 120.5883f;
		break;

	case 13:
		*uParam1 = {-3.3416f, 6521.303f, 30.2961f};
		*fParam2 = 316.4451f;
		break;

	case 14:
		*uParam1 = {-1208.417f, -785.9635f, 16.0139f};
		*fParam2 = 36.3181f;
		break;

	case 15:
		*uParam1 = {623.1845f, 2739.191f, 40.9588f};
		*fParam2 = 3.5411f;
		break;

	case 16:
		*uParam1 = {130.9555f, -198.2084f, 53.41f};
		*fParam2 = 251.3506f;
		break;

	case 17:
		*uParam1 = {-3164.065f, 1067.317f, 19.6778f};
		*fParam2 = 101.2229f;
		break;

	case 18:
		*uParam1 = {-713.2797f, -174.2767f, 35.8962f};
		*fParam2 = 29.8138f;
		break;

	case 19:
		*uParam1 = {-147.0616f, -306.4322f, 37.7912f};
		*fParam2 = 160.4526f;
		break;

	case 20:
		*uParam1 = {-1461.355f, -230.6092f, 48.3064f};
		*fParam2 = 318.7851f;
		break;

	case 21:
		*uParam1 = {-1347.739f, -1278.573f, 3.8952f};
		*fParam2 = 17.9365f;
		break;

	case 22:
		*uParam1 = {325.6833f, 164.3263f, 102.4425f};
		*fParam2 = 68.6407f;
		break;

	case 23:
		*uParam1 = {1858.774f, 3742.393f, 32.0779f};
		*fParam2 = 301.2329f;
		break;

	case 24:
		*uParam1 = {-286.3272f, 6202.802f, 30.3323f};
		*fParam2 = 225.1334f;
		break;

	case 25:
		*uParam1 = {-1161.596f, -1417.7f, 3.712f};
		*fParam2 = 246.9161f;
		break;

	case 26:
		*uParam1 = {1308.952f, -1660.611f, 50.2362f};
		*fParam2 = 163.5456f;
		break;

	case 27:
		*uParam1 = {-3161.585f, 1074.214f, 19.6847f};
		*fParam2 = 98.6092f;
		break;

	case 28:
		*uParam1 = {28.423f, -1110.814f, 28.2848f};
		*fParam2 = 85.2495f;
		break;

	case 29:
		*uParam1 = {1704.966f, 3749.709f, 33.0188f};
		*fParam2 = 45.6778f;
		break;

	case 30:
		*uParam1 = {223.949f, -38.7894f, 68.6483f};
		*fParam2 = 159.4265f;
		break;

	case 31:
		*uParam1 = {837.7854f, -1017.963f, 26.3045f};
		*fParam2 = 181.0445f;
		break;

	case 32:
		*uParam1 = {-313.1914f, 6093.351f, 30.4625f};
		*fParam2 = 315.8405f;
		break;

	case 33:
		*uParam1 = {-663.4631f, -952.8069f, 20.3143f};
		*fParam2 = 92.6796f;
		break;

	case 34:
		*uParam1 = {-1323.06f, -392.8577f, 35.4596f};
		*fParam2 = 210.7398f;
		break;

	case 35:
		*uParam1 = {-1106.102f, 2684.35f, 18.0953f};
		*fParam2 = 127.0383f;
		break;

	case 36:
		*uParam1 = {-3157.932f, 1081.309f, 19.6953f};
		*fParam2 = 100.2942f;
		break;

	case 37:
		*uParam1 = {2562.882f, 312.8641f, 107.4612f};
		*fParam2 = 179.205f;
		break;

	case 38:
		*uParam1 = {822.48f, -2142.875f, 27.8496f};
		*fParam2 = 355.0598f;
		break;

	case 39:
		*uParam1 = {-1137.053f, -1993.916f, 12.1677f};
		*fParam2 = 43.1213f;
		break;

	case 40:
		*uParam1 = {717.8107f, -1084.081f, 21.3094f};
		*fParam2 = 93.2649f;
		break;

	case 41:
		*uParam1 = {-387.6789f, -128.2568f, 37.6796f};
		*fParam2 = 119.1085f;
		break;

	case 42:
		*uParam1 = {117.8835f, 6599.415f, 31.0134f};
		*fParam2 = 90.7225f;
		break;

	case 43:
		*uParam1 = {1201.709f, 2664.813f, 36.8102f};
		*fParam2 = 133.9002f;
		break;

	case 44:
		*uParam1 = {-200.1521f, -1297.502f, 30.296f};
		*fParam2 = 269.0687f;
		break;

	case 45:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		break;
	}
	return !func_162(*uParam1, 0f, 0f, 0f, 0);
}

// Position - 0x299FB
bool func_380(int *iParam0) {
	if (!entity::is_entity_dead(player::player_ped_id(), 0) && !ped::is_ped_injured(player::player_ped_id())) {
		if (func_34()) {
			*iParam0 = func_385(entity::get_entity_coords(player::player_ped_id(), 0), 6, -1, 0, 1, -1);
			if (func_384(*iParam0) && !func_381(*iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x29A56
int func_381(int iParam0) { return func_382(iParam0, 0, 1); }

// Position - 0x29A66
int func_382(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		return gameplay::is_bit_set(Global_91543.f_1308[iParam0], iParam1);
	}
	else if (network::network_is_game_in_progress()) {
		if (func_25() == 0) {
			return gameplay::is_bit_set(func_364(func_383(iParam0), -1, 0), iParam1);
		}
	}
	else {
		return gameplay::is_bit_set(Global_101700.f_668[iParam0], iParam1);
	}
	return 0;
}

// Position - 0x29AC6
int func_383(int iParam0) {
	switch (iParam0) {
	case 0: return 822;

	case 1: return 823;

	case 2: return 824;

	case 3: return 825;

	case 4: return 826;

	case 5: return 827;

	case 6: return 828;

	case 7: return 829;

	case 8: return 830;

	case 9: return 831;

	case 10: return 832;

	case 11: return 833;

	case 12: return 834;

	case 13: return 835;

	case 14: return 836;

	case 15: return 838;

	case 16: return 839;

	case 17: return 840;

	case 18: return 841;

	case 19: return 842;

	case 20: return 843;

	case 21: return 844;

	case 22: return 845;

	case 23: return 846;

	case 24: return 847;

	case 25: return 848;

	case 26: return 849;

	case 27: return 850;

	case 28: return 851;

	case 29: return 852;

	case 30: return 853;

	case 31: return 854;

	case 32: return 855;

	case 33: return 856;

	case 34: return 857;

	case 35: return 858;

	case 36: return 859;

	case 37: return 860;

	case 38: return 861;

	case 39: return 862;

	case 40: return 866;

	case 41: return 867;

	case 42: return 868;

	case 43: return 869;

	case 44: return 5847;

	case 45: return 3780;

	default: break;
	}
	return 6022;
}

// Position - 0x29D8D
int func_384(int iParam0) { return func_382(iParam0, 5, 1); }

// Position - 0x29D9D
int func_385(vector3 vParam0, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = -1;
	iVar0 = 0;
	while (iVar0 <= 45) {
		if (iParam3 == 6 || iParam3 == func_389(iVar0)) {
			if (!iParam5 || func_388(iVar0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, func_386(iVar0, 0), 1);
				if (fVar1 < fVar2 && (fVar1 <= IntToFloat(iParam4) || iParam4 == -1) && (iParam6 || iVar0 != 21) &&
					iVar0 != iParam7) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x29E3F
Vector3 func_386(int iParam0, int iParam1) {
	switch (iParam0) {
	case -1: return 0f, 0f, 0f;

	case 0: return -821.9946f, -187.1776f, 36.5689f;

	case 1: return 133.5702f, -1710.918f, 28.2916f;

	case 2: return -1287.082f, -1116.558f, 5.9901f;

	case 3: return 1933.119f, 3726.079f, 31.8444f;

	case 4: return 1208.333f, -470.917f, 65.208f;

	case 5: return -30.7448f, -148.4921f, 56.0765f;

	case 6: return -280.8165f, 6231.771f, 30.6955f;

	case 7: return 80.665f, -1391.669f, 28.3761f;

	case 8: return 1687.881f, 4820.55f, 41.0096f;

	case 9: return 419.531f, -807.5787f, 28.4896f;

	case 10: return -1094.049f, 2704.171f, 18.0873f;

	case 11: return 1197.972f, 2704.22f, 37.1572f;

	case 12: return -818.6218f, -1077.533f, 10.3282f;

	case 13: return -0.2361f, 6516.045f, 30.8684f;

	case 14: return -1199.809f, -776.6886f, 16.3237f;

	case 15: return 618.1857f, 2752.567f, 41.0881f;

	case 16: return 126.6853f, -212.5027f, 53.5578f;

	case 17: return -3168.966f, 1055.287f, 19.8632f;

	case 18: return -715.3598f, -155.7742f, 36.4105f;

	case 19: return -158.2199f, -304.9663f, 38.735f;

	case 20: return -1455.005f, -233.1862f, 48.7936f;

	case 21: return -1335.973f, -1278.555f, 3.8598f;

	case 22: return 321.6098f, 179.4165f, 102.5865f;

	case 23: return 1861.685f, 3750.08f, 32.0318f;

	case 24: return -290.1603f, 6199.095f, 30.4871f;

	case 25: return -1153.948f, -1425.019f, 3.9544f;

	case 26: return 1322.455f, -1651.125f, 51.1885f;

	case 27: return -3169.42f, 1074.727f, 19.8343f;

	case 28: return 17.6804f, -1114.288f, 28.797f;

	case 29: return 1697.979f, 3753.2f, 33.7053f;

	case 30: return 245.2711f, -45.8126f, 68.941f;

	case 31: return 844.1248f, -1025.571f, 27.1948f;

	case 32: return -325.8904f, 6077.026f, 30.4548f;

	case 33: return -664.2178f, -943.3646f, 20.8292f;

	case 34: return -1313.948f, -390.9637f, 35.592f;

	case 35: return -1111.238f, 2688.463f, 17.6131f;

	case 36: return -3165.231f, 1082.855f, 19.8438f;

	case 37: return 2569.612f, 302.576f, 107.7349f;

	case 38: return 811.8699f, -2149.102f, 28.6363f;

	case 39: return -1147.314f, -1992.434f, 12.1803f;

	case 40: return 724.524f, -1089.081f, 21.1692f;

	case 41: return -354.5272f, -135.4011f, 38.185f;

	case 42: return 113.2615f, 6624.28f, 30.7871f;

	case 43: return 1174.707f, 2644.45f, 36.7552f;

	case 44:
		if (iParam1) {
			return -211.5f, -1324.2f, 30.296f;
		}
		else {
			return -205.6654f, -1311.113f, 30.296f;
		}
		break;

	case 45: return func_387(Global_93004);
	}
	return 1000000f, 1000000f, 1000000f;
}

// Position - 0x2A359
Vector3 func_387(int iParam0) {
	switch (iParam0) {
	case 1: return 1060f, -2990f, -35f;

	case 2: return 1060f, -2990f, -35f;

	case 3: return 974.9542f, -3000.091f, -35f;

	case 6: return -1586.36f, -566.6f, 106.17f;

	case 7: return -1389.87f, -465.17f, 82.68f;

	case 8: return -145.81f, -590.2f, 171.13f;

	case 9: return -62.49f, -823.55f, 288.74f;

	case 4: return 1102.515f, -3158.888f, -38.5186f;

	case 5: return 1005.861f, -3156.162f, -39.907f;

	default: return 0f, 0f, -200f;
	}
	return 0f, 0f, -200f;
}

// Position - 0x2A46F
int func_388(int iParam0) { return func_382(iParam0, 0, 0); }

// Position - 0x2A47F
int func_389(int iParam0) {
	switch (iParam0) {
	case -1: return 6;

	case 0: return 0;

	case 1: return 0;

	case 2: return 0;

	case 3: return 0;

	case 4: return 0;

	case 5: return 0;

	case 6: return 0;

	case 7: return 1;

	case 8: return 1;

	case 9: return 1;

	case 10: return 1;

	case 11: return 1;

	case 12: return 1;

	case 13: return 1;

	case 14: return 1;

	case 15: return 1;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 2;

	case 23: return 2;

	case 24: return 2;

	case 25: return 2;

	case 26: return 2;

	case 27: return 2;

	case 28: return 3;

	case 29: return 3;

	case 30: return 3;

	case 31: return 3;

	case 32: return 3;

	case 33: return 3;

	case 34: return 3;

	case 35: return 3;

	case 36: return 3;

	case 37: return 3;

	case 38: return 3;

	case 39: return 4;

	case 40: return 4;

	case 41: return 4;

	case 42: return 4;

	case 43: return 4;

	case 44: return 4;

	case 45: return 5;
	}
	return 6;
}

// Position - 0x2A6F2
var func_390() {
	int *iVar0;

	func_400(&iVar0, time::get_clock_seconds());
	func_399(&iVar0, time::get_clock_minutes());
	func_398(&iVar0, time::get_clock_hours());
	func_393(&iVar0, time::get_clock_day_of_month());
	func_392(&iVar0, time::get_clock_month());
	func_391(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x2A738
void func_391(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x2A7BE
void func_392(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x2A7F1
void func_393(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_397(*uParam0);
	iVar1 = func_395(*uParam0);
	if (iParam1 < 1 || iParam1 > func_394(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x2A842
int func_394(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x2A8E4
var func_395(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_396(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x2A909
int func_396(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x2A920
int func_397(var uParam0) { return uParam0 & 15; }

// Position - 0x2A92D
void func_398(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x2A967
void func_399(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x2A9A2
void func_400(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x2A9DE
int func_401(char *sParam0) {
	if (gameplay::are_strings_equal("BailBond1", sParam0)) {
		return 0;
	}
	else if (gameplay::are_strings_equal("BailBond2", sParam0)) {
		return 1;
	}
	else if (gameplay::are_strings_equal("BailBond3", sParam0)) {
		return 2;
	}
	else if (gameplay::are_strings_equal("BailBond4", sParam0)) {
		return 3;
	}
	return -1;
}

// Position - 0x2AA34
struct<2> func_402(int iParam0) {
	struct<2> Var0;

	StringCopy(&Var0, "", 8);
	switch (iParam0) {
	case 0: StringCopy(&Var0, "ABI1", 8); break;

	case 1: StringCopy(&Var0, "ABI2", 8); break;

	case 2: StringCopy(&Var0, "BA1", 8); break;

	case 3: StringCopy(&Var0, "BA2", 8); break;

	case 4: StringCopy(&Var0, "BA3", 8); break;

	case 5: StringCopy(&Var0, "BA3A", 8); break;

	case 6: StringCopy(&Var0, "BA3C", 8); break;

	case 7: StringCopy(&Var0, "BA4", 8); break;

	case 8: StringCopy(&Var0, "DRE1", 8); break;

	case 9: StringCopy(&Var0, "EPS1", 8); break;

	case 10: StringCopy(&Var0, "EPS2", 8); break;

	case 11: StringCopy(&Var0, "EPS3", 8); break;

	case 12: StringCopy(&Var0, "EPS4", 8); break;

	case 13: StringCopy(&Var0, "EPS5", 8); break;

	case 14: StringCopy(&Var0, "EPS6", 8); break;

	case 15: StringCopy(&Var0, "EPS7", 8); break;

	case 16: StringCopy(&Var0, "EPS8", 8); break;

	case 17: StringCopy(&Var0, "EXT1", 8); break;

	case 18: StringCopy(&Var0, "EXT2", 8); break;

	case 19: StringCopy(&Var0, "EXT3", 8); break;

	case 20: StringCopy(&Var0, "EXT4", 8); break;

	case 21: StringCopy(&Var0, "FAN1", 8); break;

	case 22: StringCopy(&Var0, "FAN2", 8); break;

	case 23: StringCopy(&Var0, "FAN3", 8); break;

	case 24: StringCopy(&Var0, "HAO1", 8); break;

	case 25: StringCopy(&Var0, "HUN1", 8); break;

	case 26: StringCopy(&Var0, "HUN2", 8); break;

	case 27: StringCopy(&Var0, "JOS1", 8); break;

	case 28: StringCopy(&Var0, "JOS2", 8); break;

	case 29: StringCopy(&Var0, "JOS3", 8); break;

	case 30: StringCopy(&Var0, "JOS4", 8); break;

	case 31: StringCopy(&Var0, "MAU1", 8); break;

	case 32: StringCopy(&Var0, "MIN1", 8); break;

	case 33: StringCopy(&Var0, "MIN2", 8); break;

	case 34: StringCopy(&Var0, "MIN3", 8); break;

	case 35: StringCopy(&Var0, "MRS1", 8); break;

	case 36: StringCopy(&Var0, "MRS2", 8); break;

	case 37: StringCopy(&Var0, "NI1", 8); break;

	case 38: StringCopy(&Var0, "NI1A", 8); break;

	case 39: StringCopy(&Var0, "NI1B", 8); break;

	case 40: StringCopy(&Var0, "NI1C", 8); break;

	case 41: StringCopy(&Var0, "NI1D", 8); break;

	case 42: StringCopy(&Var0, "NI2", 8); break;

	case 43: StringCopy(&Var0, "NI3", 8); break;

	case 44: StringCopy(&Var0, "OME1", 8); break;

	case 45: StringCopy(&Var0, "OME2", 8); break;

	case 46: StringCopy(&Var0, "PA1", 8); break;

	case 47: StringCopy(&Var0, "PA2", 8); break;

	case 48: StringCopy(&Var0, "PA3", 8); break;

	case 49: StringCopy(&Var0, "PA3A", 8); break;

	case 50: StringCopy(&Var0, "PA3B", 8); break;

	case 51: StringCopy(&Var0, "PA4", 8); break;

	case 52: StringCopy(&Var0, "RAM1", 8); break;

	case 53: StringCopy(&Var0, "RAM2", 8); break;

	case 54: StringCopy(&Var0, "RAM3", 8); break;

	case 55: StringCopy(&Var0, "RAM4", 8); break;

	case 56: StringCopy(&Var0, "RAM5", 8); break;

	case 57: StringCopy(&Var0, "SAS1", 8); break;

	case 58: StringCopy(&Var0, "TON1", 8); break;

	case 59: StringCopy(&Var0, "TON2", 8); break;

	case 60: StringCopy(&Var0, "TON3", 8); break;

	case 61: StringCopy(&Var0, "TON4", 8); break;

	case 62: StringCopy(&Var0, "TON5", 8); break;

	default: break;
	}
	return Var0;
}

//Position - 0x2AE81
int func_403(char* sParam0, int iParam1)
{
	int iVar0;
	char *sVar1;
	int iVar33;
	int iVar34;

	iVar33 = gameplay::get_hash_key(sParam0);
	iVar34 = 0;
	iVar34 = 0;
	while (iVar34 < 63) {
		iVar0 = iVar34;
		func_404(iVar0, &sVar1);
		if (gameplay::get_hash_key(sVar1) == iVar33) {
			return iVar0;
		}
		iVar34++;
	}
	if (iParam1 == 0) {
	}
	return -1;
}

// Position - 0x2AECA
void func_404(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		func_405(uParam1, "Abigail1", func_407(iParam0), 0, 0, 4, -1604.668f, 5239.1f, 3.01f, 66, "", 109, 0,
				 "ambient_Diving", 0, 0, 1, 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 1:
		func_405(uParam1, "Abigail2", func_407(iParam0), 0, 0, 4, -1592.84f, 5214.04f, 3.01f, 400, "", 110, 0, "", 0, 0,
				 -1, 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 2:
		func_405(uParam1, "Barry1", func_407(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", 74, 0, "", 0, 1, -1,
				 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 3:
		func_405(uParam1, "Barry2", func_407(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", -1, 0, "", 0, 1, -1,
				 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 4:
		func_405(uParam1, "Barry3", func_407(iParam0), 0, 1, 4, 414f, -761f, 29f, 381, "", -1, 0, "", 164, 1, -1, 0, 2,
				 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 5:
		func_405(uParam1, "Barry3A", func_407(iParam0), 1, 1, 0, 1199.27f, -1255.63f, 34.23f, 381, "BARSTASH", 84, 0,
				 "", 166, 0, 7, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 6:
		func_405(uParam1, "Barry3C", func_407(iParam0), 3, 1, 0, -468.9f, -1713.06f, 18.21f, 381, "", 84, 0, "", 166, 0,
				 7, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 7:
		func_405(uParam1, "Barry4", func_407(iParam0), 0, 1, 4, 237.65f, -385.41f, 44.4f, 381, "", 85, 0,
				 "postRC_Barry4", 0, 0, -1, 4, 2, 800, 2000, func_406(iParam0), 0, 0);
		break;

	case 8:
		func_405(uParam1, "Dreyfuss1", func_407(iParam0), 0, 2, 4, -1458.97f, 485.99f, 115.38f, 66, "LETTERS_HINT", 106,
				 0, "", 0, 0, -1, 4, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 9:
		func_405(uParam1, "Epsilon1", func_407(iParam0), 0, 3, 4, -1622.89f, 4204.87f, 83.3f, 66, "", 86, 0, "", 0, 1,
				 10, 4, 1, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 10:
		func_405(uParam1, "Epsilon2", func_407(iParam0), 0, 3, 4, 242.7f, 362.7f, 104.74f, 206, "", 87, 16, "", 0, 0,
				 11, 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 11:
		func_405(uParam1, "Epsilon3", func_407(iParam0), 0, 3, 4, 1835.53f, 4705.86f, 38.1f, 206, "", 88, 16, "epsCars",
				 0, 0, 12, 4, 1, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 12:
		func_405(uParam1, "Epsilon4", func_407(iParam0), 0, 3, 4, 1826.13f, 4698.88f, 38.92f, 206, "", 90, 16,
				 "postRC_Epsilon4", 0, 0, 13, 4, 1, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 13:
		func_405(uParam1, "Epsilon5", func_407(iParam0), 0, 3, 4, 637.02f, 119.7093f, 89.5f, 206, "", 89, 16,
				 "epsRobes", 0, 0, 14, 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 14:
		func_405(uParam1, "Epsilon6", func_407(iParam0), 0, 3, 4, -2892.93f, 3192.37f, 11.66f, 206, "", 93, 0, "", 0, 0,
				 15, 4, 1, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 15:
		func_405(uParam1, "Epsilon7", func_407(iParam0), 0, 3, 4, 524.43f, 3079.82f, 39.48f, 206, "", -1, 16,
				 "epsDesert", 0, 0, 16, 4, 1, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 16:
		func_405(uParam1, "Epsilon8", func_407(iParam0), 0, 3, 4, -697.75f, 45.38f, 43.03f, 206, "", 94, 16,
				 "epsilonTract", 0, 0, -1, 4, 1, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 17:
		func_405(uParam1, "Extreme1", func_407(iParam0), 0, 4, 4, -188.22f, 1296.1f, 302.86f, 66, "", -1, 0, "", 4, 1,
				 18, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 18:
		func_405(uParam1, "Extreme2", func_407(iParam0), 0, 4, 4, -954.19f, -2760.05f, 14.64f, 382, "", 96, 0, "", 171,
				 0, 19, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 19:
		func_405(uParam1, "Extreme3", func_407(iParam0), 0, 4, 4, -63.8f, -809.5f, 321.8f, 382, "", 97, 0, "", 0, 0, 20,
				 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 20:
		func_405(uParam1, "Extreme4", func_407(iParam0), 0, 4, 4, 1731.41f, 96.96f, 170.39f, 382, "", 98, 16, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 21:
		func_405(uParam1, "Fanatic1", func_407(iParam0), 0, 5, 4, -1877.82f, -440.649f, 45.05f, 405, "", 74, 0, "", 0,
				 1, -1, 4, 1, 700, 2000, func_406(iParam0), 1, 0);
		break;

	case 22:
		func_405(uParam1, "Fanatic2", func_407(iParam0), 0, 5, 4, 809.66f, 1279.76f, 360.49f, 405, "", -1, 0, "", 0, 1,
				 -1, 4, 4, 700, 2000, func_406(iParam0), 1, 0);
		break;

	case 23:
		func_405(uParam1, "Fanatic3", func_407(iParam0), 0, 5, 4, -915.6f, 6139.2f, 5.5f, 405, "", -1, 0, "", 0, 1, -1,
				 4, 2, 700, 2000, func_406(iParam0), 0, 1);
		break;

	case 24:
		func_405(uParam1, "Hao1", func_407(iParam0), 0, 6, 4, -72.29f, -1260.63f, 28.14f, 66, "", -1, 0,
				 "controller_Races", 13, 1, -1, 4, 2, 2000, 500, func_406(iParam0), 0, 1);
		break;

	case 25:
		func_405(uParam1, "Hunting1", func_407(iParam0), 0, 7, 4, 1804.32f, 3931.33f, 32.82f, 66, "", -1, 0, "", 174, 1,
				 26, 4, 4, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 26:
		func_405(uParam1, "Hunting2", func_407(iParam0), 0, 7, 4, -684.17f, 5839.16f, 16.09f, 384, "", 99, 0, "", 7, 0,
				 -1, 4, 4, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 27:
		func_405(uParam1, "Josh1", func_407(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 66, "", -1, 0, "forSaleSigns",
				 0, 1, 28, 4, 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 28:
		func_405(uParam1, "Josh2", func_407(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", 105, 0, "", 0, 0,
				 29, 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 29:
		func_405(uParam1, "Josh3", func_407(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", -1, 16, "", 0, 0,
				 30, 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 30:
		func_405(uParam1, "Josh4", func_407(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 385, "", -1, 36, "", 0, 0, -1,
				 4, 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 31:
		func_405(uParam1, "Maude1", func_407(iParam0), 0, 9, 4, 2726.1f, 4145f, 44.3f, 66, "", -1, 0,
				 "BailBond_Launcher", 0, 1, -1, 4, 4, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 32:
		func_405(uParam1, "Minute1", func_407(iParam0), 0, 10, 4, 327.85f, 3405.7f, 35.73f, 66, "", -1, 0, "", 0, 1, 33,
				 4, 4, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 33:
		func_405(uParam1, "Minute2", func_407(iParam0), 0, 10, 4, 18f, 4527f, 105f, 386, "", -1, 10, "", 0, 0, 34, 4, 4,
				 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 34:
		func_405(uParam1, "Minute3", func_407(iParam0), 0, 10, 4, -303.82f, 6211.29f, 31.05f, 386, "", -1, 10, "", 0, 0,
				 -1, 4, 4, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 35:
		func_405(uParam1, "MrsPhilips1", func_407(iParam0), 0, 11, 4, 1972.59f, 3816.43f, 32.42f, 66, "", -1, 0,
				 "ambient_MrsPhilips", 0, 1, -1, 4, 4, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 36:
		func_405(uParam1, "MrsPhilips2", func_407(iParam0), 0, 11, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 1, -1, 4, 4, 0,
				 2359, func_406(iParam0), 0, 0);
		break;

	case 37:
		func_405(uParam1, "Nigel1", func_407(iParam0), 0, 12, 4, -1097.16f, 790.01f, 164.52f, 66, "", -1, 0, "", 177, 1,
				 -1, 1, 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 38:
		func_405(uParam1, "Nigel1A", func_407(iParam0), 0, 12, 1, -558.65f, 284.49f, 90.86f, 149, "NIGITEMS", 100, 0,
				 "", 0, 0, 42, 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 39:
		func_405(uParam1, "Nigel1B", func_407(iParam0), 0, 12, 1, -1034.15f, 366.08f, 80.11f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_406(iParam0), 1, 1);
		break;

	case 40:
		func_405(uParam1, "Nigel1C", func_407(iParam0), 0, 12, 1, -623.91f, -266.17f, 37.76f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_406(iParam0), 1, 1);
		break;

	case 41:
		func_405(uParam1, "Nigel1D", func_407(iParam0), 0, 12, 1, -1096.85f, 67.68f, 52.95f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_406(iParam0), 1, 1);
		break;

	case 42:
		func_405(uParam1, "Nigel2", func_407(iParam0), 0, 12, 4, -1310.7f, -640.22f, 26.54f, 149, "", -1, 8, "", 0, 0,
				 43, 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 43:
		func_405(uParam1, "Nigel3", func_407(iParam0), 0, 12, 4, -44.75f, -1288.67f, 28.21f, 149, "", -1, 16,
				 "postRC_Nigel3", 0, 0, -1, 4, 4, 0, 2359, func_406(iParam0), 1, 1);
		break;

	case 44:
		func_405(uParam1, "Omega1", func_407(iParam0), 0, 13, 4, 2468.51f, 3437.39f, 49.9f, 66, "", -1, 0,
				 "spaceshipParts", 0, 1, 45, 4, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 45:
		func_405(uParam1, "Omega2", func_407(iParam0), 0, 13, 4, 2319.44f, 2583.58f, 46.76f, 387, "", 107, 0, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 46:
		func_405(uParam1, "Paparazzo1", func_407(iParam0), 0, 14, 4, -149.75f, 285.81f, 93.67f, 66, "", -1, 0, "", 0, 1,
				 47, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 47:
		func_405(uParam1, "Paparazzo2", func_407(iParam0), 0, 14, 4, -70.71f, 301.43f, 106.79f, 389, "", -1, 8, "", 0,
				 0, 48, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 48:
		func_405(uParam1, "Paparazzo3", func_407(iParam0), 0, 14, 4, -257.22f, 292.85f, 90.63f, 389, "", -1, 8, "", 183,
				 1, -1, 2, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 49:
		func_405(uParam1, "Paparazzo3A", func_407(iParam0), 0, 14, 2, 305.52f, 157.19f, 102.94f, 389, "PAPPHOTO", 102,
				 0, "", 0, 0, 51, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 50:
		func_405(uParam1, "Paparazzo3B", func_407(iParam0), 0, 14, 2, 1040.96f, -534.42f, 60.17f, 389, "", 102, 0, "",
				 0, 0, 51, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 51:
		func_405(uParam1, "Paparazzo4", func_407(iParam0), 0, 14, 4, -484.2f, 229.68f, 82.21f, 389, "", -1, 8, "", 0, 1,
				 -1, 4, 2, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 52:
		func_405(uParam1, "Rampage1", func_407(iParam0), 0, 15, 4, 908f, 3643.7f, 32.2f, 66, "", -1, 0, "", 0, 1, 54, 4,
				 4, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 54:
		func_405(uParam1, "Rampage3", func_407(iParam0), 0, 15, 4, 465.1f, -1849.3f, 27.8f, 84, "", -1, 0, "", 0, 1, 55,
				 4, 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 55:
		func_405(uParam1, "Rampage4", func_407(iParam0), 0, 15, 4, -161f, -1669.7f, 33f, 84, "", -1, 0, "", 0, 0, 56, 4,
				 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 56:
		func_405(uParam1, "Rampage5", func_407(iParam0), 0, 15, 4, -1298.2f, 2504.14f, 21.09f, 84, "", -1, 0, "", 0, 0,
				 53, 4, 4, 0, 2359, func_406(iParam0), 0, 0);
		break;

	case 53:
		func_405(uParam1, "Rampage2", func_407(iParam0), 0, 15, 4, 1181.5f, -400.1f, 67.5f, 84, "", -1, 0,
				 "rampage_controller", 0, 0, -1, 4, 4, 0, 2359, func_406(iParam0), 1, 0);
		break;

	case 57:
		func_405(uParam1, "TheLastOne", func_407(iParam0), 0, 16, 4, -1298.98f, 4640.16f, 105.67f, 66, "", 133, 1, "",
				 0, 1, -1, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 58:
		func_405(uParam1, "Tonya1", func_407(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 66, "AM_H_RCFS", -1, 0,
				 "ambient_TonyaCall", 24, 1, 59, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 59:
		func_405(uParam1, "Tonya2", func_407(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48,
				 "ambient_Tonya", 185, 0, 60, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	case 60:
		func_405(uParam1, "Tonya3", func_407(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 187, 0, 61, 4, 2, 0,
				 2359, func_406(iParam0), 0, 1);
		break;

	case 61:
		func_405(uParam1, "Tonya4", func_407(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 0, 62, 4, 2, 0, 2359,
				 func_406(iParam0), 0, 1);
		break;

	case 62:
		func_405(uParam1, "Tonya5", func_407(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_406(iParam0), 0, 1);
		break;

	default: break;
	}
}

// Position - 0x2C113
void func_405(var *uParam0, char *sParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6, vector3 vParam7,
			  int iParam10, char *sParam11, int iParam12, int iParam13, char *sParam14, int iParam15, int iParam16,
			  int iParam17, int iParam18, int iParam19, int iParam20, int iParam21, int iParam22, int iParam23,
			  int iParam24) {
	uParam0->f_4 = iParam5;
	*uParam0 = sParam1;
	uParam0->f_1 = {Param2};
	uParam0->f_3 = iParam4;
	uParam0->f_5 = iParam6;
	uParam0->f_6 = {vParam7};
	uParam0->f_9 = iParam10;
	StringCopy(&uParam0->f_10, sParam11, 16);
	uParam0->f_14 = iParam12;
	uParam0->f_15 = iParam13;
	StringCopy(&uParam0->f_16, sParam14, 24);
	uParam0->f_22 = iParam15;
	uParam0->f_23 = iParam16;
	uParam0->f_24 = iParam17;
	uParam0->f_25 = iParam18;
	uParam0->f_26 = iParam19;
	uParam0->f_27 = iParam20;
	uParam0->f_28 = iParam21;
	uParam0->f_29 = iParam22;
	uParam0->f_30 = iParam23;
	uParam0->f_31 = iParam24;
}

// Position - 0x2C1A4
int func_406(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 0;

	case 2: return 1;

	case 3: return 1;

	case 4: return 0;

	case 5: return 1;

	case 6: return 1;

	case 7: return 0;

	case 8: return 1;

	case 9: return 0;

	case 10: return 0;

	case 11: return 0;

	case 12: return 1;

	case 13: return 0;

	case 14: return 1;

	case 15: return 0;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 1;

	case 23: return 1;

	case 24: return 1;

	case 25: return 1;

	case 26: return 1;

	case 27: return 0;

	case 28: return 1;

	case 29: return 1;

	case 30: return 1;

	case 31: return 0;

	case 32: return 1;

	case 33: return 1;

	case 34: return 1;

	case 35: return 0;

	case 36: return 0;

	case 37: return 0;

	case 38: return 1;

	case 39: return 1;

	case 40: return 1;

	case 41: return 1;

	case 42: return 1;

	case 43: return 1;

	case 44: return 0;

	case 45: return 0;

	case 46: return 1;

	case 47: return 1;

	case 48: return 0;

	case 49: return 1;

	case 50: return 1;

	case 51: return 1;

	case 52: return 1;

	case 54: return 1;

	case 55: return 1;

	case 56: return 1;

	case 53: return 1;

	case 57: return 1;

	case 58: return 1;

	case 59: return 1;

	case 60: return 1;

	case 61: return 1;

	case 62: return 1;

	default: break;
	}
	return 0;
}

// Position - 0x2C4EA
struct<2> func_407(int iParam0) {
	struct<2> Var0;
	char[] cVar2[8];

	StringCopy(&Var0, "", 8);
	cVar2 = {func_402(iParam0)};
	if (gameplay::is_string_null_or_empty(&cVar2)) {
	}
	else {
		StringCopy(&Var0, "RC_", 8);
		StringConCat(&Var0, &cVar2, 8);
	}
	return Var0;
}

//Position - 0x2C522
int func_408(int iParam0)
{
	switch (iParam0) {
	case 69:
	case 70: return func_409(Global_101700.f_8044.f_99.f_205[10]);

	case 74:
	case 75: return func_409(Global_101700.f_8044.f_99.f_205[8]);

	case 84:
	case 85: return func_409(Global_101700.f_8044.f_99.f_205[11]);

	case 90: return func_409(Global_101700.f_8044.f_99.f_205[7]);

	case 93: return func_409(Global_101700.f_8044.f_99.f_205[9]);
	}
	return 0;
}

// Position - 0x2C5DE
int func_409(int iParam0) {
	switch (iParam0) {
	case 1:
	case 3:
	case 5:
	case 6:
	case 8: return 0;

	case 2:
	case 4:
	case 7:
	case 9: return 1;
	}
	return -1;
}

// Position - 0x2C632
int func_410(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = gameplay::get_hash_key(sParam0);
	iVar1 = func_411(iVar0, 1);
	if (iVar1 == -1 && !iParam1) {
	}
	return iVar1;
}

// Position - 0x2C65C
int func_411(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 94) {
		if (Global_82612[iVar0 /*34*/].f_6 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	if (!iParam1) {
	}
	return -1;
}

// Position - 0x2C692
void func_412(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x2C914
void func_413(int iParam0) {
	func_342(iParam0);
	graphics::_set_far_shadows_suppressed(1);
	vehicle::set_all_vehicle_generators_active();
	player::set_wanted_level_multiplier(1f);
	player::set_max_wanted_level(5);
	gameplay::enable_dispatch_service(3, 1);
	func_205(0);
	func_88();
	ui::clear_prints();
	if (pathfind::does_navmesh_blocking_object_exist(iLocal_2510)) {
		pathfind::remove_navmesh_blocking_object(iLocal_2510);
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		weapon::remove_weapon_from_ped(player::player_ped_id(), joaat("weapon_petrolcan"));
		ai::clear_ped_tasks(player::player_ped_id());
	}
	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (interior::get_interior_from_entity(player::player_ped_id()) != 0) {
			if (func_67(player::player_ped_id(), 2444.098f, 4977.795f, 48.9959f, 1) < 100f) {
				entity::set_entity_coords(player::player_ped_id(), 2463.811f, 4961.747f, 44.176f, 1, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), 20f);
			}
		}
	}
	if (iParam0 == 1 || iParam0 == 2) {
		func_19(50, 0, 0, 1, 0);
		func_19(51, 0, 0, 1, 0);
		func_19(52, 0, 0, 1, 0);
		func_19(53, 0, 0, 1, 0);
		func_19(54, 0, 0, 1, 0);
		func_19(55, 0, 0, 1, 0);
	}
	script::terminate_this_thread();
}

// Position - 0x2CA2C
void func_414() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_141(0)) {
		if (!func_415()) {
			iVar0 = func_140();
			if (iVar0 != -1) {
				if (!func_134(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_139();
		}
	}
}

// Position - 0x2CA9D
int func_415() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
int iLocal_36 = 0;
int iLocal_37 = 0;
int iLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int *iLocal_42 = NULL;
int iLocal_43 = 0;
int iLocal_44 = 0;
int iLocal_45 = 0;
int iLocal_46 = 0;
int iLocal_47 = 0;
int iLocal_48 = 0;
var *uLocal_49[4] = {NULL, NULL, NULL, NULL};
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 4;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 4;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 4;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 4;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 4;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 4;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
int iLocal_93 = 0;
int iLocal_94 = 0;
struct<485> Local_95 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 20, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, -1, -1, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 16
};
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 0;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 0;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 0;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 0;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
var uLocal_726 = 0;
var uLocal_727 = 0;
var uLocal_728 = 0;
var uLocal_729 = 0;
var uLocal_730 = 0;
var uLocal_731 = 0;
var uLocal_732 = 0;
var uLocal_733 = 0;
var uLocal_734 = 0;
var uLocal_735 = 0;
var uLocal_736 = 0;
var uLocal_737 = 0;
var uLocal_738 = 0;
var uLocal_739 = 0;
var uLocal_740 = 0;
var uLocal_741 = 0;
var uLocal_742 = 0;
var uLocal_743 = 0;
var uLocal_744 = 0;
var uLocal_745 = 0;
var uLocal_746 = 0;
var uLocal_747 = 0;
var uLocal_748 = 0;
var uLocal_749 = 0;
var uLocal_750 = 0;
var uLocal_751 = 0;
var uLocal_752 = 0;
var uLocal_753 = 0;
var uLocal_754 = 0;
var uLocal_755 = 0;
var uLocal_756 = 0;
var uLocal_757 = 0;
var uLocal_758 = 0;
var uLocal_759 = 0;
var uLocal_760 = 0;
var uLocal_761 = 0;
var uLocal_762 = 0;
var uLocal_763 = 0;
var uLocal_764 = 0;
var uLocal_765 = 0;
var uLocal_766 = 0;
var uLocal_767 = 0;
var uLocal_768 = 0;
var uLocal_769 = 0;
var uLocal_770 = 0;
var uLocal_771 = 0;
var uLocal_772 = 0;
var uLocal_773 = 0;
var uLocal_774 = 0;
var uLocal_775 = 0;
var uLocal_776 = 0;
var uLocal_777 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_36 = 202;
	iLocal_37 = 201;
	iLocal_38 = 24;
	iLocal_39 = 202;
	iLocal_40 = 25;
	iLocal_42 = -1;
	iLocal_43 = -1;
	iLocal_44 = -1;
	iLocal_94 = -1;
	if (player::has_force_cleanup_occurred(82)) {
		func_330();
	}
	func_329(0);
	func_317(&Local_95.f_1, func_328(Global_87853[6 /*19*/], Global_87853[7 /*19*/]));
	func_316(&Local_95, 3);
	while (!func_315(2)) {
		if (!G_TextMessageConfig) {
			func_313();
			if (func_312(3, 0)) {
				if (!func_311(66)) {
					if (!gameplay::is_bit_set(iLocal_41, 8)) {
						Local_95.f_1.f_141[0 /*2*/] = 302;
						Local_95.f_1.f_141[0 /*2*/].f_1 = 191;
						Local_95.f_1.f_141[1 /*2*/] = 309;
						Local_95.f_1.f_141[1 /*2*/].f_1 = 109;
						Local_95.f_1.f_141[2 /*2*/] = 196;
						Local_95.f_1.f_141[2 /*2*/].f_1 = 318;
						Local_95.f_1.f_141[3 /*2*/] = 220;
						Local_95.f_1.f_141[3 /*2*/].f_1 = 227;
						gameplay::set_bit(&iLocal_41, 8);
					}
				}
				else if (!gameplay::is_bit_set(iLocal_41, 9)) {
					Local_95.f_1.f_141[0 /*2*/] = 0;
					Local_95.f_1.f_141[0 /*2*/].f_1 = 0;
					Local_95.f_1.f_141[1 /*2*/] = 0;
					Local_95.f_1.f_141[1 /*2*/].f_1 = 0;
					Local_95.f_1.f_141[2 /*2*/] = 0;
					Local_95.f_1.f_141[2 /*2*/].f_1 = 0;
					Local_95.f_1.f_141[3 /*2*/] = 0;
					Local_95.f_1.f_141[3 /*2*/].f_1 = 0;
					gameplay::set_bit(&iLocal_41, 9);
				}
			}
			func_312(3, 0);
			if (Global_101700.f_6220.f_227[71] == 1 && !func_310(14)) {
				func_299(&Local_95, 40f, 50f);
				func_297(&Local_95);
				func_275();
				func_148();
			}
			else if (gameplay::is_bit_set(Local_95.f_449, 0)) {
				func_144(&Local_95);
			}
			if (func_142(0) || gameplay::is_bit_set(Local_95.f_449, 2)) {
				func_68(&Local_95);
				func_6(&Local_95);
				func_5(&Local_95);
			}
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("agency_heist3a")) > 0 ||
			script::_get_number_of_instances_of_script_with_name_hash(joaat("agency_heist3b")) > 0) {
			func_4();
		}
		if (func_315(12)) {
			if (!func_3(0)) {
				if (!gameplay::is_bit_set(Global_101700.f_1.f_120[3], 8)) {
					func_2(3, 8, 1);
				}
			}
			else if (gameplay::is_bit_set(Global_101700.f_1.f_120[3], 8)) {
				func_2(3, 8, 0);
			}
		}
		else if (gameplay::is_bit_set(Global_101700.f_1.f_120[3], 8)) {
			func_2(3, 8, 0);
		}
		system::wait(0);
	}
	func_1(0);
	func_330();
}

// Position - 0x2EA
int func_1(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
		return 1;
	}
	return 0;
}

// Position - 0x344
void func_2(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_1.f_120[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_1.f_120[iParam0], iParam1);
	}
	gameplay::set_bit(&Global_87832, iParam0);
}

// Position - 0x382
bool func_3(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x3AD
void func_4() {
	int iVar0;

	if (Global_69962) {
		return;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return;
	}
	iVar0 = system::round(1f + 1000f * system::timestep());
	Global_88044.f_8 += iVar0;
}

// Position - 0x3EF
void func_5(var *uParam0) {
	if (gameplay::is_bit_set(Global_87832, *uParam0)) {
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			gameplay::set_bit(&uParam0->f_449, 15);
			gameplay::set_bit(&uParam0->f_449, 16);
			gameplay::set_bit(&uParam0->f_449, 14);
			gameplay::clear_bit(&Global_87832, *uParam0);
		}
	}
}

// Position - 0x43E
void func_6(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = func_66(func_67(*uParam0));
	if (iVar0 < 0 || iVar0 >= 5) {
		return;
	}
	iVar1 = iVar0;
	if (iVar1 != uParam0->f_464 && !(iVar1 == 2 && uParam0->f_464 == 4) &&
		!(*uParam0 == 1 && iVar1 == 3 && uParam0->f_464 == 4)) {
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			func_7(uParam0, iVar1, 0);
		}
		else {
			uParam0->f_464 = iVar1;
		}
	}
}

// Position - 0x4CC
void func_7(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 != uParam0->f_464) {
		if (uParam0->f_680 == 0) {
			func_65(uParam0);
			uParam0->f_464 = iParam1;
			func_8(uParam0, iParam1, iParam2);
		}
	}
}

// Position - 0x4FE
void func_8(var *uParam0, int iParam1, int iParam2) {
	switch (iParam1) {
	case 0:
		func_64(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		break;

	case 1:
		func_64(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		uParam0->f_452 = -1;
		break;

	case 2:
		func_36(uParam0, uParam0->f_417, iParam2);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		uParam0->f_457 = gameplay::get_game_timer();
		break;

	case 3:
		func_19(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		gameplay::set_bit(&uParam0->f_449, 9);
		uParam0->f_457 = gameplay::get_game_timer();
		break;

	case 4:
		func_15(&uParam0->f_1.f_108[0 /*4*/], 1);
		func_15(&uParam0->f_1.f_108[1 /*4*/], 1);
		Global_101700.f_1.f_6[*uParam0] = 1;
		ui::clear_help(0);
		func_13(uParam0, 0);
		func_64(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::set_bit(&uParam0->f_449, 4);
		uParam0->f_457 = gameplay::get_game_timer();
		break;
	}
	func_9(uParam0);
}

// Position - 0x62B
void func_9(var *uParam0) {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	char *sVar3;
	char *sVar4;
	char *sVar5;
	bool bVar6;

	sVar0 = controls::_0x80C2FD58D720C801(2, 13, 1);
	sVar1 = controls::_0x80C2FD58D720C801(2, 11, 1);
	sVar2 = controls::get_control_instructional_button(0, 32, 1);
	sVar3 = controls::_0x80C2FD58D720C801(0, 1, 1);
	sVar4 = controls::get_control_instructional_button(2, 201, 1);
	sVar5 = controls::get_control_instructional_button(2, 202, 1);
	if (controls::_is_input_disabled(2)) {
		sVar0 = controls::_0x80C2FD58D720C801(2, 6, 1);
		sVar1 = controls::_0x80C2FD58D720C801(2, 7, 1);
		sVar2 = controls::_0x80C2FD58D720C801(0, 29, 1);
	}
	bVar6 = func_12(1, *uParam0);
	graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_MAX_WIDTH");
	graphics::_push_scaleform_movie_function_parameter_float(0.6f);
	graphics::_pop_scaleform_movie_function_void();
	switch (uParam0->f_464) {
	case 0:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			if (bVar6) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar2);
				func_10("PB_H_ZOOM");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_11(sVar2);
				func_10("PB_H_ZOOM");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar5);
				func_10("PB_H_EXIT");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 1:
		graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 2:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
			graphics::_pop_scaleform_movie_function_void();
			if (*uParam0 == 2) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_11(sVar0);
				func_10("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar4);
				func_10("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(3);
				func_11(sVar0);
				func_10("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar5);
				func_10("PB_H_UNDO");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar4);
				func_10("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 3:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			if (gameplay::is_bit_set(uParam0->f_449, 9)) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar1);
				func_10("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_11(sVar1);
				func_10("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_11(sVar3);
				func_10("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_11(sVar4);
				func_10("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 4:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(3);
			func_11(sVar2);
			func_10("PB_H_ZOOM");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(2);
			func_11(sVar3);
			func_10("PB_H_LOOK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_11(sVar5);
			func_10("PB_H_UNDO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_11(sVar4);
			func_10("PB_H_CONF");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;
	}
}

// Position - 0xB07
void func_10(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0xB19
void func_11(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0xB27
bool func_12(int iParam0, int iParam1) {
	var uVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return false;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return false;
	}
	uVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	return uVar0;
}

// Position - 0xB74
void func_13(var *uParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&uParam0->f_449, 18);
		if (!func_14(&uParam0->f_1.f_20[0 /*4*/]) && !func_14(&uParam0->f_1.f_20[1 /*4*/]) &&
			!func_14(&uParam0->f_1.f_108[0 /*4*/]) && !func_14(&uParam0->f_1.f_108[1 /*4*/])) {
			ui::clear_help(0);
		}
	}
	else {
		gameplay::clear_bit(&uParam0->f_449, 18);
	}
}

// Position - 0xBE9
bool func_14(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0xBFC
void func_15(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_14(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_18(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_17(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_16();
			return;
		}
		iVar0++;
	}
}

// Position - 0xCA9
void func_16() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0xDC9
void func_17(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0xE63
void func_18(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0xF73
void func_19(var *uParam0) {
	int iVar0;
	struct<2> Var1;

	func_35(uParam0);
	func_33(uParam0);
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = func_66(func_32(*uParam0));
	if (iVar0 != 0) {
		if (iVar0 == func_31(*uParam0, 0)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(8);
			graphics::_pop_scaleform_movie_function_void();
		}
		else if (iVar0 == func_31(*uParam0, 1)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
		}
	}
	Var1 = uParam0->f_1.f_16 + uParam0->f_1.f_18;
	Var1.f_1 = uParam0->f_1.f_16.f_1 + uParam0->f_1.f_18.f_1;
	func_27(uParam0, &Var1, uParam0->f_1.f_10);
	func_25(uParam0, 1, 1);
	func_13(uParam0, 0);
	func_20(uParam0);
}

// Position - 0x1046
void func_20(var *uParam0) {
	int iVar0;

	if (gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!gameplay::is_bit_set(uParam0->f_449, 18)) {
			switch (uParam0->f_464) {
			case 3:
				if (!Global_101700.f_1[*uParam0]) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_20[0 /*4*/], "")) {
						func_23(&uParam0->f_1.f_20[0 /*4*/], 3, 0, -1, 10000, 7, 0, 0, 0);
					}
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_20[1 /*4*/], "")) {
						func_23(&uParam0->f_1.f_20[1 /*4*/], 3, 1000, -1, 10000, 7, 0, 0, 0);
					}
					Global_101700.f_1[*uParam0] = 1;
				}
				else if (func_22() && !ui::is_help_message_being_displayed()) {
					if (!gameplay::is_bit_set(uParam0->f_449, 11) && !gameplay::is_bit_set(uParam0->f_449, 10) &&
						!func_21() && uParam0->f_483 == 0) {
						ui::begin_text_command_display_help("PB_H_CHOICE");
						ui::end_text_command_display_help(0, 1, 0, -1);
					}
				}
				break;

			case 2:
				if (!Global_101700.f_1.f_6[*uParam0]) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_108[0 /*4*/], "")) {
						func_23(&uParam0->f_1.f_108[0 /*4*/], 3, 0, -1, 10000, 7, 0, 0, 0);
					}
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_108[1 /*4*/], "")) {
						func_23(&uParam0->f_1.f_108[1 /*4*/], 3, 1000, -1, 10000, 7, 0, 0, 0);
					}
					Global_101700.f_1.f_6[*uParam0] = 1;
				}
				else if (func_22() && !ui::is_help_message_being_displayed()) {
					if (!gameplay::is_bit_set(uParam0->f_449, 10)) {
						if (!func_14("PB_H_GUNM") && !func_14("PB_H_HACK") && !func_14("PB_H_DRIV")) {
							iVar0 = func_66(func_32(*uParam0));
							if (uParam0->f_417 < 5) {
								if (!gameplay::is_bit_set(uParam0->f_449, 11) &&
									!gameplay::is_bit_set(uParam0->f_449, 10) && !func_21() && uParam0->f_483 == 0) {
									switch (Global_87853[iVar0 /*19*/].f_1[uParam0->f_417]) {
									case 1:
										ui::begin_text_command_display_help("PB_H_GUNM");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;

									case 2:
										ui::begin_text_command_display_help("PB_H_HACK");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;

									case 3:
										ui::begin_text_command_display_help("PB_H_DRIV");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;
									}
								}
							}
						}
					}
				}
				break;
			}
		}
	}
}

// Position - 0x12BB
int func_21() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return 1;
	}
	return 0;
}

// Position - 0x12DD
bool func_22() {
	if (Global_101700.f_19369.f_145 > 0) {
		return false;
	}
	return true;
}

// Position - 0x12FA
void func_23(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_24(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x131B
void func_24(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_16();
	}
}

// Position - 0x14EE
void func_25(var *uParam0, int iParam1, int iParam2) {
	if (!gameplay::is_bit_set(uParam0->f_1.f_303, iParam1)) {
		if (!gameplay::are_strings_equal(&uParam0->f_1.f_280[iParam1 /*2*/], "")) {
			func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_280[iParam1 /*2*/], iParam2);
			gameplay::set_bit(&uParam0->f_1.f_303, iParam1);
		}
	}
}

// Position - 0x1548
void func_26(var *uParam0, struct<2> Param1, struct<2> Param3, int iParam5) {
	if (uParam0->f_483 == 3) {
		return;
	}
	if (!gameplay::is_string_null_or_empty(&Param3)) {
		uParam0->f_467[uParam0->f_483 /*5*/] = {Param1};
		uParam0->f_467[uParam0->f_483 /*5*/].f_2 = {Param3};
		uParam0->f_467[uParam0->f_483 /*5*/].f_4 = iParam5;
		uParam0->f_483++;
	}
}

// Position - 0x15A8
void func_27(var *uParam0, var *uParam1, float fParam2) {
	vector3 vVar0;

	uParam0->f_411 = *uParam1;
	uParam0->f_411.f_1 = uParam1->f_1;
	uParam0->f_454 = gameplay::get_game_timer() + 1000;
	vVar0 = {func_29(uParam0, &uParam0->f_411)};
	func_28(&uParam0->f_649, vVar0, fParam2);
}

// Position - 0x15ED
void func_28(var *uParam0, vector3 vParam1, float fParam4) {
	uParam0->f_11 = {vParam1};
	if (fParam4 != -1f) {
		uParam0->f_7 = fParam4;
	}
}

// Position - 0x160C
Vector3 func_29(var *uParam0, var *uParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	vector3 vVar7;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;
	float fVar14;
	float fVar15;
	float fVar16;

	fVar0 = uParam0->f_1.f_4;
	fVar1 = uParam0->f_1.f_5;
	func_30(uParam0, uParam1, &fVar2, &fVar3);
	fVar4 = fVar0 * (fVar2 - 0.5f);
	fVar5 = -fVar1 * (fVar3 - 0.5f);
	fVar6 = uParam0->f_404;
	vVar7 = {uParam0->f_401};
	vVar7 = {vVar7 + Vector(fVar5, fVar4 * system::cos(90f - fVar6), fVar4 * system::sin(90f - fVar6))};
	fVar10 = fVar4;
	fVar11 = gameplay::atan(fVar10 / uParam0->f_1.f_8);
	fVar12 = uParam0->f_401.f_2 - uParam0->f_649.f_1.f_2;
	fVar13 = vVar7.z - uParam0->f_649.f_1.f_2;
	fVar14 = fVar13 - fVar12;
	fVar15 = gameplay::atan(fVar14 / uParam0->f_1.f_8);
	fVar16 = fVar11 * 3f / 18f;
	return fVar15 * 0.95f, fVar16, -fVar11 * 0.85f;
}

// Position - 0x16F1
void func_30(var *uParam0, var *uParam1, float *fParam2, float *fParam3) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0->f_1.f_2;
	iVar1 = uParam0->f_1.f_3;
	if (*uParam1 < 0 || *uParam1 > iVar0) {
		return;
	}
	if (uParam1->f_1 < 0 || uParam1->f_1 > iVar1) {
		return;
	}
	*fParam2 = system::to_float(*uParam1) / system::to_float(iVar0);
	*fParam3 = system::to_float(uParam1->f_1) / system::to_float(iVar1);
}

// Position - 0x175C
int func_31(int iParam0, int iParam1) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: return 2;

		case 1: return 1;

		default: break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: return 3;

		case 1: return 4;

		default: break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return 5;

		default: break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: return 6;

		case 1: return 7;

		default: break;
		}
		break;

	case 4:
		switch (iParam1) {
		case 0: return 8;

		case 1: return 9;

		default: break;
		}
		break;
	}
	return 0;
}

// Position - 0x1842
int func_32(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: iVar0 = 7; break;

	case 1: iVar0 = 8; break;

	case 2: iVar0 = 9; break;

	case 3: iVar0 = 10; break;

	case 4: iVar0 = 11; break;
	}
	return iVar0;
}

// Position - 0x1893
void func_33(var *uParam0) {
	int iVar0;

	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_push_scaleform_movie_function_parameter_int(1);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_16));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_16.f_1));
	graphics::_pop_scaleform_movie_function_void();
	func_34(uParam0);
	switch (*uParam0) {
	case 0:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(2);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 1:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(3);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(4);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 3:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(6);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(7);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 4:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(9);
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_push_scaleform_movie_function_parameter_bool(func_312(*uParam0, uParam0->f_1.f_29));
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = func_66(func_32(*uParam0));
	if (iVar0 != 0) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_pop_scaleform_movie_function_void();
		if (iVar0 == func_31(*uParam0, 0)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(8);
			graphics::_pop_scaleform_movie_function_void();
		}
		else if (iVar0 == func_31(*uParam0, 1)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(99);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x1B00
void func_34(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_LABELS");
	func_10("H_CRW_NAME");
	func_10("H_CRW_TYPE");
	func_10("H_CRW_SKILLS");
	switch (*uParam0) {
	case 0: func_10("H_LBL_JWL"); break;

	case 1: func_10("H_LBL_DOC"); break;

	case 2: func_10("H_LBL_RUR"); break;

	case 3: func_10("H_LBL_AGN"); break;

	case 4:
		func_10("H_LBL_FA");
		func_10("H_LBL_FB");
		break;
	}
	if (*uParam0 != 1) {
		func_10("H_LBL_CRW");
	}
	func_10("H_LBL_TODO");
	if (*uParam0 != 2) {
		func_10("H_LBL_APP");
	}
	switch (*uParam0) {
	case 0:
		func_10("H_LBL_J1");
		func_10("H_LBL_J2");
		func_10("H_LBL_J3");
		func_10("H_LBL_J4");
		func_10("HC_J_IMPACT");
		func_10("HC_J_STEALTH");
		break;

	case 1:
		func_10("HC_D_BLOW_UP");
		func_10("HC_D_DEEP_SEA");
		break;

	case 2:
		func_10("H_LBL_R1");
		func_10("H_LBL_R2");
		func_10("H_LBL_R3");
		func_10("H_LBL_R4");
		func_10("H_LBL_R5");
		func_10("H_LBL_R6");
		func_10("H_LBL_R7");
		func_10("H_LBL_R8");
		func_10("H_LBL_R9");
		func_10("H_LBL_R10");
		func_10("H_LBL_R11");
		func_10("H_LBL_R12");
		break;

	case 3:
		func_10("H_LBL_A1");
		func_10("H_LBL_A2");
		func_10("H_LBL_A3");
		func_10("H_LBL_A4");
		func_10("H_LBL_A5");
		func_10("HC_A_FIRETRUCK");
		func_10("HC_A_HELICOPTER");
		break;

	case 4:
		func_10("H_LBL_F1");
		func_10("H_LBL_F2");
		func_10("H_LBL_F3");
		func_10("H_LBL_F4");
		func_10("H_LBL_F5");
		func_10("HC_F_TRAFFCONT");
		func_10("HC_F_HELI");
		break;
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1D02
void func_35(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1D24
void func_36(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam1 < 0 || iParam1 >= uParam0->f_1.f_96) {
		return;
	}
	func_25(uParam0, 2, 1);
	iVar0 = func_66(func_32(*uParam0));
	iVar1 = Global_87853[iVar0 /*19*/].f_1[iParam1];
	switch (iVar1) {
	case 1: func_63(uParam0, iVar0, 1); break;

	case 2: func_63(uParam0, iVar0, 3); break;

	case 3: func_63(uParam0, iVar0, 2); break;
	}
	func_62(uParam0, uParam0->f_417);
	func_37(uParam0, uParam0->f_417);
	uParam0->f_450 = iParam1;
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_bool(1);
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
	func_27(uParam0, &uParam0->f_1.f_97[iParam1 /*2*/], uParam0->f_1.f_10);
	if (iParam2 != 0) {
		iVar2 = 0;
		while (uParam0->f_418[iVar2] != iParam2) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
			iVar2++;
			if (iVar2 > 7) {
				return;
			}
		}
	}
	func_13(uParam0, 0);
	func_20(uParam0);
}

// Position - 0x1E5A
void func_37(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = func_32(*uParam0);
	iVar1 = func_66(iVar0);
	iVar2 = Global_87853[iVar1 /*19*/].f_1[iParam1];
	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(0);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_97[iParam1 /*2*/]));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_97[iParam1 /*2*/].f_1));
	graphics::_pop_scaleform_movie_function_void();
	func_34(uParam0);
	iVar3 = 0;
	if (Global_101700.f_1.f_12[iVar1 /*6*/][iParam1] != 0) {
		iVar4 = Global_101700.f_1.f_12[iVar1 /*6*/][iParam1];
		func_42(uParam0->f_413, iVar4, iParam1, iVar3, iVar4);
	}
	else {
		iVar5 = 0;
		while (iVar5 < 14) {
			iVar6 = iVar5;
			if (func_41(iVar6) == iVar2) {
				if (func_40(iVar6)) {
					if (!func_39(iVar6)) {
						if (!func_38(uParam0, iVar6)) {
							if (!(iVar6 == 11 && *uParam0 == 3)) {
								func_42(uParam0->f_413, iVar6, iParam1, iVar3, iVar5);
								uParam0->f_418[iVar3] = iVar6;
								iVar3++;
							}
						}
					}
				}
			}
			iVar5++;
		}
	}
	if (Global_101700.f_1.f_12[iVar1 /*6*/][iParam1] != 0) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(iParam1);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	else {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(iParam1);
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1FE4
bool func_38(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_66(func_32(*uParam0));
	iVar1 = 0;
	while (iVar1 < uParam0->f_417) {
		if (Global_101700.f_1.f_12[iVar0 /*6*/][iVar1] == iParam1) {
			return true;
		}
		iVar1++;
	}
	return false;
}

// Position - 0x2029
bool func_39(int iParam0) { return gameplay::is_bit_set(Global_101700.f_1.f_118, iParam0); }

// Position - 0x203F
bool func_40(int iParam0) { return gameplay::is_bit_set(Global_101700.f_1.f_116, iParam0); }

// Position - 0x2055
int func_41(int iParam0) { return Global_87699[iParam0 /*5*/]; }

// Position - 0x2065
void func_42(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_push_scaleform_movie_function_parameter_int(iParam3);
	graphics::_push_scaleform_movie_function_parameter_int(iParam4);
	func_10(func_60(iParam1));
	func_10(func_59(iParam1));
	switch (func_41(iParam1)) {
	case 1:
		func_10(func_58(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_55(iParam1, 0));
		func_10(func_58(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_55(iParam1, 1));
		func_10(func_58(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_55(iParam1, 2));
		func_10(func_58(3));
		graphics::_push_scaleform_movie_function_parameter_int(func_55(iParam1, 3));
		break;

	case 2:
		func_10(func_54(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_51(iParam1, 0));
		func_10(func_54(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_51(iParam1, 1));
		func_10(func_54(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_51(iParam1, 2));
		break;

	case 3:
		func_10(func_49(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_44(iParam1, 0));
		func_10(func_49(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_44(iParam1, 1));
		func_10(func_49(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_44(iParam1, 2));
		break;
	}
	func_10("H_CRW_CUT");
	graphics::_push_scaleform_movie_function_parameter_int(func_43(iParam1));
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x21A1
var func_43(int iParam0) { return Global_87699[iParam0 /*5*/].f_1; }

// Position - 0x21B3
var func_44(int iParam0, int iParam1) {
	return system::round(system::to_float(func_46(iParam0, iParam1)) / system::to_float(func_45(iParam1)) * 100f);
}

// Position - 0x21DC
int func_45(int iParam0) {
	switch (iParam0) {
	case 0: return 100;

	case 1: return 100;

	case 2: return 100;
	}
	return 0;
}

// Position - 0x2216
int func_46(int iParam0, int iParam1) {
	if (func_41(iParam0) != 3) {
		return -1;
	}
	return func_47(iParam0, iParam1);
}

// Position - 0x2234
int func_47(int iParam0, int iParam1) {
	return func_48(iParam1, Global_101700.f_1.f_73[iParam0 /*3*/].f_1, Global_101700.f_1.f_73[iParam0 /*3*/].f_2);
}

// Position - 0x225E
int func_48(int iParam0, int iParam1, int iParam2) {
	switch (iParam0) {
	case 0:
	case 1: return system::shift_right(iParam1, 15 * iParam0) & 32767;

	case 2:
	case 3: return system::shift_right(iParam2, 15 * (iParam0 - 2)) & 32767;
	}
	return -1;
}

// Position - 0x22B2
char *func_49(int iParam0) { return func_50(3, iParam0); }

// Position - 0x22C1
char *func_50(int iParam0, int iParam1) {
	switch (iParam0) {
	case 1:
		switch (iParam1) {
		case 0: return "HC_STA_G1";

		case 1: return "HC_STA_G2";

		case 2: return "HC_STA_G3";

		case 3: return "HC_STA_G4";
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return "HC_STA_H1";

		case 1: return "HC_STA_H2";

		case 2: return "HC_STA_H3";
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: return "HC_STA_D1";

		case 1: return "HC_STA_D2";

		case 2: return "HC_STA_D3";
		}
		break;
	}
	return "ERROR!";
}

// Position - 0x23A4
var func_51(int iParam0, int iParam1) {
	return system::round(system::to_float(func_53(iParam0, iParam1)) / system::to_float(func_52(iParam1)) * 100f);
}

// Position - 0x23CD
int func_52(int iParam0) {
	switch (iParam0) {
	case 0: return 100;

	case 1: return 100;

	case 2: return 100;
	}
	return 0;
}

// Position - 0x2407
int func_53(int iParam0, int iParam1) {
	if (func_41(iParam0) != 2) {
		return -1;
	}
	return func_47(iParam0, iParam1);
}

// Position - 0x2425
char *func_54(int iParam0) { return func_50(2, iParam0); }

// Position - 0x2434
var func_55(int iParam0, int iParam1) {
	return system::round(system::to_float(func_57(iParam0, iParam1)) / system::to_float(func_56(iParam1)) * 100f);
}

// Position - 0x245D
int func_56(int iParam0) {
	switch (iParam0) {
	case 0: return 1000;

	case 1: return 100;

	case 2: return 100;

	case 3: return 100;
	}
	return 0;
}

// Position - 0x24A6
int func_57(int iParam0, int iParam1) {
	if (func_41(iParam0) != 1) {
		return -1;
	}
	return func_47(iParam0, iParam1);
}

// Position - 0x24C4
char *func_58(int iParam0) { return func_50(1, iParam0); }

// Position - 0x24D3
char *func_59(int iParam0) {
	switch (Global_87699[iParam0 /*5*/]) {
	case 1: return "HC_TYPE_G";

	case 2: return "HC_TYPE_H";

	case 3: return "HC_TYPE_D";
	}
	return "ERROR!";
}

// Position - 0x251C
char *func_60(int iParam0) { return func_61(iParam0); }

// Position - 0x252A
char *func_61(int iParam0) {
	switch (iParam0) {
	case 1: return "HC_N_GUS";

	case 2: return "HC_N_KAR";

	case 10: return "HC_N_PAC";

	case 11: return "HC_N_CHE";

	case 3: return "HC_N_HUG";

	case 4: return "HC_N_NOR";

	case 5: return "HC_N_DAR";

	case 6: return "HC_N_PAI";

	case 7: return "HC_N_CHR";

	case 12: return "HC_N_RIC";

	case 8: return "HC_N_EDD";

	case 13: return "HC_N_TAL";

	case 9: return "HC_N_KRM";
	}
	return "ERROR!";
}

// Position - 0x260D
void func_62(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x262C
void func_63(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!gameplay::is_bit_set(Global_87853[iParam1 /*19*/].f_18, iParam2)) {
		if (!gameplay::are_strings_equal(&Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/], "")) {
			func_26(uParam0, uParam0->f_1.f_276, Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/], 1);
			gameplay::set_bit(&Global_87853[iParam1 /*19*/].f_18, iParam2);
			iVar0 = 0;
			while (iVar0 < 10) {
				if (gameplay::are_strings_equal(&Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/],
												&Global_87853[iVar0 /*19*/].f_7[iParam2 /*2*/])) {
					gameplay::set_bit(&Global_87853[iVar0 /*19*/].f_18, iParam2);
				}
				iVar0++;
			}
		}
	}
}

// Position - 0x26D7
void func_64(var *uParam0) {
	func_27(uParam0, &uParam0->f_1.f_12, 45f);
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(99);
	graphics::_pop_scaleform_movie_function_void();
	func_20(uParam0);
}

// Position - 0x270D
void func_65(var *uParam0) {
	switch (uParam0->f_464) {
	case 1:
	case 2:
	case 3:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(99);
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	ui::clear_help(0);
}

// Position - 0x2750
int func_66(int iParam0) {
	if (iParam0 == 13 || iParam0 == -1) {
		return 0;
	}
	return Global_101700.f_8044.f_99.f_205[iParam0];
}

// Position - 0x277D
int func_67(int iParam0) {
	switch (iParam0) {
	case 0: return 2;

	case 1: return 3;

	case 2: return 4;

	case 3: return 5;

	case 4: return 6;
	}
	return -1;
}

// Position - 0x27CE
void func_68(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		func_69(uParam0);
	}
}

// Position - 0x27E9
void func_69(var *uParam0) {
	bool bVar0;
	vector3 vVar1;
	float fVar4;
	float fVar5;
	float fVar6;
	bool bVar7;

	bVar0 = false;
	if (!gameplay::is_bit_set(uParam0->f_449, 2)) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (!func_141(0)) {
				if (func_132(8)) {
					if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), uParam0->f_401) < 4f) {
						vVar1 = {uParam0->f_401 - entity::get_entity_coords(player::player_ped_id(), 1)};
						fVar4 = gameplay::get_heading_from_vector_2d(vVar1.x, vVar1.y);
						fVar5 = gameplay::absf(uParam0->f_404 - fVar4);
						if (fVar5 <= 70f) {
							bVar0 = true;
						}
						else {
							fVar6 = uParam0->f_404;
							if (fVar6 > 180f) {
								fVar6 -= 360f;
							}
							else if (fVar6 < -180f) {
								fVar6 += 360f;
							}
							if (fVar6 - fVar4 < fVar5) {
								fVar5 = gameplay::absf(fVar6 - fVar4);
							}
							if (fVar5 <= 70f) {
								bVar0 = true;
							}
							else {
								if (fVar4 > 180f) {
									fVar4 -= 360f;
								}
								else if (fVar4 < -180f) {
									fVar4 += 360f;
								}
								if (uParam0->f_404 - fVar4 < fVar5) {
									fVar5 = gameplay::absf(uParam0->f_404 - fVar4);
								}
								if (fVar5 <= 70f) {
									bVar0 = true;
								}
								else {
									if (fVar6 - fVar4 < fVar5) {
										fVar5 = gameplay::absf(fVar6 - fVar4);
									}
									if (fVar5 <= 70f) {
										bVar0 = true;
									}
								}
							}
						}
					}
				}
			}
		}
		if (bVar0) {
			if (uParam0->f_451 == -1) {
				func_131(&uParam0->f_451, 3, "PB_H_ENT", 0, 0, 0, 0);
			}
			else if (func_130(uParam0->f_451, 1)) {
				func_128(&uParam0->f_451);
				func_114(uParam0);
			}
		}
		else if (uParam0->f_451 != -1) {
			func_128(&uParam0->f_451);
		}
	}
	else {
		bVar7 = func_12(1, *uParam0);
		func_78(uParam0);
		if (!bVar7 && uParam0->f_453 > 15 &&
				(controls::is_control_just_pressed(2, iLocal_36) || controls::is_control_just_pressed(2, 238)) ||
			gameplay::is_bit_set(uParam0->f_449, 8)) {
			gameplay::clear_bit(&uParam0->f_449, 8);
			func_70(uParam0, 0);
		}
	}
}

// Position - 0x2A08
void func_70(var *uParam0, int iParam1) {
	vector3 vVar0;
	int iVar3;

	uParam0->f_453 = 0;
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		entity::freeze_entity_position(player::player_ped_id(), 0);
		if (!iParam1) {
			vVar0 = {uParam0->f_401};
			vVar0 = {vVar0 +
					 Vector(0f, 1f * system::cos(180f - uParam0->f_404), 1f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
			entity::set_entity_coords(player::player_ped_id(), vVar0, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 0, 0, 0);
			ped::_0x2208438012482A1A(player::player_ped_id(), 1, 0);
		}
	}
	if (player::is_player_playing(player::player_id())) {
		player::set_player_control(player::player_id(), 1, 134);
	}
	ui::display_radar(1);
	func_73(0);
	func_72();
	ui::_0xE1CD1E48E025E661();
	ui::reset_hud_component_values(17);
	graphics::_0xD39D13C9FEBF0511(0);
	func_71(&uParam0->f_649, 0, 1);
	func_15(&uParam0->f_1.f_20[0 /*4*/], 1);
	func_15(&uParam0->f_1.f_20[1 /*4*/], 1);
	func_15(&uParam0->f_1.f_108[0 /*4*/], 1);
	func_15(&uParam0->f_1.f_108[1 /*4*/], 1);
	ui::clear_help(1);
	while (ui::is_help_message_being_displayed()) {
		ui::clear_help(1);
		system::wait(0);
	}
	iVar3 = interior::get_interior_at_coords(uParam0->f_401);
	if (iVar3 != 0) {
		interior::unpin_interior(iVar3);
	}
	audio::unregister_script_with_audio();
	func_65(uParam0);
	gameplay::clear_bit(&uParam0->f_449, 7);
	gameplay::clear_bit(&uParam0->f_449, 2);
	G_DisableMessagesAndCalls3 = 0;
}

// Position - 0x2B8C
void func_71(var *uParam0, int iParam1, int iParam2) {
	if (cam::does_cam_exist(*uParam0)) {
		if (iParam2) {
			cam::render_script_cams(0, 0, 3000, 1, iParam1, 0);
		}
		if (cam::is_cam_active(*uParam0)) {
			cam::set_cam_active(*uParam0, 0);
		}
		cam::destroy_cam(*uParam0, iParam1);
	}
	if (uParam0->f_23) {
		ui::unlock_minimap_angle();
		uParam0->f_23 = 0;
	}
	uParam0->f_1 = {0f, 0f, 0f};
	uParam0->f_4 = {0f, 0f, 0f};
	uParam0->f_7 = 0f;
	uParam0->f_20 = 0;
	uParam0->f_21 = 0;
	uParam0->f_22 = 0;
	uParam0->f_8 = {0f, 0f, 0f};
	uParam0->f_11 = {0f, 0f, 0f};
	uParam0->f_14 = {0f, 0f, 0f};
	uParam0->f_17 = 0f;
	uParam0->f_18 = 0f;
}

// Position - 0x2C26
void func_72() { Global_17151.f_5 = 0; }

// Position - 0x2C34
void func_73(int iParam0) {
	if (iParam0) {
		func_77();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_141(0)) {
			func_74(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x2C97
void func_74(int iParam0) {
	if (Global_14604) {
		func_76(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_75()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x2D07
bool func_75() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x2D2E
void func_76(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_141(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x2DA2
void func_77() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x2DCB
void func_78(var *uParam0) {
	char *sVar0;
	bool bVar1;
	vector3 vVar2;

	sVar0 = controls::_0x80C2FD58D720C801(0, 1, 1);
	if (!gameplay::are_strings_equal(sVar0, uParam0->f_466)) {
		func_9(uParam0);
	}
	uParam0->f_466 = sVar0;
	func_112();
	func_102(uParam0);
	func_86(uParam0);
	if (uParam0->f_464 == 1) {
		func_83(uParam0);
	}
	if (func_22()) {
		func_20(uParam0);
	}
	bVar1 = uParam0->f_454 > gameplay::get_game_timer();
	func_79(&uParam0->f_649, gameplay::is_bit_set(uParam0->f_449, 4), gameplay::is_bit_set(uParam0->f_449, 5) && !bVar1,
			1, 0, 1045220557, 1, 1065353216);
	if (gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!cutscene::is_cutscene_playing() && cam::is_screen_faded_in() && !ui::is_pause_menu_active()) {
			if (uParam0->f_464 != 1) {
				if (uParam0->f_464 == 0 || !gameplay::is_bit_set(uParam0->f_449, 11) &&
											   !gameplay::is_bit_set(uParam0->f_449, 10) && !func_21() &&
											   uParam0->f_483 == 0) {
					if (!gameplay::is_bit_set(uParam0->f_449, 18) || uParam0->f_464 == 2) {
						graphics::draw_scaleform_movie_fullscreen(uParam0->f_414, 255, 255, 255, 0, 0);
					}
				}
			}
		}
	}
	ui::display_radar(0);
	ui::hide_hud_component_this_frame(2);
	ui::hide_hud_component_this_frame(1);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(3);
	ui::_0x25F87B30C382FCA7();
	graphics::_set_screen_draw_position(82, 66);
	ui::set_hud_component_position(17, 0.612f, 0.818f);
	graphics::_screen_draw_position_end();
	if (!cutscene::is_cutscene_playing()) {
		controls::set_input_exclusive(2, 201);
	}
	controls::set_input_exclusive(2, 202);
	controls::set_input_exclusive(2, 188);
	controls::set_input_exclusive(2, 187);
	controls::set_input_exclusive(2, 189);
	controls::set_input_exclusive(2, 190);
	if (!gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!cutscene::is_cutscene_playing()) {
			vVar2 = {uParam0->f_401};
			vVar2 = {vVar2 + Vector(0.5f, 2.9f * system::cos(180f - uParam0->f_404),
									2.9f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar2, &vVar2.f_2, 0);
			player::set_player_control(player::player_id(), 0, 134);
			ai::clear_ped_tasks_immediately(player::player_ped_id());
			entity::freeze_entity_position(player::player_ped_id(), 1);
			entity::set_entity_coords(player::player_ped_id(), vVar2, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			gameplay::set_bit(&uParam0->f_449, 7);
		}
	}
}

// Position - 0x301B
void func_79(var *uParam0, bool bParam1, bool bParam2, int iParam3, int iParam4, float fParam5, int iParam6,
			 float fParam7) {
	int iVar0[4];
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	vector3 vVar10;
	int iVar13;
	int iVar14;

	controls::_disable_input_group(2);
	func_82(&iVar0[0], &iVar0[1], &iVar0[2], &iVar0[3], 0, 0);
	if (controls::is_look_inverted()) {
		iVar0[3] *= -1;
	}
	if (controls::_is_input_disabled(2)) {
		fVar5 = controls::_0x5B84D09CEC5209C5(2, 239);
		fVar6 = controls::_0x5B84D09CEC5209C5(2, 240);
		fVar7 = fVar5 - uParam0->f_29;
		fVar8 = fVar6 - uParam0->f_30;
		uParam0->f_29 = fVar5;
		uParam0->f_30 = fVar6;
		if (iParam4) {
			iVar0[2] = -system::round(fVar7 * fParam5 * 127f);
			iVar0[3] = -system::round(fVar8 * fParam5 * 127f);
		}
		else {
			iVar0[2] = system::round(controls::_0x5B84D09CEC5209C5(2, 290) * fParam5 * 127f);
			iVar0[3] = system::round(controls::_0x5B84D09CEC5209C5(2, 291) * fParam5 * 127f);
		}
		iVar0[2] = func_81(iVar0[2] + uParam0->f_24, -127, 127);
		iVar0[3] = func_81(iVar0[3] + uParam0->f_25, -127, 127);
	}
	if (uParam0->f_24 == iVar0[2] && uParam0->f_25 == iVar0[3]) {
		if (uParam0->f_27 < gameplay::get_game_timer()) {
			uParam0->f_24 = 0;
			uParam0->f_25 = 0;
			if (controls::_is_input_disabled(2)) {
				iVar0[2] = 0;
				iVar0[3] = 0;
				uParam0->f_28 = 1;
			}
		}
	}
	else {
		uParam0->f_24 = iVar0[2];
		uParam0->f_25 = iVar0[3];
		uParam0->f_27 = gameplay::get_game_timer() + 4000;
		uParam0->f_28 = 0;
	}
	if (bParam2) {
		uParam0->f_8.f_2 = -(system::to_float(iVar0[2]) / 127f) * IntToFloat(uParam0->f_20);
		uParam0->f_8.f_1 = -uParam0->f_8.f_2 * IntToFloat(uParam0->f_22) / IntToFloat(uParam0->f_20);
		uParam0->f_8 = -(system::to_float(iVar0[3]) / 127f) * IntToFloat(uParam0->f_21);
	}
	else {
		uParam0->f_8 = {0f, 0f, 0f};
		uParam0->f_24 = 0;
		uParam0->f_25 = 0;
	}
	fVar9 = 30f * system::timestep();
	vVar10 = {uParam0->f_8 + uParam0->f_11};
	if (controls::_is_input_disabled(2) && bParam2 && !uParam0->f_28) {
		uParam0->f_14 = vVar10.x;
		uParam0->f_14.f_1 = vVar10.y;
		uParam0->f_14.f_2 = vVar10.z;
	}
	else {
		uParam0->f_14 += func_80((vVar10.x - uParam0->f_14) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_1 += func_80((vVar10.y - uParam0->f_14.f_1) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_2 += func_80((vVar10.z - uParam0->f_14.f_2) * 0.05f * fVar9 * fParam7, -3f, 3f);
	}
	if (uParam0->f_26) {
		uParam0->f_14 = func_80(uParam0->f_14, system::to_float(-uParam0->f_21), system::to_float(uParam0->f_21));
		uParam0->f_14.f_1 =
			func_80(uParam0->f_14.f_1, system::to_float(-uParam0->f_22), system::to_float(uParam0->f_22));
		uParam0->f_14.f_2 =
			func_80(uParam0->f_14.f_2, system::to_float(-uParam0->f_20), system::to_float(uParam0->f_20));
	}
	if (controls::_is_input_disabled(0) && bParam1) {
		if (uParam0->f_28) {
			uParam0->f_17 = uParam0->f_7;
		}
	}
	else {
		uParam0->f_17 = uParam0->f_7;
	}
	if (bParam1) {
		if (controls::_is_input_disabled(0)) {
			iVar13 = 40;
			iVar14 = 41;
			if (iParam6) {
				iVar13 = 241;
				iVar14 = 242;
			}
			if (controls::is_disabled_control_just_pressed(0, iVar13)) {
				uParam0->f_17 -= 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			else if (controls::is_disabled_control_just_pressed(0, iVar14)) {
				uParam0->f_17 += 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			if (iParam3) {
				uParam0->f_17 = func_80(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7);
			}
			else {
				uParam0->f_17 = func_80(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7 + uParam0->f_19);
			}
		}
		else if (iParam3) {
			if (system::to_float(iVar0[1]) < 0f) {
				uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
			}
		}
		else {
			uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
		}
	}
	uParam0->f_18 += (uParam0->f_17 - uParam0->f_18) * 0.06f * fVar9;
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4 + uParam0->f_14, uParam0->f_18, 0, 1, 1, 2);
	if (cam::does_cam_exist(*uParam0)) {
		if (cam::is_cam_active(*uParam0)) {
			if (cam::is_cam_rendering(*uParam0)) {
				unk1::_0xAF66DCEE6609B148();
			}
		}
	}
}

// Position - 0x34CD
float func_80(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x34F4
int func_81(int iParam0, int iParam1, int iParam2) {
	if (iParam0 > iParam2) {
		return iParam2;
	}
	else if (iParam0 < iParam1) {
		return iParam1;
	}
	return iParam0;
}

// Position - 0x3519
void func_82(var *uParam0, var *uParam1, var *uParam2, int *iParam3, int iParam4, int iParam5) {
	*uParam0 = system::floor(controls::_0x5B84D09CEC5209C5(2, 218) * 127f);
	*uParam1 = system::floor(controls::_0x5B84D09CEC5209C5(2, 219) * 127f);
	*uParam2 = system::floor(controls::_0x5B84D09CEC5209C5(2, 220) * 127f);
	*iParam3 = system::floor(controls::_0x5B84D09CEC5209C5(2, 221) * 127f);
	if (iParam4) {
		if (!controls::is_control_enabled(2, 218)) {
			*uParam0 = system::floor(controls::_0x4F8A26A890FD62FB(2, 218) * 127f);
		}
		if (!controls::is_control_enabled(2, 219)) {
			*uParam1 = system::floor(controls::_0x4F8A26A890FD62FB(2, 219) * 127f);
		}
		if (!controls::is_control_enabled(2, 220)) {
			*uParam2 = system::floor(controls::_0x4F8A26A890FD62FB(2, 220) * 127f);
		}
		if (!controls::is_control_enabled(2, 221)) {
			*iParam3 = system::floor(controls::_0x4F8A26A890FD62FB(2, 221) * 127f);
		}
	}
	if (controls::_is_input_disabled(2)) {
		if (iParam5) {
			if (controls::is_look_inverted()) {
				*iParam3 *= -1;
			}
			if (controls::_0xE1615EC03B3BB4FD()) {
				*iParam3 *= -1;
			}
		}
	}
}

// Position - 0x361D
void func_83(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_12(3, *uParam0)) {
		if (uParam0->f_483 == 0 && uParam0->f_455 > 3) {
			if (uParam0->f_452 == -1) {
				if (gameplay::is_bit_set(uParam0->f_449, 19)) {
					uParam0->f_452 = gameplay::get_game_timer() + 500;
				}
				else {
					uParam0->f_452 = gameplay::get_game_timer();
				}
			}
			else if (gameplay::get_game_timer() > uParam0->f_452) {
				iVar0 = 0;
				iVar1 = 0;
				while (iVar1 < uParam0->f_1.f_369) {
					if (!iVar0) {
						if (!gameplay::is_bit_set(uParam0->f_1.f_303, iVar1 + 4)) {
							func_85(uParam0, iVar1);
							if (gameplay::is_bit_set(uParam0->f_1.f_370, iVar1)) {
								gameplay::set_bit(&uParam0->f_449, 19);
							}
							else {
								gameplay::clear_bit(&uParam0->f_449, 19);
							}
							iVar0 = 1;
						}
					}
					iVar1++;
				}
				if (!iVar0) {
					func_84(3, *uParam0, 1);
				}
			}
		}
	}
}

// Position - 0x36FC
void func_84(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return;
	}
	iVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	if (iVar0 == iParam2) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	}
}

// Position - 0x3781
void func_85(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(99);
	graphics::_pop_scaleform_movie_function_void();
	func_27(uParam0, &uParam0->f_1.f_371[iParam1 /*2*/], uParam0->f_1.f_11);
	func_25(uParam0, iParam1 + 4, 1);
	uParam0->f_452 = -1;
}

// Position - 0x37C8
void func_86(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_21() && cam::is_screen_faded_in() && !cutscene::is_cutscene_playing()) {
		if (uParam0->f_483 > 0) {
			if (!gameplay::is_bit_set(uParam0->f_449, 13)) {
				if (func_87(&uParam0->f_484, &uParam0->f_467[0 /*5*/], &uParam0->f_467[0 /*5*/].f_2, 4, 0, 0, 0)) {
					uParam0->f_455 = 0;
					if (uParam0->f_467[0 /*5*/].f_4) {
						gameplay::clear_bit(&uParam0->f_449, 11);
					}
					else {
						gameplay::set_bit(&uParam0->f_449, 11);
					}
					iVar0 = 0;
					while (iVar0 < 2) {
						uParam0->f_467[iVar0 /*5*/] = {uParam0->f_467[iVar0 + 1 /*5*/]};
						uParam0->f_467[iVar0 /*5*/].f_2 = {uParam0->f_467[iVar0 + 1 /*5*/].f_2};
						uParam0->f_467[iVar0 /*5*/].f_4 = uParam0->f_467[iVar0 + 1 /*5*/].f_4;
						iVar0++;
					}
					uParam0->f_483--;
				}
			}
			else {
				iVar1 = 0;
				while (iVar1 < 2) {
					uParam0->f_467[iVar1 /*5*/] = {uParam0->f_467[iVar1 + 1 /*5*/]};
					uParam0->f_467[iVar1 /*5*/].f_2 = {uParam0->f_467[iVar1 + 1 /*5*/].f_2};
					uParam0->f_467[iVar1 /*5*/].f_4 = uParam0->f_467[iVar1 + 1 /*5*/].f_4;
					iVar1++;
				}
				uParam0->f_483--;
				gameplay::clear_bit(&uParam0->f_449, 13);
				gameplay::clear_bit(&uParam0->f_449, 11);
			}
		}
		else {
			if (gameplay::is_bit_set(uParam0->f_449, 11)) {
				gameplay::clear_bit(&uParam0->f_449, 11);
			}
			if (gameplay::is_bit_set(uParam0->f_449, 13)) {
				gameplay::clear_bit(&uParam0->f_449, 13);
			}
			uParam0->f_455++;
		}
	}
}

// Position - 0x397F
bool func_87(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_101(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_88(sParam2, iParam3, 0);
}

// Position - 0x39CD
int func_88(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_100();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_99(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_98();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_92();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_91()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_75()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_90();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_89();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_100();
	}
	return 0;
}

// Position - 0x3C99
void func_89() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x3CCA
void func_90() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x3D5F
bool func_91() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x3DF8
void func_92() {
	if (func_310(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_93();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x3E9A
int func_93() {
	func_94();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x3EB3
void func_94() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_97(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_96(player::player_ped_id());
			if (func_95(iVar0) && (!func_310(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_95(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x3FB0
bool func_95(int iParam0) { return iParam0 < 3; }

// Position - 0x3FBC
int func_96(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_97(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x3FF9
int func_97(int iParam0) {
	if (func_95(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x4025
void func_98() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x407C
bool func_99(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x40B7
void func_100() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x410E
void func_101(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, var uParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = uParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x4164
void func_102(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	uParam0->f_453++;
	if (controls::_0x6CD79468A1E595C6(2)) {
		func_9(uParam0);
	}
	if (!gameplay::is_bit_set(uParam0->f_449, 11)) {
		if (controls::is_control_just_pressed(2, iLocal_37) || controls::is_control_just_pressed(2, iLocal_39) ||
			controls::_is_input_disabled(2) &&
				(controls::is_control_just_pressed(2, iLocal_38) || controls::is_control_just_pressed(2, iLocal_40))) {
			func_110();
			if (gameplay::is_bit_set(uParam0->f_449, 12)) {
				gameplay::set_bit(&uParam0->f_449, 13);
				gameplay::clear_bit(&uParam0->f_449, 11);
				gameplay::clear_bit(&uParam0->f_449, 10);
			}
			gameplay::clear_bit(&uParam0->f_449, 12);
		}
	}
	func_82(&uParam0->f_458[0], &uParam0->f_458[1], &uParam0->f_458[2], &uParam0->f_458[3], 0, 0);
	if (controls::_is_input_disabled(2)) {
		uParam0->f_458[2] /= 10;
		uParam0->f_458[3] /= 10;
		uParam0->f_458[2] = func_81(uParam0->f_458[2] + uParam0->f_649.f_24, -127, 127);
		uParam0->f_458[3] = func_81(uParam0->f_458[3] + uParam0->f_649.f_25, -127, 127);
	}
	uParam0->f_649.f_24 = uParam0->f_458[2];
	uParam0->f_649.f_25 = uParam0->f_458[3];
	if (controls::is_look_inverted()) {
		uParam0->f_458[3] = -uParam0->f_458[3];
	}
	if (uParam0->f_454 > gameplay::get_game_timer()) {
		uParam0->f_458[2] = 0;
		uParam0->f_458[3] = 0;
	}
	if (uParam0->f_464 == 0 || uParam0->f_464 == 4) {
		if (uParam0->f_453 > 15) {
			gameplay::set_bit(&uParam0->f_449, 4);
		}
		else {
			gameplay::clear_bit(&uParam0->f_449, 4);
		}
	}
	if (!gameplay::is_bit_set(uParam0->f_449, 10)) {
		if (!gameplay::is_bit_set(uParam0->f_449, 11)) {
			if (gameplay::get_game_timer() - uParam0->f_456 > 200) {
				if (uParam0->f_464 == 2 || uParam0->f_464 == 3 || uParam0->f_464 == 4) {
					if (gameplay::get_game_timer() - uParam0->f_457 > 25000) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_280[3 /*2*/], 1);
						uParam0->f_457 = gameplay::get_game_timer() + gameplay::get_random_int_in_range(0, 8000);
					}
				}
				if (uParam0->f_464 == 2) {
					if (uParam0->f_458[1] < -85 || uParam0->f_458[0] < -85 || controls::is_control_pressed(2, 188) ||
						controls::is_control_pressed(2, 189) ||
						controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(2, 241)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(8);
						graphics::_pop_scaleform_movie_function_void();
						graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
						uParam0->f_682 = graphics::_pop_scaleform_movie_function();
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
					else if (uParam0->f_458[1] > 85 || uParam0->f_458[0] > 85 || controls::is_control_pressed(2, 187) ||
							 controls::is_control_pressed(2, 190) ||
							 controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 242)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(9);
						graphics::_pop_scaleform_movie_function_void();
						graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
						uParam0->f_682 = graphics::_pop_scaleform_movie_function();
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
				}
				if (uParam0->f_464 == 3) {
					if (uParam0->f_458[1] < -85 || controls::is_control_pressed(2, 188) ||
						controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 40)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(8);
						graphics::_pop_scaleform_movie_function_void();
						if (uParam0->f_416 != 0) {
							audio::play_sound_frontend(-1, "MARKER_ERASE", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
						}
						uParam0->f_416 = 0;
						if (gameplay::is_bit_set(uParam0->f_449, 9)) {
							gameplay::clear_bit(&uParam0->f_449, 9);
							func_9(uParam0);
						}
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
					else if (uParam0->f_458[1] > 85 || controls::is_control_pressed(2, 187) ||
							 controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 41)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(9);
						graphics::_pop_scaleform_movie_function_void();
						if (uParam0->f_416 != 1) {
							audio::play_sound_frontend(-1, "MARKER_ERASE", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
						}
						uParam0->f_416 = 1;
						if (gameplay::is_bit_set(uParam0->f_449, 9)) {
							gameplay::clear_bit(&uParam0->f_449, 9);
							func_9(uParam0);
						}
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
				}
				if (!func_21() || gameplay::is_bit_set(uParam0->f_449, 13)) {
					if (controls::is_control_just_pressed(2, iLocal_37) ||
						controls::_is_input_disabled(2) && controls::is_control_just_pressed(2, iLocal_38)) {
						switch (uParam0->f_464) {
						case 3:
							if (!func_21()) {
								if (!gameplay::is_bit_set(uParam0->f_449, 9)) {
									uParam0->f_456 = gameplay::get_game_timer();
									iVar0 = func_32(*uParam0);
									if (iVar0 != -1) {
										graphics::_push_scaleform_movie_function(uParam0->f_413,
																				 "GET_CURRENT_SELECTION");
										uParam0->f_680 = graphics::_pop_scaleform_movie_function();
										func_13(uParam0, 1);
										func_15(&uParam0->f_1.f_20[0 /*4*/], 1);
										func_15(&uParam0->f_1.f_20[1 /*4*/], 1);
										Global_101700.f_1[*uParam0] = 1;
										ui::clear_help(0);
									}
								}
							}
							break;

						case 2:
							if (!func_12(4, *uParam0)) {
								iVar0 = func_32(*uParam0);
								iVar1 = func_66(iVar0);
								if (uParam0->f_450 < Global_87853[iVar1 /*19*/]) {
									graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
									uParam0->f_681 = graphics::_pop_scaleform_movie_function();
									func_13(uParam0, 1);
								}
							}
							break;

						case 4:
							if (*uParam0 != 1) {
								func_84(4, *uParam0, 1);
								if (!func_3(0)) {
									func_108(*uParam0);
								}
							}
							else {
								func_84(5, *uParam0, 1);
							}
							audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
							iVar0 = func_32(*uParam0);
							iVar1 = func_66(iVar0);
							iVar2 = 0;
							while (iVar2 < Global_87853[iVar1 /*19*/]) {
								if (Global_101700.f_1.f_12[iVar1 /*6*/][iVar2] == 0 ||
									func_41(Global_101700.f_1.f_12[iVar1 /*6*/][iVar2]) !=
										Global_87853[iVar1 /*19*/].f_1[iVar2]) {
									iVar4 = 0;
									iVar5 = 0;
									while (iVar5 < 14) {
										if (!iVar4) {
											iVar4 = 1;
											iVar3 = iVar5;
											if (iVar3 != 0) {
												if (Global_87699[iVar3 /*5*/] !=
													Global_87853[iVar1 /*19*/].f_1[iVar2]) {
													iVar4 = 0;
												}
												if (!gameplay::is_bit_set(Global_101700.f_1.f_116, iVar3)) {
													iVar4 = 0;
												}
												if (gameplay::is_bit_set(Global_101700.f_1.f_118, iVar3)) {
													iVar4 = 0;
												}
												if (iVar3 == 11 && *uParam0 == 3) {
													iVar4 = 0;
												}
												if (func_38(uParam0, iVar3)) {
													iVar4 = 0;
												}
											}
											else {
												iVar4 = 0;
											}
										}
										iVar5++;
									}
									Global_101700.f_1.f_12[iVar1 /*6*/][iVar2] = iVar3;
								}
								iVar2++;
							}
							func_13(uParam0, 1);
							func_63(uParam0, iVar1, 4);
							break;
						}
						uParam0->f_427 = 0;
					}
					if (controls::is_control_just_pressed(2, iLocal_39) ||
						controls::_is_input_disabled(2) && controls::is_control_just_pressed(2, iLocal_40)) {
						switch (uParam0->f_464) {
						case 2:
							iVar0 = func_32(*uParam0);
							iVar1 = func_66(iVar0);
							if (uParam0->f_450 > 0) {
								func_13(uParam0, 1);
								uParam0->f_450--;
								uParam0->f_417 = uParam0->f_450;
								iVar6 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
								Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
								uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
								func_36(uParam0, uParam0->f_450, iVar6);
								audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
								uParam0->f_427 = 0;
								uParam0->f_456 = gameplay::get_game_timer();
							}
							else if (!func_315(0)) {
								if (*uParam0 != 2) {
									iVar7 = 0;
									while (iVar7 < uParam0->f_1.f_96) {
										graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
										graphics::_push_scaleform_movie_function_parameter_int(iVar7);
										graphics::_pop_scaleform_movie_function_void();
										graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
										graphics::_push_scaleform_movie_function_parameter_int(iVar7);
										graphics::_push_scaleform_movie_function_parameter_bool(1);
										graphics::_pop_scaleform_movie_function_void();
										iVar7++;
									}
									audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
									iVar7 = 0;
									while (iVar7 < 2) {
										if (uParam0->f_1.f_30[iVar7] != 13) {
											func_2(*uParam0, uParam0->f_1.f_30[iVar7], 0);
										}
										iVar7++;
									}
									uParam0->f_427 = 0;
									func_13(uParam0, 1);
									uParam0->f_456 = gameplay::get_game_timer();
									uParam0->f_465 = 0;
									func_107(0, 1);
								}
							}
							break;

						case 4:
							if (*uParam0 != 1) {
								iVar0 = func_32(*uParam0);
								iVar1 = func_66(iVar0);
								uParam0->f_450--;
								uParam0->f_417 = uParam0->f_450;
								iVar8 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
								Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
								uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
								func_7(uParam0, 2, iVar8);
							}
							else {
								iVar9 = 0;
								while (iVar9 < 2) {
									if (uParam0->f_1.f_30[iVar9] != 13) {
										func_2(*uParam0, uParam0->f_1.f_30[iVar9], 0);
									}
									iVar9++;
								}
								func_106(8, 0);
								func_84(5, 1, 0);
								uParam0->f_427 = 0;
								func_13(uParam0, 1);
								uParam0->f_456 = gameplay::get_game_timer();
								func_7(uParam0, 3, 0);
							}
							audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
							break;
						}
					}
				}
			}
		}
	}
	else if (uParam0->f_455 > 5) {
		iVar0 = func_32(*uParam0);
		iVar1 = func_66(iVar0);
		if (uParam0->f_450 >= Global_87853[iVar1 /*19*/] || *uParam0 == 1 && uParam0->f_450 > uParam0->f_415) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
			graphics::_push_scaleform_movie_function_parameter_int(99);
			graphics::_push_scaleform_movie_function_parameter_int(-1);
			graphics::_pop_scaleform_movie_function_void();
			func_25(uParam0, 0, 1);
			func_7(uParam0, 4, 0);
		}
		else {
			if (!gameplay::is_bit_set(uParam0->f_449, 17)) {
				iVar10 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
				Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
				uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
				func_36(uParam0, uParam0->f_450, iVar10);
			}
			gameplay::clear_bit(&uParam0->f_449, 17);
		}
		uParam0->f_457 = gameplay::get_game_timer();
		gameplay::clear_bit(&uParam0->f_449, 10);
	}
	else if (ui::is_help_message_being_displayed()) {
		if (!func_14(&uParam0->f_1.f_108[0 /*4*/]) && !func_14(&uParam0->f_1.f_108[1 /*4*/]) &&
			!func_14(&uParam0->f_1.f_20[0 /*4*/]) && !func_14(&uParam0->f_1.f_20[1 /*4*/])) {
			ui::clear_help(1);
		}
	}
	if (uParam0->f_680 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_680)) {
			iVar11 = graphics::_0x2DE7EFA66B906036(uParam0->f_680);
			iVar1 = func_31(*uParam0, iVar11);
			iVar0 = func_32(*uParam0);
			func_106(iVar0, iVar1);
			if (!func_3(0)) {
				func_105(*uParam0);
			}
			audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			func_63(uParam0, iVar1, 0);
			if (uParam0->f_1.f_30[iVar11] != 13) {
				func_2(*uParam0, uParam0->f_1.f_30[iVar11], 1);
			}
			iVar12 = 0;
			while (iVar12 < uParam0->f_1.f_96) {
				func_62(uParam0, iVar12);
				if (iVar12 < Global_87853[iVar1 /*19*/]) {
					graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
					graphics::_push_scaleform_movie_function_parameter_int(iVar12);
					graphics::_push_scaleform_movie_function_parameter_bool(1);
					graphics::_pop_scaleform_movie_function_void();
				}
				else {
					graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
					graphics::_push_scaleform_movie_function_parameter_int(iVar12);
					graphics::_push_scaleform_movie_function_parameter_bool(0);
					graphics::_pop_scaleform_movie_function_void();
				}
				iVar12++;
			}
			if (*uParam0 != 1) {
				func_84(5, *uParam0, 1);
			}
			else {
				gameplay::set_bit(&uParam0->f_449, 10);
				uParam0->f_450++;
			}
			ui::clear_help(0);
			uParam0->f_680 = 0;
		}
	}
	if (uParam0->f_681 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_681)) {
			iVar13 = graphics::_0x2DE7EFA66B906036(uParam0->f_681);
			iVar0 = func_32(*uParam0);
			iVar1 = func_66(iVar0);
			Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = uParam0->f_418[iVar13];
			iVar14 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
			graphics::_push_scaleform_movie_function(uParam0->f_413, "UPDATE_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_450);
			graphics::_push_scaleform_movie_function_parameter_int(iVar13);
			graphics::_push_scaleform_movie_function_parameter_int(iVar14);
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
			graphics::_push_scaleform_movie_function_parameter_int(99);
			graphics::_pop_scaleform_movie_function_void();
			audio::play_sound_frontend(-1, "PERSON_SELECT", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
			gameplay::clear_bit(&uParam0->f_449, 17);
			func_104(uParam0, iVar14);
			uParam0->f_450++;
			uParam0->f_417 = uParam0->f_450;
			uParam0->f_456 = gameplay::get_game_timer();
			uParam0->f_457 = uParam0->f_456;
			gameplay::set_bit(&uParam0->f_449, 10);
			if (!func_14(&uParam0->f_1.f_108[0 /*4*/]) && !func_14(&uParam0->f_1.f_108[1 /*4*/])) {
				ui::clear_help(0);
			}
			uParam0->f_681 = 0;
		}
	}
	if (uParam0->f_682 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_682)) {
			iVar15 = graphics::_0x2DE7EFA66B906036(uParam0->f_682);
			if (iVar15 != -1) {
				iVar16 = uParam0->f_418[iVar15];
				if (iVar16 != uParam0->f_427) {
					audio::play_sound_frontend(-1, "PERSON_SCROLL", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
				}
				uParam0->f_427 = iVar16;
			}
			uParam0->f_682 = 0;
		}
	}
	if (uParam0->f_427 != 0) {
		func_103(uParam0, uParam0->f_427);
	}
}

// Position - 0x4F2D
void func_103(var *uParam0, int iParam1) {
	if (!func_21()) {
		if (uParam0->f_483 == 0) {
			switch (iParam1) {
			case 10:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 14)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[14 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_26(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[14 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 13:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 16)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[16 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_26(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[16 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 16);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 12:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 15)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[15 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_26(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[15 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 11:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 17)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[17 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_26(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[17 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 17);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;
			}
		}
	}
}

// Position - 0x5149
void func_104(var *uParam0, int iParam1) {
	if (!gameplay::is_bit_set(uParam0->f_463, iParam1)) {
		if (!gameplay::is_bit_set(Global_101700.f_1.f_119, iParam1)) {
			if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[iParam1 /*2*/], "")) {
				func_26(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[iParam1 /*2*/], 1);
				gameplay::set_bit(&Global_101700.f_1.f_119, iParam1);
			}
		}
		else {
			switch (*uParam0) {
			case 2:
				switch (iParam1) {
				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;
				}
				break;

			case 3:
				switch (iParam1) {
				case 12:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 3)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[24 /*2*/], 1);
					}
					break;

				case 9:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 6)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[26 /*2*/], 1);
					}
					break;

				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[21 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[19 /*2*/], 1);
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[21 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[19 /*2*/], 1);
					}
					break;

				case 6:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 4)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 7:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 2)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 8:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 5)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;
				}
				break;

			case 4:
				switch (iParam1) {
				case 12:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 15)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 3)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[25 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[24 /*2*/], 1);
						}
					}
					break;

				case 7:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 2)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 14)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[30 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[28 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 14)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[29 /*2*/], 1);
					}
					break;

				case 9:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 18)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 6)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[27 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[26 /*2*/], 1);
						}
					}
					break;

				case 4:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 17)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[31 /*2*/], 1);
					}
					break;

				case 5:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 12)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[31 /*2*/], 1);
					}
					break;

				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 10)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
							if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
								func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[23 /*2*/], 1);
							}
							else {
								func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
							}
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 11)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
							if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
								func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[23 /*2*/], 1);
							}
							else {
								func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
							}
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 3:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 13)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
					}
					break;

				case 6:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 19)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 4)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 8:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 16)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 5)) {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
						}
						else {
							func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 13:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 20)) {
						func_26(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
					}
					break;
				}
				break;
			}
		}
		gameplay::set_bit(&uParam0->f_463, iParam1);
	}
}

// Position - 0x58E0
void func_105(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0:
		iVar0 = Global_101700.f_8044.f_99.f_205[7];
		if (iVar0 == 1) {
			stats::stat_set_bool(joaat("sp_heist_chose_jewel_stealth"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_jewel_stealth"), 0, 1);
		}
		break;

	case 1:
		iVar0 = Global_101700.f_8044.f_99.f_205[8];
		if (iVar0 == 3) {
			stats::stat_set_bool(joaat("sp_heist_chose_docks_sink_ship"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_docks_sink_ship"), 0, 1);
		}
		break;

	case 3:
		iVar0 = Global_101700.f_8044.f_99.f_205[10];
		if (iVar0 == 6) {
			stats::stat_set_bool(joaat("sp_heist_chose_bureau_firecrew"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_bureau_firecrew"), 0, 1);
		}
		break;

	case 4:
		iVar0 = Global_101700.f_8044.f_99.f_205[11];
		if (iVar0 == 8) {
			stats::stat_set_bool(joaat("sp_heist_chose_bigs_traffic"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_bigs_traffic"), 0, 1);
		}
		break;
	}
}

// Position - 0x59DB
void func_106(int iParam0, int iParam1) {
	if (iParam0 == 13 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_205[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_205[iParam0] = iParam1;
}

// Position - 0x5A20
void func_107(int iParam0, int iParam1) {
	if (iParam0 == 146 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_58[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_58[iParam0] = iParam1;
}

// Position - 0x5A65
void func_108(int iParam0) {
	int iVar0;
	int iVar1;

	func_109(iParam0);
	switch (iParam0) {
	case 0:
		iVar1 = Global_101700.f_8044.f_99.f_205[7];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 0); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 1);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 7: gameplay::set_bit(&Global_101700.f_1.f_117, 2); break;

			case 12:
				gameplay::set_bit(&Global_101700.f_1.f_117, 3);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
				break;

			case 6: gameplay::set_bit(&Global_101700.f_1.f_117, 4); break;

			case 8: gameplay::set_bit(&Global_101700.f_1.f_117, 5); break;

			case 9: gameplay::set_bit(&Global_101700.f_1.f_117, 6); break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;

	case 2:
		iVar1 = Global_101700.f_8044.f_99.f_205[9];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 7); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 8);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 11:
				gameplay::set_bit(&Global_101700.f_1.f_117, 9);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 17);
				break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;

	case 3:
		iVar1 = Global_101700.f_8044.f_99.f_205[10];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 10); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 11);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 5: gameplay::set_bit(&Global_101700.f_1.f_117, 12); break;

			case 3: gameplay::set_bit(&Global_101700.f_1.f_117, 13); break;

			case 4: gameplay::set_bit(&Global_101700.f_1.f_117, 17); break;

			case 7: gameplay::set_bit(&Global_101700.f_1.f_117, 14); break;

			case 12:
				gameplay::set_bit(&Global_101700.f_1.f_117, 15);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
				break;

			case 6: gameplay::set_bit(&Global_101700.f_1.f_117, 19); break;

			case 8: gameplay::set_bit(&Global_101700.f_1.f_117, 16); break;

			case 9: gameplay::set_bit(&Global_101700.f_1.f_117, 18); break;

			case 13:
				gameplay::set_bit(&Global_101700.f_1.f_117, 20);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 16);
				break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;
	}
}

// Position - 0x5DE2
void func_109(int iParam0) {
	switch (iParam0) {
	case 0:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 0);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 1);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 2);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 3);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 4);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 5);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 6);
		break;

	case 2:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 7);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 8);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 9);
		break;

	case 3:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 10);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 11);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 12);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 13);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 14);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 15);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 16);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 17);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 18);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 19);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 20);
		break;
	}
}

// Position - 0x5F2A
void func_110() {
	Global_14611 = 0;
	func_111();
}

// Position - 0x5F3A
void func_111() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0x5F5B
void func_112() {
	unk1::_0xEB2D525B57F42B40();
	func_113();
}

// Position - 0x5F6B
void func_113() { Global_17151.f_134 = 1; }

// Position - 0x5F79
void func_114(var *uParam0) {
	vector3 vVar0;
	int iVar3;

	uParam0->f_453 = 0;
	uParam0->f_463 = 0;
	gameplay::set_bit(&uParam0->f_449, 9);
	func_13(uParam0, 0);
	if (!cutscene::is_cutscene_playing()) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (Global_36912 == 1) {
				func_119(player::player_ped_id());
			}
			vVar0 = {uParam0->f_401};
			vVar0 = {vVar0 + Vector(0.5f, 2.9f * system::cos(180f - uParam0->f_404),
									2.9f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
			player::set_player_control(player::player_id(), 0, 134);
			entity::set_entity_coords(player::player_ped_id(), vVar0, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			ai::clear_ped_tasks_immediately(player::player_ped_id());
			entity::freeze_entity_position(player::player_ped_id(), 1);
		}
		gameplay::set_bit(&uParam0->f_449, 7);
	}
	ui::display_radar(0);
	func_73(1);
	func_118();
	ui::_0xFDB423997FA30340();
	gameplay::clear_area(uParam0->f_401, 5f, 1, 1, 0, 0);
	graphics::remove_particle_fx_in_range(uParam0->f_401, 5f);
	graphics::_0xD39D13C9FEBF0511(1);
	graphics::_set_screen_draw_position(82, 66);
	ui::set_hud_component_position(17, 0.612f, 0.818f);
	graphics::_screen_draw_position_end();
	func_117(&uParam0->f_649, uParam0->f_405, uParam0->f_408, 45f, 18, 13, 3, uParam0->f_1.f_9, 0, 0, -1082130432, 0);
	iVar3 = interior::get_interior_at_coords(uParam0->f_401);
	if (iVar3 != 0) {
		interior::_load_interior(iVar3);
	}
	interior::_0xAF348AFCB575A441(&Global_87770[uParam0->f_1.f_1 /*15*/].f_7);
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		interior::_0x405DC2AEF6AF95B9(interior::get_key_for_entity_in_room(player::player_ped_id()));
	}
	func_116(0);
	func_115();
	audio::register_script_with_audio(0);
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_414, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
	uParam0->f_466 = controls::_0x80C2FD58D720C801(2, 10, 1);
	gameplay::set_bit(&uParam0->f_449, 2);
	G_DisableMessagesAndCalls3 = 1;
	func_8(uParam0, uParam0->f_464, 0);
}

// Position - 0x616A
void func_115() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		func_17(iVar0);
		iVar0++;
	}
	Global_101700.f_19369.f_145 = 0;
	iVar0 = 0;
	while (iVar0 < 2) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	if (ui::is_help_message_being_displayed()) {
		ui::clear_help(1);
	}
}

// Position - 0x61C8
void func_116(int iParam0) {
	if (!iParam0) {
		Global_100344 = gameplay::get_game_timer() + 250;
	}
	Global_100341 = iParam0;
}

// Position - 0x61E6
void func_117(var *uParam0, vector3 vParam1, vector3 vParam4, float fParam7, int iParam8, int iParam9, int iParam10,
			  var uParam11, int iParam12, int iParam13, float fParam14, int iParam15) {
	uParam0->f_1 = {vParam1};
	uParam0->f_4 = {vParam4};
	uParam0->f_7 = fParam7;
	uParam0->f_20 = iParam8;
	uParam0->f_21 = iParam9;
	uParam0->f_22 = iParam10;
	uParam0->f_8 = {0f, 0f, 0f};
	uParam0->f_11 = {0f, 0f, 0f};
	uParam0->f_14 = {0f, 0f, 0f};
	uParam0->f_17 = fParam7;
	uParam0->f_18 = fParam7;
	uParam0->f_23 = iParam12;
	uParam0->f_19 = uParam11;
	*uParam0 = cam::create_cam("DEFAULT_SCRIPTED_CAMERA", 0);
	cam::set_cam_active(*uParam0, 1);
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4, uParam0->f_7, 0, 1, 1, 2);
	if (!iParam15) {
		cam::shake_cam(*uParam0, "HAND_SHAKE", 0.19f);
	}
	cam::render_script_cams(1, 0, 3000, 1, 0, 0);
	if (fParam14 > 0f) {
		cam::set_cam_near_clip(*uParam0, fParam14);
	}
	if (uParam0->f_23) {
		ui::lock_minimap_angle(iParam13);
	}
	uParam0->f_24 = 0;
	uParam0->f_25 = 0;
	uParam0->f_29 = 0f;
	uParam0->f_30 = 0f;
	uParam0->f_26 = 0;
	uParam0->f_28 = 0;
	uParam0->f_27 = 0;
}

// Position - 0x62DE
void func_118() { Global_17151.f_5 = 1; }

// Position - 0x62EC
void func_119(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam0 == 0) {
		return;
	}
	if (!entity::does_entity_exist(iParam0)) {
		return;
	}
	iVar0 = func_127(iParam0);
	if (iVar0 != -1) {
		iVar1 = Global_36715[iVar0 /*5*/];
		func_122(1, iVar1, 1);
		return;
	}
	iVar2 = func_121(iParam0);
	if (iVar2 == -1) {
		return;
	}
	func_120(iVar2);
}

// Position - 0x6345
void func_120(int iParam0) {
	if (iParam0 < 0 || iParam0 >= 5) {
		return;
	}
	if (Global_36689[iParam0 /*5*/].f_1 != 0) {
		if (Global_36689[iParam0 /*5*/].f_1 == player::player_ped_id()) {
			Global_36910 = 0;
		}
	}
	Global_36689[iParam0 /*5*/] = 13;
	Global_36689[iParam0 /*5*/].f_1 = 0;
	Global_36689[iParam0 /*5*/].f_2 = 0;
	Global_36689[iParam0 /*5*/].f_3 = 0;
	Global_36689[iParam0 /*5*/].f_4 = 0;
	Global_36688--;
	if (Global_36688 < 0) {
		Global_36688 = 0;
	}
}

// Position - 0x63C8
int func_121(int iParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 5) {
		if (Global_36689[iVar0 /*5*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x63F9
void func_122(int iParam0, int iParam1, int iParam2) { func_123(iParam0, iParam1, iParam2, 0, 0); }

// Position - 0x640D
void func_123(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam0 == -1) {
		return;
	}
	if (iParam1 == -1) {
		return;
	}
	if (iParam2 == 6) {
		return;
	}
	if (func_125(iParam0, iParam1, iParam2)) {
		return;
	}
	iVar0 = func_124();
	if (iVar0 == -1) {
		return;
	}
	Global_36796[iVar0 /*5*/] = iParam0;
	Global_36796[iVar0 /*5*/].f_1 = iParam1;
	Global_36796[iVar0 /*5*/].f_2 = iParam2;
	Global_36796[iVar0 /*5*/].f_3 = iParam3;
	Global_36796[iVar0 /*5*/].f_4 = iParam4;
}

// Position - 0x6484
int func_124() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36796[iVar0 /*5*/].f_2 == 6) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x64B5
bool func_125(int iParam0, int iParam1, int iParam2) {
	if (func_126(iParam0, iParam1, iParam2) == -1) {
		return false;
	}
	return true;
}

// Position - 0x64D0
int func_126(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (iParam2 == Global_36796[iVar0 /*5*/].f_2) {
			if (iParam0 == Global_36796[iVar0 /*5*/]) {
				if (iParam1 == Global_36796[iVar0 /*5*/].f_1) {
					return iVar0;
				}
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x651C
int func_127(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36715[iVar0 /*5*/] != -1) {
			if (iParam0 == Global_36715[iVar0 /*5*/].f_1) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x6565
void func_128(int *iParam0) {
	int iVar0;

	if (*iParam0 == -1) {
		return;
	}
	iVar0 = func_129(*iParam0);
	if (iVar0 == -1) {
		*iParam0 = -1;
		return;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/].f_7 = 1;
			*iParam0 = -1;
			return;
		}
	}
	*iParam0 = -1;
}

// Position - 0x65BC
int func_129(int iParam0) {
	int iVar0;

	if (iParam0 < 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x65F7
bool func_130(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_129(iParam0);
	if (iVar0 == -1) {
		return false;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return false;
	}
	if (func_141(0)) {
		return false;
	}
	if (cutscene::is_cutscene_playing()) {
		return false;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/] == 1 && Global_36484[iVar0 /*32*/].f_4 == 1) {
			if (iParam1) {
				if (Global_36484[iVar0 /*32*/].f_29) {
					return false;
				}
			}
			Global_36484[iVar0 /*32*/].f_5 = 1;
			Global_36484[iVar0 /*32*/].f_29 = 1;
			return true;
		}
		else {
			if (Global_36484[iVar0 /*32*/] == 0) {
			}
			if (Global_36484[iVar0 /*32*/].f_7) {
			}
		}
	}
	return false;
}

// Position - 0x66AF
void func_131(var *uParam0, int iParam1, char *sParam2, int iParam3, char *sParam4, int iParam5, int iParam6) {
	int iVar0;

	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("context_controller")) < 1) {
	}
	if (streaming::is_player_switch_in_progress()) {
		if (*uParam0 != -1) {
			func_128(uParam0);
		}
		return;
	}
	if (*uParam0 != -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (!Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/] = 1;
			Global_36484[iVar0 /*32*/].f_1 = Global_36685;
			Global_36685++;
			Global_36484[iVar0 /*32*/].f_4 = 0;
			Global_36484[iVar0 /*32*/].f_29 = 0;
			Global_36484[iVar0 /*32*/].f_5 = 0;
			Global_36484[iVar0 /*32*/].f_2 = iParam1;
			StringCopy(&Global_36484[iVar0 /*32*/].f_8, sParam2, 16);
			Global_36484[iVar0 /*32*/].f_6 = iParam3;
			Global_36484[iVar0 /*32*/].f_31 = script::get_id_of_this_thread();
			Global_36484[iVar0 /*32*/].f_7 = 0;
			Global_36484[iVar0 /*32*/].f_3 = iParam5;
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				Global_36484[iVar0 /*32*/].f_12 = 1;
				StringCopy(&Global_36484[iVar0 /*32*/].f_13, sParam4, 64);
				Global_36484[iVar0 /*32*/].f_30 = iParam6;
			}
			else {
				Global_36484[iVar0 /*32*/].f_12 = 0;
				Global_36484[iVar0 /*32*/].f_30 = 0;
			}
			*uParam0 = Global_36484[iVar0 /*32*/].f_1;
			return;
		}
		iVar0++;
	}
}

// Position - 0x67DA
bool func_132(int iParam0) {
	int iVar0;

	if (player::is_player_playing(player::player_id())) {
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				iVar0 = func_93();
				if (!func_95(iVar0)) {
					return false;
				}
				switch (iParam0) {
				case 9:
				case 0:
					if (!player::is_player_ready_for_cutscene(player::player_id()) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_getting_into_a_vehicle(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_140() || Global_100747 ||
						Global_25192 || func_139() || func_99(8, -1) || func_138() || func_137() || func_136() ||
						func_135() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 1:
					if (player::is_player_being_arrested(player::player_id(), 1) || func_140() || Global_25192 ||
						func_139() || func_99(8, -1) || func_136() || func_138() || func_137() || func_135() ||
						G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 2:
					if (!player::is_player_ready_for_cutscene(player::player_id()) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_getting_into_a_vehicle(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_140() || Global_100747 ||
						Global_25192 || func_139() || func_99(8, -1) || func_136() || func_138() || func_137() ||
						func_135() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5 || LastDispatchedMessageOrCall != -1) {
						return false;
					}
					break;

				case 3:
					if (ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_140() || Global_100747 ||
						Global_25192 || func_139() || func_99(8, -1) || func_138() || func_137() || func_135() ||
						G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 4:
					if (func_140() || player::get_player_wanted_level(player::player_id()) > 0 || func_99(8, -1) ||
						func_135() || func_134() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 5:
					if (func_99(8, -1) || func_138() || func_137() || func_134() || func_133()) {
						return false;
					}
					if (streaming::is_player_switch_in_progress() && streaming::get_player_switch_type() != 3 &&
						streaming::get_player_switch_state() < 8) {
						return false;
					}
					break;

				case 6:
					if (entity::does_entity_exist(player::player_ped_id())) {
						if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
							player::get_player_wanted_level(player::player_id()) > 0 ||
							entity::is_entity_in_air(player::player_ped_id()) ||
							ped::is_ped_ragdoll(player::player_ped_id()) ||
							ped::is_ped_falling(player::player_ped_id()) ||
							player::is_player_being_arrested(player::player_id(), 1) ||
							player::is_player_climbing(player::player_id()) || func_140() || Global_25192 ||
							func_139() || func_99(8, -1) || func_137() || func_136() || func_135() ||
							G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
							return false;
						}
					}
					break;

				case 7:
					if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
						!player::is_player_control_on(player::player_id()) ||
						!player::is_player_ready_for_cutscene(player::player_id()) || !cam::is_screen_faded_in() ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) || func_140() || func_137() ||
						Global_100747 || Global_25192 || func_139() || Global_36912 || func_99(8, -1) || func_136() ||
						func_134() || func_135() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 8:
					if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
						!player::is_player_control_on(player::player_id()) ||
						!player::is_player_ready_for_cutscene(player::player_id()) || !cam::is_screen_faded_in() ||
						player::is_player_wanted_level_greater(player::player_id(), 0) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						ped::is_ped_swimming(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) || func_140() || Global_100747 ||
						Global_25192 || func_139() || func_99(8, -1) || func_136() || func_134() || func_138() ||
						func_137() || func_135()) {
						return false;
					}
					break;
				}
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x6EF7
var func_133() { return Global_91530.f_1; }

// Position - 0x6F05
int func_134() {
	if (Global_88746 != -1) {
		return gameplay::is_bit_set(Global_82612[Global_88746 /*34*/].f_15, 13);
	}
	return 0;
}

// Position - 0x6F2B
int func_135() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0x6F45
int func_136() {
	if (Global_69962) {
		return 1;
	}
	else if (Global_55816 && !Global_55822) {
		return 1;
	}
	return 0;
}

// Position - 0x6F6F
bool func_137() { return Global_91543.f_304 > 0; }

// Position - 0x6F80
bool func_138() { return Global_91543.f_303 > 0; }

// Position - 0x6F91
var func_139() { return Global_1315233; }

// Position - 0x6F9D
int func_140() {
	if (!network::network_is_game_in_progress()) {
		return Global_89302.f_44 == 1;
	}
	return 0;
}

// Position - 0x6FB9
bool func_141(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x7013
bool func_142(int iParam0) { return func_143(iParam0, Global_35781); }

// Position - 0x7024
int func_143(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x7205
int func_144(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		func_146(uParam0);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 0)) {
		func_145(uParam0);
	}
	return 1;
}

// Position - 0x7234
void func_145(var *uParam0) {
	audio::release_named_script_audio_bank("HEIST_BULLETIN_BOARD");
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_01"));
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_02"));
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_03"));
	if (uParam0->f_413 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_413);
	}
	if (uParam0->f_414 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_414);
	}
	ui::clear_additional_text(5, 0);
	gameplay::clear_bit(&Global_87834, *uParam0);
	gameplay::clear_bit(&uParam0->f_449, 0);
}

// Position - 0x729E
void func_146(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		if (!cutscene::is_cutscene_playing()) {
			if (gameplay::is_bit_set(uParam0->f_449, 2)) {
				func_70(uParam0, 0);
			}
		}
		func_147(uParam0);
		gameplay::clear_bit(&uParam0->f_449, 1);
		gameplay::clear_bit(&Global_87833, *uParam0);
	}
}

// Position - 0x72EA
void func_147(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_33) {
		if (entity::does_entity_exist(uParam0->f_428[iVar0])) {
			object::delete_object(&uParam0->f_428[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0x7326
void func_148() {
	int iVar0;
	int iVar1;

	if (func_315(7)) {
		if (!gameplay::is_bit_set(iLocal_41, 7)) {
			cutscene::request_cutscene("AH_2_EXT_P4", 8);
			script::request_script("lesterHandler");
			streaming::request_model(1385417869);
			gameplay::set_bit(&iLocal_41, 7);
		}
		else if (cutscene::_0xB56BBBCC2955D9CB()) {
			cutscene::set_cutscene_ped_prop_variation("LESTER", 1, 0, 0, 0);
		}
	}
	if (func_315(8)) {
		if (func_315(7)) {
			if (cutscene::has_this_cutscene_loaded("AH_2_EXT_P4") && script::has_script_loaded("lesterHandler") &&
				streaming::has_model_loaded(1385417869)) {
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					if (!func_3(0) || func_93() == 0) {
						cutscene::register_entity_for_cutscene(player::player_ped_id(), "MICHAEL", 0,
															   joaat("player_zero"), 0);
					}
					else {
						cutscene::register_entity_for_cutscene(uLocal_49[0], "MICHAEL", 2, joaat("player_zero"), 0);
						gameplay::set_bit(&iLocal_41, 12);
					}
				}
				if (func_3(0)) {
					if (entity::does_entity_exist(iLocal_45)) {
						cutscene::register_entity_for_cutscene(iLocal_45, "FRANKLIN", 1, joaat("player_one"), 0);
					}
				}
				cutscene::register_entity_for_cutscene(iLocal_46, "LESTER", 2, joaat("ig_lestercrest"), 0);
				gameplay::set_bit(&iLocal_41, 10);
				func_274(0);
				func_116(1);
				func_266(1, 1, 1, 0);
				func_73(1);
				iVar0 = 0;
				while (iVar0 < func_265(3)) {
					if (func_263(3, iVar0) == 12) {
						func_254(406771743);
					}
					iVar0++;
				}
				cutscene::start_cutscene(256);
				if (func_3(0)) {
					cutscene::set_cutscene_fade_values(0, 0, 0, 0);
				}
				func_107(7, 0);
				iLocal_44 = gameplay::get_game_timer();
			}
		}
		else if (cutscene::is_cutscene_playing()) {
			func_112();
			if (gameplay::is_bit_set(iLocal_41, 5)) {
				if (entity::does_entity_exist(
						cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")))) {
					entity::set_entity_visible(
						cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")), 1, 0);
				}
				gameplay::clear_bit(&iLocal_41, 5);
			}
			if (func_93() != 0) {
				if (gameplay::is_bit_set(iLocal_41, 12)) {
					if (entity::does_entity_exist(
							cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")))) {
						uLocal_49[0] = entity::get_ped_index_from_entity_index(
							cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")));
						gameplay::clear_bit(&iLocal_41, 12);
					}
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 10)) {
				if (entity::does_entity_exist(
						cutscene::get_entity_index_of_registered_entity("LESTER", joaat("ig_lestercrest")))) {
					iLocal_46 = entity::get_ped_index_from_entity_index(
						cutscene::get_entity_index_of_registered_entity("LESTER", joaat("ig_lestercrest")));
					gameplay::clear_bit(&iLocal_41, 10);
				}
			}
			if (cutscene::can_set_exit_state_for_registered_entity("MICHAEL", 0)) {
				if (func_93() != 0) {
					iLocal_45 = player::player_ped_id();
					func_249(&uLocal_49, 0);
					func_188(&uLocal_49, 1, 0, 0);
					streaming::set_model_as_no_longer_needed(joaat("player_zero"));
				}
				if (!ped::is_ped_injured(player::player_ped_id())) {
					ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 1, 0);
					ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
					if (cam::_0xEE778F8C7E1142E2(0) == 4) {
						player::simulate_player_input_gait(player::player_id(), 1f, 2000, 0, 1, 0);
					}
					ped::set_ped_config_flag(player::player_ped_id(), 208, 0);
					ped::set_ped_config_flag(player::player_ped_id(), 118, 1);
					ped::set_ped_config_flag(player::player_ped_id(), 213, 1);
					ped::set_blocking_of_non_temporary_events(player::player_ped_id(), 0);
					iLocal_43 = gameplay::get_game_timer();
				}
			}
			ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
			if (cutscene::can_set_exit_state_for_registered_entity("LESTER", joaat("ig_lestercrest"))) {
				if (!entity::is_entity_dead(iLocal_46, 0)) {
					iVar1 = iLocal_46;
					system::start_new_script_with_args("lesterHandler", &iVar1, 1, 1424);
					script::set_script_as_no_longer_needed("lesterHandler");
				}
			}
			if (cutscene::can_set_exit_state_for_camera(0)) {
				func_274(1);
			}
		}
		else {
			if (func_3(0)) {
				if (entity::does_entity_exist(iLocal_45)) {
					ped::delete_ped(&iLocal_45);
				}
				if (entity::does_entity_exist(iLocal_46)) {
					ped::delete_ped(&iLocal_46);
				}
				cam::do_screen_fade_out(0);
			}
			else {
				Global_55822 = 0;
				Global_91530 = 0;
				func_187();
			}
			func_266(0, 1, 1, 0);
			func_73(0);
			func_186(20000);
			func_184(&Global_101700.f_2095.f_539, 67);
			func_156(&Global_101700.f_2095.f_539, 67);
			streaming::set_model_as_no_longer_needed(1385417869);
			func_155(&iLocal_42);
			gameplay::clear_bit(&iLocal_41, 2);
			ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
			if (cam::_0xEE778F8C7E1142E2(0) == 4) {
				ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 0, 0);
				player::simulate_player_input_gait(player::player_id(), 1f, 2000, 0, 1, 0);
			}
			ped::remove_scenario_blocking_area(iLocal_93, 0);
			if (iLocal_94 != -1) {
				if (pathfind::does_navmesh_blocking_object_exist(iLocal_94)) {
					pathfind::remove_navmesh_blocking_object(iLocal_94);
				}
			}
			ped::clear_ped_non_creation_area();
			pathfind::set_ped_paths_in_area(Local_95.f_1.f_394 - Local_95.f_1.f_397,
											Local_95.f_1.f_394 + Local_95.f_1.f_397, 1, 0);
			player::set_max_wanted_level(5);
			func_149(3, 0);
			func_107(8, 0);
		}
	}
	else if (!func_315(7)) {
		if (cutscene::has_this_cutscene_loaded("AH_2_EXT_P4")) {
			cutscene::remove_cutscene();
		}
	}
	if (iLocal_43 != -1) {
		if (gameplay::get_game_timer() - iLocal_43 > 2000) {
			ped::set_ped_min_move_blend_ratio(player::player_ped_id(), 1f);
			iLocal_43 = -1;
		}
	}
}

// Position - 0x77AC
void func_149(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 14) {
		iVar1 = iVar0;
		if (func_40(iVar1) || func_39(iVar1)) {
			if (!(iVar1 == 11 && iParam0 == 3)) {
				switch (iVar1) {
				case 1: func_152(4, 1); break;

				case 4: func_152(8, 1); break;

				case 6: func_152(10, 1); break;

				case 7: func_152(1, 1); break;

				case 8: func_152(3, 1); break;

				case 9: func_152(6, 1); break;

				case 10: func_152(9, 1); break;

				case 12: func_152(11, 1); break;

				case 13: func_152(12, 1); break;

				case 11:
					if (func_311(91)) {
						func_152(0, 1);
					}
					break;

				case 5:
					if (func_311(91)) {
						func_152(2, 1);
					}
					break;

				case 3:
					if (func_311(67)) {
						func_152(5, 1);
					}
					break;

				case 2:
					if (func_311(77)) {
						func_152(7, 1);
					}
					break;
				}
			}
		}
		iVar0++;
	}
	if (!func_40(10) && gameplay::is_bit_set(Global_101700.f_23954.f_8[4], 0)) {
		func_152(9, 1);
	}
	if (!func_40(13) && gameplay::is_bit_set(Global_101700.f_23954.f_8[16], 0)) {
		func_152(12, 1);
	}
	if (!func_40(12)) {
		if (iParam0 == 4) {
			func_152(11, 1);
		}
	}
	if (!iParam1) {
		if (!func_151(69)) {
			func_23("DI_HLP_HST", 2, 0, 20000, 10000, 7, 0, 209, 0);
		}
		func_150("DI_FEED_HST");
	}
}

// Position - 0x7978
void func_150(char *sParam0) {
	ui::_set_notification_text_entry("");
	ui::_set_notification_message_3("CHAR_ACTING_UP", "CHAR_ACTING_UP", 0, 0, "DI_FEED_CHAR", sParam0);
}

// Position - 0x799C
int func_151(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		return gameplay::is_bit_set(Global_101700.f_19369.f_150[iVar1], iVar0);
	}
	return 0;
}

// Position - 0x79DF
void func_152(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 >= 0 && iVar0 <= 31) {
		if (!func_154(iParam0)) {
			gameplay::set_bit(&Global_101700.f_25393.f_1, iVar0);
			if (!iParam1) {
				func_150(func_153(iParam0));
			}
		}
	}
}

// Position - 0x7A28
char *func_153(int iParam0) {
	switch (iParam0) {
	case 0: return "CM_HSTCHE";

	case 1: return "CM_HSTCHR";

	case 2: return "CM_HSTDAR";

	case 3: return "CM_HSTEDD";

	case 4: return "CM_HSTGUS";

	case 5: return "CM_HSTHUG";

	case 6: return "CM_HSTKRM";

	case 7: return "CM_HSTKAR";

	case 8: return "CM_HSTNOR";

	case 9: return "CM_HSTPAC";

	case 10: return "CM_HSTPAI";

	case 11: return "CM_HSTRIC";

	case 12: return "CM_HSTTAL";
	}
	return "ERROR!";
}

// Position - 0x7B0B
int func_154(int iParam0) {
	if (iParam0 != -1 && iParam0 != 13) {
		return gameplay::is_bit_set(Global_101700.f_25393.f_1, iParam0);
	}
	return 0;
}

// Position - 0x7B3A
void func_155(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0x7B77
void func_156(var *uParam0, int iParam1) {
	switch (iParam1) {
	case 17: func_157(uParam0, 0, 12); break;

	case 19: func_157(uParam0, 1, 13); break;

	case 29: func_157(uParam0, 1, 14); break;

	case 30:
		func_157(uParam0, 2, 15);
		func_157(uParam0, 1, 29);
		break;

	case 32:
		func_157(uParam0, 1, 16);
		func_157(uParam0, 0, 17);
		break;

	case 39:
		func_157(uParam0, 0, 21);
		func_157(uParam0, 1, 20);
		break;

	case 31: func_157(uParam0, 0, 18); break;

	case 20: func_157(uParam0, 2, 22); break;

	case 66: func_157(uParam0, 1, 23); break;

	case 68: func_157(uParam0, 1, 24); break;

	case 70: func_157(uParam0, 1, 67); break;

	case 8:
		func_157(uParam0, 1, 25);
		func_157(uParam0, 2, 26);
		break;

	case 67: func_157(uParam0, 1, 27); break;

	case 9: func_157(uParam0, 2, 28); break;

	case 38:
		func_157(uParam0, 2, 30);
		func_157(uParam0, 1, 19);
		break;

	case 83: func_157(uParam0, 2, 33); break;

	case 45: func_157(uParam0, 1, 35); break;

	case 64:
		func_157(uParam0, 0, 36);
		func_157(uParam0, 1, 37);
		break;

	case 91: func_157(uParam0, 0, 41); break;

	case 42:
		func_157(uParam0, 0, 58);
		Global_90960[0 /*98*/] = 0;
		func_157(uParam0, 2, 59);
		Global_90960[2 /*98*/] = 0;
		break;

	case 41:
		func_157(uParam0, 1, 42);
		func_157(uParam0, 2, 42);
		break;

	case 15:
		func_157(uParam0, 0, 46);
		func_157(uParam0, 1, 47);
		break;

	case 16: func_157(uParam0, 0, 48); break;

	case 48:
		func_157(uParam0, 1, 50);
		func_157(uParam0, 2, 51);
		break;

	case 74:
		func_157(uParam0, 0, 52);
		func_157(uParam0, 1, 66);
		break;

	case 76:
		func_157(uParam0, 1, 53);
		func_157(uParam0, 2, 54);
		func_157(uParam0, 0, 62);
		break;

	case 75:
		func_157(uParam0, 0, 61);
		func_157(uParam0, 1, 31);
		break;

	case 69: func_157(uParam0, 1, 63); break;

	case 84:
		func_157(uParam0, 0, 68);
		func_157(uParam0, 2, 69);
		break;

	case 85:
		func_157(uParam0, 0, 64);
		func_157(uParam0, 2, 65);
		break;

	case 93:
		func_157(uParam0, 1, 38);
		func_157(uParam0, 2, 39);
		break;

	case 11: func_157(uParam0, 2, 55); break;

	case 77:
		func_157(uParam0, 1, 56);
		func_157(uParam0, 2, 57);
		break;

	default: break;
	}
}

// Position - 0x7EC0
int func_157(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	struct<98> Var1;
	var *uVar99;
	float *fVar102;
	var *uVar103;
	float *fVar106;

	if (!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9)) {
		iVar0 = Global_101700.f_17492[iParam1];
		if (iVar0 == 11) {
			return 0;
		}
		if (iVar0 == 8 || iVar0 == 9 || iVar0 == 10) {
			return 0;
		}
	}
	Global_101700.f_17492[iParam1] = iParam2;
	uParam0->f_1524[iParam1] = func_173();
	if (!func_172(iParam2, &uParam0->f_1528[iParam1 /*3*/], &uParam0->f_1538[iParam1])) {
		return 0;
	}
	if (!func_171(uParam0->f_1528[iParam1 /*3*/], 0f, 0f, 0f, 0)) {
		if (!func_171(Global_Switch_Positions[iParam2 /*3*/], 0f, 0f, 0f, 0)) {
			Var1.f_11 = 12;
			Var1.f_31 = 49;
			Var1.f_81 = 2;
			if (func_158(iParam1, iParam2, &Var1, &uVar99, &fVar102, &uVar103, &fVar106)) {
				Global_90960[iParam1 /*98*/] = {Var1};
			}
		}
	}
	uParam0->f_1542[iParam1] = 0;
	uParam0->f_1546[iParam1 /*3*/] = {0f, 0f, 0f};
	uParam0->f_1556[iParam1] = 0;
	return 1;
}

// Position - 0x7FE0
bool func_158(int iParam0, int iParam1, int *iParam2, var *uParam3, float *fParam4, var *uParam5, float *fParam6) {
	iParam2->f_3 = 1000;
	iParam2->f_1 = 0;
	iParam2->f_84 = 255;
	iParam2->f_85 = 255;
	iParam2->f_86 = 255;
	switch (iParam1) {
	case 5:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			if (object::is_point_in_angled_area(Global_91263[iParam0 /*3*/], -829.7478f, 192.117f, 76.73248f,
												-827.1384f, 153.8595f, 59.96172f, 33.25f, 0, 1)) {
				if (Global_91255[iParam0] == 1) {
					*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
					*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
					if (system::vmag2(*uParam3) > 5f * 5f) {
						*uParam3 = {0f, 0f, 0f};
						*fParam4 = 0f;
						return false;
					}
				}
			}
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 6:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 7:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 11:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {37.43f, -23.81f, 0f};
		*fParam4 = 127f;
		return true;

	case 8:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(28.826f, -1277.56f, -90.961f) - Vector(28.3203f, -1324.195f, -90.0089f)};
		*fParam4 = 1.27f - 194.1887f;
		return true;

	case 9: return func_158(iParam0, 8, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 10: return func_158(iParam0, 8, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 13:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 5f, 0f};
		*fParam6 = 5f;
		return true;

	case 14:
		func_160(iParam0, iParam2, 2);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 15:
		iParam2->f_97 = 0;
		*iParam2 = joaat("frogger");
		iParam2->f_5 = 34;
		iParam2->f_6 = 34;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 50f, 0f};
		*fParam6 = 15f;
		return true;

	case 55:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(4.8006f, -2965.499f, 782.1644f) - Vector(4.0205f, -2975.341f, 798.4536f)};
		*fParam4 = 246.1684f - 90f;
		return true;

	case 56:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 20f;
		return true;

	case 57:
		iParam2->f_97 = 0;
		*iParam2 = joaat("penumbra");
		*uParam3 = {Vector(28.764f, -1431.464f, 66.028f) - Vector(28.2954f, -1351.52f, 37.5988f)};
		*fParam4 = 141.28f - 90.0339f;
		return true;

	case 12:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam5 = {0f, 5f, 0f};
		*fParam6 = 5f;
		return true;

	case 16:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 15f, 0f};
		*fParam6 = 5f;
		return true;

	case 17:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 15f;
		return true;

	case 18:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 19:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 15f, 0f};
		*fParam6 = 10f;
		return true;

	case 20:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 23: return func_158(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 24:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 67:
		func_160(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {21.6401f, 38.5601f, 1.9708f};
		*fParam4 = -84f;
		return true;

	case 58:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 59:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 60:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 22:
		iParam2->f_97 = 0;
		*iParam2 = joaat("phantom");
		*uParam5 = {0f, 50f, 0f};
		*fParam6 = 20f;
		return true;

	case 74:
		func_160(iParam0, iParam2, 1);
		iParam2->f_91 = 2;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 10f;
		return true;

	case 38:
		func_160(iParam0, iParam2, 2);
		iParam2->f_91 = 2;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 15f;
		return true;

	case 41:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-2.72f, 0.45f, 1f};
		*fParam4 = -137f;
		return true;

	case 25:
		iParam2->f_97 = 0;
		*iParam2 = joaat("blista");
		*uParam3 = {Vector(29.17f, -1417.047f, 54.081f) - Vector(28.2915f, -1464.68f, 72.2278f)};
		*fParam4 = 0.72f - 156.8827f;
		return true;

	case 27:
		iParam2->f_97 = 0;
		*iParam2 = joaat("seminole");
		*uParam3 = {Vector(24.9f, -938.8f, 792.3f) - Vector(24.2312f, -906f, 763f)};
		*fParam4 = 2.23f - 7.2736f;
		return true;

	case 26:
		iParam2->f_97 = 0;
		*iParam2 = joaat("peyote");
		*uParam3 = {Vector(28.701f, -1090.07f, 306.036f) - Vector(28.3684f, -1120.786f, 257.9167f)};
		*fParam4 = -1f - 97.2736f;
		return true;

	case 40:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {16.5182f, -8.5576f, -2.3291f};
		*fParam4 = 174.24f;
		return true;

	case 28:
		iParam2->f_97 = 0;
		*iParam2 = joaat("polmav");
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 234:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {16.5182f, -8.5576f, -2.3291f};
		*fParam4 = 174.24f;
		return true;

	case 75:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {2.5f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 76:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {2.5f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 42:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(4.8006f, -2965.499f, 782.1644f) - Vector(4.0205f, -2975.341f, 798.4536f)};
		*fParam4 = 246.1684f - 90f;
		return true;

	case 43:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(5.4446f, -2912.043f, 659.5297f) - Vector(5.0589f, -2916.479f, 709.0244f)};
		*fParam4 = 247.4806f - 355.326f;
		return true;

	case 44:
		iParam2->f_97 = 0;
		*iParam2 = joaat("sadler");
		*uParam3 = {Vector(5.1176f, -2936.843f, 656.9753f) - Vector(5.1337f, -2917.325f, 643.5248f)};
		*fParam4 = 253.776f - 334.1068f;
		return true;

	case 45:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mixer");
		*uParam3 = {Vector(5.681f, -2769.795f, 593.033f) - Vector(5.0558f, -2819.085f, 594.4415f)};
		*fParam4 = 2.62f - 299.0519f;
		return true;

	case 47:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cavalcade");
		iParam2->f_5 = 0;
		iParam2->f_6 = 0;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		StringCopy(&iParam2->f_27, "22LJK483", 16);
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {0f, 10f, 0f};
		*fParam6 = 15f;
		return true;

	case 49:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {-1.5f, 35f, 3f};
		*fParam6 = 15f;
		return true;

	case 48:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {3.8721f, -5.9568f, 0f};
		*fParam4 = 164.2466f - 180f;
		return true;

	case 50:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 10f, 0f};
		*fParam6 = 15f;
		return true;

	case 51:
		iParam2->f_97 = 0;
		*iParam2 = joaat("stretch");
		*uParam3 = {Vector(28.1755f, -550.2679f, -1170.72f) - Vector(30.2361f, -526.9999f, -1257.5f)};
		*fParam4 = 310.4708f - 220.9554f;
		return true;

	case 52:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 12.5f;
		return true;

	case 66:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 12.5f;
		return true;

	case 61:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 62:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 63:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-2.9117f, -15.0499f, -0.3468f};
		*fParam4 = -139.9751f;
		return true;

	case 64:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 69:
		iParam2->f_97 = 0;
		*iParam2 = joaat("prairie");
		*uParam3 = {Vector(36.5734f, -85.1799f, -737.1358f) - Vector(54f, 111f, -852f)};
		*fParam4 = 64.1848f - 180f;
		return true;

	case 65:
	case 54:
		iParam2->f_97 = 0;
		*iParam2 = joaat("frogger2");
		iParam2->f_5 = 40;
		iParam2->f_6 = 0;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		iParam2->f_89 = 1;
		if (iParam1 == 54) {
			*uParam3 = {5.5414f, -6.6035f, 1.0473f};
			*fParam4 = -83.2547f;
		}
		if (iParam1 == 65) {
			*uParam3 = {5.7209f, -12.3958f, 1.0746f};
			*fParam4 = -152.2593f;
		}
		return true;

	case 112:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 113:
		if (func_158(iParam0, 112, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 118:
		iParam2->f_97 = 0;
		*iParam2 = joaat("scorcher");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {1f, 12.5f, 0f};
		*fParam6 = 5f;
		return true;

	case 119:
		if (func_158(iParam0, 118, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {5f, 20f, 0f};
			*fParam6 = 5f;
			return true;
		}
		break;

	case 120:
		if (func_158(iParam0, 118, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 30f, 0f};
			*fParam6 = 8f;
			return true;
		}
		break;

	case 173:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cruiser");
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 114:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {-1.9002f, 1.205f, -0.3537f};
		*fParam4 = -180f;
		return true;

	case 105:
		func_160(iParam0, iParam2, 1);
		*uParam5 = {0f, 0.1f, 0f};
		*fParam6 = 0.5f;
		return true;

	case 106: return func_158(iParam0, 105, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 107: return func_158(iParam0, 105, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 98:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 99:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {0f, 0f, 0f};
		*fParam6 = 0f;
		return true;

	case 100: return func_158(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 101: return func_158(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 102: return func_158(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 123:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {3.2267f, 1.0966f, -0.354f};
		*fParam4 = -31.73f;
		return true;

	case 125:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-13.7322f, 1.8783f, 1.0593f};
		*fParam4 = 55.3652f;
		return true;

	case 133:
		iParam2->f_97 = 0;
		*iParam2 = joaat("tropic");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		iParam2->f_11[0] = 0;
		iParam2->f_11[1] = 0;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 0;
		iParam2->f_11[4] = 0;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 89:
	case 90:
	case 127:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 0f, 0f};
		*fParam6 = 0.1f;
		return true;

	case 91:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {15.4538f, -8.711f, 5.79f};
		*fParam4 = 2.4942f;
		return true;

	case 93:
		if (func_158(iParam0, 91, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-8.1f, -9.01f, 0.4439f};
			*fParam4 = 94.03f;
			return true;
		}
		break;

	case 121:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {18.8468f, 40.7721f, 0f};
		*fParam4 = -116.3936f;
		return true;

	case 115:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(43.517f, -33.7052f, -531.6035f) - Vector(45.6141f, -21.87f, -511.73f)};
		*fParam4 = 177.259f - 180f - 69f;
		return true;

	case 116:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {1.7826f, 12.2098f, -0.6964f};
		*fParam4 = -96.0001f;
		return true;

	case 117:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {11.8705f, -1.4684f, -1.6487f};
		*fParam4 = -125.8331f;
		return true;

	case 94:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-13.1578f, 16.3962f, 0.6396f};
		*fParam4 = -177f;
		return true;

	case 96:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-21.0518f, 0.5037f, 0.4091f};
		*fParam4 = -83.1262f;
		return true;

	case 108:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {10.8971f, 2.0809f, -0.7983f};
		*fParam4 = -150.9417f;
		return true;

	case 109:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {79.9901f, -52.83f, -0.3533f};
		*fParam4 = 44.7231f;
		return true;

	case 135:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 136:
		if (func_158(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 137:
		if (func_158(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 138:
		if (func_158(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 139:
		if (func_158(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {2.4845f, 2.3286f, -0.383f};
			*fParam4 = -31.4884f;
			return true;
		}
		break;

	case 140:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 15f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 141:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 40f, 0f};
			*fParam6 = 12.5f;
			return true;
		}
		break;

	case 142:
		func_160(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 10f;
		return true;

	case 143:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 144:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 145:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 146:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 147:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 15f, 0f};
			*fParam6 = 7.5f;
			return true;
		}
		break;

	case 148:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 149:
		if (func_158(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 151:
		if (func_158(iParam0, 94, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-13.2213f, 16.331f, 0f};
			*fParam4 = 6f;
			return true;
		}
		break;

	case 162:
		if (func_158(iParam0, 115, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {10.3876f, -10.3585f, -1.2183f};
			*fParam4 = 8.6726f;
			return true;
		}
		break;

	case 158:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {1.0793f, 15.631f, 1.1744f};
		*fParam4 = 2.52f;
		return true;

	case 166: return func_158(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 170:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 171: return func_158(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 172: return func_158(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 208:
		func_160(iParam0, iParam2, 1);
		*uParam5 = {0f, 0.1f, 0f};
		*fParam6 = 0.5f;
		return true;

	case 209: return func_158(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 210: return func_158(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 211:
		func_159(iParam0, iParam2, 2);
		iParam2->f_91 = 2;
		*uParam3 = {-2.19f, -1.23f, 0f};
		*fParam4 = 90f;
		return true;

	case 212:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		iParam2->f_2 = 0f;
		*uParam3 = {-1.3547f, 2.1615f, -0.3723f};
		*fParam4 = 177.8041f;
		return true;

	case 213:
		if (func_158(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-4.2075f, 1.0943f, 0f};
			*fParam4 = 15.82f;
			return true;
		}
		break;

	case 214:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		iParam2->f_2 = 0f;
		*uParam3 = {2.291f, 1.0879f, 0.0635f};
		*fParam4 = 177.798f;
		return true;

	case 215:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {-0.9714f, 1.6112f, -0.2773f};
		*fParam4 = -7.0583f;
		*uParam5 = {Vector(183.8081f, 578.5989f, 174.7651f) - Vector(176.086f, 551.7596f, 10.9694f)};
		*fParam6 = 10f;
		return true;

	case 196:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {Vector(29.4846f, -1457.915f, -17.4132f) - Vector(31.1932f, -1441.182f, -14.8689f)};
		*fParam4 = 89.0026f - -1.5f;
		*uParam5 = {Vector(33.6125f, -1563.461f, -147.0307f) - Vector(31.1932f, -1441.182f, -14.8689f)};
		*fParam6 = 10f;
		return true;

	case 221:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(43.5168f, -33.5909f, -531.4f) - Vector(45.2617f, -28.54f, -521.13f)};
		*fParam4 = 357.1407f - 84.96f;
		return true;

	case 216:
		if (func_158(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-2.1752f, -2.3781f, 0f};
			*fParam4 = -68.4f;
			return true;
		}
		break;

	case 217:
		if (func_158(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-3.9761f, 0.2542f, 0f};
			*fParam4 = -70.5273f;
			return true;
		}
		break;

	case 232:
	case 233:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {Vector(28.225f, -1015.11f, -70.4456f) - Vector(27.5447f, -1019.235f, -78.4023f)};
		*fParam4 = 162.098f - 109.0206f;
		return true;

	case 192:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.403f, -1531.113f, -1190.017f) - Vector(4.7514f, -1573.632f, -1174.458f)};
		*fParam4 = 302.182f - 105.981f;
		return true;

	case 193:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.403f, -1531.113f, -1190.017f) - Vector(4.3599f, -1573.692f, -1175.298f)};
		*fParam4 = 302.182f - 172.9187f;
		return true;

	case 194:
		if (func_158(iParam0, 193, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {12.74f, 3.26f, 0f};
			*fParam4 = 95.217f;
			return true;
		}
		break;

	case 195:
		if (func_158(iParam0, 193, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-1.34f, 7.684f, 0f};
			*fParam4 = 173.52f;
			return true;
		}
		break;

	case 200:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.4055f, -1607.568f, 44.4802f) - Vector(28.2858f - 0.5f + 1.5f, -1607.286f, 2.8895f)};
		*fParam4 = 318.2674f - (310.879f - 180f);
		return true;

	case 201:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.1773f, -1592.787f, 3.6009f) - Vector(29.2903f, -1607.286f, 2.8895f)};
		*fParam4 = 322.6286f - 130.879f;
		return true;

	case 202:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {91.3579f, 18.1788f, -0.1911f};
		*fParam4 = -90.3475f;
		return true;

	case 222:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {12.5073f, -3.4625f, -0.3702f};
		*fParam4 = 14.3405f;
		return true;

	case 223:
		if (func_158(iParam0, 222, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {21.87f, -10.5f, 0f};
			*fParam4 = -104.76f;
			return true;
		}
		break;

	case 224: return func_158(iParam0, 222, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 226:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.7f, -1356.9f, 24.6f) - Vector(29.3437f, -1351.412f, 28.986f)};
		*fParam4 = 270.1767f - 160f - 180f;
		return true;

	case 227:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-19.8544f, -10.4863f, -0.0334f};
		*fParam4 = -120.12f;
		return true;

	case 228:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {21.5897f, -6.8544f, 0.6015f};
		*fParam4 = -141f;
		return true;

	case 229:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-7.6041f, 0.1369f, 0.5812f};
		*fParam4 = -145.769f;
		return true;

	case 230:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-1.6f, 7.6802f, 0.6947f};
		*fParam4 = -50.99f;
		return true;

	case 238:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {22.322f, -6.2034f, 0f};
		*fParam4 = 73.071f;
		return true;

	case 250:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {-1.2901f, -5.5798f, -0.0357f};
		*fParam4 = 160.56f;
		return true;

	case 251:
		if (func_158(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-4.0739f, 7.7692f, -0.2984f};
			*fParam4 = -48.9552f;
			return true;
		}
		break;

	case 252:
		if (func_158(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-5.778f, -4.2397f, 0.9091f};
			*fParam4 = -12.9418f;
			return true;
		}
		break;

	case 253:
		if (func_158(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {0.6968f, 1.1033f, 0.912f};
			*fParam4 = 90f;
			return true;
		}
		break;

	case 281:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 8f, 0.6f};
		*fParam6 = 15f;
		return true;

	case 282:
		if (func_158(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			return true;
		}
		break;

	case 283:
		if (func_158(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			return true;
		}
		break;

	case 284:
		if (func_158(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			iParam2->f_97 = 0;
			*iParam2 = joaat("faggio2");
			iParam2->f_91 = 0;
			return true;
		}
		break;

	case 275:
		func_159(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 8f, 0.6f};
		*fParam6 = 15f;
		return true;

	case 276: return func_158(iParam0, 275, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 277: return func_158(iParam0, 275, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 280:
		if (!Global_3) {
			iParam2->f_97 = 0;
			*iParam2 = joaat("tropic");
			iParam2->f_11[0] = 0;
			iParam2->f_11[1] = 0;
			iParam2->f_11[2] = 1;
			iParam2->f_11[3] = 0;
			iParam2->f_11[4] = 0;
			iParam2->f_11[5] = 1;
			iParam2->f_11[6] = 1;
			iParam2->f_11[7] = 1;
			iParam2->f_11[8] = 1;
		}
		else {
			iParam2->f_97 = 0;
			*iParam2 = joaat("dinghy");
		}
		*uParam3 = {Vector(-0.6187f, -1440.421f, 2779.759f) - Vector(0.3109f, -1453.731f, 2789.845f)};
		uParam3->f_2 += 0.5f;
		*fParam4 = 340.0835f - 4.44f;
		*uParam3 = {Vector(-0.7f, 16.55f, -3.3962f) + Vector(0.5f, 0.5f, -0.5f)};
		*fParam4 = 23.6441f + 90f;
		*uParam3 = {-4.0164f, 19.9594f, 0f};
		*fParam4 = 113.6465f;
		*uParam3 = {*uParam3 * FtoV(1.1f)};
		return true;

	case 247:
		iParam2->f_97 = 0;
		*iParam2 = joaat("sanchez");
		*uParam3 = {9.8707f, 13.0084f, 0f};
		*fParam4 = -114f - 43f + 133f;
		return true;

	case 288:
		iParam2->f_97 = 0;
		*iParam2 = joaat("speedo");
		*uParam3 = {-7.7078f, 23.9099f, 1.7307f};
		*fParam4 = 24.3187f;
		return true;

	case 309:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-4.5662f, -3.2485f, 0.9455f - 1.7f};
		*fParam4 = -138.6056f;
		return true;

	case 305:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(33.8797f, 3597.047f, 1399.662f) - Vector(37.9419f, 3602.284f, 1394.208f)};
		*fParam4 = 315.9865f - 122.5269f;
		return true;

	case 310:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {10.5999f, 3.3997f, 1.0212f};
		*fParam4 = -50.3062f;
		return true;

	case 255:
		iParam2->f_97 = 0;
		*iParam2 = joaat("romero");
		*uParam3 = {-13.2279f, -7.5348f, 0f};
		*fParam4 = 4.32f;
		return true;

	case 265:
		iParam2->f_97 = 0;
		*iParam2 = joaat("bmx");
		*uParam3 = {11.9596f, 0.345f, -1.0016f};
		*fParam4 = -42.4225f;
		return true;

	case 285:
		iParam2->f_97 = 0;
		*iParam2 = joaat("gburrito");
		*uParam3 = {3.424f, 7.6462f, 0.8227f};
		*fParam4 = -150f;
		return true;

	case 256:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(7.1164f, -1094.205f, -1243.65f) - Vector(7.1f, -1105.15f, -1242.68f)};
		*fParam4 = 14.0848f - 120f;
		return true;

	case 257:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(6.8143f, -930.5448f, -1672.535f) - Vector(6.479f, -974.7168f, -1667.148f)};
		*fParam4 = 144.9416f - 171.253f;
		return true;

	case 258:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.3025f, 6276.12f, -267.5488f) - Vector(30.5054f, 6250.9f, -301.4778f)};
		*fParam4 = 130.9896f - 10.247f;
		return true;

	case 314:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cuban800");
		*uParam5 = {0f, 150f, 20f};
		*fParam6 = 30f;
		return true;
	}
	switch (iParam1) {
	case 110:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(32.5629f, -387.5143f, -147.166f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 341.4322f - 133f;
		return true;

	case 111:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(24.4283f, -689.1462f, -1306.782f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 214.6826f - 33f;
		return true;

	case 153:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.3324f, 254.0631f, -708.9244f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.2022f - -176.25f;
		return true;

	case 154:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.3324f, 254.0631f, -708.9244f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.2022f - -147.192f;
		return true;

	case 165:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(35.0054f, -441.1681f, -1100.878f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 297.5568f - -144.622f;
		return true;

	case 159:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(36.3852f, -199.5354f, -825.3141f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 29.4869f - -62.5f;
		return true;

	case 160:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(36.2086f, -144.1027f, -730.8218f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 28.532f - 119f;
		return true;

	case 167:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(31.7307f, -523.2257f, -1144.174f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 299.2956f - -22.32f;
		return true;

	case 152:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(60.9436f, 314.6989f, -1421.8f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 335.4134f - 72f;
		return true;

	case 157:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.469f, 255.3143f, -706.187f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 117.3069f - 37.27f;
		return true;

	case 225:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.7165f, -1677.734f, 185.4888f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 54.2538f - -83.8f;
		return true;

	case 218:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.3218f, -1405.159f, -17.556f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 91.3098f - -70.4124f;
		return true;

	case 219:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.2611f, -1492.151f, -219.3172f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 139.2572f - -12f;
		return true;

	case 220:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(25.3018f, -1811.693f, -22.6138f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 141.0423f - -117.356f;
		return true;

	case 206:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(208.5337f, 773.6719f, 164.1308f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 136.3104f - -36f;
		return true;

	case 207:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(108.9995f, 396.924f, -263.3745f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 284.4611f - -95.588f;
		return true;

	case 274:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(139.5782f, 2030.446f, -1883.836f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 340.5746f - 9f;
		return true;

	case 312:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.0296f, 6560.557f, -200.684f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 134.5505f - 110.5931f;
		return true;

	case 271:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(6.4647f, -1083.751f, -1278.023f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.8919f - 26.3597f;
		return true;

	case 248:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(102.4417f, 164.5124f, 325.8113f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 68.4108f - 10.77f;
		return true;

	case 242:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(56.616f, -122.9896f, -1622.22f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 210.8653f - 13.7207f;
		return true;

	case 254:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(53.0019f, -213.7796f, 172.442f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 250.3032f - -40f;
		return true;

	case 287:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(17.3426f, -836.0328f, -887.9977f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 270.8607f - -81f;
		return true;

	case 286:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(4.8359f, -1182.704f, -1264.218f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 298.4328f - -150f;
		return true;

	case 239:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(104.8218f, 289.0073f, -80.4564f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 247.6446f - -122f;
		return true;

	case 243:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2762f, -1477.282f, 434.9171f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 228.6353f - 18f;
		return true;

	case 244:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2762f, -1477.282f, 434.9171f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 228.6353f - -51f;
		return true;

	case 249:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(103.1881f, 177.7729f, 288.977f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 68.9831f - (138f - 180f);
		return true;

	case 273:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(32.7794f, -432.4635f, -161.4589f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 340.0368f - -153f;
		return true;

	case 92:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(202.1143f, 828.3607f, -806.8813f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 101.1612f - -54.347f;
		return true;

	case 103:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(12.0174f, -1108.081f, -1724.72f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 319.8931f - 143.4931f;
		return true;

	case 109:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.2248f, -628.4899f, -1859.505f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 229.0784f - 99f;
		return true;

	case 81:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(53.1469f, 90.4242f, -1393.442f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 123.1782f - -45f;
		return true;

	case 95:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(101.921f, 186.1865f, 370.5876f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 159.7861f - 70f;
		return true;

	case 97:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(45.9871f, -188.5636f, -1391.156f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 36.5172f - -45f;
		return true;

	case 134:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(46.0567f, 3076.742f, 2001.918f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 328.101f - -33.128f;
		return true;

	case 88:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(60.9442f, 314.7191f, -1421.821f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 336.5938f - -132f;
		return true;

	case 306:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(37.4888f, 5643.726f, -569.3535f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 296.1685f - gameplay::get_heading_from_vector_2d(7.4998f, -7.4995f);
		return true;

	case 307:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(47.4526f, 4717.728f, -1555.593f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 236.223f - gameplay::get_heading_from_vector_2d(-10.6345f, -0.7246f);
		return true;

	case 308:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(22.7549f, 4629.148f, -1553.861f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 332.7842f - gameplay::get_heading_from_vector_2d(3.4271f, 13.6787f);
		return true;

	case 278:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(35.9161f, -1009.745f, 631.8275f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 98.8128f - -33.77f;
		return true;

	case 279:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(234.6825f, 900.8749f, -111.9033f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 6.1087f - 155.68f;
		return true;

	case 240:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(33.5351f, 3636.151f, 1546.323f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 298.4009f - -4.124f;
		return true;

	case 241:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.512f, 6439.667f, -179.4242f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 225.5593f - 108f;
		return true;

	case 264:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2977f, -1390.545f, 486.7419f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 178.298f - -90f;
		return true;

	case 266:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.5662f, 143.2342f, -3052.895f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 85.3429f - 68.8227f;
		return true;

	case 267:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(39.9155f, 4934.08f, 2202.375f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 314.2654f - 56.2037f;
		return true;

	case 269:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.149f, -782.0952f, 401.2502f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 179.9905f - -106.6605f;
		return true;

	case 246:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.3919f, -1534.507f, -1195.256f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 305.8221f - -165f;
		return true;

	case 263:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(12.8792f, -1241.213f, -573.3765f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 316.9941f - -171f;
		return true;

	case 259:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(4.0002f, -1298.539f, -724.429f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 230.5715f - -32.488f;
		return true;

	case 260:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(61.203f, 250.8387f, -1309.114f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 10.7756f - -29.093f;
		return true;

	case 261:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.764f, 60.3233f, 917.6678f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 148.021f - 229.6085f;
		return true;

	case 270:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {Vector(350f, 8588f, 2919f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 289:
		func_160(iParam0, iParam2, 0);
		*uParam3 = {-48.5171f, 28.4211f, 3.0057f};
		*fParam4 = -1.3831f;
		return true;
	}
	return false;
}

// Position - 0xB453
void func_159(int iParam0, int *iParam1, int iParam2) {
	int iVar0;

	iParam1->f_88 = 1;
	iParam1->f_84 = 255;
	iParam1->f_85 = 255;
	iParam1->f_86 = 255;
	iParam1->f_97 = 1;
	iParam1->f_3 = 1000;
	iParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*iParam1 = iVar0;
			iParam1->f_2 = 3f;
			iParam1->f_4 = 0;
			iParam1->f_9 = 1;
			iParam1->f_11[0] = 1;
			StringCopy(&iParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*iParam1 = iVar0;
			iParam1->f_2 = 14.9f;
			iParam1->f_5 = 43;
			iParam1->f_6 = 43;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			iParam1->f_9 = 0;
			StringCopy(&iParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*iParam1 = iVar0;
			iParam1->f_2 = 14f;
			iParam1->f_5 = 32;
			iParam1->f_6 = 0;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			StringCopy(&iParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				iParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*iParam1 = iVar0;
			iParam1->f_2 = 6f;
			iParam1->f_5 = 53;
			iParam1->f_6 = 0;
			iParam1->f_7 = 59;
			iParam1->f_8 = 156;
			StringCopy(&iParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*iParam1 = iVar0;
			iParam1->f_2 = 0f;
			iParam1->f_5 = 111;
			iParam1->f_6 = 111;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			iParam1->f_10 = 1;
			StringCopy(&iParam1->f_27, "FC1988", 16);
			iParam1->f_11[0] = 1;
			iParam1->f_11[1] = 1;
			iParam1->f_11[2] = 1;
			iParam1->f_11[3] = 1;
			iParam1->f_11[4] = 1;
			iParam1->f_11[5] = 1;
			iParam1->f_11[6] = 1;
			iParam1->f_11[7] = 1;
			iParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xB6AF
int func_160(int iParam0, int *iParam1, int iParam2) {
	if (Global_90960[iParam0 /*98*/] == 0) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("blimp")) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (func_170(iParam0)) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_boat(Global_90960[iParam0 /*98*/])) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_plane(Global_90960[iParam0 /*98*/])) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_heli(Global_90960[iParam0 /*98*/])) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_train(Global_90960[iParam0 /*98*/])) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (iParam2 == 1) {
		if (!vehicle::is_this_model_a_car(Global_90960[iParam0 /*98*/])) {
			func_159(iParam0, iParam1, iParam2);
			iParam1->f_91 = iParam2;
			return 1;
		}
	}
	else if (iParam2 == 2) {
		if (!vehicle::is_this_model_a_bike(Global_90960[iParam0 /*98*/])) {
			func_159(iParam0, iParam1, iParam2);
			iParam1->f_91 = iParam2;
			return 1;
		}
	}
	if (!func_161(Global_90960[iParam0 /*98*/], 0)) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (iParam2 != 0) {
		func_159(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		if (Global_90960[iParam0 /*98*/] != *iParam1) {
			*iParam1 = {Global_90960[iParam0 /*98*/]};
			iParam1->f_91 = 0;
			return 0;
		}
	}
	else {
		func_159(iParam0, iParam1, 1);
		iParam1->f_91 = 1;
		if (Global_90960[iParam0 /*98*/] == *iParam1) {
			func_159(iParam0, iParam1, 1);
			iParam1->f_91 = 1;
			return 1;
		}
		func_159(iParam0, iParam1, 2);
		iParam1->f_91 = 2;
		if (Global_90960[iParam0 /*98*/] == *iParam1) {
			func_159(iParam0, iParam1, 2);
			iParam1->f_91 = 2;
			return 1;
		}
		*iParam1 = {Global_90960[iParam0 /*98*/]};
		iParam1->f_91 = 0;
		return 0;
	}
	func_159(iParam0, iParam1, iParam2);
	iParam1->f_91 = iParam2;
	return 1;
}

// Position - 0xB8E6
int func_161(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_169()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_168() && !func_167() && !func_166() && !func_165() && !func_169()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_166()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_164(iParam0)) {
			return 0;
		}
	}
	if (!func_162(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0xBA74
int func_162(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_163()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0xBB40
int func_163() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0xBB54
int func_164(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0xC898
int func_165() { return 0; }

// Position - 0xC8A1
int func_166() { return 1; }

// Position - 0xC8AA
int func_167() { return 1; }

// Position - 0xC8B3
int func_168() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0xC8CC
int func_169() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return 1;
			}
		}
	}
	if (Global_139179 == 2) {
		return 1;
	}
	else if (Global_139179 == 3) {
		return 0;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xC987
bool func_170(int iParam0) {
	if (Global_90960[iParam0 /*98*/] == joaat("blimp") || Global_90960[iParam0 /*98*/] == joaat("blimp2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("submersible") || Global_90960[iParam0 /*98*/] == joaat("submersible2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("freight")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("packer")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("asea2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("burrito2") || Global_90960[iParam0 /*98*/] == joaat("fbi2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("entityxf") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("cheetah") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("policeb") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("ztype") && !Global_101700.f_8044.f_330[9 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("polmav") && !Global_101700.f_8044.f_330[9 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("jb700") && !Global_101700.f_8044.f_330[10 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("monroe") && !Global_101700.f_8044.f_330[11 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("firetruk")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("handler")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("monroe")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("phantom")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("gauntlet") && !Global_101700.f_8044.f_330[80 /*6*/] &&
		!Global_101700.f_8044.f_330[81 /*6*/] && !Global_101700.f_8044.f_330[82 /*6*/]) {
		return true;
	}
	return false;
}

// Position - 0xCC07
bool func_171(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0xCC4E
int func_172(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_172(8, uParam1, fParam2);

	case 10: return func_172(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0xD5BD
var func_173() {
	int *iVar0;

	func_183(&iVar0, time::get_clock_seconds());
	func_182(&iVar0, time::get_clock_minutes());
	func_181(&iVar0, time::get_clock_hours());
	func_176(&iVar0, time::get_clock_day_of_month());
	func_175(&iVar0, time::get_clock_month());
	func_174(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0xD603
void func_174(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0xD689
void func_175(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0xD6BC
void func_176(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_180(*uParam0);
	iVar1 = func_178(*uParam0);
	if (iParam1 < 1 || iParam1 > func_177(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0xD70D
int func_177(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0xD7AF
var func_178(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_179(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0xD7D4
int func_179(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0xD7EB
int func_180(var uParam0) { return uParam0 & 15; }

// Position - 0xD7F8
void func_181(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0xD832
void func_182(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0xD86D
void func_183(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0xD8A9
void func_184(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_172(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_185(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0xDA72
void func_185(int *iParam0) { *iParam0 = -15; }

// Position - 0xDA80
void func_186(int iParam0) { Global_36332 = gameplay::get_game_timer() + iParam0; }

// Position - 0xDA92
int func_187() {
	if (func_3(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0xDADD
int func_188(var *uParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	char cVar6[64];
	int iVar22;
	var uVar23;
	char *sVar24;

	if (!uParam0->f_39) {
		if (uParam0->f_7 == 4) {
			return 1;
		}
	}
	if (!ped::is_ped_injured((*uParam0)[uParam0->f_7]) && !ped::is_ped_injured(player::player_ped_id()) &&
		(*uParam0)[uParam0->f_7] != player::player_ped_id()) {
		if (!iParam2) {
			if (ped::is_ped_ragdoll(player::player_ped_id()) && !fire::is_entity_on_fire(player::player_ped_id()) &&
				!ped::is_ped_getting_into_a_vehicle(player::player_ped_id())) {
				ai::clear_ped_tasks_immediately(player::player_ped_id());
			}
			else {
				ai::clear_ped_tasks(player::player_ped_id());
			}
			if (ped::is_ped_ragdoll((*uParam0)[uParam0->f_7]) && !fire::is_entity_on_fire((*uParam0)[uParam0->f_7]) &&
				!ped::is_ped_getting_into_a_vehicle((*uParam0)[uParam0->f_7])) {
				ai::clear_ped_tasks_immediately((*uParam0)[uParam0->f_7]);
			}
			else {
				ai::clear_ped_tasks((*uParam0)[uParam0->f_7]);
			}
		}
		iVar0 = player::player_ped_id();
		iVar1 = func_93();
		if (!uParam0->f_23) {
			func_237(iVar0, 0);
		}
		func_235(iVar1, &iVar0);
		ped::set_ped_config_flag(iVar0, 32, 1);
		ped::set_ped_config_flag(iVar0, 250, 1);
		iVar2 = func_234(uParam0->f_7);
		func_237((*uParam0)[uParam0->f_7], 0);
		fVar3 = (system::to_float(entity::get_entity_health((*uParam0)[uParam0->f_7])) - 100f) /
				(system::to_float(ped::get_ped_max_health((*uParam0)[uParam0->f_7])) - 100f) * 100f;
		switch (func_96(player::player_ped_id())) {
		case 0:
			if (graphics::_get_screen_effect_is_active("BulletTime")) {
				graphics::_stop_screen_effect("BulletTime");
			}
			if (graphics::_get_screen_effect_is_active("BulletTimeOut")) {
				graphics::_stop_screen_effect("BulletTimeOut");
			}
			break;

		case 1:
			if (graphics::_get_screen_effect_is_active("DrivingFocus")) {
				graphics::_stop_screen_effect("DrivingFocus");
			}
			if (graphics::_get_screen_effect_is_active("DrivingFocusOut")) {
				graphics::_stop_screen_effect("DrivingFocusOut");
			}
			break;

		case 2:
			if (graphics::_get_screen_effect_is_active("REDMIST")) {
				graphics::_stop_screen_effect("REDMIST");
			}
			if (graphics::_get_screen_effect_is_active("REDMISTOut")) {
				graphics::_stop_screen_effect("REDMISTOut");
			}
			break;
		}
		if (func_95(func_93())) {
			if (player::is_special_ability_active(player::player_id())) {
				player::special_ability_deactivate_fast(player::player_id());
			}
		}
		player::change_player_ped(player::player_id(), (*uParam0)[uParam0->f_7], iParam2, 0);
		ui::hide_hud_component_this_frame(3);
		ui::hide_hud_component_this_frame(13);
		if ((iParam3 & 1) != 0) {
			ped::set_ped_config_flag(player::player_ped_id(), 210, 0);
		}
		if (func_233(0) || func_233(3)) {
			if (Global_17151.f_13) {
				iVar4 = 0;
				while (iVar4 < 7) {
					if (gameplay::is_bit_set(Global_82576[iVar4 /*5*/].f_1, 2)) {
						iVar5 = Global_82576[iVar4 /*5*/];
						StringCopy(&cVar6, "MISS_SWITCH_", 64);
						StringConCat(&cVar6, &Global_82612[G_TextMessageConfig.f_109[iVar5 /*4*/] /*34*/], 64);
						stats::stat_increment(gameplay::get_hash_key(&cVar6), 1f);
					}
					iVar4++;
				}
			}
		}
		Global_17151.f_13 = 0;
		uParam0->f_5 = func_232(iVar1);
		if (uParam0->f_5 == 4) {
			uParam0->f_5 = 3;
		}
		(*uParam0)[uParam0->f_5] = iVar0;
		(*uParam0)[uParam0->f_7] = 0;
		uParam0->f_6 = func_232(iVar2);
		uParam0->f_7 = 4;
		iVar22 = player::player_ped_id();
		entity::set_entity_visible(player::player_ped_id(), 1, 0);
		func_231(iVar22);
		ped::_0xE861D0B05C7662B8(iVar22, 0, 0);
		if (fVar3 < 25f && !ped::is_ped_swimming_under_water(player::player_ped_id())) {
			entity::set_entity_health(
				player::player_ped_id(),
				system::round(25f / 100f * (system::to_float(ped::get_ped_max_health(player::player_ped_id())) - 100f) +
							  100f));
		}
		if (iParam1) {
			if (entity::does_entity_exist(iVar0)) {
				entity::set_entity_visible(iVar0, 1, 0);
				func_231(iVar0);
				ped::_0xE861D0B05C7662B8(iVar0, 0, 0);
				ped::set_ped_stealth_movement(iVar0, 0, 0);
			}
		}
		else if (entity::does_entity_exist(iVar0)) {
			sVar24 = entity::get_entity_script(iVar0, &uVar23);
			if (!gameplay::is_string_null(sVar24)) {
				if (!gameplay::are_strings_equal(sVar24, script::get_this_script_name())) {
					entity::set_entity_as_mission_entity(iVar0, 0, 1);
				}
				ped::delete_ped(&iVar0);
			}
		}
		Global_89106 = 1;
		func_229(player::player_ped_id());
		func_228();
		func_227(iVar2);
		func_218();
		func_212(iVar2);
		func_195(func_210(entity::get_entity_coords(player::player_ped_id(), 1), 145, 0));
		player::reset_player_stamina(player::player_id());
		entity::set_entity_only_damaged_by_player(player::player_ped_id(), 0);
		ped::set_ped_can_be_dragged_out(player::player_ped_id(), 1);
		if (player::is_player_playing(player::player_id())) {
			player::set_auto_give_parachute_when_enter_plane(player::player_id(), func_315(67));
		}
		if (player::is_player_playing(player::player_id())) {
			player::_0xD2B315B6689D537D(player::player_id(), func_315(68));
		}
		func_192(iVar2, &iVar22);
		if (func_310(0) || func_310(3) || func_310(2) || func_310(4)) {
			ped::set_ped_config_flag(iVar22, 32, 0);
			ped::set_ped_config_flag(iVar22, 250, 0);
		}
		else {
			ped::set_ped_config_flag(iVar22, 32, 1);
			ped::set_ped_config_flag(iVar22, 250, 1);
		}
		if (!func_191()) {
			func_189();
		}
		Global_88743 = 0;
		return 1;
	}
	else {
		if (ped::is_ped_injured(player::player_ped_id())) {
		}
		if (ped::is_ped_injured((*uParam0)[uParam0->f_7])) {
		}
		if (player::player_ped_id() == (*uParam0)[uParam0->f_7]) {
		}
	}
	return 0;
}

// Position - 0xDFBA
void func_189() {
	if (Global_89136) {
		func_94();
		graphics::_0xBF59707B3E5ED531(func_190(Global_101700.f_2095.f_539.f_3549));
	}
	else {
		graphics::_0xBF59707B3E5ED531("");
	}
}

// Position - 0xDFEC
char *func_190(var uParam0) {
	uParam0 = uParam0;
	return "";
}

// Position - 0xDFFB
bool func_191() { return Global_17149; }

// Position - 0xE006
void func_192(int iParam0, int iParam1) {
	switch (iParam0) {
	case 0:
		func_193(4, *iParam1);
		func_193(7, *iParam1);
		func_193(8, *iParam1);
		func_193(11, *iParam1);
		break;

	case 1:
		if (Global_101700.f_8044.f_330[2 /*6*/]) {
			func_193(4, *iParam1);
		}
		func_193(7, *iParam1);
		func_193(8, *iParam1);
		func_193(11, *iParam1);
		if (Global_101700.f_8044.f_99.f_58[126]) {
			func_193(12, *iParam1);
		}
		break;

	case 2:
		if (Global_101700.f_8044.f_330[20 /*6*/]) {
			func_193(4, *iParam1);
		}
		func_193(7, *iParam1);
		func_193(8, *iParam1);
		func_193(11, *iParam1);
		break;
	}
}

// Position - 0xE0D2
void func_193(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!entity::does_entity_exist(iParam1)) {
		return;
	}
	if (func_194(iParam0, iParam1)) {
		return;
	}
	if (Global_34904[iParam0 /*31*/].f_24 < 5) {
		Global_34904[iParam0 /*31*/].f_25[Global_34904[iParam0 /*31*/].f_24] = iParam1;
		Global_34904[iParam0 /*31*/].f_24++;
	}
	else {
		iVar2 = 0;
		iVar0 = 0;
		while (iVar0 < 5) {
			iVar1 = Global_34904[iParam0 /*31*/].f_25[iVar0];
			if (!entity::does_entity_exist(iVar1) || ped::is_ped_injured(iVar1)) {
				Global_34904[iParam0 /*31*/].f_25[iVar0] = iParam1;
				iVar2 = 1;
				iVar0 = 6;
			}
			iVar0++;
		}
		if (!iVar2) {
		}
	}
}

// Position - 0xE184
bool func_194(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_34904[iParam0 /*31*/].f_24) {
		if (iParam1 == Global_34904[iParam0 /*31*/].f_25[iVar0]) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0xE1BD
void func_195(int iParam0) {
	if (iParam0 == 10) {
		return;
	}
	switch (iParam0) {
	case 0:
		gameplay::set_bit(&Global_31569[38 / 32], 38 % 32);
		func_196(38, 0);
		gameplay::set_bit(&Global_31569[41 / 32], 41 % 32);
		func_196(41, 0);
		gameplay::set_bit(&Global_31569[43 / 32], 43 % 32);
		func_196(43, 0);
		gameplay::set_bit(&Global_31569[42 / 32], 42 % 32);
		func_196(42, 0);
		gameplay::set_bit(&Global_31569[44 / 32], 44 % 32);
		func_196(44, 0);
		break;

	case 1:
		gameplay::set_bit(&Global_31569[51 / 32], 51 % 32);
		func_196(51, 0);
		break;

	case 2:
		gameplay::set_bit(&Global_31569[51 / 32], 51 % 32);
		func_196(51, 0);
		break;

	case 3:
		gameplay::set_bit(&Global_31569[53 / 32], 53 % 32);
		func_196(53, 0);
		break;

	case 4:
		gameplay::set_bit(&Global_31569[81 / 32], 81 % 32);
		func_196(81, 0);
		gameplay::set_bit(&Global_31569[82 / 32], 82 % 32);
		func_196(82, 0);
		break;

	case 5:
		gameplay::set_bit(&Global_31569[47 / 32], 47 % 32);
		func_196(47, 0);
		gameplay::set_bit(&Global_31569[50 / 32], 50 % 32);
		func_196(50, 0);
		break;

	case 6:
		gameplay::set_bit(&Global_31569[50 / 32], 50 % 32);
		func_196(50, 0);
		break;
	}
}

// Position - 0xE34D
void func_196(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 != 226) {
		if (Global_69702) {
			iVar0 = Global_2433125.f_74[iParam0];
		}
		else {
			iVar0 = Global_101700.f_6220[iParam0];
		}
		if (iVar0 != iParam1 || gameplay::is_bit_set(Global_31569[iParam0 / 32], iParam0 % 32)) {
			if (iParam1 == 4 || iParam1 == 3 || iParam1 == 5 || iParam1 == 6 || iParam1 == 2) {
				gameplay::set_bit(&Global_31578[iParam0 / 32], iParam0 % 32);
				Global_32041[iParam0] = iParam1;
			}
			else if (Global_69702) {
				Global_2433125.f_74[iParam0] = iParam1;
			}
			else {
				Global_101700.f_6220[iParam0] = iParam1;
			}
			gameplay::set_bit(&Global_31569[iParam0 / 32], iParam0 % 32);
			func_198(iParam0);
			if (gameplay::is_bit_set(Global_31569[iParam0 / 32], iParam0 % 32)) {
				func_197(iParam0);
			}
		}
	}
}

// Position - 0xE446
void func_197(int iParam0) {
	if (!gameplay::is_bit_set(Global_32512.f_228[iParam0 / 32], iParam0 % 23)) {
		gameplay::set_bit(&Global_32512.f_228[iParam0 / 32], iParam0 % 23);
		Global_32512[Global_32512.f_227] = iParam0;
		Global_32512.f_227++;
	}
}

// Position - 0xE494
void func_198(int iParam0) {
	struct<7> Var0;
	bool bVar7;
	bool bVar8;
	int iVar9;
	float fVar10;
	int iVar11;
	int iVar12;
	bool bVar13;
	int iVar14;
	int iVar15;

	if (!func_207()) {
		return;
	}
	if (ped::is_ped_injured(player::player_ped_id())) {
		return;
	}
	Var0 = {func_206(iParam0)};
	if (gameplay::is_bit_set(Var0.f_4, 2)) {
		func_203(iParam0, &Var0);
	}
	if (!object::_does_door_exist(Var0.f_5)) {
		if (cutscene::is_cutscene_playing()) {
			return;
		}
	}
	bVar7 = false;
	bVar8 = false;
	fVar10 = gameplay::get_distance_between_coords(Var0, entity::get_entity_coords(player::player_ped_id(), 1), 1);
	if (gameplay::is_bit_set(Global_31578[iParam0 / 32], iParam0 % 32) && Global_32041[iParam0] == 2 && fVar10 > 210f) {
		gameplay::clear_bit(&Global_31578[iParam0 / 32], iParam0 % 32);
		Global_31587[iParam0] = 0;
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("startup_positioning")) == 0) {
		if (gameplay::is_bit_set(Global_31814[iParam0 / 32], iParam0 % 32)) {
			if (fVar10 < 25f) {
				if (Global_91543.f_301 == 0) {
					if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
						Global_91543.f_301 = interior::get_interior_from_entity(player::player_ped_id());
					}
				}
				iVar11 = Global_91543.f_301;
				iVar12 = interior::get_interior_at_coords(Var0);
				if (iVar11 == iVar12 && iVar11 != 0) {
					gameplay::set_bit(&Global_31578[iParam0 / 32], iParam0 % 32);
					Global_32041[iParam0] = 3;
					gameplay::set_bit(&Global_31569[iParam0 / 32], iParam0 % 32);
				}
			}
			gameplay::clear_bit(&Global_31814[iParam0 / 32], iParam0 % 32);
		}
	}
	if (gameplay::is_bit_set(Global_31578[iParam0 / 32], iParam0 % 32)) {
		iVar9 = Global_32041[iParam0];
	}
	else if (gameplay::is_bit_set(Var0.f_4, 0)) {
		if (Global_101700.f_8044) {
			iVar9 = func_200(iParam0);
		}
		else {
			iVar9 = 0;
		}
		if (func_310(14)) {
			iVar9 = 0;
		}
	}
	else if (gameplay::is_bit_set(Var0.f_4, 1) &&
			 script::_get_number_of_instances_of_script_with_name_hash(joaat("ambient_solomon")) == 0) {
		if (func_199()) {
			iVar9 = 0;
		}
		else {
			iVar9 = 1;
		}
	}
	else {
		iVar9 = Global_101700.f_6220[iParam0];
	}
	if (Global_32268[iParam0] != iVar9) {
		bVar7 = true;
	}
	if (gameplay::is_bit_set(Global_31569[iParam0 / 32], iParam0 % 32)) {
		if (!gameplay::is_bit_set(Global_31578[iParam0 / 32], iParam0 % 32) ||
			Global_31587[iParam0] == 0 && Global_32041[iParam0] != 2) {
			bVar7 = true;
		}
	}
	if (bVar7) {
		if (!Global_31568) {
		}
		else {
			if (!object::_does_door_exist(Var0.f_5)) {
				object::add_door_to_system(Var0.f_5, Var0.f_3, Var0, 0, 0, 0);
			}
			switch (iVar9) {
			case 1:
				if (gameplay::is_bit_set(Var0.f_4, 3)) {
					bVar13 = true;
				}
				else if (fVar10 > 3f || gameplay::absf(object::_0x65499865FCA6E5EC(Var0.f_5)) <= 0.015f) {
					iVar14 = interior::get_interior_from_entity(player::player_ped_id());
					iVar15 = interior::get_interior_at_coords(Var0);
					if (iVar14 != iVar15 || iVar14 == 0) {
						bVar13 = true;
					}
				}
				if (bVar13) {
					if (Var0.f_6 != 0f) {
						object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
					}
					object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
					bVar8 = true;
				}
				break;

			case 4:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;

			case 2:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;

			case 0:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 1);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;

			case 3:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, 0, 0, 1);
				bVar8 = true;
				break;

			case 5:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;

			case 6:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;

			default:
				if (Var0.f_6 != 0f) {
					object::_0x9BA001CB45CBF627(Var0.f_5, Var0.f_6, 0, 0);
				}
				object::_set_door_acceleration_limit(Var0.f_5, iVar9, 0, 1);
				bVar8 = true;
				break;
			}
		}
		if (bVar8) {
			gameplay::clear_bit(&Global_31569[iParam0 / 32], iParam0 % 32);
			Global_32268[iParam0] = iVar9;
		}
	}
	if (gameplay::is_bit_set(Global_31578[iParam0 / 32], iParam0 % 32) && Global_32041[iParam0] != 2) {
		gameplay::set_bit(&Global_31569[iParam0 / 32], iParam0 % 32);
		func_197(iParam0);
		if (Global_31587[iParam0] < 2) {
			Global_31587[iParam0]++;
		}
	}
}

// Position - 0xE977
bool func_199() {
	if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
		return false;
	}
	switch (func_93()) {
	case 0:
		if (Global_101700.f_8044.f_99.f_58[65]) {
			return true;
		}
		break;

	case 1:
		if (Global_101700.f_8044.f_99.f_58[66]) {
			return true;
		}
		break;

	case 2:
		if (Global_101700.f_8044.f_99.f_58[65]) {
			return true;
		}
		break;
	}
	return false;
}

// Position - 0xE9F6
int func_200(int iParam0) {
	int iVar0;

	iVar0 = func_93();
	if (func_201(iParam0)) {
		return 1;
	}
	if (iParam0 == 49) {
		if (iVar0 == 1) {
			if (gameplay::is_bit_set(Global_101700.f_6188[5], 0) || gameplay::is_bit_set(Global_101700.f_6188[6], 0)) {
				return 0;
			}
		}
		if (func_95(iVar0)) {
			if (gameplay::is_bit_set(Global_86851[5], iVar0)) {
				return 0;
			}
		}
	}
	switch (iParam0) {
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
		if (iVar0 == 0) {
			if (gameplay::is_bit_set(Global_101700.f_6188[0], 0)) {
				return 0;
			}
		}
		if (func_95(iVar0)) {
			if (gameplay::is_bit_set(Global_86851[0], iVar0)) {
				if (iParam0 != 40) {
					return 0;
				}
				else {
					return 1;
				}
			}
		}
		break;

	case 47:
	case 48:
	case 49:
		if (iVar0 == 1) {
			if (gameplay::is_bit_set(Global_101700.f_6188[5], 0)) {
				return 0;
			}
		}
		if (func_95(iVar0)) {
			if (gameplay::is_bit_set(Global_86851[5], iVar0)) {
				return 0;
			}
		}
		break;

	case 50:
		if (iVar0 == 1) {
			if (gameplay::is_bit_set(Global_101700.f_6188[6], 0)) {
				return 0;
			}
		}
		if (func_95(iVar0)) {
			if (gameplay::is_bit_set(Global_86851[6], iVar0)) {
				return 0;
			}
		}
		break;

	case 51:
	case 52:
		if (iVar0 == 2) {
			if (gameplay::is_bit_set(Global_101700.f_6188[2], 0)) {
				return 0;
			}
			if (func_95(iVar0)) {
				if (gameplay::is_bit_set(Global_86851[2], iVar0)) {
					return 0;
				}
			}
		}
		else if (iVar0 == 0) {
			if (gameplay::is_bit_set(Global_101700.f_6188[1], 0)) {
				return 0;
			}
			if (func_95(iVar0)) {
				if (gameplay::is_bit_set(Global_86851[1], iVar0)) {
					return 0;
				}
			}
		}
		break;

	case 53:
		if (iVar0 == 2) {
			if (gameplay::is_bit_set(Global_101700.f_6188[3], 0)) {
				return 0;
			}
		}
		if (func_95(iVar0)) {
			if (gameplay::is_bit_set(Global_86851[3], iVar0)) {
				return 0;
			}
		}
		break;

	default: return 0;
	}
	return 1;
}

// Position - 0xEC4B
bool func_201(int iParam0) {
	int iVar0;

	if (iParam0 == 40 || iParam0 == 49 || iParam0 == 52) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
				iVar0 = entity::get_entity_model(func_202(ped::get_vehicle_ped_is_in(player::player_ped_id(), 1)));
				switch (iVar0) {
				case joaat("utillitruck"):
				case joaat("monster"): return true;
				}
			}
		}
	}
	return false;
}

// Position - 0xECB7
var func_202(var uParam0) { return uParam0; }

// Position - 0xECC1
void func_203(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	if (!gameplay::is_bit_set(uParam1->f_4, 2)) {
		return;
	}
	iVar0 = func_173();
	iVar1 = func_205(iVar0);
	switch (iParam0) {
	case 133:
	case 134:
	case 201:
	case 202:
		if (func_204(iParam0)) {
			if (iVar1 < 19) {
				if (iVar1 >= 7) {
					Global_101700.f_6220[iParam0] = 0;
					object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
				}
			}
			else {
				return;
			}
		}
		else if (iVar1 >= 19) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 12f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else if (iVar1 < 7) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 12f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 199:
	case 200:
	case 203:
	case 204:
		if (func_204(iParam0)) {
			if (iVar1 < 18) {
				if (iVar1 >= 7) {
					Global_101700.f_6220[iParam0] = 0;
					object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
				}
			}
			else {
				return;
			}
		}
		else if (iVar1 >= 18) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 12f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else if (iVar1 < 7) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 12f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 141:
	case 142:
		if (func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("jewelry_heist")) == 0 &&
				script::_get_number_of_instances_of_script_with_name_hash(joaat("jewelry_setup1")) == 0 &&
				!Global_101700.f_8044.f_99.f_58[4]) {
				if (iVar1 < 21) {
					if (iVar1 >= 7) {
						Global_101700.f_6220[iParam0] = 0;
						object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
					}
				}
				else {
					return;
				}
			}
			else if (!Global_101700.f_8044.f_99.f_58[4]) {
				Global_101700.f_6220[iParam0] = 0;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else if (Global_101700.f_8044.f_99.f_58[4]) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("jewelry_heist")) == 0 &&
				 script::_get_number_of_instances_of_script_with_name_hash(joaat("jewelry_setup1")) == 0) {
			if (iVar1 >= 21) {
				if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 18f) {
					Global_101700.f_6220[iParam0] = 1;
					object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
				}
			}
			else if (iVar1 < 7) {
				if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 18f) {
					Global_101700.f_6220[iParam0] = 1;
					object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
				}
			}
		}
		break;

	case 145:
	case 146:
	case 143:
	case 144:
		if (func_204(iParam0)) {
			if (iVar1 < 20) {
				if (iVar1 >= 9) {
					Global_101700.f_6220[iParam0] = 0;
					object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
				}
			}
			else {
				return;
			}
		}
		else if (iVar1 >= 20) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 40f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else if (iVar1 < 9) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), *uParam1) >= 40f) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 147:
	case 148:
		if (!func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 152:
	case 153:
	case 154:
	case 155:
	case 156:
	case 157:
		if (!func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_valet")) == 0) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("assassin_valet")) > 0) {
			Global_101700.f_6220[iParam0] = 0;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 158:
	case 159:
		if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[70 /*34*/].f_6) == 0) {
			if (!func_204(iParam0)) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 160:
	case 161:
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("omega2")) == 0) {
			if (!func_204(iParam0)) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 70:
	case 71:
	case 72:
		if (!func_204(iParam0) &&
			script::_get_number_of_instances_of_script_with_name_hash(Global_82612[26 /*34*/].f_6) == 0) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		else {
			return;
		}
		break;

	case 101:
	case 102:
	case 103:
	case 104:
		if (!func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[43 /*34*/].f_6) == 0) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else {
			return;
		}
		break;

	case 190:
	case 191:
		if (!func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 193:
		if (!func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[93 /*34*/].f_6) > 0) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else {
			return;
		}
		break;

	case 198:
		if (!func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 80:
		if (!func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[8 /*34*/].f_6) == 0 &&
				script::_get_number_of_instances_of_script_with_name_hash(Global_82612[10 /*34*/].f_6) == 0) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else {
			return;
		}
		break;

	case 205:
	case 206:
		if (!func_204(iParam0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[47 /*34*/].f_6) == 0) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		else {
			return;
		}
		break;

	case 207:
		if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[70 /*34*/].f_6) == 0) {
			if (!func_204(iParam0)) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 208:
	case 209:
	case 211:
	case 210:
	case 212:
	case 213:
	case 214:
	case 215:
		if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[48 /*34*/].f_6) == 0) {
			if (!func_204(iParam0)) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 99:
	case 100:
		if (script::_get_number_of_instances_of_script_with_name_hash(Global_82612[39 /*34*/].f_6) == 0) {
			if (!func_204(iParam0)) {
				Global_101700.f_6220[iParam0] = 1;
				object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
			}
		}
		break;

	case 216:
		if (!func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 217:
	case 218:
		if (!func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 1;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;

	case 219:
	case 220:
	case 221:
	case 222:
		if (func_204(iParam0)) {
			Global_101700.f_6220[iParam0] = 0;
			object::_set_door_acceleration_limit(uParam1->f_5, Global_101700.f_6220[iParam0], 1, 1);
		}
		break;
	}
}

// Position - 0xF65C
bool func_204(int iParam0) {
	struct<7> Var0;
	int iVar7;

	Var0 = {func_206(iParam0)};
	iVar7 = object::_0x160AA1B32F6139B8(Var0.f_5);
	return iVar7 == 1 || iVar7 == 4 || iVar7 == 2;
}

// Position - 0xF690
int func_205(int iParam0) { return system::shift_right(iParam0, 9) & 31; }

// Position - 0xF6A3
struct<7> func_206(int iParam0) {
	struct<7> Var0;

	switch (iParam0) {
	case 0:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {133f, -1711f, 29f};
		Var0.f_5 = 1804701345;
		break;

	case 1:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {-1287.857f, -1115.742f, 7.1401f};
		Var0.f_5 = 1403601067;
		break;

	case 2:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {1932.952f, 3725.154f, 32.9944f};
		Var0.f_5 = -2031139496;
		break;

	case 3:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {1207.873f, -470.063f, 66.358f};
		Var0.f_5 = 1796834809;
		break;

	case 4:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {-29.8692f, -148.1571f, 57.2265f};
		Var0.f_5 = 96153298;
		break;

	case 5:
		Var0.f_3 = joaat("v_ilev_bs_door");
		Var0 = {-280.7851f, 6232.782f, 31.8455f};
		Var0.f_5 = -281080954;
		break;

	case 6:
		Var0.f_3 = joaat("v_ilev_hd_door_l");
		Var0 = {-824f, -187f, 38f};
		Var0 = {-823.2001f, -187.0831f, 37.819f};
		Var0.f_5 = 183249434;
		break;

	case 7:
		Var0.f_3 = joaat("v_ilev_hd_door_r");
		Var0 = {-823f, -188f, 38f};
		Var0 = {-822.4442f, -188.3924f, 37.819f};
		Var0.f_5 = 758345384;
		break;

	case 8:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {82.3186f, -1392.752f, 29.5261f};
		Var0.f_5 = -1069262641;
		break;

	case 9:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {82.3186f, -1390.476f, 29.5261f};
		Var0.f_5 = 1968521986;
		break;

	case 10:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {1686.983f, 4821.741f, 42.2131f};
		Var0.f_5 = -2143706301;
		break;

	case 11:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {1687.282f, 4819.484f, 42.2131f};
		Var0.f_5 = -1403421822;
		break;

	case 12:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {418.637f, -806.457f, 29.6396f};
		Var0.f_5 = -1950137670;
		break;

	case 13:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {418.637f, -808.733f, 29.6396f};
		Var0.f_5 = 1226259807;
		break;

	case 14:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {-1096.661f, 2705.446f, 19.2578f};
		Var0.f_5 = 1090833557;
		break;

	case 15:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {-1094.965f, 2706.964f, 19.2578f};
		Var0.f_5 = 897332612;
		break;

	case 16:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {1196.825f, 2703.221f, 38.3726f};
		Var0.f_5 = 1095946640;
		break;

	case 17:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {1199.101f, 2703.221f, 38.3726f};
		Var0.f_5 = 801975945;
		break;

	case 18:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {-818.7642f, -1079.544f, 11.4781f};
		Var0.f_5 = -167996547;
		break;

	case 19:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {-816.7932f, -1078.406f, 11.4781f};
		Var0.f_5 = -1935818563;
		break;

	case 20:
		Var0.f_3 = joaat("v_ilev_cs_door01");
		Var0 = {-0.0564f, 6517.461f, 32.0278f};
		Var0.f_5 = 1891185217;
		break;

	case 21:
		Var0.f_3 = joaat("v_ilev_cs_door01_r");
		Var0 = {-1.7253f, 6515.914f, 32.0278f};
		Var0.f_5 = 1236591681;
		break;

	case 22:
		Var0.f_3 = joaat("v_ilev_clothmiddoor");
		Var0 = {-1201.435f, -776.8566f, 17.9918f};
		Var0.f_5 = 1980808685;
		break;

	case 23:
		Var0.f_3 = joaat("v_ilev_clothmiddoor");
		Var0 = {617.2458f, 2751.022f, 42.7578f};
		Var0.f_5 = 1352749757;
		break;

	case 24:
		Var0.f_3 = joaat("v_ilev_clothmiddoor");
		Var0 = {127.8201f, -211.8274f, 55.2275f};
		Var0.f_5 = -566554453;
		break;

	case 25:
		Var0.f_3 = joaat("v_ilev_clothmiddoor");
		Var0 = {-3167.75f, 1055.536f, 21.5329f};
		Var0.f_5 = 1284749450;
		break;

	case 26:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-716.6754f, -155.42f, 37.6749f};
		Var0.f_5 = 261851994;
		break;

	case 27:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-715.6154f, -157.2561f, 37.6749f};
		Var0.f_5 = 217646625;
		break;

	case 28:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-157.0924f, -306.4413f, 39.994f};
		Var0.f_5 = 1801139578;
		break;

	case 29:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-156.4022f, -304.4366f, 39.994f};
		Var0.f_5 = -2123275866;
		break;

	case 30:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-1454.782f, -231.7927f, 50.0565f};
		Var0.f_5 = 1312689981;
		break;

	case 31:
		Var0.f_3 = joaat("v_ilev_ch_glassdoor");
		Var0 = {-1456.201f, -233.3682f, 50.0565f};
		Var0.f_5 = -595055661;
		break;

	case 32:
		Var0.f_3 = joaat("v_ilev_ta_door");
		Var0 = {321.81f, 178.36f, 103.68f};
		Var0.f_5 = -265260897;
		break;

	case 33:
		Var0.f_3 = -1212951353;
		Var0 = {1859.89f, 3749.79f, 33.18f};
		Var0.f_5 = -1284867488;
		break;

	case 34:
		Var0.f_3 = -1212951353;
		Var0 = {-289.1752f, 6199.112f, 31.637f};
		Var0.f_5 = 302307081;
		break;

	case 35:
		Var0.f_3 = joaat("v_ilev_ta_door");
		Var0 = {-1155.454f, -1424.008f, 5.0461f};
		Var0.f_5 = -681886015;
		break;

	case 36:
		Var0.f_3 = joaat("v_ilev_ta_door");
		Var0 = {1321.286f, -1650.597f, 52.3663f};
		Var0.f_5 = -2086556500;
		break;

	case 37:
		Var0.f_3 = joaat("v_ilev_ta_door");
		Var0 = {-3167.789f, 1074.767f, 20.9209f};
		Var0.f_5 = -1496386696;
		break;

	case 38:
		Var0.f_3 = joaat("v_ilev_mm_doorm_l");
		Var0 = {-817f, 179f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -2097039789;
		break;

	case 39:
		Var0.f_3 = joaat("v_ilev_mm_doorm_r");
		Var0 = {-816f, 178f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -2127416656;
		break;

	case 40:
		Var0.f_3 = joaat("prop_ld_garaged_01");
		Var0 = {-815f, 186f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -1986583853;
		Var0.f_6 = 6.5f;
		break;

	case 41:
		Var0.f_3 = joaat("prop_bh1_48_backdoor_l");
		Var0 = {-797f, 177f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 776026812;
		break;

	case 42:
		Var0.f_3 = joaat("prop_bh1_48_backdoor_r");
		Var0 = {-795f, 178f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 698422331;
		break;

	case 43:
		Var0.f_3 = joaat("prop_bh1_48_backdoor_l");
		Var0 = {-793f, 181f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 535076355;
		break;

	case 44:
		Var0.f_3 = joaat("prop_bh1_48_backdoor_r");
		Var0 = {-794f, 183f, 73f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 474675599;
		break;

	case 45:
		Var0.f_3 = joaat("prop_bh1_48_gate_1");
		Var0 = {-849f, 179f, 70f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -1978427516;
		break;

	case 46:
		Var0.f_3 = joaat("v_ilev_mm_windowwc");
		Var0 = {-802.7333f, 167.5041f, 77.5824f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -1700375831;
		break;

	case 47:
		Var0.f_3 = joaat("v_ilev_fa_frontdoor");
		Var0 = {-14f, -1441f, 31f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 613961892;
		break;

	case 48:
		Var0.f_3 = joaat("v_ilev_fh_frntdoor");
		Var0 = {-15f, -1427f, 31f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -272570634;
		break;

	case 49:
		Var0.f_3 = joaat("prop_sc1_21_g_door_01");
		Var0 = {-25.28f, -1431.06f, 30.84f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -1040675994;
		break;

	case 50:
		Var0.f_3 = joaat("v_ilev_fh_frontdoor");
		Var0 = {7.52f, 539.53f, 176.18f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 1201219326;
		break;

	case 51:
		Var0.f_3 = joaat("v_ilev_trevtraildr");
		Var0 = {1973f, 3815f, 34f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = 1736361794;
		break;

	case 52:
		Var0.f_3 = joaat("prop_cs4_10_tr_gd_01");
		Var0 = {1972.787f, 3824.554f, 32.5831f};
		Var0.f_5 = 1113956670;
		Var0.f_6 = 12f;
		break;

	case 53:
		Var0.f_3 = joaat("v_ilev_trev_doorfront");
		Var0 = {-1150f, -1521f, 11f};
		gameplay::set_bit(&Var0.f_4, 0);
		Var0.f_5 = -1361617046;
		break;
	}
	switch (iParam0) {
	case 54:
		Var0.f_3 = joaat("prop_com_ls_door_01");
		Var0 = {-1145.9f, -1991.14f, 14.18f};
		Var0.f_5 = -1871080926;
		Var0.f_6 = 25f;
		break;

	case 55:
		Var0.f_3 = joaat("prop_id2_11_gdoor");
		Var0 = {723.12f, -1088.83f, 23.28f};
		Var0.f_5 = 1168079979;
		Var0.f_6 = 25f;
		break;

	case 56:
		Var0.f_3 = joaat("prop_com_ls_door_01");
		Var0 = {-356.09f, -134.77f, 40.01f};
		Var0.f_5 = 1206354175;
		Var0.f_6 = 25f;
		break;

	case 57:
		Var0.f_3 = joaat("v_ilev_carmod3door");
		Var0 = {108.8502f, 6617.876f, 32.673f};
		Var0.f_5 = -1038180727;
		Var0.f_6 = 25f;
		break;

	case 58:
		Var0.f_3 = joaat("v_ilev_carmod3door");
		Var0 = {114.3206f, 6623.226f, 32.7161f};
		Var0.f_5 = 1200466273;
		Var0.f_6 = 25f;
		break;

	case 59:
		Var0.f_3 = joaat("v_ilev_carmod3door");
		Var0 = {1182.305f, 2645.242f, 38.807f};
		Var0.f_5 = 1391004277;
		Var0.f_6 = 25f;
		break;

	case 60:
		Var0.f_3 = joaat("v_ilev_carmod3door");
		Var0 = {1174.654f, 2645.242f, 38.6826f};
		Var0.f_5 = -459199009;
		Var0.f_6 = 25f;
		break;

	case 225:
		Var0.f_3 = -427498890;
		Var0 = {-205.7007f, -1310.692f, 30.2957f};
		Var0.f_5 = -288764223;
		Var0.f_6 = 25f;
		break;

	case 61:
		Var0.f_3 = joaat("v_ilev_janitor_frontdoor");
		Var0 = {-107.5401f, -9.0258f, 70.6696f};
		Var0.f_5 = -252283844;
		break;

	case 62:
		Var0.f_3 = joaat("v_ilev_ss_door8");
		Var0 = {717f, -975f, 25f};
		Var0.f_5 = -826072862;
		break;

	case 63:
		Var0.f_3 = joaat("v_ilev_ss_door7");
		Var0 = {719f, -975f, 25f};
		Var0.f_5 = 763780711;
		break;

	case 64:
		Var0.f_3 = joaat("v_ilev_ss_door02");
		Var0 = {709.9813f, -963.5311f, 30.5453f};
		Var0.f_5 = -874851305;
		break;

	case 65:
		Var0.f_3 = joaat("v_ilev_ss_door03");
		Var0 = {709.9894f, -960.6675f, 30.5453f};
		Var0.f_5 = -1480820165;
		break;

	case 66:
		Var0.f_3 = joaat("v_ilev_store_door");
		Var0 = {707.8046f, -962.4564f, 30.5453f};
		Var0.f_5 = 949391213;
		break;

	case 67:
		Var0.f_3 = -1212951353;
		Var0 = {1393f, 3599f, 35f};
		Var0.f_5 = 212192855;
		break;

	case 68:
		Var0.f_3 = -1212951353;
		Var0 = {1395f, 3600f, 35f};
		Var0.f_5 = -126474752;
		break;

	case 69:
		Var0.f_3 = joaat("v_ilev_ss_door04");
		Var0 = {1387f, 3614f, 39f};
		Var0.f_5 = 1765671336;
		break;

	case 70:
		Var0.f_3 = joaat("prop_ron_door_01");
		Var0 = {1083.547f, -1975.435f, 31.6222f};
		Var0.f_5 = 792295685;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 71:
		Var0.f_3 = joaat("prop_ron_door_01");
		Var0 = {1065.237f, -2006.079f, 32.2329f};
		Var0.f_5 = 563273144;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 72:
		Var0.f_3 = joaat("prop_ron_door_01");
		Var0 = {1085.307f, -2018.561f, 41.6289f};
		Var0.f_5 = -726993043;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 73:
		Var0.f_3 = joaat("v_ilev_bank4door02");
		Var0 = {-111f, 6464f, 32f};
		Var0.f_5 = 178228075;
		break;

	case 74:
		Var0.f_3 = joaat("v_ilev_bank4door01");
		Var0 = {-110f, 6462f, 32f};
		Var0.f_5 = 1852297978;
		break;

	case 75:
		Var0.f_3 = joaat("v_ilev_lester_doorfront");
		Var0 = {1274f, -1721f, 55f};
		Var0.f_5 = -565026078;
		break;

	case 76:
		Var0.f_3 = joaat("v_ilev_lester_doorveranda");
		Var0 = {1271.89f, -1707.57f, 53.79f};
		Var0.f_5 = 1646172266;
		break;

	case 77:
		Var0.f_3 = joaat("v_ilev_lester_doorveranda");
		Var0 = {1270.77f, -1708.1f, 53.75f};
		Var0.f_5 = 204467342;
		break;

	case 78:
		Var0.f_3 = joaat("v_ilev_deviantfrontdoor");
		Var0 = {-127.5f, -1456.18f, 37.94f};
		Var0.f_5 = 2047070410;
		break;

	case 79:
		Var0.f_3 = joaat("prop_com_gar_door_01");
		Var0 = {483.56f, -1316.08f, 32.18f};
		Var0.f_5 = 1417775309;
		break;

	case 80:
		Var0.f_3 = joaat("v_ilev_cs_door");
		Var0 = {483f, -1312f, 29f};
		Var0.f_5 = -106474626;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 81:
		Var0.f_3 = joaat("prop_strip_door_01");
		Var0 = {128f, -1299f, 29f};
		Var0.f_5 = 1840510598;
		break;

	case 82:
		Var0.f_3 = joaat("prop_magenta_door");
		Var0 = {96f, -1285f, 29f};
		Var0.f_5 = 1382825971;
		break;

	case 83:
		Var0.f_3 = joaat("prop_motel_door_09");
		Var0 = {549f, -1773f, 34f};
		Var0.f_5 = 232536303;
		break;

	case 84:
		Var0.f_3 = joaat("v_ilev_gangsafedoor");
		Var0 = {974f, -1839f, 36f};
		Var0.f_5 = 1267246609;
		gameplay::set_bit(&Var0.f_4, 3);
		break;

	case 85:
		Var0.f_3 = joaat("v_ilev_gangsafedoor");
		Var0 = {977f, -105f, 75f};
		Var0.f_5 = -1900237971;
		gameplay::set_bit(&Var0.f_4, 3);
		break;

	case 86:
		Var0.f_3 = joaat("v_ilev_ra_door1_l");
		Var0 = {1391f, 1163f, 114f};
		Var0.f_5 = 2077901353;
		break;

	case 87:
		Var0.f_3 = joaat("v_ilev_ra_door1_r");
		Var0 = {1391f, 1161f, 114f};
		Var0.f_5 = -2102079126;
		break;

	case 88:
		Var0.f_3 = joaat("prop_cs6_03_door_l");
		Var0 = {1396f, 1143f, 115f};
		Var0.f_5 = -1905793212;
		break;

	case 89:
		Var0.f_3 = joaat("prop_cs6_03_door_r");
		Var0 = {1396f, 1141f, 115f};
		Var0.f_5 = -1797032505;
		break;

	case 90:
		Var0.f_3 = joaat("v_ilev_ra_door1_l");
		Var0 = {1409f, 1146f, 114f};
		Var0.f_5 = -62235167;
		break;

	case 91:
		Var0.f_3 = joaat("v_ilev_ra_door1_r");
		Var0 = {1409f, 1148f, 114f};
		Var0.f_5 = -1727188163;
		break;

	case 92:
		Var0.f_3 = joaat("v_ilev_ra_door1_l");
		Var0 = {1408f, 1159f, 114f};
		Var0.f_5 = -562748873;
		break;

	case 93:
		Var0.f_3 = joaat("v_ilev_ra_door1_r");
		Var0 = {1408f, 1161f, 114f};
		Var0.f_5 = 1976429759;
		break;

	case 94:
		Var0.f_3 = joaat("prop_gar_door_01");
		Var0 = {-1067f, -1666f, 5f};
		Var0.f_5 = 1341041543;
		break;

	case 95:
		Var0.f_3 = joaat("prop_gar_door_02");
		Var0 = {-1065f, -1669f, 5f};
		Var0.f_5 = -1631467220;
		break;

	case 96:
		Var0.f_3 = joaat("prop_map_door_01");
		Var0 = {-1104.66f, -1638.48f, 4.68f};
		Var0.f_5 = -1788473129;
		break;

	case 97:
		Var0.f_3 = joaat("v_ilev_fib_door1");
		Var0 = {-31.72f, -1101.85f, 26.57f};
		Var0.f_5 = -1831288286;
		break;

	case 98:
		Var0.f_3 = joaat("v_ilev_tort_door");
		Var0 = {134.4f, -2204.1f, 7.52f};
		Var0.f_5 = 963876966;
		break;

	case 99:
		Var0.f_3 = joaat("v_ilev_bl_shutter2");
		Var0 = {3628f, 3747f, 28f};
		Var0.f_5 = 1773088812;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 100:
		Var0.f_3 = joaat("v_ilev_bl_shutter2");
		Var0 = {3621f, 3752f, 28f};
		Var0.f_5 = -1332101528;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 101:
		Var0.f_3 = joaat("v_ilev_rc_door3_l");
		Var0 = {-608.73f, -1610.32f, 27.16f};
		Var0.f_5 = -1811763714;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 102:
		Var0.f_3 = joaat("v_ilev_rc_door3_r");
		Var0 = {-611.32f, -1610.09f, 27.16f};
		Var0.f_5 = 1608500665;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 103:
		Var0.f_3 = joaat("v_ilev_rc_door3_l");
		Var0 = {-592.94f, -1631.58f, 27.16f};
		Var0.f_5 = -1456048340;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 104:
		Var0.f_3 = joaat("v_ilev_rc_door3_r");
		Var0 = {-592.71f, -1628.99f, 27.16f};
		Var0.f_5 = 943854909;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 105:
		Var0.f_3 = joaat("v_ilev_ss_door04");
		Var0 = {1991f, 3053f, 47f};
		Var0.f_5 = -89065356;
		break;

	case 106:
		Var0.f_3 = 479144380;
		Var0 = {1988.353f, 3054.411f, 47.3204f};
		Var0.f_5 = -925491840;
		break;

	case 107:
		Var0.f_3 = joaat("prop_epsilon_door_l");
		Var0 = {-700.17f, 47.31f, 44.3f};
		Var0.f_5 = 1999872275;
		break;

	case 108:
		Var0.f_3 = joaat("prop_epsilon_door_r");
		Var0 = {-697.94f, 48.35f, 44.3f};
		Var0.f_5 = 1999872275;
		break;

	case 109:
		Var0.f_3 = -1230442770;
		Var0 = {241.3574f, 361.0488f, 105.8963f};
		Var0.f_5 = 1538555582;
		break;

	case 110:
		Var0.f_3 = joaat("prop_ch2_09c_garage_door");
		Var0 = {-689.11f, 506.97f, 110.64f};
		Var0.f_5 = -961994186;
		break;

	case 111:
		Var0.f_3 = joaat("v_ilev_door_orangesolid");
		Var0 = {-1055.96f, -236.43f, 44.17f};
		Var0.f_5 = -1772472848;
		break;

	case 112:
		Var0.f_3 = joaat("prop_magenta_door");
		Var0 = {29f, 3661f, 41f};
		Var0.f_5 = -46374650;
		break;

	case 113:
		Var0.f_3 = joaat("prop_cs4_05_tdoor");
		Var0 = {32f, 3667f, 41f};
		Var0.f_5 = -358302761;
		break;

	case 114:
		Var0.f_3 = joaat("v_ilev_housedoor1");
		Var0 = {87f, -1959f, 21f};
		Var0.f_5 = -1237936041;
		break;

	case 115:
		Var0.f_3 = joaat("v_ilev_fh_frntdoor");
		Var0 = {0f, -1823f, 30f};
		Var0.f_5 = 1487374207;
		break;

	case 116:
		Var0.f_3 = joaat("p_cut_door_03");
		Var0 = {23.34f, -1897.6f, 23.05f};
		Var0.f_5 = -199126299;
		break;

	case 117:
		Var0.f_3 = joaat("p_cut_door_02");
		Var0 = {524.2f, 3081.14f, 41.16f};
		Var0.f_5 = -897071863;
		break;

	case 118:
		Var0.f_3 = joaat("v_ilev_po_door");
		Var0 = {-1910.58f, -576.01f, 19.25f};
		Var0.f_5 = -864465775;
		break;

	case 119:
		Var0.f_3 = joaat("prop_ss1_10_door_l");
		Var0 = {-720.39f, 256.86f, 80.29f};
		Var0.f_5 = -208439480;
		break;

	case 120:
		Var0.f_3 = joaat("prop_ss1_10_door_r");
		Var0 = {-718.42f, 257.79f, 80.29f};
		Var0.f_5 = -1001088805;
		break;

	case 121:
		Var0.f_3 = joaat("v_ilev_fibl_door02");
		Var0 = {106.38f, -742.7f, 46.18f};
		Var0.f_5 = 756894459;
		break;

	case 122:
		Var0.f_3 = joaat("v_ilev_fibl_door01");
		Var0 = {105.76f, -746.65f, 46.18f};
		Var0.f_5 = 476981677;
		break;

	case 123:
		Var0.f_3 = joaat("v_ilev_ct_door01");
		Var0 = {-2343.53f, 3265.37f, 32.96f};
		Var0.f_5 = 2081647379;
		break;

	case 124:
		Var0.f_3 = joaat("v_ilev_ct_door01");
		Var0 = {-2342.23f, 3267.62f, 32.96f};
		Var0.f_5 = 2081647379;
		break;

	case 125:
		Var0.f_3 = joaat("ap1_02_door_l");
		Var0 = {-1041.933f, -2748.167f, 22.0308f};
		Var0.f_5 = 169965357;
		break;

	case 126:
		Var0.f_3 = joaat("ap1_02_door_r");
		Var0 = {-1044.841f, -2746.489f, 22.0308f};
		Var0.f_5 = 311232516;
		break;

	case 128:
		Var0.f_3 = joaat("v_ilev_fb_doorshortl");
		Var0 = {-1045.12f, -232.004f, 39.4379f};
		Var0.f_5 = -1563127729;
		break;

	case 129:
		Var0.f_3 = joaat("v_ilev_fb_doorshortr");
		Var0 = {-1046.516f, -229.3581f, 39.4379f};
		Var0.f_5 = 759145763;
		break;

	case 130:
		Var0.f_3 = joaat("v_ilev_fb_door01");
		Var0 = {-1083.62f, -260.4167f, 38.1867f};
		Var0.f_5 = -84399179;
		break;

	case 131:
		Var0.f_3 = joaat("v_ilev_fb_door02");
		Var0 = {-1080.974f, -259.0204f, 38.1867f};
		Var0.f_5 = -461898059;
		break;

	case 127:
		Var0.f_3 = joaat("v_ilev_gtdoor");
		Var0 = {-1042.57f, -240.6f, 38.11f};
		Var0.f_5 = 1259065971;
		break;

	case 132:
		Var0.f_3 = joaat("prop_damdoor_01");
		Var0 = {1385.258f, -2079.949f, 52.7638f};
		Var0.f_5 = -884051216;
		break;

	case 133:
		Var0.f_3 = joaat("v_ilev_genbankdoor2");
		Var0 = {1656.57f, 4849.66f, 42.35f};
		Var0.f_5 = 243782214;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 134:
		Var0.f_3 = joaat("v_ilev_genbankdoor1");
		Var0 = {1656.25f, 4852.24f, 42.35f};
		Var0.f_5 = 714115627;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 135:
		Var0.f_3 = -1184516519;
		Var0 = {-1051.402f, -474.6847f, 36.6199f};
		Var0.f_5 = 1668106976;
		gameplay::set_bit(&Var0.f_4, 1);
		break;

	case 136:
		Var0.f_3 = -1184516519;
		Var0 = {-1049.285f, -476.6376f, 36.7584f};
		Var0.f_5 = 1382347031;
		gameplay::set_bit(&Var0.f_4, 1);
		break;

	case 137:
		Var0.f_3 = 1230099731;
		Var0 = {-1210.957f, -580.8765f, 27.2373f};
		Var0.f_5 = -966790948;
		gameplay::set_bit(&Var0.f_4, 1);
		break;

	case 138:
		Var0.f_3 = 1230099731;
		Var0 = {-1212.445f, -578.4401f, 27.2373f};
		Var0.f_5 = -2068750132;
		gameplay::set_bit(&Var0.f_4, 1);
		break;

	case 139:
		Var0.f_3 = joaat("v_ilev_roc_door4");
		Var0 = {-565.1712f, 276.6259f, 83.2863f};
		Var0.f_5 = -1716533184;
		break;

	case 140:
		Var0.f_3 = joaat("v_ilev_roc_door4");
		Var0 = {-561.2863f, 293.5043f, 87.7771f};
		Var0.f_5 = 2146505927;
		break;

	case 141:
		Var0.f_3 = joaat("p_jewel_door_l");
		Var0 = {-631.96f, -236.33f, 38.21f};
		Var0.f_5 = 1874948872;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 142:
		Var0.f_3 = joaat("p_jewel_door_r1");
		Var0 = {-630.43f, -238.44f, 38.21f};
		Var0.f_5 = -1965020851;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 145:
		Var0.f_3 = -1743257725;
		Var0 = {231.62f, 216.23f, 106.4f};
		Var0.f_5 = 1951546856;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 146:
		Var0.f_3 = -1743257725;
		Var0 = {232.72f, 213.88f, 106.4f};
		Var0.f_5 = -431382051;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 143:
		Var0.f_3 = 110411286;
		Var0 = {258.32f, 203.84f, 106.43f};
		Var0.f_5 = -293975210;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 144:
		Var0.f_3 = 110411286;
		Var0 = {260.76f, 202.95f, 106.43f};
		Var0.f_5 = -785215289;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 148:
		Var0.f_3 = -222270721;
		Var0 = {256.31f, 220.66f, 106.43f};
		Var0.f_5 = -366143778;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 147:
		Var0.f_3 = joaat("v_ilev_bk_door");
		Var0 = {266.36f, 217.57f, 110.43f};
		Var0.f_5 = 440819155;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 149:
		Var0.f_3 = joaat("v_ilev_shrf2door");
		Var0 = {-442.66f, 6015.222f, 31.8663f};
		Var0.f_5 = -588495243;
		break;

	case 150:
		Var0.f_3 = joaat("v_ilev_shrf2door");
		Var0 = {-444.4985f, 6017.06f, 31.8663f};
		Var0.f_5 = 1815504139;
		break;

	case 151:
		Var0.f_3 = joaat("v_ilev_shrfdoor");
		Var0 = {1855.685f, 3683.93f, 34.5928f};
		Var0.f_5 = 1344911780;
		break;

	case 152:
		Var0.f_3 = joaat("prop_bhhotel_door_l");
		Var0 = {-1223.35f, -172.41f, 39.98f};
		Var0.f_5 = -320891223;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 153:
		Var0.f_3 = joaat("prop_bhhotel_door_r");
		Var0 = {-1220.93f, -173.68f, 39.98f};
		Var0.f_5 = 1511747875;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 154:
		Var0.f_3 = joaat("prop_bhhotel_door_l");
		Var0 = {-1211.99f, -190.57f, 39.98f};
		Var0.f_5 = -1517722103;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 155:
		Var0.f_3 = joaat("prop_bhhotel_door_r");
		Var0 = {-1213.26f, -192.98f, 39.98f};
		Var0.f_5 = -1093199712;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 156:
		Var0.f_3 = joaat("prop_bhhotel_door_l");
		Var0 = {-1217.77f, -201.54f, 39.98f};
		Var0.f_5 = 1902048492;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 157:
		Var0.f_3 = joaat("prop_bhhotel_door_r");
		Var0 = {-1219.04f, -203.95f, 39.98f};
		Var0.f_5 = -444768985;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 158:
		Var0.f_3 = joaat("prop_ch3_04_door_01l");
		Var0 = {2514.32f, -317.34f, 93.32f};
		Var0.f_5 = 404057594;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 159:
		Var0.f_3 = joaat("prop_ch3_04_door_01r");
		Var0 = {2512.42f, -319.26f, 93.32f};
		Var0.f_5 = -1417472813;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 160:
		Var0.f_3 = joaat("prop_ch3_01_trlrdoor_l");
		Var0 = {2333.23f, 2574.97f, 47.03f};
		Var0.f_5 = -1376084479;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 161:
		Var0.f_3 = joaat("prop_ch3_01_trlrdoor_r");
		Var0 = {2329.65f, 2576.64f, 47.03f};
		Var0.f_5 = 457472151;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 162:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {16.1279f, -1114.605f, 29.9469f};
		Var0.f_5 = 1071759151;
		break;

	case 163:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {18.572f, -1115.495f, 29.9469f};
		Var0.f_5 = -2119023917;
		break;

	case 165:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {1698.176f, 3751.506f, 34.8553f};
		Var0.f_5 = -1488490473;
		break;

	case 166:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {1699.937f, 3753.42f, 34.8553f};
		Var0.f_5 = -511187813;
		break;

	case 167:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {244.7274f, -44.0791f, 70.91f};
		Var0.f_5 = -248569395;
		break;

	case 168:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {243.8379f, -46.5232f, 70.91f};
		Var0.f_5 = 989443413;
		break;

	case 169:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {845.3624f, -1024.539f, 28.3448f};
		Var0.f_5 = 2022251829;
		break;

	case 170:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {842.7684f, -1024.539f, 23.3448f};
		Var0.f_5 = 649820567;
		break;

	case 171:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {-326.1122f, 6075.27f, 31.6047f};
		Var0.f_5 = 537455378;
		break;

	case 172:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {-324.273f, 6077.109f, 31.6047f};
		Var0.f_5 = 1121431731;
		break;

	case 173:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {-665.2424f, -944.3256f, 21.9792f};
		Var0.f_5 = -1437380438;
		break;

	case 174:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {-662.6414f, -944.3256f, 21.9792f};
		Var0.f_5 = -946336965;
		break;

	case 175:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {-1313.826f, -389.1259f, 36.8457f};
		Var0.f_5 = 1893144650;
		break;

	case 176:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {-1314.465f, -391.6472f, 36.8457f};
		Var0.f_5 = 435841678;
		break;

	case 177:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {-1114.009f, 2689.77f, 18.7041f};
		Var0.f_5 = 948508314;
		break;

	case 178:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {-1112.071f, 2691.505f, 18.7041f};
		Var0.f_5 = -1796714665;
		break;

	case 179:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {-3164.845f, 1081.392f, 20.9887f};
		Var0.f_5 = -1155247245;
		break;

	case 180:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {-3163.812f, 1083.778f, 20.9887f};
		Var0.f_5 = 782482084;
		break;

	case 181:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {2570.905f, 303.3556f, 108.8848f};
		Var0.f_5 = -1194470801;
		break;

	case 182:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {2568.304f, 303.3556f, 108.8848f};
		Var0.f_5 = -2129698061;
		break;

	case 183:
		Var0.f_3 = joaat("v_ilev_gc_door04");
		Var0 = {813.1779f, -2148.27f, 29.7689f};
		Var0.f_5 = 1071759151;
		break;

	case 184:
		Var0.f_3 = joaat("v_ilev_gc_door03");
		Var0 = {810.5769f, -2148.27f, 29.7689f};
		Var0.f_5 = -2119023917;
		break;

	case 164:
		Var0.f_3 = joaat("v_ilev_gc_door01");
		Var0 = {6.8179f, -1098.209f, 29.9469f};
		Var0.f_5 = 1487704245;
		gameplay::set_bit(&Var0.f_4, 3);
		break;

	case 185:
		Var0.f_3 = joaat("v_ilev_gc_door01");
		Var0 = {827.5342f, -2160.493f, 29.7688f};
		Var0.f_5 = 1529812051;
		gameplay::set_bit(&Var0.f_4, 3);
		break;

	case 186:
		Var0.f_3 = joaat("prop_lrggate_01c_l");
		Var0 = {-1107.01f, 289.38f, 64.76f};
		Var0.f_5 = 904342475;
		break;

	case 187:
		Var0.f_3 = joaat("prop_lrggate_01c_r");
		Var0 = {-1101.62f, 290.36f, 64.76f};
		Var0.f_5 = -795418380;
		break;

	case 188:
		Var0.f_3 = joaat("prop_lrggate_01c_l");
		Var0 = {-1138.64f, 300.82f, 67.18f};
		Var0.f_5 = -1502457334;
		break;

	case 189:
		Var0.f_3 = joaat("prop_lrggate_01c_r");
		Var0 = {-1137.05f, 295.59f, 67.18f};
		Var0.f_5 = -1994188940;
		break;

	case 190:
		Var0.f_3 = joaat("v_ilev_bl_doorel_l");
		Var0 = {-2053.16f, 3239.49f, 30.5f};
		Var0.f_5 = -621770121;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 191:
		Var0.f_3 = joaat("v_ilev_bl_doorel_r");
		Var0 = {-2054.39f, 3237.23f, 30.5f};
		Var0.f_5 = 1018580481;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 192:
		Var0.f_3 = joaat("v_ilev_cbankcountdoor01");
		Var0 = {-108.91f, 6469.11f, 31.91f};
		Var0.f_5 = 421926217;
		break;

	case 193:
		Var0.f_3 = joaat("prop_fnclink_03gate5");
		Var0 = {-182.91f, 6168.37f, 32.14f};
		Var0.f_5 = -1331552374;
		gameplay::set_bit(&Var0.f_4, 2);
		break;
	}
	switch (iParam0) {
	case 196:
		Var0.f_3 = joaat("v_ilev_csr_door_l");
		Var0 = {-59.89f, -1092.95f, 26.88f};
		Var0.f_5 = -293141277;
		break;

	case 197:
		Var0.f_3 = joaat("v_ilev_csr_door_r");
		Var0 = {-60.55f, -1094.75f, 26.89f};
		Var0.f_5 = 506750037;
		break;

	case 194:
		Var0.f_3 = joaat("v_ilev_csr_door_l");
		Var0 = {-39.13f, -1108.22f, 26.72f};
		Var0.f_5 = 1496005418;
		break;

	case 195:
		Var0.f_3 = joaat("v_ilev_csr_door_r");
		Var0 = {-37.33f, -1108.87f, 26.72f};
		Var0.f_5 = -1863079210;
		break;

	case 198:
		Var0.f_3 = joaat("prop_ron_door_01");
		Var0 = {1943.73f, 3803.63f, 32.31f};
		Var0.f_5 = -2018911784;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 199:
		Var0.f_3 = joaat("v_ilev_genbankdoor2");
		Var0 = {316.39f, -276.49f, 54.52f};
		Var0.f_5 = -93934272;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 200:
		Var0.f_3 = joaat("v_ilev_genbankdoor1");
		Var0 = {313.96f, -275.6f, 54.52f};
		Var0.f_5 = 667682830;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 201:
		Var0.f_3 = joaat("v_ilev_genbankdoor2");
		Var0 = {-2965.71f, 484.22f, 16.05f};
		Var0.f_5 = 1876735830;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 202:
		Var0.f_3 = joaat("v_ilev_genbankdoor1");
		Var0 = {-2965.82f, 481.63f, 16.05f};
		Var0.f_5 = -2112857171;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 205:
		Var0.f_3 = joaat("v_ilev_abbmaindoor");
		Var0 = {962.1f, -2183.83f, 31.06f};
		Var0.f_5 = 2046930518;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 206:
		Var0.f_3 = joaat("v_ilev_abbmaindoor2");
		Var0 = {961.79f, -2187.08f, 31.06f};
		Var0.f_5 = 1208502884;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 207:
		Var0.f_3 = joaat("prop_ch3_04_door_02");
		Var0 = {2508.43f, -336.63f, 115.76f};
		Var0.f_5 = 1986432421;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 208:
		Var0.f_3 = joaat("prop_ch1_07_door_01l");
		Var0 = {-2255.19f, 322.26f, 184.93f};
		Var0.f_5 = -722798986;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 209:
		Var0.f_3 = joaat("prop_ch1_07_door_01r");
		Var0 = {-2254.06f, 319.7f, 184.93f};
		Var0.f_5 = 204301578;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 210:
		Var0.f_3 = joaat("prop_ch1_07_door_01l");
		Var0 = {-2301.13f, 336.91f, 184.93f};
		Var0.f_5 = -320140460;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 211:
		Var0.f_3 = joaat("prop_ch1_07_door_01r");
		Var0 = {-2298.57f, 338.05f, 184.93f};
		Var0.f_5 = 65222916;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 212:
		Var0.f_3 = joaat("prop_ch1_07_door_01l");
		Var0 = {-2222.32f, 305.86f, 184.93f};
		Var0.f_5 = -920027322;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 213:
		Var0.f_3 = joaat("prop_ch1_07_door_01r");
		Var0 = {-2221.19f, 303.3f, 184.93f};
		Var0.f_5 = -58432001;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 214:
		Var0.f_3 = joaat("prop_ch1_07_door_01l");
		Var0 = {-2280.6f, 265.43f, 184.93f};
		Var0.f_5 = -2007378629;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 215:
		Var0.f_3 = joaat("prop_ch1_07_door_01r");
		Var0 = {-2278.04f, 266.57f, 184.93f};
		Var0.f_5 = 418772613;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 216:
		Var0.f_3 = joaat("prop_gar_door_04");
		Var0 = {778.31f, -1867.49f, 30.66f};
		Var0.f_5 = 1679064921;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 217:
		Var0.f_3 = joaat("prop_gate_tep_01_l");
		Var0 = {-721.35f, 91.01f, 56.68f};
		Var0.f_5 = 412198396;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 218:
		Var0.f_3 = joaat("prop_gate_tep_01_r");
		Var0 = {-728.84f, 88.64f, 56.68f};
		Var0.f_5 = -1053755588;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 219:
		Var0.f_3 = joaat("prop_artgallery_02_dr");
		Var0 = {-2287.62f, 363.9f, 174.93f};
		Var0.f_5 = -53446139;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 220:
		Var0.f_3 = joaat("prop_artgallery_02_dl");
		Var0 = {-2289.78f, 362.91f, 174.93f};
		Var0.f_5 = 1333960556;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 221:
		Var0.f_3 = joaat("prop_artgallery_02_dr");
		Var0 = {-2289.86f, 362.88f, 174.93f};
		Var0.f_5 = -41786493;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 222:
		Var0.f_3 = joaat("prop_artgallery_02_dl");
		Var0 = {-2292.01f, 361.89f, 174.93f};
		Var0.f_5 = 1750120734;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 223:
		Var0.f_3 = joaat("prop_fnclink_07gate1");
		Var0 = {1803.94f, 3929.01f, 33.72f};
		Var0.f_5 = 1661506222;
		break;

	case 203:
		Var0.f_3 = joaat("v_ilev_genbankdoor2");
		Var0 = {-348.81f, -47.26f, 49.39f};
		Var0.f_5 = -2116116146;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 204:
		Var0.f_3 = joaat("v_ilev_genbankdoor1");
		Var0 = {-351.26f, -46.41f, 49.39f};
		Var0.f_5 = -74083138;
		gameplay::set_bit(&Var0.f_4, 2);
		break;

	case 224:
		Var0.f_3 = joaat("prop_abat_slide");
		Var0 = {962.9084f, -2105.814f, 34.6432f};
		Var0.f_5 = -1670085357;
		break;
	}
	return Var0;
}

//Position - 0x122B0
int func_207()
{
	if ((func_209() == -1 || func_209() == 999) && func_208() != 0) {
		return 1;
	}
	return 0;
}

// Position - 0x122E0
int func_208() { return Global_25191; }

// Position - 0x122EB
int func_209() { return Global_25190; }

// Position - 0x122F6
int func_210(vector3 vParam0, int iParam3, int iParam4) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = 10;
	iVar0 = 0;
	while (iVar0 <= 10 - 1) {
		if (Global_86862[iVar0 /*10*/].f_7 != 263) {
			if (Global_86862[iVar0 /*10*/].f_9 == iParam3 || iParam3 == 145) {
				if (func_211(iVar0) || iParam4 == 0) {
					fVar1 = gameplay::get_distance_between_coords(vParam0, Global_86862[iVar0 /*10*/].f_3, 1);
					if (fVar1 < fVar2) {
						fVar2 = fVar1;
						iVar3 = iVar0;
					}
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x12385
var func_211(int iParam0) { return gameplay::is_bit_set(Global_101700.f_6188[iParam0], 0); }

// Position - 0x1239D
void func_212(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 8) {
		func_213(iParam0, iVar0);
		iVar0++;
	}
}

// Position - 0x123C0
void func_213(int iParam0, int iParam1) {
	int iVar0;
	float fVar1;
	int *iVar2;
	int iVar3;

	if (iParam0 != 0 || iParam0 != 1 || iParam0 != 2 || iParam0 != 3) {
		return;
	}
	func_217(iParam0, iParam1, &iVar2, &iVar3);
	if (network::network_is_game_in_progress()) {
		iVar0 = func_214(iVar3, -1, 0);
	}
	else {
		stats::stat_get_int(iVar2, &iVar0, -1);
	}
	switch (iParam1) {
	case 2:
		fVar1 = 0.8f + 0.4f * system::to_float(iVar0) / 100f;
		player::set_player_melee_weapon_damage_modifier(player::player_id(), fVar1, 1);
		break;

	case 7:
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("armenian3")) != 0 ||
			script::_get_number_of_instances_of_script_with_name_hash(joaat("trevor3")) != 0) {
			Global_89107 = 1;
		}
		else {
			fVar1 = 1f - system::to_float(iVar0) / 100f;
			player::set_player_noise_multiplier(player::player_id(), fVar1);
			player::set_player_sneaking_noise_multiplier(player::player_id(), fVar1);
			player::set_player_stealth_perception_modifier(player::player_id(), fVar1);
		}
		break;
	}
}

// Position - 0x124AD
int func_214(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_215(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x124DF
int func_215(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_216();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x12513
int func_216() { return Global_1312735; }

// Position - 0x1251F
void func_217(int iParam0, int iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp0_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp0_stamina"); break;

		case 3: *iParam2 = joaat("sp0_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp0_strength"); break;

		case 4: *iParam2 = joaat("sp0_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp0_flying_ability"); break;

		case 6: *iParam2 = joaat("sp0_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp0_stealth_ability"); break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp1_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp1_stamina"); break;

		case 3: *iParam2 = joaat("sp1_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp1_strength"); break;

		case 4: *iParam2 = joaat("sp1_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp1_flying_ability"); break;

		case 6: *iParam2 = joaat("sp1_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp1_stealth_ability"); break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp2_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp2_stamina"); break;

		case 3: *iParam2 = joaat("sp2_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp2_strength"); break;

		case 4: *iParam2 = joaat("sp2_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp2_flying_ability"); break;

		case 6: *iParam2 = joaat("sp2_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp2_stealth_ability"); break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: *iParam3 = 64; break;

		case 1: *iParam3 = 65; break;

		case 3: *iParam3 = 67; break;

		case 2: *iParam3 = 66; break;

		case 4: *iParam3 = 68; break;

		case 5: *iParam3 = 69; break;

		case 6: *iParam3 = 70; break;

		case 7: *iParam3 = 71; break;
		}
		break;
	}
}

// Position - 0x12776
void func_218() {
	struct<50> Var0;

	if (ped::is_ped_injured(player::player_ped_id()) || !func_95(func_93()) || !func_224()) {
		return;
	}
	Var0 = 12;
	Var0.f_13 = 12;
	Var0.f_26 = 12;
	Var0.f_39 = 9;
	Var0.f_49 = 9;
	func_220(player::player_ped_id(), &Var0, 1);
	func_219(1306, Var0[0], -1, 1);
	func_219(1307, Var0[1], -1, 1);
	func_219(1308, Var0[2], -1, 1);
	func_219(1309, Var0[3], -1, 1);
	func_219(1310, Var0[4], -1, 1);
	func_219(1311, Var0[5], -1, 1);
	func_219(1312, Var0[6], -1, 1);
	func_219(1313, Var0[7], -1, 1);
	func_219(1314, Var0[8], -1, 1);
	func_219(1315, Var0[9], -1, 1);
	func_219(1316, Var0[10], -1, 1);
	func_219(1317, Var0[11], -1, 1);
	func_219(1318, Var0.f_13[0], -1, 1);
	func_219(1319, Var0.f_13[1], -1, 1);
	func_219(1320, Var0.f_13[2], -1, 1);
	func_219(1321, Var0.f_13[3], -1, 1);
	func_219(1322, Var0.f_13[4], -1, 1);
	func_219(1323, Var0.f_13[5], -1, 1);
	func_219(1324, Var0.f_13[6], -1, 1);
	func_219(1325, Var0.f_13[7], -1, 1);
	func_219(1326, Var0.f_13[8], -1, 1);
	func_219(1327, Var0.f_13[9], -1, 1);
	func_219(1328, Var0.f_13[10], -1, 1);
	func_219(1329, Var0.f_13[11], -1, 1);
	func_219(1330, Var0.f_26[0], -1, 1);
	func_219(1331, Var0.f_26[1], -1, 1);
	func_219(1332, Var0.f_26[2], -1, 1);
	func_219(1333, Var0.f_26[3], -1, 1);
	func_219(1334, Var0.f_26[4], -1, 1);
	func_219(1335, Var0.f_26[5], -1, 1);
	func_219(1336, Var0.f_26[6], -1, 1);
	func_219(1337, Var0.f_26[7], -1, 1);
	func_219(1338, Var0.f_26[8], -1, 1);
	func_219(1339, Var0.f_26[9], -1, 1);
	func_219(1340, Var0.f_26[10], -1, 1);
	func_219(1341, Var0.f_26[11], -1, 1);
	func_219(1342, Var0.f_39[0], -1, 1);
	func_219(1343, Var0.f_39[1], -1, 1);
	func_219(1344, Var0.f_39[2], -1, 1);
	func_219(1345, Var0.f_39[3], -1, 1);
	func_219(1346, Var0.f_39[4], -1, 1);
	func_219(1347, Var0.f_39[5], -1, 1);
	func_219(1348, Var0.f_39[6], -1, 1);
	func_219(1349, Var0.f_39[7], -1, 1);
	func_219(1350, Var0.f_39[8], -1, 1);
	func_219(1351, Var0.f_49[0], -1, 1);
	func_219(1352, Var0.f_49[1], -1, 1);
	func_219(1353, Var0.f_49[2], -1, 1);
	func_219(1354, Var0.f_49[3], -1, 1);
	func_219(1355, Var0.f_49[4], -1, 1);
	func_219(1356, Var0.f_49[5], -1, 1);
	func_219(1357, Var0.f_49[6], -1, 1);
	func_219(1358, Var0.f_49[7], -1, 1);
	func_219(1359, Var0.f_49[8], -1, 1);
	func_219(1360, func_93(), -1, 1);
	stats::stat_set_bool(joaat("clo_stored_initial"), 1, 1);
	Global_101700.f_2095.f_539.f_3543 = 1;
}

// Position - 0x12B89
var func_219(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;

	if (iParam2 == -1) {
		iParam2 = func_216();
	}
	if (iParam1 < 0) {
		iParam1 = 255;
	}
	iVar0 = 0;
	iVar1 = 0;
	if (iParam0 >= 384 && iParam0 < 457) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 384, 0, 1, iParam2);
		iVar1 = iParam0 - 384 - stats::_0x94F12ABF9C79E339(iParam0 - 384) * 8 * 8;
	}
	else if (iParam0 >= 457 && iParam0 < 513) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 457, 1, 1, iParam2);
		iVar1 = iParam0 - 457 - stats::_0x94F12ABF9C79E339(iParam0 - 457) * 8 * 8;
	}
	else if (iParam0 >= 1281 && iParam0 < 1305) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 1281, 0, 0, 0);
		iVar1 = iParam0 - 1281 - stats::_0x94F12ABF9C79E339(iParam0 - 1281) * 8 * 8;
	}
	else if (iParam0 >= 1305 && iParam0 < 1361) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 1305, 1, 0, 0);
		iVar1 = iParam0 - 1305 - stats::_0x94F12ABF9C79E339(iParam0 - 1305) * 8 * 8;
	}
	else if (iParam0 >= 1393 && iParam0 < 2919) {
		iVar0 = stats::_get_tupstat_int_hash(iParam0 - 1393, 0, 1, iParam2);
		iVar1 = iParam0 - 1393 - stats::_0x94F12ABF9C79E339(iParam0 - 1393) * 8 * 8;
	}
	else if (iParam0 >= 1361 && iParam0 < 1393) {
		iVar0 = stats::_get_tupstat_int_hash(iParam0 - 1361, 0, 0, 0);
		iVar1 = iParam0 - 1361 - stats::_0x94F12ABF9C79E339(iParam0 - 1361) * 8 * 8;
	}
	else if (iParam0 >= 3879 && iParam0 < 4143) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 3879, 0, 1, iParam2, "_NGPSTAT_INT");
		iVar1 = iParam0 - 3879 - stats::_0x94F12ABF9C79E339(iParam0 - 3879) * 8 * 8;
	}
	else if (iParam0 >= 4143 && iParam0 < 4207) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 4143, 0, 0, 0, "_NGPSTAT_INT");
		iVar1 = iParam0 - 4143 - stats::_0x94F12ABF9C79E339(iParam0 - 4143) * 8 * 8;
	}
	else if (iParam0 >= 4399 && iParam0 < 6028) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 4399, 0, 1, iParam2, "_LRPSTAT_INT");
		iVar1 = iParam0 - 4399 - stats::_0x94F12ABF9C79E339(iParam0 - 4399) * 8 * 8;
	}
	else if (iParam0 >= 6413 && iParam0 < 7262) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 6413, 0, 1, iParam2, "_APAPSTAT_INT");
		iVar1 = iParam0 - 6413 - stats::_0x94F12ABF9C79E339(iParam0 - 6413) * 8 * 8;
	}
	else if (iParam0 >= 7262 && iParam0 < 7313) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7262, 0, 1, iParam2, "_LR2PSTAT_INT");
		iVar1 = iParam0 - 7262 - stats::_0x94F12ABF9C79E339(iParam0 - 7262) * 8 * 8;
	}
	else if (iParam0 >= 7681 && iParam0 < 9361) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7681, 0, 1, iParam2, "_BIKEPSTAT_INT");
		iVar1 = iParam0 - 7681 - stats::_0x94F12ABF9C79E339(iParam0 - 7681) * 8 * 8;
	}
	else if (iParam0 >= 9553 && iParam0 < 15265) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 9553, 0, 1, iParam2, "_IMPEXPPSTAT_INT");
		iVar1 = iParam0 - 9553 - stats::_0x94F12ABF9C79E339(iParam0 - 9553) * 8 * 8;
	}
	else if (iParam0 >= 7641 && iParam0 < 7681) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7641, 0, 1, iParam2, "_NGDLCPSTAT_INT");
		iVar1 = iParam0 - 7641 - stats::_0x94F12ABF9C79E339(iParam0 - 7641) * 8 * 8;
	}
	else if (iParam0 >= 7313 && iParam0 < 7321) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7313, 0, 0, 0, "_NGDLCPSTAT_INT");
		iVar1 = iParam0 - 7313 - stats::_0x94F12ABF9C79E339(iParam0 - 7313) * 8 * 8;
	}
	uVar2 = stats::stat_set_masked_int(iVar0, iParam1, iVar1, 8, iParam3);
	return uVar2;
}

// Position - 0x12F7D
void func_220(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = func_96(iParam0);
		iVar1 = 0;
		while (iVar1 < 12) {
			func_223(iParam0, iVar1, &uParam1->f_13[iVar1], &(*uParam1)[iVar1], &uParam1->f_26[iVar1], iParam2, 145);
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 9) {
			func_222(iParam0, iVar1, &uParam1->f_39[iVar1], &uParam1->f_49[iVar1], iParam2, 145);
			iVar1++;
		}
		if (func_95(iVar0)) {
			uParam1->f_59 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_59;
			uParam1->f_60 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_60;
			uParam1->f_61 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_61;
			uParam1->f_62 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_62;
			uParam1->f_63 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_63;
			uParam1->f_64 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_64;
		}
		else if (network::network_is_game_in_progress() &&
				 entity::get_entity_model(iParam0) == entity::get_entity_model(player::player_ped_id())) {
			if (func_221(161, -1)) {
				uParam1->f_59 = func_214(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_214(747, Global_69521, 0);
			}
			uParam1->f_60 = func_214(748, Global_69521, 0);
			uParam1->f_61 = func_214(749, Global_69521, 0);
		}
		if (network::network_is_game_in_progress() && iParam0 == player::player_ped_id()) {
			if (func_221(161, -1)) {
				uParam1->f_59 = func_214(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_214(747, Global_69521, 0);
			}
		}
	}
}

// Position - 0x13127
bool func_221(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_215(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return false;
}

// Position - 0x13153
void func_222(int iParam0, int iParam1, int *iParam2, int *iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_prop_index(iParam0, iParam1);
		*iParam3 = ped::get_ped_prop_texture_index(iParam0, iParam1);
	}
	else {
		iVar0 = iParam5;
	}
	if (iParam4 == 0) {
		return;
	}
	if (iParam1 == 0) {
		if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
			if (iParam0 != 0) {
				if (ped::is_ped_wearing_helmet(iParam0) && ped::_0x451294E859ECC018(iParam0) != -1) {
					*iParam2 = ped::_0x451294E859ECC018(iParam0);
					*iParam3 = ped::_0x9D728C1E12BF5518(iParam0);
				}
			}
		}
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 0) {
			if (*iParam2 == 7) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 28) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		else if (iParam1 == 1) {
			if (*iParam2 == 1) {
				if ((iParam4 & 2) != 0 || (iParam4 & 64) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 0) {
			if (*iParam2 == 2) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 4) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 6) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 17) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 20) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 8 && *iParam2 <= 14) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 0) {
			if (*iParam2 == 9) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 12) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20 || *iParam2 == 2) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;
	}
}

// Position - 0x1369B
void func_223(int iParam0, int iParam1, int *iParam2, int *iParam3, var *uParam4, int iParam5, int iParam6) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_drawable_variation(iParam0, iParam1);
		*iParam3 = ped::get_ped_texture_variation(iParam0, iParam1);
		*uParam4 = ped::get_ped_palette_variation(iParam0, iParam1);
	}
	else {
		iVar0 = iParam6;
	}
	if (iParam5 == 0) {
		return;
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 15) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 3 || *iParam2 == 22) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 8) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 1 || *iParam2 == 10) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 19) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 3) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if (*iParam2 >= 5 && *iParam2 <= 7) {
				if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0x138DC
int func_224() {
	if (func_226() && func_225(0)) {
		return 1;
	}
	return 0;
}

// Position - 0x138FA
var func_225(int iParam0) { return Global_1312373[iParam0]; }

// Position - 0x1390A
var func_226() { return func_225(func_216() + 1); }

// Position - 0x1391C
void func_227(int iParam0) {
	switch (iParam0) {
	case 0:
		ped::set_relationship_between_groups(255, 1166638144, 1862763509);
		ped::set_relationship_between_groups(2, 1862763509, -1865950624);
		ped::set_relationship_between_groups(255, -1865950624, 1862763509);
		ped::set_relationship_between_groups(1, Global_86827, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86827);
		ped::set_relationship_between_groups(1, Global_86828, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86828);
		ped::set_relationship_between_groups(1, Global_86829, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86829);
		break;

	case 1:
		ped::set_relationship_between_groups(1, 1166638144, 1862763509);
		ped::set_relationship_between_groups(2, 1862763509, -1865950624);
		ped::set_relationship_between_groups(255, -1865950624, 1862763509);
		ped::set_relationship_between_groups(1, Global_86827, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86827);
		ped::set_relationship_between_groups(1, Global_86828, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86828);
		ped::set_relationship_between_groups(1, Global_86829, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86829);
		break;

	case 2:
		ped::set_relationship_between_groups(255, 1166638144, 1862763509);
		ped::set_relationship_between_groups(5, 1862763509, -1865950624);
		ped::set_relationship_between_groups(5, -1865950624, 1862763509);
		ped::set_relationship_between_groups(1, Global_86827, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86827);
		ped::set_relationship_between_groups(1, Global_86828, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86828);
		ped::set_relationship_between_groups(1, Global_86829, 1862763509);
		ped::set_relationship_between_groups(1, 1862763509, Global_86829);
		break;

	default: break;
	}
}

// Position - 0x13AD0
void func_228() {
	int iVar0;
	int iVar1;

	func_94();
	iVar0 = ui::get_main_player_blip_id();
	if (ui::does_blip_exist(iVar0)) {
		iVar1 = Global_101700.f_2095.f_539.f_3549;
		if (func_310(14)) {
			iVar1 = func_96(player::player_ped_id());
		}
		if (iVar1 == 0) {
			ui::set_blip_name_from_text_file(iVar0, "BLIP_MICHAEL");
		}
		else if (iVar1 == 1) {
			ui::set_blip_name_from_text_file(iVar0, "BLIP_FRANKLIN");
		}
		else if (iVar1 == 2) {
			ui::set_blip_name_from_text_file(iVar0, "BLIP_TREV");
		}
		else {
			ui::set_blip_name_from_text_file(iVar0, "BLIP_PLAYER");
		}
	}
}

// Position - 0x13B53
void func_229(int iParam0) {
	int iVar0;
	var uVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	struct<2> Var6;

	iVar0 = 0;
	while (iVar0 < 44) {
		iVar2 = func_230(iVar0);
		if (iVar2 != 0) {
			iVar3 = weapon::get_ped_weapontype_in_slot(iParam0, iVar2);
			if (iVar3 != 0 && iVar3 != joaat("weapon_unarmed") && iVar3 != joaat("object")) {
				if (weapon::get_ammo_in_ped_weapon(iParam0, iVar3) == -1) {
					if (weapon::get_max_ammo(iParam0, iVar3, &uVar1)) {
						weapon::set_ped_infinite_ammo(iParam0, 0, iVar3);
					}
				}
			}
		}
		iVar0++;
	}
	iVar5 = dlc1::get_num_dlc_weapons();
	iVar4 = 0;
	while (iVar4 < iVar5) {
		if (dlc1::get_dlc_weapon_data(iVar4, &Var6)) {
			iVar3 = Var6.f_1;
			if (weapon::get_ammo_in_ped_weapon(iParam0, iVar3) == -1) {
				if (weapon::get_max_ammo(iParam0, iVar3, &uVar1)) {
					weapon::set_ped_infinite_ammo(iParam0, 0, iVar3);
				}
			}
		}
		iVar4++;
	}
}

// Position - 0x13C15
int func_230(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (iParam0) {
	case 0: iVar0 = 1993361168; break;

	case 1: iVar0 = 1277010230; break;

	case 2: iVar0 = 932043479; break;

	case 3: iVar0 = -690654591; break;

	case 4: iVar0 = -1459198205; break;

	case 5: iVar0 = 195782970; break;

	case 6: iVar0 = -438797331; break;

	case 7: iVar0 = 896793492; break;

	case 8: iVar0 = 495159329; break;

	case 9: iVar0 = -1155528315; break;

	case 10: iVar0 = -515636489; break;

	case 11: iVar0 = -871913299; break;

	case 12: iVar0 = -1352759032; break;

	case 13: iVar0 = -542958961; break;

	case 14: iVar0 = 1682645887; break;

	case 15: iVar0 = -859470162; break;

	case 16: iVar0 = -2125426402; break;

	case 17: iVar0 = 2067210266; break;

	case 18: iVar0 = -538172856; break;

	case 19: iVar0 = 1783244476; break;

	case 20: iVar0 = 439844898; break;

	case 21: iVar0 = -24829327; break;

	case 22: iVar0 = 1949306232; break;

	case 23: iVar0 = -1941230881; break;

	case 24: iVar0 = -1033554448; break;

	case 25: iVar0 = 320513715; break;

	case 26: iVar0 = -695165975; break;

	case 27: iVar0 = -281028447; break;

	case 28: iVar0 = -686713772; break;

	case 29: iVar0 = 347509793; break;

	case 30: iVar0 = 1769089473; break;

	case 31: iVar0 = 189935548; break;

	case 33: iVar0 = 248801358; break;

	case 34: iVar0 = 386596758; break;

	case 35: iVar0 = -157212362; break;

	case 36: iVar0 = 436985596; break;

	case 37: iVar0 = -47957369; break;

	case 38: iVar0 = 575938238; break;
	}
	return iVar0;
}

// Position - 0x13E89
void func_231(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id() && ped::get_ped_max_health(iParam0) == 200) {
			ped::set_ped_max_health(iParam0,
									system::round(IntToFloat(ped::get_ped_max_health(iParam0)) * Global_262145.f_105));
		}
		if (Global_101700.f_2095.f_539.f_290[iVar0] <= 0f) {
			Global_101700.f_2095.f_539.f_290[iVar0] = 100f;
		}
		else if (Global_101700.f_2095.f_539.f_290[iVar0] <= 10f) {
			Global_101700.f_2095.f_539.f_290[iVar0] = 10f;
		}
		entity::set_entity_health(iParam0,
								  system::round(Global_101700.f_2095.f_539.f_290[iVar0] / 100f *
													(system::to_float(ped::get_ped_max_health(iParam0)) - 100f) +
												100f));
	}
}

// Position - 0x13F75
int func_232(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	else if (iParam0 == 2) {
		return 2;
	}
	else if (iParam0 == 1) {
		return 1;
	}
	else if (iParam0 == 145) {
		return 3;
	}
	return 4;
}

// Position - 0x13FB0
bool func_233(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_142(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0x13FD2
int func_234(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	else if (iParam0 == 2) {
		return 2;
	}
	else if (iParam0 == 1) {
		return 1;
	}
	return 145;
}

// Position - 0x14000
void func_235(int iParam0, int iParam1) {
	switch (iParam0) {
	case 0:
		func_236(4, *iParam1, 0);
		func_236(7, *iParam1, 0);
		func_236(8, *iParam1, 0);
		func_236(11, *iParam1, 0);
		break;

	case 1:
		func_236(4, *iParam1, 0);
		func_236(7, *iParam1, 0);
		func_236(8, *iParam1, 0);
		func_236(11, *iParam1, 0);
		if (Global_101700.f_8044.f_99.f_58[126]) {
			func_236(12, *iParam1, 0);
		}
		break;

	case 2:
		func_236(4, *iParam1, 0);
		func_236(7, *iParam1, 0);
		func_236(8, *iParam1, 0);
		func_236(11, *iParam1, 0);
		break;
	}
}

// Position - 0x140B8
void func_236(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	bool bVar1;

	if (!iParam2) {
		if (!entity::does_entity_exist(iParam1)) {
			return;
		}
	}
	if (Global_34904[iParam0 /*31*/].f_24 == 0) {
		return;
	}
	bVar1 = false;
	iVar0 = 0;
	while (iVar0 < Global_34904[iParam0 /*31*/].f_24) {
		if (bVar1) {
			Global_34904[iParam0 /*31*/].f_25[iVar0 - 1] = Global_34904[iParam0 /*31*/].f_25[iVar0];
			Global_34904[iParam0 /*31*/].f_25[iVar0] = 0;
		}
		else if (iParam1 == Global_34904[iParam0 /*31*/].f_25[iVar0]) {
			Global_34904[iParam0 /*31*/].f_25[iVar0] = 0;
			bVar1 = true;
		}
		iVar0++;
	}
	if (bVar1) {
		Global_34904[iParam0 /*31*/].f_24--;
	}
}

// Position - 0x14174
void func_237(int iParam0, int iParam1) {
	func_248(iParam0);
	func_243(iParam0, iParam1);
	func_242(iParam0);
	func_241(iParam0);
	func_240(iParam0);
	func_239(iParam0);
	func_238(iParam0);
}

// Position - 0x141A8
void func_238(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			Global_101700.f_2095.f_539.f_1556[iVar0] = player::get_player_wanted_level(player::player_id());
		}
	}
}

// Position - 0x141EF
void func_239(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_1546[iVar0 /*3*/] = {entity::get_entity_velocity(iParam0)};
	}
}

// Position - 0x1422D
void func_240(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (streaming::is_player_switch_in_progress() && streaming::get_player_switch_type() != 3) {
			if (streaming::get_player_switch_state() == 8) {
				return;
			}
		}
		Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/] = {entity::get_entity_coords(iParam0, 1)};
		Global_101700.f_2095.f_539.f_1538[iVar0] = entity::get_entity_heading(iParam0);
		Global_101700.f_2095.f_539.f_1542[iVar0] = interior::get_room_key_from_entity(iParam0);
		if (Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/] >= 8000f) {
			Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/] = 7500f;
		}
		else if (Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/] <= -8000f) {
			Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/] = -7500f;
		}
		if (Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_1 >= 8000f) {
			Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_1 = 7500f;
		}
		else if (Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_1 <= -8000f) {
			Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_1 = -7500f;
		}
		if (Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_2 >= 2500f) {
			Global_101700.f_2095.f_539.f_1528[iVar0 /*3*/].f_2 = 2000f;
		}
	}
}

// Position - 0x143BA
void func_241(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_294[iVar0] = ped::get_ped_armour(iParam0);
	}
}

// Position - 0x143F6
void func_242(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_290[iVar0] = (system::to_float(entity::get_entity_health(iParam0)) - 100f) /
												  (system::to_float(ped::get_ped_max_health(iParam0)) - 100f) * 100f;
	}
}

// Position - 0x14453
void func_243(int iParam0, bool bParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			func_244(iParam0, &Global_101700.f_2095.f_539.f_298[iVar0 /*284*/]);
			iVar2 = 0;
			while (iVar2 <= 8 - 1) {
				Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] = ui::_0xA13E93403F26C812(iVar2);
				if (bParam1) {
					iVar1 = ui::_0xA48931185F0536FE();
					if (Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] == iVar1) {
						Global_101700.f_2095.f_539.f_1184 = iVar2;
					}
				}
				iVar2++;
			}
			player::get_player_parachute_pack_tint_index(player::player_id(), &iVar3);
			if (iVar0 == 0) {
				stats::stat_set_int(joaat("sp0_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 1) {
				stats::stat_set_int(joaat("sp1_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 2) {
				stats::stat_set_int(joaat("sp2_parachute_current_tint"), iVar3, 1);
			}
		}
	}
}

// Position - 0x14546
void func_244(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	int iVar7;
	int iVar8;
	struct<2> Var9;
	struct<4> Var48;
	int iVar70;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			(*uParam1)[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			iVar3 = func_230(iVar0);
			if (iVar3 != 0) {
				vVar4.x = weapon::get_ped_weapontype_in_slot(iParam0, func_230(iVar0));
				vVar4.y = 0;
				vVar4.z = 0;
				if (vVar4.x != 0 && vVar4.x != joaat("weapon_unarmed")) {
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (vVar4.x == joaat("gadget_parachute")) {
						vVar4.y = 1;
					}
					gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					(*uParam1)[iVar0 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					iVar2 = func_246(vVar4.x, iVar1);
					while (iVar2 != 0) {
						if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, iVar2)) {
							gameplay::set_bit(&vVar4.f_2, iVar1);
						}
						iVar1++;
						iVar2 = func_246(vVar4.x, iVar1);
					}
				}
				(*uParam1)[iVar0 /*3*/] = {vVar4};
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 50 - 1) {
			uParam1->f_133[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar8 = dlc1::get_num_dlc_weapons();
		iVar7 = 0;
		while (iVar7 < iVar8) {
			if (dlc1::get_dlc_weapon_data(iVar7, &Var9) && !func_245(Var9.f_1) && iVar70 < 50) {
				if (!dlc1::_is_dlc_data_empty(Var9)) {
					vVar4.x = Var9.f_1;
					vVar4.y = 0;
					vVar4.z = 0;
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					}
					else {
						gameplay::set_bit(&vVar4.f_2, 20);
					}
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					uParam1->f_133[iVar70 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					while (iVar1 < dlc1::get_num_dlc_weapon_components(iVar7)) {
						if (dlc1::get_dlc_weapon_component_data(iVar7, iVar1, &Var48)) {
							if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, Var48.f_3)) {
								gameplay::set_bit(&vVar4.f_2, iVar1);
							}
						}
						iVar1++;
					}
				}
				if (vVar4.x != 0) {
					if (!weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						vVar4.x = 0;
						vVar4.y = 0;
					}
				}
				uParam1->f_133[iVar70 /*3*/] = {vVar4};
				iVar70++;
			}
			iVar7++;
		}
	}
}

// Position - 0x147AA
int func_245(int iParam0) {
	if (network::network_is_game_in_progress()) {
	}
	else {
		switch (iParam0) {
		case joaat("weapon_pistol50"):
		case joaat("weapon_bullpupshotgun"):
		case joaat("weapon_assaultsmg"): return 0;

		case joaat("weapon_bottle"):
		case joaat("weapon_snspistol"):
		case joaat("weapon_gusenberg"): return 0;

		case joaat("weapon_heavypistol"):
		case joaat("weapon_specialcarbine"): return 0;

		case joaat("weapon_bullpuprifle"): return 0;

		case joaat("weapon_dagger"):
		case joaat("weapon_vintagepistol"): return 0;

		case joaat("weapon_firework"):
		case joaat("weapon_musket"): return 0;

		case joaat("weapon_heavyshotgun"):
		case joaat("weapon_marksmanrifle"): return 0;

		case joaat("weapon_hominglauncher"):
		case joaat("weapon_proxmine"): return 0;

		case joaat("weapon_combatpdw"):
		case joaat("weapon_knuckle"):
		case joaat("weapon_marksmanpistol"): return 0;

		case -947031628:
		case -572349828:
		case 392730790:
		case -1523701417:
		case -2112826155:
		case -664359727:
		case -1887867191:
		case -837150131:
		case -344484024:
		case joaat("weapon_flaregun"):
		case joaat("weapon_handcuffs"):
		case joaat("weapon_snowball"):
		case joaat("weapon_garbagebag"):
		case joaat("weapon_flashlight"):
		case joaat("weapon_switchblade"):
		case joaat("weapon_revolver"):
		case joaat("weapon_dbshotgun"):
		case joaat("weapon_compactrifle"):
		case 317205821:
		case -1121678507:
		case 125959754:
		case -853065399:
		case -1169823560:
		case -1810795771:
		case 419712736: return 1;
		}
	}
	return 0;
}

// Position - 0x14918
int func_246(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var *uVar2;
	struct<4> Var41;

	iVar0 = 0;
	switch (iParam0) {
	case joaat("weapon_pistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpistol_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_combatpistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_appistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_appistol_clip_01"); break;

		case 1: iVar0 = joaat("component_appistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_appistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_microsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_microsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_microsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_microsmg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_smg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_smg_clip_01"); break;

		case 1: iVar0 = joaat("component_smg_clip_02"); break;

		case 2: iVar0 = joaat("component_smg_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_pi_supp"); break;

		case 5: iVar0 = joaat("component_at_scope_macro_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_smg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_assaultrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_assaultrifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_at_ar_flsh"); break;

		case 5: iVar0 = joaat("component_at_scope_macro"); break;

		case 6: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 7: iVar0 = joaat("component_assaultrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_carbinerifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_carbinerifle_clip_01"); break;

		case 1: iVar0 = joaat("component_carbinerifle_clip_02"); break;

		case 2: iVar0 = joaat("component_carbinerifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_railcover_01"); break;

		case 4: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 5: iVar0 = joaat("component_at_ar_flsh"); break;

		case 6: iVar0 = joaat("component_at_scope_medium"); break;

		case 7: iVar0 = joaat("component_at_ar_supp"); break;

		case 8: iVar0 = joaat("component_carbinerifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_advancedrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_advancedrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_advancedrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_advancedrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_mg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_mg_clip_01"); break;

		case 1: iVar0 = joaat("component_mg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_scope_small_02"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_mg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_combatmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatmg_clip_01"); break;

		case 1: iVar0 = joaat("component_combatmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_scope_medium"); break;

		case 4: iVar0 = joaat("component_combatmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_pumpshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_sr_supp"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_pumpshotgun_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_assaultshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultshotgun_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultshotgun_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;
		}
		break;

	case joaat("weapon_sniperrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sniperrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_sniperrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_heavysniper"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_heavysniper_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;
		}
		break;

	case joaat("weapon_grenadelauncher"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_scope_small"); break;
		}
		break;

	case joaat("weapon_minigun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_minigun_clip_01"); break;
		}
		break;

	case joaat("weapon_assaultsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_assaultsmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_ar_supp_02"); break;
		}
		break;

	case joaat("weapon_pistol50"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol50_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol50_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol50_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpdw"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpdw_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpdw_clip_02"); break;

		case 2: iVar0 = joaat("component_combatpdw_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_small"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sawnoffshotgun_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_bullpuprifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_bullpuprifle_clip_01"); break;

		case 1: iVar0 = joaat("component_bullpuprifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 6: iVar0 = joaat("component_bullpuprifle_varmod_low"); break;
		}
		break;

	case joaat("weapon_snspistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_snspistol_clip_01"); break;

		case 1: iVar0 = joaat("component_snspistol_clip_02"); break;

		case 2: iVar0 = joaat("component_snspistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_specialcarbine"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_specialcarbine_clip_01"); break;

		case 1: iVar0 = joaat("component_specialcarbine_clip_02"); break;

		case 2: iVar0 = joaat("component_specialcarbine_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_medium"); break;

		case 5: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_specialcarbine_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_knuckle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_knuckle_varmod_pimp"); break;

		case 1: iVar0 = joaat("component_knuckle_varmod_ballas"); break;

		case 2: iVar0 = joaat("component_knuckle_varmod_dollar"); break;

		case 3: iVar0 = joaat("component_knuckle_varmod_diamond"); break;

		case 4: iVar0 = joaat("component_knuckle_varmod_hate"); break;

		case 5: iVar0 = joaat("component_knuckle_varmod_love"); break;

		case 6: iVar0 = joaat("component_knuckle_varmod_player"); break;

		case 7: iVar0 = joaat("component_knuckle_varmod_king"); break;

		case 8: iVar0 = joaat("component_knuckle_varmod_vagos"); break;
		}
		break;

	case joaat("weapon_machinepistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_machinepistol_clip_01"); break;

		case 1: iVar0 = joaat("component_machinepistol_clip_02"); break;

		case 2: iVar0 = joaat("component_machinepistol_clip_03"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;
		}
		break;

	case joaat("weapon_switchblade"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_switchblade_varmod_var1"); break;

		case 1: iVar0 = joaat("component_switchblade_varmod_var2"); break;
		}
		break;

	case joaat("weapon_revolver"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_revolver_clip_01"); break;

		case 1: iVar0 = joaat("component_revolver_varmod_boss"); break;

		case 2: iVar0 = joaat("component_revolver_varmod_goon"); break;
		}
		break;

	case -1121678507:
		switch (iParam1) {
		case 0: iVar0 = -2067221805; break;

		case 1: iVar0 = -1820405577; break;
		}
		break;

	default:
		if (iParam0 != 0) {
			iVar1 = func_247(iParam0, &uVar2);
			if (iVar1 != -1) {
				if (iParam1 < dlc1::get_num_dlc_weapon_components(iVar1)) {
					if (dlc1::get_dlc_weapon_component_data(iVar1, iParam1, &Var41)) {
						return Var41.f_3;
					}
				}
			}
		}
		break;
	}
	return iVar0;
}

// Position - 0x15404
int func_247(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1543F
void func_248(int iParam0) {
	int iVar0;

	iVar0 = func_96(iParam0);
	if (func_95(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_1524[iVar0] = func_173();
	}
}

// Position - 0x15479
int func_249(var *uParam0, int iParam1) {
	bool bVar0;
	bool bVar1;

	if (!uParam0->f_39) {
		uParam0->f_7 = 4;
		uParam0->f_39 = 1;
	}
	if (iParam1 != 0 && iParam1 != 2 && iParam1 != 1) {
	}
	else {
		bVar0 = uParam0->f_34[iParam1] == 2;
		if (func_232(func_93()) != iParam1 || bVar0) {
			bVar1 = false;
			if (bVar0 || uParam0->f_24[iParam1] != 0 ||
				func_253(iParam1) && func_250(iParam1) && !uParam0->f_18[iParam1]) {
				if (!uParam0->f_23) {
					if (!ped::is_ped_injured((*uParam0)[iParam1]) || bVar0) {
						if (uParam0->f_34[iParam1] != 1 && uParam0->f_34[iParam1] != 3) {
							bVar1 = true;
						}
					}
				}
				else if (!ped::is_ped_injured(player::player_ped_id()) &&
						 (network::network_is_game_in_progress() ||
						  player::get_player_wanted_level(player::player_id()) == 0) &&
						 !gameplay::is_bit_set(Global_89302.f_47, iParam1)) {
					bVar1 = true;
				}
			}
			else if (!(gameplay::is_bit_set(Global_101700.f_8044.f_2[27 /*3*/], 1) && !Global_3 && !func_3(0))) {
				if (uParam0->f_23) {
					bVar1 = true;
				}
			}
			if (bVar1) {
				uParam0->f_7 = iParam1;
				return 1;
			}
		}
	}
	uParam0->f_39 = 0;
	return 0;
}

// Position - 0x155D4
int func_250(int iParam0) {
	if (Global_101700.f_8044 || Global_3) {
		if (!Global_69702 || Global_69702 && iParam0 != func_232(func_252())) {
			if (!func_251(func_234(iParam0))) {
				return 0;
			}
		}
	}
	return 1;
}

// Position - 0x15624
int func_251(int iParam0) {
	if (func_95(iParam0)) {
		if (Global_101700.f_8044 || Global_3 || func_3(0)) {
			return Global_101700.f_2095.f_539.f_1576[iParam0];
		}
		else {
			return 1;
		}
	}
	return 0;
}

// Position - 0x15672
int func_252() { return Global_101700.f_2095.f_539.f_3551; }

// Position - 0x15687
int func_253(int iParam0) {
	if (Global_101700.f_8044 || Global_3 || func_3(0)) {
		if (!Global_69702 || Global_69702 && iParam0 != func_232(func_252())) {
			if (iParam0 == 0 && !func_315(115) || iParam0 == 1 && !func_315(116) || iParam0 == 2 && !func_315(117)) {
				return 0;
			}
		}
	}
	return 1;
}

// Position - 0x15713
int func_254(int iParam0) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			if (LastDispatchedMessageOrCall != iVar0) {
				func_262(iVar0);
				func_259(iParam0);
				iVar1 = 1;
			}
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			func_259(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/] == iParam0) {
			func_258(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] == iParam0) {
			func_256(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] == iParam0) {
			func_255(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x1583A
void func_255(int iParam0) {
	int iVar0;
	struct<10> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_866) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_866 - 2) {
			G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] = {G_SomeGlobalState.MessageCallStates.f_765[iVar0 + 1 /*10*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 0) {
		G_SomeGlobalState.MessageCallStates.f_765[G_SomeGlobalState.MessageCallStates.f_866 - 1 /*10*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_866--;
	}
}

// Position - 0x158F3
void func_256(int iParam0) {
	int iVar0;
	struct<14> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_764) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_764 - 2) {
			G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] = {G_SomeGlobalState.MessageCallStates.f_651[iVar0 + 1 /*14*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 0) {
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 - 1 /*14*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_764--;
	}
	func_257(0);
	func_257(1);
	func_257(2);
}

// Position - 0x159BB
void func_257(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (!func_95(iParam0)) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 > iVar1) {
				iVar1 = G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3;
			}
		}
		iVar0++;
	}
	iVar2 = 0;
	while (iVar2 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_3 == 5) {
				iVar1 = 5;
			}
		}
		iVar2++;
	}
	G_SomeGlobalState.MessageCallStates.f_919[iParam0] = iVar1;
}

// Position - 0x15A7F
void func_258(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar15 /*15*/] == iParam0) {
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_650 - 2) {
				G_SomeGlobalState.MessageCallStates.f_199[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_199[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_199[G_SomeGlobalState.MessageCallStates.f_650 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_650--;
			return;
		}
		iVar15++;
	}
}

// Position - 0x15B2C
void func_259(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/] == iParam0) {
			func_260(G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/].f_6);
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_198 - 2) {
				G_SomeGlobalState.MessageCallStates.f_137[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_137[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_137[G_SomeGlobalState.MessageCallStates.f_198 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_198--;
			return;
		}
		iVar15++;
	}
}

// Position - 0x15BE8
int func_260(int iParam0) {
	int iVar0;

	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] == 1) {
			Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] = 0;
			if (Global_101700.f_27009[iParam0 /*29*/].f_24[Global_14443] == 0) {
				iVar0 = Global_14443;
				func_261(iParam0, iVar0);
			}
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x15C59
void func_261(int iParam0, int iParam1) {
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (iParam1 > 3) {
		}
		else {
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 0;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 0;
		}
	}
}

// Position - 0x15C9C
void func_262(int iParam0) {
	int iVar0;
	int iVar1;
	struct<15> Var2;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_136) {
		return;
	}
	iVar1 = G_SomeGlobalState.MessageCallStates[iParam0 /*15*/].f_2;
	if (G_SomeGlobalState.MessageCallStates.f_136 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_136 - 2) {
			G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] = {G_SomeGlobalState.MessageCallStates[iVar0 + 1 /*15*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_136 > 0) {
		G_SomeGlobalState.MessageCallStates[G_SomeGlobalState.MessageCallStates.f_136 - 1 /*15*/] = {Var2};
		G_SomeGlobalState.MessageCallStates.f_136--;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		if (gameplay::is_bit_set(iVar1, iVar0)) {
			func_257(iVar0);
		}
		iVar0++;
	}
}

// Position - 0x15D77
int func_263(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_66(func_264(iParam0));
	if (iVar0 < 0) {
		return 15;
	}
	if (iVar0 >= 10) {
		return 15;
	}
	return Global_101700.f_1.f_12[iVar0 /*6*/][iParam1];
}

// Position - 0x15DB8
int func_264(int iParam0) {
	switch (iParam0) {
	case 0: return 7;

	case 1: return 8;

	case 2: return 9;

	case 3: return 10;

	case 4: return 11;
	}
	return -1;
}

// Position - 0x15E0D
int func_265(int iParam0) {
	int iVar0;

	iVar0 = func_66(func_264(iParam0));
	return Global_87853[iVar0 /*19*/];
}

// Position - 0x15E29
void func_266(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_273(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_75()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_272(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_273(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_272(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_270(player::player_id()) &&
				!func_268(player::player_id(), 0) && !func_267()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_270(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0x15F42
bool func_267() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0x15F5F
bool func_268(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_269(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x15FAA
int func_269(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_216();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x15FEB
int func_270(int iParam0) {
	if (func_268(iParam0, 0)) {
		return 1;
	}
	if (func_271()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0x1602D
bool func_271() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x1603E
int func_272(int iParam0, int iParam1, var uParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && uParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x16071
void func_273(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0x16094
void func_274(int iParam0) {
	if (!iParam0) {
		if (entity::does_entity_exist(iLocal_48)) {
			object::delete_object(&iLocal_48);
		}
		entity::create_model_hide(707.3041f, -967.6456f, 30.376f, 1f, 1385417869, 0);
	}
	else {
		entity::remove_model_hide(707.3041f, -967.6456f, 30.376f, 1f, 1385417869, 0);
		if (streaming::has_model_loaded(1385417869)) {
			iLocal_48 = object::create_object(1385417869, 707.3041f, -967.6456f, 30.376f, 1, 1, 0);
			entity::set_entity_heading(iLocal_48, 183.14f);
			entity::freeze_entity_position(iLocal_48, 1);
		}
	}
}

// Position - 0x16123
void func_275() {
	if (func_315(6)) {
		if (!func_3(0)) {
			if (!gameplay::is_bit_set(iLocal_41, 6)) {
				cutscene::request_cutscene("AH_2_EXT_ALT", 8);
				streaming::request_model(1385417869);
				Local_95.f_1.f_141[2 /*2*/] = 0;
				Local_95.f_1.f_141[2 /*2*/].f_1 = 0;
				Local_95.f_1.f_141[3 /*2*/] = 0;
				Local_95.f_1.f_141[3 /*2*/].f_1 = 0;
				Local_95.f_1.f_141[7 /*2*/] = 0;
				Local_95.f_1.f_141[7 /*2*/].f_1 = 0;
				Local_95.f_1.f_141[8 /*2*/] = 0;
				Local_95.f_1.f_141[8 /*2*/].f_1 = 0;
				gameplay::set_bit(&iLocal_41, 6);
			}
			else if (cutscene::_0xB56BBBCC2955D9CB()) {
				cutscene::set_cutscene_ped_prop_variation("LESTER", 1, 0, 0, 0);
			}
			if (func_311(67)) {
				if (!func_233(0)) {
					if (func_295(&iLocal_42, 0, 0, 0, 0) == 1) {
						player::set_player_control(player::player_id(), 1, 0);
						func_294();
						if (player::is_player_playing(player::player_id())) {
							player::clear_player_wanted_level(player::player_id());
							player::set_max_wanted_level(0);
						}
						iLocal_93 =
							ped::add_scenario_blocking_area(Local_95.f_1.f_394 - Local_95.f_1.f_397,
															Local_95.f_1.f_394 + Local_95.f_1.f_397, 0, 1, 1, 1);
						iLocal_94 = pathfind::add_navmesh_blocking_object(Local_95.f_1.f_394,
																		  Local_95.f_1.f_397 * FtoV(1.5f), 0f, 0, 7);
						ped::set_ped_non_creation_area(Local_95.f_1.f_394 - Local_95.f_1.f_397,
													   Local_95.f_1.f_394 + Local_95.f_1.f_397);
						pathfind::set_ped_paths_in_area(Local_95.f_1.f_394 - Local_95.f_1.f_397,
														Local_95.f_1.f_394 + Local_95.f_1.f_397, 0, 0);
						gameplay::set_bit(&iLocal_41, 2);
					}
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 2)) {
				if (func_293("AH_2_EXT_ALT") && streaming::has_model_loaded(1385417869)) {
					if (!cutscene::is_cutscene_playing()) {
						if (entity::does_entity_exist(Global_88321.f_9[0]) &&
							!entity::is_entity_dead(Global_88321.f_9[0], 0)) {
							iLocal_46 = Global_88321.f_9[0];
							entity::set_entity_as_mission_entity(iLocal_46, 0, 1);
							cutscene::register_entity_for_cutscene(iLocal_46, "LESTER", 1, joaat("ig_lestercrest"), 0);
						}
						if (entity::does_entity_exist(Global_88321.f_28[0]) &&
							!entity::is_entity_dead(Global_88321.f_28[0], 0)) {
							iLocal_47 = Global_88321.f_28[0];
							entity::set_entity_as_mission_entity(Global_88321.f_28[0], 0, 1);
							cutscene::register_entity_for_cutscene(iLocal_47, "WALKINGSTICK_LESTER", 1,
																   joaat("prop_cs_walking_stick"), 0);
						}
						if (entity::does_entity_exist(Global_88321.f_9[1]) &&
							!entity::is_entity_dead(Global_88321.f_9[1], 0)) {
							uLocal_49[0] = Global_88321.f_9[1];
							entity::set_entity_as_mission_entity(uLocal_49[0], 0, 1);
							cutscene::register_entity_for_cutscene(uLocal_49[0], "MICHAEL", 0, joaat("player_zero"), 0);
						}
						else {
							cutscene::register_entity_for_cutscene(uLocal_49[0], "MICHAEL", 2, joaat("player_zero"), 0);
							gameplay::set_bit(&iLocal_41, 12);
						}
						if (entity::does_entity_exist(player::player_ped_id()) &&
							!entity::is_entity_dead(player::player_ped_id(), 0)) {
							iLocal_45 = player::player_ped_id();
							cutscene::register_entity_for_cutscene(iLocal_45, "FRANKLIN", 1, joaat("player_one"), 0);
						}
						func_292(&Local_95.f_484, 0, 0, "MICHAEL", 1, 1);
						func_292(&Local_95.f_484, 1, 0, "FRANKLIN", 1, 1);
						func_292(&Local_95.f_484, 3, 0, "LESTER", 1, 1);
						func_73(1);
						func_266(1, 1, 1, 0);
						func_274(0);
						object::_set_door_acceleration_limit(949391213, 3, 1, 0);
						object::_set_door_ajar_angle(949391213, 0f, 1, 0);
						cutscene::start_cutscene(2048);
						player::set_player_control(player::player_id(), 1, 0);
						iLocal_44 = gameplay::get_game_timer();
					}
					else {
						func_112();
						if (entity::does_entity_exist(Global_88321[0]) && !entity::is_entity_dead(Global_88321[0], 0)) {
							entity::set_entity_as_mission_entity(Global_88321[0], 0, 1);
							func_277(Global_88321[0], 0, 1);
							vehicle::delete_vehicle(&Global_88321[0]);
						}
						if (entity::does_entity_exist(player::get_players_last_vehicle())) {
							Global_88321[0] = player::get_players_last_vehicle();
							entity::set_entity_as_mission_entity(Global_88321[0], 0, 1);
							func_277(Global_88321[0], 0, func_93());
							vehicle::delete_vehicle(&Global_88321[0]);
						}
						if (ped::get_ped_prop_index(player::player_ped_id(), 0) == 7) {
							ped::clear_ped_prop(player::player_ped_id(), 0);
						}
						if (!gameplay::is_bit_set(iLocal_41, 13)) {
							if (!cam::is_screen_faded_in() && !cam::is_screen_fading_in()) {
								cam::do_screen_fade_in(800);
							}
							gameplay::set_bit(&iLocal_41, 13);
						}
						if (cutscene::was_cutscene_skipped()) {
							gameplay::set_bit(&iLocal_41, 14);
						}
						if (gameplay::is_bit_set(iLocal_41, 14)) {
							if (cam::is_screen_faded_out()) {
								if (!gameplay::is_bit_set(iLocal_41, 1)) {
									func_276();
									gameplay::set_bit(&iLocal_41, 1);
								}
								if (!gameplay::is_bit_set(iLocal_41, 3)) {
									func_2(3, 3, 1);
									gameplay::set_bit(&iLocal_41, 3);
								}
							}
						}
						if (gameplay::is_bit_set(iLocal_41, 12)) {
							if (entity::does_entity_exist(
									cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")))) {
								uLocal_49[0] = entity::get_ped_index_from_entity_index(
									cutscene::get_entity_index_of_registered_entity("MICHAEL", joaat("player_zero")));
								gameplay::clear_bit(&iLocal_41, 12);
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 3)) {
							if (gameplay::get_game_timer() - iLocal_44 > 15848) {
								func_2(3, 3, 1);
								gameplay::set_bit(&iLocal_41, 3);
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 1)) {
							if (gameplay::get_game_timer() - iLocal_44 > 5000) {
								func_276();
								gameplay::set_bit(&iLocal_41, 1);
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 4)) {
							if (gameplay::get_game_timer() - iLocal_44 > 71550) {
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0))) {
									if (!entity::is_entity_dead(
											cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0), 0)) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0), 0, 0);
									}
								}
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("LESTER", 0))) {
									if (!entity::is_entity_dead(
											cutscene::get_entity_index_of_cutscene_entity("LESTER", 0), 0)) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("LESTER", 0), 0, 0);
									}
								}
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0))) {
									if (entity::does_entity_exist(
											cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0))) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0), 0,
											0);
									}
								}
								gameplay::set_bit(&iLocal_41, 4);
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 5)) {
							if (gameplay::get_game_timer() - iLocal_44 > 73900) {
								if (entity::does_entity_exist(uLocal_49[0])) {
									entity::set_entity_visible(uLocal_49[0], 0, 0);
								}
								gameplay::set_bit(&iLocal_41, 5);
							}
						}
						if (cutscene::can_set_exit_state_for_registered_entity("MICHAEL", joaat("player_zero"))) {
							if (!entity::is_entity_dead(uLocal_49[0], 0)) {
								ped::set_ped_config_flag(uLocal_49[0], 208, 1);
								ped::set_ped_config_flag(uLocal_49[0], 118, 0);
								ped::set_ped_config_flag(uLocal_49[0], 213, 0);
								ped::set_blocking_of_non_temporary_events(uLocal_49[0], 1);
							}
							if (func_93() != 0) {
								func_249(&uLocal_49, 0);
								func_188(&uLocal_49, 0, 0, 0);
								streaming::set_model_as_no_longer_needed(joaat("player_zero"));
								func_292(&Local_95.f_484, 0, player::player_ped_id(), "MICHAEL", 1, 1);
							}
							if (!gameplay::is_bit_set(iLocal_41, 1)) {
								func_276();
								gameplay::set_bit(&iLocal_41, 1);
							}
							func_107(6, 0);
						}
						if (cutscene::can_set_exit_state_for_camera(0)) {
							func_274(1);
							if (!gameplay::is_bit_set(iLocal_41, 4)) {
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0))) {
									if (!entity::is_entity_dead(
											cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0), 0)) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("FRANKLIN", 0), 0, 0);
									}
								}
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("LESTER", 0))) {
									if (!entity::is_entity_dead(
											cutscene::get_entity_index_of_cutscene_entity("LESTER", 0), 0)) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("LESTER", 0), 0, 0);
									}
								}
								if (entity::does_entity_exist(
										cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0))) {
									if (entity::does_entity_exist(
											cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0))) {
										entity::set_entity_visible(
											cutscene::get_entity_index_of_cutscene_entity("WALKINGSTICK_LESTER", 0), 0,
											0);
									}
								}
								gameplay::set_bit(&iLocal_41, 4);
							}
							if (!gameplay::is_bit_set(iLocal_41, 5)) {
								if (entity::does_entity_exist(uLocal_49[0])) {
									entity::set_entity_visible(uLocal_49[0], 0, 0);
								}
								gameplay::set_bit(&iLocal_41, 5);
							}
						}
					}
				}
			}
		}
		else {
			if (func_142(0)) {
				if (func_295(&iLocal_42, 0, 0, 0, 0) == 1) {
					gameplay::set_bit(&iLocal_41, 2);
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 2)) {
				func_292(&Local_95.f_484, 0, 0, "MICHAEL", 1, 1);
				func_292(&Local_95.f_484, 1, 0, "FRANKLIN", 1, 1);
				func_292(&Local_95.f_484, 3, 0, "LESTER", 1, 1);
				func_276();
				func_107(6, 0);
			}
		}
	}
	else {
		if (cutscene::has_this_cutscene_loaded("AH_2_EXT_ALT")) {
			cutscene::remove_cutscene();
		}
		if (gameplay::is_bit_set(iLocal_41, 6)) {
			gameplay::clear_bit(&iLocal_41, 6);
		}
	}
}

// Position - 0x1692C
void func_276() {
	func_84(1, 3, 1);
	func_84(2, 3, 1);
	func_297(&Local_95);
	func_68(&Local_95);
}

// Position - 0x1694E
int func_277(int iParam0, int iParam1, int iParam2) {
	var uVar0;
	char *sVar1;

	if (iParam1 == 0) {
		sVar1 = entity::get_entity_script(iParam0, &uVar0);
		if (!gameplay::is_string_null_or_empty(sVar1)) {
			if (gameplay::get_hash_key(sVar1) == gameplay::get_hash_key("vehicle_gen_controller")) {
				return 0;
			}
		}
	}
	func_278(iParam0, iParam2);
	return 1;
}

// Position - 0x1698E
void func_278(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_283(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_279(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x16B90
void func_279(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_282(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_281(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_280(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0x16E3C
int func_280(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0x16EEC
int func_281(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x16FC6
void func_282(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0x17076
int func_283(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_290(iParam0, 0, 0) ||
		func_290(iParam0, 1, 0) || func_290(iParam0, 2, 0) || func_289(iParam0) != 145 || func_288(iParam0) ||
		func_287(iParam0) || func_286(iParam0) || func_285(iParam0) || !func_284(entity::get_entity_model(iParam0))) {
		if (func_287(iParam0)) {
		}
		if (func_287(iParam0)) {
		}
		if (func_290(iParam0, 0, 0)) {
		}
		if (func_290(iParam0, 1, 0)) {
		}
		if (func_290(iParam0, 2, 0)) {
		}
		if (func_289(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x17153
int func_284(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_161(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x17304
int func_285(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_161(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x1734A
int func_286(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x17385
bool func_287(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x17401
int func_288(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x174E9
int func_289(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x1754C
bool func_290(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_291(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x175BD
bool func_291(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x17695
void func_292(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x17730
bool func_293(char *sParam0) {
	bool bVar0;

	bVar0 = cutscene::has_this_cutscene_loaded(sParam0);
	if (!Global_69701) {
		if (!bVar0) {
			Global_69701 = 1;
		}
	}
	return bVar0;
}

// Position - 0x17755
void func_294() { Global_91530 = 1; }

// Position - 0x17762
int func_295(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_233(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_142(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_296(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0x17899
void func_296(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0x178E8
void func_297(var *uParam0) {
	if (func_12(2, *uParam0)) {
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			if (gameplay::is_bit_set(uParam0->f_449, 2)) {
				func_70(uParam0, func_298(*uParam0));
				func_84(2, *uParam0, 0);
			}
			else {
				func_114(uParam0);
				func_84(2, *uParam0, 0);
			}
		}
	}
}

// Position - 0x1793D
int func_298(int iParam0) {
	switch (iParam0) {
	case 0: return func_315(18);

	case 1: return func_315(22);

	case 2: return func_315(40);

	case 3: return func_315(8);

	case 4: return func_315(26);

	default: break;
	}
	return 0;
}

// Position - 0x179AA
void func_299(var *uParam0, float fParam1, float fParam2) {
	float fVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		fVar0 = system::vdist2(uParam0->f_401, entity::get_entity_coords(player::player_ped_id(), 1));
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			func_307(uParam0);
		}
		else if (fVar0 < fParam1 * fParam1 || gameplay::is_bit_set(Global_87833, *uParam0)) {
			if (gameplay::is_bit_set(uParam0->f_449, 0)) {
				if (func_306(uParam0)) {
					if (gameplay::is_bit_set(Global_87833, *uParam0)) {
						if (gameplay::is_bit_set(Global_87835, *uParam0)) {
							func_301(uParam0);
						}
					}
					else {
						func_301(uParam0);
					}
				}
			}
			else {
				func_300(uParam0);
			}
		}
		if (fVar0 > fParam2 * fParam2 && !gameplay::is_bit_set(Global_87833, *uParam0)) {
			if (gameplay::is_bit_set(uParam0->f_449, 0)) {
				if (gameplay::is_bit_set(uParam0->f_449, 1)) {
					func_146(uParam0);
				}
				func_145(uParam0);
			}
		}
	}
}

// Position - 0x17A93
void func_300(var *uParam0) {
	if (!audio::_0x5B50ABB1FE3746F4()) {
		return;
	}
	ui::request_additional_text(&uParam0->f_1.f_272, 5);
	audio::request_script_audio_bank("HEIST_BULLETIN_BOARD", 0, -1);
	if (*uParam0 != 1) {
		streaming::request_model(joaat("prop_ld_planning_pin_01"));
		streaming::request_model(joaat("prop_ld_planning_pin_02"));
		streaming::request_model(joaat("prop_ld_planning_pin_03"));
	}
	uParam0->f_413 = graphics::request_scaleform_movie_instance(&uParam0->f_1.f_268);
	uParam0->f_414 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	gameplay::set_bit(&Global_87832, *uParam0);
	gameplay::set_bit(&uParam0->f_449, 0);
}

// Position - 0x17B11
void func_301(var *uParam0) {
	int iVar0;

	if (!gameplay::is_bit_set(uParam0->f_449, 1)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_96) {
			func_37(uParam0, iVar0);
			iVar0++;
		}
		func_34(uParam0);
		func_33(uParam0);
		func_305(uParam0);
		func_304(uParam0);
		func_302(uParam0);
		gameplay::set_bit(&uParam0->f_449, 1);
	}
}

// Position - 0x17B6E
void func_302(var *uParam0) {
	int iVar0;
	int iVar1;
	float fVar2;
	float fVar3;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_33) {
		if (func_312(*uParam0, uParam0->f_1.f_75[iVar0])) {
			switch (iVar0 % 3) {
			case 0: iVar1 = joaat("prop_ld_planning_pin_01"); break;

			case 1: iVar1 = joaat("prop_ld_planning_pin_02"); break;

			case 2: iVar1 = joaat("prop_ld_planning_pin_03"); break;
			}
			fVar2 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
			fVar3 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
			vVar4 = {func_303(uParam0, &uParam0->f_1.f_34[iVar0 /*2*/])};
			uParam0->f_428[iVar0] = object::create_object(iVar1, vVar4, 1, 1, 0);
			entity::set_entity_rotation(uParam0->f_428[iVar0], fVar2, 0f, uParam0->f_404 + fVar3, 2, 1);
			entity::set_entity_as_mission_entity(uParam0->f_428[iVar0], 1, 0);
			entity::set_entity_invincible(uParam0->f_428[iVar0], 1);
			entity::set_entity_collision(uParam0->f_428[iVar0], 0, 0);
			entity::set_entity_has_gravity(uParam0->f_428[iVar0], 0);
			entity::freeze_entity_position(uParam0->f_428[iVar0], 1);
		}
		iVar0++;
	}
	gameplay::clear_bit(&Global_87835, *uParam0);
}

// Position - 0x17CA3
Vector3 func_303(var *uParam0, var *uParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	vector3 vVar7;

	fVar0 = uParam0->f_1.f_4;
	fVar1 = uParam0->f_1.f_5;
	func_30(uParam0, uParam1, &fVar2, &fVar3);
	fVar4 = fVar0 * (fVar2 - 0.5f);
	fVar5 = -fVar1 * (fVar3 - 0.5f);
	fVar6 = uParam0->f_404;
	vVar7 = {uParam0->f_401};
	vVar7 = {vVar7 + Vector(fVar5, fVar4 * system::cos(90f - fVar6), fVar4 * system::sin(90f - fVar6))};
	return vVar7;
}

// Position - 0x17D21
void func_304(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar1 = *uParam0;
	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_117) {
		iVar2 = uParam0->f_1.f_186[iVar0];
		iVar3 = gameplay::is_bit_set(Global_101700.f_1.f_120[iVar1], iVar2);
		if (uParam0->f_1.f_141[iVar0 /*2*/] == 0 && uParam0->f_1.f_141[iVar0 /*2*/].f_1 == 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar3);
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar3);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_141[iVar0 /*2*/]));
			graphics::_push_scaleform_movie_function_parameter_float(
				system::to_float(uParam0->f_1.f_141[iVar0 /*2*/].f_1));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar0++;
	}
}

// Position - 0x17E01
void func_305(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_push_scaleform_movie_function_parameter_int(2);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_14));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_14.f_1));
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = *uParam0;
	iVar1 = 0;
	iVar2 = 0;
	while (iVar2 < uParam0->f_1.f_209) {
		if (func_312(iVar0, uParam0->f_1.f_248[iVar2])) {
			iVar3 = 0;
			if (func_312(iVar0, uParam0->f_1.f_258[iVar2])) {
				iVar3 = 1;
			}
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
			graphics::_push_scaleform_movie_function_parameter_int(iVar1);
			graphics::_push_scaleform_movie_function_parameter_int(iVar3);
			func_10(&uParam0->f_1.f_211[iVar2 /*4*/]);
			graphics::_pop_scaleform_movie_function_void();
			iVar1++;
		}
		iVar2++;
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_pop_scaleform_movie_function_void();
	if (func_312(*uParam0, uParam0->f_1.f_210)) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	else {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x17F41
bool func_306(var *uParam0) {
	if (!graphics::has_scaleform_movie_loaded(uParam0->f_413)) {
		return false;
	}
	if (!graphics::has_scaleform_movie_loaded(uParam0->f_414)) {
		return false;
	}
	if (!ui::has_additional_text_loaded(5)) {
		return false;
	}
	if (audio::_0x5B50ABB1FE3746F4()) {
		if (!audio::request_script_audio_bank("HEIST_BULLETIN_BOARD", 0, -1)) {
			return false;
		}
	}
	else {
		return false;
	}
	if (*uParam0 != 1) {
		if (!streaming::has_model_loaded(joaat("prop_ld_planning_pin_01")) ||
			!streaming::has_model_loaded(joaat("prop_ld_planning_pin_02")) ||
			!streaming::has_model_loaded(joaat("prop_ld_planning_pin_03"))) {
			return false;
		}
	}
	gameplay::set_bit(&Global_87834, *uParam0);
	return true;
}

// Position - 0x17FDC
void func_307(var *uParam0) {
	float fVar0;
	float fVar1;

	if (func_312(*uParam0, 0)) {
		func_308(uParam0);
		fVar0 = -uParam0->f_1.f_4 * 0.5f;
		fVar1 = uParam0->f_1.f_5 * 0.5f;
		graphics::draw_scaleform_movie_3d(uParam0->f_413,
										  uParam0->f_401 + Vector(fVar1, fVar0 * system::cos(90f - uParam0->f_404),
																  fVar0 * system::sin(90f - uParam0->f_404)),
										  180f, 0f, uParam0->f_404, 1f, 1f, 1f, uParam0->f_1.f_6, uParam0->f_1.f_7, 1f,
										  2);
	}
}

// Position - 0x18066
void func_308(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	float fVar4;
	float fVar5;
	vector3 vVar6;

	if (gameplay::is_bit_set(Global_87832, *uParam0)) {
		gameplay::set_bit(&uParam0->f_449, 16);
		gameplay::set_bit(&uParam0->f_449, 15);
		gameplay::set_bit(&uParam0->f_449, 14);
		gameplay::clear_bit(&Global_87832, *uParam0);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 16)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_117) {
			iVar1 = uParam0->f_1.f_186[iVar0];
			iVar2 = func_312(*uParam0, iVar1);
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar2);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
		gameplay::clear_bit(&uParam0->f_449, 16);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 15)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_33) {
			if (func_312(*uParam0, uParam0->f_1.f_75[iVar0])) {
				if (!entity::does_entity_exist(uParam0->f_428[iVar0])) {
					switch (iVar0 % 3) {
					case 0: iVar3 = joaat("prop_ld_planning_pin_01"); break;

					case 1: iVar3 = joaat("prop_ld_planning_pin_02"); break;

					case 2: iVar3 = joaat("prop_ld_planning_pin_03"); break;
					}
					fVar4 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
					fVar5 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
					vVar6 = {func_303(uParam0, &uParam0->f_1.f_34[iVar0 /*2*/])};
					uParam0->f_428[iVar0] = object::create_object(iVar3, vVar6, 1, 1, 0);
					entity::set_entity_rotation(uParam0->f_428[iVar0], fVar4, 0f, uParam0->f_404 + fVar5, 2, 1);
					entity::set_entity_as_mission_entity(uParam0->f_428[iVar0], 1, 0);
					entity::set_entity_invincible(uParam0->f_428[iVar0], 1);
					entity::set_entity_collision(uParam0->f_428[iVar0], 0, 0);
					entity::set_entity_has_gravity(uParam0->f_428[iVar0], 0);
					entity::freeze_entity_position(uParam0->f_428[iVar0], 1);
				}
			}
			else if (!entity::does_entity_exist(uParam0->f_428[iVar0])) {
				object::delete_object(&uParam0->f_428[iVar0]);
			}
			iVar0++;
		}
		gameplay::clear_bit(&uParam0->f_449, 15);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 14)) {
		func_309(uParam0);
		func_34(uParam0);
		func_305(uParam0);
		gameplay::clear_bit(&uParam0->f_449, 14);
	}
}

// Position - 0x182B2
void func_309(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x182D6
bool func_310(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x182E4
bool func_311(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0x18310
bool func_312(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_101700.f_1.f_120[iParam0], iParam1); }

// Position - 0x1832A
void func_313() {
	int iVar0;

	iVar0 = func_93();
	if (func_95(iVar0)) {
		if (!func_233(0)) {
			if (!func_311(69) && !func_311(70)) {
				if (func_314(69) || func_314(70)) {
					if (Global_101700.f_6220.f_227[70] != 1) {
						Global_101700.f_6220.f_227[70] = 1;
						Global_32749[70] = 0;
						Global_32948[70] = 1;
					}
					if (Global_101700.f_6220.f_227[71] != 2) {
						Global_101700.f_6220.f_227[71] = 2;
						Global_32749[71] = 0;
						Global_32948[71] = 1;
					}
					if (Global_101700.f_6220.f_227[73] != 1) {
						Global_101700.f_6220.f_227[73] = 1;
						Global_32749[73] = 0;
						Global_32948[73] = 1;
					}
					if (Global_101700.f_6220.f_227[72] != 0) {
						Global_101700.f_6220.f_227[72] = 0;
						Global_32749[72] = 0;
						Global_32948[72] = 1;
					}
					if (Global_101700.f_6220.f_227[74] != 0) {
						Global_101700.f_6220.f_227[74] = 0;
						Global_32749[74] = 0;
						Global_32948[74] = 1;
					}
				}
			}
		}
	}
}

// Position - 0x18460
int func_314(int iParam0) {
	int iVar0;

	if (iParam0 == 94 || iParam0 == -1) {
		return 0;
	}
	if (Global_85809[iParam0 /*2*/]) {
		return 1;
	}
	iVar0 = 0;
	while (iVar0 < Global_82576) {
		if (Global_82576[iVar0 /*5*/] != -1) {
			if (G_TextMessageConfig.f_109[Global_82576[iVar0 /*5*/] /*4*/] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x184C8
bool func_315(int iParam0) {
	if (iParam0 == 146 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_99.f_58[iParam0];
}

// Position - 0x184F5
void func_316(var *uParam0, int iParam1) {
	vector3 vVar0;
	float fVar3;

	*uParam0 = iParam1;
	vVar0 = {Global_87770[uParam0->f_1.f_1 /*15*/].f_3};
	fVar3 = Global_87770[uParam0->f_1.f_1 /*15*/].f_6;
	uParam0->f_401 = {vVar0};
	uParam0->f_404 = fVar3;
	uParam0->f_405 = {vVar0 + Vector(0f, -uParam0->f_1.f_8 * system::cos(360f - fVar3),
									 -uParam0->f_1.f_8 * system::sin(360f - fVar3))};
	uParam0->f_408 = {-0.85f, 0f, fVar3};
	gameplay::set_bit(&uParam0->f_449, 4);
	uParam0->f_415 = uParam0->f_1.f_96;
	uParam0->f_416 = -1;
	gameplay::clear_bit(&uParam0->f_449, 0);
	gameplay::clear_bit(&uParam0->f_449, 1);
	gameplay::clear_bit(&uParam0->f_449, 2);
	uParam0->f_464 = 0;
	uParam0->f_451 = -1;
}

// Position - 0x185C1
void func_317(var *uParam0, int iParam1) {
	func_327(uParam0, 1, "HEIST_AGENCY", "BOARD5", "AHFAUD", "CRWAUD", 3, 0, 6, 13, iParam1, 708.9957f, -965.256f,
			 31.39533f, 5.5f, 6.25f, 2f);
	func_326(uParam0, 750, 540, 2.1f, 1.47f, 3.6f, 2.05f, 2f, 375, 250, 136, 411, 268, 415, 401, 418, 482, 413, 0, 0,
			 670, 350, 0, 85, 684, 106);
	func_325(uParam0, 20f, 22f, 28f);
	func_324(uParam0, "", "", "", "", "AHP12", "", "AHP13", "AHLONG");
	func_323(uParam0, 1, "CRW_GM", "");
	func_323(uParam0, 3, "CRW_HW", "");
	func_323(uParam0, 4, "CRW_NR", "");
	func_323(uParam0, 5, "CRW_DJ", "");
	func_323(uParam0, 6, "CRW_PH", "");
	func_323(uParam0, 7, "CRW_CF", "");
	func_323(uParam0, 8, "CRW_ET", "");
	func_323(uParam0, 9, "CRW_KD", "");
	func_323(uParam0, 10, "CRW_PM", "CRM_PM");
	func_323(uParam0, 12, "CRW_RL", "CRM_RL");
	func_323(uParam0, 13, "CRW_TM", "CRM_TM");
	func_322(uParam0, 24, "AHRIC1");
	func_322(uParam0, 26, "AHKAR1");
	func_322(uParam0, 18, "AHJH");
	func_322(uParam0, 19, "AHPAL");
	func_322(uParam0, 21, "AHBOTH");
	func_321(uParam0, 3, 0, 0, 0);
	func_321(uParam0, 2, 0, 0, 0);
	func_321(uParam0, 7, 0, 0, 0);
	func_321(uParam0, 8, 0, 0, 0);
	func_321(uParam0, 5, 2, 0, 0);
	func_321(uParam0, 6, 2, 0, 0);
	func_321(uParam0, 4, 2, 0, 0);
	func_321(uParam0, 9, 2, 0, 0);
	func_321(uParam0, 0, 3, 0, 0);
	func_321(uParam0, 1, 3, 0, 0);
	func_320(uParam0, 0, 1, "H_TD_JANI");
	func_320(uParam0, 1, 3, "H_TD_BLUP");
	func_320(uParam0, 2, 4, "H_TD_PLAN");
	func_320(uParam0, 2, 5, "H_TD_CREW");
	func_320(uParam0, 6, 7, "H_TD_FIRE");
	func_320(uParam0, 6, 8, "H_TD_GETA");
	func_319(uParam0, 2, 70, 71);
	func_319(uParam0, 2, 44, 174);
	func_319(uParam0, 2, 45, 209);
	func_319(uParam0, 3, 178, 68);
	func_319(uParam0, 3, 321, 65);
	func_319(uParam0, 2, 538, 52);
	func_319(uParam0, 2, 470, 82);
	func_319(uParam0, 2, 455, 207);
	func_319(uParam0, 2, 566, 207);
	func_319(uParam0, 2, 673, 339);
	func_319(uParam0, 2, 679, 442);
	func_319(uParam0, 2, 689, 63);
	func_318(uParam0, 2, "AHP8", 55, 197, 1);
	func_318(uParam0, 2, "AHP9", 252, 150, 1);
	func_318(uParam0, 2, "AHP10", 70, 97, 1);
	func_318(uParam0, 2, "AHP11", 504, 106, 1);
}

// Position - 0x188D8
void func_318(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	struct<2> Var0;

	if (uParam0->f_369 < 7) {
		StringCopy(&Var0, sParam2, 8);
		uParam0->f_386[uParam0->f_369] = iParam1;
		uParam0->f_371[uParam0->f_369 /*2*/] = iParam3;
		uParam0->f_371[uParam0->f_369 /*2*/].f_1 = iParam4;
		uParam0->f_280[uParam0->f_369 + 4 /*2*/] = {Var0};
		if (iParam5) {
			gameplay::set_bit(&uParam0->f_370, uParam0->f_369);
		}
		uParam0->f_369++;
	}
}

// Position - 0x18951
void func_319(var *uParam0, int iParam1, int iParam2, int iParam3) {
	if (uParam0->f_33 < 20) {
		uParam0->f_75[uParam0->f_33] = iParam1;
		uParam0->f_34[uParam0->f_33 /*2*/] = iParam2;
		uParam0->f_34[uParam0->f_33 /*2*/].f_1 = iParam3;
		uParam0->f_33++;
	}
}

// Position - 0x18995
void func_320(var *uParam0, int iParam1, int iParam2, char *sParam3) {
	struct<8> Var0;

	if (uParam0->f_209 < 9) {
		StringCopy(&Var0, sParam3, 32);
		uParam0->f_248[uParam0->f_209] = iParam1;
		uParam0->f_258[uParam0->f_209] = iParam2;
		MemCopy(&uParam0->f_211[uParam0->f_209 /*4*/], {Var0}, 4);
		uParam0->f_209++;
	}
}

// Position - 0x189E5
void func_321(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (uParam0->f_117 < 22) {
		uParam0->f_118[uParam0->f_117] = iParam1;
		uParam0->f_186[uParam0->f_117] = iParam2;
		uParam0->f_141[uParam0->f_117 /*2*/] = iParam3;
		uParam0->f_141[uParam0->f_117 /*2*/].f_1 = iParam4;
		uParam0->f_117++;
	}
}

// Position - 0x18A35
void func_322(var *uParam0, int iParam1, char *sParam2) {
	struct<2> Var0;

	StringCopy(&Var0, sParam2, 8);
	if (gameplay::are_strings_equal(sParam2, "")) {
		return;
	}
	uParam0->f_304[iParam1 /*2*/] = {Var0};
}

// Position - 0x18A61
void func_323(var *uParam0, int iParam1, char *sParam2, char *sParam3) {
	struct<2> Var0;
	struct<2> Var2;

	StringCopy(&Var0, sParam2, 8);
	StringCopy(&Var2, sParam3, 8);
	uParam0->f_304[iParam1 /*2*/] = {Var0};
	if (!gameplay::are_strings_equal(sParam3, "")) {
		switch (iParam1) {
		case 10: uParam0->f_304[14 /*2*/] = {Var2}; break;

		case 13: uParam0->f_304[16 /*2*/] = {Var2}; break;

		case 12: uParam0->f_304[15 /*2*/] = {Var2}; break;

		case 11: uParam0->f_304[17 /*2*/] = {Var2}; break;

		default: break;
		}
	}
}

// Position - 0x18AFB
void func_324(var *uParam0, char *sParam1, char *sParam2, char *sParam3, char *sParam4, char *sParam5, char *sParam6,
			  char *sParam7, char *sParam8) {
	struct<4> Var0;
	struct<4> Var4;
	struct<4> Var8;
	struct<4> Var12;
	struct<2> Var16;
	struct<2> Var18;
	struct<2> Var20;
	struct<2> Var22;

	StringCopy(&Var0, sParam1, 16);
	StringCopy(&Var4, sParam2, 16);
	StringCopy(&Var8, sParam3, 16);
	StringCopy(&Var12, sParam4, 16);
	StringCopy(&Var16, sParam5, 8);
	StringCopy(&Var18, sParam6, 8);
	StringCopy(&Var20, sParam7, 8);
	StringCopy(&Var22, sParam8, 8);
	uParam0->f_20[0 /*4*/] = {Var0};
	uParam0->f_20[1 /*4*/] = {Var4};
	uParam0->f_108[0 /*4*/] = {Var8};
	uParam0->f_108[1 /*4*/] = {Var12};
	uParam0->f_280[1 /*2*/] = {Var16};
	uParam0->f_280[2 /*2*/] = {Var18};
	uParam0->f_280[0 /*2*/] = {Var20};
	uParam0->f_280[3 /*2*/] = {Var22};
}

// Position - 0x18B9F
void func_325(var *uParam0, float fParam1, float fParam2, float fParam3) {
	uParam0->f_9 = fParam1;
	uParam0->f_10 = fParam2;
	uParam0->f_11 = fParam3;
}

// Position - 0x18BB9
void func_326(var *uParam0, int iParam1, int iParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  float fParam7, int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13,
			  int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, int iParam19, int iParam20,
			  int iParam21, int iParam22, int iParam23, int iParam24, int iParam25) {
	uParam0->f_2 = iParam1;
	uParam0->f_3 = iParam2;
	uParam0->f_4 = fParam3;
	uParam0->f_5 = fParam4;
	uParam0->f_6 = fParam5;
	uParam0->f_7 = fParam6;
	uParam0->f_8 = fParam7;
	uParam0->f_12 = iParam8;
	uParam0->f_12.f_1 = iParam9;
	uParam0->f_97[0 /*2*/] = iParam10;
	uParam0->f_97[0 /*2*/].f_1 = iParam11;
	uParam0->f_97[1 /*2*/] = iParam12;
	uParam0->f_97[1 /*2*/].f_1 = iParam13;
	uParam0->f_97[2 /*2*/] = iParam14;
	uParam0->f_97[2 /*2*/].f_1 = iParam15;
	uParam0->f_97[3 /*2*/] = iParam16;
	uParam0->f_97[3 /*2*/].f_1 = iParam17;
	uParam0->f_97[4 /*2*/] = iParam18;
	uParam0->f_97[4 /*2*/].f_1 = iParam19;
	uParam0->f_16 = iParam20;
	uParam0->f_16.f_1 = iParam21;
	uParam0->f_18 = iParam22;
	uParam0->f_18.f_1 = iParam23;
	uParam0->f_14 = iParam24;
	uParam0->f_14.f_1 = iParam25;
}

// Position - 0x18C87
void func_327(var *uParam0, int iParam1, char *sParam2, char *sParam3, char *sParam4, char *sParam5, int iParam6,
			  int iParam7, int iParam8, int iParam9, var uParam10, vector3 vParam11, vector3 vParam14) {
	uParam0->f_1 = iParam1;
	StringCopy(&uParam0->f_268, sParam2, 16);
	StringCopy(&uParam0->f_272, sParam3, 16);
	StringCopy(&uParam0->f_276, sParam4, 8);
	StringCopy(&uParam0->f_278, sParam5, 8);
	uParam0->f_29 = iParam6;
	uParam0->f_30[0] = iParam8;
	uParam0->f_30[1] = iParam9;
	uParam0->f_210 = iParam7;
	uParam0->f_96 = uParam10;
	uParam0->f_394 = {vParam11};
	uParam0->f_397 = {vParam14};
}

// Position - 0x18CF3
int func_328(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam0;
	}
	return iParam1;
}

// Position - 0x18D09
int func_329(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		return 0;
	}
	gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
	return 1;
}

// Position - 0x18D63
void func_330() {
	while (!func_144(&Local_95)) {
		system::wait(0);
	}
	func_107(6, 0);
	func_107(8, 0);
	func_107(7, 0);
	func_84(1, 3, 0);
	func_84(2, 3, 0);
	ped::remove_scenario_blocking_area(iLocal_93, 0);
	if (iLocal_94 != -1) {
		if (pathfind::does_navmesh_blocking_object_exist(iLocal_94)) {
			pathfind::remove_navmesh_blocking_object(iLocal_94);
		}
	}
	ped::clear_ped_non_creation_area();
	pathfind::set_ped_paths_in_area(Local_95.f_1.f_394 - Local_95.f_1.f_397, Local_95.f_1.f_394 + Local_95.f_1.f_397, 1,
									0);
	player::set_max_wanted_level(5);
	cutscene::remove_cutscene();
	if (iLocal_42 != -1) {
		func_155(&iLocal_42);
	}
	script::terminate_this_thread();
}

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
int iLocal_46 = 0;
int iLocal_47 = 0;
var uLocal_48 = 0;
int iLocal_49 = 0;
var uLocal_50 = 100;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 20;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 20;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 10;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 2;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 8;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 8;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
int iLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 50;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 50;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 50;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 0;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 50;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 0;
var uLocal_430 = 0;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 20;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
int iLocal_490 = 0;
vector3 vLocal_491 = {0f, 0f, 0f};
int iLocal_494 = 0;
int iLocal_495 = 0;
vector3 vLocal_496 = {0f, 0f, 0f};
vector3 vLocal_499 = {0f, 0f, 0f};
vector3 vLocal_502 = {0f, 0f, 0f};
char cLocal_505[16] = "";
var uLocal_507 = 0;
var uLocal_508 = 0;
bool bLocal_509 = 0;
int iLocal_510 = 0;
int iLocal_511 = 0;
float fLocal_512 = 0f;
float fLocal_513 = 0f;
int iLocal_514[32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
var uLocal_547 = 0;
var uLocal_548 = 0;
int iLocal_549[32] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int iLocal_582 = 0;
int iLocal_583 = 0;
int iLocal_584 = 0;
int iLocal_585 = 0;
int *iLocal_586 = NULL;
int iLocal_587 = 0;
int iLocal_588 = 0;
int iLocal_589 = 0;
int iLocal_590 = 0;
int iLocal_591 = 0;
int iLocal_592 = 0;
int iLocal_593 = 0;
int iLocal_594 = 0;
int iLocal_595 = 0;
int iLocal_596 = 0;
int iScriptParam_0 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int *iVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	struct<8> Var7;
	int iVar23;
	bool bVar24;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_39 = 1;
	iLocal_40 = 65;
	iLocal_41 = 49;
	iLocal_42 = 64;
	iLocal_46 = -1;
	iLocal_47 = -1;
	iLocal_49 = -1;
	iLocal_238 = 1;
	vLocal_496 = {0f, -0.7f, 1f};
	vLocal_499 = {0f, -0.8f, 1f};
	fLocal_512 = -1f;
	fLocal_513 = -1f;
	iLocal_585 = 3000;
	iLocal_586 = -1;
	iLocal_592 = -1;
	iLocal_593 = -1;
	func_100();
	if (Global_31552) {
		func_94();
		script::terminate_this_thread();
	}
	if (Global_25192) {
		func_94();
		script::terminate_this_thread();
	}
	iVar0 = 0;
	if (!entity::does_entity_exist(iScriptParam_0)) {
		func_94();
		script::terminate_this_thread();
	}
	iVar1 = interior::get_interior_from_entity(iScriptParam_0);
	if (func_93(entity::get_entity_coords(iScriptParam_0, 1))) {
		func_94();
		script::terminate_this_thread();
	}
	if (func_92(13) || func_92(14)) {
		func_94();
		script::terminate_this_thread();
	}
	iVar2 = 1;
	vLocal_491 = {entity::get_entity_coords(iScriptParam_0, 1)};
	vLocal_491.z++;
	if (cam::get_follow_ped_cam_view_mode() != 4) {
		vLocal_502 = {entity::get_offset_from_entity_in_world_coords(iScriptParam_0, vLocal_496)};
	}
	else {
		vLocal_502 = {entity::get_offset_from_entity_in_world_coords(iScriptParam_0, vLocal_499)};
	}
	if (gameplay::get_ground_z_for_3d_coord(vLocal_502, &fVar3, 0)) {
		vLocal_502.z = fVar3 + 1f;
	}
	system::settimera(0);
	audio::hint_script_audio_bank("ATM", 0, -1);
	while (iVar2) {
		iLocal_585 += system::round(0f + 1000f * system::timestep());
		iVar4 = 0;
		system::settimera(0);
		if (entity::does_entity_exist(iScriptParam_0)) {
			if (object::has_object_been_broken(iScriptParam_0)) {
				func_94();
				script::terminate_this_thread();
			}
		}
		if (Global_69702 && network::network_is_game_in_progress()) {
			if (func_81()) {
				func_94();
				script::terminate_this_thread();
			}
		}
		iVar5 = 1;
		if (entity::does_entity_exist(player::player_ped_id()) && !entity::is_entity_dead(player::player_ped_id(), 0) &&
			!cutscene::is_cutscene_playing() && player::is_player_playing(player::get_player_index())) {
			if (interior::get_interior_from_entity(player::player_ped_id()) == iVar1 &&
				!ped::is_ped_jumping(player::player_ped_id())) {
				if (!func_92(15)) {
					if (!Global_101700.f_19523.f_100) {
						if (!ui::is_help_message_being_displayed()) {
							if (Global_69702) {
								func_80("ATM_1TM_TUT", -1);
							}
							else if (!func_79("ATM_1TM_TUT")) {
								func_76("ATM_1TM_TUT", 2, 0, -1, 10000, 7, 0, 0, 0);
							}
						}
					}
					if (func_75("ATM_1TM_TUT")) {
						Global_101700.f_19523.f_100 = 1;
					}
				}
				if (!ped::is_ped_using_any_scenario(player::player_ped_id()) &&
					!ped::is_ped_ragdoll(player::player_ped_id()) && !func_74(0) &&
					entity::is_entity_at_coord(player::player_ped_id(), vLocal_491, 1f, 1f, 1f, 0, 1, 1) &&
					!ped::is_ped_in_cover(player::player_ped_id(), 0) && !func_73() && !func_72(iScriptParam_0, 0) &&
					!func_71() && entity::get_entity_speed(player::player_ped_id()) < 4f &&
					func_69(player::player_id()) != 171 && !func_68(Global_1633501.f_107548)) {
					if (ai::does_scenario_exist_in_area(vLocal_491, 2f, 0)) {
						iVar5 = 0;
					}
					iVar6 = 0;
					if (ai::is_scenario_occupied(vLocal_491, 2f, 1)) {
						iVar6 = 1;
					}
					if (Global_69702) {
						if (!network::network_is_game_in_progress()) {
							iVar6 = 1;
						}
					}
					if (ui::is_pause_menu_active()) {
						iVar6 = 1;
					}
					if (!iVar6) {
						if (iLocal_586 == -1) {
							func_67(&iLocal_586, 4, "FINH_ATMNEAR", 0, 0, 0, 0);
						}
						iVar4 = 1;
						if (func_66(iLocal_586, 1)) {
							Global_36677 = 1;
							while (!audio::request_script_audio_bank("ATM", 0, -1) && !func_61(iScriptParam_0, 1)) {
								system::wait(0);
							}
							system::wait(100);
							StringCopy(&Var7, "", 64);
							if (!ped::is_ped_injured(player::player_ped_id())) {
								weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
								if (func_60(0, &Var7)) {
									ai::task_go_straight_to_coord(player::player_ped_id(), vLocal_502, 1f, 5000,
																  entity::get_entity_heading(iScriptParam_0), 0.25f);
									iLocal_494 = 0;
								}
							}
							system::wait(100);
							system::wait(100);
							if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
								if (!ped::is_ped_injured(player::player_ped_id())) {
									iLocal_510 = func_59(1, 1, 1, 1);
									iLocal_591 = 1;
									if (Global_69702) {
										iLocal_549[network::participant_id_to_int()] = 1;
										ui::_0xC2D15BEF167E27BC();
										ui::set_multiplayer_bank_cash();
										Global_2502455 = 1;
									}
									iVar0 = 0;
									audio::start_audio_scene("ATM_PLAYER_SCENE");
									func_6(0, &iVar0, iScriptParam_0, iVar5);
									audio::stop_audio_scene("ATM_PLAYER_SCENE");
									if (Global_69702) {
										Global_2502455 = 0;
										ui::_0x95CF81BD06EE1887();
										ui::remove_multiplayer_bank_cash();
									}
									if (!iVar5 || Global_69702) {
										if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
											if (!iVar5) {
												ped::_0xF1C03A5352243A30(player::player_ped_id());
												ai::clear_ped_tasks(player::player_ped_id());
											}
											if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
												if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
													if (ped::is_ped_using_any_scenario(player::player_ped_id())) {
														ped::_0xF1C03A5352243A30(player::player_ped_id());
														if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
															ai::clear_ped_tasks(player::player_ped_id());
														}
													}
													if (func_60(1, &Var7)) {
														streaming::remove_anim_dict(&Var7);
													}
													if (func_60(2, &Var7)) {
														streaming::remove_anim_dict(&Var7);
													}
													if (func_60(3, &Var7)) {
														if (ped::is_synchronized_scene_running(iLocal_495)) {
															ped::detach_synchronized_scene(iLocal_495);
															iLocal_495 = -1;
														}
														iLocal_495 = network::network_create_synchronised_scene(
															vLocal_502, entity::get_entity_rotation(iScriptParam_0, 2),
															2, 0, 0, 1065353216, 0, 1065353216);
														network::network_add_ped_to_synchronised_scene(
															player::player_ped_id(), iLocal_495, &Var7, "exit", 8f, -4f,
															5, 0, 1148846080, 0);
														network::network_start_synchronised_scene(iLocal_495);
														streaming::remove_anim_dict(&Var7);
													}
												}
											}
										}
									}
									iVar23 = 0;
									while (iVar23 < 1000 && !func_61(iScriptParam_0, 1)) {
										iVar23 += system::round(0f + 1000f * system::timestep());
										controls::disable_control_action(2, 200, 1);
										controls::disable_control_action(2, 202, 1);
										controls::disable_control_action(0, 24, 1);
										controls::disable_control_action(0, 24, 1);
										controls::disable_control_action(0, 140, 1);
										controls::disable_control_action(0, 141, 1);
										system::wait(0);
									}
									if (Global_69702) {
										iLocal_549[network::participant_id_to_int()] = 0;
									}
									iLocal_591 = 0;
								}
							}
							func_4(&iLocal_586);
						}
					}
					else {
						func_4(&iLocal_586);
						system::wait(250);
					}
				}
				else {
					func_4(&iLocal_586);
					bVar24 = false;
					if (entity::does_entity_exist(iScriptParam_0)) {
						if (!brain::is_object_within_brain_activation_range(iScriptParam_0)) {
							bVar24 = true;
						}
					}
					else {
						bVar24 = true;
					}
					if (bVar24) {
						iVar2 = 0;
					}
				}
			}
		}
		else {
			iVar2 = 0;
		}
		if (!iVar4) {
			if (iLocal_586 != -1) {
				func_4(&iLocal_586);
			}
		}
		system::wait(0);
	}
	if (bLocal_509) {
		func_1(13, 0);
	}
	func_94();
}

// Position - 0x6B9
void func_1(int iParam0, int iParam1) {
	int iVar0;

	if (func_3(iParam0, iParam1)) {
		iVar0 = func_2();
		Global_2452429[iVar0] = iParam0;
	}
}

// Position - 0x6DC
int func_2() {
	int iVar0;
	int iVar1;

	iVar0 = 9;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (Global_2452429[iVar1] == 0) {
			iVar0 = iVar1;
			iVar1 = 10;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x711
bool func_3(int iParam0, var uParam1) {
	if (Global_1315221) {
		return false;
	}
	if (iParam0 == 22) {
		return true;
	}
	if (uParam1 || !Global_1315233 || iParam0 == 3 || iParam0 == 10 || iParam0 == 11 || iParam0 == 27 ||
		iParam0 == 28 || iParam0 == 29 || iParam0 == 30) {
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x797
void func_4(int *iParam0) {
	int iVar0;

	if (*iParam0 == -1) {
		return;
	}
	iVar0 = func_5(*iParam0);
	if (iVar0 == -1) {
		*iParam0 = -1;
		return;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/].f_7 = 1;
			*iParam0 = -1;
			return;
		}
	}
	*iParam0 = -1;
}

// Position - 0x7EE
int func_5(int iParam0) {
	int iVar0;

	if (iParam0 < 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x829
void func_6(int iParam0, int *iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	int iVar2;
	bool bVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	Global_53003 = 1;
	iVar0 = 0;
	iLocal_587 = unk_0x67D02A194A2FC2BD("ATM");
	iLocal_588 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	if (func_58(iParam2)) {
		if (func_57(4)) {
			func_56(4, 0);
			iLocal_590 = 1;
		}
	}
	iVar1 = gameplay::get_game_timer();
	cam::_0xF4F2C0D4EE209E20();
	while (!graphics::has_scaleform_movie_loaded(iLocal_587) && !func_61(iParam2, 1)) {
		system::wait(0);
		func_53();
		func_52(iParam2);
	}
	while (!graphics::has_scaleform_movie_loaded(iLocal_588) && !func_61(iParam2, 1)) {
		system::wait(0);
		func_53();
		func_52(iParam2);
	}
	func_50(0, 0);
	while (gameplay::get_game_timer() - iVar1 < iParam0) {
		system::wait(0);
		func_53();
		func_52(iParam2);
		if (func_49()) {
			return;
		}
	}
	iVar2 = gameplay::get_game_timer() + 3500;
	bVar3 = false;
	iVar4 = 1;
	iVar5 = 0;
	iLocal_594 = 1;
	iLocal_584 = 0;
	while (iVar4) {
		iLocal_584 += system::round(0f + 1000f * system::timestep());
		func_39();
		if (controls::_is_input_disabled(2)) {
			ui::_show_cursor_this_frame();
			controls::disable_control_action(2, 200, 1);
		}
		if (!Global_69702) {
			if (gameplay::get_game_timer() > iVar2) {
				bVar3 = true;
			}
		}
		else if (iVar2 > 0) {
			if (gameplay::get_game_timer() > iVar2) {
				bVar3 = true;
				iVar2 = -1;
			}
		}
		else if (iVar2 == -1) {
			bVar3 = true;
		}
		if (player::is_system_ui_being_displayed() || ui::is_pause_menu_active()) {
			bVar3 = false;
		}
		iVar6 = 0;
		if (func_72(iParam2, 1)) {
			iVar6 = 1;
		}
		if (bVar3) {
			controls::enable_control_action(2, 202, 1);
			controls::enable_control_action(2, 238, 1);
		}
		if (gameplay::get_game_timer() > iVar2) {
			graphics::draw_scaleform_movie_fullscreen(iLocal_588, 255, 255, 255, 255, 0);
			graphics::_screen_draw_position_end();
		}
		switch (*iParam1) {
		case 4:
		case 8: bVar3 = false; break;

		case 11:
		case 10: bVar3 = true; break;
		}
		if (bVar3) {
			if ((controls::is_control_just_pressed(2, 202) || controls::is_control_just_pressed(2, 238) || iVar6) &&
				iVar5) {
				audio::play_sound_frontend(-1, "PIN_BUTTON", "ATM_SOUNDS", 1);
				if (Global_69702) {
					switch (*iParam1) {
					case 0:
						iVar4 = 0;
						iLocal_510 = func_59(0, 1, iLocal_510, 1);
						break;

					case 1:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 2:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 3:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 5:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 6:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 7:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 9:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 10:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;

					case 11:
						iLocal_594 = 1;
						*iParam1 = 0;
						break;
					}
				}
				else {
					iLocal_510 = func_59(0, 1, iLocal_510, 0);
					iVar4 = 0;
				}
			}
		}
		if (!iVar5) {
			if (!Global_69702) {
				graphics::_push_scaleform_movie_function(iLocal_587, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				func_32(iLocal_587);
				graphics::_push_scaleform_movie_function(iLocal_587, "UPDATE_TEXT");
				graphics::_pop_scaleform_movie_function_void();
			}
			iVar5 = 1;
		}
		if (Global_69702) {
			if (iLocal_594) {
				while (iLocal_594) {
					iLocal_594 = 0;
					func_26(iParam2, iLocal_587, iParam1);
				}
			}
		}
		if (Global_69702) {
			func_25(iLocal_587);
		}
		if (bVar3) {
			controls::enable_control_action(2, 201, 1);
			controls::enable_control_action(2, 237, 1);
			if (Global_69702) {
				if (controls::is_control_just_pressed(2, 201) ||
					controls::is_control_just_pressed(2, 237) && !ui::_0x3D9ACB1EB139E702()) {
					func_9(iParam2, iParam1);
				}
			}
			func_8(iLocal_587);
		}
		if (!iVar0 && !Global_69702 && !iParam3) {
			if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
				ai::clear_ped_tasks_immediately(player::player_ped_id());
			}
			ai::task_use_nearest_scenario_to_coord(player::player_ped_id(), vLocal_491, 2f, -1);
			iVar0 = 1;
		}
		func_52(iParam2);
	}
	if (Global_69702) {
		func_7(iLocal_587);
	}
	graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_587);
	graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_588);
	iLocal_587 = 0;
	iLocal_588 = 0;
	Global_53003 = 0;
}

// Position - 0xC28
void func_7(int iParam0) {
	if (iLocal_511) {
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(iParam0, "SHOW_CURSOR");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		iLocal_511 = 0;
		fLocal_512 = -1f;
	}
}

// Position - 0xC58
void func_8(int iParam0) {
	int iVar0;
	int iVar1;
	float fVar2;

	if (player::is_system_ui_being_displayed() || ui::is_pause_menu_active()) {
		return;
	}
	controls::enable_control_action(2, 199, 1);
	controls::enable_control_action(2, 188, 1);
	controls::enable_control_action(2, 187, 1);
	controls::enable_control_action(2, 189, 1);
	controls::enable_control_action(2, 190, 1);
	if (controls::is_control_just_pressed(2, 188)) {
		graphics::_push_scaleform_movie_function(iParam0, "SET_INPUT_EVENT");
		graphics::_push_scaleform_movie_function_parameter_int(8);
		graphics::_pop_scaleform_movie_function_void();
	}
	if (controls::is_control_just_pressed(2, 187)) {
		graphics::_push_scaleform_movie_function(iParam0, "SET_INPUT_EVENT");
		graphics::_push_scaleform_movie_function_parameter_int(9);
		graphics::_pop_scaleform_movie_function_void();
	}
	if (controls::is_control_just_pressed(2, 189)) {
		graphics::_push_scaleform_movie_function(iParam0, "SET_INPUT_EVENT");
		graphics::_push_scaleform_movie_function_parameter_int(10);
		graphics::_pop_scaleform_movie_function_void();
	}
	if (controls::is_control_just_pressed(2, 190)) {
		graphics::_push_scaleform_movie_function(iParam0, "SET_INPUT_EVENT");
		graphics::_push_scaleform_movie_function_parameter_int(11);
		graphics::_pop_scaleform_movie_function_void();
	}
	if (!Global_69702) {
		return;
	}
	if (controls::_is_input_disabled(2)) {
		controls::enable_control_action(2, 241, 1);
		controls::enable_control_action(2, 242, 1);
		fVar2 = 1f + Global_68215 * system::timestep();
		if (controls::is_control_pressed(2, 242) || controls::is_control_pressed(2, 187)) {
			iVar1 = -200;
		}
		if (controls::is_control_pressed(2, 241) || controls::is_control_pressed(2, 188)) {
			iVar1 = 200;
		}
		graphics::_push_scaleform_movie_function(iParam0, "SET_ANALOG_STICK_INPUT");
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(system::to_float(iVar1) * fVar2);
		graphics::_pop_scaleform_movie_function_void();
	}
	else {
		controls::enable_control_action(2, 197, 1);
		controls::enable_control_action(2, 198, 1);
		iVar0 = controls::get_control_value(2, 197) - 128;
		iVar1 = controls::get_control_value(2, 198) - 128;
		if (iVar0 < 10 && iVar0 > -10) {
			iVar0 = 0;
		}
		if (iVar1 < 10 && iVar1 > -10) {
			iVar1 = 0;
		}
		fVar2 = 1f + Global_68215 * system::timestep();
		if (iLocal_595 != iVar0 || iLocal_596 != iVar1) {
			graphics::_push_scaleform_movie_function(iParam0, "SET_ANALOG_STICK_INPUT");
			graphics::_push_scaleform_movie_function_parameter_float(0f);
			graphics::_push_scaleform_movie_function_parameter_float(-system::to_float(iVar0) * fVar2);
			graphics::_push_scaleform_movie_function_parameter_float(-system::to_float(iVar1) * fVar2);
			graphics::_pop_scaleform_movie_function_void();
			iLocal_595 = iVar0;
			iLocal_596 = iVar1;
		}
	}
}

// Position - 0xE54
void func_9(int iParam0, int *iParam1) {
	var uVar0;

	graphics::_push_scaleform_movie_function(iLocal_587, "SET_INPUT_SELECT");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(iLocal_587, "GET_CURRENT_SELECTION");
	uVar0 = graphics::_pop_scaleform_movie_function();
	while (!graphics::_0x768FF8961BA904D6(uVar0) && !func_61(iParam0, 1)) {
		func_39();
	}
	iLocal_593 = graphics::_0x2DE7EFA66B906036(uVar0);
	switch (*iParam1) {
	case 0:
		switch (iLocal_593) {
		case 2: func_24(iParam1, 3); break;

		case 1: func_24(iParam1, 7); break;

		case 3: func_24(iParam1, 1); break;
		}
		return;

	case 1:
		switch (iLocal_593) {
		case 1: func_24(iParam1, 0); break;

		case 2: func_24(iParam1, 6); break;
		}
		return;

	case 2:
		if (func_23()) {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 3); break;

			case 2: func_24(iParam1, 0); break;
			}
		}
		else {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 0); break;
			}
		}
		return;

	case 6:
		if (func_22()) {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 7); break;

			case 2: func_24(iParam1, 0); break;
			}
		}
		else {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 0); break;
			}
		}
		return;

	case 3:
		if (!func_23()) {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 0); break;
			}
		}
		else {
			switch (iLocal_593) {
			case 4:
				func_24(iParam1, 0);
				iLocal_589 = 0;
				break;

			case 8:
				iLocal_589 = 0;
				func_24(iParam1, 1);
				break;

			case 1:
				func_24(iParam1, 5);
				iLocal_589 = func_21(0, 1);
				break;

			case 2:
				func_24(iParam1, 5);
				iLocal_589 = func_21(1, 1);
				break;

			case 3:
				func_24(iParam1, 5);
				iLocal_589 = func_21(2, 1);
				break;

			case 5:
				func_24(iParam1, 5);
				iLocal_589 = func_21(3, 1);
				break;

			case 6:
				func_24(iParam1, 5);
				iLocal_589 = func_21(4, 1);
				break;

			case 7:
				func_24(iParam1, 5);
				iLocal_589 = func_21(5, 1);
				break;
			}
		}
		return;

	case 7:
		if (!func_22()) {
			switch (iLocal_593) {
			case 1: func_24(iParam1, 0); break;
			}
		}
		else {
			switch (iLocal_593) {
			case 4:
				func_24(iParam1, 0);
				iLocal_589 = 0;
				break;

			case 8:
				iLocal_589 = 0;
				func_24(iParam1, 1);
				break;

			case 1:
				func_24(iParam1, 9);
				iLocal_589 = func_21(0, 0);
				break;

			case 2:
				func_24(iParam1, 9);
				iLocal_589 = func_21(1, 0);
				break;

			case 3:
				func_24(iParam1, 9);
				iLocal_589 = func_21(2, 0);
				break;

			case 5:
				func_24(iParam1, 9);
				iLocal_589 = func_21(3, 0);
				break;

			case 6:
				func_24(iParam1, 9);
				iLocal_589 = func_21(4, 0);
				break;

			case 7:
				func_24(iParam1, 9);
				iLocal_589 = func_21(5, 0);
				break;
			}
		}
		return;

	case 5:
		switch (iLocal_593) {
		case 1:
			if (func_20(iParam0, iLocal_589)) {
				func_24(iParam1, 4);
			}
			else {
				func_24(iParam1, 10);
			}
			iLocal_589 = 0;
			break;

		case 2: func_24(iParam1, 0); break;
		}
		return;

	case 9:
		switch (iLocal_593) {
		case 1:
			if (func_10(iParam0, iLocal_589)) {
				func_24(iParam1, 8);
			}
			else {
				func_24(iParam1, 10);
			}
			iLocal_589 = 0;
			break;

		case 2: func_24(iParam1, 0); break;
		}
		return;

	case 10:
		switch (iLocal_593) {
		case 1: func_24(iParam1, 0); break;
		}
		return;

	case 11:
		switch (iLocal_593) {
		case 1: func_24(iParam1, 0); break;
		}
		return;

	default:
	}
}

// Position - 0x1288
bool func_10(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var uVar2;
	int iVar3;

	iVar0 = networkcash::network_get_vc_bank_balance();
	if (iParam1 > iVar0) {
		return false;
	}
	if (func_19()) {
		if (unk_0x613F125BA3BD2EB9()) {
			return false;
		}
		unk3::_0x897433D292B44130(&iVar1, &uVar2);
		if (iVar1 != 8) {
			return false;
		}
		if (unk3::_network_transfer_bank_to_wallet(func_18(joaat("mpply_last_mp_char")), iParam1)) {
			iVar3 = unk3::_0x23789E777D14CE44();
			while (iVar3 == 1 && !func_61(iParam0, 1)) {
				iVar3 = unk3::_0x350AA5EBC03D3BD2();
				func_39();
			}
			if (iVar3 == 3) {
				unk3::_network_shop_cash_transfer_set_telemetry_nonce_seed();
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	iLocal_592 = networkcash::_0xF70EFA14FE091429(iParam1);
	bLocal_509 = true;
	if (Global_69702 && network::network_is_game_in_progress()) {
		func_11(1912, 1, -1);
	}
	return true;
}

// Position - 0x1343
void func_11(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = func_15(iParam0, func_16(iParam2), 0);
	iVar0 += iParam1;
	if (!func_14(iParam0)) {
		func_13(iParam0, iVar0, iParam2, 1, 0);
	}
	else {
		func_12(iParam0, iVar0, iParam2, 1);
	}
}

// Position - 0x1385
void func_12(int iParam0, int iParam1, var uParam2, int iParam3) {
	int iVar0;

	iVar0 = Global_2503826[iParam0 /*3*/][func_16(uParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
	switch (iParam0) {
	case 782: Global_1363219[func_16(uParam2)] = iParam1; break;

	case 783: Global_1363225[func_16(uParam2)] = iParam1; break;

	case 784: Global_1363231[func_16(uParam2)] = iParam1; break;

	case 785: Global_1363237[func_16(uParam2)] = iParam1; break;

	case 772: Global_1363195[func_16(uParam2)] = iParam1; break;

	case 773: Global_1363201[func_16(uParam2)] = iParam1; break;

	case 774: Global_1363207[func_16(uParam2)] = iParam1; break;

	case 775: Global_1363213[func_16(uParam2)] = iParam1; break;

	case 762: Global_1363171[func_16(uParam2)] = iParam1; break;

	case 763: Global_1363177[func_16(uParam2)] = iParam1; break;

	case 764: Global_1363183[func_16(uParam2)] = iParam1; break;

	case 765: Global_1363189[func_16(uParam2)] = iParam1; break;

	case 752: Global_1363243[func_16(uParam2)] = iParam1; break;

	case 753: Global_1363249[func_16(uParam2)] = iParam1; break;

	case 754: Global_1363255[func_16(uParam2)] = iParam1; break;

	case 755: Global_1363261[func_16(uParam2)] = iParam1; break;

	case 1298: Global_1363267[func_16(uParam2)] = iParam1; break;

	case 634: Global_1363273[func_16(uParam2)] = iParam1; break;

	case 1273: Global_1363279[func_16(uParam2)] = iParam1; break;

	case 1870: Global_2524277[0 /*3*/][func_16(uParam2)] = iParam1; break;

	case 2261: Global_2524277[1 /*3*/][func_16(uParam2)] = iParam1; break;

	case 2911: Global_2524277[2 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3040: Global_2524277[3 /*3*/][func_16(uParam2)] = iParam1; break;

	case 5886: Global_2524348[func_16(uParam2)] = iParam1; break;

	case 759: Global_1363285[func_16(uParam2)] = iParam1; break;

	case 760: Global_1363291[func_16(uParam2)] = iParam1; break;

	case 761: Global_1363297[func_16(uParam2)] = iParam1; break;

	case 1231: Global_1363303[func_16(uParam2)] = iParam1; break;

	case 3035: Global_2524311[0 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3036: Global_2524311[1 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3037: Global_2524311[2 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3038: Global_2524311[3 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3039: Global_2524311[4 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3618: Global_2524351[0 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3619: Global_2524351[1 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3620: Global_2524351[2 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3621: Global_2524351[3 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3622: Global_2524351[4 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3623: Global_2524367[0 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3624: Global_2524367[1 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3625: Global_2524367[2 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3626: Global_2524367[3 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3627: Global_2524367[4 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3203: Global_2524311[5 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3209: Global_2524277[4 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3645: Global_2524383[func_16(uParam2)] = iParam1; break;

	case 3646: Global_2524392[func_16(uParam2)] = iParam1; break;

	case 3647: Global_2524386[func_16(uParam2)] = iParam1; break;

	case 3648: Global_2524395[func_16(uParam2)] = iParam1; break;

	case 3649: Global_2524389[func_16(uParam2)] = iParam1; break;

	case 3650: Global_2524398[func_16(uParam2)] = iParam1; break;

	case 3671: Global_2524401[func_16(uParam2)] = iParam1; break;

	case 3211: Global_2524311[6 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3212: Global_2524277[5 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3216: Global_2524311[7 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3214: Global_2524277[6 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3991: Global_2524311[8 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3992: Global_2524277[7 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3994: Global_2524311[9 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3995: Global_2524277[8 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3997: Global_2524311[10 /*3*/][func_16(uParam2)] = iParam1; break;

	case 3998: Global_2524277[9 /*3*/][func_16(uParam2)] = iParam1; break;

	case 4000: Global_2524311[11 /*3*/][func_16(uParam2)] = iParam1; break;

	case 4001: Global_2524277[10 /*3*/][func_16(uParam2)] = iParam1; break;

	default: break;
	}
}

// Position - 0x19E4
void func_13(int iParam0, int iParam1, var uParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam4) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_16(uParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
}

// Position - 0x1A14
int func_14(int iParam0) {
	if (Global_1363152) {
		switch (iParam0) {
		case 782:
		case 783:
		case 784:
		case 785:
		case 772:
		case 773:
		case 774:
		case 775:
		case 762:
		case 763:
		case 764:
		case 765:
		case 752:
		case 753:
		case 754:
		case 755:
		case 1298:
		case 634:
		case 1273:
		case 759:
		case 760:
		case 761:
		case 1231:
		case 1870:
		case 2261:
		case 2911:
		case 3040:
		case 5886:
		case 3035:
		case 3036:
		case 3037:
		case 3038:
		case 3039:
		case 3214:
		case 3216:
		case 3618:
		case 3619:
		case 3620:
		case 3621:
		case 3622:
		case 3623:
		case 3624:
		case 3625:
		case 3626:
		case 3627:
		case 3209:
		case 3203:
		case 3645:
		case 3646:
		case 3647:
		case 3648:
		case 3649:
		case 3650:
		case 3671:
		case 3212:
		case 3211:
		case 3992:
		case 3991:
		case 3995:
		case 3994:
		case 3998:
		case 3997:
		case 4001:
		case 4000: return 1;
		}
	}
	return 0;
}

// Position - 0x1BB2
int func_15(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_16(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x1BE4
int func_16(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_17();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x1C18
var func_17() { return Global_1312735; }

// Position - 0x1C24
int func_18(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x1C42
bool func_19() {
	if (gameplay::is_pc_version()) {
		return true;
	}
	return false;
}

// Position - 0x1C56
bool func_20(int iParam0, int iParam1) {
	var uVar0;
	int iVar1;
	var uVar2;
	int iVar3;

	if (!networkcash::_0x7303E27CC6532080(iParam1, 0, 0, 0, &uVar0, -1)) {
		return false;
	}
	if (func_19()) {
		if (unk_0x613F125BA3BD2EB9()) {
			return false;
		}
		unk3::_0x897433D292B44130(&iVar1, &uVar2);
		if (iVar1 != 8) {
			return false;
		}
		if (unk3::_network_transfer_wallet_to_bank(func_18(joaat("mpply_last_mp_char")), iParam1)) {
			iVar3 = unk3::_0x350AA5EBC03D3BD2();
			while (iVar3 == 1 && !func_61(iParam0, 1)) {
				iVar3 = unk3::_0x350AA5EBC03D3BD2();
				func_39();
			}
			if (iVar3 == 3) {
				unk3::_network_shop_cash_transfer_set_telemetry_nonce_seed();
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	networkcash::_0xE260E0BB9CD995AC(iParam1);
	if (Global_69702 && network::network_is_game_in_progress()) {
		func_11(1912, 1, -1);
	}
	bLocal_509 = true;
	return true;
}

// Position - 0x1D12
int func_21(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	if (iParam1 == 1) {
		iVar0 = networkcash::network_get_vc_wallet_balance(-1);
	}
	else {
		iVar0 = networkcash::network_get_vc_bank_balance();
	}
	if (iVar0 == 0) {
		return 1;
	}
	switch (iParam0) {
	case 0:
		if (50 > iVar0) {
			return iVar0;
		}
		return 50;

	case 1:
		if (500 > iVar0 && iVar0 > 50) {
			return iVar0;
		}
		return 500;

	case 2:
		if (2500 > iVar0 && iVar0 > 500) {
			return iVar0;
		}
		return 2500;

	case 3:
		if (10000 > iVar0 && iVar0 > 2500) {
			return iVar0;
		}
		return 10000;

	case 4:
		if (100000 > iVar0 && iVar0 > 10000) {
			return iVar0;
		}
		return 100000;

	case 5:
		if (10000000 > iVar0 && iVar0 > 100000) {
			return iVar0;
		}
		return 10000000;

	default:
	}
	return 0;
}

// Position - 0x1E19
bool func_22() {
	if (networkcash::network_get_vc_bank_balance() >= func_21(0, 0)) {
		return true;
	}
	return false;
}

// Position - 0x1E33
bool func_23() {
	if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(0, 1)) {
		return true;
	}
	return false;
}

// Position - 0x1E4E
void func_24(var *uParam0, int iParam1) {
	iLocal_594 = 1;
	*uParam0 = iParam1;
}

// Position - 0x1E5F
void func_25(int iParam0) {
	float fVar0;
	float fVar1;

	if (gameplay::is_pc_version()) {
		if (iLocal_511 == 0) {
			if (controls::_is_input_disabled(2)) {
				if (fLocal_512 == -1f) {
					fLocal_512 = controls::get_control_normal(2, 239);
					fLocal_513 = controls::get_control_normal(2, 240);
				}
				else if (fLocal_512 != controls::get_control_normal(2, 239) ||
						 fLocal_513 != controls::get_control_normal(2, 240)) {
					graphics::_push_scaleform_movie_function(iParam0, "SHOW_CURSOR");
					graphics::_push_scaleform_movie_function_parameter_bool(1);
					graphics::_pop_scaleform_movie_function_void();
					iLocal_511 = 1;
				}
			}
			else {
				fLocal_512 = -1f;
			}
		}
		else if (!controls::_is_input_disabled(2) || controls::is_control_just_pressed(2, 188) ||
				 controls::is_control_just_pressed(2, 187) || controls::is_control_just_pressed(2, 189) ||
				 controls::is_control_just_pressed(2, 190) || controls::is_control_just_pressed(2, 201) ||
				 controls::is_control_just_pressed(2, 202)) {
			graphics::_push_scaleform_movie_function(iParam0, "SHOW_CURSOR");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
			fLocal_512 = -1f;
			iLocal_511 = 0;
		}
		if (iLocal_511) {
			fVar0 = controls::get_control_normal(2, 239);
			fVar1 = controls::get_control_normal(2, 240);
			if (fVar0 >= 0f && fVar0 <= 1f && fVar1 >= 0f && fVar1 <= 1f) {
				graphics::_push_scaleform_movie_function(iParam0, "SET_MOUSE_INPUT");
				graphics::_push_scaleform_movie_function_parameter_float(fVar0);
				graphics::_push_scaleform_movie_function_parameter_float(fVar1);
				graphics::_pop_scaleform_movie_function_void();
			}
		}
	}
}

// Position - 0x1FA2
void func_26(int iParam0, int iParam1, int *iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT_EMPTY");
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = 0;
	iVar1 = 0;
	iVar2 = 0;
	switch (*iParam2) {
	case 0:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		func_31("MPATM_SER");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(2);
		func_31("MPATM_DIDM");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MPATM_WITM");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(3);
		func_31("MPATM_LOG");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MENU");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 1:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("MPATM_LOG");
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MPATM_BACK");
		graphics::_pop_scaleform_movie_function_void();
		if (func_29(iParam1) > 13) {
			iVar1 = 1;
			iVar2 = 1;
		}
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_TRANSACTIONS");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 4:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		func_31("MPATM_PEND");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		iVar0 = gameplay::get_game_timer() + 1000;
		while (iVar0 > gameplay::get_game_timer() && !func_61(iParam0, 1)) {
			func_39();
		}
		func_24(iParam2, 11);
		break;

	case 8:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		func_31("MPATM_PEND");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		if (func_28(iParam0)) {
			func_24(iParam2, 11);
		}
		else {
			func_24(iParam2, 10);
		}
		break;

	case 2:
		if (func_23()) {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::begin_text_command_scaleform_string("MPATM_XDOL");
			ui::add_text_component_formatted_integer(networkcash::network_get_vc_bank_balance(), 1);
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MO_YES");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(2);
			func_31("MO_NO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_NODO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 6:
		if (func_22()) {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::begin_text_command_scaleform_string("MPATM_XDOL2");
			ui::add_text_component_formatted_integer(networkcash::network_get_vc_bank_balance(), 1);
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MO_YES");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(2);
			func_31("MO_NO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_NODO2");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 3:
		if (!func_23()) {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_NODO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_DITMT");
			graphics::_pop_scaleform_movie_function_void();
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(0, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(0, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(1, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(1, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(2, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(3);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(2, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(4);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(3, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(5);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(3, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(4, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(6);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(4, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_wallet_balance(-1) >= func_21(5, 1)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(7);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(5, 1), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_CASH_OPTIONS");
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 5:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("MPATM_CONF");
		ui::add_text_component_formatted_integer(iLocal_589, 1);
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MO_YES");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(2);
		func_31("MO_NO");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 7:
		if (!func_22()) {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_NODO2");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_31("MPATM_WITMT");
			graphics::_pop_scaleform_movie_function_void();
			if (networkcash::network_get_vc_bank_balance() >= func_21(0, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(0, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_bank_balance() >= func_21(1, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(1, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_bank_balance() >= func_21(2, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(3);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(2, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(4);
			func_31("MPATM_BACK");
			graphics::_pop_scaleform_movie_function_void();
			if (networkcash::network_get_vc_bank_balance() >= func_21(3, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(5);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(3, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_bank_balance() >= func_21(4, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(6);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(4, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			if (networkcash::network_get_vc_bank_balance() >= func_21(5, 0)) {
				graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(7);
				graphics::begin_text_command_scaleform_string("ESDOLLA");
				ui::add_text_component_formatted_integer(func_21(5, 0), 1);
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_CASH_OPTIONS");
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 9:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("MPATC_CONFW");
		ui::add_text_component_formatted_integer(iLocal_589, 1);
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MO_YES");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(2);
		func_31("MO_NO");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 10:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		func_31("MPATM_ERR");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MPATM_BACK");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 11:
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(0);
		func_31("MPATM_TRANCOM");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("MPATM_BACK");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_MESSAGE");
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	func_50(iVar1, iVar2);
	graphics::_push_scaleform_movie_function(iParam1, "DISPLAY_BALANCE");
	func_27(player::get_player_name(player::get_player_index()));
	graphics::begin_text_command_scaleform_string("MPATM_ACBA");
	graphics::end_text_command_scaleform_string();
	func_27(networkcash::_network_get_bank_balance_string());
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x287D
void func_27(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x288B
bool func_28(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iLocal_592;
	iVar1 = gameplay::get_game_timer() + 1000;
	while (!networkcash::_0xE154B48B68EF72BC(iVar0) && !func_61(iParam0, 1)) {
		func_39();
	}
	while (iVar1 > gameplay::get_game_timer() && !func_61(iParam0, 1)) {
		func_39();
	}
	return networkcash::_0x6FCF8DDEA146C45B(iVar0);
}

// Position - 0x28E3
int func_29(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	iVar0 = 2;
	if (Global_2097152[func_30() /*10758*/].f_10581 > 15) {
		Global_2097152[func_30() /*10758*/].f_10581 = 0;
	}
	iVar1 = Global_2097152[func_30() /*10758*/].f_10581 - 1;
	if (iVar1 < 0) {
		iVar1 = 15;
	}
	iVar2 = 16;
	iVar3 = 0;
	while (iVar2 > 0) {
		if (Global_2097152[func_30() /*10758*/].f_10581.f_1[iVar1] > 0) {
			graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(iVar0);
			iVar3++;
			switch (Global_2097152[func_30() /*10758*/].f_10581.f_115[iVar1]) {
			case 4:
			case 2:
			case 1:
			case 6: graphics::_push_scaleform_movie_function_parameter_int(1); break;

			case 0:
			case 3:
			case 5: graphics::_push_scaleform_movie_function_parameter_int(0); break;
			}
			graphics::_push_scaleform_movie_function_parameter_int(
				Global_2097152[func_30() /*10758*/].f_10581.f_1[iVar1]);
			switch (Global_2097152[func_30() /*10758*/].f_10581.f_115[iVar1]) {
			case 0: func_31("MPATM_PLCHLDR_WDR"); break;

			case 1: func_31("MPATM_PLCHLDR_CAD"); break;

			case 2:
				graphics::begin_text_command_scaleform_string("MPATM_PLCHLDR_CRF");
				ui::add_text_component_substring_player_name(
					&Global_2097152[func_30() /*10758*/].f_10581.f_18[iVar1 /*6*/]);
				graphics::end_text_command_scaleform_string();
				break;

			case 3:
				graphics::begin_text_command_scaleform_string("MPATM_PLCHLDR_CST");
				ui::add_text_component_substring_player_name(
					&Global_2097152[func_30() /*10758*/].f_10581.f_18[iVar1 /*6*/]);
				graphics::end_text_command_scaleform_string();
				break;

			case 4: func_31("MPATM_PLCHLDR_BRT"); break;

			case 5:
				if (Global_2097152[func_30() /*10758*/].f_10581.f_132[iVar1] != 0) {
					iVar4 = Global_2097152[func_30() /*10758*/].f_10581.f_132[iVar1];
					switch (iVar4) {
					case 2129044656: func_31("MONEY_SPENT_CONTACT_SERVICE"); break;

					case -2061062157: func_31("MONEY_SPENT_PROPERTY_UTIL"); break;

					case -632380201: func_31("MONEY_SPENT_JOB_ACTIVITY"); break;

					case 1262307134: func_31("MONEY_SPENT_BETTING"); break;

					case 1238791730: func_31("MONEY_SPENT_STYLE_ENT"); break;

					case 478532527: func_31("MONEY_SPENT_HEALTHCARE"); break;

					case -152954333: func_31("MONEY_SPENT_FROM_DEBUG"); break;

					case -1763470753: func_31("MONEY_SPENT_DROPPED_STOLEN"); break;

					case 1013304474: func_31("MONEY_SPENT_VEH_MAINTENANCE"); break;

					case -1995364556: func_31("MONEY_SPENT_HOLDUPS"); break;

					case -804615011: func_31("MONEY_SPENT_PASSIVEMODE"); break;
					}
				}
				else {
					func_31("MPATM_PLCHLDR_PRCH");
				}
				break;

			case 6:
				if (Global_2097152[func_30() /*10758*/].f_10581.f_132[iVar1] != 0) {
					iVar5 = Global_2097152[func_30() /*10758*/].f_10581.f_132[iVar1];
					switch (iVar5) {
					case 1639475247: func_31("MONEY_EARN_JOBS"); break;

					case -296514299: func_31("MONEY_EARN_SELLING_VEH"); break;

					case -1267463912: func_31("MONEY_EARN_BETTING"); break;

					case -368618205: func_31("MONEY_EARN_GOOD_SPORT"); break;

					case 41126866: func_31("MONEY_EARN_PICKED_UP"); break;

					case 414439973: func_31("MONEY_EARN_SHARED"); break;

					case 765901839: func_31("MONEY_EARN_JOBSHARED"); break;

					case -871326891: func_31("MONEY_EARN_ROCKSTAR_AWARD"); break;

					case 645760435: func_31("MONEY_EARN_REFUND"); break;

					case -1392064501: func_31("MONEY_EARN_JOB_BONUS"); break;

					case -1378221995: func_31("MONEY_EARN_HEIST_JOB"); break;
					}
				}
				else {
					func_31("MPATM_PLCHLDR_REF");
				}
				break;
			}
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
		iVar1--;
		if (iVar1 == -1) {
			iVar1 = 15;
		}
		iVar2--;
	}
	return iVar3;
}

// Position - 0x2CA5
int func_30() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x2CB2
void func_31(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x2CC4
void func_32(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	iVar0 = Global_101700.f_27009[func_34() /*29*/].f_17;
	if (iVar0 == 4 || iVar0 == 3) {
		return;
	}
	graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_31("W_BA_LGOF");
	graphics::_pop_scaleform_movie_function_void();
	switch (iVar0) {
	case 0:
		graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("ACCNA_MIKE");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 2:
		graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("ACCNA_TREVOR");
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 1:
		graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_31("ACCNA_FRANKLIN");
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(2);
	func_31("W_BA_ATL");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(3);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(Global_52996[iVar0]));
	func_31("W_BA_BAL");
	graphics::_pop_scaleform_movie_function_void();
	iVar1 = 4;
	iVar2 = 0;
	iVar3 = 0;
	iVar4 = 11;
	iVar4 = Global_101700.f_19523.f_233[iVar0 /*69*/];
	if (iVar4 >= 11) {
		iVar4 = 11;
	}
	iVar5 = Global_101700.f_19523.f_233[iVar0 /*69*/].f_1 - 1;
	if (iVar5 > -1) {
		iVar2 = 0;
		while (iVar2 < iVar4) {
			if (iVar5 < 0) {
				iVar5 = 10;
			}
			iVar3 = 0;
			if (Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar5 /*6*/] == 1) {
				iVar3 = 1;
			}
			graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(iVar1);
			graphics::_push_scaleform_movie_function_parameter_int(iVar3);
			graphics::_push_scaleform_movie_function_parameter_int(
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar5 /*6*/].f_2);
			func_31(func_33(Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar5 /*6*/].f_1));
			graphics::_pop_scaleform_movie_function_void();
			iVar5--;
			iVar1++;
			iVar2++;
		}
	}
}

// Position - 0x2E9C
char *func_33(int iParam0) {
	switch (iParam0) {
	case 31: return "ACCNA_SIM";

	case 32: return "ACCNA_LES";

	case 33: return "ACCNA_AMA";

	case 34: return "ACCNA_JIM";

	case 35: return "ACCNA_TRA";

	case 36: return "ACCNA_OSC";

	case 37: return "ACCNA_ABI";

	case 38: return "ACCNA_BUR";

	case 3: return "ACCNA_MIKE";

	case 24: return "ACCNA_DRFR";

	case 25: return "ACCNA_STRP";

	case 39: return "ACCNA_MRSPOKE";

	case 40: return "ACCNA_GOL_CLU";

	case 4: return "ACCNA_CBELL";

	case 5: return "ACCNA_WHIZZ";

	case 6: return "ACCNA_MCHON";

	case 7: return "ACCNA_DSACH";

	case 8: return "ACCNA_LSANH";

	case 9: return "ACCNA_CRAPKI";

	case 10: return "ACCNA_VCLEAN";

	case 11: return "ACCNA_CSUX";

	case 12: return "ACCNA_VBEU";

	case 13: return "ACCNA_ANAT";

	case 14: return "ACCNA_BAHAMA";

	case 15: return "ACCNA_BAR_BY";

	case 16: return "ACCNA_BAR_BI";

	case 17: return "ACCNA_BAR_HI";

	case 18: return "ACCNA_BAR_MO";

	case 19: return "ACCNA_BAR_SH";

	case 20: return "ACCNA_BAR_SI";

	case 21: return "ACCNA_TAXI";

	case 22: return "ACCNA_DTRAF";

	case 23: return "ACCNA_REPO";

	case 26: return "ACCNA_HUNT";

	case 27: return "ACCNA_RANGE";

	case 28: return "ACCNA_RACES";

	case 29: return "ACCNA_EPS_ST";

	case 30: return "ACCNA_EPS_RB";

	case 2: return "ACCNA_BROKERA";

	case 85: return "ACCNA_CARSITE";

	case 86: return "ACCNA_ARMYSITE";

	case 87: return "ACCNA_PLANESITE";

	case 88: return "ACCNA_BOATSITE";

	case 89: return "ACCNA_BIKESITE";

	case 90: return "ACCNA_AUTOSITE";

	case 91: return "ACCNA_LOSSSITE";

	case 95: return "ACCNA_CASHDEP";

	case 94: return "ACCNA_BAILBONDS";

	case 96: return "ACCNA_HOFFSHORE";

	case 97: return "ACCNA_SNACK";

	case 41: return "S_H_01";

	case 42: return "S_H_02";

	case 43: return "S_H_03";

	case 44: return "S_H_04";

	case 45: return "S_H_05";

	case 46: return "S_H_06";

	case 47: return "S_H_07";

	case 48: return "S_CL_01";

	case 49: return "S_CL_02";

	case 50: return "S_CL_03";

	case 51: return "S_CL_04";

	case 52: return "S_CL_05";

	case 53: return "S_CL_06";

	case 54: return "S_CL_07";

	case 55: return "S_CM_01";

	case 56: return "S_CM_03";

	case 57: return "S_CM_04";

	case 58: return "S_CM_05";

	case 59: return "S_CH_01";

	case 60: return "S_CH_02";

	case 61: return "S_CH_03";

	case 62: return "S_CA_01";

	case 63: return "S_T_01";

	case 64: return "S_T_02";

	case 65: return "S_T_03";

	case 66: return "S_T_04";

	case 67: return "S_T_05";

	case 68: return "S_T_06";

	case 69: return "S_G_01";

	case 70: return "S_G_02";

	case 71: return "S_G_03";

	case 72: return "S_G_04";

	case 73: return "S_G_05";

	case 74: return "S_G_06";

	case 75: return "S_G_07";

	case 76: return "S_G_08";

	case 77: return "S_G_09";

	case 78: return "S_G_10";

	case 79: return "S_G_11";

	case 80: return "S_MO_01";

	case 81: return "S_MO_05";

	case 82: return "S_MO_06";

	case 83: return "S_MO_07";

	case 84: return "S_MO_08";

	case 130: return "S_MO_09";

	case 98: return "ACCNA_TOWING";

	case 99: return "ACCNA_TAXI_LOT";

	case 100: return "ACCNA_ARMS";

	case 101: return "ACCNA_SONAR";

	case 102: return "ACCNA_CARMOD";

	case 103: return "ACCNA_VCINEMA";

	case 104: return "ACCNA_DCINEMA";

	case 105: return "ACCNA_MCINEMA";

	case 106: return "ACCNA_GOLF";

	case 107: return "ACCNA_CSCRAP";

	case 108: return "ACCNA_SMOKE";

	case 109: return "ACCNA_TEQUILA";

	case 110: return "ACCNA_PITCHERS";

	case 111: return "ACCNA_HEN";

	case 112: return "ACCNA_HOOKIES";

	case 113: return "ACCNA_MARINA";

	case 114: return "ACCNA_HANGAR";

	case 115: return "ACCNA_HELIPAD";

	case 116: return "ACCNA_GARAGE";

	case 117: return "ACCNA_PD_VB";

	case 118: return "ACCNA_PD_SC";

	case 119: return "ACCNA_PD_DT";

	case 120: return "ACCNA_PD_RH";

	case 121: return "ACCNA_PD_SS";

	case 122: return "ACCNA_PD_PB";

	case 123: return "ACCNA_PD_HW";

	case 124: return "ACCNA_H_RH";

	case 125: return "ACCNA_H_SC";

	case 126: return "ACCNA_H_DT";

	case 127: return "ACCNA_H_SS";

	case 128: return "ACCNA_H_PB";

	case 92: return "ACCNA_CONSIT";

	case 93: return "ACCNA_TRMSITE";

	case 129: return "ACCNA_DYNPROP";
	}
	return "";
}

// Position - 0x36BE
int func_34() {
	func_35();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x36D7
void func_35() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_38(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_37(player::player_ped_id());
			if (func_36(iVar0) && (!func_92(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_36(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x37D4
bool func_36(int iParam0) { return iParam0 < 3; }

// Position - 0x37E0
int func_37(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_38(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x381D
int func_38(int iParam0) {
	if (func_36(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x3847
void func_39() {
	ui::hide_hud_and_radar_this_frame();
	ui::hide_scripted_hud_component_this_frame(19);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	cam::set_gameplay_cam_relative_heading(0f);
	func_53();
	if (Global_69702) {
		ui::show_hud_component_this_frame(4);
		ui::show_hud_component_this_frame(5);
		ui::show_hud_component_this_frame(13);
		ui::show_hud_component_this_frame(3);
	}
	Global_2454745 = 1;
	controls::enable_control_action(2, 199, 1);
	graphics::_set_2d_layer(1);
	graphics::draw_scaleform_movie_fullscreen(iLocal_587, 255, 255, 255, 255, 0);
	func_47();
	func_43();
	func_40();
	system::wait(0);
}

// Position - 0x38B9
void func_40() {
	func_42();
	func_41(4, -1);
	func_41(6, -1);
	func_41(7, -1);
	func_41(3, -1);
	func_41(1, -1);
	func_41(2, -1);
	func_41(11, -1);
	func_41(13, -1);
	func_41(14, -1);
	func_41(16, -1);
}

// Position - 0x3905
void func_41(int iParam0, int iParam1) {
	gameplay::set_bit(&Global_1353070.f_1014, iParam0);
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			Global_1353070.f_170[iParam1] = 1;
		}
		break;
	}
}

// Position - 0x393B
void func_42() { Global_2494199.f_4394 = 0; }

// Position - 0x394B
void func_43() {
	if (Global_14443.f_1 != 1) {
		if (func_74(0)) {
			func_44(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x3973
void func_44(int iParam0) {
	if (Global_14604) {
		func_46(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_45()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x39E3
int func_45() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x3A0A
void func_46(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_74(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x3A7E
void func_47() {
	unk1::_0xEB2D525B57F42B40();
	func_48();
}

// Position - 0x3A8E
void func_48() { Global_17151.f_134 = 1; }

// Position - 0x3A9C
bool func_49() {
	int iVar0;
	int iVar1;

	iVar0 = player::player_ped_id();
	if (entity::is_entity_dead(iVar0, 0)) {
		return true;
	}
	if (iLocal_490 == 0) {
		iLocal_490 = entity::get_entity_health(iVar0);
		return false;
	}
	iVar1 = entity::get_entity_health(iVar0);
	if (iLocal_490 != iVar1) {
		iLocal_490 = iVar1;
		return true;
	}
	return false;
}

// Position - 0x3AE6
void func_50(int iParam0, int iParam1) {
	int iVar0;

	graphics::_push_scaleform_movie_function(iLocal_588, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(iLocal_588, "SET_CLEAR_SPACE");
	graphics::_push_scaleform_movie_function_parameter_int(200);
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(iLocal_588, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	iVar0 = 0;
	if (Global_69702) {
		graphics::_push_scaleform_movie_function(iLocal_588, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(iVar0);
		func_51(controls::get_control_instructional_button(2, 201, 1));
		func_31("MPATM_SELECT");
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_push_scaleform_movie_function_parameter_int(201);
		}
		graphics::_pop_scaleform_movie_function_void();
		iVar0++;
		if (controls::_is_input_disabled(2)) {
			iParam1 = 0;
		}
		if (iParam0) {
			graphics::_push_scaleform_movie_function(iLocal_588, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(iVar0);
			if (iParam1) {
				func_51(controls::get_control_instructional_button(2, 198, 1));
			}
			else {
				func_51(controls::_0x80C2FD58D720C801(2, 7, 1));
			}
			func_31("MPATM_NAV");
			if (gameplay::is_pc_version()) {
				graphics::_push_scaleform_movie_function_parameter_bool(0);
				graphics::_push_scaleform_movie_function_parameter_int(353);
			}
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
	}
	graphics::_push_scaleform_movie_function(iLocal_588, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(iVar0);
	func_51(controls::get_control_instructional_button(2, 202, 1));
	func_31("MPATM_EXIT");
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_push_scaleform_movie_function_parameter_int(202);
	}
	graphics::_pop_scaleform_movie_function_void();
	iVar0++;
	graphics::_push_scaleform_movie_function(iLocal_588, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x3C31
void func_51(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x3C3F
void func_52(int iParam0) {
	char *sVar0;
	char *sVar16;
	char *sVar32;
	char *sVar48;
	int iVar64;
	int iVar65;
	int iVar66;

	if (!network::network_is_game_in_progress()) {
		return;
	}
	if (ped::is_ped_injured(player::player_ped_id())) {
		return;
	}
	func_60(0, &sVar0);
	func_60(1, &sVar16);
	func_60(2, &sVar32);
	func_60(3, &sVar48);
	streaming::request_anim_dict(&sVar48);
	streaming::request_anim_dict(&sVar0);
	iVar64 = 3;
	if (entity::get_entity_model(player::player_ped_id()) == joaat("mp_f_freemode_01")) {
		iVar64 = 3;
	}
	switch (iLocal_494) {
	case 0:
		graphics::draw_debug_text("walk", entity::get_entity_coords(player::player_ped_id(), 1), 64, 256, 64, 64);
		if (streaming::has_anim_dict_loaded(&sVar0)) {
			if (ai::get_script_task_status(player::player_ped_id(), 2106541073) == 7 &&
				streaming::has_anim_dict_loaded(&sVar0)) {
				if (ped::is_synchronized_scene_running(iLocal_495)) {
					ped::detach_synchronized_scene(iLocal_495);
					iLocal_495 = -1;
				}
				iLocal_495 = network::network_create_synchronised_scene(
					vLocal_502, entity::get_entity_rotation(iParam0, 2), 2, 0, 0, 1065353216, 0, 1065353216);
				network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar0, "enter", 4f,
															   -2f, 5, 0, 1148846080, 0);
				network::network_start_synchronised_scene(iLocal_495);
				streaming::remove_anim_dict(&sVar0);
				iLocal_494 = 1;
			}
		}
		break;

	case 1:
		graphics::draw_debug_text("enter", entity::get_entity_coords(player::player_ped_id(), 1), 64, 256, 64, 64);
		streaming::request_anim_dict(&sVar16);
		streaming::request_anim_dict(&sVar32);
		iVar65 = network::_network_unlink_networked_synchronised_scene(iLocal_495);
		if (streaming::has_anim_dict_loaded(&sVar16) &&
			(!ped::is_synchronized_scene_running(iVar65) || ped::is_synchronized_scene_running(iVar65))) {
			iLocal_495 = network::network_create_synchronised_scene(vLocal_502, entity::get_entity_rotation(iParam0, 2),
																	2, 0, 1, 1065353216, 0, 1065353216);
			network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar16, "base", 4f,
														   -2f, 5, 0, 1148846080, 0);
			network::network_start_synchronised_scene(iLocal_495);
			iLocal_494 = 2;
		}
		break;

	case 2:
		graphics::draw_debug_text("base", entity::get_entity_coords(player::player_ped_id(), 1), 32, 32, 256, 128);
		iVar65 = network::_network_unlink_networked_synchronised_scene(iLocal_495);
		if (!ped::is_synchronized_scene_running(iLocal_495) && !ped::is_synchronized_scene_running(iVar65)) {
			iLocal_495 = network::network_create_synchronised_scene(vLocal_502, entity::get_entity_rotation(iParam0, 2),
																	2, 0, 1, 1065353216, 0, 1065353216);
			iVar65 = network::_network_unlink_networked_synchronised_scene(iLocal_495);
			if (ped::is_synchronized_scene_running(iVar65)) {
				ped::set_synchronized_scene_phase(iVar65, 0f);
			}
			network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar16, "base", 4f,
														   -2f, 5, 0, 1148846080, 0);
			network::network_start_synchronised_scene(iLocal_495);
			iLocal_494 = 2;
			return;
		}
		if (streaming::has_anim_dict_loaded(&sVar32) &&
			(!ped::is_synchronized_scene_running(iVar65) || ped::get_synchronized_scene_phase(iVar65) >= 0.99f)) {
			iVar66 = gameplay::get_random_int_in_range(0, iVar64);
			if (gameplay::are_strings_equal(&cLocal_505, "idle_a") && iVar66 == 0 ||
				gameplay::are_strings_equal(&cLocal_505, "idle_b") && iVar66 == 1 ||
				gameplay::are_strings_equal(&cLocal_505, "idle_c") && iVar66 == 2 ||
				gameplay::are_strings_equal(&cLocal_505, "idle_d") && iVar66 == 3) {
				iVar66++;
				if (iVar66 >= iVar64) {
					iVar66 = 0;
				}
			}
			if (ped::is_synchronized_scene_running(iLocal_495)) {
				ped::detach_synchronized_scene(iLocal_495);
				iLocal_495 = -1;
			}
			iLocal_495 = network::network_create_synchronised_scene(vLocal_502, entity::get_entity_rotation(iParam0, 2),
																	2, 0, 1, 1065353216, 0, 1065353216);
			switch (iVar66) {
			case 0:
				network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar32, "idle_a",
															   4f, -2f, 5, 0, 1148846080, 0);
				network::network_start_synchronised_scene(iLocal_495);
				StringCopy(&cLocal_505, "idle_a", 16);
				iLocal_494 = 3;
				break;

			case 1:
				network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar32, "idle_b",
															   4f, -2f, 5, 0, 1148846080, 0);
				network::network_start_synchronised_scene(iLocal_495);
				StringCopy(&cLocal_505, "idle_b", 16);
				iLocal_494 = 3;
				break;

			case 2:
				network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar32, "idle_c",
															   4f, -2f, 5, 0, 1148846080, 0);
				network::network_start_synchronised_scene(iLocal_495);
				StringCopy(&cLocal_505, "idle_c", 16);
				iLocal_494 = 3;
				break;

			case 3:
				network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar32, "idle_d",
															   4f, -2f, 5, 0, 1148846080, 0);
				network::network_start_synchronised_scene(iLocal_495);
				StringCopy(&cLocal_505, "idle_d", 16);
				iLocal_494 = 3;
				break;

			default: StringCopy(&cLocal_505, "idle_XXX", 16); break;
			}
		}
		break;

	case 3:
		if (entity::is_entity_playing_anim(player::player_ped_id(), &sVar32, "idle_a", 2)) {
			graphics::draw_debug_text("idle_a", entity::get_entity_coords(player::player_ped_id(), 1), 256, 64, 64, 64);
		}
		else if (entity::is_entity_playing_anim(player::player_ped_id(), &sVar32, "idle_b", 2)) {
			graphics::draw_debug_text("idle_b", entity::get_entity_coords(player::player_ped_id(), 1), 256, 64, 64, 64);
		}
		else if (entity::is_entity_playing_anim(player::player_ped_id(), &sVar32, "idle_c", 2)) {
			graphics::draw_debug_text("idle_c", entity::get_entity_coords(player::player_ped_id(), 1), 256, 64, 64, 64);
		}
		else if (entity::is_entity_playing_anim(player::player_ped_id(), &sVar32, "idle_d", 2)) {
			graphics::draw_debug_text("idle_d", entity::get_entity_coords(player::player_ped_id(), 1), 256, 64, 64, 64);
		}
		else {
			graphics::draw_debug_text("idle_XXX", entity::get_entity_coords(player::player_ped_id(), 1), 256, 64, 64,
									  64);
		}
		iVar65 = network::_network_unlink_networked_synchronised_scene(iLocal_495);
		if (!ped::is_synchronized_scene_running(iLocal_495) && !ped::is_synchronized_scene_running(iVar65)) {
			if (ped::is_synchronized_scene_running(iLocal_495)) {
				ped::detach_synchronized_scene(iLocal_495);
				iLocal_495 = -1;
			}
			iLocal_495 = network::network_create_synchronised_scene(vLocal_502, entity::get_entity_rotation(iParam0, 2),
																	2, 0, 1, 1065353216, 0, 1065353216);
			iVar65 = network::_network_unlink_networked_synchronised_scene(iLocal_495);
			if (ped::is_synchronized_scene_running(iVar65)) {
				ped::set_synchronized_scene_phase(iVar65, 0f);
			}
			network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar16, "base", 4f,
														   -2f, 5, 0, 1148846080, 0);
			network::network_start_synchronised_scene(iLocal_495);
			iLocal_494 = 2;
			return;
		}
		if (streaming::has_anim_dict_loaded(&sVar16) &&
			(!ped::is_synchronized_scene_running(iVar65) || ped::get_synchronized_scene_phase(iVar65) >= 0.99f)) {
			if (ped::is_synchronized_scene_running(iLocal_495)) {
				ped::detach_synchronized_scene(iLocal_495);
				iLocal_495 = -1;
			}
			iLocal_495 = network::network_create_synchronised_scene(vLocal_502, entity::get_entity_rotation(iParam0, 2),
																	2, 0, 1, 1065353216, 0, 1065353216);
			network::network_add_ped_to_synchronised_scene(player::player_ped_id(), iLocal_495, &sVar16, "base", 4f,
														   -2f, 5, 0, 1148846080, 0);
			network::network_start_synchronised_scene(iLocal_495);
			iLocal_494 = 2;
			return;
		}
		break;
	}
}

// Position - 0x427F
void func_53() {
	func_54(1);
	if (!player::is_system_ui_being_displayed() && !ui::is_pause_menu_active()) {
		controls::disable_all_control_actions(0);
		controls::disable_control_action(2, 200, 1);
		controls::enable_control_action(2, 188, 1);
		controls::enable_control_action(2, 187, 1);
		controls::enable_control_action(2, 189, 1);
		controls::enable_control_action(2, 190, 1);
		controls::enable_control_action(2, 239, 1);
		controls::enable_control_action(2, 240, 1);
		controls::enable_control_action(2, 237, 1);
	}
}

// Position - 0x42E3
void func_54(int iParam0) {
	if (iParam0) {
		if (func_55()) {
			Global_2443134.f_27 = 1;
		}
	}
	else {
		Global_2443134.f_27 = 0;
	}
}

// Position - 0x4308
bool func_55() { return gameplay::is_bit_set(Global_2443134.f_2, 11); }

// Position - 0x431C
void func_56(int iParam0, int iParam1) {
	if (iParam1) {
		if (!gameplay::is_bit_set(Global_87833, iParam0)) {
			gameplay::set_bit(&Global_87833, iParam0);
		}
	}
	else if (gameplay::is_bit_set(Global_87833, iParam0)) {
		gameplay::clear_bit(&Global_87833, iParam0);
	}
}

// Position - 0x435B
bool func_57(int iParam0) { return gameplay::is_bit_set(Global_87834, iParam0); }

// Position - 0x436D
bool func_58(int iParam0) {
	var uVar0;

	uVar0 = entity::is_entity_at_coord(iParam0, 130.1504f, -1291.626f, 28.2714f, 0.01f, 0.01f, 0.01f, 0, 1, 0);
	return uVar0;
}

// Position - 0x43A0
int func_59(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && iParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0x43D3
bool func_60(int iParam0, char *sParam1) {
	int iVar0;

	if (!network::network_is_game_in_progress()) {
		StringCopy(sParam1, "", 64);
		return false;
	}
	if (func_81()) {
		return false;
	}
	iVar0 = entity::get_entity_model(player::player_ped_id());
	if (iVar0 == joaat("mp_m_freemode_01")) {
		switch (iParam0) {
		case 0:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@male@enter", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "mini@atmenter", 64);
			}
			return true;

		case 1:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@male@base", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "mini@atmbase", 64);
			}
			return true;

		case 2:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@male@idle_a", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "anim@amb@prop_human_atm@interior@male@idle_a", 64);
			}
			return true;

		case 3:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@male@exit", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "mini@atmexit", 64);
			}
			return true;
		}
	}
	else if (iVar0 == joaat("mp_f_freemode_01")) {
		switch (iParam0) {
		case 0:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@enter", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@enter", 64);
			}
			return true;

		case 1:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@base", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@base", 64);
			}
			return true;

		case 2:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@idle_a", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@idle_a", 64);
			}
			return true;

		case 3:
			StringCopy(sParam1, "anim@amb@prop_human_atm@interior@female@exit", 64);
			if (!streaming::does_anim_dict_exist(sParam1)) {
				StringCopy(sParam1, "mini@atmexit", 64);
			}
			return true;
		}
	}
	StringCopy(sParam1, "", 64);
	return false;
}

// Position - 0x4568
bool func_61(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (network::network_is_session_active()) {
		if (network::_0xD313DE83394AF134()) {
			return true;
		}
	}
	if (entity::does_entity_exist(iParam0)) {
		if (object::has_object_been_broken(iParam0)) {
			return true;
		}
	}
	if (func_65(0)) {
		return true;
	}
	if (iParam1 && iLocal_584 > 1000) {
		if (!entity::is_entity_at_coord(player::player_ped_id(), vLocal_491, 1.5f, 1.5f, 1.5f, 0, 1, 1)) {
			return true;
		}
	}
	if (ped::is_ped_ragdoll(player::player_ped_id())) {
		return true;
	}
	iVar0 = player::get_player_index();
	if (!player::is_player_playing(iVar0)) {
		return true;
	}
	if (!player::is_player_control_on(iVar0)) {
		return true;
	}
	if (func_49()) {
		return true;
	}
	if (func_64()) {
		return true;
	}
	if (Global_69702 && func_63()) {
		return false;
	}
	if (!Global_69702 && func_62()) {
		return false;
	}
	if (Global_69702 && network::network_is_game_in_progress()) {
		if (func_81()) {
			return true;
		}
		iVar1 = 0;
		while (iVar1 < 32) {
			if (iLocal_549[iVar1] && network::participant_id_to_int() != iVar1) {
				return true;
			}
			iVar1++;
		}
	}
	return false;
}

// Position - 0x4695
var func_62() { return Global_68132; }

// Position - 0x46A1
var func_63() { return Global_1751495; }

// Position - 0x46AD
bool func_64() {
	vector3 vVar0;
	int iVar3;
	var uVar4;
	var uVar7;
	int iVar10;
	int iVar11;

	if (iLocal_583 == 0) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 0)};
		iLocal_583 = worldprobe::start_shape_test_capsule(vVar0, vVar0 - Vector(3f, 0f, 0f), 0.33f, 2,
														  player::player_ped_id(), 4);
		return iLocal_582;
	}
	else {
		iVar3 = 0;
		iVar11 = worldprobe::get_shape_test_result(iLocal_583, &iVar3, &uVar4, &uVar7, &iVar10);
		if (iVar11 == 2) {
			iLocal_582 = 0;
			if (iVar3 != 0) {
				iLocal_583 = 0;
				if (entity::is_entity_a_vehicle(iVar10) && !network::_0x21D04D7BC538C146(iVar10)) {
					iLocal_582 = 1;
				}
			}
			return iLocal_582;
		}
		else {
			if (iVar11 == 0) {
				iLocal_583 = 0;
			}
			return iLocal_582;
		}
	}
	return false;
}

// Position - 0x474B
bool func_65(int iParam0) {
	if (iParam0) {
		return Global_17151.f_4 && Global_17151.f_104 == 4;
	}
	return Global_17151.f_4;
}

// Position - 0x4774
bool func_66(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_5(iParam0);
	if (iVar0 == -1) {
		return false;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return false;
	}
	if (func_74(0)) {
		return false;
	}
	if (cutscene::is_cutscene_playing()) {
		return false;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/] == 1 && Global_36484[iVar0 /*32*/].f_4 == 1) {
			if (iParam1) {
				if (Global_36484[iVar0 /*32*/].f_29) {
					return false;
				}
			}
			Global_36484[iVar0 /*32*/].f_5 = 1;
			Global_36484[iVar0 /*32*/].f_29 = 1;
			return true;
		}
		else {
			if (Global_36484[iVar0 /*32*/] == 0) {
			}
			if (Global_36484[iVar0 /*32*/].f_7) {
			}
		}
	}
	return false;
}

// Position - 0x482C
void func_67(int iParam0, int iParam1, char *sParam2, int iParam3, char *sParam4, int iParam5, int iParam6) {
	int iVar0;

	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("context_controller")) < 1) {
	}
	if (streaming::is_player_switch_in_progress()) {
		if (*iParam0 != -1) {
			func_4(iParam0);
		}
		return;
	}
	if (*iParam0 != -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (!Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/] = 1;
			Global_36484[iVar0 /*32*/].f_1 = Global_36685;
			Global_36685++;
			Global_36484[iVar0 /*32*/].f_4 = 0;
			Global_36484[iVar0 /*32*/].f_29 = 0;
			Global_36484[iVar0 /*32*/].f_5 = 0;
			Global_36484[iVar0 /*32*/].f_2 = iParam1;
			StringCopy(&Global_36484[iVar0 /*32*/].f_8, sParam2, 16);
			Global_36484[iVar0 /*32*/].f_6 = iParam3;
			Global_36484[iVar0 /*32*/].f_31 = script::get_id_of_this_thread();
			Global_36484[iVar0 /*32*/].f_7 = 0;
			Global_36484[iVar0 /*32*/].f_3 = iParam5;
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				Global_36484[iVar0 /*32*/].f_12 = 1;
				StringCopy(&Global_36484[iVar0 /*32*/].f_13, sParam4, 64);
				Global_36484[iVar0 /*32*/].f_30 = iParam6;
			}
			else {
				Global_36484[iVar0 /*32*/].f_12 = 0;
				Global_36484[iVar0 /*32*/].f_30 = 0;
			}
			*iParam0 = Global_36484[iVar0 /*32*/].f_1;
			return;
		}
		iVar0++;
	}
}

// Position - 0x4957
bool func_68(int iParam0) { return iParam0 == 13; }

// Position - 0x4964
int func_69(int iParam0) {
	if (func_70(iParam0, 0)) {
		return Global_1619421[iParam0 /*390*/].f_11.f_32;
	}
	return -1;
}

// Position - 0x4987
bool func_70(int iParam0, int iParam1) {
	if (Global_1619421[iParam0 /*390*/].f_11.f_32 != -1 || iParam1 && Global_1619421[iParam0 /*390*/].f_11.f_31 != -1) {
		return true;
	}
	return false;
}

// Position - 0x49C2
int func_71() {
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_using(player::player_ped_id()), -1, 0) ==
			player::player_ped_id()) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x49F0
bool func_72(int iParam0, int iParam1) {
	if (iLocal_585 < 3000) {
		return true;
	}
	if (func_61(iParam0, iParam1)) {
		iLocal_585 = 0;
		return true;
	}
	return false;
}

// Position - 0x4A19
int func_73() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0x4A33
bool func_74(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x4A8D
bool func_75(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x4AA0
void func_76(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_77(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x4AC1
void func_77(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_78();
	}
}

// Position - 0x4C94
void func_78() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0x4DB4
int func_79(char *sParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x4DEF
void func_80(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x4E06
bool func_81() {
	bool bVar0;
	int *iVar1;

	func_88(&bVar0, &iVar1);
	if (bVar0) {
		return true;
	}
	if (Global_1315210 == 0) {
		if (!network::network_is_game_in_progress()) {
			return true;
		}
	}
	if (func_87()) {
		return true;
	}
	if (Global_2454747) {
		return true;
	}
	if (func_86()) {
		return true;
	}
	if (func_85(157)) {
		if (!func_84()) {
			return true;
		}
	}
	if (func_85(155)) {
		return true;
	}
	if (!network::network_is_signed_online()) {
		return true;
	}
	if (func_82() != 0) {
		if (script::_get_number_of_instances_of_script_with_name_hash(func_82()) == 0) {
			return true;
		}
	}
	return false;
}

// Position - 0x4E9B
int func_82() {
	switch (func_83()) {
	case 0: return joaat("freemode");

	case 2: return joaat("creator");
	}
	return 0;
}

// Position - 0x4ECF
int func_83() { return Global_25190; }

// Position - 0x4EDA
bool func_84() { return Global_2443134.f_577; }

// Position - 0x4EE9
bool func_85(int iParam0) {
	if (script::get_event_exists(1, iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x4F00
bool func_86() { return Global_2452525; }

// Position - 0x4F0C
bool func_87() { return Global_2443134.f_572; }

// Position - 0x4F1B
void func_88(int *iParam0, int *iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < script::get_number_of_events(1)) {
		iVar1 = script::get_event_at_index(1, iVar0);
		if (iVar1 == 171) {
			script::get_event_data(1, iVar0, &iVar2, 2);
			switch (iVar2) {
			case 381: func_89(iVar0); break;

			case 2:
				script::get_event_data(1, iVar0, &vVar4, 3);
				if (vVar4.z == 55) {
					*iParam0 = 1;
				}
				else if (vVar4.z == 32) {
					*iParam1 = 1;
				}
				break;
			}
		}
		iVar0++;
	}
}

// Position - 0x4F9B
void func_89(int iParam0) {
	vector3 vVar0;
	int iVar3;
	int iVar4;
	bool bVar5;

	if (script::get_event_data(1, iParam0, &vVar0, 3)) {
		if (func_91(vVar0.y, 1, 1)) {
			iVar3 = player::get_player_ped(vVar0.y);
			if (entity::does_entity_exist(iVar3)) {
				if (ped::is_ped_in_any_vehicle(iVar3, 0)) {
					iVar4 = ped::get_vehicle_ped_is_in(iVar3, 0);
					if (vehicle::is_vehicle_window_intact(iVar4, vVar0.z) &&
						network::network_get_this_script_is_network_script()) {
						if (func_90(iVar4, &bVar5)) {
							vehicle::remove_vehicle_window(iVar4, vVar0.z);
						}
						if (bVar5) {
							entity::set_vehicle_as_no_longer_needed(&iVar4);
						}
					}
				}
			}
		}
	}
}

// Position - 0x501C
bool func_90(int iParam0, int *iParam1) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_a_mission_entity(iParam0)) {
			if (network::network_get_entity_is_local(iParam0)) {
				if (!vehicle::is_this_model_a_train(entity::get_entity_model(iParam0))) {
					entity::set_entity_as_mission_entity(iParam0, 0, 1);
					*iParam1 = 1;
				}
			}
		}
		if (entity::does_entity_belong_to_this_script(iParam0, 0)) {
			if (network::network_has_control_of_entity(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x507B
bool func_91(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0x50C5
bool func_92(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x50D3
bool func_93(vector3 vParam0) {
	if (vParam0.x == 129.6975f && vParam0.y == -1290.842f && vParam0.z == 28.27142f) {
		return true;
	}
	if (vParam0.x == 130.5791f && vParam0.y == -1292.369f && vParam0.z == 28.27142f) {
		return true;
	}
	return false;
}

// Position - 0x5136
void func_94() {
	if (iLocal_591) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
				if (ped::is_ped_using_any_scenario(player::player_ped_id())) {
					ped::_0xF1C03A5352243A30(player::player_ped_id());
					ai::clear_ped_tasks(player::player_ped_id());
				}
			}
		}
	}
	func_97("ATM_1TM_TUT", 1);
	if (iLocal_586 != -1) {
		func_4(&iLocal_586);
	}
	if (iLocal_587 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_587);
	}
	func_96();
	func_95();
	Global_53003 = 0;
	func_59(0, 1, iLocal_510, 1);
	if (iLocal_590) {
		func_56(4, 1);
		iLocal_590 = 0;
	}
}

// Position - 0x51C4
void func_95() {
	if (Global_68132) {
	}
	Global_68132 = 0;
}

// Position - 0x51D8
void func_96() {
	if (Global_1751495) {
	}
	Global_1751495 = 0;
}

// Position - 0x51EC
void func_97(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_75(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_99(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_98(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_78();
			return;
		}
		iVar0++;
	}
}

// Position - 0x5299
void func_98(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0x5333
void func_99(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0x5443
void func_100() {
	int iVar0;

	if (network::network_is_game_in_progress()) {
		if (!network::_network_set_this_script_marked(32, 0, -1)) {
			func_94();
			script::terminate_this_thread();
		}
		func_102(0, -1, 0);
		network::network_register_host_broadcast_variables(&iLocal_514, 35);
		network::network_register_player_broadcast_variables(&iLocal_549, 33);
		iVar0 = 0;
		while (iVar0 < 32) {
			iLocal_514[iVar0] = -1;
			iVar0++;
		}
		gameplay::set_this_script_can_be_paused(0);
		if (!func_101()) {
			func_94();
			script::terminate_this_thread();
		}
	}
	else if (player::has_force_cleanup_occurred(3)) {
		func_94();
		script::terminate_this_thread();
	}
}

// Position - 0x54C3
int func_101() {
	int iVar0;

	iVar0 = 0;
	while (true) {
		iVar0++;
		if (!network::network_is_game_in_progress()) {
			return 0;
		}
		if (network::_0x5D10B3795F3FC886()) {
			return 1;
		}
		if (func_87()) {
			return 0;
		}
		if (func_85(155)) {
			return 0;
		}
		if (iVar0 >= 3600) {
			return 0;
		}
		system::wait(0);
	}
	return 0;
}

// Position - 0x551C
int func_102(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = network::network_get_script_status();
	while (iVar0 != 2) {
		if (iVar0 == 3 || iVar0 == 4 || iVar0 == 5 || iVar0 == 6) {
			if (!iParam2) {
				func_104();
			}
			else {
				return 0;
			}
		}
		if (!func_103()) {
			if (iParam0 == 0) {
				if (!network::network_is_game_in_progress()) {
					if (!iParam2) {
						func_104();
					}
					else {
						return 0;
					}
				}
				if (func_87()) {
					if (!iParam2) {
						func_104();
					}
					else {
						return 0;
					}
				}
				if (func_85(155)) {
					if (!iParam2) {
						func_104();
					}
					else {
						return 0;
					}
				}
			}
			else if (!network::network_is_in_session()) {
				if (!iParam2) {
					func_104();
				}
				else {
					return 0;
				}
			}
		}
		system::wait(0);
		iVar0 = network::network_get_script_status();
	}
	if (iParam1 > -1) {
		Global_1312500 = iVar0;
	}
	if (iParam0 == 0) {
		if (!network::network_is_game_in_progress()) {
			if (!iParam2) {
				func_104();
			}
			else {
				return 0;
			}
		}
	}
	else if (!network::network_is_in_session()) {
		if (!iParam2) {
			func_104();
		}
		else {
			return 0;
		}
	}
	return 1;
}

// Position - 0x5631
bool func_103() { return Global_1315210; }

// Position - 0x563D
void func_104() { script::terminate_this_thread(); }

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
var uLocal_21 = 0;
var uLocal_22 = 0;
float fLocal_23 = 0f;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
var uLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
int iLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 10;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 2;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 8;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 8;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
float fLocal_90 = 0f;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
float fLocal_94 = 0f;
float fLocal_95 = 0f;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 17;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 17;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 12;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 12;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 12;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 9;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 9;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
int iLocal_212 = 0;
struct<2> Local_213 = {
	0, 0
};
var uLocal_215 = 0;
var uLocal_216 = 0;
struct<2> Local_217 = {
	0, 0
};
var uLocal_219 = 0;
var uLocal_220 = 0;
struct<2> Local_221 = {
	0, 0
};
var uLocal_223 = 0;
var uLocal_224 = 0;
struct<2> Local_225 = {
	0, 0
};
var uLocal_227 = 0;
var uLocal_228 = 0;
struct<2> Local_229 = {
	0, 0
};
var uLocal_231 = 0;
var uLocal_232 = 0;
vector3 vLocal_233 = {0f, 0f, 0f};
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
int iLocal_239 = 0;
int iLocal_240 = 0;
int iLocal_241 = 0;
int iLocal_242 = 0;
int iLocal_243 = 0;
int iLocal_244 = 0;
int iLocal_245 = 0;
struct<5> Local_246 = {
	0, 0, 0, 0, 0
};
int iLocal_251 = 0;
int iLocal_252 = 0;
int iLocal_253 = 0;
bool bLocal_254 = 0;
int iLocal_255 = 0;
int iLocal_256 = 0;
int iLocal_257[20] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int iLocal_278[5] = {0, 0, 0, 0, 0};
var *uLocal_284 = NULL;
var uLocal_285 = 0;
int iLocal_286 = 0;
var uLocal_287 = 0;
int iLocal_288 = 0;
int iLocal_289 = 0;
int *iLocal_290 = NULL;
var uLocal_291 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_23 = 80f;
	fLocal_24 = 140f;
	fLocal_25 = 180f;
	fLocal_28 = 0f;
	fLocal_32 = -0.0375f;
	fLocal_33 = 0.17f;
	iLocal_36 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_90 = 0.05f + 0.275f - 0.01f;
	fLocal_93 = -0.05f;
	fLocal_94 = 0.92f;
	fLocal_95 = 1.94f;
	fLocal_96 = 2.99f;
	fLocal_97 = 3.7f;
	StringCopy(&Local_213, "CELL_37", 16);
	StringCopy(&Local_217, "CELL_249", 16);
	StringCopy(&Local_221, "CELL_206", 16);
	StringCopy(&Local_225, "CELL_212", 16);
	StringCopy(&Local_229, "CELL_213", 16);
	StringCopy(&vLocal_233, "", 24);
	iLocal_240 = 6;
	iLocal_253 = -1;
	iLocal_255 = -1;
	iLocal_256 = -1;
	gameplay::network_set_script_is_safe_for_network_game();
	iLocal_241 = func_231(&uLocal_284, 0);
	if (iLocal_241 > 0) {
	}
	func_230();
	func_229(&iLocal_290);
	if (func_228()) {
		if (func_227()) {
			func_226();
		}
		else {
			func_203(1);
			if (func_202() == 35 || func_202() == 33 || func_202() == 37 || func_202() == 21 || func_202() == 40 ||
				func_202() == 42 || func_202() == 44 || func_202() == 46 || func_202() == 48) {
				func_201();
			}
			func_200();
			if (network::network_is_in_transition() || network::network_is_transition_started() ||
				network::network_is_transition_busy() || network::network_is_transition_matchmaking() ||
				network::_0xC571D0E77D8BBC29()) {
				network::network_bail_transition(6, 0, 0);
			}
			func_199();
			func_198();
			func_200();
		}
	}
	if (!ped::is_ped_injured(player::player_ped_id()) && func_196(player::player_ped_id())) {
		iLocal_245 = 1;
	}
	Global_2443905.f_1.f_2801 = 0;
	func_193();
	iLocal_239 = 0;
	while (true) {
		system::wait(0);
		if (Local_246 == 0) {
			if (func_174()) {
				Local_246 = 1;
			}
		}
		func_170(0);
		iLocal_241 = func_231(&uLocal_284, 0);
		if (Global_14443.f_1 != 9 && Global_14443.f_1 > 3) {
			switch (iLocal_212) {
			case 0: func_165(); break;

			case 2: func_163(); break;

			case 1: func_156(); break;

			case 3: func_4(); break;

			default: break;
			}
			if (Global_14443.f_1 != 8) {
				if (func_3()) {
					func_226();
				}
			}
			else if (func_2(2, Global_14413, 0)) {
			}
		}
		if (func_1()) {
			func_226();
		}
	}
}

// Position - 0x2AF
bool func_1() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 3 || Global_14443.f_1 == 0 || Global_14387 == 1) {
		Global_14430 = 1;
		return true;
	}
	return false;
}

// Position - 0x2F2
bool func_2(int iParam0, int iParam1, int iParam2) {
	if (controls::is_control_just_pressed(iParam0, iParam1) ||
		iParam2 == 1 && controls::is_disabled_control_just_pressed(iParam0, iParam1)) {
		if (gameplay::is_pc_version()) {
			if (gameplay::update_onscreen_keyboard() == 0 ||
				network::_network_is_text_chat_active() && controls::_is_input_disabled(2)) {
				return false;
			}
		}
		if (ui::is_pause_menu_active() || ui::is_warning_message_active()) {
			return false;
		}
		else {
			return true;
		}
	}
	return false;
}

// Position - 0x364
bool func_3() {
	if (Global_2919 == 1 || Global_14443.f_1 < 7) {
		Global_14430 = 1;
		return true;
	}
	return false;
}

// Position - 0x38D
void func_4() {
	if (func_155()) {
		iLocal_242 = 0;
		func_151(0);
		return;
	}
	if (iLocal_251 < 0 || iLocal_251 >= 20) {
		if (Global_14443.f_1 > 3) {
			Global_14443.f_1 = 7;
		}
		func_149();
		func_193();
		iLocal_212 = 0;
		iLocal_242 = 0;
		return;
	}
	if (func_2(2, Global_14413, 0)) {
		iLocal_242 = 0;
		func_149();
		Global_14443.f_1 = 8;
		if (bLocal_254) {
			func_193();
			iLocal_239 = 0;
			iLocal_212 = 0;
		}
		else if (iLocal_255 == iLocal_251 && !Global_262145.f_4845) {
			func_193();
			iLocal_239 = 0;
			iLocal_212 = 0;
		}
		else if (func_148() && !Global_262145.f_4844) {
			func_132();
			iLocal_212 = 1;
		}
		else {
			func_193();
			iLocal_239 = 0;
			iLocal_212 = 0;
		}
		iLocal_256 = -1;
		func_131();
		return;
	}
	func_119();
	if (iLocal_286 == 0) {
		if (func_2(2, Global_14412, 0)) {
			iLocal_286 = 1;
		}
	}
	else if (func_118(2, Global_14412) && !iLocal_242) {
		func_5();
	}
}

// Position - 0x48F
void func_5() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	struct<13> Var8;

	func_149();
	if (func_94(iLocal_257[iLocal_251])) {
		func_93();
		switch (iLocal_257[iLocal_251]) {
		case 7: iVar0 = -1; break;

		case 9: iVar0 = 2; break;

		case 0:
			if (Global_262145.f_8252) {
				iVar0 = 129;
			}
			else {
				iVar0 = 223;
			}
			iVar3 = func_92(223);
			if (iVar3 != -1) {
				iVar1 = func_90(iVar3);
				iVar2 = func_89(Global_262145.f_5068[iVar3 /*21*/][iVar1]);
				if (iVar2 != -1) {
					func_87(&Global_794643.f_4[iVar2 /*88*/]);
					func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
					func_85();
				}
			}
			break;

		case 1:
			if (Global_262145.f_8252) {
				iVar0 = 129;
			}
			else {
				iVar0 = 224;
			}
			iVar3 = func_92(224);
			if (iVar3 != -1) {
				iVar1 = func_90(iVar3);
				iVar2 = func_89(Global_262145.f_5068[iVar3 /*21*/][iVar1]);
				if (iVar2 != -1) {
					func_87(&Global_794643.f_4[iVar2 /*88*/]);
					func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
					func_85();
				}
			}
			break;

		case 3:
			if (Global_262145.f_8252) {
				iVar0 = 129;
			}
			else {
				iVar0 = 202;
			}
			iVar3 = func_92(202);
			if (iVar3 != -1) {
				iVar1 = func_90(iVar3);
				iVar2 = func_89(Global_262145.f_5068[iVar3 /*21*/][iVar1]);
				if (iVar2 != -1) {
					func_87(&Global_794643.f_4[iVar2 /*88*/]);
					func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
					func_85();
				}
			}
			break;

		case 2:
			if (Global_262145.f_8252) {
				iVar0 = 2;
			}
			else {
				iVar0 = 184;
			}
			iVar1 = func_83();
			iVar2 = func_89(func_82(iVar1));
			if (iVar2 != -1) {
				func_87(&Global_794643.f_4[iVar2 /*88*/]);
				func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
				func_85();
			}
			break;

		case 4:
			iVar0 = 2;
			iVar3 = func_81();
			iVar1 = func_90(iVar3);
			iVar2 = func_89(func_80(iVar1, iVar3));
			if (iVar2 != -1 && Global_262145.f_5375[iVar3] == 2) {
				func_87(&Global_794643.f_4[iVar2 /*88*/]);
				func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
				func_85();
				func_79();
			}
			break;

		case 6:
			func_78();
			func_76();
			func_75(0);
			iVar0 = 222;
			break;

		case 10: iVar0 = 1; break;

		case 8:
			iVar0 = func_73();
			func_72();
			func_76();
			func_75(0);
			func_67(func_68());
			break;

		case 11: iVar0 = 0; break;

		case 14: iVar0 = 7; break;

		case 15: iVar0 = 4; break;

		case 13: iVar0 = 10; break;

		case 5:
			iVar3 = func_65();
			if (iVar3 != -1 && func_62(iVar3)) {
				iVar0 = 129;
				iVar1 = func_90(iVar3);
				iVar2 = func_89(func_80(iVar1, iVar3));
				if (iVar2 != -1) {
					func_87(&Global_794643.f_4[iVar2 /*88*/]);
					func_86(Global_794643.f_4[iVar2 /*88*/].f_71);
					func_85();
				}
			}
			else {
				iVar0 = 129;
			}
			break;

		case 12: iVar0 = 156; break;

		case 16: iVar0 = 3; break;

		case 17: iVar0 = 8; break;

		case 18:
			switch (iLocal_278[iLocal_252]) {
			case 0: iVar0 = 15; break;

			case 1: iVar0 = 14; break;

			case 2: iVar0 = 11; break;

			case 3: iVar0 = 13; break;

			case 4: iVar0 = 12; break;
			}
			break;

		case 19: iVar0 = 100; break;
		}
		func_59();
		if (iLocal_257[iLocal_251] == 8 && !Global_262145.f_4845) {
			if (iLocal_256 == 0 && iLocal_244) {
				func_58();
				func_55(0, 32);
			}
			else if (iLocal_256 == 2 || iLocal_256 == 1 && iLocal_244 == 0) {
				func_54();
			}
		}
		else if (iLocal_256 == 0 && iLocal_244) {
			func_58();
			func_55(0, 32);
		}
		if (Global_262145.f_4844 && !func_53()) {
			func_76();
			func_75(0);
		}
		else if (Global_262145.f_4843 == 0 && iLocal_245 == 0) {
			if (iLocal_256 == 1 && iLocal_244 || iLocal_256 == 0 && !iLocal_244) {
				func_76();
				func_75(0);
			}
		}
		if (iVar0 == -1) {
			func_52(12);
		}
		else if (func_228()) {
			func_52(21);
		}
		else {
			func_52(11);
		}
		if (!func_228()) {
			if (player::get_player_wanted_level(player::player_id()) > 0 && func_51() >= func_48(20)) {
				iVar4 = func_48(20);
				iVar5 = 0;
				iVar6 = 0;
				Var8 = {func_47(player::player_id())};
				func_45(-iVar4, 1, 1, 0f);
				if (func_44(1) >= iVar4) {
					func_43(iVar4, &iVar5, &iVar6);
					if (iVar5 > 0) {
						if (func_42()) {
							func_32(-180141073, iVar5, &iVar7, 1, 0, 0);
							Global_2590252[iVar7 /*76*/].f_8.f_3 = {Var8};
						}
						else {
							networkcash::network_spent_buy_wantedlevel(iVar5, &Var8, 1, 0);
						}
					}
					if (iVar6 > 0) {
						if (func_42()) {
							func_32(-180141073, iVar6, &iVar7, 0, 0, 0);
							Global_2590252[iVar7 /*76*/].f_8.f_3 = {Var8};
						}
						else {
							networkcash::network_spent_buy_wantedlevel(iVar6, &Var8, 0, 0);
						}
					}
				}
			}
			func_30();
			func_29();
			func_18(func_19(player::player_id()));
			func_11(player::player_id(), 0, 376832);
			func_10(1, 1);
			Global_1591201[player::player_id() /*602*/].f_95 = 8;
		}
		if (iVar0 == 100) {
			func_9();
		}
		else if (iVar0 == -1) {
			func_8();
		}
		else {
			func_7(iVar0);
		}
		func_6();
		if (func_228()) {
			func_151(0);
			func_226();
		}
	}
	iLocal_286 = 0;
}

// Position - 0xA97
void func_6() { Global_2450895.f_1 = 0; }

// Position - 0xAA6
void func_7(int iParam0) { Global_2443134.f_5 = iParam0; }

// Position - 0xAB6
void func_8() { Global_2443134.f_5 = -1; }

// Position - 0xAC5
void func_9() { Global_2443134.f_5 = 100; }

// Position - 0xAD5
void func_10(int iParam0, int iParam1) {
	if (iParam0) {
		if (Global_2443905.f_2842.f_84 == 0) {
			if (!dlc2::get_is_loading_screen_active()) {
				if (iParam1) {
					Global_2443905.f_2842.f_152 = 1;
					Global_2443905.f_2842.f_84 = 1;
				}
			}
		}
	}
	else if (Global_2443905.f_2842.f_84 == 1 || Global_2443905.f_2842.f_84 == 2) {
		Global_2443905.f_2842.f_84 = 3;
	}
}

// Position - 0xB3F
void func_11(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	bool bVar3;
	bool bVar4;
	bool bVar5;
	bool bVar6;
	bool bVar7;
	bool bVar8;
	bool bVar9;
	bool bVar10;
	bool bVar11;
	bool bVar12;
	bool bVar13;
	bool bVar14;
	int iVar15;
	int iVar16;
	bool bVar17;
	bool bVar18;
	bool bVar19;
	bool bVar20;
	bool bVar21;
	bool bVar22;
	bool bVar23;
	bool bVar24;
	int iVar25;
	int iVar26;

	if (iParam1) {
		if (script::_get_no_loading_screen()) {
			script::set_no_loading_screen(0);
		}
	}
	if (!network::network_is_game_in_progress()) {
		iVar0 = iParam2;
		player::set_player_control(iParam0, iParam1, iVar0);
	}
	else {
		bVar1 = (iParam2 & 2) != false;
		bVar2 = (iParam2 & 4) != false;
		bVar3 = (iParam2 & 8) != false;
		bVar4 = (iParam2 & 16) != false;
		bVar5 = (iParam2 & 32) != false;
		bVar6 = (iParam2 & 64) != false;
		bVar7 = (iParam2 & 128) != false;
		bVar8 = (iParam2 & 256) != false;
		bVar9 = (iParam2 & 512) != false;
		bVar10 = (iParam2 & 1024) != false;
		bVar11 = (iParam2 & 2048) != false;
		bVar12 = (iParam2 & 4096) != false;
		bVar13 = (iParam2 & 8192) != false;
		bVar14 = (iParam2 & 16384) != false;
		iVar15 = (iParam2 & 32768) != 0;
		iVar16 = (iParam2 & 65536) != 0;
		bVar17 = (iParam2 & 131072) != false;
		bVar18 = (iParam2 & 262144) != false;
		bVar19 = (iParam2 & 524288) != false;
		bVar20 = (iParam2 & 1048576) != false;
		bVar21 = (iParam2 & 2097152) != false;
		bVar22 = (iParam2 & 4194304) != false;
		bVar23 = (iParam2 & 8388608) != false;
		if (!func_16()) {
			bVar24 = false;
			if (iParam1 == 1) {
				bVar24 = true;
			}
			if (iVar15 == 0 && !bVar20) {
				bVar24 = true;
			}
			if (bVar9 == 1) {
				bVar24 = true;
			}
			if (bVar24) {
				return;
			}
		}
		if (bVar17) {
		}
		if (network::network_is_player_active(iParam0) && player::is_player_playing(iParam0)) {
			iVar25 = player::get_player_ped(iParam0);
			if (!bVar19) {
				if (bVar18 && iParam1 == 0 && network::network_is_game_in_progress()) {
					network::fade_out_local_player(1);
				}
				else {
					entity::set_entity_visible(iVar25, !bVar13, 0);
				}
				if (!bVar13) {
					if (network::network_is_game_in_progress() && !bVar18) {
						network::fade_out_local_player(0);
					}
					Global_2421664[iParam0 /*358*/].f_247 = 0;
				}
			}
			if (iParam1) {
				if (!func_15(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, 1, 0);
					}
				}
				if (!entity::is_entity_attached(iVar25)) {
					if (!bVar20) {
						entity::freeze_entity_position(iVar25, 0);
					}
					entity::_set_entity_register(iVar25, 1);
				}
				else if (!bVar20) {
					entity::freeze_entity_position(iVar25, 0);
				}
				ped::set_ped_can_be_targetted(iVar25, 1);
				player::set_player_invincible(iParam0, 0);
				ped::_0x4668D80430D6C299(iVar25);
				ped::set_ped_can_ragdoll(iVar25, 1);
				func_14();
				func_13();
				if (player::is_player_teleport_active()) {
					if (!bVar22) {
					}
				}
				if (streaming::is_new_load_scene_active()) {
				}
				Global_2421664[iParam0 /*358*/].f_248 = 0;
				if (!bVar23) {
					bVar2 = true;
				}
			}
			else {
				if (!func_15(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, !bVar14, 0);
					}
					if (!entity::is_entity_attached(iVar25)) {
						if (!bVar20) {
							entity::freeze_entity_position(iVar25, iVar15);
						}
						if (!iVar15) {
							entity::_set_entity_register(iVar25, 1);
						}
					}
					if (func_12(Global_1633501.f_107548)) {
						entity::freeze_entity_position(iVar25, 1);
					}
				}
				if (bVar9) {
					player::set_player_invincible(iParam0, 0);
				}
				else {
					player::set_player_invincible(iParam0, 1);
				}
				ped::set_ped_can_be_targetted(iVar25, iVar16);
				if (bVar2) {
					if (!ped::is_ped_fatally_injured(iVar25) && !ped::is_ped_in_any_vehicle(iVar25, 0)) {
						ai::clear_ped_tasks_immediately(iVar25);
					}
				}
			}
			iVar26 = 0;
			if (bVar1) {
				iVar26 |= 2;
			}
			if (bVar2) {
				iVar26 |= 4;
			}
			if (bVar3) {
				iVar26 |= 8;
			}
			if (bVar4) {
				iVar26 |= 16;
			}
			if (bVar5) {
				iVar26 |= 32;
			}
			if (bVar6) {
				iVar26 |= 64;
			}
			if (bVar7) {
				iVar26 |= 128;
			}
			if (bVar8) {
				iVar26 |= 256;
			}
			if (bVar9) {
				iVar26 |= 512;
			}
			if (bVar10) {
				iVar26 |= 1024;
			}
			if (bVar11) {
				iVar26 |= 2048;
			}
			if (bVar12) {
				iVar26 |= 4096;
			}
			player::set_player_control(iParam0, iParam1, iVar26);
		}
	}
}

// Position - 0xEF6
bool func_12(int iParam0) { return iParam0 == 17; }

// Position - 0xF03
void func_13() {
	struct<2> Var0;

	Global_2433125.f_731 = 0;
	Global_2433125.f_732 = 0;
	Global_2433125.f_733 = {9999.9f, 9999.9f, 9999.9f};
	Global_2404994.f_2220 = {Var0};
}

// Position - 0xF40
void func_14() {
	Global_2404994.f_644 = 0;
	Global_2404994.f_2261 = 0;
	Global_2404994.f_501 = 0;
	Global_2404994.f_576 = 0;
	Global_2421664[player::player_id() /*358*/].f_210 = 0;
}

// Position - 0xF76
int func_15(int iParam0) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iParam0, 1)) {
		return 1;
	}
	else {
		iVar0 = ai::get_script_task_status(iParam0, -1794415470);
		if (iVar0 == 0) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xFA7
int func_16() {
	if (func_17() == 0) {
		return 1;
	}
	return 0;
}

// Position - 0xFBC
int func_17() { return Global_1312466.f_18; }

// Position - 0xFCA
void func_18(vector3 vParam0) { Global_2452512 = {vParam0}; }

// Position - 0xFDC
Vector3 func_19(int iParam0) {
	vector3 vVar0;

	if (ui::does_blip_exist(Global_2414713[iParam0])) {
		vVar0 = {ui::get_blip_coords(Global_2414713[iParam0])};
	}
	else if (ui::does_blip_exist(Global_2414713.f_33[iParam0]) && iParam0 != Global_2433125) {
		vVar0 = {ui::get_blip_coords(Global_2414713.f_33[iParam0])};
	}
	if (system::vmag(vVar0) > 0f) {
		return vVar0;
	}
	return func_20(iParam0);
}

// Position - 0x1050
Vector3 func_20(int iParam0) {
	int iVar0;

	if (Global_1591201[iParam0 /*602*/].f_258.f_15 > 0) {
		return func_27(func_28(Global_1591201[player::player_id() /*602*/].f_258.f_15));
	}
	else {
		func_24(func_26(iParam0), &iVar0);
		if (iVar0 > 0) {
			return func_27(func_28(iVar0));
		}
	}
	if (func_21(iParam0)) {
		return Global_1764677.f_21[Global_2421664[iParam0 /*358*/].f_312.f_1 /*3*/];
	}
	return func_26(iParam0);
}

// Position - 0x10D1
bool func_21(int iParam0) {
	if (iParam0 != func_23()) {
		if (func_22(iParam0, 1, 1)) {
			return Global_2421664[iParam0 /*358*/].f_312.f_1 != -1;
		}
	}
	return false;
}

// Position - 0x1101
bool func_22(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0x114B
int func_23() { return -1; }

// Position - 0x1154
void func_24(vector3 vParam0, int *iParam3) {
	int iVar0;
	int iVar1;

	iVar0 = 1;
	iVar1 = 7;
	while (iVar0 <= iVar1) {
		if (func_25(vParam0, iVar0)) {
			*iParam3 = iVar0;
			return;
		}
		iVar0++;
	}
	iVar0 = 34;
	iVar1 = 43;
	while (iVar0 <= iVar1) {
		if (func_25(vParam0, iVar0)) {
			*iParam3 = iVar0;
			return;
		}
		iVar0++;
	}
	iVar0 = 61;
	iVar1 = 65;
	while (iVar0 <= iVar1) {
		if (func_25(vParam0, iVar0)) {
			*iParam3 = iVar0;
			return;
		}
		iVar0++;
	}
	iVar0 = 8;
	if (func_25(vParam0, iVar0)) {
		if (Global_1591201[player::player_id() /*602*/].f_258.f_15 > 0) {
			*iParam3 = Global_1591201[player::player_id() /*602*/].f_258.f_15;
		}
		else if (Global_2404580.f_1 > 0) {
			*iParam3 = Global_2404580.f_1;
		}
		else {
			*iParam3 = iVar0;
		}
		return;
	}
	iVar0 = 17;
	if (func_25(vParam0, iVar0)) {
		if (Global_1591201[player::player_id() /*602*/].f_258.f_15 > 0) {
			*iParam3 = Global_1591201[player::player_id() /*602*/].f_258.f_15;
		}
		else if (Global_2404580.f_1 > 0) {
			*iParam3 = Global_2404580.f_1;
		}
		else {
			*iParam3 = iVar0;
		}
		return;
	}
}

// Position - 0x1293
bool func_25(vector3 vParam0, int iParam3) {
	int iVar0;

	if (iParam3 != 999) {
		if (object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/],
											Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/].f_3,
											Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/],
												Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_3,
												Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/],
												Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_3,
												Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_6, 0, 1)) {
			return true;
		}
	}
	else {
		iVar0 = 1;
		while (iVar0 <= 7) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 34;
		while (iVar0 <= 43) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 61;
		while (iVar0 <= 65) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 73;
		while (iVar0 <= 76) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 77;
		while (iVar0 <= 82) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 83;
		while (iVar0 <= 85) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 87;
		while (iVar0 <= 90) {
			if (func_25(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		if (func_25(vParam0, 8)) {
			return true;
		}
		if (func_25(vParam0, 17)) {
			return true;
		}
	}
	return false;
}

// Position - 0x14D5
Vector3 func_26(int iParam0) { return entity::get_entity_coords(player::get_player_ped(iParam0), 0); }

// Position - 0x14E8
Vector3 func_27(int iParam0) {
	vector3 vVar0;

	switch (iParam0) {
	case 1: vVar0 = {-773.4775f, 310.6321f, 84.6981f}; break;

	case 2: vVar0 = {-252.5713f, -949.9199f, 30.221f}; break;

	case 3: vVar0 = {-1443.094f, -544.7684f, 33.7424f}; break;

	case 4: vVar0 = {-913.85f, -455.1392f, 38.5999f}; break;

	case 5: vVar0 = {-47.3145f, -585.9766f, 36.9593f}; break;

	case 6: vVar0 = {-932.7474f, -383.9246f, 37.9613f}; break;

	case 7: vVar0 = {-619.1315f, 37.8841f, 42.5883f}; break;

	case 8: vVar0 = {284.9614f, -159.9891f, 63.6221f}; break;

	case 9: vVar0 = {2.8889f, 35.7762f, 70.5349f}; break;

	case 10: vVar0 = {9.74f, 84.6906f, 77.3975f}; break;

	case 11: vVar0 = {-512.1465f, 111.2223f, 62.351f}; break;

	case 12: vVar0 = {-197.3405f, 88.1053f, 68.7422f}; break;

	case 13: vVar0 = {-628.3212f, 165.8364f, 60.1651f}; break;

	case 14: vVar0 = {-973.3757f, -1429.425f, 6.6791f}; break;

	case 15: vVar0 = {-829.1362f, -855.0104f, 18.6297f}; break;

	case 16: vVar0 = {-757.5739f, -755.5591f, 25.5697f}; break;

	case 17: vVar0 = {-45.1289f, -57.0925f, 62.2531f}; break;

	case 18: vVar0 = {-206.7293f, 184.142f, 79.3279f}; break;

	case 19: vVar0 = {-811.7045f, -984.1961f, 13.1538f}; break;

	case 20: vVar0 = {-664.0032f, -853.6744f, 23.4325f}; break;

	case 21: vVar0 = {-1534.025f, -324.5247f, 46.5237f}; break;

	case 22: vVar0 = {-1561.381f, -412.1974f, 41.389f}; break;

	case 23: vVar0 = {-1608.851f, -429.184f, 39.439f}; break;

	case 24: vVar0 = {964.3583f, -1034.199f, 39.8303f}; break;

	case 25: vVar0 = {894.2868f, -885.5679f, 26.1212f}; break;

	case 26: vVar0 = {821.1741f, -924.1658f, 25.1998f}; break;

	case 27: vVar0 = {759.7933f, -759.8209f, 25.759f}; break;

	case 28: vVar0 = {844.7289f, -1164.1f, 24.2681f}; break;

	case 29: vVar0 = {526.2521f, -1604.613f, 28.2625f}; break;

	case 30: vVar0 = {572.0462f, -1570.736f, 27.4904f}; break;

	case 31: vVar0 = {722.2852f, -1190.617f, 23.282f}; break;

	case 32: vVar0 = {497.6212f, -1494.084f, 28.2893f}; break;

	case 33: vVar0 = {480.3127f, -1549.937f, 28.2828f}; break;

	case 34: vVar0 = {-68.702f, 6426.148f, 30.439f}; break;

	case 35: vVar0 = {-247.4374f, 6240.294f, 30.4892f}; break;

	case 36: vVar0 = {2554.165f, 4668.059f, 33.0233f}; break;

	case 37: vVar0 = {2461.22f, 1589.255f, 32.0443f}; break;

	case 38: vVar0 = {-2203.335f, 4244.427f, 47.3305f}; break;

	case 39: vVar0 = {218.0665f, 2601.817f, 44.7668f}; break;

	case 40: vVar0 = {186.1719f, 2786.343f, 45.0144f}; break;

	case 41: vVar0 = {642.0746f, 2791.729f, 40.9795f}; break;

	case 42: vVar0 = {-1130.938f, 2701.133f, 17.8004f}; break;

	case 43: vVar0 = {-10.944f, -1646.76f, 28.3125f}; break;

	case 44: vVar0 = {1024.263f, -2398.404f, 29.1261f}; break;

	case 45: vVar0 = {870.8577f, -2232.323f, 29.5508f}; break;

	case 46: vVar0 = {-663.8541f, -2380.389f, 12.9446f}; break;

	case 47: vVar0 = {-1088.616f, -2235.098f, 12.2182f}; break;

	case 48: vVar0 = {-342.5126f, -1468.675f, 29.6107f}; break;

	case 49: vVar0 = {-1241.54f, -259.8841f, 37.9445f}; break;

	case 50: vVar0 = {899.8448f, -147.528f, 75.5674f}; break;

	case 51: vVar0 = {-1405.411f, 526.8572f, 122.8361f}; break;

	case 52: vVar0 = {1341.552f, -1578.037f, 53.4443f}; break;

	case 53: vVar0 = {-105.7029f, 6528.539f, 29.1719f}; break;

	case 54: vVar0 = {-302.3985f, 6327.434f, 31.8918f}; break;

	case 55: vVar0 = {-15.258f, 6557.378f, 32.2454f}; break;

	case 56: vVar0 = {1899.673f, 3773.178f, 31.8829f}; break;

	case 57: vVar0 = {1662.121f, 4776.317f, 41.0075f}; break;

	case 58: vVar0 = {-178.2278f, 490.886f, 134.0466f}; break;

	case 59: vVar0 = {339.5743f, 439.7083f, 145.5896f}; break;

	case 60: vVar0 = {-764.6163f, 618.3144f, 137.5536f}; break;

	case 61: vVar0 = {-679.5461f, 592.5162f, 139.693f}; break;

	case 62: vVar0 = {124.4571f, 551.8877f, 181.658f}; break;

	case 63: vVar0 = {-563.7349f, 689.099f, 151.6596f}; break;

	case 64: vVar0 = {-743.0927f, 590.0371f, 140.9221f}; break;

	case 65: vVar0 = {-861.252f, 684.8923f, 146.2643f}; break;

	case 66: vVar0 = {-1292.456f, 440.9454f, 93.7572f}; break;

	case 67: vVar0 = {369.5891f, 417.4813f, 136.8344f}; break;

	case 68: vVar0 = {-1581.501f, -558.2578f, 33.9528f}; break;

	case 69: vVar0 = {-1379.546f, -499.1783f, 32.1574f}; break;

	case 70: vVar0 = {-117.5296f, -605.7157f, 35.2857f}; break;

	case 71: vVar0 = {-67.0943f, -802.4415f, 43.2273f}; break;

	case 72: vVar0 = {254.1892f, -1809.183f, 26.1805f}; break;

	case 73: vVar0 = {-1472.278f, -920.0677f, 8.9683f}; break;

	case 74: vVar0 = {38.9478f, -1026.629f, 28.6354f}; break;

	case 75: vVar0 = {46.903f, 2789.825f, 57.1124f}; break;

	case 76: vVar0 = {-342.3246f, 6065.316f, 30.4895f}; break;

	case 77: vVar0 = {1737.878f, 3709.088f, 33.1348f}; break;

	case 78: vVar0 = {939.7161f, -1459.204f, 30.467f}; break;

	case 79: vVar0 = {189.7624f, 309.7488f, 104.4714f}; break;

	case 80: vVar0 = {-21.9593f, -191.3618f, 51.5599f}; break;

	case 81: vVar0 = {2472.22f, 4110.493f, 36.9629f}; break;

	case 82: vVar0 = {-39.3286f, 6420.603f, 30.7017f}; break;

	case 83: vVar0 = {-1134.762f, -1568.848f, 3.4077f}; break;
	}
	return vVar0;
}

// Position - 0x1E0F
int func_28(int iParam0) {
	switch (iParam0) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 61:
	case 83:
	case 84:
	case 85: return 1;

	case 5:
	case 6: return 2;

	case 7:
	case 34:
	case 62: return 3;

	case 35:
	case 36:
	case 37: return 4;

	case 38:
	case 39:
	case 65: return 5;

	case 40:
	case 41:
	case 63: return 6;

	case 42:
	case 43:
	case 64: return 7;

	case 8: return 8;

	case 9: return 9;

	case 10: return 10;

	case 11: return 11;

	case 12: return 12;

	case 13: return 13;

	case 14: return 14;

	case 15: return 15;

	case 16: return 16;

	case 17: return 17;

	case 18: return 18;

	case 19: return 19;

	case 20: return 20;

	case 21: return 21;

	case 22: return 22;

	case 23: return 23;

	case 24: return 24;

	case 25: return 25;

	case 26: return 26;

	case 27: return 27;

	case 28: return 28;

	case 29: return 29;

	case 30: return 30;

	case 31: return 31;

	case 32: return 32;

	case 33: return 33;

	case 44: return 34;

	case 45: return 35;

	case 46: return 36;

	case 47: return 37;

	case 48: return 38;

	case 49: return 39;

	case 50: return 40;

	case 51: return 41;

	case 52: return 42;

	case 53: return 43;

	case 54: return 44;

	case 55: return 45;

	case 56: return 46;

	case 57: return 47;

	case 58: return 48;

	case 59: return 49;

	case 60: return 50;

	case 66: return 51;

	case 67: return 52;

	case 68: return 53;

	case 69: return 54;

	case 70: return 55;

	case 71: return 56;

	case 72: return 57;

	case 73: return 58;

	case 74: return 59;

	case 75: return 60;

	case 76: return 61;

	case 77: return 62;

	case 78: return 63;

	case 79: return 64;

	case 80: return 65;

	case 81: return 66;

	case 82: return 67;

	case 87:
	case 103:
	case 104:
	case 105: return 68;

	case 88:
	case 106:
	case 107:
	case 108: return 69;

	case 89:
	case 109:
	case 110:
	case 111: return 70;

	case 90:
	case 112:
	case 113:
	case 114: return 71;

	case 91: return 72;

	case 92: return 73;

	case 93: return 74;

	case 94: return 75;

	case 95: return 76;

	case 96: return 77;

	case 97: return 78;

	case 98: return 79;

	case 99: return 80;

	case 100: return 81;

	case 101: return 82;

	case 102: return 83;
	}
	return 0;
}

// Position - 0x2356
void func_29() { gameplay::set_bit(&Global_2443134, 7); }

// Position - 0x2367
void func_30() {
	gameplay::set_bit(&Global_2443134, 5);
	func_31();
}

// Position - 0x237C
void func_31() { gameplay::set_bit(&Global_2443134, 8); }

// Position - 0x238E
void func_32(int iParam0, int iParam1, int *iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (!func_42()) {
		return;
	}
	iVar0 = 1;
	if (iParam4) {
		iVar0 = 4;
	}
	else if (iParam3) {
		iVar0 = 2;
	}
	else if (iParam5) {
		iVar0 = 8;
	}
	switch (iParam0) {
	case -1645229221:
	case -585718395:
	case -1359375127:
	case 454359403:
	case -982394051:
	case 1643659499:
	case -2072289654:
	case 650665123:
	case 1654961868:
	case -876847842:
	case 68030260:
	case -2122299283:
	case 366672791:
	case 283351220:
	case 291576838:
	case 1182673174:
	case -516219046:
	case 1036455748:
	case 277665518:
	case 2043854386:
	case 1839532116:
	case 1022400740:
	case 1940862352:
	case -1389227906:
	case 711665950:
	case 1704445500:
	case 1515774909:
	case 1173654533:
	case -899802304:
	case -663944335:
	case 1208553146:
	case -613221010:
	case -671062876:
	case -407201236:
	case -754024203:
	case -1885444887:
	case 1931729587:
	case 1064954035:
	case -180141073:
	case 2131324797:
	case 1612072658:
	case -517447402:
	case 1948102096:
	case 1108628223:
	case -1834046564:
	case -1239008812:
	case -222363842:
	case -1276678868:
	case 1564537328:
	case -96593501:
	case 742499889:
	case 2050093329:
	case -1752488069:
	case 634375935:
	case 1850983186:
	case 763367758:
	case 1941570214:
	case 665109499:
	case -1330755006:
	case 1976384368:
	case 268924934:
	case 1869490922:
	case -336803850:
	case -1412692765:
	case 618167454:
	case 980623936:
	case 437291904:
	case -135813048:
		if (iParam1 > 0) {
			func_33(iParam2, -1135378931, 537254313, 1474183246, iParam0, iParam1, iVar0, 7);
		}
		break;

	case -31156877:
	case -1027218631:
	case -1398318418:
	case 1652884147:
	case -57868256:
	case -1216489292:
	case -46622315:
	case -352356931:
	case -990286235:
	case 563463121:
	case 1734805203:
	case 941287179:
	case -1186079845:
	case -1985150258:
	case -1127021384:
	case -109201286:
	case 312105838:
	case 1982688246:
	case -661030418:
	case 1301046174:
	case -1586170317:
	case 393059668:
	case 23796958:
	case -1077156170:
	case 1780666425:
	case -2043695058:
	case -1922554349:
	case 1287308202:
	case 691372038:
	case 1480707108:
	case 1512499951:
	case 562283735:
	case -154732333:
	case -1362660491:
	case 645708827:
	case 767907967:
	case -1970151306:
	case 718859568:
	case -1955564771:
	case 892388724:
	case -1426920838:
	case 1349151477:
	case 1620609399:
	case 1961641934:
	case 210955503:
	case -59668082:
	case 1736933716:
	case -1468524125:
	case 111573502:
	case 1525644423:
	case 968073639:
	case 1577781788:
	case -934465332:
	case -1194253122:
	case -212607085:
	case -815546555:
	case 1048226110:
	case 569170531:
	case -856006867:
	case 848090538:
	case -47546905:
	case -293060240: func_33(iParam2, -1135378931, 1445302971, 1474183246, iParam0, iParam1, iVar0, 7); break;
	}
}

// Position - 0x271C
int func_33(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	bool bVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	bool bVar4;

	bVar0 = false;
	if (!func_42()) {
		bVar0 = true;
	}
	if (!bVar0) {
		if (!unk3::_network_shop_get_transactions_enabled_for_character(func_41()) ||
			unk3::_network_shop_get_transactions_disabled()) {
			Global_2590762 = 1;
			return 0;
		}
		if (Global_2453677) {
			if (iParam3 == 1067618600 || iParam3 == -1303831698) {
				Global_2590763 = 1;
				return 0;
			}
		}
	}
	iVar2 = 0;
	iVar1 = 0;
	while (iVar1 < 5) {
		if (Global_2590252[iVar1 /*76*/].f_2 == 0) {
			iVar2 = 1;
		}
		iVar1++;
	}
	if (!iVar2) {
		return 0;
	}
	*iParam0 = 5;
	iVar3 = 2147483647;
	if (bVar0 || unk3::_network_shop_begin_service(&iVar3, iParam3, iParam4, iParam2, iParam5, iParam6)) {
		if (bVar0 || unk3::_network_shop_checkout_start(iVar3)) {
			*iParam0 = func_40(iVar3, iParam1, iParam4, iParam2, iParam3, iParam5, 0, iParam6, iParam7);
			if (bVar0) {
				if (*iParam0 != -1) {
					Global_2590252[*iParam0 /*76*/].f_69 = 1;
				}
			}
			Global_2590752 = 1;
			return 1;
		}
	}
	else {
		if ((iParam7 & 2) != 0) {
			Global_2590761 = 1;
			Global_2590764 = iParam4;
			Global_2590766 = iParam3;
			Global_2590767 = 1;
			Global_2590765 = iParam5;
		}
		if ((iParam7 & 8) != 0) {
			Global_2590764 = iParam4;
			Global_2590766 = iParam3;
			Global_2590767 = 1;
			Global_2590765 = iParam5;
		}
		bVar4 = false;
		if (bVar4) {
			func_39(1, iParam4);
			Global_2590761 = 0;
		}
		if ((iParam7 & 4) != 0) {
			func_34(-1, iParam4, iParam6, iParam5, -1);
		}
	}
	return 0;
}

// Position - 0x2890
void func_34(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	switch (iParam1) {
	case 1704445500: gameplay::set_bit(&Global_2421664[player::player_id() /*358*/].f_125.f_71, 0); break;
	}
	if (iParam0 != -1) {
		func_35(iParam0);
	}
}

// Position - 0x28C8
void func_35(int iParam0) {
	int iVar0;

	iVar0 = 0;
	if (!func_42()) {
		iVar0 = 1;
	}
	if (iParam0 != -1) {
		if (func_38(iParam0)) {
			if (!iVar0) {
				unk3::_0xFA336E7F40C0A0D0();
			}
		}
		else if (!iVar0) {
			unk3::_network_shop_end_service(Global_2590252[iParam0 /*76*/]);
		}
		func_36(&Global_2590252[iParam0 /*76*/]);
	}
}

// Position - 0x291A
void func_36(var *uParam0) {
	*uParam0 = 0;
	*uParam0 = 2147483647;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	uParam0->f_3 = -1593119440;
	uParam0->f_4 = -2085313189;
	uParam0->f_5 = 0;
	uParam0->f_6 = 1227573907;
	uParam0->f_7 = -1161833819;
	uParam0->f_8 = 0;
	uParam0->f_8.f_1 = 0;
	uParam0->f_8.f_2 = 0;
	func_37(&uParam0->f_8.f_3);
	func_37(&uParam0->f_8.f_16);
	StringCopy(&uParam0->f_8.f_29, "", 32);
	StringCopy(&uParam0->f_8.f_37, "", 24);
	StringCopy(&uParam0->f_8.f_43, "", 16);
	StringCopy(&uParam0->f_8.f_47, "", 16);
	uParam0->f_8.f_51 = 0;
	uParam0->f_8.f_52 = 0;
	uParam0->f_8.f_53 = 0;
	uParam0->f_8.f_54 = 0;
	uParam0->f_8.f_55 = 0;
	uParam0->f_8.f_56 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 0;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
}

// Position - 0x2A01
void func_37(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_4 = 0;
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 0;
}

// Position - 0x2A49
bool func_38(int iParam0) {
	if (iParam0 >= 0 && iParam0 < 5) {
		return Global_2590252[iParam0 /*76*/].f_5 == 1;
	}
	return false;
}

// Position - 0x2A71
void func_39(int iParam0, int iParam1) {
	Global_2454840 = iParam1;
	Global_2454839 = iParam0;
}

// Position - 0x2A85
int func_40(int iParam0, var uParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			var uParam8) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 5) {
		if (Global_2590252[iVar0 /*76*/].f_2 == 0) {
			if (!func_42()) {
				iParam0 = iVar0 + 900;
			}
			Global_2590252[iVar0 /*76*/].f_2 = 1;
			Global_2590252[iVar0 /*76*/].f_1 = iParam5;
			Global_2590252[iVar0 /*76*/].f_3 = uParam1;
			Global_2590252[iVar0 /*76*/].f_4 = iParam2;
			Global_2590252[iVar0 /*76*/].f_7 = iParam3;
			Global_2590252[iVar0 /*76*/].f_5 = 0;
			Global_2590252[iVar0 /*76*/] = iParam0;
			Global_2590252[iVar0 /*76*/].f_6 = iParam4;
			Global_2590252[iVar0 /*76*/].f_72 = uParam8;
			Global_2590252[iVar0 /*76*/].f_71 = iParam7;
			Global_2590252[iVar0 /*76*/].f_75 = 0;
			Global_2590752 = 0;
			if (iParam6) {
				Global_2590252[iVar0 /*76*/].f_5 = 1;
			}
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x2B59
int func_41() { return Global_1312735; }

// Position - 0x2B65
bool func_42() {
	if (gameplay::is_pc_version()) {
		return true;
	}
	return false;
}

// Position - 0x2B79
int func_43(int iParam0, int iParam1, int *iParam2) {
	if (networkcash::network_get_vc_bank_balance() > iParam0) {
		*iParam1 = iParam0;
		return 1;
	}
	else {
		*iParam1 = networkcash::network_get_vc_bank_balance();
		*iParam2 = iParam0 - *iParam1;
	}
	return 0;
}

// Position - 0x2BA7
int func_44(int iParam0) {
	int iVar0;

	if (iParam0) {
		iVar0 = networkcash::network_get_vc_bank_balance();
	}
	iVar0 += networkcash::network_get_vc_wallet_balance(-1);
	return iVar0;
}

// Position - 0x2BC6
void func_45(int iParam0, int iParam1, int iParam2, float fParam3) {
	int iVar0;
	int iVar1;
	float fVar2;

	if (iParam1 < 1) {
		iParam1 = 1;
	}
	iVar0 = iParam0 * iParam1;
	fParam3 = 0f;
	if (iVar0 > 0) {
		fVar2 = 100f - fParam3;
		iVar1 = system::floor(IntToFloat(iVar0) * fVar2 / 100f);
	}
	else {
		iVar1 = iVar0;
	}
	Global_1591201[player::player_id() /*602*/].f_203.f_4 = iVar1;
	Global_1591201[player::player_id() /*602*/].f_203.f_3 += iVar1;
	if (iParam2 == 1) {
		func_46(iVar1, 0);
	}
}

// Position - 0x2C49
void func_46(int iParam0, int iParam1) {
	if (iParam1) {
	}
	iParam0 = iParam0;
}

// Position - 0x2C5A
struct<13> func_47(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

//Position - 0x2C71
int func_48(int iParam0)
{
	int iVar0;

	iVar0 = 0;
	if (func_50(iParam0) >= 0) {
		iVar0 = func_50(iParam0);
	}
	else {
		iVar0 = func_49(iParam0);
	}
	return iVar0;
}

// Position - 0x2C9B
int func_49(int iParam0) {
	switch (iParam0) {
	case 1: return 1000;

	case 10: return 5000;

	case 11: return 8000;

	case 8: return 1000;

	case 0: return 500;

	case 9: return 250;

	case 13: return 1000;

	case 12: return 7500;

	case 2: return 1000;

	case 14: return 500;

	case 20:
		if (player::get_player_wanted_level(player::player_id()) == 1) {
			return 200;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 2) {
			return 400;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 3) {
			return 600;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 4) {
			return 800;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 5) {
			return 1000;
		}
		break;

	case 6: return 500;

	case 22: return 200;

	case 23: return 400;

	case 24: return 700;

	case 25: return 100;

	case 26: return 1000;

	case 35: return 5000;

	case 15: return 0;

	case 17: return 0;

	case 18: return 0;

	case 19: return 0;

	case 21: return 0;

	case 36: return 0;

	case 39: return 200;

	case 40: return 1000;

	case 41: return 750;

	case 42: return 0;
	}
	return 0;
}

// Position - 0x2E93
int func_50(int iParam0) {
	switch (iParam0) {
	case 1: return Global_262145.f_5552;

	case 10: return Global_262145.f_4117;

	case 11: return Global_262145.f_4118;

	case 8: return Global_262145.f_4115;

	case 0: return Global_262145.f_4101;

	case 9: return Global_262145.f_4116;

	case 13: return Global_262145.f_4120;

	case 12: return Global_262145.f_4119;

	case 2: return Global_262145.f_4111;

	case 14: return Global_262145.f_4121;

	case 20:
		if (player::get_player_wanted_level(player::player_id()) == 1) {
			return Global_262145.f_5559;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 2) {
			return Global_262145.f_5560;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 3) {
			return Global_262145.f_5561;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 4) {
			return Global_262145.f_5562;
		}
		else if (player::get_player_wanted_level(player::player_id()) == 5) {
			return Global_262145.f_5563;
		}
		break;

	case 6: return Global_262145.f_4114;

	case 22: return Global_262145.f_4127;

	case 23: return Global_262145.f_4128;

	case 24: return Global_262145.f_4129;

	case 25: return Global_262145.f_4130;

	case 26: return Global_262145.f_4131;

	case 35: return Global_262145.f_6128;

	case 15: return Global_262145.f_5553;

	case 17: return Global_262145.f_5553;

	case 18: return Global_262145.f_5553;

	case 19: return Global_262145.f_5553;

	case 21: return Global_262145.f_5553;

	case 36: return Global_262145.f_6593;

	case 39: return -1;

	case 40: return Global_262145.f_11492;

	case 41: return Global_262145.f_11493;

	case 42: return Global_262145.f_11494;

	case 43: return Global_262145.f_13549;

	case 44: return Global_262145.f_13551;
	}
	return 0;
}

// Position - 0x3147
int func_51() { return networkcash::network_get_vc_wallet_balance(-1) + networkcash::network_get_vc_bank_balance(); }

// Position - 0x3159
void func_52(int iParam0) { Global_979732 = iParam0; }

// Position - 0x3167
bool func_53() { return Global_1315193 == 10; }

// Position - 0x3176
void func_54() { gameplay::set_bit(&Global_2443134.f_2, 26); }

// Position - 0x318A
void func_55(int iParam0, int iParam1) {
	int iVar0;
	struct<13> Var1;
	int iVar14;

	Global_2443905.f_3769 = 0;
	iVar0 = 0;
	while (iVar0 < 32) {
		Global_2443905.f_3769.f_1[iVar0 /*13*/] = {Var1};
		iVar0++;
	}
	Global_2443905.f_3769.f_1[0 /*13*/] = {func_47(player::player_id())};
	Global_2443905.f_3769 = 1;
	iVar0 = 0;
	while (iVar0 < 32) {
		iVar14 = player::int_to_playerindex(iVar0);
		if (network::network_is_player_active(iVar14) && iVar14 != player::player_id() &&
			Global_2443905.f_3769 < iParam1) {
			Var1 = {func_47(iVar14)};
			if ((iParam0 || network::network_is_friend(&Var1)) && iVar0 < 32) {
				if (iParam0 || func_56(iVar14)) {
					Global_2443905.f_3769.f_1[Global_2443905.f_3769 /*13*/] = {Var1};
					Global_2443905.f_3769++;
				}
			}
		}
		iVar0++;
	}
}

// Position - 0x3281
bool func_56(int iParam0) {
	if (!func_57(iParam0) && !network::network_has_player_started_transition(iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x32A4
bool func_57(int iParam0) { return Global_1591201[iParam0 /*602*/].f_188 != 0; }

// Position - 0x32B9
void func_58() { gameplay::set_bit(&Global_2443134.f_2, 9); }

// Position - 0x32CD
void func_59() {
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		audio::play_sound_frontend(-1, "Menu_Accept", &Global_14432, 1);
		func_60();
	}
}

// Position - 0x32F2
void func_60() {
	if (func_61()) {
		mobile::_move_finger(5);
	}
}

// Position - 0x3306
bool func_61() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (Global_69702) {
		return false;
	}
	iVar2 = 0;
	iVar0 = cam::_0x19CAFA3C87F7C2FF();
	iVar1 = cam::_0xEE778F8C7E1142E2(iVar0);
	if (iVar1 == 4) {
		iVar2 = 1;
	}
	if (Global_2595532 || iVar2) {
		return true;
	}
	return true;
}

// Position - 0x334D
bool func_62(int iParam0) {
	int iVar0;

	if (iParam0 != -1 && Global_262145.f_5375[iParam0] == 129) {
		iVar0 = func_63(2463, -1, 0);
		if (!gameplay::is_bit_set(iVar0, 22)) {
			return true;
		}
	}
	return false;
}

// Position - 0x338B
int func_63(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_64(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x33BD
int func_64(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	if (iVar0 == -1) {
		iVar1 = func_41();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x33F1
int func_65() { return func_66(129); }

// Position - 0x33FF
int func_66(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 7) {
		if (Global_262145.f_5375[iVar0] == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x342F
void func_67(int iParam0) { Global_2443905.f_5896 = iParam0; }

// Position - 0x3440
int func_68() {
	if (func_71() && func_69()) {
		return 11;
	}
	return 10;
}

// Position - 0x3462
int func_69() {
	int iVar0;

	iVar0 = func_63(5567, -1, 0);
	if (iVar0 == 0) {
		return 1;
	}
	if (network::_get_posix_time() >= iVar0 + Global_262145.f_4859) {
		func_70(5567, 0, -1, 1, 0);
		return 1;
	}
	return 0;
}

// Position - 0x34A0
void func_70(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam4) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_64(iParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
}

// Position - 0x34D0
int func_71() {
	if (gameplay::is_bit_set(gameplay::get_random_int_in_range(0, 65535), 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x34F1
void func_72() { gameplay::set_bit(&Global_2443134.f_2, 21); }

// Position - 0x3505
var func_73() {
	struct<6> Var0;

	Var0 = {func_74()};
	if (!gameplay::is_string_null_or_empty(&Var0) && !gameplay::are_strings_equal(".", &Var0)) {
		return gameplay::get_hash_key(&Var0);
	}
	if (Global_262145.f_7422 == Global_1633501.f_88646) {
		return Global_262145.f_7424;
	}
	return Global_1633501.f_88646;
}

// Position - 0x3562
struct<6> func_74() {
	struct<6> Var0;
	int iVar6;
	int iVar7;

	if (gameplay::is_string_null_or_empty(&Global_1757074.f_10)) {
		iVar7 = func_63(5404, -1, 0);
		if (iVar7 == 0) {
			StringCopy(&Var0, ".", 24);
		}
		else {
			iVar6 = 0;
			while (iVar6 < 1118) {
				if (Global_794643.f_4[iVar6 /*88*/].f_65 == 0 && Global_794643.f_4[iVar6 /*88*/].f_68 == 1 &&
					gameplay::is_bit_set(Global_794643.f_4[iVar6 /*88*/].f_76, 13)) {
					if (Global_794643.f_98389[iVar6 /*13*/].f_1 == iVar7) {
						Var0 = {Global_794643.f_112937[Global_794643.f_98389[iVar6 /*13*/].f_10 /*6*/]};
						iVar6 = 1118;
					}
				}
				iVar6++;
			}
			if (gameplay::is_string_null_or_empty(&Var0)) {
			}
		}
		Global_1757074.f_10 = {Var0};
		return Var0;
	}
	return Global_1757074.f_10;
}

//Position - 0x3641
void func_75(int iParam0)
{
	if (iParam0 == -1) {
		Global_2443134.f_767++;
	}
	else {
		Global_2443134.f_767 = iParam0;
	}
}

// Position - 0x366B
void func_76() {
	func_77();
	gameplay::set_bit(&Global_2443134.f_2, 11);
}

// Position - 0x3683
void func_77() { gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 5); }

// Position - 0x369F
void func_78() { gameplay::set_bit(&Global_2443134.f_3, 5); }

// Position - 0x36B2
void func_79() { gameplay::set_bit(&Global_2443134.f_3, 3); }

// Position - 0x36C5
int func_80(int iParam0, int iParam1) {
	if (iParam0 > 20) {
		iParam0 = 0;
	}
	return Global_262145.f_5068[iParam1 /*21*/][iParam0];
}

// Position - 0x36E6
int func_81() { return func_66(2); }

// Position - 0x36F3
int func_82(int iParam0) {
	if (iParam0 > 30) {
		iParam0 = 0;
	}
	return Global_262145.f_4926[iParam0];
}

// Position - 0x3710
int func_83() { return network::_get_posix_time() / Global_262145.f_5050 % func_84(); }

// Position - 0x3729
int func_84() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 30) {
		if (Global_262145.f_4926[iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return iVar0;
}

// Position - 0x375A
void func_85() { gameplay::set_bit(&Global_2443134.f_3, 2); }

// Position - 0x376D
void func_86(var uParam0) { Global_2443134.f_28 = uParam0; }

// Position - 0x377D
void func_87(char *sParam0) {
	StringCopy(&Global_2443134.f_737, sParam0, 24);
	if (func_88()) {
		StringCopy(&Global_970912.f_42, sParam0, 24);
	}
}

// Position - 0x37A1
bool func_88() { return gameplay::is_bit_set(Global_2443905.f_1.f_2808, 5); }

// Position - 0x37B7
int func_89(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 1118) {
		if (iParam0 == Global_794643.f_98389[iVar0 /*13*/].f_1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x37ED
int func_90(int iParam0) { return network::_get_posix_time() / Global_262145.f_5363[iParam0] % func_91(iParam0); }

// Position - 0x380C
int func_91(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 20) {
		if (Global_262145.f_5068[iParam0 /*21*/][iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return iVar0;
}

// Position - 0x3841
int func_92(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 7) {
		if (Global_262145.f_5375[iVar0] == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x3871
void func_93() {
	char *sVar0;

	StringCopy(&Global_2443134.f_737, sVar0, 24);
}

// Position - 0x3884
bool func_94(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 7:
		if (func_117()) {
			if (func_53() || func_116()) {
				return false;
			}
			else {
				return true;
			}
		}
		break;

	case 9: return func_108(2, 0, 0);

	case 10:
		if (func_53() || func_116()) {
			return false;
		}
		else {
			return func_108(1, 0, 0);
		}
		break;

	case 2:
		if (func_53() || func_116() || !Global_262145.f_5404) {
			return false;
		}
		else {
			return func_108(2, 0, 0);
		}
		break;

	case 3:
		if (func_53() || func_116() || func_92(202) == -1) {
			return false;
		}
		else {
			return func_108(2, 0, 0);
		}
		break;

	case 4:
		if (func_53() || func_116() || !Global_262145.f_5406 || Global_262145.f_5375[func_81()] != 2 ||
			Global_1574324.f_14 == -1) {
			return false;
		}
		else {
			return func_108(2, 0, 0);
		}
		break;

	case 0:
		iVar0 = func_66(223);
		if (func_53() || func_116() || iVar0 == -1 || Global_1574324.f_15[iVar0] == -1) {
			return false;
		}
		else {
			return func_108(2, 0, 0);
		}
		break;

	case 1: return false;

	case 6:
		if (func_53() || func_116() || Global_262145.f_4902) {
			return false;
		}
		else {
			return true;
		}
		break;

	case 8:
		if (func_53() || func_116() || Global_262145.f_4857 == 1) {
			return false;
		}
		else {
			return func_107() | func_104() | func_101();
		}
		break;

	case 11:
		if (func_53() || func_100() || Global_794643.f_112969[9] == 0 || func_116()) {
			return false;
		}
		else {
			return func_108(0, 0, 0);
		}
		break;

	case 14:
		if (func_53() || Global_794643.f_112969[7] == 0 || func_116()) {
			return false;
		}
		else {
			return func_108(0, 0, 0);
		}
		break;

	case 15:
		if (func_53() || Global_794643.f_112969[4] == 0 || func_116()) {
			return false;
		}
		else {
			return func_108(4, 0, 0);
		}
		break;

	case 12:
		if (func_53() || !func_99() || func_116() || Global_262145.f_10817) {
			return false;
		}
		else {
			return func_96(0) > 0 || func_95();
		}
		break;

	case 5:
		if (func_53() || Global_794643.f_112969[11] == 0 || func_116()) {
			return false;
		}
		else {
			return func_108(10, 0, 0) | func_108(0, 0, 0);
		}
		break;

	case 13:
		if (func_53() || Global_794643.f_112969[10] == 0 || func_116()) {
			return false;
		}
		else {
			return func_108(0, 0, 0);
		}
		break;

	case 16: return func_108(3, 0, 0);

	case 17: return func_108(8, 0, 0);

	case 18:
		if (Global_262145.f_4865) {
			return false;
		}
		else {
			return func_108(15, 0, 0);
		}
		break;

	case 19:
		if (func_108(2, 0, 0) && func_108(1, 0, 0) && func_108(0, 0, 0) && func_108(3, 0, 0) && func_108(8, 0, 0) &&
			!func_53() && !func_116()) {
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x3CE7
bool func_95() { return func_63(2913, -1, 0) > 0; }

// Position - 0x3CFA
int func_96(int iParam0) {
	int iVar0;

	if (Global_1760585[iParam0 /*8*/] == -1) {
		iVar0 = func_63(func_98(iParam0), -1, 0);
		if (iVar0 == -1) {
			func_97(iParam0, 0);
			iVar0 = 0;
		}
		Global_1760585[iParam0 /*8*/] = iVar0;
	}
	return Global_1760585[iParam0 /*8*/];
}

// Position - 0x3D3E
void func_97(int iParam0, int iParam1) {
	Global_1760585[iParam0 /*8*/] = iParam1;
	func_70(func_98(iParam0), iParam1, -1, 1, 0);
}

// Position - 0x3D5F
int func_98(int iParam0) {
	switch (iParam0) {
	case 0: return 5848;

	default:
	}
	return 5848;
}

// Position - 0x3D7D
bool func_99() {
	if (Global_262145.f_10815 == 1) {
		return false;
	}
	return Global_794643.f_112924[0 /*11*/].f_9 != 0;
}

// Position - 0x3DA4
var func_100() { return Global_1573272.f_4; }

// Position - 0x3DB2
int func_101() {
	int iVar0;

	if (func_103(player::player_id())) {
		return 1;
	}
	iVar0 = Global_1363267[func_64(-1)];
	if (gameplay::is_bit_set(iVar0, 9)) {
		func_102(1);
		return 1;
	}
	return 0;
}

// Position - 0x3DEB
void func_102(int iParam0) {
	if (iParam0) {
		if (!gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 21)) {
			gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_139, 21);
		}
	}
	else if (gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 21)) {
		gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_139, 21);
	}
}

// Position - 0x3E4E
bool func_103(var uParam0) {
	int iVar0;

	iVar0 = uParam0;
	if (iVar0 > -1) {
		return gameplay::is_bit_set(Global_1591201[iVar0 /*602*/].f_139, 21);
	}
	return false;
}

// Position - 0x3E75
int func_104() {
	if (Global_262145.f_4858) {
		return 0;
	}
	if (func_105()) {
		return 1;
	}
	return 0;
}

// Position - 0x3E97
bool func_105() {
	if (func_106(1) && func_106(2) && func_106(3) && func_106(4) && func_106(5)) {
		return true;
	}
	return false;
}

// Position - 0x3ED4
int func_106(int iParam0) {
	var uVar0;
	int iVar1;
	var uVar2;

	uVar0 = Global_1363138[iParam0];
	iVar1 = uVar0;
	if (stats::stat_get_bool(iVar1, &uVar2, -1)) {
		return uVar2;
	}
	return 0;
}

// Position - 0x3EFC
int func_107() {
	struct<6> Var0;

	Var0 = {func_74()};
	if (gameplay::are_strings_equal(&Var0, ".") || gameplay::is_string_null_or_empty(&Var0)) {
		return 0;
	}
	return 1;
}

// Position - 0x3F29
int func_108(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (Global_262145.f_6591 == 1) {
		if (iParam0 == 67) {
			return 1;
		}
		if (iParam0 == 74) {
			return 1;
		}
		if (func_111(player::player_id(), 85)) {
			if (iParam0 == 64 || iParam0 == 77 || iParam0 == 61 || iParam0 == 81 || iParam0 == 63 || iParam0 == 62) {
				return 1;
			}
		}
		if (iParam0 == 66 || iParam0 == 116 || iParam0 == 103 || iParam0 == 104 || iParam0 == 105 || iParam0 == 119 ||
			iParam0 == 88 || iParam0 == 75 || iParam0 == 95 || iParam0 == 65 || iParam0 == 98) {
			return 1;
		}
	}
	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 == 31) {
		if (Global_262145.f_4882 == 1) {
			return 1;
		}
	}
	if (func_110() || func_116()) {
		return 1;
	}
	iVar0 = iParam0;
	iVar1 = iVar0 / 32;
	iVar0 %= 32;
	if (iParam1) {
		if (iParam0 == 3) {
			if (func_109()) {
				return 1;
			}
			else {
				return 0;
			}
		}
	}
	if (iParam2) {
		return 0;
	}
	return gameplay::is_bit_set(Global_1574358[iVar1], iVar0);
}

// Position - 0x4099
bool func_109() {
	int iVar0;

	if (Global_1312446) {
		return true;
	}
	if (gameplay::is_bit_set(Global_2494199.f_1639, 23)) {
		return true;
	}
	if (func_110()) {
		return true;
	}
	if (func_116()) {
		return true;
	}
	iVar0 = Global_1363267[func_64(-1)];
	if (gameplay::is_bit_set(iVar0, 7)) {
		gameplay::set_bit(&Global_2494199.f_1639, 23);
		return true;
	}
	return false;
}

// Position - 0x40FF
bool func_110() { return Global_1315223; }

// Position - 0x410B
bool func_111(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (!func_114()) {
		return false;
	}
	if (func_113()) {
		return false;
	}
	if (iParam1 == 86) {
		return true;
	}
	iVar0 = func_112(iParam1);
	iVar1 = iVar0;
	return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_491, iVar1);
}

// Position - 0x4153
int func_112(int iParam0) {
	switch (iParam0) {
	case 86: return 0;

	case 19: return 1;

	case 12: return 2;

	case 31: return 3;

	case 20: return 4;

	case 18: return 5;

	case 2: return 6;

	case 76: return 7;

	default:
	}
	return 1;
}

// Position - 0x41B3
bool func_113() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_143, 3); }

// Position - 0x41CD
int func_114() {
	if (Global_1312446) {
		return 1;
	}
	if (func_110()) {
		return 1;
	}
	if (func_116()) {
		return 1;
	}
	return func_115(120, -1);
}

// Position - 0x41FD
int func_115(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_64(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x4229
bool func_116() { return Global_1315221; }

// Position - 0x4235
bool func_117() {
	if (func_108(2, 0, 0) || func_108(1, 0, 0) || func_108(0, 0, 0) || func_108(3, 0, 0) || func_108(8, 0, 0)) {
		return true;
	}
	return false;
}

// Position - 0x4281
int func_118(int iParam0, int iParam1) {
	if (controls::is_control_just_released(iParam0, iParam1)) {
		if (gameplay::is_pc_version()) {
			if (gameplay::update_onscreen_keyboard() == 0 ||
				network::_network_is_text_chat_active() && controls::_is_input_disabled(2)) {
				return 0;
			}
		}
		if (ui::is_pause_menu_active() || ui::is_warning_message_active()) {
			return 0;
		}
		else {
			return 1;
		}
	}
	return 0;
}

// Position - 0x42DC
void func_119() {
	bool bVar0;

	bVar0 = false;
	if (func_129(player::player_id())) {
		if (func_125(1)) {
			StringCopy(&vLocal_233, "PHINVQUITBBB", 24);
		}
		else {
			StringCopy(&vLocal_233, "PHINVQUITBB", 24);
		}
		bVar0 = true;
	}
	else if (func_124(player::player_id())) {
		StringCopy(&vLocal_233, "PHINVQUITB", 24);
		bVar0 = true;
	}
	if (func_121()) {
		StringCopy(&vLocal_233, "PHINVQUIT", 24);
		bVar0 = true;
	}
	if (bVar0) {
	}
	func_120(&vLocal_233, -1);
}

// Position - 0x4343
void func_120(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x435A
bool func_121() {
	if (func_122(player::player_id(), 131) || func_122(player::player_id(), 129)) {
		return true;
	}
	return false;
}

// Position - 0x4384
int func_122(int iParam0, int iParam1) {
	if (Global_1619421[iParam0 /*390*/] == iParam1) {
		return func_123(iParam0);
	}
	return 0;
}

// Position - 0x43A4
bool func_123(int iParam0) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		return gameplay::is_bit_set(Global_1619421[iVar0 /*390*/].f_1, 0);
	}
	return false;
}

// Position - 0x43CA
bool func_124(int iParam0) {
	if (func_123(iParam0)) {
		return true;
	}
	if (func_129(iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x43ED
bool func_125(int iParam0) { return func_126(player::player_id(), iParam0); }

// Position - 0x43FF
int func_126(int iParam0, bool bParam1) { return func_127(iParam0, bParam1, 1); }

// Position - 0x4410
int func_127(int iParam0, bool bParam1, int iParam2) {
	int iVar0;

	if (iParam0 == func_23()) {
		return 0;
	}
	if (!bParam1) {
		if (func_128(iParam0, iParam2)) {
			return 0;
		}
	}
	iVar0 = Global_1619421[iParam0 /*390*/].f_11;
	if (iVar0 != func_23() && Global_1619421[iVar0 /*390*/].f_11.f_289 == iParam2) {
		return 1;
	}
	return 0;
}

// Position - 0x446C
bool func_128(int iParam0, int iParam1) {
	if (iParam0 != func_23()) {
		if (Global_1619421[iParam0 /*390*/].f_11 != func_23()) {
			if (Global_1619421[iParam0 /*390*/].f_11 == iParam0 &&
				Global_1619421[iParam0 /*390*/].f_11.f_289 == iParam1) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x44BB
bool func_129(int iParam0) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		return func_130(iParam0, 9);
	}
	return false;
}

// Position - 0x44D9
var func_130(int iParam0, int iParam1) {
	return gameplay::is_bit_set(Global_1619421[iParam0 /*390*/].f_11.f_4, iParam1);
}

// Position - 0x44F4
void func_131() {
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		audio::play_sound_frontend(-1, "Menu_Back", &Global_14432, 1);
	}
}

// Position - 0x4515
void func_132() {
	int iVar0;
	bool bVar1;

	iLocal_242 = 0;
	func_147(Global_14424, "SET_DATA_SLOT_EMPTY", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	func_146(Global_14424, "SET_DATA_SLOT", 18f, 0f, 0f, -1f, -1f, "CELL_208", 0, 0, 0, 0);
	bVar1 = true;
	if (iLocal_251 == iLocal_255 && !Global_262145.f_4845) {
		if (iLocal_244) {
			graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(18);
			graphics::_push_scaleform_movie_function_parameter_int(iVar0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::begin_text_command_scaleform_string("CELL_JIP_F");
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
		graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(18);
		graphics::_push_scaleform_movie_function_parameter_int(iVar0);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("JIPMP_HEISTQ");
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
		iVar0++;
		graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(18);
		graphics::_push_scaleform_movie_function_parameter_int(iVar0);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("JIPMP_HEISTD");
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
		iVar0++;
	}
	else {
		if (iLocal_244) {
			graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(18);
			graphics::_push_scaleform_movie_function_parameter_int(iVar0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::begin_text_command_scaleform_string("CELL_JIP_F");
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
		if (Global_262145.f_4843 == 0) {
			graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(18);
			graphics::_push_scaleform_movie_function_parameter_int(iVar0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			if (iLocal_257[iLocal_251] == 4) {
				if (Global_1574324.f_14 == -2) {
					graphics::begin_text_command_scaleform_string("CELL_JIPPRP");
					bVar1 = false;
				}
				else if (Global_1574324.f_14 == -3) {
					graphics::begin_text_command_scaleform_string("CELL_JIPPRV");
					ui::add_text_component_substring_text_label(
						vehicle::get_display_name_from_vehicle_model(Global_1574324.f_32));
					bVar1 = false;
				}
				else if (Global_1574324.f_14 == 0) {
					graphics::begin_text_command_scaleform_string("CELL_JIPPRC");
					ui::add_text_component_substring_text_label(func_144(func_145()));
					bVar1 = false;
				}
				else if (Global_1574324.f_14 == -4) {
					graphics::begin_text_command_scaleform_string("FMSPR_HLP9P");
					bVar1 = false;
				}
				else if (!func_143()) {
					graphics::begin_text_command_scaleform_string("CELL_JIPPRN");
					ui::add_text_component_integer(func_142());
					bVar1 = false;
				}
				else if (func_139()) {
					graphics::begin_text_command_scaleform_string("PIM_DMAGUT");
					ui::add_text_component_substring_time(Global_1574324.f_1 - network::_get_posix_time() * 1000, 14);
					bVar1 = false;
				}
				else {
					graphics::begin_text_command_scaleform_string("CELL_JIP_PR");
					ui::add_text_component_integer(func_142());
					bVar1 = true;
				}
			}
			else {
				if (iLocal_257[iLocal_251] == 6) {
					graphics::begin_text_command_scaleform_string("JIPMP_SVMH");
				}
				else {
					graphics::begin_text_command_scaleform_string("CELL_JIP_A");
				}
				bVar1 = true;
			}
			iLocal_242 = !bVar1;
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
	}
	func_147(Global_14424, "DISPLAY_VIEW", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	if (iLocal_251 == iLocal_255 && !Global_262145.f_4845) {
		func_136("JIPMP_QJ");
	}
	else {
		func_136("CELL_JIP_OCL");
	}
	if (bVar1) {
		func_133(13, &Local_225, 1, "", 4, &Local_221, &iLocal_290);
	}
	else {
		func_133(1, "", 1, "", 4, &Local_221, &iLocal_290);
	}
}

// Position - 0x47FC
void func_133(int iParam0, char *sParam1, int iParam2, char *sParam3, int iParam4, char *sParam5, int *iParam6) {
	func_134(2, iParam0, sParam1, 0, iParam6, -1);
	func_134(1, iParam2, sParam3, 1, iParam6, 17);
	func_134(3, iParam4, sParam5, 2, iParam6, -1);
}

// Position - 0x482C
void func_134(int iParam0, int iParam1, char *sParam2, int iParam3, int *iParam4, int iParam5) {
	if (iParam1 == 1) {
		func_146(Global_14424, "SET_SOFT_KEYS", system::to_float(iParam0), 0f, system::to_float(iParam1), -1f, -1f, 0,
				 0, 0, 0, 0);
		gameplay::clear_bit(iParam4, iParam3);
		func_135(iParam5, 0);
		return;
	}
	if (Global_14431) {
		func_146(Global_14424, "SET_SOFT_KEYS", system::to_float(iParam0), 1f, system::to_float(iParam1), -1f, -1f,
				 sParam2, 0, 0, 0, 0);
		gameplay::set_bit(iParam4, iParam3);
		func_135(iParam5, 1);
		return;
	}
	func_146(Global_14424, "SET_SOFT_KEYS", system::to_float(iParam0), 1f, system::to_float(iParam1), -1f, -1f, 0, 0, 0,
			 0, 0);
	gameplay::set_bit(iParam4, iParam3);
	func_135(iParam5, 1);
}

// Position - 0x48D1
void func_135(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		gameplay::set_bit(&G_SleepModeOnOn25, iParam0);
		return;
	}
	gameplay::clear_bit(&G_SleepModeOnOn25, iParam0);
}

// Position - 0x48FC
void func_136(char *sParam0) { func_137(Global_14424, "SET_HEADER", sParam0, 0, 0, 0, 0); }

// Position - 0x4915
void func_137(int iParam0, char *sParam1, char *sParam2, char *sParam3, char *sParam4, char *sParam5, char *sParam6) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	func_138(sParam2);
	if (!gameplay::is_string_null_or_empty(sParam3)) {
		func_138(sParam3);
	}
	if (!gameplay::is_string_null_or_empty(sParam4)) {
		func_138(sParam4);
	}
	if (!gameplay::is_string_null_or_empty(sParam5)) {
		func_138(sParam5);
	}
	if (!gameplay::is_string_null_or_empty(sParam6)) {
		func_138(sParam6);
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x4970
void func_138(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x4982
bool func_139() {
	func_140();
	return network::_get_posix_time() < Global_1574324.f_1;
}

// Position - 0x4999
void func_140() {
	if (Global_1574324.f_1 == -1) {
		Global_1574324.f_1 = func_141(-392331778);
	}
}

// Position - 0x49BA
int func_141(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x49D8
var func_142() { return Global_262145.f_5371; }

// Position - 0x49E7
int func_143() {
	int iVar0;

	iVar0 = func_142();
	if (networkcash::network_can_spend_money(iVar0, 0, 1, 0, -1) && func_44(1) >= iVar0) {
		return 1;
	}
	return 0;
}

// Position - 0x4A14
char *func_144(int iParam0) {
	switch (iParam0) {
	case 0: return "FMSTP_PRC0";

	case 1: return "FMSTP_PRC1";

	case 2: return "FMSTP_PRC2";

	case 3: return "FMSTP_PRC3";

	case 4: return "FMSTP_PRC4";

	case 5: return "FMSTP_PRC5";

	case 6: return "FMSTP_PRC6";

	case 7: return "FMSTP_PRC7";

	case 8: return "FMSTP_PRC8";

	case 9: return "FMSTP_PRC9";

	case 10: return "FMSTP_PRC10";

	case 11: return "FMSTP_PRC11";

	case 12: return "FMSTP_PRC12";

	case 13: return "FMSTP_PRC13";

	case 14: return "FMSTP_PRC14";

	case 15: return "FMSTP_PRC15";

	default:
	}
	return "FMSTP_PRC14";
}

// Position - 0x4AF7
int func_145() {
	if (Global_1574324.f_23[func_81()] != -1) {
		return Global_262145.f_5216[Global_1574324.f_23[func_81()]];
	}
	return -1;
}

// Position - 0x4B28
void func_146(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  char *sParam7, char *sParam8, char *sParam9, char *sParam10, char *sParam11) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	if (!gameplay::is_string_null_or_empty(sParam7)) {
		func_138(sParam7);
	}
	if (!gameplay::is_string_null_or_empty(sParam8)) {
		func_138(sParam8);
	}
	if (!gameplay::is_string_null_or_empty(sParam9)) {
		func_138(sParam9);
	}
	if (!gameplay::is_string_null_or_empty(sParam10)) {
		func_138(sParam10);
	}
	if (!gameplay::is_string_null_or_empty(sParam11)) {
		func_138(sParam11);
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x4BDB
void func_147(int iParam0, char *sParam1, float fParam2, float fParam3, float fParam4, float fParam5, float fParam6) {
	graphics::_push_scaleform_movie_function(iParam0, sParam1);
	graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam2));
	if (fParam3 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam3));
	}
	if (fParam4 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam4));
	}
	if (fParam5 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam5));
	}
	if (fParam6 != -1f) {
		graphics::_push_scaleform_movie_function_parameter_int(system::round(fParam6));
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x4C3E
int func_148() {
	int iVar0;
	struct<13> Var1;
	int iVar14;

	if (func_53() || func_116() || Global_262145.f_4892 || Global_262145.f_4901 || iLocal_257[iLocal_251] == 4 ||
		iLocal_257[iLocal_251] == 6) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 32) {
		iVar14 = player::int_to_playerindex(iVar0);
		if (network::network_is_player_active(iVar14) && iVar14 != player::player_id()) {
			Var1 = {func_47(iVar14)};
			if (network::network_is_friend(&Var1)) {
				if (func_56(iVar14)) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x4CE5
void func_149() {
	if (gameplay::is_string_null_or_empty(&vLocal_233)) {
		return;
	}
	if (!func_150(&vLocal_233)) {
		StringCopy(&vLocal_233, "", 24);
		return;
	}
	ui::clear_help(1);
	StringCopy(&vLocal_233, "", 24);
}

// Position - 0x4D19
bool func_150(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x4D2C
void func_151(int iParam0) {
	if (Global_14604) {
		func_153(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_152()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x4D9C
int func_152() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x4DC3
void func_153(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_154(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x4E37
bool func_154(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x4E91
bool func_155() { return Global_1311716[0 /*4*/] > 0; }

// Position - 0x4EA2
void func_156() {
	func_158();
	if (func_155()) {
		func_151(0);
		iLocal_242 = 0;
		return;
	}
	if (iLocal_251 < 0 || iLocal_251 >= 20) {
		if (Global_14443.f_1 > 3) {
			Global_14443.f_1 = 7;
		}
		func_193();
		iLocal_212 = 0;
		iLocal_242 = 0;
		return;
	}
	if (func_2(2, Global_14413, 0)) {
		Global_14443.f_1 = 8;
		func_193();
		iLocal_239 = 0;
		iLocal_212 = 0;
		func_131();
		iLocal_242 = 0;
		return;
	}
	if (iLocal_241 == 0 && iLocal_288 > 0 && !iLocal_242) {
		if (func_2(2, Global_14412, 0)) {
			Global_14421 = 1;
			func_59();
			graphics::_push_scaleform_movie_function(Global_14424, "GET_CURRENT_SELECTION");
			uLocal_287 = graphics::_pop_scaleform_movie_function();
			while (!graphics::_0x768FF8961BA904D6(uLocal_287)) {
				system::wait(0);
			}
			iLocal_256 = graphics::_0x2DE7EFA66B906036(uLocal_287);
			iLocal_212 = 3;
			Global_14443.f_1 = 8;
			if (iLocal_257[iLocal_251] == 6) {
				func_5();
			}
			else {
				func_157();
			}
			iLocal_242 = 0;
		}
	}
	else if (func_2(2, Global_14412, 0) && !iLocal_242) {
		Global_14421 = 1;
		func_131();
	}
}

// Position - 0x4FB4
void func_157() {
	if (iLocal_251 == iLocal_255) {
		func_136("JIPMP_HEISTT");
	}
	else {
		func_136(&Local_213);
	}
	func_147(Global_14424, "SET_DATA_SLOT_EMPTY", system::to_float(13), -1082130432, -1082130432, -1082130432,
			 -1082130432);
	func_146(Global_14424, "SET_DATA_SLOT", system::to_float(13), system::to_float(0), system::to_float(12), -1f, -1f,
			 &Local_217, 0, 0, 0, 0);
	func_147(Global_14424, "DISPLAY_VIEW", system::to_float(13), -1082130432, -1082130432, -1082130432, -1082130432);
	func_133(13, &Local_225, 1, "", 14, &Local_229, &iLocal_290);
}

// Position - 0x5053
void func_158() {
	if (iLocal_243) {
		if (system::timera() > 150) {
			iLocal_243 = 0;
		}
	}
	if (controls::_is_input_disabled(2)) {
		if (func_2(2, 181, 0)) {
			if (iLocal_239 > 0) {
				iLocal_239--;
			}
			func_161();
		}
		if (func_2(2, 180, 0)) {
			iLocal_239++;
			if (iLocal_241 == 0) {
				if (iLocal_239 >= iLocal_240) {
					iLocal_239 = 0;
				}
			}
			else {
				iLocal_239 = 0;
			}
			func_159();
		}
	}
	if (iLocal_243 == 0) {
		if (func_2(2, Global_14419, 0)) {
			if (iLocal_239 > 0) {
				iLocal_239--;
			}
			func_161();
			iLocal_243 = 1;
			system::settimera(0);
		}
		if (func_2(2, Global_14420, 0)) {
			iLocal_239++;
			if (iLocal_241 == 0) {
				if (iLocal_239 >= iLocal_240) {
					iLocal_239 = 0;
				}
			}
			else {
				iLocal_239 = 0;
			}
			func_159();
			iLocal_243 = 1;
			system::settimera(0);
		}
	}
}

// Position - 0x5118
void func_159() {
	func_147(Global_14424, "SET_INPUT_EVENT", system::to_float(3), -1082130432, -1082130432, -1082130432, -1082130432);
	audio::play_sound_frontend(-1, "Menu_Navigate", &Global_14432, 1);
	func_160();
}

// Position - 0x5155
void func_160() {
	if (func_61()) {
		if (Global_14609 == 0) {
			mobile::_move_finger(2);
		}
		else {
			mobile::_move_finger(1);
		}
	}
}

// Position - 0x5178
void func_161() {
	func_147(Global_14424, "SET_INPUT_EVENT", system::to_float(1), -1082130432, -1082130432, -1082130432, -1082130432);
	audio::play_sound_frontend(-1, "Menu_Navigate", &Global_14432, 1);
	func_162();
}

// Position - 0x51B5
void func_162() {
	if (func_61()) {
		if (Global_14609 == 0) {
			mobile::_move_finger(1);
		}
		else {
			mobile::_move_finger(2);
		}
	}
}

// Position - 0x51D8
void func_163() {
	func_158();
	if (iLocal_241 == 0 && iLocal_288 > 0) {
		if (func_2(2, Global_14412, 0)) {
			Global_14421 = 1;
			func_59();
			graphics::_push_scaleform_movie_function(Global_14424, "GET_CURRENT_SELECTION");
			uLocal_287 = graphics::_pop_scaleform_movie_function();
			while (!graphics::_0x768FF8961BA904D6(uLocal_287)) {
				system::wait(0);
			}
			iLocal_252 = graphics::_0x2DE7EFA66B906036(uLocal_287);
			if (iLocal_252 > -1 && iLocal_252 < 5) {
				if (Global_14443.f_1 > 3) {
					Global_14443.f_1 = 8;
				}
				iLocal_244 = func_148();
				if (Global_262145.f_4844 && !func_53() && Global_262145.f_4901) {
					iLocal_212 = 3;
					Global_14443.f_1 = 8;
					func_157();
				}
				else if (func_164(iLocal_244)) {
					iLocal_212 = 1;
					func_132();
				}
				else {
					iLocal_212 = 3;
					Global_14443.f_1 = 8;
					func_157();
				}
			}
		}
	}
	else if (func_2(2, Global_14412, 0)) {
		Global_14421 = 1;
		func_131();
	}
}

// Position - 0x52C7
bool func_164(int iParam0) {
	if (func_53() || func_116()) {
		return false;
	}
	if (iParam0 == 0 && (Global_262145.f_4843 == 1 || iLocal_245 == 1)) {
		return false;
	}
	return true;
}

// Position - 0x5308
void func_165() {
	func_158();
	if (iLocal_241 == 0 && iLocal_288 > 0) {
		if (func_2(2, Global_14412, 0)) {
			Global_14421 = 1;
			func_59();
			graphics::_push_scaleform_movie_function(Global_14424, "GET_CURRENT_SELECTION");
			uLocal_287 = graphics::_pop_scaleform_movie_function();
			while (!graphics::_0x768FF8961BA904D6(uLocal_287)) {
				system::wait(0);
			}
			iLocal_251 = graphics::_0x2DE7EFA66B906036(uLocal_287);
			if (iLocal_251 > -1 && iLocal_251 < 20) {
				if (func_94(iLocal_257[iLocal_251])) {
					if (Global_14443.f_1 > 3) {
						Global_14443.f_1 = 8;
					}
					iLocal_244 = func_148();
					if (iLocal_251 == iLocal_253) {
						iLocal_212 = 2;
						func_166();
					}
					else if (iLocal_251 == iLocal_255 && !Global_262145.f_4845) {
						iLocal_212 = 1;
						func_132();
					}
					else if (Global_262145.f_4844 && !func_53() && Global_262145.f_4901) {
						iLocal_212 = 3;
						Global_14443.f_1 = 8;
						func_157();
						bLocal_254 = true;
					}
					else if (func_164(iLocal_244)) {
						iLocal_212 = 1;
						func_132();
						bLocal_254 = true;
					}
					else {
						iLocal_212 = 3;
						Global_14443.f_1 = 8;
						func_157();
						bLocal_254 = true;
					}
				}
			}
		}
	}
	else if (func_2(2, Global_14412, 0)) {
		Global_14421 = 1;
		func_131();
	}
}

// Position - 0x543F
void func_166() {
	if (Global_14443.f_1 != 7) {
		if (Global_14443.f_1 > 3) {
			Global_14443.f_1 = 7;
		}
	}
	func_147(Global_14424, "SET_DATA_SLOT_EMPTY", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	func_146(Global_14424, "SET_DATA_SLOT", 18f, 0f, 0f, -1f, -1f, "CELL_208", 0, 0, 0, 0);
	func_167();
	func_147(Global_14424, "DISPLAY_VIEW", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	func_136(&Local_213);
	if (iLocal_288 == 0) {
		func_133(1, "", 1, "", 4, &Local_221, &iLocal_290);
	}
	else {
		func_133(13, &Local_225, 1, "", 4, &Local_221, &iLocal_290);
	}
	iLocal_212 = 2;
}

// Position - 0x54FD
void func_167() {
	int iVar0;

	iLocal_289 = 0;
	if (iLocal_241 == 0 && func_117()) {
		iVar0 = 0;
		while (iVar0 <= 4) {
			if (func_169(iVar0)) {
				graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(18);
				graphics::_push_scaleform_movie_function_parameter_int(iLocal_289);
				graphics::_push_scaleform_movie_function_parameter_int(0);
				graphics::begin_text_command_scaleform_string(func_168(iVar0));
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
				iLocal_278[iLocal_289] = iVar0;
				iLocal_289++;
			}
			iVar0++;
		}
	}
	else {
		graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(18);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("JIPMP_NA");
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x55A3
char *func_168(int iParam0) {
	switch (iParam0) {
	case 0: return "JIPMP_ARM";

	case 1: return "JIPMP_DARTS";

	case 2: return "JIPMP_GOLF";

	case 3: return "JIPMP_RANG";

	case 4: return "JIPMP_TEN";

	default:
	}
	return "";
}

// Position - 0x55F6
bool func_169(int iParam0) {
	switch (iParam0) {
	case 0:
		if (func_53() || func_116()) {
			return false;
		}
		else {
			return true;
		}
		break;

	case 4:
		if (func_53() || func_116()) {
			return false;
		}
		else {
			return true;
		}
		break;

	case 1: return true;

	case 2: return true;

	case 3: return true;
	}
	return false;
}

// Position - 0x5677
void func_170(int iParam0) {
	if (!network::network_is_in_session()) {
		func_172(1);
		if (iParam0) {
			Global_2443905.f_1.f_2801 = 0;
		}
		func_171();
		func_226();
	}
}

// Position - 0x56A3
void func_171() { gameplay::clear_bit(&Global_2443134.f_2, 11); }

// Position - 0x56B7
void func_172(int iParam0) {
	if (iParam0) {
		func_173();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_154(0)) {
			func_151(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x571A
void func_173() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x5743
bool func_174() {
	if (func_176(935, &Local_246.f_1, &Local_246.f_2, &Local_246.f_4, &Global_2443905.f_1.f_2806)) {
		if (Local_246.f_4) {
			return true;
		}
		else {
			if (Local_246.f_3 > 2) {
				func_175(1200);
				return true;
			}
			Local_246.f_3++;
			Local_246.f_1 = 0;
			Local_246.f_2 = 0;
		}
	}
	return false;
}

// Position - 0x57A0
void func_175(int iParam0) { Global_2443905.f_1.f_2806 = iParam0; }

// Position - 0x57B3
bool func_176(int iParam0, int *iParam1, int *iParam2, int *iParam3, int *iParam4) {
	int iVar0;
	struct<69> Var1;
	struct<69> Var70;
	struct<20> Var139;
	struct<4> Var237;
	struct<13> Var245;

	iVar0 = func_192(iParam0);
	if (iVar0 == -1) {
	}
	else {
		if (!func_191()) {
			Global_1840973.f_11[iVar0] = 1;
			Global_1840973.f_22[iVar0] = 0;
			return true;
		}
		if (!Global_1840973.f_11[iVar0] && Global_1840973.f_22[iVar0] &&
			Global_1840973.f_33[iVar0] == Global_262145.f_151) {
			*iParam4 = Global_1840973[iVar0];
			return true;
		}
		else {
			Var1.f_3.f_1 = 4;
			Var70.f_3.f_1 = 4;
			Var139.f_19.f_1 = 4;
			Var245 = {func_47(player::player_id())};
			Var1 = iParam0;
			if (Var1 >= 1148 && Var1 <= 1197) {
				Var1.f_1 = 1;
				Var1.f_3 = 0;
			}
			else {
				Var1.f_1 = 5;
				Var1.f_3 = 1;
				StringCopy(&Var1.f_3.f_1[0 /*16*/], "SeasonId", 32);
				StringCopy(&Var1.f_3.f_1[0 /*16*/].f_8, "", 32);
				StringIntConCat(&Var1.f_3.f_1[0 /*16*/].f_8, Global_262145.f_151, 32);
			}
			switch (*iParam1) {
			case 0:
				if (func_180(iParam2, iParam3, &Var1, &Var245)) {
					func_179(&Var237, &Var1);
					if (*iParam3 && stats::_0xA0F93D5465B3094D(&Var237)) {
						if (Var237.f_3 > 0) {
							stats::_0x34770B9CE0E03B91(0, &Var139);
							if (gameplay::are_strings_equal(&Var139.f_13, "")) {
								*iParam1 = 1;
								*iParam4 = 0;
							}
							else {
								*iParam4 = stats::_0x88578F6EC36B4A3A(0, 0);
								*iParam1 = 1;
							}
						}
						else {
							*iParam1 = 1;
							*iParam4 = 0;
						}
						Global_1840973[iVar0] = *iParam4;
						Global_1840973.f_33[iVar0] = Global_262145.f_151;
						Global_1840973.f_11[iVar0] = 0;
						stats::_0x71B008056E5692D6();
					}
					else {
						*iParam1 = 1;
						Global_1840973.f_11[iVar0] = 1;
					}
					Global_1840973.f_22[iVar0] = 1;
					func_177(iParam2, iParam3, &Var1);
					Var1 = {Var70};
				}
				break;

			case 1: return true;
			}
		}
	}
	return false;
}

// Position - 0x59AB
void func_177(int *iParam0, int *iParam1, var *uParam2) {
	*iParam0 = 0;
	*iParam1 = 0;
	Global_1835008 = 0;
	func_178(&Global_1835008.f_1);
	stats::leaderboards_read_clear(*uParam2, uParam2->f_1, -1);
}

// Position - 0x59D7
void func_178(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0x59E4
void func_179(var *uParam0, var *uParam1) {
	*uParam0 = *uParam1;
	uParam0->f_1 = uParam1->f_1;
	uParam0->f_2 = 0;
}

// Position - 0x59FF
bool func_180(var *uParam0, int *iParam1, var *uParam2, var uParam3) {
	switch (*uParam0) {
	case 0:
		if (!func_187() && !func_183()) {
			func_181(*uParam2);
			if (stats::leaderboards2_read_by_handle(uParam2, uParam3)) {
				*uParam0++;
			}
			else {
				*iParam1 = 0;
				*uParam0 = 3;
			}
		}
		break;

	case 1:
		if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
			*uParam0++;
		}
		break;

	case 2:
		if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
			*iParam1 = 1;
			*uParam0++;
		}
		else {
			*iParam1 = 0;
			*uParam0++;
		}
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0x5AB3
void func_181(struct<2> Param0, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7,
			  var uParam8, var uParam9, var uParam10, var uParam11, var uParam12, var uParam13, var uParam14,
			  var uParam15, var uParam16, var uParam17, var uParam18, var uParam19, var uParam20, var uParam21,
			  var uParam22, var uParam23, var uParam24, var uParam25, var uParam26, var uParam27, var uParam28,
			  var uParam29, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
			  var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
			  var uParam43, var uParam44, var uParam45, var uParam46, var uParam47, var uParam48, var uParam49,
			  var uParam50, var uParam51, var uParam52, var uParam53, var uParam54, var uParam55, var uParam56,
			  var uParam57, var uParam58, var uParam59, var uParam60, var uParam61, var uParam62, var uParam63,
			  var uParam64, var uParam65, var uParam66, var uParam67, var uParam68) {
	Global_1835008 = 1;
	func_182(&Global_1835008.f_1, 1, 0);
	Global_1835008.f_3 = Param0;
	Global_1835008.f_4 = Param0.f_1;
}

// Position - 0x5ADE
void func_182(var *uParam0, int iParam1, int iParam2) {
	if (network::network_is_game_in_progress() && !iParam1) {
		if (!iParam2) {
			*uParam0 = network::get_network_time();
		}
		else {
			*uParam0 = network::_0x89023FBBF9200E9F();
		}
	}
	else {
		*uParam0 = gameplay::get_game_timer();
	}
	uParam0->f_1 = 1;
}

// Position - 0x5B1B
int func_183() {
	if (ui::is_pause_menu_active() && !func_184()) {
		return 1;
	}
	return 0;
}

// Position - 0x5B39
int func_184() { return func_185(player::player_id()); }

// Position - 0x5B49
int func_185(int iParam0) {
	switch (func_186(iParam0)) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 6:
	case 5:
	case 7:
	case 38:
	case 33:
	case 36:
	case 39: return 0;

	default:
	}
	return 1;
}

// Position - 0x5BA9
int func_186(int iParam0) { return Global_1591201[iParam0 /*602*/].f_188; }

// Position - 0x5BBC
int func_187() {
	if (stats::_0xA31FD15197B192BD() || Global_1835008) {
		func_188();
		return 1;
	}
	return 0;
}

// Position - 0x5BDE
void func_188() {
	if (func_189(&Global_1835008.f_1, 120000, 1)) {
		stats::leaderboards_read_clear(Global_1835008.f_3, Global_1835008.f_4, -1);
		Global_1835008 = 0;
		func_178(&Global_1835008.f_1);
	}
}

// Position - 0x5C19
bool func_189(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_190(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0x5C77
void func_190(var *uParam0, int iParam1, int iParam2) {
	if (uParam0->f_1 == 0) {
		if (network::network_is_game_in_progress() && !iParam1) {
			if (!iParam2) {
				*uParam0 = network::get_network_time();
			}
			else {
				*uParam0 = network::_0x89023FBBF9200E9F();
			}
		}
		else {
			*uParam0 = gameplay::get_game_timer();
		}
		uParam0->f_1 = 1;
	}
}

// Position - 0x5CBC
int func_191() {
	int iVar0;

	iVar0 = player::player_id();
	if (Global_1591201[iVar0 /*602*/].f_39.f_2 == 63 || Global_1591201[iVar0 /*602*/].f_39.f_2 == 62 ||
		Global_1591201[iVar0 /*602*/].f_39.f_2 == 61) {
		return 1;
	}
	return 0;
}

// Position - 0x5D0E
int func_192(int iParam0) {
	switch (iParam0) {
	case 931: return 0;

	case 932: return 1;

	case 933: return 2;

	case 934: return 3;

	case 935: return 4;

	case 936: return 5;

	case 937: return 6;

	case 938: return 7;

	case 939: return 8;

	default:
	}
	if (iParam0 >= 1148 && iParam0 <= 1197) {
		return 9;
	}
	return -1;
}

// Position - 0x5D92
void func_193() {
	if (Global_14443.f_1 != 7) {
		if (Global_14443.f_1 > 3) {
			Global_14443.f_1 = 7;
		}
	}
	func_147(Global_14424, "SET_DATA_SLOT_EMPTY", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	func_146(Global_14424, "SET_DATA_SLOT", 18f, 0f, 0f, -1f, -1f, "CELL_208", 0, 0, 0, 0);
	func_194();
	func_147(Global_14424, "DISPLAY_VIEW", 18f, -1082130432, -1082130432, -1082130432, -1082130432);
	func_136(&Local_213);
	if (iLocal_288 == 0) {
		func_133(1, "", 1, "", 4, &Local_221, &iLocal_290);
	}
	else {
		func_133(13, &Local_225, 1, "", 4, &Local_221, &iLocal_290);
	}
	iLocal_212 = 0;
}

// Position - 0x5E50
void func_194() {
	int iVar0;

	iLocal_288 = 0;
	iLocal_253 = -1;
	iLocal_255 = -1;
	if (iLocal_241 == 0 && func_117()) {
		iVar0 = 0;
		while (iVar0 <= 19) {
			if (func_94(iVar0)) {
				graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(18);
				graphics::_push_scaleform_movie_function_parameter_int(iLocal_288);
				if (iVar0 == 18) {
					iLocal_253 = iLocal_288;
				}
				if (iVar0 == 8) {
					iLocal_255 = iLocal_288;
				}
				graphics::_push_scaleform_movie_function_parameter_int(0);
				graphics::begin_text_command_scaleform_string(func_195(iVar0));
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
				iLocal_257[iLocal_288] = iVar0;
				iLocal_288++;
			}
			iVar0++;
		}
	}
	else {
		graphics::_push_scaleform_movie_function(Global_14424, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(18);
		graphics::_push_scaleform_movie_function_parameter_int(iLocal_288);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::begin_text_command_scaleform_string("JIPMP_NA");
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x5F17
char *func_195(int iParam0) {
	switch (iParam0) {
	case 7: return "JIPMP_ANY";

	case 9: return "JIPMP_RACE";

	case 10: return "JIPMP_DM";

	case 8: return "JIPMP_HEIST";

	case 11: return "JIPMP_MISS";

	case 14: return "JIPMP_MISS_L";

	case 15: return "JIPMP_MISS_C";

	case 13: return "JIPMP_MISS_V";

	case 3:
		if (Global_262145.f_8252) {
			return "JIPMP_ADVSD";
		}
		else {
			return "JIPMP_ADVSR";
		}
		break;

	case 5:
		if (func_62(func_65())) {
			return "JIPMP_STNTAM";
		}
		else {
			return "JIPMP_MISS_NV";
		}
		break;

	case 12: return "JIPMP_MISS_FL";

	case 16: return "JIPMP_SURV";

	case 17: return "JIPMP_PARA";

	case 18: return "JIPMP_MINI";

	case 19: return "JIPMP_PL";

	case 2:
		if (Global_262145.f_8252) {
			return "JIPMP_STNTRD";
		}
		else {
			return "JIPMP_STNTR";
		}
		break;

	case 4: return "JIPMP_STNTPR";

	case 6: return "JIPMP_SVM";

	case 0: return "JIPMP_SVR";
	}
	return "";
}

// Position - 0x6066
int func_196(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (func_197(iParam0) == -1) {
		return 0;
	}
	return 1;
}

// Position - 0x6087
int func_197(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36715[iVar0 /*5*/] != -1) {
			if (iParam0 == Global_36715[iVar0 /*5*/].f_1) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x60D0
void func_198() { Global_970912.f_8 = 0; }

// Position - 0x60DF
void func_199() {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	int iVar5;
	var uVar6;
	int iVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;
	var uVar14;
	var uVar15;
	var uVar16;
	var uVar17;
	struct<13> Var18;
	struct<16> Var31;
	var uVar47;
	var uVar48;
	var uVar49;
	var uVar50;
	var uVar51;
	var uVar52;
	var uVar53;
	int iVar54;
	var uVar55;
	int iVar56;
	int iVar57;

	iVar5 = -1;
	iVar7 = -1;
	iVar54 = -1;
	Global_2443905.f_5553 = {Var18};
	iVar56 = 0;
	while (iVar56 <= 31) {
		Global_2443905.f_1.f_844[iVar56 /*57*/] = {Var18};
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_13 = {Var31};
		StringCopy(&Global_2443905.f_1.f_844[iVar56 /*57*/].f_29, "", 16);
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_44 = uVar49;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_45 = uVar50;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_46 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_47 = uVar51;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_50 = uVar52;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_55 = uVar53;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_48 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_49 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_54 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_56 = uVar53;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_53 = uVar55;
		iVar57 = 0;
		while (iVar57 <= 1) {
			Global_2443905.f_1.f_844[iVar56 /*57*/].f_33[iVar57] = uVar47;
			iVar57++;
		}
		iVar57 = 0;
		while (iVar57 <= 6) {
			Global_2443905.f_1.f_844[iVar56 /*57*/].f_36[iVar57] = uVar48;
			iVar57++;
		}
		iVar56++;
	}
	iVar56 = 0;
	while (iVar56 <= 1) {
		Global_2443905.f_1.f_2669[iVar56 /*57*/] = {Var18};
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_13 = {Var31};
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_44 = uVar49;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_45 = uVar50;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_47 = uVar51;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_50 = uVar52;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_55 = uVar53;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_56 = uVar53;
		iVar57 = 0;
		while (iVar57 <= 1) {
			Global_2443905.f_1.f_2669[iVar56 /*57*/].f_33[iVar57] = uVar47;
			iVar57++;
		}
		iVar57 = 0;
		while (iVar57 <= 6) {
			Global_2443905.f_1.f_2669[iVar56 /*57*/].f_36[iVar57] = uVar48;
			iVar57++;
		}
		iVar56++;
	}
	Global_2443905.f_1.f_2797 = uVar0;
	Global_2443905.f_1.f_2798 = uVar1;
	Global_2443905.f_1.f_2799 = uVar2;
	Global_2443905.f_1.f_2801 = uVar3;
	Global_2443905.f_1.f_2804 = uVar4;
	Global_2443905.f_1.f_2805 = 0;
	Global_2443905.f_1.f_2807 = iVar5;
	Global_2443905.f_1.f_2808 = uVar6;
	Global_2443905.f_1.f_2809 = uVar6;
	Global_2443905.f_1.f_2810 = iVar7;
	Global_2443905.f_1.f_2811 = uVar8;
	Global_2443905.f_1.f_2812 = uVar9;
	Global_2443905.f_1.f_2813 = uVar10;
	Global_2443905.f_1.f_2814 = uVar11;
	Global_2443905.f_1.f_2815 = uVar12;
	Global_2443905.f_1.f_2816 = uVar13;
	Global_2443905.f_1.f_2817 = uVar14;
	Global_2443905.f_1.f_2821 = iVar54;
	Global_2443905.f_1.f_2818 = uVar15;
	Global_2443905.f_1.f_2819 = uVar16;
	Global_2443905.f_1.f_2820 = uVar17;
	Global_2443134.f_718 = 0;
}

// Position - 0x6437
void func_200() { gameplay::set_bit(&Global_2443134.f_2, 12); }

// Position - 0x644B
void func_201() { Global_979732 = -1; }

// Position - 0x6458
int func_202() { return Global_979732; }

// Position - 0x6464
void func_203(int iParam0) {
	var uVar0;

	if (func_221() && !func_220()) {
		func_171();
		func_219();
	}
	else {
		uVar0 = func_218();
		func_217();
		func_215(1);
		func_214();
		func_213();
		func_212();
		if (uVar0 && !iParam0) {
			func_85();
		}
	}
	if (Global_2450895.f_8) {
		func_211();
	}
	func_210();
	func_209();
	func_208();
	func_207();
	if (!func_206()) {
		func_205();
		func_75(0);
	}
	func_219();
	func_204(0);
	if (network::network_is_game_in_progress()) {
		network::_0xCFEB46DCD7D8D5EB(0);
	}
}

// Position - 0x64F7
void func_204(int iParam0) { Global_2443134.f_766 = iParam0; }

// Position - 0x6508
void func_205() { Global_2443134.f_5 = -1; }

// Position - 0x6517
bool func_206() { return Global_2443134.f_615; }

// Position - 0x6526
void func_207() { Global_2443134.f_28 = 30; }

// Position - 0x6536
void func_208() { Global_2443134.f_613 = 0; }

// Position - 0x6546
void func_209() { Global_2443134.f_596 = 0; }

// Position - 0x6556
void func_210() { gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 15); }

// Position - 0x6573
void func_211() {
	Global_2450895.f_8 = 0;
	Global_2450895.f_7 = 0;
}

// Position - 0x6589
void func_212() { gameplay::clear_bit(&Global_2443134, 7); }

// Position - 0x659A
void func_213() { gameplay::clear_bit(&Global_2443134, 6); }

// Position - 0x65AB
void func_214() {
	Global_2443134 = 0;
	Global_2443134.f_2 = 0;
	Global_2443134.f_3 = 0;
}

// Position - 0x65C6
void func_215(int iParam0) {
	struct<57> Var0;
	int iVar57;

	Global_2443905.f_1.f_2797 = 0;
	Global_2443905.f_1.f_2798 = 0;
	Global_2443905.f_1.f_2820 = 0;
	Global_2443905.f_1.f_2804 = 0;
	Global_2443905.f_1.f_2805 = 0;
	Global_2443905.f_1.f_2808 = 0;
	Global_2443905.f_1.f_2809 = 0;
	Global_2443905.f_1.f_2807 = -1;
	Global_2443905.f_1.f_2810 = -1;
	Global_2443905.f_1.f_2812 = 0;
	Global_2443905.f_1.f_2813 = 0;
	Global_2443905.f_1.f_2814 = 0;
	Global_2443905.f_1.f_2815 = 0;
	Global_2443905.f_1.f_2816 = 0;
	Global_2443905.f_1.f_2817 = 0;
	Global_2443905.f_1.f_2821 = -1;
	if (iParam0) {
		Global_2443905.f_1.f_2818 = -1;
		Global_2443905.f_1.f_2819 = -1;
	}
	Global_2443905.f_1.f_2840 = 0;
	func_216();
	Var0.f_33 = 2;
	Var0.f_36 = 7;
	iVar57 = 0;
	while (iVar57 <= 31) {
		Global_2443905.f_1.f_844[iVar57 /*57*/] = {Var0};
		iVar57++;
	}
	Global_2440075.f_32 = -1;
}

// Position - 0x66D6
void func_216() { Global_2440075.f_31 = 0; }

// Position - 0x66E5
void func_217() {
	struct<13> Var0;
	int iVar13;

	iVar13 = 0;
	while (iVar13 < 32) {
		Global_2440888[iVar13 /*37*/] = {Var0};
		StringCopy(&Global_2440888[iVar13 /*37*/].f_13, "", 64);
		StringCopy(&Global_2440888[iVar13 /*37*/].f_29, "", 16);
		Global_2440888[iVar13 /*37*/].f_33 = 0;
		Global_2440888[iVar13 /*37*/].f_34 = 0;
		Global_2440888[iVar13 /*37*/].f_35 = 0;
		iVar13++;
	}
	Global_2440888.f_1185 = 0;
	Global_2440888.f_1186 = 0;
}

// Position - 0x675F
var func_218() { return gameplay::is_bit_set(Global_2443134.f_3, 2); }

// Position - 0x6772
void func_219() { gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 5); }

// Position - 0x678E
bool func_220() { return gameplay::is_bit_set(Global_2443134.f_2, 27); }

// Position - 0x67A2
int func_221() {
	if (func_225() || func_224() || func_223() || func_222()) {
		return 1;
	}
	return 0;
}

// Position - 0x67D4
var func_222() { return gameplay::is_bit_set(Global_2443134, 1); }

// Position - 0x67E5
var func_223() { return gameplay::is_bit_set(Global_2443134, 2); }

// Position - 0x67F6
var func_224() { return gameplay::is_bit_set(Global_2443134, 20); }

// Position - 0x6808
var func_225() { return Global_2443134.f_577; }

// Position - 0x6817
void func_226() {
	func_149();
	script::terminate_this_thread();
}

// Position - 0x6827
bool func_227() { return Global_2443134.f_570; }

// Position - 0x6836
bool func_228() { return gameplay::is_bit_set(Global_2443134.f_2, 11); }

// Position - 0x684A
void func_229(int *iParam0) { *iParam0 = 0; }

// Position - 0x6856
void func_230() { Global_2443905.f_1.f_2806 = 0; }

// Position - 0x6868
int func_231(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	if (!network::network_is_signed_in()) {
		return 12;
	}
	if (!network::network_is_signed_online()) {
		return 12;
	}
	if (network::network_is_game_in_progress()) {
		if (player::get_player_wanted_level(player::player_id()) > 0) {
			if (network::network_is_signed_online()) {
				if (func_44(1) < func_258(iParam1, iVar0, 0, -1) + func_48(20)) {
					return 1;
				}
			}
		}
		if (func_22(player::player_id(), 1, 1)) {
			if (!player::is_player_control_on(player::player_id())) {
				return 6;
			}
		}
		else {
			return 6;
		}
		if (!func_108(2, 0, 0)) {
			return 4;
		}
		if (func_155()) {
			return 2;
		}
		if (network::network_is_signed_online()) {
			if (func_44(1) < func_258(iParam1, iVar0, 0, -1)) {
				return 3;
			}
		}
		if (func_257()) {
			return 7;
		}
		if (gameplay::is_bit_set(Global_2494199.f_743, 2)) {
			return 8;
		}
		if (Global_1591201[player::player_id() /*602*/] == 14 || Global_1591201[player::player_id() /*602*/] == 15 ||
			Global_1591201[player::player_id() /*602*/] == 13 || Global_1591201[player::player_id() /*602*/] == 6 ||
			Global_1591201[player::player_id() /*602*/] == 5 || Global_1591201[player::player_id() /*602*/] == 32 ||
			func_252() || Global_1591201[player::player_id() /*602*/].f_493 == 1 ||
			func_247(player::player_ped_id(), 1215605247, 0, uParam0, 0, 500, 1, 0) ||
			func_246(player::player_id(), 0) || func_243(player::player_id(), 1) ||
			Global_1591201[player::player_id() /*602*/] == 148) {
			return 9;
		}
		if (gameplay::is_bit_set(Global_2359301, 7)) {
			return 10;
		}
		if (G_DisableMessagesAndCalls2 == 1) {
			return 11;
		}
		if (Global_1574357 && ui::_0x4167EFE0527D706E() && ui::is_pause_menu_active()) {
			if (Global_1574324.f_14 == -2 || Global_1574324.f_14 == -3 || Global_1574324.f_14 == 0) {
				return 60;
			}
			if (!Global_262145.f_5406) {
				return 61;
			}
			if (!func_143()) {
				return 62;
			}
			if (Global_1574324.f_14 == -4) {
				return 63;
			}
			if (func_139()) {
				return 64;
			}
		}
		else {
			Global_1574357 = 0;
		}
	}
	else if (func_240()) {
		iVar1 = func_235(0, 0, 1);
		if (iVar1 == -1) {
			return 5;
		}
		else {
			if (!func_234(iVar1)) {
				return 4;
			}
			if (network::network_is_signed_online()) {
				if (func_44(1) < func_258(iParam1, iVar0, 0, -1)) {
					return 3;
				}
			}
			if (func_257()) {
				return 7;
			}
		}
	}
	else if (!func_232(1, 0) && !func_232(1, 1)) {
		return 5;
	}
	else if (func_232(1, 0) && !func_232(1, 1)) {
	}
	else if (!func_232(1, 0) && func_232(1, 1)) {
	}
	return 0;
}

// Position - 0x6B71
bool func_232(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam1 == -1) {
		iParam1 = func_41();
	}
	iVar0 = func_233(iParam1);
	iVar1 = gameplay::get_profile_setting(iVar0);
	return gameplay::is_bit_set(iVar1, iParam0);
}

// Position - 0x6B9D
int func_233(int iParam0) {
	int iVar0;

	if (iParam0 == -1) {
		iParam0 = func_41();
	}
	switch (iParam0) {
	case 0: iVar0 = 914; break;

	case 1: iVar0 = 915; break;

	case 2: iVar0 = 916; break;

	case 3: iVar0 = 917; break;

	case 4: iVar0 = 918; break;
	}
	return iVar0;
}

// Position - 0x6C00
int func_234(int iParam0) {
	if (Global_1312446) {
		return 1;
	}
	if (func_110()) {
		return 1;
	}
	if (func_116()) {
		return 1;
	}
	return func_115(119, iParam0);
}

// Position - 0x6C31
int func_235(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = iParam0;
	if (iParam1 == 0) {
	}
	iVar2 = func_41();
	if (func_239(iVar2) == 0) {
		iVar1 = 0;
		while (iVar1 <= 1) {
			iVar0 = iVar1;
			if (func_239(iVar0) && func_237(func_238(iVar0, 0))) {
				iVar1 = 2;
			}
			else if (iVar0 == 1) {
				if (iParam2 == 0) {
					iVar0 = 0;
				}
				else {
					iVar0 = -1;
				}
			}
			iVar1++;
		}
	}
	else {
		iVar0 = iVar2;
	}
	if (func_236(iVar0)) {
		iVar0 = -1;
	}
	if (iVar0 == -1 && iParam2 == 0) {
		iVar0 = 0;
	}
	return iVar0;
}

// Position - 0x6CC5
bool func_236(int iParam0) { return Global_1315261[iParam0 + 1]; }

// Position - 0x6CD7
int func_237(int iParam0) {
	if (iParam0 == 8) {
		return 1;
	}
	if (iParam0 == 9) {
		return 1;
	}
	return 0;
}

// Position - 0x6CF6
int func_238(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_41();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x6D37
int func_239(int iParam0) {
	if (func_115(76, iParam0) == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x6D53
bool func_240() {
	if (func_242() && func_241(0)) {
		return true;
	}
	return false;
}

// Position - 0x6D71
var func_241(int iParam0) { return Global_1312373[iParam0]; }

// Position - 0x6D81
var func_242() { return func_241(func_41() + 1); }

// Position - 0x6D93
int func_243(int iParam0, int iParam1) {
	if (iParam1) {
		if (func_244(iParam0)) {
			return 1;
		}
	}
	if (Global_1591201[iParam0 /*602*/] == -1) {
		return 0;
	}
	return 1;
}

// Position - 0x6DBF
bool func_244(int iParam0) { return func_245(iParam0); }

// Position - 0x6DCD
var func_245(int iParam0) { return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_13.f_1, 0); }

// Position - 0x6DE7
bool func_246(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_211, iParam1); }

// Position - 0x6E00
int func_247(int iParam0, int iParam1, int iParam2, var *uParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	int iVar1;
	var uVar2;
	struct<8> Var3;

	if (!func_251(uParam3)) {
		func_190(uParam3, 0, 0);
	}
	func_250(&Var3, iParam1);
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (func_248(iParam0, iParam1, 30)) {
				if (entity::is_entity_a_ped(iParam0)) {
					iVar0 = entity::get_ped_index_from_entity_index(iParam0);
					if (!ped::is_ped_injured(iVar0)) {
						if (ped::is_ped_a_player(iVar0)) {
							uVar2 = network::network_get_player_index_from_ped(iVar0);
							if (iParam2) {
								if (object::_0x024A60DEB0EA69F0(iParam1, uVar2, iParam4, -1)) {
									if (iParam7 ||
										!object::_0x1761DC5D8471CBAA(iParam1, uVar2, 2) &&
											!(Var3.f_7 != 0 && object::_0x1761DC5D8471CBAA(iParam1, uVar2, 3))) {
										if (iParam6) {
											return 1;
										}
										else if (iParam5 <= 0 ||
												 gameplay::absi(network::get_time_difference(
													 network::get_network_time(), *uParam3)) >= iParam5) {
											return 1;
										}
										else {
											return 0;
										}
									}
								}
							}
							else if (object::_0x024A60DEB0EA69F0(iParam1, uVar2, iParam4, -1)) {
								if (iParam6) {
									return 1;
								}
								else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
															 network::get_network_time(), *uParam3)) >= iParam5) {
									return 1;
								}
								else {
									return 0;
								}
							}
							else if (object::_0x1761DC5D8471CBAA(iParam1, uVar2, 2)) {
								if (iParam6) {
									return 1;
								}
								else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
															 network::get_network_time(), *uParam3)) >= iParam5) {
									return 1;
								}
								else {
									return 0;
								}
							}
							else if (Var3.f_7 != 0 && object::_0x1761DC5D8471CBAA(iParam1, uVar2, 3)) {
								if (iParam6) {
									return 1;
								}
								else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
															 network::get_network_time(), *uParam3)) >= iParam5) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
						else if (ped::is_ped_in_any_vehicle(iVar0, 0)) {
							iVar1 = ped::get_vehicle_ped_is_in(iVar0, 0);
							if (entity::does_entity_exist(iVar1)) {
								if (iParam2) {
									if (object::_0x372EF6699146A1E4(iParam1, iVar1, iParam4, -1)) {
										if (iParam7 ||
											!object::_0xF0EED5A6BC7B237A(iParam1, iVar1, 2) &&
												!(Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iVar1, 3))) {
											if (iParam6) {
												return 1;
											}
											else if (iParam5 <= 0 ||
													 gameplay::absi(network::get_time_difference(
														 network::get_network_time(), *uParam3)) >= iParam5) {
												return 1;
											}
											else {
												return 0;
											}
										}
									}
								}
								else if (object::_0x372EF6699146A1E4(iParam1, iVar1, iParam4, -1)) {
									if (iParam6) {
										return 1;
									}
									else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
																 network::get_network_time(), *uParam3)) >= iParam5) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else if (object::_0xF0EED5A6BC7B237A(iParam1, iVar1, 2)) {
									if (iParam6) {
										return 1;
									}
									else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
																 network::get_network_time(), *uParam3)) >= iParam5) {
										return 1;
									}
									else {
										return 0;
									}
								}
								else if (Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iVar1, 3)) {
									if (iParam6) {
										return 1;
									}
									else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
																 network::get_network_time(), *uParam3)) >= iParam5) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
						}
						else if (iParam2) {
							if (object::_0x372EF6699146A1E4(iParam1, iParam0, iParam4, -1)) {
								if (iParam7 ||
									!object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 2) &&
										!(Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 3))) {
									if (iParam6) {
										return 1;
									}
									else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
																 network::get_network_time(), *uParam3)) >= iParam5) {
										return 1;
									}
									else {
										return 0;
									}
								}
							}
						}
						else if (object::_0x372EF6699146A1E4(iParam1, iParam0, iParam4, -1)) {
							if (iParam6) {
								return 1;
							}
							else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
														 network::get_network_time(), *uParam3)) >= iParam5) {
								return 1;
							}
							else {
								return 0;
							}
						}
						else if (object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 2)) {
							if (iParam6) {
								return 1;
							}
							else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
														 network::get_network_time(), *uParam3)) >= iParam5) {
								return 1;
							}
							else {
								return 0;
							}
						}
						else if (Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 3)) {
							if (iParam6) {
								return 1;
							}
							else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
														 network::get_network_time(), *uParam3)) >= iParam5) {
								return 1;
							}
							else {
								return 0;
							}
						}
					}
				}
				else if (entity::is_entity_a_vehicle(iParam0) || entity::is_entity_an_object(iParam0)) {
					if (iParam2) {
						if (object::_0x372EF6699146A1E4(iParam1, iParam0, iParam4, -1)) {
							if (iParam7 || !object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 2) &&
											   !(Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 3))) {
								if (iParam6) {
									return 1;
								}
								else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
															 network::get_network_time(), *uParam3)) >= iParam5) {
									return 1;
								}
								else {
									return 0;
								}
							}
						}
					}
					else if (object::_0x372EF6699146A1E4(iParam1, iParam0, iParam4, -1)) {
						if (iParam6) {
							return 1;
						}
						else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
													 network::get_network_time(), *uParam3)) >= iParam5) {
							return 1;
						}
						else {
							return 0;
						}
					}
					else if (object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 2)) {
						if (iParam6) {
							return 1;
						}
						else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
													 network::get_network_time(), *uParam3)) >= iParam5) {
							return 1;
						}
						else {
							return 0;
						}
					}
					else if (Var3.f_7 != 0 && object::_0xF0EED5A6BC7B237A(iParam1, iParam0, 3)) {
						if (iParam6) {
							return 1;
						}
						else if (iParam5 <= 0 || gameplay::absi(network::get_time_difference(
													 network::get_network_time(), *uParam3)) >= iParam5) {
							return 1;
						}
						else {
							return 0;
						}
					}
				}
			}
		}
	}
	func_178(uParam3);
	return 0;
}

// Position - 0x7403
bool func_248(int iParam0, int iParam1, int iParam2) {
	if (iParam1 != -1) {
		if (gameplay::get_distance_between_coords(entity::get_entity_coords(iParam0, 1), func_249(iParam1), 1) <=
			IntToFloat(iParam2)) {
			return true;
		}
	}
	return false;
}

// Position - 0x742F
Vector3 func_249(int iParam0) {
	switch (iParam0) {
	case 1215605247: return 1204.429f, -3110.847f, 4.3988f;

	case -1710530912: return 725.1831f, -1089.349f, 21.1692f;

	case 1131590004: return -1164.887f, -2011.105f, 12.25371f;

	case 916723671: return -330.44f, -143.39f, 39.33f;

	case 1340820069: return 106.28f, 6620.01f, 32.12f;

	case -866958545: return 1182.65f, 2641.9f, 38.05f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x74E3
void func_250(var *uParam0, int iParam1) {
	switch (iParam1) {
	case 0:
	case 1215605247:
		*uParam0 = 99;
		uParam0->f_1 = 1215605247;
		uParam0->f_2 = 0;
		uParam0->f_3 = {1204.429f, -3110.847f, 4.3988f};
		uParam0->f_6 = -247372382;
		uParam0->f_7 = 0;
		uParam0->f_8 = "MP_GAR_SIMEON";
		uParam0->f_9.f_1 = {1210.884f, -3122.402f, 5.2118f};
		uParam0->f_9.f_4 = {4.0534f, 0f, 32.6363f};
		uParam0->f_9.f_7 = 32.498f;
		uParam0->f_9.f_8 = {1210.884f, -3122.402f, 5.2118f};
		uParam0->f_9.f_11 = {4.0534f, 0f, 32.6363f};
		uParam0->f_9.f_14 = 32.498f;
		uParam0->f_27 = {1204.157f, -3122.599f, 3.795331f};
		uParam0->f_27.f_3 = {1204.24f, -3099.772f, 8.400777f};
		uParam0->f_27.f_6 = 7f;
		return;

	case 1:
	case -1710530912:
		*uParam0 = 99;
		uParam0->f_1 = -1710530912;
		uParam0->f_2 = 1;
		uParam0->f_3 = {725.1831f, -1089.349f, 21.1692f};
		uParam0->f_7 = 0;
		uParam0->f_8 = "MP_GAR_PNS_2";
		uParam0->f_9.f_1 = {734.3793f, -1078.791f, 23.4305f};
		uParam0->f_9.f_4 = {-16.432f, 0f, -19.7978f};
		uParam0->f_9.f_7 = 60.0199f;
		uParam0->f_9.f_8 = {734.3027f, -1079.004f, 23.4973f};
		uParam0->f_9.f_11 = {-16.432f, 0f, -19.7978f};
		uParam0->f_9.f_14 = 60.0199f;
		uParam0->f_27 = {738.8857f, -1088.516f, 20.55957f};
		uParam0->f_27.f_3 = {718.613f, -1088.78f, 24.83263f};
		uParam0->f_27.f_6 = 7f;
		return;

	case 2:
	case 1131590004:
		*uParam0 = 99;
		uParam0->f_1 = 1131590004;
		uParam0->f_2 = 2;
		uParam0->f_3 = {-1164.887f, -2011.105f, 12.25371f};
		uParam0->f_7 = 0;
		uParam0->f_8 = "MP_GAR_NEUT_PNS_3";
		uParam0->f_9.f_1 = {-1161.774f, -2010.27f, 14.2468f};
		uParam0->f_9.f_4 = {-17.3415f, 0f, 113.6889f};
		uParam0->f_9.f_7 = 64.5334f;
		uParam0->f_9.f_8 = {-1161.639f, -2010.211f, 14.2928f};
		uParam0->f_9.f_11 = {-17.3415f, 0f, 113.6889f};
		uParam0->f_9.f_14 = 64.5334f;
		uParam0->f_27 = {-1169.723f, -2015.923f, 11.50441f};
		uParam0->f_27.f_3 = {-1160.558f, -2007.005f, 15.68027f};
		uParam0->f_27.f_6 = 5.5f;
		return;

	case 3:
	case 916723671:
		*uParam0 = 99;
		uParam0->f_1 = 916723671;
		uParam0->f_2 = 3;
		uParam0->f_3 = {-330.44f, -143.39f, 39.33f};
		uParam0->f_7 = 0;
		uParam0->f_8 = "MP_GAR_PNS_4";
		uParam0->f_9.f_1 = {-332.1567f, -141.0546f, 40.2864f};
		uParam0->f_9.f_4 = {-20.6629f, 0f, -134.7887f};
		uParam0->f_9.f_7 = 60.0241f;
		uParam0->f_9.f_8 = {-332.3621f, -140.8507f, 40.3956f};
		uParam0->f_9.f_11 = {-20.6629f, 0f, -134.7887f};
		uParam0->f_9.f_14 = 60.0241f;
		uParam0->f_27 = {-323.7998f, -146.2539f, 37.81492f};
		uParam0->f_27.f_3 = {-334.3432f, -141.7261f, 40.75964f};
		uParam0->f_27.f_6 = 5.5f;
		return;

	case 4:
	case 1340820069:
		*uParam0 = 99;
		uParam0->f_1 = 1340820069;
		uParam0->f_2 = 4;
		uParam0->f_3 = {106.28f, 6620.01f, 32.12f};
		uParam0->f_7 = 0;
		uParam0->f_8 = "MP_GAR_PNS_5";
		uParam0->f_9.f_1 = {106.688f, 6617.322f, 32.5026f};
		uParam0->f_9.f_4 = {-10.7437f, 0f, 21.7154f};
		uParam0->f_9.f_7 = 67.562f;
		uParam0->f_9.f_8 = {106.7971f, 6617.048f, 32.5586f};
		uParam0->f_9.f_11 = {-10.7437f, 0f, 21.7154f};
		uParam0->f_9.f_14 = 67.562f;
		uParam0->f_27 = {100.9759f, 6625.046f, 30.60301f};
		uParam0->f_27.f_3 = {111.2522f, 6615.657f, 33.62929f};
		uParam0->f_27.f_6 = 5.5f;
		return;

	case 5:
	case -866958545:
		*uParam0 = 99;
		uParam0->f_1 = -866958545;
		uParam0->f_2 = 5;
		uParam0->f_3 = {1182.65f, 2641.9f, 38.05f};
		uParam0->f_7 = 0;
		uParam0->f_9.f_1 = {1184.206f, 2644.004f, 38.7458f};
		uParam0->f_9.f_4 = {-15.4014f, 0f, 161.4493f};
		uParam0->f_9.f_7 = 67.3374f;
		uParam0->f_9.f_8 = {1184.345f, 2644.418f, 38.866f};
		uParam0->f_9.f_11 = {-15.4014f, 0f, 161.4493f};
		uParam0->f_9.f_14 = 67.3374f;
		uParam0->f_27 = {1182.835f, 2634.775f, 36.55006f};
		uParam0->f_27.f_3 = {1182.578f, 2647.955f, 39.58602f};
		uParam0->f_27.f_6 = 5.5f;
		return;
	}
}

// Position - 0x7A5B
bool func_251(var *uParam0) { return uParam0->f_1; }

// Position - 0x7A67
int func_252() {
	if (func_246(player::player_id(), 8)) {
		return 1;
	}
	if (func_246(player::player_id(), 10)) {
		return 1;
	}
	if (func_246(player::player_id(), 12)) {
		return 1;
	}
	if (func_246(player::player_id(), 14)) {
		return 1;
	}
	if (func_246(player::player_id(), 13)) {
		return 1;
	}
	if (func_256()) {
		return 1;
	}
	if (func_255()) {
		return 1;
	}
	if (!func_110() && !func_116()) {
		if (!func_254()) {
			if (!func_253()) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x7B01
int func_253() {
	int iVar0;

	if (gameplay::is_bit_set(Global_2494199.f_1639, 7)) {
		return 1;
	}
	iVar0 = Global_1363267[func_64(-1)];
	if (gameplay::is_bit_set(iVar0, 6)) {
		gameplay::set_bit(&Global_2494199.f_1639, 7);
		return 1;
	}
	if (func_110()) {
		return 1;
	}
	if (func_116()) {
		return 1;
	}
	return 0;
}

// Position - 0x7B5A
bool func_254() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 2); }

// Position - 0x7B74
bool func_255() {
	if (gameplay::is_bit_set(Global_2494199.f_1639, 28) && !gameplay::is_bit_set(Global_2494199.f_1639, 29)) {
		return true;
	}
	return false;
}

// Position - 0x7BA4
bool func_256() { return gameplay::is_bit_set(Global_2494199.f_1640, 3); }

// Position - 0x7BB8
bool func_257() { return Global_91543.f_304 > 0; }

// Position - 0x7BC9
int func_258(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (Global_2391003 && !iParam2) {
		return 0;
	}
	if (func_244(player::player_id())) {
		return Global_262145.f_5556;
	}
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 5: return Global_262145.f_4441;

		case 6: return Global_262145.f_4442;

		case 4: return Global_262145.f_4443;

		case 9: return Global_262145.f_4444;

		default:
		}
		return 0;

	case 1: return Global_262145.f_4439;

	case 3: return Global_262145.f_4438;

	case 6: return 500;

	case 8:
		if (iParam3 == 1) {
			return 0;
		}
		else {
			return Global_262145.f_4440;
		}
		break;

	case 2:
		if (iParam3 == 1) {
			return Global_262145.f_2342;
		}
		else {
			switch (Global_1633501.f_41912) {
			case 4:
			case 5: return Global_262145.f_4435 + Global_262145.f_2342;

			case 2:
			case 3: return Global_262145.f_4436 + Global_262145.f_2342;

			case 12:
			case 13: return Global_262145.f_4437 + Global_262145.f_2342;

			default:
			}
			return Global_262145.f_4434 + Global_262145.f_2342;
		}
		break;
	}
	return 0;
}

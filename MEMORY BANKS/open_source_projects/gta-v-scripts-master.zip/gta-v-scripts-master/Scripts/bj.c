#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
vector3 vLocal_22 = {0f, 0f, 0f};
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int iLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 10;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 2;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 8;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 8;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
float fLocal_92 = 0f;
var uLocal_93 = 0;
var uLocal_94 = 0;
float fLocal_95 = 0f;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
float fLocal_98 = 0f;
float fLocal_99 = 0f;
var uLocal_100 = 0;
struct<68> Local_101 = {
  0, 0, 1132396544, 1132396544, 1132396544, 0, -1082130432, 0, 0, 8, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
      0, 0, -1, 1092616192
};
var uLocal_169 = 0;
var uLocal_170 = 0;
vector3 vLocal_171 = {0f, 0f, 0f};
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var *uLocal_177 = NULL;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 4;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 2;
var uLocal_291 = 0;
var uLocal_292 = 4;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
var uLocal_332 = 0;
var uLocal_333 = 0;
var uLocal_334 = 0;
var uLocal_335 = 0;
var uLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 4;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
var uLocal_367 = 0;
var uLocal_368 = 0;
var uLocal_369 = 0;
var uLocal_370 = 0;
var uLocal_371 = 0;
var uLocal_372 = 0;
var uLocal_373 = 0;
var uLocal_374 = 0;
var uLocal_375 = 0;
var uLocal_376 = 0;
var uLocal_377 = 0;
var uLocal_378 = 0;
var uLocal_379 = 0;
var uLocal_380 = 0;
var uLocal_381 = 0;
var uLocal_382 = 0;
var uLocal_383 = 0;
var uLocal_384 = 0;
var uLocal_385 = 0;
var uLocal_386 = 0;
var uLocal_387 = 0;
var uLocal_388 = 0;
var uLocal_389 = 0;
var uLocal_390 = 0;
var uLocal_391 = 0;
var uLocal_392 = 0;
var uLocal_393 = 0;
var uLocal_394 = 0;
var uLocal_395 = 0;
var uLocal_396 = 0;
var uLocal_397 = 0;
var uLocal_398 = 0;
var uLocal_399 = 0;
var uLocal_400 = 0;
var uLocal_401 = 0;
var uLocal_402 = 0;
var uLocal_403 = 0;
var uLocal_404 = 0;
var uLocal_405 = 0;
var uLocal_406 = 0;
var uLocal_407 = 0;
var uLocal_408 = 0;
var uLocal_409 = 0;
var uLocal_410 = 0;
var uLocal_411 = 0;
var uLocal_412 = 0;
var uLocal_413 = 0;
var uLocal_414 = 0;
var uLocal_415 = 0;
var uLocal_416 = 0;
var uLocal_417 = 0;
var uLocal_418 = 0;
var uLocal_419 = 0;
var uLocal_420 = 0;
var uLocal_421 = 0;
var uLocal_422 = 0;
var uLocal_423 = 0;
var uLocal_424 = 0;
var uLocal_425 = 0;
var uLocal_426 = 0;
var uLocal_427 = 0;
var uLocal_428 = 0;
var uLocal_429 = 12;
var uLocal_430 = 0;
var uLocal_431 = 0;
var uLocal_432 = 0;
var uLocal_433 = 0;
var uLocal_434 = 0;
var uLocal_435 = 0;
var uLocal_436 = 0;
var uLocal_437 = 0;
var uLocal_438 = 0;
var uLocal_439 = 0;
var uLocal_440 = 0;
var uLocal_441 = 0;
var uLocal_442 = 0;
var uLocal_443 = 0;
var uLocal_444 = 0;
var uLocal_445 = 0;
var uLocal_446 = 0;
var uLocal_447 = 0;
var uLocal_448 = 0;
var uLocal_449 = 0;
var uLocal_450 = 0;
var uLocal_451 = 0;
var uLocal_452 = 0;
var uLocal_453 = 0;
var uLocal_454 = 0;
var uLocal_455 = 0;
var uLocal_456 = 0;
var uLocal_457 = 0;
var uLocal_458 = 0;
var uLocal_459 = 0;
var uLocal_460 = 0;
var uLocal_461 = 0;
var uLocal_462 = 0;
var uLocal_463 = 0;
var uLocal_464 = 0;
var uLocal_465 = 0;
var uLocal_466 = 0;
var uLocal_467 = 0;
var uLocal_468 = 0;
var uLocal_469 = 0;
var uLocal_470 = 0;
var uLocal_471 = 0;
var uLocal_472 = 0;
var uLocal_473 = 0;
var uLocal_474 = 0;
var uLocal_475 = 0;
var uLocal_476 = 0;
var uLocal_477 = 0;
var uLocal_478 = 0;
var uLocal_479 = 0;
var uLocal_480 = 0;
var uLocal_481 = 0;
var uLocal_482 = 0;
var uLocal_483 = 0;
var uLocal_484 = 0;
var uLocal_485 = 0;
var uLocal_486 = 0;
var uLocal_487 = 0;
var uLocal_488 = 0;
var uLocal_489 = 0;
var uLocal_490 = 0;
var uLocal_491 = 0;
var uLocal_492 = 0;
var uLocal_493 = 0;
var uLocal_494 = 0;
var uLocal_495 = 0;
var uLocal_496 = 0;
var uLocal_497 = 0;
var uLocal_498 = 0;
var uLocal_499 = 0;
var uLocal_500 = 0;
var uLocal_501 = 0;
var uLocal_502 = 0;
var uLocal_503 = 0;
var uLocal_504 = 0;
var uLocal_505 = 0;
var uLocal_506 = 0;
var uLocal_507 = 0;
var uLocal_508 = 0;
var uLocal_509 = 0;
var uLocal_510 = 0;
var uLocal_511 = 0;
var uLocal_512 = 0;
var uLocal_513 = 0;
var uLocal_514 = 0;
var uLocal_515 = 0;
var uLocal_516 = 0;
var uLocal_517 = 0;
var uLocal_518 = 0;
var uLocal_519 = 0;
var uLocal_520 = 0;
var uLocal_521 = 0;
var uLocal_522 = 0;
var uLocal_523 = 0;
var uLocal_524 = 0;
var uLocal_525 = 0;
var uLocal_526 = 0;
var uLocal_527 = 0;
var uLocal_528 = 0;
var uLocal_529 = 0;
var uLocal_530 = 0;
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 3;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
int iLocal_614 = 0;
int iLocal_615 = 0;
int iLocal_616 = 0;
int *iLocal_617 = NULL;
var uLocal_618 = 0;
var uLocal_619 = 0;
struct<4> ScriptParam_0 = {
  0, 0, 0, 0
};
var uScriptParam_4 = 16;
var uScriptParam_5 = 0;
var uScriptParam_6 = 0;
var uScriptParam_7 = 0;
var uScriptParam_8 = 0;
var uScriptParam_9 = 0;
var uScriptParam_10 = 0;
var uScriptParam_11 = 0;
var uScriptParam_12 = 0;
var uScriptParam_13 = 0;
var uScriptParam_14 = 0;
var uScriptParam_15 = 0;
var uScriptParam_16 = 0;
var uScriptParam_17 = 0;
var uScriptParam_18 = 0;
var uScriptParam_19 = 0;
var uScriptParam_20 = 0;
var uScriptParam_21 = 0;
var uScriptParam_22 = 0;
var uScriptParam_23 = 0;
var uScriptParam_24 = 0;
var uScriptParam_25 = 0;
var uScriptParam_26 = 0;
var uScriptParam_27 = 0;
var uScriptParam_28 = 0;
var uScriptParam_29 = 0;
var uScriptParam_30 = 0;
var uScriptParam_31 = 0;
var uScriptParam_32 = 0;
var uScriptParam_33 = 0;
var uScriptParam_34 = 0;
var uScriptParam_35 = 0;
var uScriptParam_36 = 0;
var uScriptParam_37 = 0;
var uScriptParam_38 = 0;
var uScriptParam_39 = 0;
var uScriptParam_40 = 0;
var uScriptParam_41 = 0;
var uScriptParam_42 = 0;
var uScriptParam_43 = 0;
var uScriptParam_44 = 0;
var uScriptParam_45 = 0;
var uScriptParam_46 = 0;
var uScriptParam_47 = 0;
var uScriptParam_48 = 0;
var uScriptParam_49 = 0;
var uScriptParam_50 = 0;
var uScriptParam_51 = 0;
var uScriptParam_52 = 0;
var uScriptParam_53 = 0;
var uScriptParam_54 = 0;
var uScriptParam_55 = 0;
var uScriptParam_56 = 0;
var uScriptParam_57 = 0;
var uScriptParam_58 = 0;
var uScriptParam_59 = 0;
var uScriptParam_60 = 0;
var uScriptParam_61 = 0;
var uScriptParam_62 = 0;
var uScriptParam_63 = 0;
var uScriptParam_64 = 0;
var uScriptParam_65 = 0;
var uScriptParam_66 = 0;
var uScriptParam_67 = 0;
var uScriptParam_68 = 0;
var uScriptParam_69 = 0;
var uScriptParam_70 = 0;
var uScriptParam_71 = 0;
var uScriptParam_72 = 0;
var uScriptParam_73 = 0;
var uScriptParam_74 = 0;
var uScriptParam_75 = 0;
var uScriptParam_76 = 0;
var uScriptParam_77 = 0;
var uScriptParam_78 = 0;
var uScriptParam_79 = 0;
var uScriptParam_80 = 0;
var uScriptParam_81 = 0;
var uScriptParam_82 = 0;
var uScriptParam_83 = 0;
var uScriptParam_84 = 0;
var uScriptParam_85 = 0;
var uScriptParam_86 = 0;
var uScriptParam_87 = 0;
var uScriptParam_88 = 0;
var uScriptParam_89 = 0;
var uScriptParam_90 = 0;
var uScriptParam_91 = 0;
var uScriptParam_92 = 0;
var uScriptParam_93 = 0;
var uScriptParam_94 = 0;
var uScriptParam_95 = 0;
var uScriptParam_96 = 0;
var uScriptParam_97 = 0;
var uScriptParam_98 = 0;
var uScriptParam_99 = 0;
var uScriptParam_100 = 0;
var uScriptParam_101 = 0;
var uScriptParam_102 = 0;
var uScriptParam_103 = 0;
var uScriptParam_104 = 0;
var uScriptParam_105 = 0;
var uScriptParam_106 = 0;
var uScriptParam_107 = 0;
var uScriptParam_108 = 0;
var uScriptParam_109 = 0;
var uScriptParam_110 = 0;
var uScriptParam_111 = 0;
var uScriptParam_112 = 0;
var uScriptParam_113 = 0;
var uScriptParam_114 = 0;
var uScriptParam_115 = 0;
var uScriptParam_116 = 0;
var uScriptParam_117 = 0;
var uScriptParam_118 = 0;
var uScriptParam_119 = 0;
var uScriptParam_120 = 0;
var uScriptParam_121 = 0;
var uScriptParam_122 = 0;
var uScriptParam_123 = 0;
var uScriptParam_124 = 0;
var uScriptParam_125 = 0;
var uScriptParam_126 = 0;
var uScriptParam_127 = 0;
var uScriptParam_128 = 0;
var uScriptParam_129 = 0;
var uScriptParam_130 = 0;
var uScriptParam_131 = 0;
var uScriptParam_132 = 0;
var uScriptParam_133 = 0;
var uScriptParam_134 = 0;
var uScriptParam_135 = 0;
var uScriptParam_136 = 0;
var uScriptParam_137 = 0;
var uScriptParam_138 = 0;
var uScriptParam_139 = 0;
var uScriptParam_140 = 0;
var uScriptParam_141 = 0;
var uScriptParam_142 = 0;
var uScriptParam_143 = 0;
var uScriptParam_144 = 0;
var uScriptParam_145 = 0;
var uScriptParam_146 = 0;
var uScriptParam_147 = 0;
var uScriptParam_148 = 0;
var uScriptParam_149 = 0;
var uScriptParam_150 = 0;
var uScriptParam_151 = 0;
var uScriptParam_152 = 0;
var uScriptParam_153 = 0;
var uScriptParam_154 = 0;
var uScriptParam_155 = 0;
var uScriptParam_156 = 0;
var uScriptParam_157 = 0;
var uScriptParam_158 = 0;
var uScriptParam_159 = 0;
var uScriptParam_160 = 0;
var uScriptParam_161 = 0;
var uScriptParam_162 = 0;
var uScriptParam_163 = 0;
var uScriptParam_164 = 0;
var uScriptParam_165 = 0;
var uScriptParam_166 = 0;
var uScriptParam_167 = 0;
var uScriptParam_168 = 0;
var uScriptParam_169 = 0;
#pragma endregion //}

void __EntryFunction__() {
  var *uVar0;
  int iVar14;
  int iVar15;
  struct<13> Var16;
  var *uVar101;
  var *uVar107;
  struct<27> Var111;
  int iVar714;
  int *iVar715;
  int iVar716;
  int *iVar717;
  struct<11> Var722;
  int *iVar861;
  int iVar867;
  int *iVar868;
  int iVar869;
  int *iVar870;
  int *iVar873;
  int *iVar876;
  int *iVar879;
  int *iVar882;
  int *iVar885;
  int *iVar888;
  var *uVar891;
  int *iVar894;
  int *iVar897;
  int *iVar900;
  vector3 vVar903;
  int *iVar906;
  int *iVar909;
  int *iVar912;
  int *iVar915;
  var *uVar918;
  int *iVar1083;
  int *iVar1084;
  int *iVar1085;
  int *iVar1086;
  var *uVar1087;
  int iVar1088;
  int iVar1089[3];
  int iVar1093;
  var *uVar1094;
  int iVar1095;
  int iVar1096;
  int iVar1097[6];
  int iVar1104;
  int iVar1105;
  int iVar1106;
  int iVar1107;
  int iVar1108;
  int iVar1109;
  var *uVar1110;
  var *uVar1111;
  char[] cVar1112[8];
  char *sVar1113;
  struct<4> Var1114;
  vector3 vVar1118;
  vector3 vVar1121;
  vector3 vVar1124;
  vector3 vVar1127;
  float *fVar1130;
  vector3 vVar1133;
  vector3 vVar1136;
  var *uVar1139;
  float *fVar1142;
  float fVar1143;
  float *fVar1144;
  float *fVar1145;
  float *fVar1146;
  float fVar1147;
  int iVar1148;
  int *iVar1149;
  int iVar1150;
  int *iVar1151;
  int *iVar1152;
  int iVar1153;
  int iVar1154;
  int iVar1155;
  int *iVar1156;
  int iVar1157;
  int *iVar1158;
  int iVar1159;
  int iVar1160;
  int iVar1161;
  int iVar1162;
  int iVar1163;
  int iVar1164;
  var uVar1165;
  var uVar1166;
  int iVar1167;
  bool bVar1168;
  bool bVar1169;
  int *iVar1170;
  bool bVar1171;
  int *iVar1172;
  int *iVar1173;
  int *iVar1174;
  int *iVar1175;
  int *iVar1176;
  bool bVar1177;
  int *iVar1178;
  int iVar1179;
  int iVar1180;
  bool bVar1181;
  int iVar1182;
  int iVar1183;
  int *iVar1184;
  bool bVar1185;
  int iVar1186;
  bool bVar1187;
  bool bVar1188;
  bool bVar1189;
  bool bVar1190;
  int iVar1191;
  int iVar1192;
  vector3 vVar1193;
  int iVar1196;
  bool bVar1197;

  iLocal_2 = 1;
  iLocal_3 = 134;
  iLocal_4 = 134;
  iLocal_5 = 1;
  iLocal_6 = 1;
  iLocal_7 = 1;
  iLocal_8 = 134;
  iLocal_9 = 1;
  iLocal_10 = 12;
  iLocal_11 = 12;
  fLocal_14 = 0.001f;
  iLocal_17 = -1;
  sLocal_20 = "NULL";
  fLocal_21 = 0f;
  fLocal_25 = -0.0375f;
  fLocal_26 = 0.17f;
  iLocal_28 = 3;
  fLocal_31 = 80f;
  fLocal_32 = 140f;
  fLocal_33 = 180f;
  iLocal_39 = 1;
  iLocal_40 = 65;
  iLocal_41 = 49;
  iLocal_42 = 64;
  fLocal_92 = 0.05f + 0.275f - 0.01f;
  fLocal_95 = -0.05f;
  fLocal_96 = 0.92f;
  fLocal_97 = 1.94f;
  fLocal_98 = 2.99f;
  fLocal_99 = 3.7f;
  vLocal_171 = {500f, 500f, 500f};
  uVar0 = 13;
  Var16.f_12 = 12;
  uVar107 = 2;
  Var111.f_3 = 8;
  Var111.f_12 = 8;
  Var111.f_21 = 4;
  Var111.f_26.f_32 = 3;
  Var111.f_26.f_36 = 1;
  Var111.f_26.f_53 = 2;
  Var111.f_26.f_57 = 13;
  Var111.f_26.f_71 = 13;
  Var111.f_26.f_280 = 13;
  Var111.f_26.f_489 = 13;
  Var111.f_26.f_503 = 13;
  Var111.f_26.f_517 = 13;
  Var111.f_26.f_531 = 13;
  Var722.f_10.f_2 = 8;
  Var722.f_10.f_2.f_1.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_15.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
  Var722.f_10.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
  iVar868 = -1;
  uVar918 = 16;
  iVar1083 = ScriptParam_0;
  iVar1095 = ScriptParam_0.f_3;
  cVar1112 = "BJ_FAIL";
  sVar1113 = "";
  vVar1127 = {5f, 5f, 10f};
  fVar1143 = 1f;
  fVar1147 = -1f;
  iVar1148 = -1;
  iVar1151 = -1;
  iVar1155 = Global_101700.f_17926;
  iVar1158 = 1;
  iVar1159 = -1;
  iVar1178 = 0;
  iVar1183 = 1;
  bVar1185 = false;
  iVar1186 = 0;
  bVar1188 = true;
  bVar1189 = false;
  bVar1190 = false;
  iVar1191 = 0;
  if (entity::does_entity_exist(ScriptParam_0.f_1)) {
    iVar1093 = ScriptParam_0.f_1;
  }
  else {
    iVar1093 = player::get_players_last_vehicle();
  }
  bVar1189 = weapon::has_ped_got_weapon(player::player_ped_id(),
                                        joaat("gadget_parachute"), 0);
  bVar1190 = player::get_player_has_reserve_parachute(player::player_id());
  if (bVar1189) {
    player::get_player_parachute_tint_index(player::player_id(), &iVar1164);
    player::get_player_parachute_pack_tint_index(player::player_id(),
                                                 &uVar1165);
  }
  if (bVar1190) {
    player::get_player_reserve_parachute_tint_index(player::player_id(),
                                                    &uVar1166);
  }
  if (entity::does_entity_exist(iVar1093)) {
    entity::set_entity_as_mission_entity(iVar1093, 1, 1);
  }
  if (cam::is_script_global_shaking()) {
    cam::stop_script_global_shaking(0);
  }
  if (player::has_force_cleanup_occurred(82)) {
    func_530(&Var16, &uVar1110, &iVar1083, &iVar1084, &iVar1086, &iVar1089,
             &iVar1093, &uVar918, &iVar1095, &iVar1096, &iVar1097, iVar1163,
             &iVar1158, iVar1104, iVar1105, iVar867, &uVar1094, bVar1189);
  }
  if (iVar1155 < 0) {
    return;
  }
  if (gameplay::is_bit_set(Global_101700.f_17926.f_1, iVar1155)) {
    fVar1143 = 0.1f;
  }
  iVar867 = iVar1155;
  func_529(0);
  ui::clear_help(1);
  gameplay::set_mission_flag(1);
  func_528(23, 1);
  ui::_set_minimap_attitude_indicator_level(1500f, 0);
  func_502(&Var16, iVar867);
  if (entity::does_entity_exist(iVar1095)) {
    entity::set_entity_as_mission_entity(iVar1095, 1, 1);
  }
  if (entity::does_entity_exist(iVar1083)) {
    entity::set_entity_as_mission_entity(iVar1083, 1, 1);
    if (func_501(&Var16) != 0 &&
        entity::get_entity_model(iVar1083) == func_501(&Var16)) {
      iVar1086 = iVar1083;
      iVar1083 = 0;
    }
  }
  while (true) {
    if (!iVar1183) {
      system::wait(0);
    }
    else {
      iVar1183 = 0;
    }
    if (iVar714 >= 6 && iVar714 <= 10 &&
        !ped::is_ped_injured(player::player_ped_id())) {
      iVar869 = func_490();
    }
    if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
      ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
    }
    func_489();
    func_481(&uVar101);
    func_477(&Var111, iVar714);
    func_473(&Var111, iVar714, iVar867, bVar1171);
    switch (iVar714) {
    case 0:
      func_472();
      if (cam::is_screen_fading_out()) {
        break;
      }
      func_466();
      func_465(1);
      func_461("AM_H_BASEJ", 1);
      ui::clear_prints();
      ui::clear_help(1);
      if (iVar867 == 0) {
        pathfind::set_roads_in_angled_area(-832.271f, -1525.112f, -100f,
                                           -1187.833f, -1876.646f, 100f, 50f, 1,
                                           0, 1);
        uVar1094 = vehicle::_0x54B0F614960F4A5F(
            -832.271f, -1525.112f, -100f, -1187.833f, -1876.646f, 100f, 50f);
      }
      else if (iVar867 == 5) {
        pathfind::set_roads_in_angled_area(-129.031f, -726.381f, 35f, -38.185f,
                                           -465.801f, 100f, 75f, 1, 0, 1);
      }
      else if (iVar867 == 4) {
        func_457(-74.9632f, -827.4467f, 324.9521f, 25f, 1);
        gameplay::clear_area(-74.9632f, -827.4467f, 324.9521f, 25f, 1, 0, 0, 0);
      }
      else if (iVar867 == 8) {
        func_457(-74.9632f, -827.4467f, 324.9521f, 25f, 1);
        gameplay::clear_area(-807.073f, 330.8846f, 232.6766f, 25f, 1, 0, 0, 0);
      }
      if (entity::does_entity_exist(iVar1083)) {
        func_456(&uVar891);
      }
      if (iVar867 == 6 || iVar867 == 12 || iVar867 == 5) {
        if (entity::does_entity_exist(ScriptParam_0.f_2)) {
          entity::set_entity_as_mission_entity(ScriptParam_0.f_2, 1, 1);
          object::delete_object(&ScriptParam_0.f_2);
        }
        func_447(&uVar107, &Var16, iVar867, iVar867 == 6);
        iVar1180 = 1;
      }
      iVar714 = 1;
      break;

    case 1:
      if (cam::is_screen_faded_out() ||
          (iVar867 == 5 || iVar867 == 6 || iVar867 == 12) && !bVar1171) {
        if (!bVar1171) {
          if (iVar867 != 5 && iVar867 != 6 && iVar867 != 12) {
            vVar1121 = {func_446(iVar867)};
            vVar1121 = {func_445(system::cos(vVar1121.z),
                                 system::sin(vVar1121.z),
                                 gameplay::tan(vVar1121.x))};
            if (func_444(iVar867)) {
              streaming::new_load_scene_start(func_443(iVar867), vVar1121,
                                              4000f, 0);
            }
          }
          func_437(&Var16, iVar867, &uVar0, &iVar14, &iVar15, &uVar1110,
                   &iVar1162);
        }
        else if (func_435(func_436(iVar867))) {
          vVar1136 = {FtoV(1.2f) *
                      Vector(0f, -system::cos(-97.4239f + func_434(&Var16)),
                             system::sin(-97.4239f + func_434(&Var16)))};
          vVar1133 = {entity::get_offset_from_entity_in_world_coords(
              iVar1083, 1.12046f, -0.317773f, 1.3385f)};
          vVar1136 = {func_433(vVar1136, 8.909f)};
          if (func_444(iVar867)) {
            streaming::new_load_scene_start(vVar1133 + vVar1136, vVar1136,
                                            4000f, 0);
          }
        }
        else {
          vVar1121 = {-10f, 0f, func_434(&Var16)};
          vVar1121 = {func_445(system::cos(vVar1121.z), system::sin(vVar1121.z),
                               gameplay::tan(vVar1121.x))};
          if (func_444(iVar867)) {
            streaming::new_load_scene_start(func_443(iVar867), vVar1121, 4000f,
                                            0);
          }
        }
        if (bVar1171 || iVar867 == 4 || iVar867 == 8 || iVar867 == 3) {
          if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
            ped::_0xF9ACF4A08098EA25(player::player_ped_id(), 1);
          }
          entity::set_entity_coords(player::player_ped_id(), func_443(iVar867),
                                    0, 0, 0, 1);
          entity::set_entity_heading(player::player_ped_id(), func_434(&Var16));
          entity::freeze_entity_position(player::player_ped_id(), 1);
          player::set_player_control(player::player_id(), 0, 0);
        }
        iVar714 = 2;
      }
      else if (!cam::is_screen_fading_out() &&
               (!func_432(&uVar891) || func_431(&uVar891) > 0.05f)) {
        if (ped::is_ped_in_any_heli(player::player_ped_id())) {
          cam::do_screen_fade_out(2500);
        }
        else {
          cam::do_screen_fade_out(800);
        }
      }
      break;

    case 2:
      if (func_429(&uVar0, &iVar870, &uVar1110, iVar867, iVar1162,
                   iVar867 != 5 && iVar867 != 6 && iVar867 != 12)) {
        func_428(&iVar870);
        func_405(&Var16, &uVar918, &iVar1150, &iVar1083, &iVar1084, &iVar1086,
                 &iVar1085, &uVar1087, &iVar1095, &iVar1096, iVar14, iVar15,
                 &iVar879, iVar867, &iVar1159);
        ped::_0x2208438012482A1A(player::player_ped_id(), 1, 0);
        if (!bVar1171 && !iVar1180) {
          func_447(&uVar107, &Var16, iVar867, 0);
        }
        iVar714 = 3;
      }
      break;

    case 3:
      if (!func_432(&iVar870) && !bVar1171) {
        func_404(0, 0, 1);
        func_456(&iVar870);
      }
      else if (func_432(&iVar870) && func_431(&iVar870) > 0.2f || bVar1171) {
        if (func_435(func_436(iVar867)) &&
            !entity::is_entity_playing_anim(player::player_ped_id(),
                                            "oddjobs@basejump@",
                                            "Heli_door_loop", 3)) {
        }
        else if (bVar1171) {
          cam::do_screen_fade_out(800);
          if (func_432(&iVar870)) {
            func_428(&iVar870);
          }
          if (func_501(&Var16) != 0) {
            entity::freeze_entity_position(iVar1086, 0);
            func_456(&iVar888);
          }
          iVar714 = 4;
        }
        else {
          func_428(&iVar870);
          if (cam::is_screen_faded_out()) {
            system::wait(1000);
            cam::set_cam_active_with_interp(func_403(&uVar107, 1),
                                            func_403(&uVar107, 0), 10000, 1, 1);
            cam::render_script_cams(1, 0, 3000, 1, 0, 0);
            cam::do_screen_fade_in(800);
          }
          streaming::new_load_scene_stop();
          if (func_435(func_436(iVar867))) {
            vVar1136 = {FtoV(1.2f) *
                        Vector(0f, -system::cos(-97.4239f + func_434(&Var16)),
                               system::sin(-97.4239f + func_434(&Var16)))};
            vVar1133 = {entity::get_offset_from_entity_in_world_coords(
                iVar1083, 1.12046f, -0.317773f, 1.3385f)};
            vVar1136 = {func_433(vVar1136, 8.909f)};
            if (func_444(iVar867)) {
              streaming::new_load_scene_start(vVar1133 + vVar1136, vVar1136,
                                              4000f, 0);
            }
          }
          else {
            vVar1121 = {-10f, 0f, func_434(&Var16)};
            vVar1121 = {func_445(system::cos(vVar1121.z),
                                 system::sin(vVar1121.z),
                                 gameplay::tan(vVar1121.x))};
            if (func_444(iVar867)) {
              streaming::new_load_scene_start(func_443(iVar867), vVar1121,
                                              4000f, 0);
            }
          }
          if (!func_401(func_402(iVar867)) &&
              !entity::is_entity_dead(player::player_ped_id(), 0)) {
            ai::clear_ped_tasks(player::player_ped_id());
            ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
            if (ped::get_ped_stealth_movement(player::player_ped_id())) {
              ped::set_ped_stealth_movement(player::player_ped_id(), 0, 0);
            }
            entity::set_entity_coords(player::player_ped_id(),
                                      func_402(iVar867), 1, 0, 0, 1);
            entity::set_entity_heading(
                player::player_ped_id(),
                func_400(func_402(iVar867), func_443(iVar867)));
            ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
            if (func_398() == 0) {
              ped::set_ped_component_variation(player::player_ped_id(), 9, 5, 0,
                                               0);
            }
            else if (func_398() == 1) {
              ped::set_ped_component_variation(player::player_ped_id(), 8, 1, 0,
                                               0);
            }
            else if (func_398() == 2) {
              ped::set_ped_component_variation(player::player_ped_id(), 8, 3, 0,
                                               0);
            }
            ai::open_sequence_task(&iVar1107);
            if (func_397(iVar867) > 0) {
              ai::task_stand_still(0, func_397(iVar867));
            }
            ai::task_go_straight_to_coord(0, func_443(iVar867), 1f, -1,
                                          func_434(&Var16), 1056964608);
            ai::close_sequence_task(iVar1107);
            ai::task_perform_sequence(player::player_ped_id(), iVar1107);
            ai::clear_sequence_task(&iVar1107);
          }
          if (!func_435(func_436(iVar867))) {
            if (!ped::is_ped_injured(player::player_ped_id())) {
              ped::get_ped_nearby_vehicles(player::player_ped_id(), &iVar1089);
            }
            iVar1160 = 0;
            while (iVar1160 < iVar1089) {
              if (entity::does_entity_exist(iVar1089[iVar1160]) &&
                  !entity::is_entity_dead(iVar1089[iVar1160], 0)) {
                if (system::vdist2(
                        entity::get_entity_coords(iVar1089[iVar1160], 0),
                        entity::get_entity_coords(player::player_ped_id(), 0)) <
                    2500f) {
                  entity::set_entity_lod_dist(iVar1089[iVar1160], 1000);
                  vehicle::set_vehicle_lod_multiplier(iVar1089[iVar1160], 5f);
                  entity::set_entity_load_collision_flag(iVar1089[iVar1160], 1);
                }
              }
              iVar1160++;
            }
          }
          if (func_501(&Var16) != 0) {
            func_456(&iVar888);
          }
          if (!ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
            entity::freeze_entity_position(player::player_ped_id(), 0);
          }
          if (func_396(iVar867, iVar1162) > 0f) {
            func_456(&iVar906);
          }
          iVar714 = 4;
        }
      }
      break;

    case 4:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      if (iVar1174 || iVar1175) {
        if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
          cam::do_screen_fade_in(300);
          system::wait(300);
        }
        ui::clear_help(1);
        ui::clear_prints();
        cam::render_script_cams(0, 0, 3000, 1, 1, 0);
        player::set_player_control(player::player_id(), 1, 0);
        iVar714 = 10;
      }
      else if (cam::is_screen_faded_out()) {
        func_388(0, 1, 1, 0);
        if (func_435(func_436(iVar867))) {
          func_387(&uVar107, &Var16, &vVar1118, &vVar1133, &vVar1136, iVar1083,
                   &uVar1139, &fVar1142);
          iVar1163 = audio::get_sound_id();
          if (bVar1188) {
            audio::play_sound_from_entity(iVar1163, "Helicopter_Wind_Idle",
                                          iVar1083, "BASEJUMPS_SOUNDS", 0, 0);
          }
          if (bVar1187) {
            audio::_0x70B8EC8FC108A634(1, 300362576);
          }
        }
        else {
          if (cam::is_script_global_shaking()) {
            cam::stop_script_global_shaking(0);
          }
          cam::render_script_cams(0, 0, 3000, 1, 1, 0);
          cam::set_gameplay_cam_relative_heading(0f);
          cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
        }
        ped::clear_ped_wetness(player::player_ped_id());
        ped::_0x6585D955A68452A5(player::player_ped_id());
        ped::clear_ped_blood_damage(player::player_ped_id());
        ped::reset_ped_visible_damage(player::player_ped_id());
        ui::display_radar(0);
        ui::display_hud(0);
        iVar714 = 5;
      }
      else {
        if (!iVar1182) {
          if (!func_432(&iVar912)) {
            func_456(&iVar912);
          }
          else if (func_431(&iVar912) > 4f ||
                   func_435(func_436(iVar867)) && func_431(&iVar912) > 0.5f) {
            func_376(&uVar918, "OJBJAUD", func_386(&Var16), 8, 0, 0, 0);
            iVar1182 = 1;
          }
        }
        if (!cam::is_screen_fading_out() && !bVar1171) {
          if (func_354(&Var16, iVar867, &iVar1086, &uVar107, &uVar101, &iVar873,
                       &iVar876, &iVar888, &iVar906, iVar1162, &iVar1172,
                       &iVar1184, iVar1176)) {
            ui::clear_help(1);
            iVar1176 = 0;
            if (func_353(&Var16)) {
              cam::do_screen_fade_out(800);
            }
            else {
              ui::display_radar(0);
              ui::display_hud(0);
              iVar714 = 5;
            }
          }
        }
      }
      break;

    case 5:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      func_351();
      func_350();
      if (cam::is_screen_faded_out()) {
        if (bVar1171 && bVar1181) {
          time::set_clock_time(func_349(iVar869), func_348(iVar869),
                               func_347(iVar869));
        }
        system::wait(2000);
        if (bVar1171) {
          entity::freeze_entity_position(player::player_ped_id(), 0);
          func_346(&iVar909);
          if (!ped::is_ped_injured(player::player_ped_id())) {
            ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
          }
          while (func_431(&iVar909) < 1.1f) {
            system::wait(0);
            if (!ped::is_ped_injured(player::player_ped_id())) {
              ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
            }
          }
          func_428(&iVar909);
        }
        cam::do_screen_fade_in(800);
      }
      if (entity::does_entity_exist(iVar1084) &&
          !entity::is_entity_dead(iVar1084, 0)) {
        iVar1104 = ui::add_blip_for_coord(
            entity::get_offset_from_entity_in_world_coords(iVar1084,
                                                           func_345(&Var16)));
        ui::set_blip_colour(iVar1104, 5);
        ui::_0x75A16C3DA34F1245(iVar1104, 1);
        ui::set_blip_name_from_text_file(iVar1104, "BJ_BLIP_TGT");
      }
      else {
        iVar1104 = ui::add_blip_for_coord(func_344(&Var16, 0));
        ui::set_blip_colour(iVar1104, 5);
        if (iVar1150 == 1) {
          ui::set_blip_name_from_text_file(iVar1104, "BJ_BLIP_TGT");
        }
        else {
          ui::set_blip_name_from_text_file(iVar1104, "BJ_BLIP_CHK");
        }
      }
      ui::set_blip_scale(iVar1104, 1.2f);
      if (iVar1150 > 1) {
        iVar1105 = ui::add_blip_for_coord(func_344(&Var16, 1));
        ui::set_blip_colour(iVar1105, 5);
        ui::_0x75A16C3DA34F1245(iVar1104, 1);
        ui::set_blip_scale(iVar1105, 0.7f);
        if (iVar1150 == 2) {
          ui::set_blip_name_from_text_file(iVar1105, "BJ_BLIP_TGT");
        }
        else {
          ui::set_blip_name_from_text_file(iVar1105, "BJ_BLIP_CHK");
        }
      }
      if (entity::does_entity_exist(iVar1084) &&
          !entity::is_entity_dead(iVar1084, 0)) {
        entity::set_entity_lod_dist(iVar1084, 2000);
        if (entity::does_entity_exist(iVar1096) &&
            !ped::is_ped_injured(iVar1096)) {
          ai::clear_ped_tasks(iVar1096);
        }
        if (func_342(func_343(&Var16))) {
          vehicle::delete_mission_train(&iVar1084);
        }
        else {
          entity::set_entity_coords(iVar1084, func_344(&Var16, 0), 1, 0, 0, 1);
        }
      }
      if (gameplay::is_bit_set(Global_101700.f_17926.f_1,
                               func_341(&Var16) - 125)) {
        player::set_player_can_leave_parachute_smoke_trail(player::player_id(),
                                                           1);
        player::set_player_parachute_smoke_trail_color(
            player::player_id(), gameplay::get_random_int_in_range(0, 256),
            gameplay::get_random_int_in_range(0, 256),
            gameplay::get_random_int_in_range(0, 256));
      }
      if (func_340(func_436(iVar867))) {
        func_339(1, 1, 1);
        ai::clear_ped_tasks(player::player_ped_id());
        func_346(&iVar879);
        iVar714 = 6;
        func_338(88, 1);
      }
      else if (func_435(func_436(iVar867))) {
        func_339(0, 0, 1);
        entity::freeze_entity_position(player::player_ped_id(), 0);
        iVar714 = 7;
        func_338(88, 1);
      }
      else {
        func_339(1, 1, 1);
        ai::clear_ped_tasks(player::player_ped_id());
        ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
        iVar714 = 6;
        func_338(88, 1);
      }
      if (iVar867 == 5) {
        ped::set_ped_config_flag(player::player_ped_id(), 146, 1);
      }
      if (!iVar1172 && entity::does_entity_exist(iVar1086)) {
        func_337(&iVar1086, 1);
        iVar1172 = 1;
      }
      if (!func_353(&Var16)) {
        if (func_435(func_436(iVar867))) {
          func_387(&uVar107, &Var16, &vVar1118, &vVar1133, &vVar1136, iVar1083,
                   &uVar1139, &fVar1142);
        }
        else {
          if (func_336(&Var16) && !iVar1184 && !bVar1171) {
            cam::_0xC819F3CBB62BF692(1, 0, 3, 0);
          }
          else if (iVar867 == 4 && !func_335()) {
            cam::set_cam_coord(func_403(&uVar107, 0), -76.7226f, -829.9866f,
                               326.0427f);
            cam::set_cam_rot(func_403(&uVar107, 0), 0.8541f, 0f, -17.012f, 2);
            cam::set_cam_fov(func_403(&uVar107, 0), 53.883f);
            cam::set_cam_active(func_403(&uVar107, 0), 1);
          }
          else {
            if (cam::is_script_global_shaking()) {
              cam::stop_script_global_shaking(0);
            }
            cam::render_script_cams(0, 0, 3000, 1, 1, 0);
          }
          cam::set_gameplay_cam_relative_heading(0f);
          cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
          streaming::new_load_scene_stop();
        }
      }
      if (!ped::is_ped_injured(player::player_ped_id())) {
        if (bVar1189) {
          if (!weapon::has_ped_got_weapon(player::player_ped_id(),
                                          joaat("gadget_parachute"), 0)) {
            weapon::give_weapon_to_ped(player::player_ped_id(),
                                       joaat("weapon_unarmed"), 1, 0, 1);
          }
          ped::set_ped_parachute_tint_index(player::player_ped_id(), iVar1164);
          if (bVar1190) {
            if (!player::get_player_has_reserve_parachute(
                    player::player_id())) {
              player::set_player_has_reserve_parachute(player::player_id());
            }
            ped::set_ped_reserve_parachute_tint_index(player::player_ped_id(),
                                                      uVar1166);
          }
        }
        else {
          weapon::give_weapon_to_ped(player::player_ped_id(),
                                     joaat("weapon_unarmed"), 1, 0, 1);
          ped::set_ped_parachute_tint_index(
              player::player_ped_id(),
              gameplay::get_random_int_in_range(0, 65535) % 8);
        }
      }
      streaming::request_anim_dict("skydive@base");
      streaming::request_anim_dict("skydive@freefall");
      streaming::request_anim_dict("skydive@parachute@chute");
      streaming::request_anim_dict("skydive@parachute@");
      break;

    case 6:
      if (ped::is_ped_injured(player::player_ped_id())) {
        iVar714 = 12;
        break;
      }
      else if (iVar1175 || iVar1174 || func_334(&Var16, iVar867, &bVar1177)) {
        ui::clear_help(1);
        ui::clear_prints();
        iVar714 = 10;
      }
      else {
        if (iVar867 == 5) {
          ped::set_ped_config_flag(
              player::player_ped_id(), 146,
              entity::is_entity_in_area(player::player_ped_id(), -118.4f,
                                        -973.1f, 295.2f, -117.1f, -975.7f,
                                        297.7f, 0, 1, 0));
        }
        if (iVar1176) {
          vVar1124 = {func_344(&Var16, iVar1150 - 1)};
          vVar1124.z += 100f;
          entity::set_entity_coords(player::player_ped_id(), vVar1124, 1, 0, 0,
                                    1);
          iVar1176 = 0;
        }
        if (!iVar1179) {
          if (iVar867 == 4) {
            if (controls::is_control_pressed(0, 71) ||
                controls::is_control_pressed(0, 72) ||
                controls::is_control_pressed(0, 1) ||
                controls::is_control_pressed(0, 2) ||
                controls::is_control_pressed(0, 75) ||
                !ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
              cam::render_script_cams(0, 1, 1300, 1, 1, 0);
              iVar1179 = 1;
            }
          }
        }
        func_333(&iVar879);
        func_323(&Var16, iVar1084, iVar1095, &iVar1097, &iVar1108, &iVar1109,
                 &iVar1149, &iVar1151, &iVar1152, iVar1150, &iVar1153,
                 &iVar1104, &iVar1105, &iVar1148, &iVar868, &fVar1144,
                 &fVar1145, &fVar1146, &iVar1173, 0, 1, fVar1143);
        func_322(&uVar1111);
        if (func_432(&iVar870)) {
          if (func_431(&iVar870) > 10f) {
            func_318(&iVar882, &iVar1158);
          }
        }
        else {
          func_317(&iVar870, 0f);
        }
        if (entity::does_entity_exist(iVar1086) &&
            !entity::is_entity_dead(iVar1086, 0)) {
          if (!entity::is_entity_on_screen(iVar1086) &&
              system::vdist2(entity::get_entity_coords(iVar1086, 1),
                             entity::get_entity_coords(player::player_ped_id(),
                                                       1)) > 40000f) {
            iVar1192 = vehicle::get_ped_in_vehicle_seat(iVar1086, -1, 0);
            if (!ped::is_ped_injured(iVar1192)) {
              ped::delete_ped(&iVar1192);
            }
            vehicle::delete_vehicle(&iVar1086);
          }
        }
        if (!gameplay::is_bit_set(iVar1156, 0)) {
          if (ui::is_message_being_displayed() || !func_432(&iVar915)) {
            func_346(&iVar915);
          }
          else if (func_431(&iVar915) > 0.25f) {
            Var1114 = {func_316(iVar867)};
            func_315(&Var1114, 7500, 0);
            func_428(&iVar915);
            gameplay::set_bit(&iVar1156, 0);
          }
        }
        if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
          func_314(&Var111, 1);
          iVar1088 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 1);
          if (vehicle::is_vehicle_driveable(iVar1088, 0) &&
              entity::is_entity_in_air(iVar1088)) {
            if (!gameplay::is_bit_set(iVar1156, 1)) {
              if (!func_432(&iVar894)) {
                func_456(&iVar894);
              }
              else if (func_431(&iVar894) > 0.15f) {
                func_313("BJ_VEHHELP", -1);
                func_428(&iVar894);
                gameplay::set_bit(&iVar1156, 1);
              }
            }
          }
          else {
            gameplay::clear_bit(&iVar1156, 1);
            if (func_312("BJ_VEHHELP")) {
              ui::clear_help(1);
            }
            if (func_432(&iVar894)) {
              func_428(&iVar894);
            }
          }
        }
        else {
          func_314(&Var111, 0);
          gameplay::clear_bit(&iVar1156, 1);
          if (func_312("BJ_VEHHELP")) {
            ui::clear_help(1);
          }
          if (func_432(&iVar894)) {
            func_428(&iVar894);
          }
        }
        if (ped::get_ped_parachute_state(player::player_ped_id()) != -1) {
          if (iVar867 == 5) {
            ped::set_ped_config_flag(player::player_ped_id(), 146, 0);
          }
          graphics::_0x6DDBF9DFFC4AC080(1);
          audio::set_audio_flag("DisableFlightMusic", 0);
          iVar714 = 9;
          func_428(&iVar870);
        }
      }
      break;

    case 7:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      if (iVar1174 || iVar1175) {
        if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
          cam::do_screen_fade_in(300);
          system::wait(300);
        }
        ui::clear_help(1);
        ui::clear_prints();
        if (cam::is_script_global_shaking()) {
          cam::stop_script_global_shaking(0);
        }
        cam::render_script_cams(0, 0, 3000, 1, 0, 0);
        player::set_player_control(player::player_id(), 1, 0);
        iVar714 = 10;
      }
      else {
        func_333(&iVar879);
        func_323(&Var16, iVar1084, iVar1095, &iVar1097, &iVar1108, &iVar1109,
                 &iVar1149, &iVar1151, &iVar1152, iVar1150, &iVar1153,
                 &iVar1104, &iVar1105, &iVar1148, &iVar868, &fVar1144,
                 &fVar1145, &fVar1146, &iVar1173, 0, 1, fVar1143);
        func_322(&uVar1111);
        if (func_435(func_436(iVar867)) &&
            !entity::is_entity_dead(iVar1083, 0)) {
          func_311(iVar1083, func_443(iVar867));
        }
        if (func_432(&iVar870)) {
          if (func_431(&iVar870) > 10f) {
            func_318(&iVar882, &iVar1158);
          }
        }
        else {
          func_317(&iVar870, 0f);
        }
        if (func_307(&Var16, &uVar107, &uVar101, &iVar876, &vVar1118, &fVar1130,
                     vVar1133, vVar1136) ||
            iVar1176) {
          func_428(&iVar870);
          ui::clear_help(1);
          if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
            if (entity::does_entity_exist(iVar1083) &&
                !entity::is_entity_dead(iVar1083, 0)) {
              entity::set_entity_coords(iVar1083, func_443(iVar867), 1, 0, 0,
                                        1);
              entity::set_entity_heading(iVar1083, func_434(&Var16));
              entity::freeze_entity_position(iVar1083, 1);
              iVar1159 =
                  ped::create_synchronized_scene(0f, 0f, 0f, 0f, 0f, 0f, 2);
              ped::attach_synchronized_scene_to_entity(
                  iVar1159, iVar1083,
                  entity::get_entity_bone_index_by_name(iVar1083, "Chassis"));
              ai::task_synchronized_scene(player::player_ped_id(), iVar1159,
                                          "oddjobs@basejump@", "Heli_jump", 4f,
                                          -4f, 7, 0, 1148846080, 0);
              ped::set_synchronized_scene_phase(iVar1159, 0.6f);
              func_305(iVar1083, &uVar107, &iVar873);
              streaming::new_load_scene_stop();
            }
          }
          if (bVar1187) {
            audio::_0x70B8EC8FC108A634(0, 300362576);
          }
          audio::play_sound_from_entity(iVar1163, "Helicopter_Wind", iVar1083,
                                        "BASEJUMPS_SOUNDS", 0, 0);
          iVar1176 = 0;
          iVar714 = 8;
        }
      }
      break;

    case 8:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      func_333(&iVar879);
      func_323(&Var16, iVar1084, iVar1095, &iVar1097, &iVar1108, &iVar1109,
               &iVar1149, &iVar1151, &iVar1152, iVar1150, &iVar1153, &iVar1104,
               &iVar1105, &iVar1148, &iVar868, &fVar1144, &fVar1145, &fVar1146,
               &iVar1173, 0, 1, fVar1143);
      if (ped::is_synchronized_scene_running(iVar1159)) {
        if (ped::get_synchronized_scene_phase(iVar1159) > 0.92f) {
          ai::open_sequence_task(&iVar1106);
          ai::task_force_motion_state(0, -1161760501, 0);
          ai::task_parachute(0, 1, 0);
          ai::close_sequence_task(iVar1106);
          ai::task_perform_sequence(player::player_ped_id(), iVar1106);
          ai::clear_sequence_task(&iVar1106);
        }
      }
      if (entity::does_entity_exist(iVar1083)) {
        if (func_304(&uVar107, &iVar873, vVar1133, vVar1136, vVar1118,
                     &uVar1139, &fVar1142)) {
          entity::set_entity_no_collision_entity(player::player_ped_id(),
                                                 iVar1083, 0);
          if (!entity::is_entity_playing_anim(player::player_ped_id(),
                                              "oddjobs@basejump@", "Heli_jump",
                                              3)) {
            player::set_player_control(player::player_id(), 1, 0);
            ui::display_radar(1);
            if (cam::is_script_global_shaking()) {
              cam::stop_script_global_shaking(0);
            }
            audio::set_audio_flag("DisableFlightMusic", 0);
            graphics::_0x6DDBF9DFFC4AC080(1);
            iVar714 = 9;
          }
        }
      }
      break;

    case 9:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      if (Global_17151.f_135) {
        controls::disable_control_action(0, 144, 1);
      }
      if (Global_17151.f_135) {
        controls::disable_control_action(0, 144, 1);
      }
      if (ped::is_ped_injured(player::player_ped_id())) {
        iVar714 = 12;
        break;
      }
      if (iVar1174 || iVar1175) {
        ui::clear_help(1);
        ui::clear_prints();
        iVar714 = 10;
      }
      else if (func_303(&uVar101, 3, 1000) && !Global_17151.f_135) {
        entity::set_entity_invincible(player::player_ped_id(), 1);
        player::set_player_control(player::player_id(), 0, 256);
        cam::do_screen_fade_out(800);
        while (cam::is_screen_fading_out()) {
          func_323(&Var16, iVar1084, iVar1096, &iVar1097, &iVar1108, &iVar1109,
                   &iVar1149, &iVar1151, &iVar1152, iVar1150, &iVar1153,
                   &iVar1104, &iVar1105, &iVar1148, &iVar868, &fVar1144,
                   &fVar1145, &fVar1146, &iVar1173, 0, 1, fVar1143);
          system::wait(0);
        }
        func_258(&Var16, &uVar1110, &Var111, &iVar1156, &iVar1096, &iVar1097,
                 &iVar1093, &iVar1084, &iVar1085, &iVar1086, &iVar1089,
                 &iVar1108, &iVar1109, iVar1104, iVar1105, &iVar1149, &iVar1151,
                 &iVar1152, &iVar1158, &iVar1153, iVar867, &iVar715, &iVar868,
                 &iVar885, &vVar903, &fVar1130, &fVar1144, &fVar1145, &fVar1146,
                 &iVar1173, &iVar1172, &iVar1174, &iVar1175, &iVar1176,
                 &iVar1178, &iVar1170, &uVar1094);
        bVar1171 = true;
        iVar714 = 0;
      }
      else {
        func_255(&iVar900, &iVar1097);
        if (iVar1176) {
          vVar1124 = {func_344(&Var16, iVar1150 - 1)};
          func_253(player::player_ped_id(), vVar1124);
          iVar1176 = 0;
        }
        func_333(&iVar879);
        if (func_342(func_343(&Var16))) {
          if (!entity::does_entity_exist(iVar1084) &&
              gameplay::get_distance_between_coords(
                  entity::get_entity_coords(player::player_ped_id(), 1),
                  func_344(&Var16, 0), 0) <= 200f) {
            iVar1084 = vehicle::create_mission_train(6, func_344(&Var16, 0), 1);
            if (!entity::is_entity_dead(iVar1084, 0)) {
              vehicle::set_train_cruise_speed(iVar1084, 7.5f);
            }
          }
        }
        else if (entity::does_entity_exist(iVar1084) &&
                 !entity::is_entity_dead(iVar1084, 0) &&
                 !func_401(func_344(&Var16, 0))) {
          ped::is_ped_injured(iVar1096);
          if (func_252(player::player_ped_id(), iVar1084, 0) <= 325f) {
            if (iVar867 == 5) {
              vVar1193 = {28.8687f, -299.1065f, 46.5693f};
            }
            else {
              vVar1193 = {-819.7591f, -1512.229f, 0.1336f};
            }
            if (ai::get_script_task_status(iVar1096, -1273030092) != 1) {
              if (iVar867 == 5) {
                ai::task_vehicle_mission_coors_target(
                    iVar1096, iVar1084, vVar1193, 4, 5f, 16785408, 5f, 10f, 1);
              }
              else {
                ai::task_vehicle_mission_coors_target(
                    iVar1096, iVar1084, vVar1193, 4, 5f, 16777216, 4f, -1f, 1);
              }
            }
            else {
              func_247(&iVar1084);
            }
          }
        }
        iVar715 = func_323(&Var16, iVar1084, iVar1096, &iVar1097, &iVar1108,
                           &iVar1109, &iVar1149, &iVar1151, &iVar1152, iVar1150,
                           &iVar1153, &iVar1104, &iVar1105, &iVar1148, &iVar868,
                           &fVar1144, &fVar1145, &fVar1146, &iVar1173, 1, 1,
                           fVar1143);
        if (iVar715 == 1 || iVar715 >= 2) {
          ai::task_clear_look_at(player::player_ped_id());
          if (iVar715 >= 2) {
            if (ui::is_help_message_being_displayed()) {
              ui::clear_help(1);
            }
            if (ui::is_message_being_displayed()) {
              ui::clear_prints();
            }
          }
          weapon::set_current_ped_weapon(player::player_ped_id(),
                                         joaat("weapon_unarmed"), 0);
          if (iVar867 == 5) {
            ai::clear_ped_tasks(iVar1096);
            ped::set_ped_config_flag(iVar1096, 296, 1);
          }
          iVar1196 = 0;
          while (iVar1196 < iVar1097) {
            if (entity::does_entity_exist(iVar1097[iVar1196]) &&
                !entity::is_entity_dead(iVar1097[iVar1196], 0)) {
              ai::clear_ped_tasks(iVar1097[iVar1196]);
              iVar1097[iVar1196] = 0;
            }
            iVar1196++;
          }
          iVar714 = 10;
        }
        func_246(&Var111, &Var16, iVar867, iVar1150);
      }
      break;

    case 10:
      if (iVar867 == 0) {
        vehicle::_0xBC3CCA5844452B06(200f);
      }
      if (entity::does_entity_exist(iVar1096) &&
          !entity::is_entity_dead(iVar1096, 0)) {
        if (ai::get_script_task_status(iVar1096, -982327190) != 0 &&
            ai::get_script_task_status(iVar1096, -982327190) != 1) {
          ai::clear_ped_tasks(iVar1096);
          ai::task_stand_still(iVar1096, -1);
        }
      }
      if (!iVar1174 && !iVar1175 && !bVar1177) {
        if (!func_432(&iVar885)) {
          if (!func_432(&iVar876)) {
            func_456(&iVar876);
          }
          if (ui::does_blip_exist(iVar1104)) {
            ui::remove_blip(&iVar1104);
          }
          if (ui::does_blip_exist(iVar1105)) {
            ui::remove_blip(&iVar1105);
          }
          if (iVar1151 > -1) {
            graphics::delete_checkpoint(iVar1108);
            graphics::delete_checkpoint(iVar1109);
            iVar1151 = -1;
          }
          func_317(&iVar885, 0f);
        }
        if (!func_432(&vVar903)) {
          func_456(&vVar903);
        }
        if (func_343(&Var16) == 0) {
          func_245(func_344(&Var16, iVar1150 - 1), vVar903);
        }
        if (!ped::is_ped_injured(player::player_ped_id())) {
          if (entity::does_entity_exist(iVar1084) &&
                  !entity::is_entity_dead(iVar1084, 0) &&
                  !entity::is_entity_dead(player::player_ped_id(), 0) &&
                  entity::is_entity_at_entity(player::player_ped_id(), iVar1084,
                                              vVar1127, 0, 1, 0) ||
              entity::is_entity_at_coord(player::player_ped_id(),
                                         func_344(&Var16, iVar1149), vVar1127,
                                         0, 1, 0) ||
              entity::is_entity_in_air(player::player_ped_id())) {
            bVar1197 = false;
            if (entity::is_entity_in_air(player::player_ped_id()) &&
                entity::does_entity_exist(iVar1084) &&
                !entity::is_entity_touching_entity(player::player_ped_id(),
                                                   iVar1084)) {
              bVar1197 = true;
            }
            else if (!ped::is_ped_injured(player::player_ped_id()) &&
                     ped::is_ped_ragdoll(player::player_ped_id())) {
              bVar1197 = true;
            }
            if (bVar1197) {
              if (func_303(&uVar101, 3, 1000) && !Global_17151.f_135) {
                entity::set_entity_invincible(player::player_ped_id(), 1);
                player::set_player_control(player::player_id(), 0, 256);
                cam::do_screen_fade_out(800);
                while (cam::is_screen_fading_out()) {
                  func_323(&Var16, iVar1084, iVar1096, &iVar1097, &iVar1108,
                           &iVar1109, &iVar1149, &iVar1151, &iVar1152, iVar1150,
                           &iVar1153, &iVar1104, &iVar1105, &iVar1148, &iVar868,
                           &fVar1144, &fVar1145, &fVar1146, &iVar1173, 0, 1,
                           fVar1143);
                  system::wait(0);
                }
                func_258(&Var16, &uVar1110, &Var111, &iVar1156, &iVar1096,
                         &iVar1097, &iVar1093, &iVar1084, &iVar1085, &iVar1086,
                         &iVar1089, &iVar1108, &iVar1109, iVar1104, iVar1105,
                         &iVar1149, &iVar1151, &iVar1152, &iVar1158, &iVar1153,
                         iVar867, &iVar715, &iVar868, &iVar885, &vVar903,
                         &fVar1130, &fVar1144, &fVar1145, &fVar1146, &iVar1173,
                         &iVar1172, &iVar1174, &iVar1175, &iVar1176, &iVar1178,
                         &iVar1170, &uVar1094);
                bVar1171 = true;
                iVar714 = 0;
              }
              break;
            }
          }
        }
      }
      if (ped::is_ped_injured(player::player_ped_id())) {
        iVar714 = 12;
        break;
      }
      if (iVar1174 || iVar1175 || bVar1177 ||
          func_432(&iVar885) && func_431(&iVar885) > 0.25f) {
        if (func_432(&iVar885) && func_431(&iVar885) > 0.25f) {
          func_241(func_344(&Var16, iVar1149), iVar1084, iVar1096, &iVar715,
                   &iVar1153, &fVar1147);
        }
        func_428(&iVar885);
        if (iVar1174 || iVar715 == 1) {
          iVar717 = func_240();
          while (!graphics::has_scaleform_movie_loaded(iVar717)) {
            system::wait(0);
            if (func_343(&Var16) == 0) {
              func_245(func_344(&Var16, iVar1150 - 1), vVar903);
            }
            iVar717 = func_240();
          }
          if (iVar867 == 0) {
            if (!ped::is_ped_injured(iVar1096)) {
              func_376(&uVar918, "OJBJAUD", "BJ_01D", 8, 1, 1, 0);
            }
          }
          iVar714 = 11;
          if (!func_239(&Var111, 7)) {
            iVar1157 = 125;
            gameplay::set_bit(&Global_101700.f_17926.f_1,
                              func_341(&Var16) - iVar1157);
            func_238(func_341(&Var16), 1);
            iVar1167 = 1;
            bVar1168 = true;
            bVar1169 = true;
            iVar1161 = 0;
            while (iVar1161 < 13) {
              if (!gameplay::is_bit_set(Global_101700.f_17926.f_1, iVar1161)) {
                if (func_435(func_436(iVar1161))) {
                  bVar1169 = false;
                }
                else {
                  bVar1168 = false;
                }
                iVar1167 = 0;
              }
              iVar1161++;
            }
            if (iVar1167 && !func_237(98)) {
              func_236(98, 1);
            }
            if (bVar1168) {
              func_231(128, 0, 0);
            }
            if (bVar1169) {
              func_231(129, 0, 0);
            }
            func_203(&iVar1152, iVar1150, &iVar1153, &iVar1154, fVar1143);
            if (!ped::is_ped_injured(player::player_ped_id())) {
              weapon::set_current_ped_weapon(player::player_ped_id(),
                                             joaat("weapon_unarmed"), 0);
            }
            func_202(&Var111, 7, 1);
            func_201(1, 0);
            func_456(&iVar897);
            func_200();
          }
        }
        else if (iVar1175 || bVar1177 || iVar715 >= 2) {
          ui::clear_help(1);
          ui::clear_prints();
          if (!bVar1177) {
            func_197();
          }
          if (ped::is_ped_injured(player::player_ped_id())) {
            iVar1170 = 1;
          }
          if (player::is_player_online()) {
            func_195(&Var111, 0, 201, "BJ_CONTINUE", 203, "BJ_RETRY", 353, 0,
                     353, 0);
          }
          else {
            func_202(&Var111, 27, 1);
            func_195(&Var111, 0, 201, "BJ_CONTINUE", 203, "BJ_RETRY", 211,
                     "HUD_INPUT68", 353, 0);
          }
          iVar714 = 12;
        }
        func_428(&iVar876);
      }
      break;

    case 11:
      controls::disable_control_action(2, 200, 1);
      if (!iVar1174 && !iVar1175) {
        if (func_194() && !func_239(&Var111, 26)) {
          func_189(iVar867);
          if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
            func_195(&Var111, 0, 215, "BJ_CONTINUE", 216, "BJ_RETRY", 211,
                     "HUD_INPUT68", 353, 0);
            func_202(&Var111, 26, 1);
          }
        }
      }
      if (!ped::is_ped_injured(player::player_ped_id())) {
        iVar1186 = ped::is_ped_in_any_vehicle(player::player_ped_id(), 0);
      }
      if (func_343(&Var16) == 0) {
        func_245(func_344(&Var16, iVar1150 - 1), vVar903);
      }
      if (!iVar1191) {
        iVar716 = func_72(iVar867, &Var111, &uVar1110, &uVar101, iVar1152,
                          iVar1150, iVar1153, &iVar1154, fVar1143, &iVar1178);
        iVar1191 = iVar716 == 1;
      }
      if (ped::is_ped_injured(player::player_ped_id())) {
        if (iVar1155 == 0) {
          pathfind::set_roads_in_angled_area(-832.271f, -1525.112f, -100f,
                                             -1187.833f, -1876.646f, 100f, 50f,
                                             0, 1, 1);
        }
        else if (iVar1155 == 5) {
          pathfind::set_roads_in_angled_area(-129.031f, -726.381f, 35f,
                                             -38.185f, -465.801f, 100f, 75f, 0,
                                             1, 1);
        }
        func_71(&Var16, &uVar1110, &iVar1083, &iVar1084, &iVar1086, &iVar1089,
                iVar1093, &uVar918, &iVar1095, &iVar1096, &iVar1097, iVar1163,
                &iVar1158, iVar1104, iVar1105, iVar867, &uVar1094, bVar1189);
      }
      else if (!cam::is_screen_fading_out() &&
               (!func_70() || func_431(&iVar897) >= 2f)) {
        controls::disable_control_action(0, 22, 1);
        controls::disable_control_action(0, 21, 1);
        controls::disable_control_action(0, 55, 1);
        controls::disable_control_action(0, 140, 1);
        controls::disable_control_action(0, 142, 1);
        controls::disable_control_action(0, 141, 1);
        controls::disable_control_action(0, 80, 1);
        controls::disable_control_action(0, 95, 1);
        controls::disable_control_action(0, 96, 1);
        controls::disable_control_action(0, 97, 1);
        controls::disable_control_action(0, 98, 1);
        controls::disable_control_action(0, 0, 1);
        if (func_432(&iVar876)) {
          if (iVar716 == 1 || func_431(&iVar876) >= 60f ||
              !ped::is_ped_injured(player::player_ped_id()) &&
                  ped::is_ped_jacking(player::player_ped_id()) ||
              !iVar1186 &&
                  ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
            if (!iVar1191) {
              func_69(&Var111.f_26);
              iVar1191 = 1;
            }
            if (func_44(&Var111.f_26, 0, 1065353216, 0, 0, 0)) {
              if (!iVar1174 && !iVar1175) {
                if (func_194() && !func_239(&Var111, 26)) {
                  if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
                    func_202(&Var111, 26, 1);
                  }
                }
              }
              func_41(&Var111.f_26);
              func_428(&iVar897);
              if (iVar867 == 0) {
                pathfind::set_roads_in_angled_area(-832.271f, -1525.112f, -100f,
                                                   -1187.833f, -1876.646f, 100f,
                                                   50f, 0, 1, 1);
              }
              else if (iVar867 == 5) {
                pathfind::set_roads_in_angled_area(-129.031f, -726.381f, 35f,
                                                   -38.185f, -465.801f, 100f,
                                                   75f, 0, 1, 1);
              }
              func_71(&Var16, &uVar1110, &iVar1083, &iVar1084, &iVar1086,
                      &iVar1089, iVar1093, &uVar918, &iVar1095, &iVar1096,
                      &iVar1097, iVar1163, &iVar1158, iVar1104, iVar1105,
                      iVar867, &uVar1094, bVar1189);
            }
          }
          else if (iVar716 == 0) {
            if (!iVar1174 && !iVar1175) {
              if (func_194() && !func_239(&Var111, 26)) {
                if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
                  func_202(&Var111, 26, 1);
                }
              }
            }
            func_41(&Var111.f_26);
            func_428(&iVar897);
            func_202(&Var111, 5, 0);
            player::set_player_control(player::player_id(), 0, 256);
            cam::do_screen_fade_out(800);
            while (cam::is_screen_fading_out()) {
              system::wait(0);
              if (func_343(&Var16) == 0) {
                func_245(func_344(&Var16, iVar1150 - 1), vVar903);
              }
            }
            func_258(&Var16, &uVar1110, &Var111, &iVar1156, &iVar1096,
                     &iVar1097, &iVar1093, &iVar1084, &iVar1085, &iVar1086,
                     &iVar1089, &iVar1108, &iVar1109, iVar1104, iVar1105,
                     &iVar1149, &iVar1151, &iVar1152, &iVar1158, &iVar1153,
                     iVar867, &iVar715, &iVar868, &iVar885, &vVar903, &fVar1130,
                     &fVar1144, &fVar1145, &fVar1146, &iVar1173, &iVar1172,
                     &iVar1174, &iVar1175, &iVar1176, &iVar1178, &iVar1170,
                     &uVar1094);
            bVar1171 = true;
            iVar714 = 0;
            break;
          }
          else if (iVar1178) {
            if (func_431(&iVar876) > 60f - 5f) {
              func_39(&iVar876, 60f - 5f);
            }
          }
        }
        else {
          func_317(&iVar876, 0f);
        }
      }
      break;

    case 12:
      if (!ped::is_ped_injured(player::player_ped_id())) {
        iVar1186 = ped::is_ped_in_any_vehicle(player::player_ped_id(), 0);
      }
      controls::disable_control_action(2, 200, 1);
      if (iVar1154 > 0) {
        iVar1154 = 0;
      }
      if (!iVar1174 && !iVar1175) {
        if (func_194() && !func_239(&Var111, 26)) {
          func_189(iVar867);
          if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
            func_195(&Var111, 0, 201, "BJ_CONTINUE", 203, "BJ_RETRY", 211,
                     "HUD_INPUT68", 353, 0);
            func_202(&Var111, 26, 1);
          }
        }
      }
      if (!func_239(&Var111, 24)) {
        if (ped::is_ped_injured(player::player_ped_id())) {
          bVar1181 = true;
        }
        else {
          bVar1181 = false;
        }
        audio::cancel_music_event("OJBJ_START");
        audio::cancel_music_event("OJBJ_JUMPED");
        audio::cancel_music_event("OJBJ_LANDED");
        audio::trigger_music_event("OJBJ_STOP");
        if (ui::does_blip_exist(iVar1104)) {
          ui::remove_blip(&iVar1104);
        }
        if (ui::does_blip_exist(iVar1105)) {
          ui::remove_blip(&iVar1105);
        }
        if (iVar867 == 0) {
          vehicle::_0xBC3CCA5844452B06(200f);
        }
        iVar717 = func_240();
        while (!graphics::has_scaleform_movie_loaded(iVar717)) {
          if (func_343(&Var16) == 0) {
            func_245(func_344(&Var16, iVar1150 - 1), vVar903);
          }
          system::wait(0);
          iVar717 = func_240();
        }
        if (bVar1181) {
          func_38(&iVar861, 0);
        }
        else {
          func_37(&Var722, 1050253722, 1073741824);
        }
        func_202(&Var111, 24, 1);
      }
      if (!bVar1181 && ped::is_ped_injured(player::player_ped_id())) {
        func_202(&Var111, 24, 0);
        break;
      }
      if (func_343(&Var16) == 0) {
        func_245(func_344(&Var16, iVar1150 - 1), vVar903);
      }
      if (ped::is_ped_injured(player::player_ped_id())) {
        switch (func_34(player::player_ped_id())) {
        case 0: sVar1113 = "BJ_FAIL_M"; break;

        case 1: sVar1113 = "BJ_FAIL_F"; break;

        case 2: sVar1113 = "BJ_FAIL_T"; break;
        }
      }
      else if (bVar1177) {
        sVar1113 = "BJ_FAIL_02";
      }
      else {
        sVar1113 = "BJ_FAIL_01";
      }
      bVar1185 = false;
      controls::disable_control_action(0, 0, 1);
      controls::disable_control_action(0, 80, 1);
      if (bVar1181) {
        bVar1185 = func_16(&iVar861, &Var722, &iVar717, cVar1112, sVar1113,
                           &bVar1171, 78);
      }
      else {
        bVar1185 = func_3(&iVar717, &Var722, cVar1112, sVar1113, &bVar1171, 79,
                          7, 1, 1097859072, 1);
      }
      if (bVar1185) {
        if (bVar1171) {
          if (!iVar1174 && !iVar1175) {
            if (func_194() && !func_239(&Var111, 26)) {
              if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
                func_202(&Var111, 26, 1);
              }
            }
          }
          func_258(&Var16, &uVar1110, &Var111, &iVar1156, &iVar1096, &iVar1097,
                   &iVar1093, &iVar1084, &iVar1085, &iVar1086, &iVar1089,
                   &iVar1108, &iVar1109, iVar1104, iVar1105, &iVar1149,
                   &iVar1151, &iVar1152, &iVar1158, &iVar1153, iVar867,
                   &iVar715, &iVar868, &iVar885, &vVar903, &fVar1130, &fVar1144,
                   &fVar1145, &fVar1146, &iVar1173, &iVar1172, &iVar1174,
                   &iVar1175, &iVar1176, &iVar1178, &iVar1170, &uVar1094);
          iVar714 = 0;
        }
        else {
          if (!iVar1174 && !iVar1175) {
            if (func_194() && !func_239(&Var111, 26)) {
              if (func_177(iVar867, iVar1153, fVar1147, iVar1154)) {
                func_202(&Var111, 26, 1);
              }
            }
          }
          func_2(bVar1181, &Var16, &uVar1110, &iVar1083, &iVar1084, &iVar1086,
                 &iVar1089, iVar1093, &uVar918, &iVar1095, &iVar1096, &iVar1097,
                 iVar1163, &iVar1158, iVar1104, iVar1105, iVar867, &uVar1094,
                 bVar1189);
        }
        func_1(&iVar717);
      }
      iVar715 = 0;
      break;
    }
  }
}

// Position - 0x2BD4
void func_1(int *iParam0) {
  if (graphics::has_scaleform_movie_loaded(*iParam0)) {
    graphics::set_scaleform_movie_as_no_longer_needed(iParam0);
    *iParam0 = 0;
  }
}

// Position - 0x2BF0
void func_2(bool bParam0, var *uParam1, var *uParam2, int *iParam3,
            int *iParam4, int *iParam5, int iParam6, int iParam7, var *uParam8,
            int iParam9, int iParam10, int iParam11, int iParam12,
            int *iParam13, int iParam14, int iParam15, int iParam16,
            var *uParam17, bool bParam18) {
  if (bParam0) {
    func_530(uParam1, uParam2, iParam3, iParam4, iParam5, iParam6, &iParam7,
             uParam8, iParam9, iParam10, iParam11, iParam12, iParam13, iParam14,
             iParam15, iParam16, uParam17, bParam18);
  }
  else {
    func_530(uParam1, uParam2, iParam3, iParam4, iParam5, iParam6, &iParam7,
             uParam8, iParam9, iParam10, iParam11, iParam12, iParam13, iParam14,
             iParam15, iParam16, uParam17, bParam18);
  }
}

// Position - 0x2C50
bool func_3(int iParam0, int *iParam1, char *sParam2, char *sParam3,
            int iParam4, int iParam5, int iParam6, int iParam7, float fParam8,
            int iParam9) {
  switch (*iParam1) {
  case 0:
    if (!cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
      cam::do_screen_fade_out(2500);
      unk1::_0xEB2D525B57F42B40();
    }
    if (iParam9) {
      script::set_no_loading_screen(1);
    }
    gameplay::set_time_scale(0.2f);
    if (func_15(iParam5, 4)) {
      if (audio::request_script_audio_bank("generic_failed", 0, -1)) {
        *iParam1 = 1;
      }
    }
    else {
      *iParam1 = 1;
    }
    break;

  case 1:
    graphics::_push_scaleform_movie_function(*iParam0,
                                             "SHOW_CENTERED_MP_MESSAGE_LARGE");
    graphics::begin_text_command_scaleform_string("STRING");
    ui::_set_notification_color_next(6);
    ui::add_text_component_substring_text_label(sParam2);
    graphics::end_text_command_scaleform_string();
    func_14(sParam3);
    graphics::_push_scaleform_movie_function_parameter_int(100);
    graphics::_push_scaleform_movie_function_parameter_bool(1);
    graphics::_pop_scaleform_movie_function();
    if (func_15(iParam5, 32)) {
      if (!iParam1->f_136) {
        graphics::_push_scaleform_movie_function(*iParam0, "TRANSITION_UP");
        graphics::_push_scaleform_movie_function_parameter_float(
            iParam1->f_134);
        graphics::_pop_scaleform_movie_function_void();
        iParam1->f_136 = 1;
      }
    }
    if (!func_15(iParam5, 1)) {
      controls::disable_all_control_actions(0);
    }
    func_13(&iParam1->f_10, 0, 1, 1, 1);
    func_12(&iParam1->f_10, "IB_RETRY", 2, 201, 1, 1, 0);
    func_12(&iParam1->f_10, "FE_HLP16", 2, 202, 1, 1, 0);
    if (func_15(iParam5, 4)) {
      audio::play_sound_frontend(-1, "ScreenFlash", "MissionFailedSounds", 1);
    }
    if (func_15(iParam5, 8)) {
      switch (func_398()) {
      case 0:
        graphics::_start_screen_effect("MinigameEndMichael", 500, 0);
        break;

      case 1:
        graphics::_start_screen_effect("MinigameEndFranklin", 500, 0);
        break;

      case 2:
        graphics::_start_screen_effect("MinigameEndTrevor", 500, 0);
        break;
      }
    }
    if (!func_432(&iParam1->f_1)) {
      func_456(&iParam1->f_1);
    }
    if (func_15(iParam5, 2)) {
      if (!func_432(&iParam1->f_4)) {
        func_456(&iParam1->f_4);
      }
    }
    *iParam1 = 2;
    break;

  case 2:
    ui::hide_loading_on_fade_this_frame();
    if (func_15(iParam5, 32)) {
      if (!iParam1->f_136) {
        graphics::_push_scaleform_movie_function(*iParam0, "TRANSITION_UP");
        graphics::_push_scaleform_movie_function_parameter_float(
            iParam1->f_134);
        graphics::_pop_scaleform_movie_function_void();
        iParam1->f_136 = 1;
      }
    }
    graphics::_set_2d_layer(iParam6);
    func_11(iParam0, 0, 0);
    if (!func_15(iParam5, 16) && (func_431(&iParam1->f_1) >= iParam1->f_135 ||
                                  cam::is_screen_faded_out())) {
      func_5(&iParam1->f_10, 1128792064, iParam6, iParam7, 1, 1065353216);
      ui::_show_cursor_this_frame();
      if (controls::is_control_just_released(2, 201)) {
        iParam1->f_138 = 1;
        audio::play_sound_frontend(-1, "YES", "HUD_FRONTEND_DEFAULT_SOUNDSET",
                                   1);
        if (!func_15(iParam5, 1)) {
          controls::enable_all_control_actions(0);
        }
        func_4(&iParam1->f_10);
        *iParam1 = 3;
        return false;
      }
      else if (controls::is_control_just_released(2, 202)) {
        iParam1->f_138 = 0;
        audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET",
                                   1);
        if (!func_15(iParam5, 1)) {
          controls::enable_all_control_actions(0);
        }
        func_4(&iParam1->f_10);
        *iParam1 = 3;
        return false;
      }
    }
    if (func_15(iParam5, 2)) {
      if (func_431(&iParam1->f_4) >= fParam8) {
        iParam1->f_138 = 0;
        audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET",
                                   1);
        if (!func_15(iParam5, 1)) {
          controls::enable_all_control_actions(0);
        }
        func_4(&iParam1->f_10);
        *iParam1 = 3;
        return false;
      }
    }
    break;

  case 3:
    func_11(iParam0, 0, 0);
    gameplay::set_time_scale(1f);
    if (iParam1->f_138 ||
        !(gameplay::are_strings_equal("stunt_plane_races",
                                      script::get_this_script_name()) ||
          gameplay::are_strings_equal("pilot_school",
                                      script::get_this_script_name()) ||
          gameplay::are_strings_equal("bj", script::get_this_script_name()) &&
              ped::is_ped_injured(player::player_ped_id()))) {
      cam::do_screen_fade_in(2500);
    }
    if (func_15(iParam5, 64) && iParam1->f_138) {
      cam::do_screen_fade_out(500);
    }
    func_346(&iParam1->f_4);
    if (iParam9) {
      script::set_no_loading_screen(0);
    }
    *iParam1 = 4;
    break;

  case 4:
    if (func_431(&iParam1->f_4) <= 0.1f) {
      func_11(iParam0, 0, 0);
    }
    else {
      *iParam4 = iParam1->f_138;
      return true;
    }
    break;
  }
  return false;
}

// Position - 0x3033
void func_4(int *iParam0) {
  if (*uParam0 != 0) {
    graphics::set_scaleform_movie_as_no_longer_needed(uParam0);
    *iParam0 = 0;
  }
  iParam0->f_1 = 0;
  iParam0->f_123 = 0;
}

// Position - 0x3056
void func_5(var *uParam0, float fParam1, int iParam2, bool bParam3, int iParam4,
            float fParam5) {
  int iVar0;
  int iVar1;
  int iVar2;
  char *sVar3;
  bool bVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  float fVar8;

  if (cam::is_screen_fading_out() || cam::is_screen_fading_in() ||
      cam::is_screen_faded_out() || gameplay::is_frontend_fading()) {
    if (!bParam3) {
      return;
    }
  }
  if (!func_10(uParam0)) {
    return;
  }
  ui::hide_loading_on_fade_this_frame();
  graphics::_set_2d_layer(iParam2);
  if (!func_15(uParam0->f_1, 256) ||
      func_15(uParam0->f_1, 8192) && controls::_0x6CD79468A1E595C6(2)) {
    graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
    graphics::_push_scaleform_movie_function_parameter_float(fParam1);
    graphics::_pop_scaleform_movie_function_void();
    graphics::_push_scaleform_movie_function(*uParam0, "SET_MAX_WIDTH");
    graphics::_push_scaleform_movie_function_parameter_float(fParam5);
    graphics::_pop_scaleform_movie_function_void();
    graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
    graphics::_pop_scaleform_movie_function_void();
    if (gameplay::is_pc_version()) {
      graphics::_push_scaleform_movie_function(*uParam0,
                                               "TOGGLE_MOUSE_BUTTONS");
      graphics::_push_scaleform_movie_function_parameter_bool(
          func_15(uParam0->f_1, 4096));
      graphics::_pop_scaleform_movie_function_void();
    }
    iVar5 = 0;
    iVar6 = 0;
    while (iVar6 < uParam0->f_123) {
      switch (uParam0->f_2[iVar6 /*15*/].f_2) {
      case 0: bVar4 = true; break;

      case 1: bVar4 = controls::_is_input_disabled(2); break;

      case 2: bVar4 = !controls::_is_input_disabled(2); break;

      default: bVar4 = false; break;
      }
      if (bVar4) {
        if (graphics::_push_scaleform_movie_function(*uParam0,
                                                     "SET_DATA_SLOT")) {
          graphics::_push_scaleform_movie_function_parameter_int(iVar5);
          iVar5++;
          iVar7 = 0;
          while (iVar7 < uParam0->f_2[iVar6 /*15*/].f_14) {
            iVar0 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/];
            iVar1 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/].f_1;
            iVar2 =
                gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_13, iVar7);
            if (!gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_12, iVar7)) {
              sVar3 = controls::get_control_instructional_button(iVar0, iVar1,
                                                                 iVar2);
            }
            else {
              sVar3 = controls::_0x80C2FD58D720C801(iVar0, iVar1, iVar2);
            }
            if (!gameplay::is_string_null_or_empty(sVar3)) {
              func_9(sVar3);
            }
            iVar7++;
          }
          if (!gameplay::is_string_null_or_empty(uParam0->f_2[iVar6 /*15*/])) {
            func_14(uParam0->f_2[iVar6 /*15*/]);
          }
          if (gameplay::is_pc_version()) {
            if (func_15(uParam0->f_1, 4096)) {
              if (uParam0->f_2[iVar6 /*15*/].f_1) {
                graphics::_push_scaleform_movie_function_parameter_bool(1);
                graphics::_push_scaleform_movie_function_parameter_int(
                    uParam0->f_2[iVar6 /*15*/].f_3[0 /*2*/].f_1);
              }
              else {
                graphics::_push_scaleform_movie_function_parameter_bool(0);
                graphics::_push_scaleform_movie_function_parameter_int(-1);
              }
            }
          }
          graphics::_pop_scaleform_movie_function_void();
        }
      }
      iVar6++;
    }
    fVar8 = func_8(iParam4, func_8(func_15(uParam0->f_1, 32), 1f, 0f), -1f);
    graphics::_push_scaleform_movie_function(*uParam0,
                                             "DRAW_INSTRUCTIONAL_BUTTONS");
    graphics::_push_scaleform_movie_function_parameter_float(fVar8);
    graphics::_pop_scaleform_movie_function_void();
    graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(80f);
    graphics::_pop_scaleform_movie_function_void();
    func_7(&uParam0->f_1, 256);
    func_6(&uParam0->f_1, 128);
  }
  graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
}

// Position - 0x3316
void func_6(int *iParam0, int iParam1) { *iParam0 -= (*iParam0 & iParam1); }

// Position - 0x332B
void func_7(var *uParam0, int iParam1) { *uParam0 |= iParam1; }

// Position - 0x333C
float func_8(bool bParam0, float fParam1, float fParam2) {
  if (bParam0) {
    return fParam1;
  }
  return fParam2;
}

// Position - 0x3353
void func_9(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x3361
int func_10(var *uParam0) {
  if (*uParam0 != 0) {
    if (graphics::has_scaleform_movie_loaded(*uParam0)) {
      func_7(&uParam0->f_1, 1);
      return 1;
    }
  }
  return 0;
}

// Position - 0x3388
int func_11(var *uParam0, int iParam1, int iParam2) {
  if (!func_432(&uParam0->f_2)) {
    func_346(&uParam0->f_2);
  }
  ui::hide_hud_component_this_frame(14);
  if (!iParam2) {
    graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
  }
  else if (iParam2) {
    graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
  }
  if (iParam1) {
    if (controls::is_control_pressed(2, 201)) {
      return 0;
    }
  }
  if (uParam0->f_1 == -1) {
    return 1;
  }
  if (func_431(&uParam0->f_2) * 1000f > system::to_float(uParam0->f_1)) {
    func_428(&uParam0->f_2);
    return 0;
  }
  return 1;
}

// Position - 0x341A
int func_12(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4,
            int iParam5, int iParam6) {
  int iVar0;
  int iVar1;

  if (*uParam0 == 0) {
    return 0;
  }
  iVar0 = 0;
  if (iParam5 == 1) {
    iVar0 = 1;
  }
  iVar1 = uParam0->f_123;
  if (iVar1 < 8) {
    uParam0->f_2[iVar1 /*15*/] = sParam1;
    uParam0->f_2[iVar1 /*15*/].f_1 = iVar0;
    uParam0->f_2[iVar1 /*15*/].f_2 = iParam6;
    uParam0->f_2[iVar1 /*15*/].f_12 = 0;
    uParam0->f_2[iVar1 /*15*/].f_13 = 0;
    uParam0->f_2[iVar1 /*15*/].f_14 = 0;
    uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/] = iParam2;
    uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
    if (iParam4 == 1) {
      gameplay::set_bit(&uParam0->f_2[iVar1 /*15*/].f_13, 0);
    }
    uParam0->f_2[iVar1 /*15*/].f_14++;
    uParam0->f_123++;
    return 1;
  }
  return 0;
}

// Position - 0x34E3
void func_13(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
  if (*uParam0 == 0) {
    *uParam0 =
        graphics::request_scaleform_movie_instance("instructional_buttons");
  }
  uParam0->f_1 = 0;
  uParam0->f_123 = 0;
  if (iParam1) {
    func_7(&uParam0->f_1, 32);
  }
  if (graphics::has_scaleform_movie_loaded(*uParam0)) {
    func_7(&uParam0->f_1, 1);
    if (iParam2) {
      graphics::set_scaleform_movie_to_use_system_time(*uParam0, 1);
    }
  }
  if (gameplay::is_pc_version()) {
    if (iParam3) {
      func_7(&uParam0->f_1, 4096);
    }
  }
  if (iParam4) {
    func_7(&uParam0->f_1, 8192);
  }
}

// Position - 0x355D
void func_14(char *sParam0) {
  graphics::begin_text_command_scaleform_string(sParam0);
  graphics::end_text_command_scaleform_string();
}

// Position - 0x356F
bool func_15(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x357E
int func_16(int *iParam0, int *iParam1, int iParam2, char *sParam3,
            char *sParam4, int iParam5, int iParam6) {
  switch (*iParam0) {
  case 0:
    *iParam0 = 1;
    audio::start_audio_scene("DEATH_SCENE");
    audio::play_sound_frontend(-1, "ScreenFlash", "WastedSounds", 1);
    func_33(&iParam0->f_1);
    func_32();
    func_37(iParam1, 0.15f * 0.075f, 0.5f);
    script::set_no_loading_screen(1);
    break;

  case 1:
    if (func_24() || cam::is_screen_faded_out()) {
      *iParam0 = 2;
    }
    if (!func_23(iParam0->f_4, 4)) {
      if (audio::request_script_audio_bank("OFFMISSION_WASTED", 0, -1)) {
        audio::play_sound_frontend(-1, "Bed", "WastedSounds", 1);
        func_21(&iParam0->f_4, 4);
      }
    }
    if (IntToFloat(system::timera()) > 1500f * 0.2f) {
      if (!func_23(iParam0->f_4, 2)) {
        audio::play_sound_frontend(-1, "TextHit", "WastedSounds", 1);
        func_21(&iParam0->f_4, 2);
      }
      func_3(iParam2, iParam1, sParam3, sParam4, iParam5,
             iParam6 - (4 & iParam6) - (2 & iParam6) | 16, 7, 1, 1097859072, 0);
    }
    break;

  case 2:
    if (func_3(iParam2, iParam1, sParam3, sParam4, iParam5,
               iParam6 - (8 & iParam6) - (4 & iParam6) - (2 & iParam6), 7, 1,
               1097859072, 1)) {
      func_20(0, 1);
      func_18(0, 1);
      func_32();
      if (*iParam5) {
        gameplay::ignore_next_restart(1);
      }
      else if (!iParam0->f_5) {
        func_17(0);
      }
      script::set_no_loading_screen(0);
      gameplay::_disable_automatic_respawn(0);
      *iParam0 = 3;
    }
    break;

  case 3:
    if (player::is_player_playing(player::player_id())) {
      gameplay::set_fade_in_after_death_arrest(1);
      func_20(0, 1);
      func_18(0, 1);
      audio::stop_audio_scene("DEATH_SCENE");
      script::set_no_loading_screen(0);
      return 1;
    }
    break;

  case 4: script::set_no_loading_screen(0); return 1;
  }
  return 0;
}

// Position - 0x373F
void func_17(int iParam0) {
  if (Global_35781 == 9 || Global_35781 == 10 || Global_35781 == 5) {
    Global_100351 = iParam0;
    if (iParam0) {
    }
  }
  else {
    if (iParam0) {
    }
    Global_100351 = 0;
  }
}

// Position - 0x3785
void func_18(int iParam0, int iParam1) {
  if (iParam0 == 1) {
    func_20(0, 0);
    graphics::_start_screen_effect("DeathFailOut", 0, 0);
    gameplay::set_bit(&iLocal_43, 1);
    func_19(1, 2, 0);
    cam::_set_cam_effect(2);
  }
  else {
    if (gameplay::is_bit_set(iLocal_43, 1) || iParam1) {
      graphics::_stop_screen_effect("DeathFailOut");
      func_19(0, 2, 1);
      cam::_set_cam_effect(0);
    }
    gameplay::clear_bit(&iLocal_43, 1);
  }
}

// Position - 0x37E6
void func_19(int iParam0, int iParam1, int iParam2) {
  if (iParam0 == 1) {
    gameplay::set_bit(&iLocal_43, 2);
    if (!network::network_is_game_in_progress()) {
      if (iParam1 == 1) {
        gameplay::set_time_scale(0.2f);
      }
      else {
        gameplay::set_time_scale(0.075f);
      }
    }
  }
  else {
    if (gameplay::is_bit_set(iLocal_43, 2) || iParam2) {
      if (!network::network_is_game_in_progress()) {
        gameplay::set_time_scale(1f);
      }
    }
    gameplay::clear_bit(&iLocal_43, 2);
  }
}

// Position - 0x3847
void func_20(int iParam0, int iParam1) {
  char *sVar0;

  switch (func_398()) {
  case 0: sVar0 = "DeathFailMichaelIn"; break;

  case 1: sVar0 = "DeathFailFranklinIn"; break;

  case 2: sVar0 = "DeathFailTrevorIn"; break;
  }
  if (iParam0 == 1) {
    if (!gameplay::is_bit_set(iLocal_43, 0) || iParam1) {
      graphics::_start_screen_effect(sVar0, 0, 0);
      gameplay::set_bit(&iLocal_43, 0);
      func_19(1, 1, 0);
      cam::_set_cam_effect(1);
    }
  }
  else {
    if (gameplay::is_bit_set(iLocal_43, 0) || iParam1) {
      graphics::_stop_screen_effect(sVar0);
      func_19(0, 1, 1);
      cam::_set_cam_effect(0);
    }
    gameplay::clear_bit(&iLocal_43, 0);
  }
}

// Position - 0x38E7
void func_21(var *uParam0, int iParam1) { func_22(uParam0, iParam1); }

// Position - 0x38F7
void func_22(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x3908
bool func_23(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x3917
int func_24() {
  if (!gameplay::is_bit_set(iLocal_43, 0) &&
      !gameplay::is_bit_set(iLocal_43, 1)) {
    system::settimera(0);
    func_20(1, 0);
  }
  if (!cutscene::is_cutscene_playing()) {
    ui::clear_prints();
  }
  controls::disable_control_action(2, 199, 1);
  controls::disable_control_action(0, 59, 1);
  controls::disable_control_action(0, 60, 1);
  controls::disable_control_action(0, 37, 1);
  controls::disable_control_action(0, 25, 1);
  ped::_0x5A7F62FDA59759BD();
  if (IntToFloat(system::timera()) > 1500f * 0.2f) {
    if (!gameplay::is_bit_set(iLocal_43, 1)) {
      func_18(1, 0);
      system::settimerb(0);
    }
    else if (IntToFloat(system::timerb()) > 1500f * 0.075f ||
             cam::is_screen_faded_out()) {
      if (!cam::is_screen_faded_out()) {
        if (!cam::is_screen_fading_out()) {
          cam::do_screen_fade_out(1500);
        }
      }
      else if (iLocal_44 == 0) {
        iLocal_44 = gameplay::get_game_timer() + 1000;
        if (player::is_player_playing(player::player_id())) {
          player::set_player_control(player::player_id(), 0, 0);
        }
        func_19(0, 2, 1);
        func_388(1, 1, 1, 0);
        func_26(1);
        ui::set_frontend_active(0);
        ui::set_pause_menu_active(0);
        ui::clear_help(1);
        ui::clear_prints();
        if (player::is_player_playing(player::player_id())) {
          player::set_player_control(player::player_id(), 0, 0);
        }
        func_20(0, 0);
        func_25(0);
      }
      else if (gameplay::get_game_timer() < iLocal_44) {
        return 1;
      }
    }
  }
  return 0;
}

// Position - 0x3A5B
void func_25(int iParam0) {
  int iVar0;

  iVar0 = 0;
  if (iVar0 == 0) {
    if (iParam0 == 1) {
      if (!gameplay::is_bit_set(iLocal_43, 3)) {
        gameplay::set_game_paused(1);
        gameplay::set_bit(&iLocal_43, 3);
      }
    }
    else if (gameplay::is_bit_set(iLocal_43, 3)) {
      gameplay::set_game_paused(0);
      gameplay::clear_bit(&iLocal_43, 3);
    }
  }
}

// Position - 0x3AA2
void func_26(int iParam0) {
  if (iParam0) {
    func_31();
    if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
      gameplay::set_bit(&G_SleepModeOffOn11, 16);
    }
    Global_14443.f_1 = 1;
    if (func_30(0)) {
      func_27(0);
    }
  }
  else if (Global_14443.f_1 == 1) {
    if (Global_14443.f_1 != 0) {
      Global_14443.f_1 = 3;
    }
  }
}

// Position - 0x3B05
void func_27(int iParam0) {
  if (Global_14604) {
    func_29(0, 0);
  }
  if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
    gameplay::set_bit(&G_SleepModeOffOn11, 16);
  }
  if (audio::is_mobile_phone_call_ongoing()) {
    audio::stop_scripted_conversation(0);
  }
  Global_15745 = 5;
  if (iParam0 == 1) {
    gameplay::set_bit(&G_SleepModeOnOn25, 30);
  }
  else {
    gameplay::clear_bit(&G_SleepModeOnOn25, 30);
  }
  if (!func_28()) {
    Global_14443.f_1 = 3;
  }
}

// Position - 0x3B75
bool func_28() {
  if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
    return true;
  }
  return false;
}

// Position - 0x3B9C
void func_29(int iParam0, int iParam1) {
  if (iParam0) {
    if (func_30(0)) {
      Global_14604 = 1;
      if (iParam1) {
        mobile::get_mobile_phone_position(&Global_14380);
      }
      Global_14371 = {Global_14389[Global_14388 /*3*/]};
      mobile::set_mobile_phone_position(Global_14371);
    }
  }
  else if (Global_14604 == 1) {
    Global_14604 = 0;
    Global_14371 = {Global_14396[Global_14388 /*3*/]};
    if (iParam1) {
      mobile::set_mobile_phone_position(Global_14380);
    }
    else {
      mobile::set_mobile_phone_position(Global_14371);
    }
  }
}

// Position - 0x3C10
bool func_30(int iParam0) {
  if (iParam0 == 1) {
    if (Global_14443.f_1 > 3) {
      if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
        return true;
      }
      else {
        return false;
      }
    }
    else {
      return false;
    }
  }
  if (script::_get_number_of_instances_of_script_with_name_hash(
          joaat("cellphone_flashhand")) > 0) {
    return true;
  }
  if (Global_14443.f_1 > 3) {
    return true;
  }
  return false;
}

// Position - 0x3C6A
void func_31() {
  if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
    Global_15798 = 0;
    Global_15794 = 1;
  }
}

// Position - 0x3C93
void func_32() {
  iLocal_43 = 0;
  iLocal_44 = 0;
  func_388(0, 1, 1, 0);
  func_26(1);
}

// Position - 0x3CAE
void func_33(int *iParam0) {
  if (!func_432(iParam0)) {
    func_456(iParam0);
  }
  else {
    func_346(iParam0);
  }
}

// Position - 0x3CCF
int func_34(int iParam0) {
  int iVar0;
  int iVar1;

  if (entity::does_entity_exist(iParam0)) {
    iVar1 = entity::get_entity_model(iParam0);
    iVar0 = 0;
    while (iVar0 <= 2) {
      if (func_35(iVar0) == iVar1) {
        return iVar0;
      }
      iVar0++;
    }
  }
  return 145;
}

// Position - 0x3D0C
int func_35(int iParam0) {
  if (func_36(iParam0)) {
    return Global_101700.f_27009[iParam0 /*29*/];
  }
  else if (iParam0 != 145) {
  }
  return 0;
}

// Position - 0x3D36
bool func_36(int iParam0) { return iParam0 < 3; }

// Position - 0x3D42
void func_37(int *iParam0, int iParam1, int iParam2) {
  if (func_432(&iParam0->f_1)) {
    func_428(&iParam0->f_1);
  }
  if (func_432(&iParam0->f_4)) {
    func_428(&iParam0->f_4);
  }
  func_4(&iParam0->f_10);
  iParam0->f_134 = iParam1;
  iParam0->f_135 = iParam2;
  iParam0->f_137 = 1;
  iParam0->f_136 = 0;
  *iParam0 = 0;
}

// Position - 0x3D92
void func_38(var *uParam0, int iParam1) {
  *uParam0 = 0;
  uParam0->f_4 = 0;
  uParam0->f_5 = iParam1;
  audio::request_script_audio_bank("OFFMISSION_WASTED", 0, -1);
}

// Position - 0x3DB4
void func_39(int *iParam0, float fParam1) {
  iParam0->f_1 = func_40(gameplay::is_bit_set(*iParam0, 4)) - fParam1;
  gameplay::set_bit(iParam0, 1);
  gameplay::clear_bit(iParam0, 2);
  iParam0->f_2 = 0f;
}

// Position - 0x3DE2
float func_40(bool bParam0) {
  float fVar0;
  float fVar1;
  int iVar2;
  float fVar3;
  float fVar4;

  if (bParam0) {
    fVar0 = system::to_float(gameplay::get_game_timer());
    fVar1 = fVar0 / 1000f;
    return fVar1;
  }
  if (network::network_is_game_in_progress()) {
    iVar2 = network::get_network_time();
    fVar3 = system::to_float(iVar2);
    fVar4 = fVar3 / 1000f;
    return fVar4;
  }
  return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x3E3A
void func_41(var *uParam0) {
  if (uParam0->f_1 != 0) {
    graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_1);
    uParam0->f_1 = 0;
  }
  if (uParam0->f_562 && uParam0->f_4 != 0) {
    if (gameplay::is_pc_version()) {
      graphics::_push_scaleform_movie_function(uParam0->f_4,
                                               "TOGGLE_MOUSE_BUTTONS");
      graphics::_push_scaleform_movie_function_parameter_bool(0);
      graphics::_pop_scaleform_movie_function_void();
    }
    graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_4);
    uParam0->f_4 = 0;
  }
  if (uParam0->f_564) {
    script::set_no_loading_screen(0);
    uParam0->f_564 = 0;
  }
  if (!Global_69970) {
    if (!player::is_player_dead(player::get_player_index())) {
      if (!G_TextMessageConfig) {
        if (cam::is_screen_faded_out() && !func_43(0)) {
          cam::do_screen_fade_in(800);
        }
      }
    }
  }
  func_42(0);
}

// Position - 0x3EE1
void func_42(int iParam0) {
  Global_69962 = iParam0;
  Global_69963 = iParam0;
}

// Position - 0x3EF5
bool func_43(int iParam0) {
  if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(
                      joaat("benchmark")) > 0) {
    return true;
  }
  return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x3F20
bool func_44(var *uParam0, int iParam1, float fParam2, int iParam3, int iParam4,
             int iParam5) {
  int iVar0;

  if (gameplay::get_frame_count() == uParam0->f_574) {
    return uParam0->f_575;
  }
  uParam0->f_574 = gameplay::get_frame_count();
  if (!network::network_is_game_in_progress()) {
    if (ped::is_ped_dead_or_dying(
            player::get_player_ped(player::get_player_index()), 1)) {
      uParam0->f_575 = 1;
      return true;
    }
    if (ai::is_ped_being_arrested(
            player::get_player_ped(player::get_player_index()))) {
      uParam0->f_575 = 1;
      return true;
    }
  }
  if (!uParam0->f_564) {
    if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
      script::set_no_loading_screen(1);
      uParam0->f_564 = 1;
    }
  }
  if (player::is_player_playing(player::player_id())) {
    if (!network::network_is_game_in_progress()) {
      if (player::is_special_ability_active(player::player_id())) {
        player::special_ability_deactivate(player::player_id());
      }
    }
  }
  ui::hide_hud_component_this_frame(7);
  ui::hide_hud_component_this_frame(8);
  ui::hide_hud_component_this_frame(9);
  ui::hide_hud_component_this_frame(6);
  ui::hide_hud_component_this_frame(19);
  controls::disable_control_action(2, 19, 1);
  controls::disable_control_action(0, 37, 1);
  controls::disable_control_action(0, 21, 1);
  controls::disable_control_action(0, 28, 1);
  controls::disable_control_action(0, 29, 1);
  controls::disable_control_action(0, 171, 1);
  func_68();
  if (controls::_is_input_disabled(2)) {
    if (player::_is_player_cam_control_disabled() ||
        cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
      ui::_show_cursor_this_frame();
    }
  }
  Global_36331 = 1;
  if (!uParam0->f_563) {
    switch (func_34(player::get_player_ped(player::get_player_index()))) {
    case 1: graphics::_start_screen_effect("SuccessFranklin", 1000, 0); break;

    case 2: graphics::_start_screen_effect("SuccessTrevor", 1000, 0); break;

    default: graphics::_start_screen_effect("SuccessMichael", 1000, 0); break;
    }
    uParam0->f_563 = 1;
  }
  if (uParam0->f_558 == 0) {
    uParam0->f_558 = uParam0->f_572 + system::floor(15000f * fParam2);
  }
  if (iParam4 && uParam0->f_572 >= uParam0->f_558 - 1500) {
    uParam0->f_558 = uParam0->f_572 + 3000;
  }
  if (uParam0->f_560 == 0f) {
    uParam0->f_560 += func_67(30f);
    uParam0->f_560 += IntToFloat(uParam0->f_56) * func_67(25f);
    if (uParam0->f_56 > 0) {
      uParam0->f_560 += func_67(25f * 0.5f);
    }
    if (uParam0->f_549) {
      uParam0->f_560 += func_67(30f) - func_67(2f);
    }
  }
  iVar0 = 1;
  while (iVar0) {
    func_42(1);
    uParam0->f_572 += system::round(0f + 1000f * system::timestep());
    func_47(uParam0, fParam2, iParam3);
    if (IntToFloat(uParam0->f_572) >
        IntToFloat(uParam0->f_558 + 666) - 15000f * fParam2) {
      if (uParam0->f_30 < 1f) {
        uParam0->f_30 += 0f + 1f / 0.225f * system::timestep();
      }
    }
    uParam0->f_30 = func_46(uParam0->f_30, 0f, 1f);
    if (uParam0->f_572 > uParam0->f_558 - 333) {
      if (!uParam0->f_561) {
        if (uParam0->f_565) {
          uParam0->f_565 = 0;
          uParam0->f_566 = 0;
          uParam0->f_573 = 0.75f;
          graphics::_push_scaleform_movie_function(uParam0->f_1,
                                                   "ROLL_UP_BACKGROUND");
          graphics::_pop_scaleform_movie_function_void();
        }
        uParam0->f_547 -= (0f + 1f / 1.215f * system::timestep());
      }
    }
    uParam0->f_547 = func_46(uParam0->f_547, 0f, 1f);
    if (uParam0->f_547 <= 0.7f && !uParam0->f_545 && uParam0->f_1 != 0) {
      graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_OUT");
      graphics::_pop_scaleform_movie_function_void();
      uParam0->f_546 = uParam0->f_572;
      uParam0->f_545 = 1;
    }
    if (uParam0->f_572 > uParam0->f_558 - 333) {
      if (!uParam0->f_561) {
        if (uParam0->f_548 < 1f) {
          uParam0->f_548 += 0f + 1f / 0.3f * system::timestep();
        }
      }
    }
    uParam0->f_548 = func_46(uParam0->f_548, 0f, 1f);
    if (uParam0->f_562) {
      if (controls::_0x6CD79468A1E595C6(2)) {
        if (graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
          if (!uParam0->f_567) {
            func_45(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
          }
        }
      }
    }
    if (controls::is_control_just_pressed(2, 216) &&
        uParam0->f_558 > uParam0->f_572 + 333) {
      if (!uParam0->f_566 && uParam0->f_56 != 0 &&
          graphics::has_scaleform_movie_loaded(uParam0->f_4) &&
          IntToFloat(uParam0->f_572) >
              IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
        if (!uParam0->f_565) {
          graphics::_push_scaleform_movie_function(uParam0->f_1,
                                                   "ROLL_DOWN_BACKGROUND");
          graphics::_pop_scaleform_movie_function_void();
          uParam0->f_565 = 1;
          uParam0->f_573 = 0.75f;
          if (uParam0->f_572 > uParam0->f_558 - 5000) {
            uParam0->f_558 = uParam0->f_572 + 5000;
          }
        }
        else if (iParam5) {
          graphics::_push_scaleform_movie_function(uParam0->f_1,
                                                   "ROLL_UP_BACKGROUND");
          graphics::_pop_scaleform_movie_function_void();
          uParam0->f_565 = 0;
          uParam0->f_573 = 0.75f;
        }
        func_45(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
      }
    }
    if ((uParam0->f_565 || uParam0->f_566) && uParam0->f_56 != 0) {
      if (IntToFloat(uParam0->f_572) >
          IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
        if (uParam0->f_566 && !uParam0->f_565) {
          uParam0->f_565 = 1;
          uParam0->f_573 = 0.75f;
          graphics::_push_scaleform_movie_function(uParam0->f_1,
                                                   "ROLL_DOWN_BACKGROUND");
          graphics::_pop_scaleform_movie_function_void();
        }
        uParam0->f_559 = func_46(uParam0->f_559 + 1f / 0.3f * uParam0->f_573 *
                                                      system::timestep(),
                                 0f, 1f);
        uParam0->f_573 = func_46(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
      }
    }
    else {
      uParam0->f_559 = func_46(uParam0->f_559 - 1f / 0.3f * uParam0->f_573 *
                                                    0.01f * system::timestep(),
                               0f, 1f);
      uParam0->f_573 = func_46(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
    }
    if (uParam0->f_572 > uParam0->f_558) {
      if (uParam0->f_561) {
        if (!uParam0->f_567) {
          if (controls::is_control_just_pressed(2, 215)) {
            uParam0->f_561 = 0;
          }
        }
      }
      else if (uParam0->f_572 - uParam0->f_546 > 1000 && uParam0->f_545) {
        iVar0 = 0;
      }
    }
    uParam0->f_575 = !iVar0;
    if (iParam1) {
      system::wait(0);
    }
    else {
      if (!iVar0) {
        func_42(0);
      }
      return !iVar0;
    }
  }
  func_42(0);
  return true;
}

// Position - 0x4579
void func_45(var *uParam0, int iParam1) {
  graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
  graphics::_pop_scaleform_movie_function_void();
  if (gameplay::is_pc_version()) {
    graphics::_push_scaleform_movie_function(uParam0->f_4,
                                             "TOGGLE_MOUSE_BUTTONS");
    graphics::_push_scaleform_movie_function_parameter_bool(1);
    graphics::_pop_scaleform_movie_function_void();
  }
  graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(0);
  func_9(controls::get_control_instructional_button(2, 215, 1));
  func_14("ES_HELP");
  if (gameplay::is_pc_version()) {
    graphics::_push_scaleform_movie_function_parameter_bool(1);
    graphics::_push_scaleform_movie_function_parameter_int(215);
  }
  graphics::_pop_scaleform_movie_function_void();
  if (iParam1) {
    graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
    graphics::_push_scaleform_movie_function_parameter_int(1);
    func_9(controls::get_control_instructional_button(2, 216, 1));
    func_14("ES_XPAND");
    if (gameplay::is_pc_version()) {
      graphics::_push_scaleform_movie_function_parameter_bool(1);
      graphics::_push_scaleform_movie_function_parameter_int(216);
    }
    graphics::_pop_scaleform_movie_function_void();
  }
  graphics::_push_scaleform_movie_function(uParam0->f_4,
                                           "DRAW_INSTRUCTIONAL_BUTTONS");
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x463D
float func_46(float fParam0, float fParam1, float fParam2) {
  if (fParam0 > fParam2) {
    return fParam2;
  }
  else if (fParam0 < fParam1) {
    return fParam1;
  }
  return fParam0;
}

// Position - 0x4664
void func_47(var *uParam0, float fParam1, int iParam2) {
  int iVar0;
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  float fVar10;
  float fVar11;
  float fVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  float fVar18;
  float *fVar19;
  float fVar20;
  float fVar21;
  float fVar22;
  char cVar23[16];
  char cVar27[32];
  int iVar35;
  int iVar36;
  int iVar37;
  int iVar38;
  float fVar39;
  float fVar40;
  float fVar41;
  float fVar42;
  float fVar43;

  iVar0 = system::round(uParam0->f_547 * 255f);
  fVar1 = func_66() * 0.25f;
  if (graphics::has_scaleform_movie_loaded(uParam0->f_1)) {
    if (uParam0->f_30 >= 0f) {
      if (!uParam0->f_2) {
        graphics::_push_scaleform_movie_function(uParam0->f_1,
                                                 "SHOW_MISSION_PASSED_MESSAGE");
        func_14(&uParam0->f_5);
        func_14(&uParam0->f_13);
        if (network::network_is_game_in_progress()) {
          graphics::_push_scaleform_movie_function_parameter_int(150);
        }
        else {
          graphics::_push_scaleform_movie_function_parameter_int(100);
        }
        graphics::_push_scaleform_movie_function_parameter_bool(1);
        graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_56);
        graphics::_push_scaleform_movie_function_parameter_bool(iParam2);
        graphics::_push_scaleform_movie_function_parameter_int(69);
        graphics::_pop_scaleform_movie_function_void();
        uParam0->f_2 = 1;
      }
      if (uParam0->f_56 > 0 && !uParam0->f_3 && uParam0->f_572 > 600) {
        graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_UP");
        graphics::_push_scaleform_movie_function_parameter_float(0.15f);
        graphics::_push_scaleform_movie_function_parameter_bool(1);
        graphics::_pop_scaleform_movie_function_void();
        uParam0->f_3 = 1;
      }
    }
    func_65();
    graphics::draw_scaleform_movie_fullscreen(uParam0->f_1, 255, 255, 255, 255,
                                              0);
  }
  fVar2 = uParam0->f_560 * uParam0->f_559 * (1f - uParam0->f_548);
  fVar3 = 0f;
  if (uParam0->f_567) {
    fVar3 = (0.1388889f + func_67(2f * 2f)) * uParam0->f_568 *
            (1f - uParam0->f_548);
    fVar2 += 3f * fVar3;
  }
  if (uParam0->f_548 != 0f) {
    fVar4 = 0f;
    if (fVar2 < fVar4) {
      fVar2 = fVar4;
    }
  }
  else {
    fVar5 = 0f;
    if (uParam0->f_30 >= 0.975f) {
      if (fVar2 < fVar5) {
        fVar2 = fVar5;
      }
    }
  }
  fVar1 = 0.3f * func_66();
  if (uParam0->f_12) {
    fVar1 = 0.5f;
  }
  fVar6 = *uParam0 * 2f;
  fVar7 = func_64(&uParam0->f_13);
  if (fVar6 < fVar7) {
    fVar6 = fVar7 + 3f * 0.006f;
  }
  if (graphics::_get_aspect_ratio(0) < 1.4f) {
    fVar6 *= 1.3f;
  }
  fVar7 = func_64(&uParam0->f_550);
  fVar8 = (0.119f + 0.05f) / func_66() / 2.5f;
  if ((uParam0->f_556 == 1 || uParam0->f_556 == 0) && uParam0->f_557 != 0) {
    if (fVar6 < fVar7 + 2.6f * fVar8) {
      fVar6 = fVar7 + 2.6f * fVar8;
    }
  }
  else if (uParam0->f_556 == 3) {
    if (fVar6 < fVar7 + 2.6f * fVar8) {
      fVar6 = fVar7 + 2.6f * fVar8;
    }
  }
  else if (fVar6 < fVar7 + 1.9f * fVar8) {
    fVar6 = fVar7 + 2f * fVar8;
  }
  fVar9 = 0.499f - fVar6 / 2f + 0.006f;
  fVar10 = 0.499f + fVar6 / 2f - 0.006f;
  controls::set_input_exclusive(2, 215);
  controls::set_input_exclusive(2, 216);
  controls::set_input_exclusive(2, 200);
  controls::disable_control_action(2, 200, 1);
  if (uParam0->f_562 || uParam0->f_567) {
    if (IntToFloat(uParam0->f_558) - 14000f * fParam1 <
            IntToFloat(uParam0->f_572) ||
        uParam0->f_567 && uParam0->f_559 > 0.95f &&
            uParam0->f_558 - 10000 < uParam0->f_572) {
      if (uParam0->f_567) {
        if (uParam0->f_570 < 0) {
          uParam0->f_570 *= -1;
          uParam0->f_570 = uParam0->f_572 + uParam0->f_570;
        }
        if (uParam0->f_570 > 0) {
          if (uParam0->f_570 - uParam0->f_572 > 0) {
            func_61(uParam0->f_570 - uParam0->f_572, "TIMER_TIME", 0, 0, -1, 0,
                    2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
          }
          else {
            uParam0->f_570 = 0;
            uParam0->f_569 = 1;
            uParam0->f_567 = 0;
            uParam0->f_561 = 0;
            uParam0->f_562 = 0;
            uParam0->f_558 = uParam0->f_572 + 500;
            uParam0->f_570 = 0;
          }
        }
        if (uParam0->f_568 < 1f) {
          uParam0->f_568 += 0f + 1f / 0.166f * system::timestep();
          if (uParam0->f_568 > 1f) {
            uParam0->f_568 = 1f;
          }
        }
      }
      if (cam::is_screen_faded_out()) {
        ui::hide_loading_on_fade_this_frame();
      }
      if (uParam0->f_4 != 0 && uParam0->f_548 < 0.1f &&
          uParam0->f_572 <= uParam0->f_558) {
        ui::hide_hud_component_this_frame(7);
        ui::hide_hud_component_this_frame(8);
        ui::hide_hud_component_this_frame(9);
        ui::hide_hud_component_this_frame(6);
        graphics::draw_scaleform_movie_fullscreen(uParam0->f_4, 255, 255, 255,
                                                  iVar0, 0);
      }
      if (uParam0->f_567) {
        controls::disable_control_action(0, 140, 1);
        controls::disable_control_action(0, 141, 1);
        controls::disable_control_action(0, 142, 1);
        controls::disable_control_action(2, 188, 1);
        if (controls::is_disabled_control_just_pressed(2, 188)) {
          audio::play_sound_frontend(-1, "CONTINUE",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
          uParam0->f_567 = 0;
          uParam0->f_561 = 0;
          uParam0->f_562 = 0;
          uParam0->f_558 = uParam0->f_572 + 500;
          uParam0->f_569 = 3;
          uParam0->f_570 = 0;
          audio::play_sound_frontend(-1, "continue",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
        }
        controls::disable_control_action(2, 187, 1);
        if (controls::is_disabled_control_just_pressed(2, 187)) {
          audio::play_sound_frontend(-1, "CONTINUE",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
          uParam0->f_567 = 0;
          uParam0->f_561 = 0;
          uParam0->f_562 = 0;
          uParam0->f_558 = uParam0->f_572 + 500;
          uParam0->f_569 = 4;
          uParam0->f_570 = 0;
          audio::play_sound_frontend(-1, "continue",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
        }
        controls::disable_control_action(2, 202, 1);
        if (controls::is_disabled_control_just_pressed(2, 202)) {
          audio::play_sound_frontend(-1, "CONTINUE",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
          uParam0->f_567 = 0;
          uParam0->f_561 = 0;
          uParam0->f_562 = 0;
          uParam0->f_558 = uParam0->f_572 + 500;
          uParam0->f_569 = 2;
          uParam0->f_570 = 0;
          audio::play_sound_frontend(-1, "continue",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
        }
      }
      else if (uParam0->f_562) {
        ui::hide_hud_component_this_frame(7);
        ui::hide_hud_component_this_frame(8);
        ui::hide_hud_component_this_frame(9);
        ui::hide_hud_component_this_frame(6);
        controls::disable_control_action(0, 140, 1);
        controls::disable_control_action(0, 141, 1);
        controls::disable_control_action(0, 142, 1);
        if (controls::is_control_just_pressed(2, 215) ||
            controls::is_disabled_control_just_pressed(2, 200)) {
          audio::play_sound_frontend(-1, "CONTINUE",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
          uParam0->f_562 = 0;
          uParam0->f_561 = 0;
          uParam0->f_558 = uParam0->f_572 + 500;
          audio::play_sound_frontend(-1, "continue",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
        }
      }
    }
  }
  ui::get_hud_colour(1, &iVar13, &iVar14, &iVar15, &iVar16);
  ui::set_text_colour(iVar13, iVar14, iVar15, iVar0);
  ui::set_text_wrap(fVar9, fVar10);
  ui::set_text_justification(0);
  ui::set_text_scale(1f, 0.4f);
  fVar1 -= func_67(6f);
  fVar1 += func_67(30f) - func_67(2f * 2f);
  fVar11 = fVar2 - func_67(2f * 14f);
  if (fVar11 >= 0f) {
    fVar12 = func_46(fVar11 / (0.6f * func_67(25f)), 0f, 1f);
    func_65();
    graphics::draw_rect(0.5f, fVar1 - (func_67(2f - 0.5f) - 0.001388889f),
                        fVar6, func_60(1f), iVar13, iVar14, iVar15,
                        system::round(fVar12 * IntToFloat(iVar16)), 0);
  }
  else {
    return;
  }
  fVar1 += func_67(2f * 0.3f);
  if (uParam0->f_56 > 0) {
    fVar1 += func_67(25f * 0.2f);
  }
  iVar17 = 0;
  iVar17 = 0;
  while (iVar17 < uParam0->f_56) {
    fVar11 = fVar2 - (fVar1 - 0.3f * func_66());
    if (fVar11 >= 0f) {
      fVar12 = func_46(fVar11 / (0.8f * func_67(25f)), 0f, 1f);
      func_57(uParam0, iVar17, fVar1 + func_67(2f), fVar9, fVar10,
              system::round(IntToFloat(iVar0) * fVar12));
    }
    else {
      return;
    }
    fVar1 += func_67(25f);
    iVar17++;
  }
  if (uParam0->f_56 > 0) {
    fVar1 += func_67(25f * 0.2f);
    fVar11 = fVar2 - (fVar1 - 0.3f * func_66());
    if (fVar11 >= 0f) {
      fVar1 += func_67(2f);
      fVar12 = func_46(fVar11 / (0.6f * func_67(25f)), 0f, 1f);
      func_65();
      graphics::draw_rect(0.5f, fVar1 + func_67(2f * 0.5f), fVar6, func_60(1f),
                          iVar13, iVar14, iVar15,
                          system::round(fVar12 * IntToFloat(iVar16)), 0);
    }
  }
  if (uParam0->f_549) {
    fVar1 += func_67(25f * 0.2f);
    fVar11 = fVar2 - (fVar1 - 0.3f * func_66());
    if (fVar11 >= 0f) {
      fVar12 = func_46(fVar11 / (0.8f * func_67(25f)), 0f, 1f);
      ui::set_text_colour(iVar13, iVar14, iVar15,
                          system::round(fVar12 * IntToFloat(iVar0)));
      func_50(7, 0, 1, &fVar18, &fVar19, 0);
      fVar20 = fVar9;
      fVar21 = fVar10;
      if (unk::_get_current_language_id() == 0) {
        fVar20 = fVar9 + 0.119f / func_66() / 2.5f;
        fVar21 = fVar10 - 0.119f / func_66() / 2.5f;
        if (uParam0->f_556 == 1) {
          fVar20 = fVar9 + (0.119f + 0.05f) / func_66() / 2.5f;
          fVar21 = fVar10 - (0.119f + 0.05f) / func_66() / 2.5f;
        }
      }
      if (uParam0->f_557 == 0) {
        fVar20 += (fVar18 * 0.28f + 0.006f) / 2f;
        fVar21 += (fVar18 * 0.28f + 0.006f) / 2f;
      }
      ui::set_text_wrap(fVar20, fVar21);
      ui::set_text_justification(1);
      ui::set_text_scale(1f, 0.4f);
      func_49(&uParam0->f_550, fVar20, fVar1 + func_67(2f * 2f), 0, 0, 0);
      ui::set_text_wrap(fVar20, fVar21);
      ui::set_text_justification(2);
      ui::set_text_scale(1f, 0.4f);
      ui::set_text_centre(0);
      func_65();
      fVar22 = fVar21;
      StringCopy(&cVar23, "MPHud", 16);
      StringCopy(&cVar27, "MissionPassedMedal", 32);
      fVar22 -= (fVar18 * 0.28f + 0.006f);
      ui::set_text_wrap(fVar20, fVar22);
      ui::set_text_colour(iVar13, iVar14, iVar15,
                          system::round(fVar12 * IntToFloat(iVar0)));
      switch (uParam0->f_556) {
      case 0:
        ui::begin_text_command_display_text("PERCENTAGE");
        ui::add_text_component_integer(uParam0->f_554);
        ui::end_text_command_display_text(fVar20, fVar1 + func_67(2f * 2f), 0);
        break;

      case 1:
        ui::begin_text_command_display_text("FO_TWO_NUM");
        ui::add_text_component_integer(uParam0->f_554);
        ui::add_text_component_integer(uParam0->f_555);
        ui::end_text_command_display_text(fVar20, fVar1 + func_67(2f * 2f), 0);
        break;

      case 2:
        ui::begin_text_command_display_text("MTPHPER_XPNO");
        ui::add_text_component_integer(uParam0->f_554);
        ui::end_text_command_display_text(fVar20, fVar1 + func_67(2f * 2f), 0);
        break;

      case 3:
        ui::begin_text_command_display_text("ESDOLLA");
        ui::add_text_component_formatted_integer(uParam0->f_554, 1);
        ui::end_text_command_display_text(fVar20, fVar1 + func_67(2f * 2f), 0);
        break;
      }
      if (uParam0->f_557 != 0) {
        iVar35 = 255;
        iVar36 = 255;
        iVar37 = 255;
        iVar38 = iVar0;
        switch (uParam0->f_557) {
        case 1:
          ui::get_hud_colour(107, &iVar35, &iVar36, &iVar37, &iVar38);
          break;

        case 3:
          ui::get_hud_colour(109, &iVar35, &iVar36, &iVar37, &iVar38);
          break;

        case 2:
          ui::get_hud_colour(108, &iVar35, &iVar36, &iVar37, &iVar38);
          break;
        }
        fVar39 = 0.001388889f * 5f;
        fVar40 = 0.00078125f * 16f * 2f;
        fVar41 = 0.001388889f * 16f * 2f;
        fVar42 = fVar21 + func_48(4f) - 0.006f;
        fVar43 = fVar1 + func_67(10f) + fVar39;
        if (uParam0->f_556 == -1) {
          fVar42 -= 0.006f * 6f;
        }
        fVar40 *= 0.65f;
        fVar41 *= 0.65f;
        graphics::draw_sprite(&cVar23, &cVar27, fVar42, fVar43, fVar40, fVar41,
                              0f, iVar35, iVar36, iVar37,
                              system::round(fVar12 * IntToFloat(iVar0)), 0);
      }
      fVar1 += func_67(30f) - 2f;
    }
  }
}

// Position - 0x51B6
float func_48(float fParam0) { return fParam0 * 0.00078125f; }

// Position - 0x51C6
void func_49(char *sParam0, float fParam1, float fParam2, int iParam3,
             int iParam4, int iParam5) {
  ui::set_text_centre(iParam3);
  ui::set_text_font(iParam5);
  func_65();
  if (iParam4) {
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_player_name(sParam0);
  }
  else {
    ui::begin_text_command_display_text(sParam0);
  }
  ui::end_text_command_display_text(fParam1, fParam2, 0);
}

// Position - 0x5203
int func_50(int iParam0, int iParam1, int iParam2, float fParam3,
            float *fParam4, int iParam5) {
  char cVar0[64];
  char cVar16[64];
  int iVar32;
  int iVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  vector3 vVar37;

  StringCopy(&cVar0, func_56(iParam0), 64);
  StringCopy(&cVar16, func_53(iParam0, iParam1), 64);
  if (gameplay::get_hash_key(&cVar16) != 0) {
    fVar34 = 1f;
    if (iParam5) {
      graphics::_get_active_screen_resolution(&iVar32, &iVar33);
      fVar35 = graphics::_get_aspect_ratio(0);
      if (func_52()) {
        iVar32 = system::round(system::to_float(iVar33) * fVar35);
      }
      fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
      fVar34 = fVar36 / fVar35;
      if (func_52()) {
        fVar34 = 1f;
      }
      if (script::_get_number_of_instances_of_script_with_name_hash(
              joaat("director_mode")) > 0) {
        graphics::get_screen_resolution(&iVar32, &iVar33);
      }
      iVar32 = system::round(system::to_float(iVar32) / fVar34);
      iVar33 = system::round(system::to_float(iVar33) / fVar34);
    }
    else {
      graphics::get_screen_resolution(&iVar32, &iVar33);
    }
    vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
    vVar37.x *= func_51(iParam0) / fVar34;
    vVar37.y *= func_51(iParam0) / fVar34;
    if (!iParam2) {
      vVar37.x -= 2f;
      vVar37.y -= 2f;
    }
    if (iParam0 == 30) {
      vVar37.x = 288f;
      vVar37.y = 106f;
    }
    if (iParam0 == 29 && gameplay::get_hash_key(
                             &Global_17290.f_6703[29 /*16*/]) == -1487683087) {
      vVar37.x = 106f;
      vVar37.y = 106f;
    }
    *fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
    *fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) *
               *fParam3;
    if (!iParam5) {
      if (!graphics::get_is_widescreen() && iParam0 != 30) {
        *fParam3 *= 1.33f;
      }
    }
    if (iParam0 == 29) {
      if (*fParam3 > Global_17289) {
        *fParam4 *= Global_17289 / *fParam3;
        *fParam3 = Global_17289;
      }
    }
    return 1;
  }
  return 0;
}

// Position - 0x53B4
float func_51(int iParam0) {
  switch (iParam0) {
  case 33:
  case 4:
  case 11:
  case 31:
  case 20:
  case 15:
  case 10:
  case 12:
  case 13:
  case 32:
  case 9:
  case 5:
  case 6:
  case 7:
  case 14:
  case 18:
  case 19:
  case 17:
  case 28:
  case 26:
  case 27:
  case 49: return 0.5f;
  }
  return 1f;
}

// Position - 0x5453
bool func_52() {
  int iVar0;
  int iVar1;
  float fVar2;

  graphics::_get_active_screen_resolution(&iVar0, &iVar1);
  fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
  if (fVar2 > 3.5f) {
    return true;
  }
  return false;
}

// Position - 0x5485
var func_53(int iParam0, int iParam1) {
  char *sVar0[2];
  var uVar3;
  struct<13> Var19;

  if (!gameplay::is_string_null_or_empty(
          &Global_17290.f_6703[iParam0 /*16*/])) {
    if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) ==
        -1487683087) {
      Var19 = {func_55(player::player_id())};
      if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
        return func_54(&uVar3);
      }
    }
    else {
      return func_54(&Global_17290.f_6703[iParam0 /*16*/]);
    }
  }
  switch (iParam0) {
  case 3:
    sVar0[0] = "MP_hostCrown";
    sVar0[1] = "MP_hostCrown";
    break;

  case 21:
    sVar0[0] = "MP_SpecItem_Coke";
    sVar0[1] = "MP_SpecItem_Coke";
    break;

  case 22:
    sVar0[0] = "MP_SpecItem_Heroin";
    sVar0[1] = "MP_SpecItem_Heroin";
    break;

  case 23:
    sVar0[0] = "MP_SpecItem_Weed";
    sVar0[1] = "MP_SpecItem_Weed";
    break;

  case 24:
    sVar0[0] = "MP_SpecItem_Meth";
    sVar0[1] = "MP_SpecItem_Meth";
    break;

  case 25:
    sVar0[0] = "MP_SpecItem_Cash";
    sVar0[1] = "MP_SpecItem_Cash";
    break;

  case 1:
    sVar0[0] = "shop_NEW_Star";
    sVar0[1] = "shop_NEW_Star";
    break;

  case 2:
    sVar0[0] = "shop_NEW_Star";
    sVar0[1] = "shop_NEW_Star";
    break;

  case 4:
    sVar0[0] = "Shop_Tick_Icon";
    sVar0[1] = "Shop_Tick_Icon";
    break;

  case 6:
    sVar0[0] = "Shop_Box_CrossB";
    sVar0[1] = "Shop_Box_Cross";
    break;

  case 7:
    sVar0[0] = "Shop_Box_BlankB";
    sVar0[1] = "Shop_Box_Blank";
    break;

  case 5:
    sVar0[0] = "Shop_Box_TickB";
    sVar0[1] = "Shop_Box_Tick";
    break;

  case 8:
    sVar0[0] = "shop_NEW_Star";
    sVar0[1] = "shop_NEW_Star";
    break;

  case 9:
    sVar0[0] = "Shop_Clothing_Icon_B";
    sVar0[1] = "Shop_Clothing_Icon_A";
    break;

  case 10:
    sVar0[0] = "Shop_GunClub_Icon_B";
    sVar0[1] = "Shop_GunClub_Icon_A";
    break;

  case 17:
    sVar0[0] = "Shop_Ammo_Icon_B";
    sVar0[1] = "Shop_Ammo_Icon_A";
    break;

  case 18:
    sVar0[0] = "Shop_Armour_Icon_B";
    sVar0[1] = "Shop_Armour_Icon_A";
    break;

  case 19:
    sVar0[0] = "Shop_Health_Icon_B";
    sVar0[1] = "Shop_Health_Icon_A";
    break;

  case 20:
    sVar0[0] = "Shop_MakeUp_Icon_B";
    sVar0[1] = "Shop_MakeUp_Icon_A";
    break;

  case 11:
    sVar0[0] = "Shop_Tattoos_Icon_B";
    sVar0[1] = "Shop_Tattoos_Icon_A";
    break;

  case 12:
    sVar0[0] = "Shop_Garage_Icon_B";
    sVar0[1] = "Shop_Garage_Icon_A";
    break;

  case 13:
    sVar0[0] = "Shop_Garage_Bike_Icon_B";
    sVar0[1] = "Shop_Garage_Bike_Icon_A";
    break;

  case 14:
    sVar0[0] = "Shop_Barber_Icon_B";
    sVar0[1] = "Shop_Barber_Icon_A";
    break;

  case 15:
    sVar0[0] = "shop_Lock";
    sVar0[1] = "shop_Lock";
    break;

  case 16:
    sVar0[0] = "Shop_Tick_Icon";
    sVar0[1] = "Shop_Tick_Icon";
    break;

  case 26:
    sVar0[0] = "arrowleft";
    sVar0[1] = "arrowleft";
    break;

  case 27:
    sVar0[0] = "arrowright";
    sVar0[1] = "arrowright";
    break;

  case 28:
    sVar0[0] = "MP_AlertTriangle";
    sVar0[1] = "MP_AlertTriangle";
    break;

  case 29:
    sVar0[0] = "shop_NEW_Star";
    sVar0[1] = "shop_NEW_Star";
    break;

  case 31:
    sVar0[0] = "Shop_Michael_Icon_B";
    sVar0[1] = "Shop_Michael_Icon_A";
    break;

  case 32:
    sVar0[0] = "Shop_Franklin_Icon_B";
    sVar0[1] = "Shop_Franklin_Icon_A";
    break;

  case 33:
    sVar0[0] = "Shop_Trevor_Icon_B";
    sVar0[1] = "Shop_Trevor_Icon_A";
    break;

  case 48:
    sVar0[0] = "SaleIcon";
    sVar0[1] = "SaleIcon";
    break;

  case 49:
    sVar0[0] = "Shop_Tick_Icon";
    sVar0[1] = "Shop_Tick_Icon";
    break;

  case 0:
    sVar0[0] = "";
    sVar0[1] = "";
    break;
  }
  if (iParam1) {
    return sVar0[0];
  }
  return sVar0[1];
}

// Position - 0x58BA
var func_54(var uParam0) { return uParam0; }

// Position - 0x58C4
struct<13> func_55(int iParam0) {
  struct<13> Var0;

  network::network_handle_from_player(iParam0, &Var0, 13);
  return Var0;
}

// Position - 0x58DB
char *
func_56(int iParam0) {
  var uVar0;
  struct<13> Var16;

  if (!gameplay::is_string_null_or_empty(
          &Global_17290.f_5886[iParam0 /*16*/])) {
    if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) ==
        -1487683087) {
      Var16 = {func_55(player::player_id())};
      network::_0x5835D9CD92E83184(&Var16, &uVar0);
      return func_54(&uVar0);
    }
    else {
      return func_54(&Global_17290.f_5886[iParam0 /*16*/]);
    }
  }
  if (iParam0 == 48) {
    return "MPShopSale";
  }
  return "CommonMenu";
}

// Position - 0x5950
void func_57(var *uParam0, int iParam1, float fParam2, float fParam3,
             float fParam4, int iParam5) {
  int iVar0;
  int iVar1;
  int iVar2;
  var uVar3;
  float fVar4;
  float fVar5;
  float fVar6;

  ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uVar3);
  ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
  ui::set_text_wrap(fParam3, fParam4);
  ui::set_text_justification(1);
  ui::set_text_scale(1f, func_59(14f));
  ui::set_text_centre(0);
  ui::set_text_font(0);
  func_65();
  if (uParam0->f_531[iParam1]) {
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_player_name(
        &uParam0->f_71[iParam1 /*16*/]);
  }
  else {
    ui::begin_text_command_display_text(&uParam0->f_71[iParam1 /*16*/]);
    if (uParam0->f_57[iParam1] == 16 || uParam0->f_57[iParam1] == 17) {
      ui::add_text_component_integer(uParam0->f_489[iParam1]);
    }
  }
  ui::end_text_command_display_text(fParam3, fParam2, 0);
  fVar4 = fParam4;
  switch (uParam0->f_517[iParam1]) {
  case 0: break;

  case 1:
    func_50(7, 0, 1, &fVar5, &fVar6, 0);
    graphics::draw_sprite("CommonMenu", func_53(7, 0), fParam4 - 0.006f,
                          fParam2 + func_67(2f) + 0.25f * fVar6, fVar5, fVar6,
                          0f, 255, 255, 255, iParam5, 0);
    fVar4 -= (fVar5 * 0.38f + 0.006f);
    break;

  case 2:
    func_50(5, 0, 1, &fVar5, &fVar6, 0);
    graphics::draw_sprite("CommonMenu", func_53(5, 0), fParam4 - 0.006f,
                          fParam2 + func_67(2f) + 0.25f * fVar6, fVar5, fVar6,
                          0f, 255, 255, 255, iParam5, 0);
    fVar4 -= (fVar5 * 0.38f + 0.006f);
    break;

  case 3:
    func_50(6, 0, 1, &fVar5, &fVar6, 0);
    graphics::draw_sprite("CommonMenu", func_53(6, 0), fParam4 - 0.006f,
                          fParam2 + func_67(2f) + 0.25f * fVar6, fVar5, fVar6,
                          0f, 255, 255, 255, iParam5, 0);
    fVar4 -= (fVar5 * 0.38f + 0.006f);
    break;
  }
  if (uParam0->f_57[iParam1] == 0) {
    return;
  }
  if (uParam0->f_57[iParam1] == 15) {
    ui::set_text_justification(1);
  }
  else {
    ui::set_text_justification(2);
  }
  ui::set_text_scale(1f, func_59(14f));
  if (uParam0->f_57[iParam1] == 5 || uParam0->f_57[iParam1] == 4) {
    ui::set_text_wrap(fParam3, fVar4 - 0.00078125f * 3f);
  }
  else {
    ui::set_text_wrap(fParam3, fVar4 + 0.00078125f * 2f);
  }
  ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
  func_58(uParam0->f_489[iParam1], uParam0->f_503[iParam1], fParam4, fParam2,
          &uParam0->f_280[iParam1 /*16*/], uParam0->f_57[iParam1]);
}

// Position - 0x5BDB
void func_58(int iParam0, int iParam1, float fParam2, float fParam3,
             char *sParam4, int iParam5) {
  int iVar0;
  float fVar1;
  float fVar2;
  float fVar3;
  int iVar4;
  int iVar5;
  int iVar6;

  iVar0 = 1;
  ui::set_text_centre(0);
  ui::set_text_font(0);
  func_65();
  fVar1 = 0f;
  fVar2 = 8f * 0.00078125f;
  fVar3 = 16f * 0.001388889f;
  iVar4 = 93;
  iVar5 = 182;
  iVar6 = 229;
  if (iParam5 == 4) {
    iVar4 = 194;
    iVar5 = 80;
    iVar6 = 80;
  }
  switch (iParam5) {
  case 4:
  case 5:
    ui::set_text_scale(1f, func_59(18f));
    ui::set_text_font(4);
    if (iParam0 < 0) {
      ui::_begin_text_command_width("ESMINDOLLA");
      ui::add_text_component_formatted_integer(-1 * iParam0, 1);
      fVar1 = ui::_end_text_command_get_width(0);
    }
    else {
      ui::_begin_text_command_width("ESDOLLA");
      ui::add_text_component_formatted_integer(iParam0, 1);
      fVar1 = ui::_end_text_command_get_width(0);
    }
    fVar1 -= fVar1 % 0.00078125f;
    graphics::draw_sprite("CommonMenu", "BettingBox_Left", fParam2 - fVar1,
                          fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2,
                          fVar3, 0f, iVar4, iVar5, iVar6, 255, 0);
    graphics::draw_sprite("CommonMenu", "BettingBox_Centre",
                          fParam2 - fVar1 * 0.5f - 0.00078125f * 2f,
                          fParam3 + fVar3 * 0.6f + 0.001388889f * 2f,
                          fVar1 - fVar2 * 0.5f, fVar3, 0f, iVar4, iVar5, iVar6,
                          255, 0);
    graphics::draw_sprite("CommonMenu", "BettingBox_Right",
                          fParam2 - 0.00078125f * 4f,
                          fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2,
                          fVar3, 0f, iVar4, iVar5, iVar6, 255, 0);
    ui::set_text_scale(1f, func_59(14f));
    break;
  }
  ui::_set_notification_color_next(iVar0);
  switch (iParam5) {
  case 11:
    ui::begin_text_command_display_text("PERCENTAGE");
    ui::add_text_component_integer(iParam0);
    break;

  case 1:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("FO_NUM");
    ui::add_text_component_integer(iParam0);
    break;

  case 2:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("FO_TWO_NUM");
    ui::add_text_component_integer(iParam0);
    ui::add_text_component_integer(iParam1);
    break;

  case 4:
  case 5: ui::set_text_scale(1f, func_59(18f));

  case 3:
    if (iParam0 < 0) {
      ui::begin_text_command_display_text("ESMINDOLLA");
      ui::add_text_component_formatted_integer(-1 * iParam0, 1);
    }
    else {
      ui::begin_text_command_display_text("ESDOLLA");
      ui::add_text_component_formatted_integer(iParam0, 1);
    }
    break;

  case 6: ui::begin_text_command_display_text(sParam4); break;

  case 7:
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_player_name(sParam4);
    break;

  case 8:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_time(iParam0, 14);
    break;

  case 9:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_time(iParam0, 6);
    break;

  case 10:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_time(iParam0, 2055);
    break;

  case 18:
    ui::set_text_font(5);
    ui::begin_text_command_display_text("STRING");
    ui::add_text_component_substring_time(iParam0, 2055);
    break;

  case 12:
    ui::begin_text_command_display_text("AHD_DIST");
    ui::add_text_component_integer(iParam0);
    break;

  case 13:
    ui::begin_text_command_display_text(sParam4);
    ui::add_text_component_integer(iParam0);
    ui::add_text_component_integer(iParam1);
    break;

  case 15:
  case 14:
    ui::begin_text_command_display_text(sParam4);
    ui::add_text_component_integer(iParam0);
    ui::add_text_component_integer(iParam1);
    break;

  case 16:
    ui::begin_text_command_display_text(sParam4);
    ui::add_text_component_integer(iParam1);
    break;
  }
  if (iParam5 != 17) {
    if (iParam5 == 4 || iParam5 == 5) {
      ui::end_text_command_display_text(fParam2 - 0.00078125f * 4f, fParam3, 0);
      ui::set_text_scale(1f, func_59(14f));
    }
    else {
      ui::end_text_command_display_text(fParam2, fParam3, 0);
    }
  }
}

// Position - 0x5F54
float func_59(float fParam0) { return fParam0 * 0.025f; }

// Position - 0x5F64
float func_60(float fParam0) { return fParam0 * 0.0009259259f; }

// Position - 0x5F74
void func_61(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4,
             int iParam5, int iParam6, int iParam7, int iParam8, int iParam9,
             int iParam10, int iParam11, int iParam12, int iParam13,
             int iParam14, int iParam15, int iParam16) {
  int iVar0;
  int iVar1;

  iVar0 = -1;
  iVar1 = 0;
  while (iVar1 <= 9) {
    if (iVar0 == -1) {
      if (func_63(7, iVar1) == 0) {
        iVar0 = iVar1;
      }
    }
    iVar1++;
  }
  if (iVar0 > -1) {
    Global_1354542.f_1 = 1;
    func_62(7, iVar0);
    Global_1354542.f_4282[iVar0] = iParam0;
    StringCopy(&Global_1354542.f_4282.f_11[iVar0 /*16*/], sParam1, 64);
    Global_1354542.f_4282.f_172[iVar0] = iParam2;
    Global_1354542.f_4282.f_216[iVar0] = iParam3;
    Global_1354542.f_4282.f_183[iVar0] = iParam4;
    Global_1354542.f_4282.f_194[iVar0] = iParam5;
    Global_1354542.f_4282.f_249[iVar0] = iParam6;
    Global_1354542.f_4282.f_260[iVar0] = iParam7;
    Global_1354542.f_4282.f_205[iVar0] = iParam8;
    Global_1354542.f_4282.f_314[iVar0] = iParam9;
    Global_1354542.f_4282.f_325[iVar0] = iParam10;
    Global_1354542.f_4282.f_357[iVar0] = iParam11;
    Global_1354542.f_4282.f_238[iVar0] = iParam12;
    Global_1354542.f_4282.f_271[iVar0] = iParam13;
    Global_1354542.f_4282.f_368[iVar0] = iParam14;
    Global_1354542.f_4282.f_379[iVar0] = iParam15;
    Global_1354542.f_4282.f_390[iVar0] = iParam16;
  }
}

// Position - 0x60C2
void func_62(int iParam0, int iParam1) {
  gameplay::set_bit(&Global_1354542.f_5703[iParam0], iParam1);
}

// Position - 0x60DB
int func_63(int iParam0, int iParam1) {
  return gameplay::is_bit_set(Global_1354542.f_5703[iParam0], iParam1);
}

// Position - 0x60F4
float func_64(char *sParam0) {
  ui::_begin_text_command_width(sParam0);
  return ui::_end_text_command_get_width(1) / 2f;
}

// Position - 0x6109
void func_65() {
  graphics::_set_2d_layer(1);
  if (cam::is_screen_fading_out() || cam::is_screen_faded_out()) {
    graphics::_set_2d_layer(7);
  }
  graphics::_0xC6372ECD45D73BCD(0);
}

// Position - 0x6131
float func_66() {
  float fVar0;

  fVar0 = 1f;
  if (gameplay::is_pc_version()) {
  }
  return fVar0;
}

// Position - 0x6145
float func_67(float fParam0) { return fParam0 * 0.001388889f; }

// Position - 0x6155
void func_68() {
  if (Global_14443.f_1 != 1) {
    if (func_30(0)) {
      func_27(0);
    }
    gameplay::set_bit(&G_SleepModeOffOn11, 2);
  }
}

// Position - 0x617D
void func_69(var *uParam0) {
  if (uParam0->f_561 || uParam0->f_572 <= uParam0->f_558) {
    uParam0->f_561 = 0;
    uParam0->f_558 = uParam0->f_572 - 1;
  }
}

// Position - 0x61B0
bool func_70() { return Global_91530.f_1; }

// Position - 0x61BE
void func_71(var *uParam0, var *uParam1, int *iParam2, int iParam3,
             int *iParam4, int iParam5, int iParam6, var *uParam7, int iParam8,
             int iParam9, int iParam10, int iParam11, int *iParam12,
             int iParam13, int iParam14, int iParam15, var *uParam16,
             bool bParam17) {
  func_530(uParam0, uParam1, iParam2, iParam3, iParam4, iParam5, &iParam6,
           uParam7, iParam8, iParam9, iParam10, iParam11, iParam12, iParam13,
           iParam14, iParam15, uParam16, bParam17);
}

// Position - 0x61EE
int func_72(int iParam0, var *uParam1, var *uParam2, var *uParam3, int iParam4,
            int iParam5, int iParam6, int *iParam7, float fParam8,
            int *iParam9) {
  if (!func_239(uParam1, 5)) {
    ui::clear_help(1);
    func_172(uParam1, func_176(iParam0), iParam4, iParam5 - 1, iParam6, iParam7,
             fParam8);
    func_195(uParam1, 0, 215, "BJ_CONTINUE", 216, "BJ_RETRY", 353, 0, 353, 0);
    func_202(uParam1, 5, 1);
    system::settimera(0);
  }
  if (!func_239(uParam1, 6)) {
    if (func_168(&uParam1->f_26, 0, 0)) {
      func_202(uParam1, 6, 1);
    }
    else {
      return 2;
    }
  }
  if (func_239(uParam1, 27) && player::is_player_online()) {
    if (!func_239(uParam1, 26)) {
      func_195(uParam1, 0, 215, "BJ_CONTINUE", 216, "BJ_RETRY", 353, 0, 353, 0);
    }
    func_202(uParam1, 27, 0);
  }
  if (system::timera() > 1000) {
    if (*iParam9) {
      if (player::is_player_online()) {
        func_91(uParam2, iParam0);
        func_87(uParam1);
      }
      else if (func_74(&iLocal_614, 0)) {
        iLocal_614 = 0;
        *iParam9 = 0;
        func_195(uParam1, 0, 215, "BJ_CONTINUE", 216, "BJ_RETRY", 211,
                 "HUD_INPUT68", 353, 0);
      }
    }
    else {
      if (!func_239(uParam1, 10)) {
        audio::play_sound_frontend(-1, "BASE_JUMP_PASSED", "HUD_AWARDS", 1);
        func_202(uParam1, 10, 1);
      }
      func_44(&uParam1->f_26, 0, 1065353216, 0, 1, 0);
      func_87(uParam1);
    }
    if (*iParam9) {
      if (player::is_player_online()) {
        if (!func_239(uParam1, 28) && func_73(&uLocal_177)) {
          func_202(uParam1, 28, 1);
          func_195(uParam1, 0, 202, "HUD_INPUT53", 217, "SCLB_PROFILE", 353, 0,
                   353, 0);
        }
      }
      if (func_303(uParam3, 7, 1000)) {
        *iParam9 = 0;
        func_195(uParam1, 0, 215, "BJ_CONTINUE", 216, "BJ_RETRY", 211,
                 "HUD_INPUT68", 353, 0);
      }
    }
    else if (func_303(uParam3, 5, 1000)) {
      func_69(&uParam1->f_26);
      return 1;
    }
    else if (func_303(uParam3, 4, 1000)) {
      return 0;
    }
    else if (!*iParam9 && func_303(uParam3, 8, 1000) &&
             (!player::is_player_online() || func_239(uParam1, 26))) {
      *iParam9 = 1;
      if (player::is_player_online()) {
        if (func_73(&uLocal_177)) {
          func_202(uParam1, 28, 1);
          func_195(uParam1, 0, 202, "HUD_INPUT53", 217, "SCLB_PROFILE", 353, 0,
                   353, 0);
        }
        else {
          func_202(uParam1, 28, 0);
          func_195(uParam1, 0, 202, "HUD_INPUT53", 353, 0, 353, 0, 353, 0);
        }
      }
    }
  }
  return 2;
}

// Position - 0x647D
bool func_73(var *uParam0) {
  if (gameplay::is_bit_set(uParam0->f_42, 1) && Global_1835390.f_2704[0] > 0 &&
      uParam0->f_246.f_1 >= 0) {
    return true;
  }
  return false;
}

// Position - 0x64B4
bool func_74(int *iParam0, int iParam1) {
  int iVar0;
  int iVar1;
  int iVar2;

  iVar0 = 2;
  if (Global_1840922.f_2 + 5 < gameplay::get_frame_count() &&
      Global_1840922.f_2 > 0) {
    func_86(&Global_1840922);
    func_86(&Global_1840922.f_49);
    *iParam0 = 0;
    Global_1840922.f_2 = 0;
    func_85(0);
  }
  Global_1840922.f_2 = gameplay::get_frame_count();
  iVar1 = -1;
  if (gameplay::is_orbis_version()) {
    if (network::_0xBD545D44CCE70597() == 0) {
      iVar1 = network::_0x74FB3E29E6D10FA9();
    }
  }
  if (gameplay::is_orbis_version() &&
          (iVar1 == 4 || iVar1 == 2 || iVar1 == 1 || iVar1 == 5) ||
      !func_83() && network::network_is_signed_online()) {
    if (network::_0x8D11E61A4ABF49CC()) {
      func_80(&Global_1840922.f_3, func_82(&Global_1840922.f_3));
      if (!gameplay::is_bit_set(*iParam0, 4)) {
        gameplay::set_bit(iParam0, 4);
        StringCopy(&Global_1840922.f_3.f_1, "", 64);
        func_78(&Global_1840922.f_3, 0);
      }
    }
    else {
      if (iVar1 == 4) {
        ui::_set_warning_message_2("PM_INF_QMFT", "HUD_PROFILECHNG", iVar0, 0,
                                   0, -1, 0, 0, 1);
      }
      else if (iVar1 == 2) {
        ui::_set_warning_message_2("PM_INF_QMFT", "HUD_GAMEUPD_G", iVar0, 0, 0,
                                   -1, 0, 0, 1);
      }
      else if (iVar1 == 1) {
        ui::_set_warning_message_2("PM_INF_QMFT", "HUD_SYSTUPD_G", iVar0, 0, 0,
                                   -1, 0, 0, 1);
      }
      else if (iVar1 == 5) {
        ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0,
                                   -1, 0, 0, 1);
      }
      else if (!func_83()) {
        ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_ROS", iVar0, 0, 0,
                                   -1, 0, 0, 1);
      }
      if (!gameplay::is_bit_set(*iParam0, 0)) {
        if (!controls::is_control_pressed(2, 201)) {
          gameplay::set_bit(iParam0, 0);
        }
      }
      else if (controls::is_control_just_released(2, 201)) {
        func_86(&Global_1840922.f_49);
        func_86(&Global_1840922);
        *iParam0 = 0;
        Global_1840922.f_2 = 0;
        func_85(0);
        return true;
      }
    }
  }
  else {
    func_80(&Global_1840922.f_3, func_82(&Global_1840922.f_3));
    if (func_77(&Global_1840922.f_49) &&
        !func_75(&Global_1840922.f_49, 2000, 1) &&
        !network::network_is_signed_online()) {
      gameplay::set_bit(iParam0, 3);
      StringCopy(&Global_1840922.f_3.f_1, "", 64);
      func_78(&Global_1840922.f_3, 0);
    }
    else if (!gameplay::is_bit_set(*iParam0, 3)) {
      if (!gameplay::is_bit_set(*iParam0, 1)) {
        player::display_system_signin_ui(0);
        gameplay::set_bit(iParam0, 1);
        StringCopy(&Global_1840922.f_3.f_1, "", 64);
        func_78(&Global_1840922.f_3, 0);
      }
    }
    if (func_77(&Global_1840922)) {
      if (!func_75(&Global_1840922, 4000, 1)) {
        iVar2 = 1;
      }
    }
    if (!iVar2) {
      if (iParam1) {
        if (!network::network_is_signed_online()) {
          if (network::network_is_cable_connected()) {
            ui::_set_warning_message_2("PM_INF_QMFT", "STORE_NOT_ONL", iVar0, 0,
                                       0, -1, 0, 0, 1);
          }
          else {
            ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0,
                                       0, -1, 0, 0, 1);
          }
          if (!player::is_system_ui_being_displayed()) {
            if (!gameplay::is_bit_set(*iParam0, 0)) {
              if (!controls::is_control_pressed(2, 201)) {
                gameplay::set_bit(iParam0, 0);
              }
            }
            else if (controls::is_control_just_released(2, 201)) {
              func_86(&Global_1840922);
              *iParam0 = 0;
              Global_1840922.f_2 = 0;
              func_85(0);
              return true;
            }
          }
        }
        else {
          func_86(&Global_1840922);
          *iParam0 = 0;
          Global_1840922.f_2 = 0;
          func_85(0);
          return true;
        }
      }
      else if (gameplay::is_bit_set(*iParam0, 3)) {
        if (network::network_is_cable_connected()) {
          ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_SIGN_OUT", iVar0, 0,
                                     0, -1, 0, 0, 1);
        }
        else {
          ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0,
                                     -1, 0, 0, 1);
        }
        if (!gameplay::is_bit_set(*iParam0, 0)) {
          if (!controls::is_control_pressed(2, 201)) {
            gameplay::set_bit(iParam0, 0);
          }
        }
        else if (controls::is_control_just_released(2, 201)) {
          func_86(&Global_1840922.f_49);
          func_86(&Global_1840922);
          *iParam0 = 0;
          Global_1840922.f_2 = 0;
          func_85(0);
          return true;
        }
      }
      else {
        if (network::network_is_cable_connected()) {
          ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NOT_ONL", iVar0, 0, 0,
                                     -1, 0, 0, 1);
        }
        else {
          ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0,
                                     -1, 0, 0, 1);
        }
        if (!player::is_system_ui_being_displayed()) {
          if (!gameplay::is_bit_set(*iParam0, 0)) {
            if (!controls::is_control_pressed(2, 201)) {
              gameplay::set_bit(iParam0, 0);
            }
          }
          else if (controls::is_control_just_released(2, 201)) {
            func_86(&Global_1840922.f_49);
            func_86(&Global_1840922);
            *iParam0 = 0;
            Global_1840922.f_2 = 0;
            func_85(0);
            return true;
          }
        }
      }
    }
  }
  return false;
}

// Position - 0x691D
bool func_75(var *uParam0, int iParam1, int iParam2) {
  if (iParam1 == -1) {
    return true;
  }
  func_76(uParam0, iParam2, 0);
  if (network::network_is_game_in_progress() && !iParam2) {
    if (gameplay::absi(network::get_time_difference(network::get_network_time(),
                                                    *uParam0)) >= iParam1) {
      return true;
    }
  }
  else if (gameplay::absi(network::get_time_difference(
               gameplay::get_game_timer(), *uParam0)) >= iParam1) {
    return true;
  }
  return false;
}

// Position - 0x697B
void func_76(var *uParam0, int iParam1, int iParam2) {
  if (uParam0->f_1 == 0) {
    if (network::network_is_game_in_progress() && !iParam1) {
      if (!iParam2) {
        *uParam0 = network::get_network_time();
      }
      else {
        *uParam0 = network::_0x89023FBBF9200E9F();
      }
    }
    else {
      *uParam0 = gameplay::get_game_timer();
    }
    uParam0->f_1 = 1;
  }
}

// Position - 0x69C0
bool func_77(var *uParam0) { return uParam0->f_1; }

// Position - 0x69CC
void func_78(var *uParam0, int iParam1) {
  func_79(uParam0);
  if (iParam1) {
    func_85(0);
  }
  uParam0->f_35 = 1;
}

// Position - 0x69E9
void func_79(var *uParam0) {
  struct<46> Var0;

  Var0.f_41 = 1;
  *uParam0 = {Var0};
}

// Position - 0x6A04
void func_80(int *iParam0, int iParam1) {
  if (iParam1 == 1) {
    *iParam0 = 0;
    func_81(iParam0);
  }
  if (*iParam0 == 0) {
    if (iParam0->f_36) {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::add_text_component_integer(iParam0->f_33);
      ui::add_text_component_integer(iParam0->f_34);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    else if (iParam0->f_37) {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::add_text_component_integer(iParam0->f_33);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    else if (iParam0->f_39) {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::add_text_component_substring_player_name(&iParam0->f_17);
      ui::add_text_component_integer(iParam0->f_33);
      ui::add_text_component_integer(iParam0->f_34);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    else if (iParam0->f_38) {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::add_text_component_substring_player_name(&iParam0->f_17);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    else if (iParam0->f_40) {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::add_text_component_substring_time(iParam0->f_33, 70);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    else {
      ui::_set_loading_prompt_text_entry(&iParam0->f_1);
      ui::_show_loading_prompt(iParam0->f_41);
    }
    *iParam0 = 1;
  }
  if (*iParam0 == 1) {
  }
}

// Position - 0x6B02
void func_81(int *iParam0) { iParam0->f_35 = 0; }

// Position - 0x6B0F
int func_82(var *uParam0) { return uParam0->f_35; }

// Position - 0x6B1B
int func_83() {
  if (func_84()) {
    return 0;
  }
  if (network::network_is_cloud_available() == 0) {
    return 0;
  }
  return 1;
}

// Position - 0x6B3B
bool func_84() { return Global_2453019; }

// Position - 0x6B47
void func_85(int iParam0) {
  ui::_remove_loading_prompt();
  if (iParam0) {
    ui::_0xC65AB383CD91DF98();
  }
}

// Position - 0x6B5C
void func_86(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0x6B69
void func_87(var *uParam0) {
  int iVar0;
  float fVar1;
  int iVar2;

  if (!func_90(uParam0)) {
    return;
  }
  graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
  if (controls::_0x6CD79468A1E595C6(2)) {
    iVar0 = 0;
    while (iVar0 < uParam0->f_3) {
      if (uParam0->f_3[iVar0] != 353) {
        uParam0->f_12[iVar0] = controls::get_control_instructional_button(
            2, uParam0->f_3[iVar0], 1);
      }
      iVar0++;
    }
    func_88(&uParam0->f_1, 4);
  }
  if (!func_23(uParam0->f_1, 4)) {
    graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
    graphics::_push_scaleform_movie_function_parameter_float(200f);
    graphics::_pop_scaleform_movie_function_void();
    graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
    graphics::_pop_scaleform_movie_function_void();
    fVar1 = 0f;
    iVar2 = 0;
    while (iVar2 < 4) {
      if (!gameplay::is_string_null_or_empty(uParam0->f_21[iVar2])) {
        if (!gameplay::is_string_null_or_empty(uParam0->f_12[iVar2 + 4])) {
          graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT");
          graphics::_push_scaleform_movie_function_parameter_float(fVar1);
          func_9(uParam0->f_12[iVar2 + 4]);
          func_9(uParam0->f_12[iVar2]);
          func_14(uParam0->f_21[iVar2]);
          graphics::_pop_scaleform_movie_function_void();
        }
        else {
          graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT");
          graphics::_push_scaleform_movie_function_parameter_float(fVar1);
          func_9(uParam0->f_12[iVar2]);
          func_14(uParam0->f_21[iVar2]);
          graphics::_pop_scaleform_movie_function_void();
        }
        fVar1++;
      }
      iVar2++;
    }
    graphics::_push_scaleform_movie_function(*uParam0,
                                             "DRAW_INSTRUCTIONAL_BUTTONS");
    graphics::_push_scaleform_movie_function_parameter_float(
        system::to_float(uParam0->f_2));
    graphics::_pop_scaleform_movie_function_void();
    graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(0f);
    graphics::_push_scaleform_movie_function_parameter_float(80f);
    graphics::_pop_scaleform_movie_function_void();
    func_21(&uParam0->f_1, 4);
  }
}

// Position - 0x6D02
void func_88(int *iParam0, int iParam1) { func_89(iParam0, iParam1); }

// Position - 0x6D12
void func_89(int *iParam0, var uParam1) { *iParam0 -= (*iParam0 & uParam1); }

// Position - 0x6D27
int func_90(var *uParam0) {
  if (*uParam0 != 0) {
    if (graphics::has_scaleform_movie_loaded(*uParam0)) {
      func_21(&uParam0->f_1, 1);
      return 1;
    }
  }
  return 0;
}

// Position - 0x6D4E
void func_91(var *uParam0, int iParam1) { func_92(uParam0, &uLocal_177); }

// Position - 0x6D5E
void func_92(var *uParam0, var *uParam1) {
  int iVar0;
  int iVar1;
  var uVar2[3];
  int iVar6;
  int iVar7;
  bool bVar8;
  struct<8> Var9;
  char[] cVar25[8];
  int iVar27[3];
  int iVar31;
  struct<13> Var32;
  var uVar45;
  vector3 vVar51;
  vector3 vVar57;
  int iVar63;

  func_167(&Global_1840922.f_49, 1, 0);
  ui::hide_help_text_this_frame();
  func_166();
  func_68();
  ui::hide_hud_and_radar_this_frame();
  func_164();
  ui::hide_hud_component_this_frame(10);
  func_163(1);
  func_162(1);
  if (!func_159()) {
    if (!audio::is_audio_scene_active("LEADERBOARD_SCENE")) {
      audio::start_audio_scene("LEADERBOARD_SCENE");
    }
  }
  if (!gameplay::is_bit_set(uParam1->f_42, 3)) {
    *uParam0 = func_158();
    gameplay::set_bit(&uParam1->f_42, 3);
  }
  Var32 = {func_55(player::player_id())};
  if (graphics::has_scaleform_movie_loaded(*uParam0)) {
    if (!network::_network_are_ros_available() || !player::is_player_online() ||
        !network::network_have_online_privileges() &&
            network::_0x1353F87E89946207() ||
        Global_1835390.f_2832 != 0) {
      if (!player::is_player_online()) {
        if (Global_1835390.f_2829 != 2) {
          gameplay::clear_bit(&uParam1->f_42, 1);
          Global_1835390.f_2829 = 2;
        }
      }
      else if (!network::network_have_online_privileges() &&
               network::_0x1353F87E89946207()) {
        if (Global_1835390.f_2829 != 3) {
          gameplay::clear_bit(&uParam1->f_42, 1);
          Global_1835390.f_2829 = 3;
        }
      }
      else if (!network::_network_are_ros_available()) {
        if (Global_1835390.f_2829 != 4) {
          gameplay::clear_bit(&uParam1->f_42, 1);
          Global_1835390.f_2829 = 4;
        }
      }
      else if (Global_1835390.f_2832 != 0) {
        if (Global_1835390.f_2829 != 5) {
          gameplay::clear_bit(&uParam1->f_42, 1);
          Global_1835390.f_2829 = 5;
        }
      }
      if (!gameplay::is_bit_set(uParam1->f_42, 1)) {
        graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
        graphics::_pop_scaleform_movie_function_void();
        func_157(*uParam0, Global_1835390.f_2780);
        if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
          if (!func_156(uParam1->f_44)) {
            if (Global_1835390.f_2780.f_26 > 0) {
              Var9 = {Global_1835390.f_2780.f_9};
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9,
                       Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
            }
            else {
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25,
                       &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                       -1);
            }
          }
          else if (!Global_1835390.f_2780.f_27) {
            StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
            if (Global_1835390.f_2780.f_26 > 0) {
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                       &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                       Global_1835390.f_2780.f_26);
            }
            else {
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                       &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                       -1);
            }
          }
          else {
            StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
            if (Global_1835390.f_2780.f_26 > 0) {
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                       &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                       Global_1835390.f_2780.f_26);
            }
            else {
              func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                       &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                       -1);
            }
          }
          func_154(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717,
                   Global_1835390.f_2708);
        }
        iVar31 = 0;
        gameplay::set_bit(&iVar31, 4);
        func_153(*uParam0, &iVar6, iVar31, 1, 1);
        iVar31 = 0;
        gameplay::set_bit(&iVar31, 5);
        func_153(*uParam0, &iVar6, iVar31, 1, 1);
        iVar31 = 0;
        gameplay::set_bit(&iVar31, 6);
        func_153(*uParam0, &iVar6, iVar31, 1, 1);
        gameplay::set_bit(&uParam1->f_42, 1);
        func_152(*uParam0);
        gameplay::clear_bit(&uParam1->f_42, 2);
        ui::clear_help(1);
      }
      else {
        func_152(*uParam0);
      }
    }
    else {
      if (Global_1835390.f_2829 != 1) {
        gameplay::clear_bit(&uParam1->f_42, 1);
        Global_1835390.f_2829 = 1;
      }
      if (!func_116(uParam1)) {
        uParam1->f_246.f_1 = -1;
        gameplay::clear_bit(&uParam1->f_42, 1);
        if (!gameplay::is_bit_set(uParam1->f_42, 0)) {
          graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
          graphics::_pop_scaleform_movie_function_void();
          func_157(*uParam0, Global_1835390.f_2780);
          if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
            if (!func_156(uParam1->f_44)) {
              if (Global_1835390.f_2780.f_26 > 0) {
                Var9 = {Global_1835390.f_2780.f_9};
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9,
                         1, Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            else if (!Global_1835390.f_2780.f_27) {
              StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
              if (Global_1835390.f_2780.f_26 > 0) {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            else {
              StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
              if (Global_1835390.f_2780.f_26 > 0) {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            func_154(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717,
                     Global_1835390.f_2708);
          }
          gameplay::set_bit(&uParam1->f_42, 0);
          gameplay::clear_bit(&uParam1->f_42, 2);
        }
        iVar6 = 0;
        iVar0 = 0;
        if (Global_1835390.f_2825 == -1) {
          StringCopy(&vVar51, "SC_LB_DL0", 24);
          iVar0 = 0;
          while (iVar0 < 3) {
            if (iVar0 == 0) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 4);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            else if (iVar0 == 1) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 5);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            else if (iVar0 == 2) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 6);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            iVar31 = 0;
            gameplay::set_bit(&iVar31, 7);
            func_115(*uParam0, iVar6, iVar31, &vVar51);
            iVar6++;
            iVar0++;
          }
          Global_1835390.f_2825 = 1;
          func_86(&Global_1835390.f_2823);
        }
        else if (func_75(&Global_1835390.f_2823, 300, 0)) {
          StringCopy(&vVar57, "SC_LB_DL", 24);
          StringIntConCat(&vVar57, Global_1835390.f_2825, 24);
          iVar0 = 0;
          while (iVar0 < 3) {
            if (iVar0 == 0) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 4);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            else if (iVar0 == 1) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 5);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            else if (iVar0 == 2) {
              iVar31 = 0;
              gameplay::set_bit(&iVar31, 6);
              func_153(*uParam0, &iVar6, iVar31, 0, 0);
            }
            iVar31 = 0;
            gameplay::set_bit(&iVar31, 7);
            func_115(*uParam0, iVar6, iVar31, &vVar57);
            iVar6++;
            iVar0++;
          }
          Global_1835390.f_2825++;
          if (Global_1835390.f_2825 > 3) {
            Global_1835390.f_2825 = 0;
          }
          func_86(&Global_1835390.f_2823);
        }
        func_152(*uParam0);
      }
      else {
        gameplay::clear_bit(&uParam1->f_42, 0);
        if (!gameplay::is_bit_set(uParam1->f_42, 1)) {
          iVar0 = 0;
          while (iVar0 < 3) {
            uParam1->f_246.f_187[iVar0] = 0;
            iVar0++;
          }
          graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
          graphics::_pop_scaleform_movie_function_void();
          func_157(*uParam0, Global_1835390.f_2780);
          if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
            if (!func_156(uParam1->f_44)) {
              if (Global_1835390.f_2780.f_26 > 0) {
                Var9 = {Global_1835390.f_2780.f_9};
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9,
                         1, Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &cVar25,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            else if (!Global_1835390.f_2780.f_27) {
              StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
              if (Global_1835390.f_2780.f_26 > 0) {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            else {
              StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
              if (Global_1835390.f_2780.f_26 > 0) {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         Global_1835390.f_2780.f_26);
              }
              else {
                func_155(*uParam0, &Global_1835390.f_2780.f_1, &Var9,
                         &Global_1835390.f_2780.f_9, Global_1835390.f_2780.f_25,
                         -1);
              }
            }
            func_154(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717,
                     Global_1835390.f_2708);
          }
          if (!gameplay::is_bit_set(uParam1->f_42, 6)) {
            func_114(&Global_1839721);
            func_110(uParam1, &Global_1839721);
            func_109(uParam1, &Global_1839721);
          }
          iVar6 = 0;
          uParam1->f_246.f_2 = 0;
          if (Global_1835390.f_2704[0] > 1 ||
              Global_1835390.f_2704[0] > 0 && Global_1835390.f_2775[0] != -1 ||
              Global_1835390.f_2704[0] > 0 && Global_1835390.f_2780.f_27 &&
                  func_156(uParam1->f_44) && Global_1835390.f_2775[0] != -1) {
            uParam1->f_246.f_1 = -1;
            iVar0 = 0;
            iVar0 = 0;
            while (iVar0 < 12) {
              iVar63 = 0;
              if (Global_1839721[iVar0 /*100*/].f_75 == 1) {
                if (!iVar27[0]) {
                  iVar31 = 0;
                  gameplay::set_bit(&iVar31, 4);
                  func_153(*uParam0, &iVar6, iVar31, 0, 0);
                  iVar27[0] = 1;
                }
              }
              else if (Global_1839721[iVar0 /*100*/].f_75 == 2) {
                if (!iVar27[1]) {
                  iVar31 = 0;
                  gameplay::set_bit(&iVar31, 5);
                  if (Global_1835390.f_2704[1] < 1 &&
                      Global_1835390.f_2775[1] == -1 &&
                      !(Global_1835390.f_2704[1] > 0 &&
                        Global_1835390.f_2780.f_27 && func_156(uParam1->f_44) &&
                        Global_1835390.f_2775[1] != -1)) {
                    func_153(*uParam0, &iVar6, iVar31, 1, 0);
                    iVar63 = 1;
                  }
                  else {
                    func_153(*uParam0, &iVar6, iVar31, 0, 0);
                  }
                  iVar27[1] = 1;
                }
              }
              else if (Global_1839721[iVar0 /*100*/].f_75 == 3) {
                if (!iVar27[2]) {
                  iVar31 = 0;
                  gameplay::set_bit(&iVar31, 6);
                  if (!network::_0x67A5589628E0CFF6()) {
                    iVar63 = 1;
                  }
                  else if (!network::_0xBA9775570DB788CF()) {
                    iVar63 = 1;
                  }
                  if (Global_1835390.f_2704[2] < 2 &&
                      Global_1835390.f_2775[2] == -1 &&
                      !(Global_1835390.f_2704[2] > 0 &&
                        Global_1835390.f_2780.f_27 && func_156(uParam1->f_44) &&
                        Global_1835390.f_2775[2] != -1)) {
                    iVar63 = 1;
                  }
                  if (iVar63) {
                    func_153(*uParam0, &iVar6, iVar31, 1, 0);
                  }
                  else {
                    func_153(*uParam0, &iVar6, iVar31, 0, 0);
                  }
                  iVar27[2] = 1;
                }
              }
              if (func_108(Global_1839721[iVar0 /*100*/].f_32)) {
                if (func_156(uParam1->f_44)) {
                  network::network_player_get_userid(player::player_id(),
                                                     &uVar45);
                  if (!Global_1839721[iVar0 /*100*/].f_74 &&
                      gameplay::are_strings_equal(
                          &uParam1->f_44.f_3.f_1[1 /*16*/].f_8, &uVar45)) {
                    iVar63 = 1;
                  }
                }
                if (!iVar63) {
                  iVar31 = 0;
                  if (!Global_1835390.f_2780.f_27) {
                    if (func_107(&Global_1839721[iVar0 /*100*/].f_32, &Var32)) {
                      gameplay::set_bit(&iVar31, 1);
                      if (uParam1->f_246.f_1 == -1) {
                        iVar7 = 1;
                        uParam1->f_246.f_1 = iVar0;
                        gameplay::set_bit(&iVar31, 3);
                      }
                    }
                  }
                  if (func_156(uParam1->f_44)) {
                    Var9 = {Global_1839721[iVar0 /*100*/]};
                    if (!gameplay::is_string_null_or_empty(
                            &Global_1839721[iVar0 /*100*/].f_84) &&
                        !gameplay::are_strings_equal(
                            &Global_1839721[iVar0 /*100*/].f_84, "")) {
                      StringConCat(&Var9, "/", 64);
                      StringConCat(&Var9, &Global_1839721[iVar0 /*100*/].f_84,
                                   64);
                    }
                    func_106(*uParam0, iVar6, iVar31,
                             Global_1839721[iVar0 /*100*/].f_59, &Var9,
                             &Global_1839721[iVar0 /*100*/].f_80);
                    uParam1->f_246.f_6[iVar0 /*15*/] = iVar6;
                    uParam1->f_246.f_6[iVar0 /*15*/].f_1 = iVar31;
                    uParam1->f_246.f_6[iVar0 /*15*/].f_2 = {
                        Global_1839721[iVar0 /*100*/].f_32};
                    uParam1->f_246.f_2++;
                  }
                  else {
                    func_106(*uParam0, iVar6, iVar31,
                             Global_1839721[iVar0 /*100*/].f_59,
                             &Global_1839721[iVar0 /*100*/],
                             &Global_1839721[iVar0 /*100*/].f_80);
                    uParam1->f_246.f_6[iVar0 /*15*/] = iVar6;
                    uParam1->f_246.f_6[iVar0 /*15*/].f_1 = iVar31;
                    uParam1->f_246.f_6[iVar0 /*15*/].f_2 = {
                        Global_1839721[iVar0 /*100*/].f_32};
                    uParam1->f_246.f_2++;
                  }
                  iVar1 = 0;
                  while (iVar1 < Global_1835390.f_2708) {
                    bVar8 = false;
                    if (gameplay::is_bit_set(Global_1835390.f_2770, iVar1)) {
                      if (gameplay::is_bit_set(Global_1835390.f_2768, iVar1)) {
                        if (Global_1835390.f_2754[iVar1] ==
                            Global_1839721[iVar0 /*100*/].f_67[iVar1]) {
                          bVar8 = true;
                        }
                      }
                      if (bVar8) {
                        func_101(Global_1835390.f_2780, iVar1,
                                 Global_1839721[iVar0 /*100*/].f_67[iVar1], 0,
                                 Global_1839721[iVar0 /*100*/].f_58);
                      }
                      else {
                        func_101(Global_1835390.f_2780, iVar1,
                                 Global_1839721[iVar0 /*100*/].f_67[iVar1],
                                 Global_1839721[iVar0 /*100*/].f_74,
                                 Global_1839721[iVar0 /*100*/].f_58);
                      }
                    }
                    else {
                      if (gameplay::is_bit_set(Global_1835390.f_2768, iVar1)) {
                        if (Global_1835390.f_2761[iVar1] ==
                            Global_1839721[iVar0 /*100*/].f_67[iVar1]) {
                          bVar8 = true;
                        }
                      }
                      if (bVar8) {
                        func_98(Global_1835390.f_2780, iVar1,
                                Global_1839721[iVar0 /*100*/].f_60[iVar1], 0);
                      }
                      else {
                        func_98(Global_1835390.f_2780, iVar1,
                                Global_1839721[iVar0 /*100*/].f_60[iVar1],
                                Global_1839721[iVar0 /*100*/].f_74);
                      }
                    }
                    iVar1++;
                  }
                  func_97();
                  uVar2[Global_1839721[iVar0 /*100*/].f_75 - 1]++;
                  if (uVar2[Global_1839721[iVar0 /*100*/].f_75 - 1] == 2) {
                    if (Global_1839721[iVar0 /*100*/].f_59 > 2) {
                      gameplay::set_bit(&iVar31, 2);
                      gameplay::set_bit(&uParam1->f_246.f_6[0 /*15*/].f_1, 2);
                      func_96(*uParam0, iVar6 - 1, iVar31);
                    }
                  }
                  iVar6++;
                }
              }
              iVar0++;
            }
            iVar0 = 0;
            iVar0 = 0;
            while (iVar0 < 3) {
              uParam1->f_246.f_187[iVar0] = uVar2[iVar0];
              iVar0++;
            }
          }
          else {
            iVar31 = 0;
            gameplay::set_bit(&iVar31, 4);
            func_153(*uParam0, &iVar6, iVar31, 1, 0);
            iVar31 = 0;
            gameplay::set_bit(&iVar31, 5);
            func_153(*uParam0, &iVar6, iVar31, 1, 0);
            iVar31 = 0;
            gameplay::set_bit(&iVar31, 6);
            func_153(*uParam0, &iVar6, iVar31, 1, 0);
          }
          gameplay::set_bit(&uParam1->f_42, 1);
          gameplay::clear_bit(&uParam1->f_42, 2);
          func_152(*uParam0);
          ui::clear_help(1);
          if (uParam1->f_246.f_1 == -1 && !iVar7 == 1) {
            if (Global_1835390.f_2704[0] > 1) {
              uParam1->f_246.f_1 = 0;
              gameplay::set_bit(
                  &uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1, 3);
              func_96(*uParam0, uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/],
                      uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1);
            }
          }
        }
        else {
          func_152(*uParam0);
          func_93(uParam0, uParam1);
        }
      }
    }
  }
}

// Position - 0x7D39
void func_93(var *uParam0, var *uParam1) {
  int iVar0;
  int iVar1;
  int iVar2;
  int iVar3;
  var uVar4;
  var *uVar5;
  int iVar6;
  var *uVar7;
  var *uVar8;

  iVar1 = uParam1->f_246.f_1;
  if (controls::_is_input_disabled(2)) {
    ui::_show_cursor_this_frame();
    controls::set_input_exclusive(2, 239);
    controls::set_input_exclusive(2, 240);
    controls::set_input_exclusive(2, 237);
    controls::set_input_exclusive(2, 238);
    controls::disable_control_action(2, 200, 1);
    if (controls::is_disabled_control_pressed(2, 241)) {
      controls::_set_control_normal(2, 188, 1f);
    }
    if (controls::is_disabled_control_pressed(2, 242)) {
      controls::_set_control_normal(2, 187, 1f);
    }
    if (ui::_0x632B2940C67F4EA9(*uParam0, &iVar2, &iVar3, &uVar4)) {
      if (iVar2 == 5) {
        if (iVar3 > uParam1->f_246.f_187[0]) {
          if (iVar3 <= uParam1->f_246.f_187[0] + uParam1->f_246.f_187[1] + 2) {
            iVar3 -= 2;
          }
          else {
            iVar3 -= 4;
          }
        }
        iVar3--;
        if (uParam1->f_246.f_1 != iVar3) {
          uParam1->f_246.f_1 = iVar3;
          audio::play_sound_frontend(-1, "NAV_UP_DOWN",
                                     "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
          iVar0 = 1;
        }
        else {
          controls::_set_control_normal(2, 217, 1f);
        }
      }
    }
  }
  if (!controls::_is_input_disabled(2)) {
    func_95(&uVar5, &iVar6, &uVar7, &uVar8, 0);
  }
  if (uParam1->f_246.f_2 > 0) {
    if (!gameplay::is_bit_set(uParam1->f_246, 0)) {
      if (controls::is_control_pressed(2, 188) ||
          controls::is_disabled_control_pressed(2, 188) || iVar6 < -100) {
        audio::play_sound_frontend(-1, "NAV_UP_DOWN",
                                   "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
        uParam1->f_246.f_1 += -1;
        gameplay::set_bit(&uParam1->f_246, 0);
        func_86(&uParam1->f_246.f_3);
        iVar0 = 1;
      }
    }
    else if (func_94(uParam1, 188)) {
      gameplay::clear_bit(&uParam1->f_246, 0);
    }
    if (!gameplay::is_bit_set(uParam1->f_246, 1)) {
      if (controls::is_control_pressed(2, 187) ||
          controls::is_disabled_control_pressed(2, 187) || iVar6 > 100) {
        audio::play_sound_frontend(-1, "NAV_UP_DOWN",
                                   "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
        uParam1->f_246.f_1++;
        gameplay::set_bit(&uParam1->f_246, 1);
        func_86(&uParam1->f_246.f_3);
        iVar0 = 1;
      }
    }
    else if (func_94(uParam1, 187)) {
      gameplay::clear_bit(&uParam1->f_246, 1);
    }
  }
  if (iVar0) {
    if (uParam1->f_246.f_1 < 0) {
      uParam1->f_246.f_1 = uParam1->f_246.f_2 - 1;
    }
    if (uParam1->f_246.f_1 >= uParam1->f_246.f_2) {
      uParam1->f_246.f_1 = 0;
    }
  }
  if (!gameplay::is_bit_set(uParam1->f_246, 3)) {
    if (controls::is_control_pressed(2, 204) ||
        controls::is_disabled_control_just_pressed(2, 204) ||
        controls::is_control_just_pressed(2, 237)) {
      gameplay::set_bit(&uParam1->f_246, 3);
      func_86(&uParam1->f_246.f_3);
      iVar0 = 1;
    }
  }
  else if (func_94(uParam1, 204)) {
    gameplay::clear_bit(&uParam1->f_246, 3);
  }
  if (uParam1->f_246.f_1 >= 0) {
    if (uParam1->f_246.f_1 != iVar1) {
      if (iVar1 >= 0) {
        gameplay::clear_bit(&uParam1->f_246.f_6[iVar1 /*15*/].f_1, 3);
        func_96(*uParam0, uParam1->f_246.f_6[iVar1 /*15*/],
                uParam1->f_246.f_6[iVar1 /*15*/].f_1);
      }
      gameplay::set_bit(&uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1, 3);
      func_96(*uParam0, uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/],
              uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1);
      gameplay::clear_bit(&uParam1->f_42, 2);
    }
    if (func_108(uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_2)) {
      if (!gameplay::is_bit_set(uParam1->f_246, 2)) {
        if (controls::is_control_pressed(2, 217) ||
            controls::is_disabled_control_just_pressed(2, 217)) {
          if (!player::is_system_ui_being_displayed()) {
            audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_MP_SOUNDSET",
                                       1);
            gameplay::set_bit(&uParam1->f_246, 2);
            network::network_show_profile_ui(
                &uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_2);
          }
        }
      }
      else if (!controls::is_control_pressed(2, 217)) {
        gameplay::clear_bit(&uParam1->f_246, 2);
      }
    }
  }
}

// Position - 0x80DD
bool func_94(var *uParam0, int iParam1) {
  var *uVar0;
  int iVar1;
  var *uVar2;
  var *uVar3;

  if (iParam1 == 188 || iParam1 == 187) {
    func_95(&uVar0, &iVar1, &uVar2, &uVar3, 0);
    if (!controls::is_control_pressed(2, iParam1) &&
            !controls::is_disabled_control_pressed(2, iParam1) && iVar1 < 75 &&
            iVar1 > -75 ||
        func_75(&uParam0->f_246.f_3, 250, 0)) {
      return true;
    }
  }
  else if (!controls::is_control_pressed(2, iParam1) &&
               !controls::is_disabled_control_pressed(2, iParam1) ||
           func_75(&uParam0->f_246.f_3, 250, 0)) {
    return true;
  }
  return false;
}

// Position - 0x817C
void func_95(var *uParam0, var *uParam1, var *uParam2, var *uParam3,
             int iParam4) {
  *uParam0 = system::floor(controls::get_control_normal(2, 218) * 127f);
  *uParam1 = system::floor(controls::get_control_normal(2, 219) * 127f);
  *uParam2 = system::floor(controls::get_control_normal(2, 220) * 127f);
  *uParam3 = system::floor(controls::get_control_normal(2, 221) * 127f);
  if (iParam4) {
    if (IntToFloat(*uParam0) == 0f && IntToFloat(*uParam1) == 0f) {
      *uParam0 =
          system::floor(controls::get_disabled_control_normal(2, 218) * 127f);
      *uParam1 =
          system::floor(controls::get_disabled_control_normal(2, 219) * 127f);
    }
    if (IntToFloat(*uParam2) == 0f && IntToFloat(*uParam3) == 0f) {
      *uParam2 =
          system::floor(controls::get_disabled_control_normal(2, 220) * 127f);
      *uParam3 =
          system::floor(controls::get_disabled_control_normal(2, 221) * 127f);
    }
  }
}

// Position - 0x8251
void func_96(int iParam0, int iParam1, int iParam2) {
  graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT_STATE");
  graphics::_push_scaleform_movie_function_parameter_int(iParam1);
  graphics::_push_scaleform_movie_function_parameter_int(iParam2);
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x8274
void func_97() { graphics::_pop_scaleform_movie_function_void(); }

// Position - 0x8280
void func_98(struct<30> Param0, var uParam30, var uParam31, var uParam32,
             var uParam33, var uParam34, var uParam35, var uParam36,
             var uParam37, var uParam38, var uParam39, var uParam40,
             var uParam41, var uParam42, int iParam43, float fParam44,
             int iParam45) {
  switch (Param0.f_29[iParam43]) {
  case 4:
    if (iParam45) {
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_float(fParam44, 2);
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 12:
    if (iParam45) {
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_integer(system::floor(fParam44));
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 17:
  case 19:
  case 18:
  case 20:
    if (iParam45) {
      if (Param0.f_29[iParam43] == 18 || Param0.f_29[iParam43] == 20) {
        fParam44 *= -1f;
      }
      if (!gameplay::_0xD3D15555431AB793()) {
        if (Param0.f_29[iParam43] == 19 || Param0.f_29[iParam43] == 20) {
          fParam44 = func_100(fParam44);
        }
        else {
          fParam44 = func_99(fParam44);
        }
      }
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_float(fParam44, 2);
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 0: break;
  }
}

// Position - 0x83A2
float func_99(float fParam0) { return fParam0 / 0.3048f; }

// Position - 0x83B2
float func_100(float fParam0) { return fParam0 / 1609.344f; }

// Position - 0x83C2
void func_101(struct<30> Param0, var uParam30, var uParam31, var uParam32,
              var uParam33, var uParam34, var uParam35, var uParam36,
              var uParam37, var uParam38, var uParam39, var uParam40,
              var uParam41, var uParam42, int iParam43, int iParam44,
              int iParam45, bool bParam46) {
  if (iParam44 == 2147483647 || iParam44 == -2147483647) {
    iParam45 = 0;
  }
  switch (Param0.f_29[iParam43]) {
  case 5:
    if (iParam45) {
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_integer(iParam44);
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 7:
    if (iParam45) {
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_integer(-iParam44);
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 1:
  case 9:
  case 11:
    if (iParam45) {
      if (Param0.f_29[iParam43] == 11 && iParam44 < 0) {
        iParam44 *= -1;
      }
      if (iParam44 >= 3600000 || iParam44 <= -3600000) {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 14);
        graphics::end_text_command_scaleform_string();
      }
      else if (Param0.f_29[iParam43] == 9) {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 6);
        graphics::end_text_command_scaleform_string();
      }
      else {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 2055);
        graphics::end_text_command_scaleform_string();
      }
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 6:
    if (iParam45) {
      if (iParam44 == 2147483647) {
        graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
        graphics::end_text_command_scaleform_string();
      }
      else if (iParam44 >= 3600000 || iParam44 <= -3600000) {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 14);
        graphics::end_text_command_scaleform_string();
      }
      else {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 2055);
        graphics::end_text_command_scaleform_string();
      }
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 2:
  case 10:
    if (iParam45) {
      iParam44 *= -1;
      if (iParam44 >= 3600000 || iParam44 <= -3600000) {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 14);
        graphics::end_text_command_scaleform_string();
      }
      else if (Param0.f_29[iParam43] == 10) {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 6);
        graphics::end_text_command_scaleform_string();
      }
      else {
        graphics::begin_text_command_scaleform_string("STRING");
        ui::add_text_component_substring_time(iParam44, 2055);
        graphics::end_text_command_scaleform_string();
      }
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 3:
    if (bParam46) {
      if (streaming::is_model_in_cdimage(iParam44)) {
        graphics::begin_text_command_scaleform_string("SCLB_VEH_CUST");
        ui::add_text_component_substring_text_label(
            vehicle::get_display_name_from_vehicle_model(iParam44));
        graphics::end_text_command_scaleform_string();
      }
      else {
        graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
        graphics::end_text_command_scaleform_string();
      }
    }
    else if (streaming::is_model_in_cdimage(iParam44)) {
      graphics::begin_text_command_scaleform_string(
          vehicle::get_display_name_from_vehicle_model(iParam44));
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 8:
    if (func_105(iParam44) != 0) {
      graphics::begin_text_command_scaleform_string(
          func_102(func_105(iParam44), 0));
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 13:
  case 15:
  case 14:
  case 16:
    if (iParam45) {
      if (Param0.f_29[iParam43] == 14 || Param0.f_29[iParam43] == 16) {
        iParam44 *= -1;
      }
      if (!gameplay::_0xD3D15555431AB793()) {
        if (Param0.f_29[iParam43] == 15 || Param0.f_29[iParam43] == 16) {
          iParam44 = system::floor(func_100(system::to_float(iParam44)));
        }
        else {
          iParam44 = system::floor(func_99(system::to_float(iParam44)));
        }
      }
      graphics::begin_text_command_scaleform_string("NUMBER");
      ui::add_text_component_integer(iParam44);
      graphics::end_text_command_scaleform_string();
    }
    else {
      graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
      graphics::end_text_command_scaleform_string();
    }
    break;

  case 0: break;
  }
}

// Position - 0x875C
char *func_102(int iParam0, int iParam1) {
  struct<32> Var0;

  switch (iParam0) {
  case 0:
    if (iParam1) {
      return "WTU_INVALID";
    }
    else {
      return "WT_INVALID";
    }
    break;

  case joaat("weapon_unarmed"):
    if (iParam1) {
      return "WTU_UNARMED";
    }
    else {
      return "WT_UNARMED";
    }
    break;

  case joaat("weapon_pistol"):
    if (iParam1) {
      return "WTU_PIST";
    }
    else {
      return "WT_PIST";
    }
    break;

  case joaat("weapon_combatpistol"):
    if (iParam1) {
      return "WTU_PIST_CBT";
    }
    else {
      return "WT_PIST_CBT";
    }
    break;

  case joaat("weapon_appistol"):
    if (iParam1) {
      return "WTU_PIST_AP";
    }
    else {
      return "WT_PIST_AP";
    }
    break;

  case joaat("weapon_smg"):
    if (iParam1) {
      return "WTU_SMG";
    }
    else {
      return "WT_SMG";
    }
    break;

  case joaat("weapon_microsmg"):
    if (iParam1) {
      return "WTU_SMG_MCR";
    }
    else {
      return "WT_SMG_MCR";
    }
    break;

  case joaat("weapon_assaultrifle"):
    if (iParam1) {
      return "WTU_RIFLE_ASL";
    }
    else {
      return "WT_RIFLE_ASL";
    }
    break;

  case joaat("weapon_carbinerifle"):
    if (iParam1) {
      return "WTU_RIFLE_CBN";
    }
    else {
      return "WT_RIFLE_CBN";
    }
    break;

  case joaat("weapon_advancedrifle"):
    if (iParam1) {
      return "WTU_RIFLE_ADV";
    }
    else {
      return "WT_RIFLE_ADV";
    }
    break;

  case joaat("weapon_mg"):
    if (iParam1) {
      return "WTU_MG";
    }
    else {
      return "WT_MG";
    }
    break;

  case joaat("weapon_combatmg"):
    if (iParam1) {
      return "WTU_MG_CBT";
    }
    else {
      return "WT_MG_CBT";
    }
    break;

  case joaat("weapon_pumpshotgun"):
    if (iParam1) {
      return "WTU_SG_PMP";
    }
    else {
      return "WT_SG_PMP";
    }
    break;

  case joaat("weapon_sawnoffshotgun"):
    if (iParam1) {
      return "WTU_SG_SOF";
    }
    else {
      return "WT_SG_SOF";
    }
    break;

  case joaat("weapon_assaultshotgun"):
    if (iParam1) {
      return "WTU_SG_ASL";
    }
    else {
      return "WT_SG_ASL";
    }
    break;

  case joaat("weapon_heavysniper"):
    if (iParam1) {
      return "WTU_SNIP_HVY";
    }
    else {
      return "WT_SNIP_HVY";
    }
    break;

  case joaat("weapon_remotesniper"):
    if (iParam1) {
      return "WTU_SNIP_RMT";
    }
    else {
      return "WT_SNIP_RMT";
    }
    break;

  case joaat("weapon_sniperrifle"):
    if (iParam1) {
      return "WTU_SNIP_RIF";
    }
    else {
      return "WT_SNIP_RIF";
    }
    break;

  case joaat("weapon_grenadelauncher"):
    if (iParam1) {
      return "WTU_GL";
    }
    else {
      return "WT_GL";
    }
    break;

  case joaat("weapon_rpg"):
    if (iParam1) {
      return "WTU_RPG";
    }
    else {
      return "WT_RPG";
    }
    break;

  case joaat("weapon_minigun"):
    if (iParam1) {
      return "WTU_MINIGUN";
    }
    else {
      return "WT_MINIGUN";
    }
    break;

  case joaat("weapon_grenade"):
    if (iParam1) {
      return "WTU_GNADE";
    }
    else {
      return "WT_GNADE";
    }
    break;

  case joaat("weapon_smokegrenade"):
    if (iParam1) {
      return "WTU_GNADE_SMK";
    }
    else {
      return "WT_GNADE_SMK";
    }
    break;

  case joaat("weapon_stickybomb"):
    if (iParam1) {
      return "WTU_GNADE_STK";
    }
    else {
      return "WT_GNADE_STK";
    }
    break;

  case joaat("weapon_molotov"):
    if (iParam1) {
      return "WTU_MOLOTOV";
    }
    else {
      return "WT_MOLOTOV";
    }
    break;

  case joaat("weapon_stungun"):
    if (iParam1) {
      return "WTU_STUN";
    }
    else {
      return "WT_STUN";
    }
    break;

  case joaat("weapon_petrolcan"):
    if (iParam1) {
      return "WTU_PETROL";
    }
    else {
      return "WT_PETROL";
    }
    break;

  case joaat("weapon_electric_fence"):
    if (iParam1) {
      return "WTU_ELCFEN";
    }
    else {
      return "WT_ELCFEN";
    }
    break;

  case joaat("vehicle_weapon_tank"):
    if (iParam1) {
      return "WTU_V_TANK";
    }
    else {
      return "WT_V_TANK";
    }
    break;

  case joaat("vehicle_weapon_space_rocket"):
    if (iParam1) {
      return "WTU_V_SPACERKT";
    }
    else {
      return "WT_V_SPACERKT";
    }
    break;

  case joaat("vehicle_weapon_player_laser"):
    if (iParam1) {
      return "WTU_V_PLRLSR";
    }
    else {
      return "WT_V_PLRLSR";
    }
    break;

  case joaat("object"):
    if (iParam1) {
      return "WTU_OBJECT";
    }
    else {
      return "WT_OBJECT";
    }
    break;

  case joaat("gadget_parachute"):
    if (iParam1) {
      return "WTU_PARA";
    }
    else {
      return "WT_PARA";
    }
    break;

  case 1742569970:
    if (iParam1) {
      return "WTU_A_RPG";
    }
    else {
      return "WT_A_RPG";
    }
    break;

  case -1474608608:
    if (iParam1) {
      return "WTU_A_TANK";
    }
    else {
      return "WT_A_TANK";
    }
    break;

  case 527765612:
    if (iParam1) {
      return "WTU_A_SPACERKT";
    }
    else {
      return "WT_A_SPACERKT";
    }
    break;

  case -165357558:
    if (iParam1) {
      return "WTU_A_PLRLSR";
    }
    else {
      return "WT_A_PLRLSR";
    }
    break;

  case -1372674932:
    if (iParam1) {
      return "WTU_A_ENMYLSR";
    }
    else {
      return "WT_A_ENMYLSR";
    }
    break;

  case joaat("weapon_knife"):
    if (iParam1) {
      return "WTU_KNIFE";
    }
    else {
      return "WT_KNIFE";
    }
    break;

  case joaat("weapon_nightstick"):
    if (iParam1) {
      return "WTU_NGTSTK";
    }
    else {
      return "WT_NGTSTK";
    }
    break;

  case joaat("weapon_hammer"):
    if (iParam1) {
      return "WTU_HAMMER";
    }
    else {
      return "WT_HAMMER";
    }
    break;

  case joaat("weapon_bat"):
    if (iParam1) {
      return "WTU_BAT";
    }
    else {
      return "WT_BAT";
    }
    break;

  case joaat("weapon_crowbar"):
    if (iParam1) {
      return "WTU_CROWBAR";
    }
    else {
      return "WT_CROWBAR";
    }
    break;

  case joaat("weapon_golfclub"):
    if (iParam1) {
      return "WTU_GOLFCLUB";
    }
    else {
      return "WT_GOLFCLUB";
    }
    break;

  case joaat("weapon_rammed_by_car"):
    if (iParam1) {
      return "WTU_PIST";
    }
    else {
      return "WT_PIST";
    }
    break;

  case joaat("weapon_run_over_by_car"):
    if (iParam1) {
      return "WTU_PIST";
    }
    else {
      return "WT_PIST";
    }
    break;

  case joaat("weapon_assaultsmg"):
    if (iParam1) {
      return "WTU_SMG_ASL";
    }
    else {
      return "WT_SMG_ASL";
    }
    break;

  case joaat("weapon_bullpupshotgun"):
    if (iParam1) {
      return "WTU_SG_BLP";
    }
    else {
      return "WT_SG_BLP";
    }
    break;

  case joaat("weapon_pistol50"):
    if (iParam1) {
      return "WTU_PIST_50";
    }
    else {
      return "WT_PIST_50";
    }
    break;

  case joaat("weapon_bottle"):
    if (iParam1) {
      return "WTU_BOTTLE";
    }
    else {
      return "WT_BOTTLE";
    }
    break;

  case joaat("weapon_gusenberg"):
    if (iParam1) {
      return "WTU_GUSENBERG";
    }
    else {
      return "WT_GUSENBERG";
    }
    break;

  case joaat("weapon_snspistol"):
    if (iParam1) {
      return "WTU_SNSPISTOL";
    }
    else {
      return "WT_SNSPISTOL";
    }
    break;

  case joaat("weapon_vintagepistol"):
    if (iParam1) {
      return "WTU_VPISTOL";
    }
    else {
      return "WT_VPISTOL";
    }
    break;

  case joaat("weapon_dagger"):
    if (iParam1) {
      return "WTU_DAGGER";
    }
    else {
      return "WT_DAGGER";
    }
    break;

  case joaat("weapon_flaregun"):
    if (iParam1) {
      return "WTU_FLAREGUN";
    }
    else {
      return "WT_FLAREGUN";
    }
    break;

  case joaat("weapon_heavypistol"):
    if (iParam1) {
      return "WTU_HEAVYPSTL";
    }
    else {
      return "WT_HEAVYPSTL";
    }
    break;

  case joaat("weapon_specialcarbine"):
    if (iParam1) {
      return "WTU_RIFLE_SCBN";
    }
    else {
      return "WT_RIFLE_SCBN";
    }
    break;

  case joaat("weapon_musket"):
    if (iParam1) {
      return "WTU_MUSKET";
    }
    else {
      return "WT_MUSKET";
    }
    break;

  case joaat("weapon_firework"):
    if (iParam1) {
      return "WTU_FWRKLNCHR";
    }
    else {
      return "WT_FWRKLNCHR";
    }
    break;

  case joaat("weapon_marksmanrifle"):
    if (iParam1) {
      return "WTU_MKRIFLE";
    }
    else {
      return "WT_MKRIFLE";
    }
    break;

  case joaat("weapon_heavyshotgun"):
    if (iParam1) {
      return "WTU_HVYSHOT";
    }
    else {
      return "WT_HVYSHOT";
    }
    break;

  case joaat("weapon_proxmine"):
    if (iParam1) {
      return "WTU_PRXMINE";
    }
    else {
      return "WT_PRXMINE";
    }
    break;

  case joaat("weapon_hominglauncher"):
    if (iParam1) {
      return "WTU_HOMLNCH";
    }
    else {
      return "WT_HOMLNCH";
    }
    break;

  case joaat("weapon_hatchet"):
    if (iParam1) {
      return "WTU_HATCHET";
    }
    else {
      return "WT_HATCHET";
    }
    break;

  case joaat("weapon_railgun"):
    if (iParam1) {
      return "WTU_RAILGUN";
    }
    else {
      return "WT_RAILGUN";
    }
    break;

  case joaat("weapon_combatpdw"):
    if (iParam1) {
      return "WTU_COMBATPDW";
    }
    else {
      return "WT_COMBATPDW";
    }
    break;

  case joaat("weapon_knuckle"):
    if (iParam1) {
      return "WTU_KNUCKLE";
    }
    else {
      return "WT_KNUCKLE";
    }
    break;

  case joaat("weapon_marksmanpistol"):
    if (iParam1) {
      return "WTU_MKPISTOL";
    }
    else {
      return "WT_MKPISTOL";
    }
    break;

  case joaat("weapon_bullpuprifle"):
    if (iParam1) {
      return "WTU_BULLRIFLE";
    }
    else {
      return "WT_BULLRIFLE";
    }
    break;

  case joaat("weapon_machete"):
    if (iParam1) {
      return "WTU_MACHETE";
    }
    else {
      return "WT_MACHETE";
    }
    break;

  case joaat("weapon_machinepistol"):
    if (iParam1) {
      return "WTU_MCHPIST";
    }
    else {
      return "WT_MCHPIST";
    }
    break;

  case joaat("weapon_flashlight"):
    if (iParam1) {
      return "WTU_FLASHLIGHT";
    }
    else {
      return "WT_FLASHLIGHT";
    }
    break;

  case joaat("weapon_dbshotgun"):
    if (iParam1) {
      return "WTU_DBSHGN";
    }
    else {
      return "WT_DBSHGN";
    }
    break;

  case joaat("weapon_compactrifle"):
    if (iParam1) {
      return "WTU_CMPRIFLE";
    }
    else {
      return "WT_CMPRIFLE";
    }
    break;

  case joaat("weapon_switchblade"):
    if (iParam1) {
      return "WTU_SWBLADE";
    }
    else {
      return "WT_SWBLADE";
    }
    break;

  case joaat("weapon_revolver"):
    if (iParam1) {
      return "WTU_REVOLVER";
    }
    else {
      return "WT_REVOLVER";
    }
    break;

  case 317205821:
    if (iParam1) {
      return "WTU_AUTOSHGN";
    }
    else {
      return "WT_AUTOSHGN";
    }
    break;

  case -853065399:
    if (iParam1) {
      return "WTU_BATTLEAXE";
    }
    else {
      return "WT_BATTLEAXE";
    }
    break;

  case 125959754:
    if (iParam1) {
      return "WTU_CMPGL";
    }
    else {
      return "WT_CMPGL";
    }
    break;

  case -1121678507:
    if (iParam1) {
      return "WTU_MINISMG";
    }
    else {
      return "WT_MINISMG";
    }
    break;

  case -1169823560:
    if (iParam1) {
      return "WTU_PIPEBOMB";
    }
    else {
      return "WT_PIPEBOMB";
    }
    break;

  case -1810795771:
    if (iParam1) {
      return "WTU_POOLCUE";
    }
    else {
      return "WT_POOLCUE";
    }
    break;

  case 419712736:
    if (iParam1) {
      return "WTU_WRENCH";
    }
    else {
      return "WT_WRENCH";
    }
    break;

  case joaat("weapon_cougar"): return "WT_RAGE";

  case -159960575: return "WT_VEH_WEP";

  default:
    if (func_104(iParam0, &Var0) != -1) {
      if (iParam1) {
        return func_103(&Var0.f_31);
      }
      else {
        return func_103(&Var0.f_7);
      }
    }
    break;
  }
  return "WT_INVALID";
}

// Position - 0x91C9
var func_103(var uParam0) { return uParam0; }

// Position - 0x91D3
int func_104(int iParam0, var *uParam1) {
  int iVar0;
  int iVar1;

  iVar1 = dlc1::get_num_dlc_weapons();
  iVar0 = 0;
  while (iVar0 < iVar1) {
    if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
      if (uParam1->f_1 == iParam0) {
        return iVar0;
      }
    }
    iVar0++;
  }
  return -1;
}

// Position - 0x920E
int func_105(int iParam0) {
  if (iParam0 == 600) {
    return joaat("weapon_railgun");
  }
  else if (iParam0 == 500) {
    return joaat("weapon_minigun");
  }
  else if (iParam0 == 400) {
    return joaat("weapon_mg");
  }
  else if (iParam0 == 401) {
    return joaat("weapon_combatmg");
  }
  else if (iParam0 == 402) {
    return -572349828;
  }
  else if (iParam0 == 300) {
    return joaat("weapon_assaultrifle");
  }
  else if (iParam0 == 301) {
    return joaat("weapon_carbinerifle");
  }
  else if (iParam0 == 302) {
    return joaat("weapon_advancedrifle");
  }
  else if (iParam0 == 303) {
    return -947031628;
  }
  else if (iParam0 == 200) {
    return joaat("weapon_pumpshotgun");
  }
  else if (iParam0 == 201) {
    return joaat("weapon_sawnoffshotgun");
  }
  else if (iParam0 == 202) {
    return joaat("weapon_assaultshotgun");
  }
  else if (iParam0 == 203) {
    return joaat("weapon_bullpupshotgun");
  }
  else if (iParam0 == 100) {
    return joaat("weapon_microsmg");
  }
  else if (iParam0 == 101) {
    return joaat("weapon_smg");
  }
  else if (iParam0 == 102) {
    return joaat("weapon_assaultsmg");
  }
  else if (iParam0 == 0) {
    return joaat("weapon_pistol");
  }
  else if (iParam0 == 1) {
    return joaat("weapon_combatpistol");
  }
  else if (iParam0 == 2) {
    return joaat("weapon_appistol");
  }
  else if (iParam0 == 3) {
    return joaat("weapon_pistol50");
  }
  return 0;
}

// Position - 0x9381
void func_106(int iParam0, int iParam1, int iParam2, int iParam3, char *sParam4,
              char *sParam5) {
  graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(iParam1);
  graphics::_push_scaleform_movie_function_parameter_int(iParam2);
  if (iParam3 > 0) {
    graphics::begin_text_command_scaleform_string("NUMBER");
    ui::add_text_component_integer(iParam3);
    graphics::end_text_command_scaleform_string();
  }
  else {
    graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
    graphics::end_text_command_scaleform_string();
  }
  graphics::_0xE83A3E3557A56640(sParam4);
  graphics::_0xE83A3E3557A56640(sParam5);
}

// Position - 0x93D3
bool func_107(var *uParam0, var *uParam1) {
  if (!func_108(*uParam0)) {
    return false;
  }
  if (!func_108(*uParam1)) {
    return false;
  }
  if (network::network_are_handles_the_same(uParam0, uParam1)) {
    return true;
  }
  return false;
}

// Position - 0x940D
bool func_108(var uParam0, var uParam1, var uParam2, var uParam3, var uParam4,
              var uParam5, var uParam6, var uParam7, var uParam8, var uParam9,
              var uParam10, var uParam11, var uParam12) {
  return network::network_is_handle_valid(&uParam0, 13);
}

// Position - 0x941D
void func_109(var *uParam0, var *uParam1) {
  int iVar0;
  int iVar1;
  struct<75> Var2;
  var uVar77;

  Var2.f_60 = 6;
  Var2.f_67 = 6;
  if (!gameplay::is_bit_set(uParam0->f_42, 5) &&
      !gameplay::is_bit_set(uParam0->f_42, 6)) {
    iVar0 = 0;
    while (iVar0 < 12) {
      if ((*uParam1)[iVar0 /*100*/].f_75 != 0) {
        iVar1 = iVar0 + 1;
        while (iVar1 <= 11) {
          if ((*uParam1)[iVar1 /*100*/].f_75 != 0) {
            if ((*uParam1)[iVar1 /*100*/].f_75 <
                (*uParam1)[iVar0 /*100*/].f_75) {
              uVar77 = (*uParam1)[iVar1 /*100*/].f_75;
              (*uParam1)[iVar1 /*100*/].f_75 = (*uParam1)[iVar0 /*100*/].f_75;
              (*uParam1)[iVar0 /*100*/].f_75 = uVar77;
              Var2 = {(*uParam1)[iVar1 /*100*/]};
              (*uParam1)[iVar1 /*100*/] = {(*uParam1)[iVar0 /*100*/]};
              (*uParam1)[iVar0 /*100*/] = {Var2};
            }
            else if ((*uParam1)[iVar1 /*100*/].f_75 ==
                     (*uParam1)[iVar0 /*100*/].f_75) {
              if ((*uParam1)[iVar1 /*100*/].f_59 != -1) {
                if ((*uParam1)[iVar1 /*100*/].f_59 <
                        (*uParam1)[iVar0 /*100*/].f_59 ||
                    (*uParam1)[iVar0 /*100*/].f_59 == -1) {
                  uVar77 = (*uParam1)[iVar1 /*100*/].f_75;
                  (*uParam1)[iVar1 /*100*/].f_75 =
                      (*uParam1)[iVar0 /*100*/].f_75;
                  (*uParam1)[iVar0 /*100*/].f_75 = uVar77;
                  Var2 = {(*uParam1)[iVar1 /*100*/]};
                  (*uParam1)[iVar1 /*100*/] = {(*uParam1)[iVar0 /*100*/]};
                  (*uParam1)[iVar0 /*100*/] = {Var2};
                }
              }
            }
          }
          iVar1++;
        }
      }
      iVar0++;
    }
  }
}

// Position - 0x958E
void func_110(var *uParam0, var *uParam1) {
  var *uVar0;
  var *uVar1;
  var *uVar2;
  int iVar3;
  int iVar4;

  if (!gameplay::is_bit_set(uParam0->f_42, 5) &&
      !gameplay::is_bit_set(uParam0->f_42, 6)) {
    iVar4 = 0;
    while (iVar4 < 12) {
      if (func_113(uParam1, iVar3, &uVar0, 0)) {
        (*uParam1)[iVar3 /*100*/].f_75 = 1;
        iVar3++;
        if (iVar3 >= 12) {
          return;
        }
      }
      if (func_113(uParam1, iVar3, &uVar1, 1)) {
        (*uParam1)[iVar3 /*100*/].f_75 = 2;
        iVar3++;
        if (iVar3 >= 12) {
          return;
        }
      }
      if (func_113(uParam1, iVar3, &uVar2, 2)) {
        (*uParam1)[iVar3 /*100*/].f_75 = 3;
        iVar3++;
        if (iVar3 >= 12) {
          return;
        }
      }
      iVar4++;
    }
  }
  else {
    func_111(uParam1);
  }
}

// Position - 0x9643
void func_111(var *uParam0) {
  int iVar0;
  int iVar1;
  int iVar2;
  struct<13> Var3;
  int iVar16;

  iVar0 = 0;
  while (iVar0 < 3) {
    Global_1835390.f_2704[iVar0] = 0;
    Global_1835390.f_2775[iVar0] = -1;
    iVar0++;
  }
  Var3 = {func_55(player::player_id())};
  if (stats::leaderboards_get_cache_exists(Global_1835390.f_2826)) {
    iVar16 = stats::_0x58A651CD201D89AD(Global_1835390.f_2826);
    iVar0 = 0;
    iVar0 = 0;
    while (iVar0 < iVar16) {
      if (iVar0 < 12) {
        func_112(&Global_1839591);
        iVar2 = 0;
        stats::leaderboards_get_cache_data_row(Global_1835390.f_2826, iVar0,
                                               &Global_1839591);
        (*uParam0)[iVar0 /*100*/] = {Global_1839591.f_1};
        (*uParam0)[iVar0 /*100*/].f_16 = {Global_1839591.f_17};
        (*uParam0)[iVar0 /*100*/].f_32 = {Global_1839591.f_33};
        (*uParam0)[iVar0 /*100*/].f_45 = {Global_1839591.f_46};
        (*uParam0)[iVar0 /*100*/].f_58 = Global_1839591.f_59;
        (*uParam0)[iVar0 /*100*/].f_59 = Global_1839591.f_60;
        Global_1835390.f_2708 = Global_1839591.f_62;
        Global_1835390.f_2769 = Global_1839591.f_63;
        iVar2 = 0;
        if (gameplay::is_bit_set(Global_1839591.f_61, 1)) {
          iVar2 = 1;
        }
        else if (gameplay::is_bit_set(Global_1839591.f_61, 2)) {
          iVar2 = 2;
        }
        else if (gameplay::is_bit_set(Global_1839591.f_61, 3)) {
          iVar2 = 3;
        }
        Global_1835390.f_2704[iVar2 - 1]++;
        (*uParam0)[iVar0 /*100*/].f_75 = iVar2;
        if ((*uParam0)[iVar0 /*100*/].f_59 != -1) {
          if (gameplay::is_bit_set(Global_1839591.f_61, 0)) {
            (*uParam0)[iVar0 /*100*/].f_74 = 1;
          }
          else {
            (*uParam0)[iVar0 /*100*/].f_74 = 0;
          }
          if (func_107(&(*uParam0)[iVar0 /*100*/].f_32, &Var3)) {
            Global_1835390.f_2775[iVar2 - 1] = 0;
          }
        }
        iVar1 = 0;
        while (iVar1 < Global_1839591.f_62) {
          if (gameplay::is_bit_set(Global_1839591.f_63, iVar1)) {
            (*uParam0)[iVar0 /*100*/].f_67[iVar1] = Global_1839591.f_97[iVar1];
          }
          else {
            (*uParam0)[iVar0 /*100*/].f_60[iVar1] = Global_1839591.f_64[iVar1];
          }
          iVar1++;
        }
      }
      iVar0++;
    }
  }
}

// Position - 0x9863
void func_112(var *uParam0) {
  struct<13> Var0;
  int iVar13;

  *uParam0 = 0;
  StringCopy(&uParam0->f_1, "", 64);
  StringCopy(&uParam0->f_17, "", 64);
  uParam0->f_33 = {Var0};
  uParam0->f_46 = {Var0};
  uParam0->f_59 = 0;
  uParam0->f_60 = 0;
  uParam0->f_61 = 0;
  uParam0->f_62 = 0;
  uParam0->f_63 = 0;
  iVar13 = 0;
  while (iVar13 < 32) {
    uParam0->f_64[iVar13] = 0f;
    uParam0->f_97[iVar13] = 0;
    iVar13++;
  }
}

// Position - 0x98D7
bool func_113(var *uParam0, int iParam1, var *uParam2, int iParam3) {
  int iVar0;

  if (*uParam2 == 0) {
    if (Global_1835390[iParam3 /*901*/][0 /*75*/].f_59 > 0) {
      (*uParam0)[iParam1 /*100*/] = {Global_1835390[iParam3 /*901*/][0 /*75*/]};
      Global_1839534[iParam3 /*16*/] = {
          Global_1835390[iParam3 /*901*/][0 /*75*/]};
      Global_1839534.f_49[iParam3] =
          Global_1835390[iParam3 /*901*/][0 /*75*/].f_67[Global_1835390.f_2779];
      Global_1839534.f_53[iParam3] =
          Global_1835390[iParam3 /*901*/][0 /*75*/].f_60[Global_1835390.f_2779];
      *uParam2++;
      return true;
    }
  }
  else if (*uParam2 == 1) {
    if (Global_1835390.f_2775[iParam3] > 0) {
      (*uParam0)[iParam1 /*100*/] = {
          Global_1835390[iParam3 /*901*/]
                        [Global_1835390.f_2775[iParam3] /*75*/]};
      *uParam2++;
      return true;
    }
    else {
      if (Global_1835390.f_2775[iParam3] < 0) {
        StringCopy(&(*uParam0)[iParam1 /*100*/],
                   player::get_player_name(player::player_id()), 64);
        (*uParam0)[iParam1 /*100*/].f_32 = {func_55(player::player_id())};
        (*uParam0)[iParam1 /*100*/].f_59 = -1;
        (*uParam0)[iParam1 /*100*/].f_67[0] = -1;
        (*uParam0)[iParam1 /*100*/].f_67[1] = -1;
        (*uParam0)[iParam1 /*100*/].f_67[2] = -1;
        (*uParam0)[iParam1 /*100*/].f_67[3] = -1;
        (*uParam0)[iParam1 /*100*/].f_60[0] = -1f;
        (*uParam0)[iParam1 /*100*/].f_60[1] = -1f;
        (*uParam0)[iParam1 /*100*/].f_60[2] = -1f;
        (*uParam0)[iParam1 /*100*/].f_60[3] = -1f;
        *uParam2++;
        return true;
      }
      *uParam2++;
    }
  }
  else if (*uParam2 % 2 == 0) {
    iVar0 = *uParam2 / 2;
    if (Global_1835390.f_2775[iParam3] - iVar0 >= 1) {
      if (Global_1835390[iParam3 /*901*/]
                        [Global_1835390.f_2775[iParam3] - iVar0 /*75*/]
                            .f_59 > 0) {
        (*uParam0)[iParam1 /*100*/] = {
            Global_1835390[iParam3 /*901*/]
                          [Global_1835390.f_2775[iParam3] - iVar0 /*75*/]};
        *uParam2++;
        return true;
      }
    }
  }
  else {
    iVar0 = system::floor(system::to_float(*uParam2 / 2));
    if (Global_1835390.f_2775[iParam3] + iVar0 < 12 &&
        Global_1835390.f_2775[iParam3] + iVar0 > 0) {
      if (Global_1835390[iParam3 /*901*/]
                        [Global_1835390.f_2775[iParam3] + iVar0 /*75*/]
                            .f_59 > 1) {
        (*uParam0)[iParam1 /*100*/] = {
            Global_1835390[iParam3 /*901*/]
                          [Global_1835390.f_2775[iParam3] + iVar0 /*75*/]};
        *uParam2++;
        return true;
      }
    }
  }
  *uParam2++;
  return false;
}

// Position - 0x9B80
void func_114(var *uParam0) {
  struct<13> Var0;
  int iVar13;
  int iVar14;

  iVar13 = 0;
  while (iVar13 < 12) {
    StringCopy(&(*uParam0)[iVar13 /*100*/], "", 64);
    StringCopy(&(*uParam0)[iVar13 /*100*/].f_16, "", 64);
    (*uParam0)[iVar13 /*100*/].f_32 = {Var0};
    (*uParam0)[iVar13 /*100*/].f_45 = {Var0};
    (*uParam0)[iVar13 /*100*/].f_58 = 0;
    (*uParam0)[iVar13 /*100*/].f_59 = 0;
    iVar14 = 0;
    while (iVar14 < 6) {
      (*uParam0)[iVar13 /*100*/].f_60[iVar14] = 0f;
      (*uParam0)[iVar13 /*100*/].f_67[iVar14] = 0;
      iVar14++;
    }
    (*uParam0)[iVar13 /*100*/].f_75 = 0;
    (*uParam0)[iVar13 /*100*/].f_74 = 0;
    (*uParam0)[iVar13 /*100*/].f_76 = 0;
    (*uParam0)[iVar13 /*100*/].f_77 = 0;
    (*uParam0)[iVar13 /*100*/].f_78 = 0;
    (*uParam0)[iVar13 /*100*/].f_79 = 0;
    StringCopy(&(*uParam0)[iVar13 /*100*/].f_80, "", 16);
    iVar13++;
  }
  func_86(&Global_1835390.f_2830);
}

// Position - 0x9C5F
void func_115(int iParam0, int iParam1, int iParam2, char *sParam3) {
  gameplay::set_bit(&iParam2, 7);
  graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(iParam1);
  graphics::_push_scaleform_movie_function_parameter_int(iParam2);
  graphics::begin_text_command_scaleform_string(sParam3);
  graphics::_end_text_command_scaleform_string_2();
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x9C93
int func_116(var *uParam0) {
  if (!Global_1835388) {
    if (!func_77(&Global_1835390.f_2827)) {
      func_76(&Global_1835390.f_2827, 1, 0);
      return 0;
    }
    else if (!func_75(&Global_1835390.f_2827, 1000, 1)) {
      return 0;
    }
  }
  if (!network::_network_are_ros_available() || !player::is_player_online() ||
      !network::network_have_online_privileges() &&
          network::_0x1353F87E89946207() ||
      Global_1835390.f_2832 != 0) {
    gameplay::clear_bit(&uParam0->f_42, 4);
    return 1;
  }
  if (!gameplay::is_bit_set(uParam0->f_42, 4)) {
    func_151(uParam0);
    gameplay::set_bit(&uParam0->f_42, 4);
    return 0;
  }
  else if (gameplay::is_bit_set(uParam0->f_42, 5)) {
    (*uParam0)[0] = 2;
    (*uParam0)[1] = 1;
    (*uParam0)[2] = 3;
    return 1;
  }
  if (!func_149(uParam0)) {
    return 0;
  }
  if (!func_147(uParam0)) {
    return 0;
  }
  if (!func_133(uParam0)) {
    return 0;
  }
  if (!gameplay::is_bit_set(uParam0->f_42, 6)) {
    func_114(&Global_1839721);
    func_110(uParam0, &Global_1839721);
    func_109(uParam0, &Global_1839721);
    gameplay::set_bit(&uParam0->f_42, 6);
  }
  if (!gameplay::is_bit_set(uParam0->f_42, 7)) {
    if (!func_77(&Global_1835390.f_2830)) {
      func_76(&Global_1835390.f_2830, 1, 0);
    }
    else if (func_75(&Global_1835390.f_2830, 30000, 1)) {
      gameplay::set_bit(&uParam0->f_42, 7);
    }
    if (func_130(&Global_1839721)) {
    }
    else {
      return 0;
    }
    if (func_127(&Global_1839721)) {
    }
    else {
      return 0;
    }
    if (func_121(&Global_1839721)) {
      func_117(&Global_1839721);
      gameplay::set_bit(&uParam0->f_42, 7);
      func_117(&Global_1839721);
    }
    else {
      return 0;
    }
  }
  return 1;
}

// Position - 0x9E58
void func_117(var *uParam0) {
  int iVar0;
  int iVar1;
  int iVar2;

  iVar2 = func_120(Global_1835390.f_2826);
  if (Global_1838575.f_81[iVar2] != 0) {
    func_119(-1, iVar2);
  }
  iVar0 = 0;
  while (iVar0 < 12) {
    func_112(&Global_1839591);
    if ((*uParam0)[iVar0 /*100*/].f_75 != 0) {
      Global_1839591 = Global_1835390.f_2826;
      Global_1839591.f_1 = {(*uParam0)[iVar0 /*100*/]};
      if (gameplay::are_strings_equal(&(*uParam0)[iVar0 /*100*/].f_16, "")) {
        Global_1839591.f_17 = {(*uParam0)[iVar0 /*100*/]};
      }
      else {
        Global_1839591.f_17 = {(*uParam0)[iVar0 /*100*/].f_16};
      }
      Global_1839591.f_33 = {(*uParam0)[iVar0 /*100*/].f_32};
      if (func_108((*uParam0)[iVar0 /*100*/].f_45)) {
        Global_1839591.f_46 = {(*uParam0)[iVar0 /*100*/].f_45};
      }
      else {
        Global_1839591.f_46 = {(*uParam0)[iVar0 /*100*/].f_32};
      }
      Global_1839591.f_59 = (*uParam0)[iVar0 /*100*/].f_58;
      Global_1839591.f_60 = (*uParam0)[iVar0 /*100*/].f_59;
      Global_1839591.f_62 = Global_1835390.f_2708;
      Global_1839591.f_63 = Global_1835390.f_2770;
      if ((*uParam0)[iVar0 /*100*/].f_74) {
        gameplay::set_bit(&Global_1839591.f_61, 0);
      }
      else {
        gameplay::clear_bit(&Global_1839591.f_61, 0);
      }
      gameplay::set_bit(&Global_1839591.f_61, (*uParam0)[iVar0 /*100*/].f_75);
      iVar1 = 0;
      while (iVar1 < Global_1839591.f_62) {
        if (gameplay::is_bit_set(Global_1839591.f_63, iVar1)) {
          Global_1839591.f_97[iVar1] = (*uParam0)[iVar0 /*100*/].f_67[iVar1];
        }
        else {
          Global_1839591.f_64[iVar1] = (*uParam0)[iVar0 /*100*/].f_60[iVar1];
        }
        iVar1++;
      }
      Global_1838575.f_81[iVar2] = Global_1835390.f_2826;
      stats::leaderboards_cache_data_row(&Global_1839591);
    }
    iVar0++;
  }
  Global_1838575.f_87[iVar2 /*3*/] = {func_118(player::player_id())};
}

// Position - 0xA041
Vector3 func_118(int iParam0) {
  return entity::get_entity_coords(player::get_player_ped(iParam0), 0);
}

// Position - 0xA054
void func_119(int iParam0, int iParam1) {
  int iVar0;

  if (iParam1 != -1) {
    if (stats::leaderboards_get_cache_exists(Global_1838575.f_81[iParam1])) {
      stats::_0x8EC74CEB042E7CFF(Global_1838575.f_81[iParam1]);
    }
    Global_1838575.f_81[iParam1] = 0;
  }
  else if (iParam0 != -1) {
    if (stats::leaderboards_get_cache_exists(iParam0)) {
      stats::_0x8EC74CEB042E7CFF(iParam0);
    }
    iVar0 = 0;
    while (iVar0 < 5) {
      if (Global_1838575.f_81[iVar0] == iParam0) {
        Global_1838575.f_81[iVar0] = 0;
      }
      iVar0++;
    }
  }
}

// Position - 0xA0D0
int func_120(int iParam0) {
  int iVar0;
  int iVar1;
  int iVar2;
  int iVar3;

  iVar0 = 0;
  while (iVar0 < 5) {
    if (Global_1838575.f_81[iVar0] == iParam0) {
      return iVar0;
    }
    iVar0++;
  }
  iVar0 = 0;
  iVar0 = 0;
  while (iVar0 < 5) {
    if (Global_1838575.f_81[iVar0] == 0) {
      return iVar0;
    }
    else if (stats::leaderboards_get_cache_exists(Global_1838575.f_81[iVar0])) {
      iVar3 = stats::leaderboards_get_cache_time(Global_1838575.f_81[iVar0]);
      if (iVar3 > iVar2) {
        iVar1 = iVar0;
        iVar2 = iVar3;
      }
    }
    else {
      return iVar0;
    }
    iVar0++;
  }
  return iVar1;
}

// Position - 0xA163
bool func_121(var *uParam0) {
  int iVar0;
  int iVar1;

  switch ((*uParam0)[0 /*100*/].f_76) {
  case 0:
    func_125(uParam0);
    if (gameplay::is_orbis_version() && !network::_0x72D918C99BCACC54(0)) {
      (*uParam0)[0 /*100*/].f_76 = 3;
      return false;
    }
    iVar0 = 0;
    while (iVar0 < 12) {
      if (func_108((*uParam0)[iVar0 /*100*/].f_32)) {
        if (!func_124(&(*uParam0)[iVar0 /*100*/].f_32, &Global_1841018)) {
          Global_1841018[Global_1841018.f_206 /*13*/] = {
              (*uParam0)[iVar0 /*100*/].f_32};
          Global_1841018.f_206++;
        }
      }
      iVar0++;
    }
    if (Global_1841018.f_206 > 0) {
      (*uParam0)[0 /*100*/].f_76 = 1;
    }
    else {
      (*uParam0)[0 /*100*/].f_76 = 3;
    }
    break;

  case 1:
    if (func_122(&(*uParam0)[1 /*100*/].f_76, &Global_1841018.f_206,
                 &Global_1841018, &Global_1841018.f_157)) {
      (*uParam0)[0 /*100*/].f_76 = 2;
    }
    break;

  case 2:
    if (Global_1841018.f_206 > 12) {
      Global_1841018.f_206 = 12;
    }
    iVar0 = 0;
    while (iVar0 < 12) {
      iVar1 = 0;
      while (iVar1 < Global_1841018.f_206) {
        if (func_108((*uParam0)[iVar0 /*100*/].f_32) &&
            func_108(Global_1841018[iVar1 /*13*/])) {
          if (network::network_are_handles_the_same(
                  &(*uParam0)[iVar0 /*100*/].f_32,
                  &Global_1841018[iVar1 /*13*/])) {
            (*uParam0)[iVar0 /*100*/].f_80 = {
                Global_1841018.f_157[iVar1 /*4*/]};
          }
        }
        iVar1++;
      }
      iVar0++;
    }
    (*uParam0)[0 /*100*/].f_76 = 3;
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xA306
bool func_122(int *iParam0, var *uParam1, var *uParam2, var *uParam3) {
  var uVar0;
  int iVar35;

  switch (*iParam0) {
  case 0:
    if (network::network_get_primary_clan_data_pending()) {
    }
    else {
      network::network_get_primary_clan_data_clear();
      network::network_get_primary_clan_data_start(uParam2, *uParam1);
      *iParam0 = 1;
    }
    break;

  case 1:
    if (!network::network_get_primary_clan_data_pending()) {
      if (network::network_get_primary_clan_data_success()) {
        *iParam0 = 2;
      }
      else {
        *iParam0 = 3;
      }
    }
    break;

  case 2:
    iVar35 = 0;
    while (iVar35 < *uParam1) {
      if (network::network_get_primary_clan_data_new(&(*uParam2)[iVar35 /*13*/],
                                                     &uVar0)) {
        func_123(&uVar0, &(*uParam3)[iVar35 /*4*/]);
      }
      iVar35++;
    }
    if (network::network_get_primary_clan_data_pending()) {
      network::network_get_primary_clan_data_cancel();
    }
    else {
      network::network_get_primary_clan_data_clear();
    }
    *iParam0 = 3;
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xA3BF
void func_123(var uParam0, char *sParam1) {
  network::unk_0xf45352426ff3a4f0(uParam0, 35, sParam1);
}

// Position - 0xA3D1
int func_124(var *uParam0, var *uParam1) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < 12) {
    if (func_108((*uParam1)[iVar0 /*13*/])) {
      if (network::network_are_handles_the_same(uParam0,
                                                &(*uParam1)[iVar0 /*13*/])) {
        return 1;
      }
    }
    iVar0++;
  }
  return 0;
}

// Position - 0xA410
void func_125(var *uParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < 12) {
    func_126(&Global_1841018[iVar0 /*13*/]);
    StringCopy(&Global_1841018.f_157[iVar0 /*4*/], "", 16);
    iVar0++;
  }
  if ((*uParam0)[0 /*100*/].f_76 > 0) {
    (*uParam0)[0 /*100*/].f_76 = 0;
    (*uParam0)[1 /*100*/].f_76 = 0;
    if (!network::network_get_primary_clan_data_pending()) {
      network::network_get_primary_clan_data_clear();
    }
  }
  if (network::network_get_primary_clan_data_pending()) {
    network::network_get_primary_clan_data_cancel();
  }
  Global_1841018.f_206 = 0;
}

// Position - 0xA480
void func_126(var *uParam0) {
  *uParam0 = 0;
  uParam0->f_1 = 0;
  uParam0->f_2 = 0;
  uParam0->f_3 = 0;
  uParam0->f_4 = 0;
  uParam0->f_5 = 0;
  uParam0->f_6 = 0;
  uParam0->f_7 = 0;
  uParam0->f_8 = 0;
  uParam0->f_9 = 0;
  uParam0->f_10 = 0;
  uParam0->f_11 = 0;
  uParam0->f_12 = 0;
}

// Position - 0xA4C8
bool func_127(var *uParam0) {
  int iVar0;

  if (gameplay::is_pc_version()) {
    return true;
  }
  else if (gameplay::is_durango_version()) {
    if (!func_129(uParam0)) {
      return false;
    }
  }
  else {
    iVar0 = 0;
    while (iVar0 < 12) {
      if (!func_128(&(*uParam0)[iVar0 /*100*/].f_78,
                    &(*uParam0)[iVar0 /*100*/].f_32,
                    &(*uParam0)[iVar0 /*100*/])) {
        return false;
      }
      iVar0++;
    }
  }
  return true;
}

// Position - 0xA52C
int func_128(int *iParam0, var *uParam1, char *sParam2) {
  if (*iParam0 == 2) {
    return 1;
  }
  switch (*iParam0) {
  case 0:
    if (func_108(*uParam1)) {
      if (!network::network_is_gamer_in_my_session(uParam1)) {
        if (gameplay::is_durango_version()) {
          if (network::network_gamertag_from_handle_start(uParam1)) {
            *iParam0 = 1;
          }
        }
        else if (gameplay::is_xbox360_version()) {
          if (network::network_gamertag_from_handle_start(uParam1)) {
            *iParam0 = 1;
          }
        }
        else {
          StringCopy(sParam2,
                     network::network_get_gamertag_from_handle(uParam1), 64);
          if (gameplay::is_ps3_version()) {
          }
          else if (gameplay::is_orbis_version()) {
          }
          else if (gameplay::is_pc_version()) {
          }
          *iParam0 = 2;
        }
      }
      else {
        StringCopy(sParam2,
                   player::get_player_name(
                       network::network_get_player_from_gamer_handle(uParam1)),
                   64);
        *iParam0 = 2;
      }
    }
    else {
      *iParam0 = 2;
    }
    break;

  case 1:
    if (!network::network_is_gamer_in_my_session(uParam1)) {
      if (!network::network_gamertag_from_handle_pending()) {
        if (network::network_gamertag_from_handle_succeeded()) {
          StringCopy(sParam2,
                     network::network_get_gamertag_from_handle(uParam1), 64);
        }
        *iParam0 = 2;
        return 1;
      }
    }
    else {
      StringCopy(sParam2,
                 player::get_player_name(
                     network::network_get_player_from_gamer_handle(uParam1)),
                 64);
      *iParam0 = 2;
    }
    break;

  case 2: return 1;
  }
  return 0;
}

// Position - 0xA633
int func_129(var *uParam0) {
  int iVar0;
  int iVar1;
  int iVar2;

  if (!gameplay::is_durango_version()) {
    return 1;
  }
  if ((*uParam0)[0 /*100*/].f_78 == 2) {
    return 1;
  }
  switch ((*uParam0)[0 /*100*/].f_78) {
  case 0:
    Global_1835390.f_3183 = 0;
    iVar1 = 0;
    while (iVar1 < 12) {
      StringCopy(&Global_1835390.f_2833[iVar1 /*16*/], "", 64);
      func_126(&Global_1835390.f_3026[iVar1 /*13*/]);
      if (func_108((*uParam0)[iVar1 /*100*/].f_32)) {
        Global_1835390.f_3026[Global_1835390.f_3183 /*13*/] = {
            (*uParam0)[iVar1 /*100*/].f_32};
        Global_1835390.f_3183++;
      }
      iVar1++;
    }
    if (Global_1835390.f_3183 > 0) {
      (*uParam0)[0 /*100*/].f_79 = network::_0xD66C9E72B3CC4982(
          &Global_1835390.f_3026, Global_1835390.f_3183);
      (*uParam0)[0 /*100*/].f_78 = 1;
    }
    else {
      (*uParam0)[0 /*100*/].f_78 = 2;
    }
    break;

  case 1:
    iVar0 = network::_0x58CC181719256197((*uParam0)[0 /*100*/].f_79,
                                         &Global_1835390.f_2833,
                                         Global_1835390.f_3183);
    if (iVar0 == 0) {
      iVar1 = 0;
      while (iVar1 < 12) {
        if (func_108((*uParam0)[iVar1 /*100*/].f_32)) {
          (*uParam0)[iVar1 /*100*/] = {Global_1835390.f_2833[iVar2 /*16*/]};
          iVar2++;
        }
        iVar1++;
      }
      (*uParam0)[0 /*100*/].f_78 = 2;
    }
    else if (iVar0 == -1) {
      (*uParam0)[0 /*100*/].f_78 = 2;
    }
    else {
      return 0;
    }
    break;

  case 2: (*uParam0)[0 /*100*/].f_79 = -1; return 1;
  }
  return 0;
}

// Position - 0xA7BE
bool func_130(var *uParam0) {
  int iVar0;

  if (gameplay::is_durango_version()) {
    iVar0 = 0;
    while (iVar0 < 12) {
      if (!func_132(&(*uParam0)[iVar0 /*100*/].f_77,
                    &(*uParam0)[iVar0 /*100*/].f_16,
                    &(*uParam0)[iVar0 /*100*/].f_84, &Global_1835390.f_2833,
                    &(*uParam0)[iVar0 /*100*/].f_79)) {
        return false;
      }
      iVar0++;
    }
  }
  else {
    iVar0 = 0;
    while (iVar0 < 12) {
      if (!func_131(&(*uParam0)[iVar0 /*100*/].f_77,
                    (*uParam0)[iVar0 /*100*/].f_16,
                    &(*uParam0)[iVar0 /*100*/].f_84)) {
        return false;
      }
      iVar0++;
    }
  }
  return true;
}

// Position - 0xA851
int func_131(int *iParam0, var uParam1, var uParam2, var uParam3, var uParam4,
             var uParam5, var uParam6, var uParam7, var uParam8, var uParam9,
             var uParam10, var uParam11, var uParam12, var uParam13,
             var uParam14, var uParam15, var uParam16, char *sParam17) {
  struct<13> Var0;

  if (*iParam0 == 2) {
    return 1;
  }
  else if (gameplay::is_string_null_or_empty(&uParam1)) {
    *iParam0 = 2;
    return 1;
  }
  network::network_handle_from_user_id(&uParam1, &Var0, 13);
  switch (*iParam0) {
  case 0:
    if (func_108(Var0)) {
      if (!network::network_is_gamer_in_my_session(&Var0)) {
        if (gameplay::is_xbox360_version() || gameplay::is_durango_version()) {
          if (network::network_gamertag_from_handle_start(&Var0)) {
            *iParam0 = 1;
          }
        }
        else {
          StringCopy(sParam17, network::network_get_gamertag_from_handle(&Var0),
                     64);
          if (gameplay::is_ps3_version()) {
          }
          else if (gameplay::is_orbis_version()) {
          }
          else if (gameplay::is_pc_version()) {
          }
          *iParam0 = 2;
        }
      }
      else {
        StringCopy(sParam17,
                   player::get_player_name(
                       network::network_get_player_from_gamer_handle(&Var0)),
                   64);
        *iParam0 = 2;
      }
    }
    else {
      *iParam0 = 2;
    }
    break;

  case 1:
    if (!network::network_is_gamer_in_my_session(&Var0)) {
      if (!network::network_gamertag_from_handle_pending()) {
        if (network::network_gamertag_from_handle_succeeded()) {
          StringCopy(sParam17, network::network_get_gamertag_from_handle(&Var0),
                     64);
        }
        *iParam0 = 2;
        return 1;
      }
    }
    else {
      StringCopy(sParam17,
                 player::get_player_name(
                     network::network_get_player_from_gamer_handle(&Var0)),
                 64);
      *iParam0 = 2;
    }
    break;

  case 2: return 1;
  }
  return 0;
}

// Position - 0xA969
int func_132(int *iParam0, char *sParam1, var *uParam2, var *uParam3,
             int *iParam4) {
  int iVar0;
  struct<13> Var1[1];

  if (!gameplay::is_durango_version()) {
    return 1;
  }
  if (*iParam0 == 2) {
    return 1;
  }
  else if (gameplay::is_string_null_or_empty(sParam1)) {
    *iParam0 = 2;
    return 1;
  }
  network::network_handle_from_user_id(sParam1, &Var1[0 /*13*/], 13);
  switch (*iParam0) {
  case 0:
    StringCopy(&(*uParam3)[0 /*16*/], "", 64);
    if (func_108(Var1[0 /*13*/])) {
      if (!network::network_is_gamer_in_my_session(&Var1[0 /*13*/])) {
        *iParam4 = network::_0xD66C9E72B3CC4982(&Var1, 1);
        *iParam0 = 1;
      }
      else {
        StringCopy(
            uParam2,
            player::get_player_name(
                network::network_get_player_from_gamer_handle(&Var1[0 /*13*/])),
            64);
        *iParam0 = 2;
      }
    }
    else {
      *iParam0 = 2;
    }
    break;

  case 1:
    iVar0 = network::_0x58CC181719256197(*iParam4, uParam3, 1);
    if (iVar0 == 0) {
      *uParam2 = {(*uParam3)[0 /*16*/]};
      *iParam0 = 2;
    }
    else if (iVar0 == -1) {
      *iParam0 = 2;
    }
    else {
      return 0;
    }
    break;

  case 2: *iParam4 = -1; return 1;
  }
  return 0;
}

// Position - 0xAA64
int func_133(var *uParam0) {
  struct<97> Var0;
  struct<6> Var98;
  int iVar106;
  int iVar107;
  int iVar108;
  int iVar109;
  int iVar110;
  int iVar111;
  bool bVar112;
  int iVar113;
  bool bVar114;
  int iVar115;
  struct<13> Var116;

  Var0.f_19.f_1 = 4;
  iVar109 = -1;
  iVar113 = 2;
  Var116 = {func_55(player::player_id())};
  switch ((*uParam0)[iVar113]) {
  case 0:
    Global_1835390.f_2775[iVar113] = -1;
    Global_1835390.f_2704[iVar113] = 0;
    Global_1835013.f_374 = -1;
    if (network::_network_player_is_in_clan()) {
      if (network::network_clan_player_is_active(&Var116)) {
        if (network::network_clan_player_get_desc(&uParam0->f_7, 35, &Var116)) {
          uParam0->f_44.f_2 = uParam0->f_7;
          uParam0->f_44.f_1 = 3;
          (*uParam0)[iVar113] = 1;
          return 0;
        }
      }
      else {
        (*uParam0)[iVar113] = 3;
        return 1;
      }
    }
    else {
      (*uParam0)[iVar113] = 3;
      return 1;
    }
    break;

  case 1:
    uParam0->f_44.f_1 = 3;
    Var98 = uParam0->f_44;
    Var98.f_1 = uParam0->f_44.f_1;
    if (func_145(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 11, &Var116,
                 func_146(), 0, 0, 0)) {
      func_144(&Var98, &uParam0->f_44);
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
        if (Var98.f_3 > 0) {
          iVar111 = 0;
          iVar106 = 0;
          if (func_146()) {
            iVar111 = 0;
            while (iVar111 < Var98.f_3) {
              stats::_0x34770B9CE0E03B91(iVar111, &Var0);
              if (Global_1835013.f_374 < 0) {
                if (func_107(&Var0, &Var116) ||
                    func_107(&Var0, &Global_1835013.f_361)) {
                  Global_1835013.f_374 = Var0.f_96;
                }
              }
              if (iVar109 < 0) {
                if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
                  if (Global_1835013.f_211.f_36[0] >=
                      stats::_0x88578F6EC36B4A3A(iVar111, 0)) {
                    iVar109 = iVar111;
                  }
                }
                else if (Global_1835013.f_211.f_3[0] >=
                         stats::_0x38491439B6BA7F7D(iVar111, 0)) {
                  iVar109 = iVar111;
                }
              }
              func_143(&Var0);
              iVar111++;
            }
            if (iVar109 < 0) {
              iVar109 = Var98.f_3;
            }
          }
          iVar111 = 0;
          stats::_0x34770B9CE0E03B91(0, &Var0);
          if (Var0.f_96 <= 1) {
            if (Global_1835390.f_2704[iVar113] < 12) {
              if (func_146() && iVar109 == 0) {
                func_142(uParam0,
                         &Global_1835390[iVar113 /*901*/]
                                        [Global_1835390.f_2704[iVar113] /*75*/],
                         Var0.f_96);
                Global_1835390.f_2775[iVar113] = 0;
                Global_1835390.f_2704[iVar113]++;
              }
              if (func_146() && (func_107(&Var0, &Var116) ||
                                 func_107(&Var0, &Global_1835013.f_361))) {
              }
              else {
                if (func_107(&Var0, &Var116)) {
                  iVar109 = 0;
                  Global_1835390.f_2775[iVar113] = 0;
                }
                MemCopy(&Global_1835390[iVar113 /*901*/]
                                       [Global_1835390.f_2704[iVar113] /*75*/],
                        {Var0.f_13}, 16);
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_32 = {Var0};
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_59 = Var0.f_96;
                if (func_141(uParam0->f_44)) {
                  iVar108 =
                      stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
                  if (iVar108 == 1) {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_58 = 1;
                  }
                  else {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_58 = 0;
                  }
                }
                if (func_156(uParam0->f_44)) {
                  MemCopy(&Global_1835390[iVar113 /*901*/]
                                         [Global_1835390.f_2704[iVar113] /*75*/]
                                             .f_16,
                          {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
                }
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_74 = 1;
                iVar107 = 0;
                iVar107 = 0;
                while (iVar107 < Global_1835390.f_2708) {
                  if (gameplay::is_bit_set(Global_1835390.f_2769,
                                           Global_1835390.f_2710[iVar107])) {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_67[iVar107] =
                        stats::_0x88578F6EC36B4A3A(
                            0, Global_1835390.f_2710[iVar107]);
                  }
                  else {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_60[iVar107] =
                        stats::_0x38491439B6BA7F7D(
                            0, Global_1835390.f_2710[iVar107]);
                  }
                  iVar107++;
                }
                Global_1835390.f_2704[iVar113]++;
              }
              bVar112 = true;
            }
          }
          if (!bVar112) {
            Global_1835390.f_2704[iVar113]++;
          }
          if (!func_146()) {
            iVar109 = Var98.f_5;
          }
          if (iVar109 > 6) {
            iVar110 = iVar109 - 6;
          }
          else if (bVar112) {
            iVar110 = 1;
          }
          else {
            iVar110 = 0;
          }
          iVar111 = iVar110;
          func_143(&Var0);
          iVar111 = iVar110;
          while (iVar111 <= Var98.f_3 - 1) {
            stats::_0x34770B9CE0E03B91(iVar111, &Var0);
            if (Global_1835390.f_2704[iVar113] < 12 && Var0.f_96 > 1) {
              if (func_146() && iVar109 == iVar111) {
                if (!func_107(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_32,
                              &Var116)) {
                  func_142(
                      uParam0,
                      &Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      Var0.f_96);
                  Global_1835390.f_2775[iVar113] =
                      Global_1835390.f_2704[iVar113];
                  Global_1835390.f_2704[iVar113]++;
                }
              }
              if (func_146() && (func_107(&Var0, &Var116) ||
                                 func_107(&Var0, &Global_1835013.f_361))) {
              }
              else if (Global_1835390.f_2704[iVar113] < 12) {
                if (func_108(Var0) &&
                    !func_107(
                        &Var0,
                        &Global_1835390[iVar113 /*901*/][0 /*75*/].f_32)) {
                  if (func_107(&Var0, &Var116)) {
                    if (Global_1835390.f_2775[iVar113] < 0) {
                      Global_1835390.f_2775[iVar113] =
                          Global_1835390.f_2704[iVar113];
                    }
                  }
                  MemCopy(
                      &Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      {Var0.f_13}, 16);
                  Global_1835390[iVar113 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_32 = {Var0};
                  Global_1835390[iVar113 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_59 = Var0.f_96;
                  Global_1835390[iVar113 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_74 = 1;
                  if (func_141(uParam0->f_44)) {
                    iVar108 = stats::_0x88578F6EC36B4A3A(iVar111,
                                                         Global_1835390.f_2709);
                    if (iVar108 == 1) {
                      Global_1835390[iVar113 /*901*/]
                                    [Global_1835390.f_2704[iVar113] /*75*/]
                                        .f_58 = 1;
                    }
                    else {
                      Global_1835390[iVar113 /*901*/]
                                    [Global_1835390.f_2704[iVar113] /*75*/]
                                        .f_58 = 0;
                    }
                  }
                  if (func_156(uParam0->f_44)) {
                    MemCopy(
                        &Global_1835390[iVar113 /*901*/]
                                       [Global_1835390.f_2704[iVar113] /*75*/]
                                           .f_16,
                        {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
                  }
                  iVar106 = 0;
                  iVar106 = 0;
                  while (iVar106 < Global_1835390.f_2708) {
                    if (gameplay::is_bit_set(Global_1835390.f_2769,
                                             Global_1835390.f_2710[iVar106])) {
                      Global_1835390[iVar113 /*901*/]
                                    [Global_1835390.f_2704[iVar113] /*75*/]
                                        .f_67[iVar106] =
                          stats::_0x88578F6EC36B4A3A(
                              iVar111, Global_1835390.f_2710[iVar106]);
                    }
                    else {
                      Global_1835390[iVar113 /*901*/]
                                    [Global_1835390.f_2704[iVar113] /*75*/]
                                        .f_60[iVar106] =
                          stats::_0x38491439B6BA7F7D(
                              iVar111, Global_1835390.f_2710[iVar106]);
                    }
                    iVar106++;
                  }
                  Global_1835390.f_2704[iVar113]++;
                }
              }
            }
            func_143(&Var0);
            iVar111++;
          }
          stats::_0x71B008056E5692D6();
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          if (bVar112) {
            if (Global_1835390.f_2775[iVar113] == -1 && func_146()) {
              if (Global_1835390.f_2704[iVar113] >= 1) {
                func_142(
                    uParam0,
                    &Global_1835390[iVar113 /*901*/]
                                   [Global_1835390.f_2704[iVar113] /*75*/],
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] - 1 /*75*/]
                                      .f_59 +
                        1);
              }
              else {
                func_142(uParam0,
                         &Global_1835390[iVar113 /*901*/]
                                        [Global_1835390.f_2704[iVar113] /*75*/],
                         1);
              }
              Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
              Global_1835390.f_2704[iVar113]++;
            }
            (*uParam0)[iVar113] = 3;
          }
          else {
            (*uParam0)[iVar113] = 2;
          }
        }
        else {
          if (!bVar112) {
            Global_1835390.f_2704[iVar113]++;
          }
          stats::_0x71B008056E5692D6();
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          Global_1835390.f_2775[iVar113] = -1;
          (*uParam0)[iVar113] = 2;
        }
      }
      else {
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        Global_1835390.f_2775[iVar113] = -1;
        (*uParam0)[iVar113] = 2;
        gameplay::set_bit(&Global_1835390.f_2832, iVar113);
      }
    }
    break;

  case 2:
    if (Global_1835390.f_2775[iVar113] == -1) {
      iVar115 = 11;
    }
    else {
      iVar115 = 1;
    }
    uParam0->f_44.f_1 = 3;
    Var98 = uParam0->f_44;
    Var98.f_1 = uParam0->f_44.f_1;
    if (func_135(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, iVar115)) {
      func_144(&Var98, &uParam0->f_44);
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
        if (Var98.f_3 > 0) {
          iVar106 = 0;
          while (iVar106 < Var98.f_3) {
            stats::_0x34770B9CE0E03B91(iVar106, &Var0);
            bVar114 = false;
            if (Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 > 1 ||
                Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 <= 0) {
              bVar114 = true;
            }
            if (Global_1835390.f_2704[iVar113] < 12 || bVar114) {
              if (func_146() && (func_107(&Var0, &Var116) ||
                                 func_107(&Var0, &Global_1835013.f_361))) {
              }
              else if (iVar106 == 0 || bVar114) {
                MemCopy(&Global_1835390[iVar113 /*901*/][0 /*75*/], {Var0.f_13},
                        16);
                Global_1835390[iVar113 /*901*/][0 /*75*/].f_32 = {Var0};
                Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 = Var0.f_96;
                if (func_141(uParam0->f_44)) {
                  iVar108 =
                      stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
                  if (iVar108 == 1) {
                    Global_1835390[iVar113 /*901*/][0 /*75*/].f_58 = 1;
                  }
                  else {
                    Global_1835390[iVar113 /*901*/][0 /*75*/].f_58 = 0;
                  }
                }
                if (func_156(uParam0->f_44)) {
                  MemCopy(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_16,
                          {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
                }
                Global_1835390[iVar113 /*901*/][0 /*75*/].f_74 = 1;
                iVar107 = 0;
                iVar107 = 0;
                while (iVar107 < Global_1835390.f_2708) {
                  if (gameplay::is_bit_set(Global_1835390.f_2769,
                                           Global_1835390.f_2710[iVar107])) {
                    Global_1835390[iVar113 /*901*/][0 /*75*/].f_67[iVar107] =
                        stats::_0x88578F6EC36B4A3A(
                            0, Global_1835390.f_2710[iVar107]);
                  }
                  else {
                    Global_1835390[iVar113 /*901*/][0 /*75*/].f_60[iVar107] =
                        stats::_0x38491439B6BA7F7D(
                            0, Global_1835390.f_2710[iVar107]);
                  }
                  iVar107++;
                }
                if (Global_1835390.f_2704[iVar113] == 0) {
                  if (bVar114) {
                  }
                  else {
                    Global_1835390.f_2704[iVar113]++;
                  }
                }
              }
              else if (Global_1835390.f_2704[iVar113] < 12) {
                MemCopy(&Global_1835390[iVar113 /*901*/]
                                       [Global_1835390.f_2704[iVar113] /*75*/],
                        {Var0.f_13}, 16);
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_32 = {Var0};
                if (func_141(uParam0->f_44)) {
                  iVar108 = stats::_0x88578F6EC36B4A3A(iVar106,
                                                       Global_1835390.f_2709);
                  if (iVar108 == 1) {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_58 = 1;
                  }
                  else {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_58 = 0;
                  }
                }
                if (func_156(uParam0->f_44)) {
                  MemCopy(&Global_1835390[iVar113 /*901*/]
                                         [Global_1835390.f_2704[iVar113] /*75*/]
                                             .f_16,
                          {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
                }
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_59 = Var0.f_96;
                Global_1835390[iVar113 /*901*/]
                              [Global_1835390.f_2704[iVar113] /*75*/]
                                  .f_74 = 1;
                iVar107 = 0;
                iVar107 = 0;
                while (iVar107 < Global_1835390.f_2708) {
                  if (gameplay::is_bit_set(Global_1835390.f_2769,
                                           Global_1835390.f_2710[iVar107])) {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_67[iVar107] =
                        stats::_0x88578F6EC36B4A3A(
                            iVar106, Global_1835390.f_2710[iVar107]);
                  }
                  else {
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/]
                                      .f_60[iVar107] =
                        stats::_0x38491439B6BA7F7D(
                            iVar106, Global_1835390.f_2710[iVar107]);
                  }
                  iVar107++;
                }
                if (iVar106 != 0) {
                  Global_1835390.f_2704[iVar113]++;
                }
              }
            }
            func_143(&Var0);
            iVar106++;
          }
        }
        stats::_0x71B008056E5692D6();
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        (*uParam0)[iVar113] = 3;
      }
      else {
        stats::_0x71B008056E5692D6();
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        gameplay::set_bit(&Global_1835390.f_2832, iVar113);
        Global_1835390.f_2704[iVar113] = 0;
        (*uParam0)[iVar113] = 3;
      }
      if (Global_1835390.f_2775[iVar113] == -1 && func_146()) {
        if (Global_1835390.f_2704[iVar113] >= 1) {
          func_142(uParam0,
                   &Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/],
                   Global_1835390[iVar113 /*901*/]
                                 [Global_1835390.f_2704[iVar113] - 1 /*75*/]
                                     .f_59 +
                       1);
        }
        else {
          func_142(uParam0,
                   &Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] /*75*/],
                   1);
        }
        Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
        Global_1835390.f_2704[iVar113]++;
      }
    }
    break;

  case 3:
    func_134(iVar113, Global_1835013.f_374);
    (*uParam0)[iVar113] = 4;
    break;

  case 4: return 1;
  }
  return 0;
}

// Position - 0xB897
void func_134(int iParam0, int iParam1) {
  int iVar0;

  if (func_146() &&
      Global_1835390.f_2704[iParam0] > Global_1835390.f_2775[iParam0] &&
      Global_1835390.f_2775[iParam0] >= 0) {
    if (iParam1 !=
        Global_1835390[iParam0 /*901*/][Global_1835390.f_2775[iParam0] /*75*/]
            .f_59) {
      iVar0 = 0;
      while (iVar0 < Global_1835390.f_2704[iParam0]) {
        if (iVar0 != Global_1835390.f_2775[iParam0]) {
          if (Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59 >=
              Global_1835390[iParam0 /*901*/]
                            [Global_1835390.f_2775[iParam0] /*75*/]
                                .f_59) {
            if (Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59 < iParam1 ||
                iParam1 == -1) {
              Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59++;
            }
          }
        }
        iVar0++;
      }
    }
  }
  else {
    if (!func_146()) {
    }
    if (Global_1835390.f_2704[iParam0] <= Global_1835390.f_2775[iParam0]) {
    }
    if (Global_1835390.f_2775[iParam0] < 0) {
    }
  }
}

// Position - 0xB9BC
bool func_135(var *uParam0, int *iParam1, var *uParam2, int iParam3,
              int iParam4) {
  switch (*uParam0) {
  case 0:
    if (!func_138() && !func_137()) {
      func_136(*uParam2);
      if (stats::leaderboards2_read_by_rank(uParam2, iParam3, iParam4)) {
        *uParam0++;
      }
      else {
        *iParam1 = 0;
        *uParam0 = 3;
      }
    }
    break;

  case 1:
    if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
      *uParam0++;
    }
    break;

  case 2:
    if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
      *iParam1 = 1;
      *uParam0++;
    }
    else {
      *iParam1 = 0;
      *uParam0++;
    }
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xBA72
void func_136(struct<2> Param0, var uParam2, var uParam3, var uParam4,
              var uParam5, var uParam6, var uParam7, var uParam8, var uParam9,
              var uParam10, var uParam11, var uParam12, var uParam13,
              var uParam14, var uParam15, var uParam16, var uParam17,
              var uParam18, var uParam19, var uParam20, var uParam21,
              var uParam22, var uParam23, var uParam24, var uParam25,
              var uParam26, var uParam27, var uParam28, var uParam29,
              var uParam30, var uParam31, var uParam32, var uParam33,
              var uParam34, var uParam35, var uParam36, var uParam37,
              var uParam38, var uParam39, var uParam40, var uParam41,
              var uParam42, var uParam43, var uParam44, var uParam45,
              var uParam46, var uParam47, var uParam48, var uParam49,
              var uParam50, var uParam51, var uParam52, var uParam53,
              var uParam54, var uParam55, var uParam56, var uParam57,
              var uParam58, var uParam59, var uParam60, var uParam61,
              var uParam62, var uParam63, var uParam64, var uParam65,
              var uParam66, var uParam67, var uParam68) {
  Global_1835008 = 1;
  func_167(&Global_1835008.f_1, 1, 0);
  Global_1835008.f_3 = Param0;
  Global_1835008.f_4 = Param0.f_1;
}

// Position - 0xBA9D
int func_137() {
  if (ui::is_pause_menu_active() && !func_159()) {
    return 1;
  }
  return 0;
}

// Position - 0xBABB
int func_138() {
  if (stats::_0xA31FD15197B192BD() || Global_1835008) {
    func_139();
    return 1;
  }
  return 0;
}

// Position - 0xBADD
void func_139() {
  if (func_75(&Global_1835008.f_1, 120000, 1)) {
    stats::leaderboards_read_clear(Global_1835008.f_3, Global_1835008.f_4, -1);
    Global_1835008 = 0;
    func_86(&Global_1835008.f_1);
  }
}

// Position - 0xBB18
void func_140(int *iParam0, int *iParam1, var *uParam2) {
  *iParam0 = 0;
  *iParam1 = 0;
  Global_1835008 = 0;
  func_86(&Global_1835008.f_1);
  stats::leaderboards_read_clear(*uParam2, uParam2->f_1, -1);
}

// Position - 0xBB44
bool func_141(int iParam0) {
  if (iParam0 == 815 || iParam0 == 824 || iParam0 == 825 || iParam0 == 826 ||
      iParam0 == 827 || iParam0 == 828 || iParam0 == 849) {
    return true;
  }
  return false;
}

// Position - 0xBBA2
void func_142(var *uParam0, var *uParam1, int iParam2) {
  int iVar0;
  int iVar1;

  if (func_156(uParam0->f_44)) {
    MemCopy(uParam1, {Global_1835013.f_355}, 16);
    uParam1->f_32 = {Global_1835013.f_361};
    MemCopy(&uParam1->f_16, {Global_1835013.f_349}, 16);
  }
  else {
    StringCopy(uParam1, player::get_player_name(player::player_id()), 64);
    uParam1->f_32 = {func_55(player::player_id())};
  }
  uParam1->f_59 = iParam2;
  if (func_141(uParam0->f_44)) {
    iVar0 = Global_1835013.f_211.f_36[Global_1835390.f_2709];
    if (iVar0 == 1) {
      uParam1->f_58 = 1;
    }
    else {
      uParam1->f_58 = 0;
    }
  }
  uParam1->f_74 = 1;
  iVar1 = 0;
  while (iVar1 < Global_1835390.f_2708) {
    if (gameplay::is_bit_set(Global_1835013.f_142.f_2,
                             Global_1835390.f_2710[iVar1])) {
      uParam1->f_67[iVar1] =
          Global_1835013.f_211.f_36[Global_1835390.f_2710[iVar1]];
    }
    else {
      uParam1->f_60[iVar1] =
          Global_1835013.f_211.f_3[Global_1835390.f_2710[iVar1]];
    }
    iVar1++;
  }
}

// Position - 0xBCAF
void func_143(var *uParam0) {
  int iVar0;

  *uParam0 = 0;
  uParam0->f_1 = 0;
  uParam0->f_2 = 0;
  uParam0->f_3 = 0;
  uParam0->f_4 = 0;
  uParam0->f_5 = 0;
  uParam0->f_6 = 0;
  uParam0->f_7 = 0;
  uParam0->f_8 = 0;
  uParam0->f_9 = 0;
  uParam0->f_10 = 0;
  uParam0->f_11 = 0;
  uParam0->f_12 = 0;
  StringCopy(&uParam0->f_13, "", 24);
  uParam0->f_19 = 0;
  iVar0 = 0;
  while (iVar0 < 4) {
    StringCopy(&uParam0->f_19.f_1[iVar0 /*16*/], "", 32);
    StringCopy(&uParam0->f_19.f_1[iVar0 /*16*/].f_8, "", 32);
    iVar0++;
  }
  uParam0->f_85 = 0;
  StringCopy(&uParam0->f_86, "", 32);
  StringCopy(&uParam0->f_94, "", 8);
  uParam0->f_96 = 0;
  uParam0->f_97 = 0;
}

// Position - 0xBD58
void func_144(var *uParam0, var *uParam1) {
  *uParam0 = *uParam1;
  uParam0->f_1 = uParam1->f_1;
  uParam0->f_2 = 0;
}

// Position - 0xBD73
bool func_145(var *uParam0, int *iParam1, var *uParam2, int iParam3,
              var uParam4, int iParam5, int iParam6, int iParam7, int iParam8) {
  var uVar0;
  var uVar1;

  uVar0 = Global_1835013.f_211.f_36[0];
  uVar1 = Global_1835013.f_211.f_3[0];
  if (iParam6) {
    uVar0 = iParam7;
    uVar1 = iParam8;
  }
  switch (*uParam0) {
  case 0:
    if (!func_138() && !func_137()) {
      func_136(*uParam2);
      if (iParam5) {
        if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
          if (stats::leaderboards2_read_by_score_int(uParam2, uVar0, iParam3)) {
            *uParam0++;
          }
          else {
            *iParam1 = 0;
            *uParam0 = 3;
          }
        }
        else if (stats::leaderboards2_read_by_score_float(uParam2, uVar1,
                                                          iParam3)) {
          *uParam0++;
        }
        else {
          *iParam1 = 0;
          *uParam0 = 3;
        }
      }
      else if (stats::leaderboards2_read_by_radius(uParam2, iParam3, uParam4)) {
        *uParam0++;
      }
      else {
        *iParam1 = 0;
        *uParam0 = 3;
      }
    }
    break;

  case 1:
    if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
      *uParam0++;
    }
    break;

  case 2:
    if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
      *iParam1 = 1;
      *uParam0++;
    }
    else {
      *iParam1 = 0;
      *uParam0++;
    }
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xBEAB
bool func_146() {
  if (Global_1835388 && Global_1835389) {
    return true;
  }
  return false;
}

// Position - 0xBEC8
int func_147(var *uParam0) {
  struct<20> Var0;
  struct<6> Var98;
  int iVar106;
  int iVar107;
  int iVar108;
  int iVar109;
  int iVar110;
  int iVar111;
  int iVar112;
  int iVar113;
  struct<13> Var114;

  Var0.f_19.f_1 = 4;
  iVar108 = -1;
  iVar113 = 1;
  Var114 = {func_55(player::player_id())};
  switch ((*uParam0)[1]) {
  case 0:
    iVar107 = network::network_get_friend_count();
    Global_1835390.f_2775[1] = -1;
    Global_1835013.f_374 = -1;
    Global_1835390.f_2704[iVar113] = 0;
    if (iVar107 > 0) {
      if (func_146()) {
        iVar112 = 0;
      }
      else {
        iVar112 = 1;
      }
      if (func_148(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44,
                   &uParam0->f_113, uParam0->f_113[0 /*66*/], iVar112, 0,
                   100)) {
        func_144(&Var98, &uParam0->f_44);
        if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
          if (func_146()) {
            iVar110 = 0;
            iVar110 = 0;
            while (iVar110 < Var98.f_3) {
              if (iVar108 < 0) {
                stats::_0x34770B9CE0E03B91(iVar110, &Var0);
                if (func_156(uParam0->f_44)) {
                  if (Global_1835013.f_374 < 0) {
                    if (func_107(&Var0, &Global_1835013.f_361)) {
                      Global_1835013.f_374 = Var0.f_96;
                    }
                  }
                }
                if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
                  if (Global_1835013.f_211.f_36[0] >=
                      stats::_0x88578F6EC36B4A3A(iVar110, 0)) {
                    iVar108 = iVar110;
                  }
                }
                else if (Global_1835013.f_211.f_3[0] >=
                         stats::_0x38491439B6BA7F7D(iVar110, 0)) {
                  iVar108 = iVar110;
                }
                func_143(&Var0);
              }
              iVar110++;
            }
            if (iVar108 < 0) {
              iVar108 = Var98.f_3;
            }
          }
          iVar110 = 0;
          if (func_146() && iVar108 == 0) {
            if (Global_1835390.f_2704[iVar113] < 12) {
              func_142(uParam0,
                       &Global_1835390[iVar113 /*901*/]
                                      [Global_1835390.f_2704[iVar113] /*75*/],
                       1);
              Global_1835390.f_2775[iVar113] = 0;
              Global_1835390.f_2704[iVar113]++;
            }
          }
          if (Var98.f_3 > 0) {
            stats::_0x34770B9CE0E03B91(0, &Var0);
            if (func_146() && (func_107(&Var0, &Var114) ||
                               func_107(&Var0, &Global_1835013.f_361))) {
            }
            else if (func_108(Var0) && Global_1835390.f_2704[iVar113] < 12) {
              if (func_107(&Var0, &Var114)) {
                iVar108 = 0;
                Global_1835390.f_2775[1] = 0;
              }
              MemCopy(&Global_1835390[1 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      {Var0.f_13}, 16);
              Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
                  .f_32 = {Var0};
              Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
                  .f_59 = 1;
              if (func_141(uParam0->f_44)) {
                iVar111 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
                if (iVar111 == 1) {
                  Global_1835390[1 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_58 = 1;
                }
                else {
                  Global_1835390[1 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_58 = 0;
                }
              }
              if (func_156(uParam0->f_44)) {
                MemCopy(&Global_1835390[1 /*901*/]
                                       [Global_1835390.f_2704[iVar113] /*75*/]
                                           .f_16,
                        {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
              }
              Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
                  .f_74 = 1;
              iVar106 = 0;
              while (iVar106 < Global_1835390.f_2708) {
                if (gameplay::is_bit_set(Global_1835390.f_2769,
                                         Global_1835390.f_2710[iVar106])) {
                  Global_1835390[1 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_67[iVar106] = stats::_0x88578F6EC36B4A3A(
                      0, Global_1835390.f_2710[iVar106]);
                }
                else {
                  Global_1835390[1 /*901*/]
                                [Global_1835390.f_2704[iVar113] /*75*/]
                                    .f_60[iVar106] = stats::_0x38491439B6BA7F7D(
                      0, Global_1835390.f_2710[iVar106]);
                }
                iVar106++;
              }
              Global_1835390.f_2704[1]++;
            }
            else {
              func_143(&Var0);
              stats::_0x71B008056E5692D6();
              func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
              Global_1835390.f_2704[1] = 0;
              (*uParam0)[1] = 1;
              if (Global_1835390.f_2775[iVar113] == -1 && func_146()) {
                if (Global_1835390.f_2704[iVar113] >= 1) {
                  func_142(
                      uParam0,
                      &Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      Global_1835390[iVar113 /*901*/]
                                    [Global_1835390.f_2704[iVar113] - 1 /*75*/]
                                        .f_59 +
                          1);
                }
                else {
                  func_142(
                      uParam0,
                      &Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      1);
                }
                Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
                Global_1835390.f_2704[iVar113]++;
              }
              return 0;
            }
            func_143(&Var0);
          }
          else {
            Global_1835390.f_2704[1] = 0;
            func_143(&Var0);
            stats::_0x71B008056E5692D6();
            func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
            if (Global_1835390.f_2775[iVar113] == -1 && func_146()) {
              if (Global_1835390.f_2704[iVar113] >= 1) {
                func_142(
                    uParam0,
                    &Global_1835390[iVar113 /*901*/]
                                   [Global_1835390.f_2704[iVar113] /*75*/],
                    Global_1835390[iVar113 /*901*/]
                                  [Global_1835390.f_2704[iVar113] - 1 /*75*/]
                                      .f_59 +
                        1);
              }
              else {
                func_142(uParam0,
                         &Global_1835390[iVar113 /*901*/]
                                        [Global_1835390.f_2704[iVar113] /*75*/],
                         1);
              }
              Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
              Global_1835390.f_2704[iVar113]++;
            }
            (*uParam0)[1] = 1;
            return 0;
          }
          if (!func_146()) {
            iVar108 = Var98.f_5;
          }
          if (iVar108 > 6) {
            iVar109 = iVar108 - 6;
          }
          else {
            iVar109 = 1;
          }
          iVar110 = iVar109;
          iVar110 = iVar109;
          while (iVar110 <= Var98.f_3 - 1) {
            stats::_0x34770B9CE0E03B91(iVar110, &Var0);
            if (Global_1835390.f_2704[iVar113] < 12 && Var0.f_96 > 1) {
              if (func_146() && iVar108 == iVar110) {
                if (!func_107(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_32,
                              &Var114)) {
                  func_142(
                      uParam0,
                      &Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] /*75*/],
                      Var0.f_96);
                  Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                      .f_59 = iVar110 + 1;
                  Global_1835390.f_2775[iVar113] =
                      Global_1835390.f_2704[iVar113];
                  Global_1835390.f_2704[iVar113]++;
                }
              }
              if (func_146() && (func_107(&Var0, &Var114) ||
                                 func_107(&Var0, &Global_1835013.f_361))) {
              }
              else if (Global_1835390.f_2704[1] < 12) {
                if (func_108(Var0) &&
                    !func_107(
                        &Var0,
                        &Global_1835390[iVar113 /*901*/][0 /*75*/].f_32)) {
                  if (func_107(&Var0, &Var114)) {
                    if (Global_1835390.f_2775[1] < 0) {
                      Global_1835390.f_2775[1] = Global_1835390.f_2704[1];
                    }
                  }
                  MemCopy(&Global_1835390[1 /*901*/]
                                         [Global_1835390.f_2704[1] /*75*/],
                          {Var0.f_13}, 16);
                  Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                      .f_32 = {Var0};
                  Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                      .f_59 = iVar110 + 1;
                  Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                      .f_74 = 1;
                  if (func_141(uParam0->f_44)) {
                    iVar111 = stats::_0x88578F6EC36B4A3A(iVar110,
                                                         Global_1835390.f_2709);
                    if (iVar111 == 1) {
                      Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                          .f_58 = 1;
                    }
                    else {
                      Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                          .f_58 = 0;
                    }
                  }
                  if (func_156(uParam0->f_44)) {
                    MemCopy(&Global_1835390[1 /*901*/]
                                           [Global_1835390.f_2704[1] /*75*/]
                                               .f_16,
                            {Var0.f_19.f_1[1 /*16*/].f_8}, 16);
                  }
                  iVar106 = 0;
                  while (iVar106 < Global_1835390.f_2708) {
                    if (gameplay::is_bit_set(Global_1835390.f_2769,
                                             Global_1835390.f_2710[iVar106])) {
                      Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                          .f_67[iVar106] = stats::_0x88578F6EC36B4A3A(
                          iVar110, Global_1835390.f_2710[iVar106]);
                    }
                    else {
                      Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/]
                          .f_60[iVar106] = stats::_0x38491439B6BA7F7D(
                          iVar110, Global_1835390.f_2710[iVar106]);
                    }
                    iVar106++;
                  }
                  Global_1835390.f_2704[1]++;
                }
              }
            }
            func_143(&Var0);
            iVar110++;
          }
          stats::_0x71B008056E5692D6();
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          (*uParam0)[1] = 1;
          if (Global_1835390.f_2775[iVar113] == -1 && func_146()) {
            if (Global_1835390.f_2704[iVar113] >= 1) {
              func_142(uParam0,
                       &Global_1835390[iVar113 /*901*/]
                                      [Global_1835390.f_2704[iVar113] /*75*/],
                       Global_1835390[iVar113 /*901*/]
                                     [Global_1835390.f_2704[iVar113] - 1 /*75*/]
                                         .f_59 +
                           1);
            }
            else {
              func_142(uParam0,
                       &Global_1835390[iVar113 /*901*/]
                                      [Global_1835390.f_2704[iVar113] /*75*/],
                       1);
            }
            Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
            Global_1835390.f_2704[iVar113]++;
          }
          return 0;
        }
        else {
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          Global_1835390.f_2704[1] = 0;
          (*uParam0)[1] = 1;
          gameplay::set_bit(&Global_1835390.f_2832, 1);
          return 0;
        }
      }
    }
    else {
      func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
      Global_1835390.f_2704[1] = 0;
      (*uParam0)[1] = 1;
      return 0;
    }
    break;

  case 1:
    func_134(iVar113, Global_1835013.f_374);
    (*uParam0)[1] = 2;
    break;

  case 2: return 1;
  }
  return 0;
}

// Position - 0xC8CD
bool func_148(var *uParam0, int *iParam1, var *uParam2, var uParam3,
              var uParam4, int iParam5, int iParam6, int iParam7) {
  switch (*uParam0) {
  case 0:
    if (!func_138() && !func_137()) {
      func_136(*uParam2);
      if (stats::leaderboards2_read_friends_by_row(uParam2, uParam3, uParam4,
                                                   iParam5, iParam6, iParam7)) {
        *uParam0++;
      }
      else {
        *iParam1 = 0;
        *uParam0 = 3;
      }
    }
    break;

  case 1:
    if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
      *uParam0++;
    }
    break;

  case 2:
    if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
      *iParam1 = 1;
      *uParam0++;
    }
    else {
      *iParam1 = 0;
      *uParam0++;
    }
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xC989
int func_149(var *uParam0) {
  struct<13> Var0;
  struct<97> Var13;
  struct<6> Var111;
  int iVar119;
  int iVar120;
  int iVar121;
  int iVar122;
  int iVar123;
  int iVar124;
  bool bVar125;
  int iVar126;
  bool bVar127;
  int iVar128;

  Var13.f_19.f_1 = 4;
  iVar122 = -1;
  iVar126 = 0;
  Var0 = {func_55(player::player_id())};
  switch ((*uParam0)[iVar126]) {
  case 0:
    Global_1835390.f_2775[iVar126] = -1;
    Global_1835390.f_2704[iVar126] = 0;
    Global_1835013.f_374 = -1;
    Global_1835389 = 0;
    if (func_150(uParam0->f_44)) {
      if (!Global_1835389) {
        Global_1835389 = 1;
      }
    }
    else if (Global_1835389) {
      Global_1835389 = 0;
    }
    if (!Global_1835389) {
    }
    if (func_145(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 11, &Var0,
                 func_146(), 0, 0, 0)) {
      func_144(&Var111, &uParam0->f_44);
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var111)) {
        if (Var111.f_3 > 0) {
          iVar124 = 0;
          iVar119 = 0;
          if (func_146()) {
            iVar124 = 0;
            while (iVar124 < Var111.f_3) {
              stats::_0x34770B9CE0E03B91(iVar124, &Var13);
              if (Global_1835013.f_374 < 0) {
                if (func_107(&Var13, &Var0) ||
                    func_107(&Var13, &Global_1835013.f_361)) {
                  Global_1835013.f_374 = Var13.f_96;
                }
              }
              if (iVar122 < 0) {
                if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
                  if (Global_1835013.f_211.f_36[0] >=
                      stats::_0x88578F6EC36B4A3A(iVar124, 0)) {
                    iVar122 = iVar124;
                  }
                }
                else if (Global_1835013.f_211.f_3[0] >=
                         stats::_0x38491439B6BA7F7D(iVar124, 0)) {
                  iVar122 = iVar124;
                }
              }
              func_143(&Var13);
              iVar124++;
            }
            if (iVar122 < 0) {
              iVar122 = Var111.f_3;
            }
          }
          iVar124 = 0;
          stats::_0x34770B9CE0E03B91(0, &Var13);
          if (Var13.f_96 <= 1) {
            if (Global_1835390.f_2704[iVar126] < 12) {
              if (func_146() && iVar122 == 0) {
                func_142(uParam0,
                         &Global_1835390[iVar126 /*901*/]
                                        [Global_1835390.f_2704[iVar126] /*75*/],
                         Var13.f_96);
                Global_1835390.f_2775[iVar126] = 0;
                Global_1835390.f_2704[iVar126]++;
              }
              if (func_146() && (func_107(&Var13, &Var0) ||
                                 func_107(&Var13, &Global_1835013.f_361))) {
              }
              else {
                if (func_107(&Var13, &Var0)) {
                  iVar122 = 0;
                  Global_1835390.f_2775[iVar126] = 0;
                }
                MemCopy(&Global_1835390[iVar126 /*901*/]
                                       [Global_1835390.f_2704[iVar126] /*75*/],
                        {Var13.f_13}, 16);
                Global_1835390[iVar126 /*901*/]
                              [Global_1835390.f_2704[iVar126] /*75*/]
                                  .f_32 = {Var13};
                Global_1835390[iVar126 /*901*/]
                              [Global_1835390.f_2704[iVar126] /*75*/]
                                  .f_59 = Var13.f_96;
                if (func_141(uParam0->f_44)) {
                  iVar121 =
                      stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
                  if (iVar121 == 1) {
                    Global_1835390[iVar126 /*901*/]
                                  [Global_1835390.f_2704[iVar126] /*75*/]
                                      .f_58 = 1;
                  }
                  else {
                    Global_1835390[iVar126 /*901*/]
                                  [Global_1835390.f_2704[iVar126] /*75*/]
                                      .f_58 = 0;
                  }
                }
                if (func_156(uParam0->f_44)) {
                  MemCopy(&Global_1835390[iVar126 /*901*/]
                                         [Global_1835390.f_2704[iVar126] /*75*/]
                                             .f_16,
                          {Var13.f_19.f_1[1 /*16*/].f_8}, 16);
                }
                Global_1835390[iVar126 /*901*/]
                              [Global_1835390.f_2704[iVar126] /*75*/]
                                  .f_74 = 1;
                iVar119 = 0;
                while (iVar119 < Global_1835390.f_2708) {
                  if (gameplay::is_bit_set(Global_1835390.f_2769,
                                           Global_1835390.f_2710[iVar119])) {
                    Global_1835390[iVar126 /*901*/]
                                  [Global_1835390.f_2704[iVar126] /*75*/]
                                      .f_67[iVar119] =
                        stats::_0x88578F6EC36B4A3A(
                            0, Global_1835390.f_2710[iVar119]);
                  }
                  else {
                    Global_1835390[iVar126 /*901*/]
                                  [Global_1835390.f_2704[iVar126] /*75*/]
                                      .f_60[iVar119] =
                        stats::_0x38491439B6BA7F7D(
                            0, Global_1835390.f_2710[iVar119]);
                  }
                  iVar119++;
                }
                Global_1835390.f_2704[iVar126]++;
              }
              bVar125 = true;
            }
          }
          if (!bVar125) {
            Global_1835390.f_2704[iVar126]++;
          }
          if (!func_146()) {
            iVar122 = Var111.f_5;
          }
          if (iVar122 > 6) {
            iVar123 = iVar122 - 6;
          }
          else if (bVar125) {
            iVar123 = 1;
          }
          else {
            iVar123 = 0;
          }
          iVar124 = iVar123;
          func_143(&Var13);
          iVar124 = iVar123;
          while (iVar124 <= Var111.f_3 - 1) {
            stats::_0x34770B9CE0E03B91(iVar124, &Var13);
            if (Global_1835390.f_2704[iVar126] < 12 && Var13.f_96 > 1) {
              if (func_146() && iVar122 == iVar124) {
                if (!func_107(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_32,
                              &Var13)) {
                  func_142(
                      uParam0,
                      &Global_1835390[iVar126 /*901*/]
                                     [Global_1835390.f_2704[iVar126] /*75*/],
                      Var13.f_96);
                  Global_1835390.f_2775[iVar126] =
                      Global_1835390.f_2704[iVar126];
                  Global_1835390.f_2704[iVar126]++;
                }
              }
              if (func_146() && (func_107(&Var13, &Var0) ||
                                 func_107(&Var13, &Global_1835013.f_361))) {
              }
              else if (Global_1835390.f_2704[iVar126] < 12) {
                if (func_108(Var13) &&
                    !func_107(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_32,
                              &Var13)) {
                  if (func_107(&Var13, &Var0)) {
                    if (Global_1835390.f_2775[iVar126] < 0) {
                      Global_1835390.f_2775[iVar126] =
                          Global_1835390.f_2704[iVar126];
                    }
                  }
                  MemCopy(
                      &Global_1835390[iVar126 /*901*/]
                                     [Global_1835390.f_2704[iVar126] /*75*/],
                      {Var13.f_13}, 16);
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_32 = {Var13};
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_59 = Var13.f_96;
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_74 = 1;
                  if (func_141(uParam0->f_44)) {
                    iVar121 = stats::_0x88578F6EC36B4A3A(iVar124,
                                                         Global_1835390.f_2709);
                    if (iVar121 == 1) {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_58 = 1;
                    }
                    else {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_58 = 0;
                    }
                  }
                  if (func_156(uParam0->f_44)) {
                    MemCopy(
                        &Global_1835390[iVar126 /*901*/]
                                       [Global_1835390.f_2704[iVar126] /*75*/]
                                           .f_16,
                        {Var13.f_19.f_1[1 /*16*/].f_8}, 16);
                  }
                  iVar119 = 0;
                  iVar119 = 0;
                  while (iVar119 < Global_1835390.f_2708) {
                    if (gameplay::is_bit_set(Global_1835390.f_2769,
                                             Global_1835390.f_2710[iVar119])) {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_67[iVar119] =
                          stats::_0x88578F6EC36B4A3A(
                              iVar124, Global_1835390.f_2710[iVar119]);
                    }
                    else {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_60[iVar119] =
                          stats::_0x38491439B6BA7F7D(
                              iVar124, Global_1835390.f_2710[iVar119]);
                    }
                    iVar119++;
                  }
                  Global_1835390.f_2704[iVar126]++;
                }
              }
            }
            func_143(&Var13);
            iVar124++;
          }
          stats::_0x71B008056E5692D6();
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          if (bVar125) {
            if (Global_1835390.f_2775[iVar126] == -1 && func_146()) {
              if (Global_1835390.f_2704[iVar126] >= 1) {
                func_142(
                    uParam0,
                    &Global_1835390[iVar126 /*901*/]
                                   [Global_1835390.f_2704[iVar126] /*75*/],
                    Global_1835390[iVar126 /*901*/]
                                  [Global_1835390.f_2704[iVar126] - 1 /*75*/]
                                      .f_59 +
                        1);
              }
              else {
                func_142(uParam0,
                         &Global_1835390[iVar126 /*901*/]
                                        [Global_1835390.f_2704[iVar126] /*75*/],
                         1);
              }
              Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
              Global_1835390.f_2704[iVar126]++;
            }
            (*uParam0)[iVar126] = 2;
          }
          else {
            (*uParam0)[iVar126] = 1;
          }
        }
        else {
          if (!bVar125) {
            Global_1835390.f_2704[iVar126]++;
          }
          stats::_0x71B008056E5692D6();
          func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
          Global_1835390.f_2775[iVar126] = -1;
          (*uParam0)[iVar126] = 1;
        }
      }
      else {
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        Global_1835390.f_2775[iVar126] = -1;
        (*uParam0)[iVar126] = 1;
        gameplay::set_bit(&Global_1835390.f_2832, iVar126);
      }
    }
    break;

  case 1:
    if (Global_1835390.f_2775[iVar126] == -1) {
      iVar128 = 11;
    }
    else {
      iVar128 = 1;
    }
    if (func_135(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, iVar128)) {
      func_144(&Var111, &uParam0->f_44);
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var111)) {
        if (Var111.f_3 > 0) {
          iVar119 = 0;
          while (iVar119 < Var111.f_3) {
            stats::_0x34770B9CE0E03B91(iVar119, &Var13);
            if (func_146() && (func_107(&Var13, &Var0) ||
                               func_107(&Var13, &Global_1835013.f_361))) {
            }
            else {
              bVar127 = false;
              if (Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 > 1 ||
                  Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 <= 0) {
                bVar127 = true;
              }
              if (Global_1835390.f_2704[iVar126] < 12 || bVar127) {
                if (iVar119 == 0 || bVar127) {
                  MemCopy(&Global_1835390[iVar126 /*901*/][0 /*75*/],
                          {Var13.f_13}, 16);
                  Global_1835390[iVar126 /*901*/][0 /*75*/].f_32 = {Var13};
                  Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 = Var13.f_96;
                  if (func_141(uParam0->f_44)) {
                    iVar121 =
                        stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
                    if (iVar121 == 1) {
                      Global_1835390[iVar126 /*901*/][0 /*75*/].f_58 = 1;
                    }
                    else {
                      Global_1835390[iVar126 /*901*/][0 /*75*/].f_58 = 0;
                    }
                  }
                  if (func_156(uParam0->f_44)) {
                    MemCopy(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_16,
                            {Var13.f_19.f_1[1 /*16*/].f_8}, 16);
                  }
                  Global_1835390[iVar126 /*901*/][0 /*75*/].f_74 = 1;
                  iVar120 = 0;
                  iVar120 = 0;
                  while (iVar120 < Global_1835390.f_2708) {
                    if (gameplay::is_bit_set(Global_1835390.f_2769,
                                             Global_1835390.f_2710[iVar120])) {
                      Global_1835390[iVar126 /*901*/][iVar119 /*75*/]
                          .f_67[iVar120] = stats::_0x88578F6EC36B4A3A(
                          iVar119, Global_1835390.f_2710[iVar120]);
                    }
                    else {
                      Global_1835390[iVar126 /*901*/][iVar119 /*75*/]
                          .f_60[iVar120] = stats::_0x38491439B6BA7F7D(
                          iVar119, Global_1835390.f_2710[iVar120]);
                    }
                    iVar120++;
                  }
                  if (Global_1835390.f_2704[iVar126] == 0) {
                    if (bVar127) {
                    }
                    else {
                      Global_1835390.f_2704[iVar126]++;
                    }
                  }
                  else if (Global_1835390.f_2704[iVar126] == 1 &&
                           Global_1835390.f_2775[iVar126] == -1) {
                    Global_1835390.f_2704[iVar126]++;
                  }
                }
                else if (Global_1835390.f_2704[iVar126] < 12) {
                  MemCopy(
                      &Global_1835390[iVar126 /*901*/]
                                     [Global_1835390.f_2704[iVar126] /*75*/],
                      {Var13.f_13}, 16);
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_32 = {Var13};
                  if (func_141(uParam0->f_44)) {
                    iVar121 = stats::_0x88578F6EC36B4A3A(iVar119,
                                                         Global_1835390.f_2709);
                    if (iVar121 == 1) {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_58 = 1;
                    }
                    else {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_58 = 0;
                    }
                  }
                  if (func_156(uParam0->f_44)) {
                    MemCopy(
                        &Global_1835390[iVar126 /*901*/]
                                       [Global_1835390.f_2704[iVar126] /*75*/]
                                           .f_16,
                        {Var13.f_19.f_1[1 /*16*/].f_8}, 16);
                  }
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_59 = Var13.f_96;
                  Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/]
                                    .f_74 = 1;
                  iVar120 = 0;
                  iVar120 = 0;
                  while (iVar120 < Global_1835390.f_2708) {
                    if (gameplay::is_bit_set(Global_1835390.f_2769,
                                             Global_1835390.f_2710[iVar120])) {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_67[iVar120] =
                          stats::_0x88578F6EC36B4A3A(
                              iVar119, Global_1835390.f_2710[iVar120]);
                    }
                    else {
                      Global_1835390[iVar126 /*901*/]
                                    [Global_1835390.f_2704[iVar126] /*75*/]
                                        .f_60[iVar120] =
                          stats::_0x38491439B6BA7F7D(
                              iVar119, Global_1835390.f_2710[iVar120]);
                    }
                    iVar120++;
                  }
                  if (iVar119 != 0) {
                    Global_1835390.f_2704[iVar126]++;
                  }
                }
              }
            }
            func_143(&Var13);
            iVar119++;
          }
        }
        stats::_0x71B008056E5692D6();
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        (*uParam0)[iVar126] = 2;
      }
      else {
        gameplay::set_bit(&Global_1835390.f_2832, iVar126);
        func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
        Global_1835390.f_2704[iVar126] = 0;
        (*uParam0)[iVar126] = 2;
        Global_1835390.f_2704[1] = 0;
        (*uParam0)[1] = 1;
        Global_1835390.f_2704[2] = 0;
        (*uParam0)[2] = 3;
      }
    }
    if (Global_1835390.f_2775[iVar126] == -1 && func_146()) {
      if (Global_1835390.f_2704[iVar126] >= 1) {
        func_142(uParam0,
                 &Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/],
                 Global_1835390[iVar126 /*901*/]
                               [Global_1835390.f_2704[iVar126] - 1 /*75*/]
                                   .f_59 +
                     1);
      }
      else {
        func_142(uParam0,
                 &Global_1835390[iVar126 /*901*/]
                                [Global_1835390.f_2704[iVar126] /*75*/],
                 1);
      }
      Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
      Global_1835390.f_2704[iVar126]++;
    }
    break;

  case 2:
    func_134(iVar126, Global_1835013.f_374);
    (*uParam0)[iVar126] = 3;
    break;

  case 3: return 1;
  }
  return 0;
}

// Position - 0xD7C4
bool func_150(struct<4> Param0, var uParam4, var uParam5, var uParam6,
              var uParam7, var uParam8, var uParam9, var uParam10, var uParam11,
              var uParam12, var uParam13, var uParam14, var uParam15,
              var uParam16, var uParam17, var uParam18, var uParam19,
              var uParam20, var uParam21, var uParam22, var uParam23,
              var uParam24, var uParam25, var uParam26, var uParam27,
              var uParam28, var uParam29, var uParam30, var uParam31,
              var uParam32, var uParam33, var uParam34, var uParam35,
              var uParam36, var uParam37, var uParam38, var uParam39,
              var uParam40, var uParam41, var uParam42, var uParam43,
              var uParam44, var uParam45, var uParam46, var uParam47,
              var uParam48, var uParam49, var uParam50, var uParam51,
              var uParam52, var uParam53, var uParam54, var uParam55,
              var uParam56, var uParam57, var uParam58, var uParam59,
              var uParam60, var uParam61, var uParam62, var uParam63,
              var uParam64, var uParam65, var uParam66, var uParam67,
              var uParam68) {
  int iVar0;

  if (Global_1835388) {
    if (Global_1835013.f_5 != 0) {
      if (Global_1835013.f_5 == Param0) {
        if (Global_1835013.f_5.f_2 == Param0.f_3) {
          iVar0 = 0;
          while (iVar0 < Param0.f_3) {
            if (!gameplay::are_strings_equal(
                    &Global_1835013.f_5.f_2.f_1[iVar0 /*16*/],
                    &Param0.f_3.f_1[iVar0 /*16*/]) ||
                !gameplay::are_strings_equal(
                    &Global_1835013.f_5.f_2.f_1[iVar0 /*16*/].f_8,
                    &Param0.f_3.f_1[iVar0 /*16*/].f_8)) {
              return false;
            }
            iVar0++;
          }
          return true;
        }
      }
    }
  }
  return false;
}

// Position - 0xD85C
void func_151(var *uParam0) {
  int iVar0;

  if (stats::leaderboards_get_cache_exists(Global_1835390.f_2826)) {
    iVar0 = stats::leaderboards_get_cache_time(Global_1835390.f_2826);
    if (iVar0 < 300000) {
      gameplay::set_bit(&uParam0->f_42, 5);
    }
    else {
      gameplay::clear_bit(&uParam0->f_42, 5);
      func_119(Global_1835390.f_2826, -1);
    }
  }
}

// Position - 0xD8AC
void func_152(int iParam0) {
  if (graphics::has_scaleform_movie_loaded(iParam0)) {
    graphics::draw_scaleform_movie_fullscreen(iParam0, 255, 255, 255, 0, 0);
  }
}

// Position - 0xD8CC
void func_153(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
  char *sVar0;
  struct<2> Var1;
  struct<16> Var36;
  bool bVar52;
  struct<13> Var53;
  int iVar66;
  struct<13> Var67;
  int iVar80;

  sVar0 = "";
  if (gameplay::is_bit_set(iParam2, 4)) {
    sVar0 = "SCLB_GLOBAL";
  }
  else if (gameplay::is_bit_set(iParam2, 5)) {
    *iParam1++;
    sVar0 = "SCLB_FRIENDS";
  }
  else if (gameplay::is_bit_set(iParam2, 6)) {
    *iParam1++;
    if (network::network_is_signed_online() &&
        network::_network_player_is_in_clan()) {
      if (gameplay::is_orbis_version() && !network::_0x72D918C99BCACC54(0)) {
        sVar0 = "SCLB_CREW";
      }
      else {
        Var53 = {func_55(player::player_id())};
        if (network::network_clan_player_is_active(&Var53)) {
          network::network_clan_player_get_desc(&Var1, 35, &Var53);
          if (!gameplay::is_string_null_or_empty(&Var1.f_1)) {
            sVar0 = "STRING";
            Var36 = {Var1.f_1};
            bVar52 = true;
          }
          else {
            sVar0 = "SCLB_CREW";
          }
        }
        else {
          sVar0 = "SCLB_CREW";
        }
      }
    }
    else {
      sVar0 = "SCLB_CREW";
    }
  }
  graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
  graphics::_push_scaleform_movie_function_parameter_int(iParam2);
  if (bVar52) {
    graphics::begin_text_command_scaleform_string(sVar0);
    ui::_add_text_component_scaleform(&Var36);
    graphics::end_text_command_scaleform_string();
  }
  else {
    graphics::begin_text_command_scaleform_string(sVar0);
    graphics::end_text_command_scaleform_string();
  }
  graphics::_pop_scaleform_movie_function_void();
  *iParam1++;
  if (iParam4) {
    iVar66 = 0;
    gameplay::set_bit(&iVar66, 7);
    graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
    graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
    graphics::_push_scaleform_movie_function_parameter_int(iVar66);
    if (!network::network_is_signed_online()) {
      sVar0 = "SCLB_NOT_ONL";
    }
    else if (!network::_network_are_ros_available()) {
      sVar0 = "SCLB_NO_ROS";
    }
    else if (Global_1835390.f_2832 != 0) {
      sVar0 = "SCLB_READ_FAIL";
    }
    else {
      sVar0 = "HUD_PERM";
    }
    graphics::begin_text_command_scaleform_string(sVar0);
    graphics::_end_text_command_scaleform_string_2();
    graphics::_pop_scaleform_movie_function_void();
    *iParam1++;
  }
  else if (iParam3) {
    if (gameplay::is_bit_set(iParam2, 4)) {
      sVar0 = "SCLB_NO_GLOBAL";
    }
    else if (gameplay::is_bit_set(iParam2, 5)) {
      if (network::network_get_friend_count() > 0) {
        sVar0 = "SCLB_NO_FRNDS";
      }
      else {
        sVar0 = "SCLB_NO_FRNDSb";
      }
    }
    else if (gameplay::is_bit_set(iParam2, 6)) {
      if (network::_0x67A5589628E0CFF6()) {
        if (network::_0xBA9775570DB788CF()) {
          if (network::network_is_signed_online() &&
              network::_network_player_is_in_clan()) {
            if (gameplay::is_orbis_version() &&
                !network::_0x72D918C99BCACC54(0)) {
              sVar0 = "SCLB_NO_CREWc";
            }
            else {
              Var67 = {func_55(player::player_id())};
              if (network::network_clan_player_is_active(&Var67)) {
                network::network_clan_player_get_desc(&Var1, 35, &Var67);
                if (!gameplay::is_string_null_or_empty(&Var1.f_1)) {
                  sVar0 = "SCLB_NO_CREWb";
                  Var36 = {Var1.f_1};
                  bVar52 = true;
                }
                else {
                  sVar0 = "SCLB_NO_CREWc";
                }
              }
              else {
                sVar0 = "SCLB_NO_CREWa";
              }
            }
          }
          else {
            sVar0 = "SCLB_NO_CREWa";
          }
        }
        else {
          sVar0 = "SCLB_NO_CREWe";
        }
      }
      else {
        sVar0 = "SCLB_NO_CREWd";
      }
    }
    iVar80 = 0;
    gameplay::set_bit(&iVar80, 7);
    graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
    graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
    graphics::_push_scaleform_movie_function_parameter_int(iVar80);
    if (bVar52) {
      graphics::begin_text_command_scaleform_string(sVar0);
      ui::_add_text_component_scaleform(&Var36);
      graphics::_end_text_command_scaleform_string_2();
    }
    else {
      graphics::begin_text_command_scaleform_string(sVar0);
      graphics::_end_text_command_scaleform_string_2();
    }
    graphics::_pop_scaleform_movie_function_void();
    *iParam1++;
  }
}

// Position - 0xDBA1
void func_154(int iParam0, char *sParam1, var *uParam2, int iParam3) {
  int iVar0;

  graphics::_push_scaleform_movie_function(iParam0, "SET_TITLE");
  graphics::begin_text_command_scaleform_string(sParam1);
  graphics::end_text_command_scaleform_string();
  iVar0 = 0;
  while (iVar0 < iParam3) {
    graphics::begin_text_command_scaleform_string(&(*uParam2)[iVar0 /*6*/]);
    graphics::end_text_command_scaleform_string();
    iVar0++;
  }
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xDBE3
void func_155(int iParam0, char *sParam1, char *sParam2, char *sParam3,
              int iParam4, int iParam5) {
  graphics::_push_scaleform_movie_function(iParam0, "SET_MULTIPLAYER_TITLE");
  graphics::begin_text_command_scaleform_string(sParam1);
  if (!gameplay::is_string_null_or_empty(sParam2)) {
    ui::add_text_component_substring_text_label(sParam2);
  }
  if (iParam5 == -1) {
    if (iParam4) {
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        ui::_add_text_component_scaleform(sParam3);
      }
    }
    else if (!gameplay::is_string_null_or_empty(sParam3)) {
      ui::add_text_component_substring_text_label(sParam3);
    }
  }
  else {
    if (iParam4) {
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        ui::_add_text_component_scaleform(sParam3);
      }
    }
    else if (!gameplay::is_string_null_or_empty(sParam3)) {
      ui::add_text_component_substring_text_label(sParam3);
    }
    ui::add_text_component_integer(iParam5);
  }
  graphics::end_text_command_scaleform_string();
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xDC73
bool func_156(int iParam0) {
  if (iParam0 == 825 || iParam0 == 828) {
    return true;
  }
  return false;
}

// Position - 0xDC95
void func_157(int iParam0, int iParam1) {
  graphics::_push_scaleform_movie_function(iParam0, "SET_DISPLAY_TYPE");
  graphics::_push_scaleform_movie_function_parameter_int(iParam1);
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xDCB2
var func_158() { return unk_0x67D02A194A2FC2BD("SC_LEADERBOARD"); }

// Position - 0xDCC2
int func_159() { return func_160(player::player_id()); }

// Position - 0xDCD2
int func_160(int iParam0) {
  switch (func_161(iParam0)) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
  case 6:
  case 5:
  case 7:
  case 38:
  case 33:
  case 36:
  case 39: return 0;

  default:
  }
  return 1;
}

// Position - 0xDD32
int func_161(int iParam0) { return Global_1591201[iParam0 /*602*/].f_188; }

// Position - 0xDD45
void func_162(int iParam0) { Global_1318071 = iParam0; }

// Position - 0xDD53
void func_163(int iParam0) { Global_1354542.f_995 = iParam0; }

// Position - 0xDD64
void func_164() {
  func_166();
  func_165(4, -1);
  func_165(6, -1);
  func_165(7, -1);
  func_165(3, -1);
  func_165(1, -1);
  func_165(2, -1);
  func_165(11, -1);
  func_165(13, -1);
  func_165(14, -1);
  func_165(16, -1);
}

// Position - 0xDDB0
void func_165(int iParam0, int iParam1) {
  gameplay::set_bit(&Global_1353070.f_1014, iParam0);
  switch (iParam0) {
  case 5:
    if (iParam1 > -1) {
      Global_1353070.f_170[iParam1] = 1;
    }
    break;
  }
}

// Position - 0xDDE6
void func_166() { Global_2494199.f_4394 = 0; }

// Position - 0xDDF6
void func_167(var *uParam0, int iParam1, int iParam2) {
  if (network::network_is_game_in_progress() && !iParam1) {
    if (!iParam2) {
      *uParam0 = network::get_network_time();
    }
    else {
      *uParam0 = network::_0x89023FBBF9200E9F();
    }
  }
  else {
    *uParam0 = gameplay::get_game_timer();
  }
  uParam0->f_1 = 1;
}

// Position - 0xDE33
bool func_168(var *uParam0, int iParam1, int iParam2) {
  uParam0->f_12 = iParam2;
  func_171(uParam0);
  func_170(uParam0);
  if (gameplay::are_strings_equal(&uParam0->f_550, "SPR_RESULT") ||
      gameplay::are_strings_equal(&uParam0->f_550, "") && uParam0->f_56 > 0) {
    uParam0->f_566 = 1;
  }
  if (network::network_is_game_in_progress()) {
    graphics::request_streamed_texture_dict("MPHud", 0);
  }
  if (uParam0->f_1 == 0) {
    graphics::request_streamed_texture_dict("CommonMenu", 0);
    graphics::request_streamed_texture_dict("MPLeaderboard", 0);
    graphics::request_streamed_texture_dict("MPHud", 0);
    uParam0->f_1 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
    uParam0->f_2 = 0;
    uParam0->f_3 = 0;
  }
  uParam0->f_4 =
      graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
  if (iParam1) {
    while (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
           !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
           !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
           !graphics::has_streamed_texture_dict_loaded("MPHud")) {
      system::wait(0);
    }
    if (uParam0->f_562 || uParam0->f_567) {
      while (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
        system::wait(0);
      }
    }
  }
  else {
    if (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
        !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
        !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
        !graphics::has_streamed_texture_dict_loaded("MPHud")) {
      return false;
    }
    if (uParam0->f_562) {
      if (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
        return false;
      }
    }
  }
  if (uParam0->f_562) {
    if (uParam0->f_567) {
      func_169(uParam0);
    }
    else if (uParam0->f_56 != 0) {
      func_45(uParam0, 1);
    }
    else {
      func_45(uParam0, 0);
    }
  }
  Global_69963 = 1;
  return true;
}

// Position - 0xDFD2
void func_169(var *uParam0) {
  graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
  graphics::_pop_scaleform_movie_function_void();
  if (gameplay::is_pc_version()) {
    graphics::_push_scaleform_movie_function(uParam0->f_4,
                                             "TOGGLE_MOUSE_BUTTONS");
    graphics::_push_scaleform_movie_function_parameter_bool(1);
    graphics::_pop_scaleform_movie_function_void();
  }
  graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(2);
  func_9(controls::get_control_instructional_button(2, 188, 1));
  func_14("ES_HELP_TU");
  graphics::_pop_scaleform_movie_function_void();
  graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(1);
  func_9(controls::get_control_instructional_button(2, 187, 1));
  func_14("ES_HELP_TD");
  graphics::_pop_scaleform_movie_function_void();
  graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
  graphics::_push_scaleform_movie_function_parameter_int(0);
  func_9(controls::get_control_instructional_button(2, 202, 1));
  func_14("ES_HELP_AB");
  graphics::_pop_scaleform_movie_function_void();
  graphics::_push_scaleform_movie_function(uParam0->f_4,
                                           "DRAW_INSTRUCTIONAL_BUTTONS");
  graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xE097
void func_170(float *fParam0) {
  float fVar0;
  int iVar1;
  int iVar2;
  int iVar3;

  fVar0 = 0f;
  ui::set_text_justification(0);
  ui::set_text_scale(1f, func_59(16f));
  if (fParam0->f_31 == 0) {
    if (fParam0->f_29) {
      ui::_begin_text_command_width("STRING");
      ui::add_text_component_substring_player_name(&fParam0->f_13);
      fVar0 = ui::_end_text_command_get_width(1);
    }
    else {
      ui::_begin_text_command_width(&fParam0->f_13);
      fVar0 = ui::_end_text_command_get_width(1);
    }
  }
  else {
    ui::_begin_text_command_width("STRING");
    iVar1 = 0;
    iVar2 = 0;
    iVar3 = 0;
    iVar3 = 0;
    while (iVar3 < fParam0->f_31) {
      switch (fParam0->f_32[iVar3]) {
      case 0:
        ui::add_text_component_integer(fParam0->f_53[iVar1]);
        iVar1++;
        break;

      case 1:
        ui::add_text_component_substring_text_label(
            &fParam0->f_36[iVar2 /*16*/]);
        iVar2++;
        break;

      case 2:
        ui::add_text_component_substring_player_name(
            &fParam0->f_36[iVar2 /*16*/]);
        iVar2++;
        break;
      }
      iVar3++;
    }
    fVar0 = ui::_end_text_command_get_width(1);
  }
  if (fVar0 > 0.1125f * 2f - 0.006f * 2f) {
    *fParam0 = fVar0 / 2f + 0.006f * 2f;
  }
}

// Position - 0xE19F
void func_171(var *uParam0) {
  uParam0->f_547 = 1f;
  uParam0->f_546 = 0;
  uParam0->f_568 = 0f;
  uParam0->f_558 = 0;
  uParam0->f_30 = 0f;
  uParam0->f_548 = 0f;
  uParam0->f_559 = 0f;
  uParam0->f_560 = 0f;
  uParam0->f_545 = 0;
  uParam0->f_563 = 0;
  uParam0->f_572 = 0;
  uParam0->f_564 = 0;
  uParam0->f_565 = 0;
  uParam0->f_566 = 0;
  *uParam0 = 0.1125f;
  uParam0->f_2 = 0;
  uParam0->f_3 = 0;
  uParam0->f_574 = 0;
  uParam0->f_575 = 0;
  uParam0->f_573 = 1f;
}

// Position - 0xE21E
void func_172(var *uParam0, char *sParam1, int iParam2, int iParam3,
              int iParam4, int *iParam5, float fParam6) {
  int iVar0;
  int iVar1;
  int iVar2;
  int iVar3;

  if (func_239(uParam0, 4)) {
    return;
  }
  else {
    func_175(&uParam0->f_26);
    func_174(&uParam0->f_26, "BJ_SC_PASS", sParam1, 0);
    func_202(uParam0, 4, 1);
  }
  *iParam5 = 0;
  if (iParam3 > 1) {
    if (iParam2 == iParam3) {
      iVar0 = system::ceil(100f * fParam6);
    }
  }
  iVar3 = system::ceil(IntToFloat(iParam2 * 30) * fParam6);
  iVar1 = system::ceil(fParam6 * 50f);
  iVar2 = system::ceil(fParam6 * 1.5f * system::to_float(iParam4));
  *iParam5 = iVar1 + iVar2 + iVar0 + iVar3;
  if (iParam3 > 1) {
    if (iVar0 > 0) {
      func_173(&uParam0->f_26, 3, "BJ_SC_ALLG_RWD", "", iVar0, 0, 2, 0);
    }
    else {
      func_173(&uParam0->f_26, 3, "BJ_SC_ALLG_RWD", "", 0, 0, 1, 0);
    }
    func_173(&uParam0->f_26, 2, "BJ_SC_GATES", "", iParam2, iParam3, 0, 0);
  }
  func_173(&uParam0->f_26, 11, "BJ_SC_LAND_ACC", "", iParam4, 0, 0, 0);
  if (iParam3 > 1) {
    func_173(&uParam0->f_26, 3, "BJ_SC_GATE_RWD", "", iVar3, 0, 0, 0);
  }
  func_173(&uParam0->f_26, 3, "BJ_SC_ACC_RWD", "",
           system::round((50f + 1.5f * IntToFloat(iParam4)) * fParam6), 0, 0,
           0);
  func_173(&uParam0->f_26, 3, "BJ_SC_TOT_RWD", "", *iParam5, 0, 0, 0);
}

// Position - 0xE371
void func_173(var *uParam0, int iParam1, char *sParam2, char *sParam3,
              int iParam4, int iParam5, int iParam6, int iParam7) {
  int iVar0;

  if (uParam0->f_56 == 13) {
    return;
  }
  iVar0 = uParam0->f_56;
  uParam0->f_57[iVar0] = iParam1;
  StringCopy(&uParam0->f_71[iVar0 /*16*/], sParam2, 64);
  StringCopy(&uParam0->f_280[iVar0 /*16*/], sParam3, 64);
  uParam0->f_489[iVar0] = iParam4;
  uParam0->f_503[iVar0] = iParam5;
  uParam0->f_517[iVar0] = iParam6;
  uParam0->f_531[iVar0] = iParam7;
  uParam0->f_56++;
}

// Position - 0xE3E4
void func_174(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
  StringCopy(&uParam0->f_5, sParam1, 16);
  StringCopy(&uParam0->f_13, sParam2, 64);
  uParam0->f_29 = iParam3;
  uParam0->f_11 = 0;
}

// Position - 0xE407
void func_175(var *uParam0) {
  func_171(uParam0);
  uParam0->f_570 = 0;
  uParam0->f_31 = 0;
  uParam0->f_56 = 0;
  uParam0->f_567 = 0;
  uParam0->f_569 = 0;
}

// Position - 0xE431
char *func_176(int iParam0) {
  switch (iParam0) {
  case 0: return "BJ_JUMP_01";

  case 1: return "BJ_JUMP_02";

  case 2: return "BJ_JUMP_03";

  case 3: return "BJ_JUMP_04";

  case 4: return "BJ_JUMP_05";

  case 5: return "BJ_JUMP_06";

  case 6: return "BJ_JUMP_07";

  case 7: return "BJ_JUMP_08";

  case 8: return "BJ_JUMP_09";

  case 9: return "BJ_JUMP_10";

  case 10: return "BJ_JUMP_11";

  case 11: return "BJ_JUMP_12";

  case 12: return "BJ_JUMP_13";

  default:
  }
  return "";
}

// Position - 0xE4EC
bool func_177(int iParam0, int iParam1, float fParam2, int iParam3) {
  if (Global_1835013.f_1 && !Global_1835013.f_2) {
    func_186(iParam0, iParam1, fParam2, iParam3);
    Global_1835013.f_2 = 1;
  }
  if (func_178(&uLocal_177)) {
    Global_1835388 = 1;
    return true;
  }
  return false;
}

// Position - 0xE52F
bool func_178(var *uParam0) {
  struct<98> Var0;
  struct<4> Var98;
  struct<37> Var106;
  struct<13> Var175;
  int iVar188;

  Var0.f_19.f_1 = 4;
  Var106.f_3 = 32;
  Var106.f_36 = 32;
  if (func_156(uParam0->f_44)) {
    Var175 = {Global_1835013.f_361};
  }
  else {
    Var175 = {func_55(player::player_id())};
  }
  switch (Global_1835013) {
  case 0:
    if (func_185(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, &Var175)) {
      func_144(&Var98, &uParam0->f_44);
      Global_1835013.f_142 = uParam0->f_44;
      Global_1835013.f_142.f_1 =
          stats::leaderboards_get_number_of_columns(uParam0->f_44, 0);
      iVar188 = 0;
      while (iVar188 < Global_1835013.f_142.f_1) {
        if (!func_184(uParam0->f_44, iVar188)) {
          if (func_183(uParam0->f_44, 4, iVar188)) {
            gameplay::set_bit(&Global_1835013.f_142.f_2, iVar188);
          }
          else {
            gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar188);
          }
        }
        iVar188++;
      }
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
        if (Var98.f_3 > 0) {
          stats::_0x34770B9CE0E03B91(0, &Var0);
          if (Var0.f_97 != Global_1835013.f_142.f_1) {
          }
          if (!func_108(Var0)) {
            Global_1835013.f_4 = 1;
          }
          else {
            iVar188 = 0;
            while (iVar188 < Global_1835013.f_142.f_1) {
              if (!func_184(uParam0->f_44, iVar188)) {
                if (func_183(uParam0->f_44, 4, iVar188)) {
                  Global_1835013.f_73.f_36[iVar188] =
                      stats::_0x88578F6EC36B4A3A(0, iVar188);
                  if (Global_1835013.f_73.f_36[iVar188] == -1) {
                    if (iVar188 > Var0.f_97) {
                      Global_1835013.f_73.f_36[iVar188] = 0;
                    }
                  }
                }
                else {
                  Global_1835013.f_73.f_3[iVar188] =
                      stats::_0x38491439B6BA7F7D(0, iVar188);
                  if (Global_1835013.f_73.f_3[iVar188] == -1f) {
                    if (iVar188 > Var0.f_97) {
                      Global_1835013.f_73.f_3[iVar188] = 0f;
                    }
                  }
                }
              }
              iVar188++;
            }
          }
        }
        else {
          Global_1835013.f_4 = 1;
        }
        stats::_0x71B008056E5692D6();
      }
      else {
        Global_1835013.f_4 = 1;
      }
      Global_1835013 = 1;
      func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
    }
    break;

  case 1:
    Global_1835013.f_1 = 1;
    if (Global_1835013.f_2) {
      func_182();
      if (Global_1835013.f_4) {
        if (func_181(uParam0->f_44)) {
          Global_1835013 = 3;
        }
        else {
          Global_1835013 = 2;
        }
      }
      else {
        Global_1835013 = 2;
      }
    }
    break;

  case 2:
    stats::_0xC38DC1E90D22547C(&Global_1835013.f_73, &Global_1835013.f_142,
                               &Global_1835013.f_211);
    Global_1835013 = 4;
    uParam0->f_4 = 0;
    uParam0->f_5 = 0;
    break;

  case 3:
    Global_1835013.f_211 = {Global_1835013.f_142};
    Global_1835013 = 4;
    uParam0->f_4 = 0;
    uParam0->f_5 = 0;
    break;

  case 4:
    if (network::network_is_game_in_progress() && func_180()) {
      if (func_179()) {
        Global_1835013 = 99;
      }
      else {
        Global_1835013 = 999;
        return true;
      }
    }
    else {
      Global_1835013 = 999;
      return true;
    }
    break;

  case 99:
    if (func_181(uParam0->f_44)) {
      Global_1835013.f_280 = {Global_1835013.f_142};
    }
    else {
      Var106 = Global_1835013.f_142;
      Var106.f_1 = Global_1835013.f_142.f_1;
      Var106.f_2 = Global_1835013.f_142.f_2;
      stats::_0xC38DC1E90D22547C(&Var106, &Global_1835013.f_142,
                                 &Global_1835013.f_280);
    }
    Global_1835013 = 100;
    uParam0->f_4 = 0;
    uParam0->f_5 = 0;
    break;

  case 100:
    if (func_145(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, &Var175, 1, 1,
                 Global_1835013.f_280.f_36[0], Global_1835013.f_280.f_3[0])) {
      func_144(&Var98, &uParam0->f_44);
      if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
        if (Var98.f_3 > 0) {
          stats::_0x34770B9CE0E03B91(0, &Var0);
          if (gameplay::are_strings_equal(&Var0.f_13, "")) {
            Global_979489.f_1 = -1;
          }
          else {
            Global_979489.f_1 = Var0.f_96;
          }
        }
        else {
          Global_979489.f_1 = -1;
        }
        stats::_0x71B008056E5692D6();
      }
      else {
        Global_979489.f_1 = -1;
      }
      Global_1835013 = 999;
      func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
    }
    break;

  case 999: return true;
  }
  return false;
}

// Position - 0xE952
bool func_179() { return gameplay::is_bit_set(Global_970912.f_8, 1); }

// Position - 0xE965
var func_180() { return Global_2450895.f_3; }

// Position - 0xE973
bool func_181(int iParam0) {
  switch (iParam0) {
  case 817:
  case 850:
  case 824:
  case 827:
  case 815:
  case 826:
  case 777:
  case 825:
  case 828:
  case 849:
  case 928:
  case 795:
  case 202:
  case 811:
  case 193:
  case 975:
  case 976:
  case 970:
  case 973:
  case 968:
  case 969:
  case 966:
  case 974:
  case 971:
  case 967:
  case 965:
  case 972: return true;
  }
  if (iParam0 >= 998 && iParam0 <= 1197) {
    return true;
  }
  return false;
}

// Position - 0xEA44
void func_182() {
  Global_1835013.f_73 = Global_1835013.f_142;
  Global_1835013.f_73.f_1 = Global_1835013.f_142.f_1;
  Global_1835013.f_73.f_2 = Global_1835013.f_142.f_2;
  Global_1835013.f_211 = Global_1835013.f_142;
  Global_1835013.f_211.f_1 = Global_1835013.f_142.f_1;
  Global_1835013.f_211.f_2 = Global_1835013.f_142.f_2;
}

// Position - 0xEAA4
bool func_183(int iParam0, int iParam1, int iParam2) {
  int iVar0;

  if (iParam0 == 190) {
    if (iParam2 == 0) {
      return false;
    }
  }
  if (iParam0 == 203) {
    if (iParam2 == 3 || iParam2 == 6) {
      return false;
    }
  }
  if (iParam0 == 912) {
    if (iParam2 == 0 || iParam2 == 3) {
      return false;
    }
  }
  if (iParam0 == 762 || iParam0 == 822 || iParam0 == 823) {
    if (iParam2 == 0 || iParam2 == 3) {
      return false;
    }
  }
  if (iParam0 == 791) {
    if (iParam2 == 4) {
      return false;
    }
  }
  if (iParam0 == 780) {
    if (iParam2 == 3) {
      return false;
    }
  }
  if (iParam0 == 777) {
    if (iParam2 == 3 || iParam2 == 7) {
      return false;
    }
  }
  if (iParam0 == 1200) {
    if (iParam2 == 4) {
      return false;
    }
  }
  iVar0 = stats::leaderboards_get_column_type(iParam0, iParam1, iParam2);
  switch (iVar0) {
  case 1:
  case 2: return true;
  }
  return false;
}

// Position - 0xEBA6
int func_184(int iParam0, int iParam1) {
  if (stats::leaderboards_get_column_id(iParam0, 4, iParam1) == 156) {
    return 1;
  }
  switch (iParam0) {
  case 912:
    if (iParam1 == 5) {
      return 1;
    }
    break;

  case 780:
    if (iParam1 == 4) {
      return 1;
    }
    break;

  case 1200:
    if (iParam1 == 5) {
      return 1;
    }
    break;
  }
  return 0;
}

// Position - 0xEC01
bool func_185(var *uParam0, int *iParam1, var *uParam2, var uParam3) {
  switch (*uParam0) {
  case 0:
    if (!func_138() && !func_137()) {
      func_136(*uParam2);
      if (stats::leaderboards2_read_by_handle(uParam2, uParam3)) {
        *uParam0++;
      }
      else {
        *iParam1 = 0;
        *uParam0 = 3;
      }
    }
    break;

  case 1:
    if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
      *uParam0++;
    }
    break;

  case 2:
    if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
      *iParam1 = 1;
      *uParam0++;
    }
    else {
      *iParam1 = 0;
      *uParam0++;
    }
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0xECB5
void func_186(int iParam0, int iParam1, float fParam2, int iParam3) {
  struct<6> Var0[1];
  struct<8> Var7[1];

  StringCopy(&Var7[0 /*8*/], "Location", 32);
  switch (iParam0) {
  case 0: StringCopy(&Var0[0 /*6*/], "BJUMP_01", 24); break;

  case 1: StringCopy(&Var0[0 /*6*/], "BJUMP_02", 24); break;

  case 2: StringCopy(&Var0[0 /*6*/], "BJUMP_03", 24); break;

  case 3: StringCopy(&Var0[0 /*6*/], "BJUMP_04", 24); break;

  case 4: StringCopy(&Var0[0 /*6*/], "BJUMP_05", 24); break;

  case 5: StringCopy(&Var0[0 /*6*/], "BJUMP_06", 24); break;

  case 6: StringCopy(&Var0[0 /*6*/], "BJUMP_07", 24); break;

  case 7: StringCopy(&Var0[0 /*6*/], "BJUMP_08", 24); break;

  case 8: StringCopy(&Var0[0 /*6*/], "BJUMP_09", 24); break;

  case 9: StringCopy(&Var0[0 /*6*/], "BJUMP_10", 24); break;

  case 10: StringCopy(&Var0[0 /*6*/], "BJUMP_11", 24); break;

  case 11: StringCopy(&Var0[0 /*6*/], "BJUMP_12", 24); break;

  case 12: StringCopy(&Var0[0 /*6*/], "BJUMP_13", 24); break;
  }
  if (func_188(274, &Var0, &Var7, 1, -1, 1, 0)) {
    func_187(274, 131, iParam3, 0f, 0);
    if (iParam1 == 100) {
      func_187(274, 98, 1, 0f, 0);
    }
    else {
      func_187(274, 98, 0, 0f, 0);
    }
    func_187(274, 109, 1, 0f, 0);
    func_187(274, 8, iParam3, 0f, 0);
    func_187(274, 93, 0, fParam2, 0);
  }
}

// Position - 0xEE44
void func_187(int iParam0, int iParam1, int iParam2, float fParam3,
              int iParam4) {
  int iVar0;
  int iVar1;

  if (!iParam4) {
    stats::_0x0BCA1D2C47B0D269(iParam1, iParam2, fParam3);
  }
  if (!Global_1835013.f_3) {
    Global_1835013.f_142 = iParam0;
    Global_1835013.f_142.f_1 =
        stats::leaderboards_get_number_of_columns(Global_1835013.f_142, 0);
    iVar1 = 0;
    while (iVar1 < 32) {
      if (iVar1 < Global_1835013.f_142.f_1) {
        if (iParam1 == 156) {
        }
        else if (func_183(iParam0, 4, iVar1)) {
          gameplay::set_bit(&Global_1835013.f_142.f_2, iVar1);
        }
        else {
          gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar1);
        }
      }
      else {
        gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar1);
      }
      iVar1++;
    }
    Global_1835013.f_3 = 1;
  }
  iVar1 = 0;
  while (iVar1 < 32) {
    if (iParam1 == stats::leaderboards_get_column_id(iParam0, 4, iVar1)) {
      iVar0 = iVar1;
      iVar1 = 32;
    }
    iVar1++;
  }
  Global_1835013.f_142.f_36[iVar0] = iParam2;
  Global_1835013.f_142.f_3[iVar0] = fParam3;
  if (iParam2 != 0) {
    gameplay::set_bit(&Global_1835013.f_142.f_2, iVar0);
  }
  else if (fParam3 != 0f) {
    gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar0);
  }
}

// Position - 0xEF5F
bool func_188(int iParam0, var *uParam1, var *uParam2, int iParam3, int iParam4,
              int iParam5, int iParam6) {
  struct<68> Var0;
  int iVar68;
  struct<13> Var69;
  var uVar82;

  if (!network::network_is_signed_online()) {
  }
  if (!network::network_player_is_cheater() &&
      (network::network_have_online_privileges() ||
       !network::_0x1353F87E89946207()) &&
      network::_0x422D396F80A96547()) {
    Var0.f_2.f_1 = 4;
    Var0 = iParam0;
    if (iParam4 == -1) {
      if (network::_network_player_is_in_clan()) {
        Var69 = {func_55(player::player_id())};
        if (network::network_clan_player_is_active(&Var69)) {
          if (network::network_clan_player_get_desc(&uVar82, 35, &Var69)) {
            Var0.f_1 = uVar82;
          }
        }
      }
    }
    else {
      Var0.f_1 = iParam4;
    }
    Var0.f_2 = iParam3;
    iVar68 = 0;
    while (iVar68 < iParam3) {
      Var0.f_2.f_1[iVar68 /*16*/] = {(*uParam2)[iVar68 /*8*/]};
      MemCopy(&Var0.f_2.f_1[iVar68 /*16*/].f_8, {(*uParam1)[iVar68 /*6*/]}, 8);
      iVar68++;
    }
    if (iParam5) {
      Global_1835013.f_5 = {Var0};
    }
    if (!iParam6) {
      if (network::network_is_game_in_progress() && Global_2450895.f_3) {
        stats::_0xC980E62E33DF1D5C(&Var0, &Global_1751175.f_10);
      }
      else {
        stats::leaderboards2_write_data(&Var0);
      }
    }
    return true;
  }
  if (network::network_player_is_cheater()) {
  }
  if (!network::network_have_online_privileges()) {
  }
  if (network::_0x1353F87E89946207()) {
  }
  if (!network::_0x422D396F80A96547()) {
  }
  return false;
}

// Position - 0xF093
void func_189(int iParam0) {
  vector3 vVar0;

  switch (iParam0) {
  case 0: StringCopy(&vVar0, "BJUMP_01", 24); break;

  case 1: StringCopy(&vVar0, "BJUMP_02", 24); break;

  case 2: StringCopy(&vVar0, "BJUMP_03", 24); break;

  case 3: StringCopy(&vVar0, "BJUMP_04", 24); break;

  case 4: StringCopy(&vVar0, "BJUMP_05", 24); break;

  case 5: StringCopy(&vVar0, "BJUMP_06", 24); break;

  case 6: StringCopy(&vVar0, "BJUMP_07", 24); break;

  case 7: StringCopy(&vVar0, "BJUMP_08", 24); break;

  case 8: StringCopy(&vVar0, "BJUMP_09", 24); break;

  case 9: StringCopy(&vVar0, "BJUMP_10", 24); break;

  case 10: StringCopy(&vVar0, "BJUMP_11", 24); break;

  case 11: StringCopy(&vVar0, "BJUMP_12", 24); break;

  case 12: StringCopy(&vVar0, "BJUMP_13", 24); break;
  }
  func_190(&uLocal_177, 85, &vVar0, func_176(iParam0), iParam0, -1, 0, 0);
}

// Position - 0xF194
void func_190(var *uParam0, int iParam1, char *sParam2, char *sParam3,
              int iParam4, int iParam5, int iParam6, int iParam7) {
  struct<8> Var0;
  struct<8> Var8;
  int iVar16;
  struct<6> Var17;

  if (!gameplay::is_string_null_or_empty(sParam2)) {
    StringCopy(&Var0, sParam2, 32);
  }
  if (iParam7) {
  }
  Global_1835390.f_2769 = 0;
  Global_1835390.f_2770 = 0;
  Global_1835390.f_2768 = 0;
  switch (iParam1) {
  case 2:
    if (iParam4 == 0) {
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44 = 826;
      }
      else {
        uParam0->f_44 = 815;
      }
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44.f_3 = 2;
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
        StringCopy(&Var8, "", 32);
        StringIntConCat(&Var8, iParam5, 32);
        uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
        Global_1835390.f_2780.f_26 = iParam5;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          if (iParam5 == 1) {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_L1", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
          else {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_LM", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
        }
        else if (iParam5 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_L1", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_LM", 32);
        }
      }
      else {
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE", 32);
          StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN", 32);
        }
        Global_1835390.f_2780.f_26 = -1;
      }
      Global_1835390.f_2780 = 1;
      if (iParam5 <= 0 || func_193()) {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
        Global_1835390.f_2710[0] = 1;
        Global_1835390.f_2710[1] = 3;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 4;
        Global_1835390.f_2708 = 2;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        Global_1835390.f_2780.f_28 = 4;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 3;
        Global_1835390.f_2780.f_29[2] = 5;
      }
      else {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
        Global_1835390.f_2710[0] = 2;
        Global_1835390.f_2710[1] = 1;
        Global_1835390.f_2710[2] = 3;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 4;
        Global_1835390.f_2708 = 3;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
        Global_1835390.f_2780.f_28 = 5;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 1;
        Global_1835390.f_2780.f_29[2] = 3;
        Global_1835390.f_2780.f_29[3] = 5;
      }
      Global_1835390.f_2779 = 0;
    }
    else if (iParam4 == 1) {
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44 = 827;
      }
      else {
        uParam0->f_44 = 824;
      }
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44.f_3 = 2;
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
        StringCopy(&Var8, "", 32);
        StringIntConCat(&Var8, iParam5, 32);
        uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
        Global_1835390.f_2780.f_26 = iParam5;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          if (iParam5 == 1) {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_L1", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
          else {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_LM", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
        }
        else if (iParam5 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN_L1", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN_LM", 32);
        }
      }
      else {
        Global_1835390.f_2780.f_26 = -1;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE", 32);
          StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN", 32);
        }
      }
      Global_1835390.f_2780 = 1;
      if (iParam5 <= 0 || func_193()) {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
        Global_1835390.f_2710[0] = 1;
        Global_1835390.f_2710[1] = 5;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 6;
        Global_1835390.f_2708 = 2;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        Global_1835390.f_2780.f_28 = 4;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 3;
        Global_1835390.f_2780.f_29[2] = 5;
      }
      else {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
        Global_1835390.f_2710[0] = 2;
        Global_1835390.f_2710[1] = 1;
        Global_1835390.f_2710[2] = 5;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2708 = 3;
        Global_1835390.f_2709 = 6;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
        Global_1835390.f_2780.f_28 = 5;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 1;
        Global_1835390.f_2780.f_29[2] = 3;
        Global_1835390.f_2780.f_29[3] = 5;
      }
      Global_1835390.f_2779 = 0;
    }
    else if (iParam4 == 2) {
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44 = 828;
      }
      else {
        uParam0->f_44 = 825;
      }
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 2;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      if (!iParam6) {
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "CoDriver", 32);
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "", 32);
      }
      else {
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "CoDriver", 32);
        network::network_player_get_userid(player::player_id(), &Var17);
        MemCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, {Var17}, 8);
        Global_1835390.f_2780.f_27 = 1;
      }
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44.f_3 = 3;
        StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Laps", 32);
        StringCopy(&Var8, "", 32);
        StringIntConCat(&Var8, iParam5, 32);
        uParam0->f_44.f_3.f_1[2 /*16*/].f_8 = {Var8};
        Global_1835390.f_2780.f_26 = iParam5;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          if (iParam5 == 1) {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_L1", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
          else {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_LM", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
        }
        else if (iParam5 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN_L1", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN_LM", 32);
        }
      }
      else {
        Global_1835390.f_2780.f_26 = -1;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE", 32);
          StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN", 32);
        }
      }
      if (iParam5 <= 0 || func_193()) {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
        Global_1835390.f_2710[0] = 1;
        Global_1835390.f_2710[1] = 3;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 4;
        Global_1835390.f_2708 = 2;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        Global_1835390.f_2780.f_28 = 4;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 3;
        Global_1835390.f_2780.f_29[2] = 5;
      }
      else {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
        Global_1835390.f_2710[0] = 2;
        Global_1835390.f_2710[1] = 1;
        Global_1835390.f_2710[2] = 3;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2708 = 3;
        Global_1835390.f_2709 = 4;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
        Global_1835390.f_2780.f_28 = 5;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 1;
        Global_1835390.f_2780.f_29[2] = 3;
        Global_1835390.f_2780.f_29[3] = 5;
      }
      Global_1835390.f_2779 = 0;
    }
    else if (iParam4 == 10 || iParam4 == 11) {
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44 = 928;
      }
      else {
        uParam0->f_44 = 849;
      }
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44.f_3 = 2;
        StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
        StringCopy(&Var8, "", 32);
        StringIntConCat(&Var8, iParam5, 32);
        uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
        Global_1835390.f_2780.f_26 = iParam5;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          if (iParam5 == 1) {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_L1", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
          else {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_LM", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
        }
        else if (iParam5 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN_L1", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN_LM", 32);
        }
      }
      else {
        Global_1835390.f_2780.f_26 = -1;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE", 32);
          StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN", 32);
        }
      }
      Global_1835390.f_2780 = 1;
      if (iParam5 <= 0 || func_193()) {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
        Global_1835390.f_2710[0] = 1;
        Global_1835390.f_2710[1] = 0;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 0;
        Global_1835390.f_2708 = 1;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        Global_1835390.f_2780.f_28 = 4;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 5;
      }
      else {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        Global_1835390.f_2710[0] = 2;
        Global_1835390.f_2710[1] = 1;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2708 = 2;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
        Global_1835390.f_2780.f_28 = 5;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 1;
        Global_1835390.f_2780.f_29[2] = 5;
      }
      Global_1835390.f_2779 = 0;
    }
    else if (iParam4 == 3) {
      if (iParam5 > 0 && !func_193()) {
        uParam0->f_44 = 998 + iParam5 - 1;
      }
      else {
        uParam0->f_44 = 975;
      }
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      if (iParam5 > 0 && !func_193()) {
        Global_1835390.f_2780.f_26 = iParam5;
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          if (iParam5 == 1) {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_L1", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
          else {
            StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_LM", 32);
            StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
          }
        }
        else if (iParam5 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_L1", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_LM", 32);
        }
      }
      else {
        if (!gameplay::is_string_null_or_empty(sParam3)) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE", 32);
          StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN", 32);
        }
        Global_1835390.f_2780.f_26 = -1;
      }
      Global_1835390.f_2780 = 1;
      if (iParam5 <= 0 || func_193()) {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
        Global_1835390.f_2710[0] = 1;
        Global_1835390.f_2710[1] = 3;
        Global_1835390.f_2710[2] = 0;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 4;
        Global_1835390.f_2708 = 2;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        Global_1835390.f_2780.f_28 = 4;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 3;
        Global_1835390.f_2780.f_29[2] = 5;
      }
      else {
        StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
        StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
        StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
        StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
        Global_1835390.f_2710[0] = 2;
        Global_1835390.f_2710[1] = 1;
        Global_1835390.f_2710[2] = 3;
        Global_1835390.f_2710[3] = 0;
        Global_1835390.f_2709 = 4;
        Global_1835390.f_2708 = 3;
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
        gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
        Global_1835390.f_2780.f_28 = 5;
        Global_1835390.f_2780.f_29[0] = 1;
        Global_1835390.f_2780.f_29[1] = 1;
        Global_1835390.f_2780.f_29[2] = 3;
        Global_1835390.f_2780.f_29[3] = 5;
      }
      Global_1835390.f_2779 = 0;
    }
    break;

  case 1:
    if (iParam4 == 0) {
      uParam0->f_44 = 762;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_DM", 32);
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_DM_NN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
      StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
      StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 6;
      Global_1835390.f_2710[3] = 3;
      Global_1835390.f_2710[4] = 1;
      Global_1835390.f_2710[5] = 2;
      Global_1835390.f_2708 = 6;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 4;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 4;
      Global_1835390.f_2780.f_29[4] = 5;
      Global_1835390.f_2780.f_29[5] = 5;
    }
    else if (iParam4 == 1) {
      uParam0->f_44 = 822;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_TDM", 32);
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_TDM_NN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
      StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
      StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 6;
      Global_1835390.f_2710[3] = 3;
      Global_1835390.f_2710[4] = 1;
      Global_1835390.f_2710[5] = 2;
      Global_1835390.f_2708 = 6;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 4;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 4;
      Global_1835390.f_2780.f_29[4] = 5;
      Global_1835390.f_2780.f_29[5] = 5;
    }
    else if (iParam4 == 2) {
      uParam0->f_44 = 823;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_VEHDM", 32);
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_VEHDM_NN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
      StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
      StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 6;
      Global_1835390.f_2710[3] = 3;
      Global_1835390.f_2710[4] = 1;
      Global_1835390.f_2710[5] = 2;
      Global_1835390.f_2708 = 6;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 4;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 4;
      Global_1835390.f_2780.f_29[4] = 5;
      Global_1835390.f_2780.f_29[5] = 5;
    }
    break;

  case 11:
    uParam0->f_44 = 193;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_GOLF", 32);
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_GOLF0", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_GOLF1", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_GAMES", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 1;
    Global_1835390.f_2710[2] = 3;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 3;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 7;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 94:
    uParam0->f_44 = 193;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_GOLF", 32);
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_GOLF0", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_GOLF1", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_GAMES", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 1;
    Global_1835390.f_2710[2] = 3;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 3;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 7;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 92:
    uParam0->f_44 = 811;
    uParam0->f_44.f_1 = 1;
    uParam0->f_44.f_3 = 0;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_HUNTING", 32);
    StringCopy(&Global_1835390.f_2780.f_9, "CMSW", 64);
    Global_1835390.f_2780.f_25 = 0;
    Global_1835390.f_2780 = 0;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_HSCORE", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIMEHUNT", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_EKILLS", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_PHOTOS", 24);
    StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MONEY", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 5;
    Global_1835390.f_2710[2] = 2;
    Global_1835390.f_2710[3] = 4;
    Global_1835390.f_2710[4] = 6;
    Global_1835390.f_2708 = 5;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
    Global_1835390.f_2780.f_28 = 6;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 6;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    Global_1835390.f_2780.f_29[4] = 5;
    break;

  case 15:
    uParam0->f_44 = 749;
    uParam0->f_44.f_1 = 1;
    uParam0->f_44.f_3 = 0;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_ARM", 32);
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_WLRAT", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
    Global_1835390.f_2710[0] = 2;
    Global_1835390.f_2710[1] = 5;
    Global_1835390.f_2710[2] = 0;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 3;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 4;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 14:
    uParam0->f_44 = 190;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    if (iParam4 == -1) {
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
    }
    else {
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    }
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_DARTS", 32);
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 7;
    Global_1835390.f_2710[2] = 5;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 3;
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 4;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 12:
    uParam0->f_44 = 283;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TENNIS", 32);
    StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    if (gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_TENNIS", 64);
      StringIntConCat(&Global_1835390.f_2780.f_9, iParam4 + 1, 64);
    }
    Global_1835390.f_2780.f_25 = 0;
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TEN1", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TEN2", 24);
    StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_TEN0", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 9;
    Global_1835390.f_2710[2] = 7;
    Global_1835390.f_2710[3] = 5;
    Global_1835390.f_2710[4] = 2;
    Global_1835390.f_2708 = 5;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    Global_1835390.f_2780.f_29[4] = 5;
    break;

  case 87:
    uParam0->f_44 = 283;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TENNIS", 32);
    StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    Global_1835390.f_2780.f_25 = 0;
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TEN1", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TEN2", 24);
    StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_TEN0", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 9;
    Global_1835390.f_2710[2] = 7;
    Global_1835390.f_2710[3] = 5;
    Global_1835390.f_2710[4] = 2;
    Global_1835390.f_2708 = 5;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    Global_1835390.f_2780.f_29[4] = 5;
    break;

  case 13:
    uParam0->f_44 = 912;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 2;
    switch (iParam4) {
    case 0:
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "RANDOM", 32);
      StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEa", 32);
      break;

    case 1:
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "GRID", 32);
      StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEb", 32);
      break;

    case 2:
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "COVERED", 32);
      StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEc", 32);
      break;

    default:
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "RANDOM", 32);
      StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEa", 32);
      break;
    }
    switch (iParam5) {
    case 0:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Pistols", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_PISTOL", 64);
      break;

    case 1:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "SMGs", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_SMG", 64);
      break;

    case 2:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "AssaultRifles", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_ASSAULT", 64);
      break;

    case 3:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Shotguns", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_SHOTGUN", 64);
      break;

    case 4:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "LMGs", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_LMG", 64);
      break;

    case 5:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Heavies", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_HEAVY", 64);
      break;

    default:
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Pistols", 32);
      StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_PISTOL", 64);
      break;
    }
    Global_1835390.f_2780.f_25 = 0;
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_HITS", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_SHOTS", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_ACC", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 2;
    Global_1835390.f_2710[2] = 1;
    Global_1835390.f_2710[3] = 3;
    Global_1835390.f_2708 = 4;
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    Global_1835390.f_2780.f_28 = 4;
    Global_1835390.f_2780.f_29[0] = 4;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 4;
    break;

  case 38:
  case 39:
  case 40:
  case 41:
  case 42:
  case 43:
  case 44:
  case 45:
  case 46:
  case 47:
  case 48:
  case 49:
  case 50:
  case 51:
  case 52:
  case 53:
  case 54:
  case 55:
  case 206:
  case 207:
  case 208:
  case 209:
    uParam0->f_44 = 203;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGE", 32);
    MemCopy(&Global_1835390.f_2780.f_9, {func_192(iParam1)}, 16);
    Global_1835390.f_2780.f_25 = 0;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WEAP", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 7;
    Global_1835390.f_2708 = 2;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    Global_1835390.f_2780.f_28 = 4;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 8;
    break;

  case 69:
  case 71:
  case 70:
    uParam0->f_44 = 202;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TRI", 32);
    StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    Global_1835390.f_2780.f_25 = 0;
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_RANK", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 0;
    Global_1835390.f_2710[2] = 0;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 1;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    Global_1835390.f_2780.f_28 = 3;
    Global_1835390.f_2780.f_29[0] = 2;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 0;
    Global_1835390.f_2780.f_29[3] = 0;
    break;

  case 80:
    uParam0->f_44 = 817;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 3;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var0};
    StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "OffroadRace", 32);
    Global_1835390.f_2780.f_25 = 0;
    Global_1835390.f_2780 = 1;
    StringCopy(&Global_1835390.f_2780.f_1, "OFFR_TITLE", 32);
    StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
    Global_1835390.f_2710[0] = 3;
    Global_1835390.f_2708 = 1;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    Global_1835390.f_2780.f_28 = 3;
    Global_1835390.f_2780.f_29[0] = 1;
    break;

  case 3:
    uParam0->f_44 = 791;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HRD", 32);
      StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HRD_NN", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WAVE", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TKILLS", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TDEATH", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 1;
    Global_1835390.f_2710[2] = 2;
    Global_1835390.f_2710[3] = 3;
    Global_1835390.f_2708 = 4;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 0:
    if (iParam4 == 7 || iParam4 == 1) {
      uParam0->f_44 = 1200;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        if (iParam4 == 1) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEIST", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEISTP", 32);
        }
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else if (iParam4 == 1) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEIST_NN", 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEISTPNN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_ACC", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_HEADSHOT", 24);
      StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 1;
      Global_1835390.f_2710[2] = 4;
      Global_1835390.f_2710[3] = 5;
      Global_1835390.f_2710[4] = 6;
      Global_1835390.f_2708 = 3;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
      Global_1835390.f_2780.f_28 = 6;
      Global_1835390.f_2780.f_29[0] = 5;
      Global_1835390.f_2780.f_29[1] = 11;
      Global_1835390.f_2780.f_29[2] = 4;
      Global_1835390.f_2780.f_29[3] = 5;
      Global_1835390.f_2780.f_29[4] = 5;
    }
    else if (Global_1633501.f_50 == 1) {
      uParam0->f_44 = 777;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        if (Global_1633501.f_2 == 5) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS", 32);
        }
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else if (Global_1633501.f_2 == 5) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS_NN", 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_KILLS", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_DEATH", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 1;
      Global_1835390.f_2710[2] = 2;
      Global_1835390.f_2710[3] = 0;
      Global_1835390.f_2708 = 3;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 2;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
    }
    else {
      uParam0->f_44 = 780;
      uParam0->f_44.f_1 = 5;
      uParam0->f_44.f_3 = 1;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
      uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        if (Global_1633501.f_2 == 5) {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS", 32);
        }
        else {
          StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS", 32);
        }
        StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
      }
      else if (Global_1633501.f_2 == 5) {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS_NN", 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_KILLS", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_DEATH", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 1;
      Global_1835390.f_2710[2] = 2;
      Global_1835390.f_2710[3] = 0;
      Global_1835390.f_2708 = 3;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 5;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
    }
    break;

  case 8:
    uParam0->f_44 = 795;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ", 32);
      StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ_NN", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_JUMPS", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 1;
    gameplay::set_bit(&Global_1835390.f_2768, 1);
    Global_1835390.f_2754[1] = -1;
    Global_1835390.f_2710[2] = 2;
    Global_1835390.f_2710[3] = 0;
    Global_1835390.f_2708 = 3;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    Global_1835390.f_2780.f_28 = 5;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 11;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 85:
    uParam0->f_44 = 274;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    Global_1835390.f_2780.f_25 = 0;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ", 32);
      StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ_NN", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_CASH", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_TOTCASH", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 3;
    Global_1835390.f_2708 = 2;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    Global_1835390.f_2780.f_28 = 3;
    Global_1835390.f_2780.f_29[0] = 5;
    Global_1835390.f_2780.f_29[1] = 5;
    break;

  case 122:
    switch (iParam4) {
    case 0:
    case 9:
    case 4:
    case 8:
      switch (iParam4) {
      case 0: uParam0->f_44 = 965; break;

      case 9: uParam0->f_44 = 966; break;

      case 4: uParam0->f_44 = 967; break;

      case 8: uParam0->f_44 = 968; break;
      }
      uParam0->f_44.f_1 = 1;
      uParam0->f_44.f_3 = 0;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
      Global_1835390.f_2710[0] = 1;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 3;
      Global_1835390.f_2710[3] = 2;
      Global_1835390.f_2708 = 4;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      Global_1835390.f_2780.f_29[0] = 1;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
      break;

    case 1:
    case 2:
    case 3:
      switch (iParam4) {
      case 1: uParam0->f_44 = 969; break;

      case 2: uParam0->f_44 = 970; break;

      case 3: uParam0->f_44 = 973; break;
      }
      uParam0->f_44.f_1 = 1;
      uParam0->f_44.f_3 = 0;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_DIST", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
      Global_1835390.f_2710[0] = 1;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 3;
      Global_1835390.f_2710[3] = 2;
      Global_1835390.f_2708 = 4;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      Global_1835390.f_2780.f_29[0] = 4;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
      break;

    case 7:
      uParam0->f_44 = 971;
      uParam0->f_44.f_1 = 1;
      uParam0->f_44.f_3 = 0;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_AVG_HEI", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
      Global_1835390.f_2710[0] = 1;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 3;
      Global_1835390.f_2710[3] = 2;
      Global_1835390.f_2708 = 4;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      Global_1835390.f_2780.f_29[0] = 4;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
      break;

    case 6:
    case 5:
      switch (iParam4) {
      case 6: uParam0->f_44 = 972; break;

      case 5: uParam0->f_44 = 974; break;
      }
      uParam0->f_44.f_1 = 1;
      uParam0->f_44.f_3 = 0;
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
      Global_1835390.f_2780 = 1;
      if (!gameplay::is_string_null_or_empty(sParam3)) {
        StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
      }
      else {
        StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
      }
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
      Global_1835390.f_2710[0] = 0;
      Global_1835390.f_2710[1] = 3;
      Global_1835390.f_2710[2] = 2;
      Global_1835390.f_2710[3] = 1;
      Global_1835390.f_2708 = 4;
      gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
      Global_1835390.f_2780.f_29[0] = 12;
      Global_1835390.f_2780.f_29[1] = 5;
      Global_1835390.f_2780.f_29[2] = 5;
      Global_1835390.f_2780.f_29[3] = 5;
      break;
    }
    break;

  case 83:
    uParam0->f_44 = 192;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_DIST", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
    Global_1835390.f_2710[0] = 2;
    Global_1835390.f_2710[1] = 5;
    Global_1835390.f_2710[2] = 4;
    Global_1835390.f_2710[3] = 3;
    Global_1835390.f_2708 = 4;
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    Global_1835390.f_2780.f_29[0] = 17;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 82:
    uParam0->f_44 = 850;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    Global_1835390.f_2780.f_25 = 0;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 4;
    Global_1835390.f_2710[2] = 3;
    Global_1835390.f_2710[3] = 2;
    Global_1835390.f_2708 = 4;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    Global_1835390.f_2780.f_29[0] = 10;
    Global_1835390.f_2780.f_29[1] = 5;
    Global_1835390.f_2780.f_29[2] = 5;
    Global_1835390.f_2780.f_29[3] = 5;
    break;

  case 84:
    uParam0->f_44 = 820;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 1;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
    Global_1835390.f_2780 = 1;
    Global_1835390.f_2780.f_25 = 0;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
      StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
    StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
    StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_ACC", 24);
    StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL1", 24);
    StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MEDAL2", 24);
    StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MEDAL3", 24);
    Global_1835390.f_2710[0] = 0;
    Global_1835390.f_2710[1] = 1;
    Global_1835390.f_2710[2] = 2;
    Global_1835390.f_2710[3] = 5;
    Global_1835390.f_2710[4] = 4;
    Global_1835390.f_2710[5] = 3;
    Global_1835390.f_2708 = 6;
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
    gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
    Global_1835390.f_2780.f_29[0] = 4;
    Global_1835390.f_2780.f_29[1] = 9;
    Global_1835390.f_2780.f_29[2] = 4;
    Global_1835390.f_2780.f_29[3] = 5;
    Global_1835390.f_2780.f_29[4] = 5;
    Global_1835390.f_2780.f_29[5] = 5;
    break;

  case 86:
    uParam0->f_44 = 817;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 3;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
    uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var0};
    StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StuntPlaneRace", 32);
    Global_1835390.f_2780 = 1;
    Global_1835390.f_2780.f_25 = 0;
    if (!gameplay::is_string_null_or_empty(sParam3)) {
      StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
    }
    else {
      StringCopy(&Global_1835390.f_2780.f_1, "SPR_TITLE", 32);
    }
    StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
    Global_1835390.f_2710[0] = 2;
    Global_1835390.f_2708 = 1;
    gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
    Global_1835390.f_2780.f_28 = 3;
    Global_1835390.f_2780.f_29[0] = 1;
    break;

  case 91:
    uParam0->f_44 = 817;
    uParam0->f_44.f_1 = 5;
    uParam0->f_44.f_3 = 3;
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
    Global_1835390.f_2780 = 1;
    if (iParam5 <= 0) {
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
      Global_1835390.f_2710[0] = 3;
      Global_1835390.f_2710[1] = 4;
      Global_1835390.f_2710[2] = 1;
      Global_1835390.f_2710[3] = 0;
      Global_1835390.f_2709 = 6;
      Global_1835390.f_2708 = 2;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      Global_1835390.f_2780.f_28 = 4;
      Global_1835390.f_2780.f_29[0] = 1;
      Global_1835390.f_2780.f_29[1] = 3;
    }
    else {
      StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
      StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
      StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
      StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
      Global_1835390.f_2710[0] = 3;
      Global_1835390.f_2710[1] = 2;
      Global_1835390.f_2710[2] = 4;
      Global_1835390.f_2710[3] = 1;
      Global_1835390.f_2709 = 4;
      Global_1835390.f_2708 = 3;
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
      gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
      Global_1835390.f_2780.f_28 = 5;
      Global_1835390.f_2780.f_29[0] = 1;
      Global_1835390.f_2780.f_29[1] = 1;
      Global_1835390.f_2780.f_29[2] = 3;
    }
    Global_1835390.f_2779 = 0;
    switch (iParam4) {
    case 0:
      StringCopy(&Global_1835390.f_2780.f_1, "MGCR_1", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_1", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
      break;

    case 1:
      StringCopy(&Global_1835390.f_2780.f_1, "MGCR_2", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_2", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
      break;

    case 2:
      StringCopy(&Global_1835390.f_2780.f_1, "MGCR_4", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_4", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
      break;

    case 3:
      StringCopy(&Global_1835390.f_2780.f_1, "MGCR_5", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_5", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
      break;

    case 4:
      StringCopy(&Global_1835390.f_2780.f_1, "MGCR_6", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_6", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
      break;

    case 5:
      StringCopy(&Global_1835390.f_2780.f_1, "MGSR_1", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_1", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
      break;

    case 6:
      StringCopy(&Global_1835390.f_2780.f_1, "MGSR_2", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_2", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
      break;

    case 7:
      StringCopy(&Global_1835390.f_2780.f_1, "MGSR_3", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_3", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
      break;

    case 8:
      StringCopy(&Global_1835390.f_2780.f_1, "MGSR_4", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_4", 32);
      StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
      break;

    default: break;
    }
    break;
  }
  iVar16 = 0;
  iVar16 = 0;
  while (iVar16 < Global_1835390.f_2708) {
    if (gameplay::is_bit_set(Global_1835390.f_2769,
                             Global_1835390.f_2710[iVar16])) {
      gameplay::set_bit(&Global_1835390.f_2770, iVar16);
    }
    iVar16++;
  }
  Global_1835390.f_2826 =
      func_191(Var0, uParam0->f_44, iParam1, iParam4, iParam5, iParam6);
}

// Position - 0x13579
var func_191(struct<8> Param0, int iParam8, int iParam9, int iParam10,
             int iParam11, bool bParam12) {
  char cVar0[64];

  MemCopy(&cVar0, {Param0}, 16);
  StringIntConCat(&cVar0, iParam8, 64);
  StringConCat(&cVar0, "_", 64);
  if (func_156(iParam8)) {
    if (bParam12) {
      StringConCat(&cVar0, "CoDri", 64);
    }
    else {
      StringConCat(&cVar0, "Dri", 64);
    }
    StringConCat(&cVar0, "_", 64);
  }
  StringIntConCat(&cVar0, iParam9, 64);
  StringConCat(&cVar0, "_", 64);
  StringIntConCat(&cVar0, iParam10, 64);
  StringConCat(&cVar0, "_", 64);
  StringIntConCat(&cVar0, iParam11, 64);
  return gameplay::get_hash_key(&cVar0);
}

// Position - 0x135EB
struct<6> func_192(int iParam0) {
  struct<6> Var0;

  switch (iParam0) {
  case 38: StringCopy(&Var0, "HUD_MG_RANGE0", 24); break;

  case 39: StringCopy(&Var0, "HUD_MG_RANGE1", 24); break;

  case 40: StringCopy(&Var0, "HUD_MG_RANGE2", 24); break;

  case 41: StringCopy(&Var0, "HUD_MG_RANGE3", 24); break;

  case 42: StringCopy(&Var0, "HUD_MG_RANGE4", 24); break;

  case 43: StringCopy(&Var0, "HUD_MG_RANGE5", 24); break;

  case 44: StringCopy(&Var0, "HUD_MG_RANGE6", 24); break;

  case 45: StringCopy(&Var0, "HUD_MG_RANGE7", 24); break;

  case 46: StringCopy(&Var0, "HUD_MG_RANGE8", 24); break;

  case 47: StringCopy(&Var0, "HUD_MG_RANGE9", 24); break;

  case 48: StringCopy(&Var0, "HUD_MG_RANGE10", 24); break;

  case 49: StringCopy(&Var0, "HUD_MG_RANGE11", 24); break;

  case 50: StringCopy(&Var0, "HUD_MG_RANGE12", 24); break;

  case 51: StringCopy(&Var0, "HUD_MG_RANGE13", 24); break;

  case 52: StringCopy(&Var0, "HUD_MG_RANGE14", 24); break;

  case 53: StringCopy(&Var0, "HUD_MG_RANGE15", 24); break;

  case 54: StringCopy(&Var0, "HUD_MG_RANGE16", 24); break;

  case 55: StringCopy(&Var0, "HUD_MG_RANGE17", 24); break;

  case 206: StringCopy(&Var0, "HUD_MG_RANGE18", 24); break;

  case 207: StringCopy(&Var0, "HUD_MG_RANGE19", 24); break;

  case 208: StringCopy(&Var0, "HUD_MG_RANGE20", 24); break;

  case 209: StringCopy(&Var0, "HUD_MG_RANGE21", 24); break;
  }
  return Var0;
}

//Position - 0x13774
int func_193()
{
  if (Global_1633501.f_41912 == 1 || Global_1633501.f_41912 == 3 ||
      Global_1633501.f_41912 == 5 || Global_1633501.f_41912 == 7 ||
      Global_1633501.f_41912 == 8 || Global_1633501.f_41912 == 9 ||
      Global_1633501.f_41912 == 11 || Global_1633501.f_41912 == 13) {
    return 1;
  }
  return 0;
}

// Position - 0x13812
var func_194() { return network::network_is_signed_online(); }

// Position - 0x1381E
void func_195(var *uParam0, int iParam1, int iParam2, char *sParam3,
              int iParam4, char *sParam5, int iParam6, int iParam7, int iParam8,
              int iParam9) {
  if (*uParam0 == 0) {
    *uParam0 =
        graphics::request_scaleform_movie_instance("instructional_buttons");
  }
  uParam0->f_1 = 0;
  uParam0->f_3[0] = iParam2;
  uParam0->f_3[1] = iParam4;
  uParam0->f_3[2] = iParam6;
  uParam0->f_3[3] = iParam8;
  uParam0->f_3[4] = 353;
  uParam0->f_3[5] = 353;
  uParam0->f_3[6] = 353;
  uParam0->f_3[7] = 353;
  uParam0->f_12[0] =
      func_196(iParam2 != 353,
               controls::get_control_instructional_button(2, iParam2, 1), "");
  uParam0->f_12[1] =
      func_196(iParam4 != 353,
               controls::get_control_instructional_button(2, iParam4, 1), "");
  uParam0->f_12[2] =
      func_196(iParam6 != 353,
               controls::get_control_instructional_button(2, iParam6, 1), "");
  uParam0->f_12[3] =
      func_196(iParam8 != 353,
               controls::get_control_instructional_button(2, iParam8, 1), "");
  uParam0->f_12[4] = 0;
  uParam0->f_12[5] = 0;
  uParam0->f_12[6] = 0;
  uParam0->f_12[7] = 0;
  uParam0->f_21[0] = sParam3;
  uParam0->f_21[1] = sParam5;
  uParam0->f_21[2] = iParam7;
  uParam0->f_21[3] = iParam9;
  if (iParam1) {
    uParam0->f_2 = 1;
  }
  else {
    uParam0->f_2 = 0;
  }
  if (graphics::has_scaleform_movie_loaded(*uParam0)) {
    func_21(&uParam0->f_1, 1);
  }
}

// Position - 0x13962
var func_196(bool bParam0, var uParam1, char *sParam2) {
  if (bParam0) {
    return uParam1;
  }
  return sParam2;
}

// Position - 0x13979
void func_197() { func_198(player::player_ped_id(), "GENERIC_CURSE_MED", 24); }

// Position - 0x1398F
void func_198(int iParam0, char *sParam1, int iParam2) {
  audio::_play_ambient_speech1(iParam0, sParam1, func_199(iParam2), 1);
}

// Position - 0x139A6
int func_199(int iParam0) {
  int iVar0;

  switch (iParam0) {
  case 0: return "SPEECH_PARAMS_STANDARD";

  case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

  case 2: return "SPEECH_PARAMS_BEAT";

  case 3: return "SPEECH_PARAMS_FORCE";

  case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

  case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

  case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

  case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

  case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

  case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

  case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

  case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

  case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

  case 13: return "SPEECH_PARAMS_MEGAPHONE";

  case 14: return "SPEECH_PARAMS_HELI";

  case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

  case 16: return "SPEECH_PARAMS_FORCE_HELI";

  case 17: return "SPEECH_PARAMS_INTERRUPT";

  case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

  case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

  case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

  case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

  case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

  case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

  case 24: return "SPEECH_PARAMS_ADD_BLIP";

  case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

  case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

  case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

  case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

  case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

  case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

  case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

  case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

  case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

  case 34: return "SPEECH_PARAMS_SHOUTED";

  case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

  case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

  default:
  }
  iVar0 = 0;
  return iVar0;
}

// Position - 0x13B9B
int func_200() {
  if (func_43(0)) {
    return 0;
  }
  if (Global_91530.f_8) {
    if (Global_91530.f_10 > 0) {
      return 0;
    }
  }
  else if (Global_91530.f_10 > 1) {
    return 0;
  }
  Global_91530.f_10++;
  return 1;
}

// Position - 0x13BE6
void func_201(int iParam0, int iParam1) {
  Global_91530.f_7 = iParam0;
  Global_91530.f_8 = iParam1;
}

// Position - 0x13BFE
void func_202(var *uParam0, int iParam1, int iParam2) {
  if (iParam2) {
    gameplay::set_bit(&uParam0->f_602, iParam1);
  }
  else {
    gameplay::clear_bit(&uParam0->f_602, iParam1);
  }
}

// Position - 0x13C24
int func_203(int *iParam0, int iParam1, int *iParam2, int *iParam3,
             float fParam4) {
  int iVar0;

  if (iParam1 > 1 && *iParam0 == iParam1 - 1) {
    iVar0 = 100;
  }
  else {
    iVar0 = 0;
  }
  *iParam3 = 0;
  *iParam3 += system::ceil(fParam4 * 50f + fParam4 * IntToFloat(iVar0));
  *iParam3 += system::ceil(fParam4 * 1.5f * system::to_float(*iParam2));
  func_204(func_398(), 1, *iParam3, 0, 0);
  return 1;
}

// Position - 0x13C92
void func_204(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
  int iVar0;
  int iVar1;

  if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 3) {
    return;
  }
  if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 4) {
    return;
  }
  func_205(Global_101700.f_27009[iParam0 /*29*/].f_17, 1, iParam1, iParam2, 0);
  if (iParam3) {
    iVar0 = 0;
    if (iParam4) {
      switch (iParam0) {
      case 0: iVar1 = joaat("sp0_money_made_from_random_peds"); break;

      case 1: iVar1 = joaat("sp1_money_made_from_random_peds"); break;

      case 2: iVar1 = joaat("sp2_money_made_from_random_peds"); break;

      default: return;
      }
    }
    else {
      switch (iParam0) {
      case 0: iVar1 = joaat("sp0_money_made_from_missions"); break;

      case 1: iVar1 = joaat("sp1_money_made_from_missions"); break;

      case 2: iVar1 = joaat("sp2_money_made_from_missions"); break;

      default: return;
      }
    }
    stats::stat_get_int(iVar1, &iVar0, -1);
    iVar0 += iParam2;
    stats::stat_set_int(iVar1, iVar0, 1);
  }
}

// Position - 0x13D79
int func_205(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
  float fVar0;
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;

  func_230();
  if (iParam3 < 1) {
    return 0;
  }
  fVar0 = 1f;
  switch (iParam1) {
  case 0:
    switch (iParam0) {
    case 0:
      func_338(99, 1);
      func_229(joaat("sp0_money_total_spent"), iParam3);
      break;

    case 1: func_229(joaat("sp1_money_total_spent"), iParam3); break;

    case 2: func_229(joaat("sp2_money_total_spent"), iParam3); break;
    }
    func_213(0);
    switch (iParam2) {
    case 126:
    case 128:
    case 124:
    case 125:
    case 127:
      if (func_212(5)) {
        fVar0 = 0.9f;
        iVar1 = 5;
      }
      break;

    case 63:
    case 64:
    case 65:
    case 66:
    case 67:
    case 68:
      switch (iParam0) {
      case 0: func_229(joaat("sp0_money_spent_on_tattoos"), iParam3); break;

      case 1: func_229(joaat("sp1_money_spent_on_tattoos"), iParam3); break;

      case 2: func_229(joaat("sp2_money_spent_on_tattoos"), iParam3); break;
      }
      if (func_212(1)) {
        fVar0 = 0f;
        iVar1 = 1;
      }
      break;

    case 21:
      switch (iParam0) {
      case 0: func_229(joaat("sp0_money_spent_on_taxis"), iParam3); break;

      case 1: func_229(joaat("sp1_money_spent_on_taxis"), iParam3); break;

      case 2: func_229(joaat("sp2_money_spent_on_taxis"), iParam3); break;
      }
      break;

    case 25:
      switch (iParam0) {
      case 0: func_229(joaat("sp0_money_spent_in_strip_clubs"), iParam3); break;

      case 1: func_229(joaat("sp1_money_spent_in_strip_clubs"), iParam3); break;

      case 2: func_229(joaat("sp2_money_spent_in_strip_clubs"), iParam3); break;
      }
      break;

    case 98:
    case 99:
    case 100:
    case 101:
    case 103:
    case 104:
    case 105:
    case 106:
    case 107:
    case 108:
    case 109:
    case 110:
    case 111:
    case 112:
      switch (iParam0) {
      case 0: func_229(joaat("sp0_money_spent_property"), iParam3); break;

      case 1: func_229(joaat("sp1_money_spent_property"), iParam3); break;

      case 2: func_229(joaat("sp2_money_spent_property"), iParam3); break;
      }
      break;

    default:
      switch (script::get_hash_of_this_script_name()) {
      case joaat("clothes_shop_sp"):
        switch (iParam0) {
        case 0: func_229(joaat("sp0_money_spent_in_clothes"), iParam3); break;

        case 1: func_229(joaat("sp1_money_spent_in_clothes"), iParam3); break;

        case 2: func_229(joaat("sp2_money_spent_in_clothes"), iParam3); break;
        }
        break;

      case joaat("hairdo_shop_sp"):
        switch (iParam0) {
        case 0: func_229(joaat("sp0_money_spent_on_hairdos"), iParam3); break;

        case 1: func_229(joaat("sp1_money_spent_on_hairdos"), iParam3); break;

        case 2: func_229(joaat("sp2_money_spent_on_hairdos"), iParam3); break;
        }
        if (func_212(0)) {
          fVar0 = 0f;
          iVar1 = 0;
        }
        break;

      case joaat("gunclub_shop"):
        switch (iParam0) {
        case 0:
          func_229(joaat("sp0_money_spent_in_buying_guns"), iParam3);
          break;

        case 1:
          func_229(joaat("sp1_money_spent_in_buying_guns"), iParam3);
          break;

        case 2:
          func_229(joaat("sp2_money_spent_in_buying_guns"), iParam3);
          break;
        }
        break;

      case joaat("carmod_shop"):
        switch (iParam0) {
        case 0: func_229(joaat("sp0_money_spent_car_mods"), iParam3); break;

        case 1: func_229(joaat("sp1_money_spent_car_mods"), iParam3); break;

        case 2: func_229(joaat("sp2_money_spent_car_mods"), iParam3); break;
        }
        func_211(iParam3);
        break;
      }
      break;
    }
    break;

  case 1:
    switch (iParam0) {
    case 0: func_338(95, iParam3); break;

    case 1: func_338(97, iParam3); break;

    case 2: func_338(96, iParam3); break;
    }
    func_338(98, iParam3);
    break;
  }
  iVar2 = iParam0;
  iParam3 = system::floor(fVar0 * system::to_float(iParam3));
  iVar3 = 0;
  iVar4 = iParam3;
  if (fVar0 == 0f) {
    func_208(iVar1);
    return 1;
  }
  else if (fVar0 != 1f) {
    func_208(iVar1);
  }
  iVar5 = Global_52996[iVar2] + iParam3;
  switch (iParam1) {
  case 1:
    if (Global_52996[iVar2] >= 0 && iParam3 > 0) {
      if (iVar5 <= 0) {
        Global_52996[iVar2] = 2147483647;
      }
      else {
        Global_52996[iVar2] += iParam3;
      }
    }
    switch (iParam0) {
    case 0: func_229(joaat("sp0_total_cash_earned"), iParam3); break;

    case 1: func_229(joaat("sp1_total_cash_earned"), iParam3); break;

    case 2: func_229(joaat("sp2_total_cash_earned"), iParam3); break;
    }
    break;

  case 0:
    if (!iParam4) {
      if (Global_52996[iVar2] - iParam3 < 0) {
        return 0;
      }
    }
    iVar3 = Global_52996[iVar2];
    Global_52996[iVar2] -= iParam3;
    if (iParam4) {
      iVar4 = iVar3;
    }
    break;
  }
  if (iParam2 == 1) {
    if (iVar4 > 20) {
    }
  }
  else {
    Global_101700.f_19523.f_233[iVar2 /*69*/]
        .f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/] = iParam1;
    Global_101700.f_19523.f_233[iVar2 /*69*/]
        .f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/]
        .f_1 = iParam2;
    Global_101700.f_19523.f_233[iVar2 /*69*/]
        .f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/]
        .f_2 = iParam3;
    Global_101700.f_19523.f_233[iVar2 /*69*/]++;
    Global_101700.f_19523.f_233[iVar2 /*69*/].f_1++;
    if (Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 > 10) {
      Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 = 0;
    }
  }
  func_207(iParam0);
  if (Global_35781 == 15) {
    func_206(0);
  }
  return 1;
}

// Position - 0x1437F
void func_206(int iParam0) {
  int iVar0;
  int iVar1;

  iVar0 = 0;
  iVar1 = 0;
  iVar0 = 0;
  while (iVar0 < 3) {
    iVar1 = 0;
    while (iVar1 < 11) {
      Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
          Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
      Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
          Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
      Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
          Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
      iVar1++;
    }
    iVar0++;
  }
  iVar0 = 0;
  while (iVar0 < 10) {
    Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
    Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
    Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
    Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
    Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
    Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
    Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
    Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
    Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
    if (!iParam0) {
      Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
      Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
      Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
      Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
      Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
      Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
      Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
      Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
      Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
    }
    iVar0++;
  }
}

// Position - 0x14601
void func_207(int iParam0) {
  int iVar0;

  iVar0 = Global_52996[iParam0];
  switch (iParam0) {
  case 0: stats::stat_set_int(joaat("sp0_total_cash"), iVar0, 1); break;

  case 1: stats::stat_set_int(joaat("sp1_total_cash"), iVar0, 1); break;

  case 2: stats::stat_set_int(joaat("sp2_total_cash"), iVar0, 1); break;
  }
}

// Position - 0x1465B
void func_208(int iParam0) {
  bool bVar0;
  char cVar1[64];

  bVar0 = false;
  if (!network::network_is_game_in_progress()) {
    if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0)) {
      bVar0 = true;
      gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
    }
  }
  else if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0) ||
           gameplay::is_bit_set(
               Global_2097152[func_210() /*10758*/].f_7546.f_10, iParam0)) {
    bVar0 = true;
    gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
    gameplay::clear_bit(&Global_2097152[func_210() /*10758*/].f_7546.f_10,
                        iParam0);
  }
  if (bVar0) {
    StringCopy(&cVar1, "CHAR_LIFEINVADER", 64);
    ui::_set_notification_text_entry("COUP_RED");
    ui::add_text_component_substring_text_label(func_209(iParam0));
    ui::_set_notification_message(&cVar1, &cVar1, 1, 0, "", 0);
  }
}

// Position - 0x1471D
char *func_209(int iParam0) {
  switch (iParam0) {
  case 0: return "COUP_HAIRC";

  case 1: return "COUP_TATTOO";

  case 2: return "COUP_WARSTOCK";

  case 3: return "COUP_MOSPORT";

  case 4: return "COUP_ELITAS";

  case 5: return "COUP_MEDSPENS";

  case 6: return "COUP_SPRUNK";

  case 7: return "COUP_RESPRAY";

  default:
  }
  return "";
}

// Position - 0x14797
int func_210() {
  int iVar0;

  iVar0 = 0;
  return iVar0;
}

// Position - 0x147A4
void func_211(int iParam0) {
  func_338(93, iParam0);
  func_338(29, iParam0);
  func_338(30, iParam0);
}

// Position - 0x147C4
bool func_212(int iParam0) {
  if (!network::network_is_game_in_progress()) {
    return gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0);
  }
  return gameplay::is_bit_set(Global_2097152[func_210() /*10758*/].f_7546.f_10,
                              iParam0);
}

// Position - 0x14800
int func_213(int iParam0) {
  int iVar0;
  int iVar1;
  int iVar2;

  iVar1 = 0;
  if (player::has_achievement_been_passed(27)) {
    return 0;
  }
  if (stats::stat_get_int(joaat("sp0_money_total_spent"), &iVar0, -1)) {
    iVar1 += iVar0;
  }
  if (stats::stat_get_int(joaat("sp1_money_total_spent"), &iVar0, -1)) {
    iVar1 += iVar0;
  }
  if (stats::stat_get_int(joaat("sp2_money_total_spent"), &iVar0, -1)) {
    iVar1 += iVar0;
  }
  if (iParam0) {
  }
  iVar2 = 0;
  stats::stat_get_int(joaat("num_cash_spent"), &iVar2, -1);
  if (iVar1 > 0 && iVar2 / 2000000 != iVar1 / 2000000) {
    stats::stat_set_int(joaat("num_cash_spent"), iVar1, 1);
    func_228(27, iVar1);
  }
  if (iVar1 < 200000000) {
    return 0;
  }
  func_214(27, 1);
  return 1;
}

// Position - 0x148B7
int func_214(int iParam0, int iParam1) {
  if (iParam0 >= 70) {
    return 0;
  }
  return func_215(iParam0, iParam1);
}

// Position - 0x148D2
int func_215(int iParam0, int iParam1) {
  if (func_227(14) && !func_226(iParam0)) {
    return 0;
  }
  if (player::has_achievement_been_passed(iParam0) && iParam1 == 1) {
    return 0;
  }
  if (Global_25436 != 0 && !Global_69702) {
    return 0;
  }
  if (func_225(&Global_2595550)) {
    if (func_223(&Global_2595550, iParam0)) {
      return 0;
    }
    if (func_216(&Global_2595550, iParam0)) {
      return 1;
    }
  }
  else {
    if (!player::give_achievement_to_player(iParam0)) {
      return 0;
    }
    if (player::has_achievement_been_passed(iParam0)) {
      return 1;
    }
    return 0;
  }
  return 0;
}

// Position - 0x1496F
bool func_216(var *uParam0, int iParam1) {
  int iVar0;
  var *uVar1[70];

  if (player::has_achievement_been_passed(iParam1)) {
    return false;
  }
  if (func_227(14) && !func_226(iParam1)) {
    return false;
  }
  if (func_223(uParam0, iParam1)) {
    return false;
  }
  if (func_222(uParam0) < 0f) {
    func_221(uParam0, 0);
  }
  func_219(&uVar1);
  iVar0 = 0;
  iVar0 = 0;
  while (iVar0 < *uParam0 - 1) {
    uVar1[iVar0 + 1] = (*uParam0)[iVar0];
    iVar0++;
  }
  func_217(&uVar1, iParam1);
  iVar0 = 0;
  iVar0 = 0;
  while (iVar0 < *uParam0) {
    (*uParam0)[iVar0] = uVar1[iVar0];
    iVar0++;
  }
  return true;
}

// Position - 0x14A20
int func_217(var *uParam0, int iParam1) {
  int iVar0;

  if (player::has_achievement_been_passed(iParam1)) {
    return 0;
  }
  if (func_227(14) && !func_226(iParam1)) {
    return 0;
  }
  if (func_223(uParam0, iParam1)) {
    return 0;
  }
  if (func_222(uParam0) < 0f) {
    func_221(uParam0, 0);
  }
  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if (func_218(uParam0, iVar0)) {
      (*uParam0)[iVar0] = iParam1;
      return 1;
    }
    iVar0++;
  }
  return 0;
}

// Position - 0x14A9B
bool func_218(var *uParam0, int iParam1) { return (*uParam0)[iParam1] == 70; }

// Position - 0x14AAC
void func_219(var *uParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    func_220(uParam0, iVar0);
    iVar0++;
  }
  func_221(uParam0, Global_2595549 - 0.5f);
}

// Position - 0x14AE0
void func_220(var *uParam0, int iParam1) { (*uParam0)[iParam1] = 70; }

// Position - 0x14AF0
void func_221(var *uParam0, float fParam1) {
  if (fParam1 == 0f) {
    uParam0->f_72 = 0f;
  }
  else {
    uParam0->f_72 = fParam1;
  }
}

// Position - 0x14B0D
float func_222(var *uParam0) { return uParam0->f_72; }

// Position - 0x14B19
bool func_223(var *uParam0, int iParam1) {
  return func_224(uParam0, iParam1) != -1;
}

// Position - 0x14B2B
int func_224(var *uParam0, int iParam1) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if ((*uParam0)[iVar0] == iParam1) {
      return iVar0;
    }
    iVar0++;
  }
  return -1;
}

// Position - 0x14B58
bool func_225(var *uParam0) { return uParam0->f_71 == 1; }

// Position - 0x14B66
int func_226(int iParam0) {
  switch (iParam0) {
  case 60:
  case 61:
  case 62:
  case 63:
  case 64:
  case 65:
  case 66:
  case 67:
  case 68:
  case 69: return 1;

  default:
  }
  return 0;
}

// Position - 0x14BB6
bool func_227(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x14BC4
int func_228(int iParam0, int iParam1) {
  int iVar0;

  if (iParam0 < 0) {
    return 0;
  }
  if (iParam0 > 70) {
    return 0;
  }
  if (iParam1 <= 0 || iParam1 > 100) {
    return 0;
  }
  iVar0 = player::_0x1C186837D0619335(iParam0);
  if (iParam1 > iVar0) {
    return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
  }
  return 0;
}

// Position - 0x14C15
void func_229(int iParam0, int iParam1) {
  int iVar0;

  stats::stat_get_int(iParam0, &iVar0, -1);
  iVar0 += iParam1;
  stats::stat_set_int(iParam0, iVar0, 1);
}

// Position - 0x14C38
void func_230() {
  int iVar0;

  if (network::network_is_signed_in()) {
    stats::stat_get_int(joaat("sp0_total_cash"), &iVar0, -1);
    if (Global_52996[0] != iVar0) {
      Global_52996[0] = iVar0;
    }
    stats::stat_get_int(joaat("sp1_total_cash"), &iVar0, -1);
    if (Global_52996[1] != iVar0) {
      Global_52996[1] = iVar0;
    }
    stats::stat_get_int(joaat("sp2_total_cash"), &iVar0, -1);
    if (Global_52996[2] != iVar0) {
      Global_52996[2] = iVar0;
    }
  }
}

// Position - 0x14CAD
void func_231(int iParam0, int iParam1, int iParam2) {
  bool bVar0;

  if (iParam0 < 0) {
  }
  if (iParam0 == 321 || iParam0 > 321) {
  }
  else {
    func_234(891 + iParam0, 1, -1, 1);
  }
  bVar0 = true;
  if (Global_101700.f_9153[iParam0 /*12*/].f_5 == 1) {
    if (Global_101700.f_9153[iParam0 /*12*/].f_6 == 11 ||
        Global_101700.f_9153[iParam0 /*12*/].f_6 == 12) {
      bVar0 = false;
    }
  }
  else {
    Global_101700.f_9153[iParam0 /*12*/].f_5 = 1;
    Global_101700.f_9153[iParam0 /*12*/].f_10 = iParam1;
    Global_101700.f_9153[iParam0 /*12*/].f_11 = iParam2;
    if (iParam0 == 287) {
      stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_0"), 50, 0);
    }
    if (iParam0 == 286) {
      stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_1"), 50, 0);
    }
    if (iParam0 == 299) {
      stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_3"), 50, 0);
    }
  }
  if (bVar0) {
    func_232();
  }
}

// Position - 0x14D95
void func_232() {
  int iVar0;
  float fVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  int iVar9;

  iVar0 = 0;
  Global_101436 = 0;
  Global_101437 = 0;
  Global_101438 = 0;
  Global_101439 = 0;
  Global_101440 = 0;
  Global_101441 = 0;
  Global_101442 = 0;
  fVar1 = 0f;
  fVar2 = 0f;
  fVar3 = 0f;
  fVar4 = 0f;
  fVar5 = 0f;
  fVar6 = 0f;
  fVar7 = 0f;
  fVar8 = Global_101700.f_9153.f_3853;
  Global_101700.f_9153.f_3853 = 0f;
  while (iVar0 < 321) {
    if (Global_101700.f_9153[iVar0 /*12*/].f_5 == 1) {
      switch (Global_101700.f_9153[iVar0 /*12*/].f_6) {
      case 1:
        Global_101436++;
        fVar1 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      case 3:
        Global_101437++;
        fVar2 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      case 5:
        Global_101438++;
        fVar3 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      case 7:
        Global_101439++;
        fVar4 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      case 9:
        Global_101440++;
        fVar5 += Global_101700.f_9153[iVar0 /*12*/].f_4 * 4f;
        break;

      case 11:
        Global_101441++;
        fVar6 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      case 13:
        Global_101442++;
        fVar7 += Global_101700.f_9153[iVar0 /*12*/].f_4;
        break;

      default: break;
      }
    }
    iVar0++;
  }
  if (Global_101419 > 0) {
    if (Global_101436 == Global_101419) {
      fVar1 = 55f;
    }
  }
  if (Global_101420 > 0) {
    if (Global_101437 == Global_101420) {
      fVar2 = 10f;
    }
  }
  if (Global_101421 > 0) {
    if (Global_101438 == Global_101421) {
      fVar3 = 0f;
    }
  }
  if (Global_101422 > 0) {
    if (Global_101439 == Global_101422) {
      fVar4 = 10f;
    }
  }
  if (Global_101423 > 0) {
    if (Global_101440 == Global_101423 ||
        Global_101423 * 10 / Global_101440 < 41 ||
        Global_101440 > Global_101426 || Global_101440 == Global_101426) {
      if (!gameplay::is_bit_set(Global_101700.f_9153.f_3856, 14)) {
        if (Global_101440 == Global_101423) {
          stats::_0x11FF1C80276097ED(joaat("num_rndevents_completed"),
                                     Global_101423, 0);
          gameplay::set_bit(&Global_101700.f_9153.f_3856, 14);
        }
      }
      fVar5 = 5f;
    }
  }
  if (Global_101424 > 0) {
    if (Global_101441 == Global_101424) {
      fVar6 = 15f;
    }
  }
  if (Global_101425 > 0) {
    if (Global_101442 == Global_101425) {
      fVar7 = 5f;
    }
  }
  Global_101700.f_9153.f_3853 =
      fVar1 + fVar2 + fVar3 + fVar4 + fVar5 + fVar6 + fVar7;
  if (Global_101440 > Global_101426 || Global_101440 == Global_101426) {
    iVar9 = Global_101426;
  }
  else {
    iVar9 = Global_101440;
  }
  stats::stat_set_int(joaat("num_missions_completed"), Global_101436, 1);
  stats::stat_set_int(joaat("num_missions_available"), Global_101419, 1);
  stats::stat_set_int(joaat("num_minigames_completed"), Global_101437, 1);
  stats::stat_set_int(joaat("num_minigames_available"), Global_101420, 1);
  stats::stat_set_int(joaat("num_oddjobs_completed"), Global_101438, 1);
  stats::stat_set_int(joaat("num_oddjobs_available"), Global_101421, 1);
  stats::stat_set_int(joaat("num_rndpeople_completed"), Global_101439, 1);
  stats::stat_set_int(joaat("num_rndpeople_available"), Global_101422, 1);
  stats::stat_set_int(joaat("num_rndevents_completed"), iVar9, 1);
  stats::stat_set_int(joaat("num_rndevents_available"), Global_101426, 1);
  stats::stat_set_int(joaat("num_misc_completed"),
                      Global_101442 + Global_101441, 1);
  stats::stat_set_int(joaat("num_misc_available"),
                      Global_101425 + Global_101424, 1);
  Global_101443 = Global_101436 * 100 / Global_101419;
  Global_101445 =
      Global_101438 + Global_101437 * 100 / (Global_101421 + Global_101420);
  Global_101444 = Global_101439 + iVar9 * 100 / (Global_101422 + Global_101426);
  Global_101446 =
      Global_101441 + Global_101442 * 100 / (Global_101424 + Global_101425);
  stats::stat_set_float(joaat("total_progress_made"),
                        Global_101700.f_9153.f_3853, 1);
  stats::stat_set_int(joaat("percent_story_missions"), Global_101443, 1);
  stats::stat_set_int(joaat("percent_ambient_missions"), Global_101444, 1);
  stats::stat_set_int(joaat("percent_oddjobs"), Global_101445, 1);
  if (fVar8 > 0f &&
      system::floor(fVar8) < system::floor(Global_101700.f_9153.f_3853)) {
    func_228(13, system::floor(Global_101700.f_9153.f_3853));
  }
  if (!datafile::datafile_is_save_pending()) {
    if (!Global_69702) {
      if (func_233() == 2 == 0 && !network::network_is_game_in_progress()) {
        if (network::network_is_cloud_available()) {
          Global_101434 = 0;
        }
        if (!Global_55822) {
          func_200();
        }
      }
    }
  }
}

// Position - 0x15256
int func_233() { return Global_25190; }

// Position - 0x15261
int func_234(int iParam0, int iParam1, int iParam2, int iParam3) {
  int iVar0;
  int iVar1;
  var uVar2;
  var uVar3;
  var uVar4;
  var uVar5;
  var uVar6;
  var uVar7;
  var uVar8;
  var uVar9;
  var uVar10;
  var uVar11;
  var uVar12;
  var uVar13;

  if (iParam2 == -1) {
    iParam2 = func_235();
  }
  iVar0 = 0;
  if (iParam0 >= 0 && iParam0 < 192) {
    uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
    iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 192 && iParam0 < 384) {
    uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
    iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 513 && iParam0 < 705) {
    uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
    iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 705 && iParam0 < 1281) {
    uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
    iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 3111 && iParam0 < 3879) {
    uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
    iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 2919 && iParam0 < 3111) {
    uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
    iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 4207 && iParam0 < 4335) {
    uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2,
                                         "_NGPSTAT_BOOL");
    iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 4335 && iParam0 < 4399) {
    uVar9 =
        stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
    iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 6029 && iParam0 < 6413) {
    uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2,
                                          "_NGTATPSTAT_BOOL");
    iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 7385 && iParam0 < 7641) {
    uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2,
                                          "_NGDLCPSTAT_BOOL");
    iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 7321 && iParam0 < 7385) {
    uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0,
                                          "_NGDLCPSTAT_BOOL");
    iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
  }
  else if (iParam0 >= 9361 && iParam0 < 9553) {
    uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2,
                                          "_DLCBIKEPSTAT_BOOL");
    iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
    iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
  }
  return iVar0;
}

// Position - 0x155F5
var func_235() { return Global_1312735; }

// Position - 0x15601
void func_236(int iParam0, int iParam1) {
  if (iParam0 == 146 || iParam0 == -1) {
    return;
  }
  if (Global_101700.f_8044.f_99.f_58[iParam0] == iParam1) {
    return;
  }
  Global_101700.f_8044.f_99.f_58[iParam0] = iParam1;
}

// Position - 0x15646
int func_237(int iParam0) {
  if (iParam0 == 146 || iParam0 == -1) {
    return 0;
  }
  return Global_101700.f_8044.f_99.f_58[iParam0];
}

// Position - 0x15673
void func_238(int iParam0, int iParam1) {
  int iVar0;

  iVar0 = iParam0;
  if (iVar0 < 0 || iVar0 >= 263 || iParam0 == 263) {
    return;
  }
  if (iParam1 == gameplay::is_bit_set(Global_25501[iVar0 /*23*/].f_11, 20)) {
    return;
  }
  if (iParam1) {
    gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 20);
  }
  else {
    gameplay::clear_bit(&Global_25501[iVar0 /*23*/].f_11, 20);
  }
  if (Global_25498 == 1) {
    Global_25499 = 1;
  }
  Global_25498 = 1;
  gameplay::set_bit(&Global_25501[iVar0 /*23*/].f_11, 20);
}

// Position - 0x156FC
bool func_239(var *uParam0, int iParam1) {
  return gameplay::is_bit_set(uParam0->f_602, iParam1);
}

// Position - 0x1570F
var func_240() { return unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE"); }

// Position - 0x1571F
void func_241(vector3 vParam0, int iParam3, int iParam4, int *iParam5,
              int *iParam6, float *fParam7) {
  int iVar0;
  int iVar1;
  bool bVar2;
  var uVar3;
  var uVar4;
  var uVar5;
  var uVar6;
  bool bVar7;
  int iVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  bool bVar12;
  vector3 vVar13;
  vector3 vVar16;
  float fVar19;
  int iVar20;
  vector3 vVar21;
  vector3 vVar24;

  iVar0 = player::player_ped_id();
  iVar1 = 0;
  bVar2 = ped::is_ped_injured(iVar0);
  if (bVar2) {
    *iParam5 = 2;
    return;
  }
  uVar3 = ped::get_ped_parachute_state(iVar0);
  uVar4 = ped::get_ped_parachute_landing_type(iVar0);
  uVar5 = entity::is_entity_in_air(iVar0);
  uVar6 = ped::is_ped_ragdoll(iVar0);
  bVar7 = entity::does_entity_exist(iParam3);
  iVar8 = bVar7 && ped::is_ped_on_specific_vehicle(iVar0, iParam3);
  bVar9 = bVar7 && !ped::is_ped_injured(iParam4) &&
          entity::is_entity_touching_entity(iVar0, iParam4);
  bVar10 = bVar7 && vehicle::get_vehicle_trailer_vehicle(iParam3, &iVar1);
  bVar11 = bVar10 && !entity::is_entity_dead(iVar1, 0) &&
           ped::is_ped_on_specific_vehicle(iVar0, iVar1);
  bVar12 = !bVar7 && !func_401(vParam0);
  if (bVar12) {
    vVar13 = {entity::get_entity_coords(iVar0, 1)};
    vVar16 = {vVar13 - vParam0};
    fVar19 = system::sqrt(vVar16.x * vVar16.x + vVar16.y * vVar16.y);
    *fParam7 = fVar19;
    if (vVar16.z < 5f && vVar16.z > -2f && fVar19 < 15f) {
      *iParam6 =
          func_244(system::ceil(100f * (15f - fVar19) / 15f) + 4, 0, 100);
      *iParam5 = 1;
    }
    else {
      *iParam5 = 3;
    }
  }
  if (bVar7) {
    if (func_242(iParam3, iParam4)) {
      *fParam7 = 0f;
      *iParam6 = 100;
      *iParam5 = 1;
    }
    else {
      *iParam6 = 0;
      *iParam5 = 3;
    }
  }
  if (bVar10) {
    vehicle::get_vehicle_trailer_vehicle(iParam3, &iVar20);
    vVar21 = {entity::get_entity_coords(iVar0, 1)};
    vVar24 = {entity::get_entity_coords(iVar20, 1)};
  }
}

// Position - 0x158B6
bool func_242(int iParam0, int iParam1) {
  int iVar0;
  int iVar1;
  vector3 vVar2;
  vector3 vVar5;
  int iVar8;
  vector3 vVar9;

  if (!ped::is_ped_injured(player::player_ped_id()) &&
      entity::does_entity_exist(iParam0) &&
      vehicle::is_vehicle_driveable(iParam0, 0)) {
    vVar5 = {entity::get_entity_coords(player::player_ped_id(), 1)};
    if (func_342(entity::get_entity_model(iParam0))) {
      iVar8 = 0;
      iVar8 = 0;
      while (iVar8 < 6) {
        iVar1 = vehicle::get_train_carriage(iParam0, iVar8);
        if (entity::does_entity_exist(iVar1)) {
          vVar2 = {entity::get_entity_coords(iParam0, 1)};
          if (ped::is_ped_on_specific_vehicle(player::player_ped_id(), iVar1)) {
            return true;
          }
        }
        iVar8++;
      }
    }
    if (entity::does_entity_exist(iParam0)) {
      vehicle::get_vehicle_trailer_vehicle(iParam0, &iVar0);
      if (ped::is_ped_on_specific_vehicle(player::player_ped_id(), iParam0) ||
          entity::is_entity_touching_entity(player::player_ped_id(), iParam0) ||
          entity::does_entity_exist(iParam1) &&
              !entity::is_entity_dead(iParam1, 0) &&
              entity::is_entity_touching_entity(player::player_ped_id(),
                                                iParam1)) {
        if (vVar2.z < vVar5.z) {
          return true;
        }
      }
    }
    if (entity::does_entity_exist(iVar0)) {
      if (!entity::is_entity_dead(iVar0, 0)) {
        if (ped::is_ped_on_specific_vehicle(player::player_ped_id(), iVar0)) {
          return true;
        }
        else if (entity::is_entity_touching_entity(player::player_ped_id(),
                                                   iVar0)) {
          vVar9 = {entity::get_offset_from_entity_given_world_coords(
              iVar0, entity::get_entity_coords(player::player_ped_id(), 1))};
          vVar9.x = func_243(gameplay::absf(vVar9.x) - 1.305f, 0f);
          if (vVar9.y >= 0f) {
            vVar9.y = func_243(vVar9.y - 5.98f, 0f);
          }
          else {
            vVar9.y = func_243(-vVar9.y - 6.21f, 0f);
          }
          if (vVar9.y == 0f && vVar9.x == 0f) {
            return true;
          }
        }
      }
    }
  }
  return false;
}

// Position - 0x15A69
float func_243(float fParam0, float fParam1) {
  if (fParam0 > fParam1) {
    return fParam0;
  }
  return fParam1;
}

// Position - 0x15A80
int func_244(int iParam0, int iParam1, int iParam2) {
  if (iParam0 > iParam2) {
    return iParam2;
  }
  else if (iParam0 < iParam1) {
    return iParam1;
  }
  return iParam0;
}

// Position - 0x15AA5
void func_245(vector3 vParam0, int *iParam3, var uParam4, var uParam5) {
  float fVar0;
  int iVar1;

  if (!func_432(&iParam3)) {
    return;
  }
  fVar0 = func_431(&iParam3);
  if (fVar0 > 1.4f) {
    return;
  }
  iVar1 = 170 - system::ceil(170f * fVar0 / 1.4f);
  graphics::draw_marker(6, vParam0, 0f, 0f, 1f, 0f, 0f, 0f, 4f, 4f, 4f, 240,
                        200, 80, iVar1, 0, 0, 2, 0, 0, 0, 0);
  graphics::draw_marker(6, vParam0, 0f, 0f, 1f, 0f, 0f, 0f, 9f, 9f, 9f, 240,
                        200, 80, iVar1, 0, 0, 2, 0, 0, 0, 0);
  graphics::draw_marker(6, vParam0, 0f, 0f, 1f, 0f, 0f, 0f, 14f, 14f, 14f, 240,
                        200, 80, iVar1, 0, 0, 2, 0, 0, 0, 0);
}

// Position - 0x15B5C
void func_246(var *uParam0, var *uParam1, int iParam2, int iParam3) {
  int iVar0;

  iVar0 = func_343(uParam1);
  if (func_435(func_436(iParam2))) {
    if (!func_239(uParam0, 0)) {
      if (iParam3 > 1) {
        func_315("BJ_MG_MTOBJ", 7500, 1);
      }
      else if (iVar0 != 0) {
        if (func_342(iVar0)) {
          func_315("BJ_MG_TRAIN", 7500, 1);
        }
        else {
          func_315("BJ_MG_BOAT", 7500, 1);
        }
      }
      else {
        func_315("BJ_MG_STOBJ", 7500, 1);
      }
      func_202(uParam0, 0, 1);
    }
  }
  if (func_312("BJ_FALLHLP") && Global_17151.f_135) {
    ui::clear_help(1);
    func_202(uParam0, 1, 0);
  }
  if (!func_239(uParam0, 1) && !Global_17151.f_135) {
    ui::add_next_message_to_previous_briefs(0);
    ui::clear_help(1);
    func_313("BJ_FALLHLP", -1);
    func_202(uParam0, 1, 1);
  }
  else if (!func_239(uParam0, 2)) {
    if (ped::get_ped_parachute_state(player::player_ped_id()) == 1 ||
        ped::get_ped_parachute_state(player::player_ped_id()) == 2) {
      ui::clear_help(1);
      if (controls::_is_input_disabled(0)) {
        func_313("BJ_PARAHLP_KM", 10000);
      }
      else {
        func_313("BJ_PARAHLP", 10000);
      }
      func_202(uParam0, 2, 1);
    }
  }
  else if (!func_239(uParam0, 3)) {
    if (ped::get_ped_parachute_state(player::player_ped_id()) == -1 ||
        ped::get_ped_parachute_state(player::player_ped_id()) == 3) {
      ui::clear_help(1);
      func_202(uParam0, 3, 1);
    }
  }
}

// Position - 0x15CBE
void func_247(int iParam0) {
  vector3 vVar0;
  vector3 vVar3;
  vector3 vVar6;
  vector3 vVar9;
  vector3 vVar12;
  var uVar15;
  vector3 vVar18;
  float fVar21;
  float fVar22;
  float fVar23;
  float fVar24;

  if (!ped::is_ped_injured(player::player_ped_id())) {
    if (entity::does_entity_exist(
            entity::get_entity_attached_to(player::player_ped_id()))) {
      vVar0 = {entity::get_entity_speed_vector(
          entity::get_entity_attached_to(player::player_ped_id()), 0)};
    }
    else {
      vVar0 = {entity::get_entity_speed_vector(player::player_ped_id(), 1)};
    }
    fVar21 = vVar0.y;
    vVar3 = {entity::get_entity_coords(player::player_ped_id(), 1)};
    vVar3.z = 0f;
  }
  if (entity::does_entity_exist(*iParam0) &&
      vehicle::is_vehicle_driveable(*iParam0, 0)) {
    vVar6 = {entity::get_entity_coords(*iParam0, 1)};
    vVar6.z = 0f;
    vVar18 = {entity::get_entity_velocity(*iParam0)};
  }
  if (vehicle::is_vehicle_driveable(*iParam0, 0)) {
    entity::get_entity_matrix(*iParam0, &vVar9, &uVar15, &uVar15, &uVar15);
    vVar9.z = 0f;
  }
  vVar12 = {vVar3 - vVar6};
  vVar12.z = 0f;
  fVar23 = gameplay::absf(func_251(vVar12, vVar9));
  if (func_250(*iParam0)) {
    fVar22 = func_46(fVar21 - fVar23 / fVar21, 2f, 3f);
  }
  else {
    fVar22 = func_46(fVar21 + fVar23 / fVar21, 3f, 10f);
  }
  fVar24 = func_46(func_248(vVar18.y, fVar22, 0.5f), vVar18.y, fVar21);
  vVar18.y = func_248(vVar18.y, fVar22, 0.5f);
  if (entity::does_entity_exist(*iParam0) &&
      vehicle::is_vehicle_driveable(*iParam0, 0) && vVar18.y > 2f &&
      vVar18.y < vehicle::_0x53AF99BAA671CA47(*iParam0)) {
    ai::set_drive_task_max_cruise_speed(
        vehicle::get_ped_in_vehicle_seat(*iParam0, -1, 0), fVar24);
  }
}

// Position - 0x15E31
float func_248(float fParam0, float fParam1, float fParam2) {
  float fVar0;

  fVar0 = (1f - system::cos(func_249(fParam2 * 3.141593f))) * 0.5f;
  return fParam0 * (1f - fVar0) + fParam1 * fVar0;
}

// Position - 0x15E60
float func_249(float fParam0) { return fParam0 * 57.29578f; }

// Position - 0x15E70
bool func_250(int iParam0) {
  vector3 vVar0;
  vector3 vVar3;
  var uVar6;
  vector3 vVar9;
  vector3 vVar12;
  float fVar15;

  if (!ped::is_ped_injured(player::player_ped_id())) {
    vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
  }
  if (vehicle::is_vehicle_driveable(iParam0, 0)) {
    entity::get_entity_matrix(iParam0, &vVar12, &uVar6, &uVar6, &vVar3);
  }
  vVar9 = {vVar0 - vVar3};
  vVar9.z = 0f;
  vVar12.z = 0f;
  fVar15 = func_251(vVar9, vVar12);
  if (fVar15 < 0f) {
    return true;
  }
  return false;
}

// Position - 0x15EDA
float func_251(vector3 vParam0, vector3 vParam3) {
  return vParam0.x * vParam3.x + vParam0.y * vParam3.y + vParam0.z * vParam3.z;
}

// Position - 0x15EFB
float func_252(int iParam0, int iParam1, int iParam2) {
  vector3 vVar0;
  vector3 vVar3;

  if (!entity::is_entity_dead(iParam0, 0)) {
    vVar0 = {entity::get_entity_coords(iParam0, 1)};
  }
  else {
    vVar0 = {entity::get_entity_coords(iParam0, 0)};
  }
  if (!entity::is_entity_dead(iParam1, 0)) {
    vVar3 = {entity::get_entity_coords(iParam1, 1)};
  }
  else {
    vVar3 = {entity::get_entity_coords(iParam1, 0)};
  }
  return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x15F59
Vector3 func_253(int iParam0, vector3 vParam1) {
  var uVar0;

  vParam1.z += 0.15f;
  if (gameplay::get_ground_z_for_3d_coord(vParam1, &uVar0, 0)) {
    vParam1.z = uVar0;
  }
  if (func_254(iParam0)) {
    entity::set_entity_coords(iParam0, vParam1, 1, 0, 0, 1);
  }
  return vParam1;
}

// Position - 0x15F9E
bool func_254(int iParam0) {
  if (!entity::does_entity_exist(iParam0)) {
    return false;
  }
  return !entity::is_entity_dead(iParam0, 0);
}

// Position - 0x15FBC
void func_255(int *iParam0, var *uParam1) {
  var *uVar0[6];
  int iVar7;
  vector3 vVar8;
  float fVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;

  if (!func_432(iParam0)) {
    func_456(iParam0);
  }
  if (func_431(iParam0) < 1f) {
    return;
  }
  if (entity::is_entity_dead(player::player_ped_id(), 0)) {
    return;
  }
  iVar12 = ped::get_ped_nearby_peds(player::player_ped_id(), &uVar0, -1);
  iVar13 = 0;
  while (iVar13 < 6) {
    if (entity::does_entity_exist((*uParam1)[iVar13]) &&
        !entity::is_entity_dead((*uParam1)[iVar13], 0) &&
        !ped::is_ped_injured((*uParam1)[iVar13])) {
      if (func_257((*uParam1)[iVar13], &uVar0) == -1) {
        func_256(&(*uParam1)[iVar13]);
      }
      else {
        vVar8 = {entity::get_entity_coords(player::player_ped_id(), 1) -
                 entity::get_entity_coords((*uParam1)[iVar13], 1)};
        fVar11 = vVar8.x * vVar8.x + vVar8.y * vVar8.y;
        if (vVar8.z * vVar8.z < 3f * fVar11) {
          func_256(&(*uParam1)[iVar13]);
        }
      }
    }
    iVar13++;
  }
  if (iVar12 > 0) {
    iVar13 = 0;
    while (iVar13 < iVar12) {
      if (entity::does_entity_exist(uVar0[iVar13]) &&
          !entity::is_entity_dead(uVar0[iVar13], 0) &&
          !ped::is_ped_injured(uVar0[iVar13]) &&
          ped::is_ped_human(uVar0[iVar13]) &&
          !ped::is_ped_in_any_vehicle(uVar0[iVar13], 1)) {
        if (func_257(uVar0[iVar13], uParam1) == -1) {
          vVar8 = {entity::get_entity_coords(player::player_ped_id(), 1) -
                   entity::get_entity_coords(uVar0[iVar13], 1)};
          fVar11 = vVar8.x * vVar8.x + vVar8.y * vVar8.y;
          if (vVar8.z * vVar8.z > 3f * fVar11) {
            iVar15 = 0;
            iVar14 = 0;
            while (iVar14 < *uParam1) {
              if (!entity::does_entity_exist((*uParam1)[iVar14]) ||
                  ped::is_ped_injured((*uParam1)[iVar14])) {
                (*uParam1)[iVar14] = uVar0[iVar13];
                ai::open_sequence_task(&iVar7);
                ai::task_play_anim(0, "oddjobs@basejump@", "ped_a_intro", 8f,
                                   -8f, -1, 0, 0, 0, 0, 0);
                ai::task_play_anim(0, "oddjobs@basejump@", "ped_a_loop", 8f,
                                   -8f, -1, 1, 0, 0, 0, 0);
                ai::close_sequence_task(iVar7);
                ai::task_perform_sequence(uVar0[iVar13], iVar7);
                ai::clear_sequence_task(&iVar7);
                iVar14 = *uParam1;
                iVar15 = 1;
              }
              iVar14++;
            }
            if (!iVar15) {
              return;
            }
          }
        }
      }
      iVar13++;
    }
  }
}

// Position - 0x161FF
void func_256(int *iParam0) {
  ai::clear_ped_tasks(*iParam0);
  ai::task_play_anim(*iParam0, "oddjobs@basejump@", "ped_a_exit", 8f, -8f, -1,
                     0, 0, 0, 0, 0);
  *iParam0 = 0;
}

// Position - 0x16230
int func_257(int iParam0, var *uParam1) {
  int iVar0;

  if (entity::does_entity_exist(iParam0)) {
    iVar0 = 0;
    iVar0 = 0;
    while (iVar0 < *uParam1) {
      if (entity::does_entity_exist((*uParam1)[iVar0])) {
        if (iParam0 == (*uParam1)[iVar0]) {
          return iVar0;
        }
      }
      iVar0++;
    }
  }
  return -1;
}

// Position - 0x16276
void func_258(var *uParam0, var *uParam1, var *uParam2, int *iParam3,
              int iParam4, int iParam5, int iParam6, int *iParam7, int *iParam8,
              int *iParam9, int iParam10, int iParam11, int iParam12,
              int iParam13, int iParam14, int *iParam15, int *iParam16,
              int *iParam17, int *iParam18, int *iParam19, int iParam20,
              int *iParam21, int *iParam22, int *iParam23, int *iParam24,
              float *fParam25, float *fParam26, float *fParam27,
              float *fParam28, int *iParam29, int *iParam30, int *iParam31,
              int *iParam32, int *iParam33, int *iParam34, int *iParam35,
              var *uParam36) {
  int iVar0;
  int iVar1;
  int iVar2;
  var uVar3;
  int iVar4;

  vehicle::_0xE30524E1871F481D(*uParam36);
  func_351();
  func_350();
  func_466();
  func_41(&uParam2->f_26);
  *iParam19 = 0;
  *iParam21 = 0;
  *fParam25 = {0f, 0f, 0f};
  *iParam22 = -1;
  *iParam29 = 0;
  *iParam30 = 0;
  func_302(uParam2);
  if (func_432(iParam24)) {
    func_428(iParam24);
  }
  if (func_432(iParam23)) {
    func_428(iParam23);
  }
  if (entity::does_entity_exist(*iParam7)) {
    if (func_342(func_343(uParam0))) {
      vehicle::delete_mission_train(iParam7);
    }
    else {
      if (!entity::is_entity_dead(*iParam7, 0)) {
        iVar1 = vehicle::get_ped_in_vehicle_seat(*iParam7, -1, 0);
        if (entity::does_entity_exist(iVar1)) {
          ped::delete_ped(&iVar1);
        }
      }
      vehicle::delete_vehicle(iParam7);
    }
  }
  iVar2 = 0;
  while (iVar2 < *iParam5) {
    if (entity::does_entity_exist((*iParam5)[iVar2]) &&
        !entity::is_entity_dead((*iParam5)[iVar2], 0)) {
      ai::clear_ped_tasks((*iParam5)[iVar2]);
      (*iParam5)[iVar2] = 0;
    }
    iVar2++;
  }
  if (entity::does_entity_exist(*iParam8)) {
    vehicle::delete_vehicle(iParam8);
  }
  if (entity::does_entity_exist(*iParam9)) {
    if (!func_301(*iParam9) &&
        entity::does_entity_exist(
            vehicle::get_ped_in_vehicle_seat(*iParam9, -1, 0))) {
      uVar3 = vehicle::get_ped_in_vehicle_seat(*iParam9, -1, 0);
      ped::delete_ped(&uVar3);
    }
    vehicle::delete_vehicle(iParam9);
  }
  if (!entity::is_entity_dead(*iParam4, 0)) {
    entity::set_ped_as_no_longer_needed(iParam4);
  }
  if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
    iVar0 = ped::get_vehicle_ped_is_using(player::player_ped_id());
    if (entity::does_entity_exist(iVar0)) {
      ped::_0xF9ACF4A08098EA25(player::player_ped_id(), 1);
      entity::set_entity_coords(
          player::player_ped_id(),
          entity::get_entity_coords(iVar0, 1) + Vector(0f, 0f, 2f), 1, 0, 0, 1);
      if (entity::does_entity_exist(*iParam6) && iVar0 == *iParam6) {
        vehicle::set_players_last_vehicle(*iParam6);
        func_262(*iParam6, func_300(iParam20), func_299(iParam20), 24, 0);
        entity::set_entity_velocity(iVar0, 0f, 0f, 0f);
        entity::set_entity_coords(iVar0, func_300(iParam20), 1, 0, 0, 1);
        vehicle::set_vehicle_on_ground_properly(iVar0, 1084227584);
        entity::set_entity_heading(iVar0, func_299(iParam20));
      }
      else {
        if (!entity::is_entity_a_mission_entity(iVar0)) {
          entity::set_entity_as_mission_entity(iVar0, 1, 0);
        }
        vehicle::delete_vehicle(&iVar0);
      }
    }
  }
  *iParam15 = 0;
  *iParam17 = 0;
  *iParam18 = 1;
  *fParam26 = 0f;
  *fParam27 = 0f;
  *fParam28 = 0f;
  *iParam31 = 0;
  *iParam32 = 0;
  *iParam33 = 0;
  *iParam34 = 0;
  *iParam35 = 0;
  if (*iParam16 > -1) {
    graphics::delete_checkpoint(*iParam11);
    graphics::delete_checkpoint(*iParam12);
    *iParam16 = -1;
  }
  if (ui::does_blip_exist(iParam13)) {
    ui::remove_blip(&iParam13);
  }
  if (ui::does_blip_exist(iParam14)) {
    ui::remove_blip(&iParam14);
  }
  iVar4 = 0;
  while (iVar4 < *iParam10) {
    if (entity::does_entity_exist((*iParam10)[iVar4]) &&
        !entity::is_entity_dead((*iParam10)[iVar4], 0)) {
      vehicle::set_vehicle_lod_multiplier((*iParam10)[iVar4], 1f);
      entity::set_entity_load_collision_flag((*iParam10)[iVar4], 0);
    }
    (*iParam10)[iVar4] = 0;
    iVar4++;
  }
  func_261(uParam2);
  *iParam3 = 0;
  func_260();
  func_259();
  cam::do_screen_fade_out(800);
}

// Position - 0x1654F
void func_259() { Global_25334 = 1; }

// Position - 0x1655B
void func_260() {
  int iVar0;

  Local_101.f_66 = -1;
  Local_101.f_67 = 10f;
  iVar0 = 0;
  while (iVar0 < 8) {
    Local_101.f_9[iVar0 /*7*/].f_3 = -1f;
    Local_101.f_9[iVar0 /*7*/].f_4 = -1f;
    Local_101.f_9[iVar0 /*7*/].f_5 = 0;
    Local_101.f_9[iVar0 /*7*/].f_6 = 0;
    iVar0++;
  }
  Local_101.f_5 = 0;
  Local_101.f_5.f_1 = -1f;
  Local_101.f_5.f_2 = 0;
  Local_101 = 0;
  Local_101.f_1 = 0;
}

// Position - 0x165CB
void func_261(var *uParam0) { uParam0->f_602 = 0; }

// Position - 0x165D9
void func_262(int iParam0, vector3 vParam1, float fParam4, int iParam5,
              int iParam6) {
  struct<60> Var0;

  if (entity::does_entity_exist(iParam0) &&
      vehicle::is_vehicle_driveable(iParam0, 0)) {
    if (iParam5 != 24 && iParam5 != 25) {
      return;
    }
    if (iParam5 == 24) {
      if (entity::does_entity_exist(Global_68531.f_484[25]) &&
          vehicle::is_vehicle_driveable(Global_68531.f_484[25], 0)) {
        if (Global_68531.f_484[25] == iParam0) {
          return;
        }
      }
    }
    if (!iParam6) {
      if (vehicle::is_big_vehicle(iParam0) ||
          entity::get_entity_model(iParam0) == joaat("bus") ||
          entity::get_entity_model(iParam0) == joaat("tourbus")) {
        return;
      }
    }
    func_298(iParam5);
    Var0.f_9 = 49;
    Var0.f_59 = 2;
    func_294(iParam0, &Var0);
    if (func_293(vParam1, 0f, 0f, 0f, 0)) {
      vParam1 = {entity::get_entity_coords(iParam0, 1)};
      fParam4 = entity::get_entity_heading(iParam0);
    }
    if (iParam5 == 24) {
      if (gameplay::get_hash_key(script::get_this_script_name()) !=
          joaat("vehicle_gen_controller")) {
        Global_69519 = gameplay::get_hash_key(script::get_this_script_name());
      }
    }
    func_286(iParam5, &Var0, vParam1, fParam4, func_292(iParam0));
    func_263(iParam5, iParam0, 0);
  }
}

// Position - 0x16702
void func_263(int iParam0, int iParam1, int iParam2) {
  int iVar0;

  if (iParam0 == -1) {
    return;
  }
  if (!func_283(&Global_68531.f_555[0 /*21*/], iParam0)) {
    return;
  }
  if (!gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 12) &&
      !gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
    if (Global_68531.f_555[0 /*21*/].f_4 != entity::get_entity_model(iParam1)) {
      return;
    }
  }
  if (Global_69438 != -1 && Global_69438 != iParam0) {
    return;
  }
  if (entity::does_entity_exist(iParam1)) {
    if (vehicle::is_vehicle_driveable(iParam1, 0)) {
      if (!entity::is_entity_a_mission_entity(iParam1)) {
        entity::set_entity_as_mission_entity(iParam1, 1, 1);
      }
      if (iParam0 == 24) {
        Global_101700.f_31389.f_4801 = func_490();
      }
      if (iParam1 != Global_68531.f_139[iParam0]) {
        if (iParam0 == 24) {
          iVar0 = func_282(iParam0);
          if (entity::does_entity_exist(iVar0) &&
              vehicle::is_vehicle_driveable(iVar0, 0) && iParam1 != iVar0) {
            func_264(iVar0, 145);
          }
        }
        Global_69437 = iParam1;
        Global_69438 = iParam0;
        Global_69439 = iParam2;
      }
    }
  }
}

// Position - 0x1681F
void func_264(int iParam0, int iParam1) {
  int iVar0;
  int iVar1;
  int iVar2;

  if (!func_265(iParam0)) {
    return;
  }
  if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
    iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
    if (!entity::does_entity_exist(iVar0)) {
      iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
    }
    if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
      if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
        iParam1 = 0;
      }
      else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
        iParam1 = 1;
      }
      else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
        iParam1 = 2;
      }
    }
    if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
      iParam1 = Global_101700.f_2095.f_539.f_3549;
    }
  }
  iVar1 = 0;
  while (iVar1 < 3) {
    iVar2 = 0;
    while (iVar2 < 2) {
      if (entity::get_entity_model(iParam0) ==
          Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
        if (!gameplay::is_string_null_or_empty(
                &Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/]
                     .f_1)) {
          if (gameplay::are_strings_equal(
                  vehicle::get_vehicle_number_plate_text(iParam0),
                  &Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/]
                       .f_1)) {
            Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
            Global_101700.f_31389.f_5592[iVar1] = iVar2;
          }
        }
      }
      iVar2++;
    }
    iVar1++;
  }
  iVar1 = 0;
  while (iVar1 < 3) {
    if (entity::get_entity_model(iParam0) ==
        Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
      if (!gameplay::is_string_null_or_empty(
              &Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
        if (gameplay::are_strings_equal(
                vehicle::get_vehicle_number_plate_text(iParam0),
                &Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
          Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
        }
      }
    }
    iVar1++;
  }
  Global_101700.f_31389.f_5590 = iParam1;
  Global_69436 = iParam0;
  Global_101700.f_31389.f_5588 = 1;
  func_294(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x16A21
int func_265(int iParam0) {
  if (!entity::does_entity_exist(iParam0) ||
      !vehicle::is_vehicle_driveable(iParam0, 0) || func_280(iParam0, 0, 0) ||
      func_280(iParam0, 1, 0) || func_280(iParam0, 2, 0) ||
      func_292(iParam0) != 145 || func_279(iParam0) || func_278(iParam0) ||
      func_277(iParam0) || func_276(iParam0) ||
      !func_266(entity::get_entity_model(iParam0))) {
    if (func_278(iParam0)) {
    }
    if (func_278(iParam0)) {
    }
    if (func_280(iParam0, 0, 0)) {
    }
    if (func_280(iParam0, 1, 0)) {
    }
    if (func_280(iParam0, 2, 0)) {
    }
    if (func_292(iParam0) != 145) {
    }
    return 0;
  }
  return 1;
}

// Position - 0x16AFE
int func_266(int iParam0) {
  if (iParam0 == 0) {
    return 0;
  }
  if (!func_267(iParam0, 0)) {
    return 0;
  }
  if (vehicle::is_this_model_a_boat(iParam0) ||
      vehicle::is_this_model_a_plane(iParam0) ||
      vehicle::is_this_model_a_heli(iParam0) ||
      vehicle::is_this_model_a_train(iParam0)) {
    return 0;
  }
  switch (iParam0) {
  case joaat("bus"):
  case joaat("stretch"):
  case joaat("barracks"):
  case joaat("armytanker"):
  case joaat("rhino"):
  case joaat("armytrailer"):
  case joaat("barracks2"):
  case joaat("flatbed"):
  case joaat("ripley"):
  case joaat("towtruck"):
  case joaat("towtruck2"):
  case joaat("airbus"):
  case joaat("coach"):
  case joaat("rentalbus"):
  case joaat("tourbus"):
  case joaat("firetruk"):
  case joaat("pbus"):
  case joaat("trash"):
  case joaat("benson"):
  case joaat("boattrailer"):
  case joaat("biff"):
  case joaat("hauler"):
  case joaat("docktrailer"):
  case joaat("phantom"):
  case joaat("pounder"):
  case joaat("tractor2"):
  case joaat("bulldozer"):
  case joaat("handler"):
  case joaat("tiptruck"):
  case joaat("cutter"):
  case joaat("dump"):
  case joaat("mixer"):
  case joaat("mixer2"):
  case joaat("rubble"):
  case joaat("scrap"):
  case joaat("tiptruck2"):
  case joaat("camper"):
  case joaat("taco"):
  case joaat("boxville"):
  case joaat("boxville2"):
  case joaat("boxville3"):
  case joaat("journey"):
  case joaat("mule"):
  case joaat("mule2"):
  case joaat("police"):
  case joaat("police2"):
  case joaat("police3"):
  case joaat("police4"):
  case joaat("policeb"):
  case joaat("policeold1"):
  case joaat("policeold2"):
  case joaat("policet"):
  case joaat("taxi"):
  case joaat("submersible"):
  case joaat("submersible2"):
  case joaat("monster"): return 0;
  }
  return 1;
}

// Position - 0x16CAF
int func_267(int iParam0, int iParam1) {
  int iVar0;
  struct<2> Var1;

  if (iParam0 == 0) {
    return 0;
  }
  if (!streaming::is_model_a_vehicle(iParam0)) {
    return 0;
  }
  if (iParam0 == joaat("dominator2") &&
          !network::network_is_game_in_progress() ||
      iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
      iParam0 == joaat("gauntlet2") &&
          !network::network_is_game_in_progress() ||
      iParam0 == joaat("blimp2") ||
      iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() ||
      iParam0 == joaat("blista3")) {
    if (!func_275()) {
      return 0;
    }
  }
  else {
    iVar0 = 0;
    while (iVar0 < dlc1::get_num_dlc_vehicles()) {
      if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
        if (iParam0 == Var1.f_1) {
          if (dlc1::_is_dlc_data_empty(Var1)) {
            return 0;
          }
        }
      }
      iVar0++;
    }
  }
  if (iParam0 == joaat("blimp")) {
    if (!func_274() && !func_273() && !func_272() && !func_271() &&
        !func_275()) {
      return 0;
    }
  }
  if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") ||
      iParam0 == joaat("khamelion")) {
    if (gameplay::is_durango_version() || gameplay::is_pc_version() ||
        gameplay::is_orbis_version()) {
    }
    else if (!func_272()) {
      return 0;
    }
  }
  if (iParam1) {
    if (!func_270(iParam0)) {
      return 0;
    }
  }
  if (!func_268(iParam0)) {
    return 0;
  }
  return 1;
}

// Position - 0x16E3D
int func_268(int iParam0) {
  int iVar0;
  var uVar1;
  char cVar2[64];

  if (!func_269()) {
    return 1;
  }
  unk3::_0x897433D292B44130(&iVar0, &uVar1);
  if (iVar0 == 4) {
    return 1;
  }
  switch (iParam0) {
  case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

  case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

  case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

  case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

  case joaat("technical2"):
    StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64);
    break;

  case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

  case joaat("wastelander"):
    StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64);
    break;

  case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

  default: return 1;
  }
  if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
    return 0;
  }
  return 1;
}

// Position - 0x16F09
int func_269() {
  if (gameplay::is_pc_version()) {
    return 1;
  }
  return 0;
}

// Position - 0x16F1D
int func_270(int iParam0) {
  int iVar0;
  int iVar1;

  if (Global_2482093) {
    return 1;
  }
  iVar0 = 1;
  iVar1 = network::_get_posix_time();
  if (iParam0 == joaat("btype3")) {
    if (!Global_262145.f_5506 && !Global_262145.f_11530 &&
        iVar1 < Global_262145.f_11531) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("faction3")) {
    if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
    if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("sabregt2")) {
    if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tornado5")) {
    if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("minivan2")) {
    if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("slamvan3")) {
    if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("prototipo")) {
    if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("seven70")) {
    if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("pfister811")) {
    if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("bf400")) {
    if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("brioso")) {
    if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("cliffhanger")) {
    if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("contender")) {
    if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("le7b")) {
    if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("omnis")) {
    if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("trophytruck")) {
    if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("trophytruck2")) {
    if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tropos")) {
    if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("gargoyle")) {
    if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("rallytruck")) {
    if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tampa2")) {
    if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tyrus")) {
    if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("sheava")) {
    if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("lynx")) {
    if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("stalion2")) {
    if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("gauntlet2")) {
    if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("dominator2")) {
    if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("buffalo3")) {
    if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("defiler")) {
    if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("nightblade")) {
    if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("zombiea")) {
    if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("esskey")) {
    if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("avarus")) {
    if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("zombieb")) {
    if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("hakuchou2")) {
    if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("vortex")) {
    if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("shotaro")) {
    if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("chimera")) {
    if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("raptor")) {
    if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("daemon2")) {
    if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("blazer4")) {
    if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tornado6")) {
    if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("youga2")) {
    if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("wolfsbane")) {
    if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("faggio3")) {
    if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("faggio")) {
    if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("bagger")) {
    if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("sanctus")) {
    if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("manchez")) {
    if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("ratbike")) {
    if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("voltic2")) {
    if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("ruiner2")) {
    if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("dune4")) {
    if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("dune5")) {
    if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("phantom2")) {
    if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("technical2")) {
    if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("boxville5")) {
    if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("wastelander")) {
    if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("blazer5")) {
    if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("comet2")) {
    if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("comet3")) {
    if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("diablous")) {
    if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("diablous2")) {
    if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("elegy")) {
    if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("elegy2")) {
    if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("fcr")) {
    if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("fcr2")) {
    if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("italigtb")) {
    if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("italigtb2")) {
    if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("nero")) {
    if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("nero2")) {
    if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("penetrator")) {
    if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("specter")) {
    if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("specter2")) {
    if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("tempesta")) {
    if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
      iVar0 = 0;
    }
  }
  if (iParam0 == joaat("gp1")) {
    if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("infernus2")) {
    if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("ruston")) {
    if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
      iVar0 = 0;
    }
  }
  else if (iParam0 == joaat("turismo2")) {
    if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
      iVar0 = 0;
    }
  }
  return iVar0;
}

// Position - 0x17C60
int func_271() { return 0; }

// Position - 0x17C69
int func_272() { return 1; }

// Position - 0x17C72
int func_273() { return 1; }

// Position - 0x17C7B
int func_274() {
  if (dlc2::is_dlc_present(-1226939934)) {
    return 1;
  }
  return 0;
}

// Position - 0x17C94
bool func_275() {
  int iVar0;

  if (network::network_is_signed_in()) {
    if (network::_network_are_ros_available()) {
      if (network::_0x593570C289A77688()) {
        stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
        gameplay::set_bit(&iVar0, 2);
        gameplay::set_bit(&iVar0, 4);
        gameplay::set_bit(&iVar0, 6);
        gameplay::set_bit(&Global_25, 2);
        gameplay::set_bit(&Global_25, 4);
        gameplay::set_bit(&Global_25, 6);
        stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
        if (gameplay::_0x5AA3BEFA29F03AD4()) {
          iVar0 = gameplay::get_profile_setting(866);
          gameplay::set_bit(&iVar0, 0);
          stats::_0xDAC073C7901F9E15(iVar0);
        }
        return true;
      }
    }
  }
  if (Global_139179 == 2) {
    return true;
  }
  else if (Global_139179 == 3) {
    return false;
  }
  if (gameplay::_0x5AA3BEFA29F03AD4()) {
    if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
      return true;
    }
  }
  return false;
}

// Position - 0x17D4F
int func_276(int iParam0) {
  int iVar0;
  char *sVar1;

  iVar0 = entity::get_entity_model(iParam0);
  sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
  if (iVar0 == joaat("speedo") &&
      gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
    return 1;
  }
  if (!func_267(iVar0, 0)) {
    return 1;
  }
  return 0;
}

// Position - 0x17D95
int func_277(int iParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < 3) {
    if (entity::does_entity_exist(Global_89185[iVar0])) {
      if (Global_89185[iVar0] == iParam0) {
        return 1;
      }
    }
    iVar0++;
  }
  return 0;
}

// Position - 0x17DD0
bool func_278(int iParam0) {
  int iVar0;

  if (entity::does_entity_exist(iParam0) &&
      vehicle::is_vehicle_driveable(iParam0, 0)) {
    iVar0 = 0;
    while (iVar0 < 9) {
      if (entity::does_entity_exist(Global_89155[iVar0]) &&
          vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
        if (Global_89155[iVar0] == iParam0 &&
            entity::get_entity_model(Global_89155[iVar0]) ==
                entity::get_entity_model(iParam0)) {
          return true;
        }
      }
      iVar0++;
    }
  }
  return false;
}

// Position - 0x17E4C
int func_279(int iParam0) {
  int iVar0;

  if (entity::does_entity_exist(Global_68531.f_484[24])) {
    if (iParam0 == Global_68531.f_484[24]) {
      return 0;
    }
  }
  iVar0 = 0;
  while (iVar0 < 68) {
    if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
      if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 &&
          iVar0 != 27 && iVar0 != 30 && iVar0 != 33 && iVar0 != 28 &&
          iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 &&
          iVar0 != 32) {
        if (iParam0 == Global_68531.f_484[iVar0]) {
          return 1;
        }
      }
    }
    iVar0++;
  }
  return 0;
}

// Position - 0x17F34
bool func_280(int iParam0, int iParam1, int iParam2) {
  int iVar0;
  char *sVar1;
  int iVar9;

  if (!entity::does_entity_exist(iParam0) ||
      !vehicle::is_vehicle_driveable(iParam0, 0)) {
    return false;
  }
  iVar0 = 0;
  while (func_281(iParam1, iVar0, &sVar1, &iVar9)) {
    if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
      if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
        return true;
      }
    }
    iVar0++;
  }
  return false;
}

// Position - 0x17FA5
bool func_281(int iParam0, int iParam1, char *sParam2, int *iParam3) {
  StringCopy(sParam2, "", 32);
  switch (iParam0) {
  case 0:
    if (iParam1 == 0) {
      StringCopy(sParam2, "Michael - Beverly Hills", 32);
      *iParam3 = 0;
      return true;
    }
    else if (iParam1 == 1) {
      StringCopy(sParam2, "Trevor - Countryside", 32);
      *iParam3 = 1;
      return true;
    }
    break;

  case 1:
    if (iParam1 == 0) {
      StringCopy(sParam2, "Franklin - Aunt", 32);
      *iParam3 = 5;
      return true;
    }
    else if (iParam1 == 1) {
      StringCopy(sParam2, "Franklin - Hills", 32);
      *iParam3 = 6;
      return true;
    }
    break;

  case 2:
    if (iParam1 == 0) {
      StringCopy(sParam2, "Trevor - Countryside", 32);
      *iParam3 = 2;
      return true;
    }
    else if (iParam1 == 1) {
      StringCopy(sParam2, "Trevor - City", 32);
      *iParam3 = 3;
      return true;
    }
    else if (iParam1 == 2) {
      StringCopy(sParam2, "Trevor - Stripclub", 32);
      *iParam3 = 4;
      return true;
    }
    break;
  }
  return false;
}

// Position - 0x1807E
int func_282(int iParam0) {
  if (iParam0 == -1) {
    return 0;
  }
  return Global_68531.f_139[iParam0];
}

// Position - 0x1809A
bool func_283(var *uParam0, int iParam1) {
  int iVar0;
  int iVar1;

  *uParam0 = {0f, 0f, 0f};
  uParam0->f_3 = 0f;
  uParam0->f_4 = 0;
  StringCopy(&uParam0->f_5, "", 16);
  uParam0->f_9 = 0;
  uParam0->f_10 = 0;
  uParam0->f_11 = 0;
  uParam0->f_12 = 145;
  uParam0->f_13 = -1;
  uParam0->f_14 = 0;
  uParam0->f_15 = {0f, 0f, 0f};
  uParam0->f_18 = {0f, 0f, 0f};
  switch (iParam1) {
  case 0:
    *uParam0 = {-831.8538f, 172.1154f, 69.9058f};
    uParam0->f_3 = 157.5705f;
    uParam0->f_4 = func_284(0, 1);
    uParam0->f_12 = 0;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 1:
    *uParam0 = {1970.943f, 3801.684f, 31.1396f};
    uParam0->f_3 = 301.3964f;
    uParam0->f_4 = func_284(0, 1);
    uParam0->f_12 = 0;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 2:
    *uParam0 = {-22.6297f, -1439.137f, 29.6549f};
    uParam0->f_3 = 180.0808f;
    uParam0->f_4 = func_284(1, 1);
    uParam0->f_12 = 1;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 3:
    *uParam0 = {-22.5229f, -1434.699f, 29.6552f};
    uParam0->f_3 = 141.6114f;
    uParam0->f_4 = func_284(1, 2);
    uParam0->f_12 = 1;
    gameplay::set_bit(&uParam0->f_9, 19);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 4:
    *uParam0 = {10.9281f, 545.669f, 174.7951f};
    uParam0->f_3 = 61.392f;
    uParam0->f_4 = func_284(1, 1);
    uParam0->f_12 = 1;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 5:
    *uParam0 = {6.1093f, 544.9742f, 174.2835f};
    uParam0->f_3 = 92.1548f;
    uParam0->f_4 = func_284(1, 2);
    uParam0->f_12 = 1;
    gameplay::set_bit(&uParam0->f_9, 19);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 6:
    *uParam0 = {1981.416f, 3808.131f, 31.1384f};
    uParam0->f_3 = 117.2557f;
    uParam0->f_4 = func_284(2, 1);
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 7:
    *uParam0 = {-1158.488f, -1529.367f, 3.8995f};
    uParam0->f_3 = 35.7505f;
    uParam0->f_4 = func_284(2, 1);
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 8:
    *uParam0 = {148.2868f, -1270.569f, 28.2252f};
    uParam0->f_3 = 208.4685f;
    uParam0->f_4 = func_284(2, 1);
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 20);
    gameplay::set_bit(&uParam0->f_9, 7);
    iVar0 = 1;
    break;

  case 9:
    *uParam0 = {1459.509f, -1380.45f, 78.3259f};
    uParam0->f_3 = 99.6211f;
    uParam0->f_4 = joaat("scorcher");
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 10:
    *uParam0 = {-1518.947f, -1387.865f, -0.5134f};
    uParam0->f_3 = 98.3867f;
    uParam0->f_4 = joaat("seashark");
    iVar0 = 1;
    gameplay::set_bit(&uParam0->f_9, 6);
    break;

  case 11:
    *uParam0 = {353.0926f, 3577.593f, 32.351f};
    uParam0->f_3 = 16.6205f;
    uParam0->f_4 = joaat("duster");
    iVar0 = 1;
    gameplay::set_bit(&uParam0->f_9, 6);
    break;

  case 12:
    uParam0->f_14 = 0;
    *uParam0 = {-1652.004f, -3142.348f, 12.9921f};
    uParam0->f_3 = 329.1082f;
    uParam0->f_12 = 0;
    uParam0->f_13 = 359;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 13:
    uParam0->f_14 = 1;
    *uParam0 = {-1271.649f, -3380.685f, 12.9451f};
    uParam0->f_3 = 329.5137f;
    uParam0->f_12 = 1;
    uParam0->f_13 = 359;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 14:
    uParam0->f_14 = 2;
    *uParam0 = {1735.586f, 3294.531f, 40.1651f};
    uParam0->f_3 = 194.9525f;
    uParam0->f_12 = 2;
    uParam0->f_13 = 359;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 15:
    uParam0->f_14 = 3;
    *uParam0 = {-846.27f, -1363.19f, 0.22f};
    uParam0->f_3 = 108.78f;
    uParam0->f_12 = 0;
    uParam0->f_13 = 356;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 22);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 16:
    uParam0->f_14 = 4;
    *uParam0 = {-849.47f, -1354.99f, 0.24f};
    uParam0->f_3 = 109.84f;
    uParam0->f_12 = 1;
    uParam0->f_13 = 356;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 22);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 17:
    uParam0->f_14 = 5;
    *uParam0 = {-852.47f, -1346.2f, 0.21f};
    uParam0->f_3 = 108.76f;
    uParam0->f_12 = 2;
    uParam0->f_13 = 356;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 22);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 18:
    uParam0->f_14 = 6;
    *uParam0 = {-745.857f, -1433.904f, 4.0005f};
    uParam0->f_12 = 0;
    uParam0->f_13 = 360;
    uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
    uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 19:
    uParam0->f_14 = 7;
    *uParam0 = {-761.8486f, -1453.829f, 4.0005f};
    uParam0->f_12 = 1;
    uParam0->f_13 = 360;
    uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
    uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 20:
    uParam0->f_14 = 8;
    *uParam0 = {1769.3f, 3244f, 41.1f};
    uParam0->f_12 = 2;
    uParam0->f_13 = 360;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 28);
    iVar0 = 1;
    break;

  case 21:
    uParam0->f_14 = 9;
    *uParam0 = {192.7897f, -1020.539f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 0;
    uParam0->f_13 = 357;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 28);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 22:
    uParam0->f_14 = 10;
    *uParam0 = {192.7897f, -1020.539f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 1;
    uParam0->f_13 = 357;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 28);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 23:
    uParam0->f_14 = 11;
    *uParam0 = {192.7897f, -1020.539f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 2;
    uParam0->f_13 = 357;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 14);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 28);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 26:
  case 27:
  case 28:
    iVar1 = iParam1 - 26;
    uParam0->f_14 = 12 + iVar1;
    *uParam0 = {196.2794f, -1020.479f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 0 + iVar1;
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 27);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 29:
  case 30:
  case 31:
    iVar1 = iParam1 - 29;
    uParam0->f_14 = 15 + iVar1;
    *uParam0 = {199.8872f, -1020.048f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 0 + iVar1;
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 27);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 32:
  case 33:
  case 34:
    iVar1 = iParam1 - 32;
    uParam0->f_14 = 18 + iVar1;
    *uParam0 = {203.6006f, -1019.776f, -99.98f};
    uParam0->f_3 = 180f;
    uParam0->f_4 = 0;
    uParam0->f_12 = 0 + iVar1;
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 12);
    gameplay::set_bit(&uParam0->f_9, 7);
    gameplay::set_bit(&uParam0->f_9, 27);
    gameplay::set_bit(&uParam0->f_9, 24);
    gameplay::set_bit(&uParam0->f_9, 29);
    iVar0 = 1;
    break;

  case 24:
    uParam0->f_14 = 21;
    *uParam0 = {0f, 0f, 0f};
    uParam0->f_3 = 0f;
    uParam0->f_4 = 0;
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 11);
    gameplay::set_bit(&uParam0->f_9, 13);
    gameplay::set_bit(&uParam0->f_9, 12);
    iVar0 = 1;
    break;

  case 25:
    uParam0->f_14 = 22;
    *uParam0 = {723.2515f, -632.0496f, 27.1484f};
    uParam0->f_3 = 12.9316f;
    uParam0->f_4 = joaat("tailgater");
    gameplay::set_bit(&uParam0->f_9, 10);
    gameplay::set_bit(&uParam0->f_9, 11);
    gameplay::set_bit(&uParam0->f_9, 13);
    gameplay::set_bit(&uParam0->f_9, 12);
    iVar0 = 1;
    break;

  case 35:
    *uParam0 = {-51.23f, 3111.9f, 24.95f};
    uParam0->f_3 = 46.78f;
    uParam0->f_4 = joaat("proptrailer");
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 36:
    *uParam0 = {-55.7984f, -1096.586f, 25.4223f};
    uParam0->f_3 = 308.0596f;
    uParam0->f_4 = joaat("bjxl");
    uParam0->f_10 = 126;
    uParam0->f_11 = 126;
    gameplay::set_bit(&uParam0->f_9, 9);
    gameplay::set_bit(&uParam0->f_9, 13);
    iVar0 = 1;
    break;

  case 37:
    *uParam0 = {-2892.93f, 3192.37f, 11.66f};
    uParam0->f_3 = -132.35f;
    uParam0->f_4 = joaat("velum");
    uParam0->f_10 = 157;
    uParam0->f_11 = 157;
    gameplay::set_bit(&uParam0->f_9, 9);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 13);
    iVar0 = 1;
    break;

  case 38:
    *uParam0 = {1744.308f, 3270.673f, 40.2076f};
    uParam0->f_3 = 125f;
    uParam0->f_4 = joaat("cargobob3");
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 39:
    *uParam0 = {1751.44f, 3322.643f, 42.1855f};
    uParam0->f_3 = 268.134f;
    uParam0->f_4 = joaat("submersible");
    gameplay::set_bit(&uParam0->f_9, 23);
    iVar0 = 1;
    break;

  case 41:
    *uParam0 = {1377.104f, -2076.2f, 52f};
    uParam0->f_3 = 37.5f;
    uParam0->f_4 = joaat("towtruck");
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 40:
    *uParam0 = {1380.42f, -2072.77f, 51.7607f};
    uParam0->f_3 = 37.5f;
    uParam0->f_4 = joaat("trash");
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 42:
    *uParam0 = {1359.389f, 3618.441f, 33.8907f};
    uParam0->f_3 = 108.2337f;
    uParam0->f_4 = joaat("barracks");
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 43:
    *uParam0 = {693.1154f, -1018.155f, 21.6387f};
    uParam0->f_3 = 177.6454f;
    uParam0->f_4 = joaat("firetruk");
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 8);
    iVar0 = 1;
    break;

  case 44:
    *uParam0 = {-73.6963f, 495.124f, 143.5226f};
    uParam0->f_3 = 155.5994f;
    uParam0->f_4 = joaat("vacca");
    iVar0 = 1;
    break;

  case 45:
    *uParam0 = {-67.6314f, 891.8266f, 234.5348f};
    uParam0->f_3 = 294.993f;
    uParam0->f_4 = joaat("surano");
    iVar0 = 1;
    break;

  case 46:
    *uParam0 = {533.9048f, -169.2469f, 53.7005f};
    uParam0->f_3 = 1.2998f;
    uParam0->f_4 = joaat("tornado2");
    iVar0 = 1;
    break;

  case 47:
    *uParam0 = {-726.8914f, -408.6952f, 34.0416f};
    uParam0->f_3 = 267.7392f;
    uParam0->f_4 = joaat("superd");
    iVar0 = 1;
    break;

  case 48:
    *uParam0 = {-1321.519f, 261.3993f, 61.5709f};
    uParam0->f_3 = 350.7697f;
    uParam0->f_4 = joaat("double");
    iVar0 = 1;
    break;

  case 49:
    *uParam0 = {-1267.999f, 451.6463f, 93.7071f};
    uParam0->f_3 = 48.9311f;
    uParam0->f_4 = joaat("double");
    iVar0 = 1;
    break;

  case 50:
    *uParam0 = {-1062.076f, -226.7637f, 37.157f};
    uParam0->f_3 = 234.2767f;
    uParam0->f_4 = joaat("double");
    iVar0 = 1;
    break;

  case 51:
    *uParam0 = {68.16914f, -1558.958f, 29.46904f};
    uParam0->f_3 = 49.90575f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 52:
    *uParam0 = {589.4399f, 2736.708f, 42.03316f};
    uParam0->f_3 = -175.7105f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 53:
    *uParam0 = {-488.774f, -344.5721f, 34.36356f};
    uParam0->f_3 = 82.4042f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 54:
    *uParam0 = {288.8808f, -585.4728f, 43.15428f};
    uParam0->f_3 = -20.80707f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 55:
    *uParam0 = {304.8294f, -1383.674f, 31.67744f};
    uParam0->f_3 = -41.11603f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 56:
    *uParam0 = {1126.194f, -1481.486f, 34.7016f};
    uParam0->f_3 = -91.43369f;
    uParam0->f_4 = joaat("rumpo2");
    uParam0->f_12 = 2;
    gameplay::set_bit(&uParam0->f_9, 26);
    iVar0 = 1;
    break;

  case 57:
    *uParam0 = {-1598.36f, 5252.84f, 0f};
    uParam0->f_3 = 28.14f;
    uParam0->f_4 = joaat("submersible");
    uParam0->f_13 = 308;
    gameplay::set_bit(&uParam0->f_9, 2);
    gameplay::set_bit(&uParam0->f_9, 30);
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 58:
    *uParam0 = {-1602.62f, 5260.37f, 0.86f};
    uParam0->f_3 = 25.32f;
    uParam0->f_4 = joaat("dinghy");
    uParam0->f_13 = 404;
    gameplay::set_bit(&uParam0->f_9, 2);
    gameplay::set_bit(&uParam0->f_9, 22);
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 59:
    *uParam0 = {2116.571f, 4763.279f, 40.1596f};
    uParam0->f_3 = 198.723f;
    uParam0->f_4 = joaat("bfinjection");
    iVar0 = 1;
    break;

  case 60:
    *uParam0 = {1133.21f, 120.2f, 80.9f};
    uParam0->f_3 = 134.4f;
    if (func_275()) {
      uParam0->f_4 = joaat("blimp2");
    }
    else {
      uParam0->f_4 = joaat("blimp");
    }
    uParam0->f_13 = 401;
    gameplay::set_bit(&uParam0->f_9, 13);
    gameplay::set_bit(&uParam0->f_9, 2);
    gameplay::set_bit(&uParam0->f_9, 1);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 21);
    iVar0 = 1;
    break;

  case 61:
    *uParam0 = {-806.31f, -2679.65f, 13.9f};
    uParam0->f_3 = 150.54f;
    if (func_275()) {
      uParam0->f_4 = joaat("blimp2");
    }
    else {
      uParam0->f_4 = joaat("blimp");
    }
    uParam0->f_13 = 401;
    gameplay::set_bit(&uParam0->f_9, 13);
    gameplay::set_bit(&uParam0->f_9, 2);
    gameplay::set_bit(&uParam0->f_9, 1);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 21);
    iVar0 = 1;
    break;

  case 62:
    *uParam0 = {1985.85f, 3828.96f, 31.98f};
    uParam0->f_3 = -16.58f;
    uParam0->f_4 = joaat("blazer3");
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 63:
    *uParam0 = {3870.75f, 4464.67f, 0f};
    uParam0->f_3 = 0f;
    uParam0->f_4 = joaat("submersible2");
    uParam0->f_13 = 308;
    gameplay::set_bit(&uParam0->f_9, 0);
    gameplay::set_bit(&uParam0->f_9, 21);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 6);
    gameplay::set_bit(&uParam0->f_9, 30);
    iVar0 = 1;
    break;

  case 64:
    *uParam0 = {1257.729f, -2564.474f, 41.717f};
    uParam0->f_3 = 284.5561f;
    uParam0->f_4 = joaat("dukes2");
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 65:
    *uParam0 = {643.2823f, 3014.152f, 42.2733f};
    uParam0->f_3 = 128.0554f;
    uParam0->f_4 = joaat("dukes2");
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 66:
    *uParam0 = {38.9368f, 850.8677f, 196.3f};
    uParam0->f_3 = 311.6813f;
    uParam0->f_4 = joaat("dodo");
    gameplay::set_bit(&uParam0->f_9, 30);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;

  case 67:
    *uParam0 = {1333.875f, 4262.226f, 30.78f};
    uParam0->f_3 = 262.5293f;
    uParam0->f_4 = joaat("dodo");
    gameplay::set_bit(&uParam0->f_9, 30);
    gameplay::set_bit(&uParam0->f_9, 23);
    gameplay::set_bit(&uParam0->f_9, 6);
    iVar0 = 1;
    break;
  }
  if (gameplay::is_bit_set(uParam0->f_9, 10)) {
    uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
    if (iParam1 == 14) {
      if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") ||
          uParam0->f_4 == joaat("luxor") || uParam0->f_4 == joaat("shamal") ||
          uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
        *uParam0 = {1678.8f, 3229.6f, 41.8f};
        uParam0->f_3 = 106.0906f;
      }
    }
    if (!func_293(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f,
                  0)) {
      *uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
    }
    if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
      uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
    }
  }
  if (gameplay::is_bit_set(uParam0->f_9, 19)) {
    if (!func_293(
            Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/],
            0f, 0f, 0f, 0)) {
      *uParam0 = {
          Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
      uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
    }
  }
  else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
    if (!func_293(
            Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/],
            0f, 0f, 0f, 0)) {
      *uParam0 = {
          Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
      uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
    }
  }
  return iVar0;
}

// Position - 0x19791
int func_284(int iParam0, int iParam1) {
  struct<82> Var0;

  if (func_36(iParam0)) {
    Var0.f_11 = 12;
    Var0.f_31 = 49;
    Var0.f_81 = 2;
    func_285(iParam0, &Var0, iParam1);
    return Var0;
  }
  else if (iParam0 != 145) {
  }
  return 0;
}

// Position - 0x197D3
void func_285(int iParam0, var *uParam1, int iParam2) {
  int iVar0;

  uParam1->f_88 = 1;
  uParam1->f_84 = 255;
  uParam1->f_85 = 255;
  uParam1->f_86 = 255;
  uParam1->f_97 = 1;
  uParam1->f_3 = 1000;
  uParam1->f_1 = 0;
  switch (iParam0) {
  case 0:
    iVar0 = joaat("tailgater");
    if (Global_101700.f_8044.f_99.f_58[128] &&
        !Global_101700.f_8044.f_99.f_58[131]) {
      iVar0 = joaat("premier");
    }
    switch (iVar0) {
    case joaat("tailgater"):
      *uParam1 = iVar0;
      uParam1->f_2 = 3f;
      uParam1->f_4 = 0;
      uParam1->f_9 = 1;
      uParam1->f_11[0] = 1;
      StringCopy(&uParam1->f_27, "5MDS003", 16);
      break;

    case joaat("premier"):
      *uParam1 = iVar0;
      uParam1->f_2 = 14.9f;
      uParam1->f_5 = 43;
      uParam1->f_6 = 43;
      uParam1->f_7 = 0;
      uParam1->f_8 = 156;
      uParam1->f_9 = 0;
      StringCopy(&uParam1->f_27, "880HS955", 16);
      break;
    }
    break;

  case 2:
    iVar0 = joaat("bodhi2");
    switch (iVar0) {
    case joaat("bodhi2"):
      *uParam1 = iVar0;
      uParam1->f_2 = 14f;
      uParam1->f_5 = 32;
      uParam1->f_6 = 0;
      uParam1->f_7 = 0;
      uParam1->f_8 = 156;
      StringCopy(&uParam1->f_27, "BETTY 32", 16);
      if (Global_101700.f_8044.f_99.f_58[119]) {
        uParam1->f_11[1] = 1;
      }
      break;
    }
    break;

  case 1:
    if (iParam2 == 1) {
      iVar0 = joaat("buffalo2");
    }
    else if (iParam2 == 2) {
      iVar0 = joaat("bagger");
    }
    else if (Global_101700.f_8044.f_99.f_58[118]) {
      iVar0 = joaat("bagger");
    }
    else {
      iVar0 = joaat("buffalo2");
    }
    switch (iVar0) {
    case joaat("bagger"):
      *uParam1 = iVar0;
      uParam1->f_2 = 6f;
      uParam1->f_5 = 53;
      uParam1->f_6 = 0;
      uParam1->f_7 = 59;
      uParam1->f_8 = 156;
      StringCopy(&uParam1->f_27, "FC88", 16);
      break;

    case joaat("buffalo2"):
      *uParam1 = iVar0;
      uParam1->f_2 = 0f;
      uParam1->f_5 = 111;
      uParam1->f_6 = 111;
      uParam1->f_7 = 0;
      uParam1->f_8 = 156;
      uParam1->f_10 = 1;
      StringCopy(&uParam1->f_27, "FC1988", 16);
      uParam1->f_11[0] = 1;
      uParam1->f_11[1] = 1;
      uParam1->f_11[2] = 1;
      uParam1->f_11[3] = 1;
      uParam1->f_11[4] = 1;
      uParam1->f_11[5] = 1;
      uParam1->f_11[6] = 1;
      uParam1->f_11[7] = 1;
      uParam1->f_11[8] = 1;
      break;
    }
    break;

  default: break;
  }
}

// Position - 0x19A2F
void func_286(int iParam0, var *uParam1, vector3 vParam2, var uParam5,
              int iParam6) {
  if (func_283(&Global_68531.f_555[0 /*21*/], iParam0)) {
    if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
      func_291(iParam0);
      func_290(uParam1, &Global_101700.f_31389
                             .f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/]);
      if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 11)) {
        Global_101700.f_31389
            .f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {vParam2};
        Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] =
            uParam5;
      }
      else {
        Global_101700.f_31389
            .f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {0f, 0f, 0f};
        Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] = -1f;
      }
      Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] =
          iParam6 + 1;
      func_287(iParam0, 1);
    }
  }
}

// Position - 0x19B2E
void func_287(int iParam0, int iParam1) {
  if (iParam0 == -1) {
    return;
  }
  if (iParam1) {
    if (!func_289(iParam0, 0)) {
      func_288(iParam0, 1, 0);
      func_288(iParam0, 2, 0);
      func_288(iParam0, 3, 0);
      func_288(iParam0, 4, 0);
      func_288(iParam0, 0, 1);
      Global_68531[iParam0] = 1;
    }
  }
  else {
    func_288(iParam0, 0, 0);
  }
}

// Position - 0x19B8B
void func_288(int iParam0, int iParam1, int iParam2) {
  if (iParam0 == -1) {
    return;
  }
  if (iParam2) {
    gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
  }
  else {
    gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
  }
}

// Position - 0x19BC6
int func_289(int iParam0, int iParam1) {
  if (iParam0 == -1) {
    return 0;
  }
  return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x19BE9
void func_290(var *uParam0, var *uParam1) {
  uParam1->f_66 = uParam0->f_66;
  *uParam1 = *uParam0;
  uParam1->f_1 = {uParam0->f_1};
  uParam1->f_5 = uParam0->f_5;
  uParam1->f_6 = uParam0->f_6;
  uParam1->f_7 = uParam0->f_7;
  uParam1->f_8 = uParam0->f_8;
  uParam1->f_9 = {uParam0->f_9};
  uParam1->f_59 = {uParam0->f_59};
  uParam1->f_62 = uParam0->f_62;
  uParam1->f_63 = uParam0->f_63;
  uParam1->f_64 = uParam0->f_64;
  uParam1->f_65 = uParam0->f_65;
  uParam1->f_77 = uParam0->f_77;
  uParam1->f_67 = uParam0->f_67;
  uParam1->f_69 = uParam0->f_69;
  uParam1->f_68 = uParam0->f_68;
  uParam1->f_71 = uParam0->f_71;
  uParam1->f_72 = uParam0->f_72;
  uParam1->f_73 = uParam0->f_73;
  uParam1->f_74 = uParam0->f_74;
  uParam1->f_75 = uParam0->f_75;
  uParam1->f_76 = uParam0->f_76;
}

// Position - 0x19CB5
void func_291(int iParam0) {
  if (iParam0 == -1) {
    return;
  }
  if (func_283(&Global_68531.f_555[0 /*21*/], iParam0)) {
    if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
      entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
      entity::set_vehicle_as_no_longer_needed(&Global_68531.f_139[iParam0]);
      Global_68531.f_139[iParam0] = 0;
    }
    if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
      func_287(iParam0, 0);
    }
  }
}

// Position - 0x19D2F
int func_292(int iParam0) {
  int iVar0;

  if (!entity::does_entity_exist(iParam0)) {
    return 145;
  }
  if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
    return 145;
  }
  iVar0 = 0;
  while (iVar0 < 9) {
    if (entity::does_entity_exist(Global_89155[iVar0])) {
      if (Global_89155[iVar0] == iParam0) {
        return Global_89165[iVar0];
      }
    }
    iVar0++;
  }
  return 145;
}

// Position - 0x19D92
bool func_293(vector3 vParam0, vector3 vParam3, int iParam6) {
  if (iParam6) {
    return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
  }
  return vParam0.x == vParam3.x && vParam0.y == vParam3.y &&
         vParam0.z == vParam3.z;
}

// Position - 0x19DD9
void func_294(int iParam0, var *uParam1) {
  int iVar0;

  if (vehicle::is_vehicle_driveable(iParam0, 0)) {
    func_297(uParam1);
    uParam1->f_66 = entity::get_entity_model(iParam0);
    StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0),
               16);
    *uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
    vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
    vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
    vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62,
                                          &uParam1->f_63, &uParam1->f_64);
    uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
    uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
    uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
    uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
    vehicle::get_vehicle_custom_secondary_colour(
        iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
    vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74,
                                             &uParam1->f_75, &uParam1->f_76);
    if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
      gameplay::set_bit(&uParam1->f_77, 28);
    }
    if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
      gameplay::set_bit(&uParam1->f_77, 29);
    }
    if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
      gameplay::set_bit(&uParam1->f_77, 30);
    }
    if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
      gameplay::set_bit(&uParam1->f_77, 31);
    }
    if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
      uParam1->f_65 = 0;
    }
    if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
      uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
    }
    if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
      if (vehicle::_vehicle_has_landing_gear(iParam0)) {
        switch (vehicle::get_landing_gear_state(iParam0)) {
        case 2:
        case 0:
          gameplay::clear_bit(&uParam1->f_77, 23);
          gameplay::set_bit(&uParam1->f_77, 22);
          break;

        case 3:
        case 1:
          gameplay::clear_bit(&uParam1->f_77, 23);
          gameplay::clear_bit(&uParam1->f_77, 22);
          break;

        case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
        }
      }
      else {
        gameplay::set_bit(&uParam1->f_77, 23);
      }
    }
    if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
      gameplay::set_bit(&uParam1->f_77, 9);
    }
    if (vehicle::is_vehicle_stolen(iParam0)) {
      gameplay::set_bit(&uParam1->f_77, 10);
    }
    if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
      gameplay::set_bit(&uParam1->f_77, 13);
      vehicle::get_vehicle_custom_primary_colour(
          iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
    }
    if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
      gameplay::set_bit(&uParam1->f_77, 12);
    }
    func_296(&iParam0, &uParam1->f_9, &uParam1->f_59);
    iVar0 = 0;
    while (iVar0 <= 11) {
      if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
        gameplay::set_bit(&uParam1->f_77, func_295(iVar0 + 1));
      }
      iVar0++;
    }
    if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
      gameplay::set_bit(&uParam1->f_77, 11);
    }
    else {
      gameplay::clear_bit(&uParam1->f_77, 11);
    }
    if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
        decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
      gameplay::set_bit(&uParam1->f_77, 27);
    }
    else {
      gameplay::clear_bit(&uParam1->f_77, 27);
    }
  }
}

// Position - 0x1A085
int func_295(int iParam0) {
  switch (iParam0) {
  case 1: return 0;

  case 2: return 1;

  case 3: return 2;

  case 4: return 3;

  case 5: return 4;

  case 6: return 5;

  case 7: return 6;

  case 8: return 7;

  case 9: return 8;

  case 10: return 24;

  case 11: return 25;

  case 12: return 26;
  }
  return 0;
}

// Position - 0x1A135
int func_296(int iParam0, var *uParam1, var *uParam2) {
  int iVar0;
  int iVar1;

  if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
    return 0;
  }
  if (vehicle::get_num_mod_kits(*iParam0) == 0) {
    return 0;
  }
  iVar0 = 0;
  while (iVar0 < *uParam1) {
    iVar1 = iVar0;
    if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 ||
        iVar1 == 21 || iVar1 == 22) {
      (*uParam1)[iVar0] = 0;
      if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
        (*uParam1)[iVar0] = 1;
      }
    }
    else {
      (*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
      if (iVar0 == 23) {
        (*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
      }
      else if (iVar0 == 24) {
        (*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
      }
    }
    iVar0++;
  }
  return 1;
}

// Position - 0x1A20F
void func_297(var *uParam0) {
  int iVar0;

  uParam0->f_66 = 0;
  uParam0->f_77 = 0;
  uParam0->f_65 = 0;
  uParam0->f_62 = 0;
  uParam0->f_63 = 0;
  uParam0->f_64 = 0;
  uParam0->f_74 = 0;
  uParam0->f_75 = 0;
  uParam0->f_76 = 0;
  *uParam0 = 0;
  StringCopy(&uParam0->f_1, "", 16);
  uParam0->f_5 = 0;
  uParam0->f_6 = 0;
  uParam0->f_7 = 0;
  uParam0->f_8 = 0;
  iVar0 = 0;
  while (iVar0 < 49) {
    uParam0->f_9[iVar0] = 0;
    iVar0++;
  }
  iVar0 = 0;
  while (iVar0 < 2) {
    uParam0->f_59[iVar0] = 0;
    iVar0++;
  }
  uParam0->f_67 = 0;
  uParam0->f_68 = 0;
  uParam0->f_69 = 0;
  uParam0->f_70 = 1;
  uParam0->f_71 = 0;
  uParam0->f_72 = 0;
  uParam0->f_73 = 0;
}

// Position - 0x1A2BF
void func_298(int iParam0) {
  if (iParam0 != 24 && iParam0 != 25) {
  }
  func_291(iParam0);
  func_287(iParam0, 0);
}

// Position - 0x1A2E6
float func_299(int iParam0) {
  switch (iParam0) {
  case 0: return 192.1528f;

  case 1: return 144.2205f;

  case 2: return 82.0341f;

  case 3: return 134.9389f;

  case 4: return 241.8704f;

  case 5: return 342.318f;

  case 6: return 174.9318f;

  case 7: return 186.4915f;

  case 8: return 93.0806f;

  case 9: return 213.7284f;

  case 10: return 55.5964f;

  case 11: return 61.2421f;

  case 12: return 304.1476f;

  default:
  }
  return 0f;
  return 0f;
}

// Position - 0x1A3B0
Vector3 func_300(int iParam0) {
  switch (iParam0) {
  case 0: return -835.2823f, -1303.246f, 4.0004f;

  case 1: return 1236.613f, 143.0208f, 80.8622f;

  case 2: return 2463.523f, 1495.492f, 34.8794f;

  case 3: return -262.0742f, 6590.702f, 0.9787f;

  case 4: return -45.396f, -784.1727f, 43.2721f;

  case 5: return -182.8192f, -890.5899f, 28.3452f;

  case 6: return -1236.648f, 4557.094f, 185.7374f;

  case 7: return -731.5519f, 4497.153f, 75.5991f;

  case 8: return -790.7881f, 293.895f, 84.7917f;

  case 9: return -1426.048f, 4408.049f, 46.1198f;

  case 10: return 2491.808f, 5001.821f, 44.1871f;

  case 11: return 1067.101f, -198.2404f, 68.6323f;

  case 12: return -762.3691f, 4301.332f, 145.2817f;

  default:
  }
  return 0f, 0f, 0f;
  return 0f, 0f, 0f;
}

// Position - 0x1A500
int func_301(int iParam0) {
  if (entity::does_entity_exist(iParam0)) {
    if (entity::is_entity_dead(iParam0, 0)) {
      return 1;
    }
    else if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
      if (!fire::is_entity_on_fire(iParam0)) {
        return 1;
      }
    }
  }
  else {
    return 1;
  }
  return 0;
}

// Position - 0x1A543
void func_302(int *iParam0) {
  if (*uParam0 != 0) {
    graphics::set_scaleform_movie_as_no_longer_needed(uParam0);
    *iParam0 = 0;
  }
  iParam0->f_1 = 0;
  iParam0->f_2 = 0;
  iParam0->f_12[0] = 0;
  iParam0->f_12[1] = 0;
  iParam0->f_12[2] = 0;
  iParam0->f_12[3] = 0;
  iParam0->f_12[4] = 0;
  iParam0->f_12[5] = 0;
  iParam0->f_12[6] = 0;
  iParam0->f_12[7] = 0;
  iParam0->f_3[0] = 353;
  iParam0->f_3[1] = 353;
  iParam0->f_3[2] = 353;
  iParam0->f_3[3] = 353;
  iParam0->f_3[4] = 353;
  iParam0->f_3[5] = 353;
  iParam0->f_3[6] = 353;
  iParam0->f_3[7] = 353;
  iParam0->f_21[0] = 0;
  iParam0->f_21[1] = 0;
  iParam0->f_21[2] = 0;
  iParam0->f_21[3] = 0;
}

// Position - 0x1A616
bool func_303(var *uParam0, int iParam1, int iParam2) {
  if (gameplay::get_game_timer() - uParam0->f_5 > iParam2) {
    uParam0->f_4 = gameplay::get_game_timer();
  }
  uParam0->f_5 = gameplay::get_game_timer();
  if (gameplay::get_game_timer() - uParam0->f_4 > iParam2) {
    if (gameplay::is_bit_set(uParam0->f_2, iParam1) &&
        !gameplay::is_bit_set(uParam0->f_3, iParam1)) {
      uParam0->f_4 = gameplay::get_game_timer();
      return true;
    }
  }
  return false;
}

// Position - 0x1A674
bool func_304(var *uParam0, int *iParam1, vector3 vParam2, vector3 vParam5,
              vector3 vParam8, var *uParam11, float *fParam12) {
  vector3 vVar0;

  switch (uParam0->f_3) {
  case 0:
    if (func_431(iParam1) >= 0f) {
      vParam8.z = func_46(vParam8.z, -8.909f, 8.909f);
      uParam11->f_2 += vParam8.z;
      vVar0 = {func_433(vParam5, vParam8.z)};
      cam::set_cam_params(func_403(uParam0, 0), vParam2 + vVar0, *uParam11,
                          *fParam12, 300, 1, 1, 2);
      cam::set_cam_active_with_interp(func_403(uParam0, 1),
                                      func_403(uParam0, 0),
                                      system::floor(1000f * (1.1f - 0f)), 2, 1);
      uParam0->f_3 = 1;
    }
    break;

  case 1:
    if (func_431(iParam1) >= 0f) {
      cam::set_gameplay_cam_relative_heading(0f);
      cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
      cam::render_script_cams(0, 1, system::floor(1000f * (1.1f - 0f)), 0, 0,
                              0);
      uParam0->f_3 = 2;
    }
    break;

  case 2:
    if (func_431(iParam1) >= 1.1f) {
      uParam0->f_3 = 3;
      return true;
    }
    break;

  case 3: return true;
  }
  return false;
}

// Position - 0x1A788
void func_305(int iParam0, var *uParam1, int *iParam2) {
  vector3 vVar0;
  int iVar3;
  int iVar4;
  vector3 vVar5;

  iVar3 = func_403(uParam1, 0);
  iVar4 = func_403(uParam1, 1);
  cam::set_cam_near_clip(iVar4, func_306());
  vVar5 = {entity::get_offset_from_entity_in_world_coords(iParam0, 2f, -0.3f,
                                                          -7.7824f)};
  cam::set_cam_coord(iVar4, vVar5);
  vVar0 = {cam::get_cam_rot(iVar3, 2)};
  vVar0.x = 0f;
  cam::set_cam_rot(iVar4, vVar0, 2);
  cam::set_cam_fov(iVar4, cam::get_cam_fov(iVar3));
  cam::render_script_cams(1, 0, 3000, 1, 0, 0);
  uParam1->f_3 = 0;
  func_346(iParam2);
}

// Position - 0x1A807
float func_306() {
  if (gameplay::is_pc_version()) {
    return 0.5f;
  }
  return 0.84f;
}

// Position - 0x1A823
int func_307(var *uParam0, var *uParam1, var *uParam2, int *iParam3,
             var *uParam4, float *fParam5, vector3 vParam6, vector3 vParam9) {
  int iVar0;
  vector3 vVar1;
  vector3 vVar4;

  iVar0 = func_403(uParam1, 0);
  vVar1 = {func_310(uParam2)};
  if (controls::is_look_inverted()) {
    vVar1.y *= -1f;
  }
  if (!controls::_is_input_disabled(2)) {
    fParam5->f_2 -= vVar1.x * gameplay::get_frame_time() * 100f;
    *fParam5 += vVar1.y * gameplay::get_frame_time() * 100f;
    if (gameplay::absf(fParam5->f_2) > 0.001f) {
      fParam5->f_2 -= fParam5->f_2 * gameplay::get_frame_time() * 4f;
    }
    else {
      fParam5->f_2 = 0f;
    }
    if (gameplay::absf(*fParam5) > 0.001f) {
      *fParam5 -= *fParam5 * gameplay::get_frame_time() * 5f;
    }
    else {
      *fParam5 = 0f;
    }
  }
  else {
    fParam5->f_2 = -vVar1.x * 130f;
    *fParam5 = vVar1.y * 130f;
  }
  uParam4->f_2 += fParam5->f_2 * gameplay::get_frame_time();
  if (uParam4->f_2 > 0.5f * 43.7465f) {
    uParam4->f_2 = 0.5f * 43.7465f;
    fParam5->f_2 = 0f;
  }
  else if (uParam4->f_2 < -0.5f * 43.7465f) {
    uParam4->f_2 = -0.5f * 43.7465f;
    fParam5->f_2 = 0f;
  }
  *uParam4 += *fParam5 * gameplay::get_frame_time();
  if (*uParam4 > 0.5f * 21.6f) {
    *uParam4 = 0.5f * 21.6f;
    *fParam5 = 0f;
  }
  else if (*uParam4 < -0.5f * 21.6f) {
    *uParam4 = -0.5f * 21.6f;
    *fParam5 = 0f;
  }
  vVar4 = {func_433(vParam9, uParam4->f_2)};
  cam::set_cam_coord(iVar0, vParam6 + vVar4);
  cam::set_cam_rot(iVar0, -33f + *uParam4, 0f,
                   -88.515f + func_434(uParam0) + uParam4->f_2, 2);
  cam::set_cam_near_clip(iVar0, func_306());
  if (!cam::is_screen_faded_in() || !func_432(iParam3)) {
    func_346(iParam3);
  }
  else {
    if (!ui::is_help_message_being_displayed()) {
      func_309("BJ_VLOOKHLP");
    }
    if (func_432(iParam3) && func_431(iParam3) > 0.5f) {
      if (func_308(uParam2, 1)) {
        func_428(iParam3);
        cam::detach_cam(iVar0);
        return 1;
      }
    }
  }
  return 0;
}

// Position - 0x1AA61
bool func_308(var *uParam0, int iParam1) {
  return gameplay::is_bit_set(uParam0->f_2, iParam1) &&
         !gameplay::is_bit_set(uParam0->f_3, iParam1);
}

// Position - 0x1AA83
void func_309(char *sParam0) {
  ui::begin_text_command_display_help(sParam0);
  ui::end_text_command_display_help(0, 1, 1, -1);
}

// Position - 0x1AA99
Vector3 func_310(var *uParam0) { return *uParam0, uParam0->f_1, 0f; }

// Position - 0x1AAA9
void func_311(int iParam0, vector3 vParam1) {
  float fVar0;
  float fVar1;
  float fVar2;

  fVar0 =
      0.006f *
      system::sin(0.25f * 0.5f * system::to_float(gameplay::get_game_timer()) +
                  1.5f);
  fVar1 = 0.006f *
          system::sin(
              0.25f * 0.4f * system::to_float(gameplay::get_game_timer()) + 3f);
  fVar2 = 0.006f * system::sin(0.25f * 1f *
                               system::to_float(gameplay::get_game_timer()));
  if (!entity::is_entity_dead(iParam0, 0)) {
    entity::set_entity_coords(iParam0, vParam1 + Vector(fVar2, fVar1, fVar0), 1,
                              0, 0, 1);
  }
}

// Position - 0x1AB35
bool func_312(char *sParam0) {
  ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
  return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x1AB48
void func_313(char *sParam0, int iParam1) {
  ui::begin_text_command_display_help(sParam0);
  ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x1AB5F
void func_314(var *uParam0, int iParam1) {
  if (iParam1) {
    if (audio::is_audio_scene_active("BASEJUMPS_PREP_FOR_JUMP_ON_FOOT")) {
      audio::stop_audio_scene("BASEJUMPS_PREP_FOR_JUMP_ON_FOOT");
      func_202(uParam0, 20, 0);
    }
  }
  else if (audio::is_audio_scene_active("BASEJUMPS_PREP_FOR_JUMP_MOTO")) {
    audio::stop_audio_scene("BASEJUMPS_PREP_FOR_JUMP_MOTO");
    func_202(uParam0, 20, 0);
  }
}

// Position - 0x1ABA7
void func_315(char *sParam0, int iParam1, int iParam2) {
  iParam2 = iParam2;
  ui::begin_text_command_print(sParam0);
  ui::end_text_command_print(iParam1, 1);
}

// Position - 0x1ABC0
struct<4> func_316(int iParam0) {
  struct<4> Var0;

  switch (iParam0) {
  case 3:
  case 12:
  case 6: StringCopy(&Var0, "BJ_OBJ_JCL", 16); break;

  case 4: StringCopy(&Var0, "BJ_OBJ_JDB", 16); break;

  case 5: StringCopy(&Var0, "BJ_OBJ_JCR", 16); break;

  case 8: StringCopy(&Var0, "BJ_OBJ_JB", 16); break;

  default: break;
  }
  return Var0;
}

//Position - 0x1AC26
void func_317(int* iParam0, float fParam1)
{
  if (!func_432(iParam0)) {
    func_39(iParam0, fParam1);
  }
}

// Position - 0x1AC40
void func_318(int *iParam0, int *iParam1) {
  if (func_432(iParam0)) {
    if (func_320(iParam0, 7.5f * IntToFloat(*iParam1))) {
      *iParam1++;
      func_198(player::player_ped_id(), "BASEJUMP_ABOUT_TO_JUMP", 24);
    }
  }
  else if (!func_319()) {
    func_317(iParam0, 0f);
  }
}

// Position - 0x1AC8C
int func_319() {
  if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
    return 1;
  }
  return 0;
}

// Position - 0x1ACAE
bool func_320(int *iParam0, float fParam1) {
  if (func_321(iParam0, fParam1)) {
    func_428(iParam0);
    return true;
  }
  return false;
}

// Position - 0x1ACCC
bool func_321(int *iParam0, float fParam1) {
  if (func_432(iParam0)) {
    if (func_431(iParam0) > fParam1) {
      return true;
    }
  }
  return false;
}

// Position - 0x1ACEE
void func_322(var *uParam0) {
  if (!ped::is_ped_injured(player::player_ped_id())) {
    weapon::get_current_ped_weapon(player::player_ped_id(), uParam0, 1);
    if (*uParam0 != 0 && *uParam0 != joaat("weapon_unarmed") &&
        *uParam0 != joaat("weapon_electric_fence") &&
        *uParam0 != joaat("gadget_parachute") && *uParam0 != joaat("object")) {
      weapon::give_weapon_to_ped(player::player_ped_id(),
                                 joaat("weapon_unarmed"), -1, 0, 1);
    }
    controls::disable_control_action(0, 37, 1);
    controls::disable_control_action(0, 66, 1);
    controls::disable_control_action(0, 67, 1);
    controls::disable_control_action(0, 68, 1);
    controls::disable_control_action(0, 99, 1);
    controls::disable_control_action(0, 100, 1);
    ui::hide_hud_component_this_frame(19);
  }
}

// Position - 0x1AD94
int func_323(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4,
             int iParam5, int *iParam6, int iParam7, int *iParam8, int iParam9,
             int *iParam10, int iParam11, int *iParam12, int iParam13,
             int *iParam14, float *fParam15, float *fParam16, float *fParam17,
             int *iParam18, int iParam19, int iParam20, float fParam21) {
  vector3 vVar0;
  var uVar3;
  var uVar6;
  vector3 vVar9;
  vector3 vVar12;
  vector3 vVar15;
  vector3 vVar18;
  vector3 vVar21;
  vector3 vVar24;
  vector3 vVar27;
  vector3 vVar30;
  float fVar33;
  float fVar34;
  float fVar35;
  float fVar36;
  bool bVar37;
  bool bVar38;
  int iVar39;
  int iVar40;
  int iVar41;
  var uVar42;
  var uVar43;
  var uVar44;

  vVar12 = {func_344(uParam0, *iParam6)};
  bVar37 = *iParam6 == iParam9 - 1;
  (*iParam3)[0] = (*iParam3)[0];
  if (!ped::is_ped_injured(player::player_ped_id())) {
    entity::get_entity_matrix(player::player_ped_id(), &vVar0, &uVar3, &uVar6,
                              &vVar9);
  }
  if (bVar37) {
    if (entity::does_entity_exist(iParam1) &&
        !entity::is_entity_dead(iParam1, 0)) {
      vVar27 = {entity::get_offset_from_entity_in_world_coords(
          iParam1, func_345(uParam0))};
      fVar36 = vVar27.z - vVar12.z;
      if (iParam20) {
        if (ui::does_blip_exist(*iParam11)) {
          ui::set_blip_coords(*iParam11, vVar27);
        }
        else {
          *iParam11 = ui::add_blip_for_coord(vVar27);
          ui::set_blip_colour(*iParam11, 5);
          ui::set_blip_scale(*iParam11, 1.2f);
          ui::set_blip_name_from_text_file(*iParam11, "BJ_BLIP_TGT");
        }
      }
      vVar30 = {func_344(uParam0, 0)};
      vVar27.z = vVar30.z + fVar36;
      vVar12 = {vVar27};
    }
    else if (func_343(uParam0) != 0) {
      vVar27 = {func_344(uParam0, 0)};
      vVar12 = {vVar27};
    }
    else {
      vVar27 = {vVar12};
    }
    vVar18 = {vVar9 - vVar12};
    if (func_343(uParam0) == 0) {
      graphics::draw_marker(6, vVar27, 0f, 0f, 1f, 0f, 0f, 0f, 4f, 4f, 4f, 240,
                            200, 80, func_332(vVar27, 170, 200), 0, 0, 2, 0, 0,
                            0, 0);
      graphics::draw_marker(6, vVar27, 0f, 0f, 1f, 0f, 0f, 0f, 9f, 9f, 9f, 240,
                            200, 80, func_332(vVar27, 170, 200), 0, 0, 2, 0, 0,
                            0, 0);
      graphics::draw_marker(6, vVar27, 0f, 0f, 1f, 0f, 0f, 0f, 14f, 14f, 14f,
                            240, 200, 80, func_332(vVar27, 170, 200), 0, 0, 2,
                            0, 0, 0, 0);
    }
    if (*iParam7 != -1) {
      graphics::delete_checkpoint(*iParam4);
      *iParam7 = -1;
    }
  }
  else {
    ui::get_hud_colour(134, &iVar39, &iVar40, &iVar41, &uVar42);
    vVar18 = {vVar9 - vVar12};
    vVar15 = {func_344(uParam0, *iParam6 + 1)};
    graphics::draw_marker(6, vVar12, func_445(vVar18), 0f, 0f, 0f, 14f, 14f,
                          14f, 240, 200, 80, func_332(vVar12, 25, 200), 0, 0, 2,
                          0, 0, 0, 0);
    if (*iParam7 != *iParam6) {
      if (*iParam7 >= 0) {
        graphics::delete_checkpoint(*iParam4);
        *iParam4 = 0;
        if (*iParam7 < iParam9 - 2) {
          graphics::delete_checkpoint(*iParam5);
          *iParam4 = 0;
        }
      }
      *iParam4 = graphics::create_checkpoint(
          15, vVar12, vVar15, 9f, iVar39, iVar40, iVar41,
          func_332(vVar27, 25,
                   system::ceil(200f * system::to_float(113) /
                                system::to_float(170))),
          0);
      if (*iParam6 < iParam9 - 2) {
        *iParam5 = graphics::create_checkpoint(
            15, vVar15, func_344(uParam0, *iParam6 + 2), 9f * 0.5f, iVar39,
            iVar40, iVar41,
            func_332(vVar27, 25,
                     system::ceil(200f * system::to_float(113) /
                                  system::to_float(170))),
            0);
      }
      *iParam7 = *iParam6;
    }
    if (*iParam6 + 1 == iParam9 - 1) {
      graphics::draw_marker(6, vVar15, 0f, 0f, 1f, 0f, 0f, 0f, 0.5f * 4f,
                            0.5f * 4f, 0.5f * 4f, 240, 200, 80,
                            func_332(vVar15, 170, 200), 0, 0, 2, 0, 0, 0, 0);
      graphics::draw_marker(6, vVar15, 0f, 0f, 1f, 0f, 0f, 0f, 0.5f * 9f,
                            0.5f * 9f, 0.5f * 9f, 240, 200, 80,
                            func_332(vVar15, 170, 200), 0, 0, 2, 0, 0, 0, 0);
      graphics::draw_marker(6, vVar15, 0f, 0f, 1f, 0f, 0f, 0f, 0.5f * 14f,
                            0.5f * 14f, 0.5f * 14f, 240, 200, 80,
                            func_332(vVar15, 170, 200), 0, 0, 2, 0, 0, 0, 0);
    }
    else {
      graphics::draw_marker(6, vVar15, func_445(vVar9 - vVar15), 0f, 0f, 0f,
                            0.5f * 14f, 0.5f * 14f, 0.5f * 14f, 240, 200, 80,
                            func_332(vVar15, 25, 200), 0, 0, 2, 0, 0, 0, 0);
    }
    if (*iParam4 != 0) {
      graphics::set_checkpoint_rgba(
          *iParam4, iVar39, iVar40, iVar41,
          func_332(vVar12, 25,
                   system::ceil(200f * system::to_float(113) /
                                system::to_float(170))));
    }
    if (*iParam5 != 0) {
      graphics::set_checkpoint_rgba(
          *iParam5, iVar39, iVar40, iVar41,
          func_332(vVar15, 25,
                   system::ceil(200f * system::to_float(113) /
                                system::to_float(170))));
    }
  }
  if (!iParam19) {
    return 0;
  }
  if (ped::get_ped_parachute_state(player::player_ped_id()) == 0 ||
      ped::get_ped_parachute_state(player::player_ped_id()) == 1 ||
      ped::get_ped_parachute_state(player::player_ped_id()) == 2 &&
          !controls::is_control_pressed(0, 80)) {
    if (!graphics::get_screen_coord_from_world_coord(vVar12, &uVar43,
                                                     &uVar44)) {
      if (iLocal_615) {
        func_330(vVar12, fParam15, fParam16, fParam17);
        if (func_432(&iLocal_617)) {
          func_428(&iLocal_617);
        }
      }
      else if (func_432(&iLocal_617)) {
        if (func_328(&iLocal_617) > 0.5f) {
          func_428(&iLocal_617);
          iLocal_615 = 1;
        }
      }
      else {
        func_456(&iLocal_617);
      }
    }
    else if (iLocal_615) {
      func_330(vVar12, fParam15, fParam16, fParam17);
      if (func_432(&iLocal_617)) {
        if (func_328(&iLocal_617) > 0.5f) {
          func_428(&iLocal_617);
          iLocal_615 = 0;
        }
      }
      else {
        func_456(&iLocal_617);
      }
    }
    else if (func_432(&iLocal_617)) {
      func_428(&iLocal_617);
    }
  }
  else {
    iLocal_615 = 0;
  }
  if (func_327(iParam14, iParam18, &iParam1)) {
    if (ui::does_blip_exist(*iParam11)) {
      ui::remove_blip(iParam11);
    }
    if (ui::does_blip_exist(*iParam12)) {
      ui::remove_blip(iParam12);
    }
    if (!bVar37) {
      return 2;
    }
    fVar34 = system::sqrt(vVar18.x * vVar18.x + vVar18.y * vVar18.y);
    if (vVar18.z < 5f && vVar18.z > -2f && fVar34 < 15f ||
        func_242(iParam1, iParam2)) {
      *iParam10 =
          func_244(system::ceil(100f * (15f - fVar34) / 15f) + 4, 0, 100);
      return 1;
    }
    else {
      return 3;
    }
  }
  else if (func_326()) {
    if (player::get_player_invincible(player::player_id())) {
      player::set_player_invincible(player::player_id(), 0);
    }
  }
  else if (!bVar37) {
    fVar33 = system::vmag2(vVar18);
    if (fVar33 < 22f * 22f) {
      if (fVar33 < 10f * 10f) {
        bVar38 = true;
      }
      else if (func_251(vVar0, -vVar18 / FtoV(system::sqrt(fVar33))) < 0.08f) {
        bVar38 = true;
      }
      if (bVar38) {
        *iParam8++;
        func_325(iParam13, 1);
        func_204(func_398(), 1, system::floor(30f * fParam21), 0, 0);
        iLocal_616 = 0;
      }
      if (!bVar38 && !iLocal_616) {
        iLocal_616 = 1;
      }
    }
    else if (ped::get_ped_parachute_state(player::player_ped_id()) == 0 ||
             ped::get_ped_parachute_state(player::player_ped_id()) == -1) {
      if (vVar18.z < -22f) {
        func_325(iParam13, 0);
        bVar38 = true;
      }
    }
    else {
      vVar24 = {entity::get_entity_forward_vector(player::player_ped_id())};
      vVar24.z = 0f;
      vVar24 = {func_445(vVar24)};
      vVar21 = {-vVar18.x, -vVar18.y, 0f};
      vVar21 = {func_445(vVar21)};
      fVar35 = vVar9.z - 32f + 32f * func_324(vVar24, vVar21);
      fVar34 = system::sqrt(vVar18.x * vVar18.x + vVar18.y * vVar18.y);
      if (vVar9.z - fVar35 < fVar34) {
        fVar35 -= 0.05f * (fVar35 - vVar9.z + fVar34);
        if (fVar35 < vVar12.z - 22f) {
          func_325(iParam13, 0);
          bVar38 = true;
        }
      }
    }
    if (iLocal_616) {
      if (system::vmag2(vVar18) >= 22f * 22f) {
        *iParam8++;
        func_325(iParam13, 1);
        func_204(func_398(), 1, system::floor(30f * fParam21), 0, 0);
        bVar38 = true;
        iLocal_616 = 0;
      }
    }
    if (bVar38) {
      *iParam6++;
      if (ui::does_blip_exist(*iParam11)) {
        ui::remove_blip(iParam11);
      }
      if (ui::does_blip_exist(*iParam12)) {
        *iParam11 = *iParam12;
        *iParam12 = 0;
        ui::set_blip_scale(*iParam11, 1.2f);
        if (*iParam6 >= iParam9 - 1) {
          ui::set_blip_name_from_text_file(*iParam11, "BJ_BLIP_TGT");
        }
        else {
          ui::set_blip_name_from_text_file(*iParam11, "BJ_BLIP_CHK");
        }
      }
      if (*iParam6 < iParam9 - 1) {
        if (!ui::does_blip_exist(*iParam12)) {
          *iParam12 = ui::add_blip_for_coord(func_344(uParam0, *iParam6 + 1));
          ui::set_blip_colour(*iParam12, 5);
          ui::set_blip_scale(*iParam12, 0.7f);
          if (*iParam6 + 1 >= iParam9 - 1) {
            ui::set_blip_name_from_text_file(*iParam12, "BJ_BLIP_TGT");
          }
          else {
            ui::set_blip_name_from_text_file(*iParam12, "BJ_BLIP_CHK");
          }
        }
      }
      else {
        *iParam12 = 0;
      }
      ai::task_look_at_coord(player::player_ped_id(),
                             func_344(uParam0, *iParam6), -1, 0, 2);
    }
  }
  return 0;
}

// Position - 0x1B690
float func_324(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
  return Param0 * Param3 + Param0.f_1 * Param3.f_1;
}

// Position - 0x1B6A7
void func_325(var *uParam0, int iParam1) {
  *uParam0 = audio::get_sound_id();
  if (iParam1) {
    audio::play_sound_frontend(*uParam0, "CHECKPOINT_NORMAL",
                               "HUD_MINI_GAME_SOUNDSET", 1);
  }
  else {
    func_315("BJ_MISSED", 7500, 1);
    audio::play_sound_frontend(*uParam0, "CHECKPOINT_MISSED",
                               "HUD_MINI_GAME_SOUNDSET", 1);
  }
}

// Position - 0x1B6EA
bool func_326() {
  if (ped::is_ped_ragdoll(player::player_ped_id()) &&
      (ped::get_ped_parachute_state(player::player_ped_id()) == 3 ||
       ped::get_ped_parachute_state(player::player_ped_id()) == -1) &&
      entity::get_entity_height_above_ground(player::player_ped_id()) > 50f &&
      !player::get_player_has_reserve_parachute(player::player_id())) {
    return true;
  }
  return false;
}

// Position - 0x1B742
bool func_327(int *iParam0, int *iParam1, int iParam2) {
  int iVar0;
  int iVar1;

  if (ped::is_ped_injured(player::player_ped_id())) {
    return true;
  }
  iVar0 = player::player_ped_id();
  if (!*iParam1) {
    iVar1 = ped::get_ped_parachute_landing_type(iVar0);
    if (iVar1 != -1 && !entity::is_entity_in_air(iVar0)) {
      *iParam1 = 1;
      *iParam0 = iVar1;
    }
  }
  return entity::is_entity_in_water(player::player_ped_id()) ||
         ped::get_ped_parachute_state(iVar0) == 3 &&
             !entity::is_entity_in_air(iVar0) ||
         ped::get_ped_parachute_state(iVar0) == -1 &&
             !entity::is_entity_in_air(iVar0) ||
         entity::does_entity_exist(*iParam2) && !ped::is_ped_injured(iVar0) &&
             !entity::is_entity_dead(*iParam2, 0) &&
             ped::is_ped_on_specific_vehicle(iVar0, *iParam2);
}

// Position - 0x1B7FB
float func_328(int *iParam0) {
  if (func_432(iParam0)) {
    if (func_329(iParam0)) {
      return iParam0->f_2;
    }
    else {
      return func_40(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
    }
  }
  return 0f;
}

// Position - 0x1B837
bool func_329(int *iParam0) { return gameplay::is_bit_set(*iParam0, 2); }

// Position - 0x1B847
void func_330(vector3 vParam0, float *fParam3, float *fParam4, float *fParam5) {
  var uVar0;
  var uVar1;
  float fVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  int iVar8;
  int iVar9;

  if (graphics::get_screen_coord_from_world_coord(vParam0, &uVar0, &uVar1)) {
  }
  fVar4 = 0f;
  fVar5 = 0.05f;
  fVar6 = 0.05f;
  func_331(vParam0, &fVar2, &fVar3);
  if (fVar2 != 0f && fVar3 != 0f) {
    if (fVar2 >= 0.7999f) {
      fVar4 = 90f;
    }
    else if (fVar2 <= 0.2f) {
      fVar4 = -90f;
    }
    else if (fVar3 <= 0.2f) {
      fVar4 = 0f;
    }
    else if (fVar3 >= 0.7999f) {
      fVar4 = 180f;
    }
    graphics::get_screen_resolution(&iVar8, &iVar9);
    fVar7 = system::to_float(iVar8) / system::to_float(iVar9);
    if (fVar4 == 0f || fVar4 == 180f) {
      fVar5 = 0.05f * 16f / 9f;
      fVar6 = 0.05f / fVar7;
    }
    else {
      fVar5 = 0.05f;
      fVar6 = 0.05f * 16f / 9f / fVar7;
    }
    if (fVar4 != *fParam5 || *fParam3 == 0f && *fParam4 == 0f ||
        gameplay::absf(fVar2 - *fParam3) < 0.04f &&
            gameplay::absf(fVar3 - *fParam4) < 0.04f) {
      graphics::draw_sprite("basejumping", "Arrow_Pointer", fVar2, fVar3, fVar6,
                            fVar5, fVar4, 240, 200, 80, 170, 0);
    }
    *fParam5 = fVar4;
  }
  *fParam3 = fVar2;
  *fParam4 = fVar3;
}

// Position - 0x1B9B6
void func_331(vector3 vParam0, float *fParam3, float *fParam4) {
  float fVar0;
  float fVar1;
  vector3 vVar2;

  if (!func_293(vParam0, 0f, 0f, 0f, 0)) {
    ui::_get_screen_coord_from_world_coord(vParam0, &fVar0, &fVar1);
  }
  if (fVar0 >= 0.5f) {
    vVar2.x = fVar0 - 0.5f;
  }
  else {
    vVar2.x = 0.5f - fVar0;
  }
  if (fVar1 >= 0.5f) {
    vVar2.y = fVar1 - 0.5f;
  }
  else {
    vVar2.y = 0.5f - fVar1;
  }
  vVar2.z = 0f;
  func_445(vVar2);
  vVar2.x *= 0.75f;
  vVar2.y *= 0.75f;
  if (fVar0 >= 0.5f) {
    fVar0 = 0.5f + vVar2.x;
  }
  else {
    fVar0 = 0.5f - vVar2.x;
  }
  if (fVar1 >= 0.5f) {
    fVar1 = 0.5f + vVar2.y;
  }
  else {
    fVar1 = 0.5f - vVar2.y;
  }
  *fParam3 = fVar0;
  *fParam4 = fVar1;
}

// Position - 0x1BA9D
int func_332(vector3 vParam0, int iParam3, int iParam4) {
  float fVar0;
  int iVar1;
  float fVar2;
  float fVar3;

  fVar0 = 100f;
  iVar1 = 50;
  if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
    fVar2 = gameplay::get_distance_between_coords(
        vParam0, entity::get_entity_coords(player::player_ped_id(), 1), 1);
    if (fVar2 > fVar0) {
      iVar1 = iParam4;
    }
    else {
      fVar3 = (fVar0 - fVar2) / fVar0;
      iVar1 = iParam4 - system::ceil(IntToFloat(iParam4 - iParam3) * fVar3);
    }
  }
  if (iVar1 < iParam3) {
    iVar1 = iParam3;
  }
  return iVar1;
}

// Position - 0x1BB09
void func_333(int *iParam0) {
  if (func_432(iParam0) && func_431(iParam0) > 7.5f) {
    func_428(iParam0);
  }
}

// Position - 0x1BB31
int func_334(var *uParam0, int iParam1, int *iParam2) {
  int iVar0;
  vector3 vVar1;
  vector3 vVar4;
  float fVar7;

  if (entity::is_entity_dead(player::player_ped_id(), 0)) {
    return 0;
  }
  if (ped::is_ped_in_flying_vehicle(player::player_ped_id())) {
    *iParam2 = 1;
    return 1;
  }
  vVar1 = {entity::get_entity_coords(player::player_ped_id(), 1)};
  if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
    iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 1);
    if (entity::is_entity_in_air(iVar0)) {
      return 0;
    }
    else if (!gameplay::get_ground_z_for_3d_coord(
                 entity::get_entity_coords(iVar0, 1), &fVar7, 0)) {
      return 0;
    }
    else if (vVar1.z >= fVar7 + 1.5f) {
      return 0;
    }
  }
  if (entity::is_entity_in_air(player::player_ped_id())) {
    return 0;
  }
  else if (!gameplay::get_ground_z_for_3d_coord(vVar1, &fVar7, 0)) {
    return 0;
  }
  else if (vVar1.z >= fVar7 + 1.5f) {
    return 0;
  }
  vVar4 = {func_344(uParam0, 0)};
  if (vVar1.z < vVar4.z + 5f) {
    *iParam2 = 1;
    return 1;
  }
  if (iParam1 == 5) {
    if (vVar1.z < 288f) {
      *iParam2 = 1;
      return 1;
    }
  }
  else if (iParam1 == 4) {
    if (vVar1.z < 305f) {
      *iParam2 = 1;
      return 1;
    }
  }
  else if (iParam1 == 8) {
    if (vVar1.z < 227f) {
      *iParam2 = 1;
      return 1;
    }
  }
  else if (iParam1 == 6 || iParam1 == 12) {
    if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
                       func_443(iParam1)) > 3600f) {
      *iParam2 = 1;
      return 1;
    }
  }
  return 0;
}

// Position - 0x1BCAC
int func_335() {
  if (cam::_0xEE778F8C7E1142E2(cam::_0x19CAFA3C87F7C2FF()) == 4) {
    return 1;
  }
  return 0;
}

// Position - 0x1BCC5
var func_336(var *uParam0) { return uParam0->f_84; }

// Position - 0x1BCD1
void func_337(int *iParam0, int iParam1) {
  int iVar0;
  int iVar1;
  vector3 vVar2;
  vector3 vVar5;
  float fVar8;

  if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
    return;
  }
  vVar2 = {entity::get_entity_coords(*iParam0, 1)};
  fVar8 = vehicle::_0x53AF99BAA671CA47(*iParam0);
  iVar1 = vehicle::get_ped_in_vehicle_seat(*iParam0, -1, 0);
  entity::freeze_entity_position(*iParam0, 0);
  ai::open_sequence_task(&iVar0);
  if (!iParam1) {
    ai::task_vehicle_mission_coors_target(
        0, *iParam0, entity::get_entity_coords(*iParam0, 1), 4, 0f, 786469, 2f,
        0f, 1);
  }
  ai::task_vehicle_mission_coors_target(
      0, *iParam0,
      vVar2 + FtoV(5f) * entity::get_entity_forward_vector(*iParam0) +
          Vector(20f, 0f, 0f),
      4, 0.3f * fVar8, 786469, 5f, 10f, 1);
  vVar5 = {FtoV(1000f) * entity::get_entity_forward_vector(*iParam0)};
  vVar5.z = 200f;
  ai::task_vehicle_mission_coors_target(0, *iParam0, vVar2 + vVar5, 4, fVar8,
                                        262144, 15f, 10f, 1);
  ai::close_sequence_task(iVar0);
  ai::clear_ped_tasks(iVar1);
  ai::task_perform_sequence(iVar1, iVar0);
  ai::clear_sequence_task(&iVar0);
}

// Position - 0x1BDC0
void func_338(int iParam0, int iParam1) {
  int iVar0;

  if (iParam1 < 1) {
    return;
  }
  if (Global_51564[iParam0 /*7*/].f_2) {
    return;
  }
  if (network::network_is_game_in_progress()) {
    return;
  }
  if (Global_51564[iParam0 /*7*/]) {
    stats::stat_get_int(Global_51564[iParam0 /*7*/].f_1, &iVar0, -1);
    iVar0 += iParam1;
    stats::stat_set_int(Global_51564[iParam0 /*7*/].f_1, iVar0, 1);
  }
}

// Position - 0x1BE1D
void func_339(int iParam0, int iParam1, int iParam2) {
  if (iParam0) {
    player::set_player_control(player::get_player_index(), 1, 0);
  }
  cutscene::_0xC61B86C9F61EB404(1);
  func_388(0, 1, iParam2, 0);
  if (iParam1) {
    ui::display_radar(1);
    ui::display_hud(1);
  }
  func_528(23, 0);
}

// Position - 0x1BE58
bool func_340(int iParam0) {
  switch (iParam0) {
  case joaat("bmx"):
  case joaat("scorcher"):
  case joaat("tribike"):
  case joaat("tribike2"):
  case joaat("tribike3"):
  case joaat("vader"):
  case joaat("akuma"):
  case joaat("bagger"):
  case joaat("ruffian"):
  case joaat("bati"):
  case joaat("bati2"):
  case joaat("blazer"):
  case joaat("blazer2"):
  case joaat("cruiser"):
  case joaat("hexer"):
  case joaat("nemesis"):
  case joaat("pcj"):
  case joaat("policeb"): return true;

  default:
  }
  return false;
}

// Position - 0x1BED8
int func_341(var *uParam0) { return *uParam0; }

// Position - 0x1BEE3
bool func_342(int iParam0) {
  switch (iParam0) {
  case joaat("freight"):
  case joaat("metrotrain"): return true;

  default:
  }
  return false;
}

// Position - 0x1BF03
int func_343(var *uParam0) { return uParam0->f_1; }

// Position - 0x1BF0F
Vector3 func_344(var *uParam0, int iParam1) {
  if (iParam1 < 0 || iParam1 >= 12) {
    return 0f, 0f, 0f;
  }
  return uParam0->f_12[iParam1 /*3*/];
}

// Position - 0x1BF39
Vector3 func_345(var *uParam0) { return uParam0->f_6; }

// Position - 0x1BF47
void func_346(int *iParam0) { func_39(iParam0, 0f); }

// Position - 0x1BF56
int func_347(int iParam0) { return system::shift_right(iParam0, 20) & 63; }

// Position - 0x1BF69
int func_348(int iParam0) { return system::shift_right(iParam0, 14) & 63; }

// Position - 0x1BF7C
int func_349(int iParam0) { return system::shift_right(iParam0, 9) & 31; }

// Position - 0x1BF8F
void func_350() {
  int iVar0;

  stats::leaderboards_clear_cache_data();
  iVar0 = 0;
  while (iVar0 < 5) {
    Global_1838575.f_81[iVar0] = 0;
    iVar0++;
  }
}

// Position - 0x1BFB8
void func_351() {
  struct<68> Var0;

  Global_1835013 = 0;
  Global_1835013.f_1 = 0;
  Global_1835013.f_2 = 0;
  Global_1835013.f_3 = 0;
  Global_1835013.f_4 = 0;
  func_352(&Global_1835013.f_73);
  func_352(&Global_1835013.f_142);
  func_352(&Global_1835013.f_211);
  func_352(&Global_1835013.f_280);
  StringCopy(&Global_1835013.f_349, "", 24);
  StringCopy(&Global_1835013.f_355, "", 24);
  func_126(&Global_1835013.f_361);
  Global_1835013.f_374 = -1;
  Global_1835388 = 0;
  Global_1835389 = 0;
  Var0.f_2.f_1 = 4;
  Global_1835013.f_5 = {Var0};
}

// Position - 0x1C05E
void func_352(var *uParam0) {
  int iVar0;

  *uParam0 = 0;
  uParam0->f_1 = 0;
  uParam0->f_2 = 0;
  iVar0 = 0;
  while (iVar0 < 32) {
    uParam0->f_3[iVar0] = 0f;
    uParam0->f_36[iVar0] = 0;
    iVar0++;
  }
}

// Position - 0x1C099
bool func_353(var *uParam0) { return uParam0->f_83; }

// Position - 0x1C0A5
bool func_354(var *uParam0, int iParam1, int *iParam2, var *uParam3,
              var *uParam4, int *iParam5, int *iParam6, int *iParam7,
              int *iParam8, int iParam9, int *iParam10, int *iParam11,
              var uParam12) {
  if (cam::is_cam_interpolating(func_403(uParam3, 1))) {
    func_346(iParam5);
  }
  if (!*iParam10) {
    if (func_432(iParam7) && func_431(iParam7) >= func_375(uParam0)) {
      func_337(iParam2, 0);
      func_428(iParam7);
      *iParam10 = 1;
    }
  }
  else if (vehicle::is_vehicle_driveable(*iParam2, 0)) {
    vehicle::set_heli_blades_speed(*iParam2, 0.7f);
  }
  if (func_432(iParam5) && func_431(iParam5) > 0.2f) {
    func_428(iParam5);
    func_428(iParam6);
    return true;
  }
  if (!func_432(iParam6)) {
    func_456(iParam6);
  }
  else if (uParam12 && cam::is_screen_faded_in() ||
           func_431(iParam6) > 0.5f && func_308(uParam4, 2)) {
    *iParam11 = 1;
    func_428(iParam5);
    func_428(iParam6);
    return true;
  }
  ui::hide_hud_component_this_frame(2);
  if (func_432(iParam8)) {
    if (func_436(iParam1) != 0) {
      func_428(iParam8);
    }
    else if (func_431(iParam8) > func_396(iParam1, iParam9)) {
      switch (iParam9) {
      case 0:
        ai::task_play_anim(player::player_ped_id(),
                           "amb@world_human_hiker_standing@male@idle_a",
                           "idle_a", 8f, -1.4f, -1, 48, 0, 0, 0, 0);
        break;

      case 1:
        ai::task_play_anim(player::player_ped_id(),
                           "amb@world_human_muscle_flex@arms_at_side@base",
                           "base", 8f, -1.4f, -1, 48, 0.681f, 0, 0, 0);
        break;

      case 2:
        ai::task_play_anim(player::player_ped_id(), "playidles_cold",
                           "blow_hands", 8f, -1.4f, -1, 48, 0.537f, 0, 0, 0);
        break;
      }
      func_428(iParam8);
    }
  }
  if (cam::is_screen_faded_in()) {
    func_355();
  }
  else {
    func_346(iParam6);
  }
  return false;
}

// Position - 0x1C266
void func_355() {
  struct<6> Var0;
  int iVar6;

  iVar6 = Global_101700.f_17926;
  func_356(Var0, 0, 0, 0, 0, iVar6);
}

// Position - 0x1C285
void func_356(struct<6> Param0, int iParam6, int iParam7, int iParam8,
              int iParam9, int iParam10) {
  float fVar0;
  int iVar1;
  int iVar2;
  int iVar3;
  struct<2> Var4;
  float fVar6;
  float fVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  var uVar11;
  int iVar12;

  if (Global_69956 != 6) {
    if (Global_69958 == -1) {
      if (func_370(1, Param0)) {
        if (Global_69959 == 3) {
          fVar0 = 1.5f;
        }
        else {
          fVar0 = 2.5f;
        }
        if (fLocal_21 > fVar0) {
          Global_69958 = gameplay::get_game_timer();
          vLocal_22 = {ui::get_hud_component_position(15)};
          fLocal_21 = 0f;
        }
        else {
          fLocal_21 += gameplay::get_frame_time();
        }
      }
      else {
        fLocal_21 = 0f;
      }
    }
    else {
      if (!func_370(0, Param0)) {
        Global_69958 = gameplay::get_game_timer() - 9000;
      }
      ui::hide_hud_component_this_frame(7);
      ui::hide_hud_component_this_frame(6);
      ui::hide_hud_component_this_frame(8);
      ui::hide_hud_component_this_frame(9);
      iVar1 = gameplay::get_game_timer() - Global_69958;
      if (iVar1 < 9000 && !cam::is_screen_faded_out()) {
        iVar2 = 255;
        if (iVar1 < 1000) {
          iVar2 = system::ceil(system::to_float(iVar1) / 1000f * 255f);
        }
        else {
          iVar3 = 9000 - iVar1;
          if (iVar3 < 1000) {
            iVar2 = system::ceil(system::to_float(iVar3) / 1000f * 255f);
          }
        }
        switch (Global_69956) {
        case 3:
        case 5:
          if (iParam6 == 1) {
            fVar6 = 0f;
            fVar7 = -0.07f;
          }
          else if (iParam7 == 1) {
            fVar6 = 0f;
            fVar7 = -0.077f;
          }
          else if (iParam8 == 1) {
            fVar6 = 0f;
            fVar7 = -0.05f;
          }
          else if (iParam9 == 1) {
            fVar6 = 0f;
            fVar7 = -0.035f;
          }
          else {
            fVar6 = 0f;
            fVar7 = -0.014f;
          }
          break;

        default:
          fVar6 = 0f;
          fVar7 = -0.014f;
          break;
        }
        graphics::_set_screen_draw_position(82, 66);
        ui::set_text_font(1);
        ui::set_text_justification(2);
        iVar12 = func_398();
        if (Global_69959 == 1 && Global_69957 == 62) {
          iVar12 = Global_101700.f_2095.f_539.f_3550;
        }
        switch (iVar12) {
        case 0:
          ui::get_hud_colour(143, &iVar8, &iVar9, &iVar10, &uVar11);
          break;

        case 1:
          ui::get_hud_colour(144, &iVar8, &iVar9, &iVar10, &uVar11);
          break;

        case 2:
          ui::get_hud_colour(145, &iVar8, &iVar9, &iVar10, &uVar11);
          break;

        default:
          iVar8 = 240;
          iVar9 = 200;
          iVar10 = 80;
        }
        ui::set_text_colour(iVar8, iVar9, iVar10, iVar2);
        ui::set_text_drop_shadow();
        Var4 = {func_359(Global_69957, Global_69959, iParam10)};
        if (fVar7 == -0.014f) {
        }
        graphics::_screen_draw_position_ratio(fVar6, fVar7, 0f, 0.01f);
        ui::set_text_scale(0.67f, 0.67f);
        if (!graphics::get_is_widescreen() && !graphics::get_is_hidef()) {
          fLocal_26 = 0.14f;
        }
        else {
          fLocal_26 = 0.17f;
        }
        if (fVar7 == -0.014f) {
          if (func_358(&Var4) > fLocal_26) {
            if (ui::is_hud_component_active(15)) {
              ui::set_hud_component_position(15, vLocal_22.x,
                                             vLocal_22.y + fLocal_25);
              Global_69961 = 1;
            }
          }
        }
        ui::begin_text_command_display_text(&Var4);
        ui::end_text_command_display_text(fVar6, fVar7, 0);
        graphics::_screen_draw_position_end();
        if (Global_69960 == 1) {
          func_357();
          fLocal_21 = 0f;
        }
      }
      else {
        func_357();
        fLocal_21 = 0f;
      }
    }
  }
}

// Position - 0x1C56A
void func_357() {
  if (Global_69956 != 6) {
  }
  if (Global_69961) {
    ui::reset_hud_component_values(15);
    Global_69961 = 0;
    Global_17290.f_7899 = 0;
  }
  Global_69956 = 6;
  Global_69958 = -1;
  Global_69957 = -1;
}

// Position - 0x1C5A2
float func_358(char *sParam0) {
  ui::_begin_text_command_width(sParam0);
  return ui::_end_text_command_get_width(1);
}

// Position - 0x1C5B5
struct<2> func_359(int iParam0, int iParam1, int iParam2) {
  struct<2> Var0;
  int iVar2;

  StringCopy(&Var0, "", 8);
  switch (iParam1) {
  case 1: Var0 = {func_369(iParam0)}; break;

  case 7: Var0 = {func_367(iParam0)}; break;

  case 3:
    iVar2 = iParam0;
    switch (iVar2) {
    case 0: Var0 = {func_366(iParam2)}; break;

    case 8: Var0 = {func_365(iParam2)}; break;

    case 7: Var0 = {func_364(iParam2)}; break;

    case 10: Var0 = {func_363(iParam2)}; break;

    case 5: Var0 = {func_362(iParam2)}; break;

    case 4: Var0 = {func_361(iParam2)}; break;

    default: StringCopy(&Var0, func_360(iVar2), 8); break;
    }
    break;

  default: break;
  }
  return Var0;
}

// Position - 0x1C68B
char *
func_360(int iParam0) {
  switch (iParam0) {
  case 0: return "MG_BJUM";

  case 1: return "MG_DART";

  case 2: return "MG_GOLF";

  case 3: return "MG_HUNT";

  case 4: return "MG_OFFR";

  case 5: return "MG_PILO";

  case 6: return "MG_RMPG";

  case 7: return "MG_SERA";

  case 8: return "MG_SRAC";

  case 9: return "MG_STRP";

  case 10: return "MG_STNT";

  case 11: return "MG_SHTR";

  case 12: return "MG_TAXI";

  case 13: return "MG_TENN";

  case 14: return "MG_TOWI";

  case 15: return "MG_TRFA";

  case 16: return "MG_TRFG";

  case 17: return "MG_TRIA";

  case 18: return "MG_YOGA";

  case 19: return "MG_CRCE";
  }
  return "INVALID!";
}

// Position - 0x1C7DE
struct<2> func_361(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "MGOR_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C811
struct<2>
func_362(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "MGFS_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C844
struct<2>
func_363(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "MGSP_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C877
struct<2>
func_364(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "MGSR_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C8AA
struct<2>
func_365(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2) || iParam0 == 3) {
  }
  else {
    StringCopy(&Var0, "MGCR_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C8E7
struct<2>
func_366(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  IntToString(&cVar2, iParam0, 8);
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "MGBJ_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C91A
struct<2>
func_367(int iParam0) {
  struct<2> Var0;
  char[] cVar2[8];

  StringCopy(&Var0, "", 8);
  cVar2 = {func_368(iParam0)};
  if (gameplay::is_string_null_or_empty(&cVar2)) {
  }
  else {
    StringCopy(&Var0, "RC_", 8);
    StringConCat(&Var0, &cVar2, 8);
  }
  return Var0;
}

// Position - 0x1C951
struct<2>
func_368(int iParam0) {
  struct<2> Var0;

  StringCopy(&Var0, "", 8);
  switch (iParam0) {
  case 0: StringCopy(&Var0, "ABI1", 8); break;

  case 1: StringCopy(&Var0, "ABI2", 8); break;

  case 2: StringCopy(&Var0, "BA1", 8); break;

  case 3: StringCopy(&Var0, "BA2", 8); break;

  case 4: StringCopy(&Var0, "BA3", 8); break;

  case 5: StringCopy(&Var0, "BA3A", 8); break;

  case 6: StringCopy(&Var0, "BA3C", 8); break;

  case 7: StringCopy(&Var0, "BA4", 8); break;

  case 8: StringCopy(&Var0, "DRE1", 8); break;

  case 9: StringCopy(&Var0, "EPS1", 8); break;

  case 10: StringCopy(&Var0, "EPS2", 8); break;

  case 11: StringCopy(&Var0, "EPS3", 8); break;

  case 12: StringCopy(&Var0, "EPS4", 8); break;

  case 13: StringCopy(&Var0, "EPS5", 8); break;

  case 14: StringCopy(&Var0, "EPS6", 8); break;

  case 15: StringCopy(&Var0, "EPS7", 8); break;

  case 16: StringCopy(&Var0, "EPS8", 8); break;

  case 17: StringCopy(&Var0, "EXT1", 8); break;

  case 18: StringCopy(&Var0, "EXT2", 8); break;

  case 19: StringCopy(&Var0, "EXT3", 8); break;

  case 20: StringCopy(&Var0, "EXT4", 8); break;

  case 21: StringCopy(&Var0, "FAN1", 8); break;

  case 22: StringCopy(&Var0, "FAN2", 8); break;

  case 23: StringCopy(&Var0, "FAN3", 8); break;

  case 24: StringCopy(&Var0, "HAO1", 8); break;

  case 25: StringCopy(&Var0, "HUN1", 8); break;

  case 26: StringCopy(&Var0, "HUN2", 8); break;

  case 27: StringCopy(&Var0, "JOS1", 8); break;

  case 28: StringCopy(&Var0, "JOS2", 8); break;

  case 29: StringCopy(&Var0, "JOS3", 8); break;

  case 30: StringCopy(&Var0, "JOS4", 8); break;

  case 31: StringCopy(&Var0, "MAU1", 8); break;

  case 32: StringCopy(&Var0, "MIN1", 8); break;

  case 33: StringCopy(&Var0, "MIN2", 8); break;

  case 34: StringCopy(&Var0, "MIN3", 8); break;

  case 35: StringCopy(&Var0, "MRS1", 8); break;

  case 36: StringCopy(&Var0, "MRS2", 8); break;

  case 37: StringCopy(&Var0, "NI1", 8); break;

  case 38: StringCopy(&Var0, "NI1A", 8); break;

  case 39: StringCopy(&Var0, "NI1B", 8); break;

  case 40: StringCopy(&Var0, "NI1C", 8); break;

  case 41: StringCopy(&Var0, "NI1D", 8); break;

  case 42: StringCopy(&Var0, "NI2", 8); break;

  case 43: StringCopy(&Var0, "NI3", 8); break;

  case 44: StringCopy(&Var0, "OME1", 8); break;

  case 45: StringCopy(&Var0, "OME2", 8); break;

  case 46: StringCopy(&Var0, "PA1", 8); break;

  case 47: StringCopy(&Var0, "PA2", 8); break;

  case 48: StringCopy(&Var0, "PA3", 8); break;

  case 49: StringCopy(&Var0, "PA3A", 8); break;

  case 50: StringCopy(&Var0, "PA3B", 8); break;

  case 51: StringCopy(&Var0, "PA4", 8); break;

  case 52: StringCopy(&Var0, "RAM1", 8); break;

  case 53: StringCopy(&Var0, "RAM2", 8); break;

  case 54: StringCopy(&Var0, "RAM3", 8); break;

  case 55: StringCopy(&Var0, "RAM4", 8); break;

  case 56: StringCopy(&Var0, "RAM5", 8); break;

  case 57: StringCopy(&Var0, "SAS1", 8); break;

  case 58: StringCopy(&Var0, "TON1", 8); break;

  case 59: StringCopy(&Var0, "TON2", 8); break;

  case 60: StringCopy(&Var0, "TON3", 8); break;

  case 61: StringCopy(&Var0, "TON4", 8); break;

  case 62: StringCopy(&Var0, "TON5", 8); break;

  default: break;
  }
  return Var0;
}

// Position - 0x1CD9D
struct<2>
func_369(int iParam0) {
  struct<2> Var0;

  StringCopy(&Var0, "M_", 8);
  StringConCat(&Var0, &Global_82612[iParam0 /*34*/].f_8, 8);
  if (iParam0 == 90) {
    switch (Global_101700.f_8044.f_99.f_205[7]) {
    case 1: StringConCat(&Var0, "A", 8); break;

    case 2: StringConCat(&Var0, "B", 8); break;

    default: StringConCat(&Var0, "A", 8); break;
    }
  }
  return Var0;
}

//Position - 0x1CE06
bool func_370(int iParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6)
{
  if (!func_372(0) || G_TextMessageConfig || Global_69960 == 1 ||
      !cam::is_screen_faded_in()) {
    return false;
  }
  switch (Global_69956) {
  case 0:
    if (gameplay::are_strings_equal(&uParam1, "NONE") ||
        gameplay::is_string_null_or_empty(&uParam1)) {
      Global_69956 = 3;
    }
    else {
      Global_69956 = 1;
    }
    break;

  case 1:
    if (cutscene::has_cutscene_loaded()) {
      Global_69956 = 2;
    }
    break;

  case 2:
    if (cutscene::is_cutscene_playing()) {
      Global_69956 = 4;
      return true;
    }
    else if (!cutscene::is_cutscene_active()) {
      Global_69956 = 3;
    }
    break;

  case 3:
    if (cutscene::is_cutscene_playing()) {
    }
    else {
      Global_69956 = 5;
      return true;
    }
    break;

  case 4:
    if (cutscene::is_cutscene_playing()) {
      return true;
    }
    else if (iParam0 == 1) {
      Global_69956 = 5;
    }
    break;

  case 5:
    if (cutscene::is_cutscene_playing() || func_30(0) || func_371(1)) {
    }
    else {
      return true;
    }
    break;
  }
  return false;
}

// Position - 0x1CF1E
bool func_371(int iParam0) {
  if (iParam0) {
    return Global_17151.f_4 && Global_17151.f_104 == 4;
  }
  return Global_17151.f_4;
}

// Position - 0x1CF47
int func_372(int iParam0) {
  if (Global_35781 == 15) {
    return 0;
  }
  if (func_373(iParam0)) {
    return 0;
  }
  return 1;
}

// Position - 0x1CF69
bool func_373(int iParam0) { return func_374(iParam0, Global_35781); }

// Position - 0x1CF7A
int func_374(int iParam0, int iParam1) {
  if (iParam1 == 15) {
    return 1;
  }
  if (iParam0 == 15) {
    return 0;
  }
  switch (iParam0) {
  case 16:
    switch (iParam1) {
    case 9:
    case 10:
    case 7:
    case 13:
    case 14: return 0;
    }
    return 1;

  case 0:
    switch (iParam1) {
    case 5:
    case 17: return 1;
    }
    break;

  case 2:
  case 3:
    switch (iParam1) {
    case 5:
    case 6:
    case 8:
    case 17: return 1;
    }
    break;

  case 4:
    if (iParam1 == 17) {
      return 1;
    }
    break;

  case 5: break;

  case 6:
  case 8:
    if (iParam1 == 5) {
      return 1;
    }
    break;

  case 7:
    if (iParam1 == 6) {
      return 1;
    }
    break;

  case 9:
    if (iParam1 == 5) {
      return 1;
    }
    break;

  case 10:
    switch (iParam1) {
    case 5:
    case 6:
    case 17: return 1;
    }
    break;

  case 11:
    if (iParam1 == 5) {
      return 1;
    }
    break;

  case 17:
    switch (iParam1) {
    case 17:
    case 12:
    case 5: return 1;
    }
    break;

  case 18:
  case 12:
    switch (iParam1) {
    case 5:
    case 6:
    case 8: return 1;
    }
    break;

  case 13:
    switch (iParam1) {
    case 5: return 1;
    }
    break;

  case 14:
    switch (iParam1) {
    case 5: return 1;
    }
    break;
  }
  return 0;
}

// Position - 0x1D15B
float func_375(var *uParam0) { return uParam0->f_80; }

// Position - 0x1D167
int func_376(var *uParam0, char *sParam1, char *sParam2, int iParam3,
             int iParam4, int iParam5, int iParam6) {
  func_385(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
  if (iParam3 > 7) {
    if (iParam3 < 12) {
      iParam3 = 7;
    }
  }
  Global_15752 = 0;
  Global_15754 = 0;
  Global_15759 = 0;
  Global_16736 = 0;
  Global_16738 = 0;
  Global_16742 = 0;
  Global_2621441 = 0;
  return func_377(sParam2, iParam3, 0);
}

// Position - 0x1D1B5
int func_377(char *sParam0, int iParam1, int iParam2) {
  Global_15746 = 0;
  if (Global_15745 == 0 || Global_15747 == 2) {
    if (Global_15745 != 0) {
      if (iParam1 > Global_15747) {
        if (Global_15752 == 0) {
          audio::stop_scripted_conversation(0);
          Global_14443.f_1 = 3;
          Global_15745 = 0;
          Global_15746 = 1;
          Global_15798 = 0;
          Global_15741 = 0;
          Global_15742 = 0;
          Global_15756 = 0;
          Global_15755 = 0;
          Global_14442 = 0;
        }
        else {
          func_384();
          return 0;
        }
      }
      else {
        return 0;
      }
    }
    if (audio::is_scripted_conversation_ongoing()) {
      return 0;
    }
    if (func_383(8, -1)) {
      return 0;
    }
    Global_15821 = {Global_15815};
    func_382();
    Global_15034 = {Global_15199};
    Global_15751 = Global_15752;
    Global_15758 = Global_15759;
    Global_2621442 = Global_2621441;
    Global_15760 = {Global_15776};
    Global_15753 = Global_15754;
    Global_16735 = Global_16736;
    Global_16743 = {Global_16749};
    Global_16737 = Global_16738;
    Global_16739 = Global_16740;
    Global_16741 = Global_16742;
    Global_15364.f_370 = Global_16734;
    Global_15364.f_368 = Global_16732;
    Global_15364.f_369 = Global_16733;
    Global_15741 = Global_15742;
    if (Global_15751) {
      gameplay::clear_bit(&G_SleepModeOnOn25, 20);
      gameplay::clear_bit(&G_SleepModeOffOn11, 17);
      gameplay::clear_bit(&Global_2315, 0);
      if (iParam2) {
        func_381();
        if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
          if (iParam1 == 13) {
          }
          else {
            return 0;
          }
        }
        if (Global_14443.f_1 > 3) {
          return 0;
        }
      }
      if (Global_14409 == 1) {
        return 0;
      }
      if (player::is_player_playing(player::player_id())) {
        if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
          return 0;
        }
        if (func_380()) {
          return 0;
        }
        if (ai::is_ped_sprinting(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_ragdoll(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
          return 0;
        }
        if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(),
                                               joaat("gadget_parachute"))) {
          return 0;
        }
        if (!Global_69702) {
          if (entity::is_entity_in_water(player::player_ped_id())) {
            return 0;
          }
          if (player::is_player_climbing(player::player_id())) {
            return 0;
          }
          if (ped::is_ped_planting_bomb(player::player_ped_id())) {
            return 0;
          }
          if (player::is_special_ability_active(player::player_id())) {
            return 0;
          }
        }
      }
      if (func_28()) {
        return 0;
      }
      else {
        switch (Global_14443.f_1) {
        case 7: return 0;

        case 8: return 0;

        case 9: break;

        case 10: break;

        default: break;
        }
        if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
          return 0;
        }
      }
      func_379();
      Global_15755 = iParam2;
    }
    Global_15747 = iParam1;
    StringCopy(&Global_15364, sParam0, 24);
    Global_14611 = 0;
    func_378();
    return 1;
  }
  if (Global_15745 == 5) {
    return 0;
  }
  if (iParam1 < Global_15747 || iParam1 == Global_15747) {
    return 0;
  }
  if (iParam1 == 2) {
  }
  else {
    func_384();
  }
  return 0;
}

// Position - 0x1D481
void func_378() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 69) {
    StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
    iVar0++;
  }
  audio::stop_scripted_conversation(0);
  Global_15745 = 1;
}

// Position - 0x1D4B2
void func_379() {
  Global_15798 = Global_15797;
  Global_15792 = Global_15793;
  Global_15839 = {Global_15827};
  Global_15845 = {Global_15833};
  Global_15800 = Global_15799;
  Global_15869 = {Global_15851};
  Global_15875 = {Global_15857};
  Global_15881 = {Global_15863};
  Global_15887 = {Global_15893};
  Global_1628 = Global_1629;
  Global_1630 = Global_1631;
  Global_15756 = Global_15757;
  Global_15758 = Global_15759;
  Global_15760 = {Global_15776};
  Global_15749 = Global_15750;
  Global_16761 = 0;
  Global_15794 = 0;
  Global_15795 = 0;
  gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x1D547
bool func_380() {
  int iVar0;
  int iVar1;

  if (Global_69702) {
    iVar0 = 0;
    weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
    if (player::is_player_playing(player::player_id())) {
      if (iVar1 == joaat("weapon_sniperrifle") ||
          iVar1 == joaat("weapon_heavysniper") ||
          iVar1 == joaat("weapon_remotesniper")) {
        iVar0 = 1;
      }
    }
    if (cam::is_aim_cam_active() && iVar0 == 1) {
      return true;
    }
    else {
      return false;
    }
  }
  if (player::is_player_playing(player::player_id())) {
    if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
      return true;
    }
    else {
      return false;
    }
  }
  return true;
}

// Position - 0x1D5E0
void func_381() {
  if (func_227(14)) {
    if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
      if (entity::get_entity_model(player::player_ped_id()) ==
          Global_101700.f_27009[0 /*29*/]) {
        Global_14443 = 0;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[1 /*29*/]) {
        Global_14443 = 1;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[2 /*29*/]) {
        Global_14443 = 2;
      }
      else {
        Global_14443 = 0;
      }
    }
  }
  else {
    Global_14443 = func_398();
    if (Global_14443 == 145) {
      Global_14443 = 3;
    }
    if (Global_69702) {
      Global_14443 = 3;
    }
    if (Global_14443 > 3) {
      Global_14443 = 3;
    }
  }
}

// Position - 0x1D682
void func_382() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 15) {
    Global_15034[iVar0 /*10*/] = 0;
    StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
    Global_15034[iVar0 /*10*/].f_7 = 0;
    Global_15034[iVar0 /*10*/].f_8 = 0;
    iVar0++;
  }
  Global_15034.f_161 = -99;
  Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x1D6D9
bool func_383(int iParam0, int iParam1) {
  switch (iParam0) {
  case 5:
    if (iParam1 > -1) {
      return Global_1353070.f_203[iParam1];
    }
    break;
  }
  return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x1D714
void func_384() {
  audio::restart_scripted_conversation();
  Global_16756 = 0;
  if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 ||
      Global_14442 == 1) {
    audio::stop_scripted_conversation(0);
    Global_15745 = 6;
    Global_14443.f_1 = 3;
    return;
  }
  if (audio::is_scripted_conversation_ongoing()) {
    audio::stop_scripted_conversation(1);
    Global_15745 = 6;
    return;
  }
}

// Position - 0x1D76B
void func_385(var *uParam0, int iParam1, char *sParam2, int iParam3,
              int iParam4, var uParam5) {
  Global_15199 = {*uParam0};
  Global_1629 = iParam1;
  StringCopy(&Global_15815, sParam2, 24);
  Global_16734 = uParam5;
  if (iParam3 == 0) {
    Global_16732 = 1;
    Global_16730 = 0;
  }
  else {
    Global_16732 = 0;
    Global_16730 = 1;
  }
  if (iParam4 == 0) {
    Global_16733 = 1;
    Global_16731 = 0;
  }
  else {
    Global_16733 = 0;
    Global_16731 = 1;
  }
}

// Position - 0x1D7C1
char *func_386(var *uParam0) { return uParam0->f_4; }

// Position - 0x1D7CD
void func_387(var *uParam0, var *uParam1, var *uParam2, var *uParam3,
              var *uParam4, int iParam5, var *uParam6, float *fParam7) {
  int iVar0;
  vector3 vVar1;
  vector3 vVar4;
  vector3 vVar7;

  iVar0 = func_403(uParam0, 0);
  if (entity::does_entity_exist(iParam5) &&
      !entity::is_entity_dead(iParam5, 0)) {
    *uParam2 = {10.2986f, 0f, 8.909f};
    *uParam4 = {FtoV(1.2f) *
                Vector(0f, -system::cos(-97.4239f + func_434(uParam1)),
                       system::sin(-97.4239f + func_434(uParam1)))};
    *uParam3 = {entity::get_offset_from_entity_in_world_coords(
        iParam5, 1.12046f, -0.317773f, 1.3385f)};
    vVar1 = {func_433(*uParam4, uParam2->f_2)};
    vVar7 = {*uParam3 + vVar1};
    *uParam6 = {-33f + *uParam2, 0f, -88.515f + func_434(uParam1)};
    *fParam7 = 26f;
    vVar4 = {*uParam6};
    vVar4.z += uParam2->f_2;
    cam::set_cam_coord(iVar0, vVar7);
    cam::set_cam_rot(iVar0, vVar4, 2);
    cam::set_cam_fov(iVar0, *fParam7);
    cam::set_cam_near_clip(iVar0, func_306());
  }
  cam::set_cam_active(iVar0, 1);
  cam::render_script_cams(1, 0, 3000, 1, 0, 0);
}

// Position - 0x1D8D8
void func_388(int iParam0, int iParam1, int iParam2, int iParam3) {
  if (iParam0) {
    player::special_ability_deactivate_fast(player::player_id());
    player::set_all_random_peds_flee(player::player_id(), 1);
    player::set_police_ignore_player(player::player_id(), 1);
    func_395(1);
    ui::_0xA8FDB297A8D25FBA();
    ui::_0xFDB423997FA30340();
    if (Global_14443.f_1 > 3) {
      if (audio::is_mobile_phone_call_ongoing()) {
        audio::stop_scripted_conversation(0);
      }
      if (!func_28()) {
        Global_14443.f_1 = 3;
      }
      Global_15745 = 5;
    }
    func_394(1, iParam3, iParam2, 0);
    Global_55828 = 1;
    Global_68134 = 1;
    G_DisableMessagesAndCalls1 = 1;
  }
  else {
    func_395(0);
    ui::_0xE1CD1E48E025E661();
    Global_55828 = 0;
    if (iParam1) {
      graphics::_0x03FC694AE06C5A20();
    }
    player::set_all_random_peds_flee(player::player_id(), 0);
    player::set_police_ignore_player(player::player_id(), 0);
    func_394(0, iParam3, iParam2, 0);
    if (network::network_is_game_in_progress()) {
      if (!ped::is_ped_injured(player::player_ped_id()) &&
          !func_392(player::player_id()) && !func_390(player::player_id(), 0) &&
          !func_389()) {
        entity::set_entity_invincible(player::player_ped_id(), 0);
      }
    }
    else if (!ped::is_ped_injured(player::player_ped_id()) &&
             !func_392(player::player_id())) {
      entity::set_entity_invincible(player::player_ped_id(), 0);
    }
    G_DisableMessagesAndCalls1 = 0;
  }
}

// Position - 0x1D9F1
bool func_389() {
  return gameplay::is_bit_set(
      Global_1591201[player::player_id() /*602*/].f_39.f_18, 14);
}

// Position - 0x1DA0E
bool func_390(int iParam0, int iParam1) {
  bool bVar0;

  if (iParam0 == player::player_id()) {
    bVar0 = func_391(-1, 0) == 8;
  }
  else {
    bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
  }
  if (iParam1 == 1) {
    if (network::network_is_player_active(iParam0)) {
      bVar0 = player::get_player_team(iParam0) == 8;
    }
  }
  return bVar0;
}

// Position - 0x1DA59
int func_391(int iParam0, int iParam1) {
  int iVar0;
  int iVar1;

  iVar1 = iParam0;
  if (iVar1 == -1) {
    iVar1 = func_235();
  }
  if (Global_1315213[iVar1] == 1) {
    if (iParam1) {
    }
    iVar0 = 8;
  }
  else {
    iVar0 = Global_1312729[iVar1];
    if (iParam1) {
    }
  }
  return iVar0;
}

// Position - 0x1DA9A
int func_392(int iParam0) {
  if (func_390(iParam0, 0)) {
    return 1;
  }
  if (func_393()) {
    if (iParam0 == player::player_id()) {
      return 1;
    }
  }
  if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
    return 1;
  }
  return 0;
}

// Position - 0x1DADC
bool func_393() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x1DAED
int func_394(int iParam0, int iParam1, var uParam2, int iParam3) {
  int iVar0;

  iVar0 = 0;
  if (gameplay::is_pc_version()) {
    if (cutscene::_0xA0FE76168A189DDB() != iParam0 && uParam2) {
      cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
      iVar0 = 1;
    }
  }
  return iVar0;
}

// Position - 0x1DB20
void func_395(int iParam0) {
  if (iParam0 == 1) {
    gameplay::set_bit(&G_SleepModeOnOn25, 13);
  }
  else {
    gameplay::clear_bit(&G_SleepModeOnOn25, 13);
  }
}

// Position - 0x1DB43
float func_396(int iParam0, int iParam1) {
  switch (iParam0) {
  case 3:
    switch (iParam1) {
    case 0: return 6f;

    case 1: return 7.3f;

    case 2: return 6.8f;

    default:
    }
    break;

  case 8:
    switch (iParam1) {
    case 0: return 4.2f;

    case 1: return 5.5f;

    case 2: return 5f;

    default:
    }
    break;

  case 5: return 0f;

  case 6: return 0f;

  case 12: return 0f;
  }
  return 0f;
}

// Position - 0x1DBDD
int func_397(int iParam0) {
  switch (iParam0) {
  case 5: return 3000;

  case 6: return 1500;

  case 12: return 2000;

  default:
  }
  return 0;
}

// Position - 0x1DC11
int func_398() {
  func_399();
  return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x1DC2A
void func_399() {
  int iVar0;

  if (entity::does_entity_exist(player::player_ped_id())) {
    if (func_35(Global_101700.f_2095.f_539.f_3549) !=
        entity::get_entity_model(player::player_ped_id())) {
      iVar0 = func_34(player::player_ped_id());
      if (func_36(iVar0) && (!func_227(14) || Global_100652)) {
        if (Global_101700.f_2095.f_539.f_3549 != iVar0 &&
            func_36(Global_101700.f_2095.f_539.f_3549)) {
          Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
        }
        Global_101700.f_2095.f_539.f_3551 = iVar0;
        Global_101700.f_2095.f_539.f_3549 = iVar0;
        return;
      }
    }
    else {
      if (Global_101700.f_2095.f_539.f_3549 != 145) {
        Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
      }
      return;
    }
  }
  Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x1DD27
var func_400(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
  return gameplay::get_heading_from_vector_2d(Param3 - Param0,
                                              Param3.f_1 - Param0.f_1);
}

// Position - 0x1DD41
bool func_401(vector3 vParam0) {
  if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
    return true;
  }
  return false;
}

// Position - 0x1DD6B
Vector3 func_402(int iParam0) {
  switch (iParam0) {
  case 5: return -120.0078f, -976.4348f, 295.2008f;

  case 6: return -1242.709f, 4539.658f, 185.6828f;

  case 12: return -768.0306f, 4330.409f, 147.6768f;

  default:
  }
  return 0f, 0f, 0f;
}

// Position - 0x1DDC5
int func_403(var *uParam0, int iParam1) {
  if (iParam1 >= 2) {
    return 0;
  }
  return (*uParam0)[iParam1];
}

// Position - 0x1DDDD
void func_404(int iParam0, int iParam1, int iParam2) {
  player::set_player_control(player::get_player_index(), 0, iParam0);
  if (!ped::is_ped_injured(player::player_ped_id())) {
    fire::stop_fire_in_range(
        entity::get_entity_coords(player::player_ped_id(), 1), 15f);
  }
  cutscene::_0xC61B86C9F61EB404(iParam1);
  func_27(0);
  func_388(1, 1, iParam2, 0);
  ui::display_radar(0);
  ui::display_hud(0);
  func_528(23, 1);
}

// Position - 0x1DE33
void func_405(var *uParam0, var *uParam1, var *uParam2, int *iParam3,
              int *iParam4, int *iParam5, int *iParam6, var *uParam7,
              int iParam8, int iParam9, int iParam10, int iParam11,
              var *uParam12, int iParam13, int iParam14) {
  int iVar0;
  int iVar1;
  vector3 vVar2;
  int iVar5;
  int iVar6;
  var uVar7;

  if (entity::is_entity_dead(player::player_ped_id(), 0)) {
    return;
  }
  if (func_401(func_427(uParam0))) {
  }
  else {
    vehicle::set_all_vehicle_generators_active_in_area(func_427(uParam0),
                                                       func_426(uParam0), 0, 1);
  }
  iVar5 = 0;
  while (iVar5 < 12) {
    if (!func_401(func_344(uParam0, iVar5))) {
      *uParam2 = iVar5 + 1;
    }
    else {
      iVar5 = 999999;
    }
    iVar5++;
  }
  player::set_player_control(player::player_id(), 0, 0);
  weapon::set_current_ped_weapon(player::player_ped_id(),
                                 joaat("weapon_unarmed"), 0);
  weapon::give_weapon_to_ped(player::player_ped_id(), joaat("gadget_parachute"),
                             1, 0, 0);
  entity::set_entity_invincible(player::player_ped_id(), 0);
  if (iParam13 == 4) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 320f && vVar2.z < 340f && vVar2.x > -103f &&
            vVar2.x < -45f && vVar2.y > -850f && vVar2.y < -787f) {
          entity::set_entity_coords(iVar1, -89.794f, -742.6727f, 43.7472f, 1, 0,
                                    0, 1);
          entity::set_entity_heading(iVar1, -109.33f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  else if (iParam13 == 3) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 689.4f && vVar2.z < 701.8875f && vVar2.x > 404.6f &&
            vVar2.x < 413.4f && vVar2.y > 5700.6f && vVar2.y < 5711.9f) {
          entity::set_entity_coords(iVar1, -215.2838f, 6543.57f, 10.0967f, 1, 0,
                                    0, 1);
          entity::set_entity_heading(iVar1, 145.5732f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  else if (iParam13 == 5) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 294.5f && vVar2.z < 298.9f && vVar2.x > -121.3f &&
            vVar2.x < -116.5f && vVar2.y > -978.1f && vVar2.y < -973.2f) {
          entity::set_entity_coords(iVar1, -118.1021f, -947.3954f, 27.3296f, 1,
                                    0, 0, 1);
          entity::set_entity_heading(iVar1, 341.9614f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  else if (iParam13 == 6) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 182.7f && vVar2.z < 202.7f && vVar2.x > -1252.7f &&
            vVar2.x < -1227.9f && vVar2.y > 4525.8f && vVar2.y < 4549.3f) {
          entity::set_entity_coords(iVar1, -1237.022f, 4559.404f, 185.9418f, 1,
                                    0, 0, 1);
          entity::set_entity_heading(iVar1, 172.2123f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  else if (iParam13 == 8) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 230f && vVar2.z < 244.5f && vVar2.x > -809.6f &&
            vVar2.x < -747.7f && vVar2.y > 310.6f && vVar2.y < 346.6f) {
          entity::set_entity_coords(iVar1, -1351.805f, 133.95f, 55.2558f, 1, 0,
                                    0, 1);
          entity::set_entity_heading(iVar1, 0.8373f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  else if (iParam13 == 12) {
    iVar1 = player::get_players_last_vehicle();
    if (entity::does_entity_exist(iVar1)) {
      if (entity::is_entity_dead(iVar1, 0)) {
        vehicle::delete_vehicle(&iVar1);
      }
      else {
        vVar2 = {entity::get_entity_coords(iVar1, 1)};
        if (vVar2.z > 143.6f && vVar2.z < 154.5f && vVar2.x > -777f &&
            vVar2.x < -758.9f && vVar2.y > 4328.3f && vVar2.y < 4344f) {
          entity::set_entity_coords(iVar1, -765.8775f, 4294.807f, 145.6581f, 1,
                                    0, 0, 1);
          entity::set_entity_heading(iVar1, 349.2306f);
          vehicle::set_vehicle_doors_shut(iVar1, 1);
        }
      }
    }
  }
  if (!ped::is_ped_injured(player::player_ped_id())) {
    player::set_player_control(player::player_id(), 0, 0);
    weapon::set_current_ped_weapon(player::player_ped_id(),
                                   joaat("weapon_unarmed"), 0);
    weapon::give_weapon_to_ped(player::player_ped_id(),
                               joaat("gadget_parachute"), 1, 0, 0);
  }
  iVar0 = func_436(iParam13);
  if (iVar0 != 0) {
    if (!entity::is_entity_dead(*iParam3, 0) ||
        entity::does_entity_exist(*iParam3)) {
      vehicle::set_vehicle_fixed(*iParam3);
      entity::set_entity_coords(*iParam3, func_443(iParam13), 1, 0, 0, 1);
      entity::set_entity_heading(*iParam3, func_434(uParam0));
    }
    else {
      *iParam3 = vehicle::create_vehicle(iVar0, func_443(iParam13),
                                         func_434(uParam0), 1, 1);
    }
    if (func_435(iVar0)) {
      if (!entity::does_entity_exist(*iParam8) ||
          entity::is_entity_dead(*iParam8, 0)) {
        *iParam8 =
            ped::create_ped_inside_vehicle(*iParam3, 26, iParam10, -1, 1, 1);
        ped::set_ped_helmet(*iParam8, 0);
        func_425(*iParam8, iParam13);
        entity::set_entity_invincible(*iParam8, 1);
      }
      cam::_0xF4C8CF9E353AFECA("SKY_DIVING_SHAKE", 0.15f);
      func_423(uParam1, *iParam8, func_424(iParam13));
      func_420(uParam1, player::player_ped_id(), func_422());
      vehicle::set_heli_blades_speed(*iParam3, 0.7f);
      entity::freeze_entity_position(*iParam3, 1);
      if (!ped::is_ped_injured(player::player_ped_id())) {
        if (!ped::is_ped_in_vehicle(player::player_ped_id(), *iParam3, 0)) {
          entity::detach_entity(player::player_ped_id(), 1, 1);
          entity::freeze_entity_position(player::player_ped_id(), 0);
          ped::set_ped_into_vehicle(player::player_ped_id(), *iParam3, 2);
        }
        else if (func_419(player::player_ped_id(), *iParam3) == 1) {
          entity::freeze_entity_position(player::player_ped_id(), 0);
          ped::set_ped_into_vehicle(player::player_ped_id(), *iParam3, 2);
        }
      }
      if (!entity::is_entity_dead(*iParam3, 0)) {
        *iParam14 = ped::create_synchronized_scene(0f, 0f, 0f, 0f, 0f, 0f, 2);
        ped::attach_synchronized_scene_to_entity(
            *iParam14, *iParam3,
            entity::get_entity_bone_index_by_name(*iParam3, "Chassis"));
        ai::task_synchronized_scene(player::player_ped_id(), *iParam14,
                                    "oddjobs@basejump@", "Heli_door_loop", 4f,
                                    -4f, 65, 0, 1148846080, 0);
        ped::set_synchronized_scene_looped(*iParam14, 1);
      }
      func_456(uParam12);
    }
    else if (func_340(iVar0)) {
      func_420(uParam1, player::player_ped_id(), func_422());
      entity::freeze_entity_position(player::player_ped_id(), 0);
      ped::set_ped_into_vehicle(player::player_ped_id(), *iParam3, -1);
      ped::give_ped_helmet(player::player_ped_id(), 0, 4096, -1);
      func_456(uParam12);
    }
  }
  else {
    func_420(uParam1, player::player_ped_id(), func_422());
    if (func_353(uParam0)) {
      if (!ped::is_ped_injured(player::player_ped_id()) &&
          (ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
           ped::is_ped_on_vehicle(player::player_ped_id()))) {
        ped::_0xF9ACF4A08098EA25(player::player_ped_id(), 1);
      }
      entity::set_entity_coords(player::player_ped_id(), func_443(iParam13), 1,
                                0, 0, 1);
      entity::set_entity_heading(player::player_ped_id(), func_434(uParam0));
      ai::task_stand_still(player::player_ped_id(), -1);
      if (entity::does_entity_exist(*iParam3)) {
        iVar6 = -1;
        while (iVar6 <=
               vehicle::get_vehicle_max_number_of_passengers(*iParam3) - 1) {
          if (!vehicle::is_vehicle_seat_free(*iParam3, iVar6, 0)) {
            uVar7 = vehicle::get_ped_in_vehicle_seat(*iParam3, iVar6, 0);
            ped::delete_ped(&uVar7);
          }
          iVar6++;
        }
        vehicle::delete_vehicle(iParam3);
      }
    }
  }
  ped::set_ped_reset_flag(player::player_ped_id(), 177, 1);
  ped::set_ped_config_flag(player::player_ped_id(), 36, 1);
  if (func_501(uParam0) != 0) {
    func_415(uParam0, iParam5, iParam13);
  }
  if (func_414(uParam0) != 0) {
    func_411(uParam0, uParam7);
  }
  iVar0 = func_343(uParam0);
  if (func_342(iVar0)) {
    vehicle::delete_all_trains();
    vehicle::set_random_trains(0);
  }
  else if (iVar0 != 0) {
    gameplay::clear_area(func_344(uParam0, 0), 100f, 1, 0, 0, 0);
    if (entity::does_entity_exist(*uParam4) &&
        entity::is_entity_dead(*uParam4, 0)) {
      vehicle::delete_vehicle(uParam4);
    }
    if (!entity::does_entity_exist(*iParam4)) {
      *iParam4 = vehicle::create_vehicle(iVar0, func_344(uParam0, 0),
                                         func_410(uParam0), 1, 1);
      if (func_409(func_343(uParam0))) {
        vehicle::set_vehicle_colour_combination(*iParam4, 11);
      }
      else if (func_408(func_343(uParam0))) {
        vehicle::set_vehicle_extra(*iParam4, 1, 1);
        vehicle::set_vehicle_colour_combination(*iParam4, 6);
        vehicle::set_vehicle_lights(*iParam4, 2);
        vehicle::_0xBC3CCA5844452B06(200f);
        entity::set_entity_lod_dist(*iParam4, 1000);
      }
      entity::set_entity_load_collision_flag(*iParam4, 1);
    }
    else if (!entity::is_entity_dead(*iParam4, 0)) {
      vehicle::set_vehicle_fixed(*iParam4);
      entity::set_entity_coords(*iParam4, func_344(uParam0, 0), 1, 0, 0, 1);
      entity::set_entity_heading(*iParam4, func_410(uParam0));
    }
    if (func_409(func_343(uParam0))) {
      if (entity::does_entity_exist(*uParam6) &&
          entity::is_entity_dead(*uParam6, 0)) {
        vehicle::delete_vehicle(uParam6);
      }
      if (!entity::does_entity_exist(*iParam6)) {
        *iParam6 = vehicle::create_vehicle(
            joaat("trflat"),
            entity::get_offset_from_entity_in_world_coords(*iParam4, 0f, -10f,
                                                           0f),
            func_410(uParam0), 1, 1);
        entity::set_entity_load_collision_flag(*iParam6, 1);
        entity::set_entity_lod_dist(*iParam6, 2000);
      }
      else if (!entity::is_entity_dead(*iParam6, 0)) {
        vehicle::set_vehicle_fixed(*iParam6);
      }
      if (!vehicle::is_vehicle_attached_to_trailer(*iParam4)) {
        vehicle::attach_vehicle_to_trailer(*iParam4, *iParam6, 1065353216);
      }
    }
    if (entity::does_entity_exist(*uParam9) &&
        entity::is_entity_dead(*uParam9, 0)) {
      ped::delete_ped(uParam9);
    }
    if (!entity::does_entity_exist(*iParam9)) {
      *iParam9 =
          ped::create_ped_inside_vehicle(*iParam4, 26, iParam11, -1, 1, 1);
      entity::set_entity_as_mission_entity(*iParam9, 1, 0);
      ped::set_blocking_of_non_temporary_events(*iParam9, 1);
      func_407(*iParam9, iParam13);
      if (iParam13 == 0) {
        func_406(uParam1, 2, *iParam9, "EX3MERC1", 0, 1);
      }
    }
    else {
      entity::set_entity_health(*iParam9,
                                entity::get_entity_max_health(*iParam9));
      ped::reset_ped_visible_damage(*iParam9);
      ai::clear_ped_tasks(*iParam9);
      if (!ped::is_ped_in_vehicle(*iParam9, *iParam4, 0) ||
          vehicle::get_ped_in_vehicle_seat(*iParam4, -1, 0) != *iParam9) {
        if (ped::is_ped_in_any_vehicle(*iParam9, 1)) {
          ped::_0xF9ACF4A08098EA25(*iParam9, 1);
        }
        ped::set_ped_into_vehicle(*iParam9, *iParam4, -1);
      }
    }
    entity::set_entity_load_collision_flag(*iParam9, 1);
  }
  if (func_398() == 0) {
    ped::set_ped_component_variation(player::player_ped_id(), 9, 5, 0, 0);
  }
  else if (func_398() == 1) {
    ped::set_ped_component_variation(player::player_ped_id(), 8, 1, 0, 0);
  }
  else if (func_398() == 2) {
    ped::set_ped_component_variation(player::player_ped_id(), 8, 3, 0, 0);
  }
}

// Position - 0x1E8DF
void func_406(var *uParam0, int iParam1, int iParam2, char *sParam3,
              int iParam4, int iParam5) {
  if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
  }
  (*uParam0)[iParam1 /*10*/] = iParam2;
  StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
  (*uParam0)[iParam1 /*10*/].f_7 = 1;
  (*uParam0)[iParam1 /*10*/].f_8 = iParam4;
  (*uParam0)[iParam1 /*10*/].f_9 = iParam5;
  if (!Global_69702) {
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
        ped::set_ped_can_play_ambient_anims(iParam2, 0);
      }
      else {
        ped::set_ped_can_play_ambient_anims(iParam2, 1);
      }
    }
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
      }
      else {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
      }
    }
  }
}

// Position - 0x1E97A
void func_407(int iParam0, int iParam1) {
  if (entity::is_entity_dead(iParam0, 0)) {
    return;
  }
  switch (iParam1) {
  case 0:
    ped::set_ped_component_variation(iParam0, 0, 1, 0, 0);
    ped::set_ped_component_variation(iParam0, 3, 0, 0, 0);
    ped::set_ped_component_variation(iParam0, 4, 0, 2, 0);
    ped::clear_ped_prop(iParam0, 0);
    ped::set_ped_prop_index(iParam0, 1, 1, 0, 0);
    break;

  case 5:
    ped::set_ped_component_variation(iParam0, 0, 0, 1, 0);
    ped::set_ped_component_variation(iParam0, 2, 0, 1, 0);
    ped::set_ped_component_variation(iParam0, 3, 1, 2, 0);
    ped::set_ped_component_variation(iParam0, 4, 1, 1, 0);
    ped::clear_ped_prop(iParam0, 0);
    ped::clear_ped_prop(iParam0, 1);
    break;

  case 7:
    ped::set_ped_component_variation(iParam0, 0, 0, 1, 0);
    ped::set_ped_component_variation(iParam0, 3, 0, 2, 0);
    ped::set_ped_component_variation(iParam0, 4, 0, 2, 0);
    ped::set_ped_component_variation(iParam0, 8, 0, 1, 0);
    ped::set_ped_prop_index(iParam0, 0, 0, 2, 0);
    break;
  }
}

// Position - 0x1EA49
bool func_408(int iParam0) {
  switch (iParam0) {
  case joaat("seashark"):
  case joaat("seashark2"):
  case joaat("dinghy"):
  case joaat("jetmax"):
  case joaat("marquis"):
  case joaat("squalo"):
  case joaat("suntrap"):
  case joaat("tropic"):
  case joaat("predator"): return true;

  default:
  }
  return false;
}

// Position - 0x1EA93
bool func_409(int iParam0) {
  switch (iParam0) {
  case joaat("hauler"):
  case joaat("biff"):
  case joaat("packer"):
  case joaat("trash"):
  case joaat("benson"):
  case joaat("phantom"):
  case joaat("pounder"): return true;

  default:
  }
  return false;
}

// Position - 0x1EAD1
var func_410(var *uParam0) { return uParam0->f_77; }

// Position - 0x1EADD
void func_411(var *uParam0, int *iParam1) {
  if (!entity::does_entity_exist(*uParam1)) {
    *uParam1 = vehicle::create_vehicle(func_414(uParam0), func_413(uParam0),
                                       func_412(uParam0), 1, 1);
  }
  else if (entity::is_entity_dead(*uParam1, 0)) {
    vehicle::delete_vehicle(uParam1);
    *iParam1 = vehicle::create_vehicle(func_414(uParam0), func_413(uParam0),
                                       func_412(uParam0), 1, 1);
  }
  else {
    vehicle::set_vehicle_fixed(*iParam1);
  }
}

// Position - 0x1EB44
var func_412(var *uParam0) { return uParam0->f_79; }

// Position - 0x1EB50
Vector3 func_413(var *uParam0) { return uParam0->f_9; }

// Position - 0x1EB5E
int func_414(var *uParam0) { return uParam0->f_3; }

// Position - 0x1EB6A
void func_415(var *uParam0, int *iParam1, int iParam2) {
  int iVar0;
  int iVar1;
  int iVar2;

  if (entity::does_entity_exist(*iParam1)) {
    if (!func_301(*iParam1) &&
        entity::does_entity_exist(
            vehicle::get_ped_in_vehicle_seat(*iParam1, -1, 0))) {
      iVar1 = vehicle::get_ped_in_vehicle_seat(*iParam1, -1, 0);
    }
    iVar2 = *iParam1;
  }
  iVar0 = func_418(iParam2);
  if (iVar0 != 0) {
    if (!entity::does_entity_exist(iVar2)) {
      iVar2 = vehicle::create_vehicle(func_501(uParam0), func_417(uParam0),
                                      func_416(uParam0), 1, 1);
    }
    else {
      entity::set_entity_coords(iVar2, func_417(uParam0), 1, 0, 0, 1);
      entity::set_entity_heading(iVar2, func_416(uParam0));
    }
    entity::freeze_entity_position(iVar2, 1);
    if (!entity::does_entity_exist(iVar1)) {
      iVar1 = ped::create_ped_inside_vehicle(iVar2, 26, iVar0, -1, 1, 1);
    }
    ped::set_ped_helmet(iVar1, 0);
    func_425(iVar1, iParam2);
  }
  else {
    if (!entity::does_entity_exist(iVar2)) {
      iVar2 = vehicle::create_vehicle(func_501(uParam0), func_417(uParam0),
                                      func_416(uParam0), 1, 1);
    }
    else {
      entity::set_entity_coords(iVar2, func_417(uParam0), 1, 0, 0, 1);
      entity::set_entity_heading(iVar2, func_416(uParam0));
    }
    entity::freeze_entity_position(iVar2, 1);
    if (!entity::does_entity_exist(iVar1)) {
      iVar1 = ped::create_ped_inside_vehicle(iVar2, 26, joaat("s_m_y_pilot_01"),
                                             -1, 1, 1);
    }
    ped::set_ped_helmet(iVar1, 0);
    ped::set_ped_prop_index(iVar1, 0, 2, 0, 0);
    ped::set_ped_prop_index(iVar1, 1, 0, 0, 0);
  }
  vehicle::set_vehicle_engine_on(iVar2, 1, 1, 0);
  vehicle::set_heli_blades_speed(iVar2, 0.7f);
  ai::clear_ped_tasks(iVar1);
  ai::task_stand_still(iVar1, -1);
  *iParam1 = iVar2;
}

// Position - 0x1ECD3
var func_416(var *uParam0) { return uParam0->f_78; }

// Position - 0x1ECDF
Vector3 func_417(var *uParam0) { return uParam0->f_70; }

// Position - 0x1ECED
int func_418(int iParam0) {
  switch (iParam0) {
  case 0: return joaat("s_m_y_pilot_01");

  case 1: return joaat("s_m_y_pilot_01");

  case 2: return joaat("s_m_y_pilot_01");

  case 3: return joaat("s_m_y_pilot_01");

  case 7: return joaat("a_m_y_hippy_01");

  case 9: return joaat("s_m_y_pilot_01");

  case 10: return joaat("s_m_y_pilot_01");

  case 11: return joaat("a_m_m_genfat_02");

  default:
  }
  return 0;
}

// Position - 0x1ED6D
int func_419(int iParam0, int iParam1) {
  if (!entity::is_entity_dead(iParam0, 0) &&
      !entity::is_entity_dead(iParam1, 0)) {
    if (ped::is_ped_sitting_in_vehicle(iParam0, iParam1)) {
      if (vehicle::get_ped_in_vehicle_seat(iParam1, -1, 0) == iParam0) {
        return -1;
      }
      if (vehicle::get_ped_in_vehicle_seat(iParam1, 0, 0) == iParam0) {
        return 0;
      }
      if (vehicle::get_ped_in_vehicle_seat(iParam1, 1, 0) == iParam0) {
        return 1;
      }
      if (vehicle::get_ped_in_vehicle_seat(iParam1, 2, 0) == iParam0) {
        return 2;
      }
    }
  }
  return -2;
}

// Position - 0x1EDDF
void func_420(var *uParam0, int iParam1, char *sParam2) {
  int iVar0;

  iVar0 = func_421();
  if (!ped::is_ped_injured(iParam1)) {
    func_406(uParam0, iVar0, iParam1, sParam2, 1, 1);
  }
  else {
    func_406(uParam0, iVar0, 0, sParam2, 0, 1);
  }
}

// Position - 0x1EE15
int func_421() {
  if (func_398() == 1) {
    return 2;
  }
  if (func_398() == 2) {
    return 3;
  }
  return 1;
}

// Position - 0x1EE3C
char *func_422() {
  int iVar0;

  iVar0 = func_34(player::player_ped_id());
  switch (iVar0) {
  case 0: return "MICHAEL";

  case 2: return "TREVOR";

  case 1: return "FRANKLIN";

  default:
  }
  return "";
}

// Position - 0x1EE7F
void func_423(var *uParam0, int iParam1, char *sParam2) {
  int iVar0;

  iVar0 = 0;
  if (!ped::is_ped_injured(iParam1)) {
    func_406(uParam0, iVar0, iParam1, sParam2, 1, 1);
  }
  else {
    func_406(uParam0, iVar0, 0, sParam2, 0, 1);
  }
}

// Position - 0x1EEB2
char *func_424(int iParam0) { return "EXT1HELIPILOT"; }

// Position - 0x1EEBE
void func_425(int iParam0, int iParam1) {
  if (entity::is_entity_dead(iParam0, 0)) {
    return;
  }
  switch (iParam1) {
  case 7:
    ped::set_ped_component_variation(iParam0, 0, 0, 1, 0);
    ped::set_ped_component_variation(iParam0, 2, 1, 0, 0);
    ped::set_ped_component_variation(iParam0, 3, 0, 0, 0);
    ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
    ped::set_ped_component_variation(iParam0, 8, 1, 0, 0);
    ped::set_ped_prop_index(iParam0, 1, 0, 0, 0);
    break;

  case 11:
    ped::set_ped_component_variation(iParam0, 0, 1, 0, 0);
    ped::set_ped_component_variation(iParam0, 2, 2, 0, 0);
    ped::set_ped_component_variation(iParam0, 3, 1, 0, 0);
    ped::set_ped_component_variation(iParam0, 4, 0, 2, 0);
    ped::set_ped_prop_index(iParam0, 0, 1, 2, 0);
    ped::set_ped_prop_index(iParam0, 1, 1, 0, 0);
    break;
  }
}

// Position - 0x1EF65
Vector3 func_426(var *uParam0) { return uParam0->f_67; }

// Position - 0x1EF73
Vector3 func_427(var *uParam0) { return uParam0->f_64; }

// Position - 0x1EF81
void func_428(int *iParam0) {
  iParam0->f_1 = 0f;
  iParam0->f_2 = 0f;
  *iParam0 = 0;
}

// Position - 0x1EF97
bool func_429(var *uParam0, var *uParam1, var *uParam2, int iParam3,
              int iParam4, bool bParam5) {
  char cVar0[64];

  if (!func_435(func_436(iParam3))) {
    streaming::request_additional_collision_at_coord(func_443(iParam3));
  }
  if (func_432(uParam1)) {
    if (func_431(uParam1) >= 5f) {
      return true;
    }
  }
  else {
    func_317(uParam1, 0f);
  }
  if (cam::is_screen_faded_out()) {
    if (!streaming::is_new_load_scene_loaded()) {
      return false;
    }
  }
  if (func_435(func_436(iParam3))) {
    if (!streaming::has_anim_dict_loaded("veh@helicopter@rps@base")) {
      return false;
    }
  }
  if (func_396(iParam3, 0) > 0f) {
    switch (iParam4) {
    case 0:
      StringCopy(&cVar0, "amb@world_human_hiker_standing@male@idle_a", 64);
      break;

    case 1:
      StringCopy(&cVar0, "amb@world_human_muscle_flex@arms_at_side@base", 64);
      break;

    case 2: StringCopy(&cVar0, "playidles_cold", 64); break;
    }
    if (!streaming::has_anim_dict_loaded(&cVar0)) {
      return false;
    }
  }
  if (func_430(uParam0)) {
    if (graphics::has_scaleform_movie_loaded(*uParam2)) {
      if (ui::has_additional_text_loaded(2)) {
        if (graphics::has_streamed_texture_dict_loaded("basejumping")) {
          if (streaming::has_anim_dict_loaded("oddjobs@basejump@") &&
              streaming::has_anim_dict_loaded("skydive@freefall") &&
              streaming::has_anim_dict_loaded("skydive@parachute@chute") &&
              streaming::has_anim_dict_loaded("skydive@parachute@")) {
            if (ped::can_create_random_ped(0)) {
              if (!bParam5 || cam::is_screen_faded_out()) {
                return true;
              }
            }
          }
        }
      }
    }
  }
  return false;
}

// Position - 0x1F0CE
bool func_430(var *uParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if ((*uParam0)[iVar0] != 0) {
      if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
        if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
        }
        return false;
      }
    }
    iVar0++;
  }
  return true;
}

// Position - 0x1F115
float func_431(int *iParam0) {
  if (func_432(iParam0)) {
    if (func_329(iParam0)) {
      return iParam0->f_2;
    }
    else {
      return func_40(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
    }
  }
  return iParam0->f_1;
}

// Position - 0x1F154
bool func_432(int *iParam0) { return gameplay::is_bit_set(*iParam0, 1); }

// Position - 0x1F164
Vector3 func_433(vector3 vParam0, float fParam3) {
  vector3 vVar0;
  float fVar3;
  float fVar4;

  fVar3 = system::sin(fParam3);
  fVar4 = system::cos(fParam3);
  vVar0.x = vParam0.x * fVar4 - vParam0.y * fVar3;
  vVar0.y = vParam0.x * fVar3 + vParam0.y * fVar4;
  vVar0.z = vParam0.z;
  return vVar0;
}

// Position - 0x1F1A8
float func_434(var *uParam0) { return uParam0->f_76; }

// Position - 0x1F1B4
bool func_435(int iParam0) {
  switch (iParam0) {
  case joaat("annihilator"):
  case joaat("buzzard"):
  case joaat("buzzard2"):
  case joaat("cargobob"):
  case joaat("cargobob2"):
  case joaat("frogger"):
  case joaat("maverick"):
  case joaat("polmav"):
  case joaat("skylift"): return true;

  default:
  }
  return false;
}

// Position - 0x1F1FE
int func_436(int iParam0) {
  switch (iParam0) {
  case 0:
  case 1:
  case 2:
  case 7:
  case 9:
  case 10:
  case 11: return joaat("maverick");

  case 4: return joaat("bati");
  }
  return 0;
}

// Position - 0x1F254
void func_437(var *uParam0, int iParam1, var *uParam2, int *iParam3,
              int *iParam4, var *uParam5, var *uParam6) {
  int iVar0;
  int iVar1;

  func_26(1);
  audio::set_frontend_radio_active(0);
  if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
    ped::set_ped_lod_multiplier(player::player_ped_id(), 2f);
  }
  switch (iParam1) {
  case 0:
    ped::add_scenario_blocking_area(-901.2005f, 4422.489f, 19.3471f, -906.842f,
                                    4424.97f, 300.017f, 0, 1, 1, 1);
    break;

  case 1: break;

  case 2: break;

  case 3: break;

  case 4: break;

  case 5: break;

  case 6: break;

  case 7: break;

  case 8: func_442(1, 1); break;

  case 9: break;

  case 10: break;

  case 11: break;

  case 12: break;
  }
  if (cam::is_screen_faded_out()) {
    gameplay::clear_area(func_443(iParam1), 5000f, 1, 0, 0, 0);
  }
  ui::request_additional_text("BJUMP", 2);
  iVar0 = func_436(iParam1);
  if (iVar0 != 0) {
    if (func_435(iVar0)) {
      streaming::request_anim_dict("veh@helicopter@rps@base");
      *iParam3 = func_418(iParam1);
      func_440(uParam2, *iParam3);
    }
    func_440(uParam2, iVar0);
  }
  if (func_501(uParam0) != 0) {
    func_440(uParam2, func_501(uParam0));
    if (func_418(iParam1) != 0) {
      func_440(uParam2, func_418(iParam1));
    }
    else {
      func_440(uParam2, joaat("s_m_y_pilot_01"));
    }
  }
  iVar1 = func_343(uParam0);
  if (iVar1 != 0) {
    *iParam4 = func_439(iParam1);
    func_440(uParam2, *iParam4);
    func_440(uParam2, iVar1);
    func_440(uParam2, joaat("trflat"));
  }
  if (func_342(iVar1)) {
    func_440(uParam2, joaat("freight"));
    func_440(uParam2, joaat("freightcar"));
    func_440(uParam2, joaat("freightgrain"));
    func_440(uParam2, joaat("freightcont1"));
    func_440(uParam2, joaat("freightcont2"));
    func_440(uParam2, joaat("tankercar"));
    func_440(uParam2, joaat("metrotrain"));
  }
  if (func_414(uParam0) != 0) {
    func_440(uParam2, func_414(uParam0));
  }
  *uParam5 = func_158();
  func_438(uParam2);
  streaming::request_anim_dict("oddjobs@basejump@");
  streaming::request_anim_dict("skydive@freefall");
  streaming::request_anim_dict("skydive@parachute@chute");
  streaming::request_anim_dict("skydive@parachute@");
  graphics::request_streamed_texture_dict("basejumping", 0);
  if (func_396(iParam1, 0) > 0f) {
    *uParam6 = gameplay::get_random_int_in_range(0, 2);
    switch (*uParam6) {
    case 0:
      streaming::request_anim_dict(
          "amb@world_human_hiker_standing@male@idle_a");
      break;

    case 1:
      streaming::request_anim_dict(
          "amb@world_human_muscle_flex@arms_at_side@base");
      break;
    }
  }
  if (func_436(iParam1) == 0) {
    streaming::request_additional_collision_at_coord(func_443(iParam1));
  }
}

// Position - 0x1F4EF
void func_438(var *uParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if ((*uParam0)[iVar0] != 0) {
      streaming::request_model((*uParam0)[iVar0]);
    }
    iVar0++;
  }
}

// Position - 0x1F51F
int func_439(int iParam0) {
  switch (iParam0) {
  case 0: return joaat("a_m_y_beach_01");

  case 5: return joaat("s_m_m_trucker_01");

  case 7: return joaat("a_m_y_beach_01");

  default:
  }
  return 0;
}

// Position - 0x1F559
int func_440(var *uParam0, int iParam1) {
  int iVar0;
  int iVar1;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if ((*uParam0)[iVar0] != 0) {
      if ((*uParam0)[iVar0] == iParam1) {
        return 0;
      }
    }
    iVar0++;
  }
  iVar1 = func_441(uParam0);
  if (iVar1 < 0 || iVar1 >= *uParam0) {
    return 0;
  }
  (*uParam0)[iVar1] = iParam1;
  return 1;
}

// Position - 0x1F5B6
int func_441(var *uParam0) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < *uParam0) {
    if ((*uParam0)[iVar0] == 0) {
      return iVar0;
    }
    iVar0++;
  }
  return -1;
}

// Position - 0x1F5E2
void func_442(int iParam0, int iParam1) {
  gameplay::set_bit(&Global_25347, iParam0);
  StringCopy(&Global_25348[iParam0 /*6*/], script::get_this_script_name(), 24);
  Global_25403[iParam0] = iParam1;
}

// Position - 0x1F609
Vector3 func_443(int iParam0) {
  switch (iParam0) {
  case 0: return -1152.053f, -1857.884f, 204.0663f;

  case 1: return 885.114f, -437.352f, 529.867f;

  case 2: return 2034.912f, 1971.051f, 582.7461f;

  case 3: return 409.7498f, 5703.525f, 695.17f;

  case 4: return -74.9632f, -827.4467f, 324.9521f;

  case 5: return -117.6998f, -975.571f, 295f;

  case 6: return -1243.784f, 4534.163f, 184.8471f;

  case 7: return -359.1f, 4119.5f, 304.1f;

  case 8: return -807.073f, 330.8846f, 232.6766f;

  case 9: return -1286.99f, 3668.922f, 1072.466f;

  case 10: return 1018.441f, 3956.706f, 1354f;

  case 11: return 1627.196f, -421.7584f, 1321.484f;

  case 12: return -766.5999f, 4334.805f, 147.1205f;

  default:
  }
  return 0f, 0f, 0f;
}

// Position - 0x1F753
bool func_444(int iParam0) {
  if (cam::is_screen_faded_out()) {
    if (entity::is_entity_at_coord(player::player_ped_id(), func_443(iParam0),
                                   15f, 15f, 15f, 0, 1, 0)) {
      return true;
    }
    entity::set_entity_coords(player::player_ped_id(), func_443(iParam0), 0, 0,
                              0, 1);
    if (entity::is_entity_at_coord(player::player_ped_id(), func_443(iParam0),
                                   15f, 15f, 15f, 0, 1, 0)) {
      return true;
    }
  }
  return false;
}

// Position - 0x1F7C3
Vector3 func_445(vector3 vParam0) {
  float fVar0;
  float fVar1;

  fVar0 = system::vmag(vParam0);
  if (fVar0 != 0f) {
    fVar1 = 1f / fVar0;
    vParam0 = {vParam0 * FtoV(fVar1)};
  }
  else {
    vParam0.x = 0f;
    vParam0.y = 0f;
    vParam0.z = 0f;
  }
  return vParam0;
}

// Position - 0x1F802
Vector3 func_446(int iParam0) {
  switch (iParam0) {
  case 0: return -21.7965f, -0.0328f, 70.0438f;

  case 1: return -26.5541f, 0.0092f, -86.4416f;

  case 2: return -11.2825f, 0.0213f, 148.5283f;

  case 3: return -39.935f, 0f, 12.8174f;

  case 4: return 0.9749f, 0f, -5.2236f;

  case 5: return -12.889f, 0f, 1.6227f;

  case 6: return -48.5605f, 0f, 160.4909f;

  case 7: return -37.0509f, 0.0324f, 24.0288f;

  case 8: return -17.4118f, 0f, 117.7175f;

  case 9: return -15.4633f, 0.0328f, -5.1142f;

  case 10: return -20.9567f, 0f, 170.5743f;

  case 11: return 1.9344f, 0f, -55.2084f;

  case 12: return -46.0342f, 0f, 37.5935f;

  default:
  }
  return 0f, 0f, 0f;
}

// Position - 0x1F92C
void func_447(var *uParam0, var *uParam1, int iParam2, int iParam3) {
  vector3 vVar0;
  vector3 vVar3;
  float fVar6;
  vector3 vVar7;

  vVar0 = {func_455(uParam1)};
  vVar3 = {func_454(uParam1)};
  fVar6 = func_453(uParam1);
  if (!cam::does_cam_exist(func_403(uParam0, 0))) {
    func_452(uParam0, 0,
             cam::create_camera_with_params(26379945, vVar0, vVar3, 65f, 0, 2),
             1);
  }
  else {
    cam::set_cam_coord(func_403(uParam0, 0), vVar0);
    cam::set_cam_rot(func_403(uParam0, 0), vVar3, 2);
  }
  cam::set_cam_fov(func_403(uParam0, 0), fVar6);
  cam::set_cam_active(func_403(uParam0, 0), 1);
  if (iParam3) {
    vVar7 = {vVar0};
    vVar7.z += 8f;
    cam::set_cam_params(func_403(uParam0, 0), vVar7, vVar3, fVar6,
                        func_451(iParam2), 1, 1, 2);
  }
  vVar0 = {func_450(uParam1)};
  vVar3 = {func_449(uParam1)};
  fVar6 = func_448(uParam1);
  if (!cam::does_cam_exist(func_403(uParam0, 1))) {
    func_452(uParam0, 1,
             cam::create_camera_with_params(26379945, vVar0, vVar3, 65f, 0, 2),
             1);
  }
  else {
    cam::set_cam_coord(func_403(uParam0, 1), vVar0);
    cam::set_cam_rot(func_403(uParam0, 1), vVar3, 2);
  }
  cam::set_cam_fov(func_403(uParam0, 1), fVar6);
  if (!cam::is_screen_faded_out()) {
    cam::set_cam_active_with_interp(func_403(uParam0, 1), func_403(uParam0, 0),
                                    func_451(iParam2), 1, 1);
  }
  cam::render_script_cams(1, 0, 3000, 1, 0, 0);
  cam::_0xF4C8CF9E353AFECA("HAND_SHAKE", 0.2f);
  ui::display_radar(0);
  ui::display_hud(0);
}

// Position - 0x1FAB2
var func_448(var *uParam0) { return uParam0->f_82; }

// Position - 0x1FABE
Vector3 func_449(var *uParam0) { return uParam0->f_58; }

// Position - 0x1FACC
Vector3 func_450(var *uParam0) { return uParam0->f_55; }

// Position - 0x1FADA
int func_451(int iParam0) {
  switch (iParam0) {
  case 5:
  case 6:
  case 12: return 6000;
  }
  return 10000;
}

// Position - 0x1FB07
void func_452(var *uParam0, int iParam1, int iParam2, int iParam3) {
  if (iParam1 >= 2) {
    return;
  }
  if (iParam3 && !cam::does_cam_exist(iParam2)) {
    return;
  }
  (*uParam0)[iParam1] = iParam2;
}

// Position - 0x1FB34
var func_453(var *uParam0) { return uParam0->f_81; }

// Position - 0x1FB40
Vector3 func_454(var *uParam0) { return uParam0->f_52; }

// Position - 0x1FB4E
Vector3 func_455(var *uParam0) { return uParam0->f_49; }

// Position - 0x1FB5C
void func_456(int *iParam0) {
  if (!func_432(iParam0)) {
    func_346(iParam0);
  }
}

// Position - 0x1FB74
void func_457(vector3 vParam0, float fParam3, int iParam4) {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < 68) {
    if (func_283(&Global_68531.f_555[0 /*21*/], iVar0)) {
      if (gameplay::get_distance_between_coords(
              vParam0, Global_68531.f_555[0 /*21*/], iParam4) <= fParam3) {
        func_458(iVar0);
      }
    }
    iVar0++;
  }
}

// Position - 0x1FBC4
void func_458(int iParam0) {
  bool bVar0;

  if (iParam0 == -1) {
    return;
  }
  if (func_283(&Global_68531.f_555[0 /*21*/], iParam0)) {
    if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
      bVar0 = true;
      if (!ped::is_ped_injured(player::player_ped_id())) {
        if (vehicle::is_vehicle_driveable(Global_68531.f_139[iParam0], 0)) {
          if (ped::is_ped_in_vehicle(player::player_ped_id(),
                                     Global_68531.f_139[iParam0], 0)) {
            bVar0 = false;
          }
        }
      }
      if (bVar0) {
        entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
        vehicle::delete_vehicle(&Global_68531.f_139[iParam0]);
      }
    }
    Global_68531[iParam0] = 1;
    if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
      if (iParam0 == 24 && func_289(iParam0, 0) && Global_69440.f_66 == 0 &&
          Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] !=
              0 &&
          Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] > 3 &&
          (!func_459(0, Global_68531.f_555[0 /*21*/].f_12) ||
           !func_459(1, Global_68531.f_555[0 /*21*/].f_12))) {
        func_290(&Global_101700.f_31389
                      .f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/],
                 &Global_69440);
        Global_69518 = Global_101700.f_31389.f_5591;
      }
      func_287(iParam0, 0);
    }
  }
}

// Position - 0x1FD36
int func_459(int iParam0, int iParam1) {
  int iVar0;

  switch (iParam1) {
  case 0: iVar0 = 0; break;

  case 1: iVar0 = 1; break;

  case 2: iVar0 = 2; break;
  }
  if (iParam0 < 0 ||
      iParam0 >= func_460(&Global_101700.f_31389.f_5038[iVar0 /*157*/])) {
    return 0;
  }
  return func_267(
      Global_101700.f_31389.f_5038[iVar0 /*157*/][iParam0 /*78*/].f_66, 0);
}

// Position - 0x1FDA8
int func_460(var *uParam0) { return *uParam0; }

// Position - 0x1FDB3
void func_461(char *sParam0, int iParam1) {
  int iVar0;
  int iVar1;

  if (Global_100342 && iParam1) {
    if (func_312(sParam0) && !ui::is_help_message_fading_out()) {
      ui::clear_help(0);
    }
  }
  iVar0 = 0;
  while (iVar0 < Global_101700.f_19369.f_145) {
    if (gameplay::are_strings_equal(sParam0,
                                    &Global_101700.f_19369[iVar0 /*16*/])) {
      iVar1 = iVar0;
      while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
        func_464(iVar1, iVar1 + 1);
        iVar1++;
      }
      func_463(Global_101700.f_19369.f_145 - 1);
      Global_101700.f_19369.f_145--;
      func_462();
      return;
    }
    iVar0++;
  }
}

// Position - 0x1FE60
void func_462() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 < 3) {
    Global_101700.f_19369.f_146[iVar0] = 0;
    iVar0++;
  }
  iVar0 = 0;
  while (iVar0 < Global_101700.f_19369.f_145) {
    if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
      if (Global_101700.f_19369[iVar0 /*16*/].f_12 >
          Global_101700.f_19369.f_146[0]) {
        Global_101700.f_19369.f_146[0] =
            Global_101700.f_19369[iVar0 /*16*/].f_12;
      }
    }
    if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
      if (Global_101700.f_19369[iVar0 /*16*/].f_12 >
          Global_101700.f_19369.f_146[1]) {
        Global_101700.f_19369.f_146[1] =
            Global_101700.f_19369[iVar0 /*16*/].f_12;
      }
    }
    if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
      if (Global_101700.f_19369[iVar0 /*16*/].f_12 >
          Global_101700.f_19369.f_146[2]) {
        Global_101700.f_19369.f_146[2] =
            Global_101700.f_19369[iVar0 /*16*/].f_12;
      }
    }
    iVar0++;
  }
}

// Position - 0x1FF80
void func_463(int iParam0) {
  StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
  StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
  Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
  Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
  Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0x2001C
void func_464(int iParam0, int iParam1) {
  Global_101700.f_19369[iParam0 /*16*/] = {
      Global_101700.f_19369[iParam1 /*16*/]};
  Global_101700.f_19369[iParam0 /*16*/].f_4 = {
      Global_101700.f_19369[iParam1 /*16*/].f_4};
  Global_101700.f_19369[iParam0 /*16*/].f_8 =
      Global_101700.f_19369[iParam1 /*16*/].f_8;
  Global_101700.f_19369[iParam0 /*16*/].f_10 =
      Global_101700.f_19369[iParam1 /*16*/].f_10;
  Global_101700.f_19369[iParam0 /*16*/].f_9 =
      Global_101700.f_19369[iParam1 /*16*/].f_9;
  Global_101700.f_19369[iParam0 /*16*/].f_11 =
      Global_101700.f_19369[iParam1 /*16*/].f_11;
  Global_101700.f_19369[iParam0 /*16*/].f_12 =
      Global_101700.f_19369[iParam1 /*16*/].f_12;
  Global_101700.f_19369[iParam0 /*16*/].f_13 =
      Global_101700.f_19369[iParam1 /*16*/].f_13;
  Global_101700.f_19369[iParam0 /*16*/].f_14 =
      Global_101700.f_19369[iParam1 /*16*/].f_14;
  Global_101700.f_19369[iParam0 /*16*/].f_15 =
      Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0x2012C
void func_465(int iParam0) {
  if (iParam0) {
    gameplay::set_fade_in_after_death_arrest(0);
    gameplay::_disable_automatic_respawn(1);
    gameplay::set_fade_out_after_death(0);
    func_17(1);
    Global_87082 = 1;
  }
  else {
    gameplay::set_fade_in_after_death_arrest(1);
    gameplay::_disable_automatic_respawn(0);
    gameplay::set_fade_out_after_death(1);
    func_17(0);
    Global_87082 = 0;
  }
}

// Position - 0x2016E
void func_466() { func_467(&uLocal_177); }

// Position - 0x2017C
void func_467(var *uParam0) {
  if (uParam0->f_4 != 0) {
    func_140(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
  }
  if ((*uParam0)[0] != 0 || (*uParam0)[1] != 0 || (*uParam0)[2] != 0) {
    func_471(uParam0);
    func_470(uParam0);
    func_114(&Global_1839721);
  }
  if (Global_1835390.f_2708 != 0 || Global_1835390.f_3184) {
    func_468();
  }
  if (audio::is_audio_scene_active("LEADERBOARD_SCENE")) {
    audio::stop_audio_scene("LEADERBOARD_SCENE");
  }
  if (network::network_is_signed_online()) {
    func_86(&Global_1840922.f_49);
  }
  Global_2494199.f_3829 = 0;
}

// Position - 0x2021D
void func_468() {
  int iVar0;
  int iVar1;
  struct<75> Var2;

  Var2.f_60 = 6;
  Var2.f_67 = 6;
  iVar0 = 0;
  while (iVar0 < 3) {
    iVar1 = 0;
    while (iVar1 < 12) {
      Global_1835390[iVar0 /*901*/][iVar1 /*75*/] = {Var2};
      iVar1++;
    }
    Global_1835390.f_2704[iVar0] = 0;
    iVar0++;
  }
  Global_1835390.f_2708 = 0;
  Global_1835390.f_2709 = 0;
  iVar0 = 0;
  iVar0 = 0;
  while (iVar0 < 6) {
    Global_1835390.f_2710[iVar0] = 0;
    StringCopy(&Global_1835390.f_2717[iVar0 /*6*/], "", 24);
    Global_1835390.f_2754[iVar0] = 0;
    Global_1835390.f_2761[iVar0] = 0;
    iVar0++;
  }
  Global_1835390.f_2768 = 0;
  Global_1835390.f_2769 = 0;
  Global_1835390.f_2770 = 0;
  iVar0 = 0;
  iVar0 = 0;
  while (iVar0 < 3) {
    Global_1835390.f_2771[iVar0] = 0;
    Global_1835390.f_2775[iVar0] = 0;
    iVar0++;
  }
  Global_1835390.f_2779 = 0;
  func_469(&Global_1835390.f_2780);
  func_86(&Global_1835390.f_2823);
  Global_1835390.f_2825 = -1;
  Global_1835390.f_2826 = 0;
  func_86(&Global_1835390.f_2827);
  Global_1835390.f_2829 = 0;
  func_86(&Global_1835390.f_2830);
  Global_1835390.f_2832 = 0;
  Global_1835390.f_2780.f_28 = 0;
  Global_1835390.f_2780.f_27 = 0;
  Global_1835390.f_3184 = 0;
}

// Position - 0x20388
void func_469(var *uParam0) {
  int iVar0;

  *uParam0 = 0;
  StringCopy(&uParam0->f_1, "", 32);
  StringCopy(&uParam0->f_9, "", 64);
  uParam0->f_25 = 1;
  uParam0->f_26 = 0;
  uParam0->f_27 = 0;
  uParam0->f_28 = 0;
  iVar0 = 0;
  while (iVar0 < 6) {
    uParam0->f_29[iVar0] = 0;
    uParam0->f_36[iVar0] = 0;
    iVar0++;
  }
}

// Position - 0x203DE
void func_470(var *uParam0) {
  int iVar0;
  struct<13> Var1;

  uParam0->f_246 = 0;
  uParam0->f_246.f_1 = -1;
  uParam0->f_246.f_2 = 0;
  func_86(&uParam0->f_246.f_3);
  uParam0->f_246.f_5 = 0;
  iVar0 = 0;
  while (iVar0 < 12) {
    uParam0->f_246.f_6[iVar0 /*15*/] = -1;
    uParam0->f_246.f_6[iVar0 /*15*/].f_1 = 0;
    uParam0->f_246.f_6[iVar0 /*15*/].f_2 = {Var1};
    iVar0++;
  }
  iVar0 = 0;
  while (iVar0 < 3) {
    uParam0->f_246.f_187[iVar0] = 0;
    iVar0++;
  }
}

// Position - 0x20466
void func_471(var *uParam0) {
  int iVar0;
  struct<35> Var1;

  (*uParam0)[0] = 0;
  (*uParam0)[1] = 0;
  (*uParam0)[2] = 0;
  uParam0->f_4 = 0;
  uParam0->f_6 = 0;
  uParam0->f_7 = {Var1};
  uParam0->f_42 = 0;
  uParam0->f_43 = 0;
  uParam0->f_44 = 0;
  uParam0->f_44.f_1 = 0;
  uParam0->f_44.f_2 = 0;
  uParam0->f_44.f_3 = 0;
  iVar0 = 0;
  while (iVar0 < 4) {
    StringCopy(&uParam0->f_44.f_3.f_1[iVar0 /*16*/], "", 32);
    StringCopy(&uParam0->f_44.f_3.f_1[iVar0 /*16*/].f_8, "", 32);
    iVar0++;
  }
  uParam0->f_113[0 /*66*/] = 0;
  iVar0 = 0;
  while (iVar0 < 4) {
    StringCopy(&uParam0->f_113[0 /*66*/].f_1[iVar0 /*16*/], "", 32);
    StringCopy(&uParam0->f_113[0 /*66*/].f_1[iVar0 /*16*/].f_8, "", 32);
    iVar0++;
  }
}

// Position - 0x20530
void func_472() { Global_17151.f_5 = 1; }

// Position - 0x2053E
void func_473(var *uParam0, int iParam1, int iParam2, bool bParam3) {
  int iVar0;

  if (iParam1 < 11) {
    if (!func_239(uParam0, 19)) {
      if (iParam1 == 4 && !bParam3 &&
          (cam::is_screen_faded_in() || cam::is_screen_fading_in())) {
        if (func_475(func_476(iParam2, 19), "", &uParam0->f_602, 19)) {
        }
      }
    }
    if (!func_239(uParam0, 20)) {
      if (iParam1 > 4) {
        if (func_475(func_476(iParam2, 20), func_476(iParam2, 19),
                     &uParam0->f_602, 20)) {
        }
      }
    }
    else if (!func_239(uParam0, 21)) {
      if (iParam1 == 9) {
        if (func_475(func_476(iParam2, 21), func_476(iParam2, 20),
                     &uParam0->f_602, 21)) {
        }
      }
      else if (iParam1 == 8) {
        if (func_475(func_476(iParam2, 21), func_476(iParam2, 20),
                     &uParam0->f_602, 21)) {
        }
      }
    }
    else if (!func_239(uParam0, 22)) {
      if (iParam1 == 9) {
        iVar0 = ped::get_ped_parachute_state(player::player_ped_id());
        if (iVar0 == 1 || iVar0 == 2) {
          if (func_475(func_476(iParam2, 22), func_476(iParam2, 21),
                       &uParam0->f_602, 22)) {
          }
        }
      }
    }
    else if (iParam1 == 10 && !func_239(uParam0, 23)) {
      func_474(func_476(iParam2, 22), &uParam0->f_602, 23);
    }
    else if (!func_239(uParam0, 23) &&
             !player::is_player_playing(player::player_id())) {
      audio::stop_audio_scenes();
    }
  }
}

// Position - 0x206BC
void func_474(char *sParam0, int *iParam1, int iParam2) {
  if (!gameplay::is_bit_set(*iParam1, iParam2)) {
    audio::stop_audio_scene(sParam0);
    gameplay::set_bit(iParam1, iParam2);
  }
}

// Position - 0x206DF
bool func_475(char *sParam0, char *sParam1, int *iParam2, int iParam3) {
  if (!gameplay::is_string_null_or_empty(sParam1)) {
    if (audio::is_audio_scene_active(sParam1)) {
      audio::stop_audio_scene(sParam1);
    }
  }
  if (!gameplay::is_bit_set(*iParam2, iParam3)) {
    if (audio::start_audio_scene(sParam0)) {
      gameplay::set_bit(iParam2, iParam3);
      return true;
    }
  }
  else {
    return true;
  }
  return false;
}

// Position - 0x20730
char *func_476(int iParam0, int iParam1) {
  char *sVar0;

  sVar0 = "";
  switch (iParam1) {
  case 19: return "BASEJUMPS_OVERVIEW_CUTSCENE";

  case 20:
    if (func_435(func_436(iParam0))) {
      sVar0 = "BASEJUMPS_PREP_FOR_JUMP_HELI";
    }
    else if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
             func_340(entity::get_entity_model(
                 ped::get_vehicle_ped_is_in(player::player_ped_id(), 0)))) {
      sVar0 = "BASEJUMPS_PREP_FOR_JUMP_MOTO";
    }
    else {
      sVar0 = "BASEJUMPS_PREP_FOR_JUMP_ON_FOOT";
    }
    return sVar0;

  case 21: return "BASEJUMPS_SKYDIVE";

  case 22: return "BASEJUMPS_OPEN_PARACHUTE";

  default:
  }
  return "";
}

// Position - 0x207C0
void func_477(var *uParam0, int iParam1) {
  if (iParam1 < 11) {
    if (!func_239(uParam0, 15)) {
      if (iParam1 >= 4 &&
          (cam::is_screen_faded_in() || cam::is_screen_fading_in())) {
        if (func_479(func_480(11), &uParam0->f_602, 11)) {
          func_478(func_480(15), &uParam0->f_602, 15);
        }
      }
    }
    else if (!func_239(uParam0, 16)) {
      if (iParam1 == 9) {
        if (func_479(func_480(12), &uParam0->f_602, 12)) {
          func_478(func_480(16), &uParam0->f_602, 16);
        }
      }
      else if (iParam1 == 8) {
        if (func_479(func_480(12), &uParam0->f_602, 12)) {
          func_478(func_480(16), &uParam0->f_602, 16);
        }
      }
    }
    else if (iParam1 == 10 && !func_239(uParam0, 17)) {
      if (func_479(func_480(13), &uParam0->f_602, 13)) {
        func_478(func_480(17), &uParam0->f_602, 17);
      }
    }
  }
}

// Position - 0x208C6
int func_478(char *sParam0, int *iParam1, int iParam2) {
  if (!gameplay::is_bit_set(*iParam1, iParam2)) {
    if (audio::prepare_music_event(sParam0)) {
      if (audio::trigger_music_event(sParam0)) {
        gameplay::set_bit(iParam1, iParam2);
        return 1;
      }
    }
  }
  else {
    return 1;
  }
  return 0;
}

// Position - 0x20907
bool func_479(char *sParam0, int *iParam1, int iParam2) {
  if (!gameplay::is_bit_set(*iParam1, iParam2)) {
    if (audio::prepare_music_event(sParam0)) {
      gameplay::set_bit(iParam1, iParam2);
      return true;
    }
  }
  else {
    return true;
  }
  return false;
}

// Position - 0x20939
char *func_480(int iParam0) {
  switch (iParam0) {
  case 15:
  case 11: return "OJBJ_START";

  case 16:
  case 12: return "OJBJ_JUMPED";

  case 17:
  case 13: return "OJBJ_LANDED";

  case 18:
  case 14: return "OJBJ_STOP";

  default:
  }
  return "";
}

// Position - 0x20997
void func_481(var *uParam0) {
  struct<2> Var0;
  var *uVar3;
  var *uVar4;
  int iVar5;
  int iVar6;

  controls::_disable_input_group(0);
  controls::_disable_input_group(2);
  func_488(&uVar3, &uVar4, &iVar5, &iVar6,
           player::is_player_control_on(player::player_id()),
           controls::_is_input_disabled(2));
  Var0 = system::to_float(iVar5) / 128f;
  Var0.f_1 = system::to_float(iVar6) / -128f;
  func_485(uParam0, Var0, Var0.f_1);
  func_484(uParam0);
  if (controls::is_control_pressed(2, 224)) {
    func_483(uParam0, 0, 1);
  }
  if (controls::is_control_pressed(0, 22) ||
      controls::is_disabled_control_pressed(0, 22)) {
    func_483(uParam0, 1, 1);
  }
  if (func_482()) {
    func_483(uParam0, 2, 1);
  }
  if (controls::is_disabled_control_pressed(2, 22)) {
    func_483(uParam0, 3, 1);
  }
  if (controls::is_control_pressed(2, 216)) {
    func_483(uParam0, 4, 1);
  }
  if (controls::is_control_pressed(2, 215) ||
      controls::is_disabled_control_pressed(2, 200)) {
    func_483(uParam0, 5, 1);
  }
  if (controls::is_control_pressed(2, 201)) {
    func_483(uParam0, 6, 1);
  }
  if (controls::is_control_pressed(2, 202)) {
    func_483(uParam0, 7, 1);
  }
  if (controls::is_control_pressed(2, 211)) {
    func_483(uParam0, 8, 1);
  }
}

// Position - 0x20AAC
bool func_482() {
  if (ui::is_pause_menu_active()) {
    return false;
  }
  if (controls::is_control_pressed(0, 18) ||
      controls::is_control_pressed(2, 18)) {
    return true;
  }
  return false;
}

// Position - 0x20ADE
void func_483(var *uParam0, int iParam1, int iParam2) {
  if (iParam2) {
    gameplay::set_bit(&uParam0->f_2, iParam1);
  }
  else {
    gameplay::clear_bit(&uParam0->f_2, iParam1);
  }
}

// Position - 0x20B02
void func_484(var *uParam0) {
  uParam0->f_3 = uParam0->f_2;
  uParam0->f_2 = 0;
}

// Position - 0x20B17
void func_485(var *uParam0, var uParam1, var uParam2) {
  func_487(uParam0, uParam1);
  func_486(uParam0, uParam2);
}

// Position - 0x20B2F
void func_486(var *uParam0, var uParam1) { uParam0->f_1 = uParam1; }

// Position - 0x20B3D
void func_487(var *uParam0, var uParam1) { *uParam0 = uParam1; }

// Position - 0x20B4A
void func_488(var *uParam0, var *uParam1, var *uParam2, var *uParam3,
              bool bParam4, int iParam5) {
  float fVar0;
  float fVar1;
  float fVar2;
  float fVar3;

  if (iParam5 == 0) {
    if (bParam4) {
      fVar0 = controls::get_control_normal(0, 218);
      fVar1 = controls::get_control_normal(0, 219);
      fVar2 = controls::get_control_normal(0, 220);
      fVar3 = controls::get_control_normal(0, 221);
    }
    else {
      fVar0 = controls::get_disabled_control_normal(0, 218);
      fVar1 = controls::get_disabled_control_normal(0, 219);
      fVar2 = controls::get_disabled_control_normal(0, 220);
      fVar3 = controls::get_disabled_control_normal(0, 221);
    }
  }
  else if (bParam4) {
    fVar0 = controls::_0x5B84D09CEC5209C5(0, 218);
    fVar1 = controls::_0x5B84D09CEC5209C5(0, 219);
    fVar2 = controls::_0x5B84D09CEC5209C5(0, 220);
    fVar3 = controls::_0x5B84D09CEC5209C5(0, 221);
  }
  else {
    fVar0 = controls::_0x4F8A26A890FD62FB(0, 218);
    fVar1 = controls::_0x4F8A26A890FD62FB(0, 219);
    fVar2 = controls::_0x4F8A26A890FD62FB(0, 220);
    fVar3 = controls::_0x4F8A26A890FD62FB(0, 221);
  }
  *uParam0 = system::round(128f * fVar0);
  *uParam1 = system::round(128f * fVar1);
  *uParam2 = system::round(128f * fVar2);
  *uParam3 = system::round(128f * fVar3);
}

// Position - 0x20C37
void func_489() {
  controls::disable_control_action(0, 81, 1);
  controls::disable_control_action(0, 82, 1);
  controls::disable_control_action(0, 85, 1);
  controls::disable_control_action(0, 37, 1);
  controls::disable_control_action(0, 12, 1);
  controls::disable_control_action(0, 13, 1);
  controls::disable_control_action(0, 14, 1);
  controls::disable_control_action(0, 15, 1);
  controls::disable_control_action(0, 16, 1);
  controls::disable_control_action(0, 17, 1);
  controls::disable_control_action(0, 25, 1);
  controls::disable_control_action(0, 24, 1);
  controls::disable_control_action(0, 50, 1);
  controls::disable_control_action(0, 53, 1);
  controls::disable_control_action(0, 54, 1);
  ui::hide_hud_component_this_frame(19);
  ui::hide_hud_component_this_frame(2);
  ui::hide_hud_component_this_frame(14);
  ui::hide_hud_component_this_frame(16);
  ui::hide_hud_component_this_frame(6);
  ui::hide_hud_component_this_frame(7);
  ui::hide_hud_component_this_frame(8);
  ui::hide_hud_component_this_frame(9);
}

// Position - 0x20CE4
var func_490() {
  int *iVar0;

  func_500(&iVar0, time::get_clock_seconds());
  func_499(&iVar0, time::get_clock_minutes());
  func_498(&iVar0, time::get_clock_hours());
  func_493(&iVar0, time::get_clock_day_of_month());
  func_492(&iVar0, time::get_clock_month());
  func_491(&iVar0, time::get_clock_year());
  return iVar0;
}

// Position - 0x20D2A
void func_491(int *iParam0, int iParam1) {
  if (iParam1 <= 0) {
    return;
  }
  if (iParam1 > 2043 || iParam1 < 1979) {
    return;
  }
  *iParam0 -= (*iParam0 & 2080374784);
  if (iParam1 < 2011) {
    *iParam0 |= system::shift_left(2011 - iParam1, 26);
    *iParam0 |= -2147483648;
  }
  else {
    *iParam0 |= system::shift_left(iParam1 - 2011, 26);
    *iParam0 -= (*iParam0 & -2147483648);
  }
}

// Position - 0x20DB0
void func_492(var *uParam0, int iParam1) {
  if (iParam1 < 0 || iParam1 > 11) {
    return;
  }
  *uParam0 -= (*uParam0 & 15);
  *uParam0 |= iParam1;
}

// Position - 0x20DE3
void func_493(var *uParam0, int iParam1) {
  int iVar0;
  int iVar1;

  iVar0 = func_497(*uParam0);
  iVar1 = func_495(*uParam0);
  if (iParam1 < 1 || iParam1 > func_494(iVar0, iVar1)) {
    return;
  }
  *uParam0 -= (*uParam0 & 496);
  *uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x20E34
int func_494(int iParam0, int iParam1) {
  if (iParam1 < 0) {
    iParam1 = 0;
  }
  switch (iParam0) {
  case 0:
  case 2:
  case 4:
  case 6:
  case 7:
  case 9:
  case 11: return 31;

  case 3:
  case 5:
  case 8:
  case 10: return 30;

  case 1:
    if (iParam1 % 4 == 0) {
      if (iParam1 % 100 != 0) {
        return 29;
      }
      else if (iParam1 % 400 == 0) {
        return 29;
      }
    }
    return 28;
  }
  return 30;
}

// Position - 0x20ED6
var func_495(int iParam0) {
  return (system::shift_right(iParam0, 26) & 31) *
             func_496(gameplay::is_bit_set(iParam0, 31), -1, 1) +
         2011;
}

// Position - 0x20EFB
int func_496(bool bParam0, int iParam1, int iParam2) {
  if (bParam0) {
    return iParam1;
  }
  return iParam2;
}

// Position - 0x20F12
int func_497(var uParam0) { return uParam0 & 15; }

// Position - 0x20F1F
void func_498(var *uParam0, int iParam1) {
  if (iParam1 < 0 || iParam1 > 24) {
    return;
  }
  *uParam0 -= (*uParam0 & 15872);
  *uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x20F59
void func_499(var *uParam0, int iParam1) {
  if (iParam1 < 0 || iParam1 >= 60) {
    return;
  }
  *uParam0 -= (*uParam0 & 1032192);
  *uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x20F94
void func_500(var *uParam0, int iParam1) {
  if (iParam1 < 0 || iParam1 >= 60) {
    return;
  }
  *uParam0 -= (*uParam0 & 66060288);
  *uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x20FD0
int func_501(var *uParam0) { return uParam0->f_2; }

// Position - 0x20FDC
void func_502(var *uParam0, int iParam1) {
  int iVar0;

  iVar0 = func_34(player::player_ped_id());
  switch (iParam1) {
  case 0:
    func_527(uParam0, 125);
    func_526(uParam0, joaat("squalo"));
    func_525(uParam0, 41.0737f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, -1039.712f, -1731.145f, 1f);
    func_516(uParam0, 317.8872f);
    func_515(uParam0, 0f, -2f, 0f);
    func_514(uParam0, "BJ_01P");
    func_512(uParam0, func_513(0));
    func_511(uParam0, func_446(0));
    func_510(uParam0, 53.4142f);
    func_509(uParam0, -1151.402f, -1864.369f, 214.9385f);
    func_508(uParam0, -55.1298f, -0.0328f, -19.7985f);
    func_507(uParam0, 39.6124f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 1:
    func_527(uParam0, 126);
    func_526(uParam0, 0);
    func_525(uParam0, 10.5f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, 978.232f, -397.611f, 416.607f);
    func_517(uParam0, 1, 873.389f, -183.851f, 302.972f);
    func_517(uParam0, 2, 1082.347f, -86.822f, 174.287f);
    func_517(uParam0, 3, 1151.098f, 124.6955f, 81.4805f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    func_514(uParam0, "BJ_02P");
    func_512(uParam0, func_513(1));
    func_511(uParam0, func_446(1));
    func_510(uParam0, 52.5984f);
    func_509(uParam0, 886.5799f, -442.7917f, 535.8002f);
    func_508(uParam0, -41.778f, 0.0092f, -13.8287f);
    func_507(uParam0, 41.3305f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 2:
    func_527(uParam0, 127);
    func_526(uParam0, 0);
    func_525(uParam0, 289.2623f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, 2028.516f, 1759.102f, 424.7939f);
    func_517(uParam0, 1, 2230.78f, 1600.25f, 318.384f);
    func_517(uParam0, 2, 2410.55f, 1739.71f, 253.494f);
    func_517(uParam0, 3, 2273.787f, 1885.168f, 152.702f);
    func_517(uParam0, 4, 2111.912f, 1887.456f, 92.5308f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    func_514(uParam0, "BJ_03P");
    func_512(uParam0, func_513(2));
    func_511(uParam0, func_446(2));
    func_510(uParam0, 31.9702f);
    func_509(uParam0, 2038.807f, 1971.563f, 591.7618f);
    func_508(uParam0, -79.6953f, 0.0213f, 159.6313f);
    func_507(uParam0, 50.8804f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 3:
    func_527(uParam0, 128);
    func_526(uParam0, 0);
    func_525(uParam0, 60.1427f);
    func_524(uParam0, joaat("frogger"));
    func_523(uParam0, 402.6013f, 5736.451f, 696.3928f);
    func_522(uParam0, 119.8889f);
    func_521(uParam0, 5f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, 320.69f, 5808.49f, 550.56f);
    func_517(uParam0, 1, 220.59f, 5943.149f, 415.514f);
    func_517(uParam0, 2, 30.63f, 6117.63f, 227.9f);
    func_517(uParam0, 3, -80.95f, 6440.43f, 100.48f);
    func_517(uParam0, 4, -273.773f, 6633.584f, 6.533f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_04M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_04F");
    }
    else {
      func_514(uParam0, "BJ_04T");
    }
    func_512(uParam0, func_513(3));
    func_511(uParam0, func_446(3));
    func_510(uParam0, 44.3626f);
    func_509(uParam0, 409.9299f, 5701.477f, 696.7185f);
    func_508(uParam0, -5.0705f, 0f, 20.8267f);
    func_507(uParam0, 43.8549f);
    func_506(uParam0, 0);
    func_505(uParam0, 1);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 4:
    func_527(uParam0, 129);
    func_526(uParam0, 0);
    func_525(uParam0, 1.8891f);
    func_524(uParam0, joaat("skylift"));
    func_523(uParam0, -75.3f, -823.9f, 329.2f);
    func_522(uParam0, 150f);
    func_521(uParam0, 4f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, -77.2067f, -444.208f, 37f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_05M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_05F");
    }
    else {
      func_514(uParam0, "BJ_05T");
    }
    func_512(uParam0, func_513(4));
    func_511(uParam0, func_446(4));
    func_510(uParam0, 26.7726f);
    func_509(uParam0, -111.8981f, -862.3896f, 334.5773f);
    func_508(uParam0, -5.4775f, 0.0397f, -29.0222f);
    func_507(uParam0, 30.0131f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 5:
    func_527(uParam0, 130);
    func_526(uParam0, joaat("hauler"));
    func_525(uParam0, 358.9586f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, -96.9738f, -662.5833f, 34.7843f);
    func_516(uParam0, -18.6f);
    func_515(uParam0, 0f, -6f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_06M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_06F");
    }
    else {
      func_514(uParam0, "BJ_06T");
    }
    func_512(uParam0, func_513(5));
    func_511(uParam0, func_446(5));
    func_510(uParam0, 55.7667f);
    func_509(uParam0, -117.2447f, -977.6218f, 297.0984f);
    func_508(uParam0, -7.6574f, 0f, 0.8528f);
    func_507(uParam0, 60f);
    func_506(uParam0, 0);
    func_505(uParam0, 1);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 6:
    func_527(uParam0, 131);
    func_526(uParam0, 0);
    func_525(uParam0, 164.6178f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, joaat("blazer"));
    func_519(uParam0, -1310.948f, 4330.126f, 7.2444f);
    func_518(uParam0, 87.84f);
    func_517(uParam0, 0, -1246.49f, 4482.091f, 100.349f);
    func_517(uParam0, 1, -1309.67f, 4400.428f, 50.542f);
    func_517(uParam0, 2, -1304.67f, 4348.428f, 5.75f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_07M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_07F");
    }
    else {
      func_514(uParam0, "BJ_07T");
    }
    func_512(uParam0, func_513(6));
    func_511(uParam0, func_446(6));
    func_510(uParam0, 47.1789f);
    func_509(uParam0, -1242.731f, 4536.298f, 186.6862f);
    func_508(uParam0, -13.6409f, 0f, 172.0553f);
    func_507(uParam0, 47.1789f);
    func_506(uParam0, 0);
    func_505(uParam0, 1);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 7:
    func_527(uParam0, 132);
    func_526(uParam0, joaat("freight"));
    func_525(uParam0, 112.6f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, -487.5452f, 4252.192f, 87.712f);
    func_516(uParam0, 10.8894f);
    func_515(uParam0, 0f, -20f, 4f);
    func_514(uParam0, "BJ_08P");
    func_512(uParam0, func_513(7));
    func_511(uParam0, func_446(7));
    func_510(uParam0, 24.3623f);
    func_509(uParam0, -337.5233f, 4110.16f, 315.6679f);
    func_508(uParam0, -29.1422f, 0.0324f, 47.5813f);
    func_507(uParam0, 37.0424f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 8:
    func_527(uParam0, 133);
    func_526(uParam0, 0);
    func_525(uParam0, 104.207f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, -1154.443f, 204.1726f, 64.4915f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_09M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_09F");
    }
    else {
      func_514(uParam0, "BJ_09T");
    }
    func_512(uParam0, func_513(8));
    func_511(uParam0, func_446(8));
    func_510(uParam0, 50f);
    func_509(uParam0, -805.2963f, 332.5761f, 234.6604f);
    func_508(uParam0, -19.7458f, 0f, 116.6405f);
    func_507(uParam0, 55.2882f);
    func_506(uParam0, 0);
    func_505(uParam0, 1);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 9:
    func_527(uParam0, 134);
    func_526(uParam0, 0);
    func_525(uParam0, 329.4791f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, joaat("blazer"));
    func_519(uParam0, -818.3042f, 4405.675f, 20.1095f);
    func_518(uParam0, -89.36f);
    func_517(uParam0, 0, -1200f, 3616f, 964f);
    func_517(uParam0, 1, -1240f, 3307f, 854f);
    func_517(uParam0, 2, -1552f, 3456f, 655f);
    func_517(uParam0, 3, -1616f, 3808f, 505f);
    func_517(uParam0, 4, -1157.684f, 4128.348f, 288.607f);
    func_517(uParam0, 5, -1063.995f, 4246.137f, 163.291f);
    func_517(uParam0, 6, -938.541f, 4360.14f, 82.372f);
    func_517(uParam0, 7, -828.1418f, 4413.562f, 20.062f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    func_514(uParam0, "BJ_10P");
    func_512(uParam0, func_513(9));
    func_511(uParam0, func_446(9));
    func_510(uParam0, 31.7648f);
    func_509(uParam0, -1286.976f, 3660.137f, 1082.208f);
    func_508(uParam0, -47.0453f, 0.0328f, -13.4198f);
    func_507(uParam0, 39.6786f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 10:
    func_527(uParam0, 135);
    func_526(uParam0, 0);
    func_525(uParam0, 0f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, 0);
    func_519(uParam0, 0f, 0f, 0f);
    func_518(uParam0, 0f);
    func_517(uParam0, 0, 1239.342f, 4008.389f, 1135.372f);
    func_517(uParam0, 1, 1374.479f, 4156.592f, 1019.694f);
    func_517(uParam0, 2, 1391.31f, 4362.621f, 909.212f);
    func_517(uParam0, 3, 1240.832f, 4598.044f, 758.002f);
    func_517(uParam0, 4, 1382.169f, 4377.629f, 600.013f);
    func_517(uParam0, 5, 1624.116f, 4207.519f, 471.225f);
    func_517(uParam0, 6, 1910.345f, 4175.518f, 362.862f);
    func_517(uParam0, 7, 2236.975f, 4282.967f, 218.116f);
    func_517(uParam0, 8, 2330.282f, 4534.43f, 90f);
    func_517(uParam0, 9, 2473.344f, 4715.347f, 33.524f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    func_514(uParam0, "BJ_11P");
    func_512(uParam0, func_513(10));
    func_511(uParam0, func_446(10));
    func_510(uParam0, 27.2187f);
    func_509(uParam0, 1012.673f, 3960.436f, 1367.701f);
    func_508(uParam0, -54.7868f, 0f, -90.128f);
    func_507(uParam0, 35.5634f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 11:
    func_527(uParam0, 136);
    func_526(uParam0, 0);
    func_525(uParam0, 24.92f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, joaat("sanchez"));
    func_519(uParam0, 1280.933f, -50.6157f, 61.8195f);
    func_518(uParam0, 130.39f);
    func_517(uParam0, 0, 1829.46f, -260.665f, 1141.852f);
    func_517(uParam0, 1, 1816.46f, -10.665f, 1033.084f);
    func_517(uParam0, 2, 1688.46f, 218.335f, 924.307f);
    func_517(uParam0, 3, 1503.46f, 382.335f, 815.529f);
    func_517(uParam0, 4, 1554.46f, 598.335f, 706.751f);
    func_517(uParam0, 5, 1813.46f, 724.335f, 597.973f);
    func_517(uParam0, 6, 1975.46f, 519.335f, 486.196f);
    func_517(uParam0, 7, 1946.46f, 125.335f, 364.417f);
    func_517(uParam0, 8, 1663.46f, -15.665f, 241.64f);
    func_517(uParam0, 9, 1396.64f, -62.665f, 118f);
    func_517(uParam0, 10, 1278.5f, -41.05f, 61.7f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    func_514(uParam0, "BJ_12P");
    func_512(uParam0, func_513(11));
    func_511(uParam0, func_446(11));
    func_510(uParam0, 18.9374f);
    func_509(uParam0, 1628.156f, -431.2605f, 1332.761f);
    func_508(uParam0, -54.5827f, 0f, -2.0463f);
    func_507(uParam0, 56.4495f);
    func_506(uParam0, 0);
    func_505(uParam0, 0);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;

  case 12:
    func_527(uParam0, 137);
    func_526(uParam0, 0);
    func_525(uParam0, 359.2885f);
    func_524(uParam0, 0);
    func_523(uParam0, 0f, 0f, 0f);
    func_522(uParam0, 0f);
    func_521(uParam0, 0f);
    func_520(uParam0, joaat("sanchez"));
    func_519(uParam0, -885.2659f, 4433.592f, 20.381f);
    func_518(uParam0, 104.35f);
    func_517(uParam0, 0, -771.9196f, 4400.453f, 60.5786f);
    func_517(uParam0, 1, -892.6581f, 4427.487f, 19.8561f);
    func_516(uParam0, 0f);
    func_515(uParam0, 0f, 0f, 0f);
    if (iVar0 == 0) {
      func_514(uParam0, "BJ_13M");
    }
    else if (iVar0 == 1) {
      func_514(uParam0, "BJ_13F");
    }
    else {
      func_514(uParam0, "BJ_13T");
    }
    func_512(uParam0, func_513(12));
    func_511(uParam0, func_446(12));
    func_510(uParam0, 48.3921f);
    func_509(uParam0, -765.6544f, 4332.836f, 149.0282f);
    func_508(uParam0, -18.0357f, 0f, 6.0212f);
    func_507(uParam0, 48.3921f);
    func_506(uParam0, 0);
    func_505(uParam0, 1);
    func_504(uParam0, 0f, 0f, 0f);
    func_503(uParam0, 0f, 0f, 0f);
    break;
  }
}

// Position - 0x221B6
void func_503(var *uParam0, vector3 vParam1) { uParam0->f_67 = {vParam1}; }

// Position - 0x221C8
void func_504(var *uParam0, vector3 vParam1) { uParam0->f_64 = {vParam1}; }

// Position - 0x221DA
void func_505(var *uParam0, int iParam1) { uParam0->f_84 = iParam1; }

// Position - 0x221E8
void func_506(var *uParam0, int iParam1) { uParam0->f_83 = iParam1; }

// Position - 0x221F6
void func_507(var *uParam0, float fParam1) { uParam0->f_82 = fParam1; }

// Position - 0x22204
void func_508(var *uParam0, vector3 vParam1) { uParam0->f_58 = {vParam1}; }

// Position - 0x22216
void func_509(var *uParam0, vector3 vParam1) { uParam0->f_55 = {vParam1}; }

// Position - 0x22228
void func_510(var *uParam0, float fParam1) { uParam0->f_81 = fParam1; }

// Position - 0x22236
void func_511(var *uParam0, vector3 vParam1) { uParam0->f_52 = {vParam1}; }

// Position - 0x22248
void func_512(var *uParam0, vector3 vParam1) { uParam0->f_49 = {vParam1}; }

// Position - 0x2225A
Vector3 func_513(int iParam0) {
  switch (iParam0) {
  case 0: return -1143.586f, -1859.747f, 208.3878f;

  case 1: return 877.5864f, -436.3322f, 536.9036f;

  case 2: return 2041.231f, 1978.98f, 585.9358f;

  case 3: return 405.2326f, 5705.887f, 697.2318f;

  case 4: return -103.8901f, -870.8046f, 298.7574f;

  case 5: return -118.2569f, -975.1133f, 297.3781f;

  case 6: return -1237.465f, 4526.661f, 181.7929f;

  case 7: return -357.7932f, 4107.914f, 314.8059f;

  case 8: return -809.6324f, 331.3331f, 233.2818f;

  case 9: return -1286.926f, 3660.203f, 1076.051f;

  case 10: return 1022.178f, 3975.738f, 1362.533f;

  case 11: return 1608.553f, -434.5186f, 1321.916f;

  case 12: return -756.3533f, 4341.521f, 143.8134f;

  default:
  }
  return 0f, 0f, 0f;
}

// Position - 0x223A4
void func_514(var *uParam0, char *sParam1) { uParam0->f_4 = sParam1; }

// Position - 0x223B2
void func_515(var *uParam0, vector3 vParam1) { uParam0->f_6 = {vParam1}; }

// Position - 0x223C4
void func_516(var *uParam0, float fParam1) { uParam0->f_77 = fParam1; }

// Position - 0x223D2
void func_517(var *uParam0, int iParam1, vector3 vParam2) {
  if (iParam1 < 0 || iParam1 >= 12) {
    return;
  }
  uParam0->f_12[iParam1 /*3*/] = {vParam2};
}

// Position - 0x223FD
void func_518(var *uParam0, float fParam1) { uParam0->f_79 = fParam1; }

// Position - 0x2240B
void func_519(var *uParam0, vector3 vParam1) { uParam0->f_9 = {vParam1}; }

// Position - 0x2241D
void func_520(var *uParam0, int iParam1) { uParam0->f_3 = iParam1; }

// Position - 0x2242B
void func_521(var *uParam0, float fParam1) { uParam0->f_80 = fParam1; }

// Position - 0x22439
void func_522(var *uParam0, float fParam1) { uParam0->f_78 = fParam1; }

// Position - 0x22447
void func_523(var *uParam0, vector3 vParam1) { uParam0->f_70 = {vParam1}; }

// Position - 0x22459
void func_524(var *uParam0, int iParam1) { uParam0->f_2 = iParam1; }

// Position - 0x22467
void func_525(var *uParam0, float fParam1) { uParam0->f_76 = fParam1; }

// Position - 0x22475
void func_526(var *uParam0, int iParam1) { uParam0->f_1 = iParam1; }

// Position - 0x22483
void func_527(var *uParam0, int iParam1) { *uParam0 = iParam1; }

// Position - 0x22490
void func_528(int iParam0, int iParam1) {
  if (iParam1) {
    gameplay::set_bit(&Global_25434, iParam0);
  }
  else {
    gameplay::clear_bit(&Global_25434, iParam0);
  }
}

// Position - 0x224B2
void func_529(int iParam0) {
  func_357();
  Global_69957 = iParam0;
  Global_69956 = 0;
  Global_69959 = 3;
}

// Position - 0x224CE
void func_530(var *uParam0, var *uParam1, int *iParam2, var *uParam3,
              int *iParam4, var *uParam5, int iParam6, var *uParam7,
              int iParam8, var *uParam9, var *uParam10, var uParam11,
              int *iParam12, int iParam13, int iParam14, int iParam15,
              var *uParam16, bool bParam17) {
  int iVar0;
  int iVar1;
  int iVar2;

  func_351();
  func_350();
  func_466();
  func_536(uParam1);
  func_528(23, 0);
  func_535(*uParam1);
  vehicle::_0xE30524E1871F481D(*uParam16);
  audio::cancel_music_event("OJBJ_START");
  audio::cancel_music_event("OJBJ_JUMPED");
  audio::cancel_music_event("OJBJ_LANDED");
  audio::trigger_music_event("OJBJ_STOP");
  audio::stop_audio_scene("BASEJUMPS_OPEN_PARACHUTE");
  audio::stop_audio_scene("BASEJUMPS_PREP_FOR_JUMP_ON_FOOT");
  audio::stop_audio_scene("BASEJUMPS_PREP_FOR_JUMP_MOTO");
  audio::stop_audio_scene("BASEJUMPS_SKYDIVE");
  audio::stop_audio_scene("BASEJUMPS_OPEN_PARACHUTE");
  audio::stop_audio_scenes();
  uParam11 = uParam11;
  Global_87081 = 0;
  Global_87082 = 0;
  Global_87083 = 0;
  func_20(0, 1);
  func_18(0, 1);
  func_17(0);
  gameplay::set_fade_out_after_death(1);
  gameplay::_disable_automatic_respawn(0);
  gameplay::ignore_next_restart(0);
  while (cam::is_screen_fading_out()) {
    system::wait(0);
  }
  if (cam::is_script_global_shaking()) {
    cam::stop_script_global_shaking(1);
  }
  if (ui::does_blip_exist(iParam13)) {
    ui::remove_blip(&iParam13);
  }
  if (ui::does_blip_exist(iParam14)) {
    ui::remove_blip(&iParam14);
  }
  func_357();
  func_26(0);
  player::set_player_can_leave_parachute_smoke_trail(player::player_id(), 0);
  func_534(1, 1);
  if (func_401(func_427(uParam0))) {
  }
  else {
    vehicle::_0x0A436B8643716D14();
  }
  ped::remove_scenario_blocking_areas();
  func_532(uParam7);
  func_259();
  ui::_set_minimap_attitude_indicator_level(0f, 0);
  graphics::_0x6DDBF9DFFC4AC080(0);
  func_201(0, 0);
  player::set_player_control(player::player_id(), 1, 0);
  if (iParam15 == 5) {
    ped::set_ped_config_flag(player::player_ped_id(), 146, 0);
  }
  if (entity::does_entity_exist(player::player_ped_id()) &&
      !ped::is_ped_injured(player::player_ped_id())) {
    ped::set_ped_reset_flag(player::player_ped_id(), 177, 0);
    ped::set_ped_config_flag(player::player_ped_id(), 36, 0);
    player::set_player_invincible(player::player_id(), 0);
    ped::set_ped_can_be_knocked_off_vehicle(player::player_ped_id(), 0);
    if (!bParam17) {
      weapon::remove_weapon_from_ped(player::player_ped_id(),
                                     joaat("gadget_parachute"));
    }
    ped::set_ped_lod_multiplier(player::player_ped_id(), 1f);
    ped::set_ped_helmet(player::player_ped_id(), 1);
  }
  iVar1 = 0;
  while (iVar1 < *uParam10) {
    if (entity::does_entity_exist((*uParam10)[iVar1]) &&
        !entity::is_entity_dead((*uParam10)[iVar1], 0)) {
      ai::clear_ped_tasks((*uParam10)[iVar1]);
      (*uParam10)[iVar1] = 0;
    }
    iVar1++;
  }
  if (entity::does_entity_exist(*iParam6) &&
      *iParam6 != player::get_players_last_vehicle() &&
      !entity::is_entity_dead(*iParam6, 0)) {
    vehicle::set_players_last_vehicle(*iParam6);
    func_262(*iParam6, func_300(iParam15), func_299(iParam15), 24, 0);
  }
  if (!ped::is_ped_injured(*iParam8)) {
    if (!entity::is_entity_on_screen(*iParam8)) {
      ped::delete_ped(iParam8);
    }
    else {
      entity::set_ped_as_no_longer_needed(iParam8);
    }
  }
  if (!ped::is_ped_injured(*uParam9)) {
    ai::clear_ped_tasks(*uParam9);
    ped::set_blocking_of_non_temporary_events(*uParam9, 1);
  }
  if (entity::does_entity_exist(*iParam2)) {
    if (func_435(func_436(iParam15))) {
      if (!entity::is_entity_dead(*iParam2, 0) &&
          !ped::is_ped_injured(player::player_ped_id()) &&
          ped::is_ped_in_vehicle(player::player_ped_id(), *iParam2, 0)) {
        ped::_0xF9ACF4A08098EA25(player::player_ped_id(), 1);
      }
      if (!entity::is_entity_on_screen(*iParam2)) {
        vehicle::delete_vehicle(iParam2);
      }
      else {
        entity::set_vehicle_as_no_longer_needed(iParam2);
      }
    }
    else {
      entity::set_vehicle_as_no_longer_needed(iParam2);
    }
  }
  if (entity::does_entity_exist(*uParam3)) {
    if (func_342(func_343(uParam0))) {
      vehicle::set_mission_train_as_no_longer_needed(uParam3, 0);
      vehicle::set_random_trains(1);
    }
  }
  if (entity::does_entity_exist(*iParam4) &&
      !entity::is_entity_dead(*iParam4, 0)) {
    iVar0 = vehicle::get_ped_in_vehicle_seat(*iParam4, -1, 0);
    if (entity::does_entity_exist(iVar0)) {
      ped::delete_ped(&iVar0);
    }
    vehicle::delete_vehicle(iParam4);
  }
  iVar2 = 0;
  while (iVar2 < *uParam5) {
    if (entity::does_entity_exist((*uParam5)[iVar2]) &&
        !entity::is_entity_dead((*uParam5)[iVar2], 0)) {
      vehicle::set_vehicle_lod_multiplier((*uParam5)[iVar2], 1f);
      entity::set_entity_load_collision_flag((*uParam5)[iVar2], 0);
    }
    iVar2++;
  }
  *iParam12 = 1;
  ui::clear_help(1);
  cam::render_script_cams(0, 0, 3000, 1, 0, 0);
  ui::display_radar(1);
  ui::display_hud(1);
  audio::set_frontend_radio_active(1);
  func_531();
  script::set_no_loading_screen(0);
  Global_101700.f_17926 = -1;
  script::terminate_this_thread();
}

// Position - 0x22893
void func_531() { Global_17151.f_5 = 0; }

// Position - 0x228A1
void func_532(var *uParam0) {
  func_533(uParam0, 0);
  func_533(uParam0, 1);
  func_533(uParam0, 2);
}

// Position - 0x228BE
void func_533(var *uParam0, int iParam1) {
  if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
    (*uParam0)[iParam1 /*10*/].f_7 = 0;
  }
}

// Position - 0x228DB
void func_534(int iParam0, int iParam1) {
  if (gameplay::is_bit_set(Global_25347, iParam0)) {
    if (!iParam1) {
      gameplay::clear_bit(&Global_25347, iParam0);
      StringCopy(&Global_25348[iParam0 /*6*/], "NULL", 24);
      Global_25403[iParam0] = iParam1;
    }
  }
}

// Position - 0x22912
void func_535(var uParam0) {
  graphics::set_scaleform_movie_as_no_longer_needed(&uParam0);
}

// Position - 0x22920
void func_536(var *uParam0) { func_535(*uParam0); }

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
var uLocal_43 = 0;
var uLocal_44 = 10;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 2;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 8;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 8;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var *uLocal_80 = NULL;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
int iLocal_85 = 0;
var *uLocal_86 = NULL;
var uLocal_87 = 0;
var *uLocal_88 = NULL;
var uLocal_89 = 0;
var *uLocal_90 = NULL;
var uLocal_91 = 0;
var uLocal_92 = 1;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 1;
var uLocal_97 = 0;
var *uLocal_98 = NULL;
var uLocal_99 = 0;
var *uLocal_100 = NULL;
var uLocal_101 = 0;
var *uLocal_102 = NULL;
var uLocal_103 = 0;
var uLocal_104 = 1;
var uLocal_105 = 0;
var uLocal_106 = 1;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 1;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
vector3 vLocal_114 = {0f, 0f, 0f};
var uLocal_117 = 0;
var uLocal_118 = 1;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 1;
var uLocal_123 = 0;
var *uLocal_124 = NULL;
var uLocal_125 = 0;
var *uLocal_126 = NULL;
var uLocal_127 = 0;
var *uLocal_128 = NULL;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
int *iLocal_145 = NULL;
var *uLocal_146 = NULL;
var uLocal_147 = 0;
var uLocal_148 = 0;
var *uLocal_149 = NULL;
var *uLocal_150 = NULL;
int iLocal_151[1] = {0};
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var *uLocal_156 = NULL;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var *uLocal_321 = NULL;
var uLocal_322 = 0;
struct<4> ScriptParam_0 = {
	0, 0, 0, 0
};
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	iLocal_28 = 3;
	fLocal_31 = 80f;
	fLocal_32 = 140f;
	fLocal_33 = 180f;
	iLocal_39 = 1;
	iLocal_40 = 65;
	iLocal_41 = 49;
	iLocal_42 = 64;
	iLocal_85 = 1;
	if (player::has_force_cleanup_occurred(66)) {
		func_50();
	}
	system::wait(0);
	func_49(ScriptParam_0);
	func_47();
	while (iLocal_85) {
		system::wait(0);
		iLocal_85 = 0;
		if (func_41(1, vLocal_114, 1.5f)) {
			func_32(&iLocal_145, &uLocal_146, &uLocal_149, &uLocal_150, vLocal_114, "v_franklinshouse");
			if (func_31(126)) {
				func_1(2, &uLocal_80, vLocal_114, 30f, 22.5f, 7.5f, &uLocal_98);
			}
			iLocal_85 = 1;
		}
	}
	func_50();
}

// Position - 0xF3
int func_1(int iParam0, var *uParam1, vector3 vParam2, vector3 vParam5, var *uParam8) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	vector3 vVar5;
	vector3 vVar8;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	if (ped::is_ped_injured(player::player_ped_id())) {
		return 0;
	}
	if (Global_86848 != -1) {
		return 0;
	}
	if (func_29(iParam0, func_30())) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = func_28(iVar0);
		if (!func_27(iVar1)) {
			if (entity::does_entity_exist(Global_89302[iVar0])) {
				if (func_29(iParam0, func_26(iVar1))) {
					return 0;
				}
			}
		}
		iVar0++;
	}
	iVar3 = 145;
	iVar2 = 0;
	while (iVar2 < 3) {
		if (func_29(iParam0, func_26(iVar2))) {
			iVar3 = iVar2;
		}
		iVar2++;
	}
	if (!func_25(iVar3)) {
		return 0;
	}
	if (!func_24(iVar3)) {
		return 0;
	}
	switch (iVar3) {
	case 0:
		if (Global_2595547) {
			return 0;
		}
		break;

	case 1: break;

	case 2: break;

	default: return 0;
	}
	if (!func_15(iVar3, func_19())) {
		return 0;
	}
	switch (iVar3) {
	case 0: iVar4 = 0; break;

	case 1: iVar4 = 1; break;

	case 2: iVar4 = 2; break;

	default: return 0;
	}
	if (Global_101700.f_27009[iVar3 /*29*/].f_12[iVar4] == 1) {
		return 0;
	}
	if (func_14(vParam5, 0f, 0f, 0f, 0)) {
		vParam5 = {50f, 50f, 50f};
	}
	vVar5 = {vParam2 - vParam5};
	vVar8 = {vParam2 + vParam5};
	func_13(vVar5, vVar8);
	func_12(vVar5, vVar8, &uParam1->f_1);
	func_10(iParam0, uParam8);
	func_9(vVar5, vVar8);
	func_8(vVar5, vVar8, &uParam1->f_4);
	if (Global_86847 != 8) {
		if (Global_86848 == -1) {
			iVar11 = -1;
			if (func_29(iParam0, func_30())) {
			}
			iVar12 = 5000;
			if (func_7()) {
				switch (iVar3) {
				case 0: iVar11 = -181320640; break;

				case 1: iVar11 = 1418815087; break;

				case 2: iVar11 = 2087297077; break;

				default: return 0;
				}
				iVar13 = -1;
				switch (Global_86847) {
				case 0:
					iVar14 = 11;
					iVar13 = 3;
					break;

				case 1:
					iVar14 = 12;
					iVar13 = 3;
					break;

				case 4:
					iVar14 = 13;
					iVar12 = 10000;
					iVar13 = 3;
					break;

				case 6:
					iVar14 = 14;
					iVar12 = 10000;
					iVar13 = 3;
					break;

				case 7:
					iVar14 = 15;
					iVar12 = 10000;
					iVar13 = 3;
					break;

				case 2:
					iVar14 = 16;
					iVar13 = 3;
					break;

				case 3:
					iVar14 = 17;
					iVar13 = 3;
					break;

				case 5:
					iVar14 = 18;
					iVar13 = 3;
					break;

				default: return 0;
				}
				if ((iVar14 == 14 || iVar14 == 15) && iVar11 != -181320640) {
					iVar14 = 13;
				}
				iVar16 = gameplay::get_random_int_in_range(0, iVar13);
				switch (iVar16) {
				case 0: iVar15 = 19; break;

				case 1: iVar15 = 20; break;

				case 2: iVar15 = 21; break;

				case 3: iVar15 = 22; break;

				case 4: iVar15 = 23; break;

				default: return 0;
				}
				if (func_6(iVar11, iVar14, iVar15, 6, func_30(), iVar3, iVar12, 10000, -1, 0, -1, 0, 1)) {
					Global_86848 = gameplay::get_game_timer();
					return 1;
				}
			}
			else {
				switch (Global_86847) {
				case 0:
					switch (iVar3) {
					case 0: iVar11 = 2038672434; break;

					case 1: iVar11 = 975196153; break;

					case 2: iVar11 = 1127548000; break;

					default: return 0;
					}
					break;

				case 4:
					switch (iVar3) {
					case 0: iVar11 = 1666308520; break;

					case 1: iVar11 = -710274964; break;

					case 2: iVar11 = -1291788156; break;

					default: return 0;
					}
					iVar12 = 10000;
					break;

				case 6:
					switch (iVar3) {
					case 1: iVar11 = 1289879258; break;

					default: return 0;
					}
					break;

				case 3:
					switch (iVar3) {
					case 0: iVar11 = 1894462438; break;

					case 1: iVar11 = 1621076324; break;

					case 2: iVar11 = 1993031175; break;

					default: return 0;
					}
					break;

				case 1:
				case 2:
				case 5:
				case 7: return 0;

				default: return 0;
				}
				if (func_2(iVar11, 6, func_30(), iVar3, iVar3, iVar12, 10000, -1, -1, 0, -1, 0)) {
					Global_86848 = gameplay::get_game_timer();
					return 1;
				}
			}
		}
	}
	return 0;
}

// Position - 0x5CF
bool func_2(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			int iParam8, int iParam9, int iParam10, int iParam11) {
	struct<15> Var0;
	int iVar15;

	if (func_5(0)) {
		return false;
	}
	if (iParam5 < 0) {
		return false;
	}
	if (iParam6 < 0) {
		return false;
	}
	if (iParam8 == 76) {
		return false;
	}
	if (iParam9 == 235) {
		return false;
	}
	if (iParam3 < 3) {
		if (gameplay::is_bit_set(iParam2, iParam3)) {
			return false;
		}
	}
	if (iParam4 < 3) {
		if (iParam4 != iParam3) {
			return false;
		}
	}
	if (iParam2 < 1 || iParam2 > 7) {
		return false;
	}
	if (G_SomeGlobalState.MessageCallStates.f_136 < 9) {
		Var0 = iParam0;
		if (G_SomeGlobalState.MessageCallStates.f_911 == Var0) {
			G_SomeGlobalState.MessageCallStates.f_911 = -1;
		}
		Var0.f_3 = func_4(iParam1);
		Var0.f_1 = iParam11;
		Var0.f_2 = iParam2;
		Var0.f_4 = gameplay::get_game_timer() + iParam5;
		Var0.f_5 = iParam6;
		Var0.f_6 = iParam3;
		Var0.f_14 = iParam4;
		Var0.f_10 = iParam7;
		Var0.f_11 = -1;
		Var0.f_7 = iParam8;
		Var0.f_8 = iParam9;
		Var0.f_9 = iParam10;
		gameplay::clear_bit(&Var0.f_1, 1);
		gameplay::clear_bit(&Var0.f_1, 0);
		if (iParam7 != -1) {
			gameplay::set_bit(&Var0.f_1, 11);
		}
		else if (iParam1 == 0) {
			gameplay::set_bit(&Var0.f_1, 10);
		}
		G_SomeGlobalState.MessageCallStates[G_SomeGlobalState.MessageCallStates.f_136 /*15*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_136++;
		iVar15 = 0;
		while (iVar15 < 3) {
			if (gameplay::is_bit_set(iParam2, iVar15)) {
				func_3(iVar15);
			}
			iVar15++;
		}
		return true;
	}
	return false;
}

// Position - 0x74F
void func_3(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (!func_25(iParam0)) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 > iVar1) {
				iVar1 = G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3;
			}
		}
		iVar0++;
	}
	iVar2 = 0;
	while (iVar2 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_3 == 5) {
				iVar1 = 5;
			}
		}
		iVar2++;
	}
	G_SomeGlobalState.MessageCallStates.f_919[iParam0] = iVar1;
}

// Position - 0x813
int func_4(int iParam0) {
	switch (iParam0) {
	case 0:
	case 4: return 5;

	case 7: return 4;

	case 2: return 3;

	case 1: return 2;

	case 3: return 1;

	case 5:
	case 6: return 0;
	}
	return 7;
}

// Position - 0x87D
bool func_5(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x8A8
bool func_6(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			int iParam8, int iParam9, int iParam10, int iParam11, int iParam12) {
	struct<14> Var0;

	if (func_5(0)) {
		return false;
	}
	if (iParam6 < 0) {
		return false;
	}
	if (iParam7 < 0) {
		return false;
	}
	if (iParam8 == 76) {
		return false;
	}
	if (iParam9 == 235) {
		return false;
	}
	if (iParam5 < 3) {
		if (gameplay::is_bit_set(iParam4, iParam5)) {
			return false;
		}
	}
	if (iParam4 < 1 || iParam4 > 7) {
		return false;
	}
	if (iParam1 == -1) {
		return false;
	}
	if (iParam1 == 83 || iParam2 == 83) {
		return false;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 < 8) {
		Var0 = iParam0;
		Var0.f_3 = func_4(iParam3);
		Var0.f_4 = gameplay::get_game_timer() + iParam6;
		Var0.f_5 = iParam7;
		Var0.f_1 = iParam11;
		Var0.f_2 = iParam4;
		Var0.f_6 = iParam5;
		Var0.f_7 = iParam8;
		Var0.f_8 = iParam9;
		Var0.f_9 = iParam10;
		Var0.f_10 = iParam1;
		Var0.f_11 = iParam2;
		Var0.f_13 = iParam12;
		gameplay::clear_bit(&Var0.f_1, 0);
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 /*14*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_764++;
		func_3(0);
		func_3(1);
		func_3(2);
		return true;
	}
	return false;
}

// Position - 0x9E6
bool func_7() {
	if (gameplay::is_bit_set(gameplay::get_random_int_in_range(0, 65535), 0)) {
		return true;
	}
	return false;
}

// Position - 0xA07
void func_8(vector3 vParam0, vector3 vParam3, var *uParam6) {
	if (ped::is_ped_shooting(player::player_ped_id())) {
		if (gameplay::has_bullet_impacted_in_box(vParam0, vParam3, 1, 1)) {
			*uParam6++;
			if (*uParam6 > 6) {
				Global_86847 = 3;
			}
		}
		else if (fire::is_explosion_in_area(0, vParam0, vParam3) || fire::is_explosion_in_area(2, vParam0, vParam3) ||
				 gameplay::is_projectile_type_in_area(vParam0, vParam3, joaat("weapon_grenadelauncher"), 1)) {
			Global_86847 = 5;
		}
	}
}

// Position - 0xA82
void func_9(vector3 vParam0, vector3 vParam3) {
	int iVar0;

	if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
		if (iVar0 == joaat("weapon_molotov") || iVar0 == joaat("weapon_petrolcan")) {
			if (fire::is_explosion_in_area(3, vParam0, vParam3)) {
				Global_86847 = 2;
			}
		}
	}
}

// Position - 0xAC6
void func_10(var uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		iVar1 = func_11(iVar0);
		if (iVar1 == 145) {
		}
		else if (iVar1 == func_19()) {
		}
		else if (!func_29(uParam0, func_26(iVar1))) {
		}
		else if (entity::get_entity_model(iVar0) == joaat("bagger")) {
			Global_86847 = 6;
		}
		else {
			Global_86847 = 4;
		}
		if (Global_86847 != 4) {
			iVar2 = 0;
			while (iVar2 < *uParam1) {
				if (iVar0 == (*uParam1)[iVar2]) {
					iVar3 = entity::get_entity_model(iVar0);
					if (iVar3 == joaat("issi2")) {
						Global_86847 = 7;
					}
					if (iVar3 == joaat("sentinel2")) {
						Global_86847 = 6;
					}
				}
				iVar2++;
			}
		}
	}
}

// Position - 0xB7D
int func_11(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0xBE0
void func_12(vector3 vParam0, vector3 vParam3, int *iParam6) {
	if (ped::is_ped_ducking(player::player_ped_id()) || ped::is_ped_in_cover(player::player_ped_id(), 0) ||
		ped::get_ped_stealth_movement(player::player_ped_id())) {
		if (entity::is_entity_in_area(player::player_ped_id(), vParam0, vParam3, 0, 1, 0)) {
			if (*iParam6 < 0) {
				*iParam6 = gameplay::get_game_timer();
			}
			else if (gameplay::get_game_timer() > *iParam6 + 10000) {
				Global_86847 = 1;
			}
		}
		else {
			*iParam6 = -1;
		}
	}
	else {
		*iParam6 = -1;
	}
}

// Position - 0xC57
void func_13(vector3 vParam0, vector3 vParam3) {
	int iVar0;

	if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
		if (iVar0 == joaat("weapon_rpg")) {
			if (gameplay::is_projectile_type_in_area(vParam0, vParam3, iVar0, 1)) {
				Global_86847 = 0;
			}
		}
	}
}

// Position - 0xC8E
bool func_14(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0xCD5
int func_15(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam0 >= 150 || iParam1 >= 150 || iParam0 == iParam1) {
		return 0;
	}
	iVar0 = func_18(iParam0);
	iVar1 = func_18(iParam1);
	if (iVar0 != 7 && iVar1 != 7) {
		iVar2 = func_17(iVar0, iVar1);
		if (iVar2 != 10) {
			if (func_16(iVar2) != -1) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0xD3F
int func_16(int iParam0) {
	if (iParam0 < 9) {
		return Global_87680[iParam0 /*2*/];
	}
	return -1;
}

// Position - 0xD5D
int func_17(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 != 0 && iParam0 != 1 && iParam0 != 2) {
		if (iParam1 == 0 || iParam1 == 1 || iParam1 == 2) {
			iVar0 = iParam1;
			iParam1 = iParam0;
			iParam0 = iVar0;
		}
	}
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: return 10;

		case 1: return 0;

		case 2: return 2;

		case 3: return 10;

		case 4: return 5;

		case 5: return 8;

		default: return 10;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: return 0;

		case 1: return 10;

		case 2: return 1;

		case 3: return 3;

		case 4: return 6;

		case 5: return 10;

		default: return 10;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return 2;

		case 1: return 1;

		case 2: return 10;

		case 3: return 4;

		case 4: return 7;

		case 5: return 10;

		default: return 10;
		}
		break;
	}
	return 10;
}

// Position - 0xEE7
int func_18(int iParam0) {
	if (iParam0 == 145) {
		return 7;
	}
	if (iParam0 < 150) {
		return Global_101700.f_27009[iParam0 /*29*/].f_11;
	}
	if (iParam0 == 144) {
		return 7;
	}
	if (iParam0 == 150) {
		return 6;
	}
	if (iParam0 == 151) {
		return 6;
	}
	return 6;
}

// Position - 0xF42
int func_19() {
	func_20();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0xF5B
void func_20() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_23(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_22(player::player_ped_id());
			if (func_25(iVar0) && (!func_21(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_25(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x1058
bool func_21(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x1066
int func_22(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_23(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x10A3
int func_23(int iParam0) {
	if (func_25(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x10CD
int func_24(int iParam0) {
	if (func_25(iParam0)) {
		if (Global_101700.f_8044 || Global_3 || func_5(0)) {
			return Global_101700.f_2095.f_539.f_1576[iParam0];
		}
		else {
			return 1;
		}
	}
	return 0;
}

// Position - 0x111B
bool func_25(int iParam0) { return iParam0 < 3; }

// Position - 0x1127
int func_26(int iParam0) {
	switch (iParam0) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;
	}
	return 0;
}

// Position - 0x115E
bool func_27(int iParam0) {
	func_20();
	return iParam0 == Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x117A
int func_28(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	else if (iParam0 == 2) {
		return 2;
	}
	else if (iParam0 == 1) {
		return 1;
	}
	return 145;
}

// Position - 0x11A8
bool func_29(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x11B7
int func_30() {
	func_20();
	switch (Global_101700.f_2095.f_539.f_3549) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;
	}
	return 0;
}

// Position - 0x11FD
bool func_31(int iParam0) {
	if (iParam0 == 146 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_99.f_58[iParam0];
}

// Position - 0x122A
void func_32(int *iParam0, var *uParam1, var *uParam2, var *uParam3, vector3 vParam4, char *sParam7) {
	int iVar0;
	vector3 vVar1;

	if (ped::is_ped_injured(player::player_ped_id())) {
		return;
	}
	if (!*iParam0) {
		if (!func_40(uParam1)) {
			*iParam0 = 1;
		}
		else if (func_37(uParam1, 1f)) {
			*iParam0 = 1;
		}
	}
	else if (player::is_player_playing(player::player_id())) {
		*uParam2 = interior::get_interior_from_entity(player::player_ped_id());
		if (!gameplay::is_string_null_or_empty(sParam7)) {
			if (!interior::is_valid_interior(*uParam3)) {
				*uParam3 = interior::get_interior_at_coords_with_type(vParam4, sParam7);
			}
		}
		func_34(uParam1);
		*iParam0 = 0;
	}
	if (interior::is_valid_interior(*uParam2) && interior::is_interior_ready(*uParam2)) {
		if (*uParam2 == *uParam3) {
			if (player::is_player_wanted_level_greater(player::player_id(), 0)) {
				return;
			}
			controls::disable_control_action(0, 47, 1);
			controls::disable_control_action(0, 38, 1);
			controls::disable_control_action(0, 22, 1);
			controls::disable_control_action(0, 46, 1);
			controls::disable_control_action(0, 25, 1);
			controls::disable_control_action(0, 140, 1);
			controls::disable_control_action(0, 141, 1);
			controls::disable_control_action(0, 142, 1);
			controls::disable_control_action(0, 143, 1);
			controls::disable_control_action(0, 142, 1);
			if (cam::get_follow_ped_cam_view_mode() == 4) {
				controls::disable_control_action(0, 21, 1);
			}
			controls::disable_control_action(0, 69, 1);
			controls::disable_control_action(0, 70, 1);
			controls::disable_control_action(0, 68, 1);
			controls::disable_control_action(0, 92, 1);
			controls::disable_control_action(0, 99, 1);
			controls::disable_control_action(0, 115, 1);
			controls::disable_control_action(0, 37, 1);
			controls::disable_control_action(0, 99, 1);
			controls::disable_control_action(0, 100, 1);
			if (controls::is_disabled_control_pressed(0, 37)) {
				if (!Global_101700.f_17473.f_17) {
					func_33("FAM_WEAPDIS", -1);
					Global_101700.f_17473.f_17 = 1;
				}
				*uParam2 = interior::get_interior_from_entity(player::player_ped_id());
				if (!gameplay::is_string_null_or_empty(sParam7)) {
					if (!interior::is_valid_interior(*uParam3)) {
						*uParam3 = interior::get_interior_at_coords_with_type(vParam4, sParam7);
					}
				}
				func_34(uParam1);
				*iParam0 = 0;
			}
			if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
				if (iVar0 != joaat("weapon_unarmed") && iVar0 != joaat("object")) {
					weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
				}
			}
			if (weapon::get_current_ped_vehicle_weapon(player::player_ped_id(), &iVar0)) {
				if (iVar0 != joaat("weapon_unarmed") && iVar0 != joaat("object")) {
					weapon::set_current_ped_vehicle_weapon(player::player_ped_id(), joaat("weapon_unarmed"));
				}
			}
		}
		else if (!gameplay::is_string_null_or_empty(sParam7)) {
			vVar1 = {interior::get_offset_from_interior_in_world_coords(*uParam2, 0f, 0f, 0f)};
			if (system::vdist2(vParam4, vVar1) < 5f * 5f) {
				if (!interior::is_valid_interior(*uParam3)) {
					*uParam3 = *uParam2;
				}
			}
		}
	}
}

// Position - 0x1487
void func_33(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x149E
void func_34(var *uParam0) { func_35(uParam0, 0f); }

// Position - 0x14AD
void func_35(int *iParam0, float fParam1) {
	uParam0->f_1 = func_36(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x14DB
float func_36(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x1533
bool func_37(var *uParam0, float fParam1) {
	if (func_40(uParam0)) {
		if (func_38(uParam0) > fParam1) {
			return true;
		}
	}
	return false;
}

// Position - 0x1555
float func_38(var *uParam0) {
	if (func_40(uParam0)) {
		if (func_39(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_36(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x1594
bool func_39(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x15A4
bool func_40(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x15B4
bool func_41(int iParam0, vector3 vParam1, float fParam4) {
	if (!func_42(iParam0)) {
		return false;
	}
	if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1), vParam1, 1) >=
		100f * fParam4) {
		return false;
	}
	if (Global_91541) {
		return false;
	}
	return true;
}

// Position - 0x15F8
int func_42(int iParam0) {
	if (!player::is_player_playing(player::player_id())) {
		return 0;
	}
	if (func_44(0) || func_44(3) || func_44(2) || func_44(14)) {
		if (streaming::is_player_switch_in_progress()) {
			if (streaming::get_player_switch_type() != 3) {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	if (func_43()) {
		if (streaming::is_player_switch_in_progress()) {
			if (streaming::get_player_switch_type() != 3) {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	if (gameplay::get_mission_flag()) {
		return 0;
	}
	if (gameplay::get_random_event_flag() && Global_101690) {
		return 0;
	}
	if (!func_27(iParam0)) {
	}
	if (!gameplay::is_bit_set(Global_101700.f_8044.f_2[27 /*3*/], 1)) {
		return 0;
	}
	return 1;
}

// Position - 0x16B9
bool func_43() {
	if (Global_88746 != -1) {
		return true;
	}
	return false;
}

// Position - 0x16CE
int func_44(int iParam0) {
	if (Global_35781 == 15) {
		return 0;
	}
	if (func_45(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x16F0
bool func_45(int iParam0) { return func_46(iParam0, Global_35781); }

// Position - 0x1701
int func_46(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x18E2
void func_47() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 1) {
		iLocal_151[iVar0] = 0;
		iVar0++;
	}
	func_48(&uLocal_156, 0, player::player_ped_id(), "FRANKLIN", 0, 1);
}

// Position - 0x1913
void func_48(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x19AE
void func_49(struct<4> Param0) {
	vLocal_114 = {Param0};
	uLocal_117 = Param0.f_3;
}

// Position - 0x19C4
void func_50() {
	int iVar0;
	int iVar1;

	func_56(&uLocal_321, &uLocal_98, &uLocal_86, &uLocal_100, &uLocal_102, &uLocal_88, &uLocal_90, &uLocal_124,
			&uLocal_126, &uLocal_128);
	iVar0 = 0;
	while (iVar0 < 1) {
		iVar1 = func_55(iVar0);
		if (iVar1 < 15) {
			if (Global_86830[iVar1] != 141) {
				func_54(iVar1);
				Global_86830[iVar1] = 141;
			}
			func_51(iVar1);
		}
		iVar0++;
	}
	gameplay::set_game_paused(0);
	script::terminate_this_thread();
}

// Position - 0x1A32
void func_51(int iParam0) {
	int *iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = func_53(iParam0, &iVar0);
	if (iVar1 != 145) {
		if (func_25(iVar1)) {
			iVar0 = func_23(iVar1);
		}
		else {
			iVar0 = func_52(iVar1);
		}
	}
	streaming::set_model_as_no_longer_needed(iVar0);
}

// Position - 0x1A70
int func_52(int iParam0) {
	if (!func_25(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x1A9B
int func_53(int iParam0, int *iParam1) {
	*iParam1 = 0;
	switch (iParam0) {
	case 0: return 14;

	case 1: return 15;

	case 2: return 17;

	case 5: return 44;

	case 6: return 19;

	case 7: return 37;

	case 10: return 20;

	case 8: return 0;

	case 9: return 2;

	case 11: return 40;

	case 12: *iParam1 = joaat("s_f_m_maid_01"); return 145;

	case 13: return 32;

	case 14: return 24;

	case 3: *iParam1 = joaat("s_f_m_maid_01"); return 145;

	case 4: *iParam1 = joaat("s_m_m_gardener_01"); return 145;

	case 15: return 150;
	}
	return 145;
}

// Position - 0x1BA6
void func_54(int iParam0) {
	switch (Global_86830[iParam0]) {
	case 137:
	case 138:
	case 139:
	case 140:
	case 141: break;

	default: Global_101700.f_17473[iParam0] = Global_86830[iParam0]; break;
	}
}

// Position - 0x1BF2
int func_55(int iParam0) {
	switch (iParam0) {
	case 0: return 16;

	case 1: return 15;
	}
	return 16;
}

// Position - 0x1C1F
void func_56(var *uParam0, var *uParam1, var *uParam2, var *uParam3, var *uParam4, var *uParam5, var *uParam6,
			 var *uParam7, var *uParam8, var *uParam9) {
	int iVar0;
	struct<8> Var1;
	int iVar17;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (ped::is_synchronized_scene_running((*uParam0)[iVar0])) {
			ped::detach_synchronized_scene((*uParam0)[iVar0]);
		}
		(*uParam0)[iVar0] = -1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		if (func_77((*uParam1)[iVar0], "familyVeh", iVar0)) {
			vehicle::delete_vehicle(&(*uParam1)[iVar0]);
		}
		if (entity::does_entity_exist((*uParam1)[iVar0]) &&
			entity::does_entity_belong_to_this_script((*uParam1)[iVar0], 1)) {
			entity::set_vehicle_as_no_longer_needed(&(*uParam1)[iVar0]);
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < *uParam2) {
		if (func_76(4, (*uParam2)[iVar0])) {
			func_75(4, (*uParam2)[iVar0], 0);
		}
		if (*uParam2)
			[iVar0] != player::player_ped_id() {
				if (func_77((*uParam2)[iVar0], "familyPed", iVar0)) {
					ped::delete_ped(&(*uParam2)[iVar0]);
				}
				func_74(&(*uParam2)[iVar0]);
			}
		if (entity::does_entity_exist((*uParam3)[iVar0])) {
			if (entity::is_entity_attached((*uParam3)[iVar0])) {
				entity::detach_entity((*uParam3)[iVar0], 1, 1);
			}
		}
		if (func_77((*uParam3)[iVar0], "familyProp", iVar0)) {
			object::delete_object(&(*uParam3)[iVar0]);
		}
		if (entity::does_entity_exist((*uParam3)[iVar0]) &&
			entity::does_entity_belong_to_this_script((*uParam3)[iVar0], 1)) {
			entity::set_object_as_no_longer_needed(&(*uParam3)[iVar0]);
		}
		if (func_77((*uParam5)[iVar0], "familyExtraPed", iVar0)) {
			ped::delete_ped(&(*uParam5)[iVar0]);
		}
		if (entity::does_entity_exist((*uParam5)[iVar0]) &&
			entity::does_entity_belong_to_this_script((*uParam5)[iVar0], 1)) {
			entity::set_ped_as_no_longer_needed(&(*uParam5)[iVar0]);
		}
		if ((*uParam4)[iVar0] != 0) {
			streaming::set_model_as_no_longer_needed((*uParam4)[iVar0]);
		}
		if ((*uParam6)[iVar0] != 0) {
			streaming::set_model_as_no_longer_needed((*uParam6)[iVar0]);
		}
		func_73(&(*uParam7)[iVar0], &(*uParam8)[iVar0], &(*uParam9)[iVar0 /*16*/]);
		iVar0++;
	}
	iVar17 = 0;
	while (iVar17 < 139) {
		StringCopy(&Var1, "", 64);
		if (func_72(iVar17, &Var1)) {
			streaming::remove_anim_dict(&Var1);
		}
		iVar17++;
	}
	func_69();
	func_65();
	func_57(-181320640);
	func_57(1418815087);
	func_57(2087297077);
	func_57(313472619);
	func_57(2038672434);
	func_57(1666308520);
	func_57(1894462438);
	func_57(1728635625);
	func_57(975196153);
	func_57(-710274964);
	func_57(1289879258);
	func_57(1621076324);
	func_57(1005256598);
	func_57(1127548000);
	func_57(-1291788156);
	func_57(1993031175);
	Global_86847 = 8;
	Global_86848 = -1;
}

// Position - 0x1EDB
int func_57(int iParam0) {
	int iVar0;
	int iVar1;

	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] == iParam0) {
			if (LastDispatchedMessageOrCall != iVar0) {
				func_64(iVar0);
				func_61(iParam0);
				iVar1 = 1;
			}
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar0 /*15*/] == iParam0) {
			func_61(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar0 /*15*/] == iParam0) {
			func_60(iParam0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] == iParam0) {
			func_59(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] == iParam0) {
			func_58(iVar0);
			iVar1 = 1;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0x2002
void func_58(int iParam0) {
	int iVar0;
	struct<10> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_866) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_866 - 2) {
			G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/] = {G_SomeGlobalState.MessageCallStates.f_765[iVar0 + 1 /*10*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_866 > 0) {
		G_SomeGlobalState.MessageCallStates.f_765[G_SomeGlobalState.MessageCallStates.f_866 - 1 /*10*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_866--;
	}
}

// Position - 0x20BB
void func_59(int iParam0) {
	int iVar0;
	struct<14> Var1;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_764) {
		return;
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_764 - 2) {
			G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/] = {G_SomeGlobalState.MessageCallStates.f_651[iVar0 + 1 /*14*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_764 > 0) {
		G_SomeGlobalState.MessageCallStates.f_651[G_SomeGlobalState.MessageCallStates.f_764 - 1 /*14*/] = {Var1};
		G_SomeGlobalState.MessageCallStates.f_764--;
	}
	func_3(0);
	func_3(1);
	func_3(2);
}

// Position - 0x2183
void func_60(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_650) {
		if (G_SomeGlobalState.MessageCallStates.f_199[iVar15 /*15*/] == iParam0) {
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_650 - 2) {
				G_SomeGlobalState.MessageCallStates.f_199[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_199[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_199[G_SomeGlobalState.MessageCallStates.f_650 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_650--;
			return;
		}
		iVar15++;
	}
}

// Position - 0x2230
void func_61(int iParam0) {
	struct<15> Var0;
	int iVar15;
	int iVar16;

	iVar15 = 0;
	while (iVar15 < G_SomeGlobalState.MessageCallStates.f_198) {
		if (G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/] == iParam0) {
			func_62(G_SomeGlobalState.MessageCallStates.f_137[iVar15 /*15*/].f_6);
			iVar16 = iVar15;
			while (iVar16 <= G_SomeGlobalState.MessageCallStates.f_198 - 2) {
				G_SomeGlobalState.MessageCallStates.f_137[iVar16 /*15*/] = {G_SomeGlobalState.MessageCallStates.f_137[iVar16 + 1 /*15*/]};
				iVar16++;
			}
			G_SomeGlobalState.MessageCallStates.f_137[G_SomeGlobalState.MessageCallStates.f_198 - 1 /*15*/] = {Var0};
			G_SomeGlobalState.MessageCallStates.f_198--;
			return;
		}
		iVar15++;
	}
}

// Position - 0x22EC
int func_62(int iParam0) {
	int iVar0;

	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] == 1) {
			Global_101700.f_27009[iParam0 /*29*/].f_19[Global_14443] = 0;
			if (Global_101700.f_27009[iParam0 /*29*/].f_24[Global_14443] == 0) {
				iVar0 = Global_14443;
				func_63(iParam0, iVar0);
			}
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x235D
void func_63(int iParam0, int iParam1) {
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (iParam1 > 3) {
		}
		else {
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 0;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 0;
		}
	}
}

// Position - 0x23A0
void func_64(int iParam0) {
	int iVar0;
	int iVar1;
	struct<15> Var2;

	if (iParam0 < 0 || iParam0 >= G_SomeGlobalState.MessageCallStates.f_136) {
		return;
	}
	iVar1 = G_SomeGlobalState.MessageCallStates[iParam0 /*15*/].f_2;
	if (G_SomeGlobalState.MessageCallStates.f_136 > 1) {
		iVar0 = iParam0;
		while (iVar0 <= G_SomeGlobalState.MessageCallStates.f_136 - 2) {
			G_SomeGlobalState.MessageCallStates[iVar0 /*15*/] = {G_SomeGlobalState.MessageCallStates[iVar0 + 1 /*15*/]};
			iVar0++;
		}
	}
	if (G_SomeGlobalState.MessageCallStates.f_136 > 0) {
		G_SomeGlobalState.MessageCallStates[G_SomeGlobalState.MessageCallStates.f_136 - 1 /*15*/] = {Var2};
		G_SomeGlobalState.MessageCallStates.f_136--;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		if (gameplay::is_bit_set(iVar1, iVar0)) {
			func_3(iVar0);
		}
		iVar0++;
	}
}

// Position - 0x247B
void func_65() {
	if (func_68(4)) {
		func_67(4, 0);
		func_66(4);
	}
	if (func_68(5)) {
		func_67(5, 0);
		func_66(5);
	}
	if (func_68(0)) {
		func_67(0, 0);
		func_66(0);
	}
}

// Position - 0x24BC
void func_66(int iParam0) {
	if (iParam0 != -1) {
		Global_25250[iParam0 /*11*/].f_4 = 1;
	}
}

// Position - 0x24D4
void func_67(int iParam0, int iParam1) { Global_25250[iParam0 /*11*/].f_10 = iParam1; }

// Position - 0x24E7
bool func_68(int iParam0) {
	if (iParam0 != -1) {
		if (Global_25250[iParam0 /*11*/].f_5) {
			return true;
		}
	}
	return false;
}

// Position - 0x2506
int func_69() {
	int *iVar0;
	vector3 vVar1;
	int iVar4;
	int iVar5;
	char[] cVar6[8];
	int *iVar22;
	int iVar23;
	int iVar24;

	iVar0 = 0;
	vVar1 = {0f, 0f, 0f};
	iVar4 = 226;
	iVar5 = 825812850;
	iVar22 = 0;
	iVar23 = 0;
	while (iVar23 < 11) {
		func_71(iVar23, &iVar0, &vVar1, &iVar4, &iVar5, &cVar6, &iVar22);
		if (object::does_object_of_type_exist_at_coords(vVar1, 10f, iVar0, 0)) {
			iVar24 = object::get_closest_object_of_type(vVar1, 10f, iVar0, 0, 0, 1);
			if (entity::does_entity_exist(iVar24)) {
				if (iVar5 == 825812850) {
					entity::set_entity_rotation(iVar24, 0f, 0f, 21f, 2, 1);
				}
				entity::set_object_as_no_longer_needed(&iVar24);
			}
		}
		if (iVar4 != 226) {
		}
		else if (!object::_does_door_exist(iVar5)) {
		}
		else {
			object::_set_door_acceleration_limit(iVar5, 3, 1, 1);
			object::_set_door_ajar_angle(iVar5, 0f, 1, 1);
			if (iVar23 != 6 && iVar23 != 7 && iVar23 != 8 && iVar23 != 9) {
				object::remove_door_from_system(iVar5);
			}
		}
		iVar23++;
	}
	func_70(4, 0);
	return 0;
}

// Position - 0x25F4
void func_70(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_34904[iParam0 /*31*/].f_1, 6);
	}
	else {
		gameplay::clear_bit(&Global_34904[iParam0 /*31*/].f_1, 6);
	}
}

// Position - 0x2620
void func_71(int iParam0, int *iParam1, var *uParam2, int *iParam3, int *iParam4, char *sParam5, int *iParam6) {
	switch (iParam0) {
	case 0:
		*iParam1 = joaat("v_ilev_mm_doorson");
		*uParam2 = {-806.8f, 174f, 76.9f};
		StringCopy(sParam5, "V_Michael_1_Son", 64);
		*iParam3 = 226;
		*iParam4 = 1850241841;
		*iParam6 = 0;
		break;

	case 1:
		*iParam1 = joaat("v_ilev_mm_doordaughter");
		*uParam2 = {-802.7f, 176.2f, 76.9f};
		StringCopy(sParam5, "V_Michael_1_Daught", 64);
		*iParam3 = 226;
		*iParam4 = -378388578;
		*iParam6 = 0;
		break;

	case 2:
		*iParam1 = joaat("v_ilev_mm_doorw");
		*uParam2 = {-805f, 171.9f, 76.9f};
		StringCopy(sParam5, "V_Michael_1_WC", 64);
		*iParam3 = 226;
		*iParam4 = -1223666875;
		*iParam6 = 0;
		break;

	case 3:
		*iParam1 = joaat("v_ilev_mm_doorw");
		*uParam2 = {-809.281f, 177.855f, 76.89f};
		StringCopy(sParam5, "V_Michael_1_WC", 64);
		*iParam3 = 226;
		*iParam4 = 1893421006;
		*iParam6 = 0;
		break;

	case 4:
		*iParam1 = joaat("v_ilev_mm_fridge_l");
		*uParam2 = {-804.1f, 185.8f, 72.7f};
		StringCopy(sParam5, "V_Michael_G_Kitche", 64);
		*iParam3 = 226;
		*iParam4 = 825812850;
		*iParam6 = 1;
		break;

	case 5:
		*iParam1 = joaat("v_ilev_mm_fridge_r");
		*uParam2 = {-802.8f, 186.3f, 72.7f};
		StringCopy(sParam5, "V_Michael_G_Kitche", 64);
		*iParam3 = 226;
		*iParam4 = 825812850;
		*iParam6 = 1;
		break;

	case 6:
		*iParam1 = joaat("prop_bh1_48_backdoor_l");
		*uParam2 = {-796.5657f, 177.2214f, 73.0405f};
		StringCopy(sParam5, "V_Michael_G_Kitche", 64);
		*iParam3 = 41;
		*iParam4 = 776026812;
		*iParam6 = 1;
		break;

	case 7:
		*iParam1 = joaat("prop_bh1_48_backdoor_r");
		*uParam2 = {-794.5051f, 178.0124f, 73.0405f};
		StringCopy(sParam5, "V_Michael_G_Kitche", 64);
		*iParam3 = 42;
		*iParam4 = 698422331;
		*iParam6 = 1;
		break;

	case 8:
		*iParam1 = joaat("v_ilev_mm_doorm_l");
		*uParam2 = {-817f, 179f, 73f};
		StringCopy(sParam5, "V_Michael_G_Front", 64);
		*iParam3 = 38;
		*iParam4 = -2097039789;
		*iParam6 = 1;
		break;

	case 9:
		*iParam1 = joaat("v_ilev_mm_doorm_r");
		*uParam2 = {-816f, 178f, 73f};
		StringCopy(sParam5, "V_Michael_G_Front", 64);
		*iParam3 = 39;
		*iParam4 = -2127416656;
		*iParam6 = 1;
		break;

	case 10:
		*iParam1 = joaat("v_ilev_trev_doorbath");
		*uParam2 = {-1150.158f, -1518.768f, 10.781f};
		StringCopy(sParam5, "rm_bathroom", 64);
		*iParam3 = 226;
		*iParam4 = 2007032394;
		*iParam6 = 0;
		break;

	default:
		*iParam1 = 0;
		*uParam2 = {0f, 0f, 0f};
		StringCopy(sParam5, "NULL", 64);
		*iParam3 = 226;
		*iParam4 = 825812850;
		*iParam6 = 0;
		break;
	}
}

// Position - 0x28E8
bool func_72(int iParam0, char *sParam1) {
	switch (iParam0) {
	case 0: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_12", 64); return true;

	case 2: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_9", 64); return true;

	case 3: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_9", 64); return true;

	case 4: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_10", 64); return true;

	case 18: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_3@BASE", 64); return true;

	case 5: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_2@IG_2_P2", 64); return true;

	case 21: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_2@IG_2_P2", 64); return true;

	case 9: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_3@SLEEPING", 64); return true;

	case 11: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_5@BASE", 64); return true;

	case 12: StringCopy(sParam1, "TIMETABLE@TRACY@IG_9_2@", 64); return true;

	case 13: StringCopy(sParam1, "TIMETABLE@TRACY@IG_9_7@", 64); return true;

	case 14: StringCopy(sParam1, "TIMETABLE@TRACY@IG_9_8@", 64); return true;

	case 15: StringCopy(sParam1, "TIMETABLE@TRACY@IG_9_11@", 64); return true;

	case 16: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_1@BASE", 64); return true;

	case 17: StringCopy(sParam1, "TIMETABLE@JIMMY@IG_4@BASE", 64); return true;

	case 20: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_2", 64); return true;

	case 24: StringCopy(sParam1, "SWITCH@MICHAEL@AROUND_THE_TABLE_SELFISH", 64); return true;

	case 19: StringCopy(sParam1, "SWITCH@MICHAEL@ON_SOFA", 64); return true;

	case 25: StringCopy(sParam1, "TIMETABLE@JIMMY@MICS3_IG_15@", 64); return true;

	case 26: StringCopy(sParam1, "TIMETABLE@TRACY@IG_3@BASE", 64); return true;

	case 32: StringCopy(sParam1, "TIMETABLE@TRACY@IG_5@BASE", 64); return true;

	case 33: StringCopy(sParam1, "TIMETABLE@TRACY@IG_8@BASE", 64); return true;

	case 38: StringCopy(sParam1, "TIMETABLE@TRACY@IG_7@BASE", 64); return true;

	case 34: StringCopy(sParam1, "TIMETABLE@TRACY@IG_2@IDLE_A", 64); return true;

	case 35: StringCopy(sParam1, "TIMETABLE@TRACY@IG_15@BASE", 64); return true;

	case 37: StringCopy(sParam1, "TIMETABLE@TRACY@IG_4@", 64); return true;

	case 36: StringCopy(sParam1, "TIMETABLE@TRACY@IG_1@BASE", 64); return true;

	case 28: StringCopy(sParam1, "TIMETABLE@TRACY@IG_14@", 64); return true;

	case 43: StringCopy(sParam1, "TIMETABLE@TRACY@SLEEP@", 64); return true;

	case 44: StringCopy(sParam1, "TIMETABLE@TRACY@FAMR_IG_4", 64); return true;

	case 29: StringCopy(sParam1, "TIMETABLE@TRACY@FAMR_IG_4", 64); return true;

	case 30: StringCopy(sParam1, "TIMETABLE@TRACY@FAMR_IG_4", 64); return true;

	case 45: StringCopy(sParam1, "TIMETABLE@TRACY@FAMR_IG_5", 64); return true;

	case 47: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_9", 64); return true;

	case 48: StringCopy(sParam1, "TIMETABLE@AMANDA@FACEMASK@BASE", 64); return true;

	case 68: StringCopy(sParam1, "TIMETABLE@AMANDA@FACEMASK@BASE", 64); return true;

	case 50: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_4", 64); return true;

	case 69: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_4", 64); return true;

	case 51: StringCopy(sParam1, "TIMETABLE@AMANDA@MAGDEMO_IG_2_SYNCED", 64); return true;

	case 52: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_7", 64); return true;

	case 67: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_7", 64); return true;

	case 53: StringCopy(sParam1, "TIMETABLE@AMANDA@DRUNK_IN_KITCHEN@", 64); return true;

	case 54: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_5", 64); return true;

	case 70: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_5", 64); return true;

	case 64: StringCopy(sParam1, "TIMETABLE@AMANDA@DRUNK@BASE", 64); return true;

	case 55: StringCopy(sParam1, "TIMETABLE@AMANDA@DRUNK@BASE", 64); return true;

	case 71: StringCopy(sParam1, "TIMETABLE@AMANDA@DRUNK@BASE", 64); return true;

	case 56: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_2_P2", 64); return true;

	case 57: StringCopy(sParam1, "TIMETABLE@AMANDA@DRUNK@BASE", 64); return true;

	case 58: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_3", 64); return true;

	case 59: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_11", 64); return true;

	case 72: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_11", 64); return true;

	case 60: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_11", 64); return true;

	case 61: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_6", 64); return true;

	case 63: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_6", 64); return true;

	case 62: StringCopy(sParam1, "TIMETABLE@AMANDA@IG_6", 64); return true;

	case 65: StringCopy(sParam1, "SWITCH@MICHAEL@BEDROOM", 64); return true;

	case 66: StringCopy(sParam1, "SWITCH@MICHAEL@GETS_READY", 64); return true;

	case 73: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_6", 64); return true;

	case 74: StringCopy(sParam1, "TIMETABLE@REUNITED@IG_7", 64); return true;

	case 76: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_SURFACE@BASE", 64); return true;

	case 78: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_SURFACE@BASE", 64); return true;

	case 85: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_SURFACE@BASE", 64); return true;

	case 77: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_SURFACE_1@", 64); return true;

	case 79: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_WINDOW@BASE", 64); return true;

	case 86: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_WINDOW@BASE", 64); return true;

	case 80: StringCopy(sParam1, "TIMETABLE@MAID@CLEANING_WINDOW@BASE", 64); return true;

	case 81: StringCopy(sParam1, "TIMETABLE@MAID@IG_2@", 64); return true;

	case 82: StringCopy(sParam1, "TIMETABLE@MAID@IG_8@", 64); return true;

	case 83: StringCopy(sParam1, "TIMETABLE@MAID@IG_8@", 64); return true;

	case 89: StringCopy(sParam1, "TIMETABLE@GARDENER@CLEAN_POOL@", 64); return true;

	case 90: StringCopy(sParam1, "TIMETABLE@GARDENER@LAWNMOW@", 64); return true;

	case 91: StringCopy(sParam1, "TIMETABLE@GARDENER@FILLING_CAN", 64); return true;

	case 94: StringCopy(sParam1, "TIMETABLE@DENICE@IG_1", 64); return true;

	case 95: StringCopy(sParam1, "TIMETABLE@DENICE@IG_2", 64); return true;

	case 96: StringCopy(sParam1, "TIMETABLE@DENICE@IG_3", 64); return true;

	case 98: StringCopy(sParam1, "TIMETABLE@DENICE@IG_3", 64); return true;

	case 97: StringCopy(sParam1, "TIMETABLE@DENICE@IG_4", 64); break;

	case 100: StringCopy(sParam1, "TIMETABLE@RON@HAND_RADIO_IG_1", 64); return true;

	case 101: StringCopy(sParam1, "TIMETABLE@RON@IG_2", 64); return true;

	case 119: StringCopy(sParam1, "TIMETABLE@RON@IG_2", 64); return true;

	case 102: StringCopy(sParam1, "TIMETABLE@RON@IG_3_COUCH", 64); return true;

	case 103: StringCopy(sParam1, "TIMETABLE@RON@IG_3_COUCH", 64); return true;

	case 104: StringCopy(sParam1, "TIMETABLE@RON@IG_4_SMOKING_METH", 64); return true;

	case 105: StringCopy(sParam1, "TIMETABLE@RON@MOONSHINE_IG_5", 64); return true;

	case 106: StringCopy(sParam1, "TIMETABLE@RON@IG_6", 64); return true;

	case 107: StringCopy(sParam1, "TIMETABLE@MICHAEL@ON_CHAIRIDLE_A", 64); return true;

	case 108: StringCopy(sParam1, "TIMETABLE@MICHAEL@ON_CLUBCHAIRBASE", 64); return true;

	case 109: StringCopy(sParam1, "TIMETABLE@MICHAEL@ON_SOFABASE", 64); return true;

	case 110: StringCopy(sParam1, "TIMETABLE@MICHAEL@TALK_PHONEbase", 64); return true;

	case 111: StringCopy(sParam1, "TIMETABLE@MICHAEL@TALK_PHONEEXIT_A", 64); return true;

	case 116: StringCopy(sParam1, "TIMETABLE@TREVOR@IG_1", 64); return true;

	case 117: StringCopy(sParam1, "TIMETABLE@TREVOR@TRV_IG_2", 64); return true;

	case 112: StringCopy(sParam1, "TIMETABLE@TREVOR@SMOKING_METH@BASE", 64); return true;

	case 113: StringCopy(sParam1, "TIMETABLE@TREVOR@ON_THE_TOILET", 64); return true;

	case 114: StringCopy(sParam1, "TIMETABLE@TREVOR@GRENADE_THROWING", 64); return true;

	case 115: StringCopy(sParam1, "SWITCH@TREVOR@BED", 64); return true;

	case 118: StringCopy(sParam1, "TIMETABLE@RON@IG_1", 64); return true;

	case 120: StringCopy(sParam1, "TIMETABLE@RON@IG_3", 64); return true;

	case 121: StringCopy(sParam1, "TIMETABLE@RON@IG_4", 64); return true;

	case 122: StringCopy(sParam1, "TIMETABLE@PATRICIA@PAT_IG_1", 64); return true;

	case 123: StringCopy(sParam1, "TIMETABLE@PATRICIA@PAT_IG_2@BASE", 64); return true;

	case 124: StringCopy(sParam1, "TIMETABLE@PATRICIA@PAT_IG_3@", 64); return true;

	case 126: StringCopy(sParam1, "TIMETABLE@FLOYD@CLEAN_KITCHEN@BASE", 64); return true;

	case 127: StringCopy(sParam1, "TIMETABLE@FLOYD@CRYINGONBED@BASE", 64); return true;

	case 130: StringCopy(sParam1, "TIMETABLE@FLOYD@CALLING", 64); return true;

	case 131: StringCopy(sParam1, "TIMETABLE@FLOYD@ENDING_CALL", 64); return true;

	case 132: StringCopy(sParam1, "TIMETABLE@FLOYD@HIDING_BEHIND_COUCH", 64); return true;

	case 133: StringCopy(sParam1, "TIMETABLE@FLOYD@HIDING_BEHIND_COUCH", 64); return true;

	case 134: StringCopy(sParam1, "TIMETABLE@FLOYD@HIDING_BEHIND_COUCH", 64); return true;

	case 135: StringCopy(sParam1, "TIMETABLE@FLOYD@CRYINGONBED_IG_5@", 64); return true;
	}
	StringCopy(sParam1, "", 64);
	return false;
}

// Position - 0x3206
int func_73(int *iParam0, int *iParam1, char *sParam2) {
	audio::stop_stream();
	if (*iParam0 == 0 && *iParam1 == -1 && gameplay::is_string_null_or_empty(sParam2)) {
		return 0;
	}
	if (*iParam0 != 0) {
		audio::stop_stream();
		*iParam0 = 0;
	}
	if (*iParam1 != -1) {
		audio::stop_sound(*iParam1);
		*iParam1 = -1;
	}
	if (!gameplay::is_string_null_or_empty(sParam2)) {
		audio::release_named_script_audio_bank(sParam2);
		if (gameplay::are_strings_equal(sParam2, "AFT_SON_PORN")) {
			audio::set_audio_flag("DisableReplayScriptStreamRecording", 0);
		}
	}
	StringCopy(sParam2, "", 64);
	return 1;
}

// Position - 0x3282
void func_74(int iParam0) {
	if (!ped::is_ped_injured(*iParam0)) {
		if (ai::get_script_task_status(*iParam0, -2017877118) != 0) {
			ped::set_ped_keep_task(*iParam0, 1);
		}
	}
	if (entity::does_entity_exist(*iParam0)) {
		if (entity::does_entity_belong_to_this_script(*iParam0, 1)) {
			entity::set_ped_as_no_longer_needed(iParam0);
		}
	}
	else {
		entity::set_ped_as_no_longer_needed(iParam0);
	}
}

// Position - 0x32D1
void func_75(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	bool bVar1;

	if (!iParam2) {
		if (!entity::does_entity_exist(iParam1)) {
			return;
		}
	}
	if (Global_34904[iParam0 /*31*/].f_24 == 0) {
		return;
	}
	bVar1 = false;
	iVar0 = 0;
	while (iVar0 < Global_34904[iParam0 /*31*/].f_24) {
		if (bVar1) {
			Global_34904[iParam0 /*31*/].f_25[iVar0 - 1] = Global_34904[iParam0 /*31*/].f_25[iVar0];
			Global_34904[iParam0 /*31*/].f_25[iVar0] = 0;
		}
		else if (iParam1 == Global_34904[iParam0 /*31*/].f_25[iVar0]) {
			Global_34904[iParam0 /*31*/].f_25[iVar0] = 0;
			bVar1 = true;
		}
		iVar0++;
	}
	if (bVar1) {
		Global_34904[iParam0 /*31*/].f_24--;
	}
}

// Position - 0x338D
bool func_76(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_34904[iParam0 /*31*/].f_24) {
		if (iParam1 == Global_34904[iParam0 /*31*/].f_25[iVar0]) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x33C6
bool func_77(int iParam0, char *sParam1, int iParam2) {
	if (!entity::does_entity_exist(iParam0)) {
		return false;
	}
	if (player::get_cause_of_most_recent_force_cleanup() == 64 &&
		entity::get_entity_model(iParam0) != joaat("prop_bong_01")) {
		if (!entity::is_entity_dead(iParam0, 0) && !entity::does_entity_belong_to_this_script(iParam0, 1)) {
			entity::set_entity_as_mission_entity(iParam0, 1, 0);
		}
		return true;
	}
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (entity::is_entity_a_vehicle(iParam0) && player::is_player_playing(player::player_id())) {
			if (ped::is_ped_in_vehicle(player::player_ped_id(), entity::get_vehicle_index_from_entity_index(iParam0),
									   0)) {
				return false;
			}
		}
	}
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (!entity::does_entity_belong_to_this_script(iParam0, 1)) {
			return false;
		}
		if (entity::get_entity_model(iParam0) == joaat("prop_bong_01")) {
			return false;
		}
	}
	if (Global_91541) {
		return true;
	}
	if (cam::is_screen_faded_out()) {
		return true;
	}
	if (func_78() || gameplay::get_mission_flag()) {
		if (entity::is_entity_on_screen(iParam0)) {
			return false;
		}
		return true;
	}
	sParam1 = sParam1;
	iParam2 = iParam2;
	return false;
}

// Position - 0x34BF
int func_78() {
	if (Global_35781 == 15) {
		return 0;
	}
	return 1;
}

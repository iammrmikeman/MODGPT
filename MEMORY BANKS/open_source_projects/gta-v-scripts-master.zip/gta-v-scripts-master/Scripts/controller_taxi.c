#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
var uLocal_20 = 0;
var uLocal_21 = 0;
var uLocal_22 = -1;
var uLocal_23 = 0;
var uLocal_24 = 0;
var uLocal_25 = 0;
var uLocal_26 = 0;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 1000;
var uLocal_30 = 1000;
var uLocal_31 = 0;
char *sLocal_32 = NULL;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
float fLocal_37 = 0f;
float fLocal_38 = 0f;
var uLocal_39 = 0;
int iLocal_40 = 0;
var uLocal_41 = 0;
var uLocal_42 = 0;
float fLocal_43 = 0f;
float fLocal_44 = 0f;
float fLocal_45 = 0f;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
int iLocal_51 = 0;
int iLocal_52 = 0;
int iLocal_53 = 0;
int iLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 6;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
vector3 vLocal_83 = {0f, 0f, 0f};
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
int iLocal_98 = 0;
vector3 vLocal_99 = {0f, 0f, 0f};
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
int iLocal_105 = 0;
int iLocal_106 = 0;
int iLocal_107 = 0;
int iLocal_108 = 0;
int iLocal_109 = 0;
int iLocal_110 = 0;
float fLocal_111 = 0f;
int iLocal_112 = 0;
int iLocal_113 = 0;
int iLocal_114 = 0;
int iLocal_115 = 0;
int iLocal_116 = 0;
int iLocal_117 = 0;
int *iLocal_118 = NULL;
var uLocal_119 = 0;
var uLocal_120 = 0;
int *iLocal_121 = NULL;
var uLocal_122 = 0;
var uLocal_123 = 0;
var *uLocal_124 = NULL;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 0;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
var uLocal_230 = 0;
var uLocal_231 = 0;
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 0;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 0;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 0;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
var uLocal_281 = 0;
var uLocal_282 = 0;
var uLocal_283 = 0;
var uLocal_284 = 0;
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	vector3 vVar6;
	vector3 vVar12;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_32 = "NULL";
	fLocal_33 = 0f;
	fLocal_37 = -0.0375f;
	fLocal_38 = 0.17f;
	iLocal_40 = 3;
	fLocal_43 = 80f;
	fLocal_44 = 140f;
	fLocal_45 = 180f;
	iLocal_51 = 1;
	iLocal_52 = 65;
	iLocal_53 = 49;
	iLocal_54 = 64;
	uLocal_77 = ui::_0x4A9923385BDB9DAD();
	uLocal_78 = ui::_get_blip_info_id_iterator();
	vLocal_83 = {500f, 500f, 500f};
	iLocal_108 = -1;
	fLocal_111 = 0f;
	iLocal_117 = 1;
	iVar0 = 0;
	iVar1 = 0;
	func_84(&Global_101700.f_18056, 4);
	func_84(&Global_101700.f_18056, 256);
	if (player::has_force_cleanup_occurred(82)) {
		func_83();
	}
	func_82(16);
	while (true) {
		iVar0 = !func_81(0, 12);
		iVar2 = 0;
		if (iVar0 && iVar1 != 1) {
			iVar1 = 1;
		}
		if (iVar1 == 2) {
			if (func_80(9)) {
				func_79(&iLocal_118);
				iVar1 = 1;
			}
		}
		switch (iVar1) {
		case 0:
			if (entity::does_entity_exist(player::player_ped_id())) {
				iVar3 = func_78(player::player_ped_id());
				if (iVar3 == 0 || iVar3 == 2 || iVar3 == 1) {
					func_77();
					if (!func_76(Global_101700.f_18056, 64)) {
						func_74(&Global_101700.f_18056, 64);
					}
					func_73(&uLocal_124);
					iVar1 = 1;
					func_71(&iLocal_118);
				}
			}
			iVar2 = 100;
			break;

		case 1:
			if (func_70(1)) {
				iLocal_109 = gameplay::get_game_timer();
			}
			if (!func_69() && !Global_88752) {
				if (iVar1 != 2) {
					if (!gameplay::is_minigame_in_progress() && !iVar0 && !func_68(5)) {
						func_65();
						if (func_64()) {
							if (!iLocal_113) {
								if (func_62() == 2) {
									if (!func_76(Global_101700.f_18056, 1)) {
										switch (func_61("TC_H_TOODAMAGED")) {
										case 2: func_59("TC_H_TOODAMAGED", 1, 0, 1000, 10000, 7, 0, 0, 0); break;

										case 1: func_74(&Global_101700.f_18056, 1); break;
										}
									}
								}
								else {
									func_84(&Global_101700.f_18056, 1);
								}
								iLocal_113 = 1;
							}
							if (player::get_player_wanted_level(player::player_id()) != 0) {
								iLocal_106 = 0;
							}
							else if (iLocal_114) {
								if (!func_76(Global_101700.f_18056, 16384)) {
									switch (func_61("TC_ANOTHERJOB")) {
									case 2: func_59("TC_ANOTHERJOB", 1, 0, 1000, 10000, 7, 0, 0, 0); break;

									case 1: func_74(&Global_101700.f_18056, 16384); break;
									}
								}
							}
							else if (!func_76(Global_101700.f_18056, 16)) {
								if (!iLocal_116) {
									switch (func_61("TC_HOWTOSTART")) {
									case 2: func_59("TC_HOWTOSTART", 1, 0, 1000, 10000, 7, 0, 0, 0); break;

									case 1:
										iLocal_110 = gameplay::get_game_timer();
										iLocal_116 = 1;
										if (func_58("TC_HOWTOSTART")) {
											Global_101700.f_18056.f_22[15]++;
										}
										if (Global_101700.f_18056.f_22[15] >= 5) {
											func_74(&Global_101700.f_18056, 16);
										}
										break;
									}
								}
							}
							if (ui::does_blip_exist(iLocal_105)) {
								ui::remove_blip(&iLocal_105);
							}
							switch (iLocal_106) {
							case 0:
								if (func_62() == 0) {
									if (!func_57(&iLocal_118)) {
										func_56(&iLocal_118);
									}
									if (func_57(&iLocal_121)) {
										func_79(&iLocal_121);
									}
									if (func_53(&iLocal_118) > 20f) {
										if (!ui::is_help_message_being_displayed() && func_52()) {
											iLocal_107 = 9;
											StringCopy(&vLocal_99, "Taxi_Procedural", 24);
											func_51(&uLocal_124, 8, 0, "TaxiDispatch", 0, 1);
											func_50(&uLocal_124, "OJTXAUD", "OJTX_PRO_OFF", 2, 0, 0, 0);
											func_71(&iLocal_118);
											iLocal_106 = 1;
										}
										else if (!func_52()) {
											if (gameplay::get_game_timer() % 1000 < 50) {
											}
										}
									}
								}
								break;

							case 1:
								if (!func_57(&iLocal_118)) {
									func_56(&iLocal_118);
								}
								if (func_53(&iLocal_118) >= 6f) {
									switch (func_61("TC_JOBOFFERED")) {
									case 2: func_59("TC_JOBOFFERED", 1, 0, 1000, 10000, 7, 0, 0, 0); break;

									case 1:
										iLocal_112 = 1;
										func_71(&iLocal_118);
										iLocal_106 = 2;
										break;
									}
									if (gameplay::get_game_timer() % 1000 < 50) {
									}
								}
								break;

							case 2:
								if (!func_57(&iLocal_118)) {
									func_56(&iLocal_118);
								}
								if (func_53(&iLocal_118) > 15f) {
									if (!func_76(Global_101700.f_18056, 32)) {
										func_49("TC_MISSEDJOB", -1);
										func_74(&Global_101700.f_18056, 32);
									}
									fLocal_111 = gameplay::get_random_float_in_range(10f, 40f) + func_53(&iLocal_118);
									iLocal_106 = 3;
								}
								else if (iLocal_112) {
									if (func_53(&iLocal_118) > 6f) {
										iLocal_112 = 0;
										ui::clear_help(1);
									}
								}
								break;

							case 3:
								if (!func_57(&iLocal_118)) {
									func_56(&iLocal_118);
								}
								if (func_53(&iLocal_118) > fLocal_111) {
									func_79(&iLocal_118);
									iLocal_106 = 0;
								}
								break;
							}
							if (controls::is_control_pressed(0, 86) &&
								!entity::is_entity_upsidedown(player::player_ped_id()) && !Global_25341 &&
								gameplay::get_game_timer() - iLocal_109 > 3000) {
								iVar4 = func_62();
								if (iVar4 == 0) {
									if (iLocal_106 == 0 || iLocal_106 == 3) {
										func_73(&uLocal_124);
										iLocal_107 = 9;
										func_33(iLocal_107, &vLocal_99, &uLocal_124, 0);
										iLocal_115 = 1;
										iVar1 = 4;
									}
									else {
										ui::clear_prints();
										ui::clear_help(1);
										if (!func_76(Global_101700.f_18056, 128)) {
											func_74(&Global_101700.f_18056, 128);
										}
										iVar1 = 4;
									}
									script::request_script(&vLocal_99);
									func_79(&iLocal_118);
									iVar2 = 0;
								}
								else if (iVar4 == 2) {
									if (!ui::is_help_message_being_displayed()) {
										func_49("TXC_HEALTH_GONE", -1);
									}
								}
								else if (iVar4 == 3) {
									if (!ui::is_help_message_being_displayed()) {
										if (!func_58("TXC_WANTED_WARN")) {
											if (!func_76(Global_101700.f_18056, 32768)) {
												func_49("TXC_WANTED_WARN", -1);
												func_74(&Global_101700.f_18056, 32768);
											}
										}
									}
								}
							}
						}
						else {
							if (!func_57(&iLocal_121)) {
								func_56(&iLocal_121);
							}
							else {
								if (func_53(&iLocal_121) < 10f) {
									if (gameplay::get_game_timer() % 1000 < 50) {
									}
								}
								if (func_53(&iLocal_121) > 10f && iLocal_106 != 0) {
									iLocal_106 = 0;
								}
							}
							if (func_32("TC_HOWTOSTART")) {
								func_28("TC_HOWTOSTART", 1);
							}
							if (func_32("TC_JOBOFFERED")) {
								func_28("TC_JOBOFFERED", 1);
							}
							if (func_32("TC_H_TOODAMAGED")) {
								func_28("TC_H_TOODAMAGED", 1);
							}
							if (func_32("TC_ANOTHERJOB")) {
								func_28("TC_ANOTHERJOB", 1);
							}
							if (gameplay::get_game_timer() - iLocal_110 > 60000 && !func_58("TC_HOWTOSTART") &&
								iLocal_116) {
								iLocal_116 = 0;
							}
							if (iLocal_114) {
								iLocal_114 = 0;
							}
							iLocal_113 = 0;
							func_79(&iLocal_118);
						}
					}
				}
			}
			else if (player::get_player_wanted_level(player::player_id()) != 0) {
				iLocal_106 = 0;
			}
			break;

		case 4:
			if (!ped::is_ped_injured(player::player_ped_id())) {
				audio::set_horn_enabled(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 1);
			}
			if (script::has_script_loaded(&vLocal_99)) {
				iVar5 = func_24(&iLocal_108, 2, 9, 0, 0);
				if (iVar5 == 1) {
					Global_100755 = 1;
					if (iLocal_115) {
						iVar1 = 5;
					}
					else {
						iVar1 = 7;
					}
					iVar2 = 0;
				}
				else if (iVar5 == 0) {
					iLocal_106 = 0;
					iVar1 = 11;
				}
				else {
					func_23("PROCESS_TAXI_DBG_SKIP = Scene is loading.", &iLocal_117, 1000);
				}
			}
			break;

		case 5:
			StringCopy(&vVar6, "OJTX_PLRDE1", 24);
			func_22(&vVar6, 1);
			func_50(&uLocal_124, "OJTXAUD", &vVar6, 8, 0, 0, 0);
			iVar1 = 6;
			break;

		case 6:
			if (!func_21()) {
				func_50(&uLocal_124, "OJTXAUD", "OJTX_DIS_JOB", 8, 0, 0, 0);
				iVar1 = 7;
			}
			break;

		case 7:
			if (!func_21()) {
				StringCopy(&vVar12, "OJTX_ACCEPT", 24);
				func_22(&vVar12, 1);
				func_73(&uLocal_124);
				func_50(&uLocal_124, "OJTXAUD", &vVar12, 8, 0, 0, 0);
				iVar1 = 8;
			}
			break;

		case 8:
			if (func_64()) {
				if (!func_21()) {
					iLocal_114 = 0;
					if (func_32("TC_HOWTOSTART")) {
						func_28("TC_HOWTOSTART", 1);
					}
					iLocal_98 = system::start_new_script(&vLocal_99, 20500);
					script::set_script_as_no_longer_needed(&vLocal_99);
					if (!func_76(Global_101700.f_18056, 4)) {
						func_74(&Global_101700.f_18056, 4);
						vehicle::set_vehicle_model_is_suppressed(func_20(), 1);
					}
					func_74(&Global_101700.f_18056, 256);
					StringCopy(&vLocal_99, "", 24);
					iLocal_115 = 0;
					iVar1 = 10;
					iLocal_106 = 0;
				}
			}
			else {
				if (func_21()) {
					func_18();
				}
				iLocal_114 = 0;
				iLocal_115 = 0;
				script::set_script_as_no_longer_needed(&vLocal_99);
				func_74(&Global_101700.f_18056, 256);
				StringCopy(&vLocal_99, "", 24);
				iLocal_106 = 0;
				iVar1 = 10;
			}
			break;

		case 10:
			if (!script::is_thread_active(iLocal_98)) {
				func_84(&Global_101700.f_18056, 2048);
				if (func_76(Global_101700.f_18056, 4)) {
					func_84(&Global_101700.f_18056, 4);
					vehicle::set_vehicle_model_is_suppressed(func_20(), 0);
				}
				Global_100755 = 0;
				iLocal_107 = -1;
				iVar1 = 11;
				iVar2 = 0;
			}
			else if (func_76(Global_101700.f_18056, 1024)) {
				func_84(&Global_101700.f_18056, 1024);
				func_11(func_17(iLocal_107), 0, 0);
				iLocal_114 = 1;
				func_9(iLocal_107, iLocal_114);
				func_8(1, 0);
				func_5();
			}
			break;

		case 11:
			if (func_76(Global_101700.f_18056, 256)) {
				func_84(&Global_101700.f_18056, 256);
				func_4(&iLocal_108);
			}
			iLocal_108 = -1;
			if (!func_3()) {
				func_8(0, 0);
				func_2();
				StringCopy(&vLocal_99, "", 24);
				if (iLocal_98 != 0) {
					if (script::is_thread_active(iLocal_98)) {
						script::terminate_thread(iLocal_98);
						iLocal_98 = 0;
					}
				}
				func_79(&iLocal_118);
				func_1(0);
				iLocal_106 = 0;
				iVar1 = 1;
				iVar2 = 0;
			}
			break;

		case 12: func_83(); break;

		default: func_83(); break;
		}
		system::wait(iVar2);
	}
}

// Position - 0x9D6
void func_1(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x9EA
void func_2() {
	vector3 vVar0[24];

	if (gameplay::is_xbox360_version() || gameplay::is_durango_version()) {
		network::network_set_rich_presence(StackVal, 0, 0, 0);
	}
	else if (gameplay::is_ps3_version() || gameplay::is_orbis_version()) {
		StringCopy(&cVar0, "PRESENCE_0_STR", 24);
		network::_0x3E200C2BCF4164EB(0, &cVar0);
	}
}

// Position - 0xA2C
bool func_3() { return Global_91530.f_1; }

// Position - 0xA3A
void func_4(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0xA77
void func_5() { func_6(); }

// Position - 0xA84
int func_6() {
	if (func_7(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0xACF
bool func_7(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0xAFA
void func_8(int iParam0, int iParam1) {
	Global_91530.f_7 = iParam0;
	Global_91530.f_8 = iParam1;
}

// Position - 0xB12
void func_9(int iParam0, int iParam1) {
	func_10();
	if (iParam1) {
		Global_101700.f_18056.f_1[iParam0 /*2*/] = 1;
		Global_101700.f_18056.f_1[iParam0 /*2*/].f_1 = 0;
	}
	else {
		Global_101700.f_18056.f_1[iParam0 /*2*/] = 0;
		Global_101700.f_18056.f_1[iParam0 /*2*/].f_1 = 1;
	}
}

// Position - 0xB62
void func_10() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 10) {
		Global_101700.f_18056.f_1[iVar0 /*2*/].f_1 = 0;
		iVar0++;
	}
}

// Position - 0xB8D
void func_11(int iParam0, int iParam1, int iParam2) {
	bool bVar0;

	if (iParam0 < 0) {
	}
	if (iParam0 == 321 || iParam0 > 321) {
	}
	else {
		func_15(891 + iParam0, 1, -1, 1);
	}
	bVar0 = true;
	if (Global_101700.f_9153[iParam0 /*12*/].f_5 == 1) {
		if (Global_101700.f_9153[iParam0 /*12*/].f_6 == 11 || Global_101700.f_9153[iParam0 /*12*/].f_6 == 12) {
			bVar0 = false;
		}
	}
	else {
		Global_101700.f_9153[iParam0 /*12*/].f_5 = 1;
		Global_101700.f_9153[iParam0 /*12*/].f_10 = iParam1;
		Global_101700.f_9153[iParam0 /*12*/].f_11 = iParam2;
		if (iParam0 == 287) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_0"), 50, 0);
		}
		if (iParam0 == 286) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_1"), 50, 0);
		}
		if (iParam0 == 299) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_3"), 50, 0);
		}
	}
	if (bVar0) {
		func_12();
	}
}

// Position - 0xC75
void func_12() {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	int iVar9;

	iVar0 = 0;
	Global_101436 = 0;
	Global_101437 = 0;
	Global_101438 = 0;
	Global_101439 = 0;
	Global_101440 = 0;
	Global_101441 = 0;
	Global_101442 = 0;
	fVar1 = 0f;
	fVar2 = 0f;
	fVar3 = 0f;
	fVar4 = 0f;
	fVar5 = 0f;
	fVar6 = 0f;
	fVar7 = 0f;
	fVar8 = Global_101700.f_9153.f_3853;
	Global_101700.f_9153.f_3853 = 0f;
	while (iVar0 < 321) {
		if (Global_101700.f_9153[iVar0 /*12*/].f_5 == 1) {
			switch (Global_101700.f_9153[iVar0 /*12*/].f_6) {
			case 1:
				Global_101436++;
				fVar1 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 3:
				Global_101437++;
				fVar2 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 5:
				Global_101438++;
				fVar3 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 7:
				Global_101439++;
				fVar4 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 9:
				Global_101440++;
				fVar5 += Global_101700.f_9153[iVar0 /*12*/].f_4 * 4f;
				break;

			case 11:
				Global_101441++;
				fVar6 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 13:
				Global_101442++;
				fVar7 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			default: break;
			}
		}
		iVar0++;
	}
	if (Global_101419 > 0) {
		if (Global_101436 == Global_101419) {
			fVar1 = 55f;
		}
	}
	if (Global_101420 > 0) {
		if (Global_101437 == Global_101420) {
			fVar2 = 10f;
		}
	}
	if (Global_101421 > 0) {
		if (Global_101438 == Global_101421) {
			fVar3 = 0f;
		}
	}
	if (Global_101422 > 0) {
		if (Global_101439 == Global_101422) {
			fVar4 = 10f;
		}
	}
	if (Global_101423 > 0) {
		if (Global_101440 == Global_101423 || Global_101423 * 10 / Global_101440 < 41 ||
			Global_101440 > Global_101426 || Global_101440 == Global_101426) {
			if (!gameplay::is_bit_set(Global_101700.f_9153.f_3856, 14)) {
				if (Global_101440 == Global_101423) {
					stats::_0x11FF1C80276097ED(joaat("num_rndevents_completed"), Global_101423, 0);
					gameplay::set_bit(&Global_101700.f_9153.f_3856, 14);
				}
			}
			fVar5 = 5f;
		}
	}
	if (Global_101424 > 0) {
		if (Global_101441 == Global_101424) {
			fVar6 = 15f;
		}
	}
	if (Global_101425 > 0) {
		if (Global_101442 == Global_101425) {
			fVar7 = 5f;
		}
	}
	Global_101700.f_9153.f_3853 = fVar1 + fVar2 + fVar3 + fVar4 + fVar5 + fVar6 + fVar7;
	if (Global_101440 > Global_101426 || Global_101440 == Global_101426) {
		iVar9 = Global_101426;
	}
	else {
		iVar9 = Global_101440;
	}
	stats::stat_set_int(joaat("num_missions_completed"), Global_101436, 1);
	stats::stat_set_int(joaat("num_missions_available"), Global_101419, 1);
	stats::stat_set_int(joaat("num_minigames_completed"), Global_101437, 1);
	stats::stat_set_int(joaat("num_minigames_available"), Global_101420, 1);
	stats::stat_set_int(joaat("num_oddjobs_completed"), Global_101438, 1);
	stats::stat_set_int(joaat("num_oddjobs_available"), Global_101421, 1);
	stats::stat_set_int(joaat("num_rndpeople_completed"), Global_101439, 1);
	stats::stat_set_int(joaat("num_rndpeople_available"), Global_101422, 1);
	stats::stat_set_int(joaat("num_rndevents_completed"), iVar9, 1);
	stats::stat_set_int(joaat("num_rndevents_available"), Global_101426, 1);
	stats::stat_set_int(joaat("num_misc_completed"), Global_101442 + Global_101441, 1);
	stats::stat_set_int(joaat("num_misc_available"), Global_101425 + Global_101424, 1);
	Global_101443 = Global_101436 * 100 / Global_101419;
	Global_101445 = Global_101438 + Global_101437 * 100 / (Global_101421 + Global_101420);
	Global_101444 = Global_101439 + iVar9 * 100 / (Global_101422 + Global_101426);
	Global_101446 = Global_101441 + Global_101442 * 100 / (Global_101424 + Global_101425);
	stats::stat_set_float(joaat("total_progress_made"), Global_101700.f_9153.f_3853, 1);
	stats::stat_set_int(joaat("percent_story_missions"), Global_101443, 1);
	stats::stat_set_int(joaat("percent_ambient_missions"), Global_101444, 1);
	stats::stat_set_int(joaat("percent_oddjobs"), Global_101445, 1);
	if (fVar8 > 0f && system::floor(fVar8) < system::floor(Global_101700.f_9153.f_3853)) {
		func_14(13, system::floor(Global_101700.f_9153.f_3853));
	}
	if (!datafile::datafile_is_save_pending()) {
		if (!Global_69702) {
			if (func_13() == 2 == 0 && !network::network_is_game_in_progress()) {
				if (network::network_is_cloud_available()) {
					Global_101434 = 0;
				}
				if (!Global_55822) {
					func_6();
				}
			}
		}
	}
}

// Position - 0x1136
int func_13() { return Global_25190; }

// Position - 0x1141
int func_14(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x1192
int func_15(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;
	var uVar6;
	var uVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;

	if (iParam2 == -1) {
		iParam2 = func_16();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
		iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
		iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
		iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
		iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
		iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
		iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		uVar9 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2, "_NGTATPSTAT_BOOL");
		iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2, "_DLCBIKEPSTAT_BOOL");
		iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
	}
	return iVar0;
}

// Position - 0x1524
var func_16() { return Global_1312735; }

// Position - 0x1530
int func_17(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: iVar0 = 199; break;

	case 1: iVar0 = 200; break;

	case 2: iVar0 = 201; break;

	case 3: iVar0 = 202; break;

	case 4: iVar0 = 203; break;

	case 5: iVar0 = 204; break;

	case 6: iVar0 = 205; break;

	case 7: iVar0 = 206; break;

	case 8: iVar0 = 207; break;

	case 9: break;

	default: iVar0 = 199; break;
	}
	return iVar0;
}

// Position - 0x15C6
void func_18() {
	Global_14611 = 0;
	func_19();
}

// Position - 0x15D6
void func_19() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x162D
int func_20() { return joaat("taxi"); }

// Position - 0x163A
bool func_21() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return true;
	}
	return false;
}

// Position - 0x165C
void func_22(char *sParam0, int iParam1) {
	int iVar0;

	iVar0 = func_78(player::player_ped_id());
	if (iVar0 == 0) {
		if (iParam1) {
			StringConCat(sParam0, "M", 24);
		}
		else {
			StringConCat(sParam0, "_2", 24);
		}
	}
	else if (iVar0 == 2) {
		if (iParam1) {
			StringConCat(sParam0, "T", 24);
		}
		else {
			StringConCat(sParam0, "_3", 24);
		}
	}
	else if (iVar0 == 1) {
		if (iParam1) {
			StringConCat(sParam0, "F", 24);
		}
		else {
			StringConCat(sParam0, "_4", 24);
		}
	}
}

// Position - 0x16CE
void func_23(char *sParam0, int iParam1, int iParam2) {
	if (gameplay::get_game_timer() < *iParam1 + iParam2) {
		return;
	}
	*iParam1 = gameplay::get_game_timer();
}

// Position - 0x16ED
int func_24(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_80(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_26(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_25(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0x1824
void func_25(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0x1873
bool func_26(int iParam0) { return func_27(iParam0, Global_35781); }

// Position - 0x1884
int func_27(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x1A65
void func_28(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_58(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_31(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_30(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_29();
			return;
		}
		iVar0++;
	}
}

// Position - 0x1B12
void func_29() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0x1C32
void func_30(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0x1CCC
void func_31(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0x1DDC
bool func_32(char *sParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x1E17
void func_33(int iParam0, char *sParam1, var *uParam2, int iParam3) {
	struct<6> Var0;
	vector3 vVar6[24];

	if (iParam0 == 0) {
		StringCopy(sParam1, "Taxi_NeedExcitement", 24);
	}
	else if (iParam0 == 1) {
		StringCopy(sParam1, "Taxi_TakeItEasy", 24);
	}
	else if (iParam0 == 2) {
		StringCopy(sParam1, "Taxi_Deadline", 24);
	}
	else if (iParam0 == 3) {
		StringCopy(sParam1, "Taxi_GotYourBack", 24);
	}
	else if (iParam0 == 4) {
		StringCopy(sParam1, "Taxi_TakeToBest", 24);
	}
	else if (iParam0 == 5) {
		StringCopy(sParam1, "Taxi_CutYouIn", 24);
	}
	else if (iParam0 == 6) {
		StringCopy(sParam1, "Taxi_GotYouNow", 24);
	}
	else if (iParam0 == 7) {
		StringCopy(sParam1, "Taxi_ClownCar", 24);
	}
	else if (iParam0 == 8) {
		StringCopy(sParam1, "Taxi_FollowCar", 24);
	}
	else if (iParam0 == 9) {
		StringCopy(sParam1, "Taxi_Procedural", 24);
	}
	if (iParam3) {
		StringCopy(&Var0, func_48(iParam0), 24);
		cVar6 = {Var0};
		StringConCat(&cVar6, "_1", 24);
		func_73(uParam2);
		func_34(uParam2, "OJTXAUD", &Var0, &cVar6, 8, 0, 0);
	}
}

// Position - 0x1F01
int func_34(var *uParam0, char *sParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6) {
	func_47(uParam0, 145, sParam1, iParam5, iParam6, 0);
	if (iParam4 > 7) {
		if (iParam4 < 12) {
			iParam4 = 7;
		}
	}
	Global_15752 = 0;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 1;
	Global_16738 = 0;
	Global_16742 = 0;
	StringCopy(&Global_16749, sParam3, 24);
	Global_2621441 = 0;
	return func_35(sParam2, iParam4, 0);
}

// Position - 0x1F55
int func_35(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_19();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_46(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_45();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_40();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_39()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_38()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_37();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_36();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_19();
	}
	return 0;
}

// Position - 0x2221
void func_36() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x2252
void func_37() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x22E7
bool func_38() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x230E
bool func_39() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x23A7
void func_40() {
	if (func_68(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_41();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x2449
var func_41() {
	func_42();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x2462
void func_42() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_44(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_78(player::player_ped_id());
			if (func_43(iVar0) && (!func_68(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_43(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x255F
bool func_43(int iParam0) { return iParam0 < 3; }

// Position - 0x256B
int func_44(int iParam0) {
	if (func_43(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x2595
void func_45() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x25EC
bool func_46(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x2627
void func_47(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x267D
char *func_48(int iParam0) {
	if (iParam0 == 0) {
		return "OJTX_EXC_OFF";
	}
	else if (iParam0 == 1) {
		return "OJTX_TIE_OFF";
	}
	else if (iParam0 == 2) {
		return "OJTX_DL_OFF";
	}
	else if (iParam0 == 3) {
		return "OJTX_GB_OFF";
	}
	else if (iParam0 == 4) {
		return "OJTX_TB_OFF";
	}
	else if (iParam0 == 5) {
		return "OJTX_CI_OFF";
	}
	else if (iParam0 == 6) {
		return "OJTX_GN_OFF";
	}
	else if (iParam0 == 7) {
		return "OJTX_CC_OFF";
	}
	else if (iParam0 == 8) {
		return "OJTX_FC_OFF";
	}
	else if (iParam0 == 9) {
		return "OJTX_PRO_OFF";
	}
	return "";
}

// Position - 0x2726
void func_49(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x273D
int func_50(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_47(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_35(sParam2, iParam3, 0);
}

// Position - 0x278B
void func_51(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x2826
int func_52() {
	int iVar0;

	iVar0 = gameplay::get_game_timer();
	if (Global_15745 == 0) {
		if (iVar0 - Global_16767 > 3000) {
			if (audio::is_scripted_conversation_ongoing() == 0) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x2865
float func_53(int *iParam0) {
	if (func_57(iParam0)) {
		if (func_55(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_54(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return iParam0->f_1;
}

// Position - 0x28A4
float func_54(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x28FC
bool func_55(int *iParam0) { return gameplay::is_bit_set(*iParam0, 2); }

// Position - 0x290C
void func_56(int *iParam0) {
	if (!func_57(iParam0)) {
		func_71(iParam0);
	}
}

// Position - 0x2924
bool func_57(int *iParam0) { return gameplay::is_bit_set(*iParam0, 1); }

// Position - 0x2934
bool func_58(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x2947
void func_59(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_60(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x2968
void func_60(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_29();
	}
}

// Position - 0x2B3B
int func_61(char *sParam0) {
	if (gameplay::are_strings_equal(sParam0, &Global_100345)) {
		return 1;
	}
	if (func_32(sParam0)) {
		return 0;
	}
	return 2;
}

// Position - 0x2B62
int func_62() {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_64()) {
		return 1;
	}
	else {
		iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
		iVar1 = system::round(vehicle::get_vehicle_engine_health(iVar0));
		iVar2 = entity::get_entity_health(iVar0);
		if (iVar1 < 100 || iVar2 < 100) {
			return 2;
		}
		if (!func_63(iVar0)) {
			return 2;
		}
		if (player::get_player_wanted_level(player::player_id()) > 0) {
			return 3;
		}
	}
	return 0;
}

// Position - 0x2BCE
int func_63(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	if (!vehicle::is_vehicle_tyre_burst(iParam0, 0, 0)) {
		iVar0++;
	}
	if (!vehicle::is_vehicle_tyre_burst(iParam0, 1, 0)) {
		iVar0++;
	}
	if (!vehicle::is_vehicle_tyre_burst(iParam0, 4, 0)) {
		iVar0++;
	}
	if (!vehicle::is_vehicle_tyre_burst(iParam0, 5, 0)) {
		iVar0++;
	}
	if (iVar0 < 2) {
		return 0;
	}
	if (vehicle::is_this_model_a_car(entity::get_entity_model(iParam0))) {
		iVar1 = 0;
		if (!vehicle::is_vehicle_door_damaged(iParam0, 0)) {
			iVar1++;
		}
		if (!vehicle::is_vehicle_door_damaged(iParam0, 1)) {
			iVar1++;
		}
		if (!vehicle::is_vehicle_door_damaged(iParam0, 2)) {
			iVar1++;
		}
		if (!vehicle::is_vehicle_door_damaged(iParam0, 3)) {
			iVar1++;
		}
		if (iVar1 < 2) {
			return 0;
		}
	}
	return 1;
}

// Position - 0x2C8A
bool func_64() {
	int iVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			if (vehicle::is_vehicle_driveable(iVar0, 0)) {
				if (vehicle::get_ped_in_vehicle_seat(iVar0, -1, 0) == player::player_ped_id()) {
					if (vehicle::is_vehicle_model(iVar0, func_20())) {
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0x2CE1
void func_65() {
	if (!func_76(Global_101700.f_18056, 8192)) {
		if (func_64()) {
			func_74(&Global_101700.f_18056, 8192);
			func_67();
		}
	}
	else if (!func_64()) {
		func_84(&Global_101700.f_18056, 8192);
		func_66();
	}
}

// Position - 0x2D31
void func_66() {
	int iVar0;

	iVar0 = player::get_players_last_vehicle();
	if (vehicle::is_vehicle_driveable(iVar0, 0)) {
		audio::play_sound_from_entity(-1, "Radio_Off", iVar0, "TAXI_SOUNDS", 0, 0);
	}
}

// Position - 0x2D5A
void func_67() {
	int iVar0;

	iVar0 = player::get_players_last_vehicle();
	if (vehicle::is_vehicle_driveable(iVar0, 0)) {
		audio::play_sound_from_entity(-1, "Radio_On", iVar0, "TAXI_SOUNDS", 0, 0);
	}
}

// Position - 0x2D83
bool func_68(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x2D91
int func_69() {
	if (Global_35781 == 15) {
		return 0;
	}
	return 1;
}

// Position - 0x2DA6
bool func_70(int iParam0) {
	if (Global_17151.f_130) {
		return false;
	}
	if (controls::is_control_just_released(0, 19) || !iParam0 && controls::is_disabled_control_just_released(0, 19)) {
		return true;
	}
	if (gameplay::is_pc_version()) {
		if (controls::is_control_just_released(0, 166)) {
			if (!controls::is_control_pressed(0, 167) && !controls::is_control_pressed(0, 168) &&
				!controls::is_control_pressed(0, 169)) {
				return true;
			}
		}
		else if (controls::is_control_just_released(0, 167)) {
			if (!controls::is_control_pressed(0, 166) && !controls::is_control_pressed(0, 168) &&
				!controls::is_control_pressed(0, 169)) {
				return true;
			}
		}
		else if (controls::is_control_just_released(0, 168)) {
			if (!controls::is_control_pressed(0, 166) && !controls::is_control_pressed(0, 167) &&
				!controls::is_control_pressed(0, 169)) {
				return true;
			}
		}
		else if (controls::is_control_just_released(0, 169)) {
			if (!controls::is_control_pressed(0, 166) && !controls::is_control_pressed(0, 167) &&
				!controls::is_control_pressed(0, 168)) {
				return true;
			}
		}
		if (!iParam0) {
			if (controls::is_disabled_control_just_released(0, 166)) {
				if (!controls::is_disabled_control_pressed(0, 167) && !controls::is_disabled_control_pressed(0, 168) &&
					!controls::is_disabled_control_pressed(0, 169)) {
					return true;
				}
			}
			else if (controls::is_disabled_control_just_released(0, 167)) {
				if (!controls::is_disabled_control_pressed(0, 166) && !controls::is_disabled_control_pressed(0, 168) &&
					!controls::is_disabled_control_pressed(0, 169)) {
					return true;
				}
			}
			else if (controls::is_disabled_control_just_released(0, 168)) {
				if (!controls::is_disabled_control_pressed(0, 166) && !controls::is_disabled_control_pressed(0, 167) &&
					!controls::is_disabled_control_pressed(0, 169)) {
					return true;
				}
			}
			else if (controls::is_disabled_control_just_released(0, 169)) {
				if (!controls::is_disabled_control_pressed(0, 166) && !controls::is_disabled_control_pressed(0, 167) &&
					!controls::is_disabled_control_pressed(0, 168)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x2F98
void func_71(int *iParam0) { func_72(iParam0, 0f); }

// Position - 0x2FA7
void func_72(int *iParam0, float fParam1) {
	uParam0->f_1 = func_54(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x2FD5
void func_73(var *uParam0) {
	int iVar0;
	char cVar1[64];

	iVar0 = func_78(player::player_ped_id());
	if (iVar0 == 0) {
		func_51(uParam0, 0, player::player_ped_id(), "MICHAEL", 0, 1);
	}
	else if (iVar0 == 2) {
		func_51(uParam0, 0, player::player_ped_id(), "TREVOR", 0, 1);
	}
	else if (iVar0 == 1) {
		func_51(uParam0, 0, player::player_ped_id(), "FRANKLIN", 0, 1);
	}
	else {
		func_51(uParam0, 0, player::player_ped_id(), "MICHAEL", 0, 1);
		StringCopy(&cVar1, "Invalid enum passed to Taxi dialogue is: ", 64);
		StringIntConCat(&cVar1, iVar0, 64);
	}
	func_51(uParam0, 8, 0, "TaxiDispatch", 0, 1);
}

// Position - 0x3062
void func_74(var *uParam0, int iParam1) { func_75(uParam0, iParam1); }

// Position - 0x3072
void func_75(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x3083
bool func_76(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x3092
void func_77() {
	int iVar0;

	if (func_76(Global_101700.f_18056, 2048)) {
		iVar0 = 0;
		while (iVar0 <= 10 - 1) {
			Global_101700.f_18056.f_1[0 /*2*/] = 0;
			Global_101700.f_18056.f_1[0 /*2*/].f_1 = 0;
			iVar0++;
		}
	}
}

// Position - 0x30DC
int func_78(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_44(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x3119
void func_79(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x312F
bool func_80(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_26(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0x3151
int func_81(int iParam0, int iParam1) {
	var uVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return 0;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return 0;
	}
	uVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	return uVar0;
}

// Position - 0x319E
int func_82(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		return 0;
	}
	gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
	return 1;
}

// Position - 0x31F8
void func_83() {
	if (func_76(Global_101700.f_18056, 4)) {
		func_84(&Global_101700.f_18056, 4);
		vehicle::set_vehicle_model_is_suppressed(func_20(), 0);
	}
	if (func_76(Global_101700.f_18056, 256)) {
		func_84(&Global_101700.f_18056, 256);
		func_4(&iLocal_108);
	}
	if (iLocal_98 != 0) {
		if (script::is_thread_active(iLocal_98)) {
			script::terminate_thread(iLocal_98);
			iLocal_98 = 0;
		}
	}
	if (ui::get_length_of_literal_string(&vLocal_99) != 0) {
		script::set_script_as_no_longer_needed(&vLocal_99);
	}
	if (ui::does_blip_exist(iLocal_105)) {
		ui::remove_blip(&iLocal_105);
	}
	script::terminate_this_thread();
}

// Position - 0x3284
void func_84(int *iParam0, int iParam1) { func_85(iParam0, iParam1); }

// Position - 0x3294
void func_85(int *iParam0, var uParam1) { *iParam0 -= (*iParam0 & uParam1); }

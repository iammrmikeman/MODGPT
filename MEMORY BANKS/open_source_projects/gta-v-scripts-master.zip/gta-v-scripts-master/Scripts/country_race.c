#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
struct<8> Local_46 = {
	0, 0, 0, 0, 0, 0, 0, 0
};
struct<55> Local_54 = {
	6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9
};
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
int iLocal_120 = 0;
int iLocal_121 = 0;
int iLocal_122 = 0;
int iLocal_123 = 0;
int iLocal_124 = 0;
int iLocal_125 = 0;
int iLocal_126 = 0;
vector3 vLocal_127 = {0f, 0f, 0f};
vector3 vLocal_130 = {0f, 0f, 0f};
vector3 vLocal_133 = {0f, 0f, 0f};
char *sLocal_136 = NULL;
char *sLocal_137 = NULL;
char *sLocal_138 = NULL;
char *sLocal_139 = NULL;
int iLocal_140 = 0;
bool bLocal_141 = 0;
var *uLocal_142 = NULL;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
int *iLocal_173 = NULL;
int iLocal_174 = 0;
int *iLocal_175 = NULL;
int iLocal_176 = 0;
int iLocal_177 = 0;
int iLocal_178 = 0;
int iLocal_179 = 0;
char *sLocal_180 = NULL;
vector3 vLocal_181 = {0f, 0f, 0f};
vector3 vLocal_184 = {0f, 0f, 0f};
vector3 vLocal_187 = {0f, 0f, 0f};
vector3 vLocal_190 = {0f, 0f, 0f};
vector3 vLocal_193 = {0f, 0f, 0f};
struct<50> Local_196[8];
struct<50> Local_597[23];
struct<12> Local_1748[8];
struct<11> Local_1845[1];
var *uLocal_1857 = NULL;
var uLocal_1858 = 3;
var uLocal_1859 = 0;
var uLocal_1860 = 0;
var uLocal_1861 = 0;
var uLocal_1862 = 0;
var uLocal_1863 = 0;
var uLocal_1864 = 1092616192;
var uLocal_1865 = 1101004800;
var uLocal_1866 = 0;
var uLocal_1867 = 0;
var uLocal_1868 = 0;
var uLocal_1869 = 0;
var uLocal_1870 = 0;
var uLocal_1871 = 0;
var uLocal_1872 = 0;
var uLocal_1873 = 0;
var uLocal_1874 = 3;
var uLocal_1875 = 0;
var uLocal_1876 = 0;
var uLocal_1877 = 0;
var uLocal_1878 = 0;
var uLocal_1879 = 0;
var uLocal_1880 = 0;
var uLocal_1881 = 0;
var *uLocal_1882 = NULL;
var uLocal_1883 = 0;
var uLocal_1884 = 0;
var uLocal_1885 = 0;
var uLocal_1886 = 0;
var uLocal_1887 = 0;
var uLocal_1888 = 0;
var uLocal_1889 = 0;
var uLocal_1890 = 0;
var uLocal_1891 = 0;
var uLocal_1892 = 0;
var uLocal_1893 = 0;
var uLocal_1894 = 0;
var uLocal_1895 = 0;
var uLocal_1896 = 0;
var uLocal_1897 = 0;
var uLocal_1898 = 0;
var uLocal_1899 = 0;
var uLocal_1900 = 0;
var uLocal_1901 = 0;
var uLocal_1902 = 0;
var uLocal_1903 = 0;
var uLocal_1904 = 0;
var uLocal_1905 = 0;
var uLocal_1906 = 0;
var uLocal_1907 = 0;
var uLocal_1908 = 0;
var uLocal_1909 = 0;
var uLocal_1910 = 0;
var uLocal_1911 = 0;
var uLocal_1912 = 0;
var uLocal_1913 = 0;
var uLocal_1914 = 0;
var uLocal_1915 = 0;
var uLocal_1916 = 0;
var uLocal_1917 = 0;
var uLocal_1918 = 0;
var uLocal_1919 = 0;
var uLocal_1920 = 0;
var uLocal_1921 = 0;
var uLocal_1922 = 0;
var uLocal_1923 = 0;
var uLocal_1924 = 0;
var uLocal_1925 = 0;
var uLocal_1926 = 0;
var uLocal_1927 = 0;
var uLocal_1928 = 0;
var uLocal_1929 = 0;
var uLocal_1930 = 0;
var uLocal_1931 = 0;
var uLocal_1932 = 0;
var uLocal_1933 = 0;
var uLocal_1934 = 0;
var uLocal_1935 = 0;
var uLocal_1936 = 0;
var uLocal_1937 = 0;
var uLocal_1938 = 0;
var uLocal_1939 = 0;
var uLocal_1940 = 0;
var uLocal_1941 = 0;
var uLocal_1942 = 0;
struct<20> Local_1943 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<11> Local_1963 = {
	0, 0, 0, 0, 0, 0, 0, 21, 6, 0, 0
};
var uLocal_1974 = 0;
int iLocal_1975 = 0;
int iLocal_1976 = 0;
int iLocal_1977 = 0;
struct<2> Local_1978 = {
	0, 0
};
var uLocal_1980 = 0;
int *iLocal_1981 = NULL;
var uLocal_1982 = 0;
var uLocal_1983 = 0;
var uLocal_1984 = 0;
var uLocal_1985 = 0;
var uLocal_1986 = 0;
var uLocal_1987 = 0;
var uLocal_1988 = 0;
var uLocal_1989 = 0;
var uLocal_1990 = 0;
var uLocal_1991 = 0;
var uLocal_1992 = 0;
var uLocal_1993 = 8;
var uLocal_1994 = 0;
var uLocal_1995 = 0;
var uLocal_1996 = 0;
var uLocal_1997 = 4;
var uLocal_1998 = 0;
var uLocal_1999 = 0;
var uLocal_2000 = 0;
var uLocal_2001 = 0;
var uLocal_2002 = 0;
var uLocal_2003 = 0;
var uLocal_2004 = 0;
var uLocal_2005 = 0;
var uLocal_2006 = 0;
var uLocal_2007 = 0;
var uLocal_2008 = 0;
var uLocal_2009 = 0;
var uLocal_2010 = 0;
var uLocal_2011 = 0;
var uLocal_2012 = 4;
var uLocal_2013 = 0;
var uLocal_2014 = 0;
var uLocal_2015 = 0;
var uLocal_2016 = 0;
var uLocal_2017 = 0;
var uLocal_2018 = 0;
var uLocal_2019 = 0;
var uLocal_2020 = 0;
var uLocal_2021 = 0;
var uLocal_2022 = 0;
var uLocal_2023 = 0;
var uLocal_2024 = 0;
var uLocal_2025 = 0;
var uLocal_2026 = 0;
var uLocal_2027 = 4;
var uLocal_2028 = 0;
var uLocal_2029 = 0;
var uLocal_2030 = 0;
var uLocal_2031 = 0;
var uLocal_2032 = 0;
var uLocal_2033 = 0;
var uLocal_2034 = 0;
var uLocal_2035 = 0;
var uLocal_2036 = 0;
var uLocal_2037 = 0;
var uLocal_2038 = 0;
var uLocal_2039 = 0;
var uLocal_2040 = 0;
var uLocal_2041 = 0;
var uLocal_2042 = 4;
var uLocal_2043 = 0;
var uLocal_2044 = 0;
var uLocal_2045 = 0;
var uLocal_2046 = 0;
var uLocal_2047 = 0;
var uLocal_2048 = 0;
var uLocal_2049 = 0;
var uLocal_2050 = 0;
var uLocal_2051 = 0;
var uLocal_2052 = 0;
var uLocal_2053 = 0;
var uLocal_2054 = 0;
var uLocal_2055 = 0;
var uLocal_2056 = 0;
var uLocal_2057 = 4;
var uLocal_2058 = 0;
var uLocal_2059 = 0;
var uLocal_2060 = 0;
var uLocal_2061 = 0;
var uLocal_2062 = 0;
var uLocal_2063 = 0;
var uLocal_2064 = 0;
var uLocal_2065 = 0;
var uLocal_2066 = 0;
var uLocal_2067 = 0;
var uLocal_2068 = 0;
var uLocal_2069 = 0;
var uLocal_2070 = 0;
var uLocal_2071 = 0;
var uLocal_2072 = 4;
var uLocal_2073 = 0;
var uLocal_2074 = 0;
var uLocal_2075 = 0;
var uLocal_2076 = 0;
var uLocal_2077 = 0;
var uLocal_2078 = 0;
var uLocal_2079 = 0;
var uLocal_2080 = 0;
var uLocal_2081 = 0;
var uLocal_2082 = 0;
var uLocal_2083 = 0;
var uLocal_2084 = 0;
var uLocal_2085 = 0;
var uLocal_2086 = 0;
var uLocal_2087 = 4;
var uLocal_2088 = 0;
var uLocal_2089 = 0;
var uLocal_2090 = 0;
var uLocal_2091 = 0;
var uLocal_2092 = 0;
var uLocal_2093 = 0;
var uLocal_2094 = 0;
var uLocal_2095 = 0;
var uLocal_2096 = 0;
var uLocal_2097 = 0;
var uLocal_2098 = 0;
var uLocal_2099 = 0;
var uLocal_2100 = 0;
var uLocal_2101 = 0;
var uLocal_2102 = 4;
var uLocal_2103 = 0;
var uLocal_2104 = 0;
var uLocal_2105 = 0;
var uLocal_2106 = 0;
var uLocal_2107 = 0;
var uLocal_2108 = 0;
var uLocal_2109 = 0;
var uLocal_2110 = 0;
var uLocal_2111 = 0;
var uLocal_2112 = 0;
var uLocal_2113 = 0;
var uLocal_2114 = 0;
var uLocal_2115 = 0;
var uLocal_2116 = 0;
var uLocal_2117 = 0;
var uLocal_2118 = 0;
var uLocal_2119 = 0;
var *uLocal_2120 = NULL;
var uLocal_2121 = 0;
var uLocal_2122 = 0;
var uLocal_2123 = 0;
var uLocal_2124 = 0;
int iLocal_2125 = 0;
int iLocal_2126 = 0;
int iLocal_2127 = 0;
int *iLocal_2128 = NULL;
int iLocal_2129 = 0;
int iLocal_2130 = 0;
int iLocal_2131 = 0;
int iLocal_2132 = 0;
int iLocal_2133 = 0;
int iLocal_2134 = 0;
var *uLocal_2135 = NULL;
var uLocal_2136 = 0;
var uLocal_2137 = 0;
var uLocal_2138 = 0;
var uLocal_2139 = 0;
var uLocal_2140 = 0;
var uLocal_2141 = 0;
var uLocal_2142 = 0;
var uLocal_2143 = 0;
var uLocal_2144 = 0;
var uLocal_2145 = 0;
var uLocal_2146 = 0;
var uLocal_2147 = 0;
var uLocal_2148 = 0;
var uLocal_2149 = 0;
var uLocal_2150 = 0;
var uLocal_2151 = 0;
var uLocal_2152 = 0;
var uLocal_2153 = 0;
var uLocal_2154 = 0;
var uLocal_2155 = 0;
var uLocal_2156 = 0;
var uLocal_2157 = 0;
var uLocal_2158 = 0;
var uLocal_2159 = 0;
var uLocal_2160 = 0;
var uLocal_2161 = 0;
var uLocal_2162 = 0;
var uLocal_2163 = 0;
var uLocal_2164 = 0;
var uLocal_2165 = 0;
var uLocal_2166 = 0;
var uLocal_2167 = 3;
var uLocal_2168 = 0;
var uLocal_2169 = 0;
var uLocal_2170 = 0;
var uLocal_2171 = 1;
var uLocal_2172 = 0;
var uLocal_2173 = 0;
var uLocal_2174 = 0;
var uLocal_2175 = 0;
var uLocal_2176 = 0;
var uLocal_2177 = 0;
var uLocal_2178 = 0;
var uLocal_2179 = 0;
var uLocal_2180 = 0;
var uLocal_2181 = 0;
var uLocal_2182 = 0;
var uLocal_2183 = 0;
var uLocal_2184 = 0;
var uLocal_2185 = 0;
var uLocal_2186 = 0;
var uLocal_2187 = 0;
var uLocal_2188 = 2;
var uLocal_2189 = 0;
var uLocal_2190 = 0;
var uLocal_2191 = 0;
var uLocal_2192 = 13;
var uLocal_2193 = 0;
var uLocal_2194 = 0;
var uLocal_2195 = 0;
var uLocal_2196 = 0;
var uLocal_2197 = 0;
var uLocal_2198 = 0;
var uLocal_2199 = 0;
var uLocal_2200 = 0;
var uLocal_2201 = 0;
var uLocal_2202 = 0;
var uLocal_2203 = 0;
var uLocal_2204 = 0;
var uLocal_2205 = 0;
var uLocal_2206 = 13;
var uLocal_2207 = 0;
var uLocal_2208 = 0;
var uLocal_2209 = 0;
var uLocal_2210 = 0;
var uLocal_2211 = 0;
var uLocal_2212 = 0;
var uLocal_2213 = 0;
var uLocal_2214 = 0;
var uLocal_2215 = 0;
var uLocal_2216 = 0;
var uLocal_2217 = 0;
var uLocal_2218 = 0;
var uLocal_2219 = 0;
var uLocal_2220 = 0;
var uLocal_2221 = 0;
var uLocal_2222 = 0;
var uLocal_2223 = 0;
var uLocal_2224 = 0;
var uLocal_2225 = 0;
var uLocal_2226 = 0;
var uLocal_2227 = 0;
var uLocal_2228 = 0;
var uLocal_2229 = 0;
var uLocal_2230 = 0;
var uLocal_2231 = 0;
var uLocal_2232 = 0;
var uLocal_2233 = 0;
var uLocal_2234 = 0;
var uLocal_2235 = 0;
var uLocal_2236 = 0;
var uLocal_2237 = 0;
var uLocal_2238 = 0;
var uLocal_2239 = 0;
var uLocal_2240 = 0;
var uLocal_2241 = 0;
var uLocal_2242 = 0;
var uLocal_2243 = 0;
var uLocal_2244 = 0;
var uLocal_2245 = 0;
var uLocal_2246 = 0;
var uLocal_2247 = 0;
var uLocal_2248 = 0;
var uLocal_2249 = 0;
var uLocal_2250 = 0;
var uLocal_2251 = 0;
var uLocal_2252 = 0;
var uLocal_2253 = 0;
var uLocal_2254 = 0;
var uLocal_2255 = 0;
var uLocal_2256 = 0;
var uLocal_2257 = 0;
var uLocal_2258 = 0;
var uLocal_2259 = 0;
var uLocal_2260 = 0;
var uLocal_2261 = 0;
var uLocal_2262 = 0;
var uLocal_2263 = 0;
var uLocal_2264 = 0;
var uLocal_2265 = 0;
var uLocal_2266 = 0;
var uLocal_2267 = 0;
var uLocal_2268 = 0;
var uLocal_2269 = 0;
var uLocal_2270 = 0;
var uLocal_2271 = 0;
var uLocal_2272 = 0;
var uLocal_2273 = 0;
var uLocal_2274 = 0;
var uLocal_2275 = 0;
var uLocal_2276 = 0;
var uLocal_2277 = 0;
var uLocal_2278 = 0;
var uLocal_2279 = 0;
var uLocal_2280 = 0;
var uLocal_2281 = 0;
var uLocal_2282 = 0;
var uLocal_2283 = 0;
var uLocal_2284 = 0;
var uLocal_2285 = 0;
var uLocal_2286 = 0;
var uLocal_2287 = 0;
var uLocal_2288 = 0;
var uLocal_2289 = 0;
var uLocal_2290 = 0;
var uLocal_2291 = 0;
var uLocal_2292 = 0;
var uLocal_2293 = 0;
var uLocal_2294 = 0;
var uLocal_2295 = 0;
var uLocal_2296 = 0;
var uLocal_2297 = 0;
var uLocal_2298 = 0;
var uLocal_2299 = 0;
var uLocal_2300 = 0;
var uLocal_2301 = 0;
var uLocal_2302 = 0;
var uLocal_2303 = 0;
var uLocal_2304 = 0;
var uLocal_2305 = 0;
var uLocal_2306 = 0;
var uLocal_2307 = 0;
var uLocal_2308 = 0;
var uLocal_2309 = 0;
var uLocal_2310 = 0;
var uLocal_2311 = 0;
var uLocal_2312 = 0;
var uLocal_2313 = 0;
var uLocal_2314 = 0;
var uLocal_2315 = 0;
var uLocal_2316 = 0;
var uLocal_2317 = 0;
var uLocal_2318 = 0;
var uLocal_2319 = 0;
var uLocal_2320 = 0;
var uLocal_2321 = 0;
var uLocal_2322 = 0;
var uLocal_2323 = 0;
var uLocal_2324 = 0;
var uLocal_2325 = 0;
var uLocal_2326 = 0;
var uLocal_2327 = 0;
var uLocal_2328 = 0;
var uLocal_2329 = 0;
var uLocal_2330 = 0;
var uLocal_2331 = 0;
var uLocal_2332 = 0;
var uLocal_2333 = 0;
var uLocal_2334 = 0;
var uLocal_2335 = 0;
var uLocal_2336 = 0;
var uLocal_2337 = 0;
var uLocal_2338 = 0;
var uLocal_2339 = 0;
var uLocal_2340 = 0;
var uLocal_2341 = 0;
var uLocal_2342 = 0;
var uLocal_2343 = 0;
var uLocal_2344 = 0;
var uLocal_2345 = 0;
var uLocal_2346 = 0;
var uLocal_2347 = 0;
var uLocal_2348 = 0;
var uLocal_2349 = 0;
var uLocal_2350 = 0;
var uLocal_2351 = 0;
var uLocal_2352 = 0;
var uLocal_2353 = 0;
var uLocal_2354 = 0;
var uLocal_2355 = 0;
var uLocal_2356 = 0;
var uLocal_2357 = 0;
var uLocal_2358 = 0;
var uLocal_2359 = 0;
var uLocal_2360 = 0;
var uLocal_2361 = 0;
var uLocal_2362 = 0;
var uLocal_2363 = 0;
var uLocal_2364 = 0;
var uLocal_2365 = 0;
var uLocal_2366 = 0;
var uLocal_2367 = 0;
var uLocal_2368 = 0;
var uLocal_2369 = 0;
var uLocal_2370 = 0;
var uLocal_2371 = 0;
var uLocal_2372 = 0;
var uLocal_2373 = 0;
var uLocal_2374 = 0;
var uLocal_2375 = 0;
var uLocal_2376 = 0;
var uLocal_2377 = 0;
var uLocal_2378 = 0;
var uLocal_2379 = 0;
var uLocal_2380 = 0;
var uLocal_2381 = 0;
var uLocal_2382 = 0;
var uLocal_2383 = 0;
var uLocal_2384 = 0;
var uLocal_2385 = 0;
var uLocal_2386 = 0;
var uLocal_2387 = 0;
var uLocal_2388 = 0;
var uLocal_2389 = 0;
var uLocal_2390 = 0;
var uLocal_2391 = 0;
var uLocal_2392 = 0;
var uLocal_2393 = 0;
var uLocal_2394 = 0;
var uLocal_2395 = 0;
var uLocal_2396 = 0;
var uLocal_2397 = 0;
var uLocal_2398 = 0;
var uLocal_2399 = 0;
var uLocal_2400 = 0;
var uLocal_2401 = 0;
var uLocal_2402 = 0;
var uLocal_2403 = 0;
var uLocal_2404 = 0;
var uLocal_2405 = 0;
var uLocal_2406 = 0;
var uLocal_2407 = 0;
var uLocal_2408 = 0;
var uLocal_2409 = 0;
var uLocal_2410 = 0;
var uLocal_2411 = 0;
var uLocal_2412 = 0;
var uLocal_2413 = 0;
var uLocal_2414 = 0;
var uLocal_2415 = 13;
var uLocal_2416 = 0;
var uLocal_2417 = 0;
var uLocal_2418 = 0;
var uLocal_2419 = 0;
var uLocal_2420 = 0;
var uLocal_2421 = 0;
var uLocal_2422 = 0;
var uLocal_2423 = 0;
var uLocal_2424 = 0;
var uLocal_2425 = 0;
var uLocal_2426 = 0;
var uLocal_2427 = 0;
var uLocal_2428 = 0;
var uLocal_2429 = 0;
var uLocal_2430 = 0;
var uLocal_2431 = 0;
var uLocal_2432 = 0;
var uLocal_2433 = 0;
var uLocal_2434 = 0;
var uLocal_2435 = 0;
var uLocal_2436 = 0;
var uLocal_2437 = 0;
var uLocal_2438 = 0;
var uLocal_2439 = 0;
var uLocal_2440 = 0;
var uLocal_2441 = 0;
var uLocal_2442 = 0;
var uLocal_2443 = 0;
var uLocal_2444 = 0;
var uLocal_2445 = 0;
var uLocal_2446 = 0;
var uLocal_2447 = 0;
var uLocal_2448 = 0;
var uLocal_2449 = 0;
var uLocal_2450 = 0;
var uLocal_2451 = 0;
var uLocal_2452 = 0;
var uLocal_2453 = 0;
var uLocal_2454 = 0;
var uLocal_2455 = 0;
var uLocal_2456 = 0;
var uLocal_2457 = 0;
var uLocal_2458 = 0;
var uLocal_2459 = 0;
var uLocal_2460 = 0;
var uLocal_2461 = 0;
var uLocal_2462 = 0;
var uLocal_2463 = 0;
var uLocal_2464 = 0;
var uLocal_2465 = 0;
var uLocal_2466 = 0;
var uLocal_2467 = 0;
var uLocal_2468 = 0;
var uLocal_2469 = 0;
var uLocal_2470 = 0;
var uLocal_2471 = 0;
var uLocal_2472 = 0;
var uLocal_2473 = 0;
var uLocal_2474 = 0;
var uLocal_2475 = 0;
var uLocal_2476 = 0;
var uLocal_2477 = 0;
var uLocal_2478 = 0;
var uLocal_2479 = 0;
var uLocal_2480 = 0;
var uLocal_2481 = 0;
var uLocal_2482 = 0;
var uLocal_2483 = 0;
var uLocal_2484 = 0;
var uLocal_2485 = 0;
var uLocal_2486 = 0;
var uLocal_2487 = 0;
var uLocal_2488 = 0;
var uLocal_2489 = 0;
var uLocal_2490 = 0;
var uLocal_2491 = 0;
var uLocal_2492 = 0;
var uLocal_2493 = 0;
var uLocal_2494 = 0;
var uLocal_2495 = 0;
var uLocal_2496 = 0;
var uLocal_2497 = 0;
var uLocal_2498 = 0;
var uLocal_2499 = 0;
var uLocal_2500 = 0;
var uLocal_2501 = 0;
var uLocal_2502 = 0;
var uLocal_2503 = 0;
var uLocal_2504 = 0;
var uLocal_2505 = 0;
var uLocal_2506 = 0;
var uLocal_2507 = 0;
var uLocal_2508 = 0;
var uLocal_2509 = 0;
var uLocal_2510 = 0;
var uLocal_2511 = 0;
var uLocal_2512 = 0;
var uLocal_2513 = 0;
var uLocal_2514 = 0;
var uLocal_2515 = 0;
var uLocal_2516 = 0;
var uLocal_2517 = 0;
var uLocal_2518 = 0;
var uLocal_2519 = 0;
var uLocal_2520 = 0;
var uLocal_2521 = 0;
var uLocal_2522 = 0;
var uLocal_2523 = 0;
var uLocal_2524 = 0;
var uLocal_2525 = 0;
var uLocal_2526 = 0;
var uLocal_2527 = 0;
var uLocal_2528 = 0;
var uLocal_2529 = 0;
var uLocal_2530 = 0;
var uLocal_2531 = 0;
var uLocal_2532 = 0;
var uLocal_2533 = 0;
var uLocal_2534 = 0;
var uLocal_2535 = 0;
var uLocal_2536 = 0;
var uLocal_2537 = 0;
var uLocal_2538 = 0;
var uLocal_2539 = 0;
var uLocal_2540 = 0;
var uLocal_2541 = 0;
var uLocal_2542 = 0;
var uLocal_2543 = 0;
var uLocal_2544 = 0;
var uLocal_2545 = 0;
var uLocal_2546 = 0;
var uLocal_2547 = 0;
var uLocal_2548 = 0;
var uLocal_2549 = 0;
var uLocal_2550 = 0;
var uLocal_2551 = 0;
var uLocal_2552 = 0;
var uLocal_2553 = 0;
var uLocal_2554 = 0;
var uLocal_2555 = 0;
var uLocal_2556 = 0;
var uLocal_2557 = 0;
var uLocal_2558 = 0;
var uLocal_2559 = 0;
var uLocal_2560 = 0;
var uLocal_2561 = 0;
var uLocal_2562 = 0;
var uLocal_2563 = 0;
var uLocal_2564 = 0;
var uLocal_2565 = 0;
var uLocal_2566 = 0;
var uLocal_2567 = 0;
var uLocal_2568 = 0;
var uLocal_2569 = 0;
var uLocal_2570 = 0;
var uLocal_2571 = 0;
var uLocal_2572 = 0;
var uLocal_2573 = 0;
var uLocal_2574 = 0;
var uLocal_2575 = 0;
var uLocal_2576 = 0;
var uLocal_2577 = 0;
var uLocal_2578 = 0;
var uLocal_2579 = 0;
var uLocal_2580 = 0;
var uLocal_2581 = 0;
var uLocal_2582 = 0;
var uLocal_2583 = 0;
var uLocal_2584 = 0;
var uLocal_2585 = 0;
var uLocal_2586 = 0;
var uLocal_2587 = 0;
var uLocal_2588 = 0;
var uLocal_2589 = 0;
var uLocal_2590 = 0;
var uLocal_2591 = 0;
var uLocal_2592 = 0;
var uLocal_2593 = 0;
var uLocal_2594 = 0;
var uLocal_2595 = 0;
var uLocal_2596 = 0;
var uLocal_2597 = 0;
var uLocal_2598 = 0;
var uLocal_2599 = 0;
var uLocal_2600 = 0;
var uLocal_2601 = 0;
var uLocal_2602 = 0;
var uLocal_2603 = 0;
var uLocal_2604 = 0;
var uLocal_2605 = 0;
var uLocal_2606 = 0;
var uLocal_2607 = 0;
var uLocal_2608 = 0;
var uLocal_2609 = 0;
var uLocal_2610 = 0;
var uLocal_2611 = 0;
var uLocal_2612 = 0;
var uLocal_2613 = 0;
var uLocal_2614 = 0;
var uLocal_2615 = 0;
var uLocal_2616 = 0;
var uLocal_2617 = 0;
var uLocal_2618 = 0;
var uLocal_2619 = 0;
var uLocal_2620 = 0;
var uLocal_2621 = 0;
var uLocal_2622 = 0;
var uLocal_2623 = 0;
var uLocal_2624 = 13;
var uLocal_2625 = 0;
var uLocal_2626 = 0;
var uLocal_2627 = 0;
var uLocal_2628 = 0;
var uLocal_2629 = 0;
var uLocal_2630 = 0;
var uLocal_2631 = 0;
var uLocal_2632 = 0;
var uLocal_2633 = 0;
var uLocal_2634 = 0;
var uLocal_2635 = 0;
var uLocal_2636 = 0;
var uLocal_2637 = 0;
var uLocal_2638 = 13;
var uLocal_2639 = 0;
var uLocal_2640 = 0;
var uLocal_2641 = 0;
var uLocal_2642 = 0;
var uLocal_2643 = 0;
var uLocal_2644 = 0;
var uLocal_2645 = 0;
var uLocal_2646 = 0;
var uLocal_2647 = 0;
var uLocal_2648 = 0;
var uLocal_2649 = 0;
var uLocal_2650 = 0;
var uLocal_2651 = 0;
var uLocal_2652 = 13;
var uLocal_2653 = 0;
var uLocal_2654 = 0;
var uLocal_2655 = 0;
var uLocal_2656 = 0;
var uLocal_2657 = 0;
var uLocal_2658 = 0;
var uLocal_2659 = 0;
var uLocal_2660 = 0;
var uLocal_2661 = 0;
var uLocal_2662 = 0;
var uLocal_2663 = 0;
var uLocal_2664 = 0;
var uLocal_2665 = 0;
var uLocal_2666 = 13;
var uLocal_2667 = 0;
var uLocal_2668 = 0;
var uLocal_2669 = 0;
var uLocal_2670 = 0;
var uLocal_2671 = 0;
var uLocal_2672 = 0;
var uLocal_2673 = 0;
var uLocal_2674 = 0;
var uLocal_2675 = 0;
var uLocal_2676 = 0;
var uLocal_2677 = 0;
var uLocal_2678 = 0;
var uLocal_2679 = 0;
var uLocal_2680 = 0;
var uLocal_2681 = 0;
var uLocal_2682 = 0;
var uLocal_2683 = 0;
var uLocal_2684 = 0;
var uLocal_2685 = 0;
var uLocal_2686 = 0;
var uLocal_2687 = 0;
var uLocal_2688 = 0;
var uLocal_2689 = 0;
var uLocal_2690 = 0;
var uLocal_2691 = 0;
var uLocal_2692 = 0;
var uLocal_2693 = 0;
var uLocal_2694 = 0;
var uLocal_2695 = 0;
var uLocal_2696 = 0;
var uLocal_2697 = 0;
var uLocal_2698 = 0;
var uLocal_2699 = 0;
var uLocal_2700 = 0;
var uLocal_2701 = 0;
var uLocal_2702 = 0;
var uLocal_2703 = 0;
var uLocal_2704 = 0;
var uLocal_2705 = 0;
var uLocal_2706 = 0;
var uLocal_2707 = 0;
var uLocal_2708 = 0;
var uLocal_2709 = 0;
var uLocal_2710 = 0;
var *uLocal_2711 = NULL;
var uLocal_2712 = 0;
var uLocal_2713 = 8;
var uLocal_2714 = 0;
var uLocal_2715 = 0;
var uLocal_2716 = 0;
var uLocal_2717 = 4;
var uLocal_2718 = 0;
var uLocal_2719 = 0;
var uLocal_2720 = 0;
var uLocal_2721 = 0;
var uLocal_2722 = 0;
var uLocal_2723 = 0;
var uLocal_2724 = 0;
var uLocal_2725 = 0;
var uLocal_2726 = 0;
var uLocal_2727 = 0;
var uLocal_2728 = 0;
var uLocal_2729 = 0;
var uLocal_2730 = 0;
var uLocal_2731 = 0;
var uLocal_2732 = 4;
var uLocal_2733 = 0;
var uLocal_2734 = 0;
var uLocal_2735 = 0;
var uLocal_2736 = 0;
var uLocal_2737 = 0;
var uLocal_2738 = 0;
var uLocal_2739 = 0;
var uLocal_2740 = 0;
var uLocal_2741 = 0;
var uLocal_2742 = 0;
var uLocal_2743 = 0;
var uLocal_2744 = 0;
var uLocal_2745 = 0;
var uLocal_2746 = 0;
var uLocal_2747 = 4;
var uLocal_2748 = 0;
var uLocal_2749 = 0;
var uLocal_2750 = 0;
var uLocal_2751 = 0;
var uLocal_2752 = 0;
var uLocal_2753 = 0;
var uLocal_2754 = 0;
var uLocal_2755 = 0;
var uLocal_2756 = 0;
var uLocal_2757 = 0;
var uLocal_2758 = 0;
var uLocal_2759 = 0;
var uLocal_2760 = 0;
var uLocal_2761 = 0;
var uLocal_2762 = 4;
var uLocal_2763 = 0;
var uLocal_2764 = 0;
var uLocal_2765 = 0;
var uLocal_2766 = 0;
var uLocal_2767 = 0;
var uLocal_2768 = 0;
var uLocal_2769 = 0;
var uLocal_2770 = 0;
var uLocal_2771 = 0;
var uLocal_2772 = 0;
var uLocal_2773 = 0;
var uLocal_2774 = 0;
var uLocal_2775 = 0;
var uLocal_2776 = 0;
var uLocal_2777 = 4;
var uLocal_2778 = 0;
var uLocal_2779 = 0;
var uLocal_2780 = 0;
var uLocal_2781 = 0;
var uLocal_2782 = 0;
var uLocal_2783 = 0;
var uLocal_2784 = 0;
var uLocal_2785 = 0;
var uLocal_2786 = 0;
var uLocal_2787 = 0;
var uLocal_2788 = 0;
var uLocal_2789 = 0;
var uLocal_2790 = 0;
var uLocal_2791 = 0;
var uLocal_2792 = 4;
var uLocal_2793 = 0;
var uLocal_2794 = 0;
var uLocal_2795 = 0;
var uLocal_2796 = 0;
var uLocal_2797 = 0;
var uLocal_2798 = 0;
var uLocal_2799 = 0;
var uLocal_2800 = 0;
var uLocal_2801 = 0;
var uLocal_2802 = 0;
var uLocal_2803 = 0;
var uLocal_2804 = 0;
var uLocal_2805 = 0;
var uLocal_2806 = 0;
var uLocal_2807 = 4;
var uLocal_2808 = 0;
var uLocal_2809 = 0;
var uLocal_2810 = 0;
var uLocal_2811 = 0;
var uLocal_2812 = 0;
var uLocal_2813 = 0;
var uLocal_2814 = 0;
var uLocal_2815 = 0;
var uLocal_2816 = 0;
var uLocal_2817 = 0;
var uLocal_2818 = 0;
var uLocal_2819 = 0;
var uLocal_2820 = 0;
var uLocal_2821 = 0;
var uLocal_2822 = 4;
var uLocal_2823 = 0;
var uLocal_2824 = 0;
var uLocal_2825 = 0;
var uLocal_2826 = 0;
var uLocal_2827 = 0;
var uLocal_2828 = 0;
var uLocal_2829 = 0;
var uLocal_2830 = 0;
var uLocal_2831 = 0;
var uLocal_2832 = 0;
var uLocal_2833 = 0;
var uLocal_2834 = 0;
int *iLocal_2835 = NULL;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	vLocal_127 = {1967.042f, 3116.005f, 45.8901f};
	vLocal_130 = {1967.042f, 3116.005f, 45.8901f};
	vLocal_133 = {1967.042f, 3116.005f, 45.8901f};
	sLocal_136 = "Stage Setup";
	sLocal_137 = "Race";
	sLocal_138 = "Complete";
	sLocal_139 = "";
	vLocal_181 = {8.669f, -5.9084f, 0.0428f};
	iLocal_2127 = player::player_ped_id();
	gameplay::set_mission_flag(1);
	if (player::has_force_cleanup_occurred(3)) {
		func_334(1, 0, 1, 0);
	}
	func_324();
	func_315();
	while (true) {
		if (iLocal_1975 != 3) {
			func_268();
		}
		switch (iLocal_1975) {
		case 0: func_244(); break;

		case 1: func_209(); break;

		case 2: func_57(); break;

		case 3: func_1(); break;
		}
		system::wait(0);
	}
}

// Position - 0x147
void func_1() {
	controls::disable_control_action(0, 80, 1);
	func_52();
	switch (iLocal_174) {
	case 0:
		cam::set_cinematic_button_active(0);
		iLocal_174++;
		break;

	case 1:
		if (func_25(&uLocal_2120, &iLocal_1981, "CRACEFAIL", sLocal_180, &bLocal_141, 78, 7, 1, 1097859072, 1)) {
			if (bLocal_141) {
				audio::play_sound_frontend(-1, "YES", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				func_2(1, 0);
			}
			else {
				audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				cam::do_screen_fade_out(500);
				system::settimera(0);
				iLocal_174++;
			}
		}
		break;

	case 2:
		if (system::timera() > 1500) {
			func_334(1, 1, 0, 0);
		}
		break;
	}
}

// Position - 0x1F0
void func_2(int iParam0, int iParam1) {
	cam::do_screen_fade_out(500);
	while (!cam::is_screen_faded_out()) {
		ped::set_ped_density_multiplier_this_frame(0f);
		vehicle::set_vehicle_density_multiplier_this_frame(0f);
		ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
		system::wait(0);
	}
	func_24();
	func_334(0, 1, iParam1, 0);
	func_315();
	switch (iParam0) {
	case 0:
		func_23(iLocal_2127, vLocal_127, 103.4f, 1, 1);
		func_22();
		break;

	case 1:
		func_23(iLocal_2127, vLocal_130, 103.4f, 1, 1);
		func_7();
		break;

	case 2:
		func_23(iLocal_2127, vLocal_133, 103.4f, 1, 1);
		func_6();
		break;
	}
	func_4(entity::get_entity_coords(iLocal_2127, 1), 1112014848, 12, 5000, 0, 0);
	cam::set_gameplay_cam_relative_heading(0f);
	cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
	func_3(500);
}

// Position - 0x2C5
void func_3(int iParam0) {
	if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
		if (!cam::is_screen_fading_in()) {
			cam::do_screen_fade_in(iParam0);
		}
	}
	while (!cam::is_screen_faded_in()) {
		ped::set_ped_density_multiplier_this_frame(0f);
		vehicle::set_vehicle_density_multiplier_this_frame(0f);
		ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
		system::wait(0);
	}
}

// Position - 0x30C
void func_4(vector3 vParam0, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	int iVar1;

	iVar0 = streaming::format_focus_heading(vParam0, iParam3, iParam4, 127);
	if (streaming::_0x07C313F94746702C(iVar0)) {
		iVar1 = gameplay::get_game_timer() + iParam5;
		while (!streaming::_0x7D41E9D2D17C5B2D(iVar0) && gameplay::get_game_timer() < iVar1) {
			if (iParam7) {
				func_52();
			}
			if (iParam6) {
				func_5();
			}
			system::wait(0);
		}
		if (gameplay::get_game_timer() < iVar1) {
		}
		streaming::_0x1EE7D8DF4425F053(iVar0);
	}
}

// Position - 0x37B
void func_5() { Global_17151.f_6 = 1; }

// Position - 0x389
void func_6() {
	Local_46.f_6 = 1;
	ai::request_waypoint_recording(Local_54.f_64);
	while (!ai::get_is_waypoint_recording_loaded(Local_54.f_64)) {
		system::wait(0);
	}
	if (entity::does_entity_exist(player::get_players_last_vehicle())) {
		iLocal_2129 = player::get_players_last_vehicle();
		entity::set_entity_as_mission_entity(iLocal_2129, 1, 0);
	}
	else {
		streaming::request_model(joaat("gauntlet"));
		while (!streaming::has_model_loaded(joaat("gauntlet"))) {
			system::wait(0);
		}
		iLocal_2129 = vehicle::create_vehicle(joaat("gauntlet"), Local_54[5 /*3*/], Local_54.f_54[8], 1, 1);
		streaming::set_model_as_no_longer_needed(joaat("gauntlet"));
		ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
	}
	func_23(player::get_players_last_vehicle(), Local_54[5 /*3*/], Local_54.f_54[1], 0, 1);
	vehicle::set_vehicle_forward_speed(player::get_players_last_vehicle(), 30f);
	iLocal_1975 = 2;
}

// Position - 0x44A
void func_7() {
	int iVar0;

	func_21(&Local_46);
	while (!func_20(&Local_46)) {
		system::wait(0);
	}
	func_12(197, 1, 0, 1, 0);
	iVar0 = 0;
	while (iVar0 <= 7) {
		func_9(&Local_196[iVar0 /*50*/], 1, 0);
		iVar0++;
	}
	if (!func_8(iLocal_2129)) {
		if (entity::does_entity_exist(player::get_players_last_vehicle())) {
			iLocal_2129 = player::get_players_last_vehicle();
			entity::set_entity_as_mission_entity(iLocal_2129, 1, 0);
		}
		else {
			streaming::request_model(joaat("gauntlet"));
			while (!streaming::has_model_loaded(joaat("gauntlet"))) {
				system::wait(0);
			}
			iLocal_2129 = vehicle::create_vehicle(joaat("gauntlet"), Local_54.f_26[8 /*3*/], Local_54.f_54[8], 1, 1);
			ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
		}
	}
	else {
		func_23(iLocal_2129, Local_54.f_26[8 /*3*/], Local_54.f_54[8], 0, 1);
		ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
	}
	vehicle::set_vehicle_fixed(iLocal_2129);
	vehicle::set_vehicle_doors_locked(iLocal_2129, 4);
	vehicle::set_vehicle_handbrake(iLocal_2129, 1);
	ai::request_waypoint_recording(Local_54.f_64);
	while (!ai::get_is_waypoint_recording_loaded(Local_54.f_64)) {
		system::wait(0);
	}
	func_23(iLocal_2129, Local_54.f_26[8 /*3*/], Local_54.f_54[8], 0, 1);
	iLocal_1975 = 1;
}

// Position - 0x583
bool func_8(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x5A4
void func_9(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!uParam0->f_41) {
		streaming::request_model(uParam0->f_3);
		if (iParam1) {
			while (!streaming::has_model_loaded(uParam0->f_3)) {
				system::wait(0);
			}
		}
		streaming::request_model(uParam0->f_5.f_2);
		if (iParam1) {
			while (!streaming::has_model_loaded(uParam0->f_5.f_2)) {
				system::wait(0);
			}
		}
		iVar0 = 0;
		if (streaming::has_model_loaded(uParam0->f_3) && streaming::has_model_loaded(uParam0->f_5.f_2)) {
			iVar0 = 1;
		}
		if (iVar0 && (iParam2 == 0 || iParam2 == 1 && !cam::is_sphere_visible(uParam0->f_37, 2f))) {
			uParam0->f_5.f_3 = {uParam0->f_37};
			uParam0->f_5.f_6 = uParam0->f_40;
			uParam0->f_5 = vehicle::create_vehicle(uParam0->f_5.f_2, uParam0->f_37, uParam0->f_40, 1, 1);
			streaming::set_model_as_no_longer_needed(uParam0->f_5.f_2);
			vehicle::set_vehicle_engine_on(uParam0->f_5, 1, 1, 0);
			uParam0->f_5.f_7 = 1;
			*uParam0 = ped::create_ped_inside_vehicle(uParam0->f_5, 26, uParam0->f_3, -1, 1, 1);
			func_11(uParam0);
			vehicle::_0x1AA8A837D2169D94(uParam0->f_5, 1);
			if (entity::does_entity_exist(*uParam0)) {
				ped::set_ped_accuracy(*uParam0, 20);
				ped::set_ped_alertness(*uParam0, 3);
				ped::set_ped_combat_ability(*uParam0, 2);
				ped::set_ped_combat_attributes(*uParam0, 42, 1);
				ped::set_ped_combat_attributes(*uParam0, 28, 1);
				ped::set_ped_combat_attributes(*uParam0, 52, 1);
				ped::set_ped_combat_attributes(*uParam0, 35, 1);
				ped::set_ped_combat_attributes(*uParam0, 14, 1);
				ped::set_ped_combat_attributes(*uParam0, 29, 1);
				ped::set_ped_combat_movement(*uParam0, 1);
				ped::set_ped_config_flag(*uParam0, 281, 1);
				ped::set_ped_config_flag(*uParam0, 132, 1);
				ped::set_ped_config_flag(*uParam0, 188, 1);
				ped::set_ped_dies_when_injured(*uParam0, 1);
				ped::set_ped_keep_task(*uParam0, 1);
				ped::set_ped_name_debug(*uParam0, &uParam0->f_46);
				ped::set_ped_relationship_group_hash(*uParam0, uParam0->f_4);
				ped::set_blocking_of_non_temporary_events(*uParam0, 1);
				uParam0->f_42 = 0;
				uParam0->f_41 = 1;
				uParam0->f_44 = 0;
				if (uParam0->f_17.f_11 == 1) {
					func_10(*uParam0);
				}
				streaming::set_model_as_no_longer_needed(uParam0->f_3);
			}
		}
	}
}

// Position - 0x793
void func_10(int iParam0) {
	switch (Global_101700.f_24032) {
	case 0:
		ped::set_ped_component_variation(iParam0, 0, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;

	case 1:
		ped::set_ped_component_variation(iParam0, 0, 1, 1, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 7, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 4, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 1, 0);
		break;

	case 2:
		ped::set_ped_component_variation(iParam0, 0, 1, 2, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 5, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 2, 0);
		break;

	case 3:
		ped::set_ped_component_variation(iParam0, 0, 1, 0, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 2, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 3, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;

	case 4:
		ped::set_ped_component_variation(iParam0, 0, 0, 1, 0);
		ped::set_ped_component_variation(iParam0, 3, 0, 6, 0);
		ped::set_ped_component_variation(iParam0, 4, 0, 0, 0);
		ped::set_ped_component_variation(iParam0, 6, 0, 3, 0);
		ped::set_ped_component_variation(iParam0, 10, 0, 0, 0);
		break;
	}
}

// Position - 0x8D3
void func_11(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	int iVar18;
	int iVar19;
	int iVar20;
	int iVar21;

	iVar0 = -1;
	iVar1 = -1;
	iVar2 = -1;
	iVar3 = -1;
	iVar4 = -1;
	iVar5 = -1;
	iVar6 = -1;
	iVar7 = -1;
	iVar8 = -1;
	iVar9 = -1;
	iVar10 = -1;
	iVar11 = -1;
	iVar12 = -1;
	iVar13 = 3;
	iVar14 = 2;
	iVar15 = 2;
	iVar16 = 3;
	iVar17 = -1;
	iVar18 = -1;
	iVar19 = -1;
	iVar20 = -1;
	iVar21 = -1;
	switch (Global_101700.f_24032) {
	case 0:
		switch (uParam0->f_17.f_11) {
		case 0:
			iVar0 = 6;
			iVar1 = 1;
			iVar2 = -1;
			iVar3 = 0;
			iVar4 = 1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = 0;
			iVar9 = 3;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 3;
			iVar14 = 2;
			iVar15 = 2;
			iVar16 = 3;
			iVar17 = 6;
			iVar18 = 0;
			iVar19 = 27;
			iVar20 = 0;
			iVar21 = 120;
			break;

		case 2:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = -1;
			iVar3 = 2;
			iVar4 = 0;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = 1;
			iVar8 = 0;
			iVar9 = -1;
			iVar10 = 0;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 3;
			iVar14 = 2;
			iVar15 = 2;
			iVar16 = -1;
			iVar17 = 1;
			iVar18 = 24;
			iVar19 = 0;
			iVar20 = 0;
			iVar21 = 132;
			vehicle::set_convertible_roof(uParam0->f_5, 0);
			break;

		case 3:
			iVar0 = 0;
			iVar1 = 1;
			iVar2 = -1;
			iVar3 = 0;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = 1;
			iVar11 = 0;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 2;
			iVar15 = 2;
			iVar16 = -1;
			iVar17 = 10;
			iVar18 = 147;
			iVar19 = 16;
			iVar20 = 20;
			iVar21 = 119;
			break;

		case 4:
			iVar0 = 0;
			iVar1 = 0;
			iVar2 = 1;
			iVar3 = 0;
			iVar4 = 0;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = 0;
			iVar9 = 3;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 1;
			iVar15 = 1;
			iVar16 = -1;
			iVar17 = 8;
			iVar18 = 60;
			iVar19 = 113;
			iVar20 = 19;
			iVar21 = 113;
			break;

		case 5:
			iVar0 = 10;
			iVar1 = 2;
			iVar2 = 1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 2;
			iVar14 = 1;
			iVar15 = 1;
			iVar16 = 2;
			iVar17 = 11;
			iVar18 = 138;
			iVar19 = 0;
			iVar20 = 1;
			iVar21 = 138;
			break;

		case 6:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 3;
			iVar3 = 1;
			iVar4 = 0;
			iVar5 = 1;
			iVar6 = 3;
			iVar7 = 0;
			iVar8 = 2;
			iVar9 = 1;
			iVar10 = 1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 0;
			iVar15 = 2;
			iVar16 = 1;
			iVar17 = 23;
			iVar18 = 64;
			iVar19 = 13;
			iVar20 = 13;
			iVar21 = 67;
			break;

		case 7:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = 2;
			iVar9 = 2;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 1;
			iVar15 = 2;
			iVar16 = 1;
			iVar17 = 11;
			iVar18 = 39;
			iVar19 = 107;
			iVar20 = 0;
			iVar21 = 156;
			break;
		}
		break;

	case 1:
		switch (uParam0->f_17.f_11) {
		case 0:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = 0;
			iVar4 = 0;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 2;
			iVar13 = 1;
			iVar14 = 0;
			iVar15 = 0;
			iVar16 = -1;
			iVar17 = 14;
			iVar18 = 11;
			iVar19 = 36;
			iVar20 = 0;
			iVar21 = 36;
			break;

		case 2:
			iVar0 = 0;
			iVar1 = 4;
			iVar2 = 0;
			iVar3 = 3;
			iVar4 = 0;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = 1;
			iVar9 = 1;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 2;
			iVar15 = 0;
			iVar16 = 3;
			iVar17 = 12;
			iVar18 = 24;
			iVar19 = 64;
			iVar20 = 0;
			iVar21 = 24;
			break;

		case 3:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = 0;
			iVar4 = 0;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = -1;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 3;
			iVar14 = 2;
			iVar15 = 0;
			iVar16 = 0;
			iVar17 = 23;
			iVar18 = 120;
			iVar19 = 120;
			iVar20 = 120;
			iVar21 = 120;
			break;

		case 4:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 3;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 3;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 1;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 1;
			iVar15 = 2;
			iVar16 = 2;
			iVar17 = 3;
			iVar18 = 40;
			iVar19 = 42;
			iVar20 = 7;
			iVar21 = 156;
			break;

		case 5:
			iVar0 = 7;
			iVar1 = 0;
			iVar2 = -1;
			iVar3 = 0;
			iVar4 = 1;
			iVar5 = -1;
			iVar6 = 1;
			iVar7 = 0;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 1;
			iVar14 = 2;
			iVar15 = 0;
			iVar16 = -1;
			iVar17 = 22;
			iVar18 = 62;
			iVar19 = 91;
			iVar20 = 6;
			iVar21 = 156;
			vehicle::set_convertible_roof(uParam0->f_5, 1);
			break;

		case 6:
			iVar0 = 0;
			iVar1 = 1;
			iVar2 = 0;
			iVar3 = 0;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 1;
			iVar7 = 1;
			iVar8 = -1;
			iVar9 = 2;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 2;
			iVar14 = 1;
			iVar15 = 0;
			iVar16 = 1;
			iVar17 = 11;
			iVar18 = 50;
			iVar19 = 120;
			iVar20 = 134;
			iVar21 = 156;
			break;

		case 7:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 1;
			iVar3 = 1;
			iVar4 = -1;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = 0;
			iVar9 = 1;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 3;
			iVar14 = 2;
			iVar15 = 0;
			iVar16 = 3;
			iVar17 = 8;
			iVar18 = 36;
			iVar19 = 25;
			iVar20 = 6;
			iVar21 = 156;
			break;
		}
		break;

	case 2:
		switch (uParam0->f_17.f_11) {
		case 0:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 1;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 3;
			iVar14 = 2;
			iVar15 = 0;
			iVar16 = 0;
			iVar17 = 7;
			iVar18 = 64;
			iVar19 = 2;
			iVar20 = 6;
			iVar21 = 2;
			break;

		case 2:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 2;
			iVar3 = 1;
			iVar4 = 2;
			iVar5 = 0;
			iVar6 = 2;
			iVar7 = 0;
			iVar8 = 1;
			iVar9 = -1;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 2;
			iVar14 = 2;
			iVar15 = 1;
			iVar16 = 3;
			iVar17 = 5;
			iVar18 = 52;
			iVar19 = 5;
			iVar20 = 26;
			iVar21 = 106;
			break;

		case 3:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = 0;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 2;
			iVar14 = 0;
			iVar15 = 0;
			iVar16 = 1;
			iVar17 = 15;
			iVar18 = 72;
			iVar19 = 38;
			iVar20 = 46;
			iVar21 = 156;
			break;

		case 4:
			iVar0 = 0;
			iVar1 = 1;
			iVar2 = 1;
			iVar3 = 1;
			iVar4 = 0;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 0;
			iVar14 = 0;
			iVar15 = 0;
			iVar16 = 0;
			iVar17 = 10;
			iVar18 = 62;
			iVar19 = 126;
			iVar20 = 15;
			iVar21 = 126;
			break;

		case 5:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = 0;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 1;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 2;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = 0;
			iVar13 = 1;
			iVar14 = 1;
			iVar15 = 0;
			iVar16 = 0;
			iVar17 = 11;
			iVar18 = 29;
			iVar19 = 9;
			iVar20 = 6;
			iVar21 = 9;
			break;

		case 6:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = -1;
			iVar9 = 3;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 1;
			iVar14 = 0;
			iVar15 = 0;
			iVar16 = 0;
			iVar17 = 15;
			iVar18 = 143;
			iVar19 = 8;
			iVar20 = 1;
			iVar21 = 143;
			break;

		case 7:
			iVar0 = 0;
			iVar1 = -1;
			iVar2 = 0;
			iVar3 = 2;
			iVar4 = 0;
			iVar5 = -1;
			iVar6 = 1;
			iVar7 = 0;
			iVar8 = -1;
			iVar9 = 0;
			iVar10 = -1;
			iVar11 = -1;
			iVar12 = -1;
			iVar13 = 1;
			iVar14 = 0;
			iVar15 = 0;
			iVar16 = 3;
			iVar17 = 4;
			iVar18 = 15;
			iVar19 = 120;
			iVar20 = 120;
			iVar21 = 120;
			break;
		}
		break;

	case 3:
		switch (uParam0->f_17.f_11) {
		case 0:
			iVar0 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = -1;
			iVar9 = -1;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			iVar18 = 140;
			iVar19 = 122;
			iVar20 = 58;
			iVar21 = 17;
			break;

		case 2:
			iVar0 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = -1;
			iVar9 = -1;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			iVar18 = 149;
			iVar19 = 122;
			iVar20 = 114;
			iVar21 = 92;
			break;

		case 3:
			iVar0 = -1;
			iVar2 = 1;
			iVar3 = 0;
			iVar4 = 0;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = 0;
			iVar8 = 0;
			iVar12 = 2;
			iVar9 = 0;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			iVar18 = 27;
			iVar19 = 134;
			iVar20 = 28;
			iVar21 = 126;
			break;

		case 4:
			iVar0 = -1;
			iVar2 = 0;
			iVar3 = 0;
			iVar4 = 0;
			iVar5 = 0;
			iVar6 = 0;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = 0;
			iVar9 = -1;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			break;

		case 5:
			iVar0 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = -1;
			iVar9 = -1;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			iVar18 = 88;
			iVar19 = 40;
			iVar20 = 14;
			iVar21 = 123;
			break;

		case 6:
			iVar0 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = -1;
			iVar9 = -1;
			iVar13 = -1;
			iVar14 = -1;
			iVar15 = -1;
			iVar16 = -1;
			iVar18 = 55;
			iVar19 = 40;
			iVar20 = 14;
			iVar21 = 0;
			break;

		case 7:
			iVar0 = -1;
			iVar2 = -1;
			iVar3 = -1;
			iVar4 = -1;
			iVar5 = -1;
			iVar6 = -1;
			iVar7 = -1;
			iVar8 = -1;
			iVar12 = -1;
			iVar9 = -1;
			iVar18 = 38;
			iVar19 = 121;
			iVar20 = 123;
			iVar21 = 132;
			break;
		}
		break;

	case 4:
		switch (uParam0->f_17.f_11) {
		case 0:
			iVar18 = 140;
			iVar19 = 124;
			iVar20 = 134;
			iVar21 = 89;
			break;

		case 1:
			iVar18 = 135;
			iVar19 = 134;
			iVar20 = 134;
			iVar21 = 121;
			break;

		case 2: break;

		case 3:
			iVar18 = 0;
			iVar19 = 134;
			iVar20 = 134;
			iVar21 = 0;
			break;

		case 4:
			iVar18 = 57;
			iVar19 = 134;
			iVar20 = 134;
			iVar21 = 67;
			break;

		case 5: break;

		case 6:
			iVar18 = 141;
			iVar19 = 134;
			iVar20 = 134;
			iVar21 = 127;
			break;

		case 7:
			iVar18 = 39;
			iVar19 = 95;
			iVar20 = 124;
			iVar21 = 88;
			break;
		}
		break;
	}
	if (uParam0->f_17.f_11 == 1) {
		iVar16 = 3;
	}
	iVar13 = vehicle::get_num_vehicle_mods(uParam0->f_5, 11) - 1;
	iVar14 = vehicle::get_num_vehicle_mods(uParam0->f_5, 12) - 1;
	iVar15 = vehicle::get_num_vehicle_mods(uParam0->f_5, 13) - 1;
	if (func_8(uParam0->f_5)) {
		if (vehicle::get_num_mod_kits(uParam0->f_5) > 0) {
			vehicle::set_vehicle_mod_kit(uParam0->f_5, 0);
			if (iVar0 != -1) {
				if (iVar0 < vehicle::get_number_of_vehicle_colours(uParam0->f_5)) {
					vehicle::set_vehicle_colour_combination(uParam0->f_5, iVar0);
				}
			}
			if (iVar18 != -1 || iVar19 != -1) {
				vehicle::set_vehicle_colours(uParam0->f_5, iVar18, iVar19);
			}
			if (iVar20 != -1 || iVar21 != -1) {
				vehicle::set_vehicle_extra_colours(uParam0->f_5, iVar20, iVar21);
			}
			if (iVar1 != -1) {
				vehicle::set_vehicle_window_tint(uParam0->f_5, iVar1);
			}
			if (iVar2 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 0) > iVar2) {
					vehicle::set_vehicle_mod(uParam0->f_5, 0, iVar2, 0);
				}
			}
			if (iVar3 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 1) > iVar3) {
					vehicle::set_vehicle_mod(uParam0->f_5, 1, iVar3, 0);
				}
			}
			if (iVar4 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 2) > iVar4) {
					vehicle::set_vehicle_mod(uParam0->f_5, 2, iVar4, 0);
				}
			}
			if (iVar5 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 3) > iVar5) {
					vehicle::set_vehicle_mod(uParam0->f_5, 3, iVar5, 0);
				}
			}
			if (iVar6 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 4) > iVar6) {
					vehicle::set_vehicle_mod(uParam0->f_5, 4, iVar6, 0);
				}
			}
			if (iVar7 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 5) > iVar7) {
					vehicle::set_vehicle_mod(uParam0->f_5, 5, iVar7, 0);
				}
			}
			if (iVar8 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 6) > iVar8) {
					vehicle::set_vehicle_mod(uParam0->f_5, 6, iVar8, 0);
				}
			}
			if (iVar9 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 7) > iVar9) {
					vehicle::set_vehicle_mod(uParam0->f_5, 7, iVar9, 0);
				}
			}
			if (iVar10 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 8) > iVar10) {
					vehicle::set_vehicle_mod(uParam0->f_5, 8, iVar10, 0);
				}
			}
			if (iVar11 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 9) > iVar11) {
					vehicle::set_vehicle_mod(uParam0->f_5, 9, iVar11, 0);
				}
			}
			if (iVar12 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 10) > iVar12) {
					vehicle::set_vehicle_mod(uParam0->f_5, 10, iVar12, 0);
				}
			}
			if (iVar13 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 11) > iVar13) {
					vehicle::set_vehicle_mod(uParam0->f_5, 11, iVar13, 0);
				}
			}
			if (iVar14 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 12) > iVar14) {
					vehicle::set_vehicle_mod(uParam0->f_5, 12, iVar14, 0);
				}
			}
			if (iVar15 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 13) > iVar15) {
					vehicle::set_vehicle_mod(uParam0->f_5, 13, iVar15, 0);
				}
			}
			if (iVar16 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 15) > iVar16) {
					vehicle::set_vehicle_mod(uParam0->f_5, 15, iVar16, 0);
				}
			}
			if (iVar17 != -1) {
				if (vehicle::get_num_vehicle_mods(uParam0->f_5, 23) > iVar17) {
					vehicle::set_vehicle_mod(uParam0->f_5, 23, iVar17, 0);
				}
			}
			vehicle::toggle_vehicle_mod(uParam0->f_5, 18, 1);
			vehicle::toggle_vehicle_mod(uParam0->f_5, 17, 1);
			vehicle::toggle_vehicle_mod(uParam0->f_5, 22, 1);
		}
		if (vehicle::is_vehicle_a_convertible(uParam0->f_5, 0)) {
			vehicle::set_convertible_roof(uParam0->f_5, 1);
		}
	}
}

// Position - 0x15B0
void func_12(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (iParam0 != 198) {
		if (Global_69702) {
			Global_2433125.f_74.f_227[iParam0] = iParam1;
		}
		else {
			Global_101700.f_6220.f_227[iParam0] = iParam1;
		}
		Global_32749[iParam0] = iParam2;
		Global_32948[iParam0] = 1;
		func_15(iParam0, iParam3, iParam4, 0);
		func_13(iParam0, iParam1);
	}
}

// Position - 0x160B
void func_13(int iParam0, int iParam1) {
	switch (iParam0) {
	case 12:
		if (iParam1 == 0) {
			audio::set_ambient_zone_state_persistent("AZ_PORT_OF_LS_UNDERWATER_CREAKS", 0, 0);
		}
		else {
			audio::set_ambient_zone_state_persistent("AZ_PORT_OF_LS_UNDERWATER_CREAKS", 1, 0);
		}
		break;

	case 71:
		if (iParam1 != 1) {
			audio::set_ambient_zone_list_state_persistent("HEIST_SWEATSHOP_ZONES", 0, 0);
		}
		else {
			audio::set_ambient_zone_list_state_persistent("HEIST_SWEATSHOP_ZONES", 1, 0);
		}
		break;

	case 65:
		if (iParam1 == 1) {
			func_14(0, 0);
		}
		else {
			func_14(0, 1);
		}
		break;

	case 6:
		if (iParam1 == 1) {
			audio::set_ambient_zone_state_persistent("AZ_UNDERWATER_EXILE_01_PLANE_WRECK", 1, 0);
		}
		else {
			audio::set_ambient_zone_state_persistent("AZ_UNDERWATER_EXILE_01_PLANE_WRECK", 0, 0);
		}
		break;

	case 174:
		if (iParam1 == 2) {
			audio::_0xB4BBFD9CD8B3922B("V_CARSHOWROOM_PS_WINDOW_UNBROKEN");
		}
		break;

	case 37:
		if (iParam1 == 1) {
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_STAGE_RADIO", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_01", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_02", 0);
			audio::set_static_emitter_enabled("TREVOR1_TRAILER_PARK_MAIN_TRAILER_RADIO_03", 0);
		}
		break;
	}
}

// Position - 0x16EB
void func_14(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_100340, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_100340, iParam0);
	}
	Global_100339 = 1;
}

// Position - 0x1714
bool func_15(int iParam0, bool bParam1, int iParam2, int iParam3) {
	bool bVar0;
	int iVar1;
	int iVar2;
	struct<5> Var3;
	var uVar98;
	bool bVar99;
	int iVar100;

	bVar0 = false;
	Var3.f_4 = 3;
	Var3.f_8 = 3;
	Var3.f_64 = 3;
	Var3.f_75 = 3;
	Var3.f_91 = 3;
	func_19(&Var3, iParam0);
	if (func_16()) {
		iVar1 = Global_101700.f_6220.f_227[iParam0];
	}
	else {
		iVar1 = Global_2433125.f_74.f_227[iParam0];
	}
	iVar2 = Global_33147[iParam0];
	if (ped::is_ped_injured(player::player_ped_id()) && !iParam3) {
	}
	else {
		bVar99 = true;
		if (gameplay::get_hash_key(script::get_this_script_name()) != gameplay::get_hash_key("standard_global_reg")) {
			if (iParam2 == 0) {
				if (Global_32749[iParam0] &&
					gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 0), Var3,
														  1) < 200f) {
					bVar99 = false;
				}
				if (!player::is_player_playing(player::player_id()) ||
					ai::is_ped_being_arrested(player::player_ped_id())) {
					if (!cam::is_screen_faded_out()) {
						bVar99 = false;
					}
				}
			}
		}
		if (streaming::is_new_load_scene_active() &&
			(!streaming::is_player_switch_in_progress() || streaming::get_player_switch_state() != 5)) {
			bVar99 = false;
		}
		if (bVar99) {
			switch (Var3.f_3) {
			case 0:
				if (iVar1 == 2) {
				}
				else {
					if (Var3.f_4[iVar1] != 0) {
						entity::remove_model_hide(Var3, 10f, Var3.f_4[iVar1], 0);
					}
					if (Var3.f_4[iVar2] != 0) {
						entity::create_model_hide(Var3, 10f, Var3.f_4[iVar2], 1);
					}
					Global_34343[iParam0] = 1;
				}
				bVar0 = true;
				break;

			case 1:
				if (iVar1 == 0) {
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_34)) {
							streaming::request_ipl(&Var3.f_34);
						}
					}
				}
				else if (iVar1 == 1) {
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (streaming::is_ipl_active(&Var3.f_34)) {
							streaming::remove_ipl(&Var3.f_34);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
						if (!streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
				}
				else if (iVar1 == 2) {
					if (gameplay::get_hash_key(&Var3.f_34) != gameplay::get_hash_key("")) {
						if (streaming::is_ipl_active(&Var3.f_34)) {
							streaming::remove_ipl(&Var3.f_34);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[0 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[0 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
						if (streaming::is_ipl_active(&Var3.f_8[1 /*8*/])) {
							streaming::remove_ipl(&Var3.f_8[1 /*8*/]);
						}
					}
					if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
						gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES")) {
						if (!streaming::is_ipl_active(&Var3.f_8[2 /*8*/])) {
							streaming::request_ipl(&Var3.f_8[2 /*8*/]);
						}
					}
				}
				Global_34144[iParam0] = 1;
				Global_34343[iParam0] = 1;
				bVar0 = true;
				break;

			case 2:
				iVar100 = interior::get_interior_at_coords_with_type(Var3, &Var3.f_42);
				if (iVar100 != 0) {
					if (gameplay::get_hash_key(&Var3.f_50) != gameplay::get_hash_key("")) {
						if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_50)) {
							interior::_disable_interior_prop(iVar100, &Var3.f_50);
						}
					}
					if (iVar1 == 0) {
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) !=
								gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
					}
					else if (iVar1 == 1) {
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) !=
								gameplay::get_hash_key(&Var3.f_8[iVar1 /*8*/])) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
					}
					else if (iVar1 == 2) {
						if (gameplay::get_hash_key(&Var3.f_8[0 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[0 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[0 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[1 /*8*/]) != gameplay::get_hash_key("")) {
							if (interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[1 /*8*/])) {
								interior::_disable_interior_prop(iVar100, &Var3.f_8[1 /*8*/]);
							}
						}
						if (gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("") &&
							gameplay::get_hash_key(&Var3.f_8[2 /*8*/]) != gameplay::get_hash_key("REMOVE_ALL_STATES")) {
							if (!interior::_is_interior_prop_enabled(iVar100, &Var3.f_8[2 /*8*/])) {
								interior::_enable_interior_prop(iVar100, &Var3.f_8[2 /*8*/]);
							}
						}
					}
					if (bParam1) {
						interior::refresh_interior(iVar100);
					}
				}
				Global_34343[iParam0] = 1;
				Global_34144[iParam0] = 1;
				bVar0 = true;
				break;

			case 3:
				if (gameplay::get_distance_between_coords(Var3, entity::get_entity_coords(player::player_ped_id(), 0),
														  1) < 250f) {
					uVar98 = object::_get_des_object(Var3, 25f, &Var3.f_8[0 /*8*/]);
					if (object::_does_des_object_exist(uVar98)) {
						if (iVar1 == 0) {
							object::_set_des_object_state(uVar98, 3);
							Global_34343[iParam0] = 1;
							bVar0 = true;
						}
						else if (iVar1 == 1) {
							if (object::_get_des_object_state(uVar98) != 6 &&
								object::_get_des_object_state(uVar98) != 7 &&
								object::_get_des_object_state(uVar98) != 8) {
								object::_set_des_object_state(uVar98, 10);
								Global_34343[iParam0] = 1;
								bVar0 = true;
							}
						}
						else if (iVar1 == 2) {
							bVar0 = true;
						}
					}
				}
				break;

			case 4:
				if (iVar1 == 0) {
					entity::remove_model_swap(Var3, 50f, Var3.f_4[1], Var3.f_4[0], 0);
					gameplay::clear_bit(&Global_32495[iParam0 / 32], iParam0 % 32);
				}
				else if (iVar1 == 1) {
					entity::create_model_swap(Var3, 50f, Var3.f_4[0], Var3.f_4[1], 1);
					gameplay::set_bit(&Global_32495[iParam0 / 32], iParam0 % 32);
				}
				bVar0 = true;
				break;
			}
			if (bVar0) {
				Global_32948[iParam0] = 0;
				Global_33147[iParam0] = iVar1;
				if (!func_16()) {
					if (!Global_33744[iParam0]) {
						Global_33744[iParam0] = 1;
						Global_33943++;
					}
				}
			}
		}
	}
	return bVar0;
}

// Position - 0x2039
bool func_16() {
	if ((func_18() == -1 || func_18() == 999) && func_17() != 0) {
		return true;
	}
	return false;
}

// Position - 0x2069
int func_17() { return Global_25191; }

// Position - 0x2074
int func_18() { return Global_25190; }

// Position - 0x207F
int func_19(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		uParam0->f_4[iVar0] = 0;
		StringCopy(&uParam0->f_8[iVar0 /*8*/], "", 32);
		uParam0->f_64[iVar0] = 0;
		uParam0->f_75[iVar0] = 0;
		uParam0->f_91[iVar0] = 0;
		iVar0++;
	}
	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0;
	uParam0->f_33 = 0;
	StringCopy(&uParam0->f_34, "", 32);
	StringCopy(&uParam0->f_42, "", 32);
	StringCopy(&uParam0->f_50, "", 32);
	uParam0->f_58 = {0f, 0f, 0f};
	uParam0->f_61 = {0f, 0f, 0f};
	uParam0->f_68 = {0f, 0f, 0f};
	uParam0->f_71 = {0f, 0f, 0f};
	uParam0->f_74 = 0f;
	uParam0->f_79 = {0f, 0f, 0f};
	uParam0->f_82 = {0f, 0f, 0f};
	uParam0->f_85 = {0f, 0f, 0f};
	uParam0->f_88 = {0f, 0f, 0f};
	switch (iParam1) {
	case 3:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "TRV1_Trail_start", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "TRV1_Trail_end", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "TRV1_Trail_Finish", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-24.685f, 3032.92f, 40.331f};
		break;

	case 4:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS3_05_water_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS3_05_water_grp2", 32);
		*uParam0 = {-24.685f, 3032.92f, 40.331f};
		break;

	case 0:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "gasstation_ipl_group1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "gasstation_ipl_group2", 32);
		*uParam0 = {-93.4f, 6410.9f, 36.8f};
		break;

	case 1:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DES_Smash2_startimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_Smash2_endimap", 32);
		*uParam0 = {890.3647f, -2367.289f, 28.10582f};
		break;

	case 2:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DES_StiltHouse_imapstart", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_StiltHouse_imapend", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "des_stilthouse_rebuild", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1020.5f, 663.41f, 154.75f};
		uParam0->f_58 = {-1018.913f, 603.2904f, 105.6611f};
		uParam0->f_61 = {-1038.913f, 639.2904f, 135.6611f};
		uParam0->f_64[0] = 1;
		uParam0->f_64[1] = 0;
		break;

	case 5:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "bnkheist_apt_norm", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bnkheist_apt_dest", 32);
		break;

	case 196:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bnkheist_apt_dest_vfx", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		break;

	case 6:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "crashed_cargoplane", 32);
		break;

	case 7:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_jb700_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 8:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_entityXF_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 9:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_cheetah_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 10:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "prop_ztype_covered", 32);
		*uParam0 = {490.8999f, -1334.068f, 28.3298f};
		break;

	case 11:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "BH1_48_Killed_Michael", 32);
		break;

	case 12:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "cargoship", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "sunkcargoship", 32);
		uParam0->f_68 = {-162.8918f, -2365.769f, 0f};
		uParam0->f_71 = {190.75f, 31.25f, 21f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		break;

	case 13:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ship_occ_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ship_occ_grp2", 32);
		break;

	case 14:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "smboat", 32);
		break;

	case 15:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "gasparticle_grp2", 32);
		*uParam0 = {-95.2f, 6411.3f, 31.5f};
		break;

	case 16:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS1_02_cf_offmission", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission1", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 17:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission2", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 18:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission3", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 19:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS1_02_cf_onmission4", 32);
		*uParam0 = {-146.3837f, 6161.5f, 30.2062f};
		break;

	case 20:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "jetstealtunnel", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {801.7f, -1810.8f, 23.3f};
		break;

	case 21:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Jetsteal_ipl_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Jetsteal_ipl_grp2", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {787.3967f, -1808.858f, 29.8532f};
		uParam0->f_58 = {814f, -1750f, 20f};
		uParam0->f_61 = {790f, -1899f, 35f};
		uParam0->f_64[0] = 1;
		uParam0->f_64[1] = 0;
		uParam0->f_64[2] = 0;
		break;

	case 22:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "BH1_47_JoshHse_UnBurnt", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "BH1_47_JoshHse_Burnt", 32);
		break;

	case 23:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bh1_47_joshhse_firevfx", 32);
		break;

	case 24:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_30_Keep_Closed", 32);
		break;

	case 25:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "triathlon2_VBprops", 32);
		break;

	case 26:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_REQUEST", 32);
		*uParam0 = {163.4f, -745.7f, 251f};
		break;

	case 27:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FBI_colPLUG", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 28:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FBI_repair", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 29:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = joaat("dt1_05_build1_h");
		uParam0->f_4[1] = joaat("dt1_05_build1_damage");
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 30:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = -112041596;
		uParam0->f_4[1] = joaat("dt1_05_build1_damage_lod");
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 31:
		uParam0->f_3 = 4;
		uParam0->f_4[0] = -186270611;
		uParam0->f_4[1] = joaat("dt1_05_damage_slod");
		*uParam0 = {178.534f, -668.835f, 37.2113f};
		break;

	case 32:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FIB_heist_lights", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 33:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FIB_heist_dmg", 32);
		*uParam0 = {136.004f, -749.287f, 153.302f};
		break;

	case 34:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_rubble", 32);
		*uParam0 = {74.29f, -736.05f, 46.76f};
		break;

	case 35:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "FIBlobbyfake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FIBlobby", 32);
		*uParam0 = {105.4557f, -745.4835f, 44.7548f};
		break;

	case 36:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_05_HC_REMOVE", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_HC_REQ", 32);
		*uParam0 = {169f, -670.3f, 41.9f};
		break;

	case 37:
		uParam0->f_3 = 1;
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		uParam0->f_79 = {16.9757f, 3614.307f, 30.0677f};
		uParam0->f_82 = {145.2451f, 3748.912f, 49.6958f};
		uParam0->f_85 = {16.9757f, 3614.307f, 30.0677f};
		uParam0->f_88 = {145.2451f, 3748.912f, 49.6958f};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		break;

	case 38:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkA_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkA_grp2", 32);
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		break;

	case 39:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerA_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {50.2f, 3743.9f, 40.9f};
		break;

	case 40:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkB_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkB_grp2", 32);
		*uParam0 = {106.7f, 3732.1f, 40.8f};
		break;

	case 41:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerB_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {106.7f, 3732.1f, 40.8f};
		break;

	case 42:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkC_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkC_grp2", 32);
		*uParam0 = {72.7f, 3695.4f, 42f};
		break;

	case 43:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerC_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {72.7f, 3695.4f, 42f};
		break;

	case 44:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkD_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkD_grp2", 32);
		*uParam0 = {43.8f, 3699.7f, 41.3f};
		break;

	case 45:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerD_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {43.8f, 3699.7f, 41.3f};
		break;

	case 46:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "trailerparkE_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "trailerparkE_grp2", 32);
		*uParam0 = {28.5f, 3668f, 40.4f};
		break;

	case 47:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_trailerE_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {28.5f, 3668f, 40.4f};
		break;

	case 48:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_34, "des_methtrailer", 32);
		StringCopy(&uParam0->f_8[0 /*8*/], "methtrailer_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "methtrailer_grp2", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "methtrailer_grp3", 32);
		uParam0->f_33 = 1;
		*uParam0 = {29.4838f, 3735.593f, 38.688f};
		uParam0->f_68 = {31.134f, 3738.783f, 39.062f};
		uParam0->f_71 = {13.6f, 20f, 8.9f};
		uParam0->f_74 = 48f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 1;
		break;

	case 49:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "occl_meth_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {29.4838f, 3735.593f, 38.688f};
		break;

	case 50:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhs_startimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhs_endimap", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2450.595f, 4959.929f, 44.2575f};
		uParam0->f_79 = {2383.756f, 4929.988f, 39.52461f};
		uParam0->f_82 = {2505.756f, 5023.988f, 67.52461f};
		break;

	case 55:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhs_start_occl", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhs_end_occl", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {2450.595f, 4959.929f, 44.2575f};
		break;

	case 51:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farm", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "farm", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "farm_burnt", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2444.8f, 4976.4f, 50.5f};
		break;

	case 52:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farm_props", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "farm_burnt_props", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 53:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "des_farmhouse", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "des_farmhouse", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 54:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "farmint_cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "farmint", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {2447.9f, 4973.4f, 47.7f};
		break;

	case 56:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "tankerexp_grp0", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp3", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 57:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp1", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 58:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "tankerexp_grp2", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 59:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DES_tankerexp", 32);
		*uParam0 = {1676.415f, -1626.37f, 111.4848f};
		break;

	case 60:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "dockcrane1", 32);
		*uParam0 = {889.3f, -2910.9f, 40f};
		break;

	case 61:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CanyonRvrShallow", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CanyonRvrDeep", 32);
		*uParam0 = {-1600.619f, 4443.457f, 0.725f};
		break;

	case 62:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Garage_door_locked", 32);
		*uParam0 = {966.1f, -114.8f, 75.2f};
		break;

	case 63:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ch1_02_closed", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ch1_02_open", 32);
		*uParam0 = {-3086.428f, 339.2523f, 6.3717f};
		break;

	case 64:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ferris_finale_Anim", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-1675.178f, -1143.605f, 12.0175f};
		break;

	case 65:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "railing_start", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "railing_end", 32);
		*uParam0 = {-532.1309f, 4526.187f, 88.7955f};
		break;

	case 66:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "canyonriver01", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "canyonriver01_traincrash", 32);
		*uParam0 = {-532.1309f, 4526.187f, 88.7955f};
		break;

	case 67:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_05_WOFFM", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_05_FIB2_Mission", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "DT1_05_WOFFM", 32);
		*uParam0 = {131.29f, -631.22f, 261.85f};
		break;

	case 68:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "coronertrash", 32);
		*uParam0 = {233.9f, -1355f, 30.3f};
		break;

	case 69:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Coroner_Int_off", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Coroner_Int_on", 32);
		*uParam0 = {234.4f, -1355.6f, 40.5f};
		break;

	case 70:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "id2_14_pre_no_int", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 71:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_during1", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "id2_14_during2", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 72:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_on_fire", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "id2_14_post_no_int", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 73:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "id2_14_during_door", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 74:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "burnt_switch_off", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {716.84f, -962.05f, 31.59f};
		break;

	case 75:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "RC12B_Default", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "RC12B_Destroyed", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "RC12B_Fixed", 32);
		uParam0->f_33 = 0;
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 76:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "RC12B_HospitalInterior", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 105:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SM_15_BldGRAF1", 32);
		*uParam0 = {330.4596f, -584.8196f, 42.3174f};
		break;

	case 106:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CH3_RD2_BishopsChickenGraffiti", 32);
		*uParam0 = {1861.28f, 2402.11f, 58.53f};
		break;

	case 107:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FruitBB", 32);
		*uParam0 = {-1327.46f, -274.82f, 54.25f};
		break;

	case 108:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS5_04_MazeBillboardGraffiti", 32);
		*uParam0 = {2697.32f, 3162.18f, 58.1f};
		break;

	case 109:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS5_Roads_RonOilGraffiti", 32);
		*uParam0 = {2119.12f, 3058.21f, 53.25f};
		break;

	case 110:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ap1_03_bbrd_dcl", 32);
		*uParam0 = {-804.25f, -2276.88f, 23.59f};
		break;

	case 111:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "HW1_02_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "HW1_02_NewBill", 32);
		*uParam0 = {296.5f, 173.3f, 100.4f};
		break;

	case 112:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "HW1_Emissive_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "HW1_Emissive_NewBill", 32);
		*uParam0 = {296.5f, 173.3f, 100.4f};
		break;

	case 77:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {480.9554f, -1321.21f, 28.2037f};
		uParam0->f_85 = {508.3f, -1299.3f, 39.4f};
		uParam0->f_88 = {459.9f, -1363.2f, 21.4f};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		uParam0->f_91[2] = 0;
		break;

	case 78:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "TrevorsTrailer", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "TrevorsTrailerTrash", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "TrevorsTrailerTidy", 32);
		*uParam0 = {1973f, 3815f, 34f};
		uParam0->f_33 = 0;
		break;

	case 79:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "scafstartimap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "scafendimap", 32);
		*uParam0 = {-1088.6f, -1650.6f, 6.4f};
		break;

	case 80:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "chop_props", 32);
		*uParam0 = {-13.83f, -1455.45f, 31.81f};
		break;

	case 113:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "AP1_04_TriAf01", 32);
		*uParam0 = {-1277.629f, -2030.913f, 1.2823f};
		break;

	case 114:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS2_06_TriAf02", 32);
		*uParam0 = {2384.969f, 4277.583f, 30.379f};
		break;

	case 115:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS4_04_TriAf03", 32);
		*uParam0 = {1577.881f, 3836.107f, 30.7717f};
		break;

	case 87:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_21_prop_lift_on", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-180.5771f, -1016.928f, 28.2893f};
		break;

	case 88:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "jewel2fake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "post_hiest_unload", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "bh1_16_refurb", 32);
		*uParam0 = {-630.4205f, -236.7843f, 37.057f};
		uParam0->f_79 = {-623.6868f - 11f, -231.935f - 11f, 40.30703f - 3.25f};
		uParam0->f_82 = {-623.6868f + 11f, -231.935f + 11f, 40.30703f + 3.25f};
		break;

	case 89:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "bh1_16_doors_shut", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "refit_unload", 32);
		*uParam0 = {-583.1606f, -282.3967f, 35.394f};
		break;

	case 90:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "v_tunnel_hole_swap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "v_tunnel_hole", 32);
		*uParam0 = {-14.651f, -604.3639f, 25.1823f};
		break;

	case 91:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "cs5_4_trains", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2773.61f, 2835.327f, 35.1903f};
		break;

	case 94:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "airfield", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {1743.682f, 3286.251f, 40.0875f};
		break;

	case 95:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "REMOVE_ALL_STATES", 32);
		uParam0->f_33 = 1;
		*uParam0 = {1222.9f, 1877.9f, 79.9f};
		uParam0->f_58 = {1206.8f, 1803f, 43.9f};
		uParam0->f_61 = {1329f, 2060.4f, 143.9f};
		uParam0->f_64[0] = 0;
		uParam0->f_64[1] = 1;
		uParam0->f_64[2] = 0;
		break;

	case 104:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_01_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SC1_01_NewBill", 32);
		*uParam0 = {-351f, -1324f, 44.02f};
		break;

	case 103:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_17_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "DT1_17_NewBill", 32);
		*uParam0 = {391.81f, -962.71f, 41.97f};
		break;

	case 102:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SC1_14_OldBill", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SC1_14_NewBill", 32);
		*uParam0 = {424.2f, -1944.31f, 33.09f};
		break;

	case 92:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ld_rail_01_track", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2626.374f, 2949.869f, 39.1409f};
		break;

	case 93:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "ld_rail_02_track", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {2626.374f, 2949.869f, 39.1409f};
		break;

	case 118:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_M_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_M_moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-811.2679f, 179.3344f, 75.7408f};
		break;

	case 116:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_D_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_D_Moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-802.0311f, 172.9131f, 75.7408f};
		break;

	case 117:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_S_items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_S_items_swap", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 119:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_L_Items", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_L_Moved", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 120:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_M_items_swap", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-808.033f, 172.1309f, 75.7406f};
		break;

	case 122:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_FameShame", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-802.0311f, 172.9131f, 75.7408f};
		break;

	case 121:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_JewelHeist", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 123:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Michael_premier", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 124:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_plane_ticket", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 170:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "burgershot_yoga", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-813.3f, 177.5f, 75.76f};
		break;

	case 171:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_Scuba", 32);
		StringCopy(&uParam0->f_42, "V_Michael_Garage", 32);
		*uParam0 = {-810.5301f, 187.7868f, 71.4786f};
		break;

	case 125:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_Michael_bed_tidy", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_Michael_bed_Messy", 32);
		StringCopy(&uParam0->f_42, "V_Michael", 32);
		*uParam0 = {-811.2679f, 179.3344f, 75.7408f};
		break;

	case 164:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Jewel_Gasmasks", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 165:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_53_Agency _Overalls", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 166:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_53_Agency_Blueprint", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 167:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_KitBag", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 168:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_Body_Armour", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 169:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_35_Fireman", 32);
		StringCopy(&uParam0->f_42, "V_Sweat", 32);
		*uParam0 = {707.2563f, -965.147f, 29.4179f};
		break;

	case 126:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 127:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 128:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Trevor_Helmet2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 129:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 130:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 131:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_24_Trevor_Briefcase2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 132:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay1", 32);
		StringCopy(&uParam0->f_42, "V_Trailer", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 133:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay3", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTRASH", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 134:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_26_Michael_Stay2", 32);
		StringCopy(&uParam0->f_42, "V_TrailerTidy", 32);
		*uParam0 = {1973.805f, 3818.555f, 32.4363f};
		break;

	case 179:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "shutter_open", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "shutter_closed", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-30.8793f, -1088.336f, 25.4221f};
		uParam0->f_68 = {-29.3f, -1086.35f, 25.57f};
		uParam0->f_71 = {5.5f, 3f, 2f};
		uParam0->f_74 = -10f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		break;

	case 174:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "csr_beforeMission", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "csr_afterMissionA", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "csr_afterMissionB", 32);
		StringCopy(&uParam0->f_50, "csr_inMission", 32);
		uParam0->f_33 = 0;
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 175:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-49.21f, -1090.28f, 25.42f};
		uParam0->f_68 = {-49.21f, -1090.28f, 25.42f};
		uParam0->f_71 = {2.5f, 3f, 3f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 176:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-49.28f, -1092.66f, 25.42f};
		uParam0->f_68 = {-49.28f, -1092.66f, 25.42f};
		uParam0->f_71 = {3f, 1f, 3f};
		uParam0->f_74 = 0f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 177:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_carshowroom", 32);
		*uParam0 = {-53.07f, -1096.73f, 25.5f};
		uParam0->f_68 = {-53.07f, -1096.73f, 25.5f};
		uParam0->f_71 = {1f, 3f, 2f};
		uParam0->f_74 = -45f;
		uParam0->f_75[0] = 0;
		uParam0->f_75[1] = 1;
		uParam0->f_75[2] = 0;
		break;

	case 178:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "carshowroom_broken", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "carshowroom_boarded", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 173:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "shr_int", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "fakeint", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-59.7936f, -1098.784f, 27.2612f};
		break;

	case 180:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_03_Shutter", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "", 32);
		*uParam0 = {23.9346f, -669.7552f, 30.8853f};
		break;

	case 181:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "Hospitaldoorsanim", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "Hospitaldoorsfixed", 32);
		StringCopy(&uParam0->f_42, "v_hospital", 32);
		uParam0->f_33 = 0;
		*uParam0 = {300.9423f, -586.1784f, 42.2919f};
		break;

	case 135:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_clean_apt", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_A", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 136:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_B", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 137:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_mess_C", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 138:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_sextoys_a", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 139:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_wade_shit", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 140:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_wade_sofa_A", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 141:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "layer_debra_pic", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 142:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_torture", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 143:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_sofa_A", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_sofa_B", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 144:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "layer_whiskey", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 145:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "swap_mrJam_A", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_mrJam_B", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 146:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "swap_mrJam_C", 32);
		StringCopy(&uParam0->f_42, "v_trevors", 32);
		*uParam0 = {-1157.129f, -1523.028f, 9.6327f};
		break;

	case 147:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "vb_30_emissive", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "vb_30_murder", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1150.039f, -1521.761f, 9.6331f};
		break;

	case 148:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "vb_30_crimetape", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-1150.039f, -1521.761f, 9.6331f};
		break;

	case 149:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "sheriff_cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {1856.029f, 3682.998f, 33.2675f};
		break;

	case 150:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "CS1_16_Sheriff_Cap", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-440.5073f, 6018.766f, 30.49f};
		break;

	case 151:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ufo", 32);
		uParam0->f_33 = 0;
		*uParam0 = {487.31f, 5588.386f, 793.0532f};
		break;

	case 152:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "ufo_eye", 32);
		uParam0->f_33 = 0;
		*uParam0 = {487.31f, 5588.386f, 793.0532f};
		break;

	case 153:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "V_57_FranklinStuff", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_Franklin_LEFT", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 154:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_GangBandana", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 155:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_57_Safari", 32);
		StringCopy(&uParam0->f_42, "v_franklins", 32);
		*uParam0 = {-13.9623f, -1440.614f, 30.1015f};
		break;

	case 172:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "V_19_Trevor_Mess", 32);
		StringCopy(&uParam0->f_42, "v_strip3", 32);
		*uParam0 = {96.4811f, -1291.294f, 28.2688f};
		break;

	case 182:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {139.5795f, -3092.962f, 8.64631f};
		uParam0->f_79 = {Vector(8.64631f, -3092.962f, 139.5795f) - Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_82 = {Vector(8.64631f, -3092.962f, 139.5795f) + Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_85 = {Vector(8.64631f, -3092.962f, 139.5795f) - Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_88 = {Vector(8.64631f, -3092.962f, 139.5795f) + Vector(4.1875f, 24f, 33.3125f)};
		uParam0->f_91[0] = 0;
		uParam0->f_91[1] = 1;
		uParam0->f_91[2] = 1;
		break;

	case 183:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {203.7784f, -3131.767f, 7.041344f};
		uParam0->f_79 = {Vector(7.041344f, -3131.767f, 203.7784f) - Vector(2.5625f, 2.75f, 4.875f)};
		uParam0->f_82 = {Vector(7.041344f, -3131.767f, 203.7784f) + Vector(2.5625f, 2.75f, 4.875f)};
		break;

	case 184:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {144.7706f, -2982.659f, 7.952507f};
		uParam0->f_79 = {Vector(7.952507f, -2982.659f, 144.7706f) - Vector(3.125f, 3.4375f, 5.3125f)};
		uParam0->f_82 = {Vector(7.952507f, -2982.659f, 144.7706f) + Vector(3.125f, 3.4375f, 5.3125f)};
		break;

	case 185:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1154.965f, -1520.983f, 9.132731f};
		uParam0->f_79 = {-1154.965f, -1520.983f, 9.132731f};
		uParam0->f_82 = {-1158.965f, -1524.983f, 11.63273f};
		break;

	case 187:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1052.204f, 371.9537f, 67.914f};
		uParam0->f_79 = {-1052.204f, 371.9537f, 67.914f};
		uParam0->f_82 = {-1048.064f, 368.0221f, 70.9128f};
		break;

	case 186:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {1954.984f, 3792.991f, 30.3086f};
		uParam0->f_79 = {1954.984f, 3792.991f, 30.3086f};
		uParam0->f_82 = {1983.45f, 3830.78f, 36.2726f};
		break;

	case 188:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 1;
		*uParam0 = {-1122.202f, 48.5724f, 51.4652f};
		uParam0->f_79 = {-1122.202f, 48.5724f, 51.4652f};
		uParam0->f_82 = {-1076.233f, 92.1041f, 60.0617f};
		break;

	case 81:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "KorizTempWalls", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-2199.138f, 223.4648f, 181.1118f};
		break;

	case 82:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "mic3_chopper_debris", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {-2242.785f, 263.4779f, 173.6154f};
		break;

	case 83:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "chemgrill_grp1", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {3832.9f, 3665.5f, -23.4f};
		break;

	case 84:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Plane_crash_trench", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		uParam0->f_33 = 0;
		*uParam0 = {2814.7f, 4758.5f, 47.9f};
		break;

	case 85:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "golfflags", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-1096.505f, 4.5754f, 49.8103f};
		break;

	case 86:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "yogagame", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {-781.6566f, 186.8937f, 71.8352f};
		break;

	case 189:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "Carwash_with_spinners", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "Carwash_without_spinners", 32);
		uParam0->f_33 = 0;
		*uParam0 = {55.7f, -1391.3f, 30.5f};
		break;

	case 190:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "KT_CarWash", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "KT_CarWash_NoBrush", 32);
		uParam0->f_33 = 0;
		*uParam0 = {700.091f, -933.641f, 20.308f};
		break;

	case 191:
		uParam0->f_3 = 1;
		*uParam0 = {-1096.381f, -836.17f, 36.6755f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 192:
		uParam0->f_3 = 1;
		*uParam0 = {449.6558f, -980.1375f, 42.6918f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 193:
		uParam0->f_3 = 1;
		*uParam0 = {363.0175f, -1598.079f, 35.9502f};
		uParam0->f_85 = {*uParam0 - Vector(25f, 25f, 15f)};
		uParam0->f_88 = {*uParam0 + Vector(25f, 25f, 15f)};
		uParam0->f_91[0] = 1;
		uParam0->f_91[1] = 0;
		break;

	case 194:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "CS3_07_MPGates", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "", 32);
		*uParam0 = {-1601.424f, 2808.213f, 16.2598f};
		break;

	case 97:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "DT1_03_Gr_Closed", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "", 32);
		*uParam0 = {23.7318f, -647.2123f, 37.9549f};
		break;

	case 98:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "FINBANK", 32);
		*uParam0 = {12.9689f, -648.4698f, 9.7693f};
		break;

	case 99:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "PAPER1_RCM_ALT", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "PAPER1_RCM", 32);
		*uParam0 = {-1459.127f, 486.1281f, 115.2016f};
		break;

	case 100:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "SP1_10_fake_interior", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "SP1_10_real_interior", 32);
		*uParam0 = {-248.4916f, -2010.509f, 34.5743f};
		break;

	case 101:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "facelobbyfake", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "facelobby", 32);
		*uParam0 = {-1081.347f, -263.1502f, 38.7152f};
		break;

	case 195:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "atriumglstatic", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "atriumglmission", 32);
		StringCopy(&uParam0->f_8[2 /*8*/], "atriumglcut", 32);
		*uParam0 = {136.1795f, -750.701f, 262.0516f};
		break;

	case 197:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "racetrack01", 32);
		*uParam0 = {2096f, 3168.7f, 42.9f};
		break;
	}
	switch (iParam1) {
	case 156:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "showhome_only", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 157:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "franklin_unpacking", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 158:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "franklin_settled", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 163:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_tshirt", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 159:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "bong_and_wine", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 161:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_flyer", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 162:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "progress_tux", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 160:
		uParam0->f_3 = 2;
		StringCopy(&uParam0->f_8[0 /*8*/], "locked", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "unlocked", 32);
		StringCopy(&uParam0->f_42, "v_franklinshouse", 32);
		*uParam0 = {7.0256f, 537.3075f, 175.0281f};
		break;

	case 96:
		uParam0->f_3 = 1;
		StringCopy(&uParam0->f_8[0 /*8*/], "", 32);
		StringCopy(&uParam0->f_8[1 /*8*/], "chophillskennel", 32);
		*uParam0 = {19.0568f, 536.4818f, 169.6277f};
		break;
	}
	return 1;
}

// Position - 0x581C
int func_20(var *uParam0) {
	return graphics::has_scaleform_movie_loaded(*uParam0) & audio::request_script_audio_bank("HUD_321_GO", 0, -1);
}

// Position - 0x583A
void func_21(var *uParam0) {
	*uParam0 = unk_0x67D02A194A2FC2BD("COUNTDOWN");
	audio::request_script_audio_bank("HUD_321_GO", 0, -1);
}

// Position - 0x5858
void func_22() {
	if (!func_8(iLocal_2129)) {
		if (entity::does_entity_exist(player::get_players_last_vehicle())) {
			iLocal_2129 = player::get_players_last_vehicle();
			entity::set_entity_as_mission_entity(iLocal_2129, 1, 0);
		}
		else {
			streaming::request_model(joaat("gauntlet"));
			while (!streaming::has_model_loaded(joaat("gauntlet"))) {
				system::wait(0);
			}
			iLocal_2129 =
				vehicle::create_vehicle(joaat("gauntlet"), Local_54.f_26[8 /*3*/] + vLocal_181, Local_54.f_54[8], 1, 1);
			streaming::set_model_as_no_longer_needed(joaat("gauntlet"));
			ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
		}
	}
	else {
		func_23(iLocal_2129, Local_54.f_26[8 /*3*/] + vLocal_181, Local_54.f_54[8], 0, 1);
		ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
	}
	func_23(iLocal_2129, Local_54.f_26[8 /*3*/] + vLocal_181, Local_54.f_54[8], 0, 1);
	iLocal_1975 = 0;
}

// Position - 0x5936
int func_23(int iParam0, vector3 vParam1, float fParam4, int iParam5, int iParam6) {
	bool bVar0;
	float fVar1;

	bVar0 = false;
	if (func_8(iParam0)) {
		if (iParam5 == 1) {
			fVar1 = 0f;
			bVar0 = gameplay::get_ground_z_for_3d_coord(vParam1, &fVar1, 0);
			if (bVar0) {
				vParam1.z = fVar1;
			}
		}
		entity::set_entity_coords(iParam0, vParam1, 1, 0, 0, iParam6);
		entity::set_entity_heading(iParam0, fParam4);
		if (iParam5) {
			return bVar0;
		}
		return 1;
	}
	return 0;
}

// Position - 0x5991
void func_24() {
	vector3 vVar0;

	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			vVar0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
			entity::set_entity_coords(player::player_ped_id(), vVar0.x, vVar0.y, vVar0.z + 1f, 1, 0, 0, 1);
		}
	}
}

// Position - 0x59D6
bool func_25(var *uParam0, int *iParam1, char *sParam2, char *sParam3, var *uParam4, int iParam5, int iParam6,
			 int iParam7, float fParam8, int iParam9) {
	switch (*iParam1) {
	case 0:
		if (!cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
			cam::do_screen_fade_out(2500);
			unk1::_0xEB2D525B57F42B40();
		}
		if (iParam9) {
			script::set_no_loading_screen(1);
		}
		gameplay::set_time_scale(0.2f);
		if (func_51(iParam5, 4)) {
			if (audio::request_script_audio_bank("generic_failed", 0, -1)) {
				*iParam1 = 1;
			}
		}
		else {
			*iParam1 = 1;
		}
		break;

	case 1:
		graphics::_push_scaleform_movie_function(*uParam0, "SHOW_CENTERED_MP_MESSAGE_LARGE");
		graphics::begin_text_command_scaleform_string("STRING");
		ui::_set_notification_color_next(6);
		ui::add_text_component_substring_text_label(sParam2);
		graphics::end_text_command_scaleform_string();
		func_50(sParam3);
		graphics::_push_scaleform_movie_function_parameter_int(100);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function();
		if (func_51(iParam5, 32)) {
			if (!iParam1->f_136) {
				graphics::_push_scaleform_movie_function(*uParam0, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(iParam1->f_134);
				graphics::_pop_scaleform_movie_function_void();
				iParam1->f_136 = 1;
			}
		}
		if (!func_51(iParam5, 1)) {
			controls::disable_all_control_actions(0);
		}
		func_49(&iParam1->f_10, 0, 1, 1, 1);
		func_48(&iParam1->f_10, "IB_RETRY", 2, 201, 1, 1, 0);
		func_48(&iParam1->f_10, "FE_HLP16", 2, 202, 1, 1, 0);
		if (func_51(iParam5, 4)) {
			audio::play_sound_frontend(-1, "ScreenFlash", "MissionFailedSounds", 1);
		}
		if (func_51(iParam5, 8)) {
			switch (func_42()) {
			case 0: graphics::_start_screen_effect("MinigameEndMichael", 500, 0); break;

			case 1: graphics::_start_screen_effect("MinigameEndFranklin", 500, 0); break;

			case 2: graphics::_start_screen_effect("MinigameEndTrevor", 500, 0); break;
			}
		}
		if (!func_41(&iParam1->f_1)) {
			func_40(&iParam1->f_1);
		}
		if (func_51(iParam5, 2)) {
			if (!func_41(&iParam1->f_4)) {
				func_40(&iParam1->f_4);
			}
		}
		*iParam1 = 2;
		break;

	case 2:
		ui::hide_loading_on_fade_this_frame();
		if (func_51(iParam5, 32)) {
			if (!iParam1->f_136) {
				graphics::_push_scaleform_movie_function(*uParam0, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(iParam1->f_134);
				graphics::_pop_scaleform_movie_function_void();
				iParam1->f_136 = 1;
			}
		}
		graphics::_set_2d_layer(iParam6);
		func_38(uParam0, 0, 0);
		if (!func_51(iParam5, 16) && (func_36(&iParam1->f_1) >= iParam1->f_135 || cam::is_screen_faded_out())) {
			func_30(&iParam1->f_10, 1128792064, iParam6, iParam7, 1, 1065353216);
			ui::_show_cursor_this_frame();
			if (controls::is_control_just_released(2, 201)) {
				iParam1->f_138 = 1;
				audio::play_sound_frontend(-1, "YES", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				if (!func_51(iParam5, 1)) {
					controls::enable_all_control_actions(0);
				}
				func_29(&iParam1->f_10);
				*iParam1 = 3;
				return false;
			}
			else if (controls::is_control_just_released(2, 202)) {
				iParam1->f_138 = 0;
				audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				if (!func_51(iParam5, 1)) {
					controls::enable_all_control_actions(0);
				}
				func_29(&iParam1->f_10);
				*iParam1 = 3;
				return false;
			}
		}
		if (func_51(iParam5, 2)) {
			if (func_36(&iParam1->f_4) >= fParam8) {
				iParam1->f_138 = 0;
				audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				if (!func_51(iParam5, 1)) {
					controls::enable_all_control_actions(0);
				}
				func_29(&iParam1->f_10);
				*iParam1 = 3;
				return false;
			}
		}
		break;

	case 3:
		func_38(uParam0, 0, 0);
		gameplay::set_time_scale(1f);
		if (iParam1->f_138 || !(gameplay::are_strings_equal("stunt_plane_races", script::get_this_script_name()) ||
								gameplay::are_strings_equal("pilot_school", script::get_this_script_name()) ||
								gameplay::are_strings_equal("bj", script::get_this_script_name()) &&
									ped::is_ped_injured(player::player_ped_id()))) {
			cam::do_screen_fade_in(2500);
		}
		if (func_51(iParam5, 64) && iParam1->f_138) {
			cam::do_screen_fade_out(500);
		}
		func_26(&iParam1->f_4);
		if (iParam9) {
			script::set_no_loading_screen(0);
		}
		*iParam1 = 4;
		break;

	case 4:
		if (func_36(&iParam1->f_4) <= 0.1f) {
			func_38(uParam0, 0, 0);
		}
		else {
			*uParam4 = iParam1->f_138;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x5DB3
void func_26(var *uParam0) { func_27(uParam0, 0f); }

// Position - 0x5DC2
void func_27(int *iParam0, float fParam1) {
	uParam0->f_1 = func_28(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x5DF0
float func_28(int iParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (iParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x5E48
void func_29(int *iParam0) {
	if (*uParam0 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(uParam0);
		*iParam0 = 0;
	}
	iParam0->f_1 = 0;
	iParam0->f_123 = 0;
}

// Position - 0x5E6B
void func_30(var *uParam0, float fParam1, int iParam2, int iParam3, int iParam4, float fParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char *sVar3;
	bool bVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	float fVar8;

	if (cam::is_screen_fading_out() || cam::is_screen_fading_in() || cam::is_screen_faded_out() ||
		gameplay::is_frontend_fading()) {
		if (!iParam3) {
			return;
		}
	}
	if (!func_35(uParam0)) {
		return;
	}
	ui::hide_loading_on_fade_this_frame();
	graphics::_set_2d_layer(iParam2);
	if (!func_51(uParam0->f_1, 256) || func_51(uParam0->f_1, 8192) && controls::_0x6CD79468A1E595C6(2)) {
		graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
		graphics::_push_scaleform_movie_function_parameter_float(fParam1);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_MAX_WIDTH");
		graphics::_push_scaleform_movie_function_parameter_float(fParam5);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(*uParam0, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(func_51(uParam0->f_1, 4096));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar5 = 0;
		iVar6 = 0;
		while (iVar6 < uParam0->f_123) {
			switch (uParam0->f_2[iVar6 /*15*/].f_2) {
			case 0: bVar4 = true; break;

			case 1: bVar4 = controls::_is_input_disabled(2); break;

			case 2: bVar4 = !controls::_is_input_disabled(2); break;

			default: bVar4 = false; break;
			}
			if (bVar4) {
				if (graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT")) {
					graphics::_push_scaleform_movie_function_parameter_int(iVar5);
					iVar5++;
					iVar7 = 0;
					while (iVar7 < uParam0->f_2[iVar6 /*15*/].f_14) {
						iVar0 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/];
						iVar1 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/].f_1;
						iVar2 = gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_13, iVar7);
						if (!gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_12, iVar7)) {
							sVar3 = controls::get_control_instructional_button(iVar0, iVar1, iVar2);
						}
						else {
							sVar3 = controls::_0x80C2FD58D720C801(iVar0, iVar1, iVar2);
						}
						if (!gameplay::is_string_null_or_empty(sVar3)) {
							func_34(sVar3);
						}
						iVar7++;
					}
					if (!gameplay::is_string_null_or_empty(uParam0->f_2[iVar6 /*15*/])) {
						func_50(uParam0->f_2[iVar6 /*15*/]);
					}
					if (gameplay::is_pc_version()) {
						if (func_51(uParam0->f_1, 4096)) {
							if (uParam0->f_2[iVar6 /*15*/].f_1) {
								graphics::_push_scaleform_movie_function_parameter_bool(1);
								graphics::_push_scaleform_movie_function_parameter_int(
									uParam0->f_2[iVar6 /*15*/].f_3[0 /*2*/].f_1);
							}
							else {
								graphics::_push_scaleform_movie_function_parameter_bool(0);
								graphics::_push_scaleform_movie_function_parameter_int(-1);
							}
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar6++;
		}
		fVar8 = func_33(iParam4, func_33(func_51(uParam0->f_1, 32), 1f, 0f), -1f);
		graphics::_push_scaleform_movie_function(*uParam0, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_float(fVar8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(80f);
		graphics::_pop_scaleform_movie_function_void();
		func_32(&uParam0->f_1, 256);
		func_31(&uParam0->f_1, 128);
	}
	graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
}

// Position - 0x612B
void func_31(int *iParam0, int iParam1) { *iParam0 -= (*iParam0 & iParam1); }

// Position - 0x6140
void func_32(var *uParam0, int iParam1) { *uParam0 |= iParam1; }

// Position - 0x6151
float func_33(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x6168
void func_34(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x6176
int func_35(var *uParam0) {
	if (*uParam0 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			func_32(&uParam0->f_1, 1);
			return 1;
		}
	}
	return 0;
}

// Position - 0x619D
float func_36(var *uParam0) {
	if (func_41(uParam0)) {
		if (func_37(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_28(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x61DC
bool func_37(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x61EC
int func_38(var *uParam0, int iParam1, int iParam2) {
	if (!func_41(&uParam0->f_2)) {
		func_26(&uParam0->f_2);
	}
	ui::hide_hud_component_this_frame(14);
	if (!iParam2) {
		graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
	}
	else if (iParam2) {
		graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
	}
	if (iParam1) {
		if (controls::is_control_pressed(2, 201)) {
			return 0;
		}
	}
	if (uParam0->f_1 == -1) {
		return 1;
	}
	if (func_36(&uParam0->f_2) * 1000f > system::to_float(uParam0->f_1)) {
		func_39(&uParam0->f_2);
		return 0;
	}
	return 1;
}

// Position - 0x627E
void func_39(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x6294
void func_40(var *uParam0) {
	if (!func_41(uParam0)) {
		func_26(uParam0);
	}
}

// Position - 0x62AC
bool func_41(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x62BC
int func_42() {
	func_43();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x62D5
void func_43() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_47(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_46(player::player_ped_id());
			if (func_45(iVar0) && (!func_44(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_45(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x63D2
bool func_44(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x63E0
bool func_45(int iParam0) { return iParam0 < 3; }

// Position - 0x63EC
int func_46(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_47(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x6429
int func_47(int iParam0) {
	if (func_45(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x6453
int func_48(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;

	if (*uParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	if (iParam5 == 1) {
		iVar0 = 1;
	}
	iVar1 = uParam0->f_123;
	if (iVar1 < 8) {
		uParam0->f_2[iVar1 /*15*/] = sParam1;
		uParam0->f_2[iVar1 /*15*/].f_1 = iVar0;
		uParam0->f_2[iVar1 /*15*/].f_2 = iParam6;
		uParam0->f_2[iVar1 /*15*/].f_12 = 0;
		uParam0->f_2[iVar1 /*15*/].f_13 = 0;
		uParam0->f_2[iVar1 /*15*/].f_14 = 0;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/] = iParam2;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
		if (iParam4 == 1) {
			gameplay::set_bit(&uParam0->f_2[iVar1 /*15*/].f_13, 0);
		}
		uParam0->f_2[iVar1 /*15*/].f_14++;
		uParam0->f_123++;
		return 1;
	}
	return 0;
}

// Position - 0x651C
void func_49(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (*uParam0 == 0) {
		*uParam0 = graphics::request_scaleform_movie_instance("instructional_buttons");
	}
	uParam0->f_1 = 0;
	uParam0->f_123 = 0;
	if (iParam1) {
		func_32(&uParam0->f_1, 32);
	}
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		func_32(&uParam0->f_1, 1);
		if (iParam2) {
			graphics::set_scaleform_movie_to_use_system_time(*uParam0, 1);
		}
	}
	if (gameplay::is_pc_version()) {
		if (iParam3) {
			func_32(&uParam0->f_1, 4096);
		}
	}
	if (iParam4) {
		func_32(&uParam0->f_1, 8192);
	}
}

// Position - 0x6596
void func_50(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x65A8
bool func_51(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x65B7
void func_52() {
	if (Global_14443.f_1 != 1) {
		if (func_56(0)) {
			func_53(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x65DF
void func_53(int iParam0) {
	if (Global_14604) {
		func_55(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_54()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x664F
int func_54() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x6676
void func_55(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_56(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x66EA
bool func_56(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x6744
void func_57() {
	int iVar0;

	switch (iLocal_174) {
	case 0:
		func_144(2, sLocal_138, 1, 1, 0, 1);
		audio::start_audio_scene("STREET_RACE_OUTRO");
		iLocal_174++;
		break;

	case 1:
		iLocal_2125 = cam::create_camera_with_params(26379945, 1954.776f, 3149.146f, 47.0701f, 4.9054f, -0.0416f,
													 -158.4057f, 52.4461f, 0, 2);
		iLocal_2126 = cam::create_camera_with_params(26379945, 1954.776f, 3150.146f, 47.0701f, 4.9054f, -0.0416f,
													 -158.4057f, 52.4461f, 0, 2);
		cam::set_cam_active(iLocal_2125, 1);
		cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 2000, 0, 1);
		switch (func_42()) {
		case 0: graphics::_start_screen_effect("MinigameEndMichael", 0, 0); break;

		case 1: graphics::_start_screen_effect("MinigameEndFranklin", 0, 0); break;

		case 2: graphics::_start_screen_effect("MinigameEndTrevor", 0, 0); break;
		}
		audio::play_sound_frontend(-1, "Hit_In", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
		cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		cam::set_gameplay_cam_relative_heading(0f);
		func_132(1, 0, 0, 2000, 1, 0);
		cam::set_cinematic_mode_active(0);
		cam::shake_cam(iLocal_2126, "HAND_SHAKE", 0.3f);
		ai::task_vehicle_follow_waypoint_recording(iLocal_2127, ped::get_vehicle_ped_is_in(iLocal_2127, 0),
												   Local_54.f_64, 786468, 0, 28, -1, 30f, 1, 1073741824);
		if (Local_1943.f_7 == 1) {
			streaming::request_model(func_131());
		}
		iLocal_174++;
		break;

	case 2:
		if (cam::does_cam_exist(iLocal_2126)) {
			if (!cam::is_cam_interpolating(iLocal_2126)) {
				cam::destroy_cam(iLocal_2125, 0);
				iLocal_2125 = cam::create_camera_with_params(26379945, 1954.776f, 3149.146f, 47.0701f, 89.5011f,
															 -0.0416f, -158.4057f, 30f, 0, 2);
				cam::set_cam_active_with_interp(iLocal_2125, iLocal_2126, 600, 1, 1);
				cam::set_cam_motion_blur_strength(iLocal_2125, 1f);
				ai::clear_ped_tasks(player::player_ped_id());
				vehicle::_set_vehicle_halt(ped::get_vehicle_ped_is_in(iLocal_2127, 0), 10f, 1, 0);
				switch (func_42()) {
				case 0: graphics::_stop_screen_effect("MinigameEndMichael"); break;

				case 1: graphics::_stop_screen_effect("MinigameEndFranklin"); break;

				case 2: graphics::_stop_screen_effect("MinigameEndTrevor"); break;
				}
				graphics::_start_screen_effect("MinigameTransitionIn", 0, 1);
				audio::play_sound_frontend(-1, "Short_Transition_In", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
				cam::destroy_cam(iLocal_2126, 0);
				iLocal_126 = 0;
				iLocal_174++;
			}
		}
		break;

	case 3:
		if (cam::does_cam_exist(iLocal_2125)) {
			if (!cam::is_cam_interpolating(iLocal_2125)) {
				iVar0 = 0;
				while (iVar0 <= 7) {
					func_130(&Local_196[iVar0 /*50*/].f_1);
					func_128(&Local_196[iVar0 /*50*/], 1);
					func_127(&Local_196[iVar0 /*50*/].f_5, 1);
					iVar0++;
				}
				func_12(197, 0, 0, 1, 0);
				iVar0 = 0;
				while (iVar0 < Local_597) {
					func_128(&Local_597[iVar0 /*50*/], 1);
					iVar0++;
				}
			}
		}
		if (func_86(Local_1943, &uLocal_2135, &uLocal_2711, &iLocal_2835)) {
			if (!iLocal_2835) {
				if (Local_1943.f_7 > 1) {
					iLocal_174 = 10;
				}
				else {
					iLocal_2130 = vehicle::create_vehicle(func_131(), func_85(), func_84(), 1, 1);
					streaming::set_model_as_no_longer_needed(func_131());
					if (Global_101700.f_24032 == 4) {
						vehicle::set_vehicle_livery(iLocal_2130, 0);
						vehicle::set_vehicle_colours(iLocal_2130, 44, 83);
						vehicle::set_vehicle_extra_colours(iLocal_2130, 111, 111);
					}
					iLocal_174++;
				}
			}
			else {
				func_2(1, 0);
			}
		}
		break;

	case 4:
		cam::destroy_all_cams(0);
		iLocal_2125 = cam::create_camera_with_params(26379945, 1971.382f, 3108.135f, 47.2013f, 89.4758f, 0.0478f,
													 53.1639f, 53.3742f, 0, 2);
		cam::set_cam_active(iLocal_2125, 1);
		iLocal_2126 = cam::create_camera_with_params(26379945, 1971.382f, 3108.135f, 47.2013f, 0.4758f, 0.0478f,
													 53.1639f, 53.3742f, 0, 2);
		cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 600, 1, 1);
		graphics::_stop_screen_effect("MinigameTransitionIn");
		audio::play_sound_frontend(-1, "Short_Transition_Out", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
		cam::set_cam_motion_blur_strength(iLocal_2125, 1f);
		cam::shake_cam(iLocal_2125, "HAND_SHAKE", 0.3f);
		cam::set_cam_motion_blur_strength(iLocal_2126, 1f);
		cam::shake_cam(iLocal_2126, "HAND_SHAKE", 0.3f);
		func_23(iLocal_2129, 1967.471f, 3124.583f, 46.0038f, 186.2056f, 1, 1);
		ai::task_vehicle_mission_coors_target(player::player_ped_id(), iLocal_2129, 1968.5f, 3113.2f, 45.9001f, 4, 2f,
											  786469, 1f, -1f, 1);
		graphics::_stop_all_screen_effects();
		graphics::_start_screen_effect("MinigameTransitionOut", 0, 0);
		gameplay::clear_area(func_83(), 100f, 1, 0, 0, 0);
		iLocal_174++;
		break;

	case 5:
		if (cam::does_cam_exist(iLocal_2126)) {
			if (!cam::is_cam_interpolating(iLocal_2126)) {
				cam::destroy_cam(iLocal_2125, 0);
				iLocal_2125 = cam::create_camera_with_params(26379945, 1971.637f, 3108.429f, 47.201f, 0.1839f, 0.0478f,
															 40.5043f, 40f, 0, 2);
				cam::set_cam_active_with_interp(iLocal_2125, iLocal_2126, 5000, 1, 1);
				cam::shake_cam(iLocal_2125, "HAND_SHAKE", 1f);
				system::settimera(0);
				iLocal_174++;
			}
		}
		break;

	case 6:
		if (system::timera() > 4700) {
			if (cam::_0xEE778F8C7E1142E2(0) == 4 || cam::_0xEE778F8C7E1142E2(1) == 4) {
				graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
				audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
			}
			iLocal_174++;
		}
		break;

	case 7:
		if (cam::does_cam_exist(iLocal_2125)) {
			if (!cam::is_cam_interpolating(iLocal_2125)) {
				ai::task_leave_any_vehicle(player::player_ped_id(), 0, 0);
				if (cam::_0xEE778F8C7E1142E2(0) != 4 && cam::_0xEE778F8C7E1142E2(1) != 4) {
					cam::set_gameplay_cam_relative_heading(-69.3229f);
					cam::set_gameplay_cam_relative_pitch(-10.5361f, 1065353216);
				}
				func_132(0, 0, 0, 2000, 1, 0);
				system::settimera(0);
				iLocal_174++;
			}
		}
		break;

	case 8:
		graphics::_stop_all_screen_effects();
		func_60(iLocal_2130, 145);
		func_59();
		audio::stop_audio_scene("STREET_RACE_OUTRO");
		func_334(1, 0, 1, 0);
		break;

	case 10:
		cam::destroy_all_cams(0);
		iLocal_2125 = cam::create_camera_with_params(26379945, 1953.31f, 3139.005f, 48.1762f, 89.5003f, -0.0032f,
													 52.2429f, 25.3742f, 0, 2);
		cam::set_cam_active(iLocal_2125, 1);
		iLocal_2126 = cam::create_camera_with_params(26379945, 1953.31f, 3139.005f, 48.1762f, -7.3963f, -0.0058f,
													 52.1179f, 45f, 0, 2);
		cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 800, 1, 1);
		graphics::_stop_screen_effect("MinigameTransitionIn");
		audio::play_sound_frontend(-1, "Short_Transition_Out", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
		cam::set_cam_motion_blur_strength(iLocal_2125, 1f);
		cam::shake_cam(iLocal_2125, "HAND_SHAKE", 0.3f);
		cam::set_cam_motion_blur_strength(iLocal_2126, 1f);
		cam::shake_cam(iLocal_2126, "HAND_SHAKE", 0.3f);
		func_23(iLocal_2129, 1948.257f, 3142.936f, 45.8642f, 51.7219f, 1, 1);
		ai::clear_ped_tasks(player::player_ped_id());
		graphics::_start_screen_effect("MinigameTransitionOut", 0, 0);
		gameplay::clear_area(func_83(), 100f, 1, 0, 0, 0);
		system::settimera(0);
		iLocal_174++;
		break;

	case 11:
		if (system::timera() > 500) {
			if (cam::_0xEE778F8C7E1142E2(1) == 4) {
				if (func_8(iLocal_2129)) {
					cam::_0x11FA5D3479C7DD47(entity::get_entity_model(iLocal_2129));
				}
				graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
				audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
			}
			iLocal_174++;
		}
		break;

	case 12:
		if (system::timera() > 790) {
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			if (func_8(iLocal_2129)) {
				cam::_0x11FA5D3479C7DD47(entity::get_entity_model(iLocal_2129));
			}
			func_132(0, 0, 1, 2000, 1, 0);
			system::settimera(0);
			iLocal_174++;
		}
		break;

	case 13:
		if (system::timera() > 2000) {
			graphics::_stop_all_screen_effects();
			func_58();
			audio::stop_audio_scene("STREET_RACE_OUTRO");
			func_334(1, 0, 1, 0);
		}
		break;
	}
}

// Position - 0x6F14
void func_58() { Global_101697 = 0; }

// Position - 0x6F21
void func_59() { Global_101697 = 1; }

// Position - 0x6F2E
void func_60(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_65(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_61(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0x7130
void func_61(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_64(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_63(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_62(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0x73DC
int func_62(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0x748C
int func_63(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x7566
void func_64(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0x7616
int func_65(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_81(iParam0, 0, 0) ||
		func_81(iParam0, 1, 0) || func_81(iParam0, 2, 0) || func_80(iParam0) != 145 || func_79(iParam0) ||
		func_78(iParam0) || func_77(iParam0) || func_76(iParam0) || !func_66(entity::get_entity_model(iParam0))) {
		if (func_78(iParam0)) {
		}
		if (func_78(iParam0)) {
		}
		if (func_81(iParam0, 0, 0)) {
		}
		if (func_81(iParam0, 1, 0)) {
		}
		if (func_81(iParam0, 2, 0)) {
		}
		if (func_80(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0x76F3
int func_66(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_67(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x78A4
int func_67(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_75()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_74() && !func_73() && !func_72() && !func_71() && !func_75()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_72()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_70(iParam0)) {
			return 0;
		}
	}
	if (!func_68(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x7A32
int func_68(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_69()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x7AFE
int func_69() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x7B12
int func_70(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x8857
int func_71() { return 0; }

// Position - 0x8860
int func_72() { return 1; }

// Position - 0x8869
int func_73() { return 1; }

// Position - 0x8872
int func_74() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x888B
int func_75() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return 1;
			}
		}
	}
	if (Global_139179 == 2) {
		return 1;
	}
	else if (Global_139179 == 3) {
		return 0;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x8946
int func_76(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_67(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x898C
int func_77(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x89C7
bool func_78(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x8A43
int func_79(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x8B2B
int func_80(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x8B8E
bool func_81(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_82(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x8BFF
bool func_82(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x8CD7
Vector3 func_83() { return 1967.042f, 3116.005f, 45.8901f; }

// Position - 0x8CEE
float func_84() { return 194.8257f; }

// Position - 0x8CFB
Vector3 func_85() { return 1964.038f, 3114.635f, 46.1319f; }

// Position - 0x8D12
bool func_86(struct<13> Param0, var uParam13, var uParam14, var uParam15, var uParam16, var uParam17, var uParam18,
			 var uParam19, var *uParam20, var *uParam21, int *iParam22) {
	int iVar0;
	struct<2> Var1;
	char cVar5[16];

	switch (iLocal_126) {
	case 0:
		func_126(uParam20);
		func_123(uParam21, 1);
		iVar0 = 0;
		switch (Param0.f_7) {
		case 1: iVar0 = 3; break;

		case 2: iVar0 = 2; break;

		case 3: iVar0 = 1; break;

		default: iVar0 = 0; break;
		}
		StringCopy(&Var1, "CRACEP", 16);
		StringIntConCat(&Var1, Param0.f_7, 16);
		StringCopy(&cVar5, "CRACETRACK", 16);
		StringIntConCat(&cVar5, Global_101700.f_24032 + 1, 16);
		func_122(uParam20, &Var1, &cVar5, 0);
		if (Param0.f_12 != 0) {
			func_121(uParam20, 18, "CRACETIME", "", Param0.f_12, 0, 0, 0);
		}
		if (Global_101700.f_24032.f_1 != 0) {
			func_121(uParam20, 18, "CRACEBTIME", "", Global_101700.f_24032.f_1, 0, 0, 0);
		}
		uParam20->f_561 = 1;
		if (Param0.f_7 <= 3) {
			func_120(uParam20, 1, "CRACERES", Param0.f_7, 9, 1, iVar0);
		}
		else {
			func_120(uParam20, 0, "CRACERES", Param0.f_7, 9, 1, iVar0);
		}
		system::settimerb(0);
		if (Param0.f_7 <= 1) {
			audio::play_sound_frontend(-1, "MEDAL_UP", "HUD_MINI_GAME_SOUNDSET", 1);
		}
		else {
			audio::play_sound_frontend(-1, "RACE_PLACED", "HUD_AWARDS", 1);
		}
		iLocal_126 = 1;
		func_116(uParam20, 1, 0);
		uParam20->f_566 = 1;
		break;

	case 1:
		ui::hide_hud_and_radar_this_frame();
		func_92(uParam20, 0, 1065353216, 0, 0, 0);
		func_91(uParam21);
		if (system::timerb() > 2000) {
			if (controls::_is_input_disabled(2)) {
				ui::_show_cursor_this_frame();
			}
			if (controls::is_control_just_pressed(2, 216)) {
				func_90(uParam20);
				iLocal_126 = 2;
				*iParam22 = 1;
			}
			else if (controls::is_control_just_pressed(2, 215)) {
				func_90(uParam20);
				iLocal_126 = 2;
				*iParam22 = 0;
			}
		}
		break;

	case 2:
		if (func_92(uParam20, 0, 1065353216, 0, 0, 0)) {
			func_87(uParam20);
			func_29(uParam21);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x8EF0
void func_87(var *uParam0) {
	if (uParam0->f_1 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_1);
		uParam0->f_1 = 0;
	}
	if (uParam0->f_562 && uParam0->f_4 != 0) {
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_4);
		uParam0->f_4 = 0;
	}
	if (uParam0->f_564) {
		script::set_no_loading_screen(0);
		uParam0->f_564 = 0;
	}
	if (!Global_69970) {
		if (!player::is_player_dead(player::get_player_index())) {
			if (!G_TextMessageConfig) {
				if (cam::is_screen_faded_out() && !func_89(0)) {
					cam::do_screen_fade_in(800);
				}
			}
		}
	}
	func_88(0);
}

// Position - 0x8F97
void func_88(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x8FAB
int func_89(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return 1;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x8FD6
void func_90(var *uParam0) {
	uParam0->f_562 = 0;
	uParam0->f_561 = 0;
	uParam0->f_558 = uParam0->f_572 + 500;
}

// Position - 0x8FF7
void func_91(var *uParam0) { func_30(uParam0, 1128792064, 1, 0, 1, 1065353216); }

// Position - 0x9012
bool func_92(var *uParam0, int iParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (gameplay::get_frame_count() == uParam0->f_574) {
		return uParam0->f_575;
	}
	uParam0->f_574 = gameplay::get_frame_count();
	if (!network::network_is_game_in_progress()) {
		if (ped::is_ped_dead_or_dying(player::get_player_ped(player::get_player_index()), 1)) {
			uParam0->f_575 = 1;
			return true;
		}
		if (ai::is_ped_being_arrested(player::get_player_ped(player::get_player_index()))) {
			uParam0->f_575 = 1;
			return true;
		}
	}
	if (!uParam0->f_564) {
		if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
			script::set_no_loading_screen(1);
			uParam0->f_564 = 1;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (!network::network_is_game_in_progress()) {
			if (player::is_special_ability_active(player::player_id())) {
				player::special_ability_deactivate(player::player_id());
			}
		}
	}
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(19);
	controls::disable_control_action(2, 19, 1);
	controls::disable_control_action(0, 37, 1);
	controls::disable_control_action(0, 21, 1);
	controls::disable_control_action(0, 28, 1);
	controls::disable_control_action(0, 29, 1);
	controls::disable_control_action(0, 171, 1);
	func_52();
	if (controls::_is_input_disabled(2)) {
		if (player::_is_player_cam_control_disabled() || cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			ui::_show_cursor_this_frame();
		}
	}
	Global_36331 = 1;
	if (!uParam0->f_563) {
		switch (func_46(player::get_player_ped(player::get_player_index()))) {
		case 1: graphics::_start_screen_effect("SuccessFranklin", 1000, 0); break;

		case 2: graphics::_start_screen_effect("SuccessTrevor", 1000, 0); break;

		default: graphics::_start_screen_effect("SuccessMichael", 1000, 0); break;
		}
		uParam0->f_563 = 1;
	}
	if (uParam0->f_558 == 0) {
		uParam0->f_558 = uParam0->f_572 + system::floor(15000f * fParam2);
	}
	if (iParam4 && uParam0->f_572 >= uParam0->f_558 - 1500) {
		uParam0->f_558 = uParam0->f_572 + 3000;
	}
	if (uParam0->f_560 == 0f) {
		uParam0->f_560 += func_115(30f);
		uParam0->f_560 += IntToFloat(uParam0->f_56) * func_115(25f);
		if (uParam0->f_56 > 0) {
			uParam0->f_560 += func_115(25f * 0.5f);
		}
		if (uParam0->f_549) {
			uParam0->f_560 += func_115(30f) - func_115(2f);
		}
	}
	iVar0 = 1;
	while (iVar0) {
		func_88(1);
		uParam0->f_572 += system::round(0f + 1000f * system::timestep());
		func_95(uParam0, fParam2, iParam3);
		if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 666) - 15000f * fParam2) {
			if (uParam0->f_30 < 1f) {
				uParam0->f_30 += 0f + 1f / 0.225f * system::timestep();
			}
		}
		uParam0->f_30 = func_94(uParam0->f_30, 0f, 1f);
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_565) {
					uParam0->f_565 = 0;
					uParam0->f_566 = 0;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_547 -= (0f + 1f / 1.215f * system::timestep());
			}
		}
		uParam0->f_547 = func_94(uParam0->f_547, 0f, 1f);
		if (uParam0->f_547 <= 0.7f && !uParam0->f_545 && uParam0->f_1 != 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_OUT");
			graphics::_pop_scaleform_movie_function_void();
			uParam0->f_546 = uParam0->f_572;
			uParam0->f_545 = 1;
		}
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_548 < 1f) {
					uParam0->f_548 += 0f + 1f / 0.3f * system::timestep();
				}
			}
		}
		uParam0->f_548 = func_94(uParam0->f_548, 0f, 1f);
		if (uParam0->f_562) {
			if (controls::_0x6CD79468A1E595C6(2)) {
				if (graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
					if (!uParam0->f_567) {
						func_93(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
					}
				}
			}
		}
		if (controls::is_control_just_pressed(2, 216) && uParam0->f_558 > uParam0->f_572 + 333) {
			if (!uParam0->f_566 && uParam0->f_56 != 0 && graphics::has_scaleform_movie_loaded(uParam0->f_4) &&
				IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (!uParam0->f_565) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					if (uParam0->f_572 > uParam0->f_558 - 5000) {
						uParam0->f_558 = uParam0->f_572 + 5000;
					}
				}
				else if (iParam5) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 0;
					uParam0->f_573 = 0.75f;
				}
				func_93(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
			}
		}
		if ((uParam0->f_565 || uParam0->f_566) && uParam0->f_56 != 0) {
			if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (uParam0->f_566 && !uParam0->f_565) {
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_559 = func_94(uParam0->f_559 + 1f / 0.3f * uParam0->f_573 * system::timestep(), 0f, 1f);
				uParam0->f_573 = func_94(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
			}
		}
		else {
			uParam0->f_559 = func_94(uParam0->f_559 - 1f / 0.3f * uParam0->f_573 * 0.01f * system::timestep(), 0f, 1f);
			uParam0->f_573 = func_94(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
		}
		if (uParam0->f_572 > uParam0->f_558) {
			if (uParam0->f_561) {
				if (!uParam0->f_567) {
					if (controls::is_control_just_pressed(2, 215)) {
						uParam0->f_561 = 0;
					}
				}
			}
			else if (uParam0->f_572 - uParam0->f_546 > 1000 && uParam0->f_545) {
				iVar0 = 0;
			}
		}
		uParam0->f_575 = !iVar0;
		if (iParam1) {
			system::wait(0);
		}
		else {
			if (!iVar0) {
				func_88(0);
			}
			return !iVar0;
		}
	}
	func_88(0);
	return true;
}

// Position - 0x966A
void func_93(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_34(controls::get_control_instructional_button(2, 215, 1));
	func_50("ES_HELP");
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_push_scaleform_movie_function_parameter_int(215);
	}
	graphics::_pop_scaleform_movie_function_void();
	if (iParam1) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_34(controls::get_control_instructional_button(2, 216, 1));
		func_50("ES_XPAND");
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_push_scaleform_movie_function_parameter_int(216);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x972E
float func_94(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x9755
void func_95(var *uParam0, float fParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	float fVar18;
	float *fVar19;
	float fVar20;
	float fVar21;
	float fVar22;
	char cVar23[16];
	char cVar27[32];
	int iVar35;
	int iVar36;
	int iVar37;
	int iVar38;
	float fVar39;
	float fVar40;
	float fVar41;
	float fVar42;
	float fVar43;

	iVar0 = system::round(uParam0->f_547 * 255f);
	fVar1 = func_114() * 0.25f;
	if (graphics::has_scaleform_movie_loaded(uParam0->f_1)) {
		if (uParam0->f_30 >= 0f) {
			if (!uParam0->f_2) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "SHOW_MISSION_PASSED_MESSAGE");
				func_50(&uParam0->f_5);
				func_50(&uParam0->f_13);
				if (network::network_is_game_in_progress()) {
					graphics::_push_scaleform_movie_function_parameter_int(150);
				}
				else {
					graphics::_push_scaleform_movie_function_parameter_int(100);
				}
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_56);
				graphics::_push_scaleform_movie_function_parameter_bool(iParam2);
				graphics::_push_scaleform_movie_function_parameter_int(69);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_2 = 1;
			}
			if (uParam0->f_56 > 0 && !uParam0->f_3 && uParam0->f_572 > 600) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(0.15f);
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_3 = 1;
			}
		}
		func_113();
		graphics::draw_scaleform_movie_fullscreen(uParam0->f_1, 255, 255, 255, 255, 0);
	}
	fVar2 = uParam0->f_560 * uParam0->f_559 * (1f - uParam0->f_548);
	fVar3 = 0f;
	if (uParam0->f_567) {
		fVar3 = (0.1388889f + func_115(2f * 2f)) * uParam0->f_568 * (1f - uParam0->f_548);
		fVar2 += 3f * fVar3;
	}
	if (uParam0->f_548 != 0f) {
		fVar4 = 0f;
		if (fVar2 < fVar4) {
			fVar2 = fVar4;
		}
	}
	else {
		fVar5 = 0f;
		if (uParam0->f_30 >= 0.975f) {
			if (fVar2 < fVar5) {
				fVar2 = fVar5;
			}
		}
	}
	fVar1 = 0.3f * func_114();
	if (uParam0->f_12) {
		fVar1 = 0.5f;
	}
	fVar6 = *uParam0 * 2f;
	fVar7 = func_112(&uParam0->f_13);
	if (fVar6 < fVar7) {
		fVar6 = fVar7 + 3f * 0.006f;
	}
	if (graphics::_get_aspect_ratio(0) < 1.4f) {
		fVar6 *= 1.3f;
	}
	fVar7 = func_112(&uParam0->f_550);
	fVar8 = (0.119f + 0.05f) / func_114() / 2.5f;
	if ((uParam0->f_556 == 1 || uParam0->f_556 == 0) && uParam0->f_557 != 0) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (uParam0->f_556 == 3) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (fVar6 < fVar7 + 1.9f * fVar8) {
		fVar6 = fVar7 + 2f * fVar8;
	}
	fVar9 = 0.499f - fVar6 / 2f + 0.006f;
	fVar10 = 0.499f + fVar6 / 2f - 0.006f;
	controls::set_input_exclusive(2, 215);
	controls::set_input_exclusive(2, 216);
	controls::set_input_exclusive(2, 200);
	controls::disable_control_action(2, 200, 1);
	if (uParam0->f_562 || uParam0->f_567) {
		if (IntToFloat(uParam0->f_558) - 14000f * fParam1 < IntToFloat(uParam0->f_572) ||
			uParam0->f_567 && uParam0->f_559 > 0.95f && uParam0->f_558 - 10000 < uParam0->f_572) {
			if (uParam0->f_567) {
				if (uParam0->f_570 < 0) {
					uParam0->f_570 *= -1;
					uParam0->f_570 = uParam0->f_572 + uParam0->f_570;
				}
				if (uParam0->f_570 > 0) {
					if (uParam0->f_570 - uParam0->f_572 > 0) {
						func_109(uParam0->f_570 - uParam0->f_572, "TIMER_TIME", 0, 0, -1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0,
								 0, 0);
					}
					else {
						uParam0->f_570 = 0;
						uParam0->f_569 = 1;
						uParam0->f_567 = 0;
						uParam0->f_561 = 0;
						uParam0->f_562 = 0;
						uParam0->f_558 = uParam0->f_572 + 500;
						uParam0->f_570 = 0;
					}
				}
				if (uParam0->f_568 < 1f) {
					uParam0->f_568 += 0f + 1f / 0.166f * system::timestep();
					if (uParam0->f_568 > 1f) {
						uParam0->f_568 = 1f;
					}
				}
			}
			if (cam::is_screen_faded_out()) {
				ui::hide_loading_on_fade_this_frame();
			}
			if (uParam0->f_4 != 0 && uParam0->f_548 < 0.1f && uParam0->f_572 <= uParam0->f_558) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				graphics::draw_scaleform_movie_fullscreen(uParam0->f_4, 255, 255, 255, iVar0, 0);
			}
			if (uParam0->f_567) {
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				controls::disable_control_action(2, 188, 1);
				if (controls::is_disabled_control_just_pressed(2, 188)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 3;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 187, 1);
				if (controls::is_disabled_control_just_pressed(2, 187)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 4;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 202, 1);
				if (controls::is_disabled_control_just_pressed(2, 202)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 2;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
			else if (uParam0->f_562) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_562 = 0;
					uParam0->f_561 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
		}
	}
	ui::get_hud_colour(1, &iVar13, &iVar14, &iVar15, &iVar16);
	ui::set_text_colour(iVar13, iVar14, iVar15, iVar0);
	ui::set_text_wrap(fVar9, fVar10);
	ui::set_text_justification(0);
	ui::set_text_scale(1f, 0.4f);
	fVar1 -= func_115(6f);
	fVar1 += func_115(30f) - func_115(2f * 2f);
	fVar11 = fVar2 - func_115(2f * 14f);
	if (fVar11 >= 0f) {
		fVar12 = func_94(fVar11 / (0.6f * func_115(25f)), 0f, 1f);
		func_113();
		graphics::draw_rect(0.5f, fVar1 - (func_115(2f - 0.5f) - 0.001388889f), fVar6, func_108(1f), iVar13, iVar14,
							iVar15, system::round(fVar12 * IntToFloat(iVar16)), 0);
	}
	else {
		return;
	}
	fVar1 += func_115(2f * 0.3f);
	if (uParam0->f_56 > 0) {
		fVar1 += func_115(25f * 0.2f);
	}
	iVar17 = 0;
	iVar17 = 0;
	while (iVar17 < uParam0->f_56) {
		fVar11 = fVar2 - (fVar1 - 0.3f * func_114());
		if (fVar11 >= 0f) {
			fVar12 = func_94(fVar11 / (0.8f * func_115(25f)), 0f, 1f);
			func_105(uParam0, iVar17, fVar1 + func_115(2f), fVar9, fVar10, system::round(IntToFloat(iVar0) * fVar12));
		}
		else {
			return;
		}
		fVar1 += func_115(25f);
		iVar17++;
	}
	if (uParam0->f_56 > 0) {
		fVar1 += func_115(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_114());
		if (fVar11 >= 0f) {
			fVar1 += func_115(2f);
			fVar12 = func_94(fVar11 / (0.6f * func_115(25f)), 0f, 1f);
			func_113();
			graphics::draw_rect(0.5f, fVar1 + func_115(2f * 0.5f), fVar6, func_108(1f), iVar13, iVar14, iVar15,
								system::round(fVar12 * IntToFloat(iVar16)), 0);
		}
	}
	if (uParam0->f_549) {
		fVar1 += func_115(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_114());
		if (fVar11 >= 0f) {
			fVar12 = func_94(fVar11 / (0.8f * func_115(25f)), 0f, 1f);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			func_98(7, 0, 1, &fVar18, &fVar19, 0);
			fVar20 = fVar9;
			fVar21 = fVar10;
			if (unk::_get_current_language_id() == 0) {
				fVar20 = fVar9 + 0.119f / func_114() / 2.5f;
				fVar21 = fVar10 - 0.119f / func_114() / 2.5f;
				if (uParam0->f_556 == 1) {
					fVar20 = fVar9 + (0.119f + 0.05f) / func_114() / 2.5f;
					fVar21 = fVar10 - (0.119f + 0.05f) / func_114() / 2.5f;
				}
			}
			if (uParam0->f_557 == 0) {
				fVar20 += (fVar18 * 0.28f + 0.006f) / 2f;
				fVar21 += (fVar18 * 0.28f + 0.006f) / 2f;
			}
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(1);
			ui::set_text_scale(1f, 0.4f);
			func_97(&uParam0->f_550, fVar20, fVar1 + func_115(2f * 2f), 0, 0, 0);
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(2);
			ui::set_text_scale(1f, 0.4f);
			ui::set_text_centre(0);
			func_113();
			fVar22 = fVar21;
			StringCopy(&cVar23, "MPHud", 16);
			StringCopy(&cVar27, "MissionPassedMedal", 32);
			fVar22 -= (fVar18 * 0.28f + 0.006f);
			ui::set_text_wrap(fVar20, fVar22);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			switch (uParam0->f_556) {
			case 0:
				ui::begin_text_command_display_text("PERCENTAGE");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_115(2f * 2f), 0);
				break;

			case 1:
				ui::begin_text_command_display_text("FO_TWO_NUM");
				ui::add_text_component_integer(uParam0->f_554);
				ui::add_text_component_integer(uParam0->f_555);
				ui::end_text_command_display_text(fVar20, fVar1 + func_115(2f * 2f), 0);
				break;

			case 2:
				ui::begin_text_command_display_text("MTPHPER_XPNO");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_115(2f * 2f), 0);
				break;

			case 3:
				ui::begin_text_command_display_text("ESDOLLA");
				ui::add_text_component_formatted_integer(uParam0->f_554, 1);
				ui::end_text_command_display_text(fVar20, fVar1 + func_115(2f * 2f), 0);
				break;
			}
			if (uParam0->f_557 != 0) {
				iVar35 = 255;
				iVar36 = 255;
				iVar37 = 255;
				iVar38 = iVar0;
				switch (uParam0->f_557) {
				case 1: ui::get_hud_colour(107, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 3: ui::get_hud_colour(109, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 2: ui::get_hud_colour(108, &iVar35, &iVar36, &iVar37, &iVar38); break;
				}
				fVar39 = 0.001388889f * 5f;
				fVar40 = 0.00078125f * 16f * 2f;
				fVar41 = 0.001388889f * 16f * 2f;
				fVar42 = fVar21 + func_96(4f) - 0.006f;
				fVar43 = fVar1 + func_115(10f) + fVar39;
				if (uParam0->f_556 == -1) {
					fVar42 -= 0.006f * 6f;
				}
				fVar40 *= 0.65f;
				fVar41 *= 0.65f;
				graphics::draw_sprite(&cVar23, &cVar27, fVar42, fVar43, fVar40, fVar41, 0f, iVar35, iVar36, iVar37,
									  system::round(fVar12 * IntToFloat(iVar0)), 0);
			}
			fVar1 += func_115(30f) - 2f;
		}
	}
}

// Position - 0xA29F
float func_96(float fParam0) { return fParam0 * 0.00078125f; }

// Position - 0xA2AF
void func_97(char *sParam0, float fParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	ui::set_text_centre(iParam3);
	ui::set_text_font(iParam5);
	func_113();
	if (iParam4) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam0);
	}
	else {
		ui::begin_text_command_display_text(sParam0);
	}
	ui::end_text_command_display_text(fParam1, fParam2, 0);
}

// Position - 0xA2EC
int func_98(int iParam0, int iParam1, int iParam2, float fParam3, float *fParam4, int iParam5) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	float fVar36;
	vector3 vVar37;

	StringCopy(&cVar0, func_104(iParam0), 64);
	StringCopy(&cVar16, func_101(iParam0, iParam1), 64);
	if (gameplay::get_hash_key(&cVar16) != 0) {
		fVar34 = 1f;
		if (iParam5) {
			graphics::_get_active_screen_resolution(&iVar32, &iVar33);
			fVar35 = graphics::_get_aspect_ratio(0);
			if (func_100()) {
				iVar32 = system::round(system::to_float(iVar33) * fVar35);
			}
			fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
			fVar34 = fVar36 / fVar35;
			if (func_100()) {
				fVar34 = 1f;
			}
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
				graphics::get_screen_resolution(&iVar32, &iVar33);
			}
			iVar32 = system::round(system::to_float(iVar32) / fVar34);
			iVar33 = system::round(system::to_float(iVar33) / fVar34);
		}
		else {
			graphics::get_screen_resolution(&iVar32, &iVar33);
		}
		vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
		vVar37.x *= func_99(iParam0) / fVar34;
		vVar37.y *= func_99(iParam0) / fVar34;
		if (!iParam2) {
			vVar37.x -= 2f;
			vVar37.y -= 2f;
		}
		if (iParam0 == 30) {
			vVar37.x = 288f;
			vVar37.y = 106f;
		}
		if (iParam0 == 29 && gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
			vVar37.x = 106f;
			vVar37.y = 106f;
		}
		*fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
		*fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) * *fParam3;
		if (!iParam5) {
			if (!graphics::get_is_widescreen() && iParam0 != 30) {
				*fParam3 *= 1.33f;
			}
		}
		if (iParam0 == 29) {
			if (*fParam3 > Global_17289) {
				*fParam4 *= Global_17289 / *fParam3;
				*fParam3 = Global_17289;
			}
		}
		return 1;
	}
	return 0;
}

// Position - 0xA49D
float func_99(int iParam0) {
	switch (iParam0) {
	case 33:
	case 4:
	case 11:
	case 31:
	case 20:
	case 15:
	case 10:
	case 12:
	case 13:
	case 32:
	case 9:
	case 5:
	case 6:
	case 7:
	case 14:
	case 18:
	case 19:
	case 17:
	case 28:
	case 26:
	case 27:
	case 49: return 0.5f;
	}
	return 1f;
}

// Position - 0xA53C
bool func_100() {
	int iVar0;
	int iVar1;
	float fVar2;

	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (fVar2 > 3.5f) {
		return true;
	}
	return false;
}

// Position - 0xA56E
var func_101(int iParam0, int iParam1) {
	char *sVar0[2];
	var uVar3;
	struct<13> Var19;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_6703[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) == -1487683087) {
			Var19 = {func_103(player::player_id())};
			if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
				return func_102(&uVar3);
			}
		}
		else {
			return func_102(&Global_17290.f_6703[iParam0 /*16*/]);
		}
	}
	switch (iParam0) {
	case 3:
		sVar0[0] = "MP_hostCrown";
		sVar0[1] = "MP_hostCrown";
		break;

	case 21:
		sVar0[0] = "MP_SpecItem_Coke";
		sVar0[1] = "MP_SpecItem_Coke";
		break;

	case 22:
		sVar0[0] = "MP_SpecItem_Heroin";
		sVar0[1] = "MP_SpecItem_Heroin";
		break;

	case 23:
		sVar0[0] = "MP_SpecItem_Weed";
		sVar0[1] = "MP_SpecItem_Weed";
		break;

	case 24:
		sVar0[0] = "MP_SpecItem_Meth";
		sVar0[1] = "MP_SpecItem_Meth";
		break;

	case 25:
		sVar0[0] = "MP_SpecItem_Cash";
		sVar0[1] = "MP_SpecItem_Cash";
		break;

	case 1:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 2:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 4:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 6:
		sVar0[0] = "Shop_Box_CrossB";
		sVar0[1] = "Shop_Box_Cross";
		break;

	case 7:
		sVar0[0] = "Shop_Box_BlankB";
		sVar0[1] = "Shop_Box_Blank";
		break;

	case 5:
		sVar0[0] = "Shop_Box_TickB";
		sVar0[1] = "Shop_Box_Tick";
		break;

	case 8:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 9:
		sVar0[0] = "Shop_Clothing_Icon_B";
		sVar0[1] = "Shop_Clothing_Icon_A";
		break;

	case 10:
		sVar0[0] = "Shop_GunClub_Icon_B";
		sVar0[1] = "Shop_GunClub_Icon_A";
		break;

	case 17:
		sVar0[0] = "Shop_Ammo_Icon_B";
		sVar0[1] = "Shop_Ammo_Icon_A";
		break;

	case 18:
		sVar0[0] = "Shop_Armour_Icon_B";
		sVar0[1] = "Shop_Armour_Icon_A";
		break;

	case 19:
		sVar0[0] = "Shop_Health_Icon_B";
		sVar0[1] = "Shop_Health_Icon_A";
		break;

	case 20:
		sVar0[0] = "Shop_MakeUp_Icon_B";
		sVar0[1] = "Shop_MakeUp_Icon_A";
		break;

	case 11:
		sVar0[0] = "Shop_Tattoos_Icon_B";
		sVar0[1] = "Shop_Tattoos_Icon_A";
		break;

	case 12:
		sVar0[0] = "Shop_Garage_Icon_B";
		sVar0[1] = "Shop_Garage_Icon_A";
		break;

	case 13:
		sVar0[0] = "Shop_Garage_Bike_Icon_B";
		sVar0[1] = "Shop_Garage_Bike_Icon_A";
		break;

	case 14:
		sVar0[0] = "Shop_Barber_Icon_B";
		sVar0[1] = "Shop_Barber_Icon_A";
		break;

	case 15:
		sVar0[0] = "shop_Lock";
		sVar0[1] = "shop_Lock";
		break;

	case 16:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 26:
		sVar0[0] = "arrowleft";
		sVar0[1] = "arrowleft";
		break;

	case 27:
		sVar0[0] = "arrowright";
		sVar0[1] = "arrowright";
		break;

	case 28:
		sVar0[0] = "MP_AlertTriangle";
		sVar0[1] = "MP_AlertTriangle";
		break;

	case 29:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 31:
		sVar0[0] = "Shop_Michael_Icon_B";
		sVar0[1] = "Shop_Michael_Icon_A";
		break;

	case 32:
		sVar0[0] = "Shop_Franklin_Icon_B";
		sVar0[1] = "Shop_Franklin_Icon_A";
		break;

	case 33:
		sVar0[0] = "Shop_Trevor_Icon_B";
		sVar0[1] = "Shop_Trevor_Icon_A";
		break;

	case 48:
		sVar0[0] = "SaleIcon";
		sVar0[1] = "SaleIcon";
		break;

	case 49:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 0:
		sVar0[0] = "";
		sVar0[1] = "";
		break;
	}
	if (iParam1) {
		return sVar0[0];
	}
	return sVar0[1];
}

// Position - 0xA9A3
var func_102(var uParam0) { return uParam0; }

// Position - 0xA9AD
struct<13> func_103(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

// Position - 0xA9C4
char *
func_104(int iParam0) {
	var uVar0;
	struct<13> Var16;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5886[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) == -1487683087) {
			Var16 = {func_103(player::player_id())};
			network::_0x5835D9CD92E83184(&Var16, &uVar0);
			return func_102(&uVar0);
		}
		else {
			return func_102(&Global_17290.f_5886[iParam0 /*16*/]);
		}
	}
	if (iParam0 == 48) {
		return "MPShopSale";
	}
	return "CommonMenu";
}

// Position - 0xAA39
void func_105(var *uParam0, int iParam1, float fParam2, float fParam3, float fParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uVar3);
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	ui::set_text_wrap(fParam3, fParam4);
	ui::set_text_justification(1);
	ui::set_text_scale(1f, func_107(14f));
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_113();
	if (uParam0->f_531[iParam1]) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(&uParam0->f_71[iParam1 /*16*/]);
	}
	else {
		ui::begin_text_command_display_text(&uParam0->f_71[iParam1 /*16*/]);
		if (uParam0->f_57[iParam1] == 16 || uParam0->f_57[iParam1] == 17) {
			ui::add_text_component_integer(uParam0->f_489[iParam1]);
		}
	}
	ui::end_text_command_display_text(fParam3, fParam2, 0);
	fVar4 = fParam4;
	switch (uParam0->f_517[iParam1]) {
	case 0: break;

	case 1:
		func_98(7, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_101(7, 0), fParam4 - 0.006f, fParam2 + func_115(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 2:
		func_98(5, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_101(5, 0), fParam4 - 0.006f, fParam2 + func_115(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 3:
		func_98(6, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_101(6, 0), fParam4 - 0.006f, fParam2 + func_115(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;
	}
	if (uParam0->f_57[iParam1] == 0) {
		return;
	}
	if (uParam0->f_57[iParam1] == 15) {
		ui::set_text_justification(1);
	}
	else {
		ui::set_text_justification(2);
	}
	ui::set_text_scale(1f, func_107(14f));
	if (uParam0->f_57[iParam1] == 5 || uParam0->f_57[iParam1] == 4) {
		ui::set_text_wrap(fParam3, fVar4 - 0.00078125f * 3f);
	}
	else {
		ui::set_text_wrap(fParam3, fVar4 + 0.00078125f * 2f);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	func_106(uParam0->f_489[iParam1], uParam0->f_503[iParam1], fParam4, fParam2, &uParam0->f_280[iParam1 /*16*/],
			 uParam0->f_57[iParam1]);
}

// Position - 0xACC4
void func_106(int iParam0, int iParam1, float fParam2, float fParam3, char *sParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = 1;
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_113();
	fVar1 = 0f;
	fVar2 = 8f * 0.00078125f;
	fVar3 = 16f * 0.001388889f;
	iVar4 = 93;
	iVar5 = 182;
	iVar6 = 229;
	if (iParam5 == 4) {
		iVar4 = 194;
		iVar5 = 80;
		iVar6 = 80;
	}
	switch (iParam5) {
	case 4:
	case 5:
		ui::set_text_scale(1f, func_107(18f));
		ui::set_text_font(4);
		if (iParam0 < 0) {
			ui::_begin_text_command_width("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		else {
			ui::_begin_text_command_width("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		fVar1 -= fVar1 % 0.00078125f;
		graphics::draw_sprite("CommonMenu", "BettingBox_Left", fParam2 - fVar1,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Centre", fParam2 - fVar1 * 0.5f - 0.00078125f * 2f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar1 - fVar2 * 0.5f, fVar3, 0f, iVar4, iVar5,
							  iVar6, 255, 0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Right", fParam2 - 0.00078125f * 4f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		ui::set_text_scale(1f, func_107(14f));
		break;
	}
	ui::_set_notification_color_next(iVar0);
	switch (iParam5) {
	case 11:
		ui::begin_text_command_display_text("PERCENTAGE");
		ui::add_text_component_integer(iParam0);
		break;

	case 1:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_NUM");
		ui::add_text_component_integer(iParam0);
		break;

	case 2:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_TWO_NUM");
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 4:
	case 5: ui::set_text_scale(1f, func_107(18f));

	case 3:
		if (iParam0 < 0) {
			ui::begin_text_command_display_text("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
		}
		else {
			ui::begin_text_command_display_text("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
		}
		break;

	case 6: ui::begin_text_command_display_text(sParam4); break;

	case 7:
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam4);
		break;

	case 8:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 14);
		break;

	case 9:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 6);
		break;

	case 10:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 18:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 12:
		ui::begin_text_command_display_text("AHD_DIST");
		ui::add_text_component_integer(iParam0);
		break;

	case 13:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 15:
	case 14:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 16:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam1);
		break;
	}
	if (iParam5 != 17) {
		if (iParam5 == 4 || iParam5 == 5) {
			ui::end_text_command_display_text(fParam2 - 0.00078125f * 4f, fParam3, 0);
			ui::set_text_scale(1f, func_107(14f));
		}
		else {
			ui::end_text_command_display_text(fParam2, fParam3, 0);
		}
	}
}

// Position - 0xB03D
float func_107(float fParam0) { return fParam0 * 0.025f; }

// Position - 0xB04D
float func_108(float fParam0) { return fParam0 * 0.0009259259f; }

// Position - 0xB05D
void func_109(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			  int iParam15, int iParam16) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_111(7, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_110(7, iVar0);
		Global_1354542.f_4282[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_4282.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_4282.f_172[iVar0] = iParam2;
		Global_1354542.f_4282.f_216[iVar0] = iParam3;
		Global_1354542.f_4282.f_183[iVar0] = iParam4;
		Global_1354542.f_4282.f_194[iVar0] = iParam5;
		Global_1354542.f_4282.f_249[iVar0] = iParam6;
		Global_1354542.f_4282.f_260[iVar0] = iParam7;
		Global_1354542.f_4282.f_205[iVar0] = iParam8;
		Global_1354542.f_4282.f_314[iVar0] = iParam9;
		Global_1354542.f_4282.f_325[iVar0] = iParam10;
		Global_1354542.f_4282.f_357[iVar0] = iParam11;
		Global_1354542.f_4282.f_238[iVar0] = iParam12;
		Global_1354542.f_4282.f_271[iVar0] = iParam13;
		Global_1354542.f_4282.f_368[iVar0] = iParam14;
		Global_1354542.f_4282.f_379[iVar0] = iParam15;
		Global_1354542.f_4282.f_390[iVar0] = iParam16;
	}
}

// Position - 0xB1AB
void func_110(int iParam0, int iParam1) { gameplay::set_bit(&Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0xB1C4
int func_111(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0xB1DD
float func_112(char *sParam0) {
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1) / 2f;
}

// Position - 0xB1F2
void func_113() {
	graphics::_set_2d_layer(1);
	if (cam::is_screen_fading_out() || cam::is_screen_faded_out()) {
		graphics::_set_2d_layer(7);
	}
	graphics::_0xC6372ECD45D73BCD(0);
}

// Position - 0xB21A
float func_114() {
	float fVar0;

	fVar0 = 1f;
	if (gameplay::is_pc_version()) {
	}
	return fVar0;
}

// Position - 0xB22E
float func_115(float fParam0) { return fParam0 * 0.001388889f; }

// Position - 0xB23E
int func_116(var *uParam0, int iParam1, int iParam2) {
	uParam0->f_12 = iParam2;
	func_119(uParam0);
	func_118(uParam0);
	if (gameplay::are_strings_equal(&uParam0->f_550, "SPR_RESULT") ||
		gameplay::are_strings_equal(&uParam0->f_550, "") && uParam0->f_56 > 0) {
		uParam0->f_566 = 1;
	}
	if (network::network_is_game_in_progress()) {
		graphics::request_streamed_texture_dict("MPHud", 0);
	}
	if (uParam0->f_1 == 0) {
		graphics::request_streamed_texture_dict("CommonMenu", 0);
		graphics::request_streamed_texture_dict("MPLeaderboard", 0);
		graphics::request_streamed_texture_dict("MPHud", 0);
		uParam0->f_1 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
		uParam0->f_2 = 0;
		uParam0->f_3 = 0;
	}
	uParam0->f_4 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	if (iParam1) {
		while (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			   !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			   !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			   !graphics::has_streamed_texture_dict_loaded("MPHud")) {
			system::wait(0);
		}
		if (uParam0->f_562 || uParam0->f_567) {
			while (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				system::wait(0);
			}
		}
	}
	else {
		if (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			!graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			!graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			!graphics::has_streamed_texture_dict_loaded("MPHud")) {
			return 0;
		}
		if (uParam0->f_562) {
			if (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				return 0;
			}
		}
	}
	if (uParam0->f_562) {
		if (uParam0->f_567) {
			func_117(uParam0);
		}
		else if (uParam0->f_56 != 0) {
			func_93(uParam0, 1);
		}
		else {
			func_93(uParam0, 0);
		}
	}
	Global_69963 = 1;
	return 1;
}

// Position - 0xB3DD
void func_117(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(2);
	func_34(controls::get_control_instructional_button(2, 188, 1));
	func_50("ES_HELP_TU");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(1);
	func_34(controls::get_control_instructional_button(2, 187, 1));
	func_50("ES_HELP_TD");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_34(controls::get_control_instructional_button(2, 202, 1));
	func_50("ES_HELP_AB");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xB4A2
void func_118(float *fParam0) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	fVar0 = 0f;
	ui::set_text_justification(0);
	ui::set_text_scale(1f, func_107(16f));
	if (fParam0->f_31 == 0) {
		if (fParam0->f_29) {
			ui::_begin_text_command_width("STRING");
			ui::add_text_component_substring_player_name(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
		else {
			ui::_begin_text_command_width(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
	}
	else {
		ui::_begin_text_command_width("STRING");
		iVar1 = 0;
		iVar2 = 0;
		iVar3 = 0;
		iVar3 = 0;
		while (iVar3 < fParam0->f_31) {
			switch (fParam0->f_32[iVar3]) {
			case 0:
				ui::add_text_component_integer(fParam0->f_53[iVar1]);
				iVar1++;
				break;

			case 1:
				ui::add_text_component_substring_text_label(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;

			case 2:
				ui::add_text_component_substring_player_name(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;
			}
			iVar3++;
		}
		fVar0 = ui::_end_text_command_get_width(1);
	}
	if (fVar0 > 0.1125f * 2f - 0.006f * 2f) {
		*fParam0 = fVar0 / 2f + 0.006f * 2f;
	}
}

// Position - 0xB5AA
void func_119(var *uParam0) {
	uParam0->f_547 = 1f;
	uParam0->f_546 = 0;
	uParam0->f_568 = 0f;
	uParam0->f_558 = 0;
	uParam0->f_30 = 0f;
	uParam0->f_548 = 0f;
	uParam0->f_559 = 0f;
	uParam0->f_560 = 0f;
	uParam0->f_545 = 0;
	uParam0->f_563 = 0;
	uParam0->f_572 = 0;
	uParam0->f_564 = 0;
	uParam0->f_565 = 0;
	uParam0->f_566 = 0;
	*uParam0 = 0.1125f;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_574 = 0;
	uParam0->f_575 = 0;
	uParam0->f_573 = 1f;
}

// Position - 0xB629
void func_120(var *uParam0, int iParam1, char *sParam2, var uParam3, int iParam4, int iParam5, int iParam6) {
	uParam0->f_549 = iParam1;
	StringCopy(&uParam0->f_550, sParam2, 16);
	uParam0->f_554 = uParam3;
	uParam0->f_555 = iParam4;
	uParam0->f_556 = iParam5;
	uParam0->f_557 = iParam6;
}

// Position - 0xB65D
void func_121(var *uParam0, int iParam1, char *sParam2, char *sParam3, var uParam4, int iParam5, int iParam6,
			  int iParam7) {
	int iVar0;

	if (uParam0->f_56 == 13) {
		return;
	}
	iVar0 = uParam0->f_56;
	uParam0->f_57[iVar0] = iParam1;
	StringCopy(&uParam0->f_71[iVar0 /*16*/], sParam2, 64);
	StringCopy(&uParam0->f_280[iVar0 /*16*/], sParam3, 64);
	uParam0->f_489[iVar0] = uParam4;
	uParam0->f_503[iVar0] = iParam5;
	uParam0->f_517[iVar0] = iParam6;
	uParam0->f_531[iVar0] = iParam7;
	uParam0->f_56++;
}

// Position - 0xB6D0
void func_122(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	StringCopy(&uParam0->f_5, sParam1, 16);
	StringCopy(&uParam0->f_13, sParam2, 64);
	uParam0->f_29 = iParam3;
	uParam0->f_11 = 0;
}

// Position - 0xB6F3
void func_123(var *uParam0, int iParam1) {
	func_49(uParam0, 0, 0, 1, 1);
	func_48(uParam0, "CRACECONT", 2, 215, 1, 1, 0);
	if (iParam1) {
		func_48(uParam0, "CRACERET", 2, 216, 1, 1, 0);
	}
	func_125(uParam0, 1);
	func_124(uParam0, 1);
}

// Position - 0xB73A
void func_124(var *uParam0, int iParam1) {
	if (iParam1) {
		func_32(&uParam0->f_1, 16);
	}
	else {
		func_31(&uParam0->f_1, 16);
	}
}

// Position - 0xB75E
void func_125(var *uParam0, int iParam1) {
	if (iParam1) {
		func_32(&uParam0->f_1, 1024);
	}
	else {
		func_31(&uParam0->f_1, 1024);
	}
}

// Position - 0xB784
void func_126(var *uParam0) {
	func_119(uParam0);
	uParam0->f_570 = 0;
	uParam0->f_31 = 0;
	uParam0->f_56 = 0;
	uParam0->f_567 = 0;
	uParam0->f_569 = 0;
}

// Position - 0xB7AE
void func_127(int *iParam0, int iParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (!entity::is_entity_dead(*iParam0, 0)) {
			if (vehicle::is_playback_going_on_for_vehicle(*iParam0)) {
				vehicle::stop_playback_recorded_vehicle(*iParam0);
			}
			entity::stop_synchronized_entity_anim(*iParam0, -8f, 1);
			if (entity::is_entity_attached(*iParam0)) {
				entity::detach_entity(*iParam0, 1, 1);
			}
		}
		if (iParam1) {
			vehicle::delete_vehicle(iParam0);
		}
		else {
			entity::set_vehicle_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0xB812
void func_128(int iParam0, int iParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (!ped::is_ped_injured(*iParam0)) {
			if (!ped::is_ped_in_any_vehicle(*iParam0, 0) && !ped::is_ped_getting_into_a_vehicle(*iParam0)) {
				if (entity::is_entity_attached_to_any_object(*iParam0) ||
					entity::is_entity_attached_to_any_ped(*iParam0) ||
					entity::is_entity_attached_to_any_vehicle(*iParam0)) {
					entity::detach_entity(*iParam0, 1, 1);
				}
				entity::freeze_entity_position(*iParam0, 0);
			}
			if (!ped::is_ped_in_any_vehicle(*iParam0, 0)) {
				entity::set_entity_collision(*iParam0, 1, 0);
			}
			if (ped::is_ped_group_member(*iParam0, func_129())) {
				ped::remove_ped_from_group(*iParam0);
			}
			if (!iParam1) {
				ped::set_ped_keep_task(*iParam0, 1);
			}
		}
		if (iParam1) {
			ped::delete_ped(iParam0);
		}
		else {
			entity::set_ped_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0xB8C9
var func_129() { return player::get_player_group(player::get_player_index()); }

// Position - 0xB8D9
void func_130(int *iParam0) {
	if (ui::does_blip_exist(*iParam0)) {
		ui::set_blip_route(*iParam0, 0);
		ui::remove_blip(iParam0);
	}
}

// Position - 0xB8F9
int func_131() {
	switch (Global_101700.f_24032) {
	case 0: return joaat("stalion2");

	case 1: return joaat("gauntlet2");

	case 2: return joaat("dominator2");

	case 3: return joaat("buffalo3");

	case 4: return joaat("marshall");
	}
	return joaat("buffalo3");
}

// Position - 0xB967
void func_132(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	if (iParam4) {
		cam::set_widescreen_borders(iParam0, 0);
		cam::render_script_cams(iParam0, iParam2, iParam3, 1, 0, 0);
	}
	ui::clear_help(1);
	func_135(iParam0, 1, 1, 0);
	func_133(iParam0);
	ui::display_hud(!iParam0);
	ui::display_radar(!iParam0);
	if (func_8(player::player_ped_id())) {
		if (iParam5) {
			weapon::hide_ped_weapon_for_scripted_cutscene(player::player_ped_id(), iParam0);
		}
		else if (!iParam0) {
			weapon::hide_ped_weapon_for_scripted_cutscene(player::player_ped_id(), 0);
		}
	}
	if (!iParam1) {
		player::set_player_control(player::player_id(), !iParam0, 0);
	}
	else if (!player::is_player_control_on(player::player_id())) {
		player::set_player_control(player::player_id(), 1, 0);
	}
}

// Position - 0xBA01
void func_133(int iParam0) {
	if (iParam0) {
		func_134();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_56(0)) {
			func_53(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0xBA64
void func_134() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0xBA8D
void func_135(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_143(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_54()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_142(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_143(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_142(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_140(player::player_id()) &&
				!func_137(player::player_id(), 0) && !func_136()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_140(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0xBBA6
bool func_136() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0xBBC3
bool func_137(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_138(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0xBC0E
int func_138(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_139();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0xBC4F
var func_139() { return Global_1312735; }

// Position - 0xBC5B
int func_140(int iParam0) {
	if (func_137(iParam0, 0)) {
		return 1;
	}
	if (func_141()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0xBC9D
bool func_141() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0xBCAE
int func_142(int iParam0, int iParam1, var uParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && uParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0xBCE1
void func_143(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0xBD04
void func_144(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char[] cVar3[8];
	int iVar5;
	var uVar6;
	int iVar10;

	if (iParam3 == 1) {
		if (!gameplay::are_strings_equal("FinaleC2", script::get_this_script_name())) {
		}
	}
	iVar0 = 0;
	if (iParam3 == 1) {
		if (iParam0 != Global_91528) {
			iVar0 = 1;
		}
	}
	else if (iParam0 > Global_91528) {
		iVar0 = 1;
	}
	if (iVar0 == 1) {
		func_208(1);
		if (iParam0 <= Global_91528) {
		}
		iVar1 = func_206(script::get_this_script_name(), 1);
		if (iVar1 != -1 && iVar1 != 94) {
			Global_101700.f_8044.f_330[iVar1 /*6*/].f_1 = 0;
			iVar2 = func_204(iVar1);
			cVar3 = {Global_82612[iVar1 /*34*/].f_8};
			if (iVar1 == 90) {
				switch (Global_101700.f_8044.f_99.f_205[7]) {
				case 1: StringConCat(&cVar3, "A", 8); break;

				case 2: StringConCat(&cVar3, "B", 8); break;
				}
			}
			stats::playstats_mission_checkpoint(&cVar3, iVar2, Global_91528, iParam0);
		}
		else {
			iVar5 = func_199(script::get_this_script_name(), 1);
			if (iVar5 != -1) {
				Global_101700.f_17533[iVar5 /*6*/].f_4 = 0;
				MemCopy(&uVar6, {func_198(iVar5)}, 4);
				stats::playstats_mission_checkpoint(&uVar6, 0, Global_91528, iParam0);
			}
			else {
				iVar10 = func_197(&Global_91491.f_3);
				if (iVar10 > -1) {
					Global_101700.f_23945.f_4[iVar10] = 0;
				}
			}
		}
		Global_86002 = iParam2;
		Global_91528 = iParam0;
		func_145(iParam0, sParam1, iParam4, iParam5);
		if (gameplay::are_strings_equal(sParam1, "")) {
		}
	}
	else if (iParam0 < Global_91528) {
	}
}

// Position - 0xBE79
void func_145(int iParam0, var uParam1, int iParam2, int iParam3) {
	func_146(&Global_96040, script::get_this_script_name(), iParam0, uParam1, iParam3, iParam2);
}

// Position - 0xBE95
void func_146(var *uParam0, var uParam1, var uParam2, var uParam3, int iParam4, int iParam5) {
	int iVar0;
	int iVar1;

	*uParam0 = func_42();
	uParam0->f_1 = func_186();
	gameplay::_get_weather_type_transition(&uParam0->f_6, &uParam0->f_7, &uParam0->f_8);
	if (!ped::is_ped_injured(player::player_ped_id())) {
		func_171(&uParam0->f_2305, 0);
		func_170(player::player_ped_id());
		func_164(player::player_ped_id(), 0);
		weapon::get_current_ped_weapon(player::player_ped_id(), &uParam0->f_2, 1);
		if (uParam0->f_2 == 0 || uParam0->f_2 == joaat("object")) {
			uParam0->f_2 = joaat("weapon_unarmed");
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		uParam0->f_17[iVar1] = Global_101700.f_2095.f_539.f_294[iVar1];
		if (iVar1 == func_163()) {
			func_157(player::player_ped_id(), &uParam0->f_616[iVar1 /*65*/], 1);
		}
		else {
			iVar0 = 0;
			while (iVar0 < 12) {
				uParam0->f_616[iVar1 /*65*/][iVar0] = Global_91281[iVar1 /*65*/][iVar0];
				uParam0->f_616[iVar1 /*65*/].f_13[iVar0] = Global_91281[iVar1 /*65*/].f_13[iVar0];
				iVar0++;
			}
			uParam0->f_616[iVar1 /*65*/].f_59 = Global_91281[iVar1 /*65*/].f_59;
			uParam0->f_616[iVar1 /*65*/].f_60 = Global_91281[iVar1 /*65*/].f_60;
			uParam0->f_616[iVar1 /*65*/].f_61 = Global_91281[iVar1 /*65*/].f_61;
			uParam0->f_616[iVar1 /*65*/].f_62 = Global_91281[iVar1 /*65*/].f_62;
			uParam0->f_616[iVar1 /*65*/].f_63 = Global_91281[iVar1 /*65*/].f_63;
			uParam0->f_616[iVar1 /*65*/].f_64 = Global_91281[iVar1 /*65*/].f_64;
			iVar0 = 0;
			while (iVar0 < 9) {
				uParam0->f_616[iVar1 /*65*/].f_39[iVar0] = Global_91281[iVar1 /*65*/].f_39[iVar0];
				uParam0->f_616[iVar1 /*65*/].f_49[iVar0] = Global_91281[iVar1 /*65*/].f_49[iVar0];
				iVar0++;
			}
		}
		iVar0 = 0;
		while (iVar0 < 44) {
			uParam0->f_812[iVar1 /*284*/][iVar0 /*3*/] = {Global_101700.f_2095.f_539.f_298[iVar1 /*284*/][iVar0 /*3*/]};
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 < 50) {
			uParam0->f_812[iVar1 /*284*/].f_133[iVar0 /*3*/] = {
				Global_101700.f_2095.f_539.f_298[iVar1 /*284*/].f_133[iVar0 /*3*/]};
			iVar0++;
		}
		switch (iVar1) {
		case 0:
			stats::stat_get_int(joaat("sp0_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp0_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp0_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp0_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 1:
			stats::stat_get_int(joaat("sp1_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp1_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp1_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp1_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;

		case 2:
			stats::stat_get_int(joaat("sp2_weap_purch_0"), &uParam0->f_1665[iVar1 /*32*/][0], -1);
			stats::stat_get_int(joaat("sp2_weap_purch_1"), &uParam0->f_1665[iVar1 /*32*/][1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_5[0], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_5[1], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_5[2], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_5[3], -1);
			stats::stat_get_int(joaat("sp2_weap_addon_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_5[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_0"), &uParam0->f_1665[iVar1 /*32*/].f_16[0], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_1"), &uParam0->f_1665[iVar1 /*32*/].f_16[1], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_2"), &uParam0->f_1665[iVar1 /*32*/].f_16[2], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_3"), &uParam0->f_1665[iVar1 /*32*/].f_16[3], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_4"), &uParam0->f_1665[iVar1 /*32*/].f_16[4], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_5"), &uParam0->f_1665[iVar1 /*32*/].f_16[5], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_6"), &uParam0->f_1665[iVar1 /*32*/].f_16[6], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_7"), &uParam0->f_1665[iVar1 /*32*/].f_16[7], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_8"), &uParam0->f_1665[iVar1 /*32*/].f_16[8], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_9"), &uParam0->f_1665[iVar1 /*32*/].f_16[9], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_10"), &uParam0->f_1665[iVar1 /*32*/].f_16[10], -1);
			stats::stat_get_int(joaat("sp2_weap_tint_purch_11"), &uParam0->f_1665[iVar1 /*32*/].f_16[11], -1);
			break;
		}
		uParam0->f_9[iVar1] = Global_101700.f_19523.f_233[iVar1 /*69*/].f_1;
		uParam0->f_13[iVar1] = Global_52996[iVar1];
		uParam0->f_25[0 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[0 /*295*/][iVar1 /*98*/]};
		uParam0->f_25[1 /*295*/][iVar1 /*98*/] = {Global_101700.f_2095.f_539.f_1635[1 /*295*/][iVar1 /*98*/]};
		iVar0 = 0;
		while (iVar0 <= 3) {
			uParam0->f_2259[iVar1 /*15*/][iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/][iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_5[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_5[iVar0];
			uParam0->f_2259[iVar1 /*15*/].f_10[iVar0] = Global_101700.f_2095.f_493[iVar1 /*15*/].f_10[iVar0];
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 2) {
			uParam0->f_1766[iVar1 /*164*/][iVar0] = Global_101700.f_2095[iVar1 /*164*/][iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_4[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_4[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_8[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_8[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_12[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_12[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_16[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_16[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_20[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_20[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_24[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_24[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_28[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_28[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_32[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_32[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_36[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_36[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_40[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_40[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_44[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_44[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_48[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_48[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_52[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_52[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_56[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_56[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_60[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_60[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_64[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_64[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_68[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_68[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_72[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_72[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_76[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_76[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_80[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_80[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_84[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_84[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_88[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_88[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_92[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_92[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_96[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_96[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_100[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_100[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_104[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_104[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_108[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_108[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_112[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_112[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_116[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_116[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_120[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_120[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_124[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_124[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_128[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_128[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_132[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_132[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_136[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_136[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_140[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_140[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_144[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_144[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_148[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_148[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_152[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_152[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_156[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_156[iVar0];
			uParam0->f_1766[iVar1 /*164*/].f_160[iVar0] = Global_101700.f_2095[iVar1 /*164*/].f_160[iVar0];
			iVar0++;
		}
		iVar1++;
	}
	stats::stat_get_int(joaat("sp0_special_ability"), &uParam0->f_1762[0], -1);
	stats::stat_get_int(joaat("sp1_special_ability"), &uParam0->f_1762[1], -1);
	stats::stat_get_int(joaat("sp2_special_ability"), &uParam0->f_1762[2], -1);
	uParam0->f_5 = 145;
	if (iParam4 == 1) {
		func_148(&uParam0->f_2311, uParam0, iParam5, 1, 1, 0);
	}
	func_147(&uParam0->f_2401);
	uParam3 = uParam3;
	uParam2 = uParam2;
}

// Position - 0xCD1F
int func_147(var *uParam0) {
	*uParam0 = Global_87673;
	uParam0->f_1 = Global_87674;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	return 1;
}

// Position - 0xCD41
void func_148(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (iParam2 == 0) {
		iParam2 = player::player_ped_id();
	}
	if (entity::does_entity_exist(iParam2)) {
		uParam1->f_5 = func_46(iParam2);
	}
	if (func_156(iParam2, &iVar0, iParam3, iParam5)) {
		func_149(uParam0, uParam1, iVar0, iParam4);
	}
	else if (entity::does_entity_exist(iVar0)) {
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (vehicle::is_vehicle_model(iVar0, joaat("skylift")) &&
				ped::is_ped_in_vehicle(player::player_ped_id(), iVar0, 0)) {
				func_149(uParam0, uParam1, iVar0, iParam4);
			}
		}
	}
}

// Position - 0xCDC9
int func_149(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (vehicle::is_vehicle_driveable(iParam2, 0)) {
		func_151(uParam0, iParam2, iParam3);
		uParam1->f_4 = iParam2;
		if (func_150(iParam2)) {
			uParam1->f_3 = 1;
		}
		else {
			uParam1->f_3 = 0;
		}
		return 1;
	}
	return 0;
}

// Position - 0xCE09
bool func_150(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 6) {
		if (Global_91491.f_22[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0xCE37
void func_151(var *uParam0, int iParam1, int iParam2) {
	func_61(iParam1, &uParam0->f_12);
	uParam0->f_7 = func_153(iParam1, 145, 0);
	uParam0->f_11 = func_80(iParam1);
	if (!uParam0->f_7) {
		if (!uParam0->f_10) {
			uParam0->f_10 = func_152(iParam1);
		}
	}
	if (iParam2 == 1) {
		*uParam0 = {entity::get_entity_coords(iParam1, 1)};
		uParam0->f_6 = entity::get_entity_heading(iParam1);
		uParam0->f_3 = {entity::get_entity_velocity(iParam1)};
		if (entity::is_entity_in_angled_area(iParam1, -1154.326f, -1523.871f, 3.262189f, -1158.453f, -1517.75f,
											 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_6 = 305.6424f;
		}
		if (Global_69436 == iParam1) {
			uParam0->f_9 = 1;
		}
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		uParam0->f_8 = 1;
	}
	else {
		uParam0->f_8 = 0;
	}
}

// Position - 0xCF13
int func_152(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iParam0 == Global_68531.f_484[iVar0]) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xCF55
int func_153(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 0;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				if (iParam1 == 145 || iParam1 == Global_89165[iVar0]) {
					if (iParam2 == 0 || entity::get_entity_model(iParam0) == func_154(iParam1, iParam2)) {
						return 1;
					}
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xCFE3
int func_154(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_45(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_155(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0xD025
void func_155(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xD281
bool func_156(int iParam0, var *uParam1, int iParam2, int iParam3) {
	char *sVar0;

	if (entity::does_entity_exist(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			if (iParam0 == player::player_ped_id()) {
				*uParam1 = player::get_players_last_vehicle();
			}
			else {
				*uParam1 = ped::get_vehicle_ped_is_in(iParam0, 1);
			}
			if (entity::does_entity_exist(*uParam1)) {
				if (vehicle::is_vehicle_driveable(*uParam1, 0)) {
					if (iParam2 == 0 ||
						gameplay::get_distance_between_coords(entity::get_entity_coords(*uParam1, 1),
															  entity::get_entity_coords(iParam0, 1), 1) < 100f) {
						if (vehicle::is_vehicle_model(*uParam1, joaat("taxi"))) {
							if (vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != iParam0 &&
								vehicle::get_ped_in_vehicle_seat(*uParam1, -1, 0) != 0) {
								return false;
							}
						}
						if (func_81(*uParam1, func_42(), 1)) {
							sVar0 = script::get_this_script_name();
							if (!gameplay::are_strings_equal(sVar0, "save_anywhere")) {
								return false;
							}
							else if (!ped::is_ped_in_any_vehicle(iParam0, 1)) {
								return false;
							}
						}
						if (iParam3 == 1) {
							if (decorator::decor_exist_on(*uParam1, "IgnoredByQuickSave")) {
								if (decorator::decor_get_bool(*uParam1, "IgnoredByQuickSave")) {
									return false;
								}
							}
						}
						else if (vehicle::is_vehicle_model(*uParam1, joaat("blimp"))) {
							return false;
						}
						return true;
					}
				}
			}
		}
	}
	return false;
}

// Position - 0xD3B0
void func_157(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = func_46(iParam0);
		iVar1 = 0;
		while (iVar1 < 12) {
			func_162(iParam0, iVar1, &uParam1->f_13[iVar1], &(*uParam1)[iVar1], &uParam1->f_26[iVar1], iParam2, 145);
			iVar1++;
		}
		iVar1 = 0;
		while (iVar1 < 9) {
			func_161(iParam0, iVar1, &uParam1->f_39[iVar1], &uParam1->f_49[iVar1], iParam2, 145);
			iVar1++;
		}
		if (func_45(iVar0)) {
			uParam1->f_59 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_59;
			uParam1->f_60 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_60;
			uParam1->f_61 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_61;
			uParam1->f_62 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_62;
			uParam1->f_63 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_63;
			uParam1->f_64 = Global_101700.f_2095.f_539[iVar0 /*65*/].f_64;
		}
		else if (network::network_is_game_in_progress() &&
				 entity::get_entity_model(iParam0) == entity::get_entity_model(player::player_ped_id())) {
			if (func_160(161, -1)) {
				uParam1->f_59 = func_158(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_158(747, Global_69521, 0);
			}
			uParam1->f_60 = func_158(748, Global_69521, 0);
			uParam1->f_61 = func_158(749, Global_69521, 0);
		}
		if (network::network_is_game_in_progress() && iParam0 == player::player_ped_id()) {
			if (func_160(161, -1)) {
				uParam1->f_59 = func_158(2045, Global_69521, 0);
			}
			else {
				uParam1->f_59 = func_158(747, Global_69521, 0);
			}
		}
	}
}

// Position - 0xD55A
int func_158(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_159(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0xD58C
int func_159(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_139();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0xD5C0
bool func_160(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_159(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return false;
}

// Position - 0xD5EC
void func_161(int iParam0, int iParam1, int *iParam2, int *iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_prop_index(iParam0, iParam1);
		*iParam3 = ped::get_ped_prop_texture_index(iParam0, iParam1);
	}
	else {
		iVar0 = iParam5;
	}
	if (iParam4 == 0) {
		return;
	}
	if (iParam1 == 0) {
		if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
			if (iParam0 != 0) {
				if (ped::is_ped_wearing_helmet(iParam0) && ped::_0x451294E859ECC018(iParam0) != -1) {
					*iParam2 = ped::_0x451294E859ECC018(iParam0);
					*iParam3 = ped::_0x9D728C1E12BF5518(iParam0);
				}
			}
		}
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 0) {
			if (*iParam2 == 7) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 28) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		else if (iParam1 == 1) {
			if (*iParam2 == 1) {
				if ((iParam4 & 2) != 0 || (iParam4 & 64) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 0) {
			if (*iParam2 == 2) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 4) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 16) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 6) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 17) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 20) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 8 && *iParam2 <= 14) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 0) {
			if (*iParam2 == 9) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 11) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 12) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 21) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 23) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 == 27) {
				if ((iParam4 & 1) != 0 || (iParam4 & 2) != 0 || (iParam4 & 8) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
			else if (*iParam2 >= 14 && *iParam2 <= 20 || *iParam2 == 2) {
				if ((iParam4 & 2) != 0 || (iParam4 & 4) != 0) {
					*iParam2 = -1;
					*iParam3 = -1;
				}
			}
		}
		break;
	}
}

// Position - 0xDB34
void func_162(int iParam0, int iParam1, int *iParam2, int *iParam3, var *uParam4, int iParam5, int iParam6) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (iParam0 != 0) {
		*iParam2 = ped::get_ped_drawable_variation(iParam0, iParam1);
		*iParam3 = ped::get_ped_texture_variation(iParam0, iParam1);
		*uParam4 = ped::get_ped_palette_variation(iParam0, iParam1);
	}
	else {
		iVar0 = iParam6;
	}
	if (iParam5 == 0) {
		return;
	}
	switch (iVar0) {
	case 0:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 15) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 3 || *iParam2 == 22) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 8) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 1:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 1 || *iParam2 == 10) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
			if ((iParam5 & 2) != 0 || (iParam5 & 64) != 0) {
				if (*iParam2 == 19) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
				if (*iParam2 == 5) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;

	case 2:
		if (iParam1 == 8) {
			if ((iParam5 & 1) != 0 || (iParam5 & 2) != 0 || (iParam5 & 32) != 0) {
				if (*iParam2 == 3) {
					*iParam2 = 14;
					*iParam3 = 0;
				}
			}
		}
		else if (iParam1 == 9) {
			if (*iParam2 >= 5 && *iParam2 <= 7) {
				if ((iParam5 & 2) != 0 || (iParam5 & 4) != 0) {
					*iParam2 = 0;
					*iParam3 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0xDD75
int func_163() {
	func_43();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0xDD8E
void func_164(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_46(iParam0);
	if (func_45(iVar0) && !ped::is_ped_injured(iParam0)) {
		if (iParam0 == player::player_ped_id()) {
			func_165(iParam0, &Global_101700.f_2095.f_539.f_298[iVar0 /*284*/]);
			iVar2 = 0;
			while (iVar2 <= 8 - 1) {
				Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] = ui::_0xA13E93403F26C812(iVar2);
				if (iParam1) {
					iVar1 = ui::_0xA48931185F0536FE();
					if (Global_101700.f_2095.f_539.f_1151[iVar2 /*4*/][iVar0] == iVar1) {
						Global_101700.f_2095.f_539.f_1184 = iVar2;
					}
				}
				iVar2++;
			}
			player::get_player_parachute_pack_tint_index(player::player_id(), &iVar3);
			if (iVar0 == 0) {
				stats::stat_set_int(joaat("sp0_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 1) {
				stats::stat_set_int(joaat("sp1_parachute_current_tint"), iVar3, 1);
			}
			else if (iVar0 == 2) {
				stats::stat_set_int(joaat("sp2_parachute_current_tint"), iVar3, 1);
			}
		}
	}
}

// Position - 0xDE81
void func_165(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	int iVar7;
	int iVar8;
	struct<2> Var9;
	struct<4> Var48;
	int iVar70;

	if (!ped::is_ped_injured(iParam0)) {
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			(*uParam1)[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 44 - 1) {
			iVar3 = func_169(iVar0);
			if (iVar3 != 0) {
				vVar4.x = weapon::get_ped_weapontype_in_slot(iParam0, func_169(iVar0));
				vVar4.y = 0;
				vVar4.z = 0;
				if (vVar4.x != 0 && vVar4.x != joaat("weapon_unarmed")) {
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (vVar4.x == joaat("gadget_parachute")) {
						vVar4.y = 1;
					}
					gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					(*uParam1)[iVar0 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					iVar2 = func_167(vVar4.x, iVar1);
					while (iVar2 != 0) {
						if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, iVar2)) {
							gameplay::set_bit(&vVar4.f_2, iVar1);
						}
						iVar1++;
						iVar2 = func_167(vVar4.x, iVar1);
					}
				}
				(*uParam1)[iVar0 /*3*/] = {vVar4};
			}
			iVar0++;
		}
		iVar0 = 0;
		while (iVar0 <= 50 - 1) {
			uParam1->f_133[iVar0 /*3*/].f_1 = 0;
			iVar0++;
		}
		iVar8 = dlc1::get_num_dlc_weapons();
		iVar7 = 0;
		while (iVar7 < iVar8) {
			if (dlc1::get_dlc_weapon_data(iVar7, &Var9) && !func_166(Var9.f_1) && iVar70 < 50) {
				if (!dlc1::_is_dlc_data_empty(Var9)) {
					vVar4.x = Var9.f_1;
					vVar4.y = 0;
					vVar4.z = 0;
					vVar4.y = weapon::get_ammo_in_ped_weapon(iParam0, vVar4.x);
					if (weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						gameplay::set_bit(&vVar4.f_2, 20 + weapon::get_ped_weapon_tint_index(iParam0, vVar4.x));
					}
					else {
						gameplay::set_bit(&vVar4.f_2, 20);
					}
					if (vVar4.y == -1) {
						if (!weapon::get_max_ammo(iParam0, vVar4.x, &vVar4.f_1)) {
							vVar4.y = 0;
						}
					}
					uParam1->f_133[iVar70 /*3*/].f_1 = vVar4.y;
					iVar1 = 0;
					while (iVar1 < dlc1::get_num_dlc_weapon_components(iVar7)) {
						if (dlc1::get_dlc_weapon_component_data(iVar7, iVar1, &Var48)) {
							if (weapon::has_ped_got_weapon_component(iParam0, vVar4.x, Var48.f_3)) {
								gameplay::set_bit(&vVar4.f_2, iVar1);
							}
						}
						iVar1++;
					}
				}
				if (vVar4.x != 0) {
					if (!weapon::has_ped_got_weapon(iParam0, vVar4.x, 0)) {
						vVar4.x = 0;
						vVar4.y = 0;
					}
				}
				uParam1->f_133[iVar70 /*3*/] = {vVar4};
				iVar70++;
			}
			iVar7++;
		}
	}
}

// Position - 0xE0E5
int func_166(int iParam0) {
	if (network::network_is_game_in_progress()) {
	}
	else {
		switch (iParam0) {
		case joaat("weapon_pistol50"):
		case joaat("weapon_bullpupshotgun"):
		case joaat("weapon_assaultsmg"): return 0;

		case joaat("weapon_bottle"):
		case joaat("weapon_snspistol"):
		case joaat("weapon_gusenberg"): return 0;

		case joaat("weapon_heavypistol"):
		case joaat("weapon_specialcarbine"): return 0;

		case joaat("weapon_bullpuprifle"): return 0;

		case joaat("weapon_dagger"):
		case joaat("weapon_vintagepistol"): return 0;

		case joaat("weapon_firework"):
		case joaat("weapon_musket"): return 0;

		case joaat("weapon_heavyshotgun"):
		case joaat("weapon_marksmanrifle"): return 0;

		case joaat("weapon_hominglauncher"):
		case joaat("weapon_proxmine"): return 0;

		case joaat("weapon_combatpdw"):
		case joaat("weapon_knuckle"):
		case joaat("weapon_marksmanpistol"): return 0;

		case -947031628:
		case -572349828:
		case 392730790:
		case -1523701417:
		case -2112826155:
		case -664359727:
		case -1887867191:
		case -837150131:
		case -344484024:
		case joaat("weapon_flaregun"):
		case joaat("weapon_handcuffs"):
		case joaat("weapon_snowball"):
		case joaat("weapon_garbagebag"):
		case joaat("weapon_flashlight"):
		case joaat("weapon_switchblade"):
		case joaat("weapon_revolver"):
		case joaat("weapon_dbshotgun"):
		case joaat("weapon_compactrifle"):
		case 317205821:
		case -1121678507:
		case 125959754:
		case -853065399:
		case -1169823560:
		case -1810795771:
		case 419712736: return 1;
		}
	}
	return 0;
}

// Position - 0xE253
int func_167(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	var *uVar2;
	struct<4> Var41;

	iVar0 = 0;
	switch (iParam0) {
	case joaat("weapon_pistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpistol_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_combatpistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_appistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_appistol_clip_01"); break;

		case 1: iVar0 = joaat("component_appistol_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;

		case 4: iVar0 = joaat("component_appistol_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_microsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_microsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_microsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_microsmg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_smg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_smg_clip_01"); break;

		case 1: iVar0 = joaat("component_smg_clip_02"); break;

		case 2: iVar0 = joaat("component_smg_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_pi_supp"); break;

		case 5: iVar0 = joaat("component_at_scope_macro_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_smg_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_assaultrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_assaultrifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_at_ar_flsh"); break;

		case 5: iVar0 = joaat("component_at_scope_macro"); break;

		case 6: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 7: iVar0 = joaat("component_assaultrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_carbinerifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_carbinerifle_clip_01"); break;

		case 1: iVar0 = joaat("component_carbinerifle_clip_02"); break;

		case 2: iVar0 = joaat("component_carbinerifle_clip_03"); break;

		case 3: iVar0 = joaat("component_at_railcover_01"); break;

		case 4: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 5: iVar0 = joaat("component_at_ar_flsh"); break;

		case 6: iVar0 = joaat("component_at_scope_medium"); break;

		case 7: iVar0 = joaat("component_at_ar_supp"); break;

		case 8: iVar0 = joaat("component_carbinerifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_advancedrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_advancedrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_advancedrifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_advancedrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_mg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_mg_clip_01"); break;

		case 1: iVar0 = joaat("component_mg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_scope_small_02"); break;

		case 3: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 4: iVar0 = joaat("component_mg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_combatmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatmg_clip_01"); break;

		case 1: iVar0 = joaat("component_combatmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_scope_medium"); break;

		case 4: iVar0 = joaat("component_combatmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_pumpshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_sr_supp"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_pumpshotgun_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_assaultshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultshotgun_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultshotgun_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;
		}
		break;

	case joaat("weapon_sniperrifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sniperrifle_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_sniperrifle_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_heavysniper"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_heavysniper_clip_01"); break;

		case 1: iVar0 = joaat("component_at_scope_large"); break;

		case 2: iVar0 = joaat("component_at_scope_max"); break;
		}
		break;

	case joaat("weapon_grenadelauncher"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_scope_small"); break;
		}
		break;

	case joaat("weapon_minigun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_minigun_clip_01"); break;
		}
		break;

	case joaat("weapon_assaultsmg"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_assaultsmg_clip_01"); break;

		case 1: iVar0 = joaat("component_assaultsmg_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_macro"); break;

		case 4: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 5: iVar0 = joaat("component_assaultsmg_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 1: iVar0 = joaat("component_at_ar_flsh"); break;

		case 2: iVar0 = joaat("component_at_ar_supp_02"); break;
		}
		break;

	case joaat("weapon_pistol50"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_pistol50_clip_01"); break;

		case 1: iVar0 = joaat("component_pistol50_clip_02"); break;

		case 2: iVar0 = joaat("component_at_pi_flsh"); break;

		case 3: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 4: iVar0 = joaat("component_pistol50_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_combatpdw"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_combatpdw_clip_01"); break;

		case 1: iVar0 = joaat("component_combatpdw_clip_02"); break;

		case 2: iVar0 = joaat("component_combatpdw_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_small"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_sawnoffshotgun_varmod_luxe"); break;
		}
		break;

	case joaat("weapon_bullpuprifle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_bullpuprifle_clip_01"); break;

		case 1: iVar0 = joaat("component_bullpuprifle_clip_02"); break;

		case 2: iVar0 = joaat("component_at_ar_flsh"); break;

		case 3: iVar0 = joaat("component_at_scope_small"); break;

		case 4: iVar0 = joaat("component_at_ar_supp"); break;

		case 5: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 6: iVar0 = joaat("component_bullpuprifle_varmod_low"); break;
		}
		break;

	case joaat("weapon_snspistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_snspistol_clip_01"); break;

		case 1: iVar0 = joaat("component_snspistol_clip_02"); break;

		case 2: iVar0 = joaat("component_snspistol_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_specialcarbine"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_specialcarbine_clip_01"); break;

		case 1: iVar0 = joaat("component_specialcarbine_clip_02"); break;

		case 2: iVar0 = joaat("component_specialcarbine_clip_03"); break;

		case 3: iVar0 = joaat("component_at_ar_flsh"); break;

		case 4: iVar0 = joaat("component_at_scope_medium"); break;

		case 5: iVar0 = joaat("component_at_ar_supp_02"); break;

		case 6: iVar0 = joaat("component_at_ar_afgrip"); break;

		case 7: iVar0 = joaat("component_specialcarbine_varmod_lowrider"); break;
		}
		break;

	case joaat("weapon_knuckle"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_knuckle_varmod_pimp"); break;

		case 1: iVar0 = joaat("component_knuckle_varmod_ballas"); break;

		case 2: iVar0 = joaat("component_knuckle_varmod_dollar"); break;

		case 3: iVar0 = joaat("component_knuckle_varmod_diamond"); break;

		case 4: iVar0 = joaat("component_knuckle_varmod_hate"); break;

		case 5: iVar0 = joaat("component_knuckle_varmod_love"); break;

		case 6: iVar0 = joaat("component_knuckle_varmod_player"); break;

		case 7: iVar0 = joaat("component_knuckle_varmod_king"); break;

		case 8: iVar0 = joaat("component_knuckle_varmod_vagos"); break;
		}
		break;

	case joaat("weapon_machinepistol"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_machinepistol_clip_01"); break;

		case 1: iVar0 = joaat("component_machinepistol_clip_02"); break;

		case 2: iVar0 = joaat("component_machinepistol_clip_03"); break;

		case 3: iVar0 = joaat("component_at_pi_supp"); break;
		}
		break;

	case joaat("weapon_switchblade"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_switchblade_varmod_var1"); break;

		case 1: iVar0 = joaat("component_switchblade_varmod_var2"); break;
		}
		break;

	case joaat("weapon_revolver"):
		switch (iParam1) {
		case 0: iVar0 = joaat("component_revolver_clip_01"); break;

		case 1: iVar0 = joaat("component_revolver_varmod_boss"); break;

		case 2: iVar0 = joaat("component_revolver_varmod_goon"); break;
		}
		break;

	case -1121678507:
		switch (iParam1) {
		case 0: iVar0 = -2067221805; break;

		case 1: iVar0 = -1820405577; break;
		}
		break;

	default:
		if (iParam0 != 0) {
			iVar1 = func_168(iParam0, &uVar2);
			if (iVar1 != -1) {
				if (iParam1 < dlc1::get_num_dlc_weapon_components(iVar1)) {
					if (dlc1::get_dlc_weapon_component_data(iVar1, iParam1, &Var41)) {
						return Var41.f_3;
					}
				}
			}
		}
		break;
	}
	return iVar0;
}

// Position - 0xED3F
int func_168(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xED7A
int func_169(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (iParam0) {
	case 0: iVar0 = 1993361168; break;

	case 1: iVar0 = 1277010230; break;

	case 2: iVar0 = 932043479; break;

	case 3: iVar0 = -690654591; break;

	case 4: iVar0 = -1459198205; break;

	case 5: iVar0 = 195782970; break;

	case 6: iVar0 = -438797331; break;

	case 7: iVar0 = 896793492; break;

	case 8: iVar0 = 495159329; break;

	case 9: iVar0 = -1155528315; break;

	case 10: iVar0 = -515636489; break;

	case 11: iVar0 = -871913299; break;

	case 12: iVar0 = -1352759032; break;

	case 13: iVar0 = -542958961; break;

	case 14: iVar0 = 1682645887; break;

	case 15: iVar0 = -859470162; break;

	case 16: iVar0 = -2125426402; break;

	case 17: iVar0 = 2067210266; break;

	case 18: iVar0 = -538172856; break;

	case 19: iVar0 = 1783244476; break;

	case 20: iVar0 = 439844898; break;

	case 21: iVar0 = -24829327; break;

	case 22: iVar0 = 1949306232; break;

	case 23: iVar0 = -1941230881; break;

	case 24: iVar0 = -1033554448; break;

	case 25: iVar0 = 320513715; break;

	case 26: iVar0 = -695165975; break;

	case 27: iVar0 = -281028447; break;

	case 28: iVar0 = -686713772; break;

	case 29: iVar0 = 347509793; break;

	case 30: iVar0 = 1769089473; break;

	case 31: iVar0 = 189935548; break;

	case 33: iVar0 = 248801358; break;

	case 34: iVar0 = 386596758; break;

	case 35: iVar0 = -157212362; break;

	case 36: iVar0 = 436985596; break;

	case 37: iVar0 = -47957369; break;

	case 38: iVar0 = 575938238; break;
	}
	return iVar0;
}

// Position - 0xEFEE
void func_170(int iParam0) {
	int iVar0;

	iVar0 = func_46(iParam0);
	if (func_45(iVar0) && !ped::is_ped_injured(iParam0)) {
		Global_101700.f_2095.f_539.f_294[iVar0] = ped::get_ped_armour(iParam0);
	}
}

// Position - 0xF02A
void func_171(var *uParam0, int iParam1) {
	int iVar0;
	vector3 vVar1;
	float *fVar4;
	int iVar5;

	*uParam0 = {entity::get_entity_coords(player::player_ped_id(), 1)};
	uParam0->f_3 = entity::get_entity_heading(player::player_ped_id());
	uParam0->f_5 = ped::get_ped_parachute_state(player::player_ped_id());
	if (player::is_player_playing(player::player_id())) {
		uParam0->f_4 = player::get_player_wanted_level(player::player_id());
	}
	if (system::vdist(*uParam0, 320.9934f, 265.2515f, 82.1221f) < 10f) {
		*uParam0 = {301.2162f, 202.1357f, 103.3797f};
		uParam0->f_3 = 156.5144f;
	}
	else if (system::vdist(*uParam0, 377.153f, -717.567f, 10.0536f) < 10f) {
		*uParam0 = {394.2567f, -713.5439f, 28.2853f};
		uParam0->f_3 = 276.6273f;
	}
	else if (system::vdist(*uParam0, -1425.564f, -244.3f, 15.8053f) < 10f) {
		*uParam0 = {-1423.472f, -214.2539f, 45.5004f};
		uParam0->f_3 = 353.8757f;
	}
	else if (script::_get_number_of_instances_of_script_with_name_hash(joaat("finale_choice")) > 0) {
		*uParam0 = {4.2587f, 525.0214f, 173.6281f};
		uParam0->f_3 = 203.6746f;
	}
	else if (gameplay::is_bit_set(Global_69950, 4)) {
		*uParam0 = {452.0255f, 5571.85f, 780.1859f};
		uParam0->f_3 = 78.9858f;
	}
	else if (gameplay::is_bit_set(Global_69950, 5)) {
		*uParam0 = {-745.4462f, 5595.146f, 40.6594f};
		uParam0->f_3 = 261.747f;
	}
	else if (gameplay::is_bit_set(Global_69950, 6)) {
		*uParam0 = {-1675.521f, -1125.59f, 12.091f};
		uParam0->f_3 = 271.8208f;
	}
	else if (gameplay::is_bit_set(Global_69950, 7)) {
		*uParam0 = {-1631.219f, -1112.805f, 12.0212f};
		uParam0->f_3 = 316.8879f;
	}
	else if (interior::get_interior_from_entity(player::player_ped_id()) ==
			 interior::get_interior_at_coords_with_type(1272.659f, -1715.467f, 53.7715f, "v_lesters")) {
		*uParam0 = {1276.956f, -1725.189f, 53.6551f};
		uParam0->f_3 = 204.1703f;
	}
	else if (entity::is_entity_in_angled_area(player::player_ped_id(), -415.4365f, 2068.289f, 113.3002f, -564.9516f,
											  1884.703f, 134.0403f, 258.75f, 0, 1, 0) ||
			 entity::is_entity_in_angled_area(player::player_ped_id(), -596.4706f, 2089.921f, 125.4128f, -581.2134f,
											  2036.256f, 136.2836f, 9.5f, 0, 1, 0)) {
		*uParam0 = {-601.59f, 2099.197f, 128.8928f};
		uParam0->f_3 = 204.7498f;
	}
	else if (system::vdist(*uParam0, -1007.393f, -477.9584f, 52.5357f) < 8f) {
		*uParam0 = {-1018.376f, -483.9436f, 36.0964f};
		uParam0->f_3 = 114.7664f;
	}
	else if (system::vdist(*uParam0, 480.6662f, -1317.808f, 28.20303f) < 15f) {
		*uParam0 = {497.7238f, -1310.932f, 28.2372f};
		uParam0->f_3 = 289.3663f;
	}
	else if (system::vdist(*uParam0, 2329.527f, 2571.311f, 45.6779f) < 5f) {
		*uParam0 = {2316.93f, 2594.153f, 45.7199f};
		uParam0->f_3 = 348.1325f;
	}
	if (iParam1 == 1) {
		if (func_175(&iVar0)) {
			if (func_173(iVar0, &vVar1, &fVar4)) {
				vVar1.z++;
				*uParam0 = {vVar1};
				uParam0->f_3 = fVar4;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 207.4336f, -1019.795f, -100.4728f, 189.9338f,
												  -1019.623f, -95.56883f, 17.1875f, 0, 1, 0)) {
			iVar5 = func_42();
			if (iVar5 == 0) {
				*uParam0 = {-65.1234f, 81.2517f, 70.5644f};
				uParam0->f_3 = 71.6237f;
			}
			else if (iVar5 == 1) {
				*uParam0 = {-68.5531f, -1824.377f, 25.9424f};
				uParam0->f_3 = 215.8295f;
			}
			else if (iVar5 == 2) {
				*uParam0 = {-220.8189f, -1162.302f, 22.0242f};
				uParam0->f_3 = 70.2711f;
			}
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 483.7175f, -1326.63f, 28.2135f, 474.9644f,
												  -1307.998f, 34.49498f, 12f, 0, 1, 0)) {
			*uParam0 = {495.4108f, -1306.08f, 29.2883f};
			uParam0->f_3 = 213.6273f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), -1146.77f, -1534.22f, 3.37f, -1158.453f,
												  -1517.75f, 6.374244f, 13f, 0, 1, 0)) {
			*uParam0 = {-1160.095f, -1515.407f, 3.1496f};
			uParam0->f_3 = 305.6424f;
		}
		else if (entity::is_entity_in_angled_area(player::player_ped_id(), 439.5432f, -996.9769f, 24.88307f, 428.2935f,
												  -997.0192f, 28.57458f, 8.5f, 0, 1, 0)) {
			*uParam0 = {431.8853f, -1013.133f, 28.7907f};
			uParam0->f_3 = 186.6814f;
		}
		else if (func_172(*uParam0, "v_hospital", 307.3065f, -589.9595f, 43.302f)) {
			*uParam0 = {279.4137f, -585.8815f, 43.2502f};
			uParam0->f_3 = 48.8028f;
		}
	}
}

// Position - 0xF585
bool func_172(vector3 vParam0, char *sParam3, vector3 vParam4) {
	int iVar0;
	int iVar1;

	if (!interior::_are_coords_colliding_with_exterior(vParam0)) {
		iVar0 = interior::get_interior_at_coords_with_type(vParam4, sParam3);
		if (!interior::is_valid_interior(iVar0)) {
			return false;
		}
		iVar1 = interior::get_interior_from_collision(vParam0);
		if (iVar1 == iVar0) {
			return true;
		}
	}
	return false;
}

// Position - 0xF5C9
bool func_173(int iParam0, var *uParam1, float *fParam2) {
	*uParam1 = {0f, 0f, 0f};
	*fParam2 = 0f;
	switch (iParam0) {
	case 0:
		*uParam1 = {-829.842f, -191.7454f, 36.4386f};
		*fParam2 = 29.5061f;
		break;

	case 1:
		*uParam1 = {129.8484f, -1716.528f, 28.0702f};
		*fParam2 = 50.3483f;
		break;

	case 2:
		*uParam1 = {-1296.913f, -1120.999f, 5.3951f};
		*fParam2 = 0.9933f;
		break;

	case 3:
		*uParam1 = {1938.028f, 3718.736f, 31.3154f};
		*fParam2 = 118.2305f;
		break;

	case 4:
		*uParam1 = {1197.866f, -469.3809f, 65.0885f};
		*fParam2 = 346.4477f;
		break;

	case 5:
		*uParam1 = {-32.2161f, -135.8212f, 56.0532f};
		*fParam2 = 186.0052f;
		break;

	case 6:
		*uParam1 = {-287.7696f, 6238.081f, 30.2902f};
		*fParam2 = 316.1349f;
		break;

	case 7:
		*uParam1 = {99.2876f, -1395.16f, 28.2759f};
		*fParam2 = 320.2739f;
		break;

	case 8:
		*uParam1 = {1679.445f, 4819.056f, 41.0035f};
		*fParam2 = 4.6192f;
		break;

	case 9:
		*uParam1 = {411.3063f, -809.1863f, 28.1554f};
		*fParam2 = 1.8972f;
		break;

	case 10:
		*uParam1 = {-1088.054f, 2699.167f, 19.2748f};
		*fParam2 = 129.7382f;
		break;

	case 11:
		*uParam1 = {1194.163f, 2695.644f, 36.9225f};
		*fParam2 = 1.1454f;
		break;

	case 12:
		*uParam1 = {-821.2829f, -1088.027f, 10.0499f};
		*fParam2 = 120.5883f;
		break;

	case 13:
		*uParam1 = {-3.3416f, 6521.303f, 30.2961f};
		*fParam2 = 316.4451f;
		break;

	case 14:
		*uParam1 = {-1208.417f, -785.9635f, 16.0139f};
		*fParam2 = 36.3181f;
		break;

	case 15:
		*uParam1 = {623.1845f, 2739.191f, 40.9588f};
		*fParam2 = 3.5411f;
		break;

	case 16:
		*uParam1 = {130.9555f, -198.2084f, 53.41f};
		*fParam2 = 251.3506f;
		break;

	case 17:
		*uParam1 = {-3164.065f, 1067.317f, 19.6778f};
		*fParam2 = 101.2229f;
		break;

	case 18:
		*uParam1 = {-713.2797f, -174.2767f, 35.8962f};
		*fParam2 = 29.8138f;
		break;

	case 19:
		*uParam1 = {-147.0616f, -306.4322f, 37.7912f};
		*fParam2 = 160.4526f;
		break;

	case 20:
		*uParam1 = {-1461.355f, -230.6092f, 48.3064f};
		*fParam2 = 318.7851f;
		break;

	case 21:
		*uParam1 = {-1347.739f, -1278.573f, 3.8952f};
		*fParam2 = 17.9365f;
		break;

	case 22:
		*uParam1 = {325.6833f, 164.3263f, 102.4425f};
		*fParam2 = 68.6407f;
		break;

	case 23:
		*uParam1 = {1858.774f, 3742.393f, 32.0779f};
		*fParam2 = 301.2329f;
		break;

	case 24:
		*uParam1 = {-286.3272f, 6202.802f, 30.3323f};
		*fParam2 = 225.1334f;
		break;

	case 25:
		*uParam1 = {-1161.596f, -1417.7f, 3.712f};
		*fParam2 = 246.9161f;
		break;

	case 26:
		*uParam1 = {1308.952f, -1660.611f, 50.2362f};
		*fParam2 = 163.5456f;
		break;

	case 27:
		*uParam1 = {-3161.585f, 1074.214f, 19.6847f};
		*fParam2 = 98.6092f;
		break;

	case 28:
		*uParam1 = {28.423f, -1110.814f, 28.2848f};
		*fParam2 = 85.2495f;
		break;

	case 29:
		*uParam1 = {1704.966f, 3749.709f, 33.0188f};
		*fParam2 = 45.6778f;
		break;

	case 30:
		*uParam1 = {223.949f, -38.7894f, 68.6483f};
		*fParam2 = 159.4265f;
		break;

	case 31:
		*uParam1 = {837.7854f, -1017.963f, 26.3045f};
		*fParam2 = 181.0445f;
		break;

	case 32:
		*uParam1 = {-313.1914f, 6093.351f, 30.4625f};
		*fParam2 = 315.8405f;
		break;

	case 33:
		*uParam1 = {-663.4631f, -952.8069f, 20.3143f};
		*fParam2 = 92.6796f;
		break;

	case 34:
		*uParam1 = {-1323.06f, -392.8577f, 35.4596f};
		*fParam2 = 210.7398f;
		break;

	case 35:
		*uParam1 = {-1106.102f, 2684.35f, 18.0953f};
		*fParam2 = 127.0383f;
		break;

	case 36:
		*uParam1 = {-3157.932f, 1081.309f, 19.6953f};
		*fParam2 = 100.2942f;
		break;

	case 37:
		*uParam1 = {2562.882f, 312.8641f, 107.4612f};
		*fParam2 = 179.205f;
		break;

	case 38:
		*uParam1 = {822.48f, -2142.875f, 27.8496f};
		*fParam2 = 355.0598f;
		break;

	case 39:
		*uParam1 = {-1137.053f, -1993.916f, 12.1677f};
		*fParam2 = 43.1213f;
		break;

	case 40:
		*uParam1 = {717.8107f, -1084.081f, 21.3094f};
		*fParam2 = 93.2649f;
		break;

	case 41:
		*uParam1 = {-387.6789f, -128.2568f, 37.6796f};
		*fParam2 = 119.1085f;
		break;

	case 42:
		*uParam1 = {117.8835f, 6599.415f, 31.0134f};
		*fParam2 = 90.7225f;
		break;

	case 43:
		*uParam1 = {1201.709f, 2664.813f, 36.8102f};
		*fParam2 = 133.9002f;
		break;

	case 44:
		*uParam1 = {-200.1521f, -1297.502f, 30.296f};
		*fParam2 = 269.0687f;
		break;

	case 45:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		break;
	}
	return !func_174(*uParam1, 0f, 0f, 0f, 0);
}

// Position - 0xFC58
bool func_174(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0xFC9F
bool func_175(int *iParam0) {
	if (!entity::is_entity_dead(player::player_ped_id(), 0) && !ped::is_ped_injured(player::player_ped_id())) {
		if (func_185()) {
			*iParam0 = func_180(entity::get_entity_coords(player::player_ped_id(), 0), 6, -1, 0, 1, -1);
			if (func_179(*iParam0) && !func_176(*iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0xFCFA
int func_176(int iParam0) { return func_177(iParam0, 0, 1); }

// Position - 0xFD0A
int func_177(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		return gameplay::is_bit_set(Global_91543.f_1308[iParam0], iParam1);
	}
	else if (network::network_is_game_in_progress()) {
		if (func_18() == 0) {
			return gameplay::is_bit_set(func_158(func_178(iParam0), -1, 0), iParam1);
		}
	}
	else {
		return gameplay::is_bit_set(Global_101700.f_668[iParam0], iParam1);
	}
	return 0;
}

// Position - 0xFD6A
int func_178(int iParam0) {
	switch (iParam0) {
	case 0: return 822;

	case 1: return 823;

	case 2: return 824;

	case 3: return 825;

	case 4: return 826;

	case 5: return 827;

	case 6: return 828;

	case 7: return 829;

	case 8: return 830;

	case 9: return 831;

	case 10: return 832;

	case 11: return 833;

	case 12: return 834;

	case 13: return 835;

	case 14: return 836;

	case 15: return 838;

	case 16: return 839;

	case 17: return 840;

	case 18: return 841;

	case 19: return 842;

	case 20: return 843;

	case 21: return 844;

	case 22: return 845;

	case 23: return 846;

	case 24: return 847;

	case 25: return 848;

	case 26: return 849;

	case 27: return 850;

	case 28: return 851;

	case 29: return 852;

	case 30: return 853;

	case 31: return 854;

	case 32: return 855;

	case 33: return 856;

	case 34: return 857;

	case 35: return 858;

	case 36: return 859;

	case 37: return 860;

	case 38: return 861;

	case 39: return 862;

	case 40: return 866;

	case 41: return 867;

	case 42: return 868;

	case 43: return 869;

	case 44: return 5847;

	case 45: return 3780;

	default: break;
	}
	return 6022;
}

// Position - 0x10033
int func_179(int iParam0) { return func_177(iParam0, 5, 1); }

// Position - 0x10043
int func_180(vector3 vParam0, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = -1;
	iVar0 = 0;
	while (iVar0 <= 45) {
		if (iParam3 == 6 || iParam3 == func_184(iVar0)) {
			if (!iParam5 || func_183(iVar0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, func_181(iVar0, 0), 1);
				if (fVar1 < fVar2 && (fVar1 <= IntToFloat(iParam4) || iParam4 == -1) && (iParam6 || iVar0 != 21) &&
					iVar0 != iParam7) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x100E5
Vector3 func_181(int iParam0, int iParam1) {
	switch (iParam0) {
	case -1: return 0f, 0f, 0f;

	case 0: return -821.9946f, -187.1776f, 36.5689f;

	case 1: return 133.5702f, -1710.918f, 28.2916f;

	case 2: return -1287.082f, -1116.558f, 5.9901f;

	case 3: return 1933.119f, 3726.079f, 31.8444f;

	case 4: return 1208.333f, -470.917f, 65.208f;

	case 5: return -30.7448f, -148.4921f, 56.0765f;

	case 6: return -280.8165f, 6231.771f, 30.6955f;

	case 7: return 80.665f, -1391.669f, 28.3761f;

	case 8: return 1687.881f, 4820.55f, 41.0096f;

	case 9: return 419.531f, -807.5787f, 28.4896f;

	case 10: return -1094.049f, 2704.171f, 18.0873f;

	case 11: return 1197.972f, 2704.22f, 37.1572f;

	case 12: return -818.6218f, -1077.533f, 10.3282f;

	case 13: return -0.2361f, 6516.045f, 30.8684f;

	case 14: return -1199.809f, -776.6886f, 16.3237f;

	case 15: return 618.1857f, 2752.567f, 41.0881f;

	case 16: return 126.6853f, -212.5027f, 53.5578f;

	case 17: return -3168.966f, 1055.287f, 19.8632f;

	case 18: return -715.3598f, -155.7742f, 36.4105f;

	case 19: return -158.2199f, -304.9663f, 38.735f;

	case 20: return -1455.005f, -233.1862f, 48.7936f;

	case 21: return -1335.973f, -1278.555f, 3.8598f;

	case 22: return 321.6098f, 179.4165f, 102.5865f;

	case 23: return 1861.685f, 3750.08f, 32.0318f;

	case 24: return -290.1603f, 6199.095f, 30.4871f;

	case 25: return -1153.948f, -1425.019f, 3.9544f;

	case 26: return 1322.455f, -1651.125f, 51.1885f;

	case 27: return -3169.42f, 1074.727f, 19.8343f;

	case 28: return 17.6804f, -1114.288f, 28.797f;

	case 29: return 1697.979f, 3753.2f, 33.7053f;

	case 30: return 245.2711f, -45.8126f, 68.941f;

	case 31: return 844.1248f, -1025.571f, 27.1948f;

	case 32: return -325.8904f, 6077.026f, 30.4548f;

	case 33: return -664.2178f, -943.3646f, 20.8292f;

	case 34: return -1313.948f, -390.9637f, 35.592f;

	case 35: return -1111.238f, 2688.463f, 17.6131f;

	case 36: return -3165.231f, 1082.855f, 19.8438f;

	case 37: return 2569.612f, 302.576f, 107.7349f;

	case 38: return 811.8699f, -2149.102f, 28.6363f;

	case 39: return -1147.314f, -1992.434f, 12.1803f;

	case 40: return 724.524f, -1089.081f, 21.1692f;

	case 41: return -354.5272f, -135.4011f, 38.185f;

	case 42: return 113.2615f, 6624.28f, 30.7871f;

	case 43: return 1174.707f, 2644.45f, 36.7552f;

	case 44:
		if (iParam1) {
			return -211.5f, -1324.2f, 30.296f;
		}
		else {
			return -205.6654f, -1311.113f, 30.296f;
		}
		break;

	case 45: return func_182(Global_93004);
	}
	return 1000000f, 1000000f, 1000000f;
}

// Position - 0x105FF
Vector3 func_182(int iParam0) {
	switch (iParam0) {
	case 1: return 1060f, -2990f, -35f;

	case 2: return 1060f, -2990f, -35f;

	case 3: return 974.9542f, -3000.091f, -35f;

	case 6: return -1586.36f, -566.6f, 106.17f;

	case 7: return -1389.87f, -465.17f, 82.68f;

	case 8: return -145.81f, -590.2f, 171.13f;

	case 9: return -62.49f, -823.55f, 288.74f;

	case 4: return 1102.515f, -3158.888f, -38.5186f;

	case 5: return 1005.861f, -3156.162f, -39.907f;

	default: return 0f, 0f, -200f;
	}
	return 0f, 0f, -200f;
}

// Position - 0x10715
int func_183(int iParam0) { return func_177(iParam0, 0, 0); }

// Position - 0x10725
int func_184(int iParam0) {
	switch (iParam0) {
	case -1: return 6;

	case 0: return 0;

	case 1: return 0;

	case 2: return 0;

	case 3: return 0;

	case 4: return 0;

	case 5: return 0;

	case 6: return 0;

	case 7: return 1;

	case 8: return 1;

	case 9: return 1;

	case 10: return 1;

	case 11: return 1;

	case 12: return 1;

	case 13: return 1;

	case 14: return 1;

	case 15: return 1;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 2;

	case 23: return 2;

	case 24: return 2;

	case 25: return 2;

	case 26: return 2;

	case 27: return 2;

	case 28: return 3;

	case 29: return 3;

	case 30: return 3;

	case 31: return 3;

	case 32: return 3;

	case 33: return 3;

	case 34: return 3;

	case 35: return 3;

	case 36: return 3;

	case 37: return 3;

	case 38: return 3;

	case 39: return 4;

	case 40: return 4;

	case 41: return 4;

	case 42: return 4;

	case 43: return 4;

	case 44: return 4;

	case 45: return 5;
	}
	return 6;
}

// Position - 0x10998
bool func_185() { return Global_91543.f_303 > 0; }

// Position - 0x109A9
var func_186() {
	int *iVar0;

	func_196(&iVar0, time::get_clock_seconds());
	func_195(&iVar0, time::get_clock_minutes());
	func_194(&iVar0, time::get_clock_hours());
	func_189(&iVar0, time::get_clock_day_of_month());
	func_188(&iVar0, time::get_clock_month());
	func_187(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x109EF
void func_187(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x10A75
void func_188(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x10AA8
void func_189(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_193(*uParam0);
	iVar1 = func_191(*uParam0);
	if (iParam1 < 1 || iParam1 > func_190(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x10AF9
int func_190(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x10B9B
int func_191(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_192(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x10BC0
int func_192(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x10BD7
int func_193(int iParam0) { return iParam0 & 15; }

// Position - 0x10BE4
void func_194(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x10C1E
void func_195(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x10C59
void func_196(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x10C95
int func_197(char *sParam0) {
	if (gameplay::are_strings_equal("BailBond1", sParam0)) {
		return 0;
	}
	else if (gameplay::are_strings_equal("BailBond2", sParam0)) {
		return 1;
	}
	else if (gameplay::are_strings_equal("BailBond3", sParam0)) {
		return 2;
	}
	else if (gameplay::are_strings_equal("BailBond4", sParam0)) {
		return 3;
	}
	return -1;
}

// Position - 0x10CEB
struct<2> func_198(int iParam0) {
	struct<2> Var0;

	StringCopy(&Var0, "", 8);
	switch (iParam0) {
	case 0: StringCopy(&Var0, "ABI1", 8); break;

	case 1: StringCopy(&Var0, "ABI2", 8); break;

	case 2: StringCopy(&Var0, "BA1", 8); break;

	case 3: StringCopy(&Var0, "BA2", 8); break;

	case 4: StringCopy(&Var0, "BA3", 8); break;

	case 5: StringCopy(&Var0, "BA3A", 8); break;

	case 6: StringCopy(&Var0, "BA3C", 8); break;

	case 7: StringCopy(&Var0, "BA4", 8); break;

	case 8: StringCopy(&Var0, "DRE1", 8); break;

	case 9: StringCopy(&Var0, "EPS1", 8); break;

	case 10: StringCopy(&Var0, "EPS2", 8); break;

	case 11: StringCopy(&Var0, "EPS3", 8); break;

	case 12: StringCopy(&Var0, "EPS4", 8); break;

	case 13: StringCopy(&Var0, "EPS5", 8); break;

	case 14: StringCopy(&Var0, "EPS6", 8); break;

	case 15: StringCopy(&Var0, "EPS7", 8); break;

	case 16: StringCopy(&Var0, "EPS8", 8); break;

	case 17: StringCopy(&Var0, "EXT1", 8); break;

	case 18: StringCopy(&Var0, "EXT2", 8); break;

	case 19: StringCopy(&Var0, "EXT3", 8); break;

	case 20: StringCopy(&Var0, "EXT4", 8); break;

	case 21: StringCopy(&Var0, "FAN1", 8); break;

	case 22: StringCopy(&Var0, "FAN2", 8); break;

	case 23: StringCopy(&Var0, "FAN3", 8); break;

	case 24: StringCopy(&Var0, "HAO1", 8); break;

	case 25: StringCopy(&Var0, "HUN1", 8); break;

	case 26: StringCopy(&Var0, "HUN2", 8); break;

	case 27: StringCopy(&Var0, "JOS1", 8); break;

	case 28: StringCopy(&Var0, "JOS2", 8); break;

	case 29: StringCopy(&Var0, "JOS3", 8); break;

	case 30: StringCopy(&Var0, "JOS4", 8); break;

	case 31: StringCopy(&Var0, "MAU1", 8); break;

	case 32: StringCopy(&Var0, "MIN1", 8); break;

	case 33: StringCopy(&Var0, "MIN2", 8); break;

	case 34: StringCopy(&Var0, "MIN3", 8); break;

	case 35: StringCopy(&Var0, "MRS1", 8); break;

	case 36: StringCopy(&Var0, "MRS2", 8); break;

	case 37: StringCopy(&Var0, "NI1", 8); break;

	case 38: StringCopy(&Var0, "NI1A", 8); break;

	case 39: StringCopy(&Var0, "NI1B", 8); break;

	case 40: StringCopy(&Var0, "NI1C", 8); break;

	case 41: StringCopy(&Var0, "NI1D", 8); break;

	case 42: StringCopy(&Var0, "NI2", 8); break;

	case 43: StringCopy(&Var0, "NI3", 8); break;

	case 44: StringCopy(&Var0, "OME1", 8); break;

	case 45: StringCopy(&Var0, "OME2", 8); break;

	case 46: StringCopy(&Var0, "PA1", 8); break;

	case 47: StringCopy(&Var0, "PA2", 8); break;

	case 48: StringCopy(&Var0, "PA3", 8); break;

	case 49: StringCopy(&Var0, "PA3A", 8); break;

	case 50: StringCopy(&Var0, "PA3B", 8); break;

	case 51: StringCopy(&Var0, "PA4", 8); break;

	case 52: StringCopy(&Var0, "RAM1", 8); break;

	case 53: StringCopy(&Var0, "RAM2", 8); break;

	case 54: StringCopy(&Var0, "RAM3", 8); break;

	case 55: StringCopy(&Var0, "RAM4", 8); break;

	case 56: StringCopy(&Var0, "RAM5", 8); break;

	case 57: StringCopy(&Var0, "SAS1", 8); break;

	case 58: StringCopy(&Var0, "TON1", 8); break;

	case 59: StringCopy(&Var0, "TON2", 8); break;

	case 60: StringCopy(&Var0, "TON3", 8); break;

	case 61: StringCopy(&Var0, "TON4", 8); break;

	case 62: StringCopy(&Var0, "TON5", 8); break;

	default: break;
	}
	return Var0;
}

//Position - 0x11137
int func_199(char* sParam0, int iParam1)
{
	int iVar0;
	char *sVar1;
	int iVar33;
	int iVar34;

	iVar33 = gameplay::get_hash_key(sParam0);
	iVar34 = 0;
	iVar34 = 0;
	while (iVar34 < 63) {
		iVar0 = iVar34;
		func_200(iVar0, &sVar1);
		if (gameplay::get_hash_key(sVar1) == iVar33) {
			return iVar0;
		}
		iVar34++;
	}
	if (iParam1 == 0) {
	}
	return -1;
}

// Position - 0x11180
void func_200(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		func_201(uParam1, "Abigail1", func_203(iParam0), 0, 0, 4, -1604.668f, 5239.1f, 3.01f, 66, "", 109, 0,
				 "ambient_Diving", 0, 0, 1, 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 1:
		func_201(uParam1, "Abigail2", func_203(iParam0), 0, 0, 4, -1592.84f, 5214.04f, 3.01f, 400, "", 110, 0, "", 0, 0,
				 -1, 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 2:
		func_201(uParam1, "Barry1", func_203(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", 74, 0, "", 0, 1, -1,
				 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 3:
		func_201(uParam1, "Barry2", func_203(iParam0), 0, 1, 4, 190.26f, -956.35f, 29.63f, 381, "", -1, 0, "", 0, 1, -1,
				 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 4:
		func_201(uParam1, "Barry3", func_203(iParam0), 0, 1, 4, 414f, -761f, 29f, 381, "", -1, 0, "", 164, 1, -1, 0, 2,
				 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 5:
		func_201(uParam1, "Barry3A", func_203(iParam0), 1, 1, 0, 1199.27f, -1255.63f, 34.23f, 381, "BARSTASH", 84, 0,
				 "", 166, 0, 7, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 6:
		func_201(uParam1, "Barry3C", func_203(iParam0), 3, 1, 0, -468.9f, -1713.06f, 18.21f, 381, "", 84, 0, "", 166, 0,
				 7, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 7:
		func_201(uParam1, "Barry4", func_203(iParam0), 0, 1, 4, 237.65f, -385.41f, 44.4f, 381, "", 85, 0,
				 "postRC_Barry4", 0, 0, -1, 4, 2, 800, 2000, func_202(iParam0), 0, 0);
		break;

	case 8:
		func_201(uParam1, "Dreyfuss1", func_203(iParam0), 0, 2, 4, -1458.97f, 485.99f, 115.38f, 66, "LETTERS_HINT", 106,
				 0, "", 0, 0, -1, 4, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 9:
		func_201(uParam1, "Epsilon1", func_203(iParam0), 0, 3, 4, -1622.89f, 4204.87f, 83.3f, 66, "", 86, 0, "", 0, 1,
				 10, 4, 1, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 10:
		func_201(uParam1, "Epsilon2", func_203(iParam0), 0, 3, 4, 242.7f, 362.7f, 104.74f, 206, "", 87, 16, "", 0, 0,
				 11, 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 11:
		func_201(uParam1, "Epsilon3", func_203(iParam0), 0, 3, 4, 1835.53f, 4705.86f, 38.1f, 206, "", 88, 16, "epsCars",
				 0, 0, 12, 4, 1, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 12:
		func_201(uParam1, "Epsilon4", func_203(iParam0), 0, 3, 4, 1826.13f, 4698.88f, 38.92f, 206, "", 90, 16,
				 "postRC_Epsilon4", 0, 0, 13, 4, 1, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 13:
		func_201(uParam1, "Epsilon5", func_203(iParam0), 0, 3, 4, 637.02f, 119.7093f, 89.5f, 206, "", 89, 16,
				 "epsRobes", 0, 0, 14, 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 14:
		func_201(uParam1, "Epsilon6", func_203(iParam0), 0, 3, 4, -2892.93f, 3192.37f, 11.66f, 206, "", 93, 0, "", 0, 0,
				 15, 4, 1, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 15:
		func_201(uParam1, "Epsilon7", func_203(iParam0), 0, 3, 4, 524.43f, 3079.82f, 39.48f, 206, "", -1, 16,
				 "epsDesert", 0, 0, 16, 4, 1, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 16:
		func_201(uParam1, "Epsilon8", func_203(iParam0), 0, 3, 4, -697.75f, 45.38f, 43.03f, 206, "", 94, 16,
				 "epsilonTract", 0, 0, -1, 4, 1, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 17:
		func_201(uParam1, "Extreme1", func_203(iParam0), 0, 4, 4, -188.22f, 1296.1f, 302.86f, 66, "", -1, 0, "", 4, 1,
				 18, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 18:
		func_201(uParam1, "Extreme2", func_203(iParam0), 0, 4, 4, -954.19f, -2760.05f, 14.64f, 382, "", 96, 0, "", 171,
				 0, 19, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 19:
		func_201(uParam1, "Extreme3", func_203(iParam0), 0, 4, 4, -63.8f, -809.5f, 321.8f, 382, "", 97, 0, "", 0, 0, 20,
				 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 20:
		func_201(uParam1, "Extreme4", func_203(iParam0), 0, 4, 4, 1731.41f, 96.96f, 170.39f, 382, "", 98, 16, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 21:
		func_201(uParam1, "Fanatic1", func_203(iParam0), 0, 5, 4, -1877.82f, -440.649f, 45.05f, 405, "", 74, 0, "", 0,
				 1, -1, 4, 1, 700, 2000, func_202(iParam0), 1, 0);
		break;

	case 22:
		func_201(uParam1, "Fanatic2", func_203(iParam0), 0, 5, 4, 809.66f, 1279.76f, 360.49f, 405, "", -1, 0, "", 0, 1,
				 -1, 4, 4, 700, 2000, func_202(iParam0), 1, 0);
		break;

	case 23:
		func_201(uParam1, "Fanatic3", func_203(iParam0), 0, 5, 4, -915.6f, 6139.2f, 5.5f, 405, "", -1, 0, "", 0, 1, -1,
				 4, 2, 700, 2000, func_202(iParam0), 0, 1);
		break;

	case 24:
		func_201(uParam1, "Hao1", func_203(iParam0), 0, 6, 4, -72.29f, -1260.63f, 28.14f, 66, "", -1, 0,
				 "controller_Races", 13, 1, -1, 4, 2, 2000, 500, func_202(iParam0), 0, 1);
		break;

	case 25:
		func_201(uParam1, "Hunting1", func_203(iParam0), 0, 7, 4, 1804.32f, 3931.33f, 32.82f, 66, "", -1, 0, "", 174, 1,
				 26, 4, 4, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 26:
		func_201(uParam1, "Hunting2", func_203(iParam0), 0, 7, 4, -684.17f, 5839.16f, 16.09f, 384, "", 99, 0, "", 7, 0,
				 -1, 4, 4, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 27:
		func_201(uParam1, "Josh1", func_203(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 66, "", -1, 0, "forSaleSigns",
				 0, 1, 28, 4, 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 28:
		func_201(uParam1, "Josh2", func_203(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", 105, 0, "", 0, 0,
				 29, 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 29:
		func_201(uParam1, "Josh3", func_203(iParam0), 0, 8, 4, 565.39f, -1772.88f, 29.77f, 385, "", -1, 16, "", 0, 0,
				 30, 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 30:
		func_201(uParam1, "Josh4", func_203(iParam0), 0, 8, 4, -1104.93f, 291.25f, 64.3f, 385, "", -1, 36, "", 0, 0, -1,
				 4, 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 31:
		func_201(uParam1, "Maude1", func_203(iParam0), 0, 9, 4, 2726.1f, 4145f, 44.3f, 66, "", -1, 0,
				 "BailBond_Launcher", 0, 1, -1, 4, 4, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 32:
		func_201(uParam1, "Minute1", func_203(iParam0), 0, 10, 4, 327.85f, 3405.7f, 35.73f, 66, "", -1, 0, "", 0, 1, 33,
				 4, 4, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 33:
		func_201(uParam1, "Minute2", func_203(iParam0), 0, 10, 4, 18f, 4527f, 105f, 386, "", -1, 10, "", 0, 0, 34, 4, 4,
				 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 34:
		func_201(uParam1, "Minute3", func_203(iParam0), 0, 10, 4, -303.82f, 6211.29f, 31.05f, 386, "", -1, 10, "", 0, 0,
				 -1, 4, 4, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 35:
		func_201(uParam1, "MrsPhilips1", func_203(iParam0), 0, 11, 4, 1972.59f, 3816.43f, 32.42f, 66, "", -1, 0,
				 "ambient_MrsPhilips", 0, 1, -1, 4, 4, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 36:
		func_201(uParam1, "MrsPhilips2", func_203(iParam0), 0, 11, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 1, -1, 4, 4, 0,
				 2359, func_202(iParam0), 0, 0);
		break;

	case 37:
		func_201(uParam1, "Nigel1", func_203(iParam0), 0, 12, 4, -1097.16f, 790.01f, 164.52f, 66, "", -1, 0, "", 177, 1,
				 -1, 1, 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 38:
		func_201(uParam1, "Nigel1A", func_203(iParam0), 0, 12, 1, -558.65f, 284.49f, 90.86f, 149, "NIGITEMS", 100, 0,
				 "", 0, 0, 42, 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 39:
		func_201(uParam1, "Nigel1B", func_203(iParam0), 0, 12, 1, -1034.15f, 366.08f, 80.11f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_202(iParam0), 1, 1);
		break;

	case 40:
		func_201(uParam1, "Nigel1C", func_203(iParam0), 0, 12, 1, -623.91f, -266.17f, 37.76f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_202(iParam0), 1, 1);
		break;

	case 41:
		func_201(uParam1, "Nigel1D", func_203(iParam0), 0, 12, 1, -1096.85f, 67.68f, 52.95f, 149, "", 100, 0, "", 0, 0,
				 42, 4, 4, 700, 2000, func_202(iParam0), 1, 1);
		break;

	case 42:
		func_201(uParam1, "Nigel2", func_203(iParam0), 0, 12, 4, -1310.7f, -640.22f, 26.54f, 149, "", -1, 8, "", 0, 0,
				 43, 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 43:
		func_201(uParam1, "Nigel3", func_203(iParam0), 0, 12, 4, -44.75f, -1288.67f, 28.21f, 149, "", -1, 16,
				 "postRC_Nigel3", 0, 0, -1, 4, 4, 0, 2359, func_202(iParam0), 1, 1);
		break;

	case 44:
		func_201(uParam1, "Omega1", func_203(iParam0), 0, 13, 4, 2468.51f, 3437.39f, 49.9f, 66, "", -1, 0,
				 "spaceshipParts", 0, 1, 45, 4, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 45:
		func_201(uParam1, "Omega2", func_203(iParam0), 0, 13, 4, 2319.44f, 2583.58f, 46.76f, 387, "", 107, 0, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 46:
		func_201(uParam1, "Paparazzo1", func_203(iParam0), 0, 14, 4, -149.75f, 285.81f, 93.67f, 66, "", -1, 0, "", 0, 1,
				 47, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 47:
		func_201(uParam1, "Paparazzo2", func_203(iParam0), 0, 14, 4, -70.71f, 301.43f, 106.79f, 389, "", -1, 8, "", 0,
				 0, 48, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 48:
		func_201(uParam1, "Paparazzo3", func_203(iParam0), 0, 14, 4, -257.22f, 292.85f, 90.63f, 389, "", -1, 8, "", 183,
				 1, -1, 2, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 49:
		func_201(uParam1, "Paparazzo3A", func_203(iParam0), 0, 14, 2, 305.52f, 157.19f, 102.94f, 389, "PAPPHOTO", 102,
				 0, "", 0, 0, 51, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 50:
		func_201(uParam1, "Paparazzo3B", func_203(iParam0), 0, 14, 2, 1040.96f, -534.42f, 60.17f, 389, "", 102, 0, "",
				 0, 0, 51, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 51:
		func_201(uParam1, "Paparazzo4", func_203(iParam0), 0, 14, 4, -484.2f, 229.68f, 82.21f, 389, "", -1, 8, "", 0, 1,
				 -1, 4, 2, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 52:
		func_201(uParam1, "Rampage1", func_203(iParam0), 0, 15, 4, 908f, 3643.7f, 32.2f, 66, "", -1, 0, "", 0, 1, 54, 4,
				 4, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 54:
		func_201(uParam1, "Rampage3", func_203(iParam0), 0, 15, 4, 465.1f, -1849.3f, 27.8f, 84, "", -1, 0, "", 0, 1, 55,
				 4, 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 55:
		func_201(uParam1, "Rampage4", func_203(iParam0), 0, 15, 4, -161f, -1669.7f, 33f, 84, "", -1, 0, "", 0, 0, 56, 4,
				 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 56:
		func_201(uParam1, "Rampage5", func_203(iParam0), 0, 15, 4, -1298.2f, 2504.14f, 21.09f, 84, "", -1, 0, "", 0, 0,
				 53, 4, 4, 0, 2359, func_202(iParam0), 0, 0);
		break;

	case 53:
		func_201(uParam1, "Rampage2", func_203(iParam0), 0, 15, 4, 1181.5f, -400.1f, 67.5f, 84, "", -1, 0,
				 "rampage_controller", 0, 0, -1, 4, 4, 0, 2359, func_202(iParam0), 1, 0);
		break;

	case 57:
		func_201(uParam1, "TheLastOne", func_203(iParam0), 0, 16, 4, -1298.98f, 4640.16f, 105.67f, 66, "", 133, 1, "",
				 0, 1, -1, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 58:
		func_201(uParam1, "Tonya1", func_203(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 66, "AM_H_RCFS", -1, 0,
				 "ambient_TonyaCall", 24, 1, 59, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 59:
		func_201(uParam1, "Tonya2", func_203(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48,
				 "ambient_Tonya", 185, 0, 60, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	case 60:
		func_201(uParam1, "Tonya3", func_203(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 187, 0, 61, 4, 2, 0,
				 2359, func_202(iParam0), 0, 1);
		break;

	case 61:
		func_201(uParam1, "Tonya4", func_203(iParam0), 0, 17, 4, 0f, 0f, 0f, -1, "", -1, 0, "", 0, 0, 62, 4, 2, 0, 2359,
				 func_202(iParam0), 0, 1);
		break;

	case 62:
		func_201(uParam1, "Tonya5", func_203(iParam0), 0, 17, 4, -14.39f, -1472.69f, 29.58f, 388, "", -1, 48, "", 0, 0,
				 -1, 4, 2, 0, 2359, func_202(iParam0), 0, 1);
		break;

	default: break;
	}
}

// Position - 0x12335
void func_201(var *uParam0, char *sParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6, vector3 vParam7,
			  int iParam10, char *sParam11, int iParam12, int iParam13, char *sParam14, int iParam15, int iParam16,
			  int iParam17, int iParam18, int iParam19, int iParam20, int iParam21, int iParam22, int iParam23,
			  int iParam24) {
	uParam0->f_4 = iParam5;
	*uParam0 = sParam1;
	uParam0->f_1 = {Param2};
	uParam0->f_3 = iParam4;
	uParam0->f_5 = iParam6;
	uParam0->f_6 = {vParam7};
	uParam0->f_9 = iParam10;
	StringCopy(&uParam0->f_10, sParam11, 16);
	uParam0->f_14 = iParam12;
	uParam0->f_15 = iParam13;
	StringCopy(&uParam0->f_16, sParam14, 24);
	uParam0->f_22 = iParam15;
	uParam0->f_23 = iParam16;
	uParam0->f_24 = iParam17;
	uParam0->f_25 = iParam18;
	uParam0->f_26 = iParam19;
	uParam0->f_27 = iParam20;
	uParam0->f_28 = iParam21;
	uParam0->f_29 = iParam22;
	uParam0->f_30 = iParam23;
	uParam0->f_31 = iParam24;
}

// Position - 0x123C6
int func_202(int iParam0) {
	switch (iParam0) {
	case 0: return 0;

	case 1: return 0;

	case 2: return 1;

	case 3: return 1;

	case 4: return 0;

	case 5: return 1;

	case 6: return 1;

	case 7: return 0;

	case 8: return 1;

	case 9: return 0;

	case 10: return 0;

	case 11: return 0;

	case 12: return 1;

	case 13: return 0;

	case 14: return 1;

	case 15: return 0;

	case 16: return 1;

	case 17: return 1;

	case 18: return 1;

	case 19: return 1;

	case 20: return 1;

	case 21: return 1;

	case 22: return 1;

	case 23: return 1;

	case 24: return 1;

	case 25: return 1;

	case 26: return 1;

	case 27: return 0;

	case 28: return 1;

	case 29: return 1;

	case 30: return 1;

	case 31: return 0;

	case 32: return 1;

	case 33: return 1;

	case 34: return 1;

	case 35: return 0;

	case 36: return 0;

	case 37: return 0;

	case 38: return 1;

	case 39: return 1;

	case 40: return 1;

	case 41: return 1;

	case 42: return 1;

	case 43: return 1;

	case 44: return 0;

	case 45: return 0;

	case 46: return 1;

	case 47: return 1;

	case 48: return 0;

	case 49: return 1;

	case 50: return 1;

	case 51: return 1;

	case 52: return 1;

	case 54: return 1;

	case 55: return 1;

	case 56: return 1;

	case 53: return 1;

	case 57: return 1;

	case 58: return 1;

	case 59: return 1;

	case 60: return 1;

	case 61: return 1;

	case 62: return 1;

	default: break;
	}
	return 0;
}

// Position - 0x1270C
struct<2> func_203(int iParam0) {
	struct<2> Var0;
	char[] cVar2[8];

	StringCopy(&Var0, "", 8);
	cVar2 = {func_198(iParam0)};
	if (gameplay::is_string_null_or_empty(&cVar2)) {
	}
	else {
		StringCopy(&Var0, "RC_", 8);
		StringConCat(&Var0, &cVar2, 8);
	}
	return Var0;
}

//Position - 0x12743
int func_204(int iParam0)
{
	switch (iParam0) {
	case 69:
	case 70: return func_205(Global_101700.f_8044.f_99.f_205[10]);

	case 74:
	case 75: return func_205(Global_101700.f_8044.f_99.f_205[8]);

	case 84:
	case 85: return func_205(Global_101700.f_8044.f_99.f_205[11]);

	case 90: return func_205(Global_101700.f_8044.f_99.f_205[7]);

	case 93: return func_205(Global_101700.f_8044.f_99.f_205[9]);
	}
	return 0;
}

// Position - 0x127FF
int func_205(int iParam0) {
	switch (iParam0) {
	case 1:
	case 3:
	case 5:
	case 6:
	case 8: return 0;

	case 2:
	case 4:
	case 7:
	case 9: return 1;
	}
	return -1;
}

// Position - 0x12853
int func_206(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = gameplay::get_hash_key(sParam0);
	iVar1 = func_207(iVar0, 1);
	if (iVar1 == -1 && !iParam1) {
	}
	return iVar1;
}

// Position - 0x1287D
int func_207(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 94) {
		if (Global_82612[iVar0 /*34*/].f_6 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	if (!iParam1) {
	}
	return -1;
}

// Position - 0x128B3
void func_208(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x12B35
void func_209() {
	int iVar0;
	int iVar1;

	switch (iLocal_174) {
	case 0:
		func_144(1, sLocal_137, 0, 1, 0, 1);
		func_3(500);
		audio::request_script_audio_bank("HUD_321_GO", 0, -1);
		func_242(&Local_46.f_1, 8);
		func_242(&Local_46.f_1, 4);
		func_242(&Local_46.f_1, 2);
		func_242(&Local_46.f_1, 1);
		func_241();
		uLocal_2120 = func_240();
		func_239(&iLocal_1981, 1050253722, 1073741824);
		if (Global_101700.f_24032.f_2 < 2) {
			func_238("FM_IHELP_SLP", -1);
			Global_101700.f_24032.f_2++;
		}
		iLocal_174++;
		break;

	case 1:
		graphics::draw_scaleform_movie(Local_46, 0.5f, 0.5f, 1f, 1f, 255, 255, 255, 100, 0);
		if (func_232(&Local_46, 1, 0, 1, 3, 1, 0, 0)) {
			audio::stop_stream();
			func_231(&Local_46);
			iLocal_177 = gameplay::get_game_timer();
			iLocal_174++;
		}
		if (!Local_46.f_5) {
			if (func_230(Local_46.f_1, 8)) {
				Local_46.f_5 = 1;
				if (func_8(iLocal_2129)) {
					cam::_0x11FA5D3479C7DD47(entity::get_entity_model(iLocal_2129));
				}
				func_228(&Local_1963, 0, 1, 2000, 1, 0, 0, 1);
				cam::destroy_all_cams(0);
				if (func_8(player::get_players_last_vehicle())) {
					vehicle::set_vehicle_handbrake(player::get_players_last_vehicle(), 0);
				}
				ui::display_hud(1);
				ui::display_radar(1);
				audio::stop_audio_scene("RACE_INTRO_GENERIC");
				audio::set_frontend_radio_active(1);
				Local_46.f_7 = gameplay::get_game_timer();
				Local_1943.f_10 = Local_46.f_7;
				audio::start_audio_scene("STREET_RACE_DURING_RACE");
				iVar0 = 0;
				while (iVar0 <= 7) {
					Local_196[iVar0 /*50*/].f_43 = 1;
					audio::_dynamic_mixer_related_fn(Local_196[iVar0 /*50*/].f_5, "STREET_RACE_NPC_GENERAL", 0);
					iVar0++;
				}
			}
			else if (system::timera() > 2800 && iLocal_178 == 5) {
				if (cam::_0xEE778F8C7E1142E2(1) == 4) {
					if (!func_227(2, &iLocal_173)) {
						if (func_8(iLocal_2129)) {
							cam::_0x11FA5D3479C7DD47(entity::get_entity_model(iLocal_2129));
						}
						graphics::_start_screen_effect("CamPushInNeutral", 0, 0);
						audio::play_sound_frontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 1);
						func_226(2, &iLocal_173);
					}
				}
			}
		}
		break;

	case 2:
		iVar1 = 0;
		iVar0 = 0;
		while (iVar0 <= 7) {
			if (Local_196[iVar0 /*50*/].f_17.f_13) {
				iVar1++;
			}
			iVar0++;
		}
		if (iVar1 == 8) {
			if (iLocal_179 == 0) {
				iLocal_179 = gameplay::get_game_timer();
			}
		}
		if (Local_1943.f_13) {
			Local_46.f_6 = 1;
			Local_1943.f_7 = Local_1943.f_6;
			func_225(&Local_1943);
			iLocal_174++;
		}
		if (iLocal_179 != 0 && gameplay::get_game_timer() > iLocal_179 + 30000) {
			func_224(3);
			sLocal_180 = "CRACEFAIL1";
		}
		if (func_223(player::player_ped_id())) {
			if (iLocal_2133 < 0) {
				iLocal_2133 = gameplay::get_game_timer() + gameplay::get_random_int_in_range(2500, 5000);
			}
			else if (gameplay::get_game_timer() > iLocal_2133) {
				audio::play_sound_from_entity(iLocal_2134, "DISTANT_RACERS", Local_196[func_220() /*50*/].f_5,
											  "ROAD_RACE_SOUNDSET", 0, 0);
				iLocal_2133 = -1;
			}
		}
		else if (iLocal_2133 > 0) {
			iLocal_2133 = -1;
		}
		func_213(Local_1943);
		func_210();
		break;

	case 3:
		audio::stop_audio_scene("STREET_RACE_DURING_RACE");
		func_224(2);
		break;
	}
}

// Position - 0x12E42
void func_210() {
	if (Local_46.f_5 && !Local_46.f_6) {
		if (controls::is_control_pressed(2, 190)) {
			if (gameplay::get_game_timer() > iLocal_177 + 500) {
				func_212(gameplay::get_game_timer() - iLocal_177 - 500, 3000, "CRACEQUIT", 6, 0, 10, -1f, -1f, 0, 1, 0,
						 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, -1);
				if (gameplay::get_game_timer() > iLocal_177 + 3500) {
					func_211("CRACEFAIL1");
				}
			}
		}
		else {
			iLocal_177 = gameplay::get_game_timer();
		}
	}
}

// Position - 0x12EBA
void func_211(char *sParam0) {
	func_224(3);
	sLocal_180 = sParam0;
}

// Position - 0x12ECB
void func_212(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, float fParam6,
			  float fParam7, int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13,
			  int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, int iParam19, int iParam20,
			  int iParam21, int iParam22, int iParam23) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_111(0, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_110(0, iVar0);
		Global_1354542.f_1009[iVar0] = iParam0;
		Global_1354542.f_1009.f_11[iVar0] = iParam1;
		StringCopy(&Global_1354542.f_1009.f_22[iVar0 /*16*/], sParam2, 64);
		Global_1354542.f_1009.f_194[iVar0] = iParam3;
		Global_1354542.f_1009.f_183[iVar0] = iParam4;
		Global_1354542.f_1009.f_216[iVar0] = iParam5;
		Global_1354542.f_1009.f_227[iVar0 /*3*/] = fParam6;
		Global_1354542.f_1009.f_227[iVar0 /*3*/].f_1 = fParam7;
		Global_1354542.f_1009.f_258[iVar0] = iParam8;
		Global_1354542.f_1009.f_269[iVar0] = iParam9;
		Global_1354542.f_1009.f_312[iVar0] = iParam10;
		Global_1354542.f_1009.f_323[iVar0] = iParam11;
		Global_1354542.f_1009.f_334[iVar0] = iParam12;
		Global_1354542.f_1009.f_345[iVar0] = iParam13;
		Global_1354542.f_1004 = 1;
		Global_1354542.f_1009.f_356[iVar0] = iParam14;
		Global_1354542.f_1009.f_367[iVar0] = iParam15;
		Global_1354542.f_1009.f_378[iVar0] = iParam16;
		Global_1354542.f_1009.f_389[iVar0] = iParam17;
		Global_1354542.f_1009.f_400[iVar0] = iParam18;
		Global_1354542.f_1009.f_411[iVar0] = iParam19;
		Global_1354542.f_1009.f_422[iVar0] = iParam20;
		Global_1354542.f_1009.f_433[iVar0] = iParam21;
		Global_1354542.f_1009.f_444[iVar0] = iParam22;
		Global_1354542.f_1009.f_455[iVar0] = iParam23;
	}
}

// Position - 0x13094
void func_213(struct<5> Param0, var uParam5, var uParam6, var uParam7, var uParam8, var uParam9, var uParam10,
			  var uParam11, var uParam12, var uParam13, var uParam14, var uParam15, var uParam16, var uParam17,
			  var uParam18, var uParam19) {
	int iVar0;
	vector3 vVar1;
	int iVar4;
	int iVar5;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	int iVar15;

	if (func_219(player::player_ped_id())) {
		ped::set_ped_reset_flag(player::player_ped_id(), 272, 1);
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			ai::waypoint_recording_get_closest_waypoint(Local_54.f_64,
														entity::get_entity_coords(player::player_ped_id(), 1), &iVar0);
			ai::waypoint_recording_get_coord(Local_54.f_64, iVar0, &vVar1);
			if (!vehicle::is_vehicle_driveable(player::get_players_last_vehicle(), 0)) {
				iLocal_122 = 1;
				iLocal_125 = 3;
			}
			if (!func_218("CRACESTUCK")) {
				if (entity::is_entity_in_water(player::get_players_last_vehicle())) {
					func_217("CRACESTUCK");
					iLocal_123 = gameplay::get_game_timer() + 1000;
				}
				if (vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 2,
													   15000) ||
					vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 3,
													   30000) ||
					vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0,
													   10000) ||
					vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 1,
													   3000)) {
					func_217("CRACESTUCK");
					iLocal_123 = gameplay::get_game_timer() + 1000;
				}
				if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), vVar1) > 900f) {
					func_217("CRACESTUCK");
					iLocal_123 = gameplay::get_game_timer() + 1000;
				}
			}
			else if (gameplay::get_game_timer() > iLocal_123) {
				if (!entity::is_entity_in_water(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0)) &&
					!vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 2,
														15000) &&
					!vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 3,
														30000) &&
					!vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0,
														10000) &&
					!vehicle::is_vehicle_stuck_timer_up(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 1,
														3000) &&
					system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), vVar1) < 400f) {
					ui::clear_help(1);
				}
			}
		}
	}
	if (controls::is_control_pressed(0, 75) || controls::is_disabled_control_pressed(0, 75) || iLocal_122 == 1) {
		switch (iLocal_125) {
		case 0:
			iLocal_124 = gameplay::get_game_timer();
			iLocal_125 = 1;
			break;

		case 1:
			if (gameplay::get_game_timer() - iLocal_124 > 500) {
				iLocal_124 = gameplay::get_game_timer();
				iLocal_125 = 2;
			}
			break;

		case 2:
			func_212(gameplay::get_game_timer() - iLocal_124, 1500, "RACES_RMETER", 6, 0, 10, -1f, -1f, 0, 1, 0, 0, 0,
					 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, -1);
			if (gameplay::get_game_timer() - iLocal_124 >= 1500) {
				controls::disable_control_action(0, 75, 1);
				iLocal_125 = 3;
			}
			break;

		case 3:
			if (entity::does_entity_exist(player::get_players_last_vehicle())) {
				if (Param0.f_4 > 0) {
					vVar12 = {Local_54[Param0.f_4 - 1 /*3*/]};
				}
				else {
					vVar12 = {Local_54[5 /*3*/]};
				}
				ai::waypoint_recording_get_closest_waypoint(Local_54.f_64, vVar12, &iVar4);
				iVar5 = iVar4 + 1;
				ai::waypoint_recording_get_num_points(Local_54.f_64, &iVar15);
				if (iVar5 >= iVar15) {
					iVar5 = 0;
				}
				ai::waypoint_recording_get_coord(Local_54.f_64, iVar4, &vVar6);
				ai::waypoint_recording_get_coord(Local_54.f_64, iVar5, &vVar9);
				if (!vehicle::is_any_vehicle_near_point(vVar6, 5f) ||
					func_216(player::get_players_last_vehicle(), vVar6, 1) < 5f) {
					func_215(500);
					func_23(player::get_players_last_vehicle(), vVar6, func_214(vVar6, vVar9), 0, 1);
					vehicle::set_vehicle_fixed(player::get_players_last_vehicle());
					if (!ped::is_ped_in_vehicle(player::player_ped_id(), player::get_players_last_vehicle(), 0)) {
						ped::set_ped_into_vehicle(player::player_ped_id(), player::get_players_last_vehicle(), -1);
					}
					cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
					cam::set_gameplay_cam_relative_heading(0f);
					if (func_218("CRACESTUCK")) {
						ui::clear_help(1);
					}
					func_3(500);
					iLocal_125 = 4;
				}
			}
			break;

		case 4:
			if (!controls::is_control_pressed(0, 75) && !controls::is_disabled_control_pressed(0, 75)) {
				controls::enable_control_action(0, 75, 1);
				iLocal_124 = -1;
				iLocal_122 = 0;
				iLocal_125 = 0;
			}
			break;
		}
	}
	else {
		iLocal_124 = -1;
		iLocal_122 = 0;
		iLocal_125 = 0;
	}
}

// Position - 0x1343B
float func_214(struct<2> Param0, Vector3 vParam2, struct<2> Param3, Vector3 vParam5) {
	return gameplay::get_heading_from_vector_2d(Param3 - Param0, Param3.f_1 - Param0.f_1);
}

// Position - 0x13455
void func_215(int iParam0) {
	if (cam::is_screen_faded_in()) {
		if (!cam::is_screen_fading_out()) {
			cam::do_screen_fade_out(iParam0);
			while (!cam::is_screen_faded_out()) {
				ped::set_ped_density_multiplier_this_frame(0f);
				vehicle::set_vehicle_density_multiplier_this_frame(0f);
				ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
				system::wait(0);
			}
		}
	}
}

// Position - 0x13492
float func_216(int iParam0, vector3 vParam1, int iParam4) {
	vector3 vVar0;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vParam1, iParam4);
}

// Position - 0x134CC
void func_217(char *sParam0) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 1, 1, -1);
}

// Position - 0x134E2
bool func_218(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x134F5
bool func_219(int iParam0) {
	if (func_8(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x13515
int func_220() {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar1 = 0f;
	fVar2 = 1E+10f;
	iVar0 = 0;
	while (iVar0 <= 7) {
		if (func_222(Local_196[iVar0 /*50*/].f_5)) {
			fVar1 = func_221(player::player_ped_id(), Local_196[iVar0 /*50*/].f_5, 1);
			if (fVar1 < fVar2) {
				fVar2 = fVar1;
				iVar3 = iVar0;
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x1356D
var func_221(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x135CB
bool func_222(int iParam0) {
	if (func_8(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (!fire::is_entity_on_fire(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x135F5
bool func_223(int iParam0) {
	float fVar0;

	if (!ped::is_ped_injured(iParam0)) {
		fVar0 = entity::get_entity_speed(iParam0);
		if (fVar0 > -0.5f && fVar0 < 0.5f) {
			return true;
		}
	}
	return false;
}

// Position - 0x1362C
void func_224(int iParam0) {
	iLocal_174 = 0;
	iLocal_1975 = iParam0;
}

// Position - 0x1363C
void func_225(var *uParam0) {
	if (ui::does_blip_exist(uParam0->f_14)) {
		ui::remove_blip(&uParam0->f_14);
	}
	if (ui::does_blip_exist(uParam0->f_15)) {
		ui::remove_blip(&uParam0->f_15);
	}
	if (uParam0->f_16 != 0) {
		graphics::delete_checkpoint(uParam0->f_16);
	}
	if (uParam0->f_17 != 0) {
		graphics::delete_checkpoint(uParam0->f_17);
	}
}

// Position - 0x1368A
void func_226(int iParam0, int *iParam1) { gameplay::set_bit(iParam1, iParam0); }

// Position - 0x1369A
bool func_227(int iParam0, int iParam1) { return gameplay::is_bit_set(*iParam1, iParam0); }

// Position - 0x136AB
void func_228(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	int iVar0;

	if (iParam4 == 1) {
		player::set_player_control(player::player_id(), player::is_player_control_on(player::player_id()), 64);
	}
	if (!cutscene::is_cutscene_playing()) {
		player::set_player_control(player::player_id(), !iParam1, 0);
	}
	if (iParam7) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			ped::remove_ped_helmet(player::player_ped_id(), 1);
		}
	}
	if (!iParam1 && iParam6) {
		cam::_0xC819F3CBB62BF692(0, 0, 3, 0);
	}
	else {
		cam::render_script_cams(iParam1, iParam2, iParam3, 1, 0, 0);
	}
	if (iParam1) {
		ui::clear_help(1);
	}
	else {
		if (cam::does_cam_exist(uParam0->f_4)) {
			if (cam::is_cam_active(uParam0->f_4)) {
				cam::set_cam_active(uParam0->f_4, 0);
			}
			cam::destroy_cam(uParam0->f_4, 1);
		}
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			entity::set_entity_visible(player::player_ped_id(), 1, 0);
		}
		iVar0 = player::get_players_last_vehicle();
		if (entity::does_entity_exist(iVar0)) {
			entity::set_entity_visible(iVar0, 1, 0);
		}
		audio::release_named_script_audio_bank("TIME_LAPSE");
		if (audio::is_audio_scene_active("TOD_SHIFT_SCENE")) {
			audio::stop_sound(uParam0->f_10);
			audio::release_named_script_audio_bank("TIME_LAPSE");
			audio::stop_audio_scene("TOD_SHIFT_SCENE");
		}
	}
	func_135(iParam1, 1, 0, 0);
	func_229();
	if (!iParam1 && iParam5) {
		if (uParam0->f_5) {
			time::set_clock_time(uParam0->f_7, 0, 0);
		}
		else {
			time::set_clock_time(uParam0->f_8, 0, 0);
		}
	}
	if (!iParam1) {
		if (cam::is_screen_faded_out()) {
			cam::do_screen_fade_in(250);
		}
	}
	if (!iParam1) {
		if (Global_101700.f_31389.f_4801 != -15) {
			Global_101700.f_31389.f_4801 = func_186();
		}
	}
}

// Position - 0x1381C
void func_229() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 35) {
		ui::_remove_notification(Global_101700.f_13100[iVar0 /*104*/].f_16);
		iVar0++;
	}
}

// Position - 0x13848
bool func_230(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x13857
void func_231(int *iParam0) {
	graphics::set_scaleform_movie_as_no_longer_needed(iParam0);
	audio::release_script_audio_bank();
}

// Position - 0x13869
bool func_232(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7) {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	var uVar8;
	int iVar9;
	bool bVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	var uVar14;

	if (iParam7) {
		func_237(&iParam0->f_2, 1);
	}
	if (!func_41(&iParam0->f_2)) {
		func_26(&iParam0->f_2);
	}
	graphics::_set_2d_layer(1);
	graphics::draw_scaleform_movie(*iParam0, 0.5f, 0.5f, 1f, 1f, 255, 255, 255, 100, 0);
	if (iParam4 > 3) {
		iParam4 = 3;
	}
	else if (iParam4 < 0) {
		iParam4 = 0;
	}
	if (iParam5) {
		sVar0 = "3_2_1";
		sVar1 = "GO";
		sVar2 = "HUD_MINI_GAME_SOUNDSET";
	}
	else {
		sVar0 = "3_2_1";
		sVar1 = "GO";
		sVar2 = "321_GO_LOW_VOL_SOUNDSET";
	}
	if (iParam7) {
		if (func_41(&iParam0->f_2)) {
			if (func_37(&iParam0->f_2)) {
				fVar3 = iParam0->f_2.f_2;
			}
			else {
				fVar3 = func_28(1) - iParam0->f_2.f_1;
				if (fVar3 < 0f) {
					fVar3 = 0f;
					func_39(&iParam0->f_2);
					if (func_230(iParam0->f_1, 1)) {
						func_235(&iParam0->f_1, 8);
						ui::get_hud_colour(18, &iVar5, &iVar6, &iVar7, &uVar8);
						graphics::_push_scaleform_movie_function(*iParam0, "SET_MESSAGE");
						func_50("CNTDWN_GO");
						graphics::_push_scaleform_movie_function_parameter_int(iVar5);
						graphics::_push_scaleform_movie_function_parameter_int(iVar6);
						graphics::_push_scaleform_movie_function_parameter_int(iVar7);
						graphics::_push_scaleform_movie_function_parameter_bool(1);
						graphics::_pop_scaleform_movie_function_void();
						return true;
					}
					func_26(&iParam0->f_2);
				}
			}
		}
		else {
			fVar3 = iParam0->f_2.f_1;
		}
		iVar4 = system::floor(fVar3);
	}
	else {
		iVar4 = system::floor(func_36(&iParam0->f_2));
	}
	iVar9 = iVar4 - iParam4;
	bVar10 = false;
	if (!func_230(iParam0->f_1, 8)) {
		if (iVar9 >= -3 && !func_230(iParam0->f_1, 1)) {
			func_235(&iParam0->f_1, 1);
			audio::play_sound_frontend(-1, sVar0, sVar2, 1);
			func_234(iParam0, iVar9);
		}
		else if (iVar9 >= -2 && !func_230(iParam0->f_1, 2)) {
			func_235(&iParam0->f_1, 2);
			audio::play_sound_frontend(-1, sVar0, sVar2, 1);
			func_234(iParam0, iVar9);
		}
		else if (iVar9 >= -1 && !func_230(iParam0->f_1, 4)) {
			func_235(&iParam0->f_1, 4);
			audio::play_sound_frontend(-1, sVar0, sVar2, 1);
			func_234(iParam0, iVar9);
		}
		else if (iVar9 >= -1 && !func_230(iParam0->f_1, 16)) {
			if (gameplay::absf(func_36(&iParam0->f_2) - IntToFloat(iParam4)) < 0.65f) {
				if (iParam5 || iParam6) {
					func_235(&iParam0->f_1, 16);
					audio::play_sound_frontend(-1, sVar1, sVar2, 1);
				}
			}
		}
		else if (iVar9 >= 0 && !func_230(iParam0->f_1, 8)) {
			if (!iParam5 && !iParam6) {
				audio::play_sound_frontend(-1, sVar1, sVar2, 1);
			}
			func_235(&iParam0->f_1, 8);
			ui::get_hud_colour(18, &iVar11, &iVar12, &iVar13, &uVar14);
			graphics::_push_scaleform_movie_function(*iParam0, "SET_MESSAGE");
			func_50("CNTDWN_GO");
			graphics::_push_scaleform_movie_function_parameter_int(iVar11);
			graphics::_push_scaleform_movie_function_parameter_int(iVar12);
			graphics::_push_scaleform_movie_function_parameter_int(iVar13);
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_pop_scaleform_movie_function_void();
			if (!iParam1) {
				bVar10 = true;
			}
		}
	}
	else if (iVar9 == 1) {
		bVar10 = true;
	}
	if (iParam2 && func_233() || iVar4 > 5) {
		bVar10 = true;
	}
	if (bVar10) {
		if (iParam3) {
			iParam0->f_1 = 0;
			func_39(&iParam0->f_2);
		}
		return true;
	}
	return false;
}

// Position - 0x13B8A
int func_233() {
	if (ui::is_pause_menu_active()) {
		return 0;
	}
	if (controls::is_control_pressed(0, 18) || controls::is_control_pressed(2, 18)) {
		return 1;
	}
	return 0;
}

// Position - 0x13BBC
void func_234(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;

	ui::get_hud_colour(12, &iVar0, &iVar1, &iVar2, &uVar3);
	graphics::_push_scaleform_movie_function(*uParam0, "SET_MESSAGE");
	ui::_set_notification_color_next(-1);
	graphics::begin_text_command_scaleform_string("NUMBER");
	ui::add_text_component_integer(gameplay::absi(iParam1));
	graphics::end_text_command_scaleform_string();
	graphics::_push_scaleform_movie_function_parameter_int(iVar0);
	graphics::_push_scaleform_movie_function_parameter_int(iVar1);
	graphics::_push_scaleform_movie_function_parameter_int(iVar2);
	graphics::_push_scaleform_movie_function_parameter_bool(1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x13C14
void func_235(var *uParam0, int iParam1) { func_236(uParam0, iParam1); }

// Position - 0x13C24
void func_236(var *uParam0, var uParam1) { *uParam0 |= uParam1; }

// Position - 0x13C35
void func_237(int *iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(iParam0, 4);
	}
	else {
		gameplay::clear_bit(iParam0, 4);
	}
	if (gameplay::is_bit_set(*iParam0, 4)) {
	}
}

// Position - 0x13C61
void func_238(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x13C78
void func_239(int *iParam0, int iParam1, int iParam2) {
	if (func_41(&iParam0->f_1)) {
		func_39(&iParam0->f_1);
	}
	if (func_41(&iParam0->f_4)) {
		func_39(&iParam0->f_4);
	}
	func_29(&iParam0->f_10);
	iParam0->f_134 = iParam1;
	iParam0->f_135 = iParam2;
	iParam0->f_137 = 1;
	iParam0->f_136 = 0;
	*iParam0 = 0;
}

// Position - 0x13CC8
var func_240() { return unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE"); }

// Position - 0x13CD8
void func_241() {
	iLocal_2134 = audio::get_sound_id();
	iLocal_2133 = -1;
}

// Position - 0x13CEB
void func_242(int *iParam0, int iParam1) { func_243(iParam0, iParam1); }

// Position - 0x13CFB
void func_243(int *iParam0, var uParam1) { *iParam0 -= (*iParam0 & uParam1); }

// Position - 0x13D10
void func_244() {
	int iVar0;

	switch (iLocal_174) {
	case 0:
		func_144(0, sLocal_136, 0, 1, 0, 1);
		iLocal_178 = 0;
		iLocal_174++;
		break;

	case 1:
		if (func_245()) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
			entity::set_entity_invincible(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0);
			iVar0 = 0;
			while (iVar0 <= 7) {
				if (func_8(Local_196[iVar0 /*50*/])) {
					entity::set_entity_invincible(Local_196[iVar0 /*50*/], 0);
				}
				if (func_8(Local_196[iVar0 /*50*/].f_5)) {
					entity::set_entity_invincible(Local_196[iVar0 /*50*/].f_5, 0);
				}
				iVar0++;
			}
			func_3(500);
			iLocal_174++;
		}
		else if (func_227(0, &iLocal_173)) {
			func_21(&Local_46);
			ai::request_waypoint_recording(Local_54.f_64);
			func_12(197, 1, 0, 1, 0);
			audio::load_stream("STOCK_RACE_INTRO", "ROAD_RACE_SOUNDSET");
			iVar0 = 0;
			while (iVar0 <= 7) {
				if (func_8(Local_196[iVar0 /*50*/])) {
					entity::set_entity_invincible(Local_196[iVar0 /*50*/], 1);
				}
				if (func_8(Local_196[iVar0 /*50*/].f_5)) {
					entity::set_entity_invincible(Local_196[iVar0 /*50*/].f_5, 1);
				}
				iVar0++;
			}
			if (!entity::does_entity_exist(iLocal_2129)) {
				if (!cam::is_sphere_visible(entity::get_entity_coords(player::player_ped_id(), 1), 2f) &&
					!cam::is_sphere_visible(Local_54.f_26[8 /*3*/], 2f)) {
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						iLocal_2129 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
						entity::set_entity_as_mission_entity(iLocal_2129, 1, 0);
						func_23(iLocal_2129, Local_54.f_26[8 /*3*/] + vLocal_181, Local_54.f_54[8], 0, 1);
					}
					else {
						streaming::request_model(joaat("gauntlet"));
						if (streaming::has_model_loaded(joaat("gauntlet"))) {
							iLocal_2129 = vehicle::create_vehicle(
								joaat("gauntlet"), Local_54.f_26[8 /*3*/] + vLocal_181, Local_54.f_54[8], 1, 1);
						}
					}
					if (func_8(iLocal_2129)) {
						vehicle::set_vehicle_fixed(iLocal_2129);
					}
				}
			}
			else if (func_8(iLocal_2129)) {
				if (!ped::is_ped_sitting_in_vehicle(player::player_ped_id(), iLocal_2129)) {
					ped::set_ped_into_vehicle(player::player_ped_id(), iLocal_2129, -1);
				}
				if (vehicle::get_vehicle_door_lock_status(iLocal_2129) != 4) {
					vehicle::set_vehicle_doors_locked(iLocal_2129, 4);
				}
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			}
		}
		break;

	case 2: func_224(1); break;
	}
}

// Position - 0x13F48
bool func_245() {
	bool bVar0;
	int iVar1;

	switch (iLocal_178) {
	case 0:
		if (audio::request_ambient_audio_bank("TIME_LAPSE", 0, -1)) {
			Local_1963.f_4 = cam::create_cam("DEFAULT_SPLINE_CAMERA", 0);
			cam::add_cam_spline_node(Local_1963.f_4, 2002.693f, 3097.819f, 50.8232f, 5.4256f, 0.0276f, -170.9332f,
									 10000, 0, 2);
			cam::add_cam_spline_node(Local_1963.f_4, 2002.818f, 3097.488f, 48.0966f, 7.3944f, 0.0276f, -159.5117f,
									 10000, 0, 2);
			cam::set_cam_fov(Local_1963.f_4, 40f);
			cam::set_cam_active(Local_1963.f_4, 1);
			audio::play_sound_frontend(-1, "TIME_LAPSE_MASTER", 0, 1);
			func_228(&Local_1963, 1, 0, 2000, 1, 0, 0, 1);
			gameplay::clear_area(entity::get_entity_coords(player::player_ped_id(), 1), 1000f, 1, 0, 0, 0);
			ui::display_hud(0);
			ui::display_radar(0);
			system::settimera(0);
			func_226(0, &iLocal_173);
			switch (func_42()) {
			case 0: graphics::_start_screen_effect("MinigameEndMichael", 5000, 0); break;

			case 1: graphics::_start_screen_effect("MinigameEndFranklin", 5000, 0); break;

			case 2: graphics::_start_screen_effect("MinigameEndTrevor", 5000, 0); break;
			}
			iLocal_178++;
		}
		break;

	case 1:
		if (func_251(func_267(), 0, "", "", &Local_1963, -1082130432, 0, 1, 1065353216)) {
			audio::release_ambient_audio_bank();
			system::settimera(0);
			iLocal_178++;
		}
		break;

	case 2:
		if (system::timera() > 1500) {
			if (func_8(iLocal_2129)) {
				ai::task_vehicle_drive_to_coord(player::player_ped_id(), iLocal_2129, Local_54.f_26[5 /*3*/], 0.95f, 0,
												entity::get_entity_model(iLocal_2129), 786469, 3.5f, -1f);
				audio::set_radio_to_station_name("RADIO_01_CLASS_ROCK");
			}
			if (audio::is_audio_scene_active("TOD_SHIFT_SCENE")) {
				audio::stop_sound(Local_1963.f_10);
				audio::release_named_script_audio_bank("TIME_LAPSE");
				audio::stop_audio_scene("TOD_SHIFT_SCENE");
			}
			audio::_0x774BD811F656A122("RADIO_01_CLASS_ROCK", 1);
			iVar1 = 0;
			while (iVar1 <= 7) {
				if (func_8(Local_196[iVar1 /*50*/].f_5)) {
					vehicle::_set_vehicle_lights_mode(Local_196[iVar1 /*50*/].f_5, 3);
				}
				iVar1++;
			}
			if (func_250()) {
				vLocal_184 = {-0.7054f, 6.3148f, 2.0821f};
				vLocal_187 = {0.9495f, 3.9011f, 2.7419f};
				vLocal_190 = {-0.567f, 2.6724f, 1.2077f};
				vLocal_193 = {0.094f, -0.2423f, 0.7483f};
			}
			else if (func_249()) {
				vLocal_184 = {-1.6831f, 6.0271f, 4.2228f};
				vLocal_187 = {-0.0245f, 3.5705f, 4.6855f};
				vLocal_190 = {-1.0281f, 4.6872f, 1.1868f};
				vLocal_193 = {-0.185f, 1.8112f, 1.1221f};
			}
			else {
				vLocal_184 = {-1.5802f, 5.8398f, 2.2274f};
				vLocal_187 = {0.197f, 3.5006f, 2.8356f};
				vLocal_190 = {-0.6678f, 1.974f, 0.8876f};
				vLocal_193 = {0.144f, -0.9013f, 0.417f};
			}
			iLocal_2125 = cam::create_cam("DEFAULT_SCRIPTED_CAMERA", 0);
			cam::set_cam_fov(iLocal_2125, 40f);
			cam::attach_cam_to_entity(iLocal_2125, iLocal_2129, vLocal_184, 1);
			cam::point_cam_at_entity(iLocal_2125, iLocal_2129, vLocal_187, 1);
			iLocal_2126 = cam::create_cam("DEFAULT_SCRIPTED_CAMERA", 0);
			cam::set_cam_fov(iLocal_2126, 40f);
			cam::attach_cam_to_entity(iLocal_2126, iLocal_2129, vLocal_190, 1);
			cam::point_cam_at_entity(iLocal_2126, iLocal_2129, vLocal_193, 1);
			cam::set_cam_active(iLocal_2125, 1);
			cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 4000, 1, 1);
			cam::render_script_cams(1, 0, 0, 1, 0, 0);
			cam::shake_cam(iLocal_2125, "ROAD_VIBRATION_SHAKE", 0.5f);
			cam::shake_cam(iLocal_2126, "ROAD_VIBRATION_SHAKE", 0.5f);
			system::settimera(0);
			audio::start_audio_scene("RACE_INTRO_GENERIC");
			if (audio::load_stream("STOCK_RACE_INTRO", "ROAD_RACE_SOUNDSET")) {
				audio::play_stream_frontend();
			}
			iLocal_178++;
		}
		break;

	case 3:
		if (system::timera() > 6000) {
			cam::destroy_all_cams(0);
			iLocal_2125 = cam::create_camera_with_params(26379945, 1960.154f, 3125.919f, 47.8242f, -2.4987f, 0.0002f,
														 -95.2875f, 25f, 0, 2);
			iLocal_2126 = cam::create_camera_with_params(26379945, 1963.017f, 3129.43f, 47.481f, -3.0689f, 0.0002f,
														 -114.3019f, 25f, 0, 2);
			cam::set_cam_active(iLocal_2125, 1);
			cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 7000, 0, 1);
			cam::shake_cam(iLocal_2125, "HAND_SHAKE", 0.1f);
			cam::shake_cam(iLocal_2126, "HAND_SHAKE", 0.1f);
			system::settimera(0);
			iLocal_178++;
		}
		break;

	case 4:
		if (system::timera() > 4900) {
			if (func_248(player::player_ped_id(), -1817882002, 1)) {
				ai::clear_ped_tasks(player::player_ped_id());
				if (func_8(iLocal_2129)) {
					vehicle::set_vehicle_handbrake(iLocal_2129, 1);
				}
				player::set_player_control(player::player_id(), 1, 0);
			}
		}
		if (system::timera() > 7000) {
			cam::destroy_all_cams(0);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			iLocal_2125 = cam::create_camera_with_params(26379945, 1990.664f, 3113.482f, 47.1558f, 0.8047f, 0.0484f,
														 56.7722f, 50f, 1, 2);
			iLocal_2126 =
				cam::create_camera_with_params(26379945, cam::get_gameplay_cam_coord(), cam::get_gameplay_cam_rot(2),
											   cam::get_gameplay_cam_fov(), 0, 2);
			cam::set_cam_active_with_interp(iLocal_2126, iLocal_2125, 4000, 3, 1);
			system::settimera(0);
			iLocal_178++;
		}
		break;

	case 5: return true;

	case 6:
		if (system::timera() > 3000) {
			bVar0 = true;
			iVar1 = 0;
			while (iVar1 <= 7) {
				if (!entity::does_entity_exist(Local_196[iVar1 /*50*/])) {
					bVar0 = false;
				}
				iVar1++;
			}
			if (!entity::does_entity_exist(iLocal_2129)) {
				bVar0 = false;
			}
			if (bVar0) {
				func_228(&Local_1963, 0, 0, 2000, 1, 0, 0, 1);
				if (audio::is_audio_scene_active("TOD_SHIFT_SCENE")) {
					audio::stop_sound(Local_1963.f_10);
					audio::release_named_script_audio_bank("TIME_LAPSE");
					audio::stop_audio_scene("TOD_SHIFT_SCENE");
				}
				audio::set_radio_to_station_name("RADIO_01_CLASS_ROCK");
				audio::_0x774BD811F656A122("RADIO_01_CLASS_ROCK", 1);
				audio::start_audio_scene("RACE_INTRO_GENERIC");
				cam::destroy_all_cams(0);
				audio::stop_stream();
				return true;
			}
		}
		break;
	}
	if (func_246(1000)) {
		func_215(500);
		time::set_clock_time(func_267(), 0, 0);
		system::settimera(0);
		if (func_8(iLocal_2129)) {
			vehicle::set_vehicle_handbrake(iLocal_2129, 1);
			ai::clear_ped_tasks(player::player_ped_id());
			func_23(iLocal_2129, Local_54.f_26[8 /*3*/], Local_54.f_54[8], 1, 1);
			vehicle::set_vehicle_on_ground_properly(iLocal_2129, 1084227584);
		}
		iLocal_178 = 6;
	}
	return false;
}

// Position - 0x145D4
bool func_246(int iParam0) {
	if (cam::is_screen_faded_in()) {
		if (gameplay::get_game_timer() - Global_28 > iParam0) {
			Global_27 = gameplay::get_game_timer();
		}
		Global_28 = gameplay::get_game_timer();
		if (gameplay::get_game_timer() - Global_27 > iParam0) {
			if (func_247()) {
				Global_27 = gameplay::get_game_timer();
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1461E
bool func_247() {
	if (ui::is_pause_menu_active()) {
		return false;
	}
	if (controls::is_control_just_pressed(0, 18) || controls::is_control_just_pressed(2, 18)) {
		return true;
	}
	return false;
}

// Position - 0x14650
bool func_248(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = ai::get_script_task_status(iParam0, iParam1);
	if (iVar0 == 1 || iVar0 == 0) {
		return true;
	}
	else if (!iParam2) {
		if (iVar0 == 2 || iVar0 == 3) {
			return true;
		}
	}
	return false;
}

// Position - 0x14696
bool func_249() {
	int iVar0;

	if (func_222(iLocal_2129)) {
		iVar0 = entity::get_entity_model(iLocal_2129);
		if (iVar0 == gameplay::get_hash_key("MONSTER") || iVar0 == gameplay::get_hash_key("MARSHALL")) {
			return true;
		}
	}
	return false;
}

// Position - 0x146D5
bool func_250() {
	int iVar0;

	if (func_222(iLocal_2129)) {
		iVar0 = entity::get_entity_model(iLocal_2129);
		if (iVar0 == joaat("baller") || iVar0 == joaat("baller2") || iVar0 == joaat("bison") ||
			iVar0 == joaat("bison2") || iVar0 == joaat("bison3") || iVar0 == joaat("bobcatxl") ||
			iVar0 == joaat("cavalcade") || iVar0 == joaat("cavalcade2") || iVar0 == joaat("crusader") ||
			iVar0 == joaat("dubsta") || iVar0 == joaat("dubsta2") || iVar0 == joaat("fq2") ||
			iVar0 == joaat("granger") || iVar0 == joaat("gresley") || iVar0 == joaat("landstalker") ||
			iVar0 == joaat("mesa") || iVar0 == joaat("mesa2") || iVar0 == joaat("mesa3") || iVar0 == joaat("patriot") ||
			iVar0 == joaat("radi") || iVar0 == joaat("rancherxl") || iVar0 == joaat("rancherxl2") ||
			iVar0 == joaat("rebel") || iVar0 == joaat("rocoto") || iVar0 == joaat("sadler") ||
			iVar0 == joaat("sadler2") || iVar0 == joaat("sandking") || iVar0 == joaat("sandking2") ||
			iVar0 == joaat("seminole") || iVar0 == joaat("superd") || iVar0 == gameplay::get_hash_key("huntley") ||
			iVar0 == gameplay::get_hash_key("DUBSTA3")) {
			return true;
		}
	}
	return false;
}

// Position - 0x148B8
bool func_251(int iParam0, int iParam1, char *sParam2, char *sParam3, var *uParam4, float fParam5, int iParam6,
			  int iParam7, float fParam8) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int *iVar6;
	int *iVar7;
	int *iVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;

	fVar0 = -1f;
	switch (uParam4->f_3) {
	case 0:
		*uParam4 = func_186();
		iVar5 = func_186();
		func_194(&iVar5, iParam0);
		func_195(&iVar5, iParam1);
		func_196(&iVar5, 0);
		if (func_265(*uParam4, iVar5)) {
			func_263(&iVar5, 0, 0, 0, 1, 0, 0);
		}
		func_261(*uParam4, iVar5, &iVar1, &iVar2, &iVar3, &iVar6, &iVar7, &iVar8);
		uParam4->f_11 = iVar1 + iVar2 * 60 + iVar3 + iParam6 * 3600;
		func_259(system::to_float(uParam4->f_11) / 3600f);
		if (iParam7) {
			graphics::_0x5F0F3F56635809EF(0.6f);
			graphics::_set_far_shadows_suppressed(0);
			graphics::_0x0AE73D8DF3A762B2(0);
		}
		func_258();
		uParam4->f_10 = audio::get_sound_id();
		audio::play_sound_frontend(uParam4->f_10, "TIME_LAPSE_MASTER", 0, 1);
		audio::start_audio_scene("TOD_SHIFT_SCENE");
		func_229();
		uParam4->f_3++;
		break;

	case 1:
	case 2:
		if (cam::does_cam_exist(uParam4->f_4) && cam::is_cam_interpolating(uParam4->f_4) ||
			!(fParam5 >= 0.99f || fParam5 == -1f)) {
			if (cam::does_cam_exist(uParam4->f_4) && cam::is_cam_interpolating(uParam4->f_4)) {
				fVar0 = cam::get_cam_spline_phase(uParam4->f_4);
			}
			else if (!(fParam5 >= 0.99f || fParam5 == -1f)) {
				fVar0 = fParam5;
			}
			else {
				fVar0 = -1f;
			}
			if (fVar0 >= 0.5f) {
				if (uParam4->f_3 == 1) {
					if (gameplay::get_hash_key(sParam2) != 0) {
						gameplay::_set_weather_type_over_time(sParam2, fParam8);
					}
					if (gameplay::get_hash_key(sParam3) != 0) {
						gameplay::_clear_cloud_hat();
						gameplay::_set_cloud_hat_transition(sParam3, 0);
					}
					uParam4->f_3 = 2;
				}
			}
		}
		if (fVar0 >= 0.99f || fVar0 == -1f) {
			iVar5 = *uParam4;
			func_263(&iVar5, uParam4->f_11, 0, 0, 0, 0, 0);
			time::set_clock_time(func_257(iVar5), func_256(iVar5), func_255(iVar5));
			if (iParam7) {
				graphics::_0x03FC694AE06C5A20();
			}
			audio::stop_sound(uParam4->f_10);
			audio::release_named_script_audio_bank("TIME_LAPSE");
			if (iParam7) {
				graphics::_0x0AE73D8DF3A762B2(1);
				graphics::_set_far_shadows_suppressed(1);
			}
			return true;
		}
		fVar11 = fVar0;
		fVar9 = 0.1f;
		fVar10 = 0.9f;
		fVar12 = func_94((fVar11 - fVar9) / (fVar10 - fVar9), 0f, 1f);
		iVar4 = system::round(IntToFloat(uParam4->f_11) * fVar12);
		iVar5 = *uParam4;
		func_263(&iVar5, iVar4, 0, 0, 0, 0, 0);
		time::set_clock_time(func_257(iVar5), func_256(iVar5), func_255(iVar5));
		if (func_254(iVar5) != time::get_clock_day_of_month()) {
			time::set_clock_date(func_254(iVar5), func_193(iVar5), func_191(iVar5));
		}
		func_252();
		graphics::_0xE3E2C1B4C59DBC77(6);
		break;
	}
	return false;
}

// Position - 0x14B4D
void func_252() {
	unk1::_0xEB2D525B57F42B40();
	func_253();
}

// Position - 0x14B5D
void func_253() { Global_17151.f_134 = 1; }

// Position - 0x14B6B
int func_254(int iParam0) { return system::shift_right(iParam0, 4) & 31; }

// Position - 0x14B7D
int func_255(int iParam0) { return system::shift_right(iParam0, 20) & 63; }

// Position - 0x14B90
int func_256(int iParam0) { return system::shift_right(iParam0, 14) & 63; }

// Position - 0x14BA3
int func_257(int iParam0) { return system::shift_right(iParam0, 9) & 31; }

// Position - 0x14BB6
int func_258() {
	int iVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		return 0;
	}
	if (!ped::is_ped_sitting_in_any_vehicle(player::player_ped_id())) {
		return 0;
	}
	iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
	if (!entity::is_entity_dead(iVar0, 0)) {
		return 0;
	}
	audio::set_veh_radio_station(iVar0, "OFF");
	return 1;
}

// Position - 0x14C04
void func_259(float fParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (func_41(&Global_101700.f_17062.f_175[iVar0 /*19*/].f_5)) {
			func_260(&Global_101700.f_17062.f_175[iVar0 /*19*/].f_5, fParam0 * 60f);
		}
		iVar0++;
	}
	iVar1 = 0;
	while (iVar1 < 6) {
		if (func_41(&Global_101700.f_17062.f_362[iVar1 /*3*/])) {
			func_260(&Global_101700.f_17062.f_362[iVar1 /*3*/], fParam0 * 60f);
		}
		iVar1++;
	}
	audio::skip_radio_forward();
}

// Position - 0x14C95
void func_260(var *uParam0, float fParam1) {
	if (func_41(uParam0)) {
		func_27(uParam0, func_36(uParam0) + fParam1);
	}
}

// Position - 0x14CB8
void func_261(int iParam0, int iParam1, int *iParam2, int *iParam3, int *iParam4, int *iParam5, int *iParam6,
			  int *iParam7) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	if (func_265(iParam0, iParam1)) {
		iVar0 = func_193(iParam1);
		iVar1 = func_191(iParam0);
		iVar2 = func_191(iParam0) - func_191(iParam1);
		iVar3 = func_193(iParam0) - func_193(iParam1);
		iVar4 = func_254(iParam0) - func_254(iParam1);
		iVar5 = func_257(iParam0) - func_257(iParam1);
		iVar6 = func_256(iParam0) - func_256(iParam1);
		iVar7 = func_255(iParam0) - func_255(iParam1);
	}
	else {
		iVar0 = func_193(iParam0);
		iVar1 = func_191(iParam1);
		iVar2 = func_191(iParam1) - func_191(iParam0);
		iVar3 = func_193(iParam1) - func_193(iParam0);
		iVar4 = func_254(iParam1) - func_254(iParam0);
		iVar5 = func_257(iParam1) - func_257(iParam0);
		iVar6 = func_256(iParam1) - func_256(iParam0);
		iVar7 = func_255(iParam1) - func_255(iParam0);
	}
	while (iVar7 < 0) {
		iVar7 += 60;
		iVar6--;
	}
	while (iVar7 > 59) {
		iVar7 -= 60;
		iVar6++;
	}
	while (iVar6 < 0) {
		iVar6 += 60;
		iVar5--;
	}
	while (iVar6 > 59) {
		iVar6 -= 60;
		iVar5++;
	}
	while (iVar5 < 0) {
		iVar5 += 24;
		iVar4--;
	}
	while (iVar5 > 23) {
		iVar5 -= 24;
		iVar4++;
	}
	while (iVar4 < 0) {
		while (iVar3 < 0) {
			iVar3 += 12;
			iVar2--;
		}
		iVar4 += func_190(iVar0, iVar1);
		iVar3--;
		iVar0 = system::round(func_262(system::to_float(iVar0 + 1), 0f, 12f));
	}
	while (iVar3 < 0) {
		iVar3 += 12;
		iVar2--;
	}
	while (iVar3 > 12) {
		iVar3 -= 12;
		iVar2++;
	}
	*iParam2 = iVar7;
	*iParam3 = iVar6;
	*iParam4 = iVar5;
	*iParam5 = iVar4;
	*iParam6 = iVar3;
	*iParam7 = iVar2;
}

// Position - 0x14EB9
float func_262(float fParam0, float fParam1, float fParam2) {
	float fVar0;

	if (fParam1 == fParam2) {
		return fParam1;
	}
	fVar0 = fParam2 - fParam1;
	fParam0 -= IntToFloat(system::round((fParam0 - fParam1) / fVar0)) * fVar0;
	if (fParam0 < fParam1) {
		fParam0 += fVar0;
	}
	return fParam0;
}

// Position - 0x14EFB
void func_263(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = func_191(*iParam0);
	iVar1 = func_193(*iParam0);
	iVar2 = func_254(*iParam0);
	iVar3 = func_257(*iParam0);
	iVar4 = func_256(*iParam0);
	iVar5 = func_255(*iParam0);
	if (iParam6 == 0 && iParam5 == 0 && iParam4 == 0 && iParam3 == 0 && iParam2 == 0 && iParam1 == 0) {
		return;
	}
	if (iParam1 < 0) {
		return;
	}
	if (iParam2 < 0) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam4 < 0) {
		return;
	}
	if (iParam5 < 0) {
		return;
	}
	if (iParam6 < 0) {
		return;
	}
	iVar5 += iParam1;
	while (iVar5 >= 60) {
		iParam2++;
		iVar5 -= 60;
	}
	iVar4 += iParam2;
	while (iVar4 >= 60) {
		iParam3++;
		iVar4 -= 60;
	}
	iVar3 += iParam3;
	while (iVar3 >= 24) {
		iParam4++;
		iVar3 -= 24;
	}
	iVar2 += iParam4;
	iVar6 = func_190(iVar1, iVar0);
	while (iVar2 > iVar6) {
		iVar1++;
		iVar2 -= iVar6;
		if (iVar1 > 11) {
			iVar0++;
			iVar1 -= 12;
		}
		iVar6 = func_190(iVar1, iVar0);
	}
	iVar1 += iParam5;
	while (iVar1 > 11) {
		iParam6++;
		iVar1 -= 12;
	}
	iVar0 += iParam6;
	func_264(iParam0, iVar5, iVar4, iVar3, iVar2, iVar1, iVar0);
}

// Position - 0x1507D
void func_264(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_196(iParam0, iParam1);
	func_195(iParam0, iParam2);
	func_194(iParam0, iParam3);
	func_188(iParam0, iParam5);
	func_189(iParam0, iParam4);
	func_187(iParam0, iParam6);
}

// Position - 0x150B5
bool func_265(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (!func_266(iParam1) || !func_266(iParam0)) {
		return true;
	}
	iVar0 = func_191(iParam0);
	iVar1 = func_191(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_193(iParam0);
	iVar1 = func_193(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_254(iParam0);
	iVar1 = func_254(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_257(iParam0);
	iVar1 = func_257(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_256(iParam0);
	iVar1 = func_256(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_255(iParam0);
	iVar1 = func_255(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	return false;
}

// Position - 0x151C1
int func_266(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	if (iParam0 == -15) {
		return 0;
	}
	iVar0 = func_255(iParam0);
	if (iVar0 < 0 || iVar0 >= 60) {
		return 0;
	}
	iVar1 = func_256(iParam0);
	if (iVar1 < 0 || iVar1 >= 60) {
		return 0;
	}
	iVar2 = func_257(iParam0);
	if (iVar2 < 0 || iVar2 > 23) {
		return 0;
	}
	iVar3 = func_191(iParam0);
	if (iVar3 <= 0 || iVar3 > 2043 || iVar3 < 1979) {
		return 0;
	}
	iVar4 = func_193(iParam0);
	if (iVar4 < 0 || iVar4 > 11) {
		return 0;
	}
	iVar5 = func_254(iParam0);
	if (iVar5 < 1 || iVar5 > func_190(iVar4, iVar3)) {
		return 0;
	}
	return 1;
}

// Position - 0x1529D
int func_267() {
	switch (Global_101700.f_24032) {
	case 0: return 20;

	case 1: return 17;

	case 2: return 12;

	case 3: return 21;

	case 4: return 12;
	}
	return 18;
}

// Position - 0x152F9
void func_268() {
	func_314();
	func_290();
	func_275();
	func_271();
	func_270(&Local_196, &Local_1943);
	func_269(&uLocal_1882, &iLocal_175);
	func_5();
	func_52();
	controls::disable_control_action(0, 69, 1);
	controls::disable_control_action(0, 68, 1);
	controls::disable_control_action(0, 25, 1);
	controls::disable_control_action(0, 70, 1);
	controls::disable_control_action(0, 99, 1);
	controls::disable_control_action(0, 100, 1);
	ped::set_ped_density_multiplier_this_frame(0f);
	vehicle::set_vehicle_density_multiplier_this_frame(0f);
	ped::set_scenario_ped_density_multiplier_this_frame(0f, 0f);
}

// Position - 0x1536B
void func_269(var *uParam0, int *iParam1) {
	int iVar0;
	int iVar1;

	if ((*uParam0)[*iParam1 /*6*/] != 0 && entity::does_entity_exist((*uParam0)[*iParam1 /*6*/]) &&
		(*uParam0)[*iParam1 /*6*/].f_1 != 0 && entity::does_entity_exist((*uParam0)[*iParam1 /*6*/].f_1) &&
		(*uParam0)[*iParam1 /*6*/].f_4) {
		if (func_51((*uParam0)[*iParam1 /*6*/].f_2, 2)) {
			(*uParam0)[*iParam1 /*6*/].f_5 = entity::has_entity_clear_los_to_entity_in_front(
				(*uParam0)[*iParam1 /*6*/], (*uParam0)[*iParam1 /*6*/].f_1);
		}
		else {
			(*uParam0)[*iParam1 /*6*/].f_5 = entity::has_entity_clear_los_to_entity(
				(*uParam0)[*iParam1 /*6*/], (*uParam0)[*iParam1 /*6*/].f_1, (*uParam0)[*iParam1 /*6*/].f_3);
		}
	}
	iVar0++;
	*iParam1++;
	if (*iParam1 >= *uParam0) {
		*iParam1 = 0;
	}
	while (((*uParam0)[*iParam1 /*6*/] == 0 || !entity::does_entity_exist((*uParam0)[*iParam1 /*6*/]) ||
			(*uParam0)[*iParam1 /*6*/].f_1 == 0 || !entity::does_entity_exist((*uParam0)[*iParam1 /*6*/].f_1)) &&
		   iVar0 < *uParam0) {
		iVar0++;
		*iParam1++;
		if (*iParam1 >= *uParam0) {
			*iParam1 = 0;
		}
	}
	iVar1 = 0;
	while (iVar1 < *uParam0) {
		if (!(*uParam0)[iVar1 /*6*/].f_4) {
			(*uParam0)[iVar1 /*6*/] = 0;
			(*uParam0)[iVar1 /*6*/].f_1 = 0;
			(*uParam0)[iVar1 /*6*/].f_2 = 0;
			(*uParam0)[iVar1 /*6*/].f_3 = 0;
			(*uParam0)[iVar1 /*6*/].f_5 = 0;
		}
		(*uParam0)[iVar1 /*6*/].f_4 = 0;
		iVar1++;
	}
}

// Position - 0x154F1
void func_270(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	float fVar2;
	float fVar3;

	iVar0 = 1;
	iVar1 = 0;
	while (iVar1 < *iParam0) {
		if (func_8((*iParam0)[iVar1 /*50*/])) {
			if ((*iParam0)[iVar1 /*50*/].f_17.f_13) {
				iVar0++;
			}
			else if ((*iParam0)[iVar1 /*50*/].f_17.f_3 > uParam1->f_3) {
				iVar0++;
			}
			else if ((*iParam0)[iVar1 /*50*/].f_17.f_3 == uParam1->f_3) {
				if ((*iParam0)[iVar1 /*50*/].f_17.f_2 > uParam1->f_2) {
					iVar0++;
				}
				else if ((*iParam0)[iVar1 /*50*/].f_17.f_2 == uParam1->f_2) {
					fVar2 = func_216((*iParam0)[iVar1 /*50*/], Local_54[(*iParam0)[iVar1 /*50*/].f_17.f_4 /*3*/], 1);
					fVar3 = func_216(player::player_ped_id(), Local_54[uParam1->f_4 /*3*/], 1);
					if (fVar2 < fVar3) {
						iVar0++;
					}
				}
			}
		}
		iVar1++;
	}
	uParam1->f_6 = iVar0;
}

// Position - 0x155CF
void func_271() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_597) {
		if (!Local_597[iVar0 /*50*/].f_42) {
			if (Local_597[iVar0 /*50*/].f_41) {
				if (func_8(Local_597[iVar0 /*50*/])) {
					if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
									   entity::get_entity_coords(Local_597[iVar0 /*50*/], 1)) > 40000f) {
						func_128(&Local_597[iVar0 /*50*/], 1);
						Local_597[iVar0 /*50*/].f_41 = 0;
					}
				}
				else {
					func_128(&Local_597[iVar0 /*50*/], 0);
					Local_597[iVar0 /*50*/].f_42 = 1;
				}
			}
			else if (func_227(0, &iLocal_173) && !Local_46.f_6) {
				if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
								   Local_597[iVar0 /*50*/].f_37) < 22500f) {
					func_274(&Local_597[iVar0 /*50*/], 0);
				}
			}
		}
		iVar0++;
	}
	func_272(&Local_597);
}

// Position - 0x156AE
void func_272(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *iParam0) {
		if (func_8((*iParam0)[iVar0 /*50*/])) {
			if (!ped::is_ped_in_combat((*iParam0)[iVar0 /*50*/], 0) && !ped::is_ped_fleeing((*iParam0)[iVar0 /*50*/]) &&
				!ped::is_ped_ragdoll((*iParam0)[iVar0 /*50*/])) {
				ped::set_ik_target((*iParam0)[iVar0 /*50*/], 1, player::player_ped_id(), 0, 0f, 0f, 0f, 0, -1, -1);
				if (!func_248((*iParam0)[iVar0 /*50*/], 242628503, 1)) {
					ai::open_sequence_task(&(*iParam0)[iVar0 /*50*/].f_2);
					ai::task_turn_ped_to_face_entity(0, player::player_ped_id(), 2000);
					ai::task_start_scenario_in_place(0, func_273(iVar0), -1, 1);
					ai::close_sequence_task((*iParam0)[iVar0 /*50*/].f_2);
					ai::task_perform_sequence((*iParam0)[iVar0 /*50*/], (*iParam0)[iVar0 /*50*/].f_2);
					ai::clear_sequence_task(&(*iParam0)[iVar0 /*50*/].f_2);
					(*iParam0)[iVar0 /*50*/].f_45 = gameplay::get_game_timer();
				}
				else if (iVar0 != 10) {
					if (entity::get_entity_heading((*iParam0)[iVar0 /*50*/]) -
								func_214(entity::get_entity_coords((*iParam0)[iVar0 /*50*/], 1),
										 entity::get_entity_coords(player::player_ped_id(), 1)) >
							60f ||
						entity::get_entity_heading((*iParam0)[iVar0 /*50*/]) -
								func_214(entity::get_entity_coords((*iParam0)[iVar0 /*50*/], 1),
										 entity::get_entity_coords(player::player_ped_id(), 1)) <
							-60f) {
						if (gameplay::get_game_timer() > (*iParam0)[iVar0 /*50*/].f_45 + 5000) {
							ai::clear_ped_tasks((*iParam0)[iVar0 /*50*/]);
						}
					}
					else if (ai::get_sequence_progress((*iParam0)[iVar0 /*50*/]) > 0) {
						if (gameplay::get_game_timer() > (*iParam0)[iVar0 /*50*/].f_45 + 4000) {
							if (iVar0 == 2 || iVar0 == 5 || iVar0 == 18 || iVar0 == 7 || iVar0 == 14) {
								ped::set_ik_target((*iParam0)[iVar0 /*50*/], 4, player::player_ped_id(), 0, 0f, 0f, 0f,
												   0, 500, 300);
							}
						}
					}
				}
			}
			else if (ped::is_ped_ragdoll((*iParam0)[iVar0 /*50*/])) {
				entity::set_entity_health((*iParam0)[iVar0 /*50*/], 0);
			}
			else {
				func_128(&(*iParam0)[iVar0 /*50*/], 0);
			}
		}
		iVar0++;
	}
}

// Position - 0x158A3
char *func_273(int iParam0) {
	switch (iParam0) {
	case 0:
	case 1:
	case 3:
	case 4:
	case 15:
	case 16:
	case 17:
	case 6:
	case 8:
	case 9:
	case 11:
	case 12:
	case 13:
	case 19:
	case 20:
	case 21:
	case 22: return "WORLD_HUMAN_CHEERING";

	case 2:
	case 5:
	case 18:
	case 7:
	case 14: return "WORLD_HUMAN_MOBILE_FILM_SHOCKING";

	case 10: return "WORLD_HUMAN_STAND_IMPATIENT";
	}
	return "";
}

// Position - 0x1595D
void func_274(var *uParam0, int iParam1) {
	if (!uParam0->f_41) {
		streaming::request_model(uParam0->f_3);
		if (iParam1) {
			while (!streaming::has_model_loaded(uParam0->f_3)) {
				system::wait(0);
			}
		}
		if (streaming::has_model_loaded(uParam0->f_3)) {
			*uParam0 = ped::create_ped(26, uParam0->f_3, uParam0->f_37, uParam0->f_40, 1, 1);
			if (entity::does_entity_exist(*uParam0)) {
				ped::set_ped_name_debug(*uParam0, &uParam0->f_46);
				uParam0->f_41 = 1;
				uParam0->f_44 = 0;
				streaming::set_model_as_no_longer_needed(uParam0->f_3);
			}
		}
	}
}

// Position - 0x159DC
void func_275() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 <= 7) {
		if (!Local_196[iVar0 /*50*/].f_42) {
			if (Local_196[iVar0 /*50*/].f_41) {
				if (func_8(Local_196[iVar0 /*50*/])) {
					iVar1 = 1;
					if (iLocal_178 < 3) {
						iVar1 = 0;
					}
					func_279(&Local_196[iVar0 /*50*/], Local_1943, iVar1);
					func_278();
					if (func_8(Local_196[iVar0 /*50*/].f_5)) {
						if (!ui::does_blip_exist(Local_196[iVar0 /*50*/].f_1)) {
							func_276(&Local_196[iVar0 /*50*/].f_1, Local_196[iVar0 /*50*/].f_5, 1, 10f, 1);
							ui::set_blip_name_from_text_file(Local_196[iVar0 /*50*/].f_1, "CRACEBLIP");
						}
						else {
							func_276(&Local_196[iVar0 /*50*/].f_1, Local_196[iVar0 /*50*/].f_5, 1, 10f, 0);
						}
					}
				}
				else {
					func_128(&Local_196[iVar0 /*50*/], 0);
					func_130(&Local_196[iVar0 /*50*/].f_1);
					Local_196[iVar0 /*50*/].f_42 = 1;
				}
			}
			else if (!Local_46.f_6 && func_227(0, &iLocal_173)) {
				func_9(&Local_196[iVar0 /*50*/], 0, 1);
			}
		}
		iVar0++;
	}
}

// Position - 0x15AEA
void func_276(int *iParam0, int iParam1, int iParam2, float fParam3, int iParam4) {
	vector3 vVar0;
	vector3 vVar3;

	if (iParam4 == 1 && !ui::does_blip_exist(*iParam0)) {
		*iParam0 = func_277(entity::get_entity_coords(iParam1, 1), 0);
		if (iParam2) {
			ui::set_blip_colour(*iParam0, 3);
			ui::set_blip_name_from_text_file(*iParam0, "BLIP_FRIEND");
		}
		else {
			ui::set_blip_colour(*iParam0, 1);
			ui::set_blip_name_from_text_file(*iParam0, "BLIP_ENEMY");
		}
		if (entity::is_entity_a_ped(iParam1)) {
			ui::set_blip_scale(*iParam0, 0.7f);
		}
	}
	if (ui::does_blip_exist(*iParam0)) {
		vVar0 = {ui::get_blip_coords(*iParam0)};
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
		vVar0.x += (vVar3.x - vVar0.x) / fParam3;
		vVar0.y += (vVar3.y - vVar0.y) / fParam3;
		vVar0.z += (vVar3.z - vVar0.z) / fParam3;
		ui::set_blip_coords(*iParam0, vVar0);
	}
}

// Position - 0x15BBA
int func_277(vector3 vParam0, int iParam3) {
	int iVar0;

	iVar0 = ui::add_blip_for_coord(vParam0);
	ui::set_blip_scale(iVar0, func_33(network::network_is_game_in_progress(), 1f, 1f));
	ui::set_blip_route(iVar0, iParam3);
	return iVar0;
}

// Position - 0x15BE6
void func_278() {
	float fVar0;
	float fVar1;
	int iVar2;
	int iVar3;

	if (gameplay::get_game_timer() > iLocal_2132) {
		fVar1 = 1E+07f;
		iVar3 = 0;
		while (iVar3 <= 7) {
			if (func_222(Local_196[iVar3 /*50*/].f_5)) {
				fVar0 = func_221(player::player_ped_id(), Local_196[iVar3 /*50*/].f_5, 1);
				if (fVar0 < fVar1) {
					fVar0 = fVar1;
					iVar2 = iVar3;
				}
			}
			iVar3++;
		}
		if (iLocal_2131 > -1 && func_222(Local_196[iLocal_2131 /*50*/].f_5)) {
			audio::_0x18EB48CFC41F2EA0(Local_196[iLocal_2131 /*50*/].f_5, 0);
			audio::_dynamic_mixer_related_fn(Local_196[iLocal_2131 /*50*/].f_5, "STREET_RACE_NPC_GENERAL", 0);
		}
		if (func_222(Local_196[iVar2 /*50*/].f_5)) {
			audio::_dynamic_mixer_related_fn(Local_196[iVar2 /*50*/].f_5, "STREET_RACE_NPC_CLOSEST", 0);
		}
		iLocal_2131 = iVar2;
		iLocal_2132 = gameplay::get_game_timer() + 2000;
	}
}

// Position - 0x15CAC
void func_279(var *uParam0, struct<20> Param1, int iParam21) {
	int iVar0;
	vector3 vVar1;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	int iVar8;
	bool bVar9;
	int iVar10;
	vector3 vVar11;

	if (entity::does_entity_exist(uParam0->f_5) && !entity::is_entity_dead(uParam0->f_5, 0)) {
		iVar0 = 0;
		fVar4 = func_289(*uParam0);
		if (Param1.f_4 < 6) {
			uParam0->f_17 = func_216(*uParam0, Local_54[uParam0->f_17.f_4 /*3*/], 1);
			if (gameplay::get_game_timer() > Local_46.f_7 + 7500) {
				if (uParam0->f_17.f_2 > Param1.f_2 + 1) {
					if (system::vdist2(entity::get_entity_coords(uParam0->f_5, 1),
									   entity::get_entity_coords(player::player_ped_id(), 1)) > 2500f) {
						fVar4 -= fVar4 * 0.5f;
					}
					else if (system::vdist2(entity::get_entity_coords(uParam0->f_5, 1),
											entity::get_entity_coords(player::player_ped_id(), 1)) > 625f) {
						fVar4 -= fVar4 * 0.4f;
					}
					else {
						fVar4 -= fVar4 * 0.2f;
					}
				}
				else if (uParam0->f_17.f_2 == Param1.f_2 + 1) {
					fVar6 = func_216(player::player_ped_id(), Local_54[uParam0->f_17.f_4 /*3*/], 1);
					fVar5 = fVar6 - uParam0->f_17;
					if (fVar5 > 50f) {
						fVar4 -= fVar4 * 0.4f;
					}
					else if (fVar5 > 25f) {
						fVar4 -= fVar4 * 0.2f;
					}
				}
				else if (uParam0->f_17.f_2 == Param1.f_2) {
					if (Param1 > uParam0->f_17) {
						fVar5 = Param1 - uParam0->f_17;
						if (fVar5 > 50f) {
							fVar4 -= fVar4 * 0.4f;
						}
						else if (fVar5 > 25f) {
							fVar4 -= fVar4 * 0.2f;
						}
					}
					else if (Param1 < uParam0->f_17) {
						fVar5 = uParam0->f_17 - Param1;
						if (fVar5 > 50f) {
							fVar4 += fVar4 * 1.5f;
							iVar0 = 1;
							vVar1 = {0f, 3f, 0f};
						}
						else if (fVar5 > 25f) {
							fVar4 += fVar4 * 1f;
							iVar0 = 1;
							vVar1 = {0f, 1.5f, 0f};
						}
						else if (fVar5 > 0f) {
							fVar4 += fVar4 * 0.5f;
						}
					}
				}
				else if (uParam0->f_17.f_2 == Param1.f_2 - 1) {
					fVar7 = func_216(*uParam0, Local_54[Param1.f_4 /*3*/], 1);
					fVar5 = fVar7 - Param1;
					if (fVar5 > 50f) {
						fVar4 += fVar4 * 1.5f;
						iVar0 = 1;
						vVar1 = {0f, 3f, 0f};
					}
					else if (fVar5 > 25f) {
						fVar4 += fVar4 * 1f;
						iVar0 = 1;
						vVar1 = {0f, 1.5f, 0f};
					}
					else if (fVar5 > 0f) {
						fVar4 += fVar4 * 0.5f;
					}
				}
				else {
					fVar4 += fVar4 * 1.7f;
					iVar0 = 1;
					vVar1 = {0f, 4f, 0f};
				}
			}
			else {
				fVar4 = 40f;
				if (gameplay::get_game_timer() < Local_46.f_7 + 1000) {
					vVar1 = {0f, 10f, 0f};
				}
				else {
					vVar1 = {0f, 6f, 0f};
				}
				iVar0 = 1;
			}
			uParam0->f_17.f_1 = func_287(uParam0->f_17.f_1, fVar4, 0.1f, 0);
			ai::set_drive_task_cruise_speed(*uParam0, uParam0->f_17.f_1);
			ai::set_drive_task_max_cruise_speed(*uParam0, fVar4);
		}
		switch (uParam0->f_44) {
		case 0:
			if (func_41(&Local_46.f_2)) {
				uParam0->f_44++;
			}
			else if (iParam21) {
				if (!func_248(*uParam0, 242628503, 1)) {
					ai::open_sequence_task(&uParam0->f_2);
					ai::task_pause(0, gameplay::get_random_int_in_range(200, 500));
					ai::task_vehicle_temp_action(0, uParam0->f_5, 31, gameplay::get_random_int_in_range(500, 2000));
					ai::close_sequence_task(uParam0->f_2);
					ai::task_perform_sequence(*uParam0, uParam0->f_2);
					ai::clear_sequence_task(&uParam0->f_2);
				}
			}
			break;

		case 1:
			vehicle::steer_unlock_bias(uParam0->f_5, 1);
			vehicle::set_vehicle_doors_locked(uParam0->f_5, 2);
			ped::set_blocking_of_non_temporary_events(*uParam0, 1);
			vehicle::set_vehicle_strong(uParam0->f_5, 1);
			vehicle::set_vehicle_has_strong_axles(uParam0->f_5, 1);
			entity::set_entity_load_collision_flag(uParam0->f_5, 1);
			vehicle::set_vehicle_engine_on(uParam0->f_5, 1, 0, 0);
			vehicle::_0x9F3F689B814F2599(uParam0->f_5, 0);
			ai::open_sequence_task(&uParam0->f_2);
			iVar8 = gameplay::get_random_int_in_range(1100, 1300);
			ai::task_pause(0, iVar8);
			iVar8 = gameplay::get_random_int_in_range(100, 250);
			if (uParam0->f_17.f_11 == 1) {
				ai::task_vehicle_temp_action(0, uParam0->f_5, 30, 600);
			}
			else if (uParam0->f_17.f_11 == 2) {
				ai::task_vehicle_temp_action(0, uParam0->f_5, 30, 1100);
			}
			else if (uParam0->f_17.f_11 == 5) {
				ai::task_vehicle_temp_action(0, uParam0->f_5, 30, 1200);
			}
			else {
				ai::task_vehicle_temp_action(0, uParam0->f_5, 30, 1300 + uParam0->f_17.f_11 + 1 * iVar8);
			}
			ai::close_sequence_task(uParam0->f_2);
			ai::task_perform_sequence(*uParam0, uParam0->f_2);
			ai::clear_sequence_task(&uParam0->f_2);
			uParam0->f_17.f_1 = func_289(*uParam0);
			uParam0->f_44++;
			break;

		case 2:
			switch (uParam0->f_17.f_4) {
			case 5:
				if (entity::is_entity_in_angled_area(*uParam0, Local_54.f_19, Local_54.f_22, Local_54.f_25, 0, 1, 0)) {
					uParam0->f_17.f_3++;
					uParam0->f_17.f_2++;
					uParam0->f_17.f_4 = 0;
					if (uParam0->f_17.f_3 == Local_54.f_65) {
						uParam0->f_17.f_13 = 1;
					}
				}
				break;

			default:
				if (Local_46.f_5) {
					if (!func_248(*uParam0, 242628503, 1)) {
						ai::open_sequence_task(&uParam0->f_2);
						ai::task_vehicle_follow_waypoint_recording(0, uParam0->f_5, Local_54.f_64, 786468, 0, 540, -1,
																   uParam0->f_17.f_1, 1, 1073741824);
						ai::close_sequence_task(uParam0->f_2);
						ai::task_perform_sequence(*uParam0, uParam0->f_2);
						ai::clear_sequence_task(&uParam0->f_2);
					}
					bVar9 = false;
					if (uParam0->f_17 < 20f) {
						bVar9 = true;
					}
					ai::waypoint_recording_get_closest_waypoint(Local_54.f_64,
																entity::get_entity_coords(uParam0->f_5, 1), &iVar10);
					ai::waypoint_recording_get_coord(Local_54.f_64, iVar10, &vVar11);
					if (system::vdist2(vVar11, Local_54[uParam0->f_17.f_4 /*3*/]) < 400f) {
						bVar9 = true;
					}
					if (bVar9) {
						uParam0->f_17.f_2++;
						uParam0->f_17.f_4++;
					}
				}
				else if (!func_248(*uParam0, 242628503, 1) && !func_248(*uParam0, -1817882002, 1)) {
					ai::task_vehicle_drive_to_coord(
						*uParam0, uParam0->f_5, entity::get_offset_from_entity_in_world_coords(*uParam0, 0f, 100f, 0f),
						40f, 0, uParam0->f_5.f_2, 786468, 20f, 9999f);
				}
				break;
			}
			if (func_286(uParam0)) {
				if (!cam::is_sphere_visible(entity::get_entity_coords(uParam0->f_5, 1), 3f)) {
					func_285(uParam0);
				}
			}
			if (uParam0->f_17.f_11 == 1) {
				if (func_284(uParam0, Param1)) {
					func_283(uParam0, Param1);
				}
			}
			if (iLocal_121 > gameplay::get_game_timer()) {
				unk1::_0xAF66DCEE6609B148();
			}
			break;

		case 999: break;
		}
		if (Local_46.f_5 && !Local_46.f_6) {
			if (iVar0 && !func_282(vVar1)) {
				if (func_281(uParam0->f_5)) {
					if (gameplay::get_game_timer() > Local_46.f_7 + 1000) {
						vVar1 = {vVar1 * FtoV(IntToFloat(Global_101700.f_24032 + 1) * 0.75f)};
					}
					entity::apply_force_to_entity_center_of_mass(uParam0->f_5, 0, vVar1, 0, 1, 1, 1);
				}
			}
			if (func_280(*uParam0) && vehicle::is_vehicle_on_all_wheels(uParam0->f_5) &&
				!entity::is_entity_in_air(uParam0->f_5)) {
				entity::apply_force_to_entity_center_of_mass(uParam0->f_5, 0, 0f, 0f, -10f, 0, 1, 1, 1);
				vehicle::set_vehicle_friction_override(uParam0->f_5, 2f);
			}
		}
	}
}

// Position - 0x163F7
int func_280(int iParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7,
			 var uParam8, var uParam9, var uParam10, var uParam11, var uParam12, var uParam13, var uParam14,
			 var uParam15, var uParam16, var uParam17, var uParam18, var uParam19, var uParam20, var uParam21,
			 var uParam22, var uParam23, var uParam24, var uParam25, var uParam26, var uParam27, var uParam28,
			 var uParam29, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
			 var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
			 var uParam43, var uParam44, var uParam45, var uParam46, var uParam47, var uParam48, var uParam49) {
	if (entity::is_entity_in_angled_area(iParam0, 1863.932f, 3234.403f, 42.03159f, 1907.052f, 3184.802f, 50.18943f, 25f,
										 0, 1, 0) ||
		entity::is_entity_in_angled_area(iParam0, 2249.526f, 3235.603f, 45.0114f, 2191.436f, 3247.169f, 51.67255f, 25f,
										 0, 1, 0) ||
		entity::is_entity_in_angled_area(iParam0, 2276.412f, 2998.594f, 42.96453f, 2299.795f, 3059.603f, 50.52016f, 25f,
										 0, 1, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x16497
bool func_281(int iParam0) {
	int iVar0;
	vector3 vVar1;
	int iVar4;
	vector3 vVar5;
	bool bVar8;
	int iVar9;

	if (func_222(iParam0)) {
		bVar8 = false;
		iVar9 = 0;
		if (ai::waypoint_recording_get_closest_waypoint(Local_54.f_64, entity::get_entity_coords(iParam0, 1), &iVar0)) {
			if (ai::waypoint_recording_get_coord(Local_54.f_64, iVar0, &vVar1)) {
				if (ai::waypoint_recording_get_num_points(Local_54.f_64, &iVar4)) {
					if (iVar0 < iVar4) {
						bVar8 = ai::waypoint_recording_get_coord(Local_54.f_64, iVar0 + 1, &vVar5);
					}
					else {
						bVar8 = ai::waypoint_recording_get_coord(Local_54.f_64, 0, &vVar5);
					}
				}
			}
		}
		if (bVar8) {
			if (func_214(vVar1, vVar5) - entity::get_entity_heading(iParam0) < 10f &&
				func_214(vVar1, vVar5) - entity::get_entity_heading(iParam0) > -10f) {
				iVar9 = 1;
			}
		}
		if (vehicle::is_vehicle_on_all_wheels(iParam0) && iVar9 && !entity::is_entity_in_air(iParam0) &&
			system::vdist2(entity::get_entity_coords(iParam0, 1), vVar1) < 900f) {
			return true;
		}
	}
	return false;
}

// Position - 0x16582
int func_282(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0x165AC
void func_283(var *uParam0, struct<5> Param1, var uParam6, var uParam7, var uParam8, var uParam9, var uParam10,
			  var uParam11, var uParam12, var uParam13, var uParam14, var uParam15, var uParam16, var uParam17,
			  var uParam18, var uParam19, var uParam20) {
	vector3 vVar0;

	if (Param1.f_4 == 0) {
		vVar0 = {Local_54[4 /*3*/]};
	}
	else if (Param1.f_4 == 1) {
		vVar0 = {Local_54[5 /*3*/]};
	}
	else {
		vVar0 = {Local_54[Param1.f_4 - 2 /*3*/]};
	}
	if (!func_282(vVar0)) {
		if (!cam::is_sphere_visible(vVar0, 3f) &&
			!cam::is_sphere_visible(entity::get_entity_coords(uParam0->f_5, 1), 3f)) {
			if (gameplay::get_game_timer() > uParam0->f_5.f_11 + 2000 && uParam0->f_5.f_11 != 0) {
				if (!vehicle::is_any_vehicle_near_point(vVar0, 4f)) {
					if (Param1.f_4 != 0) {
						uParam0->f_17.f_3 = Param1.f_3;
						uParam0->f_17.f_4 = Param1.f_4 - 1;
					}
					else {
						uParam0->f_17.f_3 = Param1.f_3 - 1;
						uParam0->f_17.f_4 = 5;
					}
					uParam0->f_17.f_2 = Param1.f_2 - 1;
					func_23(uParam0->f_5, vVar0, func_214(vVar0, Local_54[uParam0->f_17.f_4 /*3*/]), 1, 1);
					vehicle::set_vehicle_forward_speed(uParam0->f_5, 20f);
					ai::task_vehicle_follow_waypoint_recording(*uParam0, uParam0->f_5, Local_54.f_64, 786469, 0, 540,
															   -1, uParam0->f_17.f_1, 1, 1073741824);
					iLocal_121 = gameplay::get_game_timer() + 1000;
				}
			}
		}
		else {
			uParam0->f_5.f_11 = gameplay::get_game_timer();
		}
	}
}

// Position - 0x166F2
bool func_284(var *uParam0, struct<5> Param1, var uParam6, var uParam7, var uParam8, var uParam9, var uParam10,
			  var uParam11, var uParam12, var uParam13, var uParam14, var uParam15, var uParam16, var uParam17,
			  var uParam18, var uParam19, var uParam20) {
	if (uParam0->f_17.f_2 < Param1.f_2 - 1 &&
		(uParam0->f_17.f_3 != Local_54.f_65 - 1 || uParam0->f_17.f_3 == Local_54.f_65 - 1 && Param1.f_4 < 4)) {
		return true;
	}
	return false;
}

// Position - 0x1673F
void func_285(var *uParam0) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;

	ai::waypoint_recording_get_closest_waypoint(Local_54.f_64, entity::get_entity_coords(uParam0->f_5, 1), &iVar0);
	ai::waypoint_recording_get_coord(Local_54.f_64, iVar0, &vVar1);
	ai::waypoint_recording_get_coord(Local_54.f_64, iVar0 + 1, &vVar4);
	if (!cam::is_sphere_visible(vVar1, 3f)) {
		if (!vehicle::is_any_vehicle_near_point(vVar1, 5f) || func_216(uParam0->f_5, vVar1, 1) < 5f) {
			func_23(uParam0->f_5, vVar1, func_214(vVar1, vVar4), 0, 1);
			if (!ped::is_ped_in_vehicle(*uParam0, uParam0->f_5, 0)) {
				ped::set_ped_into_vehicle(*uParam0, uParam0->f_5, -1);
			}
			iLocal_121 = gameplay::get_game_timer() + 1000;
		}
	}
}

// Position - 0x167E6
bool func_286(var *uParam0) {
	if (entity::is_entity_upsidedown(uParam0->f_5) || vehicle::is_vehicle_stuck_timer_up(uParam0->f_5, 0, 7000) ||
		vehicle::is_vehicle_stuck_timer_up(uParam0->f_5, 1, 40000)) {
		return true;
	}
	if (entity::is_entity_in_water(uParam0->f_5)) {
		return true;
	}
	if (vehicle::is_vehicle_stuck_timer_up(uParam0->f_5, 2, 7000) ||
		vehicle::is_vehicle_stuck_timer_up(uParam0->f_5, 3, 7000)) {
		return true;
	}
	if (uParam0->f_17.f_4 == uParam0->f_17.f_5) {
		if (gameplay::get_game_timer() > uParam0->f_5.f_10 + 45000) {
			return true;
		}
	}
	else {
		uParam0->f_5.f_10 = gameplay::get_game_timer();
		uParam0->f_17.f_5 = uParam0->f_17.f_4;
	}
	return false;
}

// Position - 0x16895
float func_287(float fParam0, float fParam1, float fParam2, int iParam3) {
	float fVar0;

	switch (iParam3) {
	case 1:
	case 6: fParam2 = system::pow(fParam2, 2f); break;

	case 2:
	case 7: fParam2 = 1f - system::pow(1f - fParam2, 2f); break;

	case 3:
	case 8: fParam2 = -system::cos(func_288(3.141593f * fParam2)) / 2f + 0.5f; break;

	case 4:
	case 9: fParam2 = system::pow(fParam2, 2f) * (3f - 2f * fParam2); break;
	}
	switch (iParam3) {
	case 0: fVar0 = fParam0 + fParam2 * (fParam1 - fParam0); break;

	case 1:
	case 2:
	case 3:
	case 4: fVar0 = func_287(fParam0, fParam1, fParam2, 0); break;

	case 5: fVar0 = (1f - fParam2) * fParam0 + fParam2 * fParam1; break;

	case 6:
	case 7:
	case 8:
	case 9: fVar0 = func_287(fParam0, fParam1, fParam2, 5); break;
	}
	return fVar0;
}

// Position - 0x169A8
float func_288(float fParam0) { return fParam0 * 57.29578f; }

// Position - 0x169B8
float func_289(struct<18> Param0, var uParam18, var uParam19, var uParam20, var uParam21, var uParam22, var uParam23,
			   var uParam24, var uParam25, var uParam26, var uParam27, var uParam28, var uParam29, var uParam30,
			   var uParam31, var uParam32, var uParam33, var uParam34, var uParam35, var uParam36, var uParam37,
			   var uParam38, var uParam39, var uParam40, var uParam41, var uParam42, var uParam43, var uParam44,
			   var uParam45, var uParam46, var uParam47, var uParam48, var uParam49) {
	float fVar0;

	switch (Param0.f_17.f_19) {
	case 0: fVar0 = 32f; break;

	case 1: fVar0 = 36f; break;

	case 2: fVar0 = 40f; break;

	case 3: fVar0 = 44f; break;
	}
	fVar0 += IntToFloat(3 * Global_101700.f_24032);
	return fVar0;
}

// Position - 0x16A1C
void func_290() {
	if (Local_46.f_5 && !Local_46.f_6) {
		if (Local_1943.f_4 < 6) {
			Local_1943 = func_216(iLocal_2127, Local_54[Local_1943.f_4 /*3*/], 1);
		}
		switch (Local_1943.f_4) {
		case 5:
			if (entity::is_entity_in_angled_area(player::player_ped_id(), Local_54.f_19, Local_54.f_22, Local_54.f_25,
												 0, 1, 0)) {
				Local_1943.f_3++;
				Local_1943.f_2++;
				if (Local_1943.f_3 < Local_54.f_65) {
					Local_1943.f_9 = gameplay::get_game_timer() - Local_1943.f_10;
					if (Local_1943.f_9 < Local_1943.f_8) {
						Local_1943.f_8 = Local_1943.f_9;
					}
					Local_1943.f_10 = gameplay::get_game_timer();
					Local_1943.f_4 = 0;
					Local_1978 = 1;
				}
				else {
					Local_1943.f_12 = gameplay::get_game_timer() - Local_46.f_7;
					if (Local_1943.f_12 < Global_101700.f_24032.f_1 || Global_101700.f_24032.f_1 == 0) {
						Global_101700.f_24032.f_1 = Local_1943.f_12;
					}
					Local_1943.f_13 = 1;
					Local_46.f_6 = 1;
				}
				audio::play_sound_frontend(-1, "CHECKPOINT_NORMAL", "HUD_MINI_GAME_SOUNDSET", 0);
				func_225(&Local_1943);
			}
			break;

		default:
			if (Local_1943 < 20f) {
				Local_1943.f_2++;
				Local_1943.f_4++;
				audio::play_sound_frontend(-1, "CHECKPOINT_NORMAL", "HUD_MINI_GAME_SOUNDSET", 0);
				func_225(&Local_1943);
			}
			break;
		}
		if (!Local_46.f_6) {
			if (!iLocal_140) {
				if (gameplay::get_game_timer() < Local_46.f_7 + 500) {
					if (func_281(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0))) {
						if (controls::is_control_pressed(0, 71)) {
							if (vehicle::is_this_model_a_car(
									entity::get_entity_model(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0)))) {
								audio::set_vehicle_boost_active(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0),
																1);
							}
							iLocal_176 = gameplay::get_game_timer() + 2000;
							graphics::_start_screen_effect("RaceTurbo", 0, 0);
							iLocal_140 = 1;
						}
					}
				}
			}
			else if (gameplay::get_game_timer() > iLocal_176 || !controls::is_control_pressed(0, 71)) {
				if (vehicle::is_this_model_a_car(
						entity::get_entity_model(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0)))) {
					audio::set_vehicle_boost_active(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0);
				}
				iLocal_140 = 0;
			}
			else {
				entity::apply_force_to_entity(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0, 0f, 20f, 0f,
											  0f, 0f, 0f, 0, 1, 1, 1, 0, 1);
			}
			func_313();
			func_312(&Local_1978, Local_1943);
			func_300(gameplay::get_game_timer() - Local_46.f_7, 0, "", Local_1943.f_3 + 1, Local_54.f_65, "",
					 Local_1943.f_6, 9, "", 0, 1, Local_1943.f_2 + 1, 30, "", 1, -1, -1, "", 6,
					 Global_101700.f_24032.f_1, "CRACEBTIME", gameplay::get_game_timer() - Local_1943.f_10, "", 0, 1,
					 -1, "", -1f, 1, 1, -1f, -1, 0, -1, -1, "", 1);
			if (controls::is_control_pressed(0, 20)) {
				if (!Global_1574102) {
					Global_1574102 = 1;
				}
			}
			else if (Global_1574102) {
				Global_1574102 = 0;
			}
			func_291(&Local_1943);
		}
	}
}

// Position - 0x16CF5
void func_291(var *uParam0) {
	int iVar0;

	iVar0 = uParam0->f_4 + 1;
	if (uParam0->f_4 == 5) {
		if (uParam0->f_3 + 1 == Local_54.f_65) {
			func_293(uParam0, 1, 1);
		}
		else {
			func_293(uParam0, 0, 1);
			func_292(uParam0, Local_54[0 /*3*/], 0);
		}
	}
	else {
		if (uParam0->f_2 < 1) {
			func_293(uParam0, 0, 0);
		}
		else {
			func_293(uParam0, 0, 1);
		}
		if (iVar0 == 5) {
			func_292(uParam0, Local_54[iVar0 /*3*/], 1);
		}
		else {
			func_292(uParam0, Local_54[iVar0 /*3*/], 0);
		}
	}
}

// Position - 0x16D80
void func_292(var *uParam0, vector3 vParam1, int iParam4) {
	if (!ui::does_blip_exist(uParam0->f_15)) {
		uParam0->f_15 = ui::add_blip_for_coord(vParam1);
		ui::_0x75A16C3DA34F1245(uParam0->f_15, 0);
		if (!iParam4) {
			ui::set_blip_colour(uParam0->f_15, 5);
			ui::set_blip_scale(uParam0->f_15, 0.7f);
		}
		else if (uParam0->f_3 == Local_54.f_65) {
			ui::set_blip_sprite(uParam0->f_15, 38);
			ui::set_blip_scale(uParam0->f_15, 1.2f);
		}
		ui::set_blip_name_from_text_file(uParam0->f_15, "BLIP_CPOINT");
	}
}

// Position - 0x16DF6
void func_293(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	var uVar7;
	int iVar8;
	int iVar9;
	vector3 vVar10;
	vector3 vVar13;
	vector3 vVar16;
	float fVar19;
	float fVar20;

	iVar9 = func_299(uParam0->f_4);
	ui::get_hud_colour(12, &iVar0, &iVar1, &iVar2, &iVar3);
	ui::get_hud_colour(134, &iVar4, &iVar5, &iVar6, &uVar7);
	iVar3 = func_298(uParam0->f_4);
	if (ui::does_blip_exist(uParam0->f_14)) {
		if (uParam0->f_16 != 0) {
			graphics::set_checkpoint_rgba(uParam0->f_16, iVar0, iVar1, iVar2, iVar3);
			graphics::_set_checkpoint_icon_rgba(uParam0->f_16, iVar4, iVar5, iVar6, iVar3);
		}
	}
	else {
		fVar19 = 8.5f * 1.333f;
		fVar20 = 6f;
		if (uParam0->f_4 == 5) {
			vVar13 = {Local_54[0 /*3*/]};
		}
		else {
			vVar13 = {Local_54[uParam0->f_4 + 1 /*3*/]};
		}
		if (uParam0->f_4 == 0) {
			iVar8 = 5;
		}
		else {
			iVar8 = uParam0->f_4 - 1;
		}
		vVar10 = {Local_54[uParam0->f_4 /*3*/]};
		vVar16 = {Local_54[iVar8 /*3*/]};
		vVar10.z--;
		vVar16.z--;
		if (iVar8 == 5) {
			vVar16.z -= 2f;
		}
		if (uParam0->f_4 == 5) {
			vVar10.z -= 2f;
		}
		uParam0->f_14 = ui::add_blip_for_coord(vVar10);
		ui::_0x75A16C3DA34F1245(uParam0->f_14, 0);
		if (!iParam1) {
			ui::set_blip_colour(uParam0->f_14, 5);
			ui::set_blip_scale(uParam0->f_14, 1.2f);
			ui::set_blip_priority(uParam0->f_14, 9);
			uParam0->f_16 = graphics::create_checkpoint(iVar9, vVar10 + Vector(fVar20, 0f, 0f), vVar13, fVar19, iVar0,
														iVar1, iVar2, iVar3, 0);
			graphics::_set_checkpoint_icon_rgba(uParam0->f_16, iVar4, iVar5, iVar6, iVar3);
			func_294(uParam0->f_16, vVar10);
		}
		else {
			ui::set_blip_sprite(uParam0->f_14, 38);
			ui::set_blip_scale(uParam0->f_14, 1.2f);
			ui::set_blip_priority(uParam0->f_14, 9);
			uParam0->f_16 = graphics::create_checkpoint(9, vVar10 + Vector(fVar20, 0f, 0f), vVar13, fVar19, iVar0,
														iVar1, iVar2, iVar3, 0);
			graphics::_set_checkpoint_icon_rgba(uParam0->f_16, iVar4, iVar5, iVar6, iVar3);
			func_294(uParam0->f_16, vVar10);
		}
		if (iParam2) {
			iVar9 = func_299(iVar8);
			ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uParam0->f_18);
			uParam0->f_18 = 180;
			if (uParam0->f_17 != 0) {
				graphics::delete_checkpoint(uParam0->f_17);
			}
			vVar16 = {vVar16};
			uParam0->f_17 = graphics::create_checkpoint(iVar9, vVar16 + Vector(fVar20, 0f, 0f), vVar10, fVar19, iVar0,
														iVar1, iVar2, uParam0->f_18, 0);
			func_294(uParam0->f_17, vVar16);
		}
		graphics::set_checkpoint_cylinder_height(uParam0->f_16, 9.5f, 9.5f, 30f);
		graphics::set_checkpoint_cylinder_height(uParam0->f_17, 9.5f, 9.5f, 30f);
		ui::set_blip_name_from_text_file(uParam0->f_14, "BLIP_CPOINT");
	}
	if (uParam0->f_17 != 0) {
		uParam0->f_18 -= 10;
		if (uParam0->f_18 > 0) {
			ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
			graphics::set_checkpoint_rgba(uParam0->f_17, iVar0, iVar1, iVar2, uParam0->f_18);
		}
		else {
			graphics::delete_checkpoint(uParam0->f_17);
		}
	}
}

// Position - 0x170C4
void func_294(int iParam0, vector3 vParam1) {
	int iVar0;
	vector3 vVar1[8];
	float fVar26;
	vector3 vVar27;

	iVar0 = 0;
	while (iVar0 <= 7) {
		vVar1[iVar0 /*3*/] = {vParam1 + func_297(iVar0)};
		gameplay::get_ground_z_for_3d_coord(vVar1[iVar0 /*3*/], &fVar26, 0);
		if (fVar26 < vParam1.z - 2f || fVar26 > vParam1.z + 2f) {
			vVar1[iVar0 /*3*/].f_2 = vParam1.z;
		}
		else {
			vVar1[iVar0 /*3*/].f_2 = fVar26;
		}
		iVar0++;
	}
	vVar27 = {func_295(&vVar1)};
	graphics::_0xF51D36185993515D(iParam0, vParam1 - Vector(0.3f, 0f, 0f), vVar27);
}

// Position - 0x1715B
Vector3 func_295(var *uParam0) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;
	vector3 vVar7;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		vVar1 = {(*uParam0)[iVar0 /*3*/]};
		vVar4 = {(*uParam0)[iVar0 + 1 % *uParam0 /*3*/]};
		vVar7.x += (vVar1.y - vVar4.y) * (vVar1.z + vVar4.z);
		vVar7.y += (vVar1.z - vVar4.z) * (vVar1.x + vVar4.x);
		vVar7.z += (vVar1.x - vVar4.x) * (vVar1.y + vVar4.y);
		iVar0++;
	}
	return func_296(vVar7);
}

// Position - 0x171E5
Vector3 func_296(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0x17224
Vector3 func_297(int iParam0) {
	switch (iParam0) {
	case 0: return 0f, 0f, 1f;

	case 1: return 7.5f / 2f, 0f, 1f;

	case 2: return -7.5f / 2f, 0f, 1f;

	case 3: return 0f, 7.5f / 2f, 1f;

	case 4: return 0f, -7.5f / 2f, 1f;

	case 5: return 7.5f / 2f, 7.5f / 2f, 1f;

	case 6: return -7.5f / 2f, -7.5f / 2f, 1f;

	case 7: return 7.5f / 2f, -7.5f / 2f, 1f;

	case 8: return -7.5f / 2f, 7.5f / 2f, 1f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x172EA
int func_298(int iParam0) {
	float fVar0;
	int iVar1;

	iVar1 = 240;
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		fVar0 = gameplay::get_distance_between_coords(Local_54[iParam0 /*3*/],
													  entity::get_entity_coords(player::player_ped_id(), 1), 1);
		if (fVar0 > 100f) {
			iVar1 = 240;
		}
		else {
			iVar1 = system::round(fVar0 * 2.4f);
		}
	}
	return iVar1;
}

// Position - 0x1733D
int func_299(int iParam0) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	float fVar15;

	vVar0 = {Local_54[iParam0 /*3*/]};
	if (iParam0 + 1 == 6) {
		vVar3 = {Local_54[0 /*3*/]};
	}
	else {
		vVar3 = {Local_54[iParam0 + 1 /*3*/]};
	}
	if (iParam0 - 1 >= 0) {
		vVar6 = {Local_54[iParam0 - 1 /*3*/]};
	}
	vVar9 = {vVar6 - vVar0};
	vVar12 = {vVar3 - vVar0};
	fVar15 = gameplay::get_angle_between_2d_vectors(vVar9.x, vVar9.y, vVar12.x, vVar12.y);
	if (fVar15 > 180f) {
		fVar15 = 360f - fVar15;
	}
	if (fVar15 < fLocal_30) {
		return 7;
	}
	else if (fVar15 < fLocal_31) {
		return 6;
	}
	else if (fVar15 < fLocal_32) {
		return 5;
	}
	else {
		return 5;
	}
	return 5;
}

// Position - 0x173FE
void func_300(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, char *sParam5, int iParam6,
			  int iParam7, char *sParam8, int iParam9, int iParam10, int iParam11, int iParam12, char *sParam13,
			  int iParam14, int iParam15, int iParam16, char *sParam17, int iParam18, int iParam19, char *sParam20,
			  int iParam21, char *sParam22, int iParam23, int iParam24, int iParam25, char *sParam26, float fParam27,
			  int iParam28, int iParam29, float fParam30, int iParam31, int iParam32, int iParam33, int iParam34,
			  char *sParam35, int iParam36) {
	int iVar0;
	char *sVar1;
	char *sVar2;
	char *sVar3;
	char *sVar4;
	char *sVar5;
	char *sVar6;
	char *sVar7;
	char *sVar8;
	char *sVar9;
	char *sVar10;
	char *sVar11;

	if (iParam24) {
		iVar0 = 1;
	}
	else {
		iVar0 = 0;
	}
	if (iParam34 != -1) {
		func_109(iParam34, "TIMER_CHALLTIME", iParam9, iVar0, iParam25, 0, 10, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
	}
	func_311();
	if (fParam27 > -1f) {
		func_308(0, "", iParam25, iParam28, 10, 0, sParam26, 1, fParam27, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0);
	}
	if (iParam15 > -1) {
		sVar1 = sParam17;
		if (func_307(sVar1)) {
			sVar1 = "TIM_DAMAGE";
		}
		func_212(iParam15, iParam16, sVar1, iParam18, iParam25, 10, -1f, -1f, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0,
				 1, -1);
	}
	if (!iParam32 || func_306()) {
		if (iParam6 > -1 && iParam7 > 0) {
			sVar2 = sParam8;
			if (func_307(sVar2)) {
				sVar2 = "TIM_POSIT";
			}
			func_305(iParam6, iParam7, sVar2, iParam10, iParam25, 7, 0, 0, 0, iParam10, 0);
		}
	}
	if (iParam3 > -1) {
		sVar3 = sParam5;
		if (func_307(sVar3)) {
			sVar3 = "TIM_LAP";
		}
		iParam3 = iParam3;
		iParam4 = iParam4;
		if (Global_1574102) {
			if (func_304()) {
				func_303(iParam3, iParam4, sVar3, iParam25, 1, 8, 0, 0, 0, 0, 0, 1, 1, 0, 255, 0);
			}
		}
	}
	if (iParam11 > -1 && iParam12 > -1) {
		sVar4 = sParam13;
		if (func_307(sVar4)) {
			sVar4 = "TIM_CHECKPOIN";
		}
		iParam14 = iParam14;
		if (Global_1574102) {
			func_305(iParam11, iParam12, sVar4, iParam14, iParam25, 7, 0, 0, 0, 1, 0);
		}
	}
	if (fParam30 > -1f) {
		sVar5 = "TIM_DISTANCE";
		sVar6 = "FMMC_LENGTHM";
		func_308(0, sVar5, -1, 1, 7, 0, sVar6, 1, fParam30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 0, 0, 0);
	}
	if (iParam19 > -1) {
		sVar7 = sParam20;
		if (func_307(sVar7)) {
			sVar7 = "TIMER_BESLAP";
		}
	}
	if (Global_1633501.f_41912 != 1 && Global_1633501.f_41912 != 3 && Global_1633501.f_41912 != 5 &&
		Global_1633501.f_41912 != 7) {
		if (iParam21 > -1) {
			if (!func_140(player::player_id())) {
				sVar8 = sParam22;
				if (func_307(sVar8)) {
					sVar8 = "TIMER_CURLAP";
				}
				func_109(iParam21, sVar8, 0, 1, iParam25, iParam23, 6, 0, iParam29, 0, 0, 0, 0, 0, 0, 0, 0);
			}
		}
	}
	if (func_307(sVar9)) {
		sVar9 = func_302(iParam1);
	}
	if (!iParam36) {
		if (iParam32 || Global_1574102 || func_301() == 2) {
			if (iParam32) {
				if (Global_1574102 && !gameplay::is_string_null_or_empty(sParam35)) {
					func_109(iParam31, sParam35, iParam9, 1, iParam25, 0, 5, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0);
				}
				else if (iParam31 <= 0) {
					func_109(iParam31, sVar9, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0);
				}
				else {
					func_109(iParam31, sVar9, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
				}
			}
			else if (func_301() == 2 && !gameplay::is_string_null_or_empty(sParam35)) {
				func_109(iParam31, sParam35, iParam9, 1, iParam25, 0, 5, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0);
			}
			else if (iParam31 <= 0) {
				func_109(iParam31, sVar9, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0);
			}
			else {
				func_109(iParam31, sVar9, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
			}
		}
	}
	else if (Global_1574102 || func_301() == 2) {
		if (iParam19 <= 0) {
			func_109(iParam19, sParam20, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0);
		}
		else {
			func_109(iParam19, sParam20, iParam9, 1, iParam25, 0, 5, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
		}
	}
	sVar10 = sParam2;
	if (func_307(sVar10)) {
		sVar10 = "TIMER_TIME_RCE";
	}
	if (iParam0 > -1) {
		func_109(iParam0, sVar10, iParam9, iVar0, iParam25, 0, 4, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
	}
	if (func_307(sVar11)) {
		sVar11 = "TIMER_CHALLTIME";
	}
	iParam33 = iParam33;
}

// Position - 0x177E6
int func_301() { return Global_1353070.f_68; }

// Position - 0x177F4
char *func_302(int iParam0) {
	switch (iParam0) {
	case 0: return "TIMER_WORLDTIME";

	case 1: return "FRIEND_WORLDTIME";

	case 2: return "CREW_WORLDTIME";

	case 3: return "PERS_WORLDTIME";
	}
	return "";
}

// Position - 0x17846
void func_303(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			  int iParam15) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_111(4, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_110(4, iVar0);
		Global_1354542.f_3014[iVar0] = iParam0;
		Global_1354542.f_3014.f_172[iVar0] = iParam1;
		StringCopy(&Global_1354542.f_3014.f_11[iVar0 /*16*/], sParam2, 64);
		Global_1354542.f_3014.f_183[iVar0] = iParam3;
		Global_1354542.f_3014.f_216[iVar0] = iParam5;
		Global_1354542.f_3014.f_194[iVar0] = iParam4;
		Global_1354542.f_3014.f_227[iVar0] = iParam6;
		Global_1354542.f_3014.f_270[iVar0] = iParam7;
		Global_1354542.f_3014.f_281[iVar0] = iParam8;
		Global_1354542.f_3014.f_292[iVar0] = iParam9;
		Global_1354542.f_3014.f_303[iVar0] = iParam10;
		Global_1354542.f_3014.f_314[iVar0] = iParam11;
		Global_1354542.f_3014.f_325[iVar0] = iParam13;
		Global_1354542.f_3014.f_336[iVar0] = iParam14;
		Global_1354542.f_3014.f_347[iVar0] = iParam15;
		if (iParam0 > 9 && iParam1 > 9 && gameplay::is_pc_version() && iParam12) {
			Global_1354542.f_1004 = 1;
		}
	}
}

// Position - 0x179A0
bool func_304() {
	return true;
	return false;
}

// Position - 0x179AD
void func_305(int iParam0, int iParam1, char *sParam2, var uParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_111(5, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_110(5, iVar0);
		Global_1354542.f_3372[iVar0] = iParam0;
		Global_1354542.f_3372.f_172[iVar0] = iParam1;
		StringCopy(&Global_1354542.f_3372.f_11[iVar0 /*16*/], sParam2, 64);
		Global_1354542.f_3372.f_194[iVar0] = uParam3;
		Global_1354542.f_3372.f_183[iVar0] = iParam4;
		Global_1354542.f_3372.f_216[iVar0] = iParam5;
		Global_1354542.f_3372.f_227[iVar0] = iParam6;
		Global_1354542.f_3372.f_270[iVar0] = iParam7;
		Global_1354542.f_3372.f_281[iVar0] = iParam8;
		Global_1354542.f_3372.f_292[iVar0] = iParam9;
		Global_1354542.f_3372.f_303[iVar0] = iParam10;
	}
}

// Position - 0x17A9D
var func_306() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 2); }

// Position - 0x17AB7
bool func_307(char *sParam0) {
	if (gameplay::is_string_null(sParam0)) {
		return true;
	}
	else if (gameplay::are_strings_equal(sParam0, "") || gameplay::are_strings_equal(sParam0, "0")) {
		return true;
	}
	return false;
}

// Position - 0x17AF0
void func_308(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, char *sParam6,
			  int iParam7, float fParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13,
			  int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, int iParam19, int iParam20,
			  int iParam21, int iParam22) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_111(6, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_110(6, iVar0);
		Global_1354542.f_3686[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_3686.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_3686.f_183[iVar0] = iParam3;
		Global_1354542.f_3686.f_172[iVar0] = iParam2;
		Global_1354542.f_3686.f_260[iVar0] = iParam4;
		Global_1354542.f_3686.f_271[iVar0] = iParam5;
		StringCopy(&Global_1354542.f_3686.f_282[iVar0 /*16*/], sParam6, 64);
		Global_1354542.f_3686.f_443[iVar0] = iParam7;
		Global_1354542.f_3686.f_454[iVar0] = fParam8;
		Global_1354542.f_3686.f_497[iVar0] = iParam9;
		Global_1354542.f_3686.f_508[iVar0] = iParam10;
		Global_1354542.f_3686.f_205[iVar0] = iParam11;
		Global_1354542.f_3686.f_216[iVar0] = iParam12;
		Global_1354542.f_3686.f_227[iVar0] = iParam13;
		Global_1354542.f_3686.f_238[iVar0] = iParam14;
		Global_1354542.f_3686.f_249[iVar0] = iParam15;
		Global_1354542.f_3686.f_519[iVar0] = iParam16;
		Global_1354542.f_3686.f_530[iVar0] = iParam17;
		Global_1354542.f_3686.f_541[iVar0] = iParam18;
		Global_1354542.f_3686.f_552[iVar0] = iParam19;
		Global_1354542.f_3686.f_563[iVar0] = iParam20;
		Global_1354542.f_3686.f_574[iVar0] = iParam21;
		Global_1354542.f_3686.f_585[iVar0] = iParam22;
		if (iParam15 == 5 && func_310()) {
			Global_1354542.f_1004 = 1;
		}
		if (gameplay::is_pc_version()) {
			iVar2 = 0;
			graphics::_get_active_screen_resolution(&iVar3, &iVar4);
			if (iVar3 == 1280 && iVar4 >= 960) {
				iVar2 = 1;
			}
			if (iParam0 > 99999999) {
				Global_1354542.f_1008 = 1;
			}
			else if (iParam0 > 9999999 || iVar2) {
				Global_1354542.f_1007 = 1;
			}
			else if (iParam0 > 999) {
				Global_1354542.f_1004 = 1;
			}
			if (func_309()) {
				Global_1354542.f_1008 = 1;
			}
		}
	}
}

// Position - 0x17D32
bool func_309() {
	int iVar0;
	var uVar1;

	if (gameplay::is_pc_version()) {
		graphics::_get_active_screen_resolution(&iVar0, &uVar1);
		if (iVar0 <= 1024) {
			return true;
		}
	}
	return false;
}

// Position - 0x17D56
int func_310() {
	if (unk::_get_current_language_id() == 8 || unk::_get_current_language_id() == 9 ||
		unk::_get_current_language_id() == 10) {
		return 1;
	}
	return 0;
}

// Position - 0x17D87
void func_311() {
	char *sVar0;
	int iVar1;

	if (Global_1312323 == 1 || Global_1312330 == 1 || Global_1312319.f_3 == 1) {
		if (Global_1312323 == 1) {
			sVar0 = "HUD_SPIKES";
			iVar1 = 1;
		}
		else if (Global_1312330 == 1) {
			switch (Global_1312330.f_1) {
			case 0:
				iVar1 = 2;
				sVar0 = "HUD_ROCKET";
				break;

			case 1:
				iVar1 = 3;
				sVar0 = "HUD_ROCKET_H";
				break;

			case 2:
				iVar1 = 2;
				sVar0 = "HUD_ROCKET_NH";
				break;
			}
		}
		else if (Global_1312319.f_3 == 1) {
			sVar0 = "HUD_BOOSTS";
			iVar1 = 4;
		}
		func_308(1, sVar0, -1, 1, 5, 0, "", 0, 0f, 0, 0, 0, 0, 0, 0, iVar1, 0, 0, 0, 255, 0, 0, 0);
	}
	else if (Global_1312346 == 1) {
		sVar0 = "HUD_VEH_GUN";
		iVar1 = 9;
		func_308(Global_1312346.f_1, sVar0, -1, 1, 5, 0, "", 0, 0f, 0, 0, 0, 0, 0, 0, iVar1, 0, 0, 0, 255, 0, 0, 0);
	}
}

// Position - 0x17E7F
void func_312(int *iParam0, struct<4> Param1, var uParam5, var uParam6, var uParam7, var uParam8, var uParam9,
			  var uParam10, var uParam11, var uParam12, var uParam13, var uParam14, var uParam15, var uParam16,
			  var uParam17, var uParam18, var uParam19, var uParam20) {
	switch (*iParam0) {
	case 1:
		iParam0->f_2 = unk_0x67D02A194A2FC2BD("MIDSIZED_MESSAGE");
		if (graphics::has_scaleform_movie_loaded(iParam0->f_2)) {
			*iParam0 = 2;
		}
		break;

	case 2:
		graphics::_push_scaleform_movie_function(iParam0->f_2, "SHOW_SHARD_MIDSIZED_MESSAGE");
		graphics::begin_text_command_scaleform_string("BM_LAP_STR");
		ui::_set_notification_color_next(1);
		ui::add_text_component_substring_text_label("BM_LAP");
		ui::_set_notification_color_next(1);
		ui::add_text_component_integer(Param1.f_3 + 1);
		ui::_set_notification_color_next(1);
		ui::add_text_component_integer(Local_54.f_65);
		graphics::end_text_command_scaleform_string();
		graphics::_pop_scaleform_movie_function();
		iParam0->f_1 = gameplay::get_game_timer() + 3000;
		*iParam0 = 3;
		break;

	case 3:
		if (gameplay::get_game_timer() < iParam0->f_1 - 500) {
			if (graphics::has_scaleform_movie_loaded(iParam0->f_2)) {
				graphics::draw_scaleform_movie_fullscreen(iParam0->f_2, 255, 255, 255, 255, 0);
				graphics::_set_2d_layer(4);
			}
		}
		else {
			graphics::_push_scaleform_movie_function(iParam0->f_2, "SHARD_ANIM_OUT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			graphics::_push_scaleform_movie_function_parameter_float(0.33f);
			graphics::_pop_scaleform_movie_function_void();
			*iParam0 = 4;
		}
		break;

	case 4:
		if (gameplay::get_game_timer() < iParam0->f_1) {
			if (graphics::has_scaleform_movie_loaded(iParam0->f_2)) {
				graphics::draw_scaleform_movie_fullscreen(iParam0->f_2, 255, 255, 255, 255, 0);
				graphics::_set_2d_layer(4);
			}
		}
		else {
			if (graphics::has_scaleform_movie_loaded(iParam0->f_2)) {
				graphics::set_scaleform_movie_as_no_longer_needed(&iParam0->f_2);
			}
			graphics::set_scaleform_movie_as_no_longer_needed(&iParam0->f_2);
			*iParam0 = 0;
		}
		break;
	}
}

// Position - 0x17FC4
void func_313() { Global_1354542.f_1004 = 1; }

// Position - 0x17FD4
void func_314() {
	if (!entity::is_entity_in_angled_area(player::player_ped_id(), 1688.299f, 3336.851f, 24.68442f, 2475.163f,
										  2991.082f, 120.0549f, 480f, 0, 1, 0)) {
		func_224(3);
		sLocal_180 = "CRACEFAIL1";
	}
}

// Position - 0x1801E
void func_315() {
	iLocal_173 = 0;
	iLocal_174 = 0;
	iLocal_179 = 0;
	iLocal_176 = 0;
	iLocal_140 = 0;
	iLocal_178 = 0;
	func_323(&Local_54);
	func_322(&Local_1748);
	func_321(&Local_196, &Local_1748);
	func_320(&Local_597);
	func_319(&Local_1845);
	func_318(&Local_1943);
	func_317(&Local_46);
	func_316();
}

// Position - 0x1806D
void func_316() {
	Local_1978 = 0;
	Local_1978.f_1 = 0;
}

// Position - 0x1807F
void func_317(int *iParam0) {
	iParam0->f_5 = 0;
	iParam0->f_6 = 0;
	iParam0->f_7 = 0;
}

// Position - 0x18096
void func_318(var *uParam0) {
	int iVar0;

	*uParam0 = 0f;
	uParam0->f_1 = 0f;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_4 = 0;
	uParam0->f_5 = -1;
	uParam0->f_6 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_12 = 0;
	uParam0->f_13 = 0;
	if (Global_101700.f_24032 != 4) {
		iVar0 = gameplay::get_random_int_in_range(0, 3);
		if (iVar0 == 0) {
			uParam0->f_19 = 1;
		}
		else if (iVar0 == 1) {
			uParam0->f_19 = 0;
		}
		else if (iVar0 == 2) {
			uParam0->f_19 = 2;
		}
	}
	else {
		iVar0 = gameplay::get_random_int_in_range(0, 6);
		if (iVar0 == 0) {
			uParam0->f_19 = 1;
		}
		else if (iVar0 == 1 || iVar0 == 2) {
			uParam0->f_19 = 0;
		}
		else if (iVar0 == 3 || iVar0 == 4 || iVar0 == 5) {
			uParam0->f_19 = 2;
		}
	}
}

// Position - 0x18165
void func_319(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 1) {
		(*iParam0)[iVar0 /*11*/].f_9 = 0;
		(*iParam0)[iVar0 /*11*/].f_10 = 0;
		iVar0++;
	}
}

// Position - 0x18191
void func_320(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 23) {
		(*iParam0)[iVar0 /*50*/].f_41 = 0;
		(*iParam0)[iVar0 /*50*/].f_42 = 0;
		(*iParam0)[iVar0 /*50*/].f_44 = 0;
		(*iParam0)[iVar0 /*50*/].f_45 = 0;
		(*iParam0)[iVar0 /*50*/].f_43 = 0;
		iVar1 = gameplay::get_random_int_in_range(0, 4);
		if (iVar1 == 0) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_f_y_tourist_01");
		}
		else if (iVar1 == 1) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_f_y_tourist_02");
		}
		else if (iVar1 == 2) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_m_m_tourist_01");
		}
		else if (iVar1 == 3) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_m_m_hillbilly_02");
		}
		StringCopy(&(*iParam0)[iVar0 /*50*/].f_46, "Ambient Ped ", 16);
		StringIntConCat(&(*iParam0)[iVar0 /*50*/].f_46, iVar0, 16);
		switch (iVar0) {
		case 0:
			(*iParam0)[iVar0 /*50*/].f_37 = {1977.843f, 3129.412f, 45.9792f};
			(*iParam0)[iVar0 /*50*/].f_40 = 122.9084f;
			break;

		case 1:
			(*iParam0)[iVar0 /*50*/].f_37 = {1969.595f, 3115.701f, 45.8988f};
			(*iParam0)[iVar0 /*50*/].f_40 = -32.152f;
			break;

		case 2:
			(*iParam0)[iVar0 /*50*/].f_37 = {1986.622f, 3123.347f, 46.0496f};
			(*iParam0)[iVar0 /*50*/].f_40 = 143.293f;
			break;

		case 3:
			(*iParam0)[iVar0 /*50*/].f_37 = {1968.123f, 3117.722f, 45.9001f};
			(*iParam0)[iVar0 /*50*/].f_40 = 182.6841f;
			break;

		case 4:
			(*iParam0)[iVar0 /*50*/].f_37 = {1866.502f, 3220.542f, 44.2959f};
			(*iParam0)[iVar0 /*50*/].f_40 = 283.4628f;
			break;

		case 5:
			(*iParam0)[iVar0 /*50*/].f_37 = {1866.734f, 3226.219f, 44.2235f};
			(*iParam0)[iVar0 /*50*/].f_40 = 253.3484f;
			break;

		case 6:
			(*iParam0)[iVar0 /*50*/].f_37 = {1932.064f, 3262.209f, 44.7989f};
			(*iParam0)[iVar0 /*50*/].f_40 = 184.9414f;
			break;

		case 7:
			(*iParam0)[iVar0 /*50*/].f_37 = {1939.296f, 3269.148f, 45.2262f};
			(*iParam0)[iVar0 /*50*/].f_40 = 196.2922f;
			break;

		case 8:
			(*iParam0)[iVar0 /*50*/].f_37 = {1936.04f, 3264.806f, 44.8089f};
			(*iParam0)[iVar0 /*50*/].f_40 = 179.3959f;
			break;

		case 9:
			(*iParam0)[iVar0 /*50*/].f_37 = {1938.14f, 3266.329f, 44.8089f};
			(*iParam0)[iVar0 /*50*/].f_40 = 208.0957f;
			break;

		case 10:
			(*iParam0)[iVar0 /*50*/].f_37 = {1969.938f, 3262.41f, 44.5866f};
			(*iParam0)[iVar0 /*50*/].f_40 = 135.3289f;
			break;

		case 11:
			(*iParam0)[iVar0 /*50*/].f_37 = {2129.336f, 3274.596f, 45.093f};
			(*iParam0)[iVar0 /*50*/].f_40 = 158.6073f;
			break;

		case 12:
			(*iParam0)[iVar0 /*50*/].f_37 = {2131.781f, 3273.956f, 45.093f};
			(*iParam0)[iVar0 /*50*/].f_40 = 144.4747f;
			break;

		case 13:
			(*iParam0)[iVar0 /*50*/].f_37 = {2135.285f, 3273.007f, 45.1832f};
			(*iParam0)[iVar0 /*50*/].f_40 = 164.2929f;
			break;

		case 14:
			(*iParam0)[iVar0 /*50*/].f_37 = {2135.561f, 3274.741f, 45.6104f};
			(*iParam0)[iVar0 /*50*/].f_40 = 166.3804f;
			break;

		case 15:
			(*iParam0)[iVar0 /*50*/].f_37 = {2243.927f, 3247.596f, 47.1535f};
			(*iParam0)[iVar0 /*50*/].f_40 = 113.5077f;
			break;

		case 16:
			(*iParam0)[iVar0 /*50*/].f_37 = {2242.918f, 3248.862f, 47.1472f};
			(*iParam0)[iVar0 /*50*/].f_40 = 94.3813f;
			break;

		case 17:
			(*iParam0)[iVar0 /*50*/].f_37 = {2276.538f, 2995.181f, 44.9018f};
			(*iParam0)[iVar0 /*50*/].f_40 = 343.2186f;
			break;

		case 18:
			(*iParam0)[iVar0 /*50*/].f_37 = {2272.339f, 2995.217f, 44.7997f};
			(*iParam0)[iVar0 /*50*/].f_40 = 354.5168f;
			break;

		case 19:
			(*iParam0)[iVar0 /*50*/].f_37 = {2008.773f, 3110.642f, 45.9644f};
			(*iParam0)[iVar0 /*50*/].f_40 = 212.1216f;
			break;

		case 20:
			(*iParam0)[iVar0 /*50*/].f_37 = {1993.863f, 3099.198f, 45.9635f};
			(*iParam0)[iVar0 /*50*/].f_40 = 336.9819f;
			break;

		case 21:
			(*iParam0)[iVar0 /*50*/].f_37 = {1991.992f, 3100.387f, 45.9819f};
			(*iParam0)[iVar0 /*50*/].f_40 = 332.381f;
			break;

		case 22:
			(*iParam0)[iVar0 /*50*/].f_37 = {1987.643f, 3102.67f, 46.0614f};
			(*iParam0)[iVar0 /*50*/].f_40 = 327.4696f;
			break;
		}
		iVar0++;
	}
}

// Position - 0x18690
void func_321(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 8) {
		(*iParam0)[iVar0 /*50*/].f_41 = 0;
		(*iParam0)[iVar0 /*50*/].f_42 = 0;
		(*iParam0)[iVar0 /*50*/].f_44 = 0;
		(*iParam0)[iVar0 /*50*/].f_45 = 0;
		(*iParam0)[iVar0 /*50*/].f_43 = 1;
		(*iParam0)[iVar0 /*50*/].f_4 = iLocal_120;
		iVar1 = gameplay::get_random_int_in_range(0, 2);
		if (iVar1 == 0) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_m_y_motox_01");
		}
		else if (iVar1 == 1) {
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_m_y_motox_02");
		}
		iVar1 = gameplay::get_random_int_in_range(0, 6);
		if (iVar1 == 0) {
			(*iParam0)[iVar0 /*50*/].f_17.f_19 = 1;
		}
		else if (iVar1 == 1 || iVar1 == 2) {
			(*iParam0)[iVar0 /*50*/].f_17.f_19 = 0;
		}
		else if (iVar1 == 3 || iVar1 == 4 || iVar1 == 5) {
			(*iParam0)[iVar0 /*50*/].f_17.f_19 = 2;
		}
		StringCopy(&(*iParam0)[iVar0 /*50*/].f_46, "Racer ", 16);
		StringIntConCat(&(*iParam0)[iVar0 /*50*/].f_46, iVar0, 16);
		(*iParam0)[iVar0 /*50*/].f_5 = {(*iParam1)[iVar0 /*12*/]};
		(*iParam0)[iVar0 /*50*/].f_43 = 0;
		func_318(&(*iParam0)[iVar0 /*50*/].f_17);
		(*iParam0)[iVar0 /*50*/].f_17.f_11 = iVar0;
		(*iParam0)[iVar0 /*50*/].f_37 = {Local_54.f_26[iVar0 /*3*/]};
		(*iParam0)[iVar0 /*50*/].f_40 = Local_54.f_54[iVar0];
		if (iVar0 == 1) {
			(*iParam0)[iVar0 /*50*/].f_17.f_19 = 3;
			(*iParam0)[iVar0 /*50*/].f_3 = joaat("a_m_y_motox_02");
		}
		iVar0++;
	}
}

// Position - 0x18805
void func_322(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 8) {
		(*iParam0)[iVar0 /*12*/].f_7 = 0;
		(*iParam0)[iVar0 /*12*/].f_8 = 0;
		switch (Global_101700.f_24032) {
		case 0:
			switch (iVar0) {
			case 0: (*iParam0)[iVar0 /*12*/].f_2 = joaat("buccaneer"); break;

			case 1: (*iParam0)[iVar0 /*12*/].f_2 = func_131(); break;

			case 2: (*iParam0)[iVar0 /*12*/].f_2 = joaat("manana"); break;

			case 3: (*iParam0)[iVar0 /*12*/].f_2 = joaat("tornado"); break;

			case 4: (*iParam0)[iVar0 /*12*/].f_2 = joaat("blade"); break;

			case 5: (*iParam0)[iVar0 /*12*/].f_2 = joaat("vigero"); break;

			case 6: (*iParam0)[iVar0 /*12*/].f_2 = joaat("warrener"); break;

			case 7: (*iParam0)[iVar0 /*12*/].f_2 = joaat("peyote"); break;
			}
			break;

		case 1:
			switch (iVar0) {
			case 0: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator"); break;

			case 1: (*iParam0)[iVar0 /*12*/].f_2 = func_131(); break;

			case 2: (*iParam0)[iVar0 /*12*/].f_2 = joaat("sabregt"); break;

			case 3: (*iParam0)[iVar0 /*12*/].f_2 = joaat("buffalo"); break;

			case 4: (*iParam0)[iVar0 /*12*/].f_2 = joaat("ruiner"); break;

			case 5: (*iParam0)[iVar0 /*12*/].f_2 = joaat("coquette2"); break;

			case 6: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dukes"); break;

			case 7: (*iParam0)[iVar0 /*12*/].f_2 = joaat("phoenix"); break;
			}
			break;

		case 2:
			switch (iVar0) {
			case 0: (*iParam0)[iVar0 /*12*/].f_2 = joaat("pigalle"); break;

			case 1: (*iParam0)[iVar0 /*12*/].f_2 = func_131(); break;

			case 2: (*iParam0)[iVar0 /*12*/].f_2 = joaat("futo"); break;

			case 3: (*iParam0)[iVar0 /*12*/].f_2 = joaat("rapidgt"); break;

			case 4: (*iParam0)[iVar0 /*12*/].f_2 = joaat("sultan"); break;

			case 5: (*iParam0)[iVar0 /*12*/].f_2 = joaat("phoenix"); break;

			case 6: (*iParam0)[iVar0 /*12*/].f_2 = joaat("vigero"); break;

			case 7: (*iParam0)[iVar0 /*12*/].f_2 = joaat("sabregt"); break;
			}
			break;

		case 3:
			switch (iVar0) {
			case 0: (*iParam0)[iVar0 /*12*/].f_2 = joaat("gauntlet2"); break;

			case 1: (*iParam0)[iVar0 /*12*/].f_2 = func_131(); break;

			case 2: (*iParam0)[iVar0 /*12*/].f_2 = joaat("gauntlet2"); break;

			case 3: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator2"); break;

			case 4: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator2"); break;

			case 5: (*iParam0)[iVar0 /*12*/].f_2 = joaat("stalion2"); break;

			case 6: (*iParam0)[iVar0 /*12*/].f_2 = joaat("stalion2"); break;

			case 7: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator2"); break;
			}
			break;

		case 4:
			switch (iVar0) {
			case 0: (*iParam0)[iVar0 /*12*/].f_2 = joaat("gauntlet2"); break;

			case 1: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator2"); break;

			case 2: (*iParam0)[iVar0 /*12*/].f_2 = joaat("stalion2"); break;

			case 3: (*iParam0)[iVar0 /*12*/].f_2 = joaat("buffalo3"); break;

			case 4: (*iParam0)[iVar0 /*12*/].f_2 = joaat("gauntlet2"); break;

			case 5: (*iParam0)[iVar0 /*12*/].f_2 = joaat("buffalo3"); break;

			case 6: (*iParam0)[iVar0 /*12*/].f_2 = joaat("dominator2"); break;

			case 7: (*iParam0)[iVar0 /*12*/].f_2 = joaat("buffalo3"); break;
			}
			break;
		}
		iVar0++;
	}
}

// Position - 0x18BFA
void func_323(var *uParam0) {
	uParam0->f_64 = "CountryTrack2Backwards";
	uParam0->f_65 = 5;
	uParam0->f_19 = {1952.027f, 3120.291f, 45.15582f};
	uParam0->f_22 = {1967.819f, 3145.207f, 50.28004f};
	uParam0->f_25 = 20f;
	(*uParam0)[0 /*3*/] = {1874f, 3219.9f, 45.4f};
	(*uParam0)[1 /*3*/] = {2003.4f, 3300.5f, 45.7f};
	(*uParam0)[2 /*3*/] = {2238.1f, 3239.8f, 48.1f};
	(*uParam0)[3 /*3*/] = {2280.9f, 3007f, 46f};
	(*uParam0)[4 /*3*/] = {2144.7f, 3034.1f, 45.4f};
	(*uParam0)[5 /*3*/] = {1968.9f, 3127.1f, 46.9f};
	uParam0->f_26[0 /*3*/] = {1969.251f, 3122.565f, 46.0076f};
	uParam0->f_54[0] = 53.7102f;
	uParam0->f_26[1 /*3*/] = {1971f, 3125.064f, 46.036f};
	uParam0->f_54[1] = 52.6994f;
	uParam0->f_26[2 /*3*/] = {1972.986f, 3128.541f, 46.0069f};
	uParam0->f_54[2] = 54.9611f;
	uParam0->f_26[3 /*3*/] = {1975.501f, 3117.38f, 46.0271f};
	uParam0->f_54[3] = 56.1329f;
	uParam0->f_26[4 /*3*/] = {1977.609f, 3120.305f, 46.0576f};
	uParam0->f_54[4] = 52.8064f;
	uParam0->f_26[5 /*3*/] = {1979.872f, 3123.513f, 46.0285f};
	uParam0->f_54[5] = 54.0832f;
	uParam0->f_26[6 /*3*/] = {1981.754f, 3112.13f, 46.0491f};
	uParam0->f_54[6] = 47.3411f;
	uParam0->f_26[7 /*3*/] = {1984.234f, 3115.164f, 46.0766f};
	uParam0->f_54[7] = 58.6868f;
	uParam0->f_26[8 /*3*/] = {1986.348f, 3118.184f, 46.0478f};
	uParam0->f_54[8] = 55.8988f;
}

// Position - 0x18E0C
void func_324() {
	if (func_333()) {
		func_215(500);
	}
	audio::register_script_with_audio(1);
	player::set_player_control(player::player_id(), 1, 0);
	ui::display_radar(1);
	ui::display_hud(1);
	gameplay::set_time_scale(1f);
	ui::clear_prints();
	ui::clear_help(1);
	func_332();
	func_328(&uLocal_1857, 1, 0);
	iLocal_1975 = 0;
	iLocal_2127 = player::player_ped_id();
	func_327(sLocal_139, 11, 0);
	func_326(Local_54[0 /*3*/], 1000f);
	ped::add_scenario_blocking_area(2270.041f, 3007f, 44.1942f, 2276.215f, 3010.543f, 48.0713f, 0, 1, 1, 1);
	graphics::set_debug_lines_and_spheres_drawing_active(1);
	vehicle::set_all_vehicle_generators_active_in_area(-7000f, -7000f, -100f, 7000f, 7000f, 100f, 0, 1);
	vehicle::remove_vehicles_from_generators_in_area(-7000f, -7000f, -100f, 7000f, 7000f, 100f, 0);
	func_325(1);
	pathfind::set_roads_in_angled_area(2565.207f, 2896.662f, 29.9408f, 1654.53f, 3420.822f, 63.94006f, 470f, 0, 0, 1);
	ai::set_scenario_type_enabled("WORLD_VEHICLE_BIKER", 0);
	ai::set_scenario_type_enabled("DRIVE", 0);
	ai::set_scenario_type_enabled("WORLD_VEHICLE_DRIVE_SOLO", 0);
	ai::set_scenario_type_enabled("WORLD_VEHICLE_DRIVE_PASSENGERS", 0);
	streaming::set_ped_population_budget(0);
	streaming::set_reduce_ped_model_budget(1);
	streaming::set_vehicle_population_budget(0);
	streaming::set_reduce_vehicle_model_budget(1);
	player::set_dispatch_cops_for_player(player::player_id(), 0);
	ped::set_create_random_cops(0);
	player::set_wanted_level_multiplier(0f);
	player::set_player_wanted_level(player::player_id(), 0, 0);
	player::set_player_wanted_level_now(player::player_id(), 0);
	vehicle::_0xE6C0C80B8C867537(1);
	if (cam::is_gameplay_hint_active()) {
		cam::stop_gameplay_hint(0);
	}
	ped::set_ped_config_flag(player::player_ped_id(), 32, 0);
}

// Position - 0x18F97
void func_325(int iParam0) { Global_68531.f_138 = iParam0; }

// Position - 0x18FA7
var func_326(vector3 vParam0, float fParam3) {
	vector3 vVar0;

	vVar0 = {fParam3 / 2f, fParam3 / 2f, fParam3 / 2f};
	return ped::add_scenario_blocking_area(vParam0 - vVar0, vParam0 + vVar0, 0, 1, 1, 1);
}

// Position - 0x18FD9
void func_327(char *sParam0, int iParam1, int iParam2) {
	ui::_request_additional_text_2(sParam0, iParam1);
	if (iParam2) {
		while (!ui::has_additional_text_loaded(iParam1)) {
			system::wait(0);
		}
	}
}

// Position - 0x19000
void func_328(int *iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (gameplay::is_bit_set(uParam0->f_13, 30)) {
		iParam1 = 1;
	}
	func_331(uParam0);
	iVar0 = 0;
	while (iVar0 < 3) {
		if (ui::does_blip_exist(uParam0->f_1[iVar0])) {
			ui::remove_blip(&uParam0->f_1[iVar0]);
		}
		func_330(iVar0, uParam0);
		func_329(iVar0, uParam0);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 31) {
		if (iVar0 != 8) {
			gameplay::clear_bit(&uParam0->f_13, iVar0);
			gameplay::clear_bit(&uParam0->f_14, iVar0);
		}
		iVar0++;
	}
	if (ui::does_blip_exist(*uParam0)) {
		ui::remove_blip(uParam0);
	}
	iParam0->f_6 = 0;
	iParam0->f_12 = 0;
	iParam0->f_15 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		if (!ped::is_ped_injured(iParam0->f_17[iVar0])) {
			ped::set_ped_can_play_ambient_anims(iParam0->f_17[iVar0], 1);
			ped::set_ped_can_play_ambient_base_anims(iParam0->f_17[iVar0], 1);
			if (iParam2) {
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 32, 1);
				ped::set_ped_config_flag(iParam0->f_17[iVar0], 305, 0);
			}
			ped::set_ped_config_flag(iParam0->f_17[iVar0], 268, 0);
			if (iParam1) {
				if (ped::is_ped_group_member(iParam0->f_17[iVar0], func_129()) &&
					iParam0->f_17[iVar0] != player::player_ped_id()) {
					ped::remove_ped_from_group(iParam0->f_17[iVar0]);
				}
			}
			if (!gameplay::is_bit_set(iParam0->f_13, 29)) {
				ped::set_ped_using_action_mode(iParam0->f_17[iVar0], 0, -1, 0);
			}
			iParam0->f_17[iVar0] = 0;
		}
		iVar0++;
	}
	if (player::is_player_playing(player::player_id())) {
		ped::set_ped_can_play_ambient_anims(player::player_ped_id(), 1);
		ped::set_ped_can_play_ambient_base_anims(player::player_ped_id(), 1);
	}
	if (player::is_player_playing(player::player_id())) {
		if (iParam2) {
			ped::set_ped_config_flag(player::player_ped_id(), 32, 1);
		}
	}
	iParam0->f_21 = 0;
}

// Position - 0x191B1
void func_329(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 17); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 18); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 19); break;
	}
}

// Position - 0x191F9
void func_330(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&uParam1->f_13, 14); break;

	case 1: gameplay::clear_bit(&uParam1->f_13, 15); break;

	case 2: gameplay::clear_bit(&uParam1->f_13, 16); break;
	}
}

// Position - 0x19241
void func_331(var *uParam0) {
	if (ui::does_blip_exist(uParam0->f_5)) {
		ui::remove_blip(&uParam0->f_5);
	}
}

// Position - 0x1925C
void func_332() {
	ped::add_relationship_group("ENEMIES", &iLocal_1976);
	ped::add_relationship_group("BUDDIES", &iLocal_1977);
	ped::add_relationship_group("RACERS", &iLocal_120);
	ped::set_relationship_between_groups(5, 1862763509, iLocal_1976);
	ped::set_relationship_between_groups(1, 1862763509, iLocal_1977);
	ped::set_relationship_between_groups(255, 1862763509, iLocal_120);
	ped::set_relationship_between_groups(5, iLocal_1977, iLocal_1976);
	ped::set_relationship_between_groups(1, iLocal_1977, 1862763509);
	ped::set_relationship_between_groups(255, iLocal_1977, iLocal_120);
	ped::set_relationship_between_groups(5, iLocal_1976, 1862763509);
	ped::set_relationship_between_groups(5, iLocal_1976, iLocal_1977);
	ped::set_relationship_between_groups(255, iLocal_1976, iLocal_120);
	ped::set_relationship_between_groups(255, iLocal_120, iLocal_1976);
	ped::set_relationship_between_groups(255, iLocal_120, iLocal_1977);
	ped::set_relationship_between_groups(255, iLocal_120, 1862763509);
}

// Position - 0x19317
bool func_333() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return true;
	}
	return false;
}

// Position - 0x1933B
void func_334(int iParam0, int iParam1, int iParam2, int iParam3) {
	audio::release_script_audio_bank();
	func_348(iParam1);
	func_347(iParam1, iParam2);
	func_345(iParam1);
	func_344();
	func_343();
	func_342();
	if (Local_1943.f_16 != 0) {
		graphics::delete_checkpoint(Local_1943.f_16);
	}
	if (Local_1943.f_17 != 0) {
		graphics::delete_checkpoint(Local_1943.f_17);
	}
	func_341(&uLocal_142);
	func_328(&uLocal_1857, 1, 0);
	func_339();
	func_337();
	player::set_player_control(player::player_id(), 1, 0);
	ui::display_radar(1);
	ui::display_hud(1);
	gameplay::set_time_scale(1f);
	func_132(0, 0, 0, 2000, 1, 0);
	graphics::clear_timecycle_modifier();
	entity::set_entity_visible(iLocal_2127, 1, 0);
	func_231(&Local_46);
	func_225(&Local_1943);
	if (iParam1) {
		gameplay::clear_area(entity::get_entity_coords(iLocal_2127, 1), 1000f, 1, 0, 0, 0);
	}
	audio::set_frontend_radio_active(1);
	if (func_8(iLocal_2129)) {
		vehicle::set_vehicle_handbrake(iLocal_2129, 0);
	}
	graphics::_stop_all_screen_effects();
	audio::stop_audio_scenes();
	audio::stop_stream();
	if (iParam0) {
		vehicle::_0xE6C0C80B8C867537(0);
		func_336();
		player::set_max_wanted_level(5);
		gameplay::enable_dispatch_service(5, 1);
		gameplay::enable_dispatch_service(3, 1);
		vehicle::set_all_vehicle_generators_active();
		streaming::set_ped_population_budget(2);
		streaming::set_reduce_ped_model_budget(0);
		ai::set_scenario_type_enabled("WORLD_VEHICLE_BIKER", 1);
		ai::set_scenario_type_enabled("DRIVE", 1);
		ai::set_scenario_type_enabled("WORLD_VEHICLE_DRIVE_SOLO", 1);
		ai::set_scenario_type_enabled("WORLD_VEHICLE_DRIVE_PASSENGERS", 1);
		streaming::set_vehicle_population_budget(2);
		streaming::set_reduce_vehicle_model_budget(0);
		player::set_dispatch_cops_for_player(player::player_id(), 1);
		ped::set_create_random_cops(1);
		player::set_wanted_level_multiplier(1f);
		pathfind::set_roads_in_angled_area(2565.207f, 2896.662f, 29.9408f, 1654.53f, 3420.822f, 63.94006f, 470f, 0, 1,
										   1);
		vehicle::_0xE6C0C80B8C867537(0);
		if (func_8(player::get_players_last_vehicle())) {
			vehicle::set_vehicle_doors_locked(player::get_players_last_vehicle(), 1);
			vehicle::set_vehicle_handbrake(player::get_players_last_vehicle(), 0);
		}
		time::pause_clock(0);
		script::set_no_loading_screen(0);
		if (!iParam3) {
			func_12(197, 0, 0, 1, 0);
		}
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
			func_8(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0))) {
			entity::freeze_entity_position(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0);
		}
		else {
			entity::freeze_entity_position(player::player_ped_id(), 0);
		}
		func_3(500);
		func_335(&Global_101698);
		ped::set_ped_config_flag(player::player_ped_id(), 32, 1);
		cam::set_cinematic_button_active(1);
		script::terminate_this_thread();
	}
}

// Position - 0x1954D
void func_335(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0x1958A
void func_336() {
	ped::remove_relationship_group(iLocal_1976);
	ped::remove_relationship_group(iLocal_1977);
	ped::remove_relationship_group(iLocal_120);
}

// Position - 0x195A6
void func_337() {
	Global_14611 = 0;
	func_338();
}

// Position - 0x195B6
void func_338() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x1960D
void func_339() {
	Global_14611 = 0;
	func_340();
}

// Position - 0x1961D
void func_340() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0x1963E
void func_341(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x19664
void func_342() {}

// Position - 0x1966C
void func_343() {}

// Position - 0x19674
void func_344() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_196) {
		func_130(&Local_196[iVar0 /*50*/].f_1);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_1748) {
		func_130(&Local_1748[iVar0 /*12*/].f_1);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_1845) {
		func_130(&Local_1845[iVar0 /*11*/].f_1);
		iVar0++;
	}
	func_130(&Local_1943.f_14);
	func_130(&Local_1943.f_15);
}

// Position - 0x196EF
void func_345(bool bParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_1845) {
		func_346(&Local_1845[iVar0 /*11*/], bParam0);
		iVar0++;
	}
}

// Position - 0x19718
void func_346(int *iParam0, bool bParam1) {
	if (entity::does_entity_exist(*iParam0)) {
		if (entity::is_entity_attached(*iParam0)) {
			entity::detach_entity(*iParam0, 1, 1);
		}
		if (bParam1) {
			object::delete_object(iParam0);
		}
		else {
			entity::set_object_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0x19751
void func_347(bool bParam0, var uParam1) {
	int iVar0;

	if (uParam1 && bParam0) {
		if (func_8(iLocal_2127) && ped::is_ped_in_any_vehicle(iLocal_2127, 0)) {
			func_24();
		}
		func_127(&iLocal_2129, bParam0);
	}
	iVar0 = 0;
	while (iVar0 < Local_196) {
		func_127(&Local_196[iVar0 /*50*/].f_5, bParam0);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_1748) {
		func_127(&Local_1748[iVar0 /*12*/], bParam0);
		iVar0++;
	}
	func_127(&iLocal_2128, bParam0);
	func_127(&iLocal_2130, bParam0);
}

// Position - 0x197DD
void func_348(bool bParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Local_196) {
		func_128(&Local_196[iVar0 /*50*/], bParam0);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Local_597) {
		func_128(&Local_597[iVar0 /*50*/], 1);
		iVar0++;
	}
}

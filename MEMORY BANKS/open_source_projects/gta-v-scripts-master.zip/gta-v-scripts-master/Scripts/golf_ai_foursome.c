#pragma region Local Var //{
bool bLocal_0 = 0;
var uLocal_1 = 0;
var uLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
int iLocal_12 = 0;
var uLocal_13 = 0;
var uLocal_14 = 0;
float fLocal_15 = 0f;
var uLocal_16 = 0;
var uLocal_17 = 0;
int iLocal_18 = 0;
var uLocal_19 = 0;
var uLocal_20 = 0;
char *sLocal_21 = NULL;
float fLocal_22 = 0f;
var uLocal_23 = 0;
var uLocal_24 = 0;
var uLocal_25 = 0;
float fLocal_26 = 0f;
float fLocal_27 = 0f;
var uLocal_28 = 0;
int iLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
float fLocal_34 = 0f;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 10;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 2;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 8;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 8;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
var uLocal_94 = 0;
var uLocal_95 = 0;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
float fLocal_98 = 0f;
float fLocal_99 = 0f;
float fLocal_100 = 0f;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 17;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 17;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 12;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 12;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 12;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 9;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 9;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
var uLocal_212 = 0;
var uLocal_213 = 0;
var uLocal_214 = 0;
var uLocal_215 = 0;
var uLocal_216 = 0;
var uLocal_217 = 0;
var uLocal_218 = 2;
var uLocal_219 = 0;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var uLocal_223 = 0;
var uLocal_224 = 0;
var uLocal_225 = 0;
var uLocal_226 = 0;
var uLocal_227 = 0;
var uLocal_228 = 0;
var uLocal_229 = 0;
float fLocal_230 = 0f;
float fLocal_231 = 0f;
float fLocal_232 = 0f;
var uLocal_233 = 0;
vector3 vLocal_234 = {0f, 0f, 0f};
float fLocal_237 = 0f;
bool bLocal_238 = 0;
bool bLocal_239 = 0;
bool bLocal_240 = 0;
bool bLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
vector3 vLocal_248 = {0f, 0f, 0f};
var uLocal_251 = 0;
var uLocal_252 = 0;
int iLocal_253 = 0;
bool bLocal_254 = 0;
int iLocal_255 = 0;
int iLocal_256 = 0;
int iLocal_257 = 0;
var uLocal_258 = 0;
int iLocal_259 = 0;
int iLocal_260 = 0;
int iLocal_261 = 0;
#pragma endregion //}

void __EntryFunction__() {
	struct<170> Var0;
	struct<44> Var171;
	int iVar227;
	var *uVar228;
	var *uVar253;
	int iVar265;
	int iVar266;

	iLocal_3 = 1;
	iLocal_4 = 134;
	iLocal_5 = 134;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 1;
	iLocal_9 = 134;
	iLocal_10 = 1;
	iLocal_11 = 12;
	iLocal_12 = 12;
	fLocal_15 = 0.001f;
	iLocal_18 = -1;
	sLocal_21 = "NULL";
	fLocal_22 = 0f;
	fLocal_26 = -0.0375f;
	fLocal_27 = 0.17f;
	iLocal_29 = 3;
	fLocal_32 = 80f;
	fLocal_33 = 140f;
	fLocal_34 = 180f;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_93 = 0.05f + 0.275f - 0.01f;
	fLocal_96 = -0.05f;
	fLocal_97 = 0.92f;
	fLocal_98 = 1.94f;
	fLocal_99 = 2.99f;
	fLocal_100 = 3.7f;
	fLocal_230 = -1213f;
	fLocal_231 = 118.179f;
	fLocal_232 = 1f;
	vLocal_234 = {0.57f, 0.03f, 0f};
	fLocal_237 = 50f;
	iLocal_253 = 1;
	iLocal_259 = -1;
	iLocal_260 = -1;
	iLocal_261 = 200;
	Var0 = 1;
	Var0.f_1.f_15 = 4;
	Var0.f_1.f_152 = 2;
	Var0.f_1.f_167 = 2;
	Var171 = 9;
	Var171.f_30 = 4;
	Var171.f_43 = 4;
	uVar228 = 14;
	uVar253 = 11;
	iVar227 = 2;
	uLocal_242 = uLocal_242;
	if (player::has_force_cleanup_occurred(67)) {
		func_336(&Var171, &Var0);
	}
	func_335(8);
	while (true) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		}
		switch (iVar227) {
		case 2:
			if (bLocal_0) {
			}
			func_332(&Var171);
			streaming::request_anim_dict(func_331());
			streaming::request_anim_set("move_m@golfer@");
			func_327(&uVar253);
			iVar227 = 3;
			break;

		case 3:
			if (streaming::has_anim_dict_loaded(func_331()) && audio::request_script_audio_bank("GOLF_I", 0, -1) &&
				streaming::has_anim_set_loaded("move_m@golfer@") && func_326(&uVar253)) {
				func_323(&uVar228);
				iVar227 = 4;
			}
			break;

		case 4:
			if (!ped::is_ped_injured(player::player_ped_id()) && func_322(time::get_clock_hours())) {
				if (!cam::is_sphere_visible(func_321(&Var171, 2 + iVar265 * 2), 10f) &&
						!entity::is_entity_at_coord(player::player_ped_id(), func_321(&Var171, 2 + iVar265 * 2), 10f,
													10f, 10f, 0, 1, 0) ||
					func_320() || streaming::is_player_switch_in_progress() || cam::is_screen_faded_out() ||
					func_319(4)) {
					if (iVar266 == 0) {
						func_315(&Var171, &Var0[iVar265 /*170*/], 2 + iVar265 * 2,
								 gameplay::get_random_int_in_range(1, 3));
					}
					if (iVar266 < func_314(&Var0[iVar265 /*170*/])) {
						func_308(&Var171, &Var0[iVar265 /*170*/], iVar266);
					}
					iVar266++;
					if (iVar266 > func_314(&Var0[iVar265 /*170*/])) {
						iVar266 = 0;
						func_306(&Var171, &Var0[iVar265 /*170*/], func_307(&Var0[iVar265 /*170*/]),
								 func_314(&Var0[iVar265 /*170*/]));
						iVar265++;
						if (iVar265 >= Var0) {
							iVar227 = 5;
							iVar265 = 0;
						}
					}
				}
			}
			break;

		case 5:
			func_305(&uVar228, 8);
			func_304(8);
			iVar227 = 6;
			break;

		case 6:
			func_305(&uVar228, 8);
			if (func_319(4)) {
				func_297(&Var0[0 /*170*/], &Var171);
				func_335(4);
			}
			func_1(&uVar228, &Var171, &Var0[iVar265 /*170*/], &Var0, iVar265);
			iVar265++;
			if (iVar265 >= Var0) {
				iVar265 = 0;
			}
			if (func_319(1)) {
				func_335(1);
			}
			if (func_319(2)) {
				func_335(2);
			}
			break;

		case 9: func_336(&Var171, &Var0); break;

		default: break;
		}
		system::wait(0);
	}
}

// Position - 0x38D
void func_1(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4) {
	int iVar0;
	bool bVar1;
	struct<7> Var2;
	int *iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	vector3 vVar13;

	if (func_296(uParam2)) {
		iVar0 = 0;
		while (iVar0 < func_314(uParam2)) {
			func_295(uParam2, iVar0);
			iVar0++;
		}
		return;
	}
	func_294(&uParam2->f_15[uParam2->f_165 /*34*/], player::player_ped_id(), uParam2, uParam2->f_165, uParam1);
	uParam2->f_165++;
	if (uParam2->f_165 >= func_314(uParam2)) {
		uParam2->f_165 = 0;
	}
	bVar1 = player::get_player_wanted_level(player::player_id()) > 0;
	Var2.f_2 = 1097859072;
	Var2.f_3 = 1500;
	Var2.f_4 = 45;
	Var2.f_5 = 1103626240;
	Var2.f_6 = 5;
	Var2.f_6 = 25;
	iVar0 = 0;
	while (iVar0 < func_314(uParam2)) {
		if (entity::does_entity_exist(func_293(&uParam2->f_15[iVar0 /*34*/]))) {
			if (entity::is_entity_dead(func_293(&uParam2->f_15[iVar0 /*34*/]), 0) &&
				!func_292(uParam2, iVar0, 16777216)) {
				func_290(uParam2);
				return;
			}
			if (bVar1 && func_289(func_293(&uParam2->f_15[iVar0 /*34*/]), 1) < 100f) {
				func_290(uParam2);
				return;
			}
			if (func_280(func_293(&uParam2->f_15[iVar0 /*34*/]), func_288(uParam2, 0), &Var2, &iVar9, 1, 1, 0, 1, 1)) {
				func_290(uParam2);
				return;
			}
		}
		iVar0++;
	}
	if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		if (ped::get_vehicle_ped_is_in(player::player_ped_id(), 0) == func_288(uParam2, 0)) {
			entity::set_entity_as_mission_entity(func_288(uParam2, 0), 0, 0);
			entity::set_vehicle_as_no_longer_needed(&uParam2->f_152[0]);
			func_279(uParam2, 0, 0);
			if (entity::does_entity_exist(func_278(uParam2, 0)) && !entity::is_entity_dead(func_278(uParam2, 0), 0)) {
				if (ai::get_script_task_status(func_278(uParam2, 0), -1794415470) != 1) {
					ai::clear_ped_tasks(func_278(uParam2, 0));
					ai::task_turn_ped_to_face_entity(func_278(uParam2, 0), player::player_ped_id(), -1);
				}
			}
			if (entity::does_entity_exist(func_278(uParam2, 1)) && !entity::is_entity_dead(func_278(uParam2, 1), 0)) {
				if (ai::get_script_task_status(func_278(uParam2, 1), -1794415470) != 1) {
					ai::clear_ped_tasks(func_278(uParam2, 1));
					ai::task_turn_ped_to_face_entity(func_278(uParam2, 1), player::player_ped_id(), -1);
				}
			}
		}
		if (ped::get_vehicle_ped_is_in(player::player_ped_id(), 0) == func_288(uParam2, 1)) {
			entity::set_entity_as_mission_entity(func_288(uParam2, 1), 0, 0);
			entity::set_vehicle_as_no_longer_needed(&uParam2->f_152[1]);
			func_279(uParam2, 0, 1);
		}
	}
	if (Global_100728 == func_307(uParam2)) {
		func_277(uParam2, uParam1, iParam3);
	}
	if (iParam4 == 0 && func_319(16)) {
		iVar10 = func_276(Global_100728);
		if (func_307(uParam2) != iVar10 && !func_275(iParam3, iVar10)) {
			func_274(uParam2, uParam1, iVar10);
		}
	}
	if (func_273(uParam0, 1) || func_319(1)) {
		iVar0 = 0;
		while (iVar0 < func_314(uParam2)) {
			if (entity::does_entity_exist(func_293(&uParam2->f_15[iVar0 /*34*/]))) {
				if (!entity::is_entity_dead(func_293(&uParam2->f_15[iVar0 /*34*/]), 0)) {
					entity::set_entity_coords(func_293(&uParam2->f_15[iVar0 /*34*/]),
											  func_272(&uParam2->f_15[iVar0 /*34*/]), 1, 0, 0, 1);
				}
			}
			iVar0++;
		}
		func_271(uParam2, 2);
	}
	if (func_273(uParam0, 2) || func_319(2)) {
		iVar11 = func_276(Global_100728);
		func_274(uParam2, uParam1, iVar11);
	}
	switch (func_270(uParam2)) {
	case 5:
		if (!func_269(uParam2, 1048576)) {
			if (entity::does_entity_exist(func_268(uParam2, uParam2->f_165)) &&
				!entity::is_entity_dead(func_268(uParam2, uParam2->f_165), 0) &&
				entity::does_entity_exist(func_278(uParam2, uParam2->f_165)) &&
				!func_292(uParam2, uParam2->f_165, 16777216) &&
				func_267(func_268(uParam2, uParam2->f_165), func_278(uParam2, uParam2->f_165), 1) < 25f) {
				if (ai::get_script_task_status(func_278(uParam2, uParam2->f_165), -1794415470) != 1 &&
					!func_292(uParam2, uParam2->f_165, 67108864)) {
					ai::clear_ped_tasks(func_278(uParam2, uParam2->f_165));
					if (!ped::is_ped_in_vehicle(func_278(uParam2, uParam2->f_165), func_268(uParam2, uParam2->f_165),
												0)) {
						if (uParam2->f_165 == func_265(uParam2, func_266(uParam2, uParam2->f_165))) {
							if (!entity::does_entity_exist(func_278(uParam2, uParam2->f_165 + 1)) ||
								!ped::is_ped_getting_into_a_vehicle(func_278(uParam2, uParam2->f_165 + 1))) {
								ai::task_enter_vehicle(func_278(uParam2, uParam2->f_165),
													   func_268(uParam2, uParam2->f_165), -1, -1, 1f, 1, 0);
							}
						}
						else {
							ai::task_enter_vehicle(func_278(uParam2, uParam2->f_165), func_268(uParam2, uParam2->f_165),
												   -1, 0, 1f, 1, 0);
						}
					}
				}
			}
			else {
				func_271(uParam2, 2);
				iVar0 = 0;
				while (iVar0 < func_314(uParam2)) {
					if (iVar0 != func_264(uParam2)) {
						if (func_263(uParam1, uParam2, iVar0)) {
							vVar13 = {func_262(uParam1, func_307(uParam2), iVar0)};
						}
						else if (!func_261(uParam2, -1)) {
							vVar13 = {func_260(uParam1, func_307(uParam2), iVar0)};
						}
						else {
							vVar13 = {func_259(uParam2, iVar0)};
						}
						if (entity::does_entity_exist(func_278(uParam2, iVar0)) &&
							!entity::is_entity_dead(func_278(uParam2, iVar0), 0)) {
							ai::clear_ped_tasks(func_278(uParam2, iVar0));
							ai::task_follow_nav_mesh_to_coord(func_278(uParam2, iVar0), vVar13, 1f, -1, 1048576000, 0,
															  1193033728);
						}
					}
					iVar0++;
				}
				if (func_258(uParam1, uParam2)) {
					func_257(uParam2, 0);
				}
				else {
					func_257(uParam2, 1);
				}
			}
			if (func_256(uParam2, 0)) {
				iVar0 = 0;
				while (iVar0 < func_314(uParam2)) {
					func_255(&uParam2->f_15[iVar0 /*34*/], 33554432);
					iVar0++;
				}
				func_271(uParam2, 6);
				func_254(&uParam2->f_159);
			}
		}
		else {
			func_271(uParam2, 2);
			if (func_258(uParam1, uParam2)) {
				func_257(uParam2, 0);
			}
			else {
				func_257(uParam2, 1);
			}
		}
		break;

	case 6:
		if (func_251(&uParam2->f_159, 2f)) {
			func_248(uParam2, func_264(uParam2), uParam1, 1, 0);
		}
		if (func_247(uParam2) == 0 && func_314(uParam2) > 2 && !func_292(uParam2, 2, 67108864)) {
			if (func_314(uParam2) == 3) {
				func_248(uParam2, 2, uParam1, 0, 0);
			}
			else {
				func_248(uParam2, func_246(uParam2, 2, 3), uParam1, 0, 0);
			}
		}
		else if (func_314(uParam2) > 2 && !func_292(uParam2, 0, 67108864)) {
			func_248(uParam2, func_246(uParam2, 0, 1), uParam1, 0, 0);
		}
		break;

	case 2:
		if (!func_269(uParam2, 8388608)) {
			func_67(uParam0, uParam1, uParam2);
		}
		else if (func_66(uParam1, uParam2, iParam3, 0)) {
			func_65(uParam2, 8388608);
		}
		if (!ped::is_ped_injured(func_64(uParam2))) {
			ped::set_ped_reset_flag(func_64(uParam2), 129, 1);
		}
		if (func_63(uParam2, -1, 0)) {
			func_60(uParam1, uParam2);
			uParam2->f_157 = 0;
			while (uParam2->f_157 < func_314(uParam2)) {
				func_257(uParam2, 0);
				func_59(uParam2, 0f, 0f, 0f, 5);
				func_58(uParam2, 0f, 0f, -1f);
				uParam2->f_157++;
			}
			iVar12 = func_307(uParam2);
			if (!func_66(uParam1, uParam2, iParam3, 1)) {
				func_56(uParam2, 0, 8388608);
			}
			func_52(uParam0, uParam1, uParam2, 8, 0);
			func_51(uParam2, 0);
			if (func_307(uParam2) != iVar12) {
				func_44(uParam1, uParam2);
				func_271(uParam2, 3);
			}
			if (func_269(uParam2, 1048576)) {
				vVar13 = {func_260(uParam1, func_307(uParam2), func_264(uParam2))};
				func_42(uParam2, func_264(uParam2), vVar13, uParam1, 0, 1);
				ai::task_turn_ped_to_face_coord(func_64(uParam2), func_41(uParam1, func_307(uParam2)), 0);
			}
		}
		else if (func_39(&uParam2->f_15[func_264(uParam2) /*34*/])) {
			func_38(&uParam2->f_15[func_264(uParam2) /*34*/]);
			func_51(uParam2, func_26(uParam2, uParam1));
			if (!func_261(uParam2, -1)) {
				func_257(uParam2, 0);
			}
			else if (func_18(uParam2, uParam1)) {
				func_271(uParam2, 5);
				func_257(uParam2, 1);
			}
			else {
				func_257(uParam2, 1);
			}
		}
		break;

	case 3:
		if (func_269(uParam2, 524288)) {
			func_2(uParam2, uParam1, 1);
		}
		func_271(uParam2, 5);
		break;

	case 4: break;
	}
}

// Position - 0xC2A
void func_2(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	float *fVar8;
	int iVar9;

	iVar1 = func_307(uParam0);
	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		func_17(&uParam0->f_15[iVar0 /*34*/], 0, 0);
		func_9(uParam0, iVar0, 0f, 0f, 0f, 5, 1);
		if (entity::does_entity_exist(func_293(&uParam0->f_15[iVar0 /*34*/]))) {
			if (!entity::is_entity_dead(func_293(&uParam0->f_15[iVar0 /*34*/]), 0)) {
				entity::set_entity_coords(func_293(&uParam0->f_15[iVar0 /*34*/]), func_260(uParam1, iVar1, iVar0), 1, 0,
										  0, 1);
			}
		}
		iVar0++;
	}
	if (iParam2) {
		vVar2 = {0f, 0f, 0f};
		vVar5 = {5f, 5f, 0f};
		fVar8 = 0f;
		if (func_3(func_321(uParam1, iVar1), func_41(uParam1, iVar1), &vVar2, &fVar8, 0f, 0f, 0f, 0f, 0f, 0f, 0)) {
			iVar9 = 0;
			while (iVar9 < 2) {
				if (entity::does_entity_exist(func_288(uParam0, iVar9))) {
					if (!entity::is_entity_dead(func_288(uParam0, iVar9), 0) &&
						!cam::is_sphere_visible(vVar2 + FtoV(system::to_float(iVar9)) * vVar5, 5f)) {
						entity::set_entity_coords(func_288(uParam0, iVar9),
												  vVar2 + FtoV(system::to_float(iVar9)) * vVar5, 1, 0, 0, 1);
						entity::set_entity_heading(func_288(uParam0, iVar9), fVar8);
					}
				}
				iVar9++;
			}
		}
	}
}

// Position - 0xD67
bool func_3(vector3 vParam0, struct<2> Param3, var uParam5, var *uParam6, float *fParam7, vector3 vParam8,
			struct<2> Param11, float fParam13, int iParam14) {
	int iVar0;
	int iVar1;
	var uVar2;
	vector3 vVar3;

	iVar1 = 1;
	vVar3 = {0f, 0f, 0f};
	while (!iVar0 && iVar1 < 10) {
		if (!pathfind::get_nth_closest_vehicle_node_with_heading(vParam0, iVar1, uParam6, fParam7, &uVar2, 1, 3f, 0f)) {
			return false;
		}
		else if (system::vdist2(vParam0, *uParam6) > 100f && !vehicle::is_any_vehicle_near_point(*uParam6, 5f) &&
				 !func_7(*uParam6)) {
			vVar3 = {func_6(Vector(0f, uParam6->f_1, *uParam6) - Vector(0f, Param11.f_1, Param11))};
			if (!iParam14 || func_5(vParam8, vVar3) < 0.75f) {
				iVar0 = 1;
			}
		}
		iVar1++;
	}
	if (gameplay::absf(gameplay::get_heading_from_vector_2d(Param3 - vParam0.x, Param3.f_1 - vParam0.y) - *fParam7) >
		90f) {
		*fParam7 += 180f;
	}
	func_4(uParam6, 5f, 0.5f);
	return true;
}

// Position - 0xE5C
int func_4(var *uParam0, float fParam1, float fParam2) {
	float fVar0;

	if (gameplay::get_ground_z_for_3d_coord(*uParam0 + Vector(fParam2, 0f, 0f), &fVar0, 0)) {
		if (gameplay::absf(uParam0->f_2 - fVar0) < fParam1) {
			uParam0->f_2 = fVar0;
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0xE9A
float func_5(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
	return Param0 * Param3 + Param0.f_1 * Param3.f_1;
}

// Position - 0xEB1
Vector3 func_6(vector3 vParam0) {
	float fVar0;
	float fVar1;

	fVar0 = system::vmag(vParam0);
	if (fVar0 != 0f) {
		fVar1 = 1f / fVar0;
		vParam0 = {vParam0 * FtoV(fVar1)};
	}
	else {
		vParam0.x = 0f;
		vParam0.y = 0f;
		vParam0.z = 0f;
	}
	return vParam0;
}

// Position - 0xEF0
int func_7(vector3 vParam0) {
	vector3 vVar0;
	float fVar3;

	vVar0 = {func_6(Vector(51.66f, 61.69f, -1405.69f) - Vector(51.76f, 61.61f, -1403.44f))};
	fVar3 = func_8(vVar0, -1405.69f, 61.69f, 51.66f);
	if (func_8(vParam0, vVar0) > fVar3) {
		return 1;
	}
	vVar0 = {func_6(Vector(0f, -85.86f, -1167.9f) - Vector(0f, -89.1f, -1162.01f))};
	fVar3 = func_8(vVar0, Vector(0f, -89.1f, -1162.01f) - FtoV(9.92f) * vVar0);
	if (func_8(vParam0, vVar0) > fVar3) {
		vVar0 = {func_6(Vector(0f, -89.76f, -1193.7f) - Vector(0f, -87.41f, -1192.45f))};
		fVar3 = func_8(vVar0, Vector(39.97f, -89.76f, -1193.7f) - FtoV(2.778f) * vVar0);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
		if (object::is_point_in_angled_area(vParam0, -1227.909f, -68.76888f, 43.06714f, -1260.599f, -50.60131f,
											44.63058f, 2.74f, 0, 0)) {
			return 1;
		}
	}
	else {
		vVar0 = {func_6(Vector(0f, -89.76f, -1193.7f) - Vector(0f, -87.41f, -1192.45f))};
		fVar3 = func_8(vVar0, Vector(39.97f, -89.76f, -1193.7f) - FtoV(1.03f) * vVar0);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	vVar0 = {func_6(Vector(0f, -113.24f, -970.31f) - Vector(0f, -115.19f, -973.91f))};
	fVar3 = func_8(vVar0, -970.31f, -113.24f, 38.28f);
	if (func_8(vParam0, vVar0) > fVar3) {
		vVar0 = {func_6(Vector(0f, -106.46f, -948.52f) - Vector(0f, -102.2f, -951.06f))};
		fVar3 = func_8(vVar0, -948.52f, -106.46f, 42.39f);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	else {
		vVar0 = {func_6(Vector(0f, -127.38f, -1028.62f) - Vector(0f, -129.55f, -1034.37f))};
		fVar3 = func_8(vVar0, -1028.62f, -127.38f, 39.51f);
		if (func_8(vParam0, vVar0) > fVar3) {
			vVar0 = {func_6(Vector(0f, -125.95f, -994.29f) - Vector(0f, -94.44f, -1001.81f))};
			fVar3 = func_8(vVar0, -994.29f, -125.95f, 40.12f);
			if (func_8(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
		else {
			vVar0 = {func_6(Vector(0f, -140.83f, -1037.99f) - Vector(0f, -131.81f, -1043.54f))};
			fVar3 = func_8(vVar0, -1037.99f, -140.83f, 42.99f);
			if (func_8(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
	}
	vVar0 = {func_6(Vector(0f, 96.74f, -1047.59f) - Vector(0f, 87.45f, -1041.82f))};
	fVar3 = func_8(vVar0, -1047.59f, 96.74f, 52.25f);
	if (func_8(vParam0, vVar0) > fVar3) {
		vVar0 = {func_6(Vector(0f, 180.44f, -1094.08f) - Vector(0f, 167.17f, -1086.17f))};
		fVar3 = func_8(vVar0, -1094.08f, 180.44f, 61.49f);
		if (func_8(vParam0, vVar0) > fVar3) {
			vVar0 = {func_6(Vector(0f, 196.78f, -1092f) - Vector(0f, 179.38f, -1163.07f))};
			fVar3 = func_8(vVar0, Vector(60.09f, 196.78f, -1092f) - FtoV(3.75f) * vVar0);
			if (func_8(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
		else {
			vVar0 = {func_6(Vector(0f, 145.22f, -1069.28f) - Vector(0f, 98.02f, -1152.37f))};
			fVar3 = func_8(vVar0, -1069.28f, 145.22f, 61.6f);
			if (func_8(vParam0, vVar0) > fVar3) {
				return 1;
			}
		}
	}
	else {
		vVar0 = {func_6(Vector(0f, -19.35f, -967.03f) - Vector(0f, -63.01f, -1035.28f))};
		fVar3 = func_8(vVar0, -967.03f, -19.35f, 48.28f);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	vVar0 = {func_6(Vector(0f, 186.79f, -1274.15f) - Vector(0f, 185.87f, -1255.38f))};
	fVar3 = func_8(vVar0, -1274.15f, 186.79f, 61.97f);
	if (func_8(vParam0, vVar0) > fVar3) {
		vVar0 = {func_6(Vector(0f, 192.648f, -1326.063f) - Vector(0f, 183.78f, -1325.44f))};
		fVar3 = func_8(vVar0, -1326.063f, 192.648f, 61.76f);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	else {
		vVar0 = {func_6(Vector(0f, 226.63f, -1159.35f) - Vector(0f, 203.93f, -1152.92f))};
		fVar3 = func_8(vVar0, -1159.35f, 226.63f, 70f);
		if (func_8(vParam0, vVar0) > fVar3) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1489
float func_8(vector3 vParam0, vector3 vParam3) {
	return vParam0.x * vParam3.x + vParam0.y * vParam3.y + vParam0.z * vParam3.z;
}

// Position - 0x14AA
void func_9(var *uParam0, int iParam1, vector3 vParam2, int iParam5, int iParam6) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_10(&uParam0->f_15[iParam1 /*34*/], vParam2, iParam5, iParam6);
}

// Position - 0x14DD
void func_10(var *uParam0, vector3 vParam1, int iParam4, int iParam5) {
	if (iParam5) {
	}
	if (!func_16(vParam1)) {
		if (iParam4 == 3) {
			if (func_13(vParam1)) {
				iParam4 = 2;
			}
		}
		if (func_11(vParam1)) {
			iParam4 = 9;
		}
	}
	uParam0->f_23 = iParam4;
}

// Position - 0x151F
bool func_11(vector3 vParam0) { return func_12(vParam0, -1215.93f, -15.72f, 45.21f, 2.5f, 1); }

// Position - 0x1544
bool func_12(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	return gameplay::get_distance_between_coords(vParam0, vParam3, iParam7) <= fParam6;
}

// Position - 0x155D
bool func_13(vector3 vParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 9) {
		if (system::vdist2(func_15(iVar0), vParam0) < func_14(iVar0) * func_14(iVar0)) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x159C
float func_14(int iParam0) {
	switch (iParam0) {
	case 0: return 11.26f;

	case 1: return 10.38f;

	case 2: return 13.4f;

	case 3: return 8.94f;

	case 4: return 12.8f;

	case 5: return 9.42f;

	case 6: return 9.42f;

	case 7: return 15f;

	case 8: return 11.69f;
	}
	return 0f;
}

// Position - 0x1645
Vector3 func_15(int iParam0) {
	switch (iParam0) {
	case 0: return -1370.93f, 173.98f, 57.01f;

	case 1: return -1107.26f, 157.15f, 62.04f;

	case 2: return -1312.97f, 125.64f, 56.39f;

	case 3: return -1218.56f, 107.48f, 57.04f;

	case 4: return -1098.15f, 69.5f, 53.09f;

	case 5: return -987.7f, -105.42f, 39.59f;

	case 6: return -1117.793f, -104.069f, 40.8406f;

	case 7: return -1272.63f, 38.4f, 48.75f;

	case 8: return -1138.381f, 0.60467f, 47.98225f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x174A
int func_16(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0x1774
void func_17(var *uParam0, int iParam1, int iParam2) {
	if (iParam2) {
	}
	*uParam0 = iParam1;
}

// Position - 0x1786
bool func_18(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 150;
	iVar1 = 1600;
	if (!entity::does_entity_exist(func_64(uParam0))) {
		return false;
	}
	if (system::vdist2(entity::get_entity_coords(func_64(uParam0), 1), func_41(uParam1, func_307(uParam0))) <
		IntToFloat(iVar1)) {
		if (entity::does_entity_exist(func_25(uParam0)) &&
			!entity::is_entity_dead(func_288(uParam0, func_247(uParam0)), 0)) {
			if (system::vdist2(entity::get_entity_coords(func_25(uParam0), 1), func_41(uParam1, func_307(uParam0))) >
				IntToFloat(iVar1)) {
				return true;
			}
			func_20(uParam0, uParam1, func_247(uParam0), 1, 37615 /*func_262*/, 7472 /*func_41*/);
		}
		return false;
	}
	if (system::vdist2(entity::get_entity_coords(func_64(uParam0), 1), func_19(uParam0)) < IntToFloat(iVar0)) {
		return false;
	}
	return true;
}

// Position - 0x1851
Vector3 func_19(var *uParam0) { return func_272(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x1867
void func_20(var *uParam0, var *uParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if ((iParam2 == 0 && (iVar0 == 0 || iVar0 == 1) || iParam2 == 1 && (iVar0 == 2 || iVar0 == 3)) &&
			func_23(uParam0, iVar0) == 4) {
			ai::open_sequence_task(&uParam0->f_15[iVar0 /*34*/].f_21);
			ai::task_leave_any_vehicle(0, 0, 0);
			Stack.Push(0);
			Stack.Push(uParam1);
			Stack.Push(func_307(uParam0));
			Stack.Push(iVar0);
			Call_Loc(iParam4);
			ai::task_follow_nav_mesh_to_coord(StackVal, StackVal, StackVal, StackVal, 1f, -1, 1048576000, 0,
											  1193033728);
			Stack.Push(0);
			Stack.Push(uParam1);
			Stack.Push(func_307(uParam0));
			Call_Loc(iParam5);
			ai::task_turn_ped_to_face_coord(StackVal, StackVal, StackVal, StackVal, 0);
			ai::close_sequence_task(uParam0->f_15[iVar0 /*34*/].f_21);
			ai::task_perform_sequence(func_278(uParam0, iVar0), uParam0->f_15[iVar0 /*34*/].f_21);
			ai::clear_sequence_task(&uParam0->f_15[iVar0 /*34*/].f_21);
			if (iParam3 && func_21(uParam0, iVar0) != 10) {
				func_56(uParam0, iVar0, 67108864);
			}
		}
		iVar0++;
	}
}

// Position - 0x1965
int func_21(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return -1;
	}
	return func_22(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x1991
int func_22(var *uParam0) { return *uParam0; }

// Position - 0x199C
int func_23(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_24(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x19C8
int func_24(var *uParam0) { return uParam0->f_1; }

// Position - 0x19D4
int func_25(var *uParam0) { return func_288(uParam0, func_266(uParam0, func_264(uParam0))); }

// Position - 0x19EE
int func_26(var *uParam0, var *uParam1) {
	float fVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	vector3 vVar4;
	vector3 vVar7;

	fVar0 = 0f;
	iVar1 = -1;
	if (func_36(uParam0) < 0.7f * 0.7f && func_35(uParam0) == 3 && func_34(uParam0) != 10 &&
		func_29(uParam0, uParam1)) {
		return func_264(uParam0);
	}
	iVar2 = 0;
	while (iVar2 < func_314(uParam0)) {
		if (func_23(uParam0, iVar2) != 0) {
			if (func_21(uParam0, iVar2) != 10 && !func_292(uParam0, iVar2, 16777216)) {
				vVar4 = {func_259(uParam0, iVar2)};
				vVar7 = {func_41(uParam1, func_307(uParam0))};
				vVar4.z = 0f;
				vVar7.z = 0f;
				fVar3 = system::vdist(vVar4, vVar7);
				fVar3 *= func_27(func_28(&uParam0->f_15[iVar2 /*34*/]) == 3, 1f, 99999f);
				fVar3 *= func_27(func_28(&uParam0->f_15[iVar2 /*34*/]) == 5, 100f, 1f);
				fVar3 *= IntToFloat(uParam0->f_15[iVar2 /*34*/].f_32 + 1);
				if (fVar3 > fVar0) {
					iVar1 = iVar2;
					fVar0 = fVar3;
				}
			}
		}
		iVar2++;
	}
	if (iVar1 == -1) {
		iVar1 = 0;
	}
	if (bLocal_0) {
	}
	return iVar1;
}

// Position - 0x1B26
float func_27(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x1B3D
int func_28(var *uParam0) { return uParam0->f_23; }

// Position - 0x1B49
int func_29(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if (func_28(&uParam0->f_15[iVar0 /*34*/]) != 3 && func_28(&uParam0->f_15[iVar0 /*34*/]) != 8 &&
			func_21(uParam0, iVar0) != 10 && !func_292(uParam0, iVar0, 16384) && !func_30(uParam0, uParam1, iVar0, 0) &&
			!func_292(uParam0, iVar0, 16777216)) {
			return 0;
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x1BD7
bool func_30(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	if (iParam2 == -1) {
		iParam2 = func_264(uParam0);
	}
	return func_32(uParam0, iParam2) >= func_31(uParam1, func_307(uParam0)) + 5 + iParam3;
}

// Position - 0x1C07
int func_31(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0;
	}
	return (*uParam0)[iParam1 /*3*/].f_1;
}

// Position - 0x1C2F
int func_32(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_33(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x1C5B
int func_33(var *uParam0) { return uParam0->f_18; }

// Position - 0x1C67
int func_34(var *uParam0) {
	if (uParam0->f_157 < 0) {
		return -1;
	}
	return func_22(&uParam0->f_15[uParam0->f_157 /*34*/]);
}

// Position - 0x1C89
int func_35(var *uParam0) { return func_28(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x1C9F
float func_36(var *uParam0) { return func_37(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x1CB5
float func_37(var *uParam0) { return uParam0->f_13; }

// Position - 0x1CC1
void func_38(var *uParam0) {
	if (entity::does_entity_exist(uParam0->f_4)) {
		entity::detach_entity(uParam0->f_4, 1, 1);
		object::delete_object(&uParam0->f_4);
	}
}

// Position - 0x1CE6
bool func_39(var *uParam0) {
	if (func_22(uParam0) == 9 || func_22(uParam0) == 10 || func_40(uParam0, 16777216)) {
		return true;
	}
	return false;
}

// Position - 0x1D1F
bool func_40(var *uParam0, int iParam1) { return (uParam0->f_22 & iParam1) != 0; }

// Position - 0x1D30
Vector3 func_41(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0: return -1114.121f, 220.789f, 63.78f;

	case 1: return -1322.07f, 158.77f, 56.69f;

	case 2: return -1237.419f, 112.988f, 56.086f;

	case 3: return -1096.541f, 7.848f, 49.63f;

	case 4: return -957.386f, -90.412f, 39.161f;

	case 5: return -1103.516f, -115.163f, 40.444f;

	case 6: return -1290.633f, 2.771f, 49.219f;

	case 7: return -1034.944f, -83.144f, 42.919f;

	case 8: return -1294.775f, 83.51f, 53.804f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x1E4F
void func_42(var *uParam0, int iParam1, vector3 vParam2, var *uParam5, int iParam6, int iParam7) {
	var uVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	float *fVar8;
	int iVar9;

	if (iParam6) {
		if (gameplay::get_ground_z_for_3d_coord(vParam2 + Vector(50f, 0f, 0f), &uVar0, 0)) {
			vParam2.z = uVar0;
		}
	}
	entity::set_entity_coords(func_278(uParam0, iParam1), vParam2, 0, 0, 0, 1);
	iVar1 = func_266(uParam0, iParam1);
	if (entity::does_entity_exist(func_288(uParam0, iVar1)) && iParam7) {
		vVar2 = {0f, 0f, 0f};
		vVar5 = {0f, 0f, 0f};
		fVar8 = 0f;
		if (iVar1 > 0) {
			vVar5 = {5f, 5f, 0f};
		}
		if (!entity::is_entity_dead(func_288(uParam0, iVar1), 0)) {
			if (func_292(uParam0, iParam1, 1048576)) {
				iVar9 = func_43(vParam2 + vVar5, func_41(uParam5, func_307(uParam0)), &vVar2, &fVar8);
			}
			else {
				iVar9 = func_3(vParam2 + vVar5, func_41(uParam5, func_307(uParam0)), &vVar2, &fVar8, 0f, 0f, 0f, 0f, 0f,
							   0f, 0);
			}
			if (iVar9 && !cam::is_sphere_visible(vVar2, 5f)) {
				entity::set_entity_coords(func_288(uParam0, iVar1), vVar2, 1, 0, 0, 1);
				entity::set_entity_heading(func_288(uParam0, iVar1), fVar8);
			}
		}
	}
}

// Position - 0x1F68
bool func_43(vector3 vParam0, struct<2> Param3, var uParam5, var uParam6, float *fParam7) {
	if (!pathfind::get_closest_vehicle_node_with_heading(vParam0, uParam6, fParam7, 1, 1077936128, 0)) {
		return false;
	}
	if (gameplay::absf(gameplay::get_heading_from_vector_2d(Param3 - vParam0.x, Param3.f_1 - vParam0.y) - *fParam7) >
		90f) {
		*fParam7 += 180f;
	}
	return true;
}

// Position - 0x1FBB
void func_44(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam1)) {
		func_10(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, 0f, 5, 1);
		func_50(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, -1f);
		func_49(&uParam1->f_15[iVar0 /*34*/], 0f, 0f, 0f);
		func_48(&uParam1->f_15[iVar0 /*34*/], func_321(uParam0, func_307(uParam1)));
		func_46(&uParam1->f_15[iVar0 /*34*/], func_47(uParam0, func_307(uParam1)));
		func_45(&uParam1->f_15[iVar0 /*34*/], 0);
		iVar0++;
	}
}

// Position - 0x2046
void func_45(var *uParam0, int iParam1) { uParam0->f_18 = iParam1; }

// Position - 0x2054
void func_46(var *uParam0, float fParam1) { uParam0->f_13 = fParam1; }

// Position - 0x2062
float func_47(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f;
	}
	return (*uParam0)[iParam1 /*3*/];
}

// Position - 0x2088
void func_48(var *uParam0, vector3 vParam1) { uParam0->f_7 = {vParam1}; }

// Position - 0x209A
void func_49(var *uParam0, vector3 vParam1) { uParam0->f_10 = {vParam1}; }

// Position - 0x20AC
void func_50(var *uParam0, vector3 vParam1) { uParam0->f_25 = {vParam1}; }

// Position - 0x20BE
void func_51(var *uParam0, int iParam1) { uParam0->f_157 = iParam1; }

// Position - 0x20CC
int func_52(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4) {
	int iVar0;

	uParam2->f_158++;
	if (iParam4) {
		func_55(func_307(uParam2));
	}
	iVar0 = 1;
	if (func_307(uParam2) >= iParam3 + 1 || uParam0->f_23) {
		if (iParam4 && iVar0) {
			func_54(uParam2, iParam3);
			uParam0->f_23 = 0;
			return 1;
		}
		else {
			if (func_307(uParam2) >= func_53(uParam1)) {
				func_54(uParam2, 0);
			}
			return 0;
		}
	}
	return 0;
}

// Position - 0x2143
int func_53(var *uParam0) { return uParam0->f_28; }

// Position - 0x214F
void func_54(var *uParam0, int iParam1) { uParam0->f_158 = iParam1; }

// Position - 0x215D
void func_55(int iParam0) { Global_100728 = iParam0; }

// Position - 0x216B
void func_56(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_57(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0x2198
void func_57(var *uParam0, int iParam1) { uParam0->f_22 |= iParam1; }

// Position - 0x21AB
void func_58(var *uParam0, vector3 vParam1) { func_50(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x21C5
void func_59(var *uParam0, vector3 vParam1, int iParam4) {
	func_10(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1, iParam4, 1);
}

// Position - 0x21E2
void func_60(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam1)) {
		if (func_23(uParam1, iVar0) != 3) {
			func_61(uParam1, iVar0);
		}
		iVar0++;
	}
}

// Position - 0x2215
void func_61(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_62(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x2240
void func_62(var *uParam0) {
	if (func_40(uParam0, 128)) {
		streaming::clear_focus();
		func_255(uParam0, 128);
	}
	if (entity::does_entity_exist(uParam0->f_3)) {
		if (streaming::is_entity_focus(uParam0->f_3)) {
			streaming::clear_focus();
		}
		if (entity::is_entity_a_mission_entity(uParam0->f_3)) {
			object::delete_object(&uParam0->f_3);
		}
	}
	uParam0->f_3 = 0;
}

// Position - 0x2291
bool func_63(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if (iParam1 < 0 || iParam1 != iVar0) {
			if (func_22(&uParam0->f_15[iVar0 /*34*/]) != 10 &&
				(func_24(&uParam0->f_15[iVar0 /*34*/]) != 4 || !iParam2) && !func_292(uParam0, iVar0, 16777216)) {
				return false;
			}
		}
		iVar0++;
	}
	return true;
}

// Position - 0x2308
int func_64(var *uParam0) {
	if (uParam0->f_157 < 0) {
		return 0;
	}
	return func_293(&uParam0->f_15[uParam0->f_157 /*34*/]);
}

// Position - 0x232A
void func_65(var *uParam0, int iParam1) { func_255(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x2342
bool func_66(var *uParam0, var *uParam1, var *uParam2, int iParam3) {
	int iVar0;
	int iVar1;

	iVar1 = func_307(uParam1) + iParam3;
	if (iVar1 >= func_53(uParam0)) {
		iVar1 = 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam2) {
		if (func_307(&(*uParam2)[iVar0 /*170*/]) == iVar1 && !func_292(&(*uParam2)[iVar0 /*170*/], 0, 8388608)) {
			return false;
		}
		iVar0++;
	}
	return true;
}

// Position - 0x23A1
void func_67(var *uParam0, var *uParam1, var *uParam2) {
	vector3 vVar0;

	if (!entity::does_entity_exist(func_64(uParam2))) {
		return;
	}
	if (entity::is_entity_dead(func_64(uParam2), 0)) {
		return;
	}
	switch (func_34(uParam2)) {
	case 0:
		vVar0 = {func_321(uParam1, func_307(uParam2))};
		func_4(&vVar0, 1073741824, 1065353216);
		if (!entity::does_entity_exist(func_244(uParam2))) {
			func_239(uParam2, func_241(vVar0, func_242(func_243(uParam1, func_307(uParam2)), func_19(uParam2))));
		}
		else if (!func_238()) {
			entity::set_entity_coords(func_244(uParam2), vVar0, 1, 0, 0, 1);
		}
		func_237(uParam2, entity::get_entity_coords(func_244(uParam2), 1));
		if (func_31(uParam1, func_307(uParam2)) == 1) {
			func_59(uParam2, 0f, 0f, 0f, 3);
		}
		else {
			func_59(uParam2, 0f, 0f, 0f, 5);
		}
		func_58(uParam2, 0f, 0f, -1f);
		if (!bLocal_238) {
			func_225(uParam0, uParam1, uParam2, 1);
		}
		func_202(uParam1, uParam2, uParam0, 0, 0, 1, 1, 0);
		entity::set_entity_records_collisions(func_244(uParam2), 0);
		func_201(func_244(uParam2), 1);
		func_198(uParam0, uParam1, uParam2);
		func_197(&uParam2->f_1, &uParam2->f_15[func_264(uParam2) /*34*/], uParam0);
		func_194(uParam2, func_195(uParam2, uParam0));
		func_254(&uParam2->f_162);
		func_257(uParam2, 3);
		break;

	case 1:
		if (!bLocal_238) {
			func_225(uParam0, uParam1, uParam2, 1);
		}
		func_202(uParam1, uParam2, uParam0, 0, 0, 0, 1, 0);
		if (!entity::does_entity_exist(func_244(uParam2))) {
			func_239(uParam2, func_241(func_321(uParam1, func_307(uParam2)) + Vector(0.075f, 0f, 0f),
									   func_242(func_243(uParam1, func_307(uParam2)), func_19(uParam2))));
		}
		func_198(uParam0, uParam1, uParam2);
		func_197(&uParam2->f_1, &uParam2->f_15[func_264(uParam2) /*34*/], uParam0);
		if (!func_193(uParam2)) {
			func_194(uParam2, func_195(uParam2, uParam0));
		}
		func_254(&uParam2->f_162);
		func_257(uParam2, 3);
		break;

	case 3:
		if (func_192(uParam2) || func_40(&uParam2->f_15[func_264(uParam2) /*34*/], 1048576)) {
			if (func_40(&uParam2->f_15[func_264(uParam2) /*34*/], 1048576)) {
				func_191(uParam2, func_264(uParam2), uParam1, 0, 1);
				func_188(&uParam2->f_162);
				func_257(uParam2, func_187());
				return;
			}
			if (entity::does_entity_exist(func_64(uParam2)) && !entity::is_entity_dead(func_64(uParam2), 0)) {
				if (system::vdist2(entity::get_entity_coords(func_64(uParam2), 1), func_19(uParam2)) > 9f) {
					ai::clear_ped_tasks(func_64(uParam2));
					func_257(uParam2, 1);
					return;
				}
			}
			func_188(&uParam2->f_162);
			func_257(uParam2, func_187());
			func_186(uParam2, 1);
			func_174(uParam0, &uParam2->f_15[func_264(uParam2) /*34*/], &uParam2->f_1);
			if (func_171(uParam1, uParam2)) {
				func_194(uParam2, func_195(uParam2, uParam0));
			}
		}
		else if (entity::get_entity_speed(func_64(uParam2)) == 0f && func_170(&uParam2->f_162, 15f)) {
			func_254(&uParam2->f_162);
			ai::clear_ped_tasks(func_64(uParam2));
			if (!func_261(uParam2, -1)) {
				func_257(uParam2, 0);
			}
			else {
				func_257(uParam2, 1);
			}
		}
		break;

	case 4:
		if (func_169(player::player_ped_id(), uParam2->f_15[func_264(uParam2) /*34*/].f_2, 0) < 1f) {
			if (entity::is_entity_touching_entity(player::player_ped_id(),
												  uParam2->f_15[func_264(uParam2) /*34*/].f_2)) {
				ai::clear_ped_tasks_immediately(uParam2->f_15[func_264(uParam2) /*34*/].f_2);
				func_202(uParam1, uParam2, uParam0, 0, 0, 0, 1, 0);
				func_271(uParam2, 0);
				func_257(uParam2, 1);
				func_168(&uParam2->f_162);
				return;
			}
		}
		if (bLocal_0) {
		}
		func_156(uParam2, uParam0, &uParam2->f_1, 0, 0);
		if (!func_269(uParam2, 1048576)) {
			func_174(uParam0, &uParam2->f_15[func_264(uParam2) /*34*/], &uParam2->f_1);
		}
		if (!func_273(uParam0, 8)) {
			if (uParam2->f_1 == 4 || uParam2->f_1 == 6 || func_269(uParam2, 1048576))
				&&entity::does_entity_exist(func_244(uParam2)) {
					if (func_155(func_64(uParam2)) || func_170(&uParam2->f_162, 2.5f) || func_269(uParam2, 1048576))
						&&entity::does_entity_have_physics(func_244(uParam2)) {
							if (func_269(uParam2, 1048576)) {
								if (bLocal_0) {
								}
								uParam2->f_1 = 4;
							}
							if (func_126(uParam0, uParam1, uParam2)) {
								uParam2->f_1 = 0;
								func_257(uParam2, 5);
							}
							else {
								uParam2->f_1 = 0;
								func_257(uParam2, 3);
							}
							func_125(uParam0, 8);
						}
				}
			else if (!entity::does_entity_exist(func_244(uParam2))) {
				uParam2->f_1 = 0;
				func_257(uParam2, 0);
			}
		}
		break;

	case 5:
		if (func_124(func_64(uParam2), 1f)) {
			func_118(uParam0, uParam2, 1);
		}
		if (!entity::does_entity_exist(func_244(uParam2))) {
			func_239(uParam2,
					 func_241(func_19(uParam2), func_242(func_243(uParam1, func_307(uParam2)), func_19(uParam2))));
		}
		if (!func_171(uParam1, uParam2)) {
			func_105(uParam0, uParam1, uParam2);
			func_104(&uParam2->f_1);
			if (func_269(uParam2, 4)) {
				func_103(&uParam2->f_1);
			}
		}
		else {
			func_89(uParam0, uParam1, uParam2);
			if (func_269(uParam2, 4)) {
				func_103(&uParam2->f_1);
			}
		}
		break;

	case 6:
		func_118(uParam0, uParam2, 1);
		if (func_88(uParam2) || func_87(uParam2) || func_7(entity::get_entity_coords(func_244(uParam2), 1))) {
			func_86(uParam2);
		}
		else {
			func_77(uParam1, uParam2);
		}
		func_257(uParam2, 7);
		func_76(uParam2, 1);
		if (func_75(uParam2) > func_31(uParam1, func_307(uParam2)) + 3) {
			func_257(uParam2, 7);
			func_74(uParam2, 16384);
		}
		break;

	case 8:
		func_118(uParam0, uParam2, 1);
		func_257(uParam2, 7);
		func_76(uParam2, 1);
		func_73(uParam2);
		func_65(uParam2, 67108864);
		if (!func_63(uParam2, func_264(uParam2), 0) && !func_269(uParam2, 1048576)) {
			ai::clear_ped_tasks(func_64(uParam2));
			ai::open_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
			ai::task_go_to_coord_any_means(0, func_262(uParam1, func_307(uParam2), func_264(uParam2)), 1f, 0, 0, 786603,
										   -1082130432);
			ai::task_turn_ped_to_face_coord(0, func_41(uParam1, func_307(uParam2)), 0);
			ai::close_sequence_task(uParam2->f_15[func_264(uParam2) /*34*/].f_21);
			ai::task_perform_sequence(func_64(uParam2), uParam2->f_15[func_264(uParam2) /*34*/].f_21);
			ai::clear_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
		}
		break;

	case 7:
		if (!func_118(uParam0, uParam2, 0)) {
			if (func_70(uParam1, uParam2) && !func_261(uParam2, func_264(uParam2))) {
				if (!func_269(uParam2, 1048576)) {
					if (bLocal_0) {
					}
					ai::clear_ped_tasks(func_64(uParam2));
					ai::open_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
					ai::task_follow_nav_mesh_to_coord(0, func_260(uParam1, func_307(uParam2), func_264(uParam2)), 1f,
													  -1, 1048576000, 0, 1193033728);
					ai::task_turn_ped_to_face_coord(0, func_321(uParam1, func_307(uParam2)), 0);
					ai::close_sequence_task(uParam2->f_15[func_264(uParam2) /*34*/].f_21);
					ai::task_perform_sequence(func_64(uParam2), uParam2->f_15[func_264(uParam2) /*34*/].f_21);
					ai::clear_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
				}
				else {
					entity::set_entity_coords(func_64(uParam2), func_260(uParam1, func_307(uParam2), func_264(uParam2)),
											  1, 0, 0, 1);
				}
			}
			else if (func_193(uParam2) || func_269(uParam2, 67108864)) {
				if (!func_269(uParam2, 1048576)) {
					if (!func_63(uParam2, func_264(uParam2), 0)) {
						if (bLocal_0) {
						}
						ai::clear_ped_tasks(func_64(uParam2));
						ai::open_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::task_follow_nav_mesh_to_coord(0, func_262(uParam1, func_307(uParam2), func_264(uParam2)),
														  1f, -1, 1048576000, 0, 1193033728);
						ai::task_turn_ped_to_face_coord(0, func_41(uParam1, func_307(uParam2)), 0);
						ai::close_sequence_task(uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::task_perform_sequence(func_64(uParam2), uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::clear_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
					}
				}
				else if (!func_269(uParam2, 4194304)) {
					entity::set_entity_coords(func_64(uParam2), func_262(uParam1, func_307(uParam2), func_264(uParam2)),
											  1, 0, 0, 1);
				}
			}
			else if (!func_269(uParam2, 1048576)) {
				if (!func_63(uParam2, func_264(uParam2), 0) && entity::does_entity_exist(func_25(uParam2))) {
					if (!entity::is_entity_dead(func_25(uParam2), 0)) {
						ai::clear_ped_tasks(func_64(uParam2));
						ai::open_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::task_enter_vehicle(0, func_25(uParam2), -1, func_68(uParam2), 1f, 1, 0);
						ai::close_sequence_task(uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::task_perform_sequence(func_64(uParam2), uParam2->f_15[func_264(uParam2) /*34*/].f_21);
						ai::clear_sequence_task(&uParam2->f_15[func_264(uParam2) /*34*/].f_21);
					}
				}
			}
			if (func_35(uParam2) == 8 || func_269(uParam2, 16384)) {
				func_257(uParam2, 10);
				func_65(uParam2, 16384);
			}
			else {
				func_257(uParam2, 9);
			}
		}
		break;
	}
}

// Position - 0x2D7B
int func_68(var *uParam0) { return func_69(func_264(uParam0)); }

// Position - 0x2D8D
int func_69(int iParam0) {
	if (iParam0 == 0 || iParam0 == 2) {
		return -1;
	}
	return 0;
}

// Position - 0x2DAE
bool func_70(var *uParam0, var *uParam1) {
	if (func_307(uParam1) < 0 || func_307(uParam1) >= func_53(uParam0)) {
		return false;
	}
	if (func_71(uParam1) != 5) {
		return false;
	}
	return true;
}

// Position - 0x2DE7
int func_71(var *uParam0) { return func_72(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2DFD
var func_72(var *uParam0) { return uParam0->f_24; }

// Position - 0x2E09
void func_73(var *uParam0) { func_62(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2E1F
void func_74(var *uParam0, int iParam1) { func_57(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x2E37
int func_75(var *uParam0) { return func_33(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2E4D
void func_76(var *uParam0, int iParam1) {
	func_45(&uParam0->f_15[uParam0->f_157 /*34*/], func_33(&uParam0->f_15[uParam0->f_157 /*34*/]) + iParam1);
}

// Position - 0x2E74
void func_77(var *uParam0, var *uParam1) {
	if (!bLocal_238) {
		if (func_85(uParam1) != 4) {
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		}
		func_237(uParam1, entity::get_entity_coords(func_244(uParam1), 1));
		func_84(uParam1, system::vdist(func_19(uParam1), func_41(uParam0, func_307(uParam1))));
	}
	else {
		entity::set_entity_coords(func_244(uParam1), func_19(uParam1) + Vector(0.05f, 0f, 0f), 1, 0, 0, 1);
		func_82(uParam1);
		func_80(uParam1);
	}
	entity::set_entity_max_speed(func_244(uParam1), 150f);
	func_201(func_244(uParam1), 1);
	func_65(uParam1, 2);
	func_78(uParam1, 0f);
}

// Position - 0x2F1B
void func_78(var *uParam0, float fParam1) { func_79(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x2F33
void func_79(var *uParam0, var uParam1) { uParam0->f_16 = uParam1; }

// Position - 0x2F41
void func_80(var *uParam0) { func_81(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2F57
void func_81(var *uParam0) { uParam0->f_25 = {uParam0->f_28}; }

// Position - 0x2F6B
void func_82(var *uParam0) { func_83(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2F81
void func_83(var *uParam0) { uParam0->f_23 = uParam0->f_24; }

// Position - 0x2F91
void func_84(var *uParam0, float fParam1) { func_46(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x2FA9
int func_85(var *uParam0) { return func_24(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x2FBF
void func_86(var *uParam0) {
	func_82(uParam0);
	func_80(uParam0);
	func_65(uParam0, 2);
	func_74(uParam0, 64);
	func_78(uParam0, 0f);
	func_74(uParam0, 536870912);
}

// Position - 0x2FF4
int func_87(var *uParam0) {
	if (func_35(uParam0) != -1) {
		return 0;
	}
	return 1;
}

// Position - 0x300B
int func_88(var *uParam0) {
	if (func_35(uParam0) != 7) {
		return 0;
	}
	return 1;
}

// Position - 0x3022
void func_89(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	vector3 vVar1;
	float fVar4;
	vector3 vVar5;
	vector3 vVar8;
	int iVar11;

	iVar0 = func_244(uParam2);
	vVar1 = {entity::get_entity_velocity(iVar0)};
	fVar4 = system::vmag(vVar1);
	vVar5 = {func_41(uParam1, func_307(uParam2))};
	vVar8 = {entity::get_entity_coords(iVar0, 1)};
	rope::set_damping(iVar0, 0, 2.96f);
	rope::set_damping(iVar0, 3, 2.96f);
	iVar11 = func_102(uParam1, func_307(uParam2));
	if (func_100(uParam0, uParam1, uParam2)) {
		return;
	}
	uParam2->f_1.f_5 = 0f;
	uParam2->f_1.f_6 = 0f;
	if (entity::has_entity_collided_with_anything(iVar0)) {
		func_59(uParam2, entity::get_entity_coords(iVar0, 1), func_99(entity::get_last_material_hit_by_entity(iVar0)));
		func_74(uParam2, 2);
		func_305(uParam0, 268435456);
		if (entity::does_entity_exist(iVar11)) {
			if (entity::is_entity_touching_entity(iVar0, iVar11) && !func_269(uParam2, 268435456)) {
				audio::play_sound_from_entity(-1, "GOLF_BALL_IMPACT_FLAG_MASTER", func_244(uParam2), 0, 0, 0);
				entity::set_entity_collision(iVar11, 0, 0);
				func_74(uParam2, 268435456);
			}
		}
	}
	else if (func_269(uParam2, 2) && func_193(uParam2)) {
		if (!func_273(uParam0, 268435456) && system::vdist2(vVar8, vVar5) < 0.3f * 0.3f) {
			audio::play_sound_from_entity(-1, "GOLF_BALL_CUP_MISS_MASTER", func_244(uParam2), 0, 0, 0);
			func_125(uParam0, 268435456);
		}
	}
	if (fVar4 < 0.25f || fVar4 < 6f && func_98(uParam1, uParam2) || func_269(uParam2, 256) || func_97()) {
		if (!func_96(&uParam2->f_159)) {
			func_59(uParam2, entity::get_entity_coords(iVar0, 1),
					func_99(entity::get_last_material_hit_by_entity(iVar0)));
			func_58(uParam2, entity::get_collision_normal_of_last_hit_for_entity(iVar0));
			if (func_98(uParam1, uParam2)) {
			}
			func_254(&uParam2->f_159);
		}
		if (!func_98(uParam1, uParam2) &&
			(func_269(uParam2, 256) || system::vdist2(vVar8, vVar5) < 0.1601f * 0.1601f || func_97() ||
			 func_93(uParam1, uParam2)) &&
			0) {
			func_92(iVar0, vVar8, vVar5);
			func_74(uParam2, 256);
		}
		else if (func_170(&uParam2->f_159, 0.5f)) {
			if (bLocal_0) {
			}
			entity::set_entity_records_collisions(iVar0, 0);
			func_74(uParam2, 2048);
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 0f;
			if (func_98(uParam1, uParam2)) {
				func_74(uParam2, 8192);
				func_257(uParam2, 8);
				func_201(iVar0, 0);
			}
			else {
				func_201(iVar0, 1);
				func_257(uParam2, 6);
			}
			func_74(uParam2, 4);
		}
	}
	else if (func_96(&uParam2->f_159)) {
		func_168(&uParam2->f_159);
	}
	if (func_170(&uParam2->f_162, 30f) && !func_97()) {
		entity::set_entity_coords(iVar0, func_90(uParam2), 1, 0, 0, 1);
		entity::set_entity_records_collisions(iVar0, 0);
		func_201(iVar0, 1);
		func_257(uParam2, 6);
		func_74(uParam2, 68);
	}
}

// Position - 0x3338
Vector3 func_90(var *uParam0) { return func_91(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x334E
Vector3 func_91(var *uParam0) { return uParam0->f_10; }

// Position - 0x335C
void func_92(int iParam0, struct<2> Param1, Vector3 vParam3, struct<2> Param4, var uParam6) {
	vector3 vVar0;

	vVar0 = {func_6(Vector(0f, Param4.f_1, Param4) - Vector(0f, Param1.f_1, Param1)) * FtoV(9f)};
	entity::apply_force_to_entity(iParam0, 0, vVar0, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
}

// Position - 0x3396
int func_93(var *uParam0, var *uParam1) {
	vector3 vVar0;
	float fVar3;

	if (func_85(uParam1) != 4) {
		return 0;
	}
	if (!func_171(uParam0, uParam1)) {
		return 0;
	}
	vVar0 = {func_19(uParam1)};
	fVar3 = 0.7f;
	switch (func_94(uParam1)) {
	case 0: fVar3 = 1f; break;

	case 1: fVar3 = 1.5f; break;

	case 2: fVar3 = 2.5f; break;
	}
	if (system::vdist(vVar0, func_41(uParam0, func_307(uParam1))) > fVar3) {
		return 0;
	}
	return 1;
}

// Position - 0x3423
int func_94(var *uParam0) { return func_95(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x3439
var func_95(var *uParam0) { return uParam0->f_33; }

// Position - 0x3445
bool func_96(var *uParam0) { return gameplay::is_bit_set(*uParam0, 1); }

// Position - 0x3455
int func_97() { return 0; }

// Position - 0x345E
bool func_98(var *uParam0, var *uParam1) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::does_entity_exist(func_244(uParam1))) {
		return false;
	}
	vVar0 = {entity::get_entity_coords(func_244(uParam1), 0)};
	vVar3 = {func_41(uParam0, func_307(uParam1))};
	if (system::vdist2(vVar0, vVar3) > 0.25f * 0.25f) {
		return false;
	}
	if (func_35(uParam1) == 8) {
		if (vVar0.z < vVar3.z + 0.11f) {
			return true;
		}
	}
	if (system::vdist2(vVar0, vVar3) < 0.1f * 0.1f) {
		func_59(uParam1, 0f, 0f, 0f, 8);
		return true;
	}
	return false;
}

// Position - 0x3502
int func_99(int iParam0) {
	switch (iParam0) {
	case -461750719:
	case 930824497: return 4;

	case 581794674:
	case -2041329971:
	case -309121453:
	case 555004797:
	case -1885547121:
	case -1915425863: return 9;

	case -2073312001:
	case 627123000: return 8;

	case 1187676648:
	case 282940568:
	case 951832588:
	case -840216541:
	case 510490462: return 1;

	case 1333033863: return 2;

	case -1286696947: return 3;

	case -1595148316: return 0;

	case 435688960: return 7;
	}
	return -1;
}

// Position - 0x35BB
bool func_100(var uParam0, var *uParam1, var *uParam2) {
	int iVar0;

	iVar0 = func_244(uParam2);
	if (entity::is_entity_in_water(iVar0)) {
		entity::set_entity_records_collisions(iVar0, 0);
		func_201(iVar0, 1);
		func_59(uParam2, 0f, 0f, 0f, 7);
		func_101(uParam2);
		func_257(uParam2, 6);
		func_74(uParam2, 4);
		func_74(uParam2, 2);
		return true;
	}
	return false;
}

// Position - 0x360C
void func_101(var *uParam0) {
	audio::play_sound_from_entity(-1, "GOLF_BALL_IN_WATER_MASTER", func_244(uParam0), 0, 0, 0);
	return;
	graphics::start_particle_fx_non_looped_at_coord(
		"scr_golf_landing_water", entity::get_entity_coords(func_244(uParam0), 1), 0f, 0f,
		func_242(entity::get_entity_coords(func_244(uParam0), 1), func_19(uParam0)), 1065353216, 0, 0, 0);
}

// Position - 0x365A
int func_102(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0;
	}
	return (*uParam0)[iParam1 /*3*/].f_2;
}

// Position - 0x3682
void func_103(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_2 = 0f;
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0f;
	uParam0->f_5 = 0f;
	uParam0->f_6 = 0f;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 0;
	uParam0->f_13 = 0;
}

// Position - 0x36CA
void func_104(var uParam0) {}

// Position - 0x36D2
void func_105(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float fVar5;
	var uVar6;
	vector3 vVar7;
	float fVar10;
	vector3 vVar11;
	vector3 vVar14;
	vector3 vVar17;
	float fVar20;
	float fVar21;
	float fVar22;
	float fVar23;
	vector3 vVar24;
	vector3 vVar27;
	vector3 vVar30;
	vector3 vVar33;
	vector3 vVar36;
	vector3 vVar39;

	iVar0 = func_244(uParam2);
	iVar1 = func_102(uParam1, func_307(uParam2));
	vVar2 = {entity::get_entity_velocity(iVar0)};
	fVar5 = system::vmag(vVar2);
	vVar7 = {uParam2->f_1.f_5, uParam2->f_1.f_6, 0f};
	fVar10 = func_116(uParam2);
	vVar11 = {func_6(system::cos(fVar10), system::sin(fVar10), 0f)};
	vVar14 = {func_115(vVar11, 0)};
	vVar17 = {vVar11 * FtoV(-vVar7.x) * FtoV(0.05f) + vVar14 * FtoV(vVar7.y) * FtoV(0.2f)};
	unk_0x0A25F80D5BADC013(entity::get_entity_coords(iVar0, 1), entity::get_entity_coords(iVar0, 1) + func_6(vVar17), 0,
						   0, 0, 255);
	if (func_100(uParam0, uParam1, uParam2)) {
		return;
	}
	if (entity::has_entity_collided_with_anything(iVar0)) {
		if (entity::does_entity_exist(iVar1)) {
			if (entity::is_entity_touching_entity(iVar0, iVar1)) {
				if (!func_269(uParam2, 268435456)) {
					audio::play_sound_from_entity(-1, "GOLF_BALL_IMPACT_FLAG_MASTER", func_244(uParam2), 0, 0, 0);
					func_74(uParam2, 268435456);
				}
				if (!entity::is_entity_in_air(iVar0)) {
					entity::set_entity_collision(iVar1, 0, 0);
				}
			}
		}
		fVar20 = 1f;
		fVar21 = 0f;
		fVar22 = 0f;
		fVar23 = 0f;
		switch (func_99(entity::get_last_material_hit_by_entity(iVar0))) {
		case 1:
			fVar20 = 0.89f;
			fVar21 = 0.75f;
			fVar23 = 0.2f;
			fVar22 = 0.3f;
			break;

		case 4:
		case 9:
			fVar21 = 0.25f;
			fVar20 = 0.85f;
			fVar23 = 0.5f;
			fVar22 = 0.15f;
			break;

		case 0:
			fVar20 = 0.35f;
			fVar21 = 0f;
			fVar23 = 0.2f;
			fVar22 = 0f;
			break;

		case 7: fVar20 = 0.5f; break;

		case 2:
			fVar20 = 0.85f;
			fVar21 = 0.5f;
			fVar23 = 0.55f;
			fVar22 = 0.3f;
			break;

		case 3:
			fVar20 = 0.85f;
			fVar21 = 0.3f;
			fVar23 = 0.55f;
			fVar22 = 1.2f;
			break;

		case -1: break;
		}
		if (!bLocal_241) {
			vVar17 = {vVar11 * FtoV(-vVar7.x) * FtoV(0.2f) + vVar14 * FtoV(vVar7.y) * FtoV(0.2f)};
			vVar17 = {vVar17 * FtoV(fVar22)};
			entity::apply_force_to_entity(iVar0, 0, vVar17, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
		func_114(&uParam2->f_1);
		if (!func_273(uParam0, 64)) {
			if (fVar21 != 0f && system::vmag2(vVar2) > 9.5f) {
				gameplay::_0x8BDC7BFC57A81E76(entity::get_entity_coords(iVar0, 1) + Vector(1f, 0f, 0f), &uVar6,
											  &vVar27);
				vVar30 = {FtoV(func_8(vLocal_248, vVar27)) * vVar27};
				vVar24 = {FtoV(-(1f + fVar21)) * vVar30 + vLocal_248};
				vVar33 = {vLocal_248 - vVar30};
				vVar24 = {vVar24 - vVar33 * FtoV(fVar23)};
				entity::set_entity_velocity(iVar0, vVar24);
			}
			func_125(uParam0, 64);
			func_112(uParam2, 0, func_113(iVar0));
		}
		else {
			vVar36 = {entity::get_entity_velocity(iVar0)};
			if (fVar20 != 1f) {
				vVar36 = {vVar36 * FtoV(fVar20)};
				entity::set_entity_velocity(iVar0, vVar36);
			}
		}
	}
	else {
		if (func_273(uParam0, 64)) {
			func_305(uParam0, 64);
		}
		if (!bLocal_240 && !func_111(uParam2)) {
			vVar39 = {func_6(uParam0->f_16, uParam0->f_16.f_1, 0f) * FtoV(uParam0->f_20) * FtoV(0.5f)};
			entity::apply_force_to_entity(iVar0, 0, vVar39, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
		if (!bLocal_241) {
			entity::apply_force_to_entity(iVar0, 0, vVar17, 0f, 0f, 0f, 0, 0, 0, 1, 0, 1);
		}
	}
	if (func_110(uParam2)) {
		controls::set_pad_shake(0, 50,
								func_108(0, func_109(256, gameplay::absi(system::round(uParam2->f_1.f_6)) +
															  gameplay::absi(system::round(uParam2->f_1.f_5)) + 30)));
	}
	if (!func_269(uParam2, 2)) {
		if (!func_96(&uParam2->f_159) && !func_269(uParam2, 2)) {
			func_254(&uParam2->f_159);
		}
		if (entity::has_entity_collided_with_anything(iVar0) && func_251(&uParam2->f_159, 0.2f)) {
			if (func_85(uParam2) != 4) {
				ui::clear_help(1);
			}
			if (bLocal_0) {
			}
			func_78(uParam2, system::vdist(entity::get_entity_coords(iVar0, 1), func_19(uParam2)));
			func_74(uParam2, 2);
			func_168(&uParam2->f_159);
			func_106(uParam2);
		}
	}
	else if (func_97() && !func_98(uParam1, uParam2)) {
		func_92(iVar0, entity::get_entity_coords(iVar0, 1), func_41(uParam1, func_307(uParam2)));
	}
	else if (fVar5 < 0.5f && gameplay::absf(uParam2->f_1.f_5) + gameplay::absf(uParam2->f_1.f_6) < 0.05f ||
			 fVar5 < 6f && func_98(uParam1, uParam2)) {
		if (!func_96(&uParam2->f_159)) {
			func_59(uParam2, entity::get_entity_coords(iVar0, 1),
					func_99(entity::get_last_material_hit_by_entity(iVar0)));
			func_58(uParam2, entity::get_collision_normal_of_last_hit_for_entity(iVar0));
			func_254(&uParam2->f_159);
			if (func_98(uParam1, uParam2)) {
			}
		}
		if (func_170(&uParam2->f_159, 1f)) {
			entity::set_entity_records_collisions(iVar0, 0);
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 0f;
			if (func_98(uParam1, uParam2)) {
				func_74(uParam2, 8192);
				func_257(uParam2, 8);
			}
			else {
				func_257(uParam2, 6);
				if (func_110(uParam2)) {
					controls::set_pad_shake(0, 10, 10);
				}
			}
			func_74(uParam2, 4);
			func_201(iVar0, 1);
			func_74(uParam2, 2048);
			if (func_70(uParam1, uParam2)) {
				func_74(uParam2, 8);
			}
		}
	}
	else if (func_96(&uParam2->f_159)) {
		func_168(&uParam2->f_159);
	}
	if (func_170(&uParam2->f_162, 14f) && !func_97()) {
		entity::set_entity_records_collisions(iVar0, 0);
		func_201(iVar0, 1);
		func_257(uParam2, 6);
		func_74(uParam2, 68);
		if (func_269(uParam2, 4194304)) {
			func_59(uParam2, 0f, 0f, 0f, 3);
		}
		else {
			func_59(uParam2, 0f, 0f, 0f, 4);
		}
	}
	if (entity::does_entity_exist(iVar0)) {
		vLocal_248 = {entity::get_entity_velocity(iVar0)};
	}
	func_305(uParam0, 32);
}

// Position - 0x3CF7
void func_106(var *uParam0) {
	char *sVar0;

	return;
	if (func_193(uParam0)) {
		return;
	}
	sVar0 = "";
	switch (entity::get_last_material_hit_by_entity(func_244(uParam0))) {
	case -461750719:
	case 930824497: sVar0 = "scr_golf_landing_thick_grass"; break;

	case -309121453:
	case 555004797:
	case 581794674:
	case -2041329971:
	case -1915425863: sVar0 = "scr_golf_hit_branches"; break;

	case -1595148316: sVar0 = "scr_golf_landing_bunker"; break;

	case 1333033863:
	case -1286696947:
	case 951832588:
	case 1187676648:
	case 282940568:
	case -2073312001: break;

	default: break;
	}
	if (!func_107(sVar0)) {
		graphics::start_particle_fx_non_looped_at_coord(
			sVar0, entity::get_entity_coords(func_244(uParam0), 1), 0f, 0f,
			func_242(entity::get_entity_coords(func_244(uParam0), 1), func_19(uParam0)), 1065353216, 0, 0, 0);
	}
}

// Position - 0x3DCF
int func_107(char *sParam0) {
	if (gameplay::is_string_null(sParam0)) {
		return 1;
	}
	if (ui::get_length_of_literal_string(sParam0) <= 0) {
		return 1;
	}
	return 0;
}

// Position - 0x3DF3
int func_108(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam0;
	}
	return iParam1;
}

// Position - 0x3E09
int func_109(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam1;
	}
	return iParam0;
}

// Position - 0x3E1F
bool func_110(var *uParam0) { return func_85(uParam0) == 1 || func_85(uParam0) == 2; }

// Position - 0x3E3D
bool func_111(var *uParam0) { return (func_94(uParam0) == 2 || func_269(uParam0, 65536)) && func_85(uParam0) == 4; }

// Position - 0x3E6A
void func_112(var *uParam0, int iParam1, bool bParam2) {
	char *sVar0;

	sVar0 = "";
	switch (entity::get_last_material_hit_by_entity(func_244(uParam0))) {
	case 1333033863:
	case -1286696947:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_FAIRWAY_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_FAIRWAY_MASTER";
		}
		break;

	case -461750719:
	case 930824497:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_GRASS_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_GRASS_MASTER";
		}
		break;

	case -1595148316:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_SAND_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_SAND_MASTER";
		}
		break;

	case 951832588:
	case 1187676648:
	case 282940568:
	case -840216541:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_CONCRETE_LIGHT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_CONCRETE_MASTER";
		}
		break;

	case -309121453:
	case 555004797:
	case 581794674:
	case -1915425863:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_TREE_SOFT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_TREE_MASTER";
		}
		break;

	default:
		if (bParam2) {
			sVar0 = "GOLF_BALL_IMPACT_TREE_SOFT_MASTER";
		}
		else {
			sVar0 = "GOLF_BALL_IMPACT_TREE_MASTER";
		}
		break;
	}
	if (!func_107(sVar0)) {
		if (iParam1) {
			audio::play_sound_from_coord(-1, sVar0, entity::get_entity_coords(func_244(uParam0), 1), 0, 0, 0, 0);
		}
		else {
			audio::play_sound_from_entity(-1, sVar0, func_244(uParam0), 0, 0, 0);
		}
	}
}

// Position - 0x3F94
bool func_113(int iParam0) { return entity::get_entity_speed(iParam0) < 6f; }

// Position - 0x3FA4
void func_114(var *uParam0) {
	vector3 vVar0;
	vector3 vVar3;

	if (uParam0->f_5 == 0f && uParam0->f_6 == 0f) {
		return;
	}
	vVar0 = {func_6(uParam0->f_5, uParam0->f_6, 0f) * FtoV(25f) * FtoV(gameplay::get_frame_time())};
	vVar3 = {-vVar0};
	if (gameplay::absf(uParam0->f_5) < gameplay::absf(vVar0.x)) {
		uParam0->f_5 = 0f;
	}
	else {
		uParam0->f_5 += vVar3.x;
	}
	if (gameplay::absf(uParam0->f_6) < gameplay::absf(vVar0.y)) {
		uParam0->f_6 = 0f;
	}
	else {
		uParam0->f_6 += vVar3.y;
	}
}

// Position - 0x403A
Vector3 func_115(vector3 vParam0, int iParam3) {
	vector3 vVar0;

	switch (iParam3) {
	case 0:
		vVar0.x = -vParam0.y;
		vVar0.y = vParam0.x;
		break;

	case 1:
		vVar0.x = -vParam0.x;
		vVar0.y = -vParam0.y;
		break;

	case 2:
		vVar0.x = vParam0.y;
		vVar0.y = -vParam0.x;
		break;
	}
	vVar0.z = vParam0.z;
	return vVar0;
}

// Position - 0x4098
float func_116(var *uParam0) { return func_117(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x40AE
float func_117(var *uParam0) { return uParam0->f_14; }

// Position - 0x40BA
int func_118(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	char cVar2[32];

	iVar0 = func_64(uParam1);
	sVar1 = func_121(uParam0, &uParam1->f_15[func_264(uParam1) /*34*/], 1, 1);
	StringCopy(&cVar2, sVar1, 32);
	StringConCat(&cVar2, "react_", 32);
	StringConCat(&cVar2, "nuetral_01", 32);
	if (entity::is_entity_playing_anim(iVar0, func_119(0), &cVar2, 3)) {
		if (entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar2) > 0.95f) {
			return 0;
		}
	}
	if (iParam2) {
		if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar2, 3) &&
			(entity::is_entity_playing_anim(iVar0, func_119(0), "iron_swing_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_119(0), "putt_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_119(0), "wedge_swing_action", 3) ||
			 entity::is_entity_playing_anim(iVar0, func_119(0), "wood_swing_action", 3))) {
			ai::task_play_anim(iVar0, func_119(0), &cVar2, 8f, -2f, -1, 0, 0, 0, 0, 0);
		}
		return 1;
	}
	return 0;
}

// Position - 0x41B1
char *func_119(int iParam0) {
	return func_331();
	if (!iParam0) {
		return func_331();
	}
	return func_120();
}

// Position - 0x41D4
char *func_120() { return "MINI@GOLF"; }

// Position - 0x41E0
char *func_121(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;

	iVar0 = func_123(uParam1);
	iVar1 = func_122(uParam0, iVar0);
	if (iVar1 <= 5 && !iParam2) {
		return "Wood_";
	}
	else if (iVar1 > 5 && iVar1 <= 13 && !iParam2) {
		return "Iron_";
	}
	else if (iVar1 > 13 && iVar1 <= 18 && iParam3) {
		return "Wedge_";
	}
	else if (iVar1 == 19) {
		return "Putt_";
	}
	if (iParam2) {
		return "Swing_";
	}
	return "";
}

// Position - 0x4276
int func_122(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 1;
	}
	return (*uParam0)[iParam1];
}

// Position - 0x429C
int func_123(var *uParam0) { return uParam0->f_17; }

// Position - 0x42A8
bool func_124(int iParam0, float fParam1) {
	char cVar0[32];
	char cVar8[32];
	char cVar16[32];
	char cVar24[32];

	if (!ped::is_ped_injured(iParam0)) {
		StringCopy(&cVar0, "Wood_swing_action", 32);
		StringCopy(&cVar8, "Iron_swing_action", 32);
		StringCopy(&cVar16, "Wedge_swing_action", 32);
		StringCopy(&cVar24, "Putt_action", 32);
		if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar0, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar0) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar8, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar8) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar16, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar16) >= fParam1) {
				return true;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar24, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar24) >= fParam1) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x4384
void func_125(var *uParam0, int iParam1) { uParam0->f_22 |= iParam1; }

// Position - 0x4397
bool func_126(var *uParam0, var *uParam1, var *uParam2) {
	bool bVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18;
	float fVar21;
	float fVar22;
	float fVar23;
	vector3 vVar24;
	float fVar27;
	float fVar28;

	func_201(func_244(uParam2), 0);
	entity::set_entity_records_collisions(func_244(uParam2), 1);
	object::set_object_physics_params(func_244(uParam2), -1f, -1f, 0f, 0f, 0.01f, -1f, -1f, -1f, -1f, -1f, -1082130432);
	bVar0 = func_85(uParam2) == 4;
	fVar1 = func_142(&uParam2->f_15[func_264(uParam2) /*34*/], uParam0, &uParam2->f_1, bVar0, !bLocal_239, 0);
	fVar2 = 1f;
	switch (func_35(uParam2)) {
	case 2: fVar2 = 0.95f; break;

	case 4:
	case 1: fVar2 = func_141(0.9f, 0.075f); break;

	case 0:
	case 7:
	case -1:
		fVar2 = func_141(0.85f, 0.15f);
		if (fVar2 > 0.85f) {
			fVar2 = 0.85f;
		}
		break;
	}
	fVar1 *= fVar2;
	if (func_85(uParam2) == 4 && func_122(uParam0, func_140(uParam2)) == 17) {
		fVar1 *= 0.85f;
	}
	fVar3 = func_139(uParam0, func_140(uParam2)) / 90f;
	fVar3 += 0.05f;
	fVar4 = func_116(uParam2);
	fVar5 = func_138(uParam0, func_140(uParam2));
	if (func_136(uParam2) == 2) {
		fVar3 = func_139(uParam0, func_140(uParam2)) / 150f;
	}
	switch (uParam2->f_1) {
	case 4:
		fVar4 = func_116(uParam2);
		if (bVar0 && !func_193(uParam2)) {
			fVar4 = func_242(func_90(uParam2), func_19(uParam2)) + 90f;
		}
		if (func_35(uParam2) == 0 && func_140(uParam2) != func_135(uParam0, 16)) {
			fVar4 += 25f * gameplay::get_random_float_in_range(-1f, 1f);
		}
		if (!bVar0) {
			uParam2->f_1.f_5 = 0f;
			uParam2->f_1.f_6 = 45f * uParam2->f_1.f_4;
		}
		if (func_136(uParam2) == 1) {
			fVar4 += func_141(0f, 5f);
			uParam2->f_1.f_5 *= 2f;
			uParam2->f_1.f_6 *= 2f;
		}
		break;

	case 6:
		if (!func_193(uParam2)) {
			fVar1 *= gameplay::get_random_float_in_range(0.15f, 0.25f);
			fVar3 *= gameplay::get_random_float_in_range(0.25f, 1.25f);
		}
		if (uParam2->f_1.f_7 < 0) {
			fVar4 = func_116(uParam2) + 90f * gameplay::get_random_float_in_range(0f, 1f);
			uParam2->f_1.f_5 = gameplay::get_random_float_in_range(0f, 20f) * fVar5;
		}
		else {
			fVar4 = func_116(uParam2) + 90f * gameplay::get_random_float_in_range(-1f, 0f);
			uParam2->f_1.f_5 = gameplay::get_random_float_in_range(-20f, 0f) * fVar5;
		}
		uParam2->f_1.f_6 = gameplay::get_random_float_in_range(-20f, 20f) * fVar5;
		break;

	default: break;
	}
	if (func_193(uParam2)) {
		vVar6 = {system::cos(fVar4) * fVar1, system::sin(fVar4) * fVar1, 0f};
	}
	else {
		fVar21 = 1f - fVar3;
		fVar22 = 2f * fVar21 - fVar21 * fVar21;
		fVar23 = 2f * fVar3 - fVar3 * fVar3;
		vVar9 = {func_132(func_85(uParam2) == 4, 0f, 0f, 1f, -func_133(uParam2))};
		vVar12 = {func_6(system::cos(fVar4), system::sin(fVar4), 0f)};
		vVar15 = {-func_6(vVar12 - FtoV(func_8(vVar12, vVar9)) * vVar9)};
		vVar18 = {func_6(-vVar12 * FtoV(fVar22) + vVar9 * FtoV(fVar23))};
		vVar24 = {func_6(vVar15 * FtoV(fVar22) + vVar9 * FtoV(fVar23))};
		fVar27 = func_8(vVar12, func_6(vVar24.x, vVar24.y, 0f));
		fVar28 = func_27(vVar12.x * vVar24.y - vVar12.y * vVar24.x < 0f, -1f, 1f);
		if (gameplay::absf(fVar27) < system::cos(15f)) {
			vVar24 = {func_131(vVar24, fVar28 * (gameplay::acos(gameplay::absf(fVar27)) - 15f))};
		}
		vVar18.y = vVar24.y / gameplay::absf(vVar24.y) *
				   system::sqrt(
					   gameplay::absf((vVar18.z * vVar18.z - 1f) / (vVar24.x * vVar24.x / (vVar24.y * vVar24.y) + 1f)));
		vVar18.x = vVar24.x * vVar18.y / vVar24.y;
		vVar6 = {FtoV(-1f * fVar1) * vVar18};
	}
	if (bLocal_0) {
		if (func_130(vVar6, 0f, 0f, 0f, 0.001f, 0)) {
			if (bLocal_0) {
			}
			return false;
		}
	}
	if (func_35(uParam2) == 3 && !func_193(uParam2)) {
		func_59(uParam2, 0f, 0f, 0f, 2);
	}
	entity::set_entity_velocity(func_244(uParam2), vVar6);
	entity::set_entity_max_speed(func_244(uParam2), 150f);
	func_125(uParam0, 32);
	func_129(uParam0, uParam2, 0, func_273(uParam0, 16), uParam2->f_1.f_2 < 50f);
	func_127(uParam2, uParam1, uParam0);
	func_65(uParam2, 4);
	if (!func_171(uParam1, uParam2)) {
		func_74(uParam2, 1024);
	}
	func_188(&uParam2->f_162);
	if (func_110(uParam2)) {
		if (!func_171(uParam1, uParam2)) {
			controls::set_pad_shake(0, 100, 256);
		}
	}
	return true;
}

// Position - 0x48AC
void func_127(var *uParam0, var *uParam1, var *uParam2) {
	char *sVar0;

	return;
	sVar0 = "";
	switch (func_35(uParam0)) {
	case 2:
		if (gameplay::absf(uParam0->f_1.f_4) < 10f) {
			sVar0 = "scr_golf_strike_fairway";
		}
		else {
			sVar0 = "scr_golf_strike_fairway_bad";
		}
		break;

	case 4: sVar0 = "scr_golf_strike_thick_grass"; break;

	case 0: sVar0 = "scr_golf_strike_bunker"; break;

	case 3: break;

	case 5:
		if (uParam0->f_1 != 6 && func_31(uParam1, func_307(uParam0)) > 3) {
			sVar0 = "scr_golf_tee_perfect";
		}
		break;

	case 1:
	case 7:
	case -1: break;
	}
	func_128(uParam0, func_273(uParam2, 16));
	if (!func_107(sVar0)) {
		graphics::start_particle_fx_non_looped_at_coord(sVar0, func_19(uParam0), 0f, 0f, func_116(uParam0), 1065353216,
														0, 0, 0);
	}
}

// Position - 0x498E
void func_128(var *uParam0, bool bParam1) {
	int iVar0;

	return;
	if (!func_193(uParam0) && entity::does_entity_exist(func_244(uParam0))) {
		iVar0 = graphics::start_particle_fx_looped_on_entity("scr_golf_ball_trail", func_244(uParam0), 0f, 0f, 0f, 0f,
															 0f, 0f, 1065353216, 0, 0, 0);
		if (bParam1) {
			graphics::set_particle_fx_looped_colour(iVar0, 240f / 255f, 200f / 255f, 80f / 255f, 0);
		}
	}
}

// Position - 0x49FD
void func_129(var *uParam0, var *uParam1, int iParam2, bool bParam3, bool bParam4) {
	char *sVar0;

	sVar0 = "";
	if (func_269(uParam1, 1048576)) {
		return;
	}
	switch (func_122(uParam0, func_140(uParam1))) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
		switch (func_35(uParam1)) {
		case 2:
			if (bParam4) {
				sVar0 = "GOLF_SWING_GRASS_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_GRASS_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_GRASS_MASTER";
			}
			break;

		case 5:
			if (bParam4) {
				sVar0 = "GOLF_SWING_TEE_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_TEE_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_TEE_MASTER";
			}
			break;

		default:
			if (func_35(uParam1) == 3) {
			}
			else if (func_35(uParam1) == -1) {
			}
			else if (func_35(uParam1) == 7) {
			}
			else if (func_35(uParam1) == 8) {
			}
			else if (func_35(uParam1) == 0) {
			}
			else if (func_35(uParam1) == 1) {
			}
			else if (func_35(uParam1) == 4) {
			}
			break;
		}
		break;

	case 6:
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
		switch (func_35(uParam1)) {
		case 5:
			if (bParam4) {
				sVar0 = "GOLF_SWING_TEE_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_TEE_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_TEE_IRON_MASTER";
			}
			break;

		case 2:
			if (bParam4) {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_FAIRWAY_IRON_MASTER";
			}
			break;

		case 4:
			if (bParam4) {
				sVar0 = "GOLF_SWING_ROUGH_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_ROUGH_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_ROUGH_IRON_MASTER";
			}
			break;

		case 0:
			if (bParam4) {
				sVar0 = "GOLF_SWING_SAND_IRON_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_SAND_IRON_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_SAND_IRON_MASTER";
			}
			break;

		case 1: sVar0 = "GOLF_SWING_TEE_IRON_MASTER"; break;

		default:
			if (func_35(uParam1) == 3) {
			}
			else if (func_35(uParam1) == -1) {
			}
			else if (func_35(uParam1) == 7) {
			}
			else if (func_35(uParam1) == 8) {
			}
			break;
		}
		break;

	case 15:
	case 17:
	case 18:
	case 14:
	case 16:
		switch (func_35(uParam1)) {
		case 5:
		case 2:
		case 3:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_MASTER";
			}
			break;

		case 4:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_GRASS_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_GRASS_MASTER";
			}
			break;

		case 0:
			if (bParam4) {
				sVar0 = "GOLF_SWING_CHIP_SAND_LIGHT_MASTER";
			}
			else if (bParam3) {
				sVar0 = "GOLF_SWING_CHIP_SAND_PERFECT_MASTER";
			}
			else {
				sVar0 = "GOLF_SWING_CHIP_SAND_MASTER";
			}
			break;

		case 1: sVar0 = "GOLF_SWING_CHIP_MASTER"; break;

		default: break;
		}
		break;

	case 19: sVar0 = "GOLF_SWING_PUTT_MASTER"; break;
	}
	if (!func_107(sVar0)) {
		if (iParam2 || !entity::does_entity_exist(func_244(uParam1))) {
			audio::play_sound_from_coord(-1, sVar0, func_19(uParam1), 0, 0, 0, 0);
		}
		else {
			audio::play_sound_from_entity(-1, sVar0, func_244(uParam1), 0, 0, 0);
		}
	}
}

// Position - 0x4D55
bool func_130(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return true;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return true;
		}
	}
	return false;
}

// Position - 0x4DD0
Vector3 func_131(vector3 vParam0, float fParam3) {
	vector3 vVar0;
	float fVar3;
	float fVar4;

	fVar3 = system::sin(fParam3);
	fVar4 = system::cos(fParam3);
	vVar0.x = vParam0.x * fVar4 - vParam0.y * fVar3;
	vVar0.y = vParam0.x * fVar3 + vParam0.y * fVar4;
	vVar0.z = vParam0.z;
	return vVar0;
}

// Position - 0x4E14
Vector3 func_132(bool bParam0, vector3 vParam1, vector3 vParam4) {
	if (bParam0) {
		return vParam1;
	}
	return vParam4;
}

// Position - 0x4E2F
Vector3 func_133(var *uParam0) { return func_134(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x4E45
Vector3 func_134(var *uParam0) { return uParam0->f_25; }

// Position - 0x4E53
int func_135(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < uParam0->f_15) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x4E81
int func_136(var *uParam0) { return func_137(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x4E97
int func_137(var *uParam0) { return uParam0->f_19; }

// Position - 0x4EA3
float func_138(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 0.25f;

	case 2: return 0.25f;

	case 3: return 0.25f;

	case 4: return 0.25f;

	case 5: return 0.25f;

	case 6: return 0.5f;

	case 7: return 0.5f;

	case 8: return 0.5f;

	case 9: return 0.6f;

	case 10: return 0.6f;

	case 11: return 0.7f;

	case 12: return 0.7f;

	case 13: return 0.8f;

	case 14: return 1f;

	case 15: return 1f;

	case 16: return 1f;

	case 17: return 1f;

	case 18: return 1f;

	case 19: return 0.1f;
	}
	return 0f;
}

// Position - 0x4FFE
float func_139(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 13.5f;

	case 2: return 13.75f;

	case 3: return 16f;

	case 4: return 18f;

	case 5: return 21f;

	case 6: return 17f;

	case 7: return 20f;

	case 8: return 23f;

	case 9: return 26f;

	case 10: return 29f;

	case 11: return 30f;

	case 12: return 37f;

	case 13: return 41f;

	case 14: return 45f;

	case 15: return 50f;

	case 16: return 55f;

	case 17: return 60f;

	case 18: return 64f;

	case 19: return 5f;
	}
	return 0f;
}

// Position - 0x5169
int func_140(var *uParam0) { return func_123(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x517F
float func_141(float fParam0, float fParam1) {
	float fVar0;

	fVar0 = system::sin(gameplay::get_random_float_in_range(-180f, 180f));
	if (fVar0 < 0f) {
		fVar0++;
	}
	else {
		fVar0--;
	}
	return fParam0 + fVar0 * fParam1;
}

// Position - 0x51B9
float func_142(var *uParam0, var *uParam1, var *uParam2, bool bParam3, bool bParam4, int iParam5) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;

	fVar0 = uParam2->f_3;
	if (iParam5) {
		fVar0 = 100f;
	}
	else if (!bParam4) {
		fVar0 = func_145(uParam0, 1);
	}
	switch (func_137(uParam0)) {
	case 0:
		fVar1 = 0.5575f;
		fVar2 = 0f;
		break;

	case 1:
		fVar1 = 0.575f;
		fVar2 = 15f * (1f - system::sqrt(fVar0 / 100f));
		break;

	case 3:
		fVar1 = 0.5075f;
		fVar2 = func_27(fVar0 > 25f, 25f, 15f);
		fVar2 *= (1f - system::sqrt(fVar0 / 100f));
		break;

	case 2:
		fVar1 = 0.558f;
		fVar2 = 15f * (1f - system::sqrt(fVar0 / 100f));
		break;

	case 5:
		fVar1 = 0.53f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 <= 63f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 <= 55f) {
			fVar1 *= 1.04f;
		}
		if (fVar0 <= 46f) {
			fVar1 *= 1.038f;
		}
		if (fVar0 <= 38f) {
			fVar1 *= 1.04f;
		}
		if (fVar0 <= 34f) {
			fVar1 *= 1.045f;
		}
		if (fVar0 <= 28f) {
			fVar1 *= 1.045f;
		}
		fVar2 = 0.1f;
		break;

	case 7: return -1f;

	case 4:
		fVar1 = 0.36f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 <= 62f) {
			fVar1 *= 1.035f;
		}
		else if (fVar0 <= 75f) {
			fVar1 *= 1.015f;
		}
		if (fVar0 <= 49f) {
			fVar1 *= 1.035f;
		}
		else if (fVar0 <= 58f) {
			fVar1 *= 1.025f;
		}
		if (fVar0 <= 39f) {
			fVar1 *= 1.075f;
		}
		else if (fVar0 <= 43f) {
			fVar1 *= 1.055f;
		}
		if (fVar0 <= 30f) {
			fVar1 *= 1.075f;
		}
		fVar2 = 0.1f;
		break;

	case 6:
		fVar1 = 0.79f;
		fVar1 *= (1f + 1f - system::sqrt(fVar0 / 100f));
		if (fVar0 < 65f) {
			fVar1 *= 1.015f;
		}
		if (fVar0 < 56f) {
			fVar1 *= 1.01f;
		}
		if (fVar0 < 51f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 < 45f) {
			fVar1 *= 1.02f;
		}
		if (fVar0 < 35f) {
			fVar1 *= 1.07f;
		}
		if (fVar0 < 25f) {
			fVar1 *= 1.1f;
		}
		fVar2 = 0.1f;
		break;
	}
	if (!bParam3) {
		fVar2 = 0f;
	}
	fVar3 = -1f * (fVar0 / 100f * func_144(uParam1, func_123(uParam0)) * func_143(func_28(uParam0)) * fVar1 + fVar2);
	return fVar3;
}

// Position - 0x54E8
float func_143(int iParam0) {
	switch (iParam0) {
	case 2:
	case 5: return 1f;

	case 4:
	case 1: return 0.95f;

	case 0:
	case 7:
	case -1: return 0.75f;

	case 3: return 1f;

	default: return 1f;
	}
	return 1f;
}

// Position - 0x5553
float func_144(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f;
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return 220f / 1.85f;

	case 2: return 210f / 1.85f;

	case 3: return 200f / 1.85f;

	case 4: return 190f / 1.85f;

	case 5: return 180f / 1.85f;

	case 6: return 180f / 1.85f;

	case 7: return 170f / 1.85f;

	case 8: return 160f / 1.85f;

	case 9: return 150f / 1.85f;

	case 10: return 140f / 1.85f;

	case 11: return 130f / 1.85f;

	case 12: return 120f / 1.85f;

	case 13: return 110f / 1.85f;

	case 14: return 100f / 1.85f;

	case 15: return 85f / 1.85f;

	case 16: return 75f / 1.85f;

	case 17: return 65f / 1.85f;

	case 18: return 40f / 1.85f;

	case 19: return 30f / 1.85f;
	}
	return 0f;
}

// Position - 0x5734
float func_145(var *uParam0, int iParam1) {
	float fVar0;

	fVar0 = uParam0->f_15;
	if (iParam1 && (func_24(uParam0) == 1 || func_24(uParam0) == 2)) {
		fVar0 -= func_146() * 10f;
		fVar0 = func_27(fVar0 < 5f, 5f, fVar0);
	}
	return fVar0;
}

// Position - 0x5780
float func_146() {
	int iVar0;
	float fVar1;

	stats::stat_get_int(func_147(func_149(), 2), &iVar0, -1);
	fVar1 = IntToFloat(iVar0) / 100f;
	fVar1 = 1f - fVar1;
	return fVar1;
}

// Position - 0x57AC
var func_147(int iParam0, int iParam1) {
	int *iVar0;
	int *iVar1;

	func_148(iParam0, iParam1, &iVar0, &iVar1);
	return iVar0;
}

// Position - 0x57C2
void func_148(int iParam0, int iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp0_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp0_stamina"); break;

		case 3: *iParam2 = joaat("sp0_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp0_strength"); break;

		case 4: *iParam2 = joaat("sp0_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp0_flying_ability"); break;

		case 6: *iParam2 = joaat("sp0_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp0_stealth_ability"); break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp1_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp1_stamina"); break;

		case 3: *iParam2 = joaat("sp1_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp1_strength"); break;

		case 4: *iParam2 = joaat("sp1_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp1_flying_ability"); break;

		case 6: *iParam2 = joaat("sp1_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp1_stealth_ability"); break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp2_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp2_stamina"); break;

		case 3: *iParam2 = joaat("sp2_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp2_strength"); break;

		case 4: *iParam2 = joaat("sp2_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp2_flying_ability"); break;

		case 6: *iParam2 = joaat("sp2_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp2_stealth_ability"); break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: *iParam3 = 64; break;

		case 1: *iParam3 = 65; break;

		case 3: *iParam3 = 67; break;

		case 2: *iParam3 = 66; break;

		case 4: *iParam3 = 68; break;

		case 5: *iParam3 = 69; break;

		case 6: *iParam3 = 70; break;

		case 7: *iParam3 = 71; break;
		}
		break;
	}
}

// Position - 0x5A19
int func_149() {
	func_150();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x5A32
void func_150() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_154(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_153(player::player_ped_id());
			if (func_152(iVar0) && (!func_151(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_152(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x5B2F
bool func_151(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x5B3D
bool func_152(int iParam0) { return iParam0 < 3; }

// Position - 0x5B49
int func_153(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_154(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x5B86
int func_154(int iParam0) {
	if (func_152(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x5BB0
int func_155(int iParam0) {
	char cVar0[32];
	char cVar8[32];
	char cVar16[32];
	char cVar24[32];

	if (!ped::is_ped_injured(iParam0)) {
		StringCopy(&cVar0, "Wood_swing_action", 32);
		StringCopy(&cVar8, "Iron_swing_action", 32);
		StringCopy(&cVar16, "Wedge_swing_action", 32);
		StringCopy(&cVar24, "Putt_action", 32);
		if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar0, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar0) > 0.16f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar8, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar8) > 0.134f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar16, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar16) > 0.119f) {
				return 1;
			}
		}
		else if (entity::is_entity_playing_anim(iParam0, func_119(0), &cVar24, 3)) {
			if (entity::get_entity_anim_current_time(iParam0, func_119(0), &cVar24) > 0.159f) {
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x5C98
void func_156(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4) {
	int iVar0;
	bool bVar1;
	float fVar2;
	float fVar3;

	iVar0 = 1000;
	if (func_269(uParam0, 256)) {
		iVar0 = 450;
	}
	bVar1 = func_269(uParam0, 131072);
	fVar2 = 0f;
	fVar3 = func_27(bVar1, 2f, 1f);
	if (uParam2->f_12 > 0) {
		uParam2->f_12 += system::floor(gameplay::get_frame_time() * 1000f);
	}
	if (uParam2->f_11 == 0 && !func_269(uParam0, 1048576) || func_166(uParam0) == 0) {
		func_186(uParam0, 1);
		uParam2->f_11 = gameplay::get_game_timer();
		uParam2->f_12 = uParam2->f_11;
		func_188(&uParam0->f_162);
		func_165(uParam0);
		*uParam2 = 1;
	}
	else if (uParam2->f_11 + iVar0 < uParam2->f_12 || uParam2->f_10 != 0)
		&&*uParam2 != 4 && *uParam2 != 6 || func_269(uParam0, 1048576) {
			func_186(uParam0, 4);
			*uParam2 = 4;
			if (iParam3) {
				uParam2->f_4 = func_141(0f, func_27(iParam4, 5f, 0f));
				uParam2->f_3 = func_164(uParam0, 0);
			}
			else {
				uParam2->f_4 = func_141(0f, fVar2);
				uParam2->f_3 = func_141(func_164(uParam0, 0), 20f) / fVar3;
				if (uParam2->f_3 < 15f) {
					uParam2->f_3 = 15f;
				}
			}
			if (func_136(uParam0) == 4 || func_136(uParam0) == 7 || func_136(uParam0) == 6 || func_136(uParam0) == 5) {
			}
			else {
				func_161(uParam0, uParam1, 0, 1f);
			}
			if (func_269(uParam0, 1048576)) {
				func_159(uParam0, uParam2->f_3);
				func_157(uParam0, uParam2->f_4);
			}
		}
}

// Position - 0x5E4A
void func_157(var *uParam0, float fParam1) { func_158(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1); }

// Position - 0x5E62
void func_158(var *uParam0, float fParam1) { uParam0->f_14 += fParam1; }

// Position - 0x5E75
void func_159(var *uParam0, float fParam1) {
	if (fParam1 > 100f) {
		fParam1 = 100f;
	}
	else if (fParam1 < 5f) {
		fParam1 = 5f;
	}
	func_160(&uParam0->f_15[uParam0->f_157 /*34*/], fParam1);
}

// Position - 0x5EAC
void func_160(var *uParam0, float fParam1) { uParam0->f_15 = fParam1; }

// Position - 0x5EBA
void func_161(var *uParam0, var uParam1, int iParam2, float fParam3) {
	iParam2 = iParam2;
	fParam3 = fParam3;
	switch (func_136(uParam0)) {
	case 0:
	case 1:
	case 3:
	case 2: audio::play_sound_from_entity(-1, "GOLF_FORWARD_SWING_HARD_MASTER", func_162(uParam0), 0, 0, 0); break;

	case 4:
	case 5:
	case 6:
	case 7: break;
	}
}

// Position - 0x5F1D
var func_162(var *uParam0) { return func_163(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x5F33
var func_163(var *uParam0) { return uParam0->f_4; }

// Position - 0x5F3F
float func_164(var *uParam0, int iParam1) { return func_145(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x5F57
void func_165(var *uParam0) {
	switch (func_136(uParam0)) {
	case 0:
	case 1: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_162(uParam0), 0, 0, 0); break;

	case 3:
	case 2: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_162(uParam0), 0, 0, 0); break;

	case 4:
	case 5:
	case 6:
	case 7: audio::play_sound_from_entity(-1, "GOLF_BACK_SWING_HARD_MASTER", func_162(uParam0), 0, 0, 0); break;
	}
}

// Position - 0x5FD9
int func_166(var *uParam0) { return func_167(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x5FEF
int func_167(var *uParam0) { return uParam0->f_20; }

// Position - 0x5FFB
void func_168(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x6011
float func_169(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	if (iParam2) {
		return system::vdist2(vVar0, vVar3);
	}
	return system::pow(vVar0.x - vVar3.x, 2f) + system::pow(vVar0.y - vVar3.y, 2f);
}

// Position - 0x6091
bool func_170(int *iParam0, float fParam1) {
	if (func_251(iParam0, fParam1)) {
		func_168(iParam0);
		return true;
	}
	return false;
}

// Position - 0x60AF
bool func_171(var *uParam0, var *uParam1) {
	int iVar0;
	vector3 vVar1;

	iVar0 = func_244(uParam1);
	if (entity::does_entity_exist(func_172(uParam1)) && func_35(uParam1) == 3) {
		return true;
	}
	if (!entity::does_entity_exist(iVar0)) {
		return false;
	}
	vVar1 = {entity::get_entity_coords(func_244(uParam1), 0)};
	if (func_35(uParam1) != 3 && system::vdist2(vVar1, func_41(uParam0, func_307(uParam1))) > 0.7f * 0.7f) {
		return false;
	}
	if (system::vdist2(vVar1, func_41(uParam0, func_307(uParam1))) > 55f * 55f) {
		return false;
	}
	return true;
}

// Position - 0x6156
var func_172(var *uParam0) { return func_173(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x616C
var func_173(var *uParam0) { return uParam0->f_6; }

// Position - 0x6178
void func_174(var *uParam0, var *uParam1, var *uParam2) {
	if (func_40(uParam1, 1048576) || func_22(uParam1) == 5) {
		return;
	}
	switch (func_137(uParam1)) {
	case 0:
	case 1:
	case 3:
	case 2: func_175(uParam0, uParam1, uParam2); break;

	case 4:
	case 5:
	case 6:
	case 7: func_175(uParam0, uParam1, uParam2); break;
	}
}

// Position - 0x61F3
void func_175(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float *fVar5;
	char *sVar6;
	bool bVar7;
	char *sVar8;
	char cVar9[32];
	char cVar17[32];
	char cVar25[32];
	char cVar33[32];

	if (func_185(uParam1)) {
		func_184(uParam0, uParam1, uParam2);
		return;
	}
	iVar0 = func_293(uParam1);
	fVar1 = 1f;
	fVar2 = 0.1f;
	fVar3 = 0.05f;
	fVar1 = fVar1;
	if (bLocal_0) {
	}
	if (!ped::is_ped_injured(iVar0)) {
		sVar6 = func_177(uParam1, uParam0, &fVar5, 0, 0, 0, 0);
		bVar7 = !func_107(sVar6);
		sVar8 = func_121(uParam0, uParam1, 0, 1);
		StringCopy(&cVar9, sVar8, 32);
		StringCopy(&cVar17, sVar8, 32);
		StringCopy(&cVar25, sVar8, 32);
		StringCopy(&cVar33, sVar8, 32);
		StringConCat(&cVar9, "Idle", 32);
		StringConCat(&cVar17, "Swing_Intro", 32);
		StringConCat(&cVar25, "Swing_Action", 32);
		StringConCat(&cVar33, "Swing_idle", 32);
		sVar6 = sVar6;
		bVar7 = bVar7;
		switch (func_167(uParam1)) {
		case 0:
			if (bLocal_0) {
			}
			break;

		case 1:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
				ai::task_play_anim(iVar0, func_119(0), &cVar17, 8f, -8f, -1, 2, 0, 0, 0, 0);
				if (bLocal_0) {
				}
			}
			else {
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
				if (entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17) >= 0.975f) {
					if (bLocal_0) {
					}
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0f);
					if (uParam2->f_10 == 0) {
						uParam2->f_10 = gameplay::get_game_timer();
					}
				}
				else {
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0.6f);
				}
				if (fVar4 < fVar2) {
					entity::set_entity_anim_current_time(iVar0, func_119(0), &cVar17, fVar2);
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0.8f);
				}
			}
			break;

		case 3:
			if (bLocal_0) {
			}
			StringConCat(&cVar9, "_A", 32);
			if (entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
				entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0f);
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
				if (fVar4 < fVar2) {
					ai::task_play_anim(iVar0, func_119(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					func_176(uParam1, 0);
				}
				else {
					entity::set_entity_anim_current_time(iVar0, func_119(0), &cVar17, fVar4 - fVar3);
					if (bLocal_0) {
					}
				}
			}
			else {
				if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar9, 3)) {
					ai::task_play_anim(iVar0, func_119(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				func_176(uParam1, 0);
			}
			break;

		case 4:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar25, 3)) {
				if (entity::has_entity_anim_finished(iVar0, func_119(0), &cVar17, 3)) {
					ai::task_play_anim(iVar0, func_119(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else if (entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
					fVar1 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
					ai::task_play_anim(iVar0, func_119(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else {
					func_176(uParam1, 0);
				}
			}
			break;
		}
	}
}

// Position - 0x64EA
void func_176(var *uParam0, int iParam1) { uParam0->f_20 = iParam1; }

// Position - 0x64F8
char *func_177(var *uParam0, var *uParam1, float *fParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	vector3 vVar5;
	float fVar8;
	float fVar9;
	float fVar10;
	vector3 vVar11;
	vector3 vVar14;
	vector3 vVar17;
	vector3 vVar20;
	float fVar23;
	float fVar24;
	vector3 vVar25;

	return "";
	iVar0 = func_123(uParam0);
	iVar1 = func_122(uParam1, iVar0);
	vVar2 = {entity::get_entity_coords(func_293(uParam0), 1)};
	if (iParam3) {
		vVar2 = {iParam4, iParam5, iParam6};
	}
	vVar5 = {func_272(uParam0)};
	fVar8 = 52.25f;
	func_182(iVar1, &fVar8, &fVar9, &fVar10);
	vVar2.z += fVar10;
	vVar11 = {entity::get_entity_forward_vector(func_293(uParam0))};
	vVar14 = {func_6(vVar5 - vVar2)};
	vVar17 = {func_131(vVar11, 90f)};
	vVar20 = {vVar11};
	func_178(&vVar20, fVar8, vVar17);
	fVar23 = gameplay::acos(func_8(vVar11, vVar14));
	fVar24 = fVar23 - fVar8;
	vVar25 = {func_6(vVar20)};
	func_178(&vVar25, fVar24, vVar17);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar14, 255, 0, 0, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar11, 0, 0, 255, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar25, 255, 255, 255, 255);
	unk_0x0A25F80D5BADC013(vVar2, vVar2 + vVar20, 0, 0, 0, 255);
	if (fVar23 < fVar8) {
		*fParam2 = gameplay::absf(fVar24) * fVar9;
		if (*fParam2 > 0.9999f) {
			*fParam2 = 0.9999f;
		}
		return "_High";
	}
	else {
		*fParam2 = gameplay::absf(fVar24) * fVar9;
		if (*fParam2 > 0.9999f) {
			*fParam2 = 0.9999f;
		}
		return "_Low";
	}
	*fParam2 = 0f;
	return "_High";
}

// Position - 0x668E
void func_178(var *uParam0, float fParam1, vector3 vParam2) {
	float fVar0;
	float fVar1;

	vParam2 = {func_6(vParam2)};
	fVar0 = system::cos(fParam1);
	fVar1 = system::sin(fParam1);
	*uParam0 = {func_181(*uParam0, vParam2) * FtoV(fVar0) + func_180(vParam2, *uParam0) * FtoV(fVar1) +
				func_179(*uParam0, vParam2)};
}

// Position - 0x66E4
Vector3 func_179(vector3 vParam0, vector3 vParam3) {
	vector3 vVar0;

	vVar0 = {vParam3 * FtoV(func_8(vParam0, vParam3))};
	return vVar0;
}

// Position - 0x6706
Vector3 func_180(vector3 vParam0, vector3 vParam3) {
	return vParam0.y * vParam3.z - vParam0.z * vParam3.y, vParam0.z * vParam3.x - vParam0.x * vParam3.z,
		   vParam0.x * vParam3.y - vParam0.y * vParam3.x;
}

// Position - 0x673F
Vector3 func_181(vector3 vParam0, vector3 vParam3) {
	vector3 vVar0;

	vVar0 = {vParam0 - func_179(vParam0, vParam3)};
	return vVar0;
}

// Position - 0x6760
void func_182(int iParam0, float *fParam1, float *fParam2, float *fParam3) {
	if (func_183()) {
		if (iParam0 <= 5) {
			*fParam1 = 47.24f;
			*fParam2 = 0.2f;
			*fParam3 = 0.09f;
		}
		else if (iParam0 > 5 && iParam0 <= 13) {
			*fParam1 = 53.367f;
			*fParam2 = 0.2f;
			*fParam3 = 0f;
		}
		else if (iParam0 > 13 && iParam0 <= 18) {
			*fParam1 = 52.199f;
			*fParam2 = 0.2f;
			*fParam3 = -0.07f;
		}
		else {
			*fParam1 = 70.53f;
			*fParam2 = 0.35f;
			*fParam3 = 0.5f;
		}
	}
	else if (iParam0 <= 5) {
		*fParam1 = 46.23f;
		*fParam2 = 0.2f;
		*fParam3 = 0.09f;
	}
	else if (iParam0 > 5 && iParam0 <= 13) {
		*fParam1 = 52.25f;
		*fParam2 = 0.2f;
		*fParam3 = 0f;
	}
	else if (iParam0 > 13 && iParam0 <= 18) {
		*fParam1 = 51.91f;
		*fParam2 = 0.15f;
		*fParam3 = -0.07f;
	}
	else {
		*fParam1 = 70.53f;
		*fParam2 = 0.35f;
		*fParam3 = 0.5f;
	}
}

// Position - 0x688E
bool func_183() { return false; }

// Position - 0x6897
void func_184(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float *fVar5;
	char *sVar6;
	bool bVar7;
	char *sVar8;
	char cVar9[32];
	char cVar17[32];
	char cVar25[32];

	iVar0 = func_293(uParam1);
	fVar1 = 1f;
	fVar2 = 0.1f;
	fVar3 = 0.05f;
	fVar1 = fVar1;
	if (bLocal_0) {
	}
	if (!ped::is_ped_injured(iVar0)) {
		sVar6 = func_177(uParam1, uParam0, &fVar5, 0, 0, 0, 0);
		bVar7 = !func_107(sVar6);
		sVar8 = func_121(uParam0, uParam1, 0, 1);
		StringCopy(&cVar9, sVar8, 32);
		StringCopy(&cVar17, sVar8, 32);
		StringCopy(&cVar25, sVar8, 32);
		StringConCat(&cVar9, "Idle", 32);
		StringConCat(&cVar17, "Intro", 32);
		StringConCat(&cVar25, "Action", 32);
		sVar6 = sVar6;
		bVar7 = bVar7;
		switch (func_167(uParam1)) {
		case 0:
			if (bLocal_0) {
			}
			break;

		case 1:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
				ai::task_play_anim(iVar0, func_119(0), &cVar17, 8f, -8f, -1, 2, 0, 0, 0, 0);
				if (bLocal_0) {
				}
			}
			else {
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
				if (entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17) >= 0.975f) {
					if (bLocal_0) {
					}
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0f);
					if (uParam2->f_10 == 0) {
						uParam2->f_10 = gameplay::get_game_timer();
					}
				}
				else {
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0.6f);
				}
				if (fVar4 < fVar2) {
					entity::set_entity_anim_current_time(iVar0, func_119(0), &cVar17, fVar2);
					entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0.8f);
				}
			}
			break;

		case 3:
			if (bLocal_0) {
			}
			StringConCat(&cVar9, "_a", 32);
			if (entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
				entity::set_entity_anim_speed(iVar0, func_119(0), &cVar17, 0f);
				fVar4 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
				if (fVar4 < fVar2) {
					ai::task_play_anim(iVar0, func_119(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					func_176(uParam1, 0);
				}
				else {
					entity::set_entity_anim_current_time(iVar0, func_119(0), &cVar17, fVar4 - fVar3);
					if (bLocal_0) {
					}
				}
			}
			else {
				if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar9, 3)) {
					ai::task_play_anim(iVar0, func_119(0), &cVar9, 4f, -8f, -1, 10, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				func_176(uParam1, 0);
			}
			break;

		case 4:
			if (bLocal_0) {
			}
			if (!entity::is_entity_playing_anim(iVar0, func_119(0), &cVar25, 3)) {
				if (entity::has_entity_anim_finished(iVar0, func_119(0), &cVar17, 3)) {
					ai::task_play_anim(iVar0, func_119(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else if (entity::is_entity_playing_anim(iVar0, func_119(0), &cVar17, 3)) {
					fVar1 = entity::get_entity_anim_current_time(iVar0, func_119(0), &cVar17);
					ai::task_play_anim(iVar0, func_119(0), &cVar25, 8f, -8f, -1, 2, 0, 0, 0, 0);
					if (bLocal_0) {
					}
				}
				else {
					func_176(uParam1, 0);
				}
			}
			break;
		}
	}
}

// Position - 0x6B6A
bool func_185(var *uParam0) {
	int iVar0;

	iVar0 = func_137(uParam0);
	if (iVar0 == 5 || iVar0 == 4 || iVar0 == 6 || iVar0 == 7) {
		return true;
	}
	return false;
}

// Position - 0x6BA4
void func_186(var *uParam0, int iParam1) { func_176(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x6BBC
int func_187() { return 4; }

// Position - 0x6BC5
void func_188(var *uParam0) { func_189(uParam0, 0f); }

// Position - 0x6BD4
void func_189(int *iParam0, float fParam1) {
	uParam0->f_1 = func_190(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x6C02
float func_190(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x6C5A
void func_191(var *uParam0, int iParam1, var *uParam2, int iParam3, int iParam4) {
	func_42(uParam0, iParam1, func_259(uParam0, iParam1), uParam2, iParam3, iParam4);
}

// Position - 0x6C78
int func_192(var *uParam0) {
	if (func_238() || func_193(uParam0)) {
		if (ai::get_script_task_status(func_64(uParam0), 242628503) == 1) {
			if (ai::get_sequence_progress(func_64(uParam0)) == 2) {
				return 1;
			}
		}
	}
	else if (ai::get_script_task_status(func_64(uParam0), 242628503) != 1 &&
			 ai::get_script_task_status(func_64(uParam0), 242628503) != 0) {
		return 1;
	}
	return 0;
}

// Position - 0x6CEA
bool func_193(var *uParam0) {
	int iVar0;

	iVar0 = func_136(uParam0);
	if (iVar0 == 5 || iVar0 == 4 || iVar0 == 6 || iVar0 == 7) {
		return true;
	}
	return false;
}

// Position - 0x6D24
void func_194(var *uParam0, vector3 vParam1) { func_49(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x6D3E
Vector3 func_195(var *uParam0, var *uParam1) {
	vector3 vVar0;
	float fVar3;
	float fVar4;
	var uVar5;
	vector3 vVar6;

	fVar3 = func_141(0f, 8f);
	fVar4 = func_141(1f, 0.2f);
	if (func_111(uParam0)) {
		fVar3 = func_141(0f, 4f);
		fVar4 = 1f;
	}
	if (func_269(uParam0, 1048576) || func_85(uParam0) == 4) {
		vVar0 = {object::_get_object_offset_from_coords(
			func_19(uParam0), func_116(uParam0) + fVar3,
			-func_144(uParam1, func_140(uParam0)) * func_196(func_136(uParam0)) *
				func_143(func_28(&uParam0->f_15[func_264(uParam0) /*34*/])) * func_164(uParam0, 1) * fVar4 / 100f,
			0f, 0f)};
	}
	else if (func_35(uParam0) != 3) {
		vVar0 = {object::_get_object_offset_from_coords(
			func_19(uParam0), func_116(uParam0),
			-func_144(uParam1, func_140(uParam0)) * func_196(func_136(uParam0)) *
				func_143(func_28(&uParam0->f_15[func_264(uParam0) /*34*/])) * func_164(uParam0, 1) / 100f,
			0f, 0f)};
	}
	else {
		vVar0 = {object::_get_object_offset_from_coords(func_19(uParam0), func_116(uParam0),
														FtoV(-uParam0->f_1.f_1) *
															Vector(0f, 0f, func_164(uParam0, 1) / 100f))};
	}
	if (gameplay::get_ground_z_for_3d_coord(vVar0, &uVar5, 0)) {
		vVar0.z = uVar5;
	}
	else {
		vVar0.z += 50f;
		if (gameplay::get_ground_z_for_3d_coord(vVar0, &uVar5, 0)) {
			vVar0.z = uVar5;
		}
		else {
			vVar6 = {func_19(uParam0)};
			vVar0.z = vVar6.z;
		}
	}
	return vVar0;
}

// Position - 0x6EC3
float func_196(int iParam0) {
	switch (iParam0) {
	case 0: return 1f;

	case 3: return 0.5075f / 0.5575f;

	case 2: return 0.558f / 0.5575f;

	case 5: return 0.53f / 0.5575f;

	case 7:
	case 4: return 0.36f / 0.5575f;

	case 6: return 0.79f / 0.5575f;

	case 1: return 0.575f / 0.5575f;
	}
	return 1f;
}

// Position - 0x6F70
void func_197(var *uParam0, var *uParam1, var *uParam2) {
	float fVar0;
	float fVar1;
	float fVar2;
	int iVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;

	fVar0 = func_37(uParam1);
	fVar1 = uParam0->f_1;
	fVar2 = 100f * fVar0 / fVar1;
	iVar3 = func_122(uParam2, func_123(uParam1));
	if (iVar3 == 17 || iVar3 == 16) {
		fVar4 = fVar0 / fVar1;
		fVar5 = 1f - fVar4;
		if (iVar3 == 16) {
			fVar6 = 2.5f;
		}
		else if (func_24(uParam1) != 4) {
			if (fVar2 > 40f) {
				fVar6 = 1.5f;
			}
			else if (fVar2 > 30f) {
				fVar6 = 2f;
			}
			else {
				fVar6 = 2.5f;
			}
		}
		fVar7 = fVar6 * fVar5 * fVar5 + 1f;
		fVar4 *= fVar7;
		fVar2 = fVar4 * 100f;
	}
	else if (iVar3 == 19 && func_24(uParam1) != 4) {
		fVar2 += func_146() * 10f;
	}
	func_160(uParam1, fVar2);
	if (func_145(uParam1, 0) > 100f) {
		func_160(uParam1, 100f);
	}
	else if (func_145(uParam1, 0) < 5f) {
		func_160(uParam1, 5f);
	}
}

// Position - 0x7086
void func_198(var *uParam0, var *uParam1, var *uParam2) {
	if (!func_171(uParam1, uParam2) && !func_193(uParam2)) {
		uParam2->f_1.f_1 = func_199(uParam2, uParam0);
	}
	else if (func_136(uParam2) == 4) {
		uParam2->f_1.f_1 = 5f;
	}
	else if (func_136(uParam2) == 5 || func_136(uParam2) == 7) {
		uParam2->f_1.f_1 = 10f;
	}
	else {
		uParam2->f_1.f_1 = 20f;
	}
}

// Position - 0x70FD
float func_199(var *uParam0, var *uParam1) {
	float fVar0;

	fVar0 = func_200(uParam1, func_140(uParam0));
	return fVar0;
}

// Position - 0x7115
float func_200(var *uParam0, int iParam1) {
	switch ((*uParam0)[iParam1]) {
	case 1: return 105.8f;

	case 3: return 100.5f;

	case 5: return 97.3f;

	case 7: return 90.2f;

	case 8: return 87f;

	case 9: return 83f;

	case 10: return 79.9f;

	case 11: return 73.5f;

	case 12: return 68f;

	case 13: return 59.1f;

	case 14: return 52.5f;

	case 16: return 30.9f;

	case 17: return 21.8f;

	default: break;
	}
	return 0f;
}

// Position - 0x7209
void func_201(int iParam0, int iParam1) { entity::freeze_entity_position(iParam0, iParam1); }

// Position - 0x7219
void func_202(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	vector3 vVar0;
	int iVar3;

	if (iParam5) {
		vVar0 = {func_243(uParam0, func_307(uParam1))};
	}
	else {
		vVar0 = {func_41(uParam0, func_307(uParam1))};
	}
	iVar3 = func_242(vVar0, func_19(uParam1)) + 90f;
	func_203(&uParam1->f_15[func_264(uParam1) /*34*/], uParam2, iVar3, 0, iParam3, iParam4, iParam6, iParam7);
}

// Position - 0x727C
void func_203(var *uParam0, var *uParam1, int iParam2, int iParam3, var uParam4, int iParam5, var uParam6,
			  bool bParam7) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;
	float fVar7;
	bool bVar8;

	if (func_24(uParam0) == 4) {
		ai::task_stand_still(func_293(uParam0), -1);
	}
	else {
		iParam5 = 1;
	}
	iVar0 = func_122(uParam1, func_123(uParam0));
	func_255(uParam0, 134217728);
	func_224(uParam0, iParam2);
	vVar1 = {object::_get_object_offset_from_coords(func_272(uParam0), func_117(uParam0), func_223(iVar0))};
	vVar4 = {entity::get_entity_coords(func_293(uParam0), 1)};
	if (iParam3) {
		ai::clear_ped_tasks_immediately(func_293(uParam0));
	}
	if (iParam5 || func_40(uParam0, 1048576)) {
		if (func_24(uParam0) != 4) {
			func_4(&vVar4, 100f, 0f);
		}
		if (gameplay::get_ground_z_for_3d_coord(vVar1 + Vector(1f, 0f, 0f), &fVar7, 0)) {
			if (gameplay::absf(fVar7 - vVar4.z) < 0.35f || fVar7 < vVar1.z || bParam7) {
				vVar1.z = fVar7;
			}
		}
		if (uParam4 && func_183()) {
			func_214(vVar1, func_117(uParam0), 0, 0, 0, 0, 1, 0, 1, 0);
		}
		else {
			bVar8 = true;
			if (bVar8) {
				entity::set_entity_heading(func_293(uParam0), func_117(uParam0));
				entity::set_entity_coords(func_293(uParam0), vVar1, 0, 1, 1, 1);
			}
		}
	}
	else {
		ai::clear_ped_tasks(func_293(uParam0));
		ai::open_sequence_task(&uParam0->f_21);
		if (func_238() || func_185(uParam0)) {
			ai::task_follow_nav_mesh_to_coord(0, vVar1, 1f, -1, 0.25f, 512, iParam2);
			ai::task_play_anim(0, "mini@golfai", "putt_approach_no_ball", 2f, -4f, -1, 0, 0, 0, 0, 0);
			ai::task_play_anim(0, "mini@golfai", "putt_approach_no_ball", 4f, -4f, -1, 2, 0.999f, 0, 0, 0);
		}
		else {
			ai::task_follow_nav_mesh_to_coord(0, vVar1, 1f, -1, 0.25f, 512, iParam2);
		}
		ai::close_sequence_task(uParam0->f_21);
		ai::task_perform_sequence(func_293(uParam0), uParam0->f_21);
		ai::clear_sequence_task(&uParam0->f_21);
	}
	if (bParam7) {
		func_211(uParam0, uParam1);
	}
	if (uParam6 && !func_40(uParam0, 1048576)) {
		func_204(uParam0, uParam1, 0, 0);
	}
}

// Position - 0x748F
void func_204(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	bool bVar2;
	int iVar3;

	iVar0 = func_122(uParam1, func_123(uParam0));
	iVar1 = func_210(uParam1, func_123(uParam0));
	if (iParam3) {
		if (!func_209(func_293(uParam0), iVar0)) {
			return;
		}
	}
	bVar2 = true;
	if (entity::does_entity_exist(func_163(uParam0))) {
		if (iVar1 == entity::get_entity_model(func_163(uParam0))) {
			bVar2 = false;
		}
	}
	if (bVar2) {
		func_207(uParam0, func_208(uParam0, uParam1));
	}
	if (!iParam2 || bVar2) {
		iVar3 = func_293(uParam0);
		if (!ped::is_ped_injured(iVar3)) {
			entity::attach_entity_to_entity(func_163(uParam0), iVar3, ped::get_ped_bone_index(iVar3, 28422),
											func_206(iVar3, iVar0), func_205(iVar3, iVar0), 0, 0, 0, 0, 2, 1);
		}
	}
}

// Position - 0x754B
Vector3 func_205(int iParam0, int iParam1) {
	iParam0 = iParam0;
	iParam1 = iParam1;
	return 0f, 0f, 0f;
}

// Position - 0x755E
Vector3 func_206(int iParam0, int iParam1) { return 0f, 0f, 0f; }

// Position - 0x7569
void func_207(var *uParam0, int iParam1) {
	if (uParam0->f_4 == iParam1) {
		return;
	}
	if (entity::does_entity_exist(uParam0->f_4)) {
		object::delete_object(&uParam0->f_4);
	}
	uParam0->f_4 = iParam1;
}

// Position - 0x7596
int func_208(var *uParam0, var *uParam1) {
	var uVar0;

	func_38(uParam0);
	uVar0 = object::create_object_no_offset(func_210(uParam1, func_123(uParam0)), func_272(uParam0), 0, 1, 0);
	return uVar0;
}

// Position - 0x75C1
int func_209(int iParam0, int iParam1) {
	if (iParam1 >= 1 && iParam1 <= 5) {
		return entity::is_entity_playing_anim(iParam0, func_119(0), "wood_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "wood_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "wood_idle_c", 3);
	}
	else if (iParam1 >= 6 && iParam1 <= 13) {
		return entity::is_entity_playing_anim(iParam0, func_119(0), "iron_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "iron_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "iron_idle_c", 3);
	}
	else if (iParam1 >= 14 && iParam1 <= 18) {
		return entity::is_entity_playing_anim(iParam0, func_119(0), "wedge_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "wedge_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "wedge_idle_c", 3);
	}
	else if (iParam1 == 19) {
		return entity::is_entity_playing_anim(iParam0, func_119(0), "putt_idle_a", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "putt_idle_b", 3) |
			   entity::is_entity_playing_anim(iParam0, func_119(1), "putt_idle_c", 3);
	}
	return 0;
}

// Position - 0x7709
int func_210(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return joaat("prop_golf_driver");
	}
	switch ((*uParam0)[iParam1]) {
	case 1: return joaat("prop_golf_wood_01");

	case 2: return joaat("prop_golf_wood_01");

	case 3: return joaat("prop_golf_wood_01");

	case 4: return joaat("prop_golf_wood_01");

	case 5: return joaat("prop_golf_wood_01");

	case 6: return joaat("prop_golf_iron_01");

	case 7: return joaat("prop_golf_iron_01");

	case 8: return joaat("prop_golf_iron_01");

	case 9: return joaat("prop_golf_iron_01");

	case 10: return joaat("prop_golf_iron_01");

	case 11: return joaat("prop_golf_iron_01");

	case 12: return joaat("prop_golf_iron_01");

	case 13: return joaat("prop_golf_iron_01");

	case 14: return joaat("prop_golf_pitcher_01");

	case 15: return joaat("prop_golf_pitcher_01");

	case 16: return joaat("prop_golf_pitcher_01");

	case 17: return joaat("prop_golf_pitcher_01");

	case 18: return joaat("prop_golf_pitcher_01");

	case 19: return joaat("prop_golf_putter_01");
	}
	return joaat("prop_golf_driver");
}

// Position - 0x7880
void func_211(var *uParam0, var *uParam1) {
	float fVar0;
	char *sVar1;
	bool bVar2;
	char cVar3[32];
	char cVar11[32];

	sVar1 = func_177(uParam0, uParam1, &fVar0, 0, 0, 0, 0);
	bVar2 = !func_107(sVar1);
	StringCopy(&cVar3, func_121(uParam1, uParam0, 0, 1), 32);
	StringConCat(&cVar3, "idle", 32);
	cVar11 = {cVar3};
	StringConCat(&cVar11, sVar1, 32);
	StringConCat(&cVar11, "_a", 32);
	StringConCat(&cVar3, "_a", 32);
	if (bVar2) {
	}
	func_212(func_293(uParam0), &cVar3, &cVar11, bVar2, fVar0, 1f, 10, 0f, 0f, 0f, 0);
	if (!func_40(uParam0, 32768)) {
		ped::_0x2208438012482A1A(func_293(uParam0), 1, 0);
		ped::_0xED3C76ADFA6D07C4(func_293(uParam0));
		func_57(uParam0, 32768);
	}
}

// Position - 0x7923
void func_212(int iParam0, char[4] cParam1, char[4] cParam2, bool bParam3, float fParam4, float fParam5, int iParam6,
			  float fParam7, float fParam8, float fParam9, int iParam10) {
	struct<20> Var0;
	struct<21> Var22;

	Var0.f_4 = 1065353216;
	Var0.f_5 = 1065353216;
	Var0.f_9 = 1065353216;
	Var0.f_10 = 1065353216;
	Var0.f_14 = 1065353216;
	Var0.f_15 = 1065353216;
	Var0.f_17 = 1040187392;
	Var0.f_18 = 1040187392;
	Var0.f_19 = -1;
	Var22.f_4 = 1065353216;
	Var22.f_5 = 1065353216;
	Var22.f_9 = 1065353216;
	Var22.f_10 = 1065353216;
	Var22.f_14 = 1065353216;
	Var22.f_15 = 1065353216;
	Var22.f_17 = 1040187392;
	Var22.f_18 = 1040187392;
	Var22.f_19 = -1;
	if (bParam3) {
		Var22 = 2;
		Var22.f_5 = 1f - fParam4;
		Var22.f_10 = fParam4;
		Var22.f_15 = 0f;
		Var22.f_12 = func_213(cParam1);
		Var22.f_11 = func_119(iParam10);
	}
	else {
		Var22 = 1;
	}
	Var22.f_2 = func_213(cParam1);
	Var22.f_1 = func_119(iParam10);
	Var22.f_3 = fParam7;
	Var22.f_4 = fParam5;
	if (bParam3) {
		Var22.f_7 = func_213(cParam2);
		Var22.f_6 = func_119(1);
		Var22.f_8 = fParam7;
		Var22.f_9 = fParam5;
	}
	Var22.f_20 = iParam6;
	ai::task_scripted_animation(iParam0, &Var22, &Var0, &Var0, fParam8, fParam9);
}

// Position - 0x7A6C
var func_213(var uParam0) { return uParam0; }

// Position - 0x7A76
int func_214(vector3 vParam0, float fParam3, int iParam4, int iParam5, int iParam6, int iParam7, int iParam8,
			 int iParam9, int iParam10, int iParam11) {
	vector3 vVar0;
	float fVar3;
	int iVar4;

	Global_17151.f_6 = 1;
	if (streaming::is_player_switch_in_progress() && !iParam9) {
		if (Global_2433125.f_731) {
			func_220(0, iParam9);
		}
		return 0;
	}
	if (streaming::is_new_load_scene_active() && !iParam9 && !player::is_player_teleport_active()) {
		return 0;
	}
	if (!func_219()) {
		if (func_218(player::player_id(), 1, 0)) {
			if (iParam9 && func_217(player::player_id(), 1, 0) && streaming::is_player_switch_in_progress() &&
				Global_2421664[player::player_id() /*358*/].f_225 == 1) {
			}
			else {
				return 0;
			}
		}
	}
	if (fParam3 < 0f) {
		fParam3 += 360f;
	}
	if (fParam3 >= 360f) {
		fParam3 += -360f;
	}
	if (!Global_2433125.f_731 && !iParam11) {
		vVar0 = {entity::get_entity_coords(player::player_ped_id(), 0)};
		if (gameplay::absf(vVar0.x - vParam0.x) < 0.2f && gameplay::absf(vVar0.y - vParam0.y) < 0.2f &&
			gameplay::absf(vVar0.z - vParam0.z) < 1.2f) {
			fVar3 = fParam3 - entity::get_entity_heading(player::player_ped_id());
			if (fVar3 > 180f) {
				fVar3 += -360f;
			}
			if (fVar3 < -180f) {
				fVar3 += 360f;
			}
			if (gameplay::absf(fVar3) < 1f) {
				Global_2433125.f_731 = 0;
				Global_2433125.f_732 = 0;
				if (player::is_player_teleport_active()) {
					player::stop_player_teleport();
				}
				return 1;
			}
		}
	}
	if (vParam0.x != Global_2433125.f_733 || vParam0.y != Global_2433125.f_733.f_1 ||
		vParam0.z != Global_2433125.f_733.f_2 || fParam3 != Global_2433125.f_736) {
		if (Global_2433125.f_731 == 1) {
			if (network::get_time_difference(network::get_network_time(), Global_2433125.f_737) < func_216(0)) {
				return 0;
			}
			player::stop_player_teleport();
			Global_2433125.f_732 = 1;
		}
		else {
			Global_2433125.f_732 = 0;
		}
		Global_2433125.f_733 = {vParam0};
		Global_2433125.f_736 = fParam3;
		Global_2433125.f_731 = 0;
	}
	if (!Global_2433125.f_731 && !player::is_player_teleport_active()) {
		if (iParam4) {
			iParam5 = 0;
		}
		iParam7 = iParam7;
		if (iParam7) {
		}
		if (iParam5) {
		}
		if (iParam8) {
		}
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			if (!gameplay::is_bit_set(Global_91543.f_1308[44], 16)) {
				func_215();
			}
			if (!weapon::get_current_ped_vehicle_weapon(player::player_ped_id(), &Global_2404994.f_490)) {
				Global_2404994.f_490 = 0;
			}
		}
		if (iParam9) {
			if (iParam4) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					iVar4 = ped::get_vehicle_ped_is_using(player::player_ped_id());
					entity::set_entity_coords(iVar4, vParam0, 0, 1, 1, 1);
					entity::set_entity_heading(iVar4, fParam3);
				}
				else {
					entity::set_entity_coords(player::player_ped_id(), vParam0, 0, 0, 0, 1);
					entity::set_entity_heading(player::player_ped_id(), fParam3);
				}
			}
			else {
				entity::set_entity_coords(player::player_ped_id(), vParam0, 0, 0, 0, 1);
				entity::set_entity_heading(player::player_ped_id(), fParam3);
			}
			func_220(iParam6, iParam9);
			return 1;
		}
		else {
			streaming::clear_focus();
			player::start_player_teleport(player::player_id(), vParam0, fParam3, iParam4, iParam10, 0);
		}
		Global_2433125.f_737 = network::get_network_time();
		Global_2433125.f_731 = 1;
	}
	if (Global_2433125.f_731) {
		Global_17151.f_6 = 1;
		Global_2433125.f_737 = network::get_network_time();
		if (iParam9) {
			if (system::vdist(entity::get_entity_coords(player::player_ped_id(), 0), Global_2433125.f_733) < 2f) {
				if (player::is_player_teleport_active()) {
					player::stop_player_teleport();
				}
				func_220(iParam6, iParam9);
				return 1;
			}
		}
		if (!player::is_player_teleport_active()) {
			func_220(iParam6, iParam9);
			return 1;
		}
	}
	return 0;
}

// Position - 0x7E1F
void func_215() {
	int iVar0;

	iVar0 = audio::get_player_radio_station_index();
	if (unk_0x2DD39BF3E2F9C47F() && Global_2404994.f_2219 == 0) {
		iVar0 = 255;
	}
	if (iVar0 != Global_2404994.f_2218) {
		if (!audio::is_radio_retuning()) {
			Global_2404994.f_2218 = iVar0;
		}
	}
}

// Position - 0x7E68
int func_216(int iParam0) {
	if (cam::is_screen_faded_out()) {
		return 10000;
	}
	if (iParam0) {
		return 5000;
	}
	return 1000;
}

// Position - 0x7E8B
int func_217(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return 0;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return 0;
				}
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x7ED5
bool func_218(int iParam0, int iParam1, int iParam2) {
	if (Global_2421664[iParam0 /*358*/].f_225 == 99) {
		if (iParam2 && Global_2421664[iParam0 /*358*/].f_228 == 0 || iParam2 == 0) {
			return false;
		}
	}
	if (iParam1) {
		if (Global_2421664[iParam0 /*358*/].f_225 == 13) {
			return false;
		}
	}
	return true;
}

// Position - 0x7F2C
bool func_219() { return Global_1315210; }

// Position - 0x7F38
void func_220(int iParam0, bool bParam1) {
	if (!iParam0) {
		cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
		cam::set_gameplay_cam_relative_heading(0f);
	}
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		ped::clear_ped_wetness(player::player_ped_id());
	}
	if (!bParam1) {
		streaming::clear_focus();
	}
	if (player::is_player_teleport_active()) {
		player::stop_player_teleport();
	}
	func_222();
	if (!gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_258.f_13, 14)) {
		func_221();
	}
}

// Position - 0x7FA1
void func_221() { Global_2501682.f_80 = 1; }

// Position - 0x7FB0
void func_222() {
	struct<2> Var0;

	Global_2433125.f_731 = 0;
	Global_2433125.f_732 = 0;
	Global_2433125.f_733 = {9999.9f, 9999.9f, 9999.9f};
	Global_2404994.f_2220 = {Var0};
}

// Position - 0x7FED
Vector3 func_223(int iParam0) {
	if (iParam0 <= 5) {
		return 0.11f, -1.08f, 0f;
	}
	if (iParam0 <= 13) {
		return 0.11f, -0.81f, 0f;
	}
	if (iParam0 != 19) {
		return 0.03f, -0.75f, 0f;
	}
	return 0.1f, -0.55f, 0f;
}

// Position - 0x804A
void func_224(var *uParam0, var uParam1) { uParam0->f_14 = uParam1; }

// Position - 0x8058
void func_225(var *uParam0, var *uParam1, var *uParam2, int iParam3) {
	float fVar0;
	int iVar1;
	int iVar2;
	float fVar3;
	float fVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	fVar0 = func_36(uParam2);
	fVar3 = -9999f;
	fVar4 = -1f;
	if (func_171(uParam1, uParam2) || func_238()) {
		if (func_236(uParam1, uParam2, 0)) {
			func_234(uParam2, 7);
		}
		else if (fVar0 < 5f) {
			func_234(uParam2, 4);
		}
		else if (fVar0 < 9.5f) {
			func_234(uParam2, 5);
		}
		else {
			func_234(uParam2, 6);
		}
		func_232(uParam2, func_135(uParam0, 19));
		if (func_140(uParam2) != -1) {
			return;
		}
	}
	else if (func_231(uParam2)) {
		func_234(uParam2, 0);
		func_232(uParam2, func_135(uParam0, 16));
		if (func_140(uParam2) != -1) {
			return;
		}
	}
	else if (func_230(uParam1, uParam2, iParam3)) {
		func_234(uParam2, 3);
	}
	else {
		func_234(uParam2, 0);
	}
	func_227(uParam1, uParam2, &iVar5, &iVar6, 0);
	fVar4 = func_200(uParam0, func_135(uParam0, iVar6));
	if (func_136(uParam2) == 3 || func_136(uParam2) == 2) {
		fVar4 *= func_226();
	}
	if (fVar4 > fVar0) {
		func_232(uParam2, func_135(uParam0, iVar6));
		return;
	}
	iVar2 = -1;
	iVar1 = 0;
	while (iVar1 < *uParam0) {
		iVar7 = func_122(uParam0, iVar1);
		if (iVar7 >= iVar5 && iVar7 <= iVar6) {
			fVar4 = func_200(uParam0, iVar1);
			if (func_136(uParam2) == 3 || func_136(uParam2) == 2) {
				fVar4 *= func_226();
			}
			if ((*uParam0)[iVar1] >= 14) {
				fVar4 *= 0.75f;
			}
			if (func_258(uParam1, uParam2)) {
				if (func_307(uParam2) == 2) {
					fVar4 *= 1.1f;
				}
				else if (func_307(uParam2) == 3) {
					fVar4 *= 2.25f;
				}
			}
			fVar4 -= fVar0;
			if (fVar4 < 0f && fVar4 > fVar3) {
				iVar2 = iVar1;
				fVar3 = fVar4;
			}
		}
		iVar1++;
	}
	if (iVar2 != -1) {
		func_232(uParam2, iVar2);
		return;
	}
	func_232(uParam2, func_135(uParam0, iVar5));
}

// Position - 0x8275
float func_226() { return 0.935f; }

// Position - 0x8282
void func_227(var *uParam0, var *uParam1, int *iParam2, int *iParam3, int iParam4) {
	if (func_171(uParam0, uParam1)) {
		*iParam2 = 14;
		*iParam3 = 19;
	}
	else if (func_231(uParam1)) {
		*iParam2 = 7;
		*iParam3 = 17;
	}
	else if (func_230(uParam0, uParam1, 1)) {
		*iParam2 = 7;
		if (iParam4) {
			*iParam3 = 19;
		}
		else {
			*iParam3 = 17;
		}
	}
	else if (func_229(uParam1)) {
		*iParam2 = 7;
		*iParam3 = 17;
	}
	else if (func_258(uParam0, uParam1)) {
		*iParam2 = 1;
		*iParam3 = 17;
	}
	else if (func_228(uParam1)) {
		*iParam2 = 3;
		*iParam3 = 17;
	}
	else {
		*iParam2 = 7;
		*iParam3 = 17;
	}
}

// Position - 0x8326
bool func_228(var *uParam0) {
	if (func_35(uParam0) != 2) {
		return false;
	}
	return true;
}

// Position - 0x833D
bool func_229(var *uParam0) {
	if (func_35(uParam0) != 4) {
		return false;
	}
	return true;
}

// Position - 0x8354
bool func_230(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	vector3 vVar1;

	if (func_264(uParam1) < 0) {
		return false;
	}
	iVar0 = func_244(uParam1);
	if (iParam2) {
		if (!entity::does_entity_exist(iVar0)) {
			return false;
		}
		vVar1 = {entity::get_entity_coords(func_244(uParam1), 0)};
	}
	else {
		vVar1 = {func_19(uParam1)};
	}
	if (system::vdist2(vVar1, func_41(uParam0, func_307(uParam1))) > 55f * 55f) {
		return false;
	}
	return true;
}

// Position - 0x83C9
bool func_231(var *uParam0) {
	if (func_35(uParam0) != 0) {
		return false;
	}
	return true;
}

// Position - 0x83E0
void func_232(var *uParam0, int iParam1) { func_233(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x83F8
void func_233(var *uParam0, var uParam1) { uParam0->f_17 = uParam1; }

// Position - 0x8406
void func_234(var *uParam0, int iParam1) { func_235(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x841E
void func_235(var *uParam0, var uParam1) { uParam0->f_19 = uParam1; }

// Position - 0x842C
bool func_236(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;

	if (!func_171(uParam0, uParam1)) {
		return false;
	}
	vVar0 = {func_19(uParam1)};
	if (iParam2) {
		if (entity::does_entity_exist(func_244(uParam1))) {
			vVar0 = {entity::get_entity_coords(func_244(uParam1), 1)};
		}
	}
	if (system::vdist2(vVar0, func_41(uParam0, func_307(uParam1))) > 0.7f * 0.7f) {
		return false;
	}
	return true;
}

// Position - 0x8497
void func_237(var *uParam0, vector3 vParam1) { func_48(&uParam0->f_15[uParam0->f_157 /*34*/], vParam1); }

// Position - 0x84B1
int func_238() { return 0; }

// Position - 0x84BA
void func_239(var *uParam0, int iParam1) { func_240(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x84D2
void func_240(var *uParam0, var uParam1) { uParam0->f_3 = uParam1; }

// Position - 0x84E0
int func_241(vector3 vParam0, float fParam3) {
	int iVar0;

	if (func_130(vParam0, 0f, 0f, 0f, 1056964608, 0)) {
		return 0;
	}
	iVar0 = object::create_object(joaat("prop_golf_ball"), vParam0, 1, 1, 0);
	object::_0xC6033D32241F6FB5(iVar0, 1);
	entity::_set_entity_register(iVar0, 0);
	entity::set_entity_heading(iVar0, fParam3);
	if (bLocal_0) {
	}
	return iVar0;
}

// Position - 0x852F
float func_242(struct<2> Param0, Vector3 vParam2, struct<2> Param3, var uParam5) {
	return gameplay::get_heading_from_vector_2d(Param3 - Param0, Param3.f_1 - Param0.f_1);
}

// Position - 0x8549
Vector3 func_243(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0: return -1252.974f, 182.4325f, 61.3071f;

	case 1: return -1222.204f, 150.2919f, 58.7062f;

	case 2: return -1240.082f, 105.7823f, 55.6871f;

	case 3: return -1132.487f, 74.15947f, 55.23262f;

	case 4: return -1022.111f, -34.77494f, 44.37743f;

	case 5: return -1100.057f, -114.277f, 40.5368f;

	case 6: return -1225.207f, -54.2714f, 44.1932f;

	case 7: return -1159.322f, -26.5465f, 44.7971f;

	case 8: return -1177.194f, 34.219f, 50.8363f;
	}
	return 0f, 0f, 0f;
}

// Position - 0x8668
int func_244(var *uParam0) { return func_245(&uParam0->f_15[uParam0->f_157 /*34*/]); }

// Position - 0x867E
var func_245(var *uParam0) { return uParam0->f_3; }

// Position - 0x868A
int func_246(var *uParam0, int iParam1, int iParam2) {
	if (func_37(&uParam0->f_15[iParam1 /*34*/]) > func_37(&uParam0->f_15[iParam2 /*34*/])) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x86B5
int func_247(var *uParam0) { return func_266(uParam0, func_264(uParam0)); }

// Position - 0x86C9
void func_248(var *uParam0, int iParam1, var *uParam2, int iParam3, int iParam4) {
	float *fVar0;
	float fVar1;
	int iVar2;
	int iVar3;
	vector3 vVar4;
	vector3 vVar7;
	bool bVar10;
	int iVar11;
	int iVar12;

	iVar2 = func_278(uParam0, func_250(uParam0, iParam1));
	vVar4 = {func_259(uParam0, iParam1)};
	vVar7 = {0f, 0f, 0f};
	if (entity::is_entity_dead(iVar2, 0)) {
		return;
	}
	if (entity::is_entity_dead(func_268(uParam0, iParam1), 0)) {
		func_271(uParam0, 2);
		return;
	}
	fVar1 = 144f;
	bVar10 = system::vdist2(entity::get_entity_coords(func_288(uParam0, func_266(uParam0, iParam1)), 1),
							uParam0->f_15[iParam1 /*34*/].f_10) < fVar1;
	if (!ped::is_ped_in_vehicle(iVar2, func_268(uParam0, iParam1), 0) && !bVar10) {
		if (ai::get_script_task_status(iVar2, -1794415470) != 1) {
			ai::task_enter_vehicle(iVar2, func_268(uParam0, iParam1), -1, -1, 1f, 1, 0);
		}
		return;
	}
	iVar11 = 786603;
	if (iParam4) {
		iVar11 = 17;
	}
	if (entity::does_entity_exist(iVar2) && !entity::is_entity_dead(iVar2, 0) &&
		ai::get_script_task_status(iVar2, -1817882002) != 1 && !func_40(&uParam0->f_15[iParam1 /*34*/], 33554432)) {
		if (func_266(uParam0, iParam1) == 1 && !func_261(uParam0, -1)) {
			if (func_258(uParam2, uParam0) && func_307(uParam0) == 0) {
				vVar7 = {-3f, -3f, 0f};
			}
			else {
				vVar7 = {3f, 3f, 0f};
			}
		}
		func_3(vVar4 + vVar7, func_41(uParam2, func_307(uParam0)), &uParam0->f_15[iParam1 /*34*/].f_10, &fVar0, 0f, 0f,
			   0f, 0f, 0f, 0f, 0);
		ai::task_vehicle_drive_to_coord(func_278(uParam0, func_250(uParam0, iParam1)), func_268(uParam0, iParam1),
										uParam0->f_15[iParam1 /*34*/].f_10, 4f, 0, 0, iVar11, 4f, -1f);
	}
	if (bVar10) {
		ai::clear_ped_tasks(func_278(uParam0, func_250(uParam0, iParam1)));
		func_57(&uParam0->f_15[iParam1 /*34*/], 33554432);
		if (!func_261(uParam0, -1)) {
			ai::task_everyone_leave_vehicle(func_268(uParam0, iParam1));
			iVar12 = 1;
			func_20(uParam0, uParam2, func_266(uParam0, iParam1), 0, 35882 /*func_260*/, 44724 /*func_321*/);
			iVar3 = 0;
			while (iVar3 < func_314(uParam0)) {
				if (entity::does_entity_exist(func_278(uParam0, iVar3)) &&
					!entity::is_entity_dead(func_278(uParam0, iVar3), 0)) {
					if (ped::is_ped_in_any_vehicle(func_278(uParam0, iVar3), 0)) {
						iVar12 = 0;
					}
				}
				iVar3++;
			}
			if (iVar12 && iParam3) {
				func_271(uParam0, 2);
			}
		}
		else if (system::vdist2(func_259(uParam0, iParam1), func_41(uParam2, func_307(uParam0))) < 1600f &&
				 system::vdist2(entity::get_entity_coords(func_268(uParam0, iParam1), 1),
								func_41(uParam2, func_307(uParam0))) < 1600f &&
				 !func_292(uParam0, iParam1, 67108864)) {
			func_20(uParam0, uParam2, func_266(uParam0, iParam1), 1, 37615 /*func_262*/, 7472);
			if (iParam3) {
				func_271(uParam0, 2);
			}
		}
		else if (ped::is_ped_in_any_vehicle(func_278(uParam0, iParam1), 0)) {
			ai::task_vehicle_park(func_278(uParam0, func_250(uParam0, iParam1)), func_268(uParam0, iParam1),
								  entity::get_entity_coords(func_268(uParam0, iParam1), 1), 0f, 3, 360f, 0);
			if (iParam3) {
				ai::task_leave_any_vehicle(func_278(uParam0, iParam1), 0, 0);
				func_271(uParam0, 2);
				func_249(uParam0, iParam1, 1);
			}
		}
		else if (iParam3) {
			func_271(uParam0, 2);
			func_249(uParam0, iParam1, 1);
		}
	}
}

// Position - 0x8A37
void func_249(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_17(&uParam0->f_15[iParam1 /*34*/], iParam2, 0);
}

// Position - 0x8A65
int func_250(var *uParam0, int iParam1) { return func_265(uParam0, func_266(uParam0, iParam1)); }

// Position - 0x8A7B
bool func_251(var *uParam0, float fParam1) {
	if (func_96(uParam0)) {
		if (func_252(uParam0) > fParam1) {
			return true;
		}
	}
	return false;
}

// Position - 0x8A9D
float func_252(var *uParam0) {
	if (func_96(uParam0)) {
		if (func_253(uParam0)) {
			return uParam0->f_2;
		}
		else {
			return func_190(gameplay::is_bit_set(*uParam0, 4)) - uParam0->f_1;
		}
	}
	return uParam0->f_1;
}

// Position - 0x8ADC
bool func_253(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0x8AEC
void func_254(var *uParam0) {
	if (!func_96(uParam0)) {
		func_188(uParam0);
	}
}

// Position - 0x8B04
void func_255(var *uParam0, int iParam1) { uParam0->f_22 -= (uParam0->f_22 & iParam1); }

// Position - 0x8B1C
bool func_256(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if (iVar0 >= iParam1) {
			if (!entity::is_entity_dead(func_278(uParam0, iVar0), 0) &&
				!entity::is_entity_dead(func_268(uParam0, iVar0), 0)) {
				if (!ped::is_ped_in_vehicle(func_278(uParam0, iVar0), func_268(uParam0, iVar0), 0) &&
					!func_292(uParam0, iVar0, 16777216) && !func_292(uParam0, iVar0, 67108864)) {
					return false;
				}
			}
		}
		iVar0++;
	}
	return true;
}

// Position - 0x8BAA
void func_257(var *uParam0, int iParam1) { func_17(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1, 0); }

// Position - 0x8BC3
bool func_258(var *uParam0, var *uParam1) {
	if (func_307(uParam1) < 0 || func_307(uParam1) >= func_53(uParam0)) {
		return false;
	}
	if (func_35(uParam1) != 5) {
		return false;
	}
	return true;
}

// Position - 0x8BFC
Vector3 func_259(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0f, 0f, 0f;
	}
	return func_272(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x8C2A
Vector3 func_260(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0:
		switch (iParam2) {
		case 0: return -1369.208f, 166.1965f, 57.013f;

		case 1: return -1367.259f, 166.6778f, 57.013f;

		case 2: return -1370.803f, 167.6664f, 57.013f;

		case 3: return -1371.507f, 169.5609f, 57.013f;

		case 4: return -1370.846f, 164.1834f, 56.89f;

		case 5: return -1367.902f, 164.2965f, 56.869f;
		}
		break;

	case 1:
		switch (iParam2) {
		case 0: return -1101.049f, 156.1904f, 62.0401f;

		case 1: return -1100.905f, 159.2561f, 62.0415f;

		case 2: return -1102.783f, 161.6288f, 62.0412f;

		case 3: return -1105.964f, 161.2863f, 62.0406f;

		case 4: return -1104.451f, 163.5161f, 62.0095f;

		case 5: return -1099.934f, 161.6773f, 62.0185f;
		}
		break;

	case 2:
		switch (iParam2) {
		case 0: return -1317.028f, 128.0565f, 56.4377f;

		case 1: return -1315.436f, 129.9425f, 56.6243f;

		case 2: return -1313.452f, 131.9924f, 56.8265f;

		case 3: return -1317.249f, 133.3213f, 56.705f;

		case 4: return -1318.786f, 131.5965f, 56.4503f;

		case 5: return -1320.138f, 129.2562f, 56.324f;
		}
		break;

	case 3:
		switch (iParam2) {
		case 0: return -1218.894f, 110.6482f, 57.08f;

		case 1: return -1222.243f, 110.2088f, 57.08f;

		case 2: return -1220f, 111.91f, 58.0703f;

		case 3: return -1221.256f, 101.3278f, 57.08f;

		case 4: return -1223.297f, 103.1185f, 56.813f;

		case 5: return -1216.389f, 115.3967f, 57.1354f;
		}
		break;

	case 4:
		switch (iParam2) {
		case 0: return -1104.607f, 70.6124f, 53.212f;

		case 1: return -1101.698f, 73.7137f, 53.1993f;

		case 2: return -1103.9f, 72.917f, 54.3f;

		case 3: return -1100.425f, 75.0875f, 54.3712f;

		case 4: return -1108.588f, 72.7163f, 53.4783f;

		case 5: return -1107.175f, 68.8603f, 53.2257f;
		}
		break;

	case 5:
		switch (iParam2) {
		case 0: return -984.8632f, -108.5439f, 39.5642f;

		case 1: return -982.4098f, -106.4736f, 39.5732f;

		case 2: return -981.2261f, -103.0422f, 39.5779f;

		case 3: return -981.8594f, -100.6231f, 39.5813f;

		case 4: return -978.5359f, -100.5075f, 39.5193f;

		case 5: return -981.4874f, -109.4747f, 39.2195f;
		}
		break;

	case 6:
		switch (iParam2) {
		case 0: return -1113.865f, -100.3123f, 40.905f;

		case 1: return -1111.559f, -104.7822f, 40.8405f;

		case 2: return -1113.281f, -107.0443f, 40.8405f;

		case 3: return -1116.94f, -109.7583f, 40.8608f;

		case 4: return -1110.02f, -108.1524f, 40.7427f;

		case 5: return -1112.815f, -103.1259f, 40.8406f;
		}
		break;

	case 7:
		switch (iParam2) {
		case 0: return -1277.277f, 36.1405f, 48.9194f;

		case 1: return -1277.344f, 39.2424f, 49.1028f;

		case 2: return -1275.593f, 41.3619f, 49.0876f;

		case 3: return -1271.244f, 43.9149f, 48.9679f;

		case 4: return -1279.021f, 42.0418f, 49.3157f;

		case 5: return -1281.184f, 37.6356f, 49.3165f;
		}
		break;

	case 8:
		switch (iParam2) {
		case 0: return -1138.589f, -5.6756f, 47.9822f;

		case 1: return -1136.48f, -5.8462f, 47.9822f;

		case 2: return -1134.645f, -4.3631f, 47.9822f;

		case 3: return -1133.712f, -2.4897f, 47.9822f;

		case 4: return -1133.803f, -7.843f, 47.9822f;

		case 5: return -1137.603f, -9.0347f, 47.8107f;
		}
		break;
	}
	return 0f, 0f, 0f;
}

// Position - 0x9298
int func_261(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if (iParam1 < 0 || iParam1 != iVar0) {
			if (func_33(&uParam0->f_15[iVar0 /*34*/]) < 1 && func_21(uParam0, iVar0) != 10) {
				return 0;
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x92EF
Vector3 func_262(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	switch (iParam1) {
	case 0:
		switch (iParam2) {
		case 0: return -1121.482f, 210.4423f, 63.9292f;

		case 1: return -1111.883f, 211.2035f, 63.844f;

		case 2: return -1109.581f, 220.781f, 63.9314f;

		case 3: return -1117.733f, 231.4756f, 64.5959f;

		case 4: return -1124.819f, 232.4564f, 65.106f;

		case 5: return -1114.602f, 228.6924f, 64.1294f;

		case 6: return -1124.336f, 220.1641f, 64.0189f;
		}
		break;

	case 1:
		switch (iParam2) {
		case 0: return -1324.647f, 150.2405f, 56.9512f;

		case 1: return -1332.147f, 152.7218f, 56.9449f;

		case 2: return -1340.339f, 165.985f, 57.0015f;

		case 3: return -1330.341f, 172.5728f, 57.0822f;

		case 4: return -1325.275f, 173.1006f, 57.1633f;

		case 5: return -1337.177f, 158.5159f, 56.9107f;

		case 6: return -1320.53f, 169.4781f, 56.8531f;
		}
		break;

	case 2:
		switch (iParam2) {
		case 0: return -1230.481f, 103.0481f, 55.7491f;

		case 1: return -1234.842f, 95.7965f, 55.6671f;

		case 2: return -1243.458f, 95.5196f, 55.5717f;

		case 3: return -1245.146f, 112.5895f, 55.9974f;

		case 4: return -1239.073f, 119.9953f, 56.4275f;

		case 5: return -1232.428f, 116.2665f, 56.6504f;

		case 6: return -1235.999f, 119.75f, 56.425f;
		}
		break;

	case 3:
		switch (iParam2) {
		case 0: return -1101.042f, 27.2703f, 50.1697f;

		case 1: return -1094.131f, 23.785f, 50.087f;

		case 2: return -1087.636f, 20.9966f, 50.0321f;

		case 3: return -1080.524f, 13.8964f, 49.734f;

		case 4: return -1086.105f, 4.0804f, 49.7967f;

		case 5: return -1097.654f, -1.5694f, 50.0125f;

		case 6: return -1108.614f, -4.9012f, 49.6852f;
		}
		break;

	case 4:
		switch (iParam2) {
		case 0: return -949.3773f, -93.7449f, 39.525f;

		case 1: return -965.4772f, -92.9853f, 39.3605f;

		case 2: return -965.3192f, -101.431f, 39.4042f;

		case 3: return -952.4808f, -99.1808f, 39.5487f;

		case 4: return -958.345f, -103.7673f, 39.334f;

		case 5: return -949.268f, -87.9874f, 39.3694f;

		case 6: return -951.558f, -85.9542f, 39.2469f;
		}
		break;

	case 5:
		switch (iParam2) {
		case 0: return -1098.276f, -107.6579f, 40.5369f;

		case 1: return -1106.573f, -106.9375f, 40.696f;

		case 2: return -1111.654f, -121.3032f, 40.7039f;

		case 3: return -1102.013f, -127.7622f, 40.69f;

		case 4: return -1092.945f, -115.8245f, 40.5376f;

		case 5: return -1094.257f, -122.7798f, 40.552f;

		case 6: return -1092.991f, -118.4603f, 40.5422f;
		}
		break;

	case 6:
		switch (iParam2) {
		case 0: return -1294.887f, 10.1593f, 50.3758f;

		case 1: return -1288.871f, 14.8418f, 49.8751f;

		case 2: return -1276.27f, 11.8301f, 48.5562f;

		case 3: return -1283.162f, -6.8256f, 48.6238f;

		case 4: return -1275.606f, -2.029f, 48.0408f;

		case 5: return -1273.712f, 5.2094f, 48.184f;

		case 6: return -1293.384f, 0.3131f, 49.4842f;
		}
		break;

	case 7:
		switch (iParam2) {
		case 0: return -1041.685f, -75.4766f, 43.0439f;

		case 1: return -1030.31f, -76.6724f, 43.2806f;

		case 2: return -1029.791f, -88.4011f, 43.1511f;

		case 3: return -1041.575f, -92.4546f, 42.8253f;

		case 4: return -1050.466f, -93.7612f, 42.5099f;

		case 5: return -1050.863f, -84.3568f, 42.5056f;

		case 6: return -1048.343f, -82.4877f, 42.5625f;
		}
		break;

	case 8:
		switch (iParam2) {
		case 0: return -1284.551f, 76.0288f, 53.9062f;

		case 1: return -1282.676f, 86.4323f, 53.9098f;

		case 2: return -1299.27f, 80.8423f, 53.911f;

		case 3: return -1299.105f, 87.1486f, 53.9145f;

		case 4: return -1290.099f, 74.7491f, 53.9426f;

		case 5: return -1292.312f, 90.6955f, 53.9123f;

		case 6: return -1291.197f, 89.2305f, 53.9061f;
		}
		break;
	}
	return 0f, 0f, 0f;
}

// Position - 0x9A50
bool func_263(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	vector3 vVar1;

	iVar0 = func_245(&uParam1->f_15[iParam2 /*34*/]);
	if (!entity::does_entity_exist(iVar0)) {
		return false;
	}
	vVar1 = {entity::get_entity_coords(func_245(&uParam1->f_15[iParam2 /*34*/]), 0)};
	if (system::vdist2(vVar1, func_41(uParam0, func_307(uParam1))) > 55f * 55f) {
		return false;
	}
	return true;
}

// Position - 0x9AB1
int func_264(var *uParam0) { return uParam0->f_157; }

// Position - 0x9ABD
int func_265(var *uParam0, int iParam1) { return uParam0->f_167[iParam1]; }

// Position - 0x9ACD
int func_266(var *uParam0, int iParam1) { return uParam0->f_15[iParam1 /*34*/].f_31; }

// Position - 0x9ADF
float func_267(int iParam0, int iParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;

	if (!entity::is_entity_dead(iParam0, 0)) {
		vVar0 = {entity::get_entity_coords(iParam0, 1)};
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam0, 0)};
	}
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar3 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		vVar3 = {entity::get_entity_coords(iParam1, 0)};
	}
	return gameplay::get_distance_between_coords(vVar0, vVar3, iParam2);
}

// Position - 0x9B3D
int func_268(var *uParam0, int iParam1) { return func_288(uParam0, func_266(uParam0, iParam1)); }

// Position - 0x9B53
bool func_269(var *uParam0, int iParam1) { return func_40(&uParam0->f_15[uParam0->f_157 /*34*/], iParam1); }

// Position - 0x9B6B
int func_270(var *uParam0) { return *uParam0; }

// Position - 0x9B76
void func_271(var *uParam0, int iParam1) { *uParam0 = iParam1; }

// Position - 0x9B83
Vector3 func_272(var *uParam0) { return uParam0->f_7; }

// Position - 0x9B91
bool func_273(var *uParam0, int iParam1) { return (uParam0->f_22 & iParam1) != 0; }

// Position - 0x9BA2
void func_274(var *uParam0, var *uParam1, int iParam2) {
	func_60(uParam1, uParam0);
	func_51(uParam0, 0);
	func_54(uParam0, iParam2);
	func_44(uParam1, uParam0);
	func_2(uParam0, uParam1, 1);
	func_271(uParam0, 2);
}

// Position - 0x9BD9
int func_275(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (func_307(&(*uParam0)[iVar0 /*170*/]) == iParam1) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x9C09
int func_276(int iParam0) {
	switch (iParam0) {
	case 0: return 2;

	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 2;

	case 8: return 2;
	}
	return 2;
}

// Position - 0x9C8E
void func_277(var *uParam0, var *uParam1, var *uParam2) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_53(uParam1)) {
		if (!func_275(uParam2, iVar0)) {
			func_274(uParam0, uParam1, iVar0);
			return;
		}
		iVar0++;
	}
}

// Position - 0x9CC6
int func_278(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_293(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0x9CF2
void func_279(var *uParam0, int iParam1, int iParam2) { uParam0->f_152[iParam2] = iParam1; }

// Position - 0x9D04
bool func_280(int iParam0, int iParam1, var *uParam2, int *iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8) {
	int iVar0;
	bool bVar1;

	iVar0 = player::player_ped_id();
	if (!entity::is_entity_dead(iVar0, 0) && !entity::is_entity_dead(iParam0, 0)) {
		if (!func_287(*uParam2, 1)) {
			if (func_286(iParam0, uParam2)) {
				*iParam3 = 1;
				return true;
			}
		}
		if (!func_287(*uParam2, 2)) {
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				*iParam3 = 2;
				return true;
			}
		}
		if (!func_287(*uParam2, 4)) {
			if (func_284(iVar0, iParam0, uParam2, iParam5)) {
				*iParam3 = 4;
				return true;
			}
		}
		if (!func_287(*uParam2, 8)) {
			if (func_283(iVar0, iParam0, uParam2)) {
				*iParam3 = 8;
				return true;
			}
		}
		bVar1 = !func_287(*uParam2, 128);
		if (iParam4) {
			if (func_281(iParam0, iParam1, 1, iParam6, bVar1, 1)) {
				*iParam3 = 32;
				return true;
			}
		}
		else if (!func_287(*uParam2, 16)) {
			if (func_281(iParam0, iParam1, 0, iParam6, bVar1, iParam8)) {
				*iParam3 = 16;
				return true;
			}
		}
	}
	else if (entity::does_entity_exist(iParam0)) {
		if (iParam7 && entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
			*iParam3 = 16;
			return true;
		}
	}
	return false;
}

// Position - 0x9E2E
bool func_281(int iParam0, int iParam1, int iParam2, bool bParam3, bool bParam4, int iParam5) {
	int iVar0;
	int iVar1;

	if (bParam3) {
		if (!bLocal_254) {
			iLocal_255 = entity::get_entity_health(iParam0);
			bLocal_254 = true;
		}
		iLocal_256 = entity::get_entity_health(iParam0);
		iLocal_257 = iLocal_255 - iLocal_256;
		iVar0 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar0, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar0, 1)) {
				if (IntToFloat(iLocal_257) > 100f) {
					return true;
				}
			}
		}
		if (bLocal_254) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
				if (IntToFloat(iLocal_257) > 100f) {
					return true;
				}
			}
		}
	}
	else if (entity::has_entity_been_damaged_by_entity(iParam0, player::player_ped_id(), 1)) {
		return true;
	}
	if (!bParam3) {
		iVar1 = player::get_players_last_vehicle();
		if (!entity::is_entity_dead(iVar1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam0, iVar1, 1)) {
				return true;
			}
		}
	}
	if (bParam4) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			if (ped::is_ped_being_jacked(iParam0)) {
				if (ped::get_peds_jacker(iParam0) == player::player_ped_id()) {
					return true;
				}
			}
		}
	}
	if (iParam5) {
		if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
			if (entity::is_entity_at_coord(iParam0, entity::get_entity_coords(player::player_ped_id(), 1), 10f, 10f,
										   10f, 0, 1, 0)) {
				if (player::has_player_damaged_at_least_one_ped(player::player_id())) {
					return true;
				}
			}
		}
	}
	if (ped::is_ped_performing_stealth_kill(player::player_ped_id())) {
		if (ped::was_ped_killed_by_stealth(iParam0)) {
			return true;
		}
	}
	if (func_282(player::player_ped_id(), iParam0)) {
		return true;
	}
	if (iParam2) {
		if (ped::is_ped_ragdoll(iParam0) && func_289(iParam0, 1) < 1.5f) {
			return true;
		}
		else if (ped::is_ped_in_any_vehicle(iParam0, 0)) {
			if (entity::is_entity_touching_entity(player::player_ped_id(), ped::get_vehicle_ped_is_in(iParam0, 0))) {
				return true;
			}
		}
		else if (entity::is_entity_touching_entity(player::player_ped_id(), iParam0)) {
			return true;
		}
		if (!entity::is_entity_dead(iParam1, 0)) {
			if (entity::has_entity_been_damaged_by_entity(iParam1, player::player_ped_id(), 1)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x9FFB
bool func_282(int iParam0, int iParam1) {
	int iVar0;

	weapon::get_current_ped_weapon(iParam0, &iVar0, 1);
	if (iVar0 == joaat("weapon_petrolcan")) {
		if (ped::is_ped_shooting(iParam0)) {
			if (system::vdist(entity::get_entity_coords(iParam0, 1), entity::get_entity_coords(iParam1, 1)) < 2.5f) {
				if (ped::is_ped_facing_ped(iParam0, iParam1, 180f)) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0xA050
bool func_283(int iParam0, int iParam1, var *uParam2) {
	if (weapon::is_ped_armed(iParam0, 4)) {
		if (ped::is_ped_shooting(iParam0) && !weapon::is_ped_current_weapon_silenced(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_4),
										   IntToFloat(uParam2->f_4), IntToFloat(uParam2->f_4), 0, 1, 0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0xA09E
bool func_284(int iParam0, int iParam1, var *uParam2, bool bParam3) {
	vector3 vVar0;
	int iVar3;

	iVar3 = 0;
	if (!entity::is_entity_dead(iParam1, 0)) {
		vVar0 = {entity::get_entity_coords(iParam1, 1)};
	}
	if (gameplay::is_bullet_in_area(vVar0, 4f, 1)) {
		return true;
	}
	if (gameplay::has_bullet_impacted_in_area(vVar0, system::to_float(uParam2->f_6), 1, 1)) {
		return true;
	}
	if (weapon::is_ped_armed(iParam0, 2)) {
		if (ped::is_ped_shooting(iParam0)) {
			if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1), IntToFloat(uParam2->f_6 * 3),
										   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
				if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
					entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
					return true;
				}
			}
		}
		else {
			if (ped::is_ped_in_any_vehicle(entity::get_ped_index_from_entity_index(iParam1), 0)) {
				iVar3 = ped::get_vehicle_ped_is_in(entity::get_ped_index_from_entity_index(iParam1), 0);
			}
			if (ped::is_ped_planting_bomb(iParam0) || func_285(iVar3)) {
				if (entity::is_entity_at_coord(iParam1, entity::get_entity_coords(iParam0, 1),
											   IntToFloat(uParam2->f_6 * 3), IntToFloat(uParam2->f_6 * 3),
											   IntToFloat(uParam2->f_6 * 3), 0, 1, 0)) {
					if (ped::is_ped_facing_ped(entity::get_ped_index_from_entity_index(iParam1), iParam0, 120f) &&
						entity::has_entity_clear_los_to_entity(iParam1, iParam0, 17)) {
						return true;
					}
				}
			}
		}
	}
	if (bParam3) {
		if (gameplay::is_projectile_in_area(vVar0.x - IntToFloat(uParam2->f_6), vVar0.y - IntToFloat(uParam2->f_6),
											vVar0.z - IntToFloat(uParam2->f_6), vVar0.x + IntToFloat(uParam2->f_6),
											vVar0.y + IntToFloat(uParam2->f_6), vVar0.z + IntToFloat(uParam2->f_6),
											0)) {
			return true;
		}
	}
	return false;
}

// Position - 0xA217
int func_285(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0) != 0) {
				if (weapon::get_current_ped_weapon(player::player_ped_id(), &iVar0, 1)) {
					if (iVar0 == joaat("weapon_stickybomb")) {
						if (func_267(player::player_ped_id(), iParam0, 1) < 40f) {
							if (player::get_entity_player_is_free_aiming_at(player::player_id(), &iVar1)) {
								if (entity::is_entity_a_vehicle(iVar1) &&
										entity::get_vehicle_index_from_entity_index(iVar1) == iParam0 ||
									entity::is_entity_a_ped(iVar1) &&
										entity::get_ped_index_from_entity_index(iVar1) ==
											vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0)) {
									if (ped::is_ped_on_foot(player::player_ped_id()) &&
											controls::is_control_pressed(0, 24) ||
										ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
											controls::is_control_pressed(0, 69)) {
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0xA2E5
bool func_286(int iParam0, var *uParam1) {
	if (!entity::is_entity_dead(iParam0, 0)) {
		if (weapon::is_ped_armed(player::player_ped_id(), 6)) {
			if (player::is_player_free_aiming_at_entity(player::player_id(), iParam0) ||
				player::is_player_targetting_entity(player::player_id(), iParam0)) {
				if (ped::is_ped_facing_ped(iParam0, player::player_ped_id(), 90f)) {
					if (func_289(iParam0, 1) < uParam1->f_2) {
						if (uParam1->f_1 == 0) {
							uParam1->f_1 = gameplay::get_game_timer();
						}
						else if (gameplay::get_game_timer() - uParam1->f_1 > uParam1->f_3) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

// Position - 0xA36A
bool func_287(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0xA379
int func_288(var *uParam0, int iParam1) { return uParam0->f_152[iParam1]; }

// Position - 0xA389
float func_289(int iParam0, int iParam1) {
	return func_267(player::get_player_ped(player::get_player_index()), iParam0, iParam1);
}

// Position - 0xA3A1
void func_290(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		func_61(uParam0, iVar0);
		func_38(&uParam0->f_15[iVar0 /*34*/]);
		func_291(&uParam0->f_15[iVar0 /*34*/]);
		if (entity::does_entity_exist(uParam0->f_15[iVar0 /*34*/].f_2) &&
			!entity::is_entity_dead(uParam0->f_15[iVar0 /*34*/].f_2, 0)) {
			ai::clear_ped_tasks(uParam0->f_15[iVar0 /*34*/].f_2);
		}
		func_295(uParam0, iVar0);
		iVar0++;
	}
	func_54(uParam0, -2);
}

// Position - 0xA425
void func_291(var *uParam0) {
	if (entity::does_entity_exist(uParam0->f_5)) {
		entity::set_object_as_no_longer_needed(&uParam0->f_5);
	}
}

// Position - 0xA440
bool func_292(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return false;
	}
	return func_40(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xA46E
int func_293(var *uParam0) { return uParam0->f_2; }

// Position - 0xA47A
void func_294(var *uParam0, int iParam1, var *uParam2, int iParam3, var *uParam4) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	var uVar9;
	vector3 vVar10;
	float fVar13;
	vector3 vVar14;
	vector3 vVar17;

	if (!entity::does_entity_exist(func_293(uParam0))) {
		return;
	}
	if (entity::is_entity_dead(func_293(uParam0), 0) || ped::is_ped_injured(func_293(uParam0))) {
		return;
	}
	if (!entity::does_entity_exist(iParam1)) {
		return;
	}
	if (ai::get_script_task_status(func_293(uParam0), -1794415470) == 1) {
		return;
	}
	vVar0 = {func_272(uParam0)};
	vVar3 = {entity::get_entity_coords(iParam1, 1)};
	vVar6 = {entity::get_entity_coords(func_293(uParam0), 1)};
	if (system::vdist2(vVar6, vVar3) > 150f * 150f && system::vdist2(vVar0, vVar3) > 150f * 150f) {
		if (!func_40(uParam0, 1048576)) {
			ped::set_ped_gravity(uParam0->f_2, 0);
			ped::set_ped_can_ragdoll(uParam0->f_2, 0);
		}
		func_57(uParam0, 1048576);
	}
	else {
		if (func_40(uParam0, 1048576)) {
			ped::set_ped_gravity(uParam0->f_2, 1);
			ped::set_ped_can_ragdoll(uParam0->f_2, 1);
		}
		func_255(uParam0, 1048576);
	}
	if (system::vdist2(vVar0, vVar3) > 150f * 150f) {
		func_57(uParam0, 262144);
		if (vVar0.z > 100f) {
			if (entity::does_entity_exist(uParam0->f_3)) {
				if (!entity::is_entity_dead(uParam0->f_3, 0)) {
					entity::set_entity_coords(uParam0->f_3, vVar0.x, vVar0.y, 50f, 1, 0, 0, 1);
				}
			}
		}
	}
	else {
		if (func_40(uParam0, 262144)) {
			if (entity::does_entity_exist(uParam0->f_3)) {
				if (!entity::is_entity_dead(uParam0->f_3, 0)) {
					vVar10 = {uParam0->f_7 + Vector(50f, 0f, 0f)};
					if (gameplay::get_ground_z_for_3d_coord(vVar10, &uVar9, 0)) {
						uParam0->f_7.f_2 = uVar9;
						entity::set_entity_coords(uParam0->f_3, uParam0->f_7, 1, 0, 0, 1);
					}
				}
			}
			if (func_22(uParam0) == 5) {
				func_17(uParam0, 6, 0);
			}
			func_255(uParam0, 262144);
		}
		if (func_40(uParam0, 524288) && func_261(uParam2, -1)) {
			fVar13 = system::vdist(vVar6, vVar0);
			vVar14 = {func_6(vVar0 - vVar6)};
			vVar17 = {vVar6 + vVar14 * FtoV(fVar13) * FtoV(0.5f)};
			func_42(uParam2, iParam3, vVar17, uParam4, 1, 1);
			if (ai::get_script_task_status(func_293(uParam0), 1435919172) == 1) {
				ai::clear_ped_tasks(func_293(uParam0));
			}
		}
	}
	if (system::vdist2(vVar6, vVar3) > 150f * 150f) {
		func_57(uParam0, 524288);
		if (func_40(uParam0, 262144) && iParam3 == func_264(uParam2)) {
			if (ai::get_script_task_status(uParam0->f_2, 1435919172) == 1) {
				ai::clear_ped_tasks(uParam0->f_2);
			}
			func_271(uParam2, 2);
		}
	}
	else if (func_40(uParam0, 524288)) {
		if (func_40(uParam0, 262144) && func_261(uParam2, -1)) {
			func_191(uParam2, iParam3, uParam4, 1, 1);
			if (ai::get_script_task_status(uParam0->f_2, 1435919172) == 1) {
				ai::clear_ped_tasks(uParam0->f_2);
			}
			func_271(uParam2, 5);
			if (func_258(uParam4, uParam2)) {
				func_17(uParam0, 0, 0);
			}
			else {
				func_17(uParam0, 1, 0);
			}
		}
		else {
			func_261(uParam2, -1);
			if (gameplay::get_ground_z_for_3d_coord(vVar6, &uVar9, 0)) {
				vVar6.z = uVar9;
				entity::set_entity_coords(uParam0->f_2, vVar6, 1, 0, 0, 1);
			}
		}
		func_255(uParam0, 524288);
	}
}

// Position - 0xA7F1
void func_295(var *uParam0, int iParam1) {
	if (entity::does_entity_exist(func_278(uParam0, iParam1)) &&
		!entity::is_entity_dead(func_278(uParam0, iParam1), 0)) {
		if (!entity::has_entity_clear_los_to_entity(func_278(uParam0, iParam1), player::player_ped_id(), 17)) {
			ped::delete_ped(&uParam0->f_15[iParam1 /*34*/].f_2);
			return;
		}
		else if (!func_292(uParam0, iParam1, 16777216)) {
			ai::task_smart_flee_ped(func_278(uParam0, iParam1), player::player_ped_id(), 150f, -1, 0, 0);
		}
		if (ped::is_ped_in_melee_combat(func_278(uParam0, iParam1))) {
			ai::clear_ped_tasks(func_278(uParam0, iParam1));
			ai::task_smart_flee_ped(func_278(uParam0, iParam1), player::player_ped_id(), 150f, -1, 0, 0);
		}
	}
	func_56(uParam0, iParam1, 16777216);
}

// Position - 0xA8AE
bool func_296(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < func_314(uParam0)) {
		if (!func_292(uParam0, iVar0, 16777216)) {
			return false;
		}
		iVar0++;
	}
	return true;
}

// Position - 0xA8E3
void func_297(var *uParam0, var *uParam1) {
	vector3 vVar0;
	int iVar3;

	func_60(uParam1, uParam0);
	func_51(uParam0, 0);
	func_54(uParam0, 2);
	func_44(uParam1, uParam0);
	if (!ped::is_ped_injured(func_278(uParam0, 0))) {
		vVar0 = {-1238.818f, 109.3903f, 55.91227f};
		iVar3 = func_303(uParam0, 0);
		func_302(uParam0, 0, vVar0);
		if (entity::does_entity_exist(iVar3)) {
			object::delete_object(&iVar3);
		}
		func_301(uParam0, 0, func_241(vVar0, 0f));
		func_9(uParam0, 0, vVar0, 3, 0);
		func_300(uParam0, 0, 2);
		func_249(uParam0, 0, 1);
		func_299(uParam0, 0, 4);
		func_298(uParam0, 0, 4f);
		entity::set_entity_coords(func_278(uParam0, 0), -1241.802f, 107.3439f, 55.7186f, 1, 0, 0, 1);
		entity::set_entity_heading(func_278(uParam0, 0), 342.8433f);
	}
	if (!ped::is_ped_injured(func_278(uParam0, 1))) {
		vVar0 = {-1236.201f, 112.7829f, 56.23418f};
		iVar3 = func_303(uParam0, 1);
		ai::clear_ped_tasks_immediately(func_278(uParam0, 1));
		if (entity::does_entity_exist(iVar3)) {
			object::delete_object(&iVar3);
		}
		func_302(uParam0, 1, vVar0);
		func_301(uParam0, 1, func_241(vVar0, 0f));
		func_9(uParam0, 1, vVar0, 8, 0);
		func_300(uParam0, 1, 2);
		func_249(uParam0, 1, 10);
		entity::set_entity_coords(func_278(uParam0, 1), -1243.465f, 104.3183f, 55.5857f, 1, 0, 0, 1);
		entity::set_entity_heading(func_278(uParam0, 1), 306.093f);
	}
	if (entity::does_entity_exist(func_288(uParam0, 0)) && vehicle::is_vehicle_driveable(func_288(uParam0, 0), 0)) {
		entity::set_entity_coords(func_288(uParam0, 0), -1257.234f, 94.0251f, 54.784f, 0, 0, 0, 1);
		entity::set_entity_heading(func_288(uParam0, 0), 240.9284f);
	}
	func_271(uParam0, 2);
}

// Position - 0xAABA
void func_298(var *uParam0, int iParam1, float fParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_46(&uParam0->f_15[iParam1 /*34*/], fParam2);
}

// Position - 0xAAE7
void func_299(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_235(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xAB14
void func_300(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_45(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xAB41
void func_301(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_240(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xAB6E
void func_302(var *uParam0, int iParam1, vector3 vParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_48(&uParam0->f_15[iParam1 /*34*/], vParam2);
}

// Position - 0xAB9D
int func_303(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return 0;
	}
	return func_245(&uParam0->f_15[iParam1 /*34*/]);
}

// Position - 0xABC9
void func_304(int iParam0) { Global_100728.f_1 |= iParam0; }

// Position - 0xABE0
void func_305(var *uParam0, int iParam1) { uParam0->f_22 -= (uParam0->f_22 & iParam1); }

// Position - 0xABF8
void func_306(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	vector3 vVar0;
	float *fVar3;
	int iVar4;
	vector3 vVar5;

	vVar5 = {0f, 0f, 0f};
	iVar4 = 0;
	while (iVar4 < iParam3 + 1 / 2) {
		if (!entity::does_entity_exist(func_288(uParam1, iVar4))) {
			if (iVar4 == 1) {
				vVar5 = {FtoV(10f) * entity::get_entity_forward_vector(func_288(uParam1, 0))};
			}
			if (func_43(func_321(uParam0, iParam2) + vVar5, func_41(uParam0, func_307(uParam1)), &vVar0, &fVar3)) {
				func_279(uParam1, vehicle::create_vehicle(joaat("caddy"), vVar0, fVar3, 1, 1), iVar4);
				vehicle::set_vehicle_extra(func_288(uParam1, iVar4), 5, 1);
				entity::_set_entity_register(func_288(uParam1, iVar4), 1);
			}
		}
		iVar4++;
	}
}

// Position - 0xACA2
int func_307(var *uParam0) { return uParam0->f_158; }

// Position - 0xACAE
void func_308(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;
	int iVar3;
	int *iVar4;

	iVar4 = 3;
	func_312(uParam1, iParam2, 4);
	if (iParam2 == 0) {
		vVar0 = {func_321(uParam0, func_307(uParam1))};
	}
	else {
		vVar0 = {func_260(uParam0, func_307(uParam1), iParam2)};
	}
	if (!entity::does_entity_exist(func_278(uParam1, iParam2))) {
		iVar3 = func_311(&iVar4, 1065437102);
		func_309(uParam1, iParam2, ped::create_ped(iVar4, iVar3, vVar0, 0f, 1, 1));
		entity::set_entity_heading(func_278(uParam1, iParam2), func_242(vVar0, func_321(uParam0, func_307(uParam1))));
		if (streaming::has_anim_set_loaded("move_m@golfer@")) {
			ped::set_ped_weapon_movement_clipset(func_278(uParam1, iParam2), "move_m@golfer@");
		}
		ped::_0x2F3C3D9F50681DE4(func_278(uParam1, iParam2), 1);
	}
}

// Position - 0xAD65
void func_309(var *uParam0, int iParam1, var uParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_310(&uParam0->f_15[iParam1 /*34*/], uParam2);
}

// Position - 0xAD92
void func_310(var *uParam0, var uParam1) { uParam0->f_2 = uParam1; }

// Position - 0xADA0
int func_311(int *iParam0, float fParam1) {
	if (gameplay::get_random_float_in_range(0f, 1f) < fParam1) {
		*iParam0 = 4;
		return joaat("a_m_y_golfer_01");
	}
	*iParam0 = 5;
	return joaat("a_f_y_golfer_01");
}

// Position - 0xADCD
void func_312(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_15) {
		return;
	}
	func_313(&uParam0->f_15[iParam1 /*34*/], iParam2);
}

// Position - 0xADFA
void func_313(var *uParam0, var uParam1) { uParam0->f_1 = uParam1; }

// Position - 0xAE08
int func_314(var *uParam0) { return uParam0->f_156; }

// Position - 0xAE14
void func_315(var *uParam0, var *uParam1, int iParam2, var uParam3) {
	func_54(uParam1, iParam2);
	func_318(uParam1, uParam3);
	func_317(uParam1, 0, 0);
	func_317(uParam1, 2, 1);
	func_316(uParam1, 0);
	func_44(uParam0, uParam1);
	func_51(uParam1, 0);
	func_271(uParam1, 2);
}

// Position - 0xAE59
void func_316(var *uParam0, int iParam1) { uParam0->f_165 = iParam1; }

// Position - 0xAE67
void func_317(var *uParam0, int iParam1, int iParam2) { uParam0->f_167[iParam2] = iParam1; }

// Position - 0xAE79
void func_318(var *uParam0, var uParam1) { uParam0->f_156 = uParam1; }

// Position - 0xAE87
bool func_319(int iParam0) { return (Global_100728.f_1 & iParam0) != 0; }

// Position - 0xAE9A
int func_320() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0xAEB4
Vector3 func_321(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= uParam0->f_28) {
		return 0f, 0f, 0f;
	}
	return func_15(iParam1);
}

// Position - 0xAEDC
bool func_322(int iParam0) { return iParam0 > 6 && iParam0 < 18; }

// Position - 0xAEF2
void func_323(var *uParam0) {
	func_324(uParam0, 1);
	func_324(uParam0, 3);
	func_324(uParam0, 5);
	func_324(uParam0, 7);
	func_324(uParam0, 8);
	func_324(uParam0, 9);
	func_324(uParam0, 10);
	func_324(uParam0, 11);
	func_324(uParam0, 12);
	func_324(uParam0, 13);
	func_324(uParam0, 14);
	func_324(uParam0, 16);
	func_324(uParam0, 17);
	func_324(uParam0, 19);
}

// Position - 0xAF74
int func_324(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = *uParam0;
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if ((*uParam0)[iVar0] == 0) {
			func_325(&(*uParam0)[iVar0], iParam1);
			uParam0->f_15++;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xAFB9
void func_325(var *uParam0, var uParam1) { *uParam0 = uParam1; }

// Position - 0xAFC6
int func_326(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				if (!streaming::has_model_loaded((*uParam0)[iVar0])) {
				}
				return 0;
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0xB00D
void func_327(var *uParam0) {
	func_329(uParam0, joaat("a_m_y_golfer_01"));
	func_329(uParam0, joaat("prop_golf_putter_01"));
	func_329(uParam0, joaat("prop_golf_ball"));
	func_329(uParam0, joaat("prop_golf_pitcher_01"));
	func_329(uParam0, joaat("prop_golf_wood_01"));
	func_329(uParam0, joaat("prop_golf_iron_01"));
	func_329(uParam0, joaat("caddy"));
	func_328(uParam0);
}

// Position - 0xB06F
void func_328(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			streaming::request_model((*uParam0)[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0xB09F
int func_329(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] != 0) {
			if ((*uParam0)[iVar0] == iParam1) {
				return 0;
			}
		}
		iVar0++;
	}
	iVar1 = func_330(uParam0);
	if (iVar1 < 0 || iVar1 >= *uParam0) {
		return 0;
	}
	(*uParam0)[iVar1] = iParam1;
	return 1;
}

// Position - 0xB0FC
int func_330(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0xB128
char *func_331() { return "MINI@GOLFAI"; }

// Position - 0xB134
void func_332(var *uParam0) {
	uParam0->f_30[0 /*3*/] = {-1339.236f, 60.7393f, 54.0802f};
	uParam0->f_30[1 /*3*/] = {-1339.235f, 59.1891f, 54.0802f};
	uParam0->f_30[2 /*3*/] = {-1337.066f, 56.556f, 54.0804f};
	uParam0->f_30[3 /*3*/] = {-1342.315f, 59.0051f, 54.2456f};
	uParam0->f_43[0 /*3*/] = {-1324.392f, 59.1355f, 52.5704f};
	uParam0->f_43[1 /*3*/] = {-1324.455f, 55.1355f, 52.571f};
	uParam0->f_43[2 /*3*/] = {-1324.455f, 51.1355f, 52.571f};
	uParam0->f_43[3 /*3*/] = {-1324.455f, 47.1355f, 52.571f};
	uParam0->f_28 = 9;
	func_333(uParam0);
}

// Position - 0xB208
void func_333(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < func_53(uParam0)) {
		(*uParam0)[iVar0 /*3*/] = system::vdist(func_321(uParam0, iVar0), func_243(uParam0, iVar0)) +
								  system::vdist(func_243(uParam0, iVar0), func_41(uParam0, iVar0));
		if ((*uParam0)[iVar0 /*3*/] < 35f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 1;
		}
		else if ((*uParam0)[iVar0 /*3*/] < 125f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 3;
		}
		else if ((*uParam0)[iVar0 /*3*/] < 260f) {
			(*uParam0)[iVar0 /*3*/].f_1 = 4;
		}
		else {
			(*uParam0)[iVar0 /*3*/].f_1 = 5;
		}
		iVar1 += (*uParam0)[iVar0 /*3*/].f_1;
		func_334(uParam0, iVar1);
		iVar0++;
	}
}

// Position - 0xB2C5
void func_334(var *uParam0, int iParam1) { uParam0->f_29 = iParam1; }

// Position - 0xB2D3
void func_335(int iParam0) { Global_100728.f_1 -= (Global_100728.f_1 & iParam0); }

// Position - 0xB2F1
void func_336(var *uParam0, int iParam1) {
	func_339(uParam0);
	func_338(iParam1);
	func_337();
	streaming::remove_anim_dict(func_331());
	script::terminate_this_thread();
}

// Position - 0xB315
void func_337() {
	Global_100728 = -1;
	Global_100728.f_1 = 0;
}

// Position - 0xB329
void func_338(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		iVar1 = 0;
		while (iVar1 < func_314(&(*uParam0)[iVar0 /*170*/])) {
			func_61(&(*uParam0)[iVar0 /*170*/], iVar1);
			func_38(&(*uParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/]);
			func_291(&(*uParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/]);
			if (entity::does_entity_exist((*uParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/].f_2)) {
				entity::set_ped_as_no_longer_needed(&(*uParam0)[iVar0 /*170*/].f_15[iVar1 /*34*/].f_2);
			}
			iVar1++;
		}
		if (entity::does_entity_exist((*uParam0)[iVar0 /*170*/].f_152[0])) {
			entity::set_vehicle_as_no_longer_needed(&(*uParam0)[iVar0 /*170*/].f_152[0]);
		}
		if (entity::does_entity_exist((*uParam0)[iVar0 /*170*/].f_152[1])) {
			entity::set_vehicle_as_no_longer_needed(&(*uParam0)[iVar0 /*170*/].f_152[1]);
		}
		iVar0++;
	}
}

// Position - 0xB3F5
void func_339(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		iVar1 = func_102(uParam0, iVar0);
		if (entity::does_entity_exist(iVar1) && entity::is_entity_a_mission_entity(iVar1)) {
			entity::set_object_as_no_longer_needed(&iVar1);
			object::delete_object(&iVar1);
		}
		iVar0++;
	}
}

#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
float fLocal_12 = 0f;
float fLocal_13 = 0f;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
int iLocal_29 = 0;
int iLocal_30 = 0;
int iLocal_31 = 0;
int iLocal_32 = 0;
int iLocal_33[21] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
float fLocal_55 = 0f;
vector3 vLocal_56 = {0f, 0f, 0f};
int iLocal_59 = 0;
int iLocal_60 = 0;
struct<9> Local_61 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0
};
struct<9> Local_70 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0
};
vector3 vLocal_79 = {0f, 0f, 0f};
vector3 vLocal_82 = {0f, 0f, 0f};
vector3 vLocal_85 = {0f, 0f, 0f};
float fLocal_88 = 0f;
float fLocal_89 = 0f;
float fLocal_90 = 0f;
float fLocal_91 = 0f;
float fLocal_92 = 0f;
int iLocal_93 = 0;
bool bLocal_94 = 0;
int iLocal_95 = 0;
int iLocal_96 = 0;
int iLocal_97 = 0;
int iLocal_98 = 0;
int iLocal_99 = 0;
int iLocal_100 = 0;
int iLocal_101 = 0;
char *sLocal_102 = NULL;
int iLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
float fLocal_106 = 0f;
float fLocal_107 = 0f;
float fLocal_108 = 0f;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
int iLocal_114 = 0;
int iLocal_115 = 0;
int iLocal_116 = 0;
int iLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
int iLocal_120 = 0;
int iLocal_121 = 0;
int iLocal_122 = 0;
int iLocal_123 = 0;
int iLocal_124 = 0;
int iLocal_125 = 0;
int iLocal_126 = 0;
int iLocal_127 = 0;
int iLocal_128 = 0;
int iLocal_129 = 0;
int iLocal_130 = 0;
int iLocal_131 = 0;
int iLocal_132 = 0;
bool bLocal_133 = 0;
float fLocal_134 = 0f;
int iLocal_135 = 0;
int iLocal_136 = 0;
int iLocal_137 = 0;
int iLocal_138 = 0;
int iLocal_139 = 0;
int iLocal_140 = 0;
int iLocal_141 = 0;
int iLocal_142 = 0;
float fLocal_143 = 0f;
float fLocal_144 = 0f;
float fLocal_145 = 0f;
float fLocal_146 = 0f;
float fLocal_147 = 0f;
float fLocal_148 = 0f;
float fLocal_149 = 0f;
float fLocal_150 = 0f;
int iLocal_151[11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
bool bLocal_163 = 0;
struct<68> Local_164 = {
	0, 0, 1132396544, 1132396544, 1132396544, 0, -1082130432, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, -1, 1092616192
};
var uLocal_232 = 0;
var uLocal_233 = 0;
var uLocal_234 = 0;
var uLocal_235 = 0;
var uLocal_236 = 0;
var uLocal_237 = 0;
var uLocal_238 = 0;
var uLocal_239 = 0;
var uLocal_240 = 0;
var uLocal_241 = 0;
var uLocal_242 = 0;
var uLocal_243 = 0;
var uLocal_244 = 0;
var uLocal_245 = 0;
var uLocal_246 = 0;
var uLocal_247 = 0;
var uLocal_248 = 10;
var uLocal_249 = 0;
var uLocal_250 = 0;
var uLocal_251 = 0;
var uLocal_252 = 0;
var uLocal_253 = 0;
var uLocal_254 = 0;
var uLocal_255 = 0;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 2;
var uLocal_260 = 0;
var uLocal_261 = 0;
var uLocal_262 = 8;
var uLocal_263 = 0;
var uLocal_264 = 0;
var uLocal_265 = 0;
var uLocal_266 = 0;
var uLocal_267 = 0;
var uLocal_268 = 0;
var uLocal_269 = 0;
var uLocal_270 = 0;
var uLocal_271 = 8;
var uLocal_272 = 0;
var uLocal_273 = 0;
var uLocal_274 = 0;
var uLocal_275 = 0;
var uLocal_276 = 0;
var uLocal_277 = 0;
var uLocal_278 = 0;
var uLocal_279 = 0;
var uLocal_280 = 0;
float fLocal_281 = 0f;
var uLocal_282 = 0;
var uLocal_283 = 0;
float fLocal_284 = 0f;
float fLocal_285 = 0f;
float fLocal_286 = 0f;
float fLocal_287 = 0f;
float fLocal_288 = 0f;
var uLocal_289 = 0;
int iLocal_290 = 0;
int iLocal_291 = 0;
int iLocal_292 = 0;
vector3 vLocal_293 = {0f, 0f, 0f};
var *uLocal_296[2] = {NULL, NULL};
int iLocal_299 = 0;
int iLocal_300 = 0;
int iLocal_301 = 0;
int iLocal_302 = 0;
int iLocal_303 = 0;
int iLocal_304 = 0;
int iLocal_305 = 0;
int iLocal_306 = 0;
int iLocal_307 = 0;
bool bLocal_308 = 0;
int iLocal_309 = 0;
int iLocal_310 = 0;
bool bLocal_311 = 0;
int iLocal_312 = 0;
int iLocal_313 = 0;
int iLocal_314 = 0;
int iLocal_315 = 0;
bool bLocal_316 = 0;
int iLocal_317 = 0;
int iLocal_318 = 0;
int iLocal_319 = 0;
int iLocal_320 = 0;
bool bLocal_321 = 0;
int *iLocal_322 = NULL;
int iLocal_323 = 0;
int iLocal_324 = 0;
int iLocal_325 = 0;
int iLocal_326 = 0;
int *iLocal_327 = NULL;
int iLocal_328 = 0;
int iLocal_329 = 0;
int iLocal_330 = 0;
int iLocal_331 = 0;
int iLocal_332 = 0;
int iLocal_333 = 0;
int iLocal_334 = 0;
int iLocal_335 = 0;
int iLocal_336 = 0;
var uLocal_337 = 0;
var uLocal_338 = 0;
var uLocal_339 = 0;
var uLocal_340 = 0;
var uLocal_341 = 0;
var uLocal_342 = 0;
var uLocal_343 = 0;
var uLocal_344 = 0;
var uLocal_345 = 0;
var uLocal_346 = 0;
var uLocal_347 = 0;
var uLocal_348 = 0;
var uLocal_349 = 0;
var uLocal_350 = 0;
var uLocal_351 = 0;
var uLocal_352 = 0;
var uLocal_353 = 0;
var uLocal_354 = 0;
var uLocal_355 = 0;
var uLocal_356 = 0;
var uLocal_357 = 0;
var uLocal_358 = 0;
var uLocal_359 = 0;
var uLocal_360 = 0;
var uLocal_361 = 0;
var uLocal_362 = 0;
var uLocal_363 = 0;
var uLocal_364 = 0;
var uLocal_365 = 0;
var uLocal_366 = 0;
vector3 vLocal_367 = {0f, 0f, 0f};
vector3 vLocal_370 = {0f, 0f, 0f};
vector3 vLocal_373 = {0f, 0f, 0f};
vector3 vLocal_376 = {0f, 0f, 0f};
vector3 vLocal_379 = {0f, 0f, 0f};
vector3 vLocal_382 = {0f, 0f, 0f};
float fLocal_385 = 0f;
float fLocal_386 = 0f;
float fLocal_387 = 0f;
float fLocal_388 = 0f;
int iLocal_389 = 0;
int iLocal_390 = 0;
char *sLocal_391 = NULL;
char *sLocal_392 = NULL;
int iLocal_393 = 0;
char *sLocal_394 = NULL;
char *sLocal_395 = NULL;
char *sLocal_396[3] = {NULL, NULL, NULL};
char *sLocal_400[3] = {NULL, NULL, NULL};
char *sLocal_404[3] = {NULL, NULL, NULL};
char *sLocal_408[3] = {NULL, NULL, NULL};
struct<5> ScriptParam_0 = {
	0, 0, 0, 0, 0
};
var uScriptParam_5 = 0;
var uScriptParam_6 = 0;
#pragma endregion //}

void __EntryFunction__() {
	struct<460> Var0;
	int *iVar464;
	struct<4> Var465;
	vector3 vVar471;
	struct<25> Var477;
	struct<682> Var508;
	struct<532> Var1191;
	int iVar1767;
	int iVar1768;
	int iVar1769;
	int iVar1770;
	int iVar1771;
	int iVar1772;
	int iVar1773;
	int iVar1774;
	float fVar1775;
	float fVar1776;
	vector3 vVar1777;
	vector3 vVar1780;
	vector3 vVar1783;
	vector3 vVar1786;
	vector3 vVar1789;
	char *sVar1792;
	int *iVar1793;
	int *iVar1796;
	int *iVar1799;
	var *uVar1802[20];
	int iVar1823;
	int iVar1824;
	int iVar1825;
	int iVar1826;
	int iVar1827;
	int iVar1828;
	int iVar1829;
	float fVar1830;
	int iVar1831;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	iLocal_28 = joaat("prop_dart_1");
	iLocal_29 = joaat("prop_dart_2");
	iLocal_32 = joaat("prop_dart_bd_cab_01");
	fLocal_55 = 0.063f;
	vLocal_56 = {-0.0035f, 0f, -0.001f};
	iLocal_60 = joaat("prop_target_bull");
	vLocal_85 = {987.8541f, -98.4173f, 73.8599f};
	fLocal_92 = 0.1f;
	iLocal_103 = 3;
	fLocal_106 = 80f;
	fLocal_107 = 140f;
	fLocal_108 = 180f;
	iLocal_114 = 1;
	iLocal_115 = 65;
	iLocal_116 = 49;
	iLocal_117 = 64;
	iLocal_140 = 65;
	iLocal_142 = 660;
	fLocal_147 = 0.27f;
	fLocal_148 = 0.1f;
	fLocal_149 = -120f;
	fLocal_150 = 127f;
	fLocal_281 = 0.05f + 0.275f - 0.01f;
	fLocal_284 = -0.05f;
	fLocal_285 = 0.92f;
	fLocal_286 = 1.94f;
	fLocal_287 = 2.99f;
	fLocal_288 = 3.7f;
	vLocal_293 = {500f, 500f, 500f};
	bLocal_308 = true;
	vLocal_373 = {-573.1373f, 294.0269f, 78.1765f};
	vLocal_376 = {-574.1169f, 292.7964f, 78.1766f};
	vLocal_379 = {1995.295f, 3050.084f, 46.91535f};
	vLocal_382 = {1995.488f, 3047.383f, 46.91535f};
	fLocal_385 = 172.6813f;
	fLocal_386 = 274.5094f;
	fLocal_387 = 142.6717f;
	fLocal_388 = 44.8785f;
	Var0.f_1 = 2;
	Var0.f_5 = 2;
	Var0.f_5.f_1 = 3;
	Var0.f_5.f_1.f_79 = 3;
	Var0.f_164 = 3;
	Var0.f_257 = 16;
	Var0.f_422 = 2;
	Var0.f_425 = 2;
	Var0.f_429 = 2;
	Var0.f_432 = 2;
	Var0.f_437 = 2;
	Var0.f_440 = 2;
	Var0.f_443 = 2;
	Var0.f_446 = 2;
	Var0.f_449 = 2;
	Var477.f_1 = 2;
	Var477.f_1.f_1 = 7;
	Var477.f_1.f_1.f_8 = 7;
	Var508.f_3 = 8;
	Var508.f_12 = 8;
	Var508.f_21 = 4;
	Var508.f_26.f_3 = 8;
	Var508.f_26.f_12 = 8;
	Var508.f_26.f_21 = 4;
	Var508.f_72 = 3;
	Var508.f_72.f_44.f_3.f_1 = 4;
	Var508.f_72.f_113 = 2;
	Var508.f_72.f_113.f_1.f_1 = 4;
	Var508.f_72.f_113.f_1.f_66.f_1 = 4;
	Var508.f_72.f_246.f_6 = 12;
	Var508.f_72.f_246.f_187 = 3;
	Var508.f_509.f_2 = 8;
	Var508.f_509.f_2.f_1.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_15.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
	Var508.f_509.f_2.f_1.f_15.f_15.f_15.f_15.f_15.f_15.f_15.f_3 = 4;
	Var508.f_681 = 2;
	Var1191.f_32 = 3;
	Var1191.f_36 = 1;
	Var1191.f_53 = 2;
	Var1191.f_57 = 13;
	Var1191.f_71 = 13;
	Var1191.f_280 = 13;
	Var1191.f_489 = 13;
	Var1191.f_503 = 13;
	Var1191.f_517 = 13;
	Var1191.f_531 = 13;
	iVar1773 = 0;
	sLocal_394 = "facials@gen_female@variations@happy";
	switch (func_481(player::player_ped_id())) {
	case 0: sLocal_395 = "facials@p_m_zero@variations@happy"; break;

	case 1: sLocal_395 = "facials@p_m_one@variations@happy"; break;

	case 2: sLocal_395 = "facials@p_m_two@variations@happy"; break;
	}
	sLocal_396[0] = "mood_happy_1";
	sLocal_396[1] = "mood_happy_2";
	sLocal_396[2] = "mood_happy_3";
	sLocal_400[0] = "darts_outro_01_guy1";
	sLocal_400[1] = "darts_outro_02_guy2";
	sLocal_400[2] = "darts_outro_03_guy2";
	sLocal_404[0] = "darts_outro_01_guy2";
	sLocal_404[1] = "darts_outro_02_guy1";
	sLocal_404[2] = "darts_outro_03_guy1";
	sLocal_408[0] = "darts_outro_01_cam";
	sLocal_408[1] = "darts_outro_02_cam";
	sLocal_408[2] = "darts_outro_03_cam";
	uLocal_296[0] = player::player_ped_id();
	bLocal_311 = true;
	vVar1777 = {1992.293f, 3050.583f, 47.98973f};
	vVar1780 = {-572.0406f, 294.1958f, 79.9374f};
	func_480();
	if (!ped::is_ped_injured(player::player_ped_id())) {
		iLocal_335 = 1;
		switch (gameplay::get_random_int_in_range(0, 2)) {
		case 0: iLocal_332 = joaat("a_f_m_salton_01"); break;

		case 1: iLocal_332 = joaat("a_f_o_salton_01"); break;
		}
		iLocal_330 = 10;
		weapon::set_current_ped_weapon(player::player_ped_id(), joaat("weapon_unarmed"), 1);
	}
	if (!entity::does_entity_exist(ScriptParam_0.f_4)) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (iLocal_335 == 2) {
				ScriptParam_0 = {vVar1780};
				ScriptParam_0.f_3 = -0.09f;
			}
			else {
				ScriptParam_0 = {vVar1777};
				ScriptParam_0.f_3 = 57.78315f;
			}
			if (object::does_object_of_type_exist_at_coords(ScriptParam_0, 5f, joaat("prop_dart_bd_cab_01"), 0)) {
				ScriptParam_0.f_4 =
					object::get_closest_object_of_type(ScriptParam_0, 5f, joaat("prop_dart_bd_cab_01"), 1, 0, 1);
				object::_0x163F8B586BC95F2A(ScriptParam_0, 5f, joaat("prop_dart_bd_cab_01"), &ScriptParam_0, &vVar1783,
											0);
				ScriptParam_0.f_3 = vVar1783.z;
			}
		}
	}
	else {
		vVar1783 = {entity::get_entity_coords(ScriptParam_0.f_4, 1)};
	}
	if (!entity::is_entity_dead(func_479(), 0)) {
		func_477(iLocal_330, 1);
		if (ped::is_ped_in_any_vehicle(func_479(), 0)) {
			ai::task_leave_any_vehicle(func_479(), 0, 0);
		}
		uLocal_296[1] = func_479();
	}
	else {
		gameplay::set_mission_flag(1);
	}
	if (player::has_force_cleanup_occurred(67)) {
		func_468();
		func_449(&Var0, &Var508, &Var1191);
	}
	ui::display_area_name(0);
	player::set_player_control(player::player_id(), 0, 0);
	func_447(1);
	iLocal_326 = func_444(func_481(uLocal_296[0]), 1);
	fVar1775 = system::to_float(iLocal_326) / 100f;
	fVar1776 = fVar1775 * 1200f;
	iLocal_142 = system::round(fVar1776);
	if (iLocal_142 < 660) {
		iLocal_142 = 660;
	}
	func_443(23, 1);
	while (true) {
		system::wait(0);
		ui::hide_hud_component_this_frame(2);
		ui::hide_hud_and_radar_this_frame();
		ui::set_hud_component_position(15, 0f, -0.0375f);
		if (iLocal_318 && Var0 < 13) {
			graphics::draw_scaleform_movie_3d(Var477, Var477.f_18, Var477.f_21, Var477.f_24, Var477.f_24, 2);
		}
		if (ped::is_ped_injured(ScriptParam_0.f_5) && !entity::does_entity_exist(func_479()) ||
			entity::does_entity_exist(func_479()) && ped::is_ped_injured(func_479())) {
			func_449(&Var0, &Var508, &Var1191);
		}
		if (!ped::is_ped_injured(uLocal_296[0])) {
			ped::set_ped_reset_flag(uLocal_296[0], 239, 1);
			ped::set_ped_reset_flag(uLocal_296[0], 124, 1);
			func_442();
			controls::_disable_input_group(0);
			controls::_disable_input_group(2);
			iVar1774 = 0;
			while (iVar1774 < ped::get_ped_nearby_peds(player::player_ped_id(), &uVar1802, -1)) {
				if (uVar1802[iVar1774] != uLocal_296[1]) {
					if (!ped::is_ped_injured(uVar1802[iVar1774])) {
						ped::set_ped_reset_flag(uVar1802[iVar1774], 240, 1);
					}
				}
				iVar1774++;
			}
			switch (Var0) {
			case 0:
				ui::clear_help(1);
				func_441(&Var0.f_243, &ScriptParam_0);
				func_440(Var0.f_243.f_1, Var0.f_243.f_4);
				if (entity::does_entity_exist(Var0.f_243)) {
					vLocal_367 = {
						entity::get_offset_from_entity_in_world_coords(Var0.f_243, 0.7792f, -1.138f, 0.1814f)};
					vLocal_370 = {-7.9947f, 0f, Var0.f_243.f_4 + 36.19176f};
					iLocal_129 = cam::create_camera_with_params(26379945, vLocal_367, vLocal_370, 65f, 0, 2);
					cam::set_cam_fov(iLocal_129, 30f);
				}
				func_439();
				system::settimera(0);
				Var0 = 1;
				break;

			case 1:
				if (system::timera() > 500 && !ped::is_ped_ragdoll(player::player_ped_id())) {
					gameplay::clear_area(ScriptParam_0, 0.5f, 1, 0, 0, 0);
					if (!ped::is_ped_injured(player::player_ped_id()) &&
						ped::is_ped_in_any_vehicle(player::player_ped_id(), 1)) {
						ai::clear_sequence_task(&iLocal_333);
						ai::open_sequence_task(&iLocal_333);
						ai::task_leave_any_vehicle(0, 0, 0);
						ai::close_sequence_task(iLocal_333);
						ai::task_perform_sequence(player::player_ped_id(), iLocal_333);
					}
					vLocal_85 = {vLocal_85};
					Var0 = 2;
				}
				break;

			case 2:
				iVar1824 = 0;
				while (iVar1824 < 2) {
					iVar1825 = 0;
					while (iVar1825 < 3) {
						func_438(&Var0.f_5[iVar1824 /*79*/][iVar1825 /*26*/], iVar1824);
						iVar1825++;
					}
					iVar1824++;
				}
				iVar1826 = 0;
				while (iVar1826 < 3) {
					func_438(&Var0.f_164[iVar1826 /*26*/], 0);
					iVar1826++;
				}
				iVar464 = 2;
				func_437(0);
				func_435(&Var477, iLocal_335, Var0.f_243.f_1, Var0.f_243.f_4);
				if (entity::does_entity_exist(Var0.f_243)) {
					vVar1783 = {entity::get_offset_from_entity_given_world_coords(Var0.f_243, Var477.f_18)};
				}
				func_432(&Var477, &Var508);
				audio::register_script_with_audio(0);
				Var0 = 3;
				break;

			case 3:
				if (func_429(&Var477, &Var508)) {
					func_426(&Var0.f_243, &Var465, &vVar471, 0);
					iLocal_389 = func_481(uLocal_296[0]);
					switch (iLocal_389) {
					case 0:
						sLocal_391 = func_425("MICHAEL");
						if (!gameplay::is_bit_set(Global_101661, 0)) {
							sVar1792 = "darts_ig_intro_player_0_face";
						}
						else {
							sVar1792 = "darts_ig_intro_alt1_player_0_face";
						}
						break;

					case 1:
						sLocal_391 = func_425("FRANKLIN");
						iLocal_315 = 1;
						if (!gameplay::is_bit_set(Global_101661, 0)) {
							sVar1792 = "darts_ig_intro_player_1_face";
						}
						else {
							sVar1792 = "darts_ig_intro_alt1_player_1_face";
						}
						break;

					case 2:
						sLocal_391 = func_425("TREVOR");
						if (!gameplay::is_bit_set(Global_101661, 0)) {
							sVar1792 = "darts_ig_intro_player_2_face";
						}
						else {
							sVar1792 = "darts_ig_intro_alt1_player_2_face";
						}
						break;
					}
					if (!entity::is_entity_dead(func_479(), 0)) {
						iLocal_390 = func_481(func_479());
						if (iLocal_390 == 145) {
							iLocal_390 = func_423(func_479());
						}
						switch (iLocal_390) {
						case 0: sLocal_392 = func_425("MICHAEL"); break;

						case 1: sLocal_392 = func_425("FRANKLIN"); break;

						case 2: sLocal_392 = func_425("TREVOR"); break;

						case 19:
							sLocal_392 = func_425("LAMAR");
							ped::set_ped_component_variation(func_479(), 5, 2, 0, 0);
							break;

						case 14: sLocal_392 = func_425("JIMMY"); break;

						default: sLocal_392 = "NEW_GUY"; break;
						}
					}
					else {
						iVar1772 = gameplay::get_random_int_in_range(0, 200);
						if (iLocal_335 == 2) {
							if (iVar1772 < 51) {
								sLocal_392 = func_425("RAYMOND");
								iLocal_393 = 954610991;
							}
							else if (iVar1772 < 101) {
								sLocal_392 = func_425("JOHAN");
								iLocal_393 = 94453331;
							}
							else if (iVar1772 < 151) {
								sLocal_392 = func_425("STAN");
								iLocal_393 = 1891555423;
							}
							else {
								sLocal_392 = func_425("VINCE");
								iLocal_393 = -1067630349;
							}
						}
						else if (iVar1772 < 51) {
							sLocal_392 = func_425("KRISTY");
							iLocal_393 = 885327384;
						}
						else if (iVar1772 < 101) {
							sLocal_392 = func_425("MARLENE");
							iLocal_393 = -1791000994;
						}
						else if (iVar1772 < 151) {
							sLocal_392 = func_425("LORIE");
							iLocal_393 = 1954368234;
						}
						else {
							sLocal_392 = func_425("SHELLEY");
							iLocal_393 = -863218904;
						}
					}
					iLocal_59 = object::create_object(iLocal_60, vVar471, 1, 1, 0);
					Var0.f_446[0] = 0;
					Var0.f_446[1] = 0;
					Var0 = 4;
				}
				break;

			case 4:
				if (!cam::_0x705A276EBFF3133D()) {
					iVar1823 = object::create_object(joaat("prop_dart_1"), vVar471, 1, 1, 0);
					func_420(Var0.f_243.f_4, Var465, &uVar1802, &ScriptParam_0);
					func_418(&Var477, sLocal_391, sLocal_392);
					ai::clear_ped_tasks(uLocal_296[1]);
					iLocal_334 = cam::create_camera_with_params(26379945, 0f, 0f, 0f, 0f, 0f, 0f, 65f, 0, 2);
					if (!ped::is_ped_injured(player::player_ped_id())) {
						ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 0, 0, 0);
					}
					func_417(&Var0.f_257, 0, player::player_ped_id(), sLocal_391, 0, 1);
					if (entity::is_entity_dead(func_479(), 0)) {
						if (iLocal_335 == 2) {
							func_417(&Var0.f_257, 3, uLocal_296[1], "DartsBillLost1", 0, 1);
						}
						else {
							func_417(&Var0.f_257, 3, uLocal_296[1], "DartsMelHick1", 0, 1);
						}
						iVar1773 = -1;
					}
					else {
						func_417(&Var0.f_257, 3, func_479(), sLocal_392, 0, 1);
						func_415(&iVar1799);
						iVar1773 = 6;
					}
					if (!gameplay::is_bit_set(Global_101661, 0)) {
						iVar1773 = -1;
					}
					else {
						iVar1773 = 3;
					}
					func_414(&Var477, 0);
					Var0 = 5;
				}
				break;

			case 5:
				if (!ped::is_ped_injured(uLocal_296[1]) && ped::is_ped_on_foot(uLocal_296[0]) &&
					!ped::is_ped_in_any_vehicle(uLocal_296[0], 1) && ped::is_ped_on_foot(uLocal_296[1]) &&
					!ped::is_ped_in_any_vehicle(uLocal_296[1], 1)) {
					iLocal_306 = func_412(&iLocal_322);
					if (func_411() && gameplay::get_game_timer() >= iLocal_324 + 1000 && iVar1773 != 9) {
						if (!cam::is_screen_faded_out() && !cam::is_screen_fading_out()) {
							cam::do_screen_fade_out(500);
						}
					}
					if (cam::is_screen_faded_out() && iVar1773 != 9) {
						func_408(0);
						func_406();
						iVar1773 = 9;
					}
					switch (iVar1773) {
					case -1:
						if (!ped::is_ped_injured(uLocal_296[1])) {
							iLocal_328 = ped::create_synchronized_scene(
								entity::get_offset_from_entity_in_world_coords(ScriptParam_0.f_4, 0.337842f, -0.243051f,
																			   -0.329731f),
								0f, 0f, entity::get_entity_heading(ScriptParam_0.f_4) - 3.783146f, 2);
							iLocal_334 = cam::create_cam("DEFAULT_ANIMATED_CAMERA", 0);
							cam::play_synchronized_cam_anim(iLocal_334, iLocal_328, "darts_ig_intro_cam",
															"mini@dartsintro");
							cam::set_cam_active(iLocal_334, 1);
							cam::render_script_cams(1, 0, 3000, 1, 0, 0);
							ai::task_clear_look_at(uLocal_296[0]);
							ai::task_clear_look_at(uLocal_296[1]);
							ai::clear_ped_tasks_immediately(uLocal_296[0]);
							ai::clear_ped_tasks_immediately(uLocal_296[1]);
							ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsintro",
														"darts_ig_intro_guy1", 1000f, -1000f, 0, 0, 1148846080, 0);
							ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsintro",
														"darts_ig_intro_guy2", 1000f, -1000f, 0, 0, 1148846080, 0);
							ai::task_play_anim(uLocal_296[1], "mini@dartsintro", "darts_ig_intro_guy1_face", 8f, -8f,
											   -1, 32, 0, 0, 0, 0);
							ai::task_play_anim(uLocal_296[0], "mini@dartsintro", sVar1792, 8f, -8f, -1, 32, 0, 0, 0, 0);
							entity::play_synchronized_entity_anim(iVar1823, iLocal_328, "darts_ig_intro_dart",
																  "mini@dartsintro", 1000f, 8f, 0, 1148846080);
							func_405(&iVar1799);
							iVar1773++;
						}
						break;

					case 0:
						if (ped::is_synchronized_scene_running(iLocal_328)) {
							if (!iVar1769) {
								if (func_404(&iVar1799) > 1.5f) {
									func_403(uLocal_296[0], "DARTS_REQUEST_GAME", 6);
									iVar1769 = 1;
									func_402(&iVar1799);
								}
							}
							else if (!audio::is_ambient_speech_playing(uLocal_296[0])) {
								if (!iVar1770) {
									if (!func_401(&iVar1799)) {
										func_415(&iVar1799);
									}
									else if (func_404(&iVar1799) > 0.5f) {
										func_400(uLocal_296[1]);
										func_402(&iVar1799);
										iVar1770 = 1;
									}
								}
							}
							switch (iLocal_31) {
							case 0:
								func_405(&iVar1799);
								func_399("DARTS_HOW_TO_2", -1);
								iLocal_31++;
								break;

							case 1:
								if (ped::get_synchronized_scene_phase(iLocal_328) > 0.25f) {
									func_405(&iVar1799);
									func_399("DARTS_HOW_TO_3", -1);
									iLocal_31++;
								}
								break;

							case 2:
								if (ped::get_synchronized_scene_phase(iLocal_328) > 0.55f) {
									func_399("DARTS_HOW_3A", -1);
									iLocal_31++;
								}
								break;

							case 3:
								if (ped::get_synchronized_scene_phase(iLocal_328) > 0.85f) {
									func_399("DARTS_HOW_3A", -1);
									iLocal_31++;
								}
								break;
							}
							if (ped::get_synchronized_scene_phase(iLocal_328) > 0.95f) {
								iLocal_318 = 1;
								iVar1773++;
							}
							else if (gameplay::get_game_timer() % 1000 < 50) {
							}
						}
						break;

					case 1:
						if (ped::get_synchronized_scene_phase(iLocal_328) > 0.99f) {
							if (!ped::is_ped_injured(uLocal_296[1])) {
								func_396(Var0.f_243.f_1, Var0.f_243.f_4, func_398(2), func_397(0), 0, 1);
								iLocal_31 = 0;
								ui::clear_help(1);
								cam::destroy_cam(iLocal_334, 0);
								ai::clear_ped_tasks(uLocal_296[0]);
								ai::clear_ped_tasks(uLocal_296[1]);
								entity::stop_synchronized_entity_anim(iVar1823, -1000f, 0);
								object::delete_object(&iVar1823);
								audio::stop_audio_scene(func_395(0));
								func_402(&iVar1799);
								Var0 = 6;
								iVar1773 = 0;
							}
						}
						break;

					case 3:
						if (!ped::is_ped_injured(uLocal_296[1])) {
							iLocal_328 = ped::create_synchronized_scene(
								entity::get_offset_from_entity_in_world_coords(ScriptParam_0.f_4, 0.337842f, -0.243051f,
																			   -0.329731f),
								0f, 0f, entity::get_entity_heading(ScriptParam_0.f_4) - 3.783146f, 2);
							iLocal_334 = cam::create_cam("DEFAULT_ANIMATED_CAMERA", 0);
							cam::play_synchronized_cam_anim(iLocal_334, iLocal_328, "darts_ig_intro_alt1_cam",
															"mini@dartsintro_alt1");
							cam::set_cam_active(iLocal_334, 1);
							cam::render_script_cams(1, 0, 3000, 1, 0, 0);
							ai::task_clear_look_at(uLocal_296[0]);
							ai::task_clear_look_at(uLocal_296[1]);
							ai::clear_ped_tasks_immediately(uLocal_296[0]);
							ai::clear_ped_tasks_immediately(uLocal_296[1]);
							ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsintro_alt1",
														"darts_ig_intro_alt1_guy1", 1000f, -1000f, 0, 0, 1148846080, 0);
							ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsintro_alt1",
														"darts_ig_intro_alt1_guy2", 1000f, -1000f, 0, 0, 1148846080, 0);
							ai::task_play_anim(uLocal_296[1], "mini@dartsintro_alt1", "darts_ig_intro_alt1_guy1_face",
											   8f, -8f, -1, 32, 0, 0, 0, 0);
							ai::task_play_anim(uLocal_296[0], "mini@dartsintro_alt1", sVar1792, 8f, -8f, -1, 32, 0, 0,
											   0, 0);
							entity::play_synchronized_entity_anim(iVar1823, iLocal_328, "darts_ig_intro_alt1_dart",
																  "mini@dartsintro_alt1", 1000f, 8f, 0, 1148846080);
							func_405(&iVar1799);
							iVar1773++;
						}
						break;

					case 4:
						if (ped::is_synchronized_scene_running(iLocal_328)) {
							if (!iVar1769) {
								if (func_404(&iVar1799) > 0.5f) {
									func_403(uLocal_296[0], "DARTS_REQUEST_GAME", 6);
									iVar1769 = 1;
									func_402(&iVar1799);
								}
							}
							else if (!audio::is_ambient_speech_playing(uLocal_296[0])) {
								if (!iVar1770) {
									if (!func_401(&iVar1799)) {
										func_415(&iVar1799);
									}
									else if (func_404(&iVar1799) > 0.25f) {
										func_400(uLocal_296[1]);
										func_402(&iVar1799);
										iVar1770 = 1;
									}
								}
							}
							if (ped::get_synchronized_scene_phase(iLocal_328) > 0.95f) {
								iLocal_318 = 1;
								iVar1773++;
							}
							else if (gameplay::get_game_timer() % 1000 < 50) {
							}
						}
						break;

					case 5:
						if (ped::get_synchronized_scene_phase(iLocal_328) > 0.99f) {
							if (!ped::is_ped_injured(uLocal_296[1])) {
								func_394();
								cam::destroy_cam(iLocal_334, 0);
								ai::clear_ped_tasks(uLocal_296[0]);
								ai::clear_ped_tasks(uLocal_296[1]);
								entity::stop_synchronized_entity_anim(iVar1823, -1000f, 0);
								object::delete_object(&iVar1823);
								audio::stop_audio_scene(func_395(0));
								func_402(&iVar1799);
								Var0 = 6;
								iVar1773 = 0;
							}
						}
						break;

					case 9:
						if (cam::is_screen_faded_out()) {
							iLocal_318 = 1;
							iLocal_31 = 0;
							ui::clear_help(1);
							if (!ped::is_ped_injured(uLocal_296[1])) {
								entity::set_entity_coords(uLocal_296[0], Var465, 1, 0, 0, 1);
								entity::set_entity_heading(uLocal_296[0], Var0.f_243.f_4);
								entity::set_entity_coords(uLocal_296[1], Var465.f_3, 1, 0, 0, 1);
								entity::set_entity_heading(uLocal_296[1], Var0.f_243.f_4);
								ai::clear_ped_tasks(uLocal_296[0]);
								ai::clear_ped_tasks(uLocal_296[1]);
							}
							cam::destroy_cam(iLocal_334, 0);
							entity::stop_synchronized_entity_anim(iVar1823, -1000f, 0);
							object::delete_object(&iVar1823);
							if (!gameplay::is_bit_set(Global_101661, 0)) {
								func_396(Var0.f_243.f_1, Var0.f_243.f_4, func_398(2), func_397(0), 0, 1);
							}
							else {
								func_394();
							}
							audio::stop_audio_scene(func_395(0));
							func_402(&iVar1799);
							cam::do_screen_fade_in(500);
							Var0 = 6;
							iVar1773 = 0;
						}
						break;
					}
				}
				break;

			case 6:
				switch (iVar1773) {
				case 0:
					iLocal_324 = gameplay::get_game_timer();
					if (!ped::is_ped_injured(uLocal_296[1])) {
						entity::set_entity_coords(uLocal_296[0], Var465, 1, 0, 0, 1);
						entity::set_entity_heading(uLocal_296[0], Var0.f_243.f_4);
						entity::set_entity_coords(uLocal_296[1], Var465.f_3, 1, 0, 0, 1);
						entity::set_entity_heading(uLocal_296[1], Var0.f_243.f_4);
					}
					audio::start_audio_scene(func_395(1));
					iVar1773 = 0;
					Var0 = 7;
					break;

				case 1:
					if (gameplay::get_game_timer() - iLocal_324 > 1500) {
						func_392(&Var508.f_57, "DARTS_TITLE", 0, 4000, 12, 2, 0, 0);
						iVar1773++;
					}
					break;

				case 2:
					if (!func_391(&Var508.f_57, 1, 0)) {
						audio::start_audio_scene(func_395(1));
						iVar1773 = 0;
						Var0 = 7;
					}
					break;
				}
				break;

			case 7:
				if (!gameplay::is_bit_set(Global_101661, 0)) {
					if (func_388(&iVar464, &Var0.f_243, &Var0.f_249, &Var0.f_1, &Var0.f_164, &iVar1796)) {
						gameplay::set_bit(&Global_101661, 0);
						Var0 = 8;
					}
				}
				else {
					cam::set_cam_active(iLocal_120, 1);
					Var0 = 8;
				}
				break;

			case 8:
				if (cam::is_screen_faded_out()) {
					cam::do_screen_fade_in(500);
				}
				switch (iVar1773) {
				case 0:
					if (!entity::does_entity_exist(func_479())) {
						if (!gameplay::is_bit_set(Global_101661, 10)) {
							gameplay::set_bit(&Global_101661, 10);
						}
						else {
							gameplay::clear_bit(&Global_101661, 10);
						}
						func_386(&Var508);
						iVar1773++;
					}
					else {
						func_386(&Var508);
						iVar1773++;
					}
					break;

				case 1:
					if (gameplay::is_pc_version()) {
						if (fLocal_134 != graphics::_get_aspect_ratio(0)) {
							fLocal_134 = graphics::_get_aspect_ratio(0);
							cam::set_cam_fov(iLocal_120, func_385(fLocal_134));
							cam::set_cam_fov(iLocal_121, func_385(fLocal_134));
						}
					}
					if (func_325(&Var508, &Var0.f_452, &Var0.f_453)) {
						audio::stop_audio_scene(func_395(1));
						if (Var0.f_452 > 0) {
							iVar1773 = 0;
							if (Var0.f_452 > 1 || Var0.f_453 > 1) {
								func_324(&Var477, 0, 0, 0, 0);
								iVar1768 = 1;
							}
							func_321(1, -1);
							Var0 = 9;
						}
						else if (Var0.f_452 < 0) {
							Var0 = 15;
						}
					}
					break;
				}
				break;

			case 9:
				if (func_314(&Var0, &Var477, &Var508)) {
					Var0.f_249.f_4 = 1;
					if (Global_101700.f_17929.f_5 >= 5 && Global_101700.f_17929.f_7 >= 0.8f) {
						Var0.f_249.f_4 = 2;
					}
					else if (Global_101700.f_17929.f_5 >= 3 && Global_101700.f_17929.f_7 >= 0.66f) {
						Var0.f_249.f_4 = 1;
					}
					else {
						Var0.f_249.f_4 = 0;
					}
					if (func_313(Global_101700.f_17929.f_5, &iLocal_327)) {
						func_312(&Var508.f_666, 24, 1);
					}
					fLocal_90 = func_311(Global_101700.f_17929.f_5);
					fLocal_91 = func_310(Global_101700.f_17929.f_5);
					fLocal_88 = fLocal_90;
					fLocal_89 = fLocal_91;
					iLocal_151[4]++;
					if (!ped::is_ped_injured(uLocal_296[1])) {
						ai::clear_ped_tasks_immediately(uLocal_296[1]);
						entity::set_entity_coords(uLocal_296[1], Var465.f_3, 1, 0, 0, 1);
						entity::set_entity_heading(uLocal_296[1], Var0.f_243.f_4);
					}
					if (func_401(&iVar1793)) {
						func_402(&iVar1793);
					}
					audio::start_audio_scene(func_395(2));
					func_309(uLocal_296[1]);
					Var0 = 10;
					Var0.f_1 = 2;
				}
				break;

			case 10:
				if (gameplay::is_pc_version()) {
					if (fLocal_134 != graphics::_get_aspect_ratio(0)) {
						fLocal_134 = graphics::_get_aspect_ratio(0);
						cam::set_cam_fov(iLocal_120, func_385(fLocal_134));
						cam::set_cam_fov(iLocal_121, func_385(fLocal_134));
					}
				}
				if (!bLocal_316) {
					streaming::request_anim_dict("mini@dartsoutro");
					bLocal_316 = true;
				}
				if (!iLocal_317) {
					if (bLocal_316) {
						if (!streaming::has_anim_dict_loaded("mini@dartsoutro")) {
						}
						else {
							iLocal_317 = 1;
						}
					}
				}
				func_227(&Var0, &vVar471, &Var477, &Var508, &iVar1793);
				break;

			case 11:
				switch (iVar1773) {
				case 0:
					if (func_404(&Var0.f_254) > 0.5f) {
						ui::clear_help(1);
						ui::clear_prints();
						func_226(player::player_ped_id());
						func_324(&Var477, Var0.f_449[0], Var0.f_449[1], Var0.f_446[0], Var0.f_446[1]);
						iVar1827 = 0;
						while (iVar1827 < 2) {
							iVar1828 = 0;
							while (iVar1828 < 3) {
								func_225(&Var0.f_5[iVar1827 /*79*/][iVar1828 /*26*/]);
								iVar1828++;
							}
							func_224(&Var477, iVar1827);
							iVar1827++;
						}
						if (Var0.f_459) {
							if (Var0.f_454) {
								func_222(&Var508.f_62, "DARTS_WINNER", "DARTS_SETW", 4000, 5, 12);
							}
							else {
								func_222(&Var508.f_62, "DARTS_LOSER", "DARTS_SETL", 4000, 5, 6);
							}
							Var0.f_459 = 0;
						}
						else if (Var0.f_454) {
							func_222(&Var508.f_62, "DARTS_WINNER", "DARTS_LEGW", 4000, 5, 12);
						}
						else {
							func_222(&Var508.f_62, "DARTS_LOSER", "DARTS_LEGL", 4000, 5, 6);
						}
						fVar1830 = graphics::_get_aspect_ratio(1);
						if (fVar1830 > 2f) {
							vVar1786 = {1992.294f, 3047.577f, 46.21517f};
							vVar1789 = {0f, 0f, 138.74f};
						}
						else {
							vVar1786 = {1992.336f, 3047.924f, 46.21517f};
							vVar1789 = {0f, 0f, 136.74f};
						}
						iVar1829 = func_221();
						iLocal_328 = ped::create_synchronized_scene(vVar1786, vVar1789, 2);
						iLocal_334 = cam::create_cam("DEFAULT_ANIMATED_CAMERA", 0);
						cam::play_synchronized_cam_anim(iLocal_334, iLocal_328, sLocal_408[iVar1829],
														"mini@dartsoutro");
						cam::set_cam_active(iLocal_334, 1);
						cam::render_script_cams(1, 0, 3000, 1, 0, 0);
						if (!ped::is_ped_injured(uLocal_296[0]) && !ped::is_ped_injured(uLocal_296[1])) {
							if (Var0.f_454) {
								if (Var0.f_437[0] + Var0.f_437[1] == 1) {
									iVar1831 = 1;
								}
								else {
									iVar1831 = 0;
								}
								audio::play_sound_frontend(-1, "TENNIS_POINT_WON", "HUD_AWARDS", 1);
								func_220(&uLocal_296, iVar1831);
								ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsoutro",
															sLocal_400[iVar1829], 1000f, -1.5f, 0, 0, 1148846080, 0);
								ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsoutro",
															sLocal_404[iVar1829], 1000f, -1.5f, 0, 0, 1148846080, 0);
								ai::task_play_anim(player::player_ped_id(), sLocal_395,
												   sLocal_396[gameplay::get_random_int_in_range(0, 3)], 4f, -4f, -1, 32,
												   0, 0, 0, 0);
							}
							else {
								audio::play_sound_frontend(-1, "OTHER_TEXT", "HUD_AWARDS", 1);
								func_219(&uLocal_296);
								ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsoutro",
															sLocal_400[iVar1829], 1000f, -1.5f, 0, 0, 1148846080, 0);
								ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsoutro",
															sLocal_404[iVar1829], 1000f, -1.5f, 0, 0, 1148846080, 0);
								ai::task_play_anim(uLocal_296[1], sLocal_394,
												   sLocal_396[gameplay::get_random_int_in_range(0, 3)], 4f, -4f, -1, 32,
												   0, 0, 0, 0);
							}
						}
						iVar1773++;
					}
					break;

				case 1:
					if (!func_217(&Var508.f_62, 1)) {
						iVar1773++;
					}
					break;

				case 2:
					func_402(&Var0.f_254);
					iLocal_312 = 0;
					audio::stop_audio_scene(func_395(3));
					func_394();
					if (cam::does_cam_exist(iLocal_334)) {
						cam::destroy_cam(iLocal_334, 0);
					}
					iVar1773 = 0;
					Var0 = 9;
					break;
				}
				break;

			case 12:
				if (func_404(&Var0.f_254) > 0.92f) {
					func_39(&Var0, &Var508, &Var477, &Var1191, iVar1768);
				}
				break;

			case 13:
				iVar1771 = func_10(&Var1191, 0, 1065353216, 0, 0, 0);
				if (!entity::is_entity_dead(func_479(), 0)) {
					ai::clear_ped_tasks(uLocal_296[1]);
					Var0 = 15;
				}
				switch (iVar1773) {
				case 0:
					ai::clear_ped_tasks(uLocal_296[0]);
					if (!iLocal_314) {
						cam::render_script_cams(0, iLocal_314, 3000, 1, 0, 0);
					}
					else {
						cam::_0xC819F3CBB62BF692(0, 0, 3, 0);
					}
					cam::set_gameplay_cam_relative_heading(0f);
					cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
					player::set_player_control(player::player_id(), 1, 0);
					ui::clear_prints();
					ai::task_look_at_entity(uLocal_296[0], uLocal_296[1], 5000, 2049, 3);
					func_415(&iVar1799);
					iVar1773++;
					break;

				case 1:
					if (func_7(&iVar1799) > 0.1f) {
						if (!iVar1767) {
						}
						func_415(&iVar1799);
						iVar1773++;
					}
					break;

				case 2:
					if (func_7(&iVar1799) > 0.3f) {
						if (!ped::is_ped_injured(uLocal_296[1])) {
							if (!iVar1767) {
								func_4(uLocal_296[0], "GENERIC_THANKS", 1, 4);
							}
						}
						func_415(&iVar1799);
						iVar1773++;
					}
					break;

				case 3:
					if (iVar1771 || iVar1767) {
						Var0 = 15;
						iVar1773++;
					}
					break;
				}
				break;

			case 14:
				func_2(&Var508);
				if (controls::is_control_just_released(2, 201)) {
					func_1(uLocal_296[1]);
					iLocal_331 = 2;
					iVar1767 = 1;
					if (audio::is_audio_scene_active(func_395(2))) {
						audio::stop_audio_scene(func_395(2));
					}
					Var0 = 13;
				}
				if (controls::is_control_just_released(2, 202)) {
					if (Var0.f_1 == 2) {
						iLocal_100 = 0;
					}
					func_312(&Var508.f_666, 8, 0);
					Var0 = 10;
				}
				break;

			case 15: func_449(&Var0, &Var508, &Var1191); break;
			}
		}
	}
}

// Position - 0x1E0C
void func_1(int iParam0) {
	if (!ped::is_ped_injured(iParam0)) {
		func_4(iParam0, "GAME_QUIT_EARLY", 0, 6);
	}
}

// Position - 0x1E2A
void func_2(var *uParam0) {
	if (!ui::is_pause_menu_active()) {
		if (!func_3(&uParam0->f_666, 8)) {
			func_312(&uParam0->f_666, 8, 1);
			func_312(&uParam0->f_666, 15, 0);
			func_312(&uParam0->f_666, 16, 0);
			func_312(&uParam0->f_666, 17, 0);
		}
		ui::clear_small_prints();
		ui::_set_warning_message_2("DARTS_QUIT", "DARTS_QUIT_DET", 36, 0, 0, -1, 0, 0, 1);
	}
	else if (func_3(&uParam0->f_666, 8)) {
		func_312(&uParam0->f_666, 8, 0);
	}
}

// Position - 0x1EAE
bool func_3(var *uParam0, int iParam1) { return gameplay::is_bit_set(*uParam0, iParam1); }

// Position - 0x1EBF
void func_4(int iParam0, char *sParam1, int iParam2, int iParam3) {
	if (!entity::is_entity_dead(func_479(), 0) || iParam2) {
		func_403(iParam0, sParam1, iParam3);
	}
	else if (!ped::is_ped_injured(iParam0)) {
		func_5(iParam0, sParam1, sLocal_102, iParam3);
	}
}

// Position - 0x1EFF
void func_5(int iParam0, char *sParam1, char *sParam2, int iParam3) {
	audio::_play_ambient_speech_with_voice(iParam0, sParam1, sParam2, func_6(iParam3), 0);
}

// Position - 0x1F18
int func_6(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: return "SPEECH_PARAMS_STANDARD";

	case 1: return "SPEECH_PARAMS_ALLOW_REPEAT";

	case 2: return "SPEECH_PARAMS_BEAT";

	case 3: return "SPEECH_PARAMS_FORCE";

	case 4: return "SPEECH_PARAMS_FORCE_FRONTEND";

	case 5: return "SPEECH_PARAMS_FORCE_NO_REPEAT_FRONTEND";

	case 6: return "SPEECH_PARAMS_FORCE_NORMAL";

	case 7: return "SPEECH_PARAMS_FORCE_NORMAL_CLEAR";

	case 8: return "SPEECH_PARAMS_FORCE_NORMAL_CRITICAL";

	case 9: return "SPEECH_PARAMS_FORCE_SHOUTED";

	case 10: return "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR";

	case 11: return "SPEECH_PARAMS_FORCE_SHOUTED_CRITICAL";

	case 12: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY";

	case 13: return "SPEECH_PARAMS_MEGAPHONE";

	case 14: return "SPEECH_PARAMS_HELI";

	case 15: return "SPEECH_PARAMS_FORCE_MEGAPHONE";

	case 16: return "SPEECH_PARAMS_FORCE_HELI";

	case 17: return "SPEECH_PARAMS_INTERRUPT";

	case 18: return "SPEECH_PARAMS_INTERRUPT_SHOUTED";

	case 19: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CLEAR";

	case 20: return "SPEECH_PARAMS_INTERRUPT_SHOUTED_CRITICAL";

	case 21: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE";

	case 22: return "SPEECH_PARAMS_INTERRUPT_FRONTEND";

	case 23: return "SPEECH_PARAMS_INTERRUPT_NO_FORCE_FRONTEND";

	case 24: return "SPEECH_PARAMS_ADD_BLIP";

	case 25: return "SPEECH_PARAMS_ADD_BLIP_ALLOW_REPEAT";

	case 26: return "SPEECH_PARAMS_ADD_BLIP_FORCE";

	case 27: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED";

	case 28: return "SPEECH_PARAMS_ADD_BLIP_SHOUTED_FORCE";

	case 29: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT";

	case 30: return "SPEECH_PARAMS_ADD_BLIP_INTERRUPT_FORCE";

	case 31: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED";

	case 32: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CLEAR";

	case 33: return "SPEECH_PARAMS_FORCE_PRELOAD_ONLY_SHOUTED_CRITICAL";

	case 34: return "SPEECH_PARAMS_SHOUTED";

	case 35: return "SPEECH_PARAMS_SHOUTED_CLEAR";

	case 36: return "SPEECH_PARAMS_SHOUTED_CRITICAL";

	default:
	}
	iVar0 = 0;
	return iVar0;
}

// Position - 0x210D
float func_7(int *iParam0) {
	if (func_401(iParam0)) {
		if (func_9(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_8(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return iParam0->f_1;
}

// Position - 0x214C
float func_8(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0x21A4
bool func_9(int *iParam0) { return gameplay::is_bit_set(*iParam0, 2); }

// Position - 0x21B4
int func_10(var *uParam0, int iParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (gameplay::get_frame_count() == uParam0->f_574) {
		return uParam0->f_575;
	}
	uParam0->f_574 = gameplay::get_frame_count();
	if (!network::network_is_game_in_progress()) {
		if (ped::is_ped_dead_or_dying(player::get_player_ped(player::get_player_index()), 1)) {
			uParam0->f_575 = 1;
			return 1;
		}
		if (ai::is_ped_being_arrested(player::get_player_ped(player::get_player_index()))) {
			uParam0->f_575 = 1;
			return 1;
		}
	}
	if (!uParam0->f_564) {
		if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
			script::set_no_loading_screen(1);
			uParam0->f_564 = 1;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (!network::network_is_game_in_progress()) {
			if (player::is_special_ability_active(player::player_id())) {
				player::special_ability_deactivate(player::player_id());
			}
		}
	}
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(19);
	controls::disable_control_action(2, 19, 1);
	controls::disable_control_action(0, 37, 1);
	controls::disable_control_action(0, 21, 1);
	controls::disable_control_action(0, 28, 1);
	controls::disable_control_action(0, 29, 1);
	controls::disable_control_action(0, 171, 1);
	func_37();
	if (controls::_is_input_disabled(2)) {
		if (player::_is_player_cam_control_disabled() || cam::is_screen_faded_out() && !cam::is_screen_fading_in()) {
			ui::_show_cursor_this_frame();
		}
	}
	Global_36331 = 1;
	if (!uParam0->f_563) {
		switch (func_481(player::get_player_ped(player::get_player_index()))) {
		case 1: graphics::_start_screen_effect("SuccessFranklin", 1000, 0); break;

		case 2: graphics::_start_screen_effect("SuccessTrevor", 1000, 0); break;

		default: graphics::_start_screen_effect("SuccessMichael", 1000, 0); break;
		}
		uParam0->f_563 = 1;
	}
	if (uParam0->f_558 == 0) {
		uParam0->f_558 = uParam0->f_572 + system::floor(15000f * fParam2);
	}
	if (iParam4 && uParam0->f_572 >= uParam0->f_558 - 1500) {
		uParam0->f_558 = uParam0->f_572 + 3000;
	}
	if (uParam0->f_560 == 0f) {
		uParam0->f_560 += func_36(30f);
		uParam0->f_560 += IntToFloat(uParam0->f_56) * func_36(25f);
		if (uParam0->f_56 > 0) {
			uParam0->f_560 += func_36(25f * 0.5f);
		}
		if (uParam0->f_549) {
			uParam0->f_560 += func_36(30f) - func_36(2f);
		}
	}
	iVar0 = 1;
	while (iVar0) {
		func_35(1);
		uParam0->f_572 += system::round(0f + 1000f * system::timestep());
		func_15(uParam0, fParam2, iParam3);
		if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 666) - 15000f * fParam2) {
			if (uParam0->f_30 < 1f) {
				uParam0->f_30 += 0f + 1f / 0.225f * system::timestep();
			}
		}
		uParam0->f_30 = func_14(uParam0->f_30, 0f, 1f);
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_565) {
					uParam0->f_565 = 0;
					uParam0->f_566 = 0;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_547 -= (0f + 1f / 1.215f * system::timestep());
			}
		}
		uParam0->f_547 = func_14(uParam0->f_547, 0f, 1f);
		if (uParam0->f_547 <= 0.7f && !uParam0->f_545 && uParam0->f_1 != 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_OUT");
			graphics::_pop_scaleform_movie_function_void();
			uParam0->f_546 = uParam0->f_572;
			uParam0->f_545 = 1;
		}
		if (uParam0->f_572 > uParam0->f_558 - 333) {
			if (!uParam0->f_561) {
				if (uParam0->f_548 < 1f) {
					uParam0->f_548 += 0f + 1f / 0.3f * system::timestep();
				}
			}
		}
		uParam0->f_548 = func_14(uParam0->f_548, 0f, 1f);
		if (uParam0->f_562) {
			if (controls::_0x6CD79468A1E595C6(2)) {
				if (graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
					if (!uParam0->f_567) {
						func_11(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
					}
				}
			}
		}
		if (controls::is_control_just_pressed(2, 216) && uParam0->f_558 > uParam0->f_572 + 333) {
			if (!uParam0->f_566 && uParam0->f_56 != 0 && graphics::has_scaleform_movie_loaded(uParam0->f_4) &&
				IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (!uParam0->f_565) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					if (uParam0->f_572 > uParam0->f_558 - 5000) {
						uParam0->f_558 = uParam0->f_572 + 5000;
					}
				}
				else if (iParam5) {
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_UP_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
					uParam0->f_565 = 0;
					uParam0->f_573 = 0.75f;
				}
				func_11(uParam0, !uParam0->f_565 && uParam0->f_56 > 0);
			}
		}
		if ((uParam0->f_565 || uParam0->f_566) && uParam0->f_56 != 0) {
			if (IntToFloat(uParam0->f_572) > IntToFloat(uParam0->f_558 + 1165) - 15000f * fParam2) {
				if (uParam0->f_566 && !uParam0->f_565) {
					uParam0->f_565 = 1;
					uParam0->f_573 = 0.75f;
					graphics::_push_scaleform_movie_function(uParam0->f_1, "ROLL_DOWN_BACKGROUND");
					graphics::_pop_scaleform_movie_function_void();
				}
				uParam0->f_559 = func_14(uParam0->f_559 + 1f / 0.3f * uParam0->f_573 * system::timestep(), 0f, 1f);
				uParam0->f_573 = func_14(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
			}
		}
		else {
			uParam0->f_559 = func_14(uParam0->f_559 - 1f / 0.3f * uParam0->f_573 * 0.01f * system::timestep(), 0f, 1f);
			uParam0->f_573 = func_14(uParam0->f_573 + 0.07f, 0.75f, 1.15f);
		}
		if (uParam0->f_572 > uParam0->f_558) {
			if (uParam0->f_561) {
				if (!uParam0->f_567) {
					if (controls::is_control_just_pressed(2, 215)) {
						uParam0->f_561 = 0;
					}
				}
			}
			else if (uParam0->f_572 - uParam0->f_546 > 1000 && uParam0->f_545) {
				iVar0 = 0;
			}
		}
		uParam0->f_575 = !iVar0;
		if (iParam1) {
			system::wait(0);
		}
		else {
			if (!iVar0) {
				func_35(0);
			}
			return !iVar0;
		}
	}
	func_35(0);
	return 1;
}

// Position - 0x280C
void func_11(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_13(controls::get_control_instructional_button(2, 215, 1));
	func_12("ES_HELP");
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_push_scaleform_movie_function_parameter_int(215);
	}
	graphics::_pop_scaleform_movie_function_void();
	if (iParam1) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(1);
		func_13(controls::get_control_instructional_button(2, 216, 1));
		func_12("ES_XPAND");
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function_parameter_bool(1);
			graphics::_push_scaleform_movie_function_parameter_int(216);
		}
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x28D0
void func_12(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x28E2
void func_13(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x28F0
float func_14(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x2917
void func_15(var *uParam0, float fParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	float fVar18;
	float *fVar19;
	float fVar20;
	float fVar21;
	float fVar22;
	char cVar23[16];
	char cVar27[32];
	int iVar35;
	int iVar36;
	int iVar37;
	int iVar38;
	float fVar39;
	float fVar40;
	float fVar41;
	float fVar42;
	float fVar43;

	iVar0 = system::round(uParam0->f_547 * 255f);
	fVar1 = func_34() * 0.25f;
	if (graphics::has_scaleform_movie_loaded(uParam0->f_1)) {
		if (uParam0->f_30 >= 0f) {
			if (!uParam0->f_2) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "SHOW_MISSION_PASSED_MESSAGE");
				func_12(&uParam0->f_5);
				func_12(&uParam0->f_13);
				if (network::network_is_game_in_progress()) {
					graphics::_push_scaleform_movie_function_parameter_int(150);
				}
				else {
					graphics::_push_scaleform_movie_function_parameter_int(100);
				}
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_56);
				graphics::_push_scaleform_movie_function_parameter_bool(iParam2);
				graphics::_push_scaleform_movie_function_parameter_int(69);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_2 = 1;
			}
			if (uParam0->f_56 > 0 && !uParam0->f_3 && uParam0->f_572 > 600) {
				graphics::_push_scaleform_movie_function(uParam0->f_1, "TRANSITION_UP");
				graphics::_push_scaleform_movie_function_parameter_float(0.15f);
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
				uParam0->f_3 = 1;
			}
		}
		func_33();
		graphics::draw_scaleform_movie_fullscreen(uParam0->f_1, 255, 255, 255, 255, 0);
	}
	fVar2 = uParam0->f_560 * uParam0->f_559 * (1f - uParam0->f_548);
	fVar3 = 0f;
	if (uParam0->f_567) {
		fVar3 = (0.1388889f + func_36(2f * 2f)) * uParam0->f_568 * (1f - uParam0->f_548);
		fVar2 += 3f * fVar3;
	}
	if (uParam0->f_548 != 0f) {
		fVar4 = 0f;
		if (fVar2 < fVar4) {
			fVar2 = fVar4;
		}
	}
	else {
		fVar5 = 0f;
		if (uParam0->f_30 >= 0.975f) {
			if (fVar2 < fVar5) {
				fVar2 = fVar5;
			}
		}
	}
	fVar1 = 0.3f * func_34();
	if (uParam0->f_12) {
		fVar1 = 0.5f;
	}
	fVar6 = *uParam0 * 2f;
	fVar7 = func_32(&uParam0->f_13);
	if (fVar6 < fVar7) {
		fVar6 = fVar7 + 3f * 0.006f;
	}
	if (graphics::_get_aspect_ratio(0) < 1.4f) {
		fVar6 *= 1.3f;
	}
	fVar7 = func_32(&uParam0->f_550);
	fVar8 = (0.119f + 0.05f) / func_34() / 2.5f;
	if ((uParam0->f_556 == 1 || uParam0->f_556 == 0) && uParam0->f_557 != 0) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (uParam0->f_556 == 3) {
		if (fVar6 < fVar7 + 2.6f * fVar8) {
			fVar6 = fVar7 + 2.6f * fVar8;
		}
	}
	else if (fVar6 < fVar7 + 1.9f * fVar8) {
		fVar6 = fVar7 + 2f * fVar8;
	}
	fVar9 = 0.499f - fVar6 / 2f + 0.006f;
	fVar10 = 0.499f + fVar6 / 2f - 0.006f;
	controls::set_input_exclusive(2, 215);
	controls::set_input_exclusive(2, 216);
	controls::set_input_exclusive(2, 200);
	controls::disable_control_action(2, 200, 1);
	if (uParam0->f_562 || uParam0->f_567) {
		if (IntToFloat(uParam0->f_558) - 14000f * fParam1 < IntToFloat(uParam0->f_572) ||
			uParam0->f_567 && uParam0->f_559 > 0.95f && uParam0->f_558 - 10000 < uParam0->f_572) {
			if (uParam0->f_567) {
				if (uParam0->f_570 < 0) {
					uParam0->f_570 *= -1;
					uParam0->f_570 = uParam0->f_572 + uParam0->f_570;
				}
				if (uParam0->f_570 > 0) {
					if (uParam0->f_570 - uParam0->f_572 > 0) {
						func_29(uParam0->f_570 - uParam0->f_572, "TIMER_TIME", 0, 0, -1, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0,
								0, 0);
					}
					else {
						uParam0->f_570 = 0;
						uParam0->f_569 = 1;
						uParam0->f_567 = 0;
						uParam0->f_561 = 0;
						uParam0->f_562 = 0;
						uParam0->f_558 = uParam0->f_572 + 500;
						uParam0->f_570 = 0;
					}
				}
				if (uParam0->f_568 < 1f) {
					uParam0->f_568 += 0f + 1f / 0.166f * system::timestep();
					if (uParam0->f_568 > 1f) {
						uParam0->f_568 = 1f;
					}
				}
			}
			if (cam::is_screen_faded_out()) {
				ui::hide_loading_on_fade_this_frame();
			}
			if (uParam0->f_4 != 0 && uParam0->f_548 < 0.1f && uParam0->f_572 <= uParam0->f_558) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				graphics::draw_scaleform_movie_fullscreen(uParam0->f_4, 255, 255, 255, iVar0, 0);
			}
			if (uParam0->f_567) {
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				controls::disable_control_action(2, 188, 1);
				if (controls::is_disabled_control_just_pressed(2, 188)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 3;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 187, 1);
				if (controls::is_disabled_control_just_pressed(2, 187)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 4;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
				controls::disable_control_action(2, 202, 1);
				if (controls::is_disabled_control_just_pressed(2, 202)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_567 = 0;
					uParam0->f_561 = 0;
					uParam0->f_562 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					uParam0->f_569 = 2;
					uParam0->f_570 = 0;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
			else if (uParam0->f_562) {
				ui::hide_hud_component_this_frame(7);
				ui::hide_hud_component_this_frame(8);
				ui::hide_hud_component_this_frame(9);
				ui::hide_hud_component_this_frame(6);
				controls::disable_control_action(0, 140, 1);
				controls::disable_control_action(0, 141, 1);
				controls::disable_control_action(0, 142, 1);
				if (controls::is_control_just_pressed(2, 215) || controls::is_disabled_control_just_pressed(2, 200)) {
					audio::play_sound_frontend(-1, "CONTINUE", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
					uParam0->f_562 = 0;
					uParam0->f_561 = 0;
					uParam0->f_558 = uParam0->f_572 + 500;
					audio::play_sound_frontend(-1, "continue", "HUD_FRONTEND_DEFAULT_SOUNDSET", 0);
				}
			}
		}
	}
	ui::get_hud_colour(1, &iVar13, &iVar14, &iVar15, &iVar16);
	ui::set_text_colour(iVar13, iVar14, iVar15, iVar0);
	ui::set_text_wrap(fVar9, fVar10);
	ui::set_text_justification(0);
	ui::set_text_scale(1f, 0.4f);
	fVar1 -= func_36(6f);
	fVar1 += func_36(30f) - func_36(2f * 2f);
	fVar11 = fVar2 - func_36(2f * 14f);
	if (fVar11 >= 0f) {
		fVar12 = func_14(fVar11 / (0.6f * func_36(25f)), 0f, 1f);
		func_33();
		graphics::draw_rect(0.5f, fVar1 - (func_36(2f - 0.5f) - 0.001388889f), fVar6, func_28(1f), iVar13, iVar14,
							iVar15, system::round(fVar12 * IntToFloat(iVar16)), 0);
	}
	else {
		return;
	}
	fVar1 += func_36(2f * 0.3f);
	if (uParam0->f_56 > 0) {
		fVar1 += func_36(25f * 0.2f);
	}
	iVar17 = 0;
	iVar17 = 0;
	while (iVar17 < uParam0->f_56) {
		fVar11 = fVar2 - (fVar1 - 0.3f * func_34());
		if (fVar11 >= 0f) {
			fVar12 = func_14(fVar11 / (0.8f * func_36(25f)), 0f, 1f);
			func_25(uParam0, iVar17, fVar1 + func_36(2f), fVar9, fVar10, system::round(IntToFloat(iVar0) * fVar12));
		}
		else {
			return;
		}
		fVar1 += func_36(25f);
		iVar17++;
	}
	if (uParam0->f_56 > 0) {
		fVar1 += func_36(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_34());
		if (fVar11 >= 0f) {
			fVar1 += func_36(2f);
			fVar12 = func_14(fVar11 / (0.6f * func_36(25f)), 0f, 1f);
			func_33();
			graphics::draw_rect(0.5f, fVar1 + func_36(2f * 0.5f), fVar6, func_28(1f), iVar13, iVar14, iVar15,
								system::round(fVar12 * IntToFloat(iVar16)), 0);
		}
	}
	if (uParam0->f_549) {
		fVar1 += func_36(25f * 0.2f);
		fVar11 = fVar2 - (fVar1 - 0.3f * func_34());
		if (fVar11 >= 0f) {
			fVar12 = func_14(fVar11 / (0.8f * func_36(25f)), 0f, 1f);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			func_18(7, 0, 1, &fVar18, &fVar19, 0);
			fVar20 = fVar9;
			fVar21 = fVar10;
			if (unk::_get_current_language_id() == 0) {
				fVar20 = fVar9 + 0.119f / func_34() / 2.5f;
				fVar21 = fVar10 - 0.119f / func_34() / 2.5f;
				if (uParam0->f_556 == 1) {
					fVar20 = fVar9 + (0.119f + 0.05f) / func_34() / 2.5f;
					fVar21 = fVar10 - (0.119f + 0.05f) / func_34() / 2.5f;
				}
			}
			if (uParam0->f_557 == 0) {
				fVar20 += (fVar18 * 0.28f + 0.006f) / 2f;
				fVar21 += (fVar18 * 0.28f + 0.006f) / 2f;
			}
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(1);
			ui::set_text_scale(1f, 0.4f);
			func_17(&uParam0->f_550, fVar20, fVar1 + func_36(2f * 2f), 0, 0, 0);
			ui::set_text_wrap(fVar20, fVar21);
			ui::set_text_justification(2);
			ui::set_text_scale(1f, 0.4f);
			ui::set_text_centre(0);
			func_33();
			fVar22 = fVar21;
			StringCopy(&cVar23, "MPHud", 16);
			StringCopy(&cVar27, "MissionPassedMedal", 32);
			fVar22 -= (fVar18 * 0.28f + 0.006f);
			ui::set_text_wrap(fVar20, fVar22);
			ui::set_text_colour(iVar13, iVar14, iVar15, system::round(fVar12 * IntToFloat(iVar0)));
			switch (uParam0->f_556) {
			case 0:
				ui::begin_text_command_display_text("PERCENTAGE");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_36(2f * 2f), 0);
				break;

			case 1:
				ui::begin_text_command_display_text("FO_TWO_NUM");
				ui::add_text_component_integer(uParam0->f_554);
				ui::add_text_component_integer(uParam0->f_555);
				ui::end_text_command_display_text(fVar20, fVar1 + func_36(2f * 2f), 0);
				break;

			case 2:
				ui::begin_text_command_display_text("MTPHPER_XPNO");
				ui::add_text_component_integer(uParam0->f_554);
				ui::end_text_command_display_text(fVar20, fVar1 + func_36(2f * 2f), 0);
				break;

			case 3:
				ui::begin_text_command_display_text("ESDOLLA");
				ui::add_text_component_formatted_integer(uParam0->f_554, 1);
				ui::end_text_command_display_text(fVar20, fVar1 + func_36(2f * 2f), 0);
				break;
			}
			if (uParam0->f_557 != 0) {
				iVar35 = 255;
				iVar36 = 255;
				iVar37 = 255;
				iVar38 = iVar0;
				switch (uParam0->f_557) {
				case 1: ui::get_hud_colour(107, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 3: ui::get_hud_colour(109, &iVar35, &iVar36, &iVar37, &iVar38); break;

				case 2: ui::get_hud_colour(108, &iVar35, &iVar36, &iVar37, &iVar38); break;
				}
				fVar39 = 0.001388889f * 5f;
				fVar40 = 0.00078125f * 16f * 2f;
				fVar41 = 0.001388889f * 16f * 2f;
				fVar42 = fVar21 + func_16(4f) - 0.006f;
				fVar43 = fVar1 + func_36(10f) + fVar39;
				if (uParam0->f_556 == -1) {
					fVar42 -= 0.006f * 6f;
				}
				fVar40 *= 0.65f;
				fVar41 *= 0.65f;
				graphics::draw_sprite(&cVar23, &cVar27, fVar42, fVar43, fVar40, fVar41, 0f, iVar35, iVar36, iVar37,
									  system::round(fVar12 * IntToFloat(iVar0)), 0);
			}
			fVar1 += func_36(30f) - 2f;
		}
	}
}

// Position - 0x3469
float func_16(float fParam0) { return fParam0 * 0.00078125f; }

// Position - 0x3479
void func_17(char *sParam0, float fParam1, float fParam2, int iParam3, int iParam4, int iParam5) {
	ui::set_text_centre(iParam3);
	ui::set_text_font(iParam5);
	func_33();
	if (iParam4) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam0);
	}
	else {
		ui::begin_text_command_display_text(sParam0);
	}
	ui::end_text_command_display_text(fParam1, fParam2, 0);
}

// Position - 0x34B6
bool func_18(int iParam0, int iParam1, int iParam2, float fParam3, float *fParam4, int iParam5) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	float fVar36;
	vector3 vVar37;

	StringCopy(&cVar0, func_24(iParam0), 64);
	StringCopy(&cVar16, func_21(iParam0, iParam1), 64);
	if (gameplay::get_hash_key(&cVar16) != 0) {
		fVar34 = 1f;
		if (iParam5) {
			graphics::_get_active_screen_resolution(&iVar32, &iVar33);
			fVar35 = graphics::_get_aspect_ratio(0);
			if (func_20()) {
				iVar32 = system::round(system::to_float(iVar33) * fVar35);
			}
			fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
			fVar34 = fVar36 / fVar35;
			if (func_20()) {
				fVar34 = 1f;
			}
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
				graphics::get_screen_resolution(&iVar32, &iVar33);
			}
			iVar32 = system::round(system::to_float(iVar32) / fVar34);
			iVar33 = system::round(system::to_float(iVar33) / fVar34);
		}
		else {
			graphics::get_screen_resolution(&iVar32, &iVar33);
		}
		vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
		vVar37.x *= func_19(iParam0) / fVar34;
		vVar37.y *= func_19(iParam0) / fVar34;
		if (!iParam2) {
			vVar37.x -= 2f;
			vVar37.y -= 2f;
		}
		if (iParam0 == 30) {
			vVar37.x = 288f;
			vVar37.y = 106f;
		}
		if (iParam0 == 29 && gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
			vVar37.x = 106f;
			vVar37.y = 106f;
		}
		*fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
		*fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) * *fParam3;
		if (!iParam5) {
			if (!graphics::get_is_widescreen() && iParam0 != 30) {
				*fParam3 *= 1.33f;
			}
		}
		if (iParam0 == 29) {
			if (*fParam3 > Global_17289) {
				*fParam4 *= Global_17289 / *fParam3;
				*fParam3 = Global_17289;
			}
		}
		return true;
	}
	return false;
}

// Position - 0x3667
float func_19(int iParam0) {
	switch (iParam0) {
	case 33:
	case 4:
	case 11:
	case 31:
	case 20:
	case 15:
	case 10:
	case 12:
	case 13:
	case 32:
	case 9:
	case 5:
	case 6:
	case 7:
	case 14:
	case 18:
	case 19:
	case 17:
	case 28:
	case 26:
	case 27:
	case 49: return 0.5f;
	}
	return 1f;
}

// Position - 0x3706
bool func_20() {
	int iVar0;
	int iVar1;
	float fVar2;

	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (fVar2 > 3.5f) {
		return true;
	}
	return false;
}

// Position - 0x3738
var func_21(int iParam0, int iParam1) {
	char *sVar0[2];
	var uVar3;
	struct<13> Var19;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_6703[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) == -1487683087) {
			Var19 = {func_23(player::player_id())};
			if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
				return func_22(&uVar3);
			}
		}
		else {
			return func_22(&Global_17290.f_6703[iParam0 /*16*/]);
		}
	}
	switch (iParam0) {
	case 3:
		sVar0[0] = "MP_hostCrown";
		sVar0[1] = "MP_hostCrown";
		break;

	case 21:
		sVar0[0] = "MP_SpecItem_Coke";
		sVar0[1] = "MP_SpecItem_Coke";
		break;

	case 22:
		sVar0[0] = "MP_SpecItem_Heroin";
		sVar0[1] = "MP_SpecItem_Heroin";
		break;

	case 23:
		sVar0[0] = "MP_SpecItem_Weed";
		sVar0[1] = "MP_SpecItem_Weed";
		break;

	case 24:
		sVar0[0] = "MP_SpecItem_Meth";
		sVar0[1] = "MP_SpecItem_Meth";
		break;

	case 25:
		sVar0[0] = "MP_SpecItem_Cash";
		sVar0[1] = "MP_SpecItem_Cash";
		break;

	case 1:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 2:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 4:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 6:
		sVar0[0] = "Shop_Box_CrossB";
		sVar0[1] = "Shop_Box_Cross";
		break;

	case 7:
		sVar0[0] = "Shop_Box_BlankB";
		sVar0[1] = "Shop_Box_Blank";
		break;

	case 5:
		sVar0[0] = "Shop_Box_TickB";
		sVar0[1] = "Shop_Box_Tick";
		break;

	case 8:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 9:
		sVar0[0] = "Shop_Clothing_Icon_B";
		sVar0[1] = "Shop_Clothing_Icon_A";
		break;

	case 10:
		sVar0[0] = "Shop_GunClub_Icon_B";
		sVar0[1] = "Shop_GunClub_Icon_A";
		break;

	case 17:
		sVar0[0] = "Shop_Ammo_Icon_B";
		sVar0[1] = "Shop_Ammo_Icon_A";
		break;

	case 18:
		sVar0[0] = "Shop_Armour_Icon_B";
		sVar0[1] = "Shop_Armour_Icon_A";
		break;

	case 19:
		sVar0[0] = "Shop_Health_Icon_B";
		sVar0[1] = "Shop_Health_Icon_A";
		break;

	case 20:
		sVar0[0] = "Shop_MakeUp_Icon_B";
		sVar0[1] = "Shop_MakeUp_Icon_A";
		break;

	case 11:
		sVar0[0] = "Shop_Tattoos_Icon_B";
		sVar0[1] = "Shop_Tattoos_Icon_A";
		break;

	case 12:
		sVar0[0] = "Shop_Garage_Icon_B";
		sVar0[1] = "Shop_Garage_Icon_A";
		break;

	case 13:
		sVar0[0] = "Shop_Garage_Bike_Icon_B";
		sVar0[1] = "Shop_Garage_Bike_Icon_A";
		break;

	case 14:
		sVar0[0] = "Shop_Barber_Icon_B";
		sVar0[1] = "Shop_Barber_Icon_A";
		break;

	case 15:
		sVar0[0] = "shop_Lock";
		sVar0[1] = "shop_Lock";
		break;

	case 16:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 26:
		sVar0[0] = "arrowleft";
		sVar0[1] = "arrowleft";
		break;

	case 27:
		sVar0[0] = "arrowright";
		sVar0[1] = "arrowright";
		break;

	case 28:
		sVar0[0] = "MP_AlertTriangle";
		sVar0[1] = "MP_AlertTriangle";
		break;

	case 29:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 31:
		sVar0[0] = "Shop_Michael_Icon_B";
		sVar0[1] = "Shop_Michael_Icon_A";
		break;

	case 32:
		sVar0[0] = "Shop_Franklin_Icon_B";
		sVar0[1] = "Shop_Franklin_Icon_A";
		break;

	case 33:
		sVar0[0] = "Shop_Trevor_Icon_B";
		sVar0[1] = "Shop_Trevor_Icon_A";
		break;

	case 48:
		sVar0[0] = "SaleIcon";
		sVar0[1] = "SaleIcon";
		break;

	case 49:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 0:
		sVar0[0] = "";
		sVar0[1] = "";
		break;
	}
	if (iParam1) {
		return sVar0[0];
	}
	return sVar0[1];
}

// Position - 0x3B6F
var func_22(var uParam0) { return uParam0; }

// Position - 0x3B79
struct<13> func_23(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

// Position - 0x3B90
char *
func_24(int iParam0) {
	var uVar0;
	struct<13> Var16;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5886[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) == -1487683087) {
			Var16 = {func_23(player::player_id())};
			network::_0x5835D9CD92E83184(&Var16, &uVar0);
			return func_22(&uVar0);
		}
		else {
			return func_22(&Global_17290.f_5886[iParam0 /*16*/]);
		}
	}
	if (iParam0 == 48) {
		return "MPShopSale";
	}
	return "CommonMenu";
}

// Position - 0x3C05
void func_25(var *uParam0, int iParam1, float fParam2, float fParam3, float fParam4, int iParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &uVar3);
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	ui::set_text_wrap(fParam3, fParam4);
	ui::set_text_justification(1);
	ui::set_text_scale(1f, func_27(14f));
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_33();
	if (uParam0->f_531[iParam1]) {
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(&uParam0->f_71[iParam1 /*16*/]);
	}
	else {
		ui::begin_text_command_display_text(&uParam0->f_71[iParam1 /*16*/]);
		if (uParam0->f_57[iParam1] == 16 || uParam0->f_57[iParam1] == 17) {
			ui::add_text_component_integer(uParam0->f_489[iParam1]);
		}
	}
	ui::end_text_command_display_text(fParam3, fParam2, 0);
	fVar4 = fParam4;
	switch (uParam0->f_517[iParam1]) {
	case 0: break;

	case 1:
		func_18(7, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_21(7, 0), fParam4 - 0.006f, fParam2 + func_36(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 2:
		func_18(5, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_21(5, 0), fParam4 - 0.006f, fParam2 + func_36(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;

	case 3:
		func_18(6, 0, 1, &fVar5, &fVar6, 0);
		graphics::draw_sprite("CommonMenu", func_21(6, 0), fParam4 - 0.006f, fParam2 + func_36(2f) + 0.25f * fVar6,
							  fVar5, fVar6, 0f, 255, 255, 255, iParam5, 0);
		fVar4 -= (fVar5 * 0.38f + 0.006f);
		break;
	}
	if (uParam0->f_57[iParam1] == 0) {
		return;
	}
	if (uParam0->f_57[iParam1] == 15) {
		ui::set_text_justification(1);
	}
	else {
		ui::set_text_justification(2);
	}
	ui::set_text_scale(1f, func_27(14f));
	if (uParam0->f_57[iParam1] == 5 || uParam0->f_57[iParam1] == 4) {
		ui::set_text_wrap(fParam3, fVar4 - 0.00078125f * 3f);
	}
	else {
		ui::set_text_wrap(fParam3, fVar4 + 0.00078125f * 2f);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, iParam5);
	func_26(uParam0->f_489[iParam1], uParam0->f_503[iParam1], fParam4, fParam2, &uParam0->f_280[iParam1 /*16*/],
			uParam0->f_57[iParam1]);
}

// Position - 0x3E90
void func_26(int iParam0, int iParam1, float fParam2, float fParam3, char *sParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = 1;
	ui::set_text_centre(0);
	ui::set_text_font(0);
	func_33();
	fVar1 = 0f;
	fVar2 = 8f * 0.00078125f;
	fVar3 = 16f * 0.001388889f;
	iVar4 = 93;
	iVar5 = 182;
	iVar6 = 229;
	if (iParam5 == 4) {
		iVar4 = 194;
		iVar5 = 80;
		iVar6 = 80;
	}
	switch (iParam5) {
	case 4:
	case 5:
		ui::set_text_scale(1f, func_27(18f));
		ui::set_text_font(4);
		if (iParam0 < 0) {
			ui::_begin_text_command_width("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		else {
			ui::_begin_text_command_width("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
			fVar1 = ui::_end_text_command_get_width(0);
		}
		fVar1 -= fVar1 % 0.00078125f;
		graphics::draw_sprite("CommonMenu", "BettingBox_Left", fParam2 - fVar1,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Centre", fParam2 - fVar1 * 0.5f - 0.00078125f * 2f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar1 - fVar2 * 0.5f, fVar3, 0f, iVar4, iVar5,
							  iVar6, 255, 0);
		graphics::draw_sprite("CommonMenu", "BettingBox_Right", fParam2 - 0.00078125f * 4f,
							  fParam3 + fVar3 * 0.6f + 0.001388889f * 2f, fVar2, fVar3, 0f, iVar4, iVar5, iVar6, 255,
							  0);
		ui::set_text_scale(1f, func_27(14f));
		break;
	}
	ui::_set_notification_color_next(iVar0);
	switch (iParam5) {
	case 11:
		ui::begin_text_command_display_text("PERCENTAGE");
		ui::add_text_component_integer(iParam0);
		break;

	case 1:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_NUM");
		ui::add_text_component_integer(iParam0);
		break;

	case 2:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("FO_TWO_NUM");
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 4:
	case 5: ui::set_text_scale(1f, func_27(18f));

	case 3:
		if (iParam0 < 0) {
			ui::begin_text_command_display_text("ESMINDOLLA");
			ui::add_text_component_formatted_integer(-1 * iParam0, 1);
		}
		else {
			ui::begin_text_command_display_text("ESDOLLA");
			ui::add_text_component_formatted_integer(iParam0, 1);
		}
		break;

	case 6: ui::begin_text_command_display_text(sParam4); break;

	case 7:
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_player_name(sParam4);
		break;

	case 8:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 14);
		break;

	case 9:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 6);
		break;

	case 10:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 18:
		ui::set_text_font(5);
		ui::begin_text_command_display_text("STRING");
		ui::add_text_component_substring_time(iParam0, 2055);
		break;

	case 12:
		ui::begin_text_command_display_text("AHD_DIST");
		ui::add_text_component_integer(iParam0);
		break;

	case 13:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 15:
	case 14:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam0);
		ui::add_text_component_integer(iParam1);
		break;

	case 16:
		ui::begin_text_command_display_text(sParam4);
		ui::add_text_component_integer(iParam1);
		break;
	}
	if (iParam5 != 17) {
		if (iParam5 == 4 || iParam5 == 5) {
			ui::end_text_command_display_text(fParam2 - 0.00078125f * 4f, fParam3, 0);
			ui::set_text_scale(1f, func_27(14f));
		}
		else {
			ui::end_text_command_display_text(fParam2, fParam3, 0);
		}
	}
}

// Position - 0x420B
float func_27(float fParam0) { return fParam0 * 0.025f; }

// Position - 0x421B
float func_28(float fParam0) { return fParam0 * 0.0009259259f; }

// Position - 0x422B
void func_29(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14,
			 int iParam15, int iParam16) {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_31(7, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_30(7, iVar0);
		Global_1354542.f_4282[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_4282.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_4282.f_172[iVar0] = iParam2;
		Global_1354542.f_4282.f_216[iVar0] = iParam3;
		Global_1354542.f_4282.f_183[iVar0] = iParam4;
		Global_1354542.f_4282.f_194[iVar0] = iParam5;
		Global_1354542.f_4282.f_249[iVar0] = iParam6;
		Global_1354542.f_4282.f_260[iVar0] = iParam7;
		Global_1354542.f_4282.f_205[iVar0] = iParam8;
		Global_1354542.f_4282.f_314[iVar0] = iParam9;
		Global_1354542.f_4282.f_325[iVar0] = iParam10;
		Global_1354542.f_4282.f_357[iVar0] = iParam11;
		Global_1354542.f_4282.f_238[iVar0] = iParam12;
		Global_1354542.f_4282.f_271[iVar0] = iParam13;
		Global_1354542.f_4282.f_368[iVar0] = iParam14;
		Global_1354542.f_4282.f_379[iVar0] = iParam15;
		Global_1354542.f_4282.f_390[iVar0] = iParam16;
	}
}

// Position - 0x4379
void func_30(int iParam0, int iParam1) { gameplay::set_bit(&Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x4392
int func_31(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_1354542.f_5703[iParam0], iParam1); }

// Position - 0x43AB
float func_32(char *sParam0) {
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1) / 2f;
}

// Position - 0x43C0
void func_33() {
	graphics::_set_2d_layer(1);
	if (cam::is_screen_fading_out() || cam::is_screen_faded_out()) {
		graphics::_set_2d_layer(7);
	}
	graphics::_0xC6372ECD45D73BCD(0);
}

// Position - 0x43E8
float func_34() {
	float fVar0;

	fVar0 = 1f;
	if (gameplay::is_pc_version()) {
	}
	return fVar0;
}

// Position - 0x43FC
void func_35(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x4410
float func_36(float fParam0) { return fParam0 * 0.001388889f; }

// Position - 0x4420
void func_37() {
	if (Global_14443.f_1 != 1) {
		if (func_38(0)) {
			func_408(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x4448
bool func_38(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x44A2
void func_39(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int iParam4) {
	int iVar0;
	bool bVar1;
	int iVar2;
	vector3 vVar3;
	float fVar6;
	vector3 vVar7;
	vector3 vVar10;
	int iVar13;
	int iVar14;
	int iVar15;

	if (controls::_is_input_disabled(2)) {
		controls::disable_control_action(2, 199, 1);
	}
	if (player::is_player_online()) {
		if (!iLocal_319) {
			if (func_200(uParam1, 0, &iLocal_320)) {
				func_312(&uParam1->f_666, 9, 0);
				iLocal_319 = 1;
			}
		}
	}
	if (iLocal_301) {
		if (controls::_is_input_disabled(2)) {
			ui::_show_cursor_this_frame();
		}
		bVar1 = true;
		if (uParam1->f_680) {
			if (!uParam1->f_646 && !player::is_player_online()) {
				uParam1->f_646 = func_191(&uParam1->f_647, 0);
				bVar1 = false;
				if (uParam1->f_646) {
					uParam1->f_680 = 0;
					func_312(&uParam1->f_666, 9, 0);
					uParam1->f_646 = 0;
				}
			}
			else {
				func_114(&uParam1->f_72, &uParam1->f_645);
			}
			if (bVar1) {
				func_110(&uParam1->f_509, 1128792064, 1, 0, 1, 1065353216);
				if (controls::is_control_just_pressed(2, 202)) {
					uParam1->f_680 = 0;
					func_312(&uParam1->f_666, 9, 0);
				}
				else if (controls::is_control_just_pressed(2, 215)) {
					iVar0 = 2;
				}
				else if (controls::is_control_just_pressed(2, 216)) {
					iVar0 = 1;
				}
			}
			if (func_109(&uParam1->f_72)) {
				if (!bLocal_321) {
					bLocal_321 = true;
					func_108(&uParam1->f_509, 0, 0, 1, 1);
					func_107(&uParam1->f_509, "DARTS_CONT", 2, 215, 1, 1, 0);
					func_107(&uParam1->f_509, "DARTS_REMATCH", 2, 216, 1, 1, 0);
					func_107(&uParam1->f_509, "IB_BACK", 2, 202, 1, 1, 0);
					func_107(&uParam1->f_509, "SCLB_PROFILE", 2, 217, 1, 1, 0);
					func_104(&uParam1->f_509, 1);
				}
			}
		}
		else {
			iVar0 = func_97(uParam1, 0, 0, iLocal_319);
			func_10(uParam3, 0, 1065353216, 0, 0, 0);
		}
		if (ped::is_synchronized_scene_running(iLocal_328) && ped::get_synchronized_scene_phase(iLocal_328) >= 0.995f ||
			!ped::is_synchronized_scene_running(iLocal_328)) {
			iLocal_314 = 1;
			if (cam::does_cam_exist(iLocal_334)) {
				cam::destroy_cam(iLocal_334, 0);
				if (!ped::is_ped_injured(uLocal_296[0]) && !ped::is_ped_injured(uLocal_296[1])) {
					ai::clear_ped_tasks_immediately(uLocal_296[0]);
					ai::clear_ped_tasks_immediately(uLocal_296[1]);
					ped::_0x2208438012482A1A(uLocal_296[0], 0, 0);
					ped::_0x2208438012482A1A(uLocal_296[1], 0, 0);
				}
			}
			func_96();
		}
		if (func_404(&uParam0->f_254) > 2f) {
			if (!iLocal_312) {
				if (uParam0->f_454) {
					if (uParam0->f_437[0] + uParam0->f_437[1] == 1) {
						iVar2 = 1;
					}
					else {
						iVar2 = 0;
					}
					func_220(&uLocal_296, iVar2);
				}
				else {
					func_219(&uLocal_296);
				}
				iLocal_312 = 1;
			}
		}
		if (iVar0 == 1) {
			ui::clear_help(1);
			audio::stop_audio_scene(func_395(3));
			if (!ped::is_ped_injured(uLocal_296[0]) && !ped::is_ped_injured(uLocal_296[1])) {
				ai::task_clear_look_at(uLocal_296[0]);
				ai::task_clear_look_at(uLocal_296[1]);
			}
			func_95(uParam3);
			if (iParam4) {
				func_324(uParam2, 0, 0, 0, 0);
			}
			uParam0->f_429[0] = 0;
			uParam0->f_429[1] = 0;
			uParam0->f_432[0] = 0;
			uParam0->f_432[1] = 0;
			iLocal_30 = 1;
			func_402(&uParam0->f_254);
			*uParam0 = 9;
			iLocal_312 = 0;
			iLocal_310 = 0;
			iLocal_314 = 0;
			func_92();
			iLocal_319 = 0;
			iLocal_290 = 0;
			uParam1->f_680 = 0;
			iLocal_320 = 0;
			bLocal_321 = false;
			func_84(&uParam1->f_72);
			func_439();
		}
		else if (iVar0 == 2) {
			func_83(uParam3);
			audio::stop_audio_scene(func_395(3));
			if (uParam0->f_446[0] * 10 > 0) {
				func_51(func_79(), 21, uParam0->f_446[0] * 10, 0, 0);
			}
			ui::clear_prints();
			*uParam0 = 13;
		}
		else if ((controls::is_control_just_pressed(0, 234) || controls::is_control_just_pressed(0, 235)) &&
				 uParam0->f_248 == 1 && bVar1) {
			uParam0->f_457 = 0;
			if (iLocal_300) {
				vVar3 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
				func_50(vVar3, 0, iLocal_300);
				iLocal_300 = 0;
			}
			else if (controls::is_control_just_pressed(2, 190)) {
				iLocal_323++;
				if (iLocal_323 >= uParam0->f_436) {
					iLocal_323 = 0;
				}
				vVar3 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
				func_48(vVar3);
			}
			else if (controls::is_control_just_pressed(2, 189)) {
				iLocal_323--;
				if (iLocal_323 < 0) {
					iLocal_323 = uParam0->f_436 - 1;
				}
				vVar3 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
				func_48(vVar3);
			}
		}
		else if (controls::is_control_just_pressed(0, 211) || controls::is_disabled_control_just_pressed(0, 211))
			&&bVar1 && (iLocal_319 || !player::is_player_online()) {
				uParam1->f_680 = 1;
				func_108(&uParam1->f_509, 0, 0, 1, 1);
				func_107(&uParam1->f_509, "DARTS_CONT", 2, 215, 1, 1, 0);
				func_107(&uParam1->f_509, "DARTS_REMATCH", 2, 216, 1, 1, 0);
				func_107(&uParam1->f_509, "IB_BACK", 2, 202, 1, 1, 0);
				if (bLocal_321) {
					func_107(&uParam1->f_509, "SCLB_PROFILE", 2, 217, 1, 1, 0);
				}
				func_104(&uParam1->f_509, 1);
			}
	}
	else if (!uParam0->f_457) {
		ui::clear_help(1);
		ui::clear_prints();
		func_44(uParam3, uParam0->f_454, uParam0->f_429[iLocal_30], uParam0->f_432[iLocal_30], iLocal_151[2],
				uParam0->f_437[0], uParam0->f_437[1], uParam0->f_440[0], uParam0->f_440[1], uParam0->f_443[0],
				uParam0->f_443[1], iParam4);
		fVar6 = graphics::_get_aspect_ratio(1);
		if (fVar6 > 2f) {
			vVar7 = {1992.294f, 3047.577f, 46.21517f};
			vVar10 = {0f, 0f, 138.74f};
		}
		else {
			vVar7 = {1992.336f, 3047.924f, 46.21517f};
			vVar10 = {0f, 0f, 136.74f};
		}
		iVar13 = func_221();
		iLocal_328 = ped::create_synchronized_scene(vVar7, vVar10, 2);
		iLocal_334 = cam::create_cam("DEFAULT_ANIMATED_CAMERA", 0);
		cam::play_synchronized_cam_anim(iLocal_334, iLocal_328, sLocal_408[iVar13], "mini@dartsoutro");
		cam::set_cam_active(iLocal_334, 1);
		cam::render_script_cams(1, 0, 3000, 1, 0, 0);
		if (!ped::is_ped_injured(uLocal_296[0]) && !ped::is_ped_injured(uLocal_296[1])) {
			if (uParam0->f_454) {
				ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsoutro", sLocal_400[iVar13], 1000f,
											-1.5f, 0, 0, 1148846080, 0);
				ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsoutro", sLocal_404[iVar13], 1000f,
											-1.5f, 0, 0, 1148846080, 0);
				ai::task_play_anim(player::player_ped_id(), sLocal_395,
								   sLocal_396[gameplay::get_random_int_in_range(0, 3)], 4f, -4f, -1, 32, 0, 0, 0, 0);
			}
			else {
				ai::task_synchronized_scene(uLocal_296[1], iLocal_328, "mini@dartsoutro", sLocal_400[iVar13], 1000f,
											-1.5f, 0, 0, 1148846080, 0);
				ai::task_synchronized_scene(uLocal_296[0], iLocal_328, "mini@dartsoutro", sLocal_404[iVar13], 1000f,
											-1.5f, 0, 0, 1148846080, 0);
				ai::task_play_anim(uLocal_296[1], sLocal_394, sLocal_396[gameplay::get_random_int_in_range(0, 3)], 4f,
								   -4f, -1, 32, 0, 0, 0, 0);
			}
		}
		iLocal_314 = 0;
		uParam0->f_457 = 1;
		uParam1->f_671 = gameplay::get_game_timer();
		iVar14 = 0;
		while (iVar14 < 2) {
			iVar15 = 0;
			while (iVar15 < 3) {
				func_225(&uParam0->f_5[iVar14 /*79*/][iVar15 /*26*/]);
				iVar15++;
			}
			func_224(uParam2, iVar14);
			iVar14++;
		}
	}
	else if (gameplay::get_game_timer() - uParam1->f_671 > 400 && func_40(uParam3, 0, 0)) {
		if (!uParam0->f_454) {
			audio::play_sound_frontend(-1, "LOOSE_MATCH", "HUD_MINI_GAME_SOUNDSET", 1);
		}
		iLocal_301 = 1;
	}
}

// Position - 0x4C65
int func_40(var *uParam0, int iParam1, int iParam2) {
	uParam0->f_12 = iParam2;
	func_43(uParam0);
	func_42(uParam0);
	if (gameplay::are_strings_equal(&uParam0->f_550, "SPR_RESULT") ||
		gameplay::are_strings_equal(&uParam0->f_550, "") && uParam0->f_56 > 0) {
		uParam0->f_566 = 1;
	}
	if (network::network_is_game_in_progress()) {
		graphics::request_streamed_texture_dict("MPHud", 0);
	}
	if (uParam0->f_1 == 0) {
		graphics::request_streamed_texture_dict("CommonMenu", 0);
		graphics::request_streamed_texture_dict("MPLeaderboard", 0);
		graphics::request_streamed_texture_dict("MPHud", 0);
		uParam0->f_1 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
		uParam0->f_2 = 0;
		uParam0->f_3 = 0;
	}
	uParam0->f_4 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	if (iParam1) {
		while (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			   !graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			   !graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			   !graphics::has_streamed_texture_dict_loaded("MPHud")) {
			system::wait(0);
		}
		if (uParam0->f_562 || uParam0->f_567) {
			while (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				system::wait(0);
			}
		}
	}
	else {
		if (!graphics::has_scaleform_movie_loaded(uParam0->f_1) ||
			!graphics::has_streamed_texture_dict_loaded("CommonMenu") ||
			!graphics::has_streamed_texture_dict_loaded("MPLeaderboard") ||
			!graphics::has_streamed_texture_dict_loaded("MPHud")) {
			return 0;
		}
		if (uParam0->f_562) {
			if (!graphics::has_scaleform_movie_loaded(uParam0->f_4)) {
				return 0;
			}
		}
	}
	if (uParam0->f_562) {
		if (uParam0->f_567) {
			func_41(uParam0);
		}
		else if (uParam0->f_56 != 0) {
			func_11(uParam0, 1);
		}
		else {
			func_11(uParam0, 0);
		}
	}
	Global_69963 = 1;
	return 1;
}

// Position - 0x4E05
void func_41(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_4, "CLEAR_ALL");
	graphics::_pop_scaleform_movie_function_void();
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(2);
	func_13(controls::get_control_instructional_button(2, 188, 1));
	func_12("ES_HELP_TU");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(1);
	func_13(controls::get_control_instructional_button(2, 187, 1));
	func_12("ES_HELP_TD");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(0);
	func_13(controls::get_control_instructional_button(2, 202, 1));
	func_12("ES_HELP_AB");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_4, "DRAW_INSTRUCTIONAL_BUTTONS");
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x4ECA
void func_42(float *fParam0) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	fVar0 = 0f;
	ui::set_text_justification(0);
	ui::set_text_scale(1f, func_27(16f));
	if (fParam0->f_31 == 0) {
		if (fParam0->f_29) {
			ui::_begin_text_command_width("STRING");
			ui::add_text_component_substring_player_name(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
		else {
			ui::_begin_text_command_width(&fParam0->f_13);
			fVar0 = ui::_end_text_command_get_width(1);
		}
	}
	else {
		ui::_begin_text_command_width("STRING");
		iVar1 = 0;
		iVar2 = 0;
		iVar3 = 0;
		iVar3 = 0;
		while (iVar3 < fParam0->f_31) {
			switch (fParam0->f_32[iVar3]) {
			case 0:
				ui::add_text_component_integer(fParam0->f_53[iVar1]);
				iVar1++;
				break;

			case 1:
				ui::add_text_component_substring_text_label(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;

			case 2:
				ui::add_text_component_substring_player_name(&fParam0->f_36[iVar2 /*16*/]);
				iVar2++;
				break;
			}
			iVar3++;
		}
		fVar0 = ui::_end_text_command_get_width(1);
	}
	if (fVar0 > 0.1125f * 2f - 0.006f * 2f) {
		*fParam0 = fVar0 / 2f + 0.006f * 2f;
	}
}

// Position - 0x4FD2
void func_43(var *uParam0) {
	uParam0->f_547 = 1f;
	uParam0->f_546 = 0;
	uParam0->f_568 = 0f;
	uParam0->f_558 = 0;
	uParam0->f_30 = 0f;
	uParam0->f_548 = 0f;
	uParam0->f_559 = 0f;
	uParam0->f_560 = 0f;
	uParam0->f_545 = 0;
	uParam0->f_563 = 0;
	uParam0->f_572 = 0;
	uParam0->f_564 = 0;
	uParam0->f_565 = 0;
	uParam0->f_566 = 0;
	*uParam0 = 0.1125f;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_574 = 0;
	uParam0->f_575 = 0;
	uParam0->f_573 = 1f;
}

// Position - 0x5051
void func_44(var *uParam0, bool bParam1, var uParam2, var uParam3, var uParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, bool bParam11) {
	uParam0->f_561 = 1;
	if (bParam1) {
		func_47(uParam0, "DARTS_WINNER", "DARTS_YJ", 0);
	}
	else {
		func_47(uParam0, "DARTS_LOSE_R", "DARTS_YJ", 0);
	}
	func_46(uParam0, 1, "DARTS_NUM_T", "", uParam2, 0, 0, 0);
	func_46(uParam0, 1, "DARTS_NUM_B", "", uParam3, 0, 0, 0);
	func_46(uParam0, 1, "DARTS_NUM_180", "", uParam4, 0, 0, 0);
	if (bParam11) {
		func_46(uParam0, 2, "DARTS_WIN", "", iParam5, iParam5 + iParam6, 0, 0);
		func_46(uParam0, 2, "DARTS_SWIN", "", iParam7, iParam7 + iParam8, 0, 0);
	}
	func_46(uParam0, 2, "DARTS_GWIN", "", iParam9, iParam9 + iParam10, 0, 0);
	func_45(uParam0, 0, "", 0, 0, 0, 0);
	func_35(1);
}

// Position - 0x5122
void func_45(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	uParam0->f_549 = iParam1;
	StringCopy(&uParam0->f_550, sParam2, 16);
	uParam0->f_554 = iParam3;
	uParam0->f_555 = iParam4;
	uParam0->f_556 = iParam5;
	uParam0->f_557 = iParam6;
}

// Position - 0x5156
void func_46(var *uParam0, int iParam1, char *sParam2, char *sParam3, var uParam4, int iParam5, int iParam6,
			 int iParam7) {
	int iVar0;

	if (uParam0->f_56 == 13) {
		return;
	}
	iVar0 = uParam0->f_56;
	uParam0->f_57[iVar0] = iParam1;
	StringCopy(&uParam0->f_71[iVar0 /*16*/], sParam2, 64);
	StringCopy(&uParam0->f_280[iVar0 /*16*/], sParam3, 64);
	uParam0->f_489[iVar0] = uParam4;
	uParam0->f_503[iVar0] = iParam5;
	uParam0->f_517[iVar0] = iParam6;
	uParam0->f_531[iVar0] = iParam7;
	uParam0->f_56++;
}

// Position - 0x51C9
void func_47(var *uParam0, char *sParam1, char *sParam2, int iParam3) {
	StringCopy(&uParam0->f_5, sParam1, 16);
	StringCopy(&uParam0->f_13, sParam2, 64);
	uParam0->f_29 = iParam3;
	uParam0->f_11 = 0;
}

// Position - 0x51EC
void func_48(vector3 vParam0) {
	vector3 vVar0;

	vVar0 = {func_49(vParam0)};
	if (bLocal_133) {
		cam::set_cam_coord(iLocal_131, vVar0);
		cam::set_cam_active_with_interp(iLocal_131, iLocal_130, 500, 1, 1);
		bLocal_133 = false;
	}
	else {
		cam::set_cam_coord(iLocal_130, vVar0);
		cam::set_cam_active_with_interp(iLocal_130, iLocal_131, 500, 1, 1);
		bLocal_133 = true;
	}
}

// Position - 0x523C
Vector3 func_49(vector3 vParam0) {
	vector3 vVar0;
	vector3 vVar3;

	vVar3 = {0.3495f, -0.0276f, -0.0114f};
	vVar0 = {vParam0 - vVar3};
	return vVar0;
}

// Position - 0x5268
void func_50(vector3 vParam0, int iParam3, int iParam4) {
	vector3 vVar0;

	vVar0 = {func_49(vParam0)};
	if (iParam3) {
		cam::set_cam_coord(iLocal_130, vVar0);
		cam::set_cam_active_with_interp(iLocal_130, iLocal_129, 1500, 1, 1);
		cam::set_cam_active(iLocal_129, 0);
		cam::set_cam_coord(iLocal_131, vVar0);
		bLocal_133 = true;
	}
	else if (iParam4) {
		cam::set_cam_coord(iLocal_130, vVar0);
		cam::set_cam_active_with_interp(iLocal_130, iLocal_122, 2000, 1, 1);
		bLocal_133 = true;
	}
	else {
		if (bLocal_133) {
			cam::set_cam_active_with_interp(iLocal_129, iLocal_130, 1500, 1, 1);
		}
		else {
			cam::set_cam_active_with_interp(iLocal_129, iLocal_131, 1500, 1, 1);
		}
		cam::set_cam_active(iLocal_130, 0);
	}
}

// Position - 0x52FA
void func_51(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;

	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 3) {
		return;
	}
	if (Global_101700.f_27009[iParam0 /*29*/].f_17 == 4) {
		return;
	}
	func_52(Global_101700.f_27009[iParam0 /*29*/].f_17, 1, iParam1, iParam2, 0);
	if (iParam3) {
		iVar0 = 0;
		if (iParam4) {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_random_peds"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_random_peds"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_random_peds"); break;

			default: return;
			}
		}
		else {
			switch (iParam0) {
			case 0: iVar1 = joaat("sp0_money_made_from_missions"); break;

			case 1: iVar1 = joaat("sp1_money_made_from_missions"); break;

			case 2: iVar1 = joaat("sp2_money_made_from_missions"); break;

			default: return;
			}
		}
		stats::stat_get_int(iVar1, &iVar0, -1);
		iVar0 += iParam2;
		stats::stat_set_int(iVar1, iVar0, 1);
	}
}

// Position - 0x53E1
int func_52(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	float fVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	func_78();
	if (iParam3 < 1) {
		return 0;
	}
	fVar0 = 1f;
	switch (iParam1) {
	case 0:
		switch (iParam0) {
		case 0:
			func_77(99, 1);
			func_76(joaat("sp0_money_total_spent"), iParam3);
			break;

		case 1: func_76(joaat("sp1_money_total_spent"), iParam3); break;

		case 2: func_76(joaat("sp2_money_total_spent"), iParam3); break;
		}
		func_60(0);
		switch (iParam2) {
		case 126:
		case 128:
		case 124:
		case 125:
		case 127:
			if (func_59(5)) {
				fVar0 = 0.9f;
				iVar1 = 5;
			}
			break;

		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
			switch (iParam0) {
			case 0: func_76(joaat("sp0_money_spent_on_tattoos"), iParam3); break;

			case 1: func_76(joaat("sp1_money_spent_on_tattoos"), iParam3); break;

			case 2: func_76(joaat("sp2_money_spent_on_tattoos"), iParam3); break;
			}
			if (func_59(1)) {
				fVar0 = 0f;
				iVar1 = 1;
			}
			break;

		case 21:
			switch (iParam0) {
			case 0: func_76(joaat("sp0_money_spent_on_taxis"), iParam3); break;

			case 1: func_76(joaat("sp1_money_spent_on_taxis"), iParam3); break;

			case 2: func_76(joaat("sp2_money_spent_on_taxis"), iParam3); break;
			}
			break;

		case 25:
			switch (iParam0) {
			case 0: func_76(joaat("sp0_money_spent_in_strip_clubs"), iParam3); break;

			case 1: func_76(joaat("sp1_money_spent_in_strip_clubs"), iParam3); break;

			case 2: func_76(joaat("sp2_money_spent_in_strip_clubs"), iParam3); break;
			}
			break;

		case 98:
		case 99:
		case 100:
		case 101:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
		case 110:
		case 111:
		case 112:
			switch (iParam0) {
			case 0: func_76(joaat("sp0_money_spent_property"), iParam3); break;

			case 1: func_76(joaat("sp1_money_spent_property"), iParam3); break;

			case 2: func_76(joaat("sp2_money_spent_property"), iParam3); break;
			}
			break;

		default:
			switch (script::get_hash_of_this_script_name()) {
			case joaat("clothes_shop_sp"):
				switch (iParam0) {
				case 0: func_76(joaat("sp0_money_spent_in_clothes"), iParam3); break;

				case 1: func_76(joaat("sp1_money_spent_in_clothes"), iParam3); break;

				case 2: func_76(joaat("sp2_money_spent_in_clothes"), iParam3); break;
				}
				break;

			case joaat("hairdo_shop_sp"):
				switch (iParam0) {
				case 0: func_76(joaat("sp0_money_spent_on_hairdos"), iParam3); break;

				case 1: func_76(joaat("sp1_money_spent_on_hairdos"), iParam3); break;

				case 2: func_76(joaat("sp2_money_spent_on_hairdos"), iParam3); break;
				}
				if (func_59(0)) {
					fVar0 = 0f;
					iVar1 = 0;
				}
				break;

			case joaat("gunclub_shop"):
				switch (iParam0) {
				case 0: func_76(joaat("sp0_money_spent_in_buying_guns"), iParam3); break;

				case 1: func_76(joaat("sp1_money_spent_in_buying_guns"), iParam3); break;

				case 2: func_76(joaat("sp2_money_spent_in_buying_guns"), iParam3); break;
				}
				break;

			case joaat("carmod_shop"):
				switch (iParam0) {
				case 0: func_76(joaat("sp0_money_spent_car_mods"), iParam3); break;

				case 1: func_76(joaat("sp1_money_spent_car_mods"), iParam3); break;

				case 2: func_76(joaat("sp2_money_spent_car_mods"), iParam3); break;
				}
				func_58(iParam3);
				break;
			}
			break;
		}
		break;

	case 1:
		switch (iParam0) {
		case 0: func_77(95, iParam3); break;

		case 1: func_77(97, iParam3); break;

		case 2: func_77(96, iParam3); break;
		}
		func_77(98, iParam3);
		break;
	}
	iVar2 = iParam0;
	iParam3 = system::floor(fVar0 * system::to_float(iParam3));
	iVar3 = 0;
	iVar4 = iParam3;
	if (fVar0 == 0f) {
		func_55(iVar1);
		return 1;
	}
	else if (fVar0 != 1f) {
		func_55(iVar1);
	}
	iVar5 = Global_52996[iVar2] + iParam3;
	switch (iParam1) {
	case 1:
		if (Global_52996[iVar2] >= 0 && iParam3 > 0) {
			if (iVar5 <= 0) {
				Global_52996[iVar2] = 2147483647;
			}
			else {
				Global_52996[iVar2] += iParam3;
			}
		}
		switch (iParam0) {
		case 0: func_76(joaat("sp0_total_cash_earned"), iParam3); break;

		case 1: func_76(joaat("sp1_total_cash_earned"), iParam3); break;

		case 2: func_76(joaat("sp2_total_cash_earned"), iParam3); break;
		}
		break;

	case 0:
		if (!iParam4) {
			if (Global_52996[iVar2] - iParam3 < 0) {
				return 0;
			}
		}
		iVar3 = Global_52996[iVar2];
		Global_52996[iVar2] -= iParam3;
		if (iParam4) {
			iVar4 = iVar3;
		}
		break;
	}
	if (iParam2 == 1) {
		if (iVar4 > 20) {
		}
	}
	else {
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/] = iParam1;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_1 =
			iParam2;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_2[Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 /*6*/].f_2 =
			iParam3;
		Global_101700.f_19523.f_233[iVar2 /*69*/]++;
		Global_101700.f_19523.f_233[iVar2 /*69*/].f_1++;
		if (Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 > 10) {
			Global_101700.f_19523.f_233[iVar2 /*69*/].f_1 = 0;
		}
	}
	func_54(iParam0);
	if (Global_35781 == 15) {
		func_53(0);
	}
	return 1;
}

// Position - 0x59E0
void func_53(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 11) {
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_3 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/];
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_4 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_1;
			Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_5 =
				Global_101700.f_19523.f_233[iVar0 /*69*/].f_2[iVar1 /*6*/].f_2;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 10) {
		Global_53004[iVar0 /*3*/][0] = Global_101700.f_19523[iVar0];
		Global_53004.f_31[iVar0 /*3*/][0] = Global_101700.f_19523.f_11[iVar0];
		Global_53004.f_62[iVar0 /*3*/][0] = Global_101700.f_19523.f_22[iVar0];
		Global_53004.f_93[iVar0 /*3*/][0] = Global_101700.f_19523.f_33[iVar0];
		Global_53004.f_124[iVar0 /*3*/][0] = Global_101700.f_19523.f_44[iVar0];
		Global_53004.f_155[iVar0 /*3*/][0] = Global_101700.f_19523.f_55[iVar0];
		Global_53004.f_186[iVar0 /*3*/][0] = Global_101700.f_19523.f_66[iVar0];
		Global_53004.f_217[iVar0 /*3*/][0] = Global_101700.f_19523.f_77[iVar0];
		Global_53004.f_248[iVar0 /*3*/][0] = Global_101700.f_19523.f_88[iVar0];
		if (!iParam0) {
			Global_53004[iVar0 /*3*/][1] = Global_101700.f_19523[iVar0];
			Global_53004.f_31[iVar0 /*3*/][1] = Global_101700.f_19523.f_11[iVar0];
			Global_53004.f_62[iVar0 /*3*/][1] = Global_101700.f_19523.f_22[iVar0];
			Global_53004.f_93[iVar0 /*3*/][1] = Global_101700.f_19523.f_33[iVar0];
			Global_53004.f_124[iVar0 /*3*/][1] = Global_101700.f_19523.f_44[iVar0];
			Global_53004.f_155[iVar0 /*3*/][1] = Global_101700.f_19523.f_55[iVar0];
			Global_53004.f_186[iVar0 /*3*/][1] = Global_101700.f_19523.f_66[iVar0];
			Global_53004.f_217[iVar0 /*3*/][1] = Global_101700.f_19523.f_77[iVar0];
			Global_53004.f_248[iVar0 /*3*/][1] = Global_101700.f_19523.f_88[iVar0];
		}
		iVar0++;
	}
}

// Position - 0x5C62
void func_54(int iParam0) {
	int iVar0;

	iVar0 = Global_52996[iParam0];
	switch (iParam0) {
	case 0: stats::stat_set_int(joaat("sp0_total_cash"), iVar0, 1); break;

	case 1: stats::stat_set_int(joaat("sp1_total_cash"), iVar0, 1); break;

	case 2: stats::stat_set_int(joaat("sp2_total_cash"), iVar0, 1); break;
	}
}

// Position - 0x5CBC
void func_55(int iParam0) {
	bool bVar0;
	char cVar1[64];

	bVar0 = false;
	if (!network::network_is_game_in_progress()) {
		if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0)) {
			bVar0 = true;
			gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		}
	}
	else if (gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0) ||
			 gameplay::is_bit_set(Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0)) {
		bVar0 = true;
		gameplay::clear_bit(&Global_101700.f_19523.f_471, iParam0);
		gameplay::clear_bit(&Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0);
	}
	if (bVar0) {
		StringCopy(&cVar1, "CHAR_LIFEINVADER", 64);
		ui::_set_notification_text_entry("COUP_RED");
		ui::add_text_component_substring_text_label(func_56(iParam0));
		ui::_set_notification_message(&cVar1, &cVar1, 1, 0, "", 0);
	}
}

// Position - 0x5D7F
char *func_56(int iParam0) {
	switch (iParam0) {
	case 0: return "COUP_HAIRC";

	case 1: return "COUP_TATTOO";

	case 2: return "COUP_WARSTOCK";

	case 3: return "COUP_MOSPORT";

	case 4: return "COUP_ELITAS";

	case 5: return "COUP_MEDSPENS";

	case 6: return "COUP_SPRUNK";

	case 7: return "COUP_RESPRAY";

	default:
	}
	return "";
}

// Position - 0x5DFA
int func_57() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x5E07
void func_58(int iParam0) {
	func_77(93, iParam0);
	func_77(29, iParam0);
	func_77(30, iParam0);
}

// Position - 0x5E27
bool func_59(int iParam0) {
	if (!network::network_is_game_in_progress()) {
		return gameplay::is_bit_set(Global_101700.f_19523.f_471, iParam0);
	}
	return gameplay::is_bit_set(Global_2097152[func_57() /*10758*/].f_7546.f_10, iParam0);
}

// Position - 0x5E63
int func_60(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (player::has_achievement_been_passed(27)) {
		return 0;
	}
	if (stats::stat_get_int(joaat("sp0_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp1_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (stats::stat_get_int(joaat("sp2_money_total_spent"), &iVar0, -1)) {
		iVar1 += iVar0;
	}
	if (iParam0) {
	}
	iVar2 = 0;
	stats::stat_get_int(joaat("num_cash_spent"), &iVar2, -1);
	if (iVar1 > 0 && iVar2 / 2000000 != iVar1 / 2000000) {
		stats::stat_set_int(joaat("num_cash_spent"), iVar1, 1);
		func_75(27, iVar1);
	}
	if (iVar1 < 200000000) {
		return 0;
	}
	func_61(27, 1);
	return 1;
}

// Position - 0x5F1A
int func_61(int iParam0, int iParam1) {
	if (iParam0 >= 70) {
		return 0;
	}
	return func_62(iParam0, iParam1);
}

// Position - 0x5F35
int func_62(int iParam0, int iParam1) {
	if (func_74(14) && !func_73(iParam0)) {
		return 0;
	}
	if (player::has_achievement_been_passed(iParam0) && iParam1 == 1) {
		return 0;
	}
	if (Global_25436 != 0 && !Global_69702) {
		return 0;
	}
	if (func_72(&Global_2595550)) {
		if (func_70(&Global_2595550, iParam0)) {
			return 0;
		}
		if (func_63(&Global_2595550, iParam0)) {
			return 1;
		}
	}
	else {
		if (!player::give_achievement_to_player(iParam0)) {
			return 0;
		}
		if (player::has_achievement_been_passed(iParam0)) {
			return 1;
		}
		return 0;
	}
	return 0;
}

// Position - 0x5FD2
bool func_63(var *uParam0, int iParam1) {
	int iVar0;
	var *uVar1[70];

	if (player::has_achievement_been_passed(iParam1)) {
		return false;
	}
	if (func_74(14) && !func_73(iParam1)) {
		return false;
	}
	if (func_70(uParam0, iParam1)) {
		return false;
	}
	if (func_69(uParam0) < 0f) {
		func_68(uParam0, 0);
	}
	func_66(&uVar1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0 - 1) {
		uVar1[iVar0 + 1] = (*uParam0)[iVar0];
		iVar0++;
	}
	func_64(&uVar1, iParam1);
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		(*uParam0)[iVar0] = uVar1[iVar0];
		iVar0++;
	}
	return true;
}

// Position - 0x6083
int func_64(var *uParam0, int iParam1) {
	int iVar0;

	if (player::has_achievement_been_passed(iParam1)) {
		return 0;
	}
	if (func_74(14) && !func_73(iParam1)) {
		return 0;
	}
	if (func_70(uParam0, iParam1)) {
		return 0;
	}
	if (func_69(uParam0) < 0f) {
		func_68(uParam0, 0);
	}
	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if (func_65(uParam0, iVar0)) {
			(*uParam0)[iVar0] = iParam1;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x60FE
bool func_65(var *uParam0, int iParam1) { return (*uParam0)[iParam1] == 70; }

// Position - 0x610F
void func_66(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		func_67(uParam0, iVar0);
		iVar0++;
	}
	func_68(uParam0, Global_2595549 - 0.5f);
}

// Position - 0x6143
void func_67(var *uParam0, int iParam1) { (*uParam0)[iParam1] = 70; }

// Position - 0x6153
void func_68(var *uParam0, float fParam1) {
	if (fParam1 == 0f) {
		uParam0->f_72 = 0f;
	}
	else {
		uParam0->f_72 = fParam1;
	}
}

// Position - 0x6170
float func_69(var *uParam0) { return uParam0->f_72; }

// Position - 0x617C
bool func_70(var *uParam0, int iParam1) { return func_71(uParam0, iParam1) != -1; }

// Position - 0x618E
int func_71(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < *uParam0) {
		if ((*uParam0)[iVar0] == iParam1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x61BB
bool func_72(var *uParam0) { return uParam0->f_71 == 1; }

// Position - 0x61C9
int func_73(int iParam0) {
	switch (iParam0) {
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69: return 1;

	default:
	}
	return 0;
}

// Position - 0x6219
bool func_74(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x6227
int func_75(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x6278
void func_76(int iParam0, int iParam1) {
	int iVar0;

	stats::stat_get_int(iParam0, &iVar0, -1);
	iVar0 += iParam1;
	stats::stat_set_int(iParam0, iVar0, 1);
}

// Position - 0x629B
void func_77(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 < 1) {
		return;
	}
	if (Global_51564[iParam0 /*7*/].f_2) {
		return;
	}
	if (network::network_is_game_in_progress()) {
		return;
	}
	if (Global_51564[iParam0 /*7*/]) {
		stats::stat_get_int(Global_51564[iParam0 /*7*/].f_1, &iVar0, -1);
		iVar0 += iParam1;
		stats::stat_set_int(Global_51564[iParam0 /*7*/].f_1, iVar0, 1);
	}
}

// Position - 0x62F8
void func_78() {
	int iVar0;

	if (network::network_is_signed_in()) {
		stats::stat_get_int(joaat("sp0_total_cash"), &iVar0, -1);
		if (Global_52996[0] != iVar0) {
			Global_52996[0] = iVar0;
		}
		stats::stat_get_int(joaat("sp1_total_cash"), &iVar0, -1);
		if (Global_52996[1] != iVar0) {
			Global_52996[1] = iVar0;
		}
		stats::stat_get_int(joaat("sp2_total_cash"), &iVar0, -1);
		if (Global_52996[2] != iVar0) {
			Global_52996[2] = iVar0;
		}
	}
}

// Position - 0x636D
int func_79() {
	func_80();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x6386
void func_80() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_82(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_481(player::player_ped_id());
			if (func_81(iVar0) && (!func_74(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_81(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x6483
bool func_81(int iParam0) { return iParam0 < 3; }

// Position - 0x648F
int func_82(int iParam0) {
	if (func_81(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x64B9
void func_83(var *uParam0) {
	if (uParam0->f_561 || uParam0->f_572 <= uParam0->f_558) {
		uParam0->f_561 = 0;
		uParam0->f_558 = uParam0->f_572 - 1;
	}
}

// Position - 0x64EC
void func_84(var *uParam0) {
	if (uParam0->f_4 != 0) {
		func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
	}
	if ((*uParam0)[0] != 0 || (*uParam0)[1] != 0 || (*uParam0)[2] != 0) {
		func_90(uParam0);
		func_89(uParam0);
		func_88(&Global_1839721);
	}
	if (Global_1835390.f_2708 != 0 || Global_1835390.f_3184) {
		func_86();
	}
	if (audio::is_audio_scene_active("LEADERBOARD_SCENE")) {
		audio::stop_audio_scene("LEADERBOARD_SCENE");
	}
	if (network::network_is_signed_online()) {
		func_85(&Global_1840922.f_49);
	}
	Global_2494199.f_3829 = 0;
}

// Position - 0x658D
void func_85(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0x659A
void func_86() {
	int iVar0;
	int iVar1;
	struct<75> Var2;

	Var2.f_60 = 6;
	Var2.f_67 = 6;
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = 0;
		while (iVar1 < 12) {
			Global_1835390[iVar0 /*901*/][iVar1 /*75*/] = {Var2};
			iVar1++;
		}
		Global_1835390.f_2704[iVar0] = 0;
		iVar0++;
	}
	Global_1835390.f_2708 = 0;
	Global_1835390.f_2709 = 0;
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		Global_1835390.f_2710[iVar0] = 0;
		StringCopy(&Global_1835390.f_2717[iVar0 /*6*/], "", 24);
		Global_1835390.f_2754[iVar0] = 0;
		Global_1835390.f_2761[iVar0] = 0;
		iVar0++;
	}
	Global_1835390.f_2768 = 0;
	Global_1835390.f_2769 = 0;
	Global_1835390.f_2770 = 0;
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 3) {
		Global_1835390.f_2771[iVar0] = 0;
		Global_1835390.f_2775[iVar0] = 0;
		iVar0++;
	}
	Global_1835390.f_2779 = 0;
	func_87(&Global_1835390.f_2780);
	func_85(&Global_1835390.f_2823);
	Global_1835390.f_2825 = -1;
	Global_1835390.f_2826 = 0;
	func_85(&Global_1835390.f_2827);
	Global_1835390.f_2829 = 0;
	func_85(&Global_1835390.f_2830);
	Global_1835390.f_2832 = 0;
	Global_1835390.f_2780.f_28 = 0;
	Global_1835390.f_2780.f_27 = 0;
	Global_1835390.f_3184 = 0;
}

// Position - 0x6706
void func_87(var *uParam0) {
	int iVar0;

	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 32);
	StringCopy(&uParam0->f_9, "", 64);
	uParam0->f_25 = 1;
	uParam0->f_26 = 0;
	uParam0->f_27 = 0;
	uParam0->f_28 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		uParam0->f_29[iVar0] = 0;
		uParam0->f_36[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x675E
void func_88(var *uParam0) {
	struct<13> Var0;
	int iVar13;
	int iVar14;

	iVar13 = 0;
	while (iVar13 < 12) {
		StringCopy(&(*uParam0)[iVar13 /*100*/], "", 64);
		StringCopy(&(*uParam0)[iVar13 /*100*/].f_16, "", 64);
		(*uParam0)[iVar13 /*100*/].f_32 = {Var0};
		(*uParam0)[iVar13 /*100*/].f_45 = {Var0};
		(*uParam0)[iVar13 /*100*/].f_58 = 0;
		(*uParam0)[iVar13 /*100*/].f_59 = 0;
		iVar14 = 0;
		while (iVar14 < 6) {
			(*uParam0)[iVar13 /*100*/].f_60[iVar14] = 0f;
			(*uParam0)[iVar13 /*100*/].f_67[iVar14] = 0;
			iVar14++;
		}
		(*uParam0)[iVar13 /*100*/].f_75 = 0;
		(*uParam0)[iVar13 /*100*/].f_74 = 0;
		(*uParam0)[iVar13 /*100*/].f_76 = 0;
		(*uParam0)[iVar13 /*100*/].f_77 = 0;
		(*uParam0)[iVar13 /*100*/].f_78 = 0;
		(*uParam0)[iVar13 /*100*/].f_79 = 0;
		StringCopy(&(*uParam0)[iVar13 /*100*/].f_80, "", 16);
		iVar13++;
	}
	func_85(&Global_1835390.f_2830);
}

// Position - 0x6840
void func_89(var *uParam0) {
	int iVar0;
	struct<13> Var1;

	uParam0->f_246 = 0;
	uParam0->f_246.f_1 = -1;
	uParam0->f_246.f_2 = 0;
	func_85(&uParam0->f_246.f_3);
	uParam0->f_246.f_5 = 0;
	iVar0 = 0;
	while (iVar0 < 12) {
		uParam0->f_246.f_6[iVar0 /*15*/] = -1;
		uParam0->f_246.f_6[iVar0 /*15*/].f_1 = 0;
		uParam0->f_246.f_6[iVar0 /*15*/].f_2 = {Var1};
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		uParam0->f_246.f_187[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x68C8
void func_90(var *uParam0) {
	int iVar0;
	struct<35> Var1;

	(*uParam0)[0] = 0;
	(*uParam0)[1] = 0;
	(*uParam0)[2] = 0;
	uParam0->f_4 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = {Var1};
	uParam0->f_42 = 0;
	uParam0->f_43 = 0;
	uParam0->f_44 = 0;
	uParam0->f_44.f_1 = 0;
	uParam0->f_44.f_2 = 0;
	uParam0->f_44.f_3 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		StringCopy(&uParam0->f_44.f_3.f_1[iVar0 /*16*/], "", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[iVar0 /*16*/].f_8, "", 32);
		iVar0++;
	}
	uParam0->f_113[0 /*66*/] = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		StringCopy(&uParam0->f_113[0 /*66*/].f_1[iVar0 /*16*/], "", 32);
		StringCopy(&uParam0->f_113[0 /*66*/].f_1[iVar0 /*16*/].f_8, "", 32);
		iVar0++;
	}
}

// Position - 0x6996
void func_91(int *iParam0, int *iParam1, var *uParam2) {
	*iParam0 = 0;
	*iParam1 = 0;
	Global_1835008 = 0;
	func_85(&Global_1835008.f_1);
	stats::leaderboards_read_clear(*uParam2, uParam2->f_1, -1);
}

// Position - 0x69C2
void func_92() {
	struct<68> Var0;

	Global_1835013 = 0;
	Global_1835013.f_1 = 0;
	Global_1835013.f_2 = 0;
	Global_1835013.f_3 = 0;
	Global_1835013.f_4 = 0;
	func_94(&Global_1835013.f_73);
	func_94(&Global_1835013.f_142);
	func_94(&Global_1835013.f_211);
	func_94(&Global_1835013.f_280);
	StringCopy(&Global_1835013.f_349, "", 24);
	StringCopy(&Global_1835013.f_355, "", 24);
	func_93(&Global_1835013.f_361);
	Global_1835013.f_374 = -1;
	Global_1835388 = 0;
	Global_1835389 = 0;
	Var0.f_2.f_1 = 4;
	Global_1835013.f_5 = {Var0};
}

// Position - 0x6A66
void func_93(var *uParam0) {
	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_4 = 0;
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 0;
}

// Position - 0x6AAE
void func_94(var *uParam0) {
	int iVar0;

	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	iVar0 = 0;
	while (iVar0 < 32) {
		uParam0->f_3[iVar0] = 0f;
		uParam0->f_36[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x6AE9
void func_95(var *uParam0) {
	func_43(uParam0);
	uParam0->f_570 = 0;
	uParam0->f_31 = 0;
	uParam0->f_56 = 0;
	uParam0->f_567 = 0;
	uParam0->f_569 = 0;
}

// Position - 0x6B13
void func_96() { cam::set_cam_active(iLocal_126, 1); }

// Position - 0x6B22
int func_97(var *uParam0, int iParam1, int iParam2, int iParam3) {
	if (!func_3(&uParam0->f_666, 7)) {
		if (!func_3(&uParam0->f_666, 9)) {
			func_35(1);
			func_108(&uParam0->f_509, 0, 0, 1, 1);
			func_107(&uParam0->f_509, "DARTS_CONT", 2, 215, 1, 1, 0);
			if (!iParam2) {
				func_107(&uParam0->f_509, "DARTS_REMATCH", 2, 216, 1, 1, 0);
			}
			else {
				func_107(&uParam0->f_509, "DARTS_REPLAY", 2, 216, 1, 1, 0);
			}
			if (iParam3 || !player::is_player_online()) {
				func_107(&uParam0->f_509, "HUD_LBD_LBD", 2, 211, 1, 1, 0);
			}
			func_104(&uParam0->f_509, 1);
			func_312(&uParam0->f_666, 8, 0);
			func_312(&uParam0->f_666, 9, 1);
		}
		if (!func_3(&uParam0->f_666, 14)) {
			if (iParam1) {
				if (!iParam2) {
					func_100(func_103(uParam0->f_668 < uParam0->f_669, uParam0->f_668, uParam0->f_669),
							 func_102(uParam0->f_668 < uParam0->f_669, &uParam0->f_648, &uParam0->f_654), -1, 1, 2, 1,
							 0, 1, 0, 0, 0, 0);
					func_100(func_103(uParam0->f_668 >= uParam0->f_669, uParam0->f_668, uParam0->f_669),
							 func_102(uParam0->f_668 >= uParam0->f_669, &uParam0->f_648, &uParam0->f_654), -1, 1, 2, 1,
							 0, 1, 0, 0, 0, 0);
				}
				else {
					func_100(uParam0->f_668, &uParam0->f_648, -1, 1, 2, 1, 0, 1, 0, 0, 0, 0);
				}
				func_391(&uParam0->f_57, 0, 0);
			}
			func_110(&uParam0->f_509, 1128792064, 1, 0, 1, 1065353216);
		}
		if (!ui::is_pause_menu_active()) {
			if (gameplay::get_game_timer() - uParam0->f_671 > 900) {
				if (controls::is_control_pressed(2, 216)) {
					audio::play_sound_frontend(-1, "YES", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
					func_312(&uParam0->f_666, 9, 0);
					return 1;
				}
				else if (controls::is_control_just_pressed(2, 215)) {
					audio::play_sound_frontend(-1, "NO", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
					func_99();
					func_98();
					return 2;
				}
			}
		}
	}
	else {
		func_2(uParam0);
		if (controls::is_control_just_released(2, 201)) {
			return 2;
		}
		else if (controls::is_control_just_released(2, 202)) {
			func_312(&uParam0->f_666, 9, 0);
			func_312(&uParam0->f_666, 7, 0);
		}
	}
	return 0;
}

// Position - 0x6D5D
void func_98() {
	if (Global_2433125.f_2199[0 /*76*/].f_2 != 0) {
		Global_2433125.f_2199[0 /*76*/].f_2 = 5;
	}
}

// Position - 0x6D82
void func_99() { Global_25334 = 1; }

// Position - 0x6D8E
void func_100(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, char *sParam6,
			  int iParam7, int iParam8, int iParam9, int iParam10, int iParam11) {
	int iVar0;
	int iVar1;

	if (func_101(sParam6)) {
		sParam6 = "NUMBER";
	}
	iVar0 = -1;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (iVar0 == -1) {
			if (func_31(3, iVar1) == 0) {
				iVar0 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar0 > -1) {
		Global_1354542.f_1 = 1;
		func_30(3, iVar0);
		Global_1354542.f_2539[iVar0] = iParam0;
		StringCopy(&Global_1354542.f_2539.f_11[iVar0 /*16*/], sParam1, 64);
		Global_1354542.f_2539.f_183[iVar0] = iParam3;
		Global_1354542.f_2539.f_172[iVar0] = iParam2;
		Global_1354542.f_2539.f_205[iVar0] = iParam4;
		Global_1354542.f_2539.f_216[iVar0] = iParam5;
		StringCopy(&Global_1354542.f_2539.f_259[iVar0 /*16*/], sParam6, 64);
		Global_1354542.f_2539.f_420[iVar0] = iParam7;
		Global_1354542.f_2539.f_453[iVar0] = iParam8;
		Global_1354542.f_2539.f_431[iVar0] = iParam9;
		Global_1354542.f_2539.f_442[iVar0] = iParam10;
		Global_1354542.f_2539.f_464[iVar0] = iParam11;
	}
}

// Position - 0x6EA0
bool func_101(char *sParam0) {
	if (gameplay::is_string_null(sParam0)) {
		return true;
	}
	else if (gameplay::are_strings_equal(sParam0, "") || gameplay::are_strings_equal(sParam0, "0")) {
		return true;
	}
	return false;
}

// Position - 0x6EDA
char *func_102(bool bParam0, char *sParam1, char *sParam2) {
	if (bParam0) {
		return sParam1;
	}
	return sParam2;
}

// Position - 0x6EF1
int func_103(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x6F08
void func_104(var *uParam0, int iParam1) {
	if (iParam1) {
		func_106(&uParam0->f_1, 1024);
	}
	else {
		func_105(&uParam0->f_1, 1024);
	}
}

// Position - 0x6F2E
void func_105(int *iParam0, int iParam1) { *iParam0 -= (*iParam0 & iParam1); }

// Position - 0x6F43
void func_106(var *uParam0, int iParam1) { *uParam0 |= iParam1; }

// Position - 0x6F54
int func_107(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;

	if (*uParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	if (iParam5 == 1) {
		iVar0 = 1;
	}
	iVar1 = uParam0->f_123;
	if (iVar1 < 8) {
		uParam0->f_2[iVar1 /*15*/] = sParam1;
		uParam0->f_2[iVar1 /*15*/].f_1 = iVar0;
		uParam0->f_2[iVar1 /*15*/].f_2 = iParam6;
		uParam0->f_2[iVar1 /*15*/].f_12 = 0;
		uParam0->f_2[iVar1 /*15*/].f_13 = 0;
		uParam0->f_2[iVar1 /*15*/].f_14 = 0;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/] = iParam2;
		uParam0->f_2[iVar1 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
		if (iParam4 == 1) {
			gameplay::set_bit(&uParam0->f_2[iVar1 /*15*/].f_13, 0);
		}
		uParam0->f_2[iVar1 /*15*/].f_14++;
		uParam0->f_123++;
		return 1;
	}
	return 0;
}

// Position - 0x701D
void func_108(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (*uParam0 == 0) {
		*uParam0 = graphics::request_scaleform_movie_instance("instructional_buttons");
	}
	uParam0->f_1 = 0;
	uParam0->f_123 = 0;
	if (iParam1) {
		func_106(&uParam0->f_1, 32);
	}
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		func_106(&uParam0->f_1, 1);
		if (iParam2) {
			graphics::set_scaleform_movie_to_use_system_time(*uParam0, 1);
		}
	}
	if (gameplay::is_pc_version()) {
		if (iParam3) {
			func_106(&uParam0->f_1, 4096);
		}
	}
	if (iParam4) {
		func_106(&uParam0->f_1, 8192);
	}
}

// Position - 0x7097
bool func_109(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_42, 1) && Global_1835390.f_2704[0] > 0 && uParam0->f_246.f_1 >= 0) {
		return true;
	}
	return false;
}

// Position - 0x70CE
void func_110(var *uParam0, float fParam1, int iParam2, int iParam3, int iParam4, float fParam5) {
	int iVar0;
	int iVar1;
	int iVar2;
	char *sVar3;
	bool bVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	float fVar8;

	if (cam::is_screen_fading_out() || cam::is_screen_fading_in() || cam::is_screen_faded_out() ||
		gameplay::is_frontend_fading()) {
		if (!iParam3) {
			return;
		}
	}
	if (!func_113(uParam0)) {
		return;
	}
	ui::hide_loading_on_fade_this_frame();
	graphics::_set_2d_layer(iParam2);
	if (!func_112(uParam0->f_1, 256) || func_112(uParam0->f_1, 8192) && controls::_0x6CD79468A1E595C6(2)) {
		graphics::_push_scaleform_movie_function(*uParam0, "SET_CLEAR_SPACE");
		graphics::_push_scaleform_movie_function_parameter_float(fParam1);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_MAX_WIDTH");
		graphics::_push_scaleform_movie_function_parameter_float(fParam5);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(*uParam0, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(func_112(uParam0->f_1, 4096));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar5 = 0;
		iVar6 = 0;
		while (iVar6 < uParam0->f_123) {
			switch (uParam0->f_2[iVar6 /*15*/].f_2) {
			case 0: bVar4 = true; break;

			case 1: bVar4 = controls::_is_input_disabled(2); break;

			case 2: bVar4 = !controls::_is_input_disabled(2); break;

			default: bVar4 = false; break;
			}
			if (bVar4) {
				if (graphics::_push_scaleform_movie_function(*uParam0, "SET_DATA_SLOT")) {
					graphics::_push_scaleform_movie_function_parameter_int(iVar5);
					iVar5++;
					iVar7 = 0;
					while (iVar7 < uParam0->f_2[iVar6 /*15*/].f_14) {
						iVar0 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/];
						iVar1 = uParam0->f_2[iVar6 /*15*/].f_3[iVar7 /*2*/].f_1;
						iVar2 = gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_13, iVar7);
						if (!gameplay::is_bit_set(uParam0->f_2[iVar6 /*15*/].f_12, iVar7)) {
							sVar3 = controls::get_control_instructional_button(iVar0, iVar1, iVar2);
						}
						else {
							sVar3 = controls::_0x80C2FD58D720C801(iVar0, iVar1, iVar2);
						}
						if (!gameplay::is_string_null_or_empty(sVar3)) {
							func_13(sVar3);
						}
						iVar7++;
					}
					if (!gameplay::is_string_null_or_empty(uParam0->f_2[iVar6 /*15*/])) {
						func_12(uParam0->f_2[iVar6 /*15*/]);
					}
					if (gameplay::is_pc_version()) {
						if (func_112(uParam0->f_1, 4096)) {
							if (uParam0->f_2[iVar6 /*15*/].f_1) {
								graphics::_push_scaleform_movie_function_parameter_bool(1);
								graphics::_push_scaleform_movie_function_parameter_int(
									uParam0->f_2[iVar6 /*15*/].f_3[0 /*2*/].f_1);
							}
							else {
								graphics::_push_scaleform_movie_function_parameter_bool(0);
								graphics::_push_scaleform_movie_function_parameter_int(-1);
							}
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar6++;
		}
		fVar8 = func_111(iParam4, func_111(func_112(uParam0->f_1, 32), 1f, 0f), -1f);
		graphics::_push_scaleform_movie_function(*uParam0, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_float(fVar8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(*uParam0, "SET_BACKGROUND_COLOUR");
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(0f);
		graphics::_push_scaleform_movie_function_parameter_float(80f);
		graphics::_pop_scaleform_movie_function_void();
		func_106(&uParam0->f_1, 256);
		func_105(&uParam0->f_1, 128);
	}
	graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 0, 0);
}

// Position - 0x738E
float func_111(bool bParam0, float fParam1, float fParam2) {
	if (bParam0) {
		return fParam1;
	}
	return fParam2;
}

// Position - 0x73A5
bool func_112(var uParam0, int iParam1) { return (uParam0 & iParam1) != 0; }

// Position - 0x73B4
int func_113(var *uParam0) {
	if (*uParam0 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			func_106(&uParam0->f_1, 1);
			return 1;
		}
	}
	return 0;
}

// Position - 0x73DB
void func_114(var *uParam0, var *uParam1) { func_115(uParam1, uParam0); }

// Position - 0x73EB
void func_115(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	var uVar2[3];
	int iVar6;
	int iVar7;
	bool bVar8;
	struct<8> Var9;
	char[] cVar25[8];
	int iVar27[3];
	int iVar31;
	struct<13> Var32;
	var uVar45;
	vector3 vVar51;
	vector3 vVar57;
	int iVar63;

	func_190(&Global_1840922.f_49, 1, 0);
	ui::hide_help_text_this_frame();
	func_189();
	func_37();
	ui::hide_hud_and_radar_this_frame();
	func_187();
	ui::hide_hud_component_this_frame(10);
	func_186(1);
	func_185(1);
	if (!func_182()) {
		if (!audio::is_audio_scene_active("LEADERBOARD_SCENE")) {
			audio::start_audio_scene("LEADERBOARD_SCENE");
		}
	}
	if (!gameplay::is_bit_set(uParam1->f_42, 3)) {
		*uParam0 = func_181();
		gameplay::set_bit(&uParam1->f_42, 3);
	}
	Var32 = {func_23(player::player_id())};
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		if (!network::_network_are_ros_available() || !player::is_player_online() ||
			!network::network_have_online_privileges() && network::_0x1353F87E89946207() ||
			Global_1835390.f_2832 != 0) {
			if (!player::is_player_online()) {
				if (Global_1835390.f_2829 != 2) {
					gameplay::clear_bit(&uParam1->f_42, 1);
					Global_1835390.f_2829 = 2;
				}
			}
			else if (!network::network_have_online_privileges() && network::_0x1353F87E89946207()) {
				if (Global_1835390.f_2829 != 3) {
					gameplay::clear_bit(&uParam1->f_42, 1);
					Global_1835390.f_2829 = 3;
				}
			}
			else if (!network::_network_are_ros_available()) {
				if (Global_1835390.f_2829 != 4) {
					gameplay::clear_bit(&uParam1->f_42, 1);
					Global_1835390.f_2829 = 4;
				}
			}
			else if (Global_1835390.f_2832 != 0) {
				if (Global_1835390.f_2829 != 5) {
					gameplay::clear_bit(&uParam1->f_42, 1);
					Global_1835390.f_2829 = 5;
				}
			}
			if (!gameplay::is_bit_set(uParam1->f_42, 1)) {
				graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
				graphics::_pop_scaleform_movie_function_void();
				func_180(*uParam0, Global_1835390.f_2780);
				if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
					if (!func_179(uParam1->f_44)) {
						if (Global_1835390.f_2780.f_26 > 0) {
							Var9 = {Global_1835390.f_2780.f_9};
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9, Global_1835390.f_2780.f_25,
									 Global_1835390.f_2780.f_26);
						}
						else {
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Global_1835390.f_2780.f_9,
									 Global_1835390.f_2780.f_25, -1);
						}
					}
					else if (!Global_1835390.f_2780.f_27) {
						StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
						if (Global_1835390.f_2780.f_26 > 0) {
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
									 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
						}
						else {
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
									 Global_1835390.f_2780.f_25, -1);
						}
					}
					else {
						StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
						if (Global_1835390.f_2780.f_26 > 0) {
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
									 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
						}
						else {
							func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
									 Global_1835390.f_2780.f_25, -1);
						}
					}
					func_177(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717, Global_1835390.f_2708);
				}
				iVar31 = 0;
				gameplay::set_bit(&iVar31, 4);
				func_176(*uParam0, &iVar6, iVar31, 1, 1);
				iVar31 = 0;
				gameplay::set_bit(&iVar31, 5);
				func_176(*uParam0, &iVar6, iVar31, 1, 1);
				iVar31 = 0;
				gameplay::set_bit(&iVar31, 6);
				func_176(*uParam0, &iVar6, iVar31, 1, 1);
				gameplay::set_bit(&uParam1->f_42, 1);
				func_175(*uParam0);
				gameplay::clear_bit(&uParam1->f_42, 2);
				ui::clear_help(1);
			}
			else {
				func_175(*uParam0);
			}
		}
		else {
			if (Global_1835390.f_2829 != 1) {
				gameplay::clear_bit(&uParam1->f_42, 1);
				Global_1835390.f_2829 = 1;
			}
			if (!func_140(uParam1)) {
				uParam1->f_246.f_1 = -1;
				gameplay::clear_bit(&uParam1->f_42, 1);
				if (!gameplay::is_bit_set(uParam1->f_42, 0)) {
					graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
					graphics::_pop_scaleform_movie_function_void();
					func_180(*uParam0, Global_1835390.f_2780);
					if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
						if (!func_179(uParam1->f_44)) {
							if (Global_1835390.f_2780.f_26 > 0) {
								Var9 = {Global_1835390.f_2780.f_9};
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9, 1,
										 Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						else if (!Global_1835390.f_2780.f_27) {
							StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
							if (Global_1835390.f_2780.f_26 > 0) {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						else {
							StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
							if (Global_1835390.f_2780.f_26 > 0) {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						func_177(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717, Global_1835390.f_2708);
					}
					gameplay::set_bit(&uParam1->f_42, 0);
					gameplay::clear_bit(&uParam1->f_42, 2);
				}
				iVar6 = 0;
				iVar0 = 0;
				if (Global_1835390.f_2825 == -1) {
					StringCopy(&vVar51, "SC_LB_DL0", 24);
					iVar0 = 0;
					while (iVar0 < 3) {
						if (iVar0 == 0) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 4);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						else if (iVar0 == 1) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 5);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						else if (iVar0 == 2) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 6);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						iVar31 = 0;
						gameplay::set_bit(&iVar31, 7);
						func_139(*uParam0, iVar6, iVar31, &vVar51);
						iVar6++;
						iVar0++;
					}
					Global_1835390.f_2825 = 1;
					func_85(&Global_1835390.f_2823);
				}
				else if (func_137(&Global_1835390.f_2823, 300, 0)) {
					StringCopy(&vVar57, "SC_LB_DL", 24);
					StringIntConCat(&vVar57, Global_1835390.f_2825, 24);
					iVar0 = 0;
					while (iVar0 < 3) {
						if (iVar0 == 0) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 4);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						else if (iVar0 == 1) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 5);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						else if (iVar0 == 2) {
							iVar31 = 0;
							gameplay::set_bit(&iVar31, 6);
							func_176(*uParam0, &iVar6, iVar31, 0, 0);
						}
						iVar31 = 0;
						gameplay::set_bit(&iVar31, 7);
						func_139(*uParam0, iVar6, iVar31, &vVar57);
						iVar6++;
						iVar0++;
					}
					Global_1835390.f_2825++;
					if (Global_1835390.f_2825 > 3) {
						Global_1835390.f_2825 = 0;
					}
					func_85(&Global_1835390.f_2823);
				}
				func_175(*uParam0);
			}
			else {
				gameplay::clear_bit(&uParam1->f_42, 0);
				if (!gameplay::is_bit_set(uParam1->f_42, 1)) {
					iVar0 = 0;
					while (iVar0 < 3) {
						uParam1->f_246.f_187[iVar0] = 0;
						iVar0++;
					}
					graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_ALL_SLOTS");
					graphics::_pop_scaleform_movie_function_void();
					func_180(*uParam0, Global_1835390.f_2780);
					if (ui::does_text_label_exist(&Global_1835390.f_2780.f_1)) {
						if (!func_179(uParam1->f_44)) {
							if (Global_1835390.f_2780.f_26 > 0) {
								Var9 = {Global_1835390.f_2780.f_9};
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Var9, 1,
										 Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &cVar25, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						else if (!Global_1835390.f_2780.f_27) {
							StringCopy(&Var9, "FMMC_COR_SCLB5", 64);
							if (Global_1835390.f_2780.f_26 > 0) {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						else {
							StringCopy(&Var9, "FMMC_COR_SCLB6", 64);
							if (Global_1835390.f_2780.f_26 > 0) {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, Global_1835390.f_2780.f_26);
							}
							else {
								func_178(*uParam0, &Global_1835390.f_2780.f_1, &Var9, &Global_1835390.f_2780.f_9,
										 Global_1835390.f_2780.f_25, -1);
							}
						}
						func_177(*uParam0, "SCLB_C_RANK", &Global_1835390.f_2717, Global_1835390.f_2708);
					}
					if (!gameplay::is_bit_set(uParam1->f_42, 6)) {
						func_88(&Global_1839721);
						func_133(uParam1, &Global_1839721);
						func_132(uParam1, &Global_1839721);
					}
					iVar6 = 0;
					uParam1->f_246.f_2 = 0;
					if (Global_1835390.f_2704[0] > 1 ||
						Global_1835390.f_2704[0] > 0 && Global_1835390.f_2775[0] != -1 ||
						Global_1835390.f_2704[0] > 0 && Global_1835390.f_2780.f_27 && func_179(uParam1->f_44) &&
							Global_1835390.f_2775[0] != -1) {
						uParam1->f_246.f_1 = -1;
						iVar0 = 0;
						iVar0 = 0;
						while (iVar0 < 12) {
							iVar63 = 0;
							if (Global_1839721[iVar0 /*100*/].f_75 == 1) {
								if (!iVar27[0]) {
									iVar31 = 0;
									gameplay::set_bit(&iVar31, 4);
									func_176(*uParam0, &iVar6, iVar31, 0, 0);
									iVar27[0] = 1;
								}
							}
							else if (Global_1839721[iVar0 /*100*/].f_75 == 2) {
								if (!iVar27[1]) {
									iVar31 = 0;
									gameplay::set_bit(&iVar31, 5);
									if (Global_1835390.f_2704[1] < 1 && Global_1835390.f_2775[1] == -1 &&
										!(Global_1835390.f_2704[1] > 0 && Global_1835390.f_2780.f_27 &&
										  func_179(uParam1->f_44) && Global_1835390.f_2775[1] != -1)) {
										func_176(*uParam0, &iVar6, iVar31, 1, 0);
										iVar63 = 1;
									}
									else {
										func_176(*uParam0, &iVar6, iVar31, 0, 0);
									}
									iVar27[1] = 1;
								}
							}
							else if (Global_1839721[iVar0 /*100*/].f_75 == 3) {
								if (!iVar27[2]) {
									iVar31 = 0;
									gameplay::set_bit(&iVar31, 6);
									if (!network::_0x67A5589628E0CFF6()) {
										iVar63 = 1;
									}
									else if (!network::_0xBA9775570DB788CF()) {
										iVar63 = 1;
									}
									if (Global_1835390.f_2704[2] < 2 && Global_1835390.f_2775[2] == -1 &&
										!(Global_1835390.f_2704[2] > 0 && Global_1835390.f_2780.f_27 &&
										  func_179(uParam1->f_44) && Global_1835390.f_2775[2] != -1)) {
										iVar63 = 1;
									}
									if (iVar63) {
										func_176(*uParam0, &iVar6, iVar31, 1, 0);
									}
									else {
										func_176(*uParam0, &iVar6, iVar31, 0, 0);
									}
									iVar27[2] = 1;
								}
							}
							if (func_131(Global_1839721[iVar0 /*100*/].f_32)) {
								if (func_179(uParam1->f_44)) {
									network::network_player_get_userid(player::player_id(), &uVar45);
									if (!Global_1839721[iVar0 /*100*/].f_74 &&
										gameplay::are_strings_equal(&uParam1->f_44.f_3.f_1[1 /*16*/].f_8, &uVar45)) {
										iVar63 = 1;
									}
								}
								if (!iVar63) {
									iVar31 = 0;
									if (!Global_1835390.f_2780.f_27) {
										if (func_130(&Global_1839721[iVar0 /*100*/].f_32, &Var32)) {
											gameplay::set_bit(&iVar31, 1);
											if (uParam1->f_246.f_1 == -1) {
												iVar7 = 1;
												uParam1->f_246.f_1 = iVar0;
												gameplay::set_bit(&iVar31, 3);
											}
										}
									}
									if (func_179(uParam1->f_44)) {
										Var9 = {Global_1839721[iVar0 /*100*/]};
										if (!gameplay::is_string_null_or_empty(&Global_1839721[iVar0 /*100*/].f_84) &&
											!gameplay::are_strings_equal(&Global_1839721[iVar0 /*100*/].f_84, "")) {
											StringConCat(&Var9, "/", 64);
											StringConCat(&Var9, &Global_1839721[iVar0 /*100*/].f_84, 64);
										}
										func_129(*uParam0, iVar6, iVar31, Global_1839721[iVar0 /*100*/].f_59, &Var9,
												 &Global_1839721[iVar0 /*100*/].f_80);
										uParam1->f_246.f_6[iVar0 /*15*/] = iVar6;
										uParam1->f_246.f_6[iVar0 /*15*/].f_1 = iVar31;
										uParam1->f_246.f_6[iVar0 /*15*/].f_2 = {Global_1839721[iVar0 /*100*/].f_32};
										uParam1->f_246.f_2++;
									}
									else {
										func_129(*uParam0, iVar6, iVar31, Global_1839721[iVar0 /*100*/].f_59,
												 &Global_1839721[iVar0 /*100*/], &Global_1839721[iVar0 /*100*/].f_80);
										uParam1->f_246.f_6[iVar0 /*15*/] = iVar6;
										uParam1->f_246.f_6[iVar0 /*15*/].f_1 = iVar31;
										uParam1->f_246.f_6[iVar0 /*15*/].f_2 = {Global_1839721[iVar0 /*100*/].f_32};
										uParam1->f_246.f_2++;
									}
									iVar1 = 0;
									while (iVar1 < Global_1835390.f_2708) {
										bVar8 = false;
										if (gameplay::is_bit_set(Global_1835390.f_2770, iVar1)) {
											if (gameplay::is_bit_set(Global_1835390.f_2768, iVar1)) {
												if (Global_1835390.f_2754[iVar1] ==
													Global_1839721[iVar0 /*100*/].f_67[iVar1]) {
													bVar8 = true;
												}
											}
											if (bVar8) {
												func_124(Global_1835390.f_2780, iVar1,
														 Global_1839721[iVar0 /*100*/].f_67[iVar1], 0,
														 Global_1839721[iVar0 /*100*/].f_58);
											}
											else {
												func_124(Global_1835390.f_2780, iVar1,
														 Global_1839721[iVar0 /*100*/].f_67[iVar1],
														 Global_1839721[iVar0 /*100*/].f_74,
														 Global_1839721[iVar0 /*100*/].f_58);
											}
										}
										else {
											if (gameplay::is_bit_set(Global_1835390.f_2768, iVar1)) {
												if (Global_1835390.f_2761[iVar1] ==
													Global_1839721[iVar0 /*100*/].f_67[iVar1]) {
													bVar8 = true;
												}
											}
											if (bVar8) {
												func_121(Global_1835390.f_2780, iVar1,
														 Global_1839721[iVar0 /*100*/].f_60[iVar1], 0);
											}
											else {
												func_121(Global_1835390.f_2780, iVar1,
														 Global_1839721[iVar0 /*100*/].f_60[iVar1],
														 Global_1839721[iVar0 /*100*/].f_74);
											}
										}
										iVar1++;
									}
									func_120();
									uVar2[Global_1839721[iVar0 /*100*/].f_75 - 1]++;
									if (uVar2[Global_1839721[iVar0 /*100*/].f_75 - 1] == 2) {
										if (Global_1839721[iVar0 /*100*/].f_59 > 2) {
											gameplay::set_bit(&iVar31, 2);
											gameplay::set_bit(&uParam1->f_246.f_6[0 /*15*/].f_1, 2);
											func_119(*uParam0, iVar6 - 1, iVar31);
										}
									}
									iVar6++;
								}
							}
							iVar0++;
						}
						iVar0 = 0;
						iVar0 = 0;
						while (iVar0 < 3) {
							uParam1->f_246.f_187[iVar0] = uVar2[iVar0];
							iVar0++;
						}
					}
					else {
						iVar31 = 0;
						gameplay::set_bit(&iVar31, 4);
						func_176(*uParam0, &iVar6, iVar31, 1, 0);
						iVar31 = 0;
						gameplay::set_bit(&iVar31, 5);
						func_176(*uParam0, &iVar6, iVar31, 1, 0);
						iVar31 = 0;
						gameplay::set_bit(&iVar31, 6);
						func_176(*uParam0, &iVar6, iVar31, 1, 0);
					}
					gameplay::set_bit(&uParam1->f_42, 1);
					gameplay::clear_bit(&uParam1->f_42, 2);
					func_175(*uParam0);
					ui::clear_help(1);
					if (uParam1->f_246.f_1 == -1 && !iVar7 == 1) {
						if (Global_1835390.f_2704[0] > 1) {
							uParam1->f_246.f_1 = 0;
							gameplay::set_bit(&uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1, 3);
							func_119(*uParam0, uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/],
									 uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1);
						}
					}
				}
				else {
					func_175(*uParam0);
					func_116(uParam0, uParam1);
				}
			}
		}
	}
}

// Position - 0x83C8
void func_116(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	var uVar4;
	var *uVar5;
	int iVar6;
	var *uVar7;
	var *uVar8;

	iVar1 = uParam1->f_246.f_1;
	if (controls::_is_input_disabled(2)) {
		ui::_show_cursor_this_frame();
		controls::set_input_exclusive(2, 239);
		controls::set_input_exclusive(2, 240);
		controls::set_input_exclusive(2, 237);
		controls::set_input_exclusive(2, 238);
		controls::disable_control_action(2, 200, 1);
		if (controls::is_disabled_control_pressed(2, 241)) {
			controls::_set_control_normal(2, 188, 1f);
		}
		if (controls::is_disabled_control_pressed(2, 242)) {
			controls::_set_control_normal(2, 187, 1f);
		}
		if (ui::_0x632B2940C67F4EA9(*uParam0, &iVar2, &iVar3, &uVar4)) {
			if (iVar2 == 5) {
				if (iVar3 > uParam1->f_246.f_187[0]) {
					if (iVar3 <= uParam1->f_246.f_187[0] + uParam1->f_246.f_187[1] + 2) {
						iVar3 -= 2;
					}
					else {
						iVar3 -= 4;
					}
				}
				iVar3--;
				if (uParam1->f_246.f_1 != iVar3) {
					uParam1->f_246.f_1 = iVar3;
					audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
					iVar0 = 1;
				}
				else {
					controls::_set_control_normal(2, 217, 1f);
				}
			}
		}
	}
	if (!controls::_is_input_disabled(2)) {
		func_118(&uVar5, &iVar6, &uVar7, &uVar8, 0);
	}
	if (uParam1->f_246.f_2 > 0) {
		if (!gameplay::is_bit_set(uParam1->f_246, 0)) {
			if (controls::is_control_pressed(2, 188) || controls::is_disabled_control_pressed(2, 188) || iVar6 < -100) {
				audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				uParam1->f_246.f_1 += -1;
				gameplay::set_bit(&uParam1->f_246, 0);
				func_85(&uParam1->f_246.f_3);
				iVar0 = 1;
			}
		}
		else if (func_117(uParam1, 188)) {
			gameplay::clear_bit(&uParam1->f_246, 0);
		}
		if (!gameplay::is_bit_set(uParam1->f_246, 1)) {
			if (controls::is_control_pressed(2, 187) || controls::is_disabled_control_pressed(2, 187) || iVar6 > 100) {
				audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				uParam1->f_246.f_1++;
				gameplay::set_bit(&uParam1->f_246, 1);
				func_85(&uParam1->f_246.f_3);
				iVar0 = 1;
			}
		}
		else if (func_117(uParam1, 187)) {
			gameplay::clear_bit(&uParam1->f_246, 1);
		}
	}
	if (iVar0) {
		if (uParam1->f_246.f_1 < 0) {
			uParam1->f_246.f_1 = uParam1->f_246.f_2 - 1;
		}
		if (uParam1->f_246.f_1 >= uParam1->f_246.f_2) {
			uParam1->f_246.f_1 = 0;
		}
	}
	if (!gameplay::is_bit_set(uParam1->f_246, 3)) {
		if (controls::is_control_pressed(2, 204) || controls::is_disabled_control_just_pressed(2, 204) ||
			controls::is_control_just_pressed(2, 237)) {
			gameplay::set_bit(&uParam1->f_246, 3);
			func_85(&uParam1->f_246.f_3);
			iVar0 = 1;
		}
	}
	else if (func_117(uParam1, 204)) {
		gameplay::clear_bit(&uParam1->f_246, 3);
	}
	if (uParam1->f_246.f_1 >= 0) {
		if (uParam1->f_246.f_1 != iVar1) {
			if (iVar1 >= 0) {
				gameplay::clear_bit(&uParam1->f_246.f_6[iVar1 /*15*/].f_1, 3);
				func_119(*uParam0, uParam1->f_246.f_6[iVar1 /*15*/], uParam1->f_246.f_6[iVar1 /*15*/].f_1);
			}
			gameplay::set_bit(&uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1, 3);
			func_119(*uParam0, uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/],
					 uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_1);
			gameplay::clear_bit(&uParam1->f_42, 2);
		}
		if (func_131(uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_2)) {
			if (!gameplay::is_bit_set(uParam1->f_246, 2)) {
				if (controls::is_control_pressed(2, 217) || controls::is_disabled_control_just_pressed(2, 217)) {
					if (!player::is_system_ui_being_displayed()) {
						audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_MP_SOUNDSET", 1);
						gameplay::set_bit(&uParam1->f_246, 2);
						network::network_show_profile_ui(&uParam1->f_246.f_6[uParam1->f_246.f_1 /*15*/].f_2);
					}
				}
			}
			else if (!controls::is_control_pressed(2, 217)) {
				gameplay::clear_bit(&uParam1->f_246, 2);
			}
		}
	}
}

// Position - 0x876A
bool func_117(var *uParam0, int iParam1) {
	var *uVar0;
	int iVar1;
	var *uVar2;
	var *uVar3;

	if (iParam1 == 188 || iParam1 == 187) {
		func_118(&uVar0, &iVar1, &uVar2, &uVar3, 0);
		if (!controls::is_control_pressed(2, iParam1) && !controls::is_disabled_control_pressed(2, iParam1) &&
				iVar1 < 75 && iVar1 > -75 ||
			func_137(&uParam0->f_246.f_3, 250, 0)) {
			return true;
		}
	}
	else if (!controls::is_control_pressed(2, iParam1) && !controls::is_disabled_control_pressed(2, iParam1) ||
			 func_137(&uParam0->f_246.f_3, 250, 0)) {
		return true;
	}
	return false;
}

// Position - 0x8809
void func_118(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int iParam4) {
	*uParam0 = system::floor(controls::get_control_normal(2, 218) * 127f);
	*uParam1 = system::floor(controls::get_control_normal(2, 219) * 127f);
	*uParam2 = system::floor(controls::get_control_normal(2, 220) * 127f);
	*uParam3 = system::floor(controls::get_control_normal(2, 221) * 127f);
	if (iParam4) {
		if (IntToFloat(*uParam0) == 0f && IntToFloat(*uParam1) == 0f) {
			*uParam0 = system::floor(controls::get_disabled_control_normal(2, 218) * 127f);
			*uParam1 = system::floor(controls::get_disabled_control_normal(2, 219) * 127f);
		}
		if (IntToFloat(*uParam2) == 0f && IntToFloat(*uParam3) == 0f) {
			*uParam2 = system::floor(controls::get_disabled_control_normal(2, 220) * 127f);
			*uParam3 = system::floor(controls::get_disabled_control_normal(2, 221) * 127f);
		}
	}
}

// Position - 0x88DE
void func_119(int iParam0, int iParam1, int iParam2) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT_STATE");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x8901
void func_120() { graphics::_pop_scaleform_movie_function_void(); }

// Position - 0x890D
void func_121(struct<30> Param0, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
			  var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
			  int iParam43, float fParam44, int iParam45) {
	switch (Param0.f_29[iParam43]) {
	case 4:
		if (iParam45) {
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_float(fParam44, 2);
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 12:
		if (iParam45) {
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_integer(system::floor(fParam44));
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 17:
	case 19:
	case 18:
	case 20:
		if (iParam45) {
			if (Param0.f_29[iParam43] == 18 || Param0.f_29[iParam43] == 20) {
				fParam44 *= -1f;
			}
			if (!gameplay::_0xD3D15555431AB793()) {
				if (Param0.f_29[iParam43] == 19 || Param0.f_29[iParam43] == 20) {
					fParam44 = func_123(fParam44);
				}
				else {
					fParam44 = func_122(fParam44);
				}
			}
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_float(fParam44, 2);
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 0: break;
	}
}

// Position - 0x8A2F
float func_122(float fParam0) { return fParam0 / 0.3048f; }

// Position - 0x8A3F
float func_123(float fParam0) { return fParam0 / 1609.344f; }

// Position - 0x8A4F
void func_124(struct<30> Param0, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
			  var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
			  int iParam43, int iParam44, int iParam45, bool bParam46) {
	if (iParam44 == 2147483647 || iParam44 == -2147483647) {
		iParam45 = 0;
	}
	switch (Param0.f_29[iParam43]) {
	case 5:
		if (iParam45) {
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_integer(iParam44);
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 7:
		if (iParam45) {
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_integer(-iParam44);
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 1:
	case 9:
	case 11:
		if (iParam45) {
			if (Param0.f_29[iParam43] == 11 && iParam44 < 0) {
				iParam44 *= -1;
			}
			if (iParam44 >= 3600000 || iParam44 <= -3600000) {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 14);
				graphics::end_text_command_scaleform_string();
			}
			else if (Param0.f_29[iParam43] == 9) {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 6);
				graphics::end_text_command_scaleform_string();
			}
			else {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 2055);
				graphics::end_text_command_scaleform_string();
			}
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 6:
		if (iParam45) {
			if (iParam44 == 2147483647) {
				graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
				graphics::end_text_command_scaleform_string();
			}
			else if (iParam44 >= 3600000 || iParam44 <= -3600000) {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 14);
				graphics::end_text_command_scaleform_string();
			}
			else {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 2055);
				graphics::end_text_command_scaleform_string();
			}
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 2:
	case 10:
		if (iParam45) {
			iParam44 *= -1;
			if (iParam44 >= 3600000 || iParam44 <= -3600000) {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 14);
				graphics::end_text_command_scaleform_string();
			}
			else if (Param0.f_29[iParam43] == 10) {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 6);
				graphics::end_text_command_scaleform_string();
			}
			else {
				graphics::begin_text_command_scaleform_string("STRING");
				ui::add_text_component_substring_time(iParam44, 2055);
				graphics::end_text_command_scaleform_string();
			}
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 3:
		if (bParam46) {
			if (streaming::is_model_in_cdimage(iParam44)) {
				graphics::begin_text_command_scaleform_string("SCLB_VEH_CUST");
				ui::add_text_component_substring_text_label(vehicle::get_display_name_from_vehicle_model(iParam44));
				graphics::end_text_command_scaleform_string();
			}
			else {
				graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
				graphics::end_text_command_scaleform_string();
			}
		}
		else if (streaming::is_model_in_cdimage(iParam44)) {
			graphics::begin_text_command_scaleform_string(vehicle::get_display_name_from_vehicle_model(iParam44));
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 8:
		if (func_128(iParam44) != 0) {
			graphics::begin_text_command_scaleform_string(func_125(func_128(iParam44), 0));
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 13:
	case 15:
	case 14:
	case 16:
		if (iParam45) {
			if (Param0.f_29[iParam43] == 14 || Param0.f_29[iParam43] == 16) {
				iParam44 *= -1;
			}
			if (!gameplay::_0xD3D15555431AB793()) {
				if (Param0.f_29[iParam43] == 15 || Param0.f_29[iParam43] == 16) {
					iParam44 = system::floor(func_123(system::to_float(iParam44)));
				}
				else {
					iParam44 = system::floor(func_122(system::to_float(iParam44)));
				}
			}
			graphics::begin_text_command_scaleform_string("NUMBER");
			ui::add_text_component_integer(iParam44);
			graphics::end_text_command_scaleform_string();
		}
		else {
			graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
			graphics::end_text_command_scaleform_string();
		}
		break;

	case 0: break;
	}
}

// Position - 0x8DE9
char *func_125(int iParam0, int iParam1) {
	struct<32> Var0;

	switch (iParam0) {
	case 0:
		if (iParam1) {
			return "WTU_INVALID";
		}
		else {
			return "WT_INVALID";
		}
		break;

	case joaat("weapon_unarmed"):
		if (iParam1) {
			return "WTU_UNARMED";
		}
		else {
			return "WT_UNARMED";
		}
		break;

	case joaat("weapon_pistol"):
		if (iParam1) {
			return "WTU_PIST";
		}
		else {
			return "WT_PIST";
		}
		break;

	case joaat("weapon_combatpistol"):
		if (iParam1) {
			return "WTU_PIST_CBT";
		}
		else {
			return "WT_PIST_CBT";
		}
		break;

	case joaat("weapon_appistol"):
		if (iParam1) {
			return "WTU_PIST_AP";
		}
		else {
			return "WT_PIST_AP";
		}
		break;

	case joaat("weapon_smg"):
		if (iParam1) {
			return "WTU_SMG";
		}
		else {
			return "WT_SMG";
		}
		break;

	case joaat("weapon_microsmg"):
		if (iParam1) {
			return "WTU_SMG_MCR";
		}
		else {
			return "WT_SMG_MCR";
		}
		break;

	case joaat("weapon_assaultrifle"):
		if (iParam1) {
			return "WTU_RIFLE_ASL";
		}
		else {
			return "WT_RIFLE_ASL";
		}
		break;

	case joaat("weapon_carbinerifle"):
		if (iParam1) {
			return "WTU_RIFLE_CBN";
		}
		else {
			return "WT_RIFLE_CBN";
		}
		break;

	case joaat("weapon_advancedrifle"):
		if (iParam1) {
			return "WTU_RIFLE_ADV";
		}
		else {
			return "WT_RIFLE_ADV";
		}
		break;

	case joaat("weapon_mg"):
		if (iParam1) {
			return "WTU_MG";
		}
		else {
			return "WT_MG";
		}
		break;

	case joaat("weapon_combatmg"):
		if (iParam1) {
			return "WTU_MG_CBT";
		}
		else {
			return "WT_MG_CBT";
		}
		break;

	case joaat("weapon_pumpshotgun"):
		if (iParam1) {
			return "WTU_SG_PMP";
		}
		else {
			return "WT_SG_PMP";
		}
		break;

	case joaat("weapon_sawnoffshotgun"):
		if (iParam1) {
			return "WTU_SG_SOF";
		}
		else {
			return "WT_SG_SOF";
		}
		break;

	case joaat("weapon_assaultshotgun"):
		if (iParam1) {
			return "WTU_SG_ASL";
		}
		else {
			return "WT_SG_ASL";
		}
		break;

	case joaat("weapon_heavysniper"):
		if (iParam1) {
			return "WTU_SNIP_HVY";
		}
		else {
			return "WT_SNIP_HVY";
		}
		break;

	case joaat("weapon_remotesniper"):
		if (iParam1) {
			return "WTU_SNIP_RMT";
		}
		else {
			return "WT_SNIP_RMT";
		}
		break;

	case joaat("weapon_sniperrifle"):
		if (iParam1) {
			return "WTU_SNIP_RIF";
		}
		else {
			return "WT_SNIP_RIF";
		}
		break;

	case joaat("weapon_grenadelauncher"):
		if (iParam1) {
			return "WTU_GL";
		}
		else {
			return "WT_GL";
		}
		break;

	case joaat("weapon_rpg"):
		if (iParam1) {
			return "WTU_RPG";
		}
		else {
			return "WT_RPG";
		}
		break;

	case joaat("weapon_minigun"):
		if (iParam1) {
			return "WTU_MINIGUN";
		}
		else {
			return "WT_MINIGUN";
		}
		break;

	case joaat("weapon_grenade"):
		if (iParam1) {
			return "WTU_GNADE";
		}
		else {
			return "WT_GNADE";
		}
		break;

	case joaat("weapon_smokegrenade"):
		if (iParam1) {
			return "WTU_GNADE_SMK";
		}
		else {
			return "WT_GNADE_SMK";
		}
		break;

	case joaat("weapon_stickybomb"):
		if (iParam1) {
			return "WTU_GNADE_STK";
		}
		else {
			return "WT_GNADE_STK";
		}
		break;

	case joaat("weapon_molotov"):
		if (iParam1) {
			return "WTU_MOLOTOV";
		}
		else {
			return "WT_MOLOTOV";
		}
		break;

	case joaat("weapon_stungun"):
		if (iParam1) {
			return "WTU_STUN";
		}
		else {
			return "WT_STUN";
		}
		break;

	case joaat("weapon_petrolcan"):
		if (iParam1) {
			return "WTU_PETROL";
		}
		else {
			return "WT_PETROL";
		}
		break;

	case joaat("weapon_electric_fence"):
		if (iParam1) {
			return "WTU_ELCFEN";
		}
		else {
			return "WT_ELCFEN";
		}
		break;

	case joaat("vehicle_weapon_tank"):
		if (iParam1) {
			return "WTU_V_TANK";
		}
		else {
			return "WT_V_TANK";
		}
		break;

	case joaat("vehicle_weapon_space_rocket"):
		if (iParam1) {
			return "WTU_V_SPACERKT";
		}
		else {
			return "WT_V_SPACERKT";
		}
		break;

	case joaat("vehicle_weapon_player_laser"):
		if (iParam1) {
			return "WTU_V_PLRLSR";
		}
		else {
			return "WT_V_PLRLSR";
		}
		break;

	case joaat("object"):
		if (iParam1) {
			return "WTU_OBJECT";
		}
		else {
			return "WT_OBJECT";
		}
		break;

	case joaat("gadget_parachute"):
		if (iParam1) {
			return "WTU_PARA";
		}
		else {
			return "WT_PARA";
		}
		break;

	case 1742569970:
		if (iParam1) {
			return "WTU_A_RPG";
		}
		else {
			return "WT_A_RPG";
		}
		break;

	case -1474608608:
		if (iParam1) {
			return "WTU_A_TANK";
		}
		else {
			return "WT_A_TANK";
		}
		break;

	case 527765612:
		if (iParam1) {
			return "WTU_A_SPACERKT";
		}
		else {
			return "WT_A_SPACERKT";
		}
		break;

	case -165357558:
		if (iParam1) {
			return "WTU_A_PLRLSR";
		}
		else {
			return "WT_A_PLRLSR";
		}
		break;

	case -1372674932:
		if (iParam1) {
			return "WTU_A_ENMYLSR";
		}
		else {
			return "WT_A_ENMYLSR";
		}
		break;

	case joaat("weapon_knife"):
		if (iParam1) {
			return "WTU_KNIFE";
		}
		else {
			return "WT_KNIFE";
		}
		break;

	case joaat("weapon_nightstick"):
		if (iParam1) {
			return "WTU_NGTSTK";
		}
		else {
			return "WT_NGTSTK";
		}
		break;

	case joaat("weapon_hammer"):
		if (iParam1) {
			return "WTU_HAMMER";
		}
		else {
			return "WT_HAMMER";
		}
		break;

	case joaat("weapon_bat"):
		if (iParam1) {
			return "WTU_BAT";
		}
		else {
			return "WT_BAT";
		}
		break;

	case joaat("weapon_crowbar"):
		if (iParam1) {
			return "WTU_CROWBAR";
		}
		else {
			return "WT_CROWBAR";
		}
		break;

	case joaat("weapon_golfclub"):
		if (iParam1) {
			return "WTU_GOLFCLUB";
		}
		else {
			return "WT_GOLFCLUB";
		}
		break;

	case joaat("weapon_rammed_by_car"):
		if (iParam1) {
			return "WTU_PIST";
		}
		else {
			return "WT_PIST";
		}
		break;

	case joaat("weapon_run_over_by_car"):
		if (iParam1) {
			return "WTU_PIST";
		}
		else {
			return "WT_PIST";
		}
		break;

	case joaat("weapon_assaultsmg"):
		if (iParam1) {
			return "WTU_SMG_ASL";
		}
		else {
			return "WT_SMG_ASL";
		}
		break;

	case joaat("weapon_bullpupshotgun"):
		if (iParam1) {
			return "WTU_SG_BLP";
		}
		else {
			return "WT_SG_BLP";
		}
		break;

	case joaat("weapon_pistol50"):
		if (iParam1) {
			return "WTU_PIST_50";
		}
		else {
			return "WT_PIST_50";
		}
		break;

	case joaat("weapon_bottle"):
		if (iParam1) {
			return "WTU_BOTTLE";
		}
		else {
			return "WT_BOTTLE";
		}
		break;

	case joaat("weapon_gusenberg"):
		if (iParam1) {
			return "WTU_GUSENBERG";
		}
		else {
			return "WT_GUSENBERG";
		}
		break;

	case joaat("weapon_snspistol"):
		if (iParam1) {
			return "WTU_SNSPISTOL";
		}
		else {
			return "WT_SNSPISTOL";
		}
		break;

	case joaat("weapon_vintagepistol"):
		if (iParam1) {
			return "WTU_VPISTOL";
		}
		else {
			return "WT_VPISTOL";
		}
		break;

	case joaat("weapon_dagger"):
		if (iParam1) {
			return "WTU_DAGGER";
		}
		else {
			return "WT_DAGGER";
		}
		break;

	case joaat("weapon_flaregun"):
		if (iParam1) {
			return "WTU_FLAREGUN";
		}
		else {
			return "WT_FLAREGUN";
		}
		break;

	case joaat("weapon_heavypistol"):
		if (iParam1) {
			return "WTU_HEAVYPSTL";
		}
		else {
			return "WT_HEAVYPSTL";
		}
		break;

	case joaat("weapon_specialcarbine"):
		if (iParam1) {
			return "WTU_RIFLE_SCBN";
		}
		else {
			return "WT_RIFLE_SCBN";
		}
		break;

	case joaat("weapon_musket"):
		if (iParam1) {
			return "WTU_MUSKET";
		}
		else {
			return "WT_MUSKET";
		}
		break;

	case joaat("weapon_firework"):
		if (iParam1) {
			return "WTU_FWRKLNCHR";
		}
		else {
			return "WT_FWRKLNCHR";
		}
		break;

	case joaat("weapon_marksmanrifle"):
		if (iParam1) {
			return "WTU_MKRIFLE";
		}
		else {
			return "WT_MKRIFLE";
		}
		break;

	case joaat("weapon_heavyshotgun"):
		if (iParam1) {
			return "WTU_HVYSHOT";
		}
		else {
			return "WT_HVYSHOT";
		}
		break;

	case joaat("weapon_proxmine"):
		if (iParam1) {
			return "WTU_PRXMINE";
		}
		else {
			return "WT_PRXMINE";
		}
		break;

	case joaat("weapon_hominglauncher"):
		if (iParam1) {
			return "WTU_HOMLNCH";
		}
		else {
			return "WT_HOMLNCH";
		}
		break;

	case joaat("weapon_hatchet"):
		if (iParam1) {
			return "WTU_HATCHET";
		}
		else {
			return "WT_HATCHET";
		}
		break;

	case joaat("weapon_railgun"):
		if (iParam1) {
			return "WTU_RAILGUN";
		}
		else {
			return "WT_RAILGUN";
		}
		break;

	case joaat("weapon_combatpdw"):
		if (iParam1) {
			return "WTU_COMBATPDW";
		}
		else {
			return "WT_COMBATPDW";
		}
		break;

	case joaat("weapon_knuckle"):
		if (iParam1) {
			return "WTU_KNUCKLE";
		}
		else {
			return "WT_KNUCKLE";
		}
		break;

	case joaat("weapon_marksmanpistol"):
		if (iParam1) {
			return "WTU_MKPISTOL";
		}
		else {
			return "WT_MKPISTOL";
		}
		break;

	case joaat("weapon_bullpuprifle"):
		if (iParam1) {
			return "WTU_BULLRIFLE";
		}
		else {
			return "WT_BULLRIFLE";
		}
		break;

	case joaat("weapon_machete"):
		if (iParam1) {
			return "WTU_MACHETE";
		}
		else {
			return "WT_MACHETE";
		}
		break;

	case joaat("weapon_machinepistol"):
		if (iParam1) {
			return "WTU_MCHPIST";
		}
		else {
			return "WT_MCHPIST";
		}
		break;

	case joaat("weapon_flashlight"):
		if (iParam1) {
			return "WTU_FLASHLIGHT";
		}
		else {
			return "WT_FLASHLIGHT";
		}
		break;

	case joaat("weapon_dbshotgun"):
		if (iParam1) {
			return "WTU_DBSHGN";
		}
		else {
			return "WT_DBSHGN";
		}
		break;

	case joaat("weapon_compactrifle"):
		if (iParam1) {
			return "WTU_CMPRIFLE";
		}
		else {
			return "WT_CMPRIFLE";
		}
		break;

	case joaat("weapon_switchblade"):
		if (iParam1) {
			return "WTU_SWBLADE";
		}
		else {
			return "WT_SWBLADE";
		}
		break;

	case joaat("weapon_revolver"):
		if (iParam1) {
			return "WTU_REVOLVER";
		}
		else {
			return "WT_REVOLVER";
		}
		break;

	case 317205821:
		if (iParam1) {
			return "WTU_AUTOSHGN";
		}
		else {
			return "WT_AUTOSHGN";
		}
		break;

	case -853065399:
		if (iParam1) {
			return "WTU_BATTLEAXE";
		}
		else {
			return "WT_BATTLEAXE";
		}
		break;

	case 125959754:
		if (iParam1) {
			return "WTU_CMPGL";
		}
		else {
			return "WT_CMPGL";
		}
		break;

	case -1121678507:
		if (iParam1) {
			return "WTU_MINISMG";
		}
		else {
			return "WT_MINISMG";
		}
		break;

	case -1169823560:
		if (iParam1) {
			return "WTU_PIPEBOMB";
		}
		else {
			return "WT_PIPEBOMB";
		}
		break;

	case -1810795771:
		if (iParam1) {
			return "WTU_POOLCUE";
		}
		else {
			return "WT_POOLCUE";
		}
		break;

	case 419712736:
		if (iParam1) {
			return "WTU_WRENCH";
		}
		else {
			return "WT_WRENCH";
		}
		break;

	case joaat("weapon_cougar"): return "WT_RAGE";

	case -159960575: return "WT_VEH_WEP";

	default:
		if (func_127(iParam0, &Var0) != -1) {
			if (iParam1) {
				return func_126(&Var0.f_31);
			}
			else {
				return func_126(&Var0.f_7);
			}
		}
		break;
	}
	return "WT_INVALID";
}

// Position - 0x9856
var func_126(var uParam0) { return uParam0; }

// Position - 0x9860
int func_127(int iParam0, var *uParam1) {
	int iVar0;
	int iVar1;

	iVar1 = dlc1::get_num_dlc_weapons();
	iVar0 = 0;
	while (iVar0 < iVar1) {
		if (dlc1::get_dlc_weapon_data(iVar0, uParam1)) {
			if (uParam1->f_1 == iParam0) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x989B
int func_128(int iParam0) {
	if (iParam0 == 600) {
		return joaat("weapon_railgun");
	}
	else if (iParam0 == 500) {
		return joaat("weapon_minigun");
	}
	else if (iParam0 == 400) {
		return joaat("weapon_mg");
	}
	else if (iParam0 == 401) {
		return joaat("weapon_combatmg");
	}
	else if (iParam0 == 402) {
		return -572349828;
	}
	else if (iParam0 == 300) {
		return joaat("weapon_assaultrifle");
	}
	else if (iParam0 == 301) {
		return joaat("weapon_carbinerifle");
	}
	else if (iParam0 == 302) {
		return joaat("weapon_advancedrifle");
	}
	else if (iParam0 == 303) {
		return -947031628;
	}
	else if (iParam0 == 200) {
		return joaat("weapon_pumpshotgun");
	}
	else if (iParam0 == 201) {
		return joaat("weapon_sawnoffshotgun");
	}
	else if (iParam0 == 202) {
		return joaat("weapon_assaultshotgun");
	}
	else if (iParam0 == 203) {
		return joaat("weapon_bullpupshotgun");
	}
	else if (iParam0 == 100) {
		return joaat("weapon_microsmg");
	}
	else if (iParam0 == 101) {
		return joaat("weapon_smg");
	}
	else if (iParam0 == 102) {
		return joaat("weapon_assaultsmg");
	}
	else if (iParam0 == 0) {
		return joaat("weapon_pistol");
	}
	else if (iParam0 == 1) {
		return joaat("weapon_combatpistol");
	}
	else if (iParam0 == 2) {
		return joaat("weapon_appistol");
	}
	else if (iParam0 == 3) {
		return joaat("weapon_pistol50");
	}
	return 0;
}

// Position - 0x9A0E
void func_129(int iParam0, int iParam1, int iParam2, int iParam3, char *sParam4, char *sParam5) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	if (iParam3 > 0) {
		graphics::begin_text_command_scaleform_string("NUMBER");
		ui::add_text_component_integer(iParam3);
		graphics::end_text_command_scaleform_string();
	}
	else {
		graphics::begin_text_command_scaleform_string("SC_LB_EMPTY");
		graphics::end_text_command_scaleform_string();
	}
	graphics::_0xE83A3E3557A56640(sParam4);
	graphics::_0xE83A3E3557A56640(sParam5);
}

// Position - 0x9A60
bool func_130(var *uParam0, var *uParam1) {
	if (!func_131(*uParam0)) {
		return false;
	}
	if (!func_131(*uParam1)) {
		return false;
	}
	if (network::network_are_handles_the_same(uParam0, uParam1)) {
		return true;
	}
	return false;
}

// Position - 0x9A9A
bool func_131(var uParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7,
			  var uParam8, var uParam9, var uParam10, var uParam11, var uParam12) {
	return network::network_is_handle_valid(&uParam0, 13);
}

// Position - 0x9AAA
void func_132(var *uParam0, var *uParam1) {
	int iVar0;
	int iVar1;
	struct<75> Var2;
	var uVar77;

	Var2.f_60 = 6;
	Var2.f_67 = 6;
	if (!gameplay::is_bit_set(uParam0->f_42, 5) && !gameplay::is_bit_set(uParam0->f_42, 6)) {
		iVar0 = 0;
		while (iVar0 < 12) {
			if ((*uParam1)[iVar0 /*100*/].f_75 != 0) {
				iVar1 = iVar0 + 1;
				while (iVar1 <= 11) {
					if ((*uParam1)[iVar1 /*100*/].f_75 != 0) {
						if ((*uParam1)[iVar1 /*100*/].f_75 < (*uParam1)[iVar0 /*100*/].f_75) {
							uVar77 = (*uParam1)[iVar1 /*100*/].f_75;
							(*uParam1)[iVar1 /*100*/].f_75 = (*uParam1)[iVar0 /*100*/].f_75;
							(*uParam1)[iVar0 /*100*/].f_75 = uVar77;
							Var2 = {(*uParam1)[iVar1 /*100*/]};
							(*uParam1)[iVar1 /*100*/] = {(*uParam1)[iVar0 /*100*/]};
							(*uParam1)[iVar0 /*100*/] = {Var2};
						}
						else if ((*uParam1)[iVar1 /*100*/].f_75 == (*uParam1)[iVar0 /*100*/].f_75) {
							if ((*uParam1)[iVar1 /*100*/].f_59 != -1) {
								if ((*uParam1)[iVar1 /*100*/].f_59 < (*uParam1)[iVar0 /*100*/].f_59 ||
									(*uParam1)[iVar0 /*100*/].f_59 == -1) {
									uVar77 = (*uParam1)[iVar1 /*100*/].f_75;
									(*uParam1)[iVar1 /*100*/].f_75 = (*uParam1)[iVar0 /*100*/].f_75;
									(*uParam1)[iVar0 /*100*/].f_75 = uVar77;
									Var2 = {(*uParam1)[iVar1 /*100*/]};
									(*uParam1)[iVar1 /*100*/] = {(*uParam1)[iVar0 /*100*/]};
									(*uParam1)[iVar0 /*100*/] = {Var2};
								}
							}
						}
					}
					iVar1++;
				}
			}
			iVar0++;
		}
	}
}

// Position - 0x9C1B
void func_133(var *uParam0, var *uParam1) {
	var *uVar0;
	var *uVar1;
	var *uVar2;
	int iVar3;
	int iVar4;

	if (!gameplay::is_bit_set(uParam0->f_42, 5) && !gameplay::is_bit_set(uParam0->f_42, 6)) {
		iVar4 = 0;
		while (iVar4 < 12) {
			if (func_136(uParam1, iVar3, &uVar0, 0)) {
				(*uParam1)[iVar3 /*100*/].f_75 = 1;
				iVar3++;
				if (iVar3 >= 12) {
					return;
				}
			}
			if (func_136(uParam1, iVar3, &uVar1, 1)) {
				(*uParam1)[iVar3 /*100*/].f_75 = 2;
				iVar3++;
				if (iVar3 >= 12) {
					return;
				}
			}
			if (func_136(uParam1, iVar3, &uVar2, 2)) {
				(*uParam1)[iVar3 /*100*/].f_75 = 3;
				iVar3++;
				if (iVar3 >= 12) {
					return;
				}
			}
			iVar4++;
		}
	}
	else {
		func_134(uParam1);
	}
}

// Position - 0x9CD0
void func_134(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	struct<13> Var3;
	int iVar16;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_1835390.f_2704[iVar0] = 0;
		Global_1835390.f_2775[iVar0] = -1;
		iVar0++;
	}
	Var3 = {func_23(player::player_id())};
	if (stats::leaderboards_get_cache_exists(Global_1835390.f_2826)) {
		iVar16 = stats::_0x58A651CD201D89AD(Global_1835390.f_2826);
		iVar0 = 0;
		iVar0 = 0;
		while (iVar0 < iVar16) {
			if (iVar0 < 12) {
				func_135(&Global_1839591);
				iVar2 = 0;
				stats::leaderboards_get_cache_data_row(Global_1835390.f_2826, iVar0, &Global_1839591);
				(*uParam0)[iVar0 /*100*/] = {Global_1839591.f_1};
				(*uParam0)[iVar0 /*100*/].f_16 = {Global_1839591.f_17};
				(*uParam0)[iVar0 /*100*/].f_32 = {Global_1839591.f_33};
				(*uParam0)[iVar0 /*100*/].f_45 = {Global_1839591.f_46};
				(*uParam0)[iVar0 /*100*/].f_58 = Global_1839591.f_59;
				(*uParam0)[iVar0 /*100*/].f_59 = Global_1839591.f_60;
				Global_1835390.f_2708 = Global_1839591.f_62;
				Global_1835390.f_2769 = Global_1839591.f_63;
				iVar2 = 0;
				if (gameplay::is_bit_set(Global_1839591.f_61, 1)) {
					iVar2 = 1;
				}
				else if (gameplay::is_bit_set(Global_1839591.f_61, 2)) {
					iVar2 = 2;
				}
				else if (gameplay::is_bit_set(Global_1839591.f_61, 3)) {
					iVar2 = 3;
				}
				Global_1835390.f_2704[iVar2 - 1]++;
				(*uParam0)[iVar0 /*100*/].f_75 = iVar2;
				if ((*uParam0)[iVar0 /*100*/].f_59 != -1) {
					if (gameplay::is_bit_set(Global_1839591.f_61, 0)) {
						(*uParam0)[iVar0 /*100*/].f_74 = 1;
					}
					else {
						(*uParam0)[iVar0 /*100*/].f_74 = 0;
					}
					if (func_130(&(*uParam0)[iVar0 /*100*/].f_32, &Var3)) {
						Global_1835390.f_2775[iVar2 - 1] = 0;
					}
				}
				iVar1 = 0;
				while (iVar1 < Global_1839591.f_62) {
					if (gameplay::is_bit_set(Global_1839591.f_63, iVar1)) {
						(*uParam0)[iVar0 /*100*/].f_67[iVar1] = Global_1839591.f_97[iVar1];
					}
					else {
						(*uParam0)[iVar0 /*100*/].f_60[iVar1] = Global_1839591.f_64[iVar1];
					}
					iVar1++;
				}
			}
			iVar0++;
		}
	}
}

// Position - 0x9EF0
void func_135(var *uParam0) {
	struct<13> Var0;
	int iVar13;

	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 64);
	StringCopy(&uParam0->f_17, "", 64);
	uParam0->f_33 = {Var0};
	uParam0->f_46 = {Var0};
	uParam0->f_59 = 0;
	uParam0->f_60 = 0;
	uParam0->f_61 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	iVar13 = 0;
	while (iVar13 < 32) {
		uParam0->f_64[iVar13] = 0f;
		uParam0->f_97[iVar13] = 0;
		iVar13++;
	}
}

// Position - 0x9F66
bool func_136(var *uParam0, int iParam1, var *uParam2, int iParam3) {
	int iVar0;

	if (*uParam2 == 0) {
		if (Global_1835390[iParam3 /*901*/][0 /*75*/].f_59 > 0) {
			(*uParam0)[iParam1 /*100*/] = {Global_1835390[iParam3 /*901*/][0 /*75*/]};
			Global_1839534[iParam3 /*16*/] = {Global_1835390[iParam3 /*901*/][0 /*75*/]};
			Global_1839534.f_49[iParam3] = Global_1835390[iParam3 /*901*/][0 /*75*/].f_67[Global_1835390.f_2779];
			Global_1839534.f_53[iParam3] = Global_1835390[iParam3 /*901*/][0 /*75*/].f_60[Global_1835390.f_2779];
			*uParam2++;
			return true;
		}
	}
	else if (*uParam2 == 1) {
		if (Global_1835390.f_2775[iParam3] > 0) {
			(*uParam0)[iParam1 /*100*/] = {Global_1835390[iParam3 /*901*/][Global_1835390.f_2775[iParam3] /*75*/]};
			*uParam2++;
			return true;
		}
		else {
			if (Global_1835390.f_2775[iParam3] < 0) {
				StringCopy(&(*uParam0)[iParam1 /*100*/], player::get_player_name(player::player_id()), 64);
				(*uParam0)[iParam1 /*100*/].f_32 = {func_23(player::player_id())};
				(*uParam0)[iParam1 /*100*/].f_59 = -1;
				(*uParam0)[iParam1 /*100*/].f_67[0] = -1;
				(*uParam0)[iParam1 /*100*/].f_67[1] = -1;
				(*uParam0)[iParam1 /*100*/].f_67[2] = -1;
				(*uParam0)[iParam1 /*100*/].f_67[3] = -1;
				(*uParam0)[iParam1 /*100*/].f_60[0] = -1f;
				(*uParam0)[iParam1 /*100*/].f_60[1] = -1f;
				(*uParam0)[iParam1 /*100*/].f_60[2] = -1f;
				(*uParam0)[iParam1 /*100*/].f_60[3] = -1f;
				*uParam2++;
				return true;
			}
			*uParam2++;
		}
	}
	else if (*uParam2 % 2 == 0) {
		iVar0 = *uParam2 / 2;
		if (Global_1835390.f_2775[iParam3] - iVar0 >= 1) {
			if (Global_1835390[iParam3 /*901*/][Global_1835390.f_2775[iParam3] - iVar0 /*75*/].f_59 > 0) {
				(*uParam0)[iParam1 /*100*/] = {
					Global_1835390[iParam3 /*901*/][Global_1835390.f_2775[iParam3] - iVar0 /*75*/]};
				*uParam2++;
				return true;
			}
		}
	}
	else {
		iVar0 = system::floor(system::to_float(*uParam2 / 2));
		if (Global_1835390.f_2775[iParam3] + iVar0 < 12 && Global_1835390.f_2775[iParam3] + iVar0 > 0) {
			if (Global_1835390[iParam3 /*901*/][Global_1835390.f_2775[iParam3] + iVar0 /*75*/].f_59 > 1) {
				(*uParam0)[iParam1 /*100*/] = {
					Global_1835390[iParam3 /*901*/][Global_1835390.f_2775[iParam3] + iVar0 /*75*/]};
				*uParam2++;
				return true;
			}
		}
	}
	*uParam2++;
	return false;
}

// Position - 0xA20F
bool func_137(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_138(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0xA26D
void func_138(var *uParam0, int iParam1, int iParam2) {
	if (uParam0->f_1 == 0) {
		if (network::network_is_game_in_progress() && !iParam1) {
			if (!iParam2) {
				*uParam0 = network::get_network_time();
			}
			else {
				*uParam0 = network::_0x89023FBBF9200E9F();
			}
		}
		else {
			*uParam0 = gameplay::get_game_timer();
		}
		uParam0->f_1 = 1;
	}
}

// Position - 0xA2B2
void func_139(int iParam0, int iParam1, int iParam2, char *sParam3) {
	gameplay::set_bit(&iParam2, 7);
	graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::begin_text_command_scaleform_string(sParam3);
	graphics::_end_text_command_scaleform_string_2();
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xA2E6
int func_140(var *uParam0) {
	if (!Global_1835388) {
		if (!func_174(&Global_1835390.f_2827)) {
			func_138(&Global_1835390.f_2827, 1, 0);
			return 0;
		}
		else if (!func_137(&Global_1835390.f_2827, 1000, 1)) {
			return 0;
		}
	}
	if (!network::_network_are_ros_available() || !player::is_player_online() ||
		!network::network_have_online_privileges() && network::_0x1353F87E89946207() || Global_1835390.f_2832 != 0) {
		gameplay::clear_bit(&uParam0->f_42, 4);
		return 1;
	}
	if (!gameplay::is_bit_set(uParam0->f_42, 4)) {
		func_173(uParam0);
		gameplay::set_bit(&uParam0->f_42, 4);
		return 0;
	}
	else if (gameplay::is_bit_set(uParam0->f_42, 5)) {
		(*uParam0)[0] = 2;
		(*uParam0)[1] = 1;
		(*uParam0)[2] = 3;
		return 1;
	}
	if (!func_171(uParam0)) {
		return 0;
	}
	if (!func_169(uParam0)) {
		return 0;
	}
	if (!func_156(uParam0)) {
		return 0;
	}
	if (!gameplay::is_bit_set(uParam0->f_42, 6)) {
		func_88(&Global_1839721);
		func_133(uParam0, &Global_1839721);
		func_132(uParam0, &Global_1839721);
		gameplay::set_bit(&uParam0->f_42, 6);
	}
	if (!gameplay::is_bit_set(uParam0->f_42, 7)) {
		if (!func_174(&Global_1835390.f_2830)) {
			func_138(&Global_1835390.f_2830, 1, 0);
		}
		else if (func_137(&Global_1835390.f_2830, 30000, 1)) {
			gameplay::set_bit(&uParam0->f_42, 7);
		}
		if (func_153(&Global_1839721)) {
		}
		else {
			return 0;
		}
		if (func_150(&Global_1839721)) {
		}
		else {
			return 0;
		}
		if (func_145(&Global_1839721)) {
			func_141(&Global_1839721);
			gameplay::set_bit(&uParam0->f_42, 7);
			func_141(&Global_1839721);
		}
		else {
			return 0;
		}
	}
	return 1;
}

// Position - 0xA4AB
void func_141(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar2 = func_144(Global_1835390.f_2826);
	if (Global_1838575.f_81[iVar2] != 0) {
		func_143(-1, iVar2);
	}
	iVar0 = 0;
	while (iVar0 < 12) {
		func_135(&Global_1839591);
		if ((*uParam0)[iVar0 /*100*/].f_75 != 0) {
			Global_1839591 = Global_1835390.f_2826;
			Global_1839591.f_1 = {(*uParam0)[iVar0 /*100*/]};
			if (gameplay::are_strings_equal(&(*uParam0)[iVar0 /*100*/].f_16, "")) {
				Global_1839591.f_17 = {(*uParam0)[iVar0 /*100*/]};
			}
			else {
				Global_1839591.f_17 = {(*uParam0)[iVar0 /*100*/].f_16};
			}
			Global_1839591.f_33 = {(*uParam0)[iVar0 /*100*/].f_32};
			if (func_131((*uParam0)[iVar0 /*100*/].f_45)) {
				Global_1839591.f_46 = {(*uParam0)[iVar0 /*100*/].f_45};
			}
			else {
				Global_1839591.f_46 = {(*uParam0)[iVar0 /*100*/].f_32};
			}
			Global_1839591.f_59 = (*uParam0)[iVar0 /*100*/].f_58;
			Global_1839591.f_60 = (*uParam0)[iVar0 /*100*/].f_59;
			Global_1839591.f_62 = Global_1835390.f_2708;
			Global_1839591.f_63 = Global_1835390.f_2770;
			if ((*uParam0)[iVar0 /*100*/].f_74) {
				gameplay::set_bit(&Global_1839591.f_61, 0);
			}
			else {
				gameplay::clear_bit(&Global_1839591.f_61, 0);
			}
			gameplay::set_bit(&Global_1839591.f_61, (*uParam0)[iVar0 /*100*/].f_75);
			iVar1 = 0;
			while (iVar1 < Global_1839591.f_62) {
				if (gameplay::is_bit_set(Global_1839591.f_63, iVar1)) {
					Global_1839591.f_97[iVar1] = (*uParam0)[iVar0 /*100*/].f_67[iVar1];
				}
				else {
					Global_1839591.f_64[iVar1] = (*uParam0)[iVar0 /*100*/].f_60[iVar1];
				}
				iVar1++;
			}
			Global_1838575.f_81[iVar2] = Global_1835390.f_2826;
			stats::leaderboards_cache_data_row(&Global_1839591);
		}
		iVar0++;
	}
	Global_1838575.f_87[iVar2 /*3*/] = {func_142(player::player_id())};
}

// Position - 0xA695
Vector3 func_142(int iParam0) { return entity::get_entity_coords(player::get_player_ped(iParam0), 0); }

// Position - 0xA6A8
void func_143(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 != -1) {
		if (stats::leaderboards_get_cache_exists(Global_1838575.f_81[iParam1])) {
			stats::_0x8EC74CEB042E7CFF(Global_1838575.f_81[iParam1]);
		}
		Global_1838575.f_81[iParam1] = 0;
	}
	else if (iParam0 != -1) {
		if (stats::leaderboards_get_cache_exists(iParam0)) {
			stats::_0x8EC74CEB042E7CFF(iParam0);
		}
		iVar0 = 0;
		while (iVar0 < 5) {
			if (Global_1838575.f_81[iVar0] == iParam0) {
				Global_1838575.f_81[iVar0] = 0;
			}
			iVar0++;
		}
	}
}

// Position - 0xA724
int func_144(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = 0;
	while (iVar0 < 5) {
		if (Global_1838575.f_81[iVar0] == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 5) {
		if (Global_1838575.f_81[iVar0] == 0) {
			return iVar0;
		}
		else if (stats::leaderboards_get_cache_exists(Global_1838575.f_81[iVar0])) {
			iVar3 = stats::leaderboards_get_cache_time(Global_1838575.f_81[iVar0]);
			if (iVar3 > iVar2) {
				iVar1 = iVar0;
				iVar2 = iVar3;
			}
		}
		else {
			return iVar0;
		}
		iVar0++;
	}
	return iVar1;
}

// Position - 0xA7B7
bool func_145(var *uParam0) {
	int iVar0;
	int iVar1;

	switch ((*uParam0)[0 /*100*/].f_76) {
	case 0:
		func_149(uParam0);
		if (gameplay::is_orbis_version() && !network::_0x72D918C99BCACC54(0)) {
			(*uParam0)[0 /*100*/].f_76 = 3;
			return false;
		}
		iVar0 = 0;
		while (iVar0 < 12) {
			if (func_131((*uParam0)[iVar0 /*100*/].f_32)) {
				if (!func_148(&(*uParam0)[iVar0 /*100*/].f_32, &Global_1841018)) {
					Global_1841018[Global_1841018.f_206 /*13*/] = {(*uParam0)[iVar0 /*100*/].f_32};
					Global_1841018.f_206++;
				}
			}
			iVar0++;
		}
		if (Global_1841018.f_206 > 0) {
			(*uParam0)[0 /*100*/].f_76 = 1;
		}
		else {
			(*uParam0)[0 /*100*/].f_76 = 3;
		}
		break;

	case 1:
		if (func_146(&(*uParam0)[1 /*100*/].f_76, &Global_1841018.f_206, &Global_1841018, &Global_1841018.f_157)) {
			(*uParam0)[0 /*100*/].f_76 = 2;
		}
		break;

	case 2:
		if (Global_1841018.f_206 > 12) {
			Global_1841018.f_206 = 12;
		}
		iVar0 = 0;
		while (iVar0 < 12) {
			iVar1 = 0;
			while (iVar1 < Global_1841018.f_206) {
				if (func_131((*uParam0)[iVar0 /*100*/].f_32) && func_131(Global_1841018[iVar1 /*13*/])) {
					if (network::network_are_handles_the_same(&(*uParam0)[iVar0 /*100*/].f_32,
															  &Global_1841018[iVar1 /*13*/])) {
						(*uParam0)[iVar0 /*100*/].f_80 = {Global_1841018.f_157[iVar1 /*4*/]};
					}
				}
				iVar1++;
			}
			iVar0++;
		}
		(*uParam0)[0 /*100*/].f_76 = 3;
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xA95A
bool func_146(int *iParam0, var *uParam1, var *uParam2, var *uParam3) {
	var uVar0;
	int iVar35;

	switch (*iParam0) {
	case 0:
		if (network::network_get_primary_clan_data_pending()) {
		}
		else {
			network::network_get_primary_clan_data_clear();
			network::network_get_primary_clan_data_start(uParam2, *uParam1);
			*iParam0 = 1;
		}
		break;

	case 1:
		if (!network::network_get_primary_clan_data_pending()) {
			if (network::network_get_primary_clan_data_success()) {
				*iParam0 = 2;
			}
			else {
				*iParam0 = 3;
			}
		}
		break;

	case 2:
		iVar35 = 0;
		while (iVar35 < *uParam1) {
			if (network::network_get_primary_clan_data_new(&(*uParam2)[iVar35 /*13*/], &uVar0)) {
				func_147(&uVar0, &(*uParam3)[iVar35 /*4*/]);
			}
			iVar35++;
		}
		if (network::network_get_primary_clan_data_pending()) {
			network::network_get_primary_clan_data_cancel();
		}
		else {
			network::network_get_primary_clan_data_clear();
		}
		*iParam0 = 3;
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xAA13
void func_147(var uParam0, char *sParam1) { network::unk_0xf45352426ff3a4f0(uParam0, 35, sParam1); }

// Position - 0xAA25
int func_148(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 12) {
		if (func_131((*uParam1)[iVar0 /*13*/])) {
			if (network::network_are_handles_the_same(uParam0, &(*uParam1)[iVar0 /*13*/])) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xAA64
void func_149(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 12) {
		func_93(&Global_1841018[iVar0 /*13*/]);
		StringCopy(&Global_1841018.f_157[iVar0 /*4*/], "", 16);
		iVar0++;
	}
	if ((*uParam0)[0 /*100*/].f_76 > 0) {
		(*uParam0)[0 /*100*/].f_76 = 0;
		(*uParam0)[1 /*100*/].f_76 = 0;
		if (!network::network_get_primary_clan_data_pending()) {
			network::network_get_primary_clan_data_clear();
		}
	}
	if (network::network_get_primary_clan_data_pending()) {
		network::network_get_primary_clan_data_cancel();
	}
	Global_1841018.f_206 = 0;
}

// Position - 0xAAD5
bool func_150(var *uParam0) {
	int iVar0;

	if (gameplay::is_pc_version()) {
		return true;
	}
	else if (gameplay::is_durango_version()) {
		if (!func_152(uParam0)) {
			return false;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < 12) {
			if (!func_151(&(*uParam0)[iVar0 /*100*/].f_78, &(*uParam0)[iVar0 /*100*/].f_32,
						  &(*uParam0)[iVar0 /*100*/])) {
				return false;
			}
			iVar0++;
		}
	}
	return true;
}

// Position - 0xAB39
int func_151(int *iParam0, var *uParam1, char *sParam2) {
	if (*iParam0 == 2) {
		return 1;
	}
	switch (*iParam0) {
	case 0:
		if (func_131(*uParam1)) {
			if (!network::network_is_gamer_in_my_session(uParam1)) {
				if (gameplay::is_durango_version()) {
					if (network::network_gamertag_from_handle_start(uParam1)) {
						*iParam0 = 1;
					}
				}
				else if (gameplay::is_xbox360_version()) {
					if (network::network_gamertag_from_handle_start(uParam1)) {
						*iParam0 = 1;
					}
				}
				else {
					StringCopy(sParam2, network::network_get_gamertag_from_handle(uParam1), 64);
					if (gameplay::is_ps3_version()) {
					}
					else if (gameplay::is_orbis_version()) {
					}
					else if (gameplay::is_pc_version()) {
					}
					*iParam0 = 2;
				}
			}
			else {
				StringCopy(sParam2, player::get_player_name(network::network_get_player_from_gamer_handle(uParam1)),
						   64);
				*iParam0 = 2;
			}
		}
		else {
			*iParam0 = 2;
		}
		break;

	case 1:
		if (!network::network_is_gamer_in_my_session(uParam1)) {
			if (!network::network_gamertag_from_handle_pending()) {
				if (network::network_gamertag_from_handle_succeeded()) {
					StringCopy(sParam2, network::network_get_gamertag_from_handle(uParam1), 64);
				}
				*iParam0 = 2;
				return 1;
			}
		}
		else {
			StringCopy(sParam2, player::get_player_name(network::network_get_player_from_gamer_handle(uParam1)), 64);
			*iParam0 = 2;
		}
		break;

	case 2: return 1;
	}
	return 0;
}

// Position - 0xAC40
int func_152(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!gameplay::is_durango_version()) {
		return 1;
	}
	if ((*uParam0)[0 /*100*/].f_78 == 2) {
		return 1;
	}
	switch ((*uParam0)[0 /*100*/].f_78) {
	case 0:
		Global_1835390.f_3183 = 0;
		iVar1 = 0;
		while (iVar1 < 12) {
			StringCopy(&Global_1835390.f_2833[iVar1 /*16*/], "", 64);
			func_93(&Global_1835390.f_3026[iVar1 /*13*/]);
			if (func_131((*uParam0)[iVar1 /*100*/].f_32)) {
				Global_1835390.f_3026[Global_1835390.f_3183 /*13*/] = {(*uParam0)[iVar1 /*100*/].f_32};
				Global_1835390.f_3183++;
			}
			iVar1++;
		}
		if (Global_1835390.f_3183 > 0) {
			(*uParam0)[0 /*100*/].f_79 = network::_0xD66C9E72B3CC4982(&Global_1835390.f_3026, Global_1835390.f_3183);
			(*uParam0)[0 /*100*/].f_78 = 1;
		}
		else {
			(*uParam0)[0 /*100*/].f_78 = 2;
		}
		break;

	case 1:
		iVar0 = network::_0x58CC181719256197((*uParam0)[0 /*100*/].f_79, &Global_1835390.f_2833, Global_1835390.f_3183);
		if (iVar0 == 0) {
			iVar1 = 0;
			while (iVar1 < 12) {
				if (func_131((*uParam0)[iVar1 /*100*/].f_32)) {
					(*uParam0)[iVar1 /*100*/] = {Global_1835390.f_2833[iVar2 /*16*/]};
					iVar2++;
				}
				iVar1++;
			}
			(*uParam0)[0 /*100*/].f_78 = 2;
		}
		else if (iVar0 == -1) {
			(*uParam0)[0 /*100*/].f_78 = 2;
		}
		else {
			return 0;
		}
		break;

	case 2: (*uParam0)[0 /*100*/].f_79 = -1; return 1;
	}
	return 0;
}

// Position - 0xADCC
bool func_153(var *uParam0) {
	int iVar0;

	if (gameplay::is_durango_version()) {
		iVar0 = 0;
		while (iVar0 < 12) {
			if (!func_155(&(*uParam0)[iVar0 /*100*/].f_77, &(*uParam0)[iVar0 /*100*/].f_16,
						  &(*uParam0)[iVar0 /*100*/].f_84, &Global_1835390.f_2833, &(*uParam0)[iVar0 /*100*/].f_79)) {
				return false;
			}
			iVar0++;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < 12) {
			if (!func_154(&(*uParam0)[iVar0 /*100*/].f_77, (*uParam0)[iVar0 /*100*/].f_16,
						  &(*uParam0)[iVar0 /*100*/].f_84)) {
				return false;
			}
			iVar0++;
		}
	}
	return true;
}

// Position - 0xAE5F
int func_154(int *iParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7,
			 var uParam8, var uParam9, var uParam10, var uParam11, var uParam12, var uParam13, var uParam14,
			 var uParam15, var uParam16, char *sParam17) {
	struct<13> Var0;

	if (*iParam0 == 2) {
		return 1;
	}
	else if (gameplay::is_string_null_or_empty(&uParam1)) {
		*iParam0 = 2;
		return 1;
	}
	network::network_handle_from_user_id(&uParam1, &Var0, 13);
	switch (*iParam0) {
	case 0:
		if (func_131(Var0)) {
			if (!network::network_is_gamer_in_my_session(&Var0)) {
				if (gameplay::is_xbox360_version() || gameplay::is_durango_version()) {
					if (network::network_gamertag_from_handle_start(&Var0)) {
						*iParam0 = 1;
					}
				}
				else {
					StringCopy(sParam17, network::network_get_gamertag_from_handle(&Var0), 64);
					if (gameplay::is_ps3_version()) {
					}
					else if (gameplay::is_orbis_version()) {
					}
					else if (gameplay::is_pc_version()) {
					}
					*iParam0 = 2;
				}
			}
			else {
				StringCopy(sParam17, player::get_player_name(network::network_get_player_from_gamer_handle(&Var0)), 64);
				*iParam0 = 2;
			}
		}
		else {
			*iParam0 = 2;
		}
		break;

	case 1:
		if (!network::network_is_gamer_in_my_session(&Var0)) {
			if (!network::network_gamertag_from_handle_pending()) {
				if (network::network_gamertag_from_handle_succeeded()) {
					StringCopy(sParam17, network::network_get_gamertag_from_handle(&Var0), 64);
				}
				*iParam0 = 2;
				return 1;
			}
		}
		else {
			StringCopy(sParam17, player::get_player_name(network::network_get_player_from_gamer_handle(&Var0)), 64);
			*iParam0 = 2;
		}
		break;

	case 2: return 1;
	}
	return 0;
}

// Position - 0xAF77
int func_155(int *iParam0, char *sParam1, var *uParam2, var *uParam3, int *iParam4) {
	int iVar0;
	struct<13> Var1[1];

	if (!gameplay::is_durango_version()) {
		return 1;
	}
	if (*iParam0 == 2) {
		return 1;
	}
	else if (gameplay::is_string_null_or_empty(sParam1)) {
		*iParam0 = 2;
		return 1;
	}
	network::network_handle_from_user_id(sParam1, &Var1[0 /*13*/], 13);
	switch (*iParam0) {
	case 0:
		StringCopy(&(*uParam3)[0 /*16*/], "", 64);
		if (func_131(Var1[0 /*13*/])) {
			if (!network::network_is_gamer_in_my_session(&Var1[0 /*13*/])) {
				*iParam4 = network::_0xD66C9E72B3CC4982(&Var1, 1);
				*iParam0 = 1;
			}
			else {
				StringCopy(uParam2,
						   player::get_player_name(network::network_get_player_from_gamer_handle(&Var1[0 /*13*/])), 64);
				*iParam0 = 2;
			}
		}
		else {
			*iParam0 = 2;
		}
		break;

	case 1:
		iVar0 = network::_0x58CC181719256197(*iParam4, uParam3, 1);
		if (iVar0 == 0) {
			*uParam2 = {(*uParam3)[0 /*16*/]};
			*iParam0 = 2;
		}
		else if (iVar0 == -1) {
			*iParam0 = 2;
		}
		else {
			return 0;
		}
		break;

	case 2: *iParam4 = -1; return 1;
	}
	return 0;
}

// Position - 0xB073
int func_156(var *uParam0) {
	struct<97> Var0;
	struct<6> Var98;
	int iVar106;
	int iVar107;
	int iVar108;
	int iVar109;
	int iVar110;
	int iVar111;
	bool bVar112;
	int iVar113;
	bool bVar114;
	int iVar115;
	struct<13> Var116;

	Var0.f_19.f_1 = 4;
	iVar109 = -1;
	iVar113 = 2;
	Var116 = {func_23(player::player_id())};
	switch ((*uParam0)[iVar113]) {
	case 0:
		Global_1835390.f_2775[iVar113] = -1;
		Global_1835390.f_2704[iVar113] = 0;
		Global_1835013.f_374 = -1;
		if (network::_network_player_is_in_clan()) {
			if (network::network_clan_player_is_active(&Var116)) {
				if (network::network_clan_player_get_desc(&uParam0->f_7, 35, &Var116)) {
					uParam0->f_44.f_2 = uParam0->f_7;
					uParam0->f_44.f_1 = 3;
					(*uParam0)[iVar113] = 1;
					return 0;
				}
			}
			else {
				(*uParam0)[iVar113] = 3;
				return 1;
			}
		}
		else {
			(*uParam0)[iVar113] = 3;
			return 1;
		}
		break;

	case 1:
		uParam0->f_44.f_1 = 3;
		Var98 = uParam0->f_44;
		Var98.f_1 = uParam0->f_44.f_1;
		if (func_167(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 11, &Var116, func_168(), 0, 0, 0)) {
			func_166(&Var98, &uParam0->f_44);
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
				if (Var98.f_3 > 0) {
					iVar111 = 0;
					iVar106 = 0;
					if (func_168()) {
						iVar111 = 0;
						while (iVar111 < Var98.f_3) {
							stats::_0x34770B9CE0E03B91(iVar111, &Var0);
							if (Global_1835013.f_374 < 0) {
								if (func_130(&Var0, &Var116) || func_130(&Var0, &Global_1835013.f_361)) {
									Global_1835013.f_374 = Var0.f_96;
								}
							}
							if (iVar109 < 0) {
								if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
									if (Global_1835013.f_211.f_36[0] >= stats::_0x88578F6EC36B4A3A(iVar111, 0)) {
										iVar109 = iVar111;
									}
								}
								else if (Global_1835013.f_211.f_3[0] >= stats::_0x38491439B6BA7F7D(iVar111, 0)) {
									iVar109 = iVar111;
								}
							}
							func_165(&Var0);
							iVar111++;
						}
						if (iVar109 < 0) {
							iVar109 = Var98.f_3;
						}
					}
					iVar111 = 0;
					stats::_0x34770B9CE0E03B91(0, &Var0);
					if (Var0.f_96 <= 1) {
						if (Global_1835390.f_2704[iVar113] < 12) {
							if (func_168() && iVar109 == 0) {
								func_164(uParam0,
										 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
										 Var0.f_96);
								Global_1835390.f_2775[iVar113] = 0;
								Global_1835390.f_2704[iVar113]++;
							}
							if (func_168() && (func_130(&Var0, &Var116) || func_130(&Var0, &Global_1835013.f_361))) {
							}
							else {
								if (func_130(&Var0, &Var116)) {
									iVar109 = 0;
									Global_1835390.f_2775[iVar113] = 0;
								}
								MemCopy(&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
										{Var0.f_13}, 16);
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_32 = {Var0};
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_59 = Var0.f_96;
								if (func_163(uParam0->f_44)) {
									iVar108 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
									if (iVar108 == 1) {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 1;
									}
									else {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 0;
									}
								}
								if (func_179(uParam0->f_44)) {
									MemCopy(
										&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_16,
										{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
								}
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_74 = 1;
								iVar107 = 0;
								iVar107 = 0;
								while (iVar107 < Global_1835390.f_2708) {
									if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar107])) {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
											.f_67[iVar107] =
											stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2710[iVar107]);
									}
									else {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
											.f_60[iVar107] =
											stats::_0x38491439B6BA7F7D(0, Global_1835390.f_2710[iVar107]);
									}
									iVar107++;
								}
								Global_1835390.f_2704[iVar113]++;
							}
							bVar112 = true;
						}
					}
					if (!bVar112) {
						Global_1835390.f_2704[iVar113]++;
					}
					if (!func_168()) {
						iVar109 = Var98.f_5;
					}
					if (iVar109 > 6) {
						iVar110 = iVar109 - 6;
					}
					else if (bVar112) {
						iVar110 = 1;
					}
					else {
						iVar110 = 0;
					}
					iVar111 = iVar110;
					func_165(&Var0);
					iVar111 = iVar110;
					while (iVar111 <= Var98.f_3 - 1) {
						stats::_0x34770B9CE0E03B91(iVar111, &Var0);
						if (Global_1835390.f_2704[iVar113] < 12 && Var0.f_96 > 1) {
							if (func_168() && iVar109 == iVar111) {
								if (!func_130(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_32, &Var116)) {
									func_164(uParam0,
											 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
											 Var0.f_96);
									Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
									Global_1835390.f_2704[iVar113]++;
								}
							}
							if (func_168() && (func_130(&Var0, &Var116) || func_130(&Var0, &Global_1835013.f_361))) {
							}
							else if (Global_1835390.f_2704[iVar113] < 12) {
								if (func_131(Var0) &&
									!func_130(&Var0, &Global_1835390[iVar113 /*901*/][0 /*75*/].f_32)) {
									if (func_130(&Var0, &Var116)) {
										if (Global_1835390.f_2775[iVar113] < 0) {
											Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
										}
									}
									MemCopy(&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
											{Var0.f_13}, 16);
									Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_32 = {
										Var0};
									Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_59 =
										Var0.f_96;
									Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_74 = 1;
									if (func_163(uParam0->f_44)) {
										iVar108 = stats::_0x88578F6EC36B4A3A(iVar111, Global_1835390.f_2709);
										if (iVar108 == 1) {
											Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
												.f_58 = 1;
										}
										else {
											Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
												.f_58 = 0;
										}
									}
									if (func_179(uParam0->f_44)) {
										MemCopy(&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
													 .f_16,
												{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
									}
									iVar106 = 0;
									iVar106 = 0;
									while (iVar106 < Global_1835390.f_2708) {
										if (gameplay::is_bit_set(Global_1835390.f_2769,
																 Global_1835390.f_2710[iVar106])) {
											Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
												.f_67[iVar106] =
												stats::_0x88578F6EC36B4A3A(iVar111, Global_1835390.f_2710[iVar106]);
										}
										else {
											Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
												.f_60[iVar106] =
												stats::_0x38491439B6BA7F7D(iVar111, Global_1835390.f_2710[iVar106]);
										}
										iVar106++;
									}
									Global_1835390.f_2704[iVar113]++;
								}
							}
						}
						func_165(&Var0);
						iVar111++;
					}
					stats::_0x71B008056E5692D6();
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					if (bVar112) {
						if (Global_1835390.f_2775[iVar113] == -1 && func_168()) {
							if (Global_1835390.f_2704[iVar113] >= 1) {
								func_164(
									uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
									Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] - 1 /*75*/].f_59 +
										1);
							}
							else {
								func_164(uParam0,
										 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/], 1);
							}
							Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
							Global_1835390.f_2704[iVar113]++;
						}
						(*uParam0)[iVar113] = 3;
					}
					else {
						(*uParam0)[iVar113] = 2;
					}
				}
				else {
					if (!bVar112) {
						Global_1835390.f_2704[iVar113]++;
					}
					stats::_0x71B008056E5692D6();
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					Global_1835390.f_2775[iVar113] = -1;
					(*uParam0)[iVar113] = 2;
				}
			}
			else {
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				Global_1835390.f_2775[iVar113] = -1;
				(*uParam0)[iVar113] = 2;
				gameplay::set_bit(&Global_1835390.f_2832, iVar113);
			}
		}
		break;

	case 2:
		if (Global_1835390.f_2775[iVar113] == -1) {
			iVar115 = 11;
		}
		else {
			iVar115 = 1;
		}
		uParam0->f_44.f_1 = 3;
		Var98 = uParam0->f_44;
		Var98.f_1 = uParam0->f_44.f_1;
		if (func_158(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, iVar115)) {
			func_166(&Var98, &uParam0->f_44);
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
				if (Var98.f_3 > 0) {
					iVar106 = 0;
					while (iVar106 < Var98.f_3) {
						stats::_0x34770B9CE0E03B91(iVar106, &Var0);
						bVar114 = false;
						if (Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 > 1 ||
							Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 <= 0) {
							bVar114 = true;
						}
						if (Global_1835390.f_2704[iVar113] < 12 || bVar114) {
							if (func_168() && (func_130(&Var0, &Var116) || func_130(&Var0, &Global_1835013.f_361))) {
							}
							else if (iVar106 == 0 || bVar114) {
								MemCopy(&Global_1835390[iVar113 /*901*/][0 /*75*/], {Var0.f_13}, 16);
								Global_1835390[iVar113 /*901*/][0 /*75*/].f_32 = {Var0};
								Global_1835390[iVar113 /*901*/][0 /*75*/].f_59 = Var0.f_96;
								if (func_163(uParam0->f_44)) {
									iVar108 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
									if (iVar108 == 1) {
										Global_1835390[iVar113 /*901*/][0 /*75*/].f_58 = 1;
									}
									else {
										Global_1835390[iVar113 /*901*/][0 /*75*/].f_58 = 0;
									}
								}
								if (func_179(uParam0->f_44)) {
									MemCopy(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_16,
											{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
								}
								Global_1835390[iVar113 /*901*/][0 /*75*/].f_74 = 1;
								iVar107 = 0;
								iVar107 = 0;
								while (iVar107 < Global_1835390.f_2708) {
									if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar107])) {
										Global_1835390[iVar113 /*901*/][0 /*75*/].f_67[iVar107] =
											stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2710[iVar107]);
									}
									else {
										Global_1835390[iVar113 /*901*/][0 /*75*/].f_60[iVar107] =
											stats::_0x38491439B6BA7F7D(0, Global_1835390.f_2710[iVar107]);
									}
									iVar107++;
								}
								if (Global_1835390.f_2704[iVar113] == 0) {
									if (bVar114) {
									}
									else {
										Global_1835390.f_2704[iVar113]++;
									}
								}
							}
							else if (Global_1835390.f_2704[iVar113] < 12) {
								MemCopy(&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
										{Var0.f_13}, 16);
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_32 = {Var0};
								if (func_163(uParam0->f_44)) {
									iVar108 = stats::_0x88578F6EC36B4A3A(iVar106, Global_1835390.f_2709);
									if (iVar108 == 1) {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 1;
									}
									else {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 0;
									}
								}
								if (func_179(uParam0->f_44)) {
									MemCopy(
										&Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_16,
										{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
								}
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_59 = Var0.f_96;
								Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_74 = 1;
								iVar107 = 0;
								iVar107 = 0;
								while (iVar107 < Global_1835390.f_2708) {
									if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar107])) {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
											.f_67[iVar107] =
											stats::_0x88578F6EC36B4A3A(iVar106, Global_1835390.f_2710[iVar107]);
									}
									else {
										Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/]
											.f_60[iVar107] =
											stats::_0x38491439B6BA7F7D(iVar106, Global_1835390.f_2710[iVar107]);
									}
									iVar107++;
								}
								if (iVar106 != 0) {
									Global_1835390.f_2704[iVar113]++;
								}
							}
						}
						func_165(&Var0);
						iVar106++;
					}
				}
				stats::_0x71B008056E5692D6();
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				(*uParam0)[iVar113] = 3;
			}
			else {
				stats::_0x71B008056E5692D6();
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				gameplay::set_bit(&Global_1835390.f_2832, iVar113);
				Global_1835390.f_2704[iVar113] = 0;
				(*uParam0)[iVar113] = 3;
			}
			if (Global_1835390.f_2775[iVar113] == -1 && func_168()) {
				if (Global_1835390.f_2704[iVar113] >= 1) {
					func_164(uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
							 Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] - 1 /*75*/].f_59 + 1);
				}
				else {
					func_164(uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/], 1);
				}
				Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
				Global_1835390.f_2704[iVar113]++;
			}
		}
		break;

	case 3:
		func_157(iVar113, Global_1835013.f_374);
		(*uParam0)[iVar113] = 4;
		break;

	case 4: return 1;
	}
	return 0;
}

// Position - 0xBEA6
void func_157(int iParam0, int iParam1) {
	int iVar0;

	if (func_168() && Global_1835390.f_2704[iParam0] > Global_1835390.f_2775[iParam0] &&
		Global_1835390.f_2775[iParam0] >= 0) {
		if (iParam1 != Global_1835390[iParam0 /*901*/][Global_1835390.f_2775[iParam0] /*75*/].f_59) {
			iVar0 = 0;
			while (iVar0 < Global_1835390.f_2704[iParam0]) {
				if (iVar0 != Global_1835390.f_2775[iParam0]) {
					if (Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59 >=
						Global_1835390[iParam0 /*901*/][Global_1835390.f_2775[iParam0] /*75*/].f_59) {
						if (Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59 < iParam1 || iParam1 == -1) {
							Global_1835390[iParam0 /*901*/][iVar0 /*75*/].f_59++;
						}
					}
				}
				iVar0++;
			}
		}
	}
	else {
		if (!func_168()) {
		}
		if (Global_1835390.f_2704[iParam0] <= Global_1835390.f_2775[iParam0]) {
		}
		if (Global_1835390.f_2775[iParam0] < 0) {
		}
	}
}

// Position - 0xBFCB
bool func_158(var *uParam0, int *iParam1, var *uParam2, int iParam3, int iParam4) {
	switch (*uParam0) {
	case 0:
		if (!func_161() && !func_160()) {
			func_159(*uParam2);
			if (stats::leaderboards2_read_by_rank(uParam2, iParam3, iParam4)) {
				*uParam0++;
			}
			else {
				*iParam1 = 0;
				*uParam0 = 3;
			}
		}
		break;

	case 1:
		if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
			*uParam0++;
		}
		break;

	case 2:
		if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
			*iParam1 = 1;
			*uParam0++;
		}
		else {
			*iParam1 = 0;
			*uParam0++;
		}
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xC082
void func_159(struct<2> Param0, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7,
			  var uParam8, var uParam9, var uParam10, var uParam11, var uParam12, var uParam13, var uParam14,
			  var uParam15, var uParam16, var uParam17, var uParam18, var uParam19, var uParam20, var uParam21,
			  var uParam22, var uParam23, var uParam24, var uParam25, var uParam26, var uParam27, var uParam28,
			  var uParam29, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
			  var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
			  var uParam43, var uParam44, var uParam45, var uParam46, var uParam47, var uParam48, var uParam49,
			  var uParam50, var uParam51, var uParam52, var uParam53, var uParam54, var uParam55, var uParam56,
			  var uParam57, var uParam58, var uParam59, var uParam60, var uParam61, var uParam62, var uParam63,
			  var uParam64, var uParam65, var uParam66, var uParam67, var uParam68) {
	Global_1835008 = 1;
	func_190(&Global_1835008.f_1, 1, 0);
	Global_1835008.f_3 = Param0;
	Global_1835008.f_4 = Param0.f_1;
}

// Position - 0xC0AD
int func_160() {
	if (ui::is_pause_menu_active() && !func_182()) {
		return 1;
	}
	return 0;
}

// Position - 0xC0CB
int func_161() {
	if (stats::_0xA31FD15197B192BD() || Global_1835008) {
		func_162();
		return 1;
	}
	return 0;
}

// Position - 0xC0ED
void func_162() {
	if (func_137(&Global_1835008.f_1, 120000, 1)) {
		stats::leaderboards_read_clear(Global_1835008.f_3, Global_1835008.f_4, -1);
		Global_1835008 = 0;
		func_85(&Global_1835008.f_1);
	}
}

// Position - 0xC128
bool func_163(int iParam0) {
	if (iParam0 == 815 || iParam0 == 824 || iParam0 == 825 || iParam0 == 826 || iParam0 == 827 || iParam0 == 828 ||
		iParam0 == 849) {
		return true;
	}
	return false;
}

// Position - 0xC186
void func_164(var *uParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (func_179(uParam0->f_44)) {
		MemCopy(uParam1, {Global_1835013.f_355}, 16);
		uParam1->f_32 = {Global_1835013.f_361};
		MemCopy(&uParam1->f_16, {Global_1835013.f_349}, 16);
	}
	else {
		StringCopy(uParam1, player::get_player_name(player::player_id()), 64);
		uParam1->f_32 = {func_23(player::player_id())};
	}
	uParam1->f_59 = iParam2;
	if (func_163(uParam0->f_44)) {
		iVar0 = Global_1835013.f_211.f_36[Global_1835390.f_2709];
		if (iVar0 == 1) {
			uParam1->f_58 = 1;
		}
		else {
			uParam1->f_58 = 0;
		}
	}
	uParam1->f_74 = 1;
	iVar1 = 0;
	while (iVar1 < Global_1835390.f_2708) {
		if (gameplay::is_bit_set(Global_1835013.f_142.f_2, Global_1835390.f_2710[iVar1])) {
			uParam1->f_67[iVar1] = Global_1835013.f_211.f_36[Global_1835390.f_2710[iVar1]];
		}
		else {
			uParam1->f_60[iVar1] = Global_1835013.f_211.f_3[Global_1835390.f_2710[iVar1]];
		}
		iVar1++;
	}
}

// Position - 0xC293
void func_165(var *uParam0) {
	int iVar0;

	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	uParam0->f_3 = 0;
	uParam0->f_4 = 0;
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 0;
	StringCopy(&uParam0->f_13, "", 24);
	uParam0->f_19 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		StringCopy(&uParam0->f_19.f_1[iVar0 /*16*/], "", 32);
		StringCopy(&uParam0->f_19.f_1[iVar0 /*16*/].f_8, "", 32);
		iVar0++;
	}
	uParam0->f_85 = 0;
	StringCopy(&uParam0->f_86, "", 32);
	StringCopy(&uParam0->f_94, "", 8);
	uParam0->f_96 = 0;
	uParam0->f_97 = 0;
}

// Position - 0xC341
void func_166(var *uParam0, var *uParam1) {
	*uParam0 = *uParam1;
	uParam0->f_1 = uParam1->f_1;
	uParam0->f_2 = 0;
}

// Position - 0xC35C
bool func_167(var *uParam0, int *iParam1, var *uParam2, int iParam3, var uParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8) {
	var uVar0;
	var uVar1;

	uVar0 = Global_1835013.f_211.f_36[0];
	uVar1 = Global_1835013.f_211.f_3[0];
	if (iParam6) {
		uVar0 = iParam7;
		uVar1 = iParam8;
	}
	switch (*uParam0) {
	case 0:
		if (!func_161() && !func_160()) {
			func_159(*uParam2);
			if (iParam5) {
				if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
					if (stats::leaderboards2_read_by_score_int(uParam2, uVar0, iParam3)) {
						*uParam0++;
					}
					else {
						*iParam1 = 0;
						*uParam0 = 3;
					}
				}
				else if (stats::leaderboards2_read_by_score_float(uParam2, uVar1, iParam3)) {
					*uParam0++;
				}
				else {
					*iParam1 = 0;
					*uParam0 = 3;
				}
			}
			else if (stats::leaderboards2_read_by_radius(uParam2, iParam3, uParam4)) {
				*uParam0++;
			}
			else {
				*iParam1 = 0;
				*uParam0 = 3;
			}
		}
		break;

	case 1:
		if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
			*uParam0++;
		}
		break;

	case 2:
		if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
			*iParam1 = 1;
			*uParam0++;
		}
		else {
			*iParam1 = 0;
			*uParam0++;
		}
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xC494
bool func_168() {
	if (Global_1835388 && Global_1835389) {
		return true;
	}
	return false;
}

// Position - 0xC4B1
int func_169(var *uParam0) {
	struct<20> Var0;
	struct<6> Var98;
	int iVar106;
	int iVar107;
	int iVar108;
	int iVar109;
	int iVar110;
	int iVar111;
	int iVar112;
	int iVar113;
	struct<13> Var114;

	Var0.f_19.f_1 = 4;
	iVar108 = -1;
	iVar113 = 1;
	Var114 = {func_23(player::player_id())};
	switch ((*uParam0)[1]) {
	case 0:
		iVar107 = network::network_get_friend_count();
		Global_1835390.f_2775[1] = -1;
		Global_1835013.f_374 = -1;
		Global_1835390.f_2704[iVar113] = 0;
		if (iVar107 > 0) {
			if (func_168()) {
				iVar112 = 0;
			}
			else {
				iVar112 = 1;
			}
			if (func_170(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, &uParam0->f_113, uParam0->f_113[0 /*66*/],
						 iVar112, 0, 100)) {
				func_166(&Var98, &uParam0->f_44);
				if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
					if (func_168()) {
						iVar110 = 0;
						iVar110 = 0;
						while (iVar110 < Var98.f_3) {
							if (iVar108 < 0) {
								stats::_0x34770B9CE0E03B91(iVar110, &Var0);
								if (func_179(uParam0->f_44)) {
									if (Global_1835013.f_374 < 0) {
										if (func_130(&Var0, &Global_1835013.f_361)) {
											Global_1835013.f_374 = Var0.f_96;
										}
									}
								}
								if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
									if (Global_1835013.f_211.f_36[0] >= stats::_0x88578F6EC36B4A3A(iVar110, 0)) {
										iVar108 = iVar110;
									}
								}
								else if (Global_1835013.f_211.f_3[0] >= stats::_0x38491439B6BA7F7D(iVar110, 0)) {
									iVar108 = iVar110;
								}
								func_165(&Var0);
							}
							iVar110++;
						}
						if (iVar108 < 0) {
							iVar108 = Var98.f_3;
						}
					}
					iVar110 = 0;
					if (func_168() && iVar108 == 0) {
						if (Global_1835390.f_2704[iVar113] < 12) {
							func_164(uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
									 1);
							Global_1835390.f_2775[iVar113] = 0;
							Global_1835390.f_2704[iVar113]++;
						}
					}
					if (Var98.f_3 > 0) {
						stats::_0x34770B9CE0E03B91(0, &Var0);
						if (func_168() && (func_130(&Var0, &Var114) || func_130(&Var0, &Global_1835013.f_361))) {
						}
						else if (func_131(Var0) && Global_1835390.f_2704[iVar113] < 12) {
							if (func_130(&Var0, &Var114)) {
								iVar108 = 0;
								Global_1835390.f_2775[1] = 0;
							}
							MemCopy(&Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/], {Var0.f_13}, 16);
							Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_32 = {Var0};
							Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_59 = 1;
							if (func_163(uParam0->f_44)) {
								iVar111 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
								if (iVar111 == 1) {
									Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 1;
								}
								else {
									Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_58 = 0;
								}
							}
							if (func_179(uParam0->f_44)) {
								MemCopy(&Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_16,
										{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
							}
							Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_74 = 1;
							iVar106 = 0;
							while (iVar106 < Global_1835390.f_2708) {
								if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar106])) {
									Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_67[iVar106] =
										stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2710[iVar106]);
								}
								else {
									Global_1835390[1 /*901*/][Global_1835390.f_2704[iVar113] /*75*/].f_60[iVar106] =
										stats::_0x38491439B6BA7F7D(0, Global_1835390.f_2710[iVar106]);
								}
								iVar106++;
							}
							Global_1835390.f_2704[1]++;
						}
						else {
							func_165(&Var0);
							stats::_0x71B008056E5692D6();
							func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
							Global_1835390.f_2704[1] = 0;
							(*uParam0)[1] = 1;
							if (Global_1835390.f_2775[iVar113] == -1 && func_168()) {
								if (Global_1835390.f_2704[iVar113] >= 1) {
									func_164(uParam0,
											 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
											 Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] - 1 /*75*/]
													 .f_59 +
												 1);
								}
								else {
									func_164(uParam0,
											 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
											 1);
								}
								Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
								Global_1835390.f_2704[iVar113]++;
							}
							return 0;
						}
						func_165(&Var0);
					}
					else {
						Global_1835390.f_2704[1] = 0;
						func_165(&Var0);
						stats::_0x71B008056E5692D6();
						func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
						if (Global_1835390.f_2775[iVar113] == -1 && func_168()) {
							if (Global_1835390.f_2704[iVar113] >= 1) {
								func_164(
									uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
									Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] - 1 /*75*/].f_59 +
										1);
							}
							else {
								func_164(uParam0,
										 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/], 1);
							}
							Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
							Global_1835390.f_2704[iVar113]++;
						}
						(*uParam0)[1] = 1;
						return 0;
					}
					if (!func_168()) {
						iVar108 = Var98.f_5;
					}
					if (iVar108 > 6) {
						iVar109 = iVar108 - 6;
					}
					else {
						iVar109 = 1;
					}
					iVar110 = iVar109;
					iVar110 = iVar109;
					while (iVar110 <= Var98.f_3 - 1) {
						stats::_0x34770B9CE0E03B91(iVar110, &Var0);
						if (Global_1835390.f_2704[iVar113] < 12 && Var0.f_96 > 1) {
							if (func_168() && iVar108 == iVar110) {
								if (!func_130(&Global_1835390[iVar113 /*901*/][0 /*75*/].f_32, &Var114)) {
									func_164(uParam0,
											 &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
											 Var0.f_96);
									Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_59 = iVar110 + 1;
									Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
									Global_1835390.f_2704[iVar113]++;
								}
							}
							if (func_168() && (func_130(&Var0, &Var114) || func_130(&Var0, &Global_1835013.f_361))) {
							}
							else if (Global_1835390.f_2704[1] < 12) {
								if (func_131(Var0) &&
									!func_130(&Var0, &Global_1835390[iVar113 /*901*/][0 /*75*/].f_32)) {
									if (func_130(&Var0, &Var114)) {
										if (Global_1835390.f_2775[1] < 0) {
											Global_1835390.f_2775[1] = Global_1835390.f_2704[1];
										}
									}
									MemCopy(&Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/], {Var0.f_13},
											16);
									Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_32 = {Var0};
									Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_59 = iVar110 + 1;
									Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_74 = 1;
									if (func_163(uParam0->f_44)) {
										iVar111 = stats::_0x88578F6EC36B4A3A(iVar110, Global_1835390.f_2709);
										if (iVar111 == 1) {
											Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_58 = 1;
										}
										else {
											Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_58 = 0;
										}
									}
									if (func_179(uParam0->f_44)) {
										MemCopy(&Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_16,
												{Var0.f_19.f_1[1 /*16*/].f_8}, 16);
									}
									iVar106 = 0;
									while (iVar106 < Global_1835390.f_2708) {
										if (gameplay::is_bit_set(Global_1835390.f_2769,
																 Global_1835390.f_2710[iVar106])) {
											Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_67[iVar106] =
												stats::_0x88578F6EC36B4A3A(iVar110, Global_1835390.f_2710[iVar106]);
										}
										else {
											Global_1835390[1 /*901*/][Global_1835390.f_2704[1] /*75*/].f_60[iVar106] =
												stats::_0x38491439B6BA7F7D(iVar110, Global_1835390.f_2710[iVar106]);
										}
										iVar106++;
									}
									Global_1835390.f_2704[1]++;
								}
							}
						}
						func_165(&Var0);
						iVar110++;
					}
					stats::_0x71B008056E5692D6();
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					(*uParam0)[1] = 1;
					if (Global_1835390.f_2775[iVar113] == -1 && func_168()) {
						if (Global_1835390.f_2704[iVar113] >= 1) {
							func_164(uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
									 Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] - 1 /*75*/].f_59 +
										 1);
						}
						else {
							func_164(uParam0, &Global_1835390[iVar113 /*901*/][Global_1835390.f_2704[iVar113] /*75*/],
									 1);
						}
						Global_1835390.f_2775[iVar113] = Global_1835390.f_2704[iVar113];
						Global_1835390.f_2704[iVar113]++;
					}
					return 0;
				}
				else {
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					Global_1835390.f_2704[1] = 0;
					(*uParam0)[1] = 1;
					gameplay::set_bit(&Global_1835390.f_2832, 1);
					return 0;
				}
			}
		}
		else {
			func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
			Global_1835390.f_2704[1] = 0;
			(*uParam0)[1] = 1;
			return 0;
		}
		break;

	case 1:
		func_157(iVar113, Global_1835013.f_374);
		(*uParam0)[1] = 2;
		break;

	case 2: return 1;
	}
	return 0;
}

// Position - 0xCEB4
bool func_170(var *uParam0, int *iParam1, var *uParam2, var uParam3, var uParam4, int iParam5, int iParam6,
			  int iParam7) {
	switch (*uParam0) {
	case 0:
		if (!func_161() && !func_160()) {
			func_159(*uParam2);
			if (stats::leaderboards2_read_friends_by_row(uParam2, uParam3, uParam4, iParam5, iParam6, iParam7)) {
				*uParam0++;
			}
			else {
				*iParam1 = 0;
				*uParam0 = 3;
			}
		}
		break;

	case 1:
		if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
			*uParam0++;
		}
		break;

	case 2:
		if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
			*iParam1 = 1;
			*uParam0++;
		}
		else {
			*iParam1 = 0;
			*uParam0++;
		}
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xCF70
int func_171(var *uParam0) {
	struct<13> Var0;
	struct<97> Var13;
	struct<6> Var111;
	int iVar119;
	int iVar120;
	int iVar121;
	int iVar122;
	int iVar123;
	int iVar124;
	bool bVar125;
	int iVar126;
	bool bVar127;
	int iVar128;

	Var13.f_19.f_1 = 4;
	iVar122 = -1;
	iVar126 = 0;
	Var0 = {func_23(player::player_id())};
	switch ((*uParam0)[iVar126]) {
	case 0:
		Global_1835390.f_2775[iVar126] = -1;
		Global_1835390.f_2704[iVar126] = 0;
		Global_1835013.f_374 = -1;
		Global_1835389 = 0;
		if (func_172(uParam0->f_44)) {
			if (!Global_1835389) {
				Global_1835389 = 1;
			}
		}
		else if (Global_1835389) {
			Global_1835389 = 0;
		}
		if (!Global_1835389) {
		}
		if (func_167(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 11, &Var0, func_168(), 0, 0, 0)) {
			func_166(&Var111, &uParam0->f_44);
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var111)) {
				if (Var111.f_3 > 0) {
					iVar124 = 0;
					iVar119 = 0;
					if (func_168()) {
						iVar124 = 0;
						while (iVar124 < Var111.f_3) {
							stats::_0x34770B9CE0E03B91(iVar124, &Var13);
							if (Global_1835013.f_374 < 0) {
								if (func_130(&Var13, &Var0) || func_130(&Var13, &Global_1835013.f_361)) {
									Global_1835013.f_374 = Var13.f_96;
								}
							}
							if (iVar122 < 0) {
								if (gameplay::is_bit_set(Global_1835013.f_142.f_2, 0)) {
									if (Global_1835013.f_211.f_36[0] >= stats::_0x88578F6EC36B4A3A(iVar124, 0)) {
										iVar122 = iVar124;
									}
								}
								else if (Global_1835013.f_211.f_3[0] >= stats::_0x38491439B6BA7F7D(iVar124, 0)) {
									iVar122 = iVar124;
								}
							}
							func_165(&Var13);
							iVar124++;
						}
						if (iVar122 < 0) {
							iVar122 = Var111.f_3;
						}
					}
					iVar124 = 0;
					stats::_0x34770B9CE0E03B91(0, &Var13);
					if (Var13.f_96 <= 1) {
						if (Global_1835390.f_2704[iVar126] < 12) {
							if (func_168() && iVar122 == 0) {
								func_164(uParam0,
										 &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
										 Var13.f_96);
								Global_1835390.f_2775[iVar126] = 0;
								Global_1835390.f_2704[iVar126]++;
							}
							if (func_168() && (func_130(&Var13, &Var0) || func_130(&Var13, &Global_1835013.f_361))) {
							}
							else {
								if (func_130(&Var13, &Var0)) {
									iVar122 = 0;
									Global_1835390.f_2775[iVar126] = 0;
								}
								MemCopy(&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
										{Var13.f_13}, 16);
								Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_32 = {Var13};
								Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_59 =
									Var13.f_96;
								if (func_163(uParam0->f_44)) {
									iVar121 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
									if (iVar121 == 1) {
										Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_58 = 1;
									}
									else {
										Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_58 = 0;
									}
								}
								if (func_179(uParam0->f_44)) {
									MemCopy(
										&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_16,
										{Var13.f_19.f_1[1 /*16*/].f_8}, 16);
								}
								Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_74 = 1;
								iVar119 = 0;
								while (iVar119 < Global_1835390.f_2708) {
									if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar119])) {
										Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
											.f_67[iVar119] =
											stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2710[iVar119]);
									}
									else {
										Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
											.f_60[iVar119] =
											stats::_0x38491439B6BA7F7D(0, Global_1835390.f_2710[iVar119]);
									}
									iVar119++;
								}
								Global_1835390.f_2704[iVar126]++;
							}
							bVar125 = true;
						}
					}
					if (!bVar125) {
						Global_1835390.f_2704[iVar126]++;
					}
					if (!func_168()) {
						iVar122 = Var111.f_5;
					}
					if (iVar122 > 6) {
						iVar123 = iVar122 - 6;
					}
					else if (bVar125) {
						iVar123 = 1;
					}
					else {
						iVar123 = 0;
					}
					iVar124 = iVar123;
					func_165(&Var13);
					iVar124 = iVar123;
					while (iVar124 <= Var111.f_3 - 1) {
						stats::_0x34770B9CE0E03B91(iVar124, &Var13);
						if (Global_1835390.f_2704[iVar126] < 12 && Var13.f_96 > 1) {
							if (func_168() && iVar122 == iVar124) {
								if (!func_130(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_32, &Var13)) {
									func_164(uParam0,
											 &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
											 Var13.f_96);
									Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
									Global_1835390.f_2704[iVar126]++;
								}
							}
							if (func_168() && (func_130(&Var13, &Var0) || func_130(&Var13, &Global_1835013.f_361))) {
							}
							else if (Global_1835390.f_2704[iVar126] < 12) {
								if (func_131(Var13) &&
									!func_130(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_32, &Var13)) {
									if (func_130(&Var13, &Var0)) {
										if (Global_1835390.f_2775[iVar126] < 0) {
											Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
										}
									}
									MemCopy(&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
											{Var13.f_13}, 16);
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_32 = {
										Var13};
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_59 =
										Var13.f_96;
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_74 = 1;
									if (func_163(uParam0->f_44)) {
										iVar121 = stats::_0x88578F6EC36B4A3A(iVar124, Global_1835390.f_2709);
										if (iVar121 == 1) {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_58 = 1;
										}
										else {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_58 = 0;
										}
									}
									if (func_179(uParam0->f_44)) {
										MemCopy(&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
													 .f_16,
												{Var13.f_19.f_1[1 /*16*/].f_8}, 16);
									}
									iVar119 = 0;
									iVar119 = 0;
									while (iVar119 < Global_1835390.f_2708) {
										if (gameplay::is_bit_set(Global_1835390.f_2769,
																 Global_1835390.f_2710[iVar119])) {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_67[iVar119] =
												stats::_0x88578F6EC36B4A3A(iVar124, Global_1835390.f_2710[iVar119]);
										}
										else {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_60[iVar119] =
												stats::_0x38491439B6BA7F7D(iVar124, Global_1835390.f_2710[iVar119]);
										}
										iVar119++;
									}
									Global_1835390.f_2704[iVar126]++;
								}
							}
						}
						func_165(&Var13);
						iVar124++;
					}
					stats::_0x71B008056E5692D6();
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					if (bVar125) {
						if (Global_1835390.f_2775[iVar126] == -1 && func_168()) {
							if (Global_1835390.f_2704[iVar126] >= 1) {
								func_164(
									uParam0, &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] - 1 /*75*/].f_59 +
										1);
							}
							else {
								func_164(uParam0,
										 &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/], 1);
							}
							Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
							Global_1835390.f_2704[iVar126]++;
						}
						(*uParam0)[iVar126] = 2;
					}
					else {
						(*uParam0)[iVar126] = 1;
					}
				}
				else {
					if (!bVar125) {
						Global_1835390.f_2704[iVar126]++;
					}
					stats::_0x71B008056E5692D6();
					func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
					Global_1835390.f_2775[iVar126] = -1;
					(*uParam0)[iVar126] = 1;
				}
			}
			else {
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				Global_1835390.f_2775[iVar126] = -1;
				(*uParam0)[iVar126] = 1;
				gameplay::set_bit(&Global_1835390.f_2832, iVar126);
			}
		}
		break;

	case 1:
		if (Global_1835390.f_2775[iVar126] == -1) {
			iVar128 = 11;
		}
		else {
			iVar128 = 1;
		}
		if (func_158(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, iVar128)) {
			func_166(&Var111, &uParam0->f_44);
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var111)) {
				if (Var111.f_3 > 0) {
					iVar119 = 0;
					while (iVar119 < Var111.f_3) {
						stats::_0x34770B9CE0E03B91(iVar119, &Var13);
						if (func_168() && (func_130(&Var13, &Var0) || func_130(&Var13, &Global_1835013.f_361))) {
						}
						else {
							bVar127 = false;
							if (Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 > 1 ||
								Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 <= 0) {
								bVar127 = true;
							}
							if (Global_1835390.f_2704[iVar126] < 12 || bVar127) {
								if (iVar119 == 0 || bVar127) {
									MemCopy(&Global_1835390[iVar126 /*901*/][0 /*75*/], {Var13.f_13}, 16);
									Global_1835390[iVar126 /*901*/][0 /*75*/].f_32 = {Var13};
									Global_1835390[iVar126 /*901*/][0 /*75*/].f_59 = Var13.f_96;
									if (func_163(uParam0->f_44)) {
										iVar121 = stats::_0x88578F6EC36B4A3A(0, Global_1835390.f_2709);
										if (iVar121 == 1) {
											Global_1835390[iVar126 /*901*/][0 /*75*/].f_58 = 1;
										}
										else {
											Global_1835390[iVar126 /*901*/][0 /*75*/].f_58 = 0;
										}
									}
									if (func_179(uParam0->f_44)) {
										MemCopy(&Global_1835390[iVar126 /*901*/][0 /*75*/].f_16,
												{Var13.f_19.f_1[1 /*16*/].f_8}, 16);
									}
									Global_1835390[iVar126 /*901*/][0 /*75*/].f_74 = 1;
									iVar120 = 0;
									iVar120 = 0;
									while (iVar120 < Global_1835390.f_2708) {
										if (gameplay::is_bit_set(Global_1835390.f_2769,
																 Global_1835390.f_2710[iVar120])) {
											Global_1835390[iVar126 /*901*/][iVar119 /*75*/].f_67[iVar120] =
												stats::_0x88578F6EC36B4A3A(iVar119, Global_1835390.f_2710[iVar120]);
										}
										else {
											Global_1835390[iVar126 /*901*/][iVar119 /*75*/].f_60[iVar120] =
												stats::_0x38491439B6BA7F7D(iVar119, Global_1835390.f_2710[iVar120]);
										}
										iVar120++;
									}
									if (Global_1835390.f_2704[iVar126] == 0) {
										if (bVar127) {
										}
										else {
											Global_1835390.f_2704[iVar126]++;
										}
									}
									else if (Global_1835390.f_2704[iVar126] == 1 &&
											 Global_1835390.f_2775[iVar126] == -1) {
										Global_1835390.f_2704[iVar126]++;
									}
								}
								else if (Global_1835390.f_2704[iVar126] < 12) {
									MemCopy(&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
											{Var13.f_13}, 16);
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_32 = {
										Var13};
									if (func_163(uParam0->f_44)) {
										iVar121 = stats::_0x88578F6EC36B4A3A(iVar119, Global_1835390.f_2709);
										if (iVar121 == 1) {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_58 = 1;
										}
										else {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_58 = 0;
										}
									}
									if (func_179(uParam0->f_44)) {
										MemCopy(&Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
													 .f_16,
												{Var13.f_19.f_1[1 /*16*/].f_8}, 16);
									}
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_59 =
										Var13.f_96;
									Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/].f_74 = 1;
									iVar120 = 0;
									iVar120 = 0;
									while (iVar120 < Global_1835390.f_2708) {
										if (gameplay::is_bit_set(Global_1835390.f_2769,
																 Global_1835390.f_2710[iVar120])) {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_67[iVar120] =
												stats::_0x88578F6EC36B4A3A(iVar119, Global_1835390.f_2710[iVar120]);
										}
										else {
											Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/]
												.f_60[iVar120] =
												stats::_0x38491439B6BA7F7D(iVar119, Global_1835390.f_2710[iVar120]);
										}
										iVar120++;
									}
									if (iVar119 != 0) {
										Global_1835390.f_2704[iVar126]++;
									}
								}
							}
						}
						func_165(&Var13);
						iVar119++;
					}
				}
				stats::_0x71B008056E5692D6();
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				(*uParam0)[iVar126] = 2;
			}
			else {
				gameplay::set_bit(&Global_1835390.f_2832, iVar126);
				func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
				Global_1835390.f_2704[iVar126] = 0;
				(*uParam0)[iVar126] = 2;
				Global_1835390.f_2704[1] = 0;
				(*uParam0)[1] = 1;
				Global_1835390.f_2704[2] = 0;
				(*uParam0)[2] = 3;
			}
		}
		if (Global_1835390.f_2775[iVar126] == -1 && func_168()) {
			if (Global_1835390.f_2704[iVar126] >= 1) {
				func_164(uParam0, &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/],
						 Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] - 1 /*75*/].f_59 + 1);
			}
			else {
				func_164(uParam0, &Global_1835390[iVar126 /*901*/][Global_1835390.f_2704[iVar126] /*75*/], 1);
			}
			Global_1835390.f_2775[iVar126] = Global_1835390.f_2704[iVar126];
			Global_1835390.f_2704[iVar126]++;
		}
		break;

	case 2:
		func_157(iVar126, Global_1835013.f_374);
		(*uParam0)[iVar126] = 3;
		break;

	case 3: return 1;
	}
	return 0;
}

// Position - 0xDDAB
bool func_172(struct<4> Param0, var uParam4, var uParam5, var uParam6, var uParam7, var uParam8, var uParam9,
			  var uParam10, var uParam11, var uParam12, var uParam13, var uParam14, var uParam15, var uParam16,
			  var uParam17, var uParam18, var uParam19, var uParam20, var uParam21, var uParam22, var uParam23,
			  var uParam24, var uParam25, var uParam26, var uParam27, var uParam28, var uParam29, var uParam30,
			  var uParam31, var uParam32, var uParam33, var uParam34, var uParam35, var uParam36, var uParam37,
			  var uParam38, var uParam39, var uParam40, var uParam41, var uParam42, var uParam43, var uParam44,
			  var uParam45, var uParam46, var uParam47, var uParam48, var uParam49, var uParam50, var uParam51,
			  var uParam52, var uParam53, var uParam54, var uParam55, var uParam56, var uParam57, var uParam58,
			  var uParam59, var uParam60, var uParam61, var uParam62, var uParam63, var uParam64, var uParam65,
			  var uParam66, var uParam67, var uParam68) {
	int iVar0;

	if (Global_1835388) {
		if (Global_1835013.f_5 != 0) {
			if (Global_1835013.f_5 == Param0) {
				if (Global_1835013.f_5.f_2 == Param0.f_3) {
					iVar0 = 0;
					while (iVar0 < Param0.f_3) {
						if (!gameplay::are_strings_equal(&Global_1835013.f_5.f_2.f_1[iVar0 /*16*/],
														 &Param0.f_3.f_1[iVar0 /*16*/]) ||
							!gameplay::are_strings_equal(&Global_1835013.f_5.f_2.f_1[iVar0 /*16*/].f_8,
														 &Param0.f_3.f_1[iVar0 /*16*/].f_8)) {
							return false;
						}
						iVar0++;
					}
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0xDE43
void func_173(var *uParam0) {
	int iVar0;

	if (stats::leaderboards_get_cache_exists(Global_1835390.f_2826)) {
		iVar0 = stats::leaderboards_get_cache_time(Global_1835390.f_2826);
		if (iVar0 < 300000) {
			gameplay::set_bit(&uParam0->f_42, 5);
		}
		else {
			gameplay::clear_bit(&uParam0->f_42, 5);
			func_143(Global_1835390.f_2826, -1);
		}
	}
}

// Position - 0xDE93
bool func_174(var *uParam0) { return uParam0->f_1; }

// Position - 0xDE9F
void func_175(int iParam0) {
	if (graphics::has_scaleform_movie_loaded(iParam0)) {
		graphics::draw_scaleform_movie_fullscreen(iParam0, 255, 255, 255, 0, 0);
	}
}

// Position - 0xDEBF
void func_176(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	char *sVar0;
	struct<2> Var1;
	struct<16> Var36;
	bool bVar52;
	struct<13> Var53;
	int iVar66;
	struct<13> Var67;
	int iVar80;

	sVar0 = "";
	if (gameplay::is_bit_set(iParam2, 4)) {
		sVar0 = "SCLB_GLOBAL";
	}
	else if (gameplay::is_bit_set(iParam2, 5)) {
		*iParam1++;
		sVar0 = "SCLB_FRIENDS";
	}
	else if (gameplay::is_bit_set(iParam2, 6)) {
		*iParam1++;
		if (network::network_is_signed_online() && network::_network_player_is_in_clan()) {
			if (gameplay::is_orbis_version() && !network::_0x72D918C99BCACC54(0)) {
				sVar0 = "SCLB_CREW";
			}
			else {
				Var53 = {func_23(player::player_id())};
				if (network::network_clan_player_is_active(&Var53)) {
					network::network_clan_player_get_desc(&Var1, 35, &Var53);
					if (!gameplay::is_string_null_or_empty(&Var1.f_1)) {
						sVar0 = "STRING";
						Var36 = {Var1.f_1};
						bVar52 = true;
					}
					else {
						sVar0 = "SCLB_CREW";
					}
				}
				else {
					sVar0 = "SCLB_CREW";
				}
			}
		}
		else {
			sVar0 = "SCLB_CREW";
		}
	}
	graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	if (bVar52) {
		graphics::begin_text_command_scaleform_string(sVar0);
		ui::_add_text_component_scaleform(&Var36);
		graphics::end_text_command_scaleform_string();
	}
	else {
		graphics::begin_text_command_scaleform_string(sVar0);
		graphics::end_text_command_scaleform_string();
	}
	graphics::_pop_scaleform_movie_function_void();
	*iParam1++;
	if (iParam4) {
		iVar66 = 0;
		gameplay::set_bit(&iVar66, 7);
		graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
		graphics::_push_scaleform_movie_function_parameter_int(iVar66);
		if (!network::network_is_signed_online()) {
			sVar0 = "SCLB_NOT_ONL";
		}
		else if (!network::_network_are_ros_available()) {
			sVar0 = "SCLB_NO_ROS";
		}
		else if (Global_1835390.f_2832 != 0) {
			sVar0 = "SCLB_READ_FAIL";
		}
		else {
			sVar0 = "HUD_PERM";
		}
		graphics::begin_text_command_scaleform_string(sVar0);
		graphics::_end_text_command_scaleform_string_2();
		graphics::_pop_scaleform_movie_function_void();
		*iParam1++;
	}
	else if (iParam3) {
		if (gameplay::is_bit_set(iParam2, 4)) {
			sVar0 = "SCLB_NO_GLOBAL";
		}
		else if (gameplay::is_bit_set(iParam2, 5)) {
			if (network::network_get_friend_count() > 0) {
				sVar0 = "SCLB_NO_FRNDS";
			}
			else {
				sVar0 = "SCLB_NO_FRNDSb";
			}
		}
		else if (gameplay::is_bit_set(iParam2, 6)) {
			if (network::_0x67A5589628E0CFF6()) {
				if (network::_0xBA9775570DB788CF()) {
					if (network::network_is_signed_online() && network::_network_player_is_in_clan()) {
						if (gameplay::is_orbis_version() && !network::_0x72D918C99BCACC54(0)) {
							sVar0 = "SCLB_NO_CREWc";
						}
						else {
							Var67 = {func_23(player::player_id())};
							if (network::network_clan_player_is_active(&Var67)) {
								network::network_clan_player_get_desc(&Var1, 35, &Var67);
								if (!gameplay::is_string_null_or_empty(&Var1.f_1)) {
									sVar0 = "SCLB_NO_CREWb";
									Var36 = {Var1.f_1};
									bVar52 = true;
								}
								else {
									sVar0 = "SCLB_NO_CREWc";
								}
							}
							else {
								sVar0 = "SCLB_NO_CREWa";
							}
						}
					}
					else {
						sVar0 = "SCLB_NO_CREWa";
					}
				}
				else {
					sVar0 = "SCLB_NO_CREWe";
				}
			}
			else {
				sVar0 = "SCLB_NO_CREWd";
			}
		}
		iVar80 = 0;
		gameplay::set_bit(&iVar80, 7);
		graphics::_push_scaleform_movie_function(iParam0, "SET_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(*iParam1);
		graphics::_push_scaleform_movie_function_parameter_int(iVar80);
		if (bVar52) {
			graphics::begin_text_command_scaleform_string(sVar0);
			ui::_add_text_component_scaleform(&Var36);
			graphics::_end_text_command_scaleform_string_2();
		}
		else {
			graphics::begin_text_command_scaleform_string(sVar0);
			graphics::_end_text_command_scaleform_string_2();
		}
		graphics::_pop_scaleform_movie_function_void();
		*iParam1++;
	}
}

// Position - 0xE195
void func_177(int iParam0, char *sParam1, var *uParam2, int iParam3) {
	int iVar0;

	graphics::_push_scaleform_movie_function(iParam0, "SET_TITLE");
	graphics::begin_text_command_scaleform_string(sParam1);
	graphics::end_text_command_scaleform_string();
	iVar0 = 0;
	while (iVar0 < iParam3) {
		graphics::begin_text_command_scaleform_string(&(*uParam2)[iVar0 /*6*/]);
		graphics::end_text_command_scaleform_string();
		iVar0++;
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xE1D7
void func_178(int iParam0, char *sParam1, char *sParam2, char *sParam3, int iParam4, int iParam5) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_MULTIPLAYER_TITLE");
	graphics::begin_text_command_scaleform_string(sParam1);
	if (!gameplay::is_string_null_or_empty(sParam2)) {
		ui::add_text_component_substring_text_label(sParam2);
	}
	if (iParam5 == -1) {
		if (iParam4) {
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				ui::_add_text_component_scaleform(sParam3);
			}
		}
		else if (!gameplay::is_string_null_or_empty(sParam3)) {
			ui::add_text_component_substring_text_label(sParam3);
		}
	}
	else {
		if (iParam4) {
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				ui::_add_text_component_scaleform(sParam3);
			}
		}
		else if (!gameplay::is_string_null_or_empty(sParam3)) {
			ui::add_text_component_substring_text_label(sParam3);
		}
		ui::add_text_component_integer(iParam5);
	}
	graphics::end_text_command_scaleform_string();
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xE267
bool func_179(int iParam0) {
	if (iParam0 == 825 || iParam0 == 828) {
		return true;
	}
	return false;
}

// Position - 0xE289
void func_180(int iParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_DISPLAY_TYPE");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xE2A6
var func_181() { return unk_0x67D02A194A2FC2BD("SC_LEADERBOARD"); }

// Position - 0xE2B6
int func_182() { return func_183(player::player_id()); }

// Position - 0xE2C6
int func_183(int iParam0) {
	switch (func_184(iParam0)) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 6:
	case 5:
	case 7:
	case 38:
	case 33:
	case 36:
	case 39: return 0;

	default:
	}
	return 1;
}

// Position - 0xE326
int func_184(int iParam0) { return Global_1591201[iParam0 /*602*/].f_188; }

// Position - 0xE339
void func_185(int iParam0) { Global_1318071 = iParam0; }

// Position - 0xE347
void func_186(int iParam0) { Global_1354542.f_995 = iParam0; }

// Position - 0xE358
void func_187() {
	func_189();
	func_188(4, -1);
	func_188(6, -1);
	func_188(7, -1);
	func_188(3, -1);
	func_188(1, -1);
	func_188(2, -1);
	func_188(11, -1);
	func_188(13, -1);
	func_188(14, -1);
	func_188(16, -1);
}

// Position - 0xE3A4
void func_188(int iParam0, int iParam1) {
	gameplay::set_bit(&Global_1353070.f_1014, iParam0);
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			Global_1353070.f_170[iParam1] = 1;
		}
		break;
	}
}

// Position - 0xE3DA
void func_189() { Global_2494199.f_4394 = 0; }

// Position - 0xE3EA
void func_190(var *uParam0, int iParam1, int iParam2) {
	if (network::network_is_game_in_progress() && !iParam1) {
		if (!iParam2) {
			*uParam0 = network::get_network_time();
		}
		else {
			*uParam0 = network::_0x89023FBBF9200E9F();
		}
	}
	else {
		*uParam0 = gameplay::get_game_timer();
	}
	uParam0->f_1 = 1;
}

// Position - 0xE427
int func_191(int *iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 2;
	if (Global_1840922.f_2 + 5 < gameplay::get_frame_count() && Global_1840922.f_2 > 0) {
		func_85(&Global_1840922);
		func_85(&Global_1840922.f_49);
		*iParam0 = 0;
		Global_1840922.f_2 = 0;
		func_199(0);
	}
	Global_1840922.f_2 = gameplay::get_frame_count();
	iVar1 = -1;
	if (gameplay::is_orbis_version()) {
		if (network::_0xBD545D44CCE70597() == 0) {
			iVar1 = network::_0x74FB3E29E6D10FA9();
		}
	}
	if (gameplay::is_orbis_version() && (iVar1 == 4 || iVar1 == 2 || iVar1 == 1 || iVar1 == 5) ||
		!func_197() && network::network_is_signed_online()) {
		if (network::_0x8D11E61A4ABF49CC()) {
			func_194(&Global_1840922.f_3, func_196(&Global_1840922.f_3));
			if (!gameplay::is_bit_set(*iParam0, 4)) {
				gameplay::set_bit(iParam0, 4);
				StringCopy(&Global_1840922.f_3.f_1, "", 64);
				func_192(&Global_1840922.f_3, 0);
			}
		}
		else {
			if (iVar1 == 4) {
				ui::_set_warning_message_2("PM_INF_QMFT", "HUD_PROFILECHNG", iVar0, 0, 0, -1, 0, 0, 1);
			}
			else if (iVar1 == 2) {
				ui::_set_warning_message_2("PM_INF_QMFT", "HUD_GAMEUPD_G", iVar0, 0, 0, -1, 0, 0, 1);
			}
			else if (iVar1 == 1) {
				ui::_set_warning_message_2("PM_INF_QMFT", "HUD_SYSTUPD_G", iVar0, 0, 0, -1, 0, 0, 1);
			}
			else if (iVar1 == 5) {
				ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0, -1, 0, 0, 1);
			}
			else if (!func_197()) {
				ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_ROS", iVar0, 0, 0, -1, 0, 0, 1);
			}
			if (!gameplay::is_bit_set(*iParam0, 0)) {
				if (!controls::is_control_pressed(2, 201)) {
					gameplay::set_bit(iParam0, 0);
				}
			}
			else if (controls::is_control_just_released(2, 201)) {
				func_85(&Global_1840922.f_49);
				func_85(&Global_1840922);
				*iParam0 = 0;
				Global_1840922.f_2 = 0;
				func_199(0);
				return 1;
			}
		}
	}
	else {
		func_194(&Global_1840922.f_3, func_196(&Global_1840922.f_3));
		if (func_174(&Global_1840922.f_49) && !func_137(&Global_1840922.f_49, 2000, 1) &&
			!network::network_is_signed_online()) {
			gameplay::set_bit(iParam0, 3);
			StringCopy(&Global_1840922.f_3.f_1, "", 64);
			func_192(&Global_1840922.f_3, 0);
		}
		else if (!gameplay::is_bit_set(*iParam0, 3)) {
			if (!gameplay::is_bit_set(*iParam0, 1)) {
				player::display_system_signin_ui(0);
				gameplay::set_bit(iParam0, 1);
				StringCopy(&Global_1840922.f_3.f_1, "", 64);
				func_192(&Global_1840922.f_3, 0);
			}
		}
		if (func_174(&Global_1840922)) {
			if (!func_137(&Global_1840922, 4000, 1)) {
				iVar2 = 1;
			}
		}
		if (!iVar2) {
			if (iParam1) {
				if (!network::network_is_signed_online()) {
					if (network::network_is_cable_connected()) {
						ui::_set_warning_message_2("PM_INF_QMFT", "STORE_NOT_ONL", iVar0, 0, 0, -1, 0, 0, 1);
					}
					else {
						ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0, -1, 0, 0, 1);
					}
					if (!player::is_system_ui_being_displayed()) {
						if (!gameplay::is_bit_set(*iParam0, 0)) {
							if (!controls::is_control_pressed(2, 201)) {
								gameplay::set_bit(iParam0, 0);
							}
						}
						else if (controls::is_control_just_released(2, 201)) {
							func_85(&Global_1840922);
							*iParam0 = 0;
							Global_1840922.f_2 = 0;
							func_199(0);
							return 1;
						}
					}
				}
				else {
					func_85(&Global_1840922);
					*iParam0 = 0;
					Global_1840922.f_2 = 0;
					func_199(0);
					return 1;
				}
			}
			else if (gameplay::is_bit_set(*iParam0, 3)) {
				if (network::network_is_cable_connected()) {
					ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_SIGN_OUT", iVar0, 0, 0, -1, 0, 0, 1);
				}
				else {
					ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0, -1, 0, 0, 1);
				}
				if (!gameplay::is_bit_set(*iParam0, 0)) {
					if (!controls::is_control_pressed(2, 201)) {
						gameplay::set_bit(iParam0, 0);
					}
				}
				else if (controls::is_control_just_released(2, 201)) {
					func_85(&Global_1840922.f_49);
					func_85(&Global_1840922);
					*iParam0 = 0;
					Global_1840922.f_2 = 0;
					func_199(0);
					return 1;
				}
			}
			else {
				if (network::network_is_cable_connected()) {
					ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NOT_ONL", iVar0, 0, 0, -1, 0, 0, 1);
				}
				else {
					ui::_set_warning_message_2("PM_INF_QMFT", "SCLB_NO_INT", iVar0, 0, 0, -1, 0, 0, 1);
				}
				if (!player::is_system_ui_being_displayed()) {
					if (!gameplay::is_bit_set(*iParam0, 0)) {
						if (!controls::is_control_pressed(2, 201)) {
							gameplay::set_bit(iParam0, 0);
						}
					}
					else if (controls::is_control_just_released(2, 201)) {
						func_85(&Global_1840922.f_49);
						func_85(&Global_1840922);
						*iParam0 = 0;
						Global_1840922.f_2 = 0;
						func_199(0);
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0xE893
void func_192(var *uParam0, int iParam1) {
	func_193(uParam0);
	if (iParam1) {
		func_199(0);
	}
	uParam0->f_35 = 1;
}

// Position - 0xE8B0
void func_193(var *uParam0) {
	struct<46> Var0;

	Var0.f_41 = 1;
	*uParam0 = {Var0};
}

// Position - 0xE8CB
void func_194(int *iParam0, int iParam1) {
	if (iParam1 == 1) {
		*iParam0 = 0;
		func_195(iParam0);
	}
	if (*iParam0 == 0) {
		if (iParam0->f_36) {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::add_text_component_integer(iParam0->f_33);
			ui::add_text_component_integer(iParam0->f_34);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		else if (iParam0->f_37) {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::add_text_component_integer(iParam0->f_33);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		else if (iParam0->f_39) {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::add_text_component_substring_player_name(&iParam0->f_17);
			ui::add_text_component_integer(iParam0->f_33);
			ui::add_text_component_integer(iParam0->f_34);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		else if (iParam0->f_38) {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::add_text_component_substring_player_name(&iParam0->f_17);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		else if (iParam0->f_40) {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::add_text_component_substring_time(iParam0->f_33, 70);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		else {
			ui::_set_loading_prompt_text_entry(&iParam0->f_1);
			ui::_show_loading_prompt(iParam0->f_41);
		}
		*iParam0 = 1;
	}
	if (*iParam0 == 1) {
	}
}

// Position - 0xE9C9
void func_195(int *iParam0) { iParam0->f_35 = 0; }

// Position - 0xE9D6
int func_196(var *uParam0) { return uParam0->f_35; }

// Position - 0xE9E2
int func_197() {
	if (func_198()) {
		return 0;
	}
	if (network::network_is_cloud_available() == 0) {
		return 0;
	}
	return 1;
}

// Position - 0xEA02
bool func_198() { return Global_2453019; }

// Position - 0xEA0E
void func_199(int iParam0) {
	ui::_remove_loading_prompt();
	if (iParam0) {
		ui::_0xC65AB383CD91DF98();
	}
}

// Position - 0xEA23
bool func_200(var *uParam0, int iParam1, int *iParam2) {
	if (!iLocal_290) {
		func_212(&uParam0->f_72, iParam1);
		iLocal_290 = 1;
		func_312(&uParam0->f_666, 9, 0);
	}
	else {
		if (Global_1835013.f_1 && !Global_1835013.f_2) {
			func_209(190, iParam1);
			Global_1835013.f_2 = 1;
			*iParam2 = 1;
		}
		if (func_201(&uParam0->f_72)) {
			Global_1835388 = 1;
			return true;
		}
	}
	return false;
}

// Position - 0xEA8C
bool func_201(var *uParam0) {
	struct<98> Var0;
	struct<4> Var98;
	struct<37> Var106;
	struct<13> Var175;
	int iVar188;

	Var0.f_19.f_1 = 4;
	Var106.f_3 = 32;
	Var106.f_36 = 32;
	if (func_179(uParam0->f_44)) {
		Var175 = {Global_1835013.f_361};
	}
	else {
		Var175 = {func_23(player::player_id())};
	}
	switch (Global_1835013) {
	case 0:
		if (func_208(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, &Var175)) {
			func_166(&Var98, &uParam0->f_44);
			Global_1835013.f_142 = uParam0->f_44;
			Global_1835013.f_142.f_1 = stats::leaderboards_get_number_of_columns(uParam0->f_44, 0);
			iVar188 = 0;
			while (iVar188 < Global_1835013.f_142.f_1) {
				if (!func_207(uParam0->f_44, iVar188)) {
					if (func_206(uParam0->f_44, 4, iVar188)) {
						gameplay::set_bit(&Global_1835013.f_142.f_2, iVar188);
					}
					else {
						gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar188);
					}
				}
				iVar188++;
			}
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
				if (Var98.f_3 > 0) {
					stats::_0x34770B9CE0E03B91(0, &Var0);
					if (Var0.f_97 != Global_1835013.f_142.f_1) {
					}
					if (!func_131(Var0)) {
						Global_1835013.f_4 = 1;
					}
					else {
						iVar188 = 0;
						while (iVar188 < Global_1835013.f_142.f_1) {
							if (!func_207(uParam0->f_44, iVar188)) {
								if (func_206(uParam0->f_44, 4, iVar188)) {
									Global_1835013.f_73.f_36[iVar188] = stats::_0x88578F6EC36B4A3A(0, iVar188);
									if (Global_1835013.f_73.f_36[iVar188] == -1) {
										if (iVar188 > Var0.f_97) {
											Global_1835013.f_73.f_36[iVar188] = 0;
										}
									}
								}
								else {
									Global_1835013.f_73.f_3[iVar188] = stats::_0x38491439B6BA7F7D(0, iVar188);
									if (Global_1835013.f_73.f_3[iVar188] == -1f) {
										if (iVar188 > Var0.f_97) {
											Global_1835013.f_73.f_3[iVar188] = 0f;
										}
									}
								}
							}
							iVar188++;
						}
					}
				}
				else {
					Global_1835013.f_4 = 1;
				}
				stats::_0x71B008056E5692D6();
			}
			else {
				Global_1835013.f_4 = 1;
			}
			Global_1835013 = 1;
			func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
		}
		break;

	case 1:
		Global_1835013.f_1 = 1;
		if (Global_1835013.f_2) {
			func_205();
			if (Global_1835013.f_4) {
				if (func_204(uParam0->f_44)) {
					Global_1835013 = 3;
				}
				else {
					Global_1835013 = 2;
				}
			}
			else {
				Global_1835013 = 2;
			}
		}
		break;

	case 2:
		stats::_0xC38DC1E90D22547C(&Global_1835013.f_73, &Global_1835013.f_142, &Global_1835013.f_211);
		Global_1835013 = 4;
		uParam0->f_4 = 0;
		uParam0->f_5 = 0;
		break;

	case 3:
		Global_1835013.f_211 = {Global_1835013.f_142};
		Global_1835013 = 4;
		uParam0->f_4 = 0;
		uParam0->f_5 = 0;
		break;

	case 4:
		if (network::network_is_game_in_progress() && func_203()) {
			if (func_202()) {
				Global_1835013 = 99;
			}
			else {
				Global_1835013 = 999;
				return true;
			}
		}
		else {
			Global_1835013 = 999;
			return true;
		}
		break;

	case 99:
		if (func_204(uParam0->f_44)) {
			Global_1835013.f_280 = {Global_1835013.f_142};
		}
		else {
			Var106 = Global_1835013.f_142;
			Var106.f_1 = Global_1835013.f_142.f_1;
			Var106.f_2 = Global_1835013.f_142.f_2;
			stats::_0xC38DC1E90D22547C(&Var106, &Global_1835013.f_142, &Global_1835013.f_280);
		}
		Global_1835013 = 100;
		uParam0->f_4 = 0;
		uParam0->f_5 = 0;
		break;

	case 100:
		if (func_167(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44, 1, &Var175, 1, 1, Global_1835013.f_280.f_36[0],
					 Global_1835013.f_280.f_3[0])) {
			func_166(&Var98, &uParam0->f_44);
			if (uParam0->f_5 && stats::_0xA0F93D5465B3094D(&Var98)) {
				if (Var98.f_3 > 0) {
					stats::_0x34770B9CE0E03B91(0, &Var0);
					if (gameplay::are_strings_equal(&Var0.f_13, "")) {
						Global_979489.f_1 = -1;
					}
					else {
						Global_979489.f_1 = Var0.f_96;
					}
				}
				else {
					Global_979489.f_1 = -1;
				}
				stats::_0x71B008056E5692D6();
			}
			else {
				Global_979489.f_1 = -1;
			}
			Global_1835013 = 999;
			func_91(&uParam0->f_4, &uParam0->f_5, &uParam0->f_44);
		}
		break;

	case 999: return true;
	}
	return false;
}

// Position - 0xEEB0
bool func_202() { return gameplay::is_bit_set(Global_970912.f_8, 1); }

// Position - 0xEEC3
var func_203() { return Global_2450895.f_3; }

// Position - 0xEED1
bool func_204(int iParam0) {
	switch (iParam0) {
	case 817:
	case 850:
	case 824:
	case 827:
	case 815:
	case 826:
	case 777:
	case 825:
	case 828:
	case 849:
	case 928:
	case 795:
	case 202:
	case 811:
	case 193:
	case 975:
	case 976:
	case 970:
	case 973:
	case 968:
	case 969:
	case 966:
	case 974:
	case 971:
	case 967:
	case 965:
	case 972: return true;
	}
	if (iParam0 >= 998 && iParam0 <= 1197) {
		return true;
	}
	return false;
}

// Position - 0xEFA2
void func_205() {
	Global_1835013.f_73 = Global_1835013.f_142;
	Global_1835013.f_73.f_1 = Global_1835013.f_142.f_1;
	Global_1835013.f_73.f_2 = Global_1835013.f_142.f_2;
	Global_1835013.f_211 = Global_1835013.f_142;
	Global_1835013.f_211.f_1 = Global_1835013.f_142.f_1;
	Global_1835013.f_211.f_2 = Global_1835013.f_142.f_2;
}

// Position - 0xF002
bool func_206(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (iParam0 == 190) {
		if (iParam2 == 0) {
			return false;
		}
	}
	if (iParam0 == 203) {
		if (iParam2 == 3 || iParam2 == 6) {
			return false;
		}
	}
	if (iParam0 == 912) {
		if (iParam2 == 0 || iParam2 == 3) {
			return false;
		}
	}
	if (iParam0 == 762 || iParam0 == 822 || iParam0 == 823) {
		if (iParam2 == 0 || iParam2 == 3) {
			return false;
		}
	}
	if (iParam0 == 791) {
		if (iParam2 == 4) {
			return false;
		}
	}
	if (iParam0 == 780) {
		if (iParam2 == 3) {
			return false;
		}
	}
	if (iParam0 == 777) {
		if (iParam2 == 3 || iParam2 == 7) {
			return false;
		}
	}
	if (iParam0 == 1200) {
		if (iParam2 == 4) {
			return false;
		}
	}
	iVar0 = stats::leaderboards_get_column_type(iParam0, iParam1, iParam2);
	switch (iVar0) {
	case 1:
	case 2: return true;
	}
	return false;
}

// Position - 0xF104
int func_207(int iParam0, int iParam1) {
	if (stats::leaderboards_get_column_id(iParam0, 4, iParam1) == 156) {
		return 1;
	}
	switch (iParam0) {
	case 912:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 780:
		if (iParam1 == 4) {
			return 1;
		}
		break;

	case 1200:
		if (iParam1 == 5) {
			return 1;
		}
		break;
	}
	return 0;
}

// Position - 0xF15F
bool func_208(var *uParam0, int *iParam1, var *uParam2, var uParam3) {
	switch (*uParam0) {
	case 0:
		if (!func_161() && !func_160()) {
			func_159(*uParam2);
			if (stats::leaderboards2_read_by_handle(uParam2, uParam3)) {
				*uParam0++;
			}
			else {
				*iParam1 = 0;
				*uParam0 = 3;
			}
		}
		break;

	case 1:
		if (!stats::leaderboards_read_pending(*uParam2, uParam2->f_1, -1)) {
			*uParam0++;
		}
		break;

	case 2:
		if (stats::leaderboards_read_successful(*uParam2, uParam2->f_1, 0)) {
			*iParam1 = 1;
			*uParam0++;
		}
		else {
			*iParam1 = 0;
			*uParam0++;
		}
		break;

	case 3: return true;
	}
	return false;
}

// Position - 0xF213
void func_209(int iParam0, bool bParam1) {
	struct<6> Var0[1];
	struct<8> Var7[1];

	if (!player::is_player_online()) {
		return;
	}
	StringCopy(&Var7[0 /*8*/], "GameType", 32);
	if (bParam1) {
		StringCopy(&Var0[0 /*6*/], "MP", 24);
	}
	else {
		StringCopy(&Var0[0 /*6*/], "SP", 24);
	}
	if (func_211(iParam0, &Var0, &Var7, 1, -1, 1, 0)) {
		func_210(190, 131, 0, 0f, 1);
		func_210(190, 103, iLocal_151[1], 0f, 0);
		func_210(190, 99, iLocal_151[2], 0f, 0);
		func_210(190, 109, iLocal_151[3], 0f, 0);
		func_210(190, 106, iLocal_151[5], 0f, 0);
		func_210(190, 2, iLocal_151[10], 0f, 0);
		func_210(190, 107, iLocal_151[8], 0f, 0);
		func_210(190, 116, iLocal_151[6], 0f, 0);
		iLocal_151[1] = 0;
		iLocal_151[2] = 0;
		iLocal_151[3] = 0;
		iLocal_151[5] = 0;
		iLocal_151[10] = 0;
		iLocal_151[8] = 0;
		iLocal_151[6] = 0;
	}
}

// Position - 0xF303
void func_210(int iParam0, int iParam1, int iParam2, float fParam3, int iParam4) {
	int iVar0;
	int iVar1;

	if (!iParam4) {
		stats::_0x0BCA1D2C47B0D269(iParam1, iParam2, fParam3);
	}
	if (!Global_1835013.f_3) {
		Global_1835013.f_142 = iParam0;
		Global_1835013.f_142.f_1 = stats::leaderboards_get_number_of_columns(Global_1835013.f_142, 0);
		iVar1 = 0;
		while (iVar1 < 32) {
			if (iVar1 < Global_1835013.f_142.f_1) {
				if (iParam1 == 156) {
				}
				else if (func_206(iParam0, 4, iVar1)) {
					gameplay::set_bit(&Global_1835013.f_142.f_2, iVar1);
				}
				else {
					gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar1);
				}
			}
			else {
				gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar1);
			}
			iVar1++;
		}
		Global_1835013.f_3 = 1;
	}
	iVar1 = 0;
	while (iVar1 < 32) {
		if (iParam1 == stats::leaderboards_get_column_id(iParam0, 4, iVar1)) {
			iVar0 = iVar1;
			iVar1 = 32;
		}
		iVar1++;
	}
	Global_1835013.f_142.f_36[iVar0] = iParam2;
	Global_1835013.f_142.f_3[iVar0] = fParam3;
	if (iParam2 != 0) {
		gameplay::set_bit(&Global_1835013.f_142.f_2, iVar0);
	}
	else if (fParam3 != 0f) {
		gameplay::clear_bit(&Global_1835013.f_142.f_2, iVar0);
	}
}

// Position - 0xF41E
bool func_211(var uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	struct<68> Var0;
	int iVar68;
	struct<13> Var69;
	var uVar82;

	if (!network::network_is_signed_online()) {
	}
	if (!network::network_player_is_cheater() &&
		(network::network_have_online_privileges() || !network::_0x1353F87E89946207()) &&
		network::_0x422D396F80A96547()) {
		Var0.f_2.f_1 = 4;
		Var0 = uParam0;
		if (iParam4 == -1) {
			if (network::_network_player_is_in_clan()) {
				Var69 = {func_23(player::player_id())};
				if (network::network_clan_player_is_active(&Var69)) {
					if (network::network_clan_player_get_desc(&uVar82, 35, &Var69)) {
						Var0.f_1 = uVar82;
					}
				}
			}
		}
		else {
			Var0.f_1 = iParam4;
		}
		Var0.f_2 = iParam3;
		iVar68 = 0;
		while (iVar68 < iParam3) {
			Var0.f_2.f_1[iVar68 /*16*/] = {(*uParam2)[iVar68 /*8*/]};
			MemCopy(&Var0.f_2.f_1[iVar68 /*16*/].f_8, {(*uParam1)[iVar68 /*6*/]}, 8);
			iVar68++;
		}
		if (iParam5) {
			Global_1835013.f_5 = {Var0};
		}
		if (!iParam6) {
			if (network::network_is_game_in_progress() && Global_2450895.f_3) {
				stats::_0xC980E62E33DF1D5C(&Var0, &Global_1751175.f_10);
			}
			else {
				stats::leaderboards2_write_data(&Var0);
			}
		}
		return true;
	}
	if (network::network_player_is_cheater()) {
	}
	if (!network::network_have_online_privileges()) {
	}
	if (network::_0x1353F87E89946207()) {
	}
	if (!network::_0x422D396F80A96547()) {
	}
	return false;
}

// Position - 0xF552
void func_212(var *uParam0, bool bParam1) {
	int iVar0;

	iVar0 = 0;
	if (bParam1) {
		iVar0 = -1;
	}
	func_213(uParam0, 14, "DartsLB", "", iVar0, -1, 0, 0);
}

// Position - 0xF57A
void func_213(var *uParam0, int iParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	struct<8> Var0;
	struct<8> Var8;
	int iVar16;
	struct<6> Var17;

	if (!gameplay::is_string_null_or_empty(sParam2)) {
		StringCopy(&Var0, sParam2, 32);
	}
	if (iParam7) {
	}
	Global_1835390.f_2769 = 0;
	Global_1835390.f_2770 = 0;
	Global_1835390.f_2768 = 0;
	switch (iParam1) {
	case 2:
		if (iParam4 == 0) {
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44 = 826;
			}
			else {
				uParam0->f_44 = 815;
			}
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44.f_3 = 2;
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
				StringCopy(&Var8, "", 32);
				StringIntConCat(&Var8, iParam5, 32);
				uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
				Global_1835390.f_2780.f_26 = iParam5;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					if (iParam5 == 1) {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_L1", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
					else {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_LM", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
				}
				else if (iParam5 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_L1", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_LM", 32);
				}
			}
			else {
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE", 32);
					StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN", 32);
				}
				Global_1835390.f_2780.f_26 = -1;
			}
			Global_1835390.f_2780 = 1;
			if (iParam5 <= 0 || func_216()) {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
				Global_1835390.f_2710[0] = 1;
				Global_1835390.f_2710[1] = 3;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 4;
				Global_1835390.f_2708 = 2;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				Global_1835390.f_2780.f_28 = 4;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 3;
				Global_1835390.f_2780.f_29[2] = 5;
			}
			else {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
				Global_1835390.f_2710[0] = 2;
				Global_1835390.f_2710[1] = 1;
				Global_1835390.f_2710[2] = 3;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 4;
				Global_1835390.f_2708 = 3;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
				Global_1835390.f_2780.f_28 = 5;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 1;
				Global_1835390.f_2780.f_29[2] = 3;
				Global_1835390.f_2780.f_29[3] = 5;
			}
			Global_1835390.f_2779 = 0;
		}
		else if (iParam4 == 1) {
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44 = 827;
			}
			else {
				uParam0->f_44 = 824;
			}
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44.f_3 = 2;
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
				StringCopy(&Var8, "", 32);
				StringIntConCat(&Var8, iParam5, 32);
				uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
				Global_1835390.f_2780.f_26 = iParam5;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					if (iParam5 == 1) {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_L1", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
					else {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_LM", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
				}
				else if (iParam5 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN_L1", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN_LM", 32);
				}
			}
			else {
				Global_1835390.f_2780.f_26 = -1;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE", 32);
					StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_GRCE_NN", 32);
				}
			}
			Global_1835390.f_2780 = 1;
			if (iParam5 <= 0 || func_216()) {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
				Global_1835390.f_2710[0] = 1;
				Global_1835390.f_2710[1] = 5;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 6;
				Global_1835390.f_2708 = 2;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				Global_1835390.f_2780.f_28 = 4;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 3;
				Global_1835390.f_2780.f_29[2] = 5;
			}
			else {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
				Global_1835390.f_2710[0] = 2;
				Global_1835390.f_2710[1] = 1;
				Global_1835390.f_2710[2] = 5;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2708 = 3;
				Global_1835390.f_2709 = 6;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
				Global_1835390.f_2780.f_28 = 5;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 1;
				Global_1835390.f_2780.f_29[2] = 3;
				Global_1835390.f_2780.f_29[3] = 5;
			}
			Global_1835390.f_2779 = 0;
		}
		else if (iParam4 == 2) {
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44 = 828;
			}
			else {
				uParam0->f_44 = 825;
			}
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 2;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			if (!iParam6) {
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "CoDriver", 32);
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "", 32);
			}
			else {
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "CoDriver", 32);
				network::network_player_get_userid(player::player_id(), &Var17);
				MemCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, {Var17}, 8);
				Global_1835390.f_2780.f_27 = 1;
			}
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44.f_3 = 3;
				StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Laps", 32);
				StringCopy(&Var8, "", 32);
				StringIntConCat(&Var8, iParam5, 32);
				uParam0->f_44.f_3.f_1[2 /*16*/].f_8 = {Var8};
				Global_1835390.f_2780.f_26 = iParam5;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					if (iParam5 == 1) {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_L1", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
					else {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_LM", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
				}
				else if (iParam5 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN_L1", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN_LM", 32);
				}
			}
			else {
				Global_1835390.f_2780.f_26 = -1;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE", 32);
					StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RRCE_NN", 32);
				}
			}
			if (iParam5 <= 0 || func_216()) {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
				Global_1835390.f_2710[0] = 1;
				Global_1835390.f_2710[1] = 3;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 4;
				Global_1835390.f_2708 = 2;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				Global_1835390.f_2780.f_28 = 4;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 3;
				Global_1835390.f_2780.f_29[2] = 5;
			}
			else {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
				Global_1835390.f_2710[0] = 2;
				Global_1835390.f_2710[1] = 1;
				Global_1835390.f_2710[2] = 3;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2708 = 3;
				Global_1835390.f_2709 = 4;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
				Global_1835390.f_2780.f_28 = 5;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 1;
				Global_1835390.f_2780.f_29[2] = 3;
				Global_1835390.f_2780.f_29[3] = 5;
			}
			Global_1835390.f_2779 = 0;
		}
		else if (iParam4 == 10 || iParam4 == 11) {
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44 = 928;
			}
			else {
				uParam0->f_44 = 849;
			}
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44.f_3 = 2;
				StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Laps", 32);
				StringCopy(&Var8, "", 32);
				StringIntConCat(&Var8, iParam5, 32);
				uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var8};
				Global_1835390.f_2780.f_26 = iParam5;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					if (iParam5 == 1) {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_L1", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
					else {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_LM", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
				}
				else if (iParam5 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN_L1", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN_LM", 32);
				}
			}
			else {
				Global_1835390.f_2780.f_26 = -1;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE", 32);
					StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_FRCE_NN", 32);
				}
			}
			Global_1835390.f_2780 = 1;
			if (iParam5 <= 0 || func_216()) {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
				Global_1835390.f_2710[0] = 1;
				Global_1835390.f_2710[1] = 0;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 0;
				Global_1835390.f_2708 = 1;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				Global_1835390.f_2780.f_28 = 4;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 5;
			}
			else {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				Global_1835390.f_2710[0] = 2;
				Global_1835390.f_2710[1] = 1;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2708 = 2;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
				Global_1835390.f_2780.f_28 = 5;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 1;
				Global_1835390.f_2780.f_29[2] = 5;
			}
			Global_1835390.f_2779 = 0;
		}
		else if (iParam4 == 3) {
			if (iParam5 > 0 && !func_216()) {
				uParam0->f_44 = 998 + iParam5 - 1;
			}
			else {
				uParam0->f_44 = 975;
			}
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			if (iParam5 > 0 && !func_216()) {
				Global_1835390.f_2780.f_26 = iParam5;
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					if (iParam5 == 1) {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_L1", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
					else {
						StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_LM", 32);
						StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
					}
				}
				else if (iParam5 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_L1", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN_LM", 32);
				}
			}
			else {
				if (!gameplay::is_string_null_or_empty(sParam3)) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE", 32);
					StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_RCE_NN", 32);
				}
				Global_1835390.f_2780.f_26 = -1;
			}
			Global_1835390.f_2780 = 1;
			if (iParam5 <= 0 || func_216()) {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_RANK", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
				Global_1835390.f_2710[0] = 1;
				Global_1835390.f_2710[1] = 3;
				Global_1835390.f_2710[2] = 0;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 4;
				Global_1835390.f_2708 = 2;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				Global_1835390.f_2780.f_28 = 4;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 3;
				Global_1835390.f_2780.f_29[2] = 5;
			}
			else {
				StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
				StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
				StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
				StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
				Global_1835390.f_2710[0] = 2;
				Global_1835390.f_2710[1] = 1;
				Global_1835390.f_2710[2] = 3;
				Global_1835390.f_2710[3] = 0;
				Global_1835390.f_2709 = 4;
				Global_1835390.f_2708 = 3;
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
				gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
				Global_1835390.f_2780.f_28 = 5;
				Global_1835390.f_2780.f_29[0] = 1;
				Global_1835390.f_2780.f_29[1] = 1;
				Global_1835390.f_2780.f_29[2] = 3;
				Global_1835390.f_2780.f_29[3] = 5;
			}
			Global_1835390.f_2779 = 0;
		}
		break;

	case 1:
		if (iParam4 == 0) {
			uParam0->f_44 = 762;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_DM", 32);
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_DM_NN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
			StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
			StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 6;
			Global_1835390.f_2710[3] = 3;
			Global_1835390.f_2710[4] = 1;
			Global_1835390.f_2710[5] = 2;
			Global_1835390.f_2708 = 6;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 4;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 4;
			Global_1835390.f_2780.f_29[4] = 5;
			Global_1835390.f_2780.f_29[5] = 5;
		}
		else if (iParam4 == 1) {
			uParam0->f_44 = 822;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_TDM", 32);
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_TDM_NN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
			StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
			StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 6;
			Global_1835390.f_2710[3] = 3;
			Global_1835390.f_2710[4] = 1;
			Global_1835390.f_2710[5] = 2;
			Global_1835390.f_2708 = 6;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 4;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 4;
			Global_1835390.f_2780.f_29[4] = 5;
			Global_1835390.f_2780.f_29[5] = 5;
		}
		else if (iParam4 == 2) {
			uParam0->f_44 = 823;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_VEHDM", 32);
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_VEHDM_NN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_KD", 24);
			StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
			StringCopy(&Global_1835390.f_2717[5 /*6*/], "SCLB_C_DEATH", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 6;
			Global_1835390.f_2710[3] = 3;
			Global_1835390.f_2710[4] = 1;
			Global_1835390.f_2710[5] = 2;
			Global_1835390.f_2708 = 6;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 4;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 4;
			Global_1835390.f_2780.f_29[4] = 5;
			Global_1835390.f_2780.f_29[5] = 5;
		}
		break;

	case 11:
		uParam0->f_44 = 193;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_GOLF", 32);
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_GOLF0", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_GOLF1", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_GAMES", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 1;
		Global_1835390.f_2710[2] = 3;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 3;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 7;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 94:
		uParam0->f_44 = 193;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_GOLF", 32);
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_GOLF0", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_GOLF1", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_GAMES", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 1;
		Global_1835390.f_2710[2] = 3;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 3;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 7;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 92:
		uParam0->f_44 = 811;
		uParam0->f_44.f_1 = 1;
		uParam0->f_44.f_3 = 0;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_HUNTING", 32);
		StringCopy(&Global_1835390.f_2780.f_9, "CMSW", 64);
		Global_1835390.f_2780.f_25 = 0;
		Global_1835390.f_2780 = 0;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_HSCORE", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIMEHUNT", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_EKILLS", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_PHOTOS", 24);
		StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MONEY", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 5;
		Global_1835390.f_2710[2] = 2;
		Global_1835390.f_2710[3] = 4;
		Global_1835390.f_2710[4] = 6;
		Global_1835390.f_2708 = 5;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
		Global_1835390.f_2780.f_28 = 6;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 6;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		Global_1835390.f_2780.f_29[4] = 5;
		break;

	case 15:
		uParam0->f_44 = 749;
		uParam0->f_44.f_1 = 1;
		uParam0->f_44.f_3 = 0;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_ARM", 32);
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_WLRAT", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
		Global_1835390.f_2710[0] = 2;
		Global_1835390.f_2710[1] = 5;
		Global_1835390.f_2710[2] = 0;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 3;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 4;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 14:
		uParam0->f_44 = 190;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		if (iParam4 == -1) {
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
		}
		else {
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		}
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_DARTS", 32);
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WINS", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_LOSES", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 7;
		Global_1835390.f_2710[2] = 5;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 3;
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 4;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 12:
		uParam0->f_44 = 283;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "MP", 32);
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TENNIS", 32);
		StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		if (gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_TENNIS", 64);
			StringIntConCat(&Global_1835390.f_2780.f_9, iParam4 + 1, 64);
		}
		Global_1835390.f_2780.f_25 = 0;
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TEN1", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TEN2", 24);
		StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_TEN0", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 9;
		Global_1835390.f_2710[2] = 7;
		Global_1835390.f_2710[3] = 5;
		Global_1835390.f_2710[4] = 2;
		Global_1835390.f_2708 = 5;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		Global_1835390.f_2780.f_29[4] = 5;
		break;

	case 87:
		uParam0->f_44 = 283;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TENNIS", 32);
		StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		Global_1835390.f_2780.f_25 = 0;
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WINS", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_LOSES", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TEN1", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TEN2", 24);
		StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_TEN0", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 9;
		Global_1835390.f_2710[2] = 7;
		Global_1835390.f_2710[3] = 5;
		Global_1835390.f_2710[4] = 2;
		Global_1835390.f_2708 = 5;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		Global_1835390.f_2780.f_29[4] = 5;
		break;

	case 13:
		uParam0->f_44 = 912;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 2;
		switch (iParam4) {
		case 0:
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "RANDOM", 32);
			StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEa", 32);
			break;

		case 1:
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "GRID", 32);
			StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEb", 32);
			break;

		case 2:
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "COVERED", 32);
			StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEc", 32);
			break;

		default:
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "RANDOM", 32);
			StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGEa", 32);
			break;
		}
		switch (iParam5) {
		case 0:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Pistols", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_PISTOL", 64);
			break;

		case 1:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "SMGs", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_SMG", 64);
			break;

		case 2:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "AssaultRifles", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_ASSAULT", 64);
			break;

		case 3:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Shotguns", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_SHOTGUN", 64);
			break;

		case 4:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "LMGs", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_LMG", 64);
			break;

		case 5:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Heavies", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_HEAVY", 64);
			break;

		default:
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "WeaponId", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "Pistols", 32);
			StringCopy(&Global_1835390.f_2780.f_9, "HUD_MG_PISTOL", 64);
			break;
		}
		Global_1835390.f_2780.f_25 = 0;
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_WLRAT", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_HITS", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_SHOTS", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_ACC", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 2;
		Global_1835390.f_2710[2] = 1;
		Global_1835390.f_2710[3] = 3;
		Global_1835390.f_2708 = 4;
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		Global_1835390.f_2780.f_28 = 4;
		Global_1835390.f_2780.f_29[0] = 4;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 4;
		break;

	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 206:
	case 207:
	case 208:
	case 209:
		uParam0->f_44 = 203;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Type", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_RANGE", 32);
		MemCopy(&Global_1835390.f_2780.f_9, {func_215(iParam1)}, 16);
		Global_1835390.f_2780.f_25 = 0;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WEAP", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 7;
		Global_1835390.f_2708 = 2;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		Global_1835390.f_2780.f_28 = 4;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 8;
		break;

	case 69:
	case 71:
	case 70:
		uParam0->f_44 = 202;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2780.f_1, "HUD_MG_TRI", 32);
		StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		Global_1835390.f_2780.f_25 = 0;
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_RANK", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 0;
		Global_1835390.f_2710[2] = 0;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 1;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		Global_1835390.f_2780.f_28 = 3;
		Global_1835390.f_2780.f_29[0] = 2;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 0;
		Global_1835390.f_2780.f_29[3] = 0;
		break;

	case 80:
		uParam0->f_44 = 817;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 3;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var0};
		StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "OffroadRace", 32);
		Global_1835390.f_2780.f_25 = 0;
		Global_1835390.f_2780 = 1;
		StringCopy(&Global_1835390.f_2780.f_1, "OFFR_TITLE", 32);
		StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
		Global_1835390.f_2710[0] = 3;
		Global_1835390.f_2708 = 1;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		Global_1835390.f_2780.f_28 = 3;
		Global_1835390.f_2780.f_29[0] = 1;
		break;

	case 3:
		uParam0->f_44 = 791;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HRD", 32);
			StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HRD_NN", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_WAVE", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_TKILLS", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_TDEATH", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 1;
		Global_1835390.f_2710[2] = 2;
		Global_1835390.f_2710[3] = 3;
		Global_1835390.f_2708 = 4;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 0:
		if (iParam4 == 7 || iParam4 == 1) {
			uParam0->f_44 = 1200;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				if (iParam4 == 1) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEIST", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEISTP", 32);
				}
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else if (iParam4 == 1) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEIST_NN", 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_HEISTPNN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_ACC", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_HEADSHOT", 24);
			StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_KILLS", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 1;
			Global_1835390.f_2710[2] = 4;
			Global_1835390.f_2710[3] = 5;
			Global_1835390.f_2710[4] = 6;
			Global_1835390.f_2708 = 3;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
			Global_1835390.f_2780.f_28 = 6;
			Global_1835390.f_2780.f_29[0] = 5;
			Global_1835390.f_2780.f_29[1] = 11;
			Global_1835390.f_2780.f_29[2] = 4;
			Global_1835390.f_2780.f_29[3] = 5;
			Global_1835390.f_2780.f_29[4] = 5;
		}
		else if (Global_1633501.f_50 == 1) {
			uParam0->f_44 = 777;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				if (Global_1633501.f_2 == 5) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS", 32);
				}
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else if (Global_1633501.f_2 == 5) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS_NN", 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_KILLS", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_DEATH", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 1;
			Global_1835390.f_2710[2] = 2;
			Global_1835390.f_2710[3] = 0;
			Global_1835390.f_2708 = 3;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 2;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
		}
		else {
			uParam0->f_44 = 780;
			uParam0->f_44.f_1 = 5;
			uParam0->f_44.f_3 = 1;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
			uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				if (Global_1633501.f_2 == 5) {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS", 32);
				}
				else {
					StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS", 32);
				}
				StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
			}
			else if (Global_1633501.f_2 == 5) {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_LTS_NN", 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_KILLS", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_DEATH", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 1;
			Global_1835390.f_2710[2] = 2;
			Global_1835390.f_2710[3] = 0;
			Global_1835390.f_2708 = 3;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 5;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
		}
		break;

	case 8:
		uParam0->f_44 = 795;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Mission", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ", 32);
			StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ_NN", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_JUMPS", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_RANK", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 1;
		gameplay::set_bit(&Global_1835390.f_2768, 1);
		Global_1835390.f_2754[1] = -1;
		Global_1835390.f_2710[2] = 2;
		Global_1835390.f_2710[3] = 0;
		Global_1835390.f_2708 = 3;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		Global_1835390.f_2780.f_28 = 5;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 11;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 85:
		uParam0->f_44 = 274;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		Global_1835390.f_2780.f_25 = 0;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ", 32);
			StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_BJ_NN", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_CASH", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_TOTCASH", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 3;
		Global_1835390.f_2708 = 2;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		Global_1835390.f_2780.f_28 = 3;
		Global_1835390.f_2780.f_29[0] = 5;
		Global_1835390.f_2780.f_29[1] = 5;
		break;

	case 122:
		switch (iParam4) {
		case 0:
		case 9:
		case 4:
		case 8:
			switch (iParam4) {
			case 0: uParam0->f_44 = 965; break;

			case 9: uParam0->f_44 = 966; break;

			case 4: uParam0->f_44 = 967; break;

			case 8: uParam0->f_44 = 968; break;
			}
			uParam0->f_44.f_1 = 1;
			uParam0->f_44.f_3 = 0;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
			Global_1835390.f_2710[0] = 1;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 3;
			Global_1835390.f_2710[3] = 2;
			Global_1835390.f_2708 = 4;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			Global_1835390.f_2780.f_29[0] = 1;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
			break;

		case 1:
		case 2:
		case 3:
			switch (iParam4) {
			case 1: uParam0->f_44 = 969; break;

			case 2: uParam0->f_44 = 970; break;

			case 3: uParam0->f_44 = 973; break;
			}
			uParam0->f_44.f_1 = 1;
			uParam0->f_44.f_3 = 0;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_DIST", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
			Global_1835390.f_2710[0] = 1;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 3;
			Global_1835390.f_2710[3] = 2;
			Global_1835390.f_2708 = 4;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			Global_1835390.f_2780.f_29[0] = 4;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
			break;

		case 7:
			uParam0->f_44 = 971;
			uParam0->f_44.f_1 = 1;
			uParam0->f_44.f_3 = 0;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_AVG_HEI", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
			Global_1835390.f_2710[0] = 1;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 3;
			Global_1835390.f_2710[3] = 2;
			Global_1835390.f_2708 = 4;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			Global_1835390.f_2780.f_29[0] = 4;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
			break;

		case 6:
		case 5:
			switch (iParam4) {
			case 6: uParam0->f_44 = 972; break;

			case 5: uParam0->f_44 = 974; break;
			}
			uParam0->f_44.f_1 = 1;
			uParam0->f_44.f_3 = 0;
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "", 32);
			Global_1835390.f_2780 = 1;
			if (!gameplay::is_string_null_or_empty(sParam3)) {
				StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
			}
			else {
				StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
			}
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
			Global_1835390.f_2710[0] = 0;
			Global_1835390.f_2710[1] = 3;
			Global_1835390.f_2710[2] = 2;
			Global_1835390.f_2710[3] = 1;
			Global_1835390.f_2708 = 4;
			gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
			Global_1835390.f_2780.f_29[0] = 12;
			Global_1835390.f_2780.f_29[1] = 5;
			Global_1835390.f_2780.f_29[2] = 5;
			Global_1835390.f_2780.f_29[3] = 5;
			break;
		}
		break;

	case 83:
		uParam0->f_44 = 192;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_DIST", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
		Global_1835390.f_2710[0] = 2;
		Global_1835390.f_2710[1] = 5;
		Global_1835390.f_2710[2] = 4;
		Global_1835390.f_2710[3] = 3;
		Global_1835390.f_2708 = 4;
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		Global_1835390.f_2780.f_29[0] = 17;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 82:
		uParam0->f_44 = 850;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		Global_1835390.f_2780.f_25 = 0;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_MEDAL1", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_MEDAL2", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL3", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 4;
		Global_1835390.f_2710[2] = 3;
		Global_1835390.f_2710[3] = 2;
		Global_1835390.f_2708 = 4;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		Global_1835390.f_2780.f_29[0] = 10;
		Global_1835390.f_2780.f_29[1] = 5;
		Global_1835390.f_2780.f_29[2] = 5;
		Global_1835390.f_2780.f_29[3] = 5;
		break;

	case 84:
		uParam0->f_44 = 820;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 1;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[0 /*16*/].f_8 = {Var0};
		Global_1835390.f_2780 = 1;
		Global_1835390.f_2780.f_25 = 0;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, "PS_TITLE", 32);
			StringCopy(&Global_1835390.f_2780.f_9, sParam3, 64);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SCLB_MIS_NN", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_SCORE", 24);
		StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_TIME", 24);
		StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_ACC", 24);
		StringCopy(&Global_1835390.f_2717[3 /*6*/], "SCLB_C_MEDAL1", 24);
		StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MEDAL2", 24);
		StringCopy(&Global_1835390.f_2717[4 /*6*/], "SCLB_C_MEDAL3", 24);
		Global_1835390.f_2710[0] = 0;
		Global_1835390.f_2710[1] = 1;
		Global_1835390.f_2710[2] = 2;
		Global_1835390.f_2710[3] = 5;
		Global_1835390.f_2710[4] = 4;
		Global_1835390.f_2710[5] = 3;
		Global_1835390.f_2708 = 6;
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
		gameplay::clear_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[3]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[4]);
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[5]);
		Global_1835390.f_2780.f_29[0] = 4;
		Global_1835390.f_2780.f_29[1] = 9;
		Global_1835390.f_2780.f_29[2] = 4;
		Global_1835390.f_2780.f_29[3] = 5;
		Global_1835390.f_2780.f_29[4] = 5;
		Global_1835390.f_2780.f_29[5] = 5;
		break;

	case 86:
		uParam0->f_44 = 817;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 3;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
		uParam0->f_44.f_3.f_1[1 /*16*/].f_8 = {Var0};
		StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StuntPlaneRace", 32);
		Global_1835390.f_2780 = 1;
		Global_1835390.f_2780.f_25 = 0;
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			StringCopy(&Global_1835390.f_2780.f_1, sParam3, 32);
		}
		else {
			StringCopy(&Global_1835390.f_2780.f_1, "SPR_TITLE", 32);
		}
		StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_TIME", 24);
		Global_1835390.f_2710[0] = 2;
		Global_1835390.f_2708 = 1;
		gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
		Global_1835390.f_2780.f_28 = 3;
		Global_1835390.f_2780.f_29[0] = 1;
		break;

	case 91:
		uParam0->f_44 = 817;
		uParam0->f_44.f_1 = 5;
		uParam0->f_44.f_3 = 3;
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/], "GameType", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/], "Location", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/], "Type", 32);
		StringCopy(&uParam0->f_44.f_3.f_1[0 /*16*/].f_8, "SP", 32);
		Global_1835390.f_2780 = 1;
		if (iParam5 <= 0) {
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_VEH", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
			Global_1835390.f_2710[0] = 3;
			Global_1835390.f_2710[1] = 4;
			Global_1835390.f_2710[2] = 1;
			Global_1835390.f_2710[3] = 0;
			Global_1835390.f_2709 = 6;
			Global_1835390.f_2708 = 2;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			Global_1835390.f_2780.f_28 = 4;
			Global_1835390.f_2780.f_29[0] = 1;
			Global_1835390.f_2780.f_29[1] = 3;
		}
		else {
			StringCopy(&Global_1835390.f_2717[0 /*6*/], "SCLB_C_RT", 24);
			StringCopy(&Global_1835390.f_2717[1 /*6*/], "SCLB_C_BL", 24);
			StringCopy(&Global_1835390.f_2717[2 /*6*/], "SCLB_C_VEH", 24);
			StringCopy(&Global_1835390.f_2717[3 /*6*/], "", 24);
			Global_1835390.f_2710[0] = 3;
			Global_1835390.f_2710[1] = 2;
			Global_1835390.f_2710[2] = 4;
			Global_1835390.f_2710[3] = 1;
			Global_1835390.f_2709 = 4;
			Global_1835390.f_2708 = 3;
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[0]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[1]);
			gameplay::set_bit(&Global_1835390.f_2769, Global_1835390.f_2710[2]);
			Global_1835390.f_2780.f_28 = 5;
			Global_1835390.f_2780.f_29[0] = 1;
			Global_1835390.f_2780.f_29[1] = 1;
			Global_1835390.f_2780.f_29[2] = 3;
		}
		Global_1835390.f_2779 = 0;
		switch (iParam4) {
		case 0:
			StringCopy(&Global_1835390.f_2780.f_1, "MGCR_1", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_1", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
			break;

		case 1:
			StringCopy(&Global_1835390.f_2780.f_1, "MGCR_2", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_2", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
			break;

		case 2:
			StringCopy(&Global_1835390.f_2780.f_1, "MGCR_4", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_4", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
			break;

		case 3:
			StringCopy(&Global_1835390.f_2780.f_1, "MGCR_5", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_5", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
			break;

		case 4:
			StringCopy(&Global_1835390.f_2780.f_1, "MGCR_6", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGCR_6", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "StreetRace", 32);
			break;

		case 5:
			StringCopy(&Global_1835390.f_2780.f_1, "MGSR_1", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_1", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
			break;

		case 6:
			StringCopy(&Global_1835390.f_2780.f_1, "MGSR_2", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_2", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
			break;

		case 7:
			StringCopy(&Global_1835390.f_2780.f_1, "MGSR_3", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_3", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
			break;

		case 8:
			StringCopy(&Global_1835390.f_2780.f_1, "MGSR_4", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[1 /*16*/].f_8, "MGSR_4", 32);
			StringCopy(&uParam0->f_44.f_3.f_1[2 /*16*/].f_8, "SeaRace", 32);
			break;

		default: break;
		}
		break;
	}
	iVar16 = 0;
	iVar16 = 0;
	while (iVar16 < Global_1835390.f_2708) {
		if (gameplay::is_bit_set(Global_1835390.f_2769, Global_1835390.f_2710[iVar16])) {
			gameplay::set_bit(&Global_1835390.f_2770, iVar16);
		}
		iVar16++;
	}
	Global_1835390.f_2826 = func_214(Var0, uParam0->f_44, iParam1, iParam4, iParam5, iParam6);
}

// Position - 0x13975
var func_214(struct<8> Param0, int iParam8, int iParam9, int iParam10, int iParam11, bool bParam12) {
	char cVar0[64];

	MemCopy(&cVar0, {Param0}, 16);
	StringIntConCat(&cVar0, iParam8, 64);
	StringConCat(&cVar0, "_", 64);
	if (func_179(iParam8)) {
		if (bParam12) {
			StringConCat(&cVar0, "CoDri", 64);
		}
		else {
			StringConCat(&cVar0, "Dri", 64);
		}
		StringConCat(&cVar0, "_", 64);
	}
	StringIntConCat(&cVar0, iParam9, 64);
	StringConCat(&cVar0, "_", 64);
	StringIntConCat(&cVar0, iParam10, 64);
	StringConCat(&cVar0, "_", 64);
	StringIntConCat(&cVar0, iParam11, 64);
	return gameplay::get_hash_key(&cVar0);
}

// Position - 0x139E7
struct<6> func_215(int iParam0) {
	struct<6> Var0;

	switch (iParam0) {
	case 38: StringCopy(&Var0, "HUD_MG_RANGE0", 24); break;

	case 39: StringCopy(&Var0, "HUD_MG_RANGE1", 24); break;

	case 40: StringCopy(&Var0, "HUD_MG_RANGE2", 24); break;

	case 41: StringCopy(&Var0, "HUD_MG_RANGE3", 24); break;

	case 42: StringCopy(&Var0, "HUD_MG_RANGE4", 24); break;

	case 43: StringCopy(&Var0, "HUD_MG_RANGE5", 24); break;

	case 44: StringCopy(&Var0, "HUD_MG_RANGE6", 24); break;

	case 45: StringCopy(&Var0, "HUD_MG_RANGE7", 24); break;

	case 46: StringCopy(&Var0, "HUD_MG_RANGE8", 24); break;

	case 47: StringCopy(&Var0, "HUD_MG_RANGE9", 24); break;

	case 48: StringCopy(&Var0, "HUD_MG_RANGE10", 24); break;

	case 49: StringCopy(&Var0, "HUD_MG_RANGE11", 24); break;

	case 50: StringCopy(&Var0, "HUD_MG_RANGE12", 24); break;

	case 51: StringCopy(&Var0, "HUD_MG_RANGE13", 24); break;

	case 52: StringCopy(&Var0, "HUD_MG_RANGE14", 24); break;

	case 53: StringCopy(&Var0, "HUD_MG_RANGE15", 24); break;

	case 54: StringCopy(&Var0, "HUD_MG_RANGE16", 24); break;

	case 55: StringCopy(&Var0, "HUD_MG_RANGE17", 24); break;

	case 206: StringCopy(&Var0, "HUD_MG_RANGE18", 24); break;

	case 207: StringCopy(&Var0, "HUD_MG_RANGE19", 24); break;

	case 208: StringCopy(&Var0, "HUD_MG_RANGE20", 24); break;

	case 209: StringCopy(&Var0, "HUD_MG_RANGE21", 24); break;
	}
	return Var0;
}

//Position - 0x13B70
int func_216()
{
	if (Global_1633501.f_41912 == 1 || Global_1633501.f_41912 == 3 || Global_1633501.f_41912 == 5 ||
		Global_1633501.f_41912 == 7 || Global_1633501.f_41912 == 8 || Global_1633501.f_41912 == 9 ||
		Global_1633501.f_41912 == 11 || Global_1633501.f_41912 == 13) {
		return 1;
	}
	return 0;
}

// Position - 0x13C0E
int func_217(var *uParam0, int iParam1) {
	if (!func_401(&uParam0->f_2)) {
		func_415(&uParam0->f_2);
	}
	ui::hide_hud_component_this_frame(14);
	graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
	if (iParam1 || uParam0->f_8) {
		if (controls::is_control_just_pressed(2, 201) || uParam0->f_8) {
			if (!func_401(&uParam0->f_5)) {
				func_415(&uParam0->f_5);
				func_218(uParam0, 1051260355);
			}
		}
		if (func_401(&uParam0->f_5)) {
			if (func_7(&uParam0->f_5) > 0.33f) {
				func_402(&uParam0->f_5);
				return 0;
			}
		}
	}
	if (uParam0->f_1 == -1) {
		return 1;
	}
	if (func_7(&uParam0->f_2) * 1000f > system::to_float(uParam0->f_1)) {
		if (!func_401(&uParam0->f_5)) {
			func_415(&uParam0->f_5);
			func_218(uParam0, 1051260355);
		}
		else if (func_7(&uParam0->f_5) > 0.33f) {
			func_402(&uParam0->f_2);
			return 0;
		}
	}
	return 1;
}

// Position - 0x13D11
void func_218(var *uParam0, float fParam1) {
	graphics::_push_scaleform_movie_function(*uParam0, "SHARD_ANIM_OUT");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_9);
	graphics::_push_scaleform_movie_function_parameter_float(fParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x13D37
void func_219(var *uParam0) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 40) {
		if (!ped::is_ped_injured((*uParam0)[1])) {
			func_4((*uParam0)[1], "DARTS_LOSE", 0, 4);
		}
	}
	else if (iVar0 < 70) {
		if (!ped::is_ped_injured((*uParam0)[0])) {
			func_4((*uParam0)[0], "GAME_LOSE_SELF", 1, 4);
		}
	}
	else if (!ped::is_ped_injured((*uParam0)[1])) {
		func_4((*uParam0)[1], "GAME_WIN_SELF", 0, 4);
	}
}

// Position - 0x13DB0
void func_220(var *uParam0, int iParam1) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 30) {
		if (!ped::is_ped_injured((*uParam0)[0])) {
			func_4((*uParam0)[0], "DARTS_LOSE", 1, 4);
		}
	}
	else if (iVar0 < 50) {
		if (!ped::is_ped_injured((*uParam0)[1])) {
			func_4((*uParam0)[1], "DARTS_WIN", 0, 4);
		}
	}
	else if (iVar0 < 75 && iParam1) {
		if (!ped::is_ped_injured((*uParam0)[1])) {
			func_4((*uParam0)[1], "DARTS_LOSING_BADLY", 0, 4);
		}
	}
	else if (iVar0 < 88) {
		if (!ped::is_ped_injured((*uParam0)[0])) {
			func_4((*uParam0)[0], "GAME_WIN_SELF", 1, 4);
		}
	}
	else if (!ped::is_ped_injured((*uParam0)[1])) {
		func_4((*uParam0)[1], "GAME_LOSE_SELF", 0, 4);
	}
}

// Position - 0x13E7D
int func_221() {
	int iVar0;

	if (!iLocal_315) {
		iVar0 = gameplay::get_random_int_in_range(0, 65535) % 3;
	}
	else {
		iLocal_329++;
		iVar0 = iLocal_329 % 2;
	}
	return iVar0;
}

// Position - 0x13EAD
void func_222(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	char *sVar0;

	sVar0 = func_223(iParam4);
	if (iParam4 != 5) {
		graphics::_push_scaleform_movie_function(*uParam0, "RESET_MOVIE");
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(*uParam0, sVar0);
	graphics::begin_text_command_scaleform_string("STRING");
	ui::add_text_component_substring_text_label(sParam1);
	graphics::end_text_command_scaleform_string();
	func_12(sParam2);
	graphics::_pop_scaleform_movie_function_void();
	func_415(&uParam0->f_2);
	uParam0->f_1 = iParam3;
	uParam0->f_9 = iParam5;
}

// Position - 0x13F0D
char *func_223(int iParam0) {
	switch (iParam0) {
	case 0: return "SHOW_SHARD_CENTERED_MP_MESSAGE";

	case 1: return "SHOW_SHARD_CENTERED_TOP_MP_MESSAGE";

	case 2: return "SHOW_SHARD_WASTED_MP_MESSAGE";

	case 3: return "SHOW_SHARD_RANKUP_MP_MESSAGE";

	case 4: return "SHOW_SHARD_CREW_RANKUP_MP_MESSAGE";

	case 5: return "SHOW_SHARD_MIDSIZED_MESSAGE";

	default:
	}
	return "SHOW_SHARD_CENTERED_MP_MESSAGE";
}

// Position - 0x13F6E
void func_224(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(*uParam0, "CLEAR_SCORES");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x13F8C
int func_225(int *iParam0) {
	iParam0->f_2 = {0f, -2.3685f, -0.2f};
	iParam0->f_5 = {0f, 0f, 0f};
	iParam0->f_8 = {0f, 0f, 0f};
	iParam0->f_20 = 0;
	iParam0->f_23 = 0;
	iParam0->f_24 = 0;
	iParam0->f_25 = 0;
	if (entity::does_entity_exist(*iParam0)) {
		object::delete_object(iParam0);
	}
	return 1;
}

// Position - 0x13FDC
void func_226(int iParam0) {
	cam::set_cam_active_with_interp(iLocal_122, iLocal_120, 1500, 1, 1);
	cam::set_cam_active(iLocal_123, 1);
	cam::set_cam_active_with_interp(iLocal_122, iLocal_123, 8000, 1, 1);
	cam::attach_cam_to_entity(iLocal_125, iParam0, -0.0301f, 1.498f, 0.7435f, 1);
	cam::point_cam_at_entity(iLocal_125, iParam0, 0.0557f, -1.4905f, 0.4958f, 1);
	cam::set_cam_fov(iLocal_125, 35f);
}

// Position - 0x14042
void func_227(var *uParam0, var *uParam1, var *uParam2, var *uParam3, int *iParam4) {
	int iVar0;

	if (!cam::is_cam_interpolating(iLocal_120)) {
		iVar0 = 0;
		func_308(uParam0);
		if (!iLocal_307) {
			if (uParam0->f_1 == 5) {
				if (uParam3->f_672) {
					ui::clear_help(1);
					uParam3->f_672 = 0;
				}
			}
			else if (!bLocal_163) {
				if (func_3(&uParam3->f_666, 18)) {
					if (!func_3(&uParam3->f_666, 21)) {
						if (!gameplay::is_bit_set(Global_101661, 3)) {
							func_399("DARTS_INSTR_W", -1);
							gameplay::set_bit(&Global_101661, 3);
						}
						func_312(&uParam3->f_666, 21, 1);
					}
					else if (!func_3(&uParam3->f_666, 20) && func_3(&uParam3->f_666, 19)) {
						if (!gameplay::is_bit_set(Global_101661, 4)) {
							func_399("DARTS_INSTR_B", -1);
							gameplay::set_bit(&Global_101661, 4);
						}
						func_312(&uParam3->f_666, 20, 1);
					}
				}
				uParam3->f_672 = 1;
			}
			else if (uParam3->f_672) {
				ui::clear_help(1);
				uParam3->f_672 = 0;
			}
		}
		if (uParam0->f_1 == 1) {
			if (!cam::is_cam_interpolating(iLocal_129) && uParam0->f_3 == 2) {
				func_307(uParam3);
			}
		}
		else {
			func_305(uParam3, iLocal_30);
		}
		func_304(&uParam0->f_1);
	}
	else {
		iVar0 = 1;
	}
	func_301(uParam3);
	switch (uParam0->f_1) {
	case 1:
		if (!func_293(&uParam0->f_3)) {
			uParam0->f_1 = 2;
		}
		break;

	case 0:
		if (func_286(uParam0->f_422[iLocal_30], &uParam0->f_243, &uParam0->f_4, &uParam0->f_461)) {
			uParam0->f_1 = 2;
		}
		break;

	case 2:
		if (controls::is_control_pressed(2, 228) && iLocal_30 == 0) {
			uParam0->f_1 = 1;
		}
		if (iLocal_30 == 0) {
			func_285(iLocal_31, 0);
			if (!func_284("DARTS_SHT_USE") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B") &&
				!func_284("DARTS_AIM_HLP") && !func_284("DARTS_STD_HLP") && !func_284("DARTS_FST_HLP")) {
				if (func_3(&uParam3->f_666, 24)) {
					func_399("DARTS_LEVEL", -1);
					gameplay::set_bit(&Global_101700.f_17929.f_6, iLocal_327);
					func_312(&uParam3->f_666, 24, 0);
				}
			}
			if (uParam0->f_422[iLocal_30] % 2 == 0 && uParam0->f_422[iLocal_30] < 41 && iLocal_31 == 0 && !iLocal_305) {
				if (!func_3(&uParam3->f_666, 6)) {
					func_312(&uParam3->f_666, 6, 1);
				}
				iLocal_305 = 1;
			}
			else if (uParam0->f_422[iLocal_30] == 50 && !iLocal_305) {
				if (!func_3(&uParam3->f_666, 6)) {
					func_312(&uParam3->f_666, 6, 1);
				}
				iLocal_305 = 1;
			}
			else if (func_274(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, uParam1, iVar0, 0, 0,
							  uParam0->f_248)) {
				ui::clear_prints();
				uParam3->f_670--;
				uParam0->f_1 = 3;
			}
			else if (!iLocal_302) {
				if (!func_401(iParam4)) {
					func_272(iParam4);
				}
				else if (func_7(iParam4) > 20f) {
					func_271(uLocal_296[1 - iLocal_30]);
					func_402(iParam4);
					iLocal_302 = 1;
				}
			}
		}
		else if (iLocal_31 == 0) {
			iLocal_325 = 0;
			func_270(&uParam0->f_422, &uParam0->f_249);
			func_267(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, &uParam0->f_1, &uParam0->f_249,
					 0);
		}
		else if (system::timera() > gameplay::get_random_int_in_range(1250, 2500)) {
			func_270(&uParam0->f_422, &uParam0->f_249);
			func_267(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, &uParam0->f_1, &uParam0->f_249,
					 0);
		}
		break;

	case 3:
		if (func_254(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, uParam0->f_248, 0)) {
			uParam0->f_436++;
			uParam0->f_455 = func_253(uParam0);
			uParam0->f_1 = 4;
		}
		break;

	case 4:
		if (!func_3(&uParam3->f_666, 5)) {
			func_251(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, uParam0->f_455);
		}
		func_236(uParam0, uParam3);
		break;

	case 5:
		func_229(uParam0, uParam2, uParam3);
		if (func_401(iParam4)) {
			func_402(iParam4);
		}
		break;

	case 6: func_228(uParam0, uParam3); break;
	}
}

// Position - 0x144A2
void func_228(var *uParam0, var *uParam1) {
	vector3 vVar0;
	var uVar3;
	int iVar4;
	var uVar5;

	iLocal_325++;
	iLocal_30 = 1;
	iLocal_31 = 0;
	iLocal_309 = 1;
	while (iLocal_31 < 3 && uParam0->f_1 == 6) {
		if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_23) {
			if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_25) {
				iLocal_31++;
			}
			else {
				func_251(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, 0);
				func_236(uParam0, uParam1);
			}
		}
		else if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_24) {
			if (bLocal_308) {
				if (entity::does_entity_exist(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/])) {
					object::delete_object(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/]);
				}
			}
			else {
				uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_23 = 1;
				uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_24 = 0;
				vVar0 = {object::_get_object_offset_from_coords(
					uParam0->f_243.f_1, uParam0->f_243.f_4, uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11,
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11.f_1 + fLocal_55,
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11.f_2)};
				if (entity::does_entity_exist(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/])) {
					entity::set_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], vVar0, 1, 0, 0, 1);
				}
			}
			func_251(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, 0);
			func_236(uParam0, uParam1);
			if (bLocal_308) {
				if (iLocal_310) {
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/] =
						object::create_object(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_1, vLocal_79, 1, 1, 0);
					vVar0 = {object::_get_object_offset_from_coords(
						uParam0->f_243.f_1, uParam0->f_243.f_4, uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11,
						uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11.f_1 + fLocal_55,
						uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_11.f_2)};
					entity::set_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], vVar0, 1, 0, 0, 1);
					uVar3 = gameplay::get_random_float_in_range(0f, 90f);
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_17 = {90f, uVar3, uParam0->f_243.f_4};
					entity::set_entity_rotation(uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/],
												uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_17, 0, 1);
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_23 = 1;
					uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_24 = 0;
				}
			}
		}
		else {
			func_270(&uParam0->f_422, &uParam0->f_249);
			func_267(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, &uParam0->f_1, &uParam0->f_249,
					 0);
			uParam0->f_436++;
			func_251(&uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/], &uParam0->f_243, 0);
			if ((uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_21 == 2 ||
				 uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 50) &&
				uParam0->f_422[iLocal_30] == 0) {
				if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 50) {
					uParam0->f_432[iLocal_30]++;
				}
				func_312(&uParam1->f_666, 2, 0);
				func_312(&uParam1->f_666, 3, 0);
				func_312(&uParam1->f_666, 4, 0);
				func_312(&uParam1->f_666, 5, 1);
				system::settimerb(0);
			}
			func_236(uParam0, uParam1);
			if (bLocal_308) {
				if (iLocal_310) {
					iVar4 = 0;
					while (iVar4 < iLocal_31 + 1) {
						if (!uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_23) {
							uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/] = object::create_object(
								uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_1, vLocal_79, 1, 1, 0);
							vVar0 = {object::_get_object_offset_from_coords(
								uParam0->f_243.f_1, uParam0->f_243.f_4,
								uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_11,
								uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_11.f_1 + fLocal_55,
								uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_11.f_2)};
							if (entity::does_entity_exist(uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/])) {
								entity::set_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/], vVar0, 1, 0, 0,
														  1);
							}
							uVar5 = gameplay::get_random_float_in_range(0f, 90f);
							uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_17 = {90f, uVar5, uParam0->f_243.f_4};
							entity::set_entity_rotation(uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/],
														uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_17, 0, 1);
							uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_23 = 1;
							uParam0->f_5[iLocal_30 /*79*/][iVar4 /*26*/].f_24 = 0;
						}
						iVar4++;
					}
				}
			}
		}
	}
	uParam0->f_1 = 5;
	if (iLocal_325 > 2) {
		uParam0->f_1 = 5;
	}
}

// Position - 0x1492B
void func_229(var *uParam0, var *uParam1, var *uParam2) {
	vector3 vVar0;
	int iVar3;

	switch (uParam0->f_2) {
	case 0:
		if (uParam0->f_248 == 1) {
			func_235();
		}
		if (iLocal_30 == 0) {
			if (func_3(&uParam2->f_666, 3)) {
				func_234("DARTS_PLR_DUB", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
			}
			else if (func_3(&uParam2->f_666, 4)) {
				func_233("DARTS_ONE_PT", 5000, 0);
			}
			else if (func_3(&uParam2->f_666, 2)) {
				func_234("DARTS_PLR_BUST", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
			}
			else {
				func_234("DARTS_SWITCH_C", uParam0->f_422[iLocal_30], 5000, 0);
			}
		}
		else if (func_3(&uParam2->f_666, 3)) {
			func_234("DARTS_OPP_DUB", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
		}
		else if (func_3(&uParam2->f_666, 4)) {
			func_233("DARTS_ONE_PT", 5000, 0);
		}
		else if (func_3(&uParam2->f_666, 2)) {
			func_234("DARTS_OPP_BUST", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
		}
		else {
			func_234("DARTS_SWITCH_B", uParam0->f_422[iLocal_30], 5000, 0);
		}
		system::settimerb(0);
		uParam0->f_2 = 2;
		break;

	case 1:
		if (controls::is_control_just_pressed(2, 190)) {
			iLocal_323++;
			if (iLocal_323 >= uParam0->f_436) {
				iLocal_323 = 0;
			}
			vVar0 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
			func_48(vVar0);
		}
		if (controls::is_control_just_pressed(2, 189)) {
			iLocal_323--;
			if (iLocal_323 < 0) {
				iLocal_323 = uParam0->f_436 - 1;
			}
			vVar0 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
			func_48(vVar0);
		}
		if (controls::is_control_just_pressed(2, 202)) {
			vVar0 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
			func_50(vVar0, 0, 0);
			uParam0->f_2 = 2;
		}
		if (controls::is_control_just_pressed(2, 201)) {
			iLocal_299 = 1;
			uParam0->f_2 = 2;
		}
		break;

	case 2:
		if (controls::is_control_just_pressed(2, 201) || iLocal_309 && bLocal_308) {
			iLocal_299 = 1;
		}
		if ((controls::is_control_just_pressed(2, 189) || controls::is_control_just_pressed(2, 190)) &&
			uParam0->f_248 == 1) {
			vVar0 = {entity::get_entity_coords(uParam0->f_5[iLocal_30 /*79*/][iLocal_323 /*26*/], 1)};
			func_50(vVar0, 1, 0);
			uParam0->f_2 = 1;
		}
		if (!func_3(&uParam2->f_666, 6)) {
			if (!iLocal_304) {
				if (func_232(iLocal_30 == 0, &uLocal_296[1], uParam0->f_425[iLocal_30] - uParam0->f_422[iLocal_30],
							 uParam0->f_422[0], uParam0->f_422[1])) {
					iLocal_304 = 1;
				}
			}
			else if (gameplay::get_game_timer() % 500 < 50) {
			}
		}
		else if (!iLocal_304) {
			if (func_231(iLocal_30 == 0, &uLocal_296[1], uParam0->f_425[iLocal_30] - uParam0->f_422[iLocal_30],
						 uParam0->f_422[0], uParam0->f_422[1])) {
				iLocal_304 = 1;
			}
		}
		else if (gameplay::get_game_timer() % 500 < 50) {
		}
		if (iLocal_299 || system::timerb() > 2000) {
			iLocal_309 = 0;
			iVar3 = 0;
			while (iVar3 < 3) {
				func_225(&uParam0->f_5[iLocal_30 /*79*/][iVar3 /*26*/]);
				iVar3++;
			}
			if (uParam0->f_425[iLocal_30] != uParam0->f_422[iLocal_30]) {
				func_230(uParam1, iLocal_30, uParam0->f_422[iLocal_30]);
				audio::play_sound_from_coord(-1, "DARTS_SCOREBOARD_MASTER", uParam0->f_243.f_1, 0, 0, 0, 0);
			}
			uParam0->f_425[iLocal_30] = uParam0->f_422[iLocal_30];
			iLocal_31 = 0;
			uParam0->f_428 = 0;
			if (iLocal_30 == 0) {
				iLocal_30 = 1;
			}
			else {
				iLocal_30 = 0;
			}
			func_414(uParam1, iLocal_30);
			iLocal_99 = 0;
			func_394();
			if (!bLocal_308) {
				ui::clear_small_prints();
			}
			iLocal_93 = 0;
			uParam2->f_670 = 3;
			iLocal_305 = 0;
			iLocal_302 = 0;
			iLocal_304 = 0;
			iLocal_299 = 0;
			iLocal_323 = 0;
			uParam0->f_436 = 0;
			uParam0->f_1 = 2;
			uParam0->f_2 = 0;
		}
		break;
	}
}

// Position - 0x14D44
void func_230(var *uParam0, int iParam1, int iParam2) {
	graphics::_push_scaleform_movie_function(*uParam0, "ADD_DARTS_SCORE");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x14D68
bool func_231(bool bParam0, var *uParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (bParam0) {
		if (iParam2 > 30 && bParam0 || iParam3 < 20) {
			gameplay::set_bit(&iVar0, 0);
		}
		if (iParam2 <= 30 && bParam0 || iParam3 >= 20) {
			gameplay::set_bit(&iVar0, 2);
		}
	}
	else {
		if (iParam2 > 20 && !bParam0 || iParam4 < 30) {
			gameplay::set_bit(&iVar0, 1);
		}
		if (iParam2 <= 20 && !bParam0 || iParam4 >= 30) {
			gameplay::set_bit(&iVar0, 3);
		}
	}
	iVar1 = gameplay::get_random_int_in_range(0, 100);
	iVar2 = gameplay::get_random_int_in_range(0, 100);
	if (iVar2 < 85) {
		if (gameplay::is_bit_set(iVar0, 0)) {
			if (iVar1 < 50) {
				func_4(player::player_ped_id(), "GAME_GOOD_SELF", 1, 4);
			}
			else if (iVar1 < 75) {
				func_4(*uParam1, "DARTS_PLAYING_WELL", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_GOOD_OTHER", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 2)) {
			if (iVar1 < 50) {
				func_4(player::player_ped_id(), "GAME_BAD_SELF", 1, 4);
			}
			else if (iVar1 < 68) {
				func_4(*uParam1, "DARTS_PLAYING_POORLY", 0, 4);
			}
			else if (iVar1 < 86) {
				func_4(*uParam1, "GAME_BAD_OTHER", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_HECKLE", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 1)) {
			if (iVar1 < 50) {
				func_4(player::player_ped_id(), "GAME_GOOD_OTHER", 1, 4);
			}
			else if (iVar1 < 75) {
				func_4(*uParam1, "DARTS_HAPPY", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_GOOD_SELF", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 3)) {
			if (iVar1 < 50) {
				func_4(player::player_ped_id(), "GAME_BAD_OTHER", 1, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_BAD_SELF", 0, 4);
			}
			return true;
		}
	}
	return false;
}

// Position - 0x14F65
bool func_232(bool bParam0, var *uParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (bParam0) {
		if (iParam2 > 100 && bParam0 || iParam4 - iParam3 > 75) {
			gameplay::set_bit(&iVar0, 0);
		}
		if (iParam2 < 70 && bParam0 || iParam3 - iParam4 < 50) {
			gameplay::set_bit(&iVar0, 2);
		}
	}
	else {
		if (iParam2 > 75 && !bParam0 || iParam3 - iParam4 > 50) {
			gameplay::set_bit(&iVar0, 1);
		}
		if (iParam2 < 40 && !bParam0 || iParam4 - iParam3 < 30) {
			gameplay::set_bit(&iVar0, 3);
		}
	}
	iVar1 = gameplay::get_random_int_in_range(0, 100);
	iVar2 = gameplay::get_random_int_in_range(0, 100);
	if (iVar2 < 75) {
		if (gameplay::is_bit_set(iVar0, 0)) {
			if (iVar1 < 35) {
				func_4(player::player_ped_id(), "DARTS_HAPPY", 1, 4);
			}
			else if (iVar1 < 70) {
				func_4(*uParam1, "DARTS_PLAYING_WELL", 0, 4);
			}
			else if (iVar1 < 85) {
				func_4(player::player_ped_id(), "GAME_GOOD_SELF", 1, 4);
			}
			else {
				func_4(*uParam1, "GAME_GOOD_OTHER", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 2)) {
			if (iVar1 < 50) {
				func_4(player::player_ped_id(), "GAME_BAD_SELF", 1, 4);
			}
			else if (iVar1 < 68 && !entity::does_entity_exist(func_479())) {
				func_4(*uParam1, "DARTS_PLAYING_POORLY", 0, 4);
			}
			else if (iVar1 < 86) {
				func_4(*uParam1, "GAME_BAD_OTHER", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_HECKLE", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 1)) {
			if (iVar1 < 40) {
				func_4(player::player_ped_id(), "DARTS_PLAYING_WELL", 1, 4);
			}
			else if (iVar1 < 60) {
				func_4(player::player_ped_id(), "GAME_GOOD_OTHER", 1, 4);
			}
			else if (iVar1 < 80) {
				func_4(*uParam1, "DARTS_HAPPY", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(*uParam1, "GAME_GOOD_SELF", 0, 4);
			}
			return true;
		}
		else if (gameplay::is_bit_set(iVar0, 3)) {
			if (iVar1 < 33) {
				func_4(player::player_ped_id(), "GAME_BAD_OTHER", 1, 4);
			}
			else if (iVar1 < 66) {
				func_4(*uParam1, "GAME_BAD_SELF", 0, 4);
			}
			else if (iVar1 < 100) {
				func_4(player::player_ped_id(), "GAME_HECKLE", 1, 4);
			}
			return true;
		}
	}
	return false;
}

// Position - 0x151BE
void func_233(char *sParam0, int iParam1, int iParam2) {
	iParam2 = iParam2;
	ui::begin_text_command_print(sParam0);
	ui::end_text_command_print(iParam1, 1);
}

// Position - 0x151D7
void func_234(char *sParam0, int iParam1, int iParam2, int iParam3) {
	iParam3 = iParam3;
	ui::begin_text_command_print(sParam0);
	ui::add_text_component_integer(iParam1);
	ui::end_text_command_print(iParam2, 1);
}

// Position - 0x151F6
void func_235() {
	cam::set_cam_active(iLocal_129, 1);
	cam::set_cam_active(iLocal_120, 0);
}

// Position - 0x1520C
void func_236(var *uParam0, var *uParam1) {
	uParam0->f_455 = 0;
	if (!func_3(&uParam1->f_666, 5)) {
		uParam0->f_422[iLocal_30] -= uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20;
		uParam0->f_428 += uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20;
	}
	if (func_3(&uParam1->f_666, 5)) {
		func_248(uParam0);
		func_312(&uParam1->f_666, 5, 0);
	}
	else {
		uParam0->f_429[iLocal_30]++;
		if (iLocal_30 == 0) {
			func_246(4);
			iLocal_151[10]++;
		}
		if ((uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_21 == 2 ||
			 uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 50) &&
			uParam0->f_422[iLocal_30] == 0) {
			if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 50) {
				uParam0->f_432[iLocal_30]++;
				if (iLocal_30 == 0) {
					func_246(0);
					iLocal_151[1]++;
				}
			}
			func_312(&uParam1->f_666, 2, 0);
			func_312(&uParam1->f_666, 3, 0);
			func_312(&uParam1->f_666, 4, 0);
			func_312(&uParam1->f_666, 5, 1);
			func_248(uParam0);
			func_312(&uParam1->f_666, 5, 0);
			system::settimerb(0);
		}
		else if (uParam0->f_422[iLocal_30] == 1 || uParam0->f_422[iLocal_30] < 0 ||
				 uParam0->f_422[iLocal_30] == 0 && uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_21 != 2) {
			if (uParam0->f_422[iLocal_30] == 0 && uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_21 != 2) {
				func_234("DARTS_PLR_DUB", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
				func_312(&uParam1->f_666, 3, 1);
			}
			else if (uParam0->f_422[iLocal_30] == 1) {
				func_312(&uParam1->f_666, 4, 1);
			}
			else if (iLocal_30 == 1) {
				func_234("DARTS_OPP_BUST", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
			}
			else {
				func_234("DARTS_PLR_BUST", uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20, 5000, 0);
			}
			if (!iLocal_304) {
				if (func_245(uLocal_296[1 - iLocal_30])) {
					iLocal_304 = 1;
				}
			}
			uParam0->f_422[iLocal_30] = uParam0->f_425[iLocal_30];
			if (uParam0->f_1 == 6) {
			}
			system::settimera(0);
			uParam0->f_1 = 5;
			if (iLocal_30 == 0) {
				uParam0->f_435++;
			}
			func_312(&uParam1->f_666, 2, 1);
		}
		else {
			if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 50) {
				uParam0->f_432[iLocal_30]++;
				if (iLocal_30 == 0) {
					func_244(uParam1, 1);
					func_246(0);
					iLocal_151[1]++;
				}
				if (!iLocal_304 && !iLocal_309) {
					if (func_243(uLocal_296[iLocal_30])) {
						iLocal_304 = 1;
					}
				}
			}
			if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_20 == 0) {
				if (!iLocal_304 && !iLocal_309) {
					func_242(uLocal_296[1 - iLocal_30]);
					iLocal_304 = 1;
				}
			}
			if (uParam0->f_428 == 180) {
				if (!iLocal_304 && !iLocal_309) {
					if (func_241(uLocal_296[1], iLocal_30 == 0)) {
						iLocal_304 = 1;
					}
				}
				if (iLocal_30 == 0) {
					func_244(uParam1, 0);
					func_246(1);
					iLocal_151[2]++;
				}
			}
			if (uParam0->f_428 == 140) {
				if (!iLocal_304 && !iLocal_309) {
					if (func_239(uLocal_296[iLocal_30], iLocal_30 == 0)) {
						iLocal_304 = 1;
					}
				}
			}
			if (iLocal_30 == 0) {
				if (iLocal_31 < 2) {
					if (uParam0->f_422[iLocal_30] <= 170 && !func_3(&uParam1->f_666, 18)) {
						func_312(&uParam1->f_666, 18, 1);
					}
					if (!func_3(&uParam1->f_666, 19) && func_3(&uParam1->f_666, 21)) {
						func_312(&uParam1->f_666, 19, 1);
					}
					if (uParam0->f_422[iLocal_30] < 41 && uParam0->f_422[iLocal_30] > 0 &&
							uParam0->f_422[iLocal_30] % 2 == 0 ||
						uParam0->f_422[iLocal_30] == 50) {
						if (uParam0->f_422[iLocal_30] == 50) {
						}
						if (!iLocal_303) {
							func_238(uLocal_296[1]);
							iLocal_303 = 1;
						}
						if (!uParam0->f_456) {
							uParam0->f_456 = 1;
						}
						if (!func_3(&uParam1->f_666, 6)) {
							func_312(&uParam1->f_666, 6, 1);
						}
					}
					else if (uParam0->f_456) {
						uParam0->f_456 = 0;
					}
				}
			}
			if (iLocal_30 == 0 && iLocal_31 < 2) {
				func_237("DARTS_REMAIN", uParam0->f_425[iLocal_30] - uParam0->f_422[iLocal_30],
						 uParam0->f_422[iLocal_30], 7500, 0);
			}
			else if (iLocal_30 == 1 && iLocal_31 == 2) {
			}
			else if (uParam0->f_1 != 6) {
				func_304(&uParam0->f_1);
			}
			uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_25 = 1;
			iLocal_31++;
			system::settimera(0);
			if (uParam0->f_1 != 6) {
				if (uParam0->f_456 && uParam0->f_248 == 1) {
					uParam0->f_1 = 0;
				}
				else {
					uParam0->f_1 = 2;
				}
			}
			if (iLocal_31 == 3) {
				iLocal_31 = 2;
				uParam0->f_1 = 5;
			}
			if (iLocal_30 == 0) {
				uParam0->f_435 = 0;
			}
			func_312(&uParam1->f_666, 3, 0);
			func_312(&uParam1->f_666, 2, 0);
			func_312(&uParam1->f_666, 4, 0);
		}
	}
}

// Position - 0x157A9
void func_237(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	iParam4 = iParam4;
	ui::begin_text_command_print(sParam0);
	ui::add_text_component_integer(iParam1);
	ui::add_text_component_integer(iParam2);
	ui::end_text_command_print(iParam3, 1);
}

// Position - 0x157CE
void func_238(int iParam0) {
	if (!ped::is_ped_injured(iParam0)) {
		func_4(iParam0, "DARTS_1_DART_AWAY", 0, 4);
	}
}

// Position - 0x157EC
bool func_239(int iParam0, bool bParam1) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 75) {
		if (entity::does_entity_exist(func_479())) {
			if (bParam1) {
				func_4(player::player_ped_id(), "DARTS_140", 1, 4);
			}
			else {
				func_4(func_479(), "DARTS_140", 0, 4);
			}
			return true;
		}
		else if (bParam1) {
			if (func_240()) {
				func_4(player::player_ped_id(), "DARTS_140", 1, 4);
			}
			else {
				func_4(iParam0, "DARTS_140", 0, 4);
			}
			return true;
		}
	}
	return false;
}

// Position - 0x1586B
bool func_240() {
	if (gameplay::is_bit_set(gameplay::get_random_int_in_range(0, 65535), 0)) {
		return true;
	}
	return false;
}

// Position - 0x1588C
bool func_241(int iParam0, bool bParam1) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 75) {
		if (entity::does_entity_exist(func_479())) {
			if (bParam1) {
				func_4(player::player_ped_id(), "DARTS_180", 1, 4);
			}
			else {
				func_4(func_479(), "DARTS_180", 0, 4);
			}
			return true;
		}
		else if (bParam1) {
			if (func_240()) {
				func_4(player::player_ped_id(), "DARTS_180", 1, 4);
			}
			else {
				func_4(iParam0, "DARTS_180", 0, 4);
			}
			return true;
		}
	}
	return false;
}

// Position - 0x1590B
int func_242(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 75) {
		if (iParam0 == player::player_ped_id()) {
			iVar1 = 1;
		}
		if (!ped::is_ped_injured(iParam0)) {
			func_4(iParam0, "DARTS_MISS_BOARD", iVar1, 4);
		}
		return 1;
	}
	return 0;
}

// Position - 0x1594E
bool func_243(int iParam0) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 100) {
		func_4(iParam0, "DARTS_BULLSEYE", 0, 4);
		return true;
	}
	return false;
}

// Position - 0x1597A
void func_244(var *uParam0, int iParam1) {
	uParam0->f_679 = 1;
	uParam0->f_682 = iParam1;
}

// Position - 0x1598F
bool func_245(int iParam0) {
	int iVar0;

	if (iParam0 == player::player_ped_id()) {
		iVar0 = 1;
	}
	if (!ped::is_ped_injured(iParam0)) {
		func_4(iParam0, "DARTS_BUST", iVar0, 4);
	}
	return true;
}

// Position - 0x159BB
void func_246(int iParam0) {
	switch (iParam0) {
	case 0:
		Global_101700.f_17929++;
		func_247("DARTS_STAT_NUM_BULLSEYES", Global_101700.f_17929);
		break;

	case 1:
		Global_101700.f_17929.f_1++;
		func_247("DARTS_STAT_NUM_180S", Global_101700.f_17929.f_1);
		break;

	case 2:
		Global_101700.f_17929.f_2++;
		func_247("DARTS_STAT_NUM_WINS", Global_101700.f_17929.f_2);
		break;

	case 3:
		Global_101700.f_17929.f_3++;
		func_247("DARTS_STAT_NUM_LOSS", Global_101700.f_17929.f_3);
		break;

	case 4:
		Global_101700.f_17929.f_4++;
		func_247("DARTS_STAT_DARTS_THROWN", Global_101700.f_17929.f_4);
		break;

	case 5:
		Global_101700.f_17929.f_5++;
		func_247("DARTS_STAT_NUM_GAMES", Global_101700.f_17929.f_5);
		break;

	case 7:
		Global_101700.f_17929.f_7 =
			system::to_float(Global_101700.f_17929.f_2) / system::to_float(Global_101700.f_17929.f_5);
		break;

	case 8:
		Global_101700.f_17929.f_8 =
			system::to_float(Global_101700.f_17929.f_4) / system::to_float(Global_101700.f_17929.f_5);
		break;
	}
}

// Position - 0x15B32
void func_247(char *sParam0, var uParam1) {}

// Position - 0x15B3A
void func_248(var *uParam0) {
	if (!uParam0->f_460) {
		uParam0->f_460 = 1;
	}
	func_246(5);
	ui::clear_small_prints();
	ui::clear_help(1);
	if (audio::is_audio_scene_active(func_395(2))) {
		audio::stop_audio_scene(func_395(2));
	}
	if (uParam0->f_248 == 1) {
		func_235();
	}
	if (iLocal_30 == 0) {
		uParam0->f_454 = 1;
		iLocal_313 = 1;
		uParam0->f_446[iLocal_30]++;
		uParam0->f_437[iLocal_30]++;
		func_246(2);
		iLocal_151[8]++;
	}
	else {
		uParam0->f_454 = 0;
		uParam0->f_446[iLocal_30]++;
		uParam0->f_437[iLocal_30]++;
		func_246(3);
		iLocal_151[9]++;
	}
	func_246(7);
	func_415(&uParam0->f_254);
	if (func_250(uParam0)) {
		uParam0->f_449[0] = 0;
		uParam0->f_449[1] = 0;
		uParam0->f_446[0] = 0;
		uParam0->f_446[1] = 0;
		uParam0->f_443[iLocal_30]++;
		if (!uParam0->f_458) {
			if (uParam0->f_454) {
				func_249(1);
			}
			uParam0->f_458 = 1;
		}
		if (uParam0->f_454) {
			iLocal_151[3]++;
			iLocal_331 = 0;
		}
		else {
			iLocal_151[5]++;
			iLocal_331 = 3;
		}
		*uParam0 = 12;
	}
	else {
		*uParam0 = 11;
	}
	uParam0->f_1 = 2;
	audio::start_audio_scene(func_395(3));
	iLocal_310 = 1;
	uParam0->f_428 = 0;
	iLocal_99 = 0;
	uParam0->f_425[0] = 301;
	uParam0->f_425[1] = 301;
}

// Position - 0x15CE3
void func_249(int iParam0) {
	char *sVar0;

	audio::register_script_with_audio(0);
	switch (func_79()) {
	case 0:
		if (iParam0) {
			sVar0 = "MICHAEL_SMALL_01";
		}
		else {
			sVar0 = "MICHAEL_BIG_01";
		}
		break;

	case 1:
		if (iParam0) {
			sVar0 = "FRANKLIN_SMALL_01";
		}
		else {
			sVar0 = "FRANKLIN_BIG_01";
		}
		break;

	case 2:
		if (iParam0) {
			sVar0 = "TREVOR_SMALL_01";
		}
		else {
			sVar0 = "TREVOR_BIG_01";
		}
		break;
	}
	audio::play_mission_complete_audio(sVar0);
}

// Position - 0x15D56
bool func_250(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = func_103(uParam0->f_454, 0, 1);
	switch (uParam0->f_452) {
	case 1: iVar1 = 1; break;

	case 3: iVar1 = 2; break;

	case 5: iVar1 = 3; break;
	}
	if (uParam0->f_446[iVar0] == iVar1) {
		uParam0->f_449[iVar0]++;
		uParam0->f_440[iVar0]++;
		uParam0->f_446[0] = 0;
		uParam0->f_446[1] = 0;
		uParam0->f_459 = 1;
		if (iVar0 == 0) {
			iLocal_151[6]++;
		}
		if (uParam0->f_449[iVar0] == uParam0->f_453) {
			uParam0->f_459 = 0;
			return true;
		}
	}
	return false;
}

// Position - 0x15E18
void func_251(var *uParam0, var *uParam1, int iParam2) {
	float fVar0;
	float fVar1;
	float fVar2;
	vector3 vVar3;
	int iVar6;
	int iVar7;

	vVar3 = {uParam0->f_8};
	vVar3.x += 0.0041f;
	vVar3.z += 0.0002f;
	fVar1 = gameplay::get_angle_between_2d_vectors(0f, 1f, vVar3.x, vVar3.z);
	fVar0 = func_252(vVar3);
	uParam0->f_22 = fVar0;
	if (iParam2) {
		audio::play_sound_from_coord(-1, "DARTS_HIT_DART_MASTER", uParam1->f_1, 0, 0, 0, 0);
	}
	if (fVar0 < 0.009f) {
		audio::play_sound_from_coord(-1, "DARTS_HIT_BULLSEYE_MASTER", uParam1->f_1, 0, 0, 0, 0);
		uParam0->f_20 = 50;
	}
	else if (fVar0 < 0.021f) {
		audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
		uParam0->f_20 = 25;
	}
	else if (fVar0 > 0.3f) {
		audio::play_sound_from_coord(-1, "DARTS_HIT_WALL_MASTER", uParam1->f_1, 0, 0, 0, 0);
		uParam0->f_20 = 0;
	}
	else if (fVar0 >= 0.226f) {
		audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
		uParam0->f_20 = 0;
	}
	else {
		if (fVar0 > 0.1285f && fVar0 < 0.1405f) {
			uParam0->f_21 = 3;
			audio::play_sound_from_coord(-1, "DARTS_SCORE_TRIPLE_MASTER", uParam1->f_1, 0, 0, 0, 0);
		}
		else if (fVar0 > 0.2132f && fVar0 < 0.226f) {
			uParam0->f_21 = 2;
			audio::play_sound_from_coord(-1, "DARTS_SCORE_DOUBLE_MASTER", uParam1->f_1, 0, 0, 0, 0);
		}
		else {
			uParam0->f_21 = 1;
			audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
		}
		if (uParam0->f_8 < 0f) {
			fVar1 = 360f - fVar1;
		}
		fVar2 = 0f;
		iVar6 = 0;
		iVar6 = 0;
		while (iVar6 < 21) {
			if (fVar1 >= fVar2 - 9f && fVar1 < fVar2 + 9f) {
				if (fVar1 <= fVar2 - 8.1f && fVar1 >= fVar2 - 9.9f || fVar1 >= fVar2 + 8.1f && fVar1 <= fVar2 + 9.9f) {
					audio::play_sound_from_coord(-1, "DARTS_HIT_WIRE_MASTER", uParam1->f_1, 0, 0, 0, 0);
				}
				iVar7 = iLocal_33[iVar6] * uParam0->f_21;
				uParam0->f_20 = iVar7;
			}
			fVar2 += 18f;
			iVar6++;
		}
	}
}

// Position - 0x1604C
var func_252(vector3 vParam0) { return system::sqrt(vParam0.x * vParam0.x + vParam0.z * vParam0.z); }

// Position - 0x16067
int func_253(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < iLocal_31) {
		if (uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_8 >
				uParam0->f_5[iLocal_30 /*79*/][iVar0 /*26*/].f_8 - 0.008f &&
			uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_8 <
				uParam0->f_5[iLocal_30 /*79*/][iVar0 /*26*/].f_8 + 0.008f &&
			uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_8.f_2 >
				uParam0->f_5[iLocal_30 /*79*/][iVar0 /*26*/].f_8.f_2 - 0.008f &&
			uParam0->f_5[iLocal_30 /*79*/][iLocal_31 /*26*/].f_8.f_2 <
				uParam0->f_5[iLocal_30 /*79*/][iVar0 /*26*/].f_8.f_2 + 0.008f) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1612D
bool func_254(var *uParam0, var *uParam1, int iParam2, int iParam3) {
	vector3 vVar0;
	vector3 vVar3;
	float fVar6;

	if (iLocal_30 == 0 && iParam2 == 1) {
		func_255("Darts", "Dart_Reticules", &Local_70, 1, 0, 4, 0);
	}
	fVar6 = gameplay::get_frame_time();
	vVar3 = {uParam0->f_5 * FtoV(fVar6) * FtoV(8.5f)};
	uParam0->f_2 = {uParam0->f_2 - vVar3};
	if (uParam0->f_2.f_1 > uParam0->f_8.f_1 - 0.04f) {
		uParam0->f_23 = 1;
		uParam0->f_24 = 0;
		vVar0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_11,
														uParam0->f_11.f_1 + fLocal_55, uParam0->f_11.f_2)};
		entity::set_entity_coords(*uParam0, vVar0, 1, 0, 0, 1);
		return true;
	}
	vVar0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_2,
													uParam0->f_2.f_1 + fLocal_55, uParam0->f_2.f_2)};
	entity::set_entity_coords(*uParam0, vVar0, 1, 0, 0, 1);
	uParam0->f_17.f_1 += 1000f * fVar6;
	entity::set_entity_rotation(*uParam0, uParam0->f_17, 0, 1);
	if (entity::does_entity_exist(*uParam0)) {
		if (iParam3) {
		}
	}
	else {
		return true;
	}
	return false;
}

// Position - 0x1624D
void func_255(char *sParam0, char *sParam1, var *uParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	struct<9> Var0;

	Var0 = {*uParam2};
	switch (iParam4) {
	case 0: func_266(&Var0); break;

	case 1: func_265(&Var0); break;

	case 5: func_264(&Var0); break;

	case 6: func_263(&Var0); break;

	case 7: func_262(&Var0); break;

	case 8: func_261(&Var0); break;

	case 9: func_260(&Var0); break;
	}
	if (func_258()) {
		graphics::_set_2d_layer(iParam5);
		if (iParam3 == 1) {
			graphics::draw_sprite(sParam0, sParam1, func_257(Var0), func_256(Var0.f_1), Var0.f_2, Var0.f_3, Var0.f_8,
								  Var0.f_4, Var0.f_5, Var0.f_6, Var0.f_7, iParam6);
		}
		else {
			graphics::draw_sprite(sParam0, sParam1, func_257(Var0), func_256(Var0.f_1), Var0.f_2, Var0.f_3, Var0.f_8,
								  Var0.f_4, Var0.f_5, Var0.f_6, Var0.f_7, iParam6);
		}
		graphics::_set_2d_layer(4);
	}
}

// Position - 0x16352
float func_256(float fParam0) { return fParam0 + fLocal_13; }

// Position - 0x1635F
float func_257(float fParam0) { return fParam0 + fLocal_12; }

// Position - 0x1636C
bool func_258() {
	if (func_259()) {
		return true;
	}
	if (cam::is_screen_faded_out()) {
		return false;
	}
	if (cam::is_screen_fading_out() || cam::is_screen_fading_in()) {
		return false;
	}
	if (gameplay::is_frontend_fading()) {
		return false;
	}
	return true;
}

// Position - 0x163AB
bool func_259() { return Global_1312438; }

// Position - 0x163B7
void func_260(var *uParam0) {
	uParam0->f_4 = 128;
	uParam0->f_5 = 128;
	uParam0->f_6 = 128;
}

// Position - 0x163D1
void func_261(var *uParam0) { uParam0->f_7 = 2; }

// Position - 0x163DE
void func_262(var *uParam0) { uParam0->f_7 = 5; }

// Position - 0x163EB
void func_263(var *uParam0) {
	uParam0->f_4 = 0;
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 70;
}

// Position - 0x16408
void func_264(var *uParam0) {
	uParam0->f_4 = 0;
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 100;
}

// Position - 0x16425
void func_265(var *uParam0) {
	uParam0->f_4 -= 50;
	uParam0->f_5 -= 50;
	uParam0->f_6 -= 50;
}

// Position - 0x1644E
void func_266(var *uParam0) {
	uParam0->f_4 = uParam0->f_4;
	uParam0->f_5 = uParam0->f_5;
	uParam0->f_6 = uParam0->f_6;
	uParam0->f_7 = uParam0->f_7;
}

// Position - 0x16476
void func_267(var *uParam0, var *uParam1, int *iParam2, var *uParam3, int iParam4) {
	float fVar0;
	var uVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	int iVar5;
	int iVar6;
	vector3 vVar7;
	vector3 vVar10;
	float fVar13;

	if (*uParam3 == 50) {
		fVar3 = 0f;
		fVar4 = gameplay::get_random_float_in_range(0f, 360f);
	}
	else if (*uParam3 == 25) {
		fVar3 = 0.14f;
		fVar4 = gameplay::get_random_float_in_range(0f, 360f);
	}
	else {
		if (uParam3->f_1 == 3) {
			fVar3 = 0.1345f;
		}
		else if (uParam3->f_1 == 2) {
			fVar3 = 0.218f;
		}
		else {
			fVar3 = 0.18f;
		}
		fVar13 = 0f;
		iVar5 = 0;
		iVar5 = 0;
		while (iVar5 < 21) {
			if (*uParam3 == iLocal_33[iVar5]) {
				fVar4 = fVar13;
			}
			fVar13 += 18f;
			iVar5++;
		}
	}
	if (!iParam4 && uParam3->f_3 < 30) {
		iVar5 = gameplay::get_random_int_in_range(0, 100);
		iVar6 = gameplay::get_random_int_in_range(func_269(uParam3), 150);
		if (uParam3->f_2 > 140) {
			fVar0 = gameplay::get_random_float_in_range(-35f, 35f);
		}
		else if (iVar5 < iVar6 && uParam3->f_4 == 2) {
			fVar0 = gameplay::get_random_float_in_range(-80f, 80f);
		}
		else if (iVar5 < iVar6 && uParam3->f_2 > -140) {
			fVar0 = gameplay::get_random_float_in_range(-60f, 60f);
		}
		else {
			fVar0 = gameplay::get_random_float_in_range(-100f, 100f);
			if (fVar0 > 0f) {
				fVar0 = gameplay::get_random_float_in_range(-200f, -60f);
			}
			else {
				fVar0 = gameplay::get_random_float_in_range(60f, 200f);
			}
		}
		fVar0 /= 10f;
		fVar4 += fVar0;
		iVar5 = gameplay::get_random_int_in_range(0, 100);
		iVar6 = gameplay::get_random_int_in_range(func_269(uParam3), 150);
		if (uParam3->f_2 > 140) {
			fVar0 = gameplay::get_random_float_in_range(-0.25f, 0.25f);
		}
		else if (iVar5 < iVar6 && uParam3->f_4 == 2) {
			fVar0 = gameplay::get_random_float_in_range(-0.07f, 0.07f);
		}
		else if (iVar5 < iVar6 && uParam3->f_2 > -140) {
			fVar0 = gameplay::get_random_float_in_range(-0.15f, 0.15f);
		}
		else {
			fVar0 = gameplay::get_random_float_in_range(-100f, 100f);
			if (fVar0 > 0f) {
				fVar0 = gameplay::get_random_float_in_range(-1f, -0.3f);
			}
			else {
				fVar0 = gameplay::get_random_float_in_range(0.3f, 1f);
			}
		}
		fVar0 /= 10f;
		fVar3 += fVar0;
	}
	uParam0->f_8 = system::sin(fVar4) * fVar3;
	uParam0->f_8.f_1 = -0.23f;
	uParam0->f_8.f_2 = system::cos(fVar4) * fVar3;
	uParam0->f_8 -= 0.0035f;
	uParam0->f_8.f_2 -= 0.0002f;
	if (*iParam2 == 6) {
		func_268(uParam0);
	}
	else {
		uParam0->f_23 = 0;
		uParam0->f_24 = 1;
		func_268(uParam0);
		*uParam0 = object::create_object(uParam0->f_1, vLocal_79, 0, 0, 0);
		uVar1 = gameplay::get_random_float_in_range(0f, 90f);
		vVar7 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, vLocal_82)};
		vVar10 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_8,
														 uParam0->f_8.f_1 + fLocal_55, uParam0->f_8.f_2)};
		fVar2 = gameplay::get_heading_from_vector_2d(vVar7.x - vVar10.x, vVar7.y - vVar10.y);
		fVar2 -= 180f;
		uParam0->f_17 = {90f, uVar1, fVar2};
		entity::set_entity_rotation(*uParam0, uParam0->f_17, 0, 1);
		uParam0->f_2 = {vLocal_82};
		*iParam2 = 3;
		audio::play_sound_from_entity(-1, "DARTS_THROW_DART_MASTER", *uParam0, 0, 0, 0);
	}
}

// Position - 0x167CF
void func_268(var *uParam0) {
	vector3 vVar0;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	fVar6 = 0.08f;
	uParam0->f_8.f_1 = -0.213f;
	vVar0 = {vLocal_82 - uParam0->f_8};
	fVar3 = system::vmag(vVar0);
	uParam0->f_5 = {vVar0 / FtoV(fVar3)};
	fVar4 = gameplay::get_heading_from_vector_2d(uParam0->f_5, uParam0->f_5.f_1);
	uParam0->f_17.f_2 = fVar4 - 180f;
	fVar5 = gameplay::tan(uParam0->f_17.f_2) * fVar6;
	uParam0->f_11 = {uParam0->f_8};
	uParam0->f_11 += fVar5;
	vVar0 = {vLocal_82 - uParam0->f_11};
	fVar3 = system::vmag(vVar0);
	uParam0->f_5 = {vVar0 / FtoV(fVar3)};
}

// Position - 0x1687B
int func_269(var *uParam0) {
	switch (uParam0->f_4) {
	case 0: return 25;

	case 1: return 75;

	case 2: return 90;

	default:
	}
	return 25;
}

// Position - 0x168AF
void func_270(var *uParam0, var *uParam1) {
	int iVar0;

	*uParam1 = 0;
	uParam1->f_1 = 0;
	uParam1->f_2 = (*uParam0)[1] - (*uParam0)[0];
	uParam1->f_3++;
	if ((*uParam0)[iLocal_30] > 121) {
		*uParam1 = 20;
		uParam1->f_1 = 3;
	}
	else if ((*uParam0)[iLocal_30] > 60) {
		if ((*uParam0)[iLocal_30] % 2 == 1) {
			if (func_240()) {
				*uParam1 = 19;
			}
			else {
				*uParam1 = 17;
			}
			uParam1->f_1 = 3;
		}
		else {
			*uParam1 = 20;
			uParam1->f_1 = 3;
		}
	}
	else if ((*uParam0)[iLocal_30] < 61) {
		if ((*uParam0)[iLocal_30] == 50) {
			*uParam1 = 50;
			uParam1->f_1 = 1;
		}
		else if ((*uParam0)[iLocal_30] > 52) {
			*uParam1 = (*uParam0)[iLocal_30] - 40;
			uParam1->f_1 = 1;
		}
		else if ((*uParam0)[iLocal_30] > 40) {
			*uParam1 = (*uParam0)[iLocal_30] - 32;
			uParam1->f_1 = 1;
		}
		else if ((*uParam0)[iLocal_30] % 2 == 0) {
			iVar0 = 1;
			iVar0 = 0;
			while (iVar0 < 20) {
				*uParam1 = (*uParam0)[iLocal_30] / 2;
				uParam1->f_1 = 2;
				iVar0++;
			}
		}
		else {
			iVar0 = 32;
			while (*uParam1 == 0 && iVar0 > 1) {
				if ((*uParam0)[iLocal_30] > iVar0) {
					*uParam1 = (*uParam0)[iLocal_30] - iVar0;
					uParam1->f_1 = 1;
				}
				iVar0 /= 2;
			}
		}
	}
}

// Position - 0x16A01
int func_271(int iParam0) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 100);
	if (iVar0 < 33) {
		func_4(iParam0, "DARTS_BORED", 0, 4);
		return 1;
	}
	return 0;
}

// Position - 0x16A2D
void func_272(int *iParam0) { func_273(iParam0, 0f); }

// Position - 0x16A3C
void func_273(int *iParam0, float fParam1) {
	uParam0->f_1 = func_8(gameplay::is_bit_set(*uParam0, 4)) + fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x16A6A
bool func_274(var *uParam0, var *uParam1, var *uParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	float fVar0;
	int iVar1;

	switch (iParam6) {
	case 0:
		if (iLocal_97) {
			if (system::timerb() > 50) {
				iLocal_98 = 0;
				iLocal_99 = 0;
				iLocal_101 = 0;
				if (func_283(uParam0, uParam1, 0)) {
					audio::play_sound_from_entity(-1, "DARTS_THROW_DART_MASTER", *uParam0, 0, 0, 0);
					iLocal_97 = 0;
					return true;
				}
			}
		}
		else if (!iParam3) {
			if (!(controls::is_control_just_pressed(2, 223) && iLocal_101) && !iParam4) {
				iLocal_98 = 1;
				iLocal_99 = 1;
				if (!iLocal_100) {
					func_282(uParam0, *uParam2);
					iLocal_100 = 1;
				}
				else {
					if (!iParam5) {
						func_281();
					}
					func_280(uParam0, iParam6);
					func_279(uParam0, uParam1, iParam3, 0);
				}
			}
			else {
				if (iParam4) {
					fVar0 = gameplay::get_random_float_in_range(0.02f, 0.1f);
					iVar1 = gameplay::get_random_int_in_range(0, 100);
					if (iVar1 < 50) {
						if (uParam0->f_8 + fVar0 < 0.33f) {
							uParam0->f_8 += fVar0;
						}
						else {
							uParam0->f_8 -= fVar0;
						}
					}
					else if (uParam0->f_8 - fVar0 > -0.33f) {
						uParam0->f_8 -= fVar0;
					}
					else {
						uParam0->f_8 += fVar0;
					}
					fVar0 = gameplay::get_random_float_in_range(0.02f, 0.1f);
					iVar1 = gameplay::get_random_int_in_range(0, 100);
					if (iVar1 < 50) {
						if (uParam0->f_8.f_2 + fVar0 < 0.29f) {
							uParam0->f_8.f_2 += fVar0;
						}
						else {
							uParam0->f_8.f_2 -= fVar0;
						}
					}
					else if (uParam0->f_8.f_2 - fVar0 > -0.29f) {
						uParam0->f_8.f_2 -= fVar0;
					}
					else {
						uParam0->f_8.f_2 += fVar0;
					}
					uParam0->f_2 = {vLocal_82};
					iLocal_98 = 1;
					iLocal_99 = 1;
				}
				if (iLocal_98 && iLocal_99) {
					if (!iLocal_97) {
						ui::clear_prints();
						iLocal_97 = 1;
						system::settimerb(0);
					}
				}
			}
		}
		break;

	case 1:
		if (iLocal_97) {
			func_255("Darts", "Dart_Reticules", &Local_61, 1, 0, 4, 0);
			if (system::timerb() > 25) {
				if (func_283(uParam0, uParam1, 1)) {
					audio::play_sound_from_entity(-1, "DARTS_THROW_DART_MASTER", *uParam0, 0, 0, 0);
					iLocal_97 = 0;
					return true;
				}
			}
		}
		else if (!func_275(uParam0)) {
			if (!iLocal_100) {
				func_282(uParam0, *uParam2);
			}
			else {
				func_281();
				func_280(uParam0, iParam6);
				func_279(uParam0, uParam1, iParam3, 0);
			}
		}
		else if (!iLocal_97) {
			iLocal_97 = 1;
			system::settimerb(0);
		}
		break;
	}
	return false;
}

// Position - 0x16CDF
int func_275(var *uParam0) {
	int iVar0;
	float fVar1;
	float fVar2;

	fVar1 = controls::get_control_normal(2, 220);
	fVar2 = controls::get_control_normal(2, 221);
	iLocal_136 = system::round(fVar2);
	switch (iLocal_135) {
	case 0:
		if (iLocal_136 > 120) {
			iLocal_137 = gameplay::get_game_timer();
			iLocal_135 = 1;
		}
		if (iLocal_136 < -100) {
			iLocal_141 = system::round(fVar1);
		}
		break;

	case 1:
		if (iLocal_136 > 120) {
			iLocal_137 = gameplay::get_game_timer();
		}
		else if (iLocal_136 < 120 && iLocal_136 > -120 && gameplay::get_game_timer() - iLocal_137 > 500) {
			iLocal_135 = 0;
		}
		else if (iLocal_136 < -100) {
			iLocal_138 = gameplay::get_game_timer();
			if (iLocal_138 - iLocal_137 < 500) {
				iLocal_141 = system::round(fVar1);
				iLocal_139 = iLocal_138 - iLocal_137;
				iLocal_135 = 2;
			}
		}
		break;

	case 2:
		if (iLocal_139 > iLocal_140) {
			if (iLocal_139 > 100 && iLocal_139 < 150) {
				fLocal_144 = 0.066477f;
				uParam0->f_8.f_2 -= fLocal_144;
			}
			else {
				fLocal_143 = system::to_float(iLocal_140) / system::to_float(iLocal_139);
				fLocal_144 = (1f - fLocal_143) * fLocal_147;
				uParam0->f_8.f_2 -= fLocal_144;
			}
		}
		else {
			fLocal_144 = 0f;
		}
		if (iLocal_141 > 7) {
			fLocal_145 = system::to_float(iLocal_141) / fLocal_150;
			fLocal_146 = fLocal_148 * fLocal_145;
			uParam0->f_8 += fLocal_146;
		}
		else if (iLocal_141 < -7) {
			fLocal_145 = system::to_float(iLocal_141) / fLocal_149;
			fLocal_146 = fLocal_148 * fLocal_145;
			uParam0->f_8 -= fLocal_146;
		}
		else {
			fLocal_146 = 0f;
		}
		if (fLocal_144 < 0.066477f && fLocal_146 == 0f) {
			func_278();
		}
		else if (fLocal_144 <= 0.066477f && fLocal_146 < 0.06f) {
			func_277();
		}
		else {
			func_276();
		}
		iVar0 = 1;
		iLocal_135 = 0;
		break;
	}
	return iVar0;
}

// Position - 0x16E9D
void func_276() {
	Local_70.f_4 = 210;
	Local_70.f_5 = 23;
	Local_70.f_6 = 19;
}

// Position - 0x16EB7
void func_277() {
	Local_70.f_4 = 183;
	Local_70.f_5 = 137;
	Local_70.f_6 = 0;
}

// Position - 0x16ED0
void func_278() {
	Local_70.f_4 = 16;
	Local_70.f_5 = 184;
	Local_70.f_6 = 10;
}

// Position - 0x16EEA
void func_279(var *uParam0, var *uParam1, bool bParam2, int iParam3) {
	vector3 vVar0;

	vVar0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_14,
													uParam0->f_14.f_1 + fLocal_55, uParam0->f_14.f_2)};
	if (iParam3 == 1) {
		vVar0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_14,
														uParam0->f_14.f_1 + fLocal_55, uParam0->f_14.f_2)};
	}
	graphics::get_screen_coord_from_world_coord(vVar0, &Local_61, &Local_61.f_1);
	if (gameplay::get_game_timer() % 1000 < 50) {
	}
	if (!bParam2) {
		if (bLocal_94) {
			func_255("Darts", "Dart_Reticules_Zoomed", &Local_61, 1, 0, 4, 0);
		}
		else {
			func_255("Darts", "Dart_Reticules", &Local_61, 1, 0, 4, 0);
		}
		if (!iLocal_101) {
			iLocal_101 = 1;
		}
	}
}

// Position - 0x16F99
void func_280(var *uParam0, int iParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	int iVar7;
	float fVar8;
	float fVar9;

	fVar0 = 0.033367f;
	iVar7 = 0;
	fVar3 = controls::_0x5B84D09CEC5209C5(2, 218);
	fVar4 = controls::_0x5B84D09CEC5209C5(2, 219);
	fVar5 = controls::get_control_normal(2, 220);
	fVar6 = controls::get_control_normal(2, 221);
	if (controls::_is_input_disabled(2)) {
		if (gameplay::absf(fVar5) > gameplay::absf(fVar3) || gameplay::absf(fVar6) > gameplay::absf(fVar4)) {
			fVar3 = fVar5;
			fVar4 = fVar6;
			iVar7 = 0;
		}
		else {
			if (controls::_0xE1615EC03B3BB4FD()) {
				fVar4 *= -1f;
			}
			if (controls::is_look_inverted()) {
				fVar4 *= -1f;
			}
			if (controls::is_control_pressed(2, 227)) {
				uParam0->f_8 += fVar3 * 0.06f;
				uParam0->f_8.f_2 -= fVar4 * 0.06f;
			}
			else {
				uParam0->f_8 += fVar3 * 0.03f;
				uParam0->f_8.f_2 -= fVar4 * 0.03f;
			}
			uParam0->f_8 = func_14(uParam0->f_8, -0.33f, 0.33f);
			uParam0->f_8.f_2 = func_14(uParam0->f_8.f_2, -0.29f, 0.29f);
			iVar7 = 1;
		}
	}
	if (!iVar7) {
		if (controls::_is_input_disabled(2)) {
			if (fVar5 != 0f || fVar6 != 0f) {
				fVar3 = fVar5;
				fVar4 = fVar6;
			}
		}
		if (fVar3 > 0f) {
			if (uParam0->f_8 + fLocal_92 * fVar0 < 0.33f) {
				uParam0->f_8 += fLocal_92 * fVar0;
			}
		}
		else if (fVar3 < 0f) {
			if (uParam0->f_8 - fLocal_92 * fVar0 > -0.33f) {
				uParam0->f_8 -= fLocal_92 * fVar0;
			}
		}
		if (fVar4 > 0f) {
			if (uParam0->f_8.f_2 - fLocal_92 * fVar0 > -0.29f) {
				uParam0->f_8.f_2 -= fLocal_92 * fVar0;
			}
		}
		else if (fVar4 < 0f) {
			if (uParam0->f_8.f_2 + fLocal_92 * fVar0 < 0.29f) {
				uParam0->f_8.f_2 += fLocal_92 * fVar0;
			}
		}
	}
	uParam0->f_14 = {uParam0->f_8};
	if (iParam1 == 0) {
		fVar2 = gameplay::get_random_float_in_range(0f - fLocal_89, 0f + fLocal_89);
		fVar1 = gameplay::get_random_float_in_range(0f - fLocal_88, 0f + fLocal_88);
		if (uParam0->f_8 + fVar1 * fVar0 > -0.33f && uParam0->f_8 + fVar1 * fVar0 < 0.33f) {
			uParam0->f_8 += fVar2 * fVar0;
			uParam0->f_14 = uParam0->f_8;
			uParam0->f_14 += fVar1 * fVar0;
		}
		fVar2 = gameplay::get_random_float_in_range(0f - fLocal_89, 0f + fLocal_89);
		fVar1 = gameplay::get_random_float_in_range(0f - fLocal_88, 0f + fLocal_88);
		if (uParam0->f_8.f_2 + fVar1 * fVar0 > -0.29f && uParam0->f_8.f_2 + fVar1 * fVar0 < 0.29f) {
			uParam0->f_8.f_2 += fVar2 * fVar0;
			uParam0->f_14.f_2 = uParam0->f_8.f_2;
			uParam0->f_14.f_2 += fVar1 * fVar0;
		}
	}
	if (iParam1 == 1) {
		fLocal_92 = 0.5f;
		if (iLocal_135 == 1) {
			fVar8 = 0.06f;
			fVar9 = 0.08f;
		}
		else {
			fVar8 = 0.02f;
			fVar9 = 0.03f;
		}
		fVar2 = gameplay::get_random_float_in_range(0f - fVar9, 0f + fVar9);
		fVar1 = gameplay::get_random_float_in_range(0f - fVar8, 0f + fVar8);
		if (uParam0->f_8 + fVar1 * fVar0 > -0.33f && uParam0->f_8 + fVar1 * fVar0 < 0.33f) {
			uParam0->f_8 += fVar2 * fVar0;
			uParam0->f_14 = uParam0->f_8;
			uParam0->f_14 += fVar1 * fVar0;
		}
		fVar2 = gameplay::get_random_float_in_range(0f - fVar9, 0f + fVar9);
		fVar1 = gameplay::get_random_float_in_range(0f - fVar8, 0f + fVar8);
		if (uParam0->f_8.f_2 + fVar1 * fVar0 > -0.33f && uParam0->f_8.f_2 + fVar1 * fVar0 < 0.33f) {
			uParam0->f_8.f_2 += fVar2 * fVar0;
			uParam0->f_14.f_2 = uParam0->f_8.f_2;
			uParam0->f_14.f_2 += fVar1 * fVar0;
		}
	}
}

// Position - 0x1738B
void func_281() {
	if (controls::is_control_pressed(2, 227)) {
		fLocal_92 = 0.3f;
	}
	else {
		fLocal_92 = 0.1f;
	}
	if (controls::is_control_pressed(2, 229)) {
		if (bLocal_94) {
			if (system::timera() > iLocal_142) {
				fLocal_88 = fLocal_90;
				fLocal_89 = fLocal_91;
				fLocal_92 = 0.1f;
				bLocal_94 = false;
			}
		}
		else if (iLocal_93 < 1) {
			fLocal_88 = 0.03f;
			fLocal_89 = 0.05f;
			fLocal_92 = 0.1f;
			system::settimera(0);
			bLocal_94 = true;
			iLocal_93++;
		}
		else if (!func_284("DARTS_FST_HLP") && !func_284("DARTS_AIM_HLP") && !func_284("DARTS_CLOCK") &&
				 !func_284("DARTS_STD_HLP") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B") && !iLocal_95) {
			iLocal_95 = 1;
			if (!gameplay::is_bit_set(Global_101661, 1)) {
				func_399("DARTS_SHT_USE", -1);
				gameplay::set_bit(&Global_101661, 1);
			}
		}
	}
	else if (bLocal_94) {
		fLocal_88 = fLocal_90;
		fLocal_89 = fLocal_91;
		fLocal_92 = 0.1f;
		bLocal_94 = false;
	}
}

// Position - 0x1749D
void func_282(var *uParam0, struct<4> Param1, var uParam5, var uParam6) {
	vector3 vVar0;

	vVar0 = {0f, 0f, 0f};
	vVar0.x += gameplay::get_random_float_in_range(-0.1f, 0.1f);
	vVar0.z += gameplay::get_random_float_in_range(-0.1f, 0.1f);
	uParam0->f_8 = {Param1.f_3 + vVar0};
	uParam0->f_2 = {vLocal_82};
}

// Position - 0x174F1
bool func_283(var *uParam0, var *uParam1, int iParam2) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	float fVar9;
	var uVar10;
	float fVar11;

	if (entity::does_entity_exist(*uParam0)) {
		entity::set_entity_coords(*uParam0, vLocal_79, 1, 0, 0, 1);
	}
	else {
		*uParam0 = object::create_object(uParam0->f_1, vLocal_79, 0, 0, 0);
	}
	bLocal_94 = false;
	fLocal_92 = 0.1f;
	fLocal_88 = fLocal_90;
	fLocal_89 = fLocal_91;
	uParam0->f_23 = 0;
	uParam0->f_24 = 1;
	func_268(uParam0);
	uVar10 = gameplay::get_random_float_in_range(0f, 90f);
	vVar3 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, vLocal_82)};
	vVar6 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_14 + 0.0035f,
													uParam0->f_14.f_1 + fLocal_55, uParam0->f_14.f_2)};
	fVar11 = gameplay::get_heading_from_vector_2d(vVar3.x - vVar6.x, vVar3.y - vVar6.y);
	fVar11 -= 180f;
	fVar9 = 90f;
	uParam0->f_17 = {fVar9, uVar10, fVar11};
	entity::set_entity_rotation(*uParam0, uParam0->f_17, 0, 1);
	iLocal_98 = 0;
	iLocal_100 = 0;
	if (iParam2) {
		func_255("Darts", "Dart_Reticules", &Local_61, 1, 0, 4, 0);
	}
	vVar0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, uParam0->f_8,
													uParam0->f_8.f_1 + fLocal_55, uParam0->f_8.f_2)};
	graphics::get_screen_coord_from_world_coord(vVar0, &Local_70, &Local_70.f_1);
	return true;
}

// Position - 0x17628
bool func_284(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x1763B
void func_285(int iParam0, int iParam1) {
	if (iParam0 == 0) {
		if (!gameplay::is_bit_set(Global_101661, 9)) {
			if (!func_284("DARTS_SHT_USE") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B")) {
				func_399("DARTS_AIM_HLP", -1);
				gameplay::set_bit(&Global_101661, 9);
			}
		}
		else if (iParam1 && !gameplay::is_bit_set(Global_101661, 7)) {
			if (!func_284("DARTS_AIM_HLP") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B")) {
				func_399("DARTS_CLOCK", -1);
				gameplay::set_bit(&Global_101661, 7);
			}
		}
	}
	else if (iParam0 == 1) {
		if (!gameplay::is_bit_set(Global_101661, 8)) {
			if (!func_284("DARTS_SHT_USE") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B")) {
				func_399("DARTS_STD_HLP", -1);
				gameplay::set_bit(&Global_101661, 8);
			}
		}
	}
	else if (iParam0 == 2) {
		if (!iLocal_96 && !func_284("DARTS_SHT_USE") && !func_284("DARTS_INSTR_W") && !func_284("DARTS_INSTR_B")) {
			if (!gameplay::is_bit_set(Global_101661, 2)) {
				func_399("DARTS_FST_HLP", -1);
				gameplay::set_bit(&Global_101661, 2);
			}
			iLocal_96 = 1;
		}
	}
}

// Position - 0x17790
bool func_286(int iParam0, var *uParam1, int *iParam2, var *uParam3) {
	vector3 vVar0;

	switch (*iParam2) {
	case 0:
		vVar0 = {func_289(iParam0)};
		*uParam3 = {entity::get_offset_from_entity_in_world_coords(*uParam1, vVar0)};
		func_288(*uParam3);
		system::settimerb(0);
		*iParam2 = 1;
		break;

	case 1:
		if (system::timerb() > 3000 || controls::is_control_just_pressed(2, 201)) {
			func_287();
			*iParam2 = 0;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x17801
void func_287() {
	cam::set_cam_active_with_interp(iLocal_120, iLocal_132, 2000, 1, 1);
	cam::destroy_cam(iLocal_132, 0);
}

// Position - 0x1781D
void func_288(vector3 vParam0) {
	vector3 vVar0;

	vVar0 = {-5.5606f, -0.0106f, -131.6781f};
	iLocal_132 = cam::create_camera_with_params(26379945, vParam0, vVar0, 65f, 0, 2);
	cam::set_cam_active_with_interp(iLocal_132, iLocal_120, 2000, 1, 1);
}

// Position - 0x1785F
Vector3 func_289(int iParam0) {
	float fVar0;
	vector3 vVar1;

	if (iParam0 == 50) {
		vVar1 = {0f, -0.5f, 0f};
	}
	else {
		fVar0 = func_292(iParam0);
		vVar1.y = -0.5f;
		vVar1.x = func_291(fVar0);
		vVar1.z = func_290(fVar0);
	}
	return vVar1;
}

// Position - 0x178A3
float func_290(float fParam0) {
	float fVar0;
	float fVar1;

	fVar0 = 0.218f;
	fVar1 = system::cos(fParam0) * fVar0;
	return fVar1;
}

// Position - 0x178BF
float func_291(float fParam0) {
	float fVar0;
	float fVar1;

	fVar0 = 0.218f;
	fVar1 = system::sin(fParam0) * fVar0;
	return fVar1;
}

// Position - 0x178DB
var func_292(int iParam0) {
	int iVar0;
	int iVar1;
	float fVar2;
	var uVar3;

	iVar1 = iParam0 / 2;
	iVar0 = 0;
	while (iVar0 < 21) {
		if (iVar1 == iLocal_33[iVar0]) {
			uVar3 = fVar2;
		}
		fVar2 += 18f;
		iVar0++;
	}
	return uVar3;
}

// Position - 0x17917
int func_293(int *iParam0) {
	switch (*iParam0) {
	case 0:
		if (controls::is_control_pressed(2, 228)) {
			func_300(1);
			*iParam0 = 1;
		}
		else {
			return 0;
		}
		break;

	case 1:
		if (controls::is_control_pressed(2, 228)) {
			if (!cam::is_cam_interpolating(iLocal_129)) {
				func_298();
				func_297(&iLocal_336, vLocal_367, vLocal_370, 30f, 10, 10, 3, 15f, 0, 0, -1f, 1);
				*iParam0 = 2;
			}
		}
		else {
			*iParam0 = 3;
		}
		break;

	case 2:
		if (!controls::is_control_pressed(2, 228)) {
			*iParam0 = 3;
		}
		else {
			func_294(&iLocal_336, 1, 1, 0, 0, 1045220557, 0, 1065353216);
		}
		break;

	case 3:
		func_300(0);
		func_480();
		if (cam::does_cam_exist(iLocal_336)) {
			if (cam::is_cam_active(iLocal_336)) {
				cam::set_cam_active(iLocal_336, 0);
			}
			cam::destroy_cam(iLocal_336, 0);
		}
		*iParam0 = 0;
		return 0;
	}
	return 1;
}

// Position - 0x17A09
void func_294(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4, float fParam5, int iParam6,
			  float fParam7) {
	int iVar0[4];
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	vector3 vVar10;
	int iVar13;
	int iVar14;

	controls::_disable_input_group(2);
	func_296(&iVar0[0], &iVar0[1], &iVar0[2], &iVar0[3], 0, 0);
	if (controls::is_look_inverted()) {
		iVar0[3] *= -1;
	}
	if (controls::_is_input_disabled(2)) {
		fVar5 = controls::_0x5B84D09CEC5209C5(2, 239);
		fVar6 = controls::_0x5B84D09CEC5209C5(2, 240);
		fVar7 = fVar5 - uParam0->f_29;
		fVar8 = fVar6 - uParam0->f_30;
		uParam0->f_29 = fVar5;
		uParam0->f_30 = fVar6;
		if (iParam4) {
			iVar0[2] = -system::round(fVar7 * fParam5 * 127f);
			iVar0[3] = -system::round(fVar8 * fParam5 * 127f);
		}
		else {
			iVar0[2] = system::round(controls::_0x5B84D09CEC5209C5(2, 290) * fParam5 * 127f);
			iVar0[3] = system::round(controls::_0x5B84D09CEC5209C5(2, 291) * fParam5 * 127f);
		}
		iVar0[2] = func_295(iVar0[2] + uParam0->f_24, -127, 127);
		iVar0[3] = func_295(iVar0[3] + uParam0->f_25, -127, 127);
	}
	if (uParam0->f_24 == iVar0[2] && uParam0->f_25 == iVar0[3]) {
		if (uParam0->f_27 < gameplay::get_game_timer()) {
			uParam0->f_24 = 0;
			uParam0->f_25 = 0;
			if (controls::_is_input_disabled(2)) {
				iVar0[2] = 0;
				iVar0[3] = 0;
				uParam0->f_28 = 1;
			}
		}
	}
	else {
		uParam0->f_24 = iVar0[2];
		uParam0->f_25 = iVar0[3];
		uParam0->f_27 = gameplay::get_game_timer() + 4000;
		uParam0->f_28 = 0;
	}
	if (iParam2) {
		uParam0->f_8.f_2 = -(system::to_float(iVar0[2]) / 127f) * IntToFloat(uParam0->f_20);
		uParam0->f_8.f_1 = -uParam0->f_8.f_2 * IntToFloat(uParam0->f_22) / IntToFloat(uParam0->f_20);
		uParam0->f_8 = -(system::to_float(iVar0[3]) / 127f) * IntToFloat(uParam0->f_21);
	}
	else {
		uParam0->f_8 = {0f, 0f, 0f};
		uParam0->f_24 = 0;
		uParam0->f_25 = 0;
	}
	fVar9 = 30f * system::timestep();
	vVar10 = {uParam0->f_8 + uParam0->f_11};
	if (controls::_is_input_disabled(2) && iParam2 && !uParam0->f_28) {
		uParam0->f_14 = vVar10.x;
		uParam0->f_14.f_1 = vVar10.y;
		uParam0->f_14.f_2 = vVar10.z;
	}
	else {
		uParam0->f_14 += func_14((vVar10.x - uParam0->f_14) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_1 += func_14((vVar10.y - uParam0->f_14.f_1) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_2 += func_14((vVar10.z - uParam0->f_14.f_2) * 0.05f * fVar9 * fParam7, -3f, 3f);
	}
	if (uParam0->f_26) {
		uParam0->f_14 = func_14(uParam0->f_14, system::to_float(-uParam0->f_21), system::to_float(uParam0->f_21));
		uParam0->f_14.f_1 =
			func_14(uParam0->f_14.f_1, system::to_float(-uParam0->f_22), system::to_float(uParam0->f_22));
		uParam0->f_14.f_2 =
			func_14(uParam0->f_14.f_2, system::to_float(-uParam0->f_20), system::to_float(uParam0->f_20));
	}
	if (controls::_is_input_disabled(0) && iParam1) {
		if (uParam0->f_28) {
			uParam0->f_17 = uParam0->f_7;
		}
	}
	else {
		uParam0->f_17 = uParam0->f_7;
	}
	if (iParam1) {
		if (controls::_is_input_disabled(0)) {
			iVar13 = 40;
			iVar14 = 41;
			if (iParam6) {
				iVar13 = 241;
				iVar14 = 242;
			}
			if (controls::is_disabled_control_just_pressed(0, iVar13)) {
				uParam0->f_17 -= 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			else if (controls::is_disabled_control_just_pressed(0, iVar14)) {
				uParam0->f_17 += 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			if (iParam3) {
				uParam0->f_17 = func_14(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7);
			}
			else {
				uParam0->f_17 = func_14(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7 + uParam0->f_19);
			}
		}
		else if (iParam3) {
			if (system::to_float(iVar0[1]) < 0f) {
				uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
			}
		}
		else {
			uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
		}
	}
	uParam0->f_18 += (uParam0->f_17 - uParam0->f_18) * 0.06f * fVar9;
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4 + uParam0->f_14, uParam0->f_18, 0, 1, 1, 2);
	if (cam::does_cam_exist(*uParam0)) {
		if (cam::is_cam_active(*uParam0)) {
			if (cam::is_cam_rendering(*uParam0)) {
				unk1::_0xAF66DCEE6609B148();
			}
		}
	}
}

// Position - 0x17EBB
int func_295(int iParam0, int iParam1, int iParam2) {
	if (iParam0 > iParam2) {
		return iParam2;
	}
	else if (iParam0 < iParam1) {
		return iParam1;
	}
	return iParam0;
}

// Position - 0x17EE0
void func_296(var *uParam0, var *uParam1, var *uParam2, int *iParam3, int iParam4, int iParam5) {
	*uParam0 = system::floor(controls::_0x5B84D09CEC5209C5(2, 218) * 127f);
	*uParam1 = system::floor(controls::_0x5B84D09CEC5209C5(2, 219) * 127f);
	*uParam2 = system::floor(controls::_0x5B84D09CEC5209C5(2, 220) * 127f);
	*iParam3 = system::floor(controls::_0x5B84D09CEC5209C5(2, 221) * 127f);
	if (iParam4) {
		if (!controls::is_control_enabled(2, 218)) {
			*uParam0 = system::floor(controls::_0x4F8A26A890FD62FB(2, 218) * 127f);
		}
		if (!controls::is_control_enabled(2, 219)) {
			*uParam1 = system::floor(controls::_0x4F8A26A890FD62FB(2, 219) * 127f);
		}
		if (!controls::is_control_enabled(2, 220)) {
			*uParam2 = system::floor(controls::_0x4F8A26A890FD62FB(2, 220) * 127f);
		}
		if (!controls::is_control_enabled(2, 221)) {
			*iParam3 = system::floor(controls::_0x4F8A26A890FD62FB(2, 221) * 127f);
		}
	}
	if (controls::_is_input_disabled(2)) {
		if (iParam5) {
			if (controls::is_look_inverted()) {
				*iParam3 *= -1;
			}
			if (controls::_0xE1615EC03B3BB4FD()) {
				*iParam3 *= -1;
			}
		}
	}
}

// Position - 0x17FE4
void func_297(var *uParam0, vector3 vParam1, vector3 vParam4, float fParam7, int iParam8, int iParam9, int iParam10,
			  float fParam11, int iParam12, int iParam13, float fParam14, int iParam15) {
	uParam0->f_1 = {vParam1};
	uParam0->f_4 = {vParam4};
	uParam0->f_7 = fParam7;
	uParam0->f_20 = iParam8;
	uParam0->f_21 = iParam9;
	uParam0->f_22 = iParam10;
	uParam0->f_8 = {0f, 0f, 0f};
	uParam0->f_11 = {0f, 0f, 0f};
	uParam0->f_14 = {0f, 0f, 0f};
	uParam0->f_17 = fParam7;
	uParam0->f_18 = fParam7;
	uParam0->f_23 = iParam12;
	uParam0->f_19 = fParam11;
	*uParam0 = cam::create_cam("DEFAULT_SCRIPTED_CAMERA", 0);
	cam::set_cam_active(*uParam0, 1);
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4, uParam0->f_7, 0, 1, 1, 2);
	if (!iParam15) {
		cam::shake_cam(*uParam0, "HAND_SHAKE", 0.19f);
	}
	cam::render_script_cams(1, 0, 3000, 1, 0, 0);
	if (fParam14 > 0f) {
		cam::set_cam_near_clip(*uParam0, fParam14);
	}
	if (uParam0->f_23) {
		ui::lock_minimap_angle(iParam13);
	}
	uParam0->f_24 = 0;
	uParam0->f_25 = 0;
	uParam0->f_29 = 0f;
	uParam0->f_30 = 0f;
	uParam0->f_26 = 0;
	uParam0->f_28 = 0;
	uParam0->f_27 = 0;
}

// Position - 0x180DD
void func_298() {
	if (iLocal_292) {
		return;
	}
	func_299();
	controls::_0x3D42B92563939375("Darts Zoom");
	iLocal_292 = 1;
}

// Position - 0x180FF
void func_299() {
	if (iLocal_291 || iLocal_292) {
		controls::_0x643ED62D5EA3BEBD();
		iLocal_291 = 0;
		iLocal_292 = 0;
	}
}

// Position - 0x18122
void func_300(int iParam0) {
	if (iParam0) {
		cam::set_cam_active_with_interp(iLocal_129, iLocal_120, 1000, 1, 1);
	}
	else {
		cam::set_cam_active_with_interp(iLocal_120, iLocal_129, 1000, 1, 1);
	}
}

// Position - 0x1814C
void func_301(var *uParam0) {
	if (uParam0->f_679) {
		if (uParam0->f_681 == 2) {
			uParam0->f_681 = 0;
		}
		uParam0->f_679 = 0;
	}
	switch (uParam0->f_681) {
	case 0:
		func_222(&uParam0->f_62, func_303(uParam0->f_682), "", 2000, 5, 1);
		uParam0->f_681 = 1;
		break;

	case 1:
		if (!func_217(&uParam0->f_62, 0)) {
			func_302(&uParam0->f_62);
			uParam0->f_681 = 2;
		}
		break;

	case 2: break;
	}
}

// Position - 0x181D1
void func_302(var *uParam0) {
	uParam0->f_8 = 0;
	func_402(&uParam0->f_2);
	func_402(&uParam0->f_5);
}

// Position - 0x181EE
char[] func_303(int iParam0) {
	switch (iParam0) {
	case 0: return "DARTS_180_SPLSH";

	case 1: return "DARTS_BE_SPLSH";

	default:
	}
	return "DARTS_BE_SPLSH";
}

// Position - 0x1821B
void func_304(int *iParam0) {
	if (!iLocal_99) {
		if (!controls::is_control_pressed(2, 201)) {
			iLocal_99 = 1;
		}
	}
	if (iLocal_30 == 1 && iLocal_31 < 3 && *iParam0 != 5) {
		if ((controls::is_control_pressed(2, 201) || controls::is_control_just_pressed(2, 223)) && iLocal_99) {
			*iParam0 = 6;
		}
	}
}

// Position - 0x18273
void func_305(var *uParam0, int iParam1) {
	if (!ui::is_pause_menu_active()) {
		if (iParam1 == 0) {
			if (!func_3(&uParam0->f_666, 15) && iLocal_93 <= 0) {
				func_108(&uParam0->f_509, 0, 0, 0, 1);
				func_107(&uParam0->f_509, "DARTS_THROW", 2, 223, 0, 1, 0);
				func_107(&uParam0->f_509, "DARTS_END_QT", 2, 235, 1, 1, 0);
				func_306(&uParam0->f_509, "DARTS_AIM", 2, 20, 1, 0);
				func_107(&uParam0->f_509, "DARTS_FOCUS", 2, 229, 1, 1, 0);
				func_107(&uParam0->f_509, "DARTS_FAST", 2, 227, 1, 1, 0);
				func_107(&uParam0->f_509, "IB_ZOOM", 2, 228, 1, 1, 0);
				func_104(&uParam0->f_509, 1);
				func_312(&uParam0->f_666, 8, 0);
				func_312(&uParam0->f_666, 16, 0);
				func_312(&uParam0->f_666, 23, 0);
			}
			else if (iLocal_93 > 0 && !func_3(&uParam0->f_666, 17)) {
				func_108(&uParam0->f_509, 0, 0, 0, 1);
				func_107(&uParam0->f_509, "DARTS_THROW", 2, 223, 0, 1, 0);
				func_107(&uParam0->f_509, "DARTS_END_QT", 2, 235, 1, 1, 0);
				func_306(&uParam0->f_509, "DARTS_AIM", 2, 20, 1, 0);
				func_107(&uParam0->f_509, "DARTS_FAST", 2, 227, 1, 1, 0);
				func_107(&uParam0->f_509, "IB_ZOOM", 2, 228, 1, 1, 0);
				func_104(&uParam0->f_509, 1);
				func_312(&uParam0->f_666, 8, 0);
				func_312(&uParam0->f_666, 16, 0);
				func_312(&uParam0->f_666, 23, 0);
			}
		}
		else if (!func_3(&uParam0->f_666, 16)) {
			func_108(&uParam0->f_509, 1, 0, 0, 1);
			func_107(&uParam0->f_509, "DARTS_SKIP", 2, 223, 1, 1, 0);
			func_107(&uParam0->f_509, "DARTS_END_QT", 2, 235, 1, 1, 0);
			func_104(&uParam0->f_509, 1);
			func_312(&uParam0->f_666, 16, 1);
			func_312(&uParam0->f_666, 8, 0);
			func_312(&uParam0->f_666, 15, 0);
			func_312(&uParam0->f_666, 17, 0);
			func_312(&uParam0->f_666, 23, 0);
		}
		graphics::_set_screen_draw_position(76, 66);
		graphics::_screen_draw_position_ratio(0f, 0f, 0f, 0f);
		graphics::_screen_draw_position_end();
		func_186(func_103(func_3(&uParam0->f_666, 16), 1, 2));
		func_110(&uParam0->f_509, 200f, 1, 0, 0, 1065353216);
	}
	else if (func_3(&uParam0->f_666, 15) || func_3(&uParam0->f_666, 16) || func_3(&uParam0->f_666, 23)) {
		func_312(&uParam0->f_666, 15, 0);
		func_312(&uParam0->f_666, 16, 0);
		func_312(&uParam0->f_666, 23, 0);
	}
}

// Position - 0x1852F
int func_306(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (*uParam0 == 0) {
		return 0;
	}
	iVar0 = uParam0->f_123;
	if (iVar0 < 8) {
		uParam0->f_2[iVar0 /*15*/] = sParam1;
		uParam0->f_2[iVar0 /*15*/].f_1 = 0;
		uParam0->f_2[iVar0 /*15*/].f_2 = iParam5;
		uParam0->f_2[iVar0 /*15*/].f_12 = 0;
		uParam0->f_2[iVar0 /*15*/].f_13 = 0;
		uParam0->f_2[iVar0 /*15*/].f_14 = 0;
		uParam0->f_2[iVar0 /*15*/].f_3[0 /*2*/] = iParam2;
		uParam0->f_2[iVar0 /*15*/].f_3[0 /*2*/].f_1 = iParam3;
		gameplay::set_bit(&uParam0->f_2[iVar0 /*15*/].f_12, 0);
		if (iParam4 == 1) {
			gameplay::set_bit(&uParam0->f_2[iVar0 /*15*/].f_13, 0);
		}
		uParam0->f_2[iVar0 /*15*/].f_14++;
		uParam0->f_123++;
		return 1;
	}
	return 0;
}

// Position - 0x185FA
void func_307(var *uParam0) {
	if (!ui::is_pause_menu_active()) {
		if (!func_3(&uParam0->f_666, 23)) {
			func_108(&uParam0->f_509, 0, 0, 0, 1);
			func_306(&uParam0->f_509, "IB_MAPMOVE", 2, 21, 1, 0);
			func_107(&uParam0->f_509, "IB_ZOOM", 2, 39, 1, 1, 0);
			func_104(&uParam0->f_509, 1);
			func_312(&uParam0->f_666, 23, 1);
			func_312(&uParam0->f_666, 8, 0);
			func_312(&uParam0->f_666, 16, 0);
			func_312(&uParam0->f_666, 15, 0);
			func_312(&uParam0->f_666, 17, 0);
		}
		func_110(&uParam0->f_509, 1128792064, 1, 0, 1, 1065353216);
	}
	else if (func_3(&uParam0->f_666, 15) || func_3(&uParam0->f_666, 16) || func_3(&uParam0->f_666, 23)) {
		func_312(&uParam0->f_666, 15, 0);
		func_312(&uParam0->f_666, 16, 0);
		func_312(&uParam0->f_666, 23, 0);
		func_312(&uParam0->f_666, 17, 0);
	}
}

// Position - 0x1870C
void func_308(int *iParam0) {
	int iVar0;

	iVar0 = 0;
	if (!iLocal_99) {
		if (!controls::is_control_pressed(2, 201) && !controls::is_control_pressed(2, 202)) {
			iLocal_99 = 1;
		}
		else {
			iLocal_99 = 0;
		}
	}
	if (*iParam0 != 13) {
		if (iVar0) {
			if (iLocal_99 && iLocal_98 == 0) {
				iLocal_99 = 0;
				iVar0 = 0;
				iLocal_307 = 0;
				ui::clear_help(1);
			}
		}
		if (controls::is_control_just_released(2, 235) || controls::is_disabled_control_just_released(2, 235)) {
			if (!iLocal_307) {
				*iParam0 = 14;
				iLocal_307 = 1;
				ui::clear_help(1);
			}
		}
		else if (func_284("DARTS_QUIT")) {
			iVar0 = 1;
		}
		else {
			iVar0 = 0;
			iLocal_307 = 0;
		}
	}
}

// Position - 0x187AF
void func_309(int iParam0) {
	if (!ped::is_ped_injured(iParam0)) {
		func_4(iParam0, "DARTS_BOAST", 0, 4);
	}
}

// Position - 0x187CD
float func_310(int iParam0) {
	if (iParam0 < 10) {
		return 0.107f;
	}
	if (iParam0 < 25) {
		return 0.096f;
	}
	if (iParam0 < 50) {
		return 0.085f;
	}
	if (iParam0 < 70) {
		return 0.075f;
	}
	return 0.064f;
}

// Position - 0x18822
float func_311(int iParam0) {
	if (iParam0 < 10) {
		return 0.08f;
	}
	if (iParam0 < 25) {
		return 0.072f;
	}
	if (iParam0 < 50) {
		return 0.064f;
	}
	if (iParam0 < 70) {
		return 0.056f;
	}
	return 0.048f;
}

// Position - 0x18877
void func_312(int *iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		gameplay::set_bit(iParam0, iParam1);
	}
	else {
		gameplay::clear_bit(iParam0, iParam1);
	}
}

// Position - 0x18897
bool func_313(int iParam0, int *iParam1) {
	if (iParam0 >= 10) {
		if (!gameplay::is_bit_set(Global_101700.f_17929.f_6, 12)) {
			*iParam1 = 12;
			return true;
		}
	}
	return false;
}

// Position - 0x188C3
bool func_314(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 2) {
		iParam0->f_422[iVar0] = 301;
		iParam0->f_425[iVar0] = 301;
		iVar0++;
	}
	iParam0->f_454 = 0;
	iVar0 = 0;
	while (iVar0 < 2) {
		iVar1 = 0;
		while (iVar1 < 3) {
			func_225(&iParam0->f_5[iVar0 /*79*/][iVar1 /*26*/]);
			iVar1++;
		}
		func_224(uParam1, iVar0);
		func_230(uParam1, iVar0, 301);
		iVar0++;
	}
	iLocal_30 = 0;
	iLocal_31 = 0;
	iParam0->f_428 = 0;
	iParam0->f_249.f_3 = 0;
	iLocal_323 = 0;
	iParam0->f_436 = 0;
	iLocal_93 = 0;
	iLocal_300 = 1;
	iLocal_301 = 0;
	iLocal_303 = 0;
	iLocal_95 = 0;
	iParam0->f_458 = 0;
	iParam0->f_456 = 0;
	iLocal_309 = 0;
	func_312(&uParam2->f_666, 6, 0);
	func_320();
	func_318(uParam2);
	if (iParam0->f_457) {
		func_315(iParam0->f_457);
		iParam0->f_457 = 0;
	}
	return true;
}

// Position - 0x189AF
void func_315(bool bParam0) {
	ui::display_radar(0);
	if (cam::is_cam_active(iLocal_122)) {
		cam::set_cam_active(iLocal_122, 0);
	}
	if (cam::is_cam_active(iLocal_126)) {
		cam::set_cam_active(iLocal_126, 0);
	}
	if (cam::is_screen_faded_out()) {
		func_317();
		cam::render_script_cams(1, 0, 3000, 1, 0, 0);
		cam::do_screen_fade_in(500);
	}
	func_316(bParam0);
}

// Position - 0x18A00
void func_316(bool bParam0) {
	if (bParam0) {
		cam::set_cam_active(iLocal_120, 1);
	}
}

// Position - 0x18A14
void func_317() { cam::set_cam_active(iLocal_122, 1); }

// Position - 0x18A23
void func_318(var *uParam0) {
	func_319();
	uParam0->f_670 = 3;
	func_312(&uParam0->f_666, 15, 0);
	func_312(&uParam0->f_666, 16, 0);
	func_312(&uParam0->f_666, 17, 0);
}

// Position - 0x18A59
void func_319() {
	int iVar0;

	Local_164.f_66 = -1;
	Local_164.f_67 = 10f;
	iVar0 = 0;
	while (iVar0 < 8) {
		Local_164.f_9[iVar0 /*7*/].f_3 = -1f;
		Local_164.f_9[iVar0 /*7*/].f_4 = -1f;
		Local_164.f_9[iVar0 /*7*/].f_5 = 0;
		Local_164.f_9[iVar0 /*7*/].f_6 = 0;
		iVar0++;
	}
	Local_164.f_5 = 0;
	Local_164.f_5.f_1 = -1f;
	Local_164.f_5.f_2 = 0;
	Local_164 = 0;
	Local_164.f_1 = 0;
}

// Position - 0x18AC9
void func_320() {
	system::settimera(0);
	iLocal_99 = 0;
	ui::clear_small_prints();
}

// Position - 0x18ADD
void func_321(int iParam0, int iParam1) {
	int iVar0;

	if (!func_323(&iVar0, 0, iParam1)) {
		return;
	}
	if (Global_17290.f_7899) {
		ui::reset_hud_component_values(15);
		Global_17290.f_7899 = 0;
	}
	ui::_0x55598D21339CB998(0f);
	if (Global_17290.f_5498[iVar0]) {
		ui::clear_additional_text(9, 0);
		Global_17290.f_5498[iVar0] = 0;
	}
	if (Global_17290.f_5484[iVar0]) {
		graphics::set_streamed_texture_dict_as_no_longer_needed("CommonMenu");
		Global_17290.f_5484[iVar0] = 0;
	}
	if (Global_17290.f_5491[iVar0]) {
		graphics::set_streamed_texture_dict_as_no_longer_needed("MPShopSale");
		Global_17290.f_5491[iVar0] = 0;
	}
	if (iParam0) {
		func_322(&Global_17290.f_5530[iVar0 /*10*/]);
		Global_17290.f_5591[iVar0] = 0;
	}
	else {
		Global_17290.f_5591[iVar0] = 0;
	}
}

// Position - 0x18B9B
void func_322(int *iParam0) {
	if (uParam0->f_9 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			graphics::set_scaleform_movie_as_no_longer_needed(uParam0);
		}
		*iParam0 = 0;
		iParam0->f_9 = 0;
	}
}

// Position - 0x18BC4
int func_323(int *iParam0, int iParam1, int iParam2) {
	char cVar0[64];
	int iVar16;
	int iVar17;
	int iVar18;

	if (iParam2 == -1) {
		if (network::network_is_game_in_progress() && network::network_get_this_script_is_network_script()) {
			iParam2 = network::_0x638A3A81733086DB();
		}
	}
	StringCopy(&cVar0, script::get_this_script_name(), 64);
	StringIntConCat(&cVar0, iParam2, 64);
	iVar16 = gameplay::get_hash_key(&cVar0);
	iVar18 = -1;
	iVar17 = 0;
	while (iVar17 < 6) {
		if (Global_17290.f_5591[iVar17] == iVar16) {
			*iParam0 = iVar17;
			return 1;
		}
		else if (Global_17290.f_5591[iVar17] == 0) {
			iVar18 = iVar17;
		}
		iVar17++;
	}
	if (iParam1) {
		if (iVar18 != -1) {
			Global_17290.f_5591[iVar18] = iVar16;
			*iParam0 = iVar18;
			return 1;
		}
	}
	return 0;
}

// Position - 0x18C61
void func_324(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	graphics::_push_scaleform_movie_function(*uParam0, "SET_PLAYER_SETS_AND_LEGS");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_push_scaleform_movie_function_parameter_int(iParam3);
	graphics::_push_scaleform_movie_function_parameter_int(iParam4);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x18C91
bool func_325(var *uParam0, int *iParam1, int *iParam2) {
	char *sVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	controls::disable_control_action(2, 200, 1);
	if (!func_3(&uParam0->f_666, 7)) {
		func_382(0, 0, 0, 1);
		func_381(0, -1, 1);
		if (func_380()) {
			if (Global_2594050 == uParam0->f_660) {
				iVar1 = 1;
			}
			else {
				uParam0->f_660 = Global_2594050;
				func_379(uParam0->f_660, 1, 1);
				audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				switch (uParam0->f_660) {
				case 0: sVar0 = "DARTS_LEGD"; break;

				case 1: sVar0 = "DARTS_SETD"; break;

				case 2: sVar0 = ""; break;
				}
				if (ui::does_text_label_exist(sVar0)) {
					func_378(sVar0, 0, 0);
				}
			}
			Global_2594051 = gameplay::get_game_timer() + 300;
		}
		else if (func_377() && gameplay::get_game_timer() > Global_2594051) {
			if (Global_2594050 == uParam0->f_660) {
				iVar2 = func_376(0);
				if (iVar2 == -1 || iVar2 == 1) {
					iVar1 = 1;
				}
			}
			Global_2594051 = gameplay::get_game_timer() + 300;
		}
		if (func_375(&uParam0->f_639)) {
			uParam0->f_660--;
			if (uParam0->f_660 < 0) {
				uParam0->f_660 = uParam0->f_661 - 1;
			}
			func_379(uParam0->f_660, 1, 1);
			audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			switch (uParam0->f_660) {
			case 0: sVar0 = "DARTS_LEGD"; break;

			case 1: sVar0 = "DARTS_SETD"; break;

			case 2: sVar0 = ""; break;
			}
			if (ui::does_text_label_exist(sVar0)) {
				func_378(sVar0, 0, 0);
			}
		}
		if (func_374(&uParam0->f_642)) {
			uParam0->f_660++;
			if (uParam0->f_660 > uParam0->f_661 - 1) {
				uParam0->f_660 = 0;
			}
			func_379(uParam0->f_660, 1, 1);
			audio::play_sound_frontend(-1, "NAV_UP_DOWN", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			switch (uParam0->f_660) {
			case 0: sVar0 = "DARTS_LEGD"; break;

			case 1: sVar0 = "DARTS_SETD"; break;

			case 2: sVar0 = ""; break;
			}
			if (ui::does_text_label_exist(sVar0)) {
				func_378(sVar0, 0, 0);
			}
		}
		if (func_373(&uParam0->f_633) || func_372(&uParam0->f_633, uParam0->f_660, iVar1)) {
			if (uParam0->f_660 == 0) {
				uParam0->f_662--;
				if (uParam0->f_662 < 0) {
					uParam0->f_662 = uParam0->f_663 - 1;
				}
			}
			else if (uParam0->f_660 == 1) {
				uParam0->f_664--;
				if (uParam0->f_664 < 0) {
					uParam0->f_664 = uParam0->f_665 - 1;
				}
			}
			audio::play_sound_frontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			func_354(uParam0);
		}
		if (func_353(&uParam0->f_636) || func_351(&uParam0->f_636, uParam0->f_660, iVar1)) {
			if (uParam0->f_660 == 0) {
				uParam0->f_662++;
				if (uParam0->f_662 > uParam0->f_663 - 1) {
					uParam0->f_662 = 0;
				}
			}
			else if (uParam0->f_660 == 1) {
				uParam0->f_664++;
				if (uParam0->f_664 > uParam0->f_665 - 1) {
					uParam0->f_664 = 0;
				}
			}
			audio::play_sound_frontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			func_354(uParam0);
		}
		if ((controls::is_control_just_pressed(2, 201) || iVar1 == 1) && uParam0->f_660 == 2) {
			*iParam1 = func_350(uParam0->f_662 + 1, 1);
			*iParam2 = func_350(uParam0->f_664 + 1, 0);
			audio::play_sound_frontend(-1, "OK", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			return true;
		}
		func_328(1, -1, 1, 0, 1, -1082130432, 0, 0);
		if (controls::is_control_just_released(2, 202) || func_327()) {
			func_326(0);
			func_312(&uParam0->f_666, 8, 0);
			func_312(&uParam0->f_666, 7, 1);
		}
	}
	else {
		func_2(uParam0);
		if (controls::is_control_just_released(2, 201)) {
			func_35(0);
			*iParam1 = -1;
			return true;
		}
		else if (controls::is_control_just_released(2, 202)) {
			func_354(uParam0);
			func_312(&uParam0->f_666, 7, 0);
		}
	}
	return false;
}

// Position - 0x1909F
void func_326(int iParam0) {
	int iVar0;
	int iVar1;
	float fVar2;

	iVar0 = 0;
	while (iVar0 < 256) {
		StringCopy(&Global_17290.f_73[iVar0 /*6*/], "", 24);
		iVar1 = 0;
		while (iVar1 < 4) {
			Global_17290.f_2124[iVar0 /*5*/][iVar1] = 0;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 32) {
		StringCopy(&Global_2453058[iVar0 /*16*/], "", 64);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 256) {
		Global_17290.f_3918[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4175[iVar0] = 0f;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4433[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4959[iVar0] = 0;
		Global_17290.f_5097[iVar0] = 0;
		Global_17290.f_5226[iVar0] = 0;
		Global_17290.f_5746[iVar0] = 0f;
		Global_17290.f_5355[iVar0] = 0;
		Global_17290.f_5612[iVar0] = 0f;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 5) {
		Global_17290.f_4926[iVar0] = 0;
		Global_17290.f_4938[iVar0] = 0f;
		Global_17290.f_4932[iVar0] = -1f;
		Global_17290.f_4945[iVar0] = 0;
		Global_17290.f_4953[iVar0] = 1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 12) {
		StringCopy(&Global_17290.f_4834[iVar0 /*4*/], "", 16);
		Global_17290.f_4883[iVar0] = -1;
		Global_17290.f_4896[iVar0] = 353;
		Global_17290.f_4909[iVar0] = 32;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 51) {
		StringCopy(&Global_17290.f_5886[iVar0 /*16*/], "", 64);
		StringCopy(&Global_17290.f_6703[iVar0 /*16*/], "", 64);
		iVar0++;
	}
	StringCopy(&Global_2593974.f_16, "", 16);
	Global_2593974.f_20 = -1;
	Global_17290 = 0;
	Global_17290.f_5088 = 0;
	Global_17290.f_5089 = 0;
	Global_17290.f_5090 = 0;
	Global_17290.f_5092 = 0;
	Global_17290.f_5093 = 0;
	Global_17290.f_5094 = 0;
	Global_17290.f_5091 = 0;
	Global_17290.f_5741 = 0;
	Global_17290.f_5606 = 0;
	Global_17290.f_5605 = 0;
	Global_17290.f_5607 = 0;
	StringCopy(&Global_17290.f_4562, "", 16);
	Global_17290.f_4632 = 0;
	Global_17290.f_4633 = 0;
	Global_17290.f_4634 = 0;
	Global_17290.f_4635 = 0;
	Global_17290.f_4636 = 0;
	Global_17290.f_4637 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_4566[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_4638 = 0;
	StringCopy(&Global_2593974.f_21, "", 16);
	Global_2593974.f_61 = 0;
	Global_2593974.f_62 = 0;
	Global_2593974.f_63 = 0;
	Global_2593974.f_64 = 0;
	Global_2593974.f_65 = 0;
	Global_2593974.f_66 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_2593974.f_25[iVar0] = 0;
		iVar0++;
	}
	Global_2593974.f_67 = 0;
	StringCopy(&Global_17290.f_1, "", 16);
	Global_17290.f_4944 = 0f;
	Global_17290.f_68 = 0;
	Global_17290.f_69 = 0;
	Global_17290.f_70 = 0;
	Global_17290.f_71 = 0;
	Global_17290.f_72 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_5[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_5611 = 0;
	Global_17290.f_5610 = 0;
	Global_17290.f_5608 = 0;
	Global_17290.f_5609 = 0;
	Global_17290.f_4639 = 0;
	Global_17290.f_4640 = 0;
	Global_17290.f_5095 = 10;
	Global_17290.f_5096 = 0;
	Global_17290.f_5743 = 0f;
	Global_17290.f_5744 = 0f;
	Global_17290.f_5598 = 0;
	Global_17290.f_5599 = 0;
	Global_17290.f_5600 = 0f;
	Global_17290.f_5601 = 0;
	Global_17290.f_5603 = 0;
	Global_17290.f_5602 = 0;
	Global_17290.f_5604 = 0;
	Global_17290.f_7895 = 0;
	iVar0 = 0;
	while (iVar0 < 2) {
		Global_17290.f_5875[iVar0] = -1;
		Global_17290.f_5878[iVar0] = -1;
		iVar0++;
	}
	Global_17290.f_4951 = 0f;
	Global_17290.f_4922 = 0;
	Global_17290.f_4952 = 0;
	iVar0 = 0;
	while (iVar0 < Global_17290.f_5881) {
		Global_17290.f_5881[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_7874 = 0;
	Global_17290.f_7869 = 0;
	Global_17290.f_7879 = 0;
	Global_17290.f_7884 = 0;
	Global_17290.f_7889 = 0;
	Global_17290.f_7891 = 0;
	Global_17290.f_7897 = 0;
	Global_17287 = 0.05f;
	Global_17288 = 0.05f;
	Global_17289 = 0.225f;
	fVar2 = graphics::_get_aspect_ratio(0);
	if (iParam0) {
		Global_17289 = 0.225f * 16f / 9f / fVar2;
	}
	else if (fVar2 < 1.77777f) {
		Global_17289 = 0.225f * 16f / 9f / fVar2;
	}
	else {
		Global_17289 = 0.225f;
	}
}

// Position - 0x1955D
int func_327() {
	if (controls::_is_input_disabled(2)) {
		if (controls::is_control_just_pressed(2, 238)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1957C
void func_328(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, float fParam5, int iParam6,
			  int iParam7) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	int iVar18;
	int iVar19;
	int iVar20;
	int iVar21;
	int iVar22;
	int iVar23;
	int iVar24;
	int iVar25;
	int iVar26;
	int iVar27;
	int iVar28;
	int iVar29;
	int iVar30;
	bool bVar31;
	bool bVar32;
	float fVar33;
	float fVar34;
	float fVar35;
	float *fVar36;
	vector3 vVar37;
	bool bVar40;
	float fVar41;
	float fVar42;
	float fVar43;
	float fVar44;
	float fVar45;
	int *iVar46;
	int *iVar47;
	int *iVar48;
	float fVar49;
	int iVar50;
	int iVar51;
	bool bVar52;
	int iVar53;
	int iVar54;
	float fVar55;
	float fVar56;
	float fVar57;
	float fVar58;
	int iVar59;
	int iVar60;
	float fVar61;
	float fVar62;
	float fVar63;
	char cVar64[64];
	char cVar80[64];
	float fVar96;
	int iVar97;
	float fVar98;
	float fVar99;
	int iVar100;
	int iVar101;
	int iVar102;
	int iVar103;
	int iVar104;

	if (!func_323(&iVar0, 0, iParam1)) {
		return;
	}
	if (iVar0 == -1) {
	}
	if (!func_347(0, iParam6)) {
		return;
	}
	graphics::_set_screen_draw_position(76, 84);
	graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
	fVar56 = 0f;
	fVar57 = 0f;
	if (Global_17290) {
		if (func_18(29, 1, 1, &fVar35, &fVar36, iParam7)) {
			fVar56 = fVar36;
			fVar57 = fVar35;
			fVar56 += 0f;
		}
		else {
			Global_17290 = 0;
		}
	}
	if (gameplay::get_hash_key(&Global_17290.f_1) == gameplay::get_hash_key("HIDE")) {
		fVar58 = Global_17288;
	}
	else {
		fVar58 = Global_17288 + fVar56 + 0.034722f + 0f;
	}
	if (fParam5 == -1f) {
		fParam5 = Global_17289;
	}
	fVar61 = 1f;
	if (iParam7) {
		graphics::_get_active_screen_resolution(&iVar59, &iVar60);
		fVar62 = graphics::_get_aspect_ratio(0);
		if (func_20()) {
			iVar59 = system::round(system::to_float(iVar60) * fVar62);
		}
		fVar63 = system::to_float(iVar59) / system::to_float(iVar60);
		fVar61 = fVar63 / fVar62;
		if (func_20()) {
			fVar61 = 1f;
		}
		iVar59 = system::round(system::to_float(iVar59) / fVar61);
		iVar60 = system::round(system::to_float(iVar60) / fVar61);
	}
	else {
		graphics::get_screen_resolution(&iVar59, &iVar60);
	}
	iVar5 = 0;
	while (iVar5 < 2) {
		if (iVar5 == 1 && Global_17290.f_5598) {
			if (gameplay::get_hash_key(&Global_17290.f_1) == gameplay::get_hash_key("HIDE")) {
				fVar49 = Global_17288;
			}
			else {
				if (Global_17290) {
					StringCopy(&cVar64, func_24(29), 64);
					StringCopy(&cVar80, func_21(29, 1), 64);
					if (gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
						func_346(Global_17287, Global_17288, fParam5, fVar56 - 0f, 0, 0, 0, 255);
						graphics::draw_sprite(&cVar64, &cVar80, Global_17287 + fParam5 * 0.5f,
											  Global_17288 + (fVar56 - 0f) * 0.5f, fVar57, fVar56 - 0f, 0f, 255, 255,
											  255, 255, 0);
					}
					else {
						graphics::draw_sprite(&cVar64, &cVar80, Global_17287 + fParam5 * 0.5f,
											  Global_17288 + (fVar56 - 0f) * 0.5f, fParam5, fVar56 - 0f, 0f, 255, 255,
											  255, 255, 0);
					}
				}
				if (Global_17290.f_7869) {
					iVar1 = Global_17290.f_7865;
					iVar2 = Global_17290.f_7866;
					iVar3 = Global_17290.f_7867;
					iVar4 = Global_17290.f_7868;
				}
				else {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 255;
				}
				func_346(Global_17287, Global_17288 + fVar56, fParam5, 0.034722f, iVar1, iVar2, iVar3, iVar4);
				fVar49 = Global_17288 + fVar56 + 0.034722f + 0f;
				if (gameplay::get_hash_key(&Global_17290.f_1) != 0) {
					func_345();
					ui::begin_text_command_display_text(&Global_17290.f_1);
					iVar15 = 0;
					iVar16 = 0;
					iVar17 = 0;
					iVar18 = 0;
					iVar14 = 0;
					while (iVar14 < Global_17290.f_68) {
						if (Global_17290.f_5[iVar14] == 2) {
							ui::add_text_component_integer(Global_17290.f_10[iVar15]);
							iVar15++;
						}
						else if (Global_17290.f_5[iVar14] == 3) {
							ui::add_text_component_float(Global_17290.f_14[iVar16], Global_17290.f_18[iVar16]);
							iVar16++;
						}
						else if (Global_17290.f_5[iVar14] == 1) {
							ui::add_text_component_substring_text_label(&Global_17290.f_22[iVar17 /*4*/]);
							iVar17++;
						}
						else if (Global_17290.f_5[iVar14] == 8) {
							ui::add_text_component_substring_text_label(&Global_17290.f_22[iVar17 /*4*/]);
							iVar17++;
						}
						else if (Global_17290.f_5[iVar14] == 5) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 6) {
							ui::add_text_component_substring_text_label(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 7) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 9) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						iVar14++;
					}
					ui::end_text_command_display_text(Global_17287 + 0.00390625f, Global_17288 + fVar56 + 0.00416664f,
													  0);
				}
				if (Global_17290.f_5601 > Global_17290.f_5095) {
					if (Global_17290.f_5604 != 0) {
						func_345();
						func_343(Global_17287 + fParam5 - 0.00390625f -
									 func_344("CM_ITEM_COUNT", Global_17290.f_5604, Global_17290.f_5603),
								 Global_17288 + fVar56 + 0.00416664f, "CM_ITEM_COUNT", Global_17290.f_5604,
								 Global_17290.f_5603);
					}
				}
			}
			iVar6 = Global_17290.f_5605;
			iVar9 = 0;
			fVar96 = fVar49;
			if (Global_17290.f_7879) {
				iVar1 = Global_17290.f_7875;
				iVar2 = Global_17290.f_7876;
				iVar3 = Global_17290.f_7877;
				iVar4 = Global_17290.f_7878;
			}
			else {
				ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
			}
			while (iVar9 < Global_17290.f_5095 && iVar6 <= Global_17290.f_5088) {
				if (iVar6 >= 0) {
					if (Global_17290.f_5355[iVar6]) {
						if (Global_17290.f_5226[iVar6] && iVar6 != Global_17290.f_5605) {
							fVar49 += 0.00277776f;
						}
						fVar55 = 0.034722f;
						if (Global_17290.f_5612[iVar6] != 0f) {
							fVar55 = Global_17290.f_5612[iVar6];
						}
						fVar49 += fVar55;
						iVar9++;
					}
				}
				iVar6++;
			}
			if (iParam3) {
				if (iVar9 <= 1) {
					fVar55 = 0.034722f;
					fVar49 += fVar55;
					iVar9++;
					if (Global_17290.f_5088 <= 1) {
						Global_17290.f_5088++;
					}
					iVar53 = 1;
				}
			}
			graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
								  fVar96 + (fVar49 - fVar96) * 0.5f - 0.00138888f, fParam5, fVar49 - fVar96, 0f, 255,
								  255, 255, 255, 0);
			if (Global_17290.f_5601 > Global_17290.f_5095) {
				if (Global_17290.f_7884) {
					iVar1 = Global_17290.f_7880;
					iVar2 = Global_17290.f_7881;
					iVar3 = Global_17290.f_7882;
					iVar4 = Global_17290.f_7883;
				}
				else {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 204;
				}
				func_346(Global_17287, fVar49 + 0f, fParam5, 0.034722f, iVar1, iVar2, iVar3, iVar4);
				vVar37 = {graphics::get_texture_resolution("CommonMenu", "shop_arrows_upANDdown")};
				vVar37.x *= 0.5f / fVar61;
				vVar37.y *= 0.5f / fVar61;
				if (Global_17290.f_7897) {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 255;
				}
				else {
					ui::get_hud_colour(1, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "shop_arrows_upANDdown", Global_17287 + fParam5 * 0.5f,
									  fVar49 + 0f + 0.034722f * 0.5f, vVar37.x / 1280f * fVar61,
									  vVar37.y / 720f * fVar61, 0f, iVar1, iVar2, iVar3, iVar4, 0);
				fVar49 += 0f + 0.034722f;
			}
			if (gameplay::get_hash_key(&Global_17290.f_4562) != 0 && Global_17290.f_4636 != -1) {
				fVar49 += 0.00277776f * 2f;
				fVar41 = Global_17287 + 0.0046875f;
				if (Global_17290.f_4638 != 0) {
					func_18(Global_17290.f_4638, 1, 1, &fVar35, &fVar36, iParam7);
					fVar41 = Global_17287 + fVar35 + 0.00078125f * 4f - 0.00078125f * 1f;
				}
				func_342(fVar41);
				ui::_begin_text_command_line_count(&Global_17290.f_4562);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_17290.f_4632) {
					if (Global_17290.f_4566[iVar14] == 2) {
						ui::add_text_component_integer(Global_17290.f_4571[iVar15]);
						iVar15++;
					}
					else if (Global_17290.f_4566[iVar14] == 3) {
						ui::add_text_component_float(Global_17290.f_4575[iVar16], Global_17290.f_4579[iVar16]);
						iVar16++;
					}
					else if (Global_17290.f_4566[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					iVar14++;
				}
				iVar6 = ui::_end_text_command_get_line_count(fVar41, fVar49 + 0.00277776f);
				ui::get_hud_colour(2, &iVar1, &iVar2, &iVar3, &iVar4);
				func_346(Global_17287, fVar49 - 0.00277776f, fParam5, 0.00277776f, iVar1, iVar2, iVar3, iVar4);
				if (Global_17290.f_7889) {
					iVar1 = Global_17290.f_7885;
					iVar2 = Global_17290.f_7886;
					iVar3 = Global_17290.f_7887;
					iVar4 = Global_17290.f_7888;
				}
				else {
					ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
									  fVar49 +
										  (ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) +
										   0.00138888f * 13f + 0.00138888f * 5f * IntToFloat(iVar6 - 1)) *
											  0.5f -
										  0.00138888f,
									  fParam5,
									  ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
										  0.00138888f * 5f * IntToFloat(iVar6 - 1),
									  0f, iVar1, iVar2, iVar3, iVar4, 0);
				func_342(fVar41);
				ui::begin_text_command_display_text(&Global_17290.f_4562);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_17290.f_4632) {
					if (Global_17290.f_4566[iVar14] == 2) {
						ui::add_text_component_integer(Global_17290.f_4571[iVar15]);
						iVar15++;
					}
					else if (Global_17290.f_4566[iVar14] == 3) {
						ui::add_text_component_float(Global_17290.f_4575[iVar16], Global_17290.f_4579[iVar16]);
						iVar16++;
					}
					else if (Global_17290.f_4566[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					iVar14++;
				}
				ui::end_text_command_display_text(fVar41, fVar49 + 0.00277776f, 0);
				if (Global_17290.f_4638 != 0) {
					func_18(Global_17290.f_4638, 1, 1, &fVar35, &fVar36, iParam7);
					func_341(Global_17290.f_4638, 1, &iVar46, &iVar47, &iVar48);
					graphics::draw_sprite(func_24(Global_17290.f_4638), func_21(Global_17290.f_4638, 1),
										  Global_17287 + fVar35 * 0.5f + 0.00078125f * 2f,
										  fVar49 + fVar36 * 0.5f - 0.00138888f * 4f, fVar35, fVar36, 0f, iVar46, iVar47,
										  iVar48, 255, 0);
				}
				fVar49 += ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
						  0.00138888f * 5f * IntToFloat(iVar6 - 1);
				if (Global_17290.f_4636 > 0) {
					if (gameplay::get_game_timer() - Global_17290.f_4637 > Global_17290.f_4636) {
						StringCopy(&Global_17290.f_4562, "", 16);
						Global_17290.f_4636 = -1;
					}
				}
			}
			if (gameplay::get_hash_key(&Global_2593974.f_21) != 0 && Global_2593974.f_65 != -1) {
				fVar49 += 0.00277776f * 2f;
				fVar41 = Global_17287 + 0.0046875f;
				if (Global_2593974.f_67 != 0) {
					func_18(Global_2593974.f_67, 1, 1, &fVar35, &fVar36, iParam7);
					fVar41 = Global_17287 + fVar35 + 0.00078125f * 4f - 0.00078125f * 1f;
				}
				func_342(fVar41);
				ui::_begin_text_command_line_count(&Global_2593974.f_21);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_2593974.f_61) {
					if (Global_2593974.f_25[iVar14] == 2) {
						ui::add_text_component_integer(Global_2593974.f_30[iVar15]);
						iVar15++;
					}
					else if (Global_2593974.f_25[iVar14] == 3) {
						ui::add_text_component_float(Global_2593974.f_34[iVar16], Global_2593974.f_38[iVar16]);
						iVar16++;
					}
					else if (Global_2593974.f_25[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					iVar14++;
				}
				iVar6 = ui::_end_text_command_get_line_count(fVar41, fVar49 + 0.00277776f);
				ui::get_hud_colour(2, &iVar1, &iVar2, &iVar3, &iVar4);
				func_346(Global_17287, fVar49 - 0.00277776f, fParam5, 0.00277776f, iVar1, iVar2, iVar3, iVar4);
				if (Global_17290.f_7889) {
					iVar1 = Global_17290.f_7885;
					iVar2 = Global_17290.f_7886;
					iVar3 = Global_17290.f_7887;
					iVar4 = Global_17290.f_7888;
				}
				else {
					ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
									  fVar49 +
										  (ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) +
										   0.00138888f * 13f + 0.00138888f * 5f * IntToFloat(iVar6 - 1)) *
											  0.5f -
										  0.00138888f,
									  fParam5,
									  ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
										  0.00138888f * 5f * IntToFloat(iVar6 - 1),
									  0f, iVar1, iVar2, iVar3, iVar4, 0);
				func_342(fVar41);
				ui::begin_text_command_display_text(&Global_2593974.f_21);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_2593974.f_61) {
					if (Global_2593974.f_25[iVar14] == 2) {
						ui::add_text_component_integer(Global_2593974.f_30[iVar15]);
						iVar15++;
					}
					else if (Global_2593974.f_25[iVar14] == 3) {
						ui::add_text_component_float(Global_2593974.f_34[iVar16], Global_2593974.f_38[iVar16]);
						iVar16++;
					}
					else if (Global_2593974.f_25[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					iVar14++;
				}
				ui::end_text_command_display_text(fVar41, fVar49 + 0.00277776f, 0);
				if (Global_2593974.f_67 != 0) {
					func_18(Global_2593974.f_67, 1, 1, &fVar35, &fVar36, iParam7);
					func_341(Global_2593974.f_67, 1, &iVar46, &iVar47, &iVar48);
					graphics::draw_sprite(func_24(Global_2593974.f_67), func_21(Global_2593974.f_67, 1),
										  Global_17287 + fVar35 * 0.5f + 0.00078125f * 2f,
										  fVar49 + fVar36 * 0.5f - 0.00138888f * 4f, fVar35, fVar36, 0f, iVar46, iVar47,
										  iVar48, 255, 0);
				}
				fVar49 += ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
						  0.00138888f * 5f * IntToFloat(iVar6 - 1);
				if (Global_2593974.f_65 > 0) {
					if (gameplay::get_game_timer() - Global_2593974.f_66 > Global_2593974.f_65) {
						StringCopy(&Global_2593974.f_21, "", 16);
						Global_2593974.f_65 = -1;
					}
				}
			}
			func_335(iVar59, iParam1, 0, 0, 0, 0, iParam4, 1, 0);
			graphics::_set_screen_draw_position(76, 84);
			graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
		}
		if (iVar5 == 1 || !Global_17290.f_5598) {
			iVar19 = 0;
			iVar23 = 0;
			iVar20 = 0;
			iVar21 = 0;
			iVar22 = 0;
			iVar9 = 0;
			iVar10 = 0;
			iVar11 = 0;
			iVar12 = 0;
			iVar13 = 0;
			iVar97 = Global_17290.f_5088;
			if (Global_17290.f_5599) {
				iVar97 = Global_17290.f_5602 - 1;
			}
			fVar98 = 0f;
			fVar99 = 0f;
			iVar7 = 0;
			while (iVar7 <= iVar97) {
				fVar55 = 0.034722f;
				if (Global_17290.f_5612[iVar6] != 0f) {
					fVar55 = Global_17290.f_5612[iVar6];
				}
				if (Global_17290.f_5599) {
					iVar6 = Global_17290.f_7520[iVar7];
				}
				else {
					iVar6 = iVar7;
				}
				iVar12 = iVar13;
				bVar32 = false;
				if (iVar6 >= Global_17290.f_5605 && iVar9 < Global_17290.f_5095) {
					bVar32 = true;
					if (Global_17290.f_5606 == iVar6) {
						fVar99 = fVar98;
					}
					if (Global_17290.f_5226[iVar6]) {
						iVar12++;
					}
					fVar34 = fVar58 + fVar98 + 0.00277776f * IntToFloat(iVar12) + 0.00277776f;
				}
				Global_17290.f_5746[iVar6] = fVar34;
				fVar33 = Global_17287 + 0.0046875f;
				bVar40 = false;
				bVar31 = Global_17290.f_5606 == iVar6;
				if (bVar31 && iVar5 == 1 && bVar32) {
					iVar100 = 255;
					iVar101 = 255;
					iVar102 = 255;
					iVar103 = 255;
					if (Global_17290.f_7891) {
						ui::get_hud_colour(Global_17290.f_7890, &iVar100, &iVar101, &iVar102, &iVar103);
					}
					else {
						ui::get_hud_colour(1, &iVar100, &iVar101, &iVar102, &iVar103);
					}
					graphics::draw_sprite("CommonMenu", "Gradient_Nav", Global_17287 + fParam5 * 0.5f,
										  fVar58 + fVar99 + 0.00277776f * IntToFloat(iVar12) + fVar55 * 0.5f, fParam5,
										  fVar55, 0f, iVar100, iVar101, iVar102, iVar103, 0);
					Global_17290.f_5744 = fVar34;
				}
				if (iVar53 && iVar7 == iVar97) {
					func_333(bVar31, 1, 0, 0, 0, 0, 0);
					ui::begin_text_command_display_text("DFLT_MNU_OPT");
					ui::end_text_command_display_text(fVar33, fVar34, 0);
					bVar40 = true;
				}
				else {
					iVar8 = 0;
					while (iVar8 < Global_17290.f_5096) {
						if (gameplay::is_bit_set(Global_17290.f_4959[iVar6], iVar8) ||
							Global_17290.f_4926[iVar8] == 5) {
							if (Global_17290.f_5599) {
								iVar19 = Global_17290.f_7536[iVar9 * Global_17290.f_5096 + iVar8];
								iVar20 = Global_17290.f_7577[iVar9 * Global_17290.f_5096 + iVar8];
								iVar21 = Global_17290.f_7618[iVar9 * Global_17290.f_5096 + iVar8];
								iVar22 = Global_17290.f_7659[iVar9 * Global_17290.f_5096 + iVar8];
								iVar23 = Global_17290.f_7700[iVar9 * Global_17290.f_5096 + iVar8];
							}
							else {
								Global_17290.f_7536[iVar9 * Global_17290.f_5096 + iVar8] = iVar19;
								Global_17290.f_7577[iVar9 * Global_17290.f_5096 + iVar8] = iVar20;
								Global_17290.f_7618[iVar9 * Global_17290.f_5096 + iVar8] = iVar21;
								Global_17290.f_7659[iVar9 * Global_17290.f_5096 + iVar8] = iVar22;
								Global_17290.f_7700[iVar9 * Global_17290.f_5096 + iVar8] = iVar23;
							}
							iVar104 = 0;
							iVar54 = 0;
							if (Global_17290.f_5878[0] != -1) {
								if (iVar6 * 5 + iVar8 == Global_17290.f_5875[0]) {
									iVar54 = 1;
									iVar104 = 0;
								}
							}
							if (Global_17290.f_5878[1] != -1) {
								if (iVar6 * 5 + iVar8 == Global_17290.f_5875[1]) {
									iVar54 = 1;
									iVar104 = 1;
								}
							}
							if (Global_17290.f_4932[iVar8] != -1f) {
								fVar33 = Global_17287 + 0.0046875f + Global_17290.f_4932[iVar8];
							}
							if (iVar8 < 4 && Global_17290.f_4932[iVar8 + 1] != -1f &&
								fVar33 < Global_17290.f_4932[iVar8 + 1]) {
								fVar45 = Global_17290.f_4932[iVar8 + 1] - fVar33;
							}
							else {
								fVar45 = Global_17287 + Global_17289 - 0.0046875f - fVar33;
							}
							if (Global_17290.f_4945[iVar8] && Global_17290.f_5741 && bVar31) {
								bVar52 = true;
							}
							else {
								bVar52 = false;
							}
							switch (Global_17290.f_4926[iVar8]) {
							case 0: break;

							case 1:
								iVar24 = iVar19;
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										fVar42 = 0f;
										fVar43 = 0f;
										iVar25 = 0;
										iVar26 = 0;
										iVar27 = 0;
										iVar28 = 0;
										iVar29 = 0;
										if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
											iVar50 = 0;
											iVar51 = 0;
											iVar14 = 0;
											while (iVar14 < 4) {
												if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5 ||
													Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
													iVar51 = 1;
												}
												else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
													iVar50 = 1;
												}
												iVar14++;
											}
											func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
													 iVar54, iVar104, iVar51, iVar50);
											ui::_begin_text_command_width(&Global_17290.f_73[iVar24 /*6*/]);
										}
										iVar14 = 0;
										while (iVar14 < 4) {
											if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
												iVar25++;
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
												}
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
												iVar25++;
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
												}
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_integer(
														Global_17290.f_3918[iVar20 + iVar26]);
												}
												iVar26++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_float(Global_17290.f_4175[iVar21 + iVar27],
																				 Global_17290.f_4304[iVar21 + iVar27]);
												}
												iVar27++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
												iVar28++;
											}
											iVar14++;
										}
										if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
											fVar42 = ui::_end_text_command_get_width(1);
										}
										if (iVar28 > 0) {
											iVar14 = 0;
											while (iVar14 < iVar28) {
												if (func_18(Global_17290.f_4433[iVar22 + iVar14], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar43 += fVar35;
													if (iVar14 > 0) {
														fVar43 -= 0.00078125f * 4f;
													}
													if (Global_17290.f_4433[iVar22 + iVar14] == 2 ||
														Global_17290.f_4433[iVar22 + iVar14] == 48) {
														fVar43 -= 0.00078125f * 5f;
													}
												}
												iVar14++;
											}
										}
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - (fVar42 + fVar43) + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - (fVar42 + fVar43) * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
										Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8] = fVar43;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
										fVar43 = Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_18(26, 1, 0, &fVar35, &fVar36, iParam7)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_18(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(26), func_21(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_18(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_18(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(27), func_21(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									iVar25 = 0;
									iVar26 = 0;
									iVar27 = 0;
									iVar28 = 0;
									iVar29 = 0;
									iVar30 = 0;
									if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
										iVar50 = 0;
										iVar51 = 0;
										iVar14 = 0;
										while (iVar14 < 4) {
											if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5 ||
												Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
												iVar51 = 1;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
												iVar50 = 1;
											}
											iVar14++;
										}
										func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												 iVar54, 0, iVar51, iVar50);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_332(bVar31);
										}
										ui::begin_text_command_display_text(&Global_17290.f_73[iVar24 /*6*/]);
									}
									iVar14 = 0;
									while (iVar14 < 4) {
										if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
											iVar25++;
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
											}
											iVar30 = 1;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
											iVar25++;
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
											}
											iVar30 = 8;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 5;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 6;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 7;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 9;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_integer(Global_17290.f_3918[iVar20 + iVar26]);
											}
											iVar26++;
											iVar30 = 2;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_float(Global_17290.f_4175[iVar21 + iVar27],
																			 Global_17290.f_4304[iVar21 + iVar27]);
											}
											iVar27++;
											iVar30 = 3;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
											if (Global_17290.f_4433[iVar22 + iVar28] == 2 ||
												Global_17290.f_4433[iVar22 + iVar28] == 48) {
												if (func_18(Global_17290.f_4433[iVar22 + iVar28], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar41 += fVar35 * 0.5f;
													if (func_18(Global_17290.f_4433[iVar22 + iVar28], bVar31, 1,
																&fVar35, &fVar36, iParam7)) {
														func_341(Global_17290.f_4433[iVar22 + iVar28], bVar31, &iVar46,
																 &iVar47, &iVar48);
														if (Global_17290.f_4953[iVar8] == 2) {
															graphics::draw_sprite(
																func_24(Global_17290.f_4433[iVar22 + iVar28]),
																func_21(Global_17290.f_4433[iVar22 + iVar28], bVar31),
																fVar33 + fVar41 - 0.00078125f * 8f + 0.00078125f * 4f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else {
															graphics::draw_sprite(
																func_24(Global_17290.f_4433[iVar22 + iVar28]),
																func_21(Global_17290.f_4433[iVar22 + iVar28], bVar31),
																fVar33 + fVar41 - 0.00078125f * 8f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														fVar41 += 0.00078125f * 3f;
													}
												}
											}
											iVar28++;
											iVar30 = 4;
										}
										iVar14++;
									}
									if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
										if (iVar30 == 4 && Global_17290.f_4953[iVar8] == 2) {
											ui::end_text_command_display_text(fVar33 + fVar41 + 0.00078125f * 7f,
																			  fVar34, 0);
										}
										else {
											ui::end_text_command_display_text(fVar33 + fVar41, fVar34, 0);
										}
									}
									if (iVar28 > 0) {
										fVar41 += 6f * 0.00078125f;
										iVar14 = 0;
										while (iVar14 < iVar28) {
											if (Global_17290.f_4433[iVar22 + iVar14] != 2 &&
												Global_17290.f_4433[iVar22 + iVar14] != 48) {
												if (func_18(Global_17290.f_4433[iVar22 + iVar14], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar41 += fVar35 * 0.5f;
													if (func_18(Global_17290.f_4433[iVar22 + iVar14], bVar31, 1,
																&fVar35, &fVar36, iParam7)) {
														func_341(Global_17290.f_4433[iVar22 + iVar14], bVar31, &iVar46,
																 &iVar47, &iVar48);
														if (Global_17290.f_4433[iVar22 + iVar14] == 30) {
															graphics::draw_sprite(
																func_24(Global_17290.f_4433[iVar22 + iVar14]),
																func_21(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																Global_17287 + fVar35 * 0.5f,
																fVar34 + 0.00277776f + fVar36 * 0.5f -
																	0.00078125f * 11f,
																fVar35, fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else if (Global_17290.f_4953[iVar8] == 2) {
															graphics::draw_sprite(
																func_24(Global_17290.f_4433[iVar22 + iVar14]),
																func_21(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																fVar33 + fVar41 + fVar42 - 0.00078125f * 8f +
																	0.00078125f * 4f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else {
															graphics::draw_sprite(
																func_24(Global_17290.f_4433[iVar22 + iVar14]),
																func_21(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																fVar33 + fVar41 + fVar42 - 0.00078125f * 12f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
													}
													fVar41 += 12f * 0.00078125f;
												}
											}
											iVar14++;
										}
									}
								}
								bVar40 = true;
								iVar19++;
								iVar14 = 0;
								while (iVar14 < 4) {
									if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
										iVar19++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
										iVar19++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
										iVar20++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
										iVar21++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
										iVar22++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
										iVar23++;
									}
									iVar14++;
								}
								break;

							case 2:
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												 iVar54, 0, 0, 0);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_332(bVar31);
										}
										ui::_begin_text_command_width("NUMBER");
										ui::add_text_component_integer(Global_17290.f_3918[iVar20]);
										fVar42 = ui::_end_text_command_get_width(1);
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - fVar42 + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - fVar42 * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_18(26, 1, 0, &fVar35, &fVar36, iParam7)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_18(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(26), func_21(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_18(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_18(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(27), func_21(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24], iVar54,
											 0, 0, 0);
									func_331(fVar33 + fVar41, fVar34, "NUMBER", Global_17290.f_3918[iVar20], 0);
								}
								bVar40 = true;
								iVar20++;
								break;

							case 3:
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												 iVar54, 0, 0, 0);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_332(bVar31);
										}
										ui::_begin_text_command_width("NUMBER");
										ui::add_text_component_float(Global_17290.f_4175[iVar21],
																	 Global_17290.f_4304[iVar21]);
										fVar42 = ui::_end_text_command_get_width(1);
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - fVar42 + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - fVar42 * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_18(26, 1, 0, &fVar35, &fVar36, 0)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_18(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(26), func_21(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_18(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_18(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_341(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_24(27), func_21(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									func_333(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24], iVar54,
											 0, 0, 0);
									func_330(fVar33 + fVar41, fVar34, "NUMBER", Global_17290.f_4175[iVar21],
											 Global_17290.f_4304[iVar21]);
								}
								bVar40 = true;
								iVar21++;
								break;

							case 4:
								if (iVar5 == 1 && bVar32) {
									if (func_18(Global_17290.f_4433[iVar22], bVar31, 0, &fVar35, &fVar36, iParam7)) {
										if (!Global_17290.f_5599) {
											fVar43 = fVar35;
											fVar41 = 0f;
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 += fVar45 - fVar43 + 0.00078125f * 1f;
											}
											else if (Global_17290.f_4953[iVar8] == 0) {
												fVar41 += (fVar45 - fVar33) * 0.5f - fVar43 * 0.5f;
											}
											Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
											Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8] = fVar43;
										}
										else {
											fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
											fVar43 = Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8];
										}
										if (bVar52) {
											if (func_18(26, 1, 0, &fVar35, &fVar36, iParam7)) {
												if (Global_17290.f_4953[iVar8] == 2) {
													fVar41 -= fVar35 * 2f;
												}
												fVar44 = fVar35 * 0.5f;
												if (func_18(26, 1, 1, &fVar35, &fVar36, iParam7)) {
													func_341(26, 1, &iVar46, &iVar47, &iVar48);
													graphics::draw_sprite(func_24(26), func_21(26, 1),
																		  fVar33 + fVar41 + fVar44,
																		  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																		  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
												}
											}
											if (func_18(27, 1, 0, &fVar35, &fVar36, iParam7)) {
												fVar41 += fVar35;
												fVar44 = fVar35 * 0.5f;
												if (func_18(27, 1, 1, &fVar35, &fVar36, iParam7)) {
													func_341(27, 1, &iVar46, &iVar47, &iVar48);
													graphics::draw_sprite(func_24(27), func_21(27, 1),
																		  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																		  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																		  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
												}
											}
										}
										if (func_18(Global_17290.f_4433[iVar22], bVar31, 1, &fVar35, &fVar36,
													iParam7)) {
											func_341(Global_17290.f_4433[iVar22], bVar31, &iVar46, &iVar47, &iVar48);
											graphics::draw_sprite(func_24(Global_17290.f_4433[iVar22]),
																  func_21(Global_17290.f_4433[iVar22], bVar31),
																  fVar33 + fVar41 + fVar35 * 0.5f,
																  fVar34 - 0.00277776f + fVar55 * 0.5f,
																  fVar35 * func_329(Global_17290.f_4433[iVar22]),
																  fVar36 * func_329(Global_17290.f_4433[iVar22]), 0f,
																  iVar46, iVar47, iVar48, 255, 0);
										}
									}
								}
								bVar40 = true;
								iVar22++;
								break;

							case 5: bVar40 = true; break;
							}
							if (Global_17290.f_4926[iVar8] == 5) {
								if (Global_17290.f_4938[iVar8] > 0.05f) {
									fVar33 += Global_17290.f_4938[iVar8];
								}
								else {
									fVar33 += 0.05f;
								}
							}
							else {
								fVar33 += Global_17290.f_4938[iVar8];
								if (Global_17290.f_4945[iVar8]) {
									if (func_18(26, 1, 1, &fVar35, &fVar36, iParam7)) {
										fVar33 -= fVar35;
									}
								}
							}
						}
						else {
							fVar33 += Global_17290.f_4938[iVar8];
						}
						iVar8++;
					}
				}
				if (bVar40) {
					if (bVar32) {
						Global_17290.f_7520[iVar9] = iVar6;
						Global_17290.f_5607 = iVar6;
						iVar9++;
						if (Global_17290.f_5226[iVar6]) {
							iVar13++;
						}
						if (Global_17290.f_5612[iVar6] != 0f) {
							fVar98 += Global_17290.f_5612[iVar6];
						}
						else {
							fVar98 += 0.034722f;
						}
					}
					if (!Global_17290.f_5598) {
						Global_17290.f_5355[iVar6] = 1;
						if (Global_17290.f_5097[iVar6]) {
							if (bVar31) {
								Global_17290.f_5604 = 0;
							}
						}
						else {
							iVar11++;
							if (bVar31) {
								Global_17290.f_5604 = iVar11;
							}
						}
						iVar10++;
					}
				}
				iVar7++;
			}
			if (!Global_17290.f_5598) {
				Global_17290.f_5600 = fVar58 + fVar98 + 0.00277776f * IntToFloat(iVar12);
				Global_17290.f_5603 = iVar11;
				Global_17290.f_5601 = iVar10;
				Global_17290.f_5598 = 1;
			}
		}
		iVar5++;
	}
	if (!Global_17290.f_5599) {
		Global_17290.f_5602 = iVar9;
		Global_17290.f_5599 = 1;
	}
	Global_17290.f_5743 = fVar49;
	Global_17290.f_5745 = gameplay::get_game_timer();
	ui::_0x55598D21339CB998(Global_17290.f_5743);
	if (!Global_17290.f_7864) {
		func_37();
	}
	Global_17290.f_7864 = 0;
	if (iParam2) {
		ui::hide_hud_component_this_frame(10);
	}
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(8);
	if (iParam0) {
		func_186(1);
	}
	graphics::_screen_draw_position_end();
}

// Position - 0x1C0E3
float func_329(int iParam0) {
	switch (iParam0) {
	case 35:
	case 34:
	case 47:
	case 46:
	case 42:
	case 36:
	case 37:
	case 39:
	case 40:
	case 38:
	case 50:
	case 43:
	case 44:
	case 45: return 0.85f;
	}
	return 1f;
}

// Position - 0x1C152
void func_330(float fParam0, float fParam1, char *sParam2, float fParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_float(fParam3, iParam4);
	ui::end_text_command_display_text(fParam0, fParam1, 0);
}

// Position - 0x1C171
void func_331(float fParam0, float fParam1, char *sParam2, int iParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_integer(iParam3);
	ui::end_text_command_display_text(fParam0, fParam1, iParam4);
}

// Position - 0x1C18F
void func_332(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;

	if (iParam0) {
		ui::get_hud_colour(Global_17290.f_7892[0], &iVar0, &iVar1, &iVar2, &uVar3);
	}
	else {
		ui::get_hud_colour(Global_17290.f_7892[1], &iVar0, &iVar1, &iVar2, &uVar3);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, 255);
}

// Position - 0x1C1D5
void func_333(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (iParam2) {
		if (iParam3) {
			func_334(Global_17290.f_5878[iParam4], &iVar0, &iVar1, &iVar2);
			if (iVar0 < 20 && iVar1 < 20 && iVar2 < 20) {
				if (iParam0 == 0) {
					ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
				}
			}
			else if (iVar0 > 230 && iVar1 > 230 && iVar2 > 230) {
				if (iParam0) {
					iVar0 = 0;
					iVar1 = 0;
					iVar2 = 0;
				}
			}
			ui::set_text_colour(iVar0, iVar1, iVar2, 255);
		}
		else if (iParam1) {
			if (iParam0) {
				ui::get_hud_colour(14, &iVar0, &iVar1, &iVar2, &iVar3);
				ui::set_text_colour(iVar0, iVar1, iVar2, 255);
			}
			else {
				ui::get_hud_colour(12, &iVar0, &iVar1, &iVar2, &iVar3);
				ui::set_text_colour(iVar0, iVar1, iVar2, 255);
			}
		}
		else if (iParam0) {
			ui::set_text_colour(155, 155, 155, 255);
		}
		else {
			ui::set_text_colour(155, 155, 155, 255);
		}
	}
	else if (iParam1) {
		if (iParam0) {
			ui::set_text_colour(0, 0, 0, system::floor(255f * 0.8f));
		}
		else {
			ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
			ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
		}
	}
	else if (iParam0) {
		ui::set_text_colour(155, 155, 155, 255);
	}
	else {
		ui::set_text_colour(155, 155, 155, 255);
	}
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_justification(1);
	if (iParam5) {
		ui::set_text_scale(0f, 0.425f);
		ui::set_text_font(4);
	}
	else if (iParam6) {
		ui::set_text_scale(0f, 0.425f);
		ui::set_text_font(6);
	}
	else {
		ui::set_text_font(0);
	}
	ui::set_text_wrap(0f, 1f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x1C383
void func_334(int iParam0, int *iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		*iParam1 = 8;
		*iParam2 = 8;
		*iParam3 = 8;
		break;

	case 1:
		*iParam1 = 37;
		*iParam2 = 37;
		*iParam3 = 39;
		break;

	case 22:
		*iParam1 = 140;
		*iParam2 = 146;
		*iParam3 = 154;
		break;

	case 23:
		*iParam1 = 91;
		*iParam2 = 93;
		*iParam3 = 94;
		break;

	case 6:
		*iParam1 = 81;
		*iParam2 = 84;
		*iParam3 = 89;
		break;

	case 111:
		*iParam1 = 240;
		*iParam2 = 240;
		*iParam3 = 240;
		break;

	case 28:
		*iParam1 = 150;
		*iParam2 = 8;
		*iParam3 = 0;
		break;

	case 34:
		*iParam1 = 38;
		*iParam2 = 3;
		*iParam3 = 6;
		break;

	case 88:
		*iParam1 = 245;
		*iParam2 = 137;
		*iParam3 = 15;
		break;

	case 45:
		*iParam1 = 74;
		*iParam2 = 22;
		*iParam3 = 7;
		break;

	case 56:
		*iParam1 = 45;
		*iParam2 = 58;
		*iParam3 = 53;
		break;

	case 58:
		*iParam1 = 71;
		*iParam2 = 120;
		*iParam3 = 60;
		break;

	case 54:
		*iParam1 = 77;
		*iParam2 = 98;
		*iParam3 = 104;
		break;

	case 73:
		*iParam1 = 14;
		*iParam2 = 49;
		*iParam3 = 109;
		break;

	case 68:
		*iParam1 = 22;
		*iParam2 = 34;
		*iParam3 = 72;
		break;

	case 140:
		*iParam1 = 0;
		*iParam2 = 174;
		*iParam3 = 239;
		break;

	case 131:
		*iParam1 = 255;
		*iParam2 = 183;
		*iParam3 = 0;
		break;

	case 90:
		*iParam1 = 142;
		*iParam2 = 140;
		*iParam3 = 70;
		break;

	case 97:
		*iParam1 = 156;
		*iParam2 = 141;
		*iParam3 = 113;
		break;

	case 89:
		*iParam1 = 145;
		*iParam2 = 115;
		*iParam3 = 71;
		break;

	case 105:
		*iParam1 = 98;
		*iParam2 = 68;
		*iParam3 = 40;
		break;

	case 100:
		*iParam1 = 124;
		*iParam2 = 27;
		*iParam3 = 68;
		break;

	case 99:
		*iParam1 = 114;
		*iParam2 = 42;
		*iParam3 = 63;
		break;

	case 136:
		*iParam1 = 246;
		*iParam2 = 151;
		*iParam3 = 153;
		break;

	case 49:
		*iParam1 = 32;
		*iParam2 = 32;
		*iParam3 = 44;
		break;

	case 146:
		*iParam1 = 26;
		*iParam2 = 1;
		*iParam3 = 23;
		break;

	default:
		*iParam1 = 255;
		*iParam2 = 255;
		*iParam3 = 255;
		break;
	}
}

// Position - 0x1C60D
void func_335(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, bool bParam6, int iParam7,
			  int iParam8) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_323(&iVar0, 0, iParam1)) {
		return;
	}
	iParam0 = iParam0;
	if (iParam3 && !func_347(iParam4, iParam8)) {
		return;
	}
	if (func_339()) {
		return;
	}
	if (network::_network_is_text_chat_active()) {
		return;
	}
	if (iParam7 == 0) {
		if (func_336(player::player_id(), 0)) {
			return;
		}
	}
	if (gameplay::is_pc_version()) {
		if (gameplay::update_onscreen_keyboard() == 0 || network::_network_is_text_chat_active()) {
			return;
		}
	}
	if (Global_17290.f_4639 != 0) {
		if (controls::_0x6CD79468A1E595C6(2)) {
			iVar1 = 0;
			while (iVar1 < Global_17290.f_4639) {
				if (Global_17290.f_4896[iVar1] != 353) {
					StringCopy(&Global_17290.f_4641[iVar1 /*16*/],
							   controls::get_control_instructional_button(2, Global_17290.f_4896[iVar1], 1), 64);
				}
				else if (Global_17290.f_4909[iVar1] != 32) {
					StringCopy(&Global_17290.f_4641[iVar1 /*16*/],
							   controls::_0x80C2FD58D720C801(2, Global_17290.f_4909[iVar1], 1), 64);
				}
				iVar1++;
			}
			Global_17290.f_4640 = 0;
		}
		if (!Global_17290.f_4640) {
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "CLEAR_ALL");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_MAX_WIDTH");
			graphics::_push_scaleform_movie_function_parameter_float(1f - Global_17290.f_4951 / 100f);
			graphics::_pop_scaleform_movie_function_void();
			if (gameplay::is_pc_version()) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "TOGGLE_MOUSE_BUTTONS");
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
			}
			iVar1 = 0;
			while (iVar1 < Global_17290.f_4639) {
				if (gameplay::get_hash_key(&Global_17290.f_4834[iVar1 /*4*/]) != gameplay::get_hash_key("PREV")) {
					graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_DATA_SLOT");
					graphics::_push_scaleform_movie_function_parameter_int(iVar1);
					func_13(&Global_17290.f_4641[iVar1 /*16*/]);
					iVar2 = iVar1 + 1;
					while (iVar2 < 12 && gameplay::get_hash_key(&Global_17290.f_4834[iVar2 /*4*/]) ==
											 gameplay::get_hash_key("PREV")) {
						func_13(&Global_17290.f_4641[iVar2 /*16*/]);
						iVar2++;
					}
					if (Global_17290.f_4883[iVar1] == -1) {
						func_12(&Global_17290.f_4834[iVar1 /*4*/]);
					}
					else {
						graphics::begin_text_command_scaleform_string(&Global_17290.f_4834[iVar1 /*4*/]);
						if (iParam5) {
							ui::add_text_component_substring_time(iParam2, 70);
						}
						else {
							ui::add_text_component_integer(iParam2);
						}
						graphics::end_text_command_scaleform_string();
					}
					if (gameplay::is_pc_version()) {
						if (Global_17290.f_4896[iVar1] != 353 && gameplay::is_bit_set(Global_17290.f_4922, iVar1)) {
							graphics::_push_scaleform_movie_function_parameter_bool(1);
							graphics::_push_scaleform_movie_function_parameter_int(Global_17290.f_4896[iVar1]);
						}
						else {
							graphics::_push_scaleform_movie_function_parameter_bool(0);
							graphics::_push_scaleform_movie_function_parameter_int(353);
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
				iVar1++;
			}
			if (gameplay::get_hash_key(&Global_2593974.f_16) != gameplay::get_hash_key("")) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(Global_17290.f_4639);
				func_13(&Global_2593974);
				if (Global_2593974.f_20 == -1) {
					func_12(&Global_2593974.f_16);
				}
				else {
					graphics::begin_text_command_scaleform_string(&Global_2593974.f_16);
					if (iParam5) {
						ui::add_text_component_substring_time(iParam2, 70);
					}
					else {
						ui::add_text_component_integer(iParam2);
					}
					graphics::end_text_command_scaleform_string();
				}
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_BACKGROUND_COLOUR");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(80);
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "DRAW_INSTRUCTIONAL_BUTTONS");
			if (Global_17290.f_4952) {
				graphics::_push_scaleform_movie_function_parameter_int(1);
			}
			else {
				graphics::_push_scaleform_movie_function_parameter_int(0);
			}
			graphics::_pop_scaleform_movie_function_void();
			Global_17290.f_4640 = 1;
		}
		iVar1 = 0;
		while (iVar1 < Global_17290.f_4639) {
			if (Global_17290.f_4883[iVar1] != -1) {
				if (iParam2 > 0) {
					graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/],
															 "OVERRIDE_RESPAWN_TEXT");
					graphics::_push_scaleform_movie_function_parameter_int(iVar1);
					graphics::begin_text_command_scaleform_string(&Global_17290.f_4834[iVar1 /*4*/]);
					if (iParam5) {
						ui::add_text_component_substring_time(iParam2, 70);
					}
					else {
						ui::add_text_component_integer(iParam2);
					}
					graphics::end_text_command_scaleform_string();
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar1++;
		}
		if (Global_2593974.f_20 != -1) {
			if (iParam2 > 0) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "OVERRIDE_RESPAWN_TEXT");
				graphics::_push_scaleform_movie_function_parameter_int(iVar1);
				graphics::begin_text_command_scaleform_string(&Global_2593974.f_16);
				if (iParam5) {
					ui::add_text_component_substring_time(iParam2, 70);
				}
				else {
					ui::add_text_component_integer(iParam2);
				}
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
		}
		graphics::_set_screen_draw_position(76, 66);
		graphics::_screen_draw_position_ratio(0f, 0f, 0f, 0f);
		if (bParam6) {
			if (!Global_17290.f_7899) {
				ui::set_hud_component_position(15, 0f, -0.0375f);
				Global_17290.f_7899 = 1;
			}
		}
		else if (Global_17290.f_7899) {
			ui::reset_hud_component_values(15);
			Global_17290.f_7899 = 0;
		}
		graphics::_screen_draw_position_end();
		if (Global_17290.f_4925) {
			graphics::_set_screen_draw_position(82, 66);
			graphics::_screen_draw_position_ratio(0f, 0f, 0f, 0f);
			graphics::draw_scaleform_movie(Global_17290.f_5530[iVar0 /*10*/], Global_17290.f_4923, Global_17290.f_4924,
										   1f, 1f, 255, 255, 255, 255, 0);
			graphics::_screen_draw_position_end();
		}
		else {
			graphics::draw_scaleform_movie_fullscreen(Global_17290.f_5530[iVar0 /*10*/], 255, 255, 255, 255, 0);
		}
	}
}

// Position - 0x1CAE9
bool func_336(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_337(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x1CB34
int func_337(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_338();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x1CB75
var func_338() { return Global_1312735; }

// Position - 0x1CB81
bool func_339() {
	vector3 vVar0;

	if (Global_14443.f_1 > 3) {
		return true;
	}
	if (func_340()) {
		vVar0 = {0f, -500f, 0f};
		mobile::get_mobile_phone_position(&vVar0);
		if (Global_14388 == 0) {
			if (vVar0.y > -119f) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (vVar0.y > -101f) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0x1CBEF
bool func_340() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	return false;
}

// Position - 0x1CC09
void func_341(int iParam0, int iParam1, int *iParam2, int *iParam3, int *iParam4) {
	var uVar0;

	ui::get_hud_colour(1, iParam2, iParam3, iParam4, &uVar0);
	switch (iParam0) {
	case 28:
		*iParam2 = 194;
		*iParam3 = 80;
		*iParam4 = 80;
		break;

	case 15:
	case 4:
	case 16:
	case 26:
	case 27:
	case 35:
	case 34:
	case 47:
	case 46:
	case 42:
	case 36:
	case 37:
	case 50:
	case 39:
	case 40:
	case 38:
	case 43:
	case 44:
	case 45:
	case 49:
		if (iParam1) {
			*iParam2 = 0;
			*iParam3 = 0;
			*iParam4 = 0;
		}
		break;
	}
}

// Position - 0x1CCC9
void func_342(float fParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
	ui::set_text_font(0);
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_leading(2);
	ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
	ui::set_text_wrap(fParam0, Global_17287 + Global_17289 - 0.0046875f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x1CD28
void func_343(float fParam0, float fParam1, char *sParam2, int iParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_integer(iParam3);
	ui::add_text_component_integer(iParam4);
	ui::end_text_command_display_text(fParam0, fParam1, 0);
}

// Position - 0x1CD4B
float func_344(char *sParam0, int iParam1, int iParam2) {
	if (!gameplay::is_string_null(sParam0)) {
		if (gameplay::get_hash_key(sParam0) == 0) {
			return 0f;
		}
	}
	else {
		return 0f;
	}
	func_345();
	ui::_begin_text_command_width(sParam0);
	ui::add_text_component_integer(iParam1);
	ui::add_text_component_integer(iParam2);
	return ui::_end_text_command_get_width(1);
}

// Position - 0x1CD8D
void func_345() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
	if (Global_17290.f_7874) {
		iVar0 = Global_17290.f_7870;
		iVar1 = Global_17290.f_7871;
		iVar2 = Global_17290.f_7872;
		iVar3 = Global_17290.f_7873;
	}
	ui::set_text_font(0);
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
	ui::set_text_wrap(Global_17287 + 0.0046875f, Global_17287 + Global_17289 - 0.0046875f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x1CE17
void func_346(float fParam0, float fParam1, float fParam2, float fParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7) {
	graphics::draw_rect(fParam0 + fParam2 * 0.5f, fParam1 + fParam3 * 0.5f, fParam2, fParam3, iParam4, iParam5, iParam6,
						iParam7, 0);
}

// Position - 0x1CE46
int func_347(int iParam0, bool bParam1) {
	if (Global_2433125.f_1385.f_688 != 0) {
		return 1;
	}
	if (!cam::is_screen_faded_in() || func_349(8, -1) && func_348() != 64 ||
		ui::get_pause_menu_state() != 0 && !bParam1 || streaming::is_player_switch_in_progress() && !iParam0 ||
		network::_0x2EAC52B4019E2782() || Global_69962 || Global_17290.f_7898 || ui::is_warning_message_active() ||
		Global_91543.f_1361) {
		return 0;
	}
	return 1;
}

// Position - 0x1CEE3
int func_348() { return Global_1315168; }

// Position - 0x1CEEF
var func_349(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x1CF2A
int func_350(int iParam0, int iParam1) {
	if (iParam1) {
		switch (iParam0) {
		case 1: return 1;

		case 2: return 3;

		case 3: return 5;

		default:
		}
	}
	else {
		switch (iParam0) {
		case 1: return 1;

		case 2: return 3;

		case 3: return 6;

		case 4: return 9;

		case 5: return 11;

		case 6: return 13;

		case 7: return 15;
		}

	default:
	}
	return 0;
}

// Position - 0x1CFB1
int func_351(int *iParam0, int iParam1, int iParam2) {
	if (!controls::_is_input_disabled(2)) {
		return 0;
	}
	if (iParam2 == 0) {
		return 0;
	}
	if (func_376(0) == 1 && Global_2594050 == iParam1) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return 1;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return 1;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return 0;
}

// Position - 0x1D029
void func_352(int *iParam0) {
	if (!func_401(iParam0)) {
		func_415(iParam0);
	}
}

// Position - 0x1D041
int func_353(int *iParam0) {
	float fVar0;

	fVar0 = 0f;
	if (!controls::_is_input_disabled(2)) {
		fVar0 = controls::get_control_normal(2, 218);
	}
	if (fVar0 > 0.8f || controls::is_control_pressed(2, 190) || controls::is_disabled_control_pressed(2, 190)) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return 1;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return 1;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return 0;
}

// Position - 0x1D0C6
void func_354(var *uParam0) {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;

	func_326(0);
	ui::get_hud_colour(141, &uVar0, &uVar1, &uVar2, &uVar3);
	func_371(uVar0, uVar1, uVar2, uVar3, 1);
	func_370(1, 2, 0, 0, 0);
	func_369(1, 2, 1, 1, 1);
	func_368(0, 1, 0, 0, 0);
	func_367("DARTS_TITLE");
	func_365(1, "ShopUI_Title_Darts", "ShopUI_Title_Darts");
	func_361(0, "DARTS_LEGS", 0, 1, 0, 0);
	func_358(0, func_350(uParam0->f_662 + 1, 1), 0);
	func_361(1, "DARTS_SETS", 0, 1, 0, 0);
	func_358(1, func_350(uParam0->f_664 + 1, 0), 0);
	func_357(2, 141, 141, 1);
	func_361(2, "DARTS_START", 0, 1, 0, 0);
	func_356(0);
	func_379(uParam0->f_660, 1, 1);
	if (uParam0->f_660 != 2) {
		func_378(func_102(uParam0->f_660 == 0, "DARTS_LEGD", "DARTS_SETD"), 0, 0);
	}
	func_355(201, "ITEM_SELECT", -1, 0);
	func_355(202, "IB_QUIT", -1, 0);
}

// Position - 0x1D1BC
void func_355(int iParam0, char *sParam1, int iParam2, int iParam3) {
	char *sVar0;

	sVar0 = controls::get_control_instructional_button(2, iParam0, 1);
	if (Global_17290.f_4639 >= 12) {
		StringCopy(&Global_2593974, sVar0, 64);
		StringCopy(&Global_2593974.f_16, sParam1, 16);
		Global_2593974.f_20 = iParam2;
		return;
		return;
	}
	if (!iParam3) {
		gameplay::set_bit(&Global_17290.f_4922, Global_17290.f_4639);
	}
	StringCopy(&Global_17290.f_4641[Global_17290.f_4639 /*16*/], sVar0, 64);
	StringCopy(&Global_17290.f_4834[Global_17290.f_4639 /*4*/], sParam1, 16);
	Global_17290.f_4883[Global_17290.f_4639] = iParam2;
	Global_17290.f_4896[Global_17290.f_4639] = iParam0;
	Global_17290.f_4909[Global_17290.f_4639] = 32;
	Global_17290.f_4639++;
}

// Position - 0x1D271
void func_356(int iParam0) { Global_17290.f_5605 = iParam0; }

// Position - 0x1D281
void func_357(int iParam0, int iParam1, int iParam2, int iParam3) {
	Global_17290.f_7895 = iParam3;
	Global_17290.f_7892[0] = iParam1;
	Global_17290.f_7892[1] = iParam2;
	Global_17290.f_7896 = iParam0;
}

// Position - 0x1D2AF
void func_358(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	float fVar1;
	float fVar2;
	float *fVar3;
	float fVar4;

	if (Global_17290.f_5088 > iParam0) {
		return;
	}
	if (Global_17290.f_5088 >= 128) {
		return;
	}
	if (Global_17290.f_5092 >= 256) {
		return;
	}
	if (Global_17290.f_5610 < Global_17290.f_5608) {
		return;
	}
	if (Global_17290.f_5088 != iParam0) {
		Global_17290.f_5088 = iParam0;
		Global_17290.f_5089 = 0;
	}
	iVar0 = Global_17290.f_4926[Global_17290.f_5089];
	if (iVar0 != 2) {
		while (Global_17290.f_5089 < 4 && iVar0 != 2) {
			Global_17290.f_5089++;
			iVar0 = Global_17290.f_4926[Global_17290.f_5089];
		}
		if (iVar0 != 2) {
			return;
		}
	}
	Global_17290.f_3918[Global_17290.f_5092] = iParam1;
	Global_17290.f_5092++;
	fVar1 = func_360("NUMBER", iParam1);
	if (Global_17290.f_4945[Global_17290.f_5089]) {
		func_18(26, 1, 0, &fVar2, &fVar3, 0);
		fVar1 += fVar2 * 2f;
	}
	if (fVar1 > Global_17290.f_4938[Global_17290.f_5089]) {
		Global_17290.f_4938[Global_17290.f_5089] = fVar1;
	}
	if (iParam2) {
		fVar4 = func_359("NUMBER", iParam1);
		if (fVar4 > Global_17290.f_5612[iParam0]) {
			Global_17290.f_5612[iParam0] = fVar4;
		}
	}
	gameplay::set_bit(&Global_17290.f_4959[iParam0], Global_17290.f_5089);
	Global_17290.f_5089++;
	Global_17290.f_5611 = 2;
}

// Position - 0x1D42E
var func_359(char *sParam0, int iParam1) {
	if (!ui::does_text_label_exist(sParam0)) {
	}
	if (iParam1 == 0) {
	}
	return ui::_get_text_scale_height(0.35f, 0);
}

// Position - 0x1D450
float func_360(char *sParam0, int iParam1) {
	if (!ui::does_text_label_exist(sParam0)) {
		return 0f;
	}
	func_333(1, 1, 0, 0, 0, 0, 0);
	ui::_begin_text_command_width(sParam0);
	ui::add_text_component_integer(iParam1);
	return ui::_end_text_command_get_width(1);
}

// Position - 0x1D482
void func_361(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float *fVar3;
	float fVar4;

	if (Global_17290.f_5088 > iParam0) {
		return;
	}
	if (Global_17290.f_5088 >= 128) {
		return;
	}
	if (Global_17290.f_5090 >= 256) {
		return;
	}
	if (Global_17290.f_5610 < Global_17290.f_5608) {
		return;
	}
	if (Global_17290.f_5088 != iParam0) {
		Global_17290.f_5088 = iParam0;
		Global_17290.f_5089 = 0;
	}
	iVar0 = Global_17290.f_4926[Global_17290.f_5089];
	if (iVar0 != 1) {
		while (Global_17290.f_5089 < 4 && iVar0 != 1) {
			Global_17290.f_5089++;
			iVar0 = Global_17290.f_4926[Global_17290.f_5089];
		}
		if (iVar0 != 1) {
			return;
		}
	}
	StringCopy(&Global_17290.f_73[Global_17290.f_5090 /*6*/], sParam1, 24);
	if (!gameplay::is_string_null_or_empty(sParam1) && !ui::does_text_label_exist(sParam1)) {
	}
	Global_17290.f_1610[Global_17290.f_5090] = iParam3;
	Global_17290.f_1867[Global_17290.f_5090] = iParam4;
	Global_17290.f_5090++;
	if (!iParam3) {
		func_364(Global_17290.f_5088, 1);
	}
	else {
		func_364(Global_17290.f_5088, 0);
	}
	if (iParam2 == 0) {
		fVar1 = func_363(&Global_17290.f_73[Global_17290.f_5090 /*6*/]);
		if (Global_17290.f_4945[Global_17290.f_5089]) {
			func_18(26, 1, 0, &fVar2, &fVar3, 0);
			fVar1 += fVar2 * 2f;
		}
		if (fVar1 > Global_17290.f_4938[Global_17290.f_5089]) {
			Global_17290.f_4938[Global_17290.f_5089] = fVar1;
		}
	}
	if (iParam5) {
		if (iParam2 == 0) {
			fVar4 = func_362(&Global_17290.f_73[Global_17290.f_5090 /*6*/]);
			if (fVar4 > Global_17290.f_5612[iParam0]) {
				Global_17290.f_5612[iParam0] = fVar4;
			}
		}
	}
	gameplay::set_bit(&Global_17290.f_4959[iParam0], Global_17290.f_5089);
	Global_17290.f_5089++;
	Global_17290.f_5611 = 1;
	Global_17290.f_5609 = Global_17290.f_5090 - 1;
	Global_17290.f_5610 = 0;
	Global_17290.f_5608 = iParam2;
}

// Position - 0x1D68E
var func_362(char *sParam0) {
	if (!ui::does_text_label_exist(sParam0)) {
	}
	return ui::_get_text_scale_height(0.35f, 0);
}

// Position - 0x1D6AA
float func_363(char *sParam0) {
	if (!gameplay::is_string_null(sParam0)) {
		if (gameplay::get_hash_key(sParam0) == 0) {
			return 0f;
		}
	}
	else {
		return 0f;
	}
	func_333(0, 1, 0, 0, 0, 0, 0);
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1);
}

// Position - 0x1D6E7
void func_364(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = system::floor(system::to_float(iParam0) / 32f);
	if (iParam1) {
		gameplay::set_bit(&Global_17290.f_5881[iVar0], iParam0 - iVar0 * 32);
	}
	else {
		gameplay::clear_bit(&Global_17290.f_5881[iVar0], iParam0 - iVar0 * 32);
	}
}

// Position - 0x1D733
void func_365(int iParam0, char *sParam1, char *sParam2) {
	Global_17290 = iParam0;
	func_366(29, sParam1, sParam2);
}

// Position - 0x1D74A
void func_366(int iParam0, char *sParam1, char *sParam2) {
	StringCopy(&Global_17290.f_5886[iParam0 /*16*/], sParam1, 64);
	StringCopy(&Global_17290.f_6703[iParam0 /*16*/], sParam2, 64);
}

// Position - 0x1D76E
void func_367(char *sParam0) {
	int iVar0;

	StringCopy(&Global_17290.f_1, sParam0, 16);
	Global_17290.f_68 = 0;
	Global_17290.f_69 = 0;
	Global_17290.f_70 = 0;
	Global_17290.f_71 = 0;
	Global_17290.f_72 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_5[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x1D7B9
void func_368(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4945[0] = iParam0;
	Global_17290.f_4945[1] = iParam1;
	Global_17290.f_4945[2] = iParam2;
	Global_17290.f_4945[3] = iParam3;
	Global_17290.f_4945[4] = iParam4;
}

// Position - 0x1D7F8
void func_369(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4953[0] = iParam0;
	Global_17290.f_4953[1] = iParam1;
	Global_17290.f_4953[2] = iParam2;
	Global_17290.f_4953[3] = iParam3;
	Global_17290.f_4953[4] = iParam4;
}

// Position - 0x1D837
void func_370(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4926[0] = iParam0;
	Global_17290.f_4926[1] = iParam1;
	Global_17290.f_4926[2] = iParam2;
	Global_17290.f_4926[3] = iParam3;
	Global_17290.f_4926[4] = iParam4;
	Global_17290.f_5096 = 0;
	if (iParam0 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam1 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam2 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam3 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam4 != 0) {
		Global_17290.f_5096++;
	}
}

// Position - 0x1D8E1
void func_371(var uParam0, var uParam1, var uParam2, var uParam3, int iParam4) {
	Global_17290.f_7869 = iParam4;
	Global_17290.f_7865 = uParam0;
	Global_17290.f_7866 = uParam1;
	Global_17290.f_7867 = uParam2;
	Global_17290.f_7868 = uParam3;
}

// Position - 0x1D911
int func_372(int *iParam0, int iParam1, int iParam2) {
	if (!controls::_is_input_disabled(2)) {
		return 0;
	}
	if (iParam2 == 0) {
		return 0;
	}
	if (func_376(0) == -1 && Global_2594050 == iParam1) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return 1;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return 1;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return 0;
}

// Position - 0x1D989
int func_373(int *iParam0) {
	float fVar0;

	fVar0 = 0f;
	if (!controls::_is_input_disabled(2)) {
		fVar0 = controls::get_control_normal(2, 218);
	}
	if (fVar0 < -0.8f || controls::is_control_pressed(2, 189)) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return 1;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return 1;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return 0;
}

// Position - 0x1DA01
bool func_374(int *iParam0) {
	float fVar0;

	fVar0 = 0f;
	if (!controls::_is_input_disabled(2)) {
		fVar0 = controls::get_control_normal(2, 219);
	}
	if (fVar0 > 0.8f || controls::is_control_pressed(2, 187)) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return true;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return true;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return false;
}

// Position - 0x1DA79
bool func_375(int *iParam0) {
	float fVar0;

	fVar0 = 0f;
	if (!controls::_is_input_disabled(2)) {
		fVar0 = controls::get_control_normal(2, 219);
	}
	if (fVar0 < -0.8f || controls::is_control_pressed(2, 188)) {
		if (!func_401(iParam0)) {
			func_352(iParam0);
			return true;
		}
		else if (func_7(iParam0) > 0.25f) {
			func_415(iParam0);
			return true;
		}
	}
	else if (func_401(iParam0)) {
		func_402(iParam0);
	}
	return false;
}

// Position - 0x1DAF1
int func_376(float fParam0) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	fVar6 = 0.02f;
	fVar0 = 0.05f;
	fVar2 = fVar0 + Global_17289;
	fVar1 = Global_17290.f_5600 - IntToFloat(Global_17290.f_5602) * 0.034722f;
	fVar5 = fVar0 + fParam0;
	graphics::_set_screen_draw_position(76, 84);
	graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
	graphics::_0x6DD8F5AA635EB4B2(fVar0, fVar1, &fVar0, &fVar1);
	graphics::_0x6DD8F5AA635EB4B2(fVar2, fVar3, &fVar2, &fVar3);
	graphics::_screen_draw_position_end();
	fVar4 = fVar2 - fVar6;
	if (fParam0 > 0f) {
		if (Global_2594044 >= fVar0 && Global_2594044 < fVar5) {
			return -999;
		}
	}
	if (Global_2594044 >= fVar0 && Global_2594044 < fVar4) {
		return -1;
	}
	if (Global_2594044 >= fVar4 && Global_2594044 <= fVar2) {
		return 1;
	}
	return 0;
}

// Position - 0x1DBBE
int func_377() {
	if (controls::_is_input_disabled(2)) {
		return controls::is_disabled_control_pressed(2, 237);
	}
	return 0;
}

// Position - 0x1DBD9
void func_378(char *sParam0, int iParam1, int iParam2) {
	int iVar0;

	StringCopy(&Global_17290.f_4562, sParam0, 16);
	Global_17290.f_4632 = 0;
	Global_17290.f_4633 = 0;
	Global_17290.f_4634 = 0;
	Global_17290.f_4635 = 0;
	Global_17290.f_4636 = iParam1;
	Global_17290.f_4637 = gameplay::get_game_timer();
	Global_17290.f_4638 = iParam2;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_4566[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x1DC3E
void func_379(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	Global_17290.f_5606 = iParam0;
	Global_17290.f_5741 = iParam2;
	if (Global_17290.f_5606 < Global_17290.f_5605) {
		Global_17290.f_5605 = Global_17290.f_5606;
	}
	else if (Global_17290.f_5599 && Global_17290.f_5606 > Global_17290.f_5607 ||
			 !Global_17290.f_5599 && Global_17290.f_5606 >= Global_17290.f_5605 + Global_17290.f_5095) {
		iVar0 = Global_17290.f_5605;
		while (iVar0 <= Global_17290.f_5606) {
			if (iVar0 >= 0 && iVar0 < 127) {
				if (Global_17290.f_4959[iVar0] != 0) {
					iVar1++;
				}
			}
			iVar0++;
		}
		while (iVar1 > Global_17290.f_5095 && Global_17290.f_5605 < 128) {
			Global_17290.f_5605++;
			iVar1 = 0;
			iVar0 = Global_17290.f_5605;
			while (iVar0 <= Global_17290.f_5606) {
				if (iVar0 >= 0 && iVar0 < 127) {
					if (Global_17290.f_4959[iVar0] != 0) {
						iVar1++;
					}
				}
				iVar0++;
			}
		}
	}
	Global_17290.f_5598 = 0;
	Global_17290.f_5599 = 0;
	if (iParam1) {
		StringCopy(&Global_17290.f_4562, "", 16);
		StringCopy(&Global_2593974.f_21, "", 16);
	}
}

// Position - 0x1DD90
bool func_380() {
	if (controls::_is_input_disabled(2)) {
		if (Global_2594050 > -1) {
			if (controls::is_control_just_pressed(2, 237)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1DDB7
int func_381(int iParam0, int iParam1, int iParam2) {
	if (!controls::_is_input_disabled(2)) {
		return 0;
	}
	if (ui::is_pause_menu_active() || ui::is_warning_message_active()) {
		return 0;
	}
	if (iParam2) {
		ui::_show_cursor_this_frame();
	}
	if (Global_2594050 == -6) {
		ui::_set_cursor_sprite(4);
		if (iParam0 && controls::is_control_pressed(2, 237)) {
			return 1;
		}
		else {
			Global_2594050 = -1;
			return 0;
		}
	}
	if (Global_2594050 > -1 || Global_2594050 == -3 || Global_2594050 == -2 || ui::_0x3D9ACB1EB139E702()) {
		ui::_set_cursor_sprite(1);
		return 0;
	}
	if (Global_2594050 == -1 && iParam0) {
		if (controls::is_control_pressed(2, 237)) {
			ui::_set_cursor_sprite(4);
			Global_2594050 = -6;
			return 1;
		}
		else {
			ui::_set_cursor_sprite(3);
			return 0;
		}
	}
	ui::_set_cursor_sprite(1);
	return 0;
}

// Position - 0x1DE97
void func_382(int iParam0, int iParam1, int iParam2, int iParam3) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;

	fVar6 = 0.034722f / 2f;
	iVar13 = -1;
	if (!controls::_is_input_disabled(2)) {
		Global_2594050 = -1;
		return;
	}
	controls::_0x5B73C77D9EB66E24(1);
	fVar0 = Global_17287;
	fVar2 = fVar0 + Global_17289;
	fVar3 = Global_17290.f_5600;
	fVar1 = Global_17290.f_5600 - IntToFloat(Global_17290.f_5602) * 0.034722f;
	if (iParam2) {
		fVar3 += 0.034722f;
		fVar1 += 0.034722f;
	}
	if (Global_17290.f_5602 < 1) {
		fVar1 = Global_17290.f_5600 - 0.034722f;
	}
	graphics::_set_screen_draw_position(76, 84);
	graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
	fVar4 = fVar0;
	fVar5 = fVar1;
	graphics::_0x6DD8F5AA635EB4B2(fVar0, fVar1, &fVar0, &fVar1);
	graphics::_0x6DD8F5AA635EB4B2(fVar2, fVar3, &fVar2, &fVar3);
	graphics::_screen_draw_position_end();
	func_384();
	if (Global_2594050 == -6) {
		return;
	}
	Global_2594050 = -1;
	fVar7 = Global_2594044;
	fVar8 = Global_2594045;
	if (Global_17290.f_5603 > Global_17290.f_5602) {
		if (Global_2594044 >= fVar0 && Global_2594044 <= fVar2 && Global_2594045 >= fVar3 &&
			Global_2594045 < fVar3 + fVar6) {
			Global_2594050 = -2;
			if (iParam3) {
				func_383(0);
			}
			return;
		}
		if (Global_2594044 >= fVar0 && Global_2594044 <= fVar2 && Global_2594045 >= fVar3 + fVar6 &&
			Global_2594045 < fVar3 + 0.034722f) {
			Global_2594050 = -3;
			if (iParam3) {
				func_383(0);
			}
			return;
		}
	}
	if (fVar7 >= fVar0 && fVar7 <= fVar2 && fVar8 >= fVar1 && fVar8 <= fVar3) {
		fVar9 = fVar8 - fVar1;
		iVar13 = system::floor(fVar9 / 0.034722f);
		if (Global_17290.f_5603 == -1) {
			Global_2594050 = 0;
			iVar13 = 0;
			return;
		}
		iVar11 = 148;
		iVar12 = iVar11 / Global_17290.f_5602;
		iVar10 = 32 + iVar11 - iVar12 * iVar13;
		if (iParam3) {
			if (!iParam1 || iVar13 != 0) {
				graphics::_set_screen_draw_position(76, 84);
				graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
				func_346(fVar4, fVar5 + IntToFloat(iVar13) * 0.034722f, Global_17289, 0.034722f - 0.0015f, 255, 255,
						 255, iVar10);
				graphics::_screen_draw_position_end();
			}
		}
		Global_2594050 = Global_17290.f_7520[iVar13];
		return;
	}
	if (!iParam0) {
		if (fVar7 < fVar2) {
			Global_2594050 = -4;
			return;
		}
		if (fVar8 > 0.9f) {
			Global_2594050 = -5;
			return;
		}
	}
	else if (fVar7 < fVar2 && fVar8 < fVar3 + 0.25f) {
		Global_2594050 = -4;
		return;
	}
	Global_2594050 = -1;
}

// Position - 0x1E143
void func_383(int iParam0) {
	float fVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 0.034722f / 2f;
	if (iParam0) {
		iVar3 = 48;
	}
	else {
		iVar3 = 210;
	}
	fVar0 = Global_17287;
	fVar1 = Global_17290.f_5600;
	graphics::_set_screen_draw_position(76, 84);
	graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
	if (Global_2594050 == -2) {
		func_346(fVar0, fVar1, Global_17289, fVar2, 255, 255, 255, iVar3);
	}
	else if (Global_2594050 == -3) {
		func_346(fVar0, fVar1 + fVar2, Global_17289, fVar2, 255, 255, 255, iVar3);
	}
	graphics::_screen_draw_position_end();
}

// Position - 0x1E1CC
void func_384() {
	Global_2594046 = Global_2594044;
	Global_2594047 = Global_2594045;
	Global_2594044 = controls::get_disabled_control_normal(2, 239);
	Global_2594045 = controls::get_disabled_control_normal(2, 240);
	Global_2594048 = Global_2594044 - Global_2594046;
	Global_2594049 = Global_2594045 - Global_2594047;
}

// Position - 0x1E214
float func_385(float fParam0) {
	if (fParam0 < 1.3f) {
		return 35f;
	}
	else if (fParam0 < 1.35f) {
		return 33f;
	}
	return 30f;
}

// Position - 0x1E24A
void func_386(var *uParam0) {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;

	uParam0->f_660 = 0;
	uParam0->f_661 = 3;
	uParam0->f_662 = 0;
	uParam0->f_663 = 3;
	uParam0->f_664 = 0;
	uParam0->f_665 = 7;
	func_326(0);
	ui::get_hud_colour(141, &uVar0, &uVar1, &uVar2, &uVar3);
	func_371(uVar0, uVar1, uVar2, uVar3, 1);
	func_370(1, 2, 0, 0, 0);
	func_369(1, 2, 1, 1, 1);
	func_368(0, 1, 0, 0, 0);
	func_367("DARTS_TITLE");
	func_365(1, "ShopUI_Title_Darts", "ShopUI_Title_Darts");
	func_361(0, "DARTS_LEGS", 0, 1, 0, 0);
	func_358(0, 1, 0);
	func_361(1, "DARTS_SETS", 0, 1, 0, 0);
	func_358(1, 1, 0);
	func_361(2, "DARTS_START", 0, 1, 0, 0);
	func_357(2, 141, 141, 1);
	func_356(0);
	func_379(0, 1, 1);
	func_378("DARTS_LEGD", 0, 0);
	func_387();
	func_355(201, "ITEM_SELECT", -1, 0);
	func_355(202, "IB_QUIT", -1, 0);
}

// Position - 0x1E336
void func_387() {
	if (gameplay::is_pc_version()) {
		controls::_set_cursor_location(0.325f, 0.3f);
	}
}

// Position - 0x1E354
bool func_388(int *iParam0, var *uParam1, var *uParam2, int *iParam3, var *uParam4, int *iParam5) {
	int iVar0;
	int iVar1;

	if (func_411() && gameplay::get_game_timer() >= iLocal_324 + 1000 && *iParam0 != 8) {
		if (!cam::is_screen_faded_out() && !cam::is_screen_fading_out()) {
			cam::do_screen_fade_out(500);
		}
	}
	if (cam::is_screen_faded_out() && *iParam0 != 8) {
		*iParam0 = 8;
	}
	switch (*iParam0) {
	case 2:
		switch (iLocal_31) {
		case 0:
			if (*iParam3 == 2) {
				iLocal_324 = gameplay::get_game_timer();
				func_396(uParam1->f_1, uParam1->f_4, func_398(2), func_397(0), 0, 1);
				*uParam2 = 20;
				uParam2->f_1 = 2;
				func_267(&(*uParam4)[0 /*26*/], uParam1, iParam3, uParam2, 1);
			}
			if (*iParam3 == 3) {
				if (func_254(&(*uParam4)[0 /*26*/], uParam1, 0, 0)) {
					audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
					iLocal_31++;
					func_415(iParam5);
					*iParam3 = 2;
				}
			}
			break;

		case 1:
			if (func_404(iParam5) > 1f && !func_284("DARTS_DOUBLE_T")) {
				func_399("DARTS_DOUBLE_T", -1);
			}
			if (func_404(iParam5) > 5f) {
				func_415(iParam5);
				ui::clear_help(1);
				func_390(uParam1->f_1, uParam1->f_4, func_398(3), func_397(0), 1000);
				iLocal_31 = 0;
				*iParam0 = 3;
			}
			break;
		}
		break;

	case 3:
		switch (iLocal_31) {
		case 0:
			if (!cam::is_cam_interpolating(iLocal_128)) {
				if (*iParam3 == 2) {
					*uParam2 = 20;
					uParam2->f_1 = 3;
					func_267(&(*uParam4)[1 /*26*/], uParam1, iParam3, uParam2, 1);
				}
				if (*iParam3 == 3) {
					if (func_254(&(*uParam4)[1 /*26*/], uParam1, 0, 0)) {
						audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
						iLocal_31++;
						func_415(iParam5);
						*iParam3 = 2;
					}
				}
			}
			break;

		case 1:
			if (func_404(iParam5) > 1f && !func_284("DARTS_TRIPLE_T")) {
				func_399("DARTS_TRIPLE_T", -1);
			}
			if (func_404(iParam5) > 5f) {
				func_415(iParam5);
				ui::clear_help(1);
				func_396(uParam1->f_1, uParam1->f_4, func_398(4), func_397(0), 1000, 0);
				iLocal_31 = 0;
				*iParam0 = 4;
			}
			break;
		}
		break;

	case 4:
		switch (iLocal_31) {
		case 0:
			if (!cam::is_cam_interpolating(iLocal_127)) {
				if (*iParam3 == 2) {
					*uParam2 = 50;
					uParam2->f_1 = 1;
					func_267(&(*uParam4)[2 /*26*/], uParam1, iParam3, uParam2, 1);
				}
				if (*iParam3 == 3) {
					if (func_254(&(*uParam4)[2 /*26*/], uParam1, 0, 0)) {
						audio::play_sound_from_coord(-1, "DARTS_HIT_BOARD_MASTER", uParam1->f_1, 0, 0, 0, 0);
						iLocal_31++;
						func_415(iParam5);
						*iParam3 = 2;
					}
				}
			}
			break;

		case 1:
			if (func_404(iParam5) > 1f && !func_284("DARTS_BULL_T")) {
				func_399("DARTS_BULL_T", -1);
			}
			if (func_404(iParam5) > 5f) {
				func_415(iParam5);
				ui::clear_help(1);
				audio::play_sound_frontend(-1, "CAM_PAN_DARTS", "HUD_MINI_GAME_SOUNDSET", 1);
				func_390(uParam1->f_1, uParam1->f_4, func_398(5), func_397(1), 1500);
				iLocal_31 = 0;
				*iParam0 = 5;
			}
			break;
		}
		break;

	case 5:
		if (!cam::is_cam_interpolating(iLocal_128) && !func_284("DARTS_DBL_WIN")) {
			func_399("DARTS_DBL_WIN", -1);
		}
		if (func_404(iParam5) > 6f) {
			func_415(iParam5);
			*iParam0 = 6;
		}
		break;

	case 6:
		audio::play_sound_frontend(-1, "CAM_PAN_DARTS", "HUD_MINI_GAME_SOUNDSET", 1);
		cam::set_cam_active_with_interp(iLocal_120, iLocal_128, 1500, 1, 1);
		*iParam0 = 7;
		break;

	case 7:
		if (!cam::is_cam_interpolating(iLocal_120)) {
			iLocal_31 = 0;
			ui::clear_help(1);
			ui::clear_prints();
			iVar0 = 0;
			while (iVar0 < 3) {
				func_389(&(*uParam4)[iVar0 /*26*/]);
				iVar0++;
			}
			return true;
		}
		break;

	case 8:
		if (cam::is_screen_faded_out()) {
			iLocal_31 = 0;
			ui::clear_help(1);
			ui::clear_prints();
			iVar1 = 0;
			while (iVar1 < 3) {
				func_389(&(*uParam4)[iVar1 /*26*/]);
				iVar1++;
			}
			cam::set_cam_active(iLocal_120, 1);
			cam::do_screen_fade_in(500);
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x1E770
void func_389(int *iParam0) {
	vector3 vVar0;

	vVar0 = {-1668.044f, -1056.45f, 13.1063f};
	if (entity::does_entity_exist(*iParam0)) {
		entity::set_entity_coords(*iParam0, vVar0, 1, 0, 0, 1);
		entity::set_object_as_no_longer_needed(iParam0);
		object::delete_object(iParam0);
	}
}

// Position - 0x1E7B0
void func_390(vector3 vParam0, float fParam3, vector3 vParam4, vector3 vParam7, int iParam10) {
	cam::stop_cam_pointing(iLocal_128);
	cam::set_cam_fov(iLocal_128, 35f);
	cam::set_cam_coord(iLocal_128, object::_get_object_offset_from_coords(vParam0, fParam3, vParam4));
	cam::set_cam_rot(iLocal_128, Vector(fParam3, 0f, 0f) - vParam7, 2);
	cam::set_cam_active_with_interp(iLocal_128, iLocal_127, iParam10, 1, 1);
}

// Position - 0x1E7F9
int func_391(var *uParam0, int iParam1, int iParam2) {
	if (!func_401(&uParam0->f_2)) {
		func_415(&uParam0->f_2);
	}
	ui::hide_hud_component_this_frame(14);
	if (!iParam2) {
		graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
	}
	else if (iParam2) {
		graphics::draw_scaleform_movie_fullscreen(*uParam0, 255, 255, 255, 255, 0);
	}
	if (iParam1) {
		if (controls::is_control_pressed(2, 201)) {
			return 0;
		}
	}
	if (uParam0->f_1 == -1) {
		return 1;
	}
	if (func_7(&uParam0->f_2) * 1000f > system::to_float(uParam0->f_1)) {
		func_402(&uParam0->f_2);
		return 0;
	}
	return 1;
}

// Position - 0x1E88B
void func_392(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6,
			  float fParam7) {
	char *sVar0;

	sVar0 = func_393(iParam5);
	graphics::_push_scaleform_movie_function(*uParam0, "RESET_MOVIE");
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(*uParam0, sVar0);
	graphics::begin_text_command_scaleform_string("STRING");
	ui::_set_notification_color_next(iParam4);
	ui::add_text_component_substring_text_label(sParam1);
	graphics::end_text_command_scaleform_string();
	if (!gameplay::is_string_null_or_empty(sParam2)) {
		func_12(sParam2);
	}
	if (iParam6) {
		graphics::_push_scaleform_movie_function_parameter_int(100);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
	}
	graphics::_pop_scaleform_movie_function_void();
	if (iParam6) {
		graphics::_push_scaleform_movie_function(*uParam0, "TRANSITION_UP");
		graphics::_push_scaleform_movie_function_parameter_float(fParam7);
		graphics::_pop_scaleform_movie_function_void();
	}
	func_415(&uParam0->f_2);
	uParam0->f_1 = iParam3;
}

// Position - 0x1E91A
char *func_393(int iParam0) {
	switch (iParam0) {
	case 0: return "SHOW_WASTED_MP_MESSAGE";

	case 1: return "SHOW_BUSTED_MP_MESSAGE";

	case 2: return "SHOW_CENTERED_MP_MESSAGE_LARGE";

	case 3: return "SHOW_CENTERED_TOP_MP_MESSAGE";

	case 4: return "SHOW_MIDSIZED_MESSAGE";

	case 5: return "SHOW_MISSION_END_MP_MESSAGE";

	case 6: return "SHOW_MISSION_PASSED_MESSAGE";

	case 7: return "SHOW_MISSION_FAILED_MP_MESSAGE";

	default:
	}
	return "SHOW_CENTERED_MP_MESSAGE_LARGE";
}

// Position - 0x1E995
void func_394() {
	cam::set_cam_active(iLocal_120, 1);
	cam::render_script_cams(1, 0, 3000, 1, 0, 0);
	if (cam::is_cam_active(iLocal_127)) {
		cam::set_cam_active(iLocal_127, 0);
	}
	if (cam::is_cam_active(iLocal_122)) {
		cam::set_cam_active(iLocal_122, 0);
	}
	if (cam::is_cam_active(iLocal_123)) {
		cam::set_cam_active(iLocal_123, 0);
	}
	if (cam::is_cam_active(iLocal_124)) {
		cam::set_cam_active(iLocal_124, 0);
	}
	if (cam::is_cam_active(iLocal_125)) {
		cam::set_cam_active(iLocal_125, 0);
	}
	if (cam::is_cam_active(iLocal_126)) {
		cam::set_cam_active(iLocal_126, 0);
	}
}

// Position - 0x1EA10
char *func_395(int iParam0) {
	if (iLocal_335 == 1) {
		switch (iParam0) {
		case 0: return "DARTS_MEET_OPPONENT_BAR";

		case 1: return "DARTS_MENU_BAR";

		case 2: return "DARTS_START_MATCH_BAR";

		case 3: return "DARTS_MATCH_COMPLETE_BAR";

		default:
		}
	}
	else if (iLocal_335 == 2) {
		switch (iParam0) {
		case 0: return "DARTS_MEET_OPPONENT_ROCK";

		case 1: return "DARTS_MENU_ROCK";

		case 2: return "DARTS_START_MATCH_ROCK";

		case 3: return "DARTS_MATCH_COMPLETE_ROCK";
		}

	default:
	}
	return "";
}

// Position - 0x1EAA3
void func_396(vector3 vParam0, float fParam3, vector3 vParam4, vector3 vParam7, int iParam10, int iParam11) {
	cam::stop_cam_pointing(iLocal_127);
	cam::set_cam_fov(iLocal_127, 35f);
	cam::set_cam_coord(iLocal_127, object::_get_object_offset_from_coords(vParam0, fParam3, vParam4));
	cam::set_cam_rot(iLocal_127, Vector(fParam3, 0f, 0f) - vParam7, 2);
	if (iParam11) {
		cam::set_cam_active(iLocal_127, 1);
	}
	else {
		cam::set_cam_active_with_interp(iLocal_127, iLocal_128, iParam10, 1, 1);
	}
}

// Position - 0x1EAFB
Vector3 func_397(int iParam0) {
	if (iParam0) {
		return -4.7411f, 0f, -15.32f;
	}
	return 4.9918f, 0f, 4.3916f;
}

// Position - 0x1EB24
Vector3 func_398(int iParam0) {
	switch (iParam0) {
	case 0: return -0.0588f, -1.6075f, 0.1336f;

	case 2: return -0.0944f, -1.2308f, 0.3468f;

	case 3: return -0.0948f, -1.243f, 0.2067f;

	case 4: return -0.0955f, -1.2524f, 0.1006f;

	case 5: return -0.0951f, -1.2526f, 0.0895f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x1EBAE
void func_399(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0x1EBC5
int func_400(int iParam0) {
	if (!entity::is_entity_dead(func_479(), 0)) {
		func_4(func_479(), "GENERIC_YES", 0, 6);
	}
	else {
		func_4(iParam0, "GENERIC_AGREE", 0, 6);
	}
	return 1;
}

// Position - 0x1EBF8
bool func_401(int *iParam0) { return gameplay::is_bit_set(*iParam0, 1); }

// Position - 0x1EC08
void func_402(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x1EC1E
void func_403(int iParam0, char *sParam1, int iParam2) {
	audio::_play_ambient_speech1(iParam0, sParam1, func_6(iParam2), 1);
}

// Position - 0x1EC35
float func_404(int *iParam0) {
	if (func_401(iParam0)) {
		if (func_9(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_8(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return 0f;
}

// Position - 0x1EC71
void func_405(int *iParam0) {
	if (!func_401(iParam0)) {
		func_352(iParam0);
	}
	else {
		func_415(iParam0);
	}
}

// Position - 0x1EC92
void func_406() {
	Global_14611 = 0;
	func_407();
}

// Position - 0x1ECA2
void func_407() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x1ECF9
void func_408(int iParam0) {
	if (Global_14604) {
		func_410(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_409()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x1ED69
int func_409() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x1ED90
void func_410(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_38(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x1EE04
int func_411() {
	if (ui::is_pause_menu_active()) {
		return 0;
	}
	if (controls::is_control_just_pressed(0, 18) || controls::is_control_just_pressed(2, 18)) {
		return 1;
	}
	return 0;
}

// Position - 0x1EE36
int func_412(int *iParam0) {
	int iVar0;

	iVar0 = player::get_players_last_vehicle();
	if (entity::does_entity_exist(iVar0)) {
		if (!func_413(iVar0)) {
			if (!ped::is_ped_injured(player::player_ped_id()) &&
				entity::is_entity_at_entity(iVar0, player::player_ped_id(), vLocal_293, 0, 1, 0)) {
				vehicle::set_last_driven_vehicle(iVar0);
				entity::set_entity_collision(iVar0, 0, 0);
				entity::set_entity_visible(iVar0, 0, 0);
				entity::freeze_entity_position(iVar0, 1);
				entity::set_entity_as_mission_entity(iVar0, 1, 1);
				*iParam0 = iVar0;
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x1EEA9
int func_413(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (entity::is_entity_dead(iParam0, 0)) {
			return 1;
		}
		else if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (!fire::is_entity_on_fire(iParam0)) {
				return 1;
			}
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0x1EEEC
void func_414(var *uParam0, int iParam1) {
	iParam1++;
	graphics::_push_scaleform_movie_function(*uParam0, "SET_PLAYER_HIGHLIGHT");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1EF10
void func_415(int *iParam0) { func_416(iParam0, 0f); }

// Position - 0x1EF1F
void func_416(int *iParam0, float fParam1) {
	uParam0->f_1 = func_8(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0x1EF4D
void func_417(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x1EFE8
void func_418(var *uParam0, char *sParam1, char *sParam2) {
	graphics::_push_scaleform_movie_function(*uParam0, "SET_DARTS_PLAYER_NAMES");
	func_419(sParam1);
	func_419(sParam2);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1F00C
void func_419(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x1F01A
void func_420(float fParam0, struct<4> Param1, var uParam5, var uParam6, var *uParam7, var *uParam8) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(func_479()) && !ped::is_ped_injured(func_479())) {
		ped::remove_ped_from_group(func_479());
	}
	else {
		if (entity::does_entity_exist(uParam8->f_5) && !ped::is_ped_injured(uParam8->f_5)) {
			entity::set_entity_as_mission_entity(uParam8->f_5, 1, 1);
			uLocal_296[1] = uParam8->f_5;
			ai::clear_ped_tasks(uLocal_296[1]);
		}
		else if (func_422(uParam7)) {
			ai::clear_ped_tasks(uLocal_296[1]);
		}
		else {
			uLocal_296[1] = ped::create_ped(26, iLocal_332, Param1.f_3, fParam0, 1, 1);
		}
		if (decorator::decor_exist_on(uLocal_296[1], "Darts_name")) {
			iVar0 = decorator::decor_get_int(uLocal_296[1], "Darts_name");
			if (954610991 == iVar0) {
				sLocal_392 = func_425("RAYMOND");
				iLocal_393 = 954610991;
			}
			else if (94453331 == iVar0) {
				sLocal_392 = func_425("JOHAN");
				iLocal_393 = 94453331;
			}
			else if (1891555423 == iVar0) {
				sLocal_392 = func_425("STAN");
				iLocal_393 = 1891555423;
			}
			else if (-1067630349 == iVar0) {
				sLocal_392 = func_425("VINCE");
				iLocal_393 = -1067630349;
			}
			else if (885327384 == iVar0) {
				sLocal_392 = func_425("KRISTY");
				iLocal_393 = 885327384;
			}
			else if (-1791000994 == iVar0) {
				sLocal_392 = func_425("MARLENE");
				iLocal_393 = -1791000994;
			}
			else if (1954368234 == iVar0) {
				sLocal_392 = func_425("LORIE");
				iLocal_393 = 1954368234;
			}
			else if (-863218904 == iVar0) {
				sLocal_392 = func_425("SHELLEY");
				iLocal_393 = -863218904;
			}
		}
		decorator::decor_set_int(uLocal_296[1], "Darts_name", iLocal_393);
	}
	iVar1 = entity::get_entity_model(uLocal_296[1]);
	func_421(iVar1);
	ai::task_turn_ped_to_face_entity(uLocal_296[1], uLocal_296[0], 0);
	ai::task_turn_ped_to_face_entity(uLocal_296[0], uLocal_296[1], 0);
}

// Position - 0x1F213
void func_421(int iParam0) {
	int iVar0;

	iVar0 = gameplay::get_random_int_in_range(0, 2);
	switch (iParam0) {
	case joaat("a_f_m_salton_01"):
		switch (iVar0) {
		case 0: sLocal_102 = "A_F_M_SALTON_01_WHITE_FULL_03"; break;

		case 1: sLocal_102 = "A_F_M_SALTON_01_WHITE_FULL_02"; break;
		}
		break;

	case joaat("a_f_o_salton_01"): sLocal_102 = "A_F_M_SALTON_01_WHITE_FULL_01"; break;

	case joaat("a_m_y_vinewood_01"): sLocal_102 = "G_M_Y_LOST_01_BLACK_FULL_01"; break;

	case joaat("a_m_y_vinewood_03"): sLocal_102 = "G_M_Y_LOST_02_LATINO_FULL_01"; break;

	case joaat("a_m_y_vinewood_04"): sLocal_102 = "G_M_Y_LOST_01_BLACK_FULL_02"; break;

	case joaat("a_m_y_stlat_01"): sLocal_102 = "G_M_Y_LOST_02_LATINO_FULL_02"; break;

	case joaat("a_m_y_stwhi_02"): sLocal_102 = "G_M_Y_LOST_01_WHITE_FULL_01"; break;
	}
}

// Position - 0x1F2B2
bool func_422(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < ped::get_ped_nearby_peds(player::player_ped_id(), uParam0, -1)) {
		if (!ped::is_ped_injured((*uParam0)[iVar0])) {
			if (entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_f_m_salton_01") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_f_o_salton_01") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_m_y_vinewood_01") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_m_y_stlat_01") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_m_y_vinewood_04") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_m_y_stwhi_02") ||
				entity::get_entity_model((*uParam0)[iVar0]) == joaat("a_m_y_vinewood_03")) {
				entity::set_entity_as_mission_entity((*uParam0)[iVar0], 1, 1);
				uLocal_296[1] = (*uParam0)[iVar0];
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x1F39B
int func_423(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 3;
		while (iVar0 <= 150 - 1) {
			if (func_424(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x1F3DB
int func_424(int iParam0) {
	if (!func_81(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x1F406
char *func_425(char *sParam0) {
	if (unk::_get_current_language_id() == 7) {
		if (gameplay::are_strings_equal(sParam0, "MICHAEL")) {
			return "??????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "FRANKLIN")) {
			return "????????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "TREVOR")) {
			return "????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "LAMAR")) {
			return "??????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "JIMMY")) {
			return "????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "KRISTY")) {
			return "????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "MARLENE")) {
			return "????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "LORIE")) {
			return "????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "SHELLEY")) {
			return "??????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "RAYMOND")) {
			return "??????????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "JOHAN")) {
			return "??????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "STAN")) {
			return "????????";
		}
		else if (gameplay::are_strings_equal(sParam0, "VINCE")) {
			return "????????";
		}
	}
	return sParam0;
}

// Position - 0x1F540
void func_426(var *uParam0, var *uParam1, var *uParam2, int iParam3) {
	if (entity::does_entity_exist(*uParam0)) {
		uParam0->f_4 = entity::get_entity_heading(*uParam0);
	}
	if (!iParam3) {
		func_428(uParam1, uParam0);
	}
	vLocal_82 = {0f, -2.3685f + fLocal_55, 0.1f};
	vLocal_82 = {vLocal_82 + vLocal_56};
	vLocal_79 = {object::_get_object_offset_from_coords(uParam0->f_1, uParam0->f_4, vLocal_82)};
	func_427(uParam2, uParam0);
}

// Position - 0x1F5A8
void func_427(var *uParam0, var *uParam1) {
	uParam0->f_3 = {0f, -0.15f, 0f};
	uParam0->f_3 = {uParam0->f_3 + vLocal_56};
	*uParam0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, 0f, 0f, 0f)};
}

// Position - 0x1F5E3
void func_428(var *uParam0, var *uParam1) {
	*uParam0 = {object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, -0.4f, -2.4f + fLocal_55, -1.7272f)};
	uParam0->f_3 = {
		object::_get_object_offset_from_coords(uParam1->f_1, uParam1->f_4, 0.5f, -2.4f + fLocal_55, -1.7272f)};
}

// Position - 0x1F635
bool func_429(var *uParam0, var *uParam1) {
	if (!audio::request_script_audio_bank("SCRIPT\DARTS", 0, -1)) {
		return false;
	}
	if (!audio::request_script_audio_bank("SCRIPT\FAMILY1_2", 0, -1)) {
		return false;
	}
	if (!streaming::has_model_loaded(iLocal_28) || !streaming::has_model_loaded(iLocal_29) ||
		!streaming::has_model_loaded(iLocal_60) || !streaming::has_model_loaded(iLocal_332) ||
		!graphics::has_scaleform_movie_loaded(*uParam0) || !graphics::has_scaleform_movie_loaded(uParam1->f_645) ||
		!graphics::has_scaleform_movie_loaded(uParam1->f_57) || !graphics::has_scaleform_movie_loaded(uParam1->f_62) ||
		!ui::has_additional_text_loaded(3) || !graphics::has_streamed_texture_dict_loaded("Darts") ||
		!streaming::has_anim_dict_loaded(sLocal_394) || !streaming::has_anim_dict_loaded(sLocal_395) ||
		!func_430(0, -1, 0)) {
		return false;
	}
	return true;
}

// Position - 0x1F719
int func_430(char *sParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_323(&iVar0, 1, iParam1)) {
		return 0;
	}
	iVar1 = 1;
	StringCopy(&Global_17290.f_5505[iVar0 /*4*/], sParam0, 16);
	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5505[iVar0 /*4*/])) {
		ui::request_additional_text(&Global_17290.f_5505[iVar0 /*4*/], 9);
		Global_17290.f_5498[iVar0] = 1;
		if (!ui::has_this_additional_text_loaded(&Global_17290.f_5505[iVar0 /*4*/], 9)) {
			iVar1 = 0;
		}
	}
	graphics::request_streamed_texture_dict("CommonMenu", 0);
	Global_17290.f_5484[iVar0] = 1;
	if (!graphics::has_streamed_texture_dict_loaded("CommonMenu")) {
		iVar1 = 0;
	}
	if (iParam2) {
		graphics::request_streamed_texture_dict("MPShopSale", 0);
		Global_17290.f_5491[iVar0] = 1;
		if (!graphics::has_streamed_texture_dict_loaded("MPShopSale")) {
			iVar1 = 0;
		}
	}
	iVar2 = 0;
	StringCopy(&Global_17290.f_5530[iVar0 /*10*/].f_1, "instructional_buttons", 24);
	iVar2 = func_431(&Global_17290.f_5530[iVar0 /*10*/]);
	if (!iVar1 || !iVar2) {
	}
	return iVar1 & iVar2;
}

// Position - 0x1F80F
bool func_431(var *uParam0) {
	switch (uParam0->f_9) {
	case 0:
		if (!graphics::has_scaleform_movie_loaded(*uParam0)) {
			*uParam0 = unk_0x67D02A194A2FC2BD(&uParam0->f_1);
			uParam0->f_9 = 1;
			if (uParam0->f_7) {
				if (graphics::has_scaleform_movie_loaded(*uParam0)) {
					uParam0->f_8 = gameplay::get_game_timer();
					uParam0->f_9 = 2;
				}
			}
		}
		else {
			uParam0->f_8 = gameplay::get_game_timer();
			uParam0->f_9 = 2;
		}
		break;

	case 1:
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			uParam0->f_8 = gameplay::get_game_timer();
			uParam0->f_9 = 2;
		}
		break;

	case 2:
		if (!graphics::has_scaleform_movie_loaded(*uParam0)) {
			uParam0->f_9 = 0;
		}
		break;
	}
	return uParam0->f_9 == 2;
}

// Position - 0x1F8B1
void func_432(var *uParam0, var *uParam1) {
	streaming::request_model(iLocal_28);
	streaming::request_model(iLocal_29);
	streaming::request_model(iLocal_60);
	streaming::request_model(iLocal_332);
	graphics::request_streamed_texture_dict("Darts", 0);
	graphics::request_streamed_texture_dict("ShopUI_Title_Darts", 0);
	streaming::request_anim_dict(sLocal_394);
	streaming::request_anim_dict(sLocal_395);
	*uParam0 = unk_0x67D02A194A2FC2BD("darts_scoreboard");
	uParam1->f_645 = func_181();
	uParam1->f_57 = func_434();
	uParam1->f_62 = func_433();
	ui::request_additional_text("DARTS", 3);
}

// Position - 0x1F91F
var func_433() { return unk_0x67D02A194A2FC2BD("MIDSIZED_MESSAGE"); }

// Position - 0x1F92F
var func_434() { return unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE"); }

// Position - 0x1F93F
void func_435(int *iParam0, int iParam1, vector3 vParam2, float fParam5) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 2) {
		iVar1 = 0;
		while (iVar1 < 7) {
			iParam0->f_1[iVar0 /*8*/][iVar1] = 1;
			iVar1++;
		}
		iVar0++;
	}
	if (iParam1 == 0) {
		iParam0->f_18 = {989.399f, -99.674f, 75.925f};
		iParam0->f_21 = {180f, 0f, 252.555f};
		iParam0->f_24 = {1.82f, 1.328f, 1f};
	}
	else {
		iParam0->f_18 = {1992.223f, 3049.814f, 48.333f};
		iParam0->f_21 = {180f, 0f, 87.77f};
		iParam0->f_24 = {1.82f, 1.328f, 1f};
	}
	if (!func_436(vParam2) && fParam5 != 0f) {
		iParam0->f_18 = {object::_get_object_offset_from_coords(vParam2, fParam5, -0.687645f, -0.350352f, 0.343273f)};
		iParam0->f_21 = {180f, 0f, fParam5 - -29.98685f};
	}
	iParam0->f_27 = 0.885f;
	iParam0->f_28 = 0.244f;
	iParam0->f_29 = 0.17f;
	iParam0->f_30 = 0.415f;
}

// Position - 0x1FA5B
int func_436(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return 1;
	}
	return 0;
}

// Position - 0x1FA85
void func_437(int iParam0) {
	int iVar0;

	iVar0 = iParam0 + 1;
	Local_61 = 0.5f;
	Local_61.f_1 = 0.5f;
	if (graphics::get_is_widescreen()) {
		Local_61.f_2 = 0.05f;
		Local_61.f_3 = 0.095f;
	}
	else {
		Local_61.f_2 = 0.065f;
		Local_61.f_3 = 0.09f;
	}
	Local_61.f_4 = 255;
	Local_61.f_5 = 250;
	Local_61.f_6 = 255;
	Local_61.f_7 = 123;
	if (iVar0 == 1) {
		Local_61.f_4 = 255;
		Local_61.f_5 = 255;
		Local_61.f_6 = 255;
	}
	else if (iVar0 == 2) {
		Local_61.f_4 = 255;
		Local_61.f_5 = 255;
		Local_61.f_6 = 255;
	}
	Local_61.f_8 = 0f;
	Local_70 = 0f;
	Local_70.f_1 = 0f;
	Local_70.f_2 = 0.061f;
	Local_70.f_3 = 0.105f;
	Local_70.f_4 = 200;
	Local_70.f_5 = 45;
	Local_70.f_6 = 40;
	Local_70.f_7 = 255;
	Local_70.f_8 = 0f;
}

// Position - 0x1FB58
void func_438(var *uParam0, int iParam1) {
	if (iParam1 == 0) {
		uParam0->f_1 = iLocal_28;
	}
	else {
		uParam0->f_1 = iLocal_29;
	}
	uParam0->f_24 = 0;
	uParam0->f_23 = 0;
}

// Position - 0x1FB7F
void func_439() {
	int iVar0;

	stats::leaderboards_clear_cache_data();
	iVar0 = 0;
	while (iVar0 < 5) {
		Global_1838575.f_81[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x1FBA8
void func_440(vector3 vParam0, float fParam3) {
	vector3 vVar0;
	vector3 vVar3;
	vector3 vVar6;
	vector3 vVar9;
	vector3 vVar12;
	vector3 vVar15;
	vector3 vVar18;
	float fVar21;
	vector3 vVar22;
	float fVar25;
	float fVar26;
	vector3 vVar27;
	float fVar30;
	float fVar31;
	vector3 vVar32;
	vector3 vVar35;
	vector3 vVar38;

	fLocal_134 = graphics::_get_aspect_ratio(0);
	fVar21 = 30f;
	fVar21 = func_385(fLocal_134);
	vVar22 = {-0.192784f, -1.73287f, 0.0262985f};
	fVar25 = 1.7939f;
	fVar26 = -1.3346f;
	if (graphics::get_is_widescreen()) {
		vVar27 = {-0.0974819f, -1.65968f, 0.335098f};
		fVar30 = -1.3023f;
		fVar31 = -12.4139f;
	}
	else {
		vVar27 = {-0.112635f, -1.86963f, 0.45417f};
		fVar30 = -3.7542f;
		fVar31 = -14.4576f;
	}
	vVar32 = {0.261599f, -0.750354f, -0.392929f};
	vVar38 = {0.281314f, -0.573735f, -0.39603f};
	vVar3 = {object::_get_object_offset_from_coords(vParam0, fParam3, vVar22)};
	vVar9 = {fVar26, 0f, fParam3 - fVar25};
	vVar0 = {object::_get_object_offset_from_coords(vParam0, fParam3, vVar27)};
	vVar6 = {fVar31, 0f, fParam3 - fVar30};
	vVar12 = {object::_get_object_offset_from_coords(vParam0, fParam3, vVar32)};
	vVar15 = {0.8351f, -0.0048f, fParam3 - 186.5073f};
	vVar35 = {object::_get_object_offset_from_coords(vParam0, fParam3, vVar38)};
	vVar18 = {0.8351f, -0.0048f, fParam3 - 186.5073f};
	iLocal_120 = cam::create_camera_with_params(26379945, vVar0, vVar6, fVar21, 0, 2);
	iLocal_121 = cam::create_camera_with_params(26379945, vVar3, vVar9, fVar21, 0, 2);
	iLocal_122 = cam::create_camera_with_params(26379945, vVar12, vVar15, 65f, 0, 2);
	iLocal_123 = cam::create_camera_with_params(26379945, vVar35, vVar18, 65f, 0, 2);
	iLocal_124 = cam::create_camera_with_params(26379945, 0f, 0f, 0f, 0f, 0f, 0f, 65f, 0, 2);
	iLocal_125 = cam::create_camera_with_params(26379945, 0f, 0f, 0f, 0f, 0f, 0f, 65f, 0, 2);
	iLocal_127 = cam::create_camera_with_params(26379945, 0f, 0f, 0f, 0f, 0f, 0f, 65f, 0, 2);
	iLocal_128 = cam::create_camera_with_params(26379945, 0f, 0f, 0f, 0f, 0f, 0f, 65f, 0, 2);
	iLocal_126 = cam::create_camera_with_params(26379945, 1996.235f, 3048.456f, 48.0237f, -3.4831f, 0.0223f, 60.6925f,
												38.1f, 0, 2);
	cam::set_cam_fov(iLocal_122, 43.35f);
	cam::set_cam_fov(iLocal_123, 42.35f);
	cam::shake_cam(iLocal_122, "HAND_SHAKE", 0.1f);
	cam::shake_cam(iLocal_123, "HAND_SHAKE", 0.1f);
}

// Position - 0x1FE0B
void func_441(var *uParam0, var *uParam1) {
	uParam0->f_1 = {*uParam1};
	uParam0->f_4 = uParam1->f_3;
	if (entity::does_entity_exist(uParam1->f_4)) {
		*uParam0 = uParam1->f_4;
	}
	iLocal_33[0] = 20;
	iLocal_33[10] = 3;
	iLocal_33[1] = 1;
	iLocal_33[11] = 19;
	iLocal_33[2] = 18;
	iLocal_33[12] = 7;
	iLocal_33[3] = 4;
	iLocal_33[13] = 16;
	iLocal_33[4] = 13;
	iLocal_33[14] = 8;
	iLocal_33[5] = 6;
	iLocal_33[15] = 11;
	iLocal_33[6] = 10;
	iLocal_33[16] = 14;
	iLocal_33[7] = 15;
	iLocal_33[17] = 9;
	iLocal_33[8] = 2;
	iLocal_33[18] = 12;
	iLocal_33[9] = 17;
	iLocal_33[19] = 5;
	iLocal_33[20] = 20;
}

// Position - 0x1FEC7
void func_442() { Global_17151.f_6 = 1; }

// Position - 0x1FED5
void func_443(int iParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&Global_25434, iParam0);
	}
	else {
		gameplay::clear_bit(&Global_25434, iParam0);
	}
}

// Position - 0x1FEF7
var func_444(int iParam0, int iParam1) {
	var uVar0;
	int iVar1;

	iVar1 = func_445(iParam0, iParam1);
	stats::stat_get_int(iVar1, &uVar0, -1);
	return uVar0;
}

// Position - 0x1FF15
var func_445(int iParam0, int iParam1) {
	int *iVar0;
	int *iVar1;

	func_446(iParam0, iParam1, &iVar0, &iVar1);
	return iVar0;
}

// Position - 0x1FF2B
void func_446(int iParam0, int iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp0_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp0_stamina"); break;

		case 3: *iParam2 = joaat("sp0_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp0_strength"); break;

		case 4: *iParam2 = joaat("sp0_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp0_flying_ability"); break;

		case 6: *iParam2 = joaat("sp0_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp0_stealth_ability"); break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp1_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp1_stamina"); break;

		case 3: *iParam2 = joaat("sp1_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp1_strength"); break;

		case 4: *iParam2 = joaat("sp1_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp1_flying_ability"); break;

		case 6: *iParam2 = joaat("sp1_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp1_stealth_ability"); break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: *iParam2 = joaat("sp2_special_ability_unlocked"); break;

		case 1: *iParam2 = joaat("sp2_stamina"); break;

		case 3: *iParam2 = joaat("sp2_lung_capacity"); break;

		case 2: *iParam2 = joaat("sp2_strength"); break;

		case 4: *iParam2 = joaat("sp2_wheelie_ability"); break;

		case 5: *iParam2 = joaat("sp2_flying_ability"); break;

		case 6: *iParam2 = joaat("sp2_shooting_ability"); break;

		case 7: *iParam2 = joaat("sp2_stealth_ability"); break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: *iParam3 = 64; break;

		case 1: *iParam3 = 65; break;

		case 3: *iParam3 = 67; break;

		case 2: *iParam3 = 66; break;

		case 4: *iParam3 = 68; break;

		case 5: *iParam3 = 69; break;

		case 6: *iParam3 = 70; break;

		case 7: *iParam3 = 71; break;
		}
		break;
	}
}

// Position - 0x2019F
void func_447(int iParam0) {
	if (iParam0) {
		func_448();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_38(0)) {
			func_408(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x20202
void func_448() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x2022B
void func_449(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	ui::display_area_name(1);
	func_246(8);
	func_299();
	if (iLocal_306) {
		func_467(&iLocal_322);
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		iVar1 = 0;
		while (iVar1 < 3) {
			func_389(&iParam0->f_5[iVar0 /*79*/][iVar1 /*26*/]);
			iVar1++;
		}
		iVar0++;
	}
	streaming::set_model_as_no_longer_needed(iLocal_28);
	streaming::set_model_as_no_longer_needed(iLocal_29);
	if (!ped::is_ped_injured(uLocal_296[0]) && !ped::is_ped_injured(uLocal_296[1])) {
		ai::task_clear_look_at(uLocal_296[0]);
		ai::task_clear_look_at(uLocal_296[1]);
	}
	func_466();
	streaming::set_model_as_no_longer_needed(iLocal_60);
	func_465();
	func_464(uParam1->f_645);
	func_463(&uParam1->f_57);
	if (!entity::is_entity_dead(func_479(), 0)) {
		ped::set_ped_as_group_member(func_479(), func_462());
		func_461(iLocal_330, iLocal_331);
	}
	else {
		func_459(&uLocal_296[1]);
	}
	func_447(0);
	func_458(uParam2);
	func_35(0);
	ui::reset_hud_component_values(15);
	if (player::is_player_online()) {
		if (iParam0->f_460 && !iLocal_320) {
			func_457(190, 0);
		}
	}
	func_92();
	func_439();
	func_84(&uParam1->f_72);
	system::wait(200);
	if (iLocal_313) {
		func_453(130, 0, 0);
		func_450();
	}
	func_443(23, 0);
	script::terminate_this_thread();
}

// Position - 0x20378
void func_450() { func_451(); }

// Position - 0x20385
int func_451() {
	if (func_452(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x203D0
bool func_452(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x203FB
void func_453(int iParam0, int iParam1, int iParam2) {
	bool bVar0;

	if (iParam0 < 0) {
	}
	if (iParam0 == 321 || iParam0 > 321) {
	}
	else {
		func_456(891 + iParam0, 1, -1, 1);
	}
	bVar0 = true;
	if (Global_101700.f_9153[iParam0 /*12*/].f_5 == 1) {
		if (Global_101700.f_9153[iParam0 /*12*/].f_6 == 11 || Global_101700.f_9153[iParam0 /*12*/].f_6 == 12) {
			bVar0 = false;
		}
	}
	else {
		Global_101700.f_9153[iParam0 /*12*/].f_5 = 1;
		Global_101700.f_9153[iParam0 /*12*/].f_10 = iParam1;
		Global_101700.f_9153[iParam0 /*12*/].f_11 = iParam2;
		if (iParam0 == 287) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_0"), 50, 0);
		}
		if (iParam0 == 286) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_1"), 50, 0);
		}
		if (iParam0 == 299) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_3"), 50, 0);
		}
	}
	if (bVar0) {
		func_454();
	}
}

// Position - 0x204E3
void func_454() {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	int iVar9;

	iVar0 = 0;
	Global_101436 = 0;
	Global_101437 = 0;
	Global_101438 = 0;
	Global_101439 = 0;
	Global_101440 = 0;
	Global_101441 = 0;
	Global_101442 = 0;
	fVar1 = 0f;
	fVar2 = 0f;
	fVar3 = 0f;
	fVar4 = 0f;
	fVar5 = 0f;
	fVar6 = 0f;
	fVar7 = 0f;
	fVar8 = Global_101700.f_9153.f_3853;
	Global_101700.f_9153.f_3853 = 0f;
	while (iVar0 < 321) {
		if (Global_101700.f_9153[iVar0 /*12*/].f_5 == 1) {
			switch (Global_101700.f_9153[iVar0 /*12*/].f_6) {
			case 1:
				Global_101436++;
				fVar1 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 3:
				Global_101437++;
				fVar2 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 5:
				Global_101438++;
				fVar3 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 7:
				Global_101439++;
				fVar4 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 9:
				Global_101440++;
				fVar5 += Global_101700.f_9153[iVar0 /*12*/].f_4 * 4f;
				break;

			case 11:
				Global_101441++;
				fVar6 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 13:
				Global_101442++;
				fVar7 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			default: break;
			}
		}
		iVar0++;
	}
	if (Global_101419 > 0) {
		if (Global_101436 == Global_101419) {
			fVar1 = 55f;
		}
	}
	if (Global_101420 > 0) {
		if (Global_101437 == Global_101420) {
			fVar2 = 10f;
		}
	}
	if (Global_101421 > 0) {
		if (Global_101438 == Global_101421) {
			fVar3 = 0f;
		}
	}
	if (Global_101422 > 0) {
		if (Global_101439 == Global_101422) {
			fVar4 = 10f;
		}
	}
	if (Global_101423 > 0) {
		if (Global_101440 == Global_101423 || Global_101423 * 10 / Global_101440 < 41 ||
			Global_101440 > Global_101426 || Global_101440 == Global_101426) {
			if (!gameplay::is_bit_set(Global_101700.f_9153.f_3856, 14)) {
				if (Global_101440 == Global_101423) {
					stats::_0x11FF1C80276097ED(joaat("num_rndevents_completed"), Global_101423, 0);
					gameplay::set_bit(&Global_101700.f_9153.f_3856, 14);
				}
			}
			fVar5 = 5f;
		}
	}
	if (Global_101424 > 0) {
		if (Global_101441 == Global_101424) {
			fVar6 = 15f;
		}
	}
	if (Global_101425 > 0) {
		if (Global_101442 == Global_101425) {
			fVar7 = 5f;
		}
	}
	Global_101700.f_9153.f_3853 = fVar1 + fVar2 + fVar3 + fVar4 + fVar5 + fVar6 + fVar7;
	if (Global_101440 > Global_101426 || Global_101440 == Global_101426) {
		iVar9 = Global_101426;
	}
	else {
		iVar9 = Global_101440;
	}
	stats::stat_set_int(joaat("num_missions_completed"), Global_101436, 1);
	stats::stat_set_int(joaat("num_missions_available"), Global_101419, 1);
	stats::stat_set_int(joaat("num_minigames_completed"), Global_101437, 1);
	stats::stat_set_int(joaat("num_minigames_available"), Global_101420, 1);
	stats::stat_set_int(joaat("num_oddjobs_completed"), Global_101438, 1);
	stats::stat_set_int(joaat("num_oddjobs_available"), Global_101421, 1);
	stats::stat_set_int(joaat("num_rndpeople_completed"), Global_101439, 1);
	stats::stat_set_int(joaat("num_rndpeople_available"), Global_101422, 1);
	stats::stat_set_int(joaat("num_rndevents_completed"), iVar9, 1);
	stats::stat_set_int(joaat("num_rndevents_available"), Global_101426, 1);
	stats::stat_set_int(joaat("num_misc_completed"), Global_101442 + Global_101441, 1);
	stats::stat_set_int(joaat("num_misc_available"), Global_101425 + Global_101424, 1);
	Global_101443 = Global_101436 * 100 / Global_101419;
	Global_101445 = Global_101438 + Global_101437 * 100 / (Global_101421 + Global_101420);
	Global_101444 = Global_101439 + iVar9 * 100 / (Global_101422 + Global_101426);
	Global_101446 = Global_101441 + Global_101442 * 100 / (Global_101424 + Global_101425);
	stats::stat_set_float(joaat("total_progress_made"), Global_101700.f_9153.f_3853, 1);
	stats::stat_set_int(joaat("percent_story_missions"), Global_101443, 1);
	stats::stat_set_int(joaat("percent_ambient_missions"), Global_101444, 1);
	stats::stat_set_int(joaat("percent_oddjobs"), Global_101445, 1);
	if (fVar8 > 0f && system::floor(fVar8) < system::floor(Global_101700.f_9153.f_3853)) {
		func_75(13, system::floor(Global_101700.f_9153.f_3853));
	}
	if (!datafile::datafile_is_save_pending()) {
		if (!Global_69702) {
			if (func_455() == 2 == 0 && !network::network_is_game_in_progress()) {
				if (network::network_is_cloud_available()) {
					Global_101434 = 0;
				}
				if (!Global_55822) {
					func_451();
				}
			}
		}
	}
}

// Position - 0x209A4
int func_455() { return Global_25190; }

// Position - 0x209AF
int func_456(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;
	var uVar6;
	var uVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;

	if (iParam2 == -1) {
		iParam2 = func_338();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
		iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
		iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
		iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
		iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
		iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
		iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		uVar9 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2, "_NGTATPSTAT_BOOL");
		iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2, "_DLCBIKEPSTAT_BOOL");
		iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
	}
	return iVar0;
}

// Position - 0x20D43
void func_457(int iParam0, int iParam1) {
	struct<6> Var0[1];
	struct<8> Var7[1];

	if (!player::is_player_online()) {
		return;
	}
	StringCopy(&Var7[0 /*8*/], "GameType", 32);
	if (iParam1) {
		StringCopy(&Var0[0 /*6*/], "MP", 24);
	}
	else {
		StringCopy(&Var0[0 /*6*/], "SP", 24);
	}
	if (func_211(iParam0, &Var0, &Var7, 1, -1, 0, 0)) {
		stats::_0x0BCA1D2C47B0D269(103, iLocal_151[1], 0f);
		stats::_0x0BCA1D2C47B0D269(99, iLocal_151[2], 0f);
		stats::_0x0BCA1D2C47B0D269(109, iLocal_151[3], 0f);
		stats::_0x0BCA1D2C47B0D269(106, iLocal_151[5], 0f);
		stats::_0x0BCA1D2C47B0D269(2, iLocal_151[10], 0f);
		stats::_0x0BCA1D2C47B0D269(107, iLocal_151[8], 0f);
		stats::_0x0BCA1D2C47B0D269(116, iLocal_151[6], 0f);
	}
}

// Position - 0x20DEE
void func_458(var *uParam0) {
	if (uParam0->f_1 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_1);
		uParam0->f_1 = 0;
	}
	if (uParam0->f_562 && uParam0->f_4 != 0) {
		if (gameplay::is_pc_version()) {
			graphics::_push_scaleform_movie_function(uParam0->f_4, "TOGGLE_MOUSE_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_4);
		uParam0->f_4 = 0;
	}
	if (uParam0->f_564) {
		script::set_no_loading_screen(0);
		uParam0->f_564 = 0;
	}
	if (!Global_69970) {
		if (!player::is_player_dead(player::get_player_index())) {
			if (!G_TextMessageConfig) {
				if (cam::is_screen_faded_out() && !func_452(0)) {
					cam::do_screen_fade_in(800);
				}
			}
		}
	}
	func_35(0);
}

// Position - 0x20E95
void func_459(var *uParam0) {
	if (entity::does_entity_exist(*uParam0) && !ped::is_ped_injured(*uParam0)) {
		ai::clear_sequence_task(&iLocal_333);
		ai::open_sequence_task(&iLocal_333);
		if (entity::does_entity_exist(uLocal_296[0])) {
			ai::task_look_at_entity(0, uLocal_296[0], 8000, 2049, 3);
		}
		ai::task_stand_still(0, 1000);
		if (bLocal_311) {
			if (!gameplay::is_bit_set(Global_101661, 10)) {
				ai::task_follow_nav_mesh_to_coord(0, func_460(iLocal_335 == 2, vLocal_376, vLocal_382), 1f, 20000,
												  0.25f, 0, func_111(iLocal_335 == 2, fLocal_386, fLocal_388));
			}
			else {
				ai::task_follow_nav_mesh_to_coord(0, func_460(iLocal_335 == 2, vLocal_373, vLocal_379), 1f, 20000,
												  0.25f, 0, func_111(iLocal_335 == 2, fLocal_385, fLocal_387));
			}
			ai::task_start_scenario_in_place(0, "WORLD_HUMAN_HANG_OUT_STREET", 0, 1);
		}
		else {
			ai::task_follow_nav_mesh_to_coord(0, func_460(iLocal_335 == 2, vLocal_373, vLocal_379), 1f, 20000, 0.25f, 0,
											  func_111(iLocal_335 == 2, 172.6813f, 142.6717f));
			ai::task_start_scenario_in_place(0, "WORLD_HUMAN_STAND_IMPATIENT", 0, 1);
		}
		ai::close_sequence_task(iLocal_333);
		ai::task_perform_sequence(*uParam0, iLocal_333);
		ped::set_ped_keep_task(*uParam0, 1);
	}
	streaming::set_model_as_no_longer_needed(iLocal_332);
}

// Position - 0x20FD0
Vector3 func_460(bool bParam0, vector3 vParam1, vector3 vParam4) {
	if (bParam0) {
		return vParam1;
	}
	return vParam4;
}

// Position - 0x20FEB
void func_461(int iParam0, var uParam1) {
	if (Global_87650 == iParam0) {
		Global_87651 = Global_87650;
		Global_87652 = uParam1;
		Global_87650 = 23;
	}
}

// Position - 0x21013
var func_462() { return player::get_player_group(player::get_player_index()); }

// Position - 0x21023
void func_463(int *iParam0) {
	if (graphics::has_scaleform_movie_loaded(*iParam0)) {
		graphics::set_scaleform_movie_as_no_longer_needed(iParam0);
		*iParam0 = 0;
	}
}

// Position - 0x2103F
void func_464(var uParam0) { graphics::set_scaleform_movie_as_no_longer_needed(&uParam0); }

// Position - 0x2104D
void func_465() {
	ui::clear_help(1);
	cam::destroy_all_cams(0);
	player::set_player_control(player::player_id(), 1, 0);
	ui::display_radar(1);
}

// Position - 0x2106E
void func_466() {
	if (entity::does_entity_exist(iLocal_59)) {
		object::delete_object(&iLocal_59);
	}
}

// Position - 0x21085
void func_467(var *uParam0) {
	int iVar0;

	iVar0 = *uParam0;
	if (entity::does_entity_exist(iVar0)) {
		if (!func_413(iVar0)) {
			entity::set_entity_collision(iVar0, 1, 0);
			entity::set_entity_visible(iVar0, 1, 0);
			entity::freeze_entity_position(iVar0, 0);
		}
	}
}

// Position - 0x210BC
void func_468() {
	int iVar0;

	if (script::has_script_loaded("buddyDeathResponse")) {
		system::start_new_script("buddyDeathResponse", 1424);
	}
	if (Global_101700.f_8044 || func_452(0)) {
		if (!func_476()) {
			iVar0 = func_475();
			if (iVar0 != -1) {
				if (!func_470(iVar0)) {
					return;
				}
				gameplay::set_bit(&Global_82576[iVar0 /*5*/].f_1, 5);
				return;
			}
		}
		else {
			func_469();
		}
	}
}

// Position - 0x2112D
void func_469() {
	Global_91526 = 1;
	if (player::is_player_being_arrested(player::player_id(), 1)) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_79()) {
			case 0: StringCopy(&Global_69934, "CMN_MARRE", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FARRE", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TARRE", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
	}
	else if (!player::is_player_playing(player::player_id())) {
		if (gameplay::is_string_null_or_empty(&Global_69934)) {
			switch (func_79()) {
			case 0: StringCopy(&Global_69934, "CMN_MDIED", 16); break;

			case 1: StringCopy(&Global_69934, "CMN_FDIED", 16); break;

			case 2: StringCopy(&Global_69934, "CMN_TDIED", 16); break;
			}
			StringCopy(&Global_69938, "", 16);
		}
		Global_91526 = 0;
		gameplay::set_bit(&Global_91491.f_20, 25);
	}
}

// Position - 0x2121C
int func_470(int iParam0) {
	int iVar0;
	int iVar1;

	func_469();
	if (player::is_player_playing(player::player_id())) {
		player::start_firing_amnesty(5000);
	}
	iVar0 = Global_82576[iParam0 /*5*/];
	iVar1 = G_TextMessageConfig.f_109[iVar0 /*4*/];
	func_474(iVar1, 1);
	player::_0xC9A763D8FE87436A(player::player_id());
	player::special_ability_deactivate(player::player_id());
	func_471(&Global_101700.f_2095.f_539, iVar1);
	if (Global_85999 == Global_91528) {
		Global_101700.f_8044.f_330[iVar1 /*6*/].f_1++;
	}
	if (!gameplay::is_bit_set(Global_82612[iVar1 /*34*/].f_15, 1)) {
		if (!player::is_player_playing(player::player_id())) {
			gameplay::set_fade_in_after_death_arrest(0);
		}
	}
	Global_101700.f_8044.f_330[iVar1 /*6*/].f_2++;
	Global_85999 = Global_91528;
	if (iParam0 == -1) {
		if (Global_101700.f_8044) {
		}
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 4)) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_82576[iParam0 /*5*/].f_1, 5)) {
		return 0;
	}
	return 1;
}

// Position - 0x21333
void func_471(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_473(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_472(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0x214FC
void func_472(int *iParam0) { *iParam0 = -15; }

// Position - 0x2150A
int func_473(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_473(8, uParam1, fParam2);

	case 10: return func_473(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0x21E79
void func_474(int iParam0, int iParam1) {
	if (iParam1) {
		if (iParam0 != 88 && iParam0 != 89 && iParam0 != 92) {
			Global_85809[iParam0 /*2*/] = 1;
		}
	}
	else {
		Global_85809[iParam0 /*2*/] = 0;
	}
}

// Position - 0x21EB7
int func_475() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (gameplay::is_bit_set(Global_82576[iVar0 /*5*/].f_1, 2)) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x21EEC
int func_476() {
	if (Global_91491 == 13 || Global_91491 == 10 || Global_91491 == 11 || Global_91491 == 12) {
		return 0;
	}
	return 1;
}

// Position - 0x21F2A
void func_477(int iParam0, int iParam1) {
	if (ped::is_ped_injured(func_479())) {
		return;
	}
	if (iParam1) {
		if (!ped::is_ped_group_member(func_479(), func_462())) {
			return;
		}
		if (!ped::is_ped_injured(func_478())) {
			if (!ped::is_ped_group_member(func_478(), func_462())) {
				return;
			}
		}
	}
	if (Global_87650 == 23) {
		Global_87652 = 10;
		Global_87650 = iParam0;
	}
}

// Position - 0x21F8F
var func_478() { return Global_87657; }

// Position - 0x21F9B
int func_479() { return Global_87656; }

// Position - 0x21FA7
void func_480() {
	if (iLocal_291 == 1) {
		return;
	}
	func_299();
	controls::_0x3D42B92563939375("Darts");
	iLocal_291 = 1;
}

// Position - 0x21FCA
int func_481(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_82(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

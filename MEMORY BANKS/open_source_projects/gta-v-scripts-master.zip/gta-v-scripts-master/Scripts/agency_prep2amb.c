#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
int iLocal_37 = 0;
int iLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
struct<9> Local_44 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0
};
char *sLocal_53[46] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
					   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
					   NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
int iLocal_100 = 0;
var uLocal_101[2] = {0, 0};
float fLocal_104 = 0f;
int iLocal_105 = 0;
vector3 vLocal_106 = {0f, 0f, 0f};
int iLocal_109 = 0;
vector3 vLocal_110 = {0f, 0f, 0f};
float fLocal_113 = 0f;
struct<67> Local_114 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
int iLocal_192[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
int iLocal_203 = 0;
struct<261> Local_204[4];
char *sLocal_1249[13] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
char *sLocal_1263 = NULL;
int iLocal_1264 = 0;
int iLocal_1265 = 0;
int iLocal_1266 = 0;
int iLocal_1267 = 0;
int iLocal_1268 = 0;
int iLocal_1269 = 0;
int iLocal_1270 = 0;
int iLocal_1271 = 0;
char *sLocal_1272 = NULL;
var *uLocal_1273 = NULL;
var uLocal_1274 = 0;
var uLocal_1275 = 0;
var uLocal_1276 = 0;
var uLocal_1277 = 0;
var uLocal_1278 = 0;
var uLocal_1279 = 0;
var uLocal_1280 = 0;
var uLocal_1281 = 0;
var uLocal_1282 = 0;
var uLocal_1283 = 0;
var uLocal_1284 = 0;
var uLocal_1285 = 0;
var uLocal_1286 = 0;
var uLocal_1287 = 0;
var uLocal_1288 = 0;
var uLocal_1289 = 0;
var uLocal_1290 = 0;
var uLocal_1291 = 0;
var uLocal_1292 = 0;
var uLocal_1293 = 0;
var uLocal_1294 = 0;
var uLocal_1295 = 0;
var uLocal_1296 = 0;
var uLocal_1297 = 0;
var uLocal_1298 = 0;
var uLocal_1299 = 0;
var uLocal_1300 = 0;
var uLocal_1301 = 0;
var uLocal_1302 = 0;
var uLocal_1303 = 0;
var uLocal_1304 = 0;
var uLocal_1305 = 0;
var uLocal_1306 = 0;
var uLocal_1307 = 0;
var uLocal_1308 = 0;
var uLocal_1309 = 0;
var uLocal_1310 = 0;
var uLocal_1311 = 0;
var uLocal_1312 = 0;
var uLocal_1313 = 0;
var uLocal_1314 = 0;
var uLocal_1315 = 0;
var uLocal_1316 = 0;
var uLocal_1317 = 0;
var uLocal_1318 = 0;
var uLocal_1319 = 0;
var uLocal_1320 = 0;
var uLocal_1321 = 0;
var uLocal_1322 = 0;
var uLocal_1323 = 0;
var uLocal_1324 = 0;
var uLocal_1325 = 0;
var uLocal_1326 = 0;
var uLocal_1327 = 0;
var uLocal_1328 = 0;
var uLocal_1329 = 0;
var uLocal_1330 = 0;
var uLocal_1331 = 0;
var uLocal_1332 = 0;
var uLocal_1333 = 0;
var uLocal_1334 = 0;
var uLocal_1335 = 0;
var uLocal_1336 = 0;
var uLocal_1337 = 0;
var uLocal_1338 = 0;
var uLocal_1339 = 0;
var uLocal_1340 = 0;
var uLocal_1341 = 0;
var uLocal_1342 = 0;
var uLocal_1343 = 0;
var uLocal_1344 = 0;
var uLocal_1345 = 0;
var uLocal_1346 = 0;
var uLocal_1347 = 0;
var uLocal_1348 = 0;
var uLocal_1349 = 0;
var uLocal_1350 = 0;
var uLocal_1351 = 0;
var uLocal_1352 = 0;
var uLocal_1353 = 0;
var uLocal_1354 = 0;
var uLocal_1355 = 0;
var uLocal_1356 = 0;
var uLocal_1357 = 0;
var uLocal_1358 = 0;
var uLocal_1359 = 0;
var uLocal_1360 = 0;
var uLocal_1361 = 0;
var uLocal_1362 = 0;
var uLocal_1363 = 0;
var uLocal_1364 = 0;
var uLocal_1365 = 0;
var uLocal_1366 = 0;
var uLocal_1367 = 0;
var uLocal_1368 = 0;
var uLocal_1369 = 0;
var uLocal_1370 = 0;
var uLocal_1371 = 0;
var uLocal_1372 = 0;
var uLocal_1373 = 0;
var uLocal_1374 = 0;
var uLocal_1375 = 0;
var uLocal_1376 = 0;
var uLocal_1377 = 0;
var uLocal_1378 = 0;
var uLocal_1379 = 0;
var uLocal_1380 = 0;
var uLocal_1381 = 0;
var uLocal_1382 = 0;
var uLocal_1383 = 0;
var uLocal_1384 = 0;
var uLocal_1385 = 0;
var uLocal_1386 = 0;
var uLocal_1387 = 0;
var uLocal_1388 = 0;
var uLocal_1389 = 0;
var uLocal_1390 = 0;
var uLocal_1391 = 0;
var uLocal_1392 = 0;
var uLocal_1393 = 0;
var uLocal_1394 = 0;
var uLocal_1395 = 0;
var uLocal_1396 = 0;
var uLocal_1397 = 0;
var uLocal_1398 = 0;
var uLocal_1399 = 0;
var uLocal_1400 = 0;
var uLocal_1401 = 0;
var uLocal_1402 = 0;
var uLocal_1403 = 0;
var uLocal_1404 = 0;
var uLocal_1405 = 0;
var uLocal_1406 = 0;
var uLocal_1407 = 0;
var uLocal_1408 = 0;
var uLocal_1409 = 0;
var uLocal_1410 = 0;
var uLocal_1411 = 0;
var uLocal_1412 = 0;
var uLocal_1413 = 0;
var uLocal_1414 = 0;
var uLocal_1415 = 0;
var uLocal_1416 = 0;
var uLocal_1417 = 0;
var uLocal_1418 = 0;
var uLocal_1419 = 0;
var uLocal_1420 = 0;
var uLocal_1421 = 0;
var uLocal_1422 = 0;
var uLocal_1423 = 0;
var uLocal_1424 = 0;
var uLocal_1425 = 0;
var uLocal_1426 = 0;
var uLocal_1427 = 0;
var uLocal_1428 = 0;
var uLocal_1429 = 0;
var uLocal_1430 = 0;
var uLocal_1431 = 0;
var uLocal_1432 = 0;
var uLocal_1433 = 0;
var uLocal_1434 = 0;
var uLocal_1435 = 0;
var uLocal_1436 = 0;
var uLocal_1437 = 0;
int iLocal_1438 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_43 = 145;
	iLocal_100 = -1;
	fLocal_104 = 0f;
	vLocal_106 = {0f, 0f, 0f};
	vLocal_110 = {0f, 0f, 0f};
	fLocal_113 = 0f;
	iLocal_203 = 1;
	sLocal_1263 = "";
	iLocal_1266 = -1;
	iLocal_1269 = -1;
	iLocal_1271 = -1;
	iLocal_1438 = -1;
	if (!func_264(32)) {
		iLocal_37 = Global_101700.f_9008.f_128;
		if (iLocal_37 == 2) {
			gameplay::set_bit(&iLocal_105, 10);
			vLocal_110 = {func_263(25)};
			fLocal_113 = func_262(25);
			if (func_261(&Local_114, 25)) {
				if (!gameplay::is_bit_set(iLocal_105, 14)) {
					gameplay::set_bit(&iLocal_105, 14);
				}
			}
		}
	}
	else {
		func_259("AM_H_PREP8", 2, 0, -1, 10000, 3, 0, 0, 0);
		Global_101700.f_9008.f_128 = iLocal_37;
	}
	if (player::has_force_cleanup_occurred(82)) {
		if (player::get_cause_of_most_recent_force_cleanup() == 2) {
			func_250(0);
			func_248(32, 1);
		}
		else {
			func_248(32, 0);
		}
	}
	func_243(1);
	while (true) {
		if (func_242(69)) {
			func_238("AM_H_PREP8", 1);
			func_248(32, 0);
		}
		if (!func_236(1)) {
			if (func_235(player::player_ped_id())) {
				func_228();
				func_221();
				func_220();
				func_209();
				switch (iLocal_37) {
				case 0: func_134(); break;

				case 2: func_133(); break;

				case 3: func_124(); break;

				case 4: func_15(12); break;

				case 5: break;

				default: break;
				}
				func_7();
			}
			else {
				func_1(46, 1);
			}
		}
		system::wait(0);
	}
}

// Position - 0x1D4
void func_1(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 46 - 1) {
		if (iParam0 != iVar0 && iParam0 != 46) {
			func_4(iVar0);
		}
		iVar0++;
	}
	if (iParam1) {
		if (iParam0 != 46) {
			if (!func_2(func_3(iParam0)) && !Global_100342 && !gameplay::is_bit_set(iLocal_105, 15)) {
				gameplay::set_bit(&iLocal_105, 15);
				ui::clear_help(1);
			}
		}
		else if (ui::is_help_message_being_displayed() && !Global_100342 && !gameplay::is_bit_set(iLocal_105, 15)) {
			gameplay::set_bit(&iLocal_105, 15);
			ui::clear_help(1);
		}
	}
}

// Position - 0x277
bool func_2(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x28A
char *func_3(int iParam0) { return sLocal_53[iParam0]; }

// Position - 0x298
void func_4(int iParam0) {
	int iVar0;

	iVar0 = func_6(iParam0);
	gameplay::clear_bit(&uLocal_101[func_5(iParam0)], iVar0);
}

// Position - 0x2B8
int func_5(int iParam0) {
	int iVar0;

	if (iParam0 < 32) {
		iVar0 = 0;
	}
	else {
		iVar0 = 1;
	}
	return iVar0;
}

// Position - 0x2D2
int func_6(int iParam0) {
	if (iParam0 > 31) {
		return iParam0 - 32;
	}
	return iParam0;
}

// Position - 0x2EB
void func_7() {
	if (gameplay::is_bit_set(iLocal_105, 0) && !gameplay::is_bit_set(iLocal_105, 1) &&
		!gameplay::is_bit_set(iLocal_105, 14) && func_12()) {
		if (func_11(0, 172, 0) || func_11(0, 173, 0)) {
			iLocal_1271 = gameplay::get_game_timer();
		}
		if (iLocal_1271 != -1) {
			if (gameplay::get_game_timer() - iLocal_1271 < 200) {
				iLocal_43 = func_8();
			}
			else {
				iLocal_1271 = -1;
			}
		}
	}
	else {
		iLocal_43 = 145;
		iLocal_1271 = -1;
	}
}

// Position - 0x36D
int func_8() {
	var uVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar2 = 0;
	iVar3 = 145;
	if (Global_69702) {
		iVar3 = 145;
	}
	else if (graphics::has_scaleform_movie_loaded(Global_14424) == 1) {
		if (func_10()) {
			if (func_9()) {
				iVar6 = 0;
				graphics::_push_scaleform_movie_function(Global_14424, "GET_CURRENT_SELECTION");
				uVar0 = graphics::_pop_scaleform_movie_function();
				iVar4 = gameplay::get_game_timer();
				while (!graphics::_0x768FF8961BA904D6(uVar0) && iVar6 == 0 &&
					   graphics::has_scaleform_movie_loaded(Global_14424) == 1) {
					system::wait(0);
					iVar5 = gameplay::get_game_timer();
					if (iVar5 - iVar4 > 1500) {
						iVar6 = 1;
					}
				}
				iVar1 = graphics::_0x2DE7EFA66B906036(uVar0);
				if (iVar1 > 150 || iVar1 < 0) {
					iVar1 = 150;
				}
				iVar2 = Global_14449[iVar1];
				iVar3 = iVar2;
				if (graphics::has_scaleform_movie_loaded(Global_14424) == 0) {
					iVar3 = 145;
				}
				if (iVar6 == 1) {
					iVar3 = 145;
				}
			}
			else {
				iVar3 = 145;
			}
		}
		else {
			iVar3 = 145;
		}
	}
	else {
		iVar3 = 145;
	}
	return iVar3;
}

// Position - 0x455
bool func_9() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	return false;
}

// Position - 0x46F
bool func_10() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("appcontacts")) > 0) {
		return true;
	}
	return false;
}

// Position - 0x489
int func_11(int iParam0, int iParam1, int iParam2) {
	if (controls::is_control_just_pressed(iParam0, iParam1) ||
		iParam2 == 1 && controls::is_disabled_control_just_pressed(iParam0, iParam1)) {
		if (gameplay::is_pc_version()) {
			if (gameplay::update_onscreen_keyboard() == 0 ||
				network::_network_is_text_chat_active() && controls::_is_input_disabled(2)) {
				return 0;
			}
		}
		if (ui::is_pause_menu_active() || ui::is_warning_message_active()) {
			return 0;
		}
		else {
			return 1;
		}
	}
	return 0;
}

// Position - 0x4FB
bool func_12() {
	if (func_14(0) && func_13()) {
		return true;
	}
	return false;
}

// Position - 0x519
int func_13() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("appcontacts")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0x536
bool func_14(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x590
void func_15(int iParam0) {
	func_106();
	if (iLocal_40 == 0) {
		switch (iLocal_41) {
		case 0:
			func_105(1);
			iLocal_1267 = unk_0x67D02A194A2FC2BD("MP_BIG_MESSAGE_FREEMODE");
			func_1(46, 1);
			iLocal_1268 = gameplay::get_game_timer() + 3000;
			if (!gameplay::is_bit_set(iLocal_105, 10)) {
				func_89();
			}
			func_88(iParam0, 1);
			iLocal_41 = 1;
			break;

		case 1:
			if (gameplay::get_game_timer() > iLocal_1268) {
				if (graphics::has_scaleform_movie_loaded(iLocal_1267)) {
					graphics::_push_scaleform_movie_function(iLocal_1267, "SHOW_MISSION_PASSED_MESSAGE");
					func_87("M_FB4P3_P");
					func_87("M_FB4P3");
					graphics::_push_scaleform_movie_function_parameter_int(100);
					graphics::_push_scaleform_movie_function_parameter_bool(1);
					graphics::_push_scaleform_movie_function_parameter_int(0);
					graphics::_push_scaleform_movie_function_parameter_bool(1);
					graphics::_pop_scaleform_movie_function_void();
					iLocal_1268 = gameplay::get_game_timer() + 10000;
					func_85(0);
					iLocal_41 = 2;
				}
			}
			break;

		case 2:
			if (graphics::has_scaleform_movie_loaded(iLocal_1267) && audio::_0x6F259F82D873B8B8()) {
				if (gameplay::get_game_timer() < iLocal_1268) {
					graphics::draw_scaleform_movie(iLocal_1267, 0.5f, 0.3f, 1f, 1f, 255, 255, 255, 255, 0);
				}
				else if (gameplay::get_game_timer() < iLocal_1268 + 100) {
					graphics::_push_scaleform_movie_function(iLocal_1267, "TRANSITION_OUT");
					graphics::_pop_scaleform_movie_function_void();
					iLocal_1268 -= 100;
				}
				else if (gameplay::get_game_timer() < iLocal_1268 + 500) {
					graphics::draw_scaleform_movie(iLocal_1267, 0.5f, 0.3f, 1f, 1f, 255, 255, 255, 255, 0);
				}
				else {
					iLocal_41 = 3;
				}
			}
			break;

		case 3:
			if (graphics::has_scaleform_movie_loaded(iLocal_1267)) {
				graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_1267);
			}
			func_105(0);
			if (iLocal_42 == 2) {
				func_84(108, 0);
			}
			if (func_82(iLocal_109)) {
				vehicle::set_vehicle_doors_locked(iLocal_109, 1);
			}
			func_78("M_FHPE", func_79());
			func_75(2, 0);
			break;
		}
	}
	func_16();
}

// Position - 0x735
void func_16() {
	int iVar0;

	if (!gameplay::is_bit_set(iLocal_105, 2)) {
		if (!func_74(0f, 0f, 0f, vLocal_110, 0)) {
			if (func_73(player::player_ped_id(), vLocal_110, 100f) && !func_72()) {
				if (func_82(func_71(25))) {
					iLocal_109 = func_71(25);
					entity::set_entity_as_mission_entity(iLocal_109, 1, 1);
					if (func_82(iLocal_109)) {
						if (!decorator::decor_exist_on(iLocal_109, "GetawayVehicleValid")) {
							if (decorator::decor_set_bool(iLocal_109, "GetawayVehicleValid", 1)) {
							}
						}
						gameplay::set_bit(&iLocal_105, 0);
						gameplay::set_bit(&iLocal_105, 2);
					}
				}
				else if (!func_70(25, 0)) {
					if (!func_82(func_71(25))) {
						func_66(1);
					}
				}
			}
			else if (func_82(iLocal_109)) {
				if (!func_73(player::player_ped_id(), vLocal_110, 100f)) {
				}
			}
		}
	}
	else {
		if (!func_74(0f, 0f, 0f, vLocal_110, 0)) {
			if (!func_73(player::player_ped_id(), vLocal_110, 100f)) {
				if (func_82(iLocal_109)) {
					if (!ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_109, 0)) {
						func_20(iLocal_109, vLocal_110, fLocal_113, 25, 1);
						gameplay::clear_bit(&iLocal_105, 2);
						vehicle::_0x02398B627547189C(iLocal_109, 0);
						func_19(&iLocal_109);
						gameplay::clear_bit(&iLocal_105, 0);
					}
					else {
						func_66(0);
					}
				}
				else if (!func_70(25, 0)) {
					func_66(1);
				}
			}
			else if (!func_70(25, 0)) {
				if (!func_82(iLocal_109)) {
					func_66(1);
				}
			}
			else if (!func_82(iLocal_109)) {
				iVar0 = func_71(25);
				if (func_82(iVar0) && iVar0 != iLocal_109) {
					iLocal_109 = iVar0;
				}
			}
		}
		func_17();
	}
}

// Position - 0x8D8
void func_17() {
	if (gameplay::is_bit_set(iLocal_105, 2) && gameplay::is_bit_set(iLocal_105, 0)) {
		if (func_82(iLocal_109)) {
			if (func_18(player::player_ped_id(), iLocal_109, 10f, 1)) {
				if (system::vdist2(entity::get_entity_coords(iLocal_109, 1), vLocal_110) >= 100f) {
					func_66(0);
				}
			}
		}
		else if (!func_70(25, 0)) {
			if (func_82(iLocal_109)) {
				vehicle::_0x02398B627547189C(iLocal_109, 0);
			}
			func_19(&iLocal_109);
			func_66(1);
		}
	}
}

// Position - 0x958
bool func_18(int iParam0, int iParam1, float fParam2, int iParam3) {
	return system::vdist2(entity::get_entity_coords(iParam0, iParam3), entity::get_entity_coords(iParam1, iParam3)) <=
		   fParam2 * fParam2;
}

// Position - 0x97A
void func_19(int iParam0) {
	if (entity::does_entity_exist(*iParam0)) {
		entity::is_entity_dead(*iParam0, 0);
		if (entity::is_entity_a_mission_entity(*iParam0) && entity::does_entity_belong_to_this_script(*iParam0, 1)) {
			entity::set_vehicle_as_no_longer_needed(iParam0);
		}
	}
}

// Position - 0x9B2
void func_20(int iParam0, vector3 vParam1, float fParam4, int iParam5, int iParam6) {
	struct<60> Var0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		if (iParam5 != 24 && iParam5 != 25) {
			return;
		}
		if (iParam5 == 24) {
			if (entity::does_entity_exist(Global_68531.f_484[25]) &&
				vehicle::is_vehicle_driveable(Global_68531.f_484[25], 0)) {
				if (Global_68531.f_484[25] == iParam0) {
					return;
				}
			}
		}
		if (!iParam6) {
			if (vehicle::is_big_vehicle(iParam0) || entity::get_entity_model(iParam0) == joaat("bus") ||
				entity::get_entity_model(iParam0) == joaat("tourbus")) {
				return;
			}
		}
		func_65(iParam5);
		Var0.f_9 = 49;
		Var0.f_59 = 2;
		func_61(iParam0, &Var0);
		if (func_74(vParam1, 0f, 0f, 0f, 0)) {
			vParam1 = {entity::get_entity_coords(iParam0, 1)};
			fParam4 = entity::get_entity_heading(iParam0);
		}
		if (iParam5 == 24) {
			if (gameplay::get_hash_key(script::get_this_script_name()) != joaat("vehicle_gen_controller")) {
				Global_69519 = gameplay::get_hash_key(script::get_this_script_name());
			}
		}
		func_55(iParam5, &Var0, vParam1, fParam4, func_60(iParam0));
		func_21(iParam5, iParam0, 0);
	}
}

// Position - 0xADB
void func_21(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (iParam0 == -1) {
		return;
	}
	if (!func_51(&Global_68531.f_555[0 /*21*/], iParam0)) {
		return;
	}
	if (!gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 12) &&
		!gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
		if (Global_68531.f_555[0 /*21*/].f_4 != entity::get_entity_model(iParam1)) {
			return;
		}
	}
	if (Global_69438 != -1 && Global_69438 != iParam0) {
		return;
	}
	if (entity::does_entity_exist(iParam1)) {
		if (vehicle::is_vehicle_driveable(iParam1, 0)) {
			if (!entity::is_entity_a_mission_entity(iParam1)) {
				entity::set_entity_as_mission_entity(iParam1, 1, 1);
			}
			if (iParam0 == 24) {
				Global_101700.f_31389.f_4801 = func_40();
			}
			if (iParam1 != Global_68531.f_139[iParam0]) {
				if (iParam0 == 24) {
					iVar0 = func_71(iParam0);
					if (entity::does_entity_exist(iVar0) && vehicle::is_vehicle_driveable(iVar0, 0) &&
						iParam1 != iVar0) {
						func_22(iVar0, 145);
					}
				}
				Global_69437 = iParam1;
				Global_69438 = iParam0;
				Global_69439 = iParam2;
			}
		}
	}
}

// Position - 0xBF8
void func_22(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_23(iParam0)) {
		return;
	}
	if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
		iVar0 = vehicle::get_ped_in_vehicle_seat(iParam0, -1, 0);
		if (!entity::does_entity_exist(iVar0)) {
			iVar0 = vehicle::get_last_ped_in_vehicle_seat(iParam0, -1);
		}
		if (entity::does_entity_exist(iVar0) && !ped::is_ped_injured(iVar0)) {
			if (entity::get_entity_model(iVar0) == joaat("player_zero")) {
				iParam1 = 0;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_one")) {
				iParam1 = 1;
			}
			else if (entity::get_entity_model(iVar0) == joaat("player_two")) {
				iParam1 = 2;
			}
		}
		if (iParam1 != 0 && iParam1 != 1 && iParam1 != 2) {
			iParam1 = Global_101700.f_2095.f_539.f_3549;
		}
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		iVar2 = 0;
		while (iVar2 < 2) {
			if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66) {
				if (!gameplay::is_string_null_or_empty(
						&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
					if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
													&Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_1)) {
						Global_101700.f_31389.f_5038[iVar1 /*157*/][iVar2 /*78*/].f_66 = 0;
						Global_101700.f_31389.f_5592[iVar1] = iVar2;
					}
				}
			}
			iVar2++;
		}
		iVar1++;
	}
	iVar1 = 0;
	while (iVar1 < 3) {
		if (entity::get_entity_model(iParam0) == Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66) {
			if (!gameplay::is_string_null_or_empty(&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
				if (gameplay::are_strings_equal(vehicle::get_vehicle_number_plate_text(iParam0),
												&Global_101700.f_31389.f_5600[iVar1 /*78*/].f_1)) {
					Global_101700.f_31389.f_5600[iVar1 /*78*/].f_66 = 0;
				}
			}
		}
		iVar1++;
	}
	Global_101700.f_31389.f_5590 = iParam1;
	Global_69436 = iParam0;
	Global_101700.f_31389.f_5588 = 1;
	func_61(iParam0, &Global_101700.f_31389.f_5510);
}

// Position - 0xDFA
int func_23(int iParam0) {
	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0) || func_38(iParam0, 0, 0) ||
		func_38(iParam0, 1, 0) || func_38(iParam0, 2, 0) || func_60(iParam0) != 145 || func_37(iParam0) ||
		func_36(iParam0) || func_35(iParam0) || func_34(iParam0) || !func_24(entity::get_entity_model(iParam0))) {
		if (func_36(iParam0)) {
		}
		if (func_36(iParam0)) {
		}
		if (func_38(iParam0, 0, 0)) {
		}
		if (func_38(iParam0, 1, 0)) {
		}
		if (func_38(iParam0, 2, 0)) {
		}
		if (func_60(iParam0) != 145) {
		}
		return 0;
	}
	return 1;
}

// Position - 0xED7
int func_24(int iParam0) {
	if (iParam0 == 0) {
		return 0;
	}
	if (!func_25(iParam0, 0)) {
		return 0;
	}
	if (vehicle::is_this_model_a_boat(iParam0) || vehicle::is_this_model_a_plane(iParam0) ||
		vehicle::is_this_model_a_heli(iParam0) || vehicle::is_this_model_a_train(iParam0)) {
		return 0;
	}
	switch (iParam0) {
	case joaat("bus"):
	case joaat("stretch"):
	case joaat("barracks"):
	case joaat("armytanker"):
	case joaat("rhino"):
	case joaat("armytrailer"):
	case joaat("barracks2"):
	case joaat("flatbed"):
	case joaat("ripley"):
	case joaat("towtruck"):
	case joaat("towtruck2"):
	case joaat("airbus"):
	case joaat("coach"):
	case joaat("rentalbus"):
	case joaat("tourbus"):
	case joaat("firetruk"):
	case joaat("pbus"):
	case joaat("trash"):
	case joaat("benson"):
	case joaat("boattrailer"):
	case joaat("biff"):
	case joaat("hauler"):
	case joaat("docktrailer"):
	case joaat("phantom"):
	case joaat("pounder"):
	case joaat("tractor2"):
	case joaat("bulldozer"):
	case joaat("handler"):
	case joaat("tiptruck"):
	case joaat("cutter"):
	case joaat("dump"):
	case joaat("mixer"):
	case joaat("mixer2"):
	case joaat("rubble"):
	case joaat("scrap"):
	case joaat("tiptruck2"):
	case joaat("camper"):
	case joaat("taco"):
	case joaat("boxville"):
	case joaat("boxville2"):
	case joaat("boxville3"):
	case joaat("journey"):
	case joaat("mule"):
	case joaat("mule2"):
	case joaat("police"):
	case joaat("police2"):
	case joaat("police3"):
	case joaat("police4"):
	case joaat("policeb"):
	case joaat("policeold1"):
	case joaat("policeold2"):
	case joaat("policet"):
	case joaat("taxi"):
	case joaat("submersible"):
	case joaat("submersible2"):
	case joaat("monster"): return 0;
	}
	return 1;
}

// Position - 0x1088
int func_25(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_33()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_32() && !func_31() && !func_30() && !func_29() && !func_33()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_30()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_28(iParam0)) {
			return 0;
		}
	}
	if (!func_26(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0x1216
int func_26(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_27()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0x12DC
int func_27() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0x12F0
int func_28(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x2033
int func_29() { return 0; }

// Position - 0x203C
int func_30() { return 1; }

// Position - 0x2045
int func_31() { return 1; }

// Position - 0x204E
int func_32() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0x2067
bool func_33() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return true;
			}
		}
	}
	if (Global_139179 == 2) {
		return true;
	}
	else if (Global_139179 == 3) {
		return false;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x2122
int func_34(int iParam0) {
	int iVar0;
	char *sVar1;

	iVar0 = entity::get_entity_model(iParam0);
	sVar1 = vehicle::get_vehicle_number_plate_text(iParam0);
	if (iVar0 == joaat("speedo") && gameplay::are_strings_equal(sVar1, "LAMAR G ")) {
		return 1;
	}
	if (!func_25(iVar0, 0)) {
		return 1;
	}
	return 0;
}

// Position - 0x2168
bool func_35(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		if (entity::does_entity_exist(Global_89185[iVar0])) {
			if (Global_89185[iVar0] == iParam0) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x21A3
bool func_36(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(iParam0) && vehicle::is_vehicle_driveable(iParam0, 0)) {
		iVar0 = 0;
		while (iVar0 < 9) {
			if (entity::does_entity_exist(Global_89155[iVar0]) &&
				vehicle::is_vehicle_driveable(Global_89155[iVar0], 0)) {
				if (Global_89155[iVar0] == iParam0 &&
					entity::get_entity_model(Global_89155[iVar0]) == entity::get_entity_model(iParam0)) {
					return true;
				}
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x221F
int func_37(int iParam0) {
	int iVar0;

	if (entity::does_entity_exist(Global_68531.f_484[24])) {
		if (iParam0 == Global_68531.f_484[24]) {
			return 0;
		}
	}
	iVar0 = 0;
	while (iVar0 < 68) {
		if (entity::does_entity_exist(Global_68531.f_484[iVar0])) {
			if (iVar0 != 24 && iVar0 != 21 && iVar0 != 22 && iVar0 != 23 && iVar0 != 27 && iVar0 != 30 && iVar0 != 33 &&
				iVar0 != 28 && iVar0 != 31 && iVar0 != 34 && iVar0 != 26 && iVar0 != 29 && iVar0 != 32) {
				if (iParam0 == Global_68531.f_484[iVar0]) {
					return 1;
				}
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x2307
bool func_38(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	char *sVar1;
	int iVar9;

	if (!entity::does_entity_exist(iParam0) || !vehicle::is_vehicle_driveable(iParam0, 0)) {
		return false;
	}
	iVar0 = 0;
	while (func_39(iParam1, iVar0, &sVar1, &iVar9)) {
		if (!iParam2 || gameplay::is_bit_set(Global_101700.f_6188[iVar9], 0)) {
			if (vehicle::is_vehicle_in_garage_area(&sVar1, iParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0x2378
bool func_39(int iParam0, int iParam1, char *sParam2, int *iParam3) {
	StringCopy(sParam2, "", 32);
	switch (iParam0) {
	case 0:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Michael - Beverly Hills", 32);
			*iParam3 = 0;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 1;
			return true;
		}
		break;

	case 1:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Franklin - Aunt", 32);
			*iParam3 = 5;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Franklin - Hills", 32);
			*iParam3 = 6;
			return true;
		}
		break;

	case 2:
		if (iParam1 == 0) {
			StringCopy(sParam2, "Trevor - Countryside", 32);
			*iParam3 = 2;
			return true;
		}
		else if (iParam1 == 1) {
			StringCopy(sParam2, "Trevor - City", 32);
			*iParam3 = 3;
			return true;
		}
		else if (iParam1 == 2) {
			StringCopy(sParam2, "Trevor - Stripclub", 32);
			*iParam3 = 4;
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x244F
var func_40() {
	int *iVar0;

	func_50(&iVar0, time::get_clock_seconds());
	func_49(&iVar0, time::get_clock_minutes());
	func_48(&iVar0, time::get_clock_hours());
	func_43(&iVar0, time::get_clock_day_of_month());
	func_42(&iVar0, time::get_clock_month());
	func_41(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0x2495
void func_41(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x251B
void func_42(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0x254E
void func_43(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_47(*uParam0);
	iVar1 = func_45(*uParam0);
	if (iParam1 < 1 || iParam1 > func_44(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x259F
int func_44(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x2641
var func_45(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_46(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x2666
int func_46(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x267D
int func_47(var uParam0) { return uParam0 & 15; }

// Position - 0x268A
void func_48(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x26C4
void func_49(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x26FF
void func_50(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x273B
bool func_51(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	*uParam0 = {0f, 0f, 0f};
	uParam0->f_3 = 0f;
	uParam0->f_4 = 0;
	StringCopy(&uParam0->f_5, "", 16);
	uParam0->f_9 = 0;
	uParam0->f_10 = 0;
	uParam0->f_11 = 0;
	uParam0->f_12 = 145;
	uParam0->f_13 = -1;
	uParam0->f_14 = 0;
	uParam0->f_15 = {0f, 0f, 0f};
	uParam0->f_18 = {0f, 0f, 0f};
	switch (iParam1) {
	case 0:
		*uParam0 = {-831.8538f, 172.1154f, 69.9058f};
		uParam0->f_3 = 157.5705f;
		uParam0->f_4 = func_52(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 1:
		*uParam0 = {1970.943f, 3801.684f, 31.1396f};
		uParam0->f_3 = 301.3964f;
		uParam0->f_4 = func_52(0, 1);
		uParam0->f_12 = 0;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 2:
		*uParam0 = {-22.6297f, -1439.137f, 29.6549f};
		uParam0->f_3 = 180.0808f;
		uParam0->f_4 = func_52(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 3:
		*uParam0 = {-22.5229f, -1434.699f, 29.6552f};
		uParam0->f_3 = 141.6114f;
		uParam0->f_4 = func_52(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 4:
		*uParam0 = {10.9281f, 545.669f, 174.7951f};
		uParam0->f_3 = 61.392f;
		uParam0->f_4 = func_52(1, 1);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 5:
		*uParam0 = {6.1093f, 544.9742f, 174.2835f};
		uParam0->f_3 = 92.1548f;
		uParam0->f_4 = func_52(1, 2);
		uParam0->f_12 = 1;
		gameplay::set_bit(&uParam0->f_9, 19);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 6:
		*uParam0 = {1981.416f, 3808.131f, 31.1384f};
		uParam0->f_3 = 117.2557f;
		uParam0->f_4 = func_52(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 7:
		*uParam0 = {-1158.488f, -1529.367f, 3.8995f};
		uParam0->f_3 = 35.7505f;
		uParam0->f_4 = func_52(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 8:
		*uParam0 = {148.2868f, -1270.569f, 28.2252f};
		uParam0->f_3 = 208.4685f;
		uParam0->f_4 = func_52(2, 1);
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 20);
		gameplay::set_bit(&uParam0->f_9, 7);
		iVar0 = 1;
		break;

	case 9:
		*uParam0 = {1459.509f, -1380.45f, 78.3259f};
		uParam0->f_3 = 99.6211f;
		uParam0->f_4 = joaat("scorcher");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 10:
		*uParam0 = {-1518.947f, -1387.865f, -0.5134f};
		uParam0->f_3 = 98.3867f;
		uParam0->f_4 = joaat("seashark");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 11:
		*uParam0 = {353.0926f, 3577.593f, 32.351f};
		uParam0->f_3 = 16.6205f;
		uParam0->f_4 = joaat("duster");
		iVar0 = 1;
		gameplay::set_bit(&uParam0->f_9, 6);
		break;

	case 12:
		uParam0->f_14 = 0;
		*uParam0 = {-1652.004f, -3142.348f, 12.9921f};
		uParam0->f_3 = 329.1082f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 13:
		uParam0->f_14 = 1;
		*uParam0 = {-1271.649f, -3380.685f, 12.9451f};
		uParam0->f_3 = 329.5137f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 14:
		uParam0->f_14 = 2;
		*uParam0 = {1735.586f, 3294.531f, 40.1651f};
		uParam0->f_3 = 194.9525f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 359;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 15:
		uParam0->f_14 = 3;
		*uParam0 = {-846.27f, -1363.19f, 0.22f};
		uParam0->f_3 = 108.78f;
		uParam0->f_12 = 0;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 16:
		uParam0->f_14 = 4;
		*uParam0 = {-849.47f, -1354.99f, 0.24f};
		uParam0->f_3 = 109.84f;
		uParam0->f_12 = 1;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 17:
		uParam0->f_14 = 5;
		*uParam0 = {-852.47f, -1346.2f, 0.21f};
		uParam0->f_3 = 108.76f;
		uParam0->f_12 = 2;
		uParam0->f_13 = 356;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 18:
		uParam0->f_14 = 6;
		*uParam0 = {-745.857f, -1433.904f, 4.0005f};
		uParam0->f_12 = 0;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-756.2952f, -1441.609f, 2.9184f};
		uParam0->f_18 = {-738.0606f, -1423.068f, 8.2835f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 19:
		uParam0->f_14 = 7;
		*uParam0 = {-761.8486f, -1453.829f, 4.0005f};
		uParam0->f_12 = 1;
		uParam0->f_13 = 360;
		uParam0->f_15 = {-772.8158f, -1459.957f, 3.2894f};
		uParam0->f_18 = {-754.3353f, -1440.836f, 8.3334f};
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 20:
		uParam0->f_14 = 8;
		*uParam0 = {1769.3f, 3244f, 41.1f};
		uParam0->f_12 = 2;
		uParam0->f_13 = 360;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 28);
		iVar0 = 1;
		break;

	case 21:
		uParam0->f_14 = 9;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 22:
		uParam0->f_14 = 10;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 1;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 23:
		uParam0->f_14 = 11;
		*uParam0 = {192.7897f, -1020.539f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 2;
		uParam0->f_13 = 357;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 14);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 28);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 26:
	case 27:
	case 28:
		iVar1 = iParam1 - 26;
		uParam0->f_14 = 12 + iVar1;
		*uParam0 = {196.2794f, -1020.479f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 29:
	case 30:
	case 31:
		iVar1 = iParam1 - 29;
		uParam0->f_14 = 15 + iVar1;
		*uParam0 = {199.8872f, -1020.048f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 32:
	case 33:
	case 34:
		iVar1 = iParam1 - 32;
		uParam0->f_14 = 18 + iVar1;
		*uParam0 = {203.6006f, -1019.776f, -99.98f};
		uParam0->f_3 = 180f;
		uParam0->f_4 = 0;
		uParam0->f_12 = 0 + iVar1;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 12);
		gameplay::set_bit(&uParam0->f_9, 7);
		gameplay::set_bit(&uParam0->f_9, 27);
		gameplay::set_bit(&uParam0->f_9, 24);
		gameplay::set_bit(&uParam0->f_9, 29);
		iVar0 = 1;
		break;

	case 24:
		uParam0->f_14 = 21;
		*uParam0 = {0f, 0f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = 0;
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 25:
		uParam0->f_14 = 22;
		*uParam0 = {723.2515f, -632.0496f, 27.1484f};
		uParam0->f_3 = 12.9316f;
		uParam0->f_4 = joaat("tailgater");
		gameplay::set_bit(&uParam0->f_9, 10);
		gameplay::set_bit(&uParam0->f_9, 11);
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 12);
		iVar0 = 1;
		break;

	case 35:
		*uParam0 = {-51.23f, 3111.9f, 24.95f};
		uParam0->f_3 = 46.78f;
		uParam0->f_4 = joaat("proptrailer");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 36:
		*uParam0 = {-55.7984f, -1096.586f, 25.4223f};
		uParam0->f_3 = 308.0596f;
		uParam0->f_4 = joaat("bjxl");
		uParam0->f_10 = 126;
		uParam0->f_11 = 126;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 37:
		*uParam0 = {-2892.93f, 3192.37f, 11.66f};
		uParam0->f_3 = -132.35f;
		uParam0->f_4 = joaat("velum");
		uParam0->f_10 = 157;
		uParam0->f_11 = 157;
		gameplay::set_bit(&uParam0->f_9, 9);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 13);
		iVar0 = 1;
		break;

	case 38:
		*uParam0 = {1744.308f, 3270.673f, 40.2076f};
		uParam0->f_3 = 125f;
		uParam0->f_4 = joaat("cargobob3");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 39:
		*uParam0 = {1751.44f, 3322.643f, 42.1855f};
		uParam0->f_3 = 268.134f;
		uParam0->f_4 = joaat("submersible");
		gameplay::set_bit(&uParam0->f_9, 23);
		iVar0 = 1;
		break;

	case 41:
		*uParam0 = {1377.104f, -2076.2f, 52f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("towtruck");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 40:
		*uParam0 = {1380.42f, -2072.77f, 51.7607f};
		uParam0->f_3 = 37.5f;
		uParam0->f_4 = joaat("trash");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 42:
		*uParam0 = {1359.389f, 3618.441f, 33.8907f};
		uParam0->f_3 = 108.2337f;
		uParam0->f_4 = joaat("barracks");
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 43:
		*uParam0 = {693.1154f, -1018.155f, 21.6387f};
		uParam0->f_3 = 177.6454f;
		uParam0->f_4 = joaat("firetruk");
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 8);
		iVar0 = 1;
		break;

	case 44:
		*uParam0 = {-73.6963f, 495.124f, 143.5226f};
		uParam0->f_3 = 155.5994f;
		uParam0->f_4 = joaat("vacca");
		iVar0 = 1;
		break;

	case 45:
		*uParam0 = {-67.6314f, 891.8266f, 234.5348f};
		uParam0->f_3 = 294.993f;
		uParam0->f_4 = joaat("surano");
		iVar0 = 1;
		break;

	case 46:
		*uParam0 = {533.9048f, -169.2469f, 53.7005f};
		uParam0->f_3 = 1.2998f;
		uParam0->f_4 = joaat("tornado2");
		iVar0 = 1;
		break;

	case 47:
		*uParam0 = {-726.8914f, -408.6952f, 34.0416f};
		uParam0->f_3 = 267.7392f;
		uParam0->f_4 = joaat("superd");
		iVar0 = 1;
		break;

	case 48:
		*uParam0 = {-1321.519f, 261.3993f, 61.5709f};
		uParam0->f_3 = 350.7697f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 49:
		*uParam0 = {-1267.999f, 451.6463f, 93.7071f};
		uParam0->f_3 = 48.9311f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 50:
		*uParam0 = {-1062.076f, -226.7637f, 37.157f};
		uParam0->f_3 = 234.2767f;
		uParam0->f_4 = joaat("double");
		iVar0 = 1;
		break;

	case 51:
		*uParam0 = {68.16914f, -1558.958f, 29.46904f};
		uParam0->f_3 = 49.90575f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 52:
		*uParam0 = {589.4399f, 2736.708f, 42.03316f};
		uParam0->f_3 = -175.7105f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 53:
		*uParam0 = {-488.774f, -344.5721f, 34.36356f};
		uParam0->f_3 = 82.4042f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 54:
		*uParam0 = {288.8808f, -585.4728f, 43.15428f};
		uParam0->f_3 = -20.80707f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 55:
		*uParam0 = {304.8294f, -1383.674f, 31.67744f};
		uParam0->f_3 = -41.11603f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 56:
		*uParam0 = {1126.194f, -1481.486f, 34.7016f};
		uParam0->f_3 = -91.43369f;
		uParam0->f_4 = joaat("rumpo2");
		uParam0->f_12 = 2;
		gameplay::set_bit(&uParam0->f_9, 26);
		iVar0 = 1;
		break;

	case 57:
		*uParam0 = {-1598.36f, 5252.84f, 0f};
		uParam0->f_3 = 28.14f;
		uParam0->f_4 = joaat("submersible");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 58:
		*uParam0 = {-1602.62f, 5260.37f, 0.86f};
		uParam0->f_3 = 25.32f;
		uParam0->f_4 = joaat("dinghy");
		uParam0->f_13 = 404;
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 22);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 59:
		*uParam0 = {2116.571f, 4763.279f, 40.1596f};
		uParam0->f_3 = 198.723f;
		uParam0->f_4 = joaat("bfinjection");
		iVar0 = 1;
		break;

	case 60:
		*uParam0 = {1133.21f, 120.2f, 80.9f};
		uParam0->f_3 = 134.4f;
		if (func_33()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 61:
		*uParam0 = {-806.31f, -2679.65f, 13.9f};
		uParam0->f_3 = 150.54f;
		if (func_33()) {
			uParam0->f_4 = joaat("blimp2");
		}
		else {
			uParam0->f_4 = joaat("blimp");
		}
		uParam0->f_13 = 401;
		gameplay::set_bit(&uParam0->f_9, 13);
		gameplay::set_bit(&uParam0->f_9, 2);
		gameplay::set_bit(&uParam0->f_9, 1);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 21);
		iVar0 = 1;
		break;

	case 62:
		*uParam0 = {1985.85f, 3828.96f, 31.98f};
		uParam0->f_3 = -16.58f;
		uParam0->f_4 = joaat("blazer3");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 63:
		*uParam0 = {3870.75f, 4464.67f, 0f};
		uParam0->f_3 = 0f;
		uParam0->f_4 = joaat("submersible2");
		uParam0->f_13 = 308;
		gameplay::set_bit(&uParam0->f_9, 0);
		gameplay::set_bit(&uParam0->f_9, 21);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		gameplay::set_bit(&uParam0->f_9, 30);
		iVar0 = 1;
		break;

	case 64:
		*uParam0 = {1257.729f, -2564.474f, 41.717f};
		uParam0->f_3 = 284.5561f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 65:
		*uParam0 = {643.2823f, 3014.152f, 42.2733f};
		uParam0->f_3 = 128.0554f;
		uParam0->f_4 = joaat("dukes2");
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 66:
		*uParam0 = {38.9368f, 850.8677f, 196.3f};
		uParam0->f_3 = 311.6813f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;

	case 67:
		*uParam0 = {1333.875f, 4262.226f, 30.78f};
		uParam0->f_3 = 262.5293f;
		uParam0->f_4 = joaat("dodo");
		gameplay::set_bit(&uParam0->f_9, 30);
		gameplay::set_bit(&uParam0->f_9, 23);
		gameplay::set_bit(&uParam0->f_9, 6);
		iVar0 = 1;
		break;
	}
	if (gameplay::is_bit_set(uParam0->f_9, 10)) {
		uParam0->f_4 = Global_101700.f_31389.f_69[uParam0->f_14 /*78*/].f_66;
		if (iParam1 == 14) {
			if (uParam0->f_4 == joaat("miljet") || uParam0->f_4 == joaat("besra") || uParam0->f_4 == joaat("luxor") ||
				uParam0->f_4 == joaat("shamal") || uParam0->f_4 == joaat("titan") || uParam0->f_4 == joaat("luxor2")) {
				*uParam0 = {1678.8f, 3229.6f, 41.8f};
				uParam0->f_3 = 106.0906f;
			}
		}
		if (!func_74(Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_31389.f_1864[uParam0->f_14 /*3*/]};
		}
		if (Global_101700.f_31389.f_1934[uParam0->f_14] != -1f) {
			uParam0->f_3 = Global_101700.f_31389.f_1934[uParam0->f_14];
		}
	}
	if (gameplay::is_bit_set(uParam0->f_9, 19)) {
		if (!func_74(Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[1 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[1 /*4*/][uParam0->f_12];
		}
	}
	else if (gameplay::is_bit_set(uParam0->f_9, 20)) {
		if (!func_74(Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/], 0f, 0f, 0f, 0)) {
			*uParam0 = {Global_101700.f_2095.f_539.f_2816[0 /*10*/][uParam0->f_12 /*3*/]};
			uParam0->f_3 = Global_101700.f_2095.f_539.f_2837[0 /*4*/][uParam0->f_12];
		}
	}
	return iVar0;
}

// Position - 0x3E31
int func_52(int iParam0, int iParam1) {
	struct<82> Var0;

	if (func_54(iParam0)) {
		Var0.f_11 = 12;
		Var0.f_31 = 49;
		Var0.f_81 = 2;
		func_53(iParam0, &Var0, iParam1);
		return Var0;
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x3E73
void func_53(int iParam0, var *uParam1, int iParam2) {
	int iVar0;

	uParam1->f_88 = 1;
	uParam1->f_84 = 255;
	uParam1->f_85 = 255;
	uParam1->f_86 = 255;
	uParam1->f_97 = 1;
	uParam1->f_3 = 1000;
	uParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*uParam1 = iVar0;
			uParam1->f_2 = 3f;
			uParam1->f_4 = 0;
			uParam1->f_9 = 1;
			uParam1->f_11[0] = 1;
			StringCopy(&uParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14.9f;
			uParam1->f_5 = 43;
			uParam1->f_6 = 43;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_9 = 0;
			StringCopy(&uParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 14f;
			uParam1->f_5 = 32;
			uParam1->f_6 = 0;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				uParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*uParam1 = iVar0;
			uParam1->f_2 = 6f;
			uParam1->f_5 = 53;
			uParam1->f_6 = 0;
			uParam1->f_7 = 59;
			uParam1->f_8 = 156;
			StringCopy(&uParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*uParam1 = iVar0;
			uParam1->f_2 = 0f;
			uParam1->f_5 = 111;
			uParam1->f_6 = 111;
			uParam1->f_7 = 0;
			uParam1->f_8 = 156;
			uParam1->f_10 = 1;
			StringCopy(&uParam1->f_27, "FC1988", 16);
			uParam1->f_11[0] = 1;
			uParam1->f_11[1] = 1;
			uParam1->f_11[2] = 1;
			uParam1->f_11[3] = 1;
			uParam1->f_11[4] = 1;
			uParam1->f_11[5] = 1;
			uParam1->f_11[6] = 1;
			uParam1->f_11[7] = 1;
			uParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0x40D0
bool func_54(int iParam0) { return iParam0 < 3; }

// Position - 0x40DC
void func_55(int iParam0, var *uParam1, vector3 vParam2, float fParam5, int iParam6) {
	if (func_51(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 10)) {
			func_59(iParam0);
			func_58(uParam1, &Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/]);
			if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 11)) {
				Global_101700.f_31389.f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {vParam2};
				Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] = fParam5;
			}
			else {
				Global_101700.f_31389.f_1864[Global_68531.f_555[0 /*21*/].f_14 /*3*/] = {0f, 0f, 0f};
				Global_101700.f_31389.f_1934[Global_68531.f_555[0 /*21*/].f_14] = -1f;
			}
			Global_101700.f_31389.f_1958[Global_68531.f_555[0 /*21*/].f_14] = iParam6 + 1;
			func_56(iParam0, 1);
		}
	}
}

// Position - 0x41DB
void func_56(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam1) {
		if (!func_70(iParam0, 0)) {
			func_57(iParam0, 1, 0);
			func_57(iParam0, 2, 0);
			func_57(iParam0, 3, 0);
			func_57(iParam0, 4, 0);
			func_57(iParam0, 0, 1);
			Global_68531[iParam0] = 1;
		}
	}
	else {
		func_57(iParam0, 0, 0);
	}
}

// Position - 0x4238
void func_57(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == -1) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_31389[iParam0], iParam1);
	}
}

// Position - 0x4273
void func_58(var *uParam0, var *uParam1) {
	uParam1->f_66 = uParam0->f_66;
	*uParam1 = *uParam0;
	uParam1->f_1 = {uParam0->f_1};
	uParam1->f_5 = uParam0->f_5;
	uParam1->f_6 = uParam0->f_6;
	uParam1->f_7 = uParam0->f_7;
	uParam1->f_8 = uParam0->f_8;
	uParam1->f_9 = {uParam0->f_9};
	uParam1->f_59 = {uParam0->f_59};
	uParam1->f_62 = uParam0->f_62;
	uParam1->f_63 = uParam0->f_63;
	uParam1->f_64 = uParam0->f_64;
	uParam1->f_65 = uParam0->f_65;
	uParam1->f_77 = uParam0->f_77;
	uParam1->f_67 = uParam0->f_67;
	uParam1->f_69 = uParam0->f_69;
	uParam1->f_68 = uParam0->f_68;
	uParam1->f_71 = uParam0->f_71;
	uParam1->f_72 = uParam0->f_72;
	uParam1->f_73 = uParam0->f_73;
	uParam1->f_74 = uParam0->f_74;
	uParam1->f_75 = uParam0->f_75;
	uParam1->f_76 = uParam0->f_76;
}

// Position - 0x433F
void func_59(int iParam0) {
	if (iParam0 == -1) {
		return;
	}
	if (func_51(&Global_68531.f_555[0 /*21*/], iParam0)) {
		if (entity::does_entity_exist(Global_68531.f_139[iParam0])) {
			entity::set_entity_as_mission_entity(Global_68531.f_139[iParam0], 1, 1);
			entity::set_vehicle_as_no_longer_needed(&Global_68531.f_139[iParam0]);
			Global_68531.f_139[iParam0] = 0;
		}
		if (gameplay::is_bit_set(Global_68531.f_555[0 /*21*/].f_9, 13)) {
			func_56(iParam0, 0);
		}
	}
}

// Position - 0x43B9
int func_60(int iParam0) {
	int iVar0;

	if (!entity::does_entity_exist(iParam0)) {
		return 145;
	}
	if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
		return 145;
	}
	iVar0 = 0;
	while (iVar0 < 9) {
		if (entity::does_entity_exist(Global_89155[iVar0])) {
			if (Global_89155[iVar0] == iParam0) {
				return Global_89165[iVar0];
			}
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x441C
void func_61(int iParam0, var *uParam1) {
	int iVar0;

	if (vehicle::is_vehicle_driveable(iParam0, 0)) {
		func_64(uParam1);
		uParam1->f_66 = entity::get_entity_model(iParam0);
		StringCopy(&uParam1->f_1, vehicle::get_vehicle_number_plate_text(iParam0), 16);
		*uParam1 = vehicle::get_vehicle_number_plate_text_index(iParam0);
		vehicle::get_vehicle_colours(iParam0, &uParam1->f_5, &uParam1->f_6);
		vehicle::get_vehicle_extra_colours(iParam0, &uParam1->f_7, &uParam1->f_8);
		vehicle::get_vehicle_tyre_smoke_color(iParam0, &uParam1->f_62, &uParam1->f_63, &uParam1->f_64);
		uParam1->f_65 = vehicle::get_vehicle_window_tint(iParam0);
		uParam1->f_67 = vehicle::get_vehicle_livery(iParam0);
		uParam1->f_69 = vehicle::get_vehicle_wheel_type(iParam0);
		uParam1->f_70 = vehicle::get_vehicle_door_lock_status(iParam0);
		vehicle::get_vehicle_custom_secondary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		vehicle::_get_vehicle_neon_lights_colour(iParam0, &uParam1->f_74, &uParam1->f_75, &uParam1->f_76);
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 2)) {
			gameplay::set_bit(&uParam1->f_77, 28);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 3)) {
			gameplay::set_bit(&uParam1->f_77, 29);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 30);
		}
		if (vehicle::_is_vehicle_neon_light_enabled(iParam0, 1)) {
			gameplay::set_bit(&uParam1->f_77, 31);
		}
		if (uParam1->f_65 == -1 && uParam1->f_66 != joaat("granger")) {
			uParam1->f_65 = 0;
		}
		if (vehicle::is_vehicle_a_convertible(iParam0, 0)) {
			uParam1->f_68 = vehicle::get_convertible_roof_state(iParam0);
		}
		if (vehicle::is_this_model_a_plane(uParam1->f_66)) {
			if (vehicle::_vehicle_has_landing_gear(iParam0)) {
				switch (vehicle::get_landing_gear_state(iParam0)) {
				case 2:
				case 0:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::set_bit(&uParam1->f_77, 22);
					break;

				case 3:
				case 1:
					gameplay::clear_bit(&uParam1->f_77, 23);
					gameplay::clear_bit(&uParam1->f_77, 22);
					break;

				case 4: gameplay::set_bit(&uParam1->f_77, 23); break;
				}
			}
			else {
				gameplay::set_bit(&uParam1->f_77, 23);
			}
		}
		if (!vehicle::get_vehicle_tyres_can_burst(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 9);
		}
		if (vehicle::is_vehicle_stolen(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 10);
		}
		if (vehicle::get_is_vehicle_primary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 13);
			vehicle::get_vehicle_custom_primary_colour(iParam0, &uParam1->f_71, &uParam1->f_72, &uParam1->f_73);
		}
		if (vehicle::get_is_vehicle_secondary_colour_custom(iParam0)) {
			gameplay::set_bit(&uParam1->f_77, 12);
		}
		func_63(&iParam0, &uParam1->f_9, &uParam1->f_59);
		iVar0 = 0;
		while (iVar0 <= 11) {
			if (vehicle::is_vehicle_extra_turned_on(iParam0, iVar0 + 1)) {
				gameplay::set_bit(&uParam1->f_77, func_62(iVar0 + 1));
			}
			iVar0++;
		}
		if (graphics::_does_vehicle_have_decal(iParam0, 0)) {
			gameplay::set_bit(&uParam1->f_77, 11);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 11);
		}
		if (decorator::decor_exist_on(iParam0, "IgnoredByQuickSave") &&
			decorator::decor_get_bool(iParam0, "IgnoredByQuickSave")) {
			gameplay::set_bit(&uParam1->f_77, 27);
		}
		else {
			gameplay::clear_bit(&uParam1->f_77, 27);
		}
	}
}

// Position - 0x46C8
int func_62(int iParam0) {
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 24;

	case 11: return 25;

	case 12: return 26;
	}
	return 0;
}

// Position - 0x4778
int func_63(int iParam0, var *uParam1, var *uParam2) {
	int iVar0;
	int iVar1;

	if (!vehicle::is_vehicle_driveable(*iParam0, 0)) {
		return 0;
	}
	if (vehicle::get_num_mod_kits(*iParam0) == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 < *uParam1) {
		iVar1 = iVar0;
		if (iVar1 == 17 || iVar1 == 18 || iVar1 == 19 || iVar1 == 20 || iVar1 == 21 || iVar1 == 22) {
			(*uParam1)[iVar0] = 0;
			if (vehicle::is_toggle_mod_on(*iParam0, iVar1)) {
				(*uParam1)[iVar0] = 1;
			}
		}
		else {
			(*uParam1)[iVar0] = vehicle::get_vehicle_mod(*iParam0, iVar0) + 1;
			if (iVar0 == 23) {
				(*uParam2)[0] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
			else if (iVar0 == 24) {
				(*uParam2)[1] = vehicle::get_vehicle_mod_variation(*iParam0, iVar0);
			}
		}
		iVar0++;
	}
	return 1;
}

// Position - 0x4852
void func_64(var *uParam0) {
	int iVar0;

	uParam0->f_66 = 0;
	uParam0->f_77 = 0;
	uParam0->f_65 = 0;
	uParam0->f_62 = 0;
	uParam0->f_63 = 0;
	uParam0->f_64 = 0;
	uParam0->f_74 = 0;
	uParam0->f_75 = 0;
	uParam0->f_76 = 0;
	*uParam0 = 0;
	StringCopy(&uParam0->f_1, "", 16);
	uParam0->f_5 = 0;
	uParam0->f_6 = 0;
	uParam0->f_7 = 0;
	uParam0->f_8 = 0;
	iVar0 = 0;
	while (iVar0 < 49) {
		uParam0->f_9[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 2) {
		uParam0->f_59[iVar0] = 0;
		iVar0++;
	}
	uParam0->f_67 = 0;
	uParam0->f_68 = 0;
	uParam0->f_69 = 0;
	uParam0->f_70 = 1;
	uParam0->f_71 = 0;
	uParam0->f_72 = 0;
	uParam0->f_73 = 0;
}

// Position - 0x4901
void func_65(int iParam0) {
	if (iParam0 != 24 && iParam0 != 25) {
	}
	func_59(iParam0);
	func_56(iParam0, 0);
}

// Position - 0x4928
void func_66(int iParam0) {
	if (gameplay::is_bit_set(iLocal_105, 14)) {
		if (func_68(player::player_ped_id()) == 0) {
			if (iParam0) {
				func_67(10);
			}
			else {
				func_67(12);
			}
		}
		else if (iParam0) {
			func_67(11);
		}
		else {
			func_67(13);
		}
		if (iLocal_42 == 0) {
			func_88(45, 0);
		}
		else if (iLocal_42 == 1) {
			func_88(12, 0);
		}
		else if (iLocal_42 == 2) {
			func_88(34, 0);
		}
		if (iLocal_42 != 2) {
			vLocal_106 = {0f, 0f, 0f};
		}
		iLocal_40 = 0;
		iLocal_41 = 0;
		gameplay::clear_bit(&iLocal_105, 6);
		gameplay::clear_bit(&iLocal_105, 7);
		gameplay::clear_bit(&iLocal_105, 0);
		gameplay::clear_bit(&iLocal_105, 1);
		gameplay::clear_bit(&iLocal_105, 8);
		gameplay::clear_bit(&iLocal_105, 12);
		gameplay::clear_bit(&iLocal_105, 2);
		gameplay::clear_bit(&iLocal_105, 14);
		if (iLocal_37 == 4) {
			if (graphics::has_scaleform_movie_loaded(iLocal_1267)) {
				graphics::set_scaleform_movie_as_no_longer_needed(&iLocal_1267);
			}
			func_105(0);
		}
		func_75(0, 0);
	}
}

// Position - 0x4A0F
void func_67(int iParam0) {
	int iVar0;

	iVar0 = func_6(iParam0);
	gameplay::set_bit(&uLocal_101[func_5(iParam0)], iVar0);
}

// Position - 0x4A2F
int func_68(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_69(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x4A6C
int func_69(int iParam0) {
	if (func_54(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x4A96
int func_70(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_31389[iParam0], iParam1);
}

// Position - 0x4AB9
int func_71(int iParam0) {
	if (iParam0 == -1) {
		return 0;
	}
	return Global_68531.f_139[iParam0];
}

// Position - 0x4AD5
bool func_72() {
	if (!network::network_is_game_in_progress()) {
		return Global_89302.f_44 == 1;
	}
	return false;
}

// Position - 0x4AF1
bool func_73(int iParam0, vector3 vParam1, float fParam4) {
	return system::vdist2(entity::get_entity_coords(iParam0, 1), vParam1) <= fParam4 * fParam4;
}

// Position - 0x4B0E
bool func_74(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0x4B55
void func_75(int iParam0, int iParam1) {
	Global_101700.f_9008.f_128 = iParam0;
	iLocal_37 = iParam0;
	if (iParam1) {
		return;
	}
	func_76();
}

// Position - 0x4B79
int func_76() {
	if (func_77(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x4BC4
bool func_77(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x4BEF
void func_78(char *sParam0, int iParam1) {
	stats::stat_set_gxt_label(joaat("sp_last_mission_name"), sParam0, 1);
	if (gameplay::is_bit_set(iParam1, 0)) {
		stats::stat_set_gxt_label(joaat("sp0_last_mission_name"), sParam0, 1);
	}
	if (gameplay::is_bit_set(iParam1, 1)) {
		stats::stat_set_gxt_label(joaat("sp1_last_mission_name"), sParam0, 1);
	}
	if (gameplay::is_bit_set(iParam1, 2)) {
		stats::stat_set_gxt_label(joaat("sp2_last_mission_name"), sParam0, 1);
	}
}

// Position - 0x4C49
int func_79() {
	func_80();
	switch (Global_101700.f_2095.f_539.f_3549) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 4;
	}
	return 0;
}

// Position - 0x4C8F
void func_80() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_69(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_68(player::player_ped_id());
			if (func_54(iVar0) && (!func_81(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_54(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x4D8C
bool func_81(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x4D9A
bool func_82(int iParam0) {
	if (func_83(iParam0)) {
		if (vehicle::is_vehicle_driveable(iParam0, 0)) {
			if (!fire::is_entity_on_fire(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x4DC4
bool func_83(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x4DE5
void func_84(int iParam0, int iParam1) {
	if (iParam0 == 235 || iParam0 == 0) {
		return;
	}
	Global_101700.f_7572[iParam0] = 1;
	Global_101700.f_7572.f_236[iParam0] = gameplay::get_game_timer() + iParam1;
}

// Position - 0x4E22
void func_85(int iParam0) {
	char *sVar0;

	audio::register_script_with_audio(0);
	switch (func_86()) {
	case 0:
		if (iParam0) {
			sVar0 = "MICHAEL_SMALL_01";
		}
		else {
			sVar0 = "MICHAEL_BIG_01";
		}
		break;

	case 1:
		if (iParam0) {
			sVar0 = "FRANKLIN_SMALL_01";
		}
		else {
			sVar0 = "FRANKLIN_BIG_01";
		}
		break;

	case 2:
		if (iParam0) {
			sVar0 = "TREVOR_SMALL_01";
		}
		else {
			sVar0 = "TREVOR_BIG_01";
		}
		break;
	}
	audio::play_mission_complete_audio(sVar0);
}

// Position - 0x4E95
int func_86() {
	func_80();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x4EAE
void func_87(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x4EC0
void func_88(int iParam0, int iParam1) {
	if (iParam0 == 146 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_58[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_58[iParam0] = iParam1;
}

// Position - 0x4F05
void func_89() {
	Global_101700.f_8975.f_21++;
	if (iLocal_42 == 0) {
		stats::stat_set_int(joaat("fl_co_fb4p3"), Global_101700.f_8975.f_21, 1);
		if (func_98()) {
			if (func_242(74) || func_242(75) && func_97()) {
				func_88(46, 1);
			}
		}
	}
	func_90();
	gameplay::set_bit(&iLocal_105, 10);
}

// Position - 0x4F73
void func_90() {
	if (iLocal_42 == 0) {
		func_91(23, 0, 0);
	}
	else if (iLocal_42 == 1) {
	}
	else if (iLocal_42 == 2) {
	}
}

// Position - 0x4F9B
void func_91(int iParam0, int iParam1, int iParam2) {
	bool bVar0;

	if (iParam0 < 0) {
	}
	if (iParam0 == 321 || iParam0 > 321) {
	}
	else {
		func_95(891 + iParam0, 1, -1, 1);
	}
	bVar0 = true;
	if (Global_101700.f_9153[iParam0 /*12*/].f_5 == 1) {
		if (Global_101700.f_9153[iParam0 /*12*/].f_6 == 11 || Global_101700.f_9153[iParam0 /*12*/].f_6 == 12) {
			bVar0 = false;
		}
	}
	else {
		Global_101700.f_9153[iParam0 /*12*/].f_5 = 1;
		Global_101700.f_9153[iParam0 /*12*/].f_10 = iParam1;
		Global_101700.f_9153[iParam0 /*12*/].f_11 = iParam2;
		if (iParam0 == 287) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_0"), 50, 0);
		}
		if (iParam0 == 286) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_1"), 50, 0);
		}
		if (iParam0 == 299) {
			stats::_0x11FF1C80276097ED(joaat("num_hidden_packages_3"), 50, 0);
		}
	}
	if (bVar0) {
		func_92();
	}
}

// Position - 0x5083
void func_92() {
	int iVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	int iVar9;

	iVar0 = 0;
	Global_101436 = 0;
	Global_101437 = 0;
	Global_101438 = 0;
	Global_101439 = 0;
	Global_101440 = 0;
	Global_101441 = 0;
	Global_101442 = 0;
	fVar1 = 0f;
	fVar2 = 0f;
	fVar3 = 0f;
	fVar4 = 0f;
	fVar5 = 0f;
	fVar6 = 0f;
	fVar7 = 0f;
	fVar8 = Global_101700.f_9153.f_3853;
	Global_101700.f_9153.f_3853 = 0f;
	while (iVar0 < 321) {
		if (Global_101700.f_9153[iVar0 /*12*/].f_5 == 1) {
			switch (Global_101700.f_9153[iVar0 /*12*/].f_6) {
			case 1:
				Global_101436++;
				fVar1 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 3:
				Global_101437++;
				fVar2 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 5:
				Global_101438++;
				fVar3 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 7:
				Global_101439++;
				fVar4 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 9:
				Global_101440++;
				fVar5 += Global_101700.f_9153[iVar0 /*12*/].f_4 * 4f;
				break;

			case 11:
				Global_101441++;
				fVar6 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			case 13:
				Global_101442++;
				fVar7 += Global_101700.f_9153[iVar0 /*12*/].f_4;
				break;

			default: break;
			}
		}
		iVar0++;
	}
	if (Global_101419 > 0) {
		if (Global_101436 == Global_101419) {
			fVar1 = 55f;
		}
	}
	if (Global_101420 > 0) {
		if (Global_101437 == Global_101420) {
			fVar2 = 10f;
		}
	}
	if (Global_101421 > 0) {
		if (Global_101438 == Global_101421) {
			fVar3 = 0f;
		}
	}
	if (Global_101422 > 0) {
		if (Global_101439 == Global_101422) {
			fVar4 = 10f;
		}
	}
	if (Global_101423 > 0) {
		if (Global_101440 == Global_101423 || Global_101423 * 10 / Global_101440 < 41 ||
			Global_101440 > Global_101426 || Global_101440 == Global_101426) {
			if (!gameplay::is_bit_set(Global_101700.f_9153.f_3856, 14)) {
				if (Global_101440 == Global_101423) {
					stats::_0x11FF1C80276097ED(joaat("num_rndevents_completed"), Global_101423, 0);
					gameplay::set_bit(&Global_101700.f_9153.f_3856, 14);
				}
			}
			fVar5 = 5f;
		}
	}
	if (Global_101424 > 0) {
		if (Global_101441 == Global_101424) {
			fVar6 = 15f;
		}
	}
	if (Global_101425 > 0) {
		if (Global_101442 == Global_101425) {
			fVar7 = 5f;
		}
	}
	Global_101700.f_9153.f_3853 = fVar1 + fVar2 + fVar3 + fVar4 + fVar5 + fVar6 + fVar7;
	if (Global_101440 > Global_101426 || Global_101440 == Global_101426) {
		iVar9 = Global_101426;
	}
	else {
		iVar9 = Global_101440;
	}
	stats::stat_set_int(joaat("num_missions_completed"), Global_101436, 1);
	stats::stat_set_int(joaat("num_missions_available"), Global_101419, 1);
	stats::stat_set_int(joaat("num_minigames_completed"), Global_101437, 1);
	stats::stat_set_int(joaat("num_minigames_available"), Global_101420, 1);
	stats::stat_set_int(joaat("num_oddjobs_completed"), Global_101438, 1);
	stats::stat_set_int(joaat("num_oddjobs_available"), Global_101421, 1);
	stats::stat_set_int(joaat("num_rndpeople_completed"), Global_101439, 1);
	stats::stat_set_int(joaat("num_rndpeople_available"), Global_101422, 1);
	stats::stat_set_int(joaat("num_rndevents_completed"), iVar9, 1);
	stats::stat_set_int(joaat("num_rndevents_available"), Global_101426, 1);
	stats::stat_set_int(joaat("num_misc_completed"), Global_101442 + Global_101441, 1);
	stats::stat_set_int(joaat("num_misc_available"), Global_101425 + Global_101424, 1);
	Global_101443 = Global_101436 * 100 / Global_101419;
	Global_101445 = Global_101438 + Global_101437 * 100 / (Global_101421 + Global_101420);
	Global_101444 = Global_101439 + iVar9 * 100 / (Global_101422 + Global_101426);
	Global_101446 = Global_101441 + Global_101442 * 100 / (Global_101424 + Global_101425);
	stats::stat_set_float(joaat("total_progress_made"), Global_101700.f_9153.f_3853, 1);
	stats::stat_set_int(joaat("percent_story_missions"), Global_101443, 1);
	stats::stat_set_int(joaat("percent_ambient_missions"), Global_101444, 1);
	stats::stat_set_int(joaat("percent_oddjobs"), Global_101445, 1);
	if (fVar8 > 0f && system::floor(fVar8) < system::floor(Global_101700.f_9153.f_3853)) {
		func_94(13, system::floor(Global_101700.f_9153.f_3853));
	}
	if (!datafile::datafile_is_save_pending()) {
		if (!Global_69702) {
			if (func_93() == 2 == 0 && !network::network_is_game_in_progress()) {
				if (network::network_is_cloud_available()) {
					Global_101434 = 0;
				}
				if (!Global_55822) {
					func_76();
				}
			}
		}
	}
}

// Position - 0x5544
int func_93() { return Global_25190; }

// Position - 0x554F
int func_94(int iParam0, int iParam1) {
	int iVar0;

	if (iParam0 < 0) {
		return 0;
	}
	if (iParam0 > 70) {
		return 0;
	}
	if (iParam1 <= 0 || iParam1 > 100) {
		return 0;
	}
	iVar0 = player::_0x1C186837D0619335(iParam0);
	if (iParam1 > iVar0) {
		return player::_0xC2AFFFDABBDC2C5C(iParam0, iParam1);
	}
	return 0;
}

// Position - 0x55A0
int func_95(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;
	var uVar6;
	var uVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;

	if (iParam2 == -1) {
		iParam2 = func_96();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
		iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
		iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
		iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
		iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
		iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
		iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		uVar9 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2, "_NGTATPSTAT_BOOL");
		iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2, "_DLCBIKEPSTAT_BOOL");
		iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
	}
	return iVar0;
}

// Position - 0x5934
var func_96() { return Global_1312735; }

// Position - 0x5940
int func_97() {
	if (func_242(41) && func_242(3) && func_242(21)) {
		return 1;
	}
	return 0;
}

// Position - 0x596B
bool func_98() {
	if (iLocal_42 == 0) {
		return func_103();
	}
	else if (iLocal_42 == 1) {
		return func_102();
	}
	else if (iLocal_42 == 2) {
		return func_99();
	}
	return false;
}

// Position - 0x59A1
int func_99() {
	if (func_242(79) && func_242(83) && func_100(func_101())) {
		return 1;
	}
	return 0;
}

// Position - 0x59CF
bool func_100(int iParam0) {
	if (iParam0 == 146 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_99.f_58[iParam0];
}

// Position - 0x59FC
int func_101() {
	if (iLocal_42 == 0) {
		return 45;
	}
	else if (iLocal_42 == 1) {
		return 12;
	}
	else if (iLocal_42 == 2) {
		return 34;
	}
	return -1;
}

// Position - 0x5A2C
int func_102() {
	if (func_242(68)) {
		return 1;
	}
	return 0;
}

// Position - 0x5A42
int func_103() {
	if (func_104(33, 37) >= 4) {
		return 1;
	}
	return 0;
}

// Position - 0x5A5A
int func_104(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = iParam0;
	while (iVar1 <= iParam1) {
		if (func_242(iVar1)) {
			iVar0++;
		}
		iVar1++;
	}
	if (func_100(func_101())) {
		iVar0++;
	}
	return iVar0;
}

// Position - 0x5A9B
void func_105(int iParam0) {
	Global_69962 = iParam0;
	Global_69963 = iParam0;
}

// Position - 0x5AAF
void func_106() {
	struct<6> Var0;

	if (iLocal_40 != 0) {
		Var0 = {func_123()};
		switch (iLocal_40) {
		case 1:
			if (iLocal_42 != 2) {
				if (!gameplay::is_string_null_or_empty(&Var0)) {
					if (audio::get_current_scripted_conversation_line() > 0) {
						func_122("LOCAUD", Local_44.f_7);
						func_121(1);
						iLocal_40 = 2;
					}
					else if (gameplay::is_bit_set(iLocal_105, 10) &&
							 audio::get_current_scripted_conversation_line() == 0) {
						func_122("LOCAUD", Local_44.f_7);
						func_121(1);
						iLocal_40 = 2;
					}
				}
			}
			else {
				iLocal_40 = 0;
			}
			if (func_120()) {
				iLocal_40 = 3;
			}
			break;

		case 2:
			if (func_120()) {
				iLocal_40 = 3;
			}
			if (!gameplay::is_bit_set(iLocal_105, 10)) {
				if (audio::get_current_scripted_conversation_line() >= 0) {
					func_113(Var0);
				}
			}
			else {
				iLocal_40 = 3;
			}
			break;

		case 3:
			if (!func_112()) {
				iLocal_40 = 4;
			}
			break;

		case 4:
			if (!func_14(0)) {
				if (iLocal_42 == 1) {
					func_111(Local_44.f_8);
				}
				iLocal_40 = 5;
			}
			break;

		case 5:
			if (func_86() == 0) {
				if (iLocal_42 == 0) {
					if (func_98()) {
						if (func_242(74) || func_242(75))
							&&func_97() {
								func_107(1);
								iLocal_40 = 0;
							}
						else {
							func_107(0);
							iLocal_40 = 0;
						}
					}
					else {
						iLocal_40 = 0;
					}
				}
				else {
					iLocal_40 = 0;
				}
			}
			else {
				if (iLocal_42 == 0) {
					if (func_98()) {
						if (!func_242(3)) {
							func_84(50, 0);
						}
					}
				}
				iLocal_40 = 0;
			}
			break;
		}
	}
}

// Position - 0x5C28
void func_107(int iParam0) {
	if (iParam0) {
		func_108(1527885205, 0, func_86(), 23, 3, 6000, 6000, -1, 0, -1, 0);
	}
	else if (!func_242(3)) {
		func_108(-224691627, 0, func_86(), 23, 3, 6000, 6000, -1, 50, -1, 0);
	}
	else {
		func_108(-224691627, 0, func_86(), 23, 3, 6000, 6000, -1, 0, -1, 0);
	}
}

// Position - 0x5C99
int func_108(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10) {
	struct<15> Var0;
	int iVar15;

	if (func_77(0)) {
		return 0;
	}
	if (iParam5 < 0) {
		return 0;
	}
	if (iParam6 < 0) {
		return 0;
	}
	if (iParam7 == 76) {
		return 0;
	}
	if (iParam8 == 235) {
		return 0;
	}
	if (iParam3 == iParam2) {
		return 0;
	}
	if (iParam2 != 144 && iParam2 != 0 && iParam2 != 1 && iParam2 != 2) {
		return 0;
	}
	if (G_SomeGlobalState.MessageCallStates.f_136 < 9) {
		Var0 = iParam0;
		if (G_SomeGlobalState.MessageCallStates.f_911 == Var0) {
			G_SomeGlobalState.MessageCallStates.f_911 = -1;
		}
		Var0.f_3 = func_110(iParam1);
		Var0.f_5 = iParam6;
		Var0.f_4 = gameplay::get_game_timer() + iParam5;
		Var0.f_1 = iParam10;
		iVar15 = 0;
		gameplay::set_bit(&iVar15, iParam2);
		Var0.f_2 = iVar15;
		Var0.f_6 = iParam3;
		Var0.f_14 = iParam4;
		Var0.f_10 = -1;
		Var0.f_11 = -1;
		Var0.f_7 = iParam7;
		Var0.f_8 = iParam8;
		Var0.f_9 = iParam9;
		gameplay::set_bit(&Var0.f_1, 0);
		gameplay::clear_bit(&Var0.f_1, 1);
		if (iParam1 == 0) {
			gameplay::set_bit(&Var0.f_1, 10);
		}
		G_SomeGlobalState.MessageCallStates[G_SomeGlobalState.MessageCallStates.f_136 /*15*/] = {Var0};
		G_SomeGlobalState.MessageCallStates.f_136++;
		func_109(iParam2);
		return 1;
	}
	return 0;
}

// Position - 0x5DEA
void func_109(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 0;
	if (!func_54(iParam0)) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 > iVar1) {
				iVar1 = G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3;
			}
		}
		iVar0++;
	}
	iVar2 = 0;
	while (iVar2 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_2, iParam0)) {
			if (G_SomeGlobalState.MessageCallStates.f_651[iVar2 /*14*/].f_3 == 5) {
				iVar1 = 5;
			}
		}
		iVar2++;
	}
	G_SomeGlobalState.MessageCallStates.f_919[iParam0] = iVar1;
}

// Position - 0x5EAE
int func_110(int iParam0) {
	switch (iParam0) {
	case 0:
	case 4: return 5;

	case 7: return 4;

	case 2: return 3;

	case 1: return 2;

	case 3: return 1;

	case 5:
	case 6: return 0;
	}
	return 7;
}

// Position - 0x5F18
void func_111(int iParam0) {
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		Global_101700.f_27009[iParam0 /*29*/].f_12[0] = 0;
		Global_101700.f_27009[iParam0 /*29*/].f_12[1] = 0;
		Global_101700.f_27009[iParam0 /*29*/].f_12[2] = 0;
		Global_101700.f_27009[iParam0 /*29*/].f_24[0] = 0;
		Global_101700.f_27009[iParam0 /*29*/].f_24[1] = 0;
		Global_101700.f_27009[iParam0 /*29*/].f_24[2] = 0;
	}
}

// Position - 0x5F94
int func_112() {
	if (Global_15745 == 4) {
		if (audio::is_mobile_phone_call_ongoing()) {
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x5FB9
void func_113(struct<6> Param0) {
	if (iLocal_42 == 0) {
		func_118(Param0);
	}
	else if (iLocal_42 == 1) {
		func_114(Param0);
	}
}

// Position - 0x5FE0
void func_114(struct<6> Param0) {
	if (func_98()) {
		func_115(Param0, 1);
	}
	else {
		func_115(Param0, 0);
	}
}

// Position - 0x6004
void func_115(var uParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, int iParam6) {
	struct<4> Var0;

	if (!gameplay::is_string_null_or_empty(&uParam0)) {
		if (gameplay::are_strings_equal(&uParam0, Local_44.f_7)) {
			if (audio::get_current_scripted_conversation_line() >= 0) {
				if (iLocal_42 == 0) {
					Var0 = {func_117(iParam6)};
					func_88(46, 1);
					func_122(sLocal_1272, &Var0);
					func_121(1);
				}
				else if (iLocal_42 == 1) {
					Var0 = {func_116(iParam6)};
					func_122(sLocal_1272, &Var0);
					func_121(1);
				}
				iLocal_40 = 3;
			}
		}
	}
}

// Position - 0x6074
struct<4> func_116(bool bParam0) {
	struct<4> Var0;

	if (bParam0) {
		switch (func_86()) {
		case 1: StringCopy(&Var0, "AHF_C8", 16); break;

		case 0: StringCopy(&Var0, "AHF_C5", 16); break;
		}
	}
	else {
		switch (func_86()) {
		case 1: StringCopy(&Var0, "AHF_C9", 16); break;

		case 0: StringCopy(&Var0, "AHF_C6", 16); break;
		}
	}
	return Var0;
}

// Position - 0x60DE
struct<4>
func_117(bool bParam0) {
	struct<4> Var0;

	if (bParam0) {
		switch (func_86()) {
		case 1: StringCopy(&Var0, "FBI4_ISAGO", 16); break;

		case 2: StringCopy(&Var0, "FBI4_ISAGO", 16); break;
		}
	}
	else {
		switch (func_86()) {
		case 1: StringCopy(&Var0, "FBI4_THATSIT", 16); break;

		case 2: StringCopy(&Var0, "FBI4_THATSIT", 16); break;
		}
	}
	return Var0;
}

//Position - 0x6148
void func_118(struct<6> Param0)
{
	if (func_98()) {
		if (func_119()) {
			if (func_86() != 0) {
				func_115(Param0, 1);
			}
			else {
				iLocal_40 = 3;
			}
		}
		else if (func_86() != 0) {
			func_115(Param0, 0);
		}
		else {
			iLocal_40 = 3;
		}
	}
	else {
		iLocal_40 = 3;
	}
}

// Position - 0x6195
bool func_119() {
	if (iLocal_42 == 0) {
		if (func_242(74) || func_242(74))
			&&func_97() { return true; }
	}
	else if (iLocal_42 == 1) {
		if (func_242(68)) {
			return true;
		}
	}
	return false;
}

// Position - 0x61DC
bool func_120() {
	if (Global_15794 == 1 || Global_16761 == 1) {
		return true;
	}
	return false;
}

// Position - 0x61FF
void func_121(int iParam0) {
	audio::stop_scripted_conversation(iParam0);
	if (iParam0) {
	}
}

// Position - 0x6213
void func_122(char *sParam0, char *sParam1) {
	if (audio::is_mobile_phone_call_ongoing()) {
		Global_15802 = 1;
		StringCopy(&Global_15809, sParam0, 24);
		StringCopy(&Global_15803, sParam1, 24);
	}
}

// Position - 0x6234
struct<6> func_123() {
	struct<6> Var0;

	StringCopy(&Var0, "NULL", 24);
	if (Global_15745 == 4) {
		return Global_15364;
	}
	return Var0;
}

//Position - 0x6258
void func_124()
{
	func_125();
}

// Position - 0x6264
void func_125() {
	func_131();
	func_126();
}

// Position - 0x6274
void func_126() {
	if (func_130() == 69) {
		if (func_129() && !func_70(25, 0)) {
			if (Local_114.f_66 != 0) {
				func_55(25, &Local_114, vLocal_110, fLocal_113, 145);
			}
		}
	}
	else if (func_130() == -1) {
		if (!gameplay::is_bit_set(iLocal_105, 1)) {
			if (!func_73(player::player_ped_id(), vLocal_106, 5f)) {
				if (func_128()) {
					if (!streaming::is_player_switch_in_progress()) {
						if (func_127()) {
							func_67(1);
						}
						else if (Global_100755) {
							func_67(2);
						}
						else {
							func_67(0);
						}
						iLocal_39 = 1;
						fLocal_104 = 0f;
					}
				}
			}
		}
	}
}

// Position - 0x6310
bool func_127() { return script::is_thread_active(Global_101700.f_17062.f_395); }

// Position - 0x6326
bool func_128() {
	if (func_12()) {
		if (func_86() == 0) {
			if (iLocal_43 == 12 || iLocal_43 == 1) {
				return true;
			}
		}
		else if (iLocal_43 == 0 || iLocal_43 == 12) {
			return true;
		}
	}
	return false;
}

// Position - 0x636D
int func_129() {
	if (Global_91491 == 10 || Global_91491 == 9) {
		return 1;
	}
	return 0;
}

// Position - 0x6391
int func_130() { return Global_69964; }

// Position - 0x639D
void func_131() {
	if (!func_74(vLocal_110, 0f, 0f, 0f, 0) && func_130() != func_132()) {
		if (func_73(player::player_ped_id(), vLocal_110, 60f)) {
			if (func_82(func_71(25))) {
				if (system::vdist2(entity::get_entity_coords(func_71(25), 1), vLocal_110) >= 100f) {
					func_66(0);
				}
			}
			else if (!func_70(25, 0)) {
				func_66(1);
			}
		}
	}
}

// Position - 0x6418
int func_132() {
	if (iLocal_42 == 0) {
		return 38;
	}
	else if (iLocal_42 == 1) {
		return 69;
	}
	else if (iLocal_42 == 2) {
		return 85;
	}
	return -1;
}

// Position - 0x6448
void func_133() {
	func_16();
	func_106();
}

// Position - 0x6458
void func_134() {
	int iVar0;

	func_208();
	func_194();
	func_162();
	func_106();
	func_161();
	if (func_157()) {
		if (func_135(&iVar0)) {
			func_250(0);
			if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
				ped::is_ped_stopped(player::player_ped_id())) {
				ai::task_leave_any_vehicle(player::player_ped_id(), 0, 0);
			}
			if (func_82(iLocal_109)) {
				vehicle::set_vehicle_doors_locked(iLocal_109, 2);
			}
			func_75(iVar0, 0);
		}
	}
}

// Position - 0x64C3
bool func_135(int *iParam0) {
	char *sVar0;

	if (gameplay::is_bit_set(iLocal_105, 0)) {
		func_149();
		if (func_136()) {
			sVar0 = script::get_this_script_name();
			if (!gameplay::is_string_null_or_empty(sVar0)) {
				if (iLocal_42 == 2) {
					*iParam0 = 1;
				}
				else {
					*iParam0 = 4;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0x6506
bool func_136() {
	if (func_138(&uLocal_1273, Local_44.f_8, sLocal_1272, Local_44.f_4, 9, 1, 0, 0, 0)) {
		iLocal_40 = 1;
		func_137(192, entity::get_entity_coords(player::player_ped_id(), 1));
		return true;
	}
	return false;
}

// Position - 0x6540
void func_137(int iParam0, vector3 vParam1) {
	int iVar0;

	if (ui::does_blip_exist(Global_25501[iParam0 /*23*/].f_19)) {
		ui::set_blip_coords(Global_25501[iParam0 /*23*/].f_19, vParam1);
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 <= 2) {
		Global_25501[iParam0 /*23*/][iVar0 /*3*/] = {vParam1};
		iVar0++;
	}
}

// Position - 0x658F
bool func_138(var *uParam0, var uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8) {
	func_148(uParam0, uParam1, sParam2, iParam6, iParam7, 0);
	Global_15793 = 0;
	Global_15752 = 1;
	Global_15759 = 0;
	Global_15754 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_15750 = 0;
	Global_15797 = 0;
	Global_15799 = 0;
	if (iParam5 == 1) {
		Global_15757 = 1;
	}
	else {
		Global_15757 = 0;
	}
	Global_2621441 = 0;
	return func_139(sParam3, iParam4, iParam8);
}

// Position - 0x65EE
int func_139(char *sParam0, int iParam1, bool bParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_147();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_146(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_145();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (bParam2) {
				func_144();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_143()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_142()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_141();
			Global_15755 = bParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_140();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_147();
	}
	return 0;
}

// Position - 0x68BA
void func_140() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x68EA
void func_141() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x697F
bool func_142() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x69A6
bool func_143() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x6A3F
void func_144() {
	if (func_81(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_86();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x6AE1
void func_145() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x6B37
bool func_146(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x6B72
void func_147() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x6BC9
void func_148(var *uParam0, var uParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = uParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = iParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x6C1F
void func_149() {
	int iVar0;

	iVar0 = func_86();
	func_150(iVar0, func_156(iVar0));
}

// Position - 0x6C39
void func_150(int iParam0, char *sParam1) {
	int iVar0;

	switch (iParam0) {
	case 0:
		Local_44 = 0;
		Local_44.f_1 = "MICHAEL";
		if (iLocal_42 == 0) {
			Local_44.f_2 = 1;
			Local_44.f_3 = "FRANKLIN";
			Local_44.f_8 = 5;
		}
		else {
			Local_44.f_2 = 3;
			Local_44.f_3 = "LESTER";
			if (iLocal_42 == 1) {
				Local_44.f_8 = 6;
			}
			else {
				Local_44.f_8 = 12;
			}
		}
		Local_44.f_5 = "FBI_3_FRESP";
		func_154(iParam0);
		break;

	case 1:
		Local_44 = 1;
		Local_44.f_1 = "FRANKLIN";
		if (iLocal_42 == 0) {
			Local_44.f_2 = 0;
			Local_44.f_3 = "MICHAEL";
			Local_44.f_8 = 9;
		}
		else {
			Local_44.f_2 = 3;
			Local_44.f_3 = "LESTER";
			if (iLocal_42 == 1) {
				Local_44.f_8 = 7;
			}
			else {
				Local_44.f_8 = 12;
			}
		}
		Local_44.f_5 = "FBI_3_MRESP";
		func_154(iParam0);
		break;

	case 2:
		Local_44 = 2;
		Local_44.f_1 = "TREVOR";
		if (iLocal_42 == 0) {
			Local_44.f_2 = 0;
			Local_44.f_3 = "MICHAEL";
			Local_44.f_8 = 8;
		}
		else {
			Local_44.f_2 = 3;
			Local_44.f_3 = "LESTER";
			if (iLocal_42 == 1) {
				Local_44.f_8 = 7;
			}
			else {
				Local_44.f_8 = 12;
			}
		}
		Local_44.f_5 = "FBI_3_MRESP";
		func_154(iParam0);
		break;
	}
	if (iLocal_42 == 1) {
		if (iParam0 == 0) {
			iVar0 = 0;
		}
		else {
			iVar0 = 1;
		}
		func_152(Local_44.f_8, iVar0, 0);
	}
	func_151(&uLocal_1273, Local_44, player::player_ped_id(), Local_44.f_1, 0, 1);
	func_151(&uLocal_1273, Local_44.f_2, 0, Local_44.f_3, 0, 1);
	Local_44.f_4 = sParam1;
}

// Position - 0x6DAF
void func_151(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0x6E4A
void func_152(int iParam0, int iParam1, int iParam2) {
	Global_2999 = iParam0;
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		func_144();
		if (iParam1 == 4) {
			Global_101700.f_27009[iParam0 /*29*/].f_12[0] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_12[2] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[0] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[2] = 1;
		}
		else {
			if (Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] == 1 &&
				Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] == 1) {
				iParam2 = 0;
			}
			Global_101700.f_27009[iParam0 /*29*/].f_12[iParam1] = 1;
			Global_101700.f_27009[iParam0 /*29*/].f_24[iParam1] = 1;
		}
		if (iParam2) {
			if (!Global_69702) {
				if (iParam1 != 4) {
					if (Global_14443 != iParam1) {
						Global_2972[iParam1 /*4*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
						Global_2989[iParam1] = 1;
						Global_2994[iParam1] = iParam0;
					}
					else if (iParam0 == Global_14443) {
					}
					else {
						Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
						Global_2923[1 /*6*/].f_5 = iParam1;
						func_153();
					}
				}
				else {
					Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
					Global_2923[1 /*6*/].f_5 = iParam1;
					func_153();
				}
			}
			else {
				Global_2923[1 /*6*/] = {Global_101700.f_27009[iParam0 /*29*/].f_3};
				Global_2923[1 /*6*/].f_5 = iParam1;
				func_153();
			}
		}
	}
}

// Position - 0x6FF4
void func_153() {
	char cVar0[64];
	char cVar16[64];
	char *sVar32;

	StringCopy(&cVar0, ui::_get_label_text(&Global_101700.f_27009[Global_2999 /*29*/].f_7), 64);
	if (Global_3018 == 0) {
		ui::_set_notification_text_entry("");
		StringCopy(&cVar16, ui::_get_label_text(&Global_2923[1 /*6*/]), 64);
		sVar32 = ui::_get_label_text("CELL_253");
		ui::_set_notification_message(&cVar0, &cVar0, 0, 3, sVar32, &cVar16);
	}
	else {
		ui::_set_notification_text_entry("CELL_255");
		ui::add_text_component_substring_text_label(&Global_2923[1 /*6*/]);
		ui::_set_notification_message(&cVar0, &cVar0, 0, 3, "", 0);
	}
	gameplay::clear_bit(&G_SleepModeOnOn25, 0);
}

// Position - 0x7071
void func_154(int iParam0) {
	Local_44.f_6 = zone::get_name_of_zone(entity::get_entity_coords(player::player_ped_id(), 1));
	func_155(iParam0);
}

// Position - 0x7090
void func_155(int iParam0) {
	if (!gameplay::is_string_null_or_empty(Local_44.f_6)) {
		if (gameplay::are_strings_equal(Local_44.f_6, "SanAnd")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M77";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F78";
			}
			else {
				Local_44.f_7 = "LOC_T78";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Alamo")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M101";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F1";
			}
			else {
				Local_44.f_7 = "LOC_T1";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Alta")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M1";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F2";
			}
			else {
				Local_44.f_7 = "LOC_T2";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Airp")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M48";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F49";
			}
			else {
				Local_44.f_7 = "LOC_T49";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ArmyB")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M28";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F29";
			}
			else {
				Local_44.f_7 = "LOC_T29";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "BhamCa")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M2";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F3";
			}
			else {
				Local_44.f_7 = "LOC_T3";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Banning")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M3";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F4";
			}
			else {
				Local_44.f_7 = "LOC_T4";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Baytre")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M4";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F5";
			}
			else {
				Local_44.f_7 = "LOC_T5";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Beach")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M93";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F94";
			}
			else {
				Local_44.f_7 = "LOC_T94";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "BradT")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M7";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F8";
			}
			else {
				Local_44.f_7 = "LOC_T8";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "BradP")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M6";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F7";
			}
			else {
				Local_44.f_7 = "LOC_T7";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Burton")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M8";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F9";
			}
			else {
				Local_44.f_7 = "LOC_T9";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CANNY")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M70";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F71";
			}
			else {
				Local_44.f_7 = "LOC_T71";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CCreak")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M10";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F11";
			}
			else {
				Local_44.f_7 = "LOC_T11";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CalafB")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M9";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F10";
			}
			else {
				Local_44.f_7 = "LOC_T10";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ChamH")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M11";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F12";
			}
			else {
				Local_44.f_7 = "LOC_T12";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CHU")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M13";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F14";
			}
			else {
				Local_44.f_7 = "LOC_T14";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CHIL")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M96";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F97";
			}
			else {
				Local_44.f_7 = "LOC_T97";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "COSI")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M14";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F15";
			}
			else {
				Local_44.f_7 = "LOC_T15";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "CMSW")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M12";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F13";
			}
			else {
				Local_44.f_7 = "LOC_T13";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Cypre")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M15";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F16";
			}
			else {
				Local_44.f_7 = "LOC_T16";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Davis")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M16";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F17";
			}
			else {
				Local_44.f_7 = "LOC_T17";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Desrt")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M32";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F33";
			}
			else {
				Local_44.f_7 = "LOC_T33";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "DelBe")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M19";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F20";
			}
			else {
				Local_44.f_7 = "LOC_T20";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "DelPe")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M18";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F19";
			}
			else {
				Local_44.f_7 = "LOC_T19";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "DelSol")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M41";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F42";
			}
			else {
				Local_44.f_7 = "LOC_T42";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Downt")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M20";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F21";
			}
			else {
				Local_44.f_7 = "LOC_T21";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "DTVine")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M21";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F22";
			}
			else {
				Local_44.f_7 = "LOC_T22";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Eclips")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M24";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F25";
			}
			else {
				Local_44.f_7 = "LOC_T25";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ELSant")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M22";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F23";
			}
			else {
				Local_44.f_7 = "LOC_T23";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "EBuro")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M25";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F26";
			}
			else {
				Local_44.f_7 = "LOC_T26";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ELGorl")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M26";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F27";
			}
			else {
				Local_44.f_7 = "LOC_T27";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Elysian")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M27";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F28";
			}
			else {
				Local_44.f_7 = "LOC_T28";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Galli")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M31";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F32";
			}
			else {
				Local_44.f_7 = "LOC_T32";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Galfish")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M29";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F30";
			}
			else {
				Local_44.f_7 = "LOC_T30";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Greatc")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M34";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F35";
			}
			else {
				Local_44.f_7 = "LOC_T35";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Golf")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M35";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F36";
			}
			else {
				Local_44.f_7 = "LOC_T36";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "GrapeS")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M33";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F34";
			}
			else {
				Local_44.f_7 = "LOC_T34";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Hawick")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M37";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F38";
			}
			else {
				Local_44.f_7 = "LOC_T38";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Harmo")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M36";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F37";
			}
			else {
				Local_44.f_7 = "LOC_T37";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Heart")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M38";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F39";
			}
			else {
				Local_44.f_7 = "LOC_T39";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "HumLab")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M39";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F40";
			}
			else {
				Local_44.f_7 = "LOC_T40";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "HORS")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M97";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F98";
			}
			else {
				Local_44.f_7 = "LOC_T98";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Koreat")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M46";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F47";
			}
			else {
				Local_44.f_7 = "LOC_T47";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Jail")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M5";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F6";
			}
			else {
				Local_44.f_7 = "LOC_T6";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LAct")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M45";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F46";
			}
			else {
				Local_44.f_7 = "LOC_T46";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LDam")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M44";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F45";
			}
			else {
				Local_44.f_7 = "LOC_T45";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Lago")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M43";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F44";
			}
			else {
				Local_44.f_7 = "LOC_T44";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LegSqu")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F";
			}
			else {
				Local_44.f_7 = "LOC_T";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LosSF")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M47";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F48";
			}
			else {
				Local_44.f_7 = "LOC_T48";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LMesa")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M40";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F41";
			}
			else {
				Local_44.f_7 = "LOC_T41";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LosPuer")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M41";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F42";
			}
			else {
				Local_44.f_7 = "LOC_T42";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LosPFy")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M42";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F43";
			}
			else {
				Local_44.f_7 = "LOC_T43";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "LOSTMC")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F";
			}
			else {
				Local_44.f_7 = "LOC_T";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Mirr")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M50";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F51";
			}
			else {
				Local_44.f_7 = "LOC_T51";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Morn")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M52";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F53";
			}
			else {
				Local_44.f_7 = "LOC_T53";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Murri")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M56";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F57";
			}
			else {
				Local_44.f_7 = "LOC_T57";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "MTChil")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M53";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F54";
			}
			else {
				Local_44.f_7 = "LOC_T54";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "MTJose")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M55";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F56";
			}
			else {
				Local_44.f_7 = "LOC_T56";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "MTGordo")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M54";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F55";
			}
			else {
				Local_44.f_7 = "LOC_T55";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Movie")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M72";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F73";
			}
			else {
				Local_44.f_7 = "LOC_T73";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "NCHU")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M57";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F58";
			}
			else {
				Local_44.f_7 = "LOC_T58";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Noose")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M84";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F85";
			}
			else {
				Local_44.f_7 = "LOC_T85";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Oceana")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M60";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F61";
			}
			else {
				Local_44.f_7 = "LOC_T61";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Observ")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M30";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F31";
			}
			else {
				Local_44.f_7 = "LOC_T31";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Palmpow")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M64";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F65";
			}
			else {
				Local_44.f_7 = "LOC_T65";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "PBOX")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M66";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F67";
			}
			else {
				Local_44.f_7 = "LOC_T67";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "PBluff")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M59";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F60";
			}
			else {
				Local_44.f_7 = "LOC_T60";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Paleto")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M61";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F62";
			}
			else {
				Local_44.f_7 = "LOC_T62";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "PalCov")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M62";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F63";
			}
			else {
				Local_44.f_7 = "LOC_T63";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "PalFor")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M63";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F64";
			}
			else {
				Local_44.f_7 = "LOC_T64";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "PalHigh")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M65";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F66";
			}
			else {
				Local_44.f_7 = "LOC_T66";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ProcoB")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M68";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F69";
			}
			else {
				Local_44.f_7 = "LOC_T69";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Prol")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M58";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F59";
			}
			else {
				Local_44.f_7 = "LOC_T59";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "RTRAK")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M71";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F72";
			}
			else {
				Local_44.f_7 = "LOC_T72";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Rancho")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M69";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F70";
			}
			else {
				Local_44.f_7 = "LOC_T70";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "RGLEN")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M74";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F75";
			}
			else {
				Local_44.f_7 = "LOC_T75";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Richm")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M73";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F74";
			}
			else {
				Local_44.f_7 = "LOC_T74";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Rockf")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M75";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F76";
			}
			else {
				Local_44.f_7 = "LOC_T76";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "SANDY")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M79";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F80";
			}
			else {
				Local_44.f_7 = "LOC_T80";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "TongvaH")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M87";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F88";
			}
			else {
				Local_44.f_7 = "LOC_T88";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "TongvaV")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M88";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F89";
			}
			else {
				Local_44.f_7 = "LOC_T89";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "East_V")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M23";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F24";
			}
			else {
				Local_44.f_7 = "LOC_T24";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Zenora")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M80";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F81";
			}
			else {
				Local_44.f_7 = "LOC_T81";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Slab")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M81";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F82";
			}
			else {
				Local_44.f_7 = "LOC_T82";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "SKID")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M51";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F52";
			}
			else {
				Local_44.f_7 = "LOC_T52";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "SLSant")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M82";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F83";
			}
			else {
				Local_44.f_7 = "LOC_T83";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Stad")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M49";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F50";
			}
			else {
				Local_44.f_7 = "LOC_T50";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Tatamo")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M84";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F85";
			}
			else {
				Local_44.f_7 = "LOC_T85";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Termina")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M85";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F86";
			}
			else {
				Local_44.f_7 = "LOC_T86";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "TEXTI")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M86";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F87";
			}
			else {
				Local_44.f_7 = "LOC_T87";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "WVine")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M99";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F100";
			}
			else {
				Local_44.f_7 = "LOC_T100";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "UtopiaG")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M89";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F90";
			}
			else {
				Local_44.f_7 = "LOC_T90";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Vesp")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M92";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F93";
			}
			else {
				Local_44.f_7 = "LOC_T93";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "VCana")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M94";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F95";
			}
			else {
				Local_44.f_7 = "LOC_T95";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Vine")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M95";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F96";
			}
			else {
				Local_44.f_7 = "LOC_T96";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "WMirror")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M98";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F99";
			}
			else {
				Local_44.f_7 = "LOC_T99";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "WindF")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M76";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F77";
			}
			else {
				Local_44.f_7 = "LOC_T77";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "Zancudo")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M100";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F101";
			}
			else {
				Local_44.f_7 = "LOC_T101";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "SanChia")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M78";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F79";
			}
			else {
				Local_44.f_7 = "LOC_T79";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "STRAW")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M83";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F84";
			}
			else {
				Local_44.f_7 = "LOC_T84";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "zQ_UAR")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M17";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F18";
			}
			else {
				Local_44.f_7 = "LOC_T18";
			}
			return;
		}
		if (gameplay::are_strings_equal(Local_44.f_6, "ZP_ORT")) {
			if (iParam0 == 0) {
				Local_44.f_7 = "LOC_M67";
			}
			else if (iParam0 == 1) {
				Local_44.f_7 = "LOC_F68";
			}
			else {
				Local_44.f_7 = "LOC_T68";
			}
			return;
		}
		if (iParam0 == 0) {
			Local_44.f_7 = "LOC_M";
		}
		else if (iParam0 == 1) {
			Local_44.f_7 = "LOC_M";
		}
		else {
			Local_44.f_7 = "LOC_M";
		}
	}
	else if (iParam0 == 0) {
		Local_44.f_7 = "LOC_M";
	}
	else if (iParam0 == 1) {
		Local_44.f_7 = "LOC_F";
	}
	else {
		Local_44.f_7 = "LOC_T";
	}
}

// Position - 0x8920
char *func_156(int iParam0) {
	char *sVar0;

	if (!gameplay::is_bit_set(iLocal_105, 10)) {
		if (iLocal_42 == 0) {
			sLocal_1272 = "FBIPRAU";
		}
		else if (iLocal_42 == 1) {
			sLocal_1272 = "AHFAUD";
		}
		else if (iLocal_42 == 2) {
			sLocal_1272 = "FHFAUD";
		}
		if (iLocal_42 == 0) {
			if (iParam0 == 0) {
				sVar0 = "FBI_3_MDRPC";
			}
			else if (iParam0 == 1) {
				sVar0 = "FBI_3_FDRPC";
			}
			else if (iParam0 == 2) {
				sVar0 = "FBI_3_TDRPC";
			}
		}
		else if (iLocal_42 == 1) {
			if (iParam0 == 0) {
				sVar0 = "AH_MDRPC";
			}
			else if (iParam0 == 1) {
				sVar0 = "AH_FDRPC";
			}
			else if (iParam0 == 2) {
				sVar0 = "AH_TDRPC";
			}
		}
		else if (iLocal_42 == 2) {
			if (iParam0 == 0) {
				sVar0 = "FHP_PICKCM";
			}
			else if (iParam0 == 1) {
				sVar0 = "FHP_PICKCF";
			}
			else if (iParam0 == 2) {
				sVar0 = "FHP_PICKCT";
			}
		}
	}
	else {
		sLocal_1272 = "FHFAUD";
		if (iParam0 == 0) {
			sVar0 = "FHP_MOVEM";
		}
		else if (iParam0 == 1) {
			sVar0 = "FHP_MOVEF";
		}
		else if (iParam0 == 2) {
			sVar0 = "FHP_MOVET";
		}
	}
	return sVar0;
}

// Position - 0x8A2D
bool func_157() {
	if (gameplay::is_bit_set(iLocal_105, 0)) {
		if (func_82(iLocal_109)) {
			if (gameplay::is_bit_set(iLocal_105, 1)) {
				if (func_160(0) || func_160(12) || func_160(1)) {
					func_158();
					func_1(46, 1);
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x8A81
void func_158() {
	if (!gameplay::is_bit_set(iLocal_105, 6)) {
		if (func_82(iLocal_109)) {
			vLocal_110 = {entity::get_entity_coords(iLocal_109, 1)};
			fLocal_113 = entity::get_entity_heading(iLocal_109);
			gameplay::set_bit(&iLocal_105, 6);
			gameplay::set_bit(&iLocal_105, 2);
			func_61(iLocal_109, &Local_114);
			func_20(iLocal_109, vLocal_110, fLocal_113, 25, 1);
			gameplay::set_bit(&iLocal_105, 14);
			func_159(iLocal_109);
		}
	}
}

// Position - 0x8AE4
int func_159(int iParam0) {
	if (!decorator::decor_exist_on(iParam0, "IgnoredByQuickSave")) {
		if (decorator::decor_set_bool(iParam0, "IgnoredByQuickSave", 1)) {
			return 1;
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0x8B14
int func_160(int iParam0) {
	if (Global_16860 == 0) {
		return 0;
	}
	if (Global_117[iParam0 /*10*/].f_8 != 140) {
		if (Global_14443.f_1 == 10) {
			if (Global_1628 == iParam0) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 0;
		}
	}
	return 0;
}

// Position - 0x8B5D
void func_161() {
	if (gameplay::is_bit_set(iLocal_105, 0) && gameplay::is_bit_set(iLocal_105, 1)) {
		if (!gameplay::is_bit_set(iLocal_105, 11)) {
			func_250(1);
		}
	}
	else if (gameplay::is_bit_set(iLocal_105, 11)) {
		func_250(0);
	}
}

// Position - 0x8B9F
void func_162() {
	if (gameplay::is_bit_set(iLocal_105, 0) && Global_35781 == 15 && !func_193()) {
		if (iLocal_38 == 0) {
			if (!gameplay::is_bit_set(iLocal_105, 1) && gameplay::is_bit_set(iLocal_105, 0)) {
				if (!func_73(player::player_ped_id(), vLocal_106, 5f)) {
					if (gameplay::is_bit_set(iLocal_105, 20) || func_128()) {
						if (func_235(player::player_ped_id()) && !gameplay::is_bit_set(uLocal_101[0], 17) &&
							!gameplay::is_bit_set(uLocal_101[1], 18)) {
							if (ped::is_ped_stopped(player::player_ped_id())) {
								func_192(24, 46);
								if (gameplay::is_bit_set(iLocal_105, 0)) {
									if (!func_190() && func_170(entity::get_entity_coords(iLocal_109, 1))) {
										if (func_167(iLocal_109)) {
											if (func_166(iLocal_109)) {
												gameplay::set_bit(&iLocal_105, 1);
												if (func_68(player::player_ped_id()) == 0) {
													func_67(7);
													func_1(7, 1);
												}
												else {
													func_67(8);
													func_1(8, 1);
												}
												vLocal_106 = {entity::get_entity_coords(player::player_ped_id(), 1)};
												return;
											}
										}
									}
									if (gameplay::is_bit_set(iLocal_105, 20)) {
										func_1(46, 0);
										gameplay::clear_bit(&iLocal_105, 20);
										iLocal_1438 = -1;
									}
									vLocal_106 = {entity::get_entity_coords(player::player_ped_id(), 1)};
								}
							}
							else if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
								func_192(7, 8);
								if (gameplay::is_bit_set(iLocal_105, 20)) {
									gameplay::clear_bit(&iLocal_105, 20);
									iLocal_1438 = -1;
								}
								else {
									func_67(24);
								}
							}
						}
					}
					else if (!func_12()) {
						if (ped::is_ped_stopped(player::player_ped_id()) &&
							ped::is_ped_in_any_vehicle(player::player_ped_id(), 0) &&
							!gameplay::is_bit_set(iLocal_105, 20)) {
							if (iLocal_1438 != -1) {
								if (gameplay::get_game_timer() - iLocal_1438 > 1000) {
									gameplay::set_bit(&iLocal_105, 20);
								}
							}
							else {
								iLocal_1438 = gameplay::get_game_timer();
							}
						}
						else {
							gameplay::clear_bit(&iLocal_105, 20);
						}
					}
				}
				else if (func_12()) {
					vLocal_106 = {0f, 0f, 0f};
				}
			}
			else if (gameplay::is_bit_set(iLocal_105, 0)) {
				if (!func_73(player::player_ped_id(), vLocal_106, 10f)) {
					gameplay::clear_bit(&iLocal_105, 1);
				}
				else if (!ped::is_ped_stopped(player::player_ped_id())) {
					if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
						if (!gameplay::is_bit_set(iLocal_105, 20)) {
							func_67(24);
						}
						func_1(24, 1);
						gameplay::clear_bit(&iLocal_105, 1);
						func_164(0);
					}
				}
				else if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					if (func_82(iLocal_109)) {
						if (ped::get_vehicle_ped_is_in(player::player_ped_id(), 0) != iLocal_109) {
							func_1(46, 0);
							func_164(0);
							func_163();
						}
					}
				}
			}
		}
	}
}

// Position - 0x8E2F
void func_163() {
	gameplay::clear_bit(&iLocal_105, 0);
	gameplay::clear_bit(&iLocal_105, 8);
	gameplay::clear_bit(&iLocal_105, 7);
}

// Position - 0x8E4D
void func_164(int iParam0) {
	if (Global_14604) {
		func_165(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_142()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x8EBD
void func_165(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_14(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x8F31
bool func_166(int iParam0) {
	vector3 vVar0;

	if (entity::is_entity_upsidedown(iParam0)) {
		func_67(39);
		return false;
	}
	if (!vehicle::_0x639431E895B9AA57(player::player_ped_id(), iParam0, -1, 0, 0) &&
		!vehicle::_0x639431E895B9AA57(player::player_ped_id(), iParam0, 0, 0, 0)) {
		func_67(37);
		return false;
	}
	if (entity::is_entity_in_water(iParam0)) {
		func_67(36);
		return false;
	}
	vVar0 = {entity::get_entity_rotation(iParam0, 2)};
	if (vVar0.x >= 10f || vVar0.x <= -10f) {
		func_67(42);
		return false;
	}
	else if (vVar0.y >= 15f || vVar0.y <= -15f) {
		func_67(43);
		return false;
	}
	return true;
}

// Position - 0x8FE6
bool func_167(int iParam0) {
	int iVar0;
	vector3 vVar1;
	vector3 vVar4;

	iVar0 = 0;
	if (iParam0 != 0) {
		if (func_82(iParam0)) {
			gameplay::get_model_dimensions(entity::get_entity_model(iParam0), &vVar1, &vVar4);
			vVar1 = {vVar1 + Vector(-1f, -1f, -2f)};
			vVar4 = {vVar4 + Vector(1f, 1f, 2f)};
			if (!gameplay::is_area_occupied(entity::get_offset_from_entity_in_world_coords(iParam0, vVar1),
											entity::get_offset_from_entity_in_world_coords(iParam0, vVar4), 0, 1, 0, 0,
											0, iParam0, 0)) {
				iVar0++;
			}
			else if (func_12()) {
				func_67(38);
			}
			if (!func_169()) {
				iVar0++;
			}
			else if (func_12()) {
				func_67(35);
			}
			if (iVar0 == 2) {
				if (func_168(entity::get_entity_coords(iParam0, 1))) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x909B
bool func_168(vector3 vParam0) {
	float fVar0;
	float fVar1;
	vector3 vVar2;

	vVar2 = {vParam0 + Vector(3.2f, 0f, 0f)};
	if (gameplay::get_ground_z_for_3d_coord(vVar2, &fVar0, 0) &&
		gameplay::get_ground_z_for_3d_coord(vParam0, &fVar1, 0)) {
		if (gameplay::absf(fVar0 - fVar1) < 0.9f) {
			return true;
		}
	}
	if (func_12()) {
		func_67(37);
	}
	return false;
}

// Position - 0x90F5
int func_169() {
	var uVar0[5];
	int iVar6;

	ped::get_ped_nearby_peds(player::player_ped_id(), &uVar0, -1);
	iVar6 = 0;
	while (iVar6 <= 4) {
		if (func_235(uVar0[iVar6]) && uVar0[iVar6] != player::player_ped_id()) {
			if (system::vdist2(vLocal_106, entity::get_entity_coords(uVar0[iVar6], 1)) <= 16f) {
				return 1;
			}
		}
		iVar6++;
	}
	return 0;
}

// Position - 0x915E
int func_170(vector3 vParam0) {
	if (!func_186() && !func_185(vParam0)) {
		if (!func_182()) {
			if (!func_178(vParam0)) {
				if (!func_176(vParam0) && !func_171(vParam0)) {
					return 1;
				}
			}
			else {
				func_67(0);
			}
		}
	}
	return 0;
}

// Position - 0x91B7
int func_171(vector3 vParam0) {
	if (func_174(vParam0) || func_172(vParam0)) {
		if (func_12()) {
			func_67(22);
		}
		return 1;
	}
	return 0;
}

// Position - 0x91EA
int func_172(vector3 vParam0) {
	float fVar0;

	fVar0 = system::vdist2(vParam0, Global_86963[func_173(vParam0, 0) /*9*/].f_3);
	if (fVar0 <= 40000f) {
		return 1;
	}
	return 0;
}

// Position - 0x921F
int func_173(vector3 vParam0, int iParam3) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = 7;
	iVar0 = 0;
	while (iVar0 <= 7 - 1) {
		if (Global_86963[iVar0 /*9*/].f_7 != 263) {
			if (!iParam3 || gameplay::is_bit_set(Global_101700.f_6188.f_17[iVar0], 0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, Global_86963[iVar0 /*9*/].f_3, 1);
				if (fVar1 < fVar2) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x929C
int func_174(vector3 vParam0) {
	float fVar0;

	fVar0 = system::vdist2(vParam0, Global_87027[func_175(vParam0, 0) /*9*/].f_3);
	if (fVar0 <= 40000f) {
		return 1;
	}
	return 0;
}

// Position - 0x92D1
int func_175(vector3 vParam0, int iParam3) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1E+07f;
	iVar3 = 5;
	iVar0 = 0;
	while (iVar0 <= 5 - 1) {
		if (Global_87027[iVar0 /*9*/].f_7 != 263) {
			if (!iParam3 || gameplay::is_bit_set(Global_101700.f_6188.f_11[iVar0], 0)) {
				fVar1 = gameplay::get_distance_between_coords(vParam0, Global_87027[iVar0 /*9*/].f_3, 1);
				if (fVar1 < fVar2) {
					fVar2 = fVar1;
					iVar3 = iVar0;
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0x934E
int func_176(vector3 vParam0) {
	vector3 vVar0;
	float fVar3;

	if (pathfind::get_closest_vehicle_node(vParam0, &vVar0, 0, 1077936128, 0)) {
		fVar3 = system::vdist2(vParam0, vVar0);
		if (fVar3 >= 400f || !func_177(vParam0, vVar0)) {
			return 0;
		}
		else if (fVar3 < 20f && fVar3 > 6f) {
			if (func_12()) {
				func_67(40);
			}
			return 1;
		}
		else {
			if (func_12()) {
				func_67(41);
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x93D7
int func_177(vector3 vParam0, vector3 vParam3) {
	float fVar0;

	fVar0 = gameplay::absf(vParam0.z - vParam3.z);
	if (fVar0 <= 5f) {
		return 1;
	}
	return 0;
}

// Position - 0x93FA
int func_178(vector3 vParam0) {
	if (!func_181(1)) {
		if (!func_181(0)) {
			if (func_179(vParam0, 0)) {
				return 1;
			}
		}
		else if (func_179(vParam0, 1)) {
			return 1;
		}
	}
	if (!func_181(7)) {
		if (!func_181(4)) {
			if (func_179(vParam0, 4)) {
				return 1;
			}
		}
		else {
			if (func_179(vParam0, 5)) {
				return 1;
			}
			if (func_179(vParam0, 6)) {
				return 1;
			}
		}
	}
	if (func_179(vParam0, 2)) {
		return 1;
	}
	if (func_179(vParam0, 3)) {
		return 1;
	}
	if (!func_181(8)) {
		if (func_179(vParam0, 8)) {
			return 1;
		}
	}
	if (!func_181(16)) {
		if (func_179(vParam0, 16)) {
			return 1;
		}
		if (!func_181(15)) {
			if (func_179(vParam0, 15)) {
				return 1;
			}
			if (!func_181(14)) {
				if (func_179(vParam0, 14)) {
					return 1;
				}
				if (!func_181(13)) {
					if (func_179(vParam0, 13)) {
						return 1;
					}
					if (!func_181(12)) {
						if (func_179(vParam0, 12)) {
							return 1;
						}
						if (!func_181(11)) {
							if (func_179(vParam0, 11)) {
								return 1;
							}
							if (!func_181(10)) {
								if (func_179(vParam0, 10)) {
									return 1;
								}
								if (!func_181(9)) {
									if (func_179(vParam0, 9)) {
										return 1;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	if (!func_181(20)) {
		if (func_179(vParam0, 20)) {
			return 1;
		}
		if (!func_181(19)) {
			if (func_179(vParam0, 19)) {
				return 1;
			}
			if (!func_181(18)) {
				if (func_179(vParam0, 18)) {
					return 1;
				}
				if (!func_181(17)) {
					if (func_179(vParam0, 17)) {
						return 1;
					}
				}
			}
		}
	}
	if (!func_181(21)) {
		if (func_179(vParam0, 21)) {
			return 1;
		}
	}
	if (!func_181(22)) {
		if (func_179(vParam0, 22)) {
			return 1;
		}
	}
	if (!func_181(23)) {
		if (func_179(vParam0, 23)) {
			return 1;
		}
	}
	if (!func_181(24)) {
		if (func_179(vParam0, 24)) {
			return 1;
		}
	}
	if (!func_181(26)) {
		if (!func_181(25)) {
			if (func_179(vParam0, 25)) {
				return 1;
			}
		}
		else if (func_179(vParam0, 26)) {
			return 1;
		}
	}
	if (!func_181(30)) {
		if (func_179(vParam0, 30)) {
			return 1;
		}
		if (!func_181(29)) {
			if (func_179(vParam0, 29)) {
				return 1;
			}
			if (!func_181(28)) {
				if (func_179(vParam0, 28)) {
					return 1;
				}
				if (!func_181(27)) {
					if (func_179(vParam0, 27)) {
						return 1;
					}
				}
			}
		}
	}
	if (!func_181(31)) {
		if (func_179(vParam0, 31)) {
			return 1;
		}
	}
	if (!func_181(34)) {
		if (func_179(vParam0, 34)) {
			return 1;
		}
		if (!func_181(33)) {
			if (func_179(vParam0, 33)) {
				return 1;
			}
			if (!func_181(32)) {
				if (func_179(vParam0, 32)) {
					return 1;
				}
			}
		}
	}
	if (!func_181(35)) {
		if (func_179(vParam0, 35)) {
			return 1;
		}
	}
	if (!func_181(36)) {
		if (func_179(vParam0, 36)) {
			return 1;
		}
	}
	if (!func_181(43)) {
		if (func_179(vParam0, 43)) {
			return 1;
		}
		if (!func_181(42)) {
			if (func_179(vParam0, 42)) {
				return 1;
			}
			if (!func_181(38)) {
				if (func_179(vParam0, 42)) {
					return 1;
				}
			}
			if (!func_181(39)) {
				if (func_179(vParam0, 42)) {
					return 1;
				}
			}
			if (!func_181(40)) {
				if (func_179(vParam0, 42)) {
					return 1;
				}
			}
			if (!func_181(41)) {
				if (func_179(vParam0, 42)) {
					return 1;
				}
			}
			if (!func_181(37)) {
				if (func_179(vParam0, 42)) {
					return 1;
				}
			}
		}
	}
	if (!func_181(45)) {
		if (func_179(vParam0, 45)) {
			return 1;
		}
		if (!func_181(44)) {
			if (func_179(vParam0, 44)) {
				return 1;
			}
		}
	}
	if (!func_181(51)) {
		if (func_179(vParam0, 51)) {
			return 1;
		}
		if (!func_181(48)) {
			if (func_179(vParam0, 48)) {
				return 1;
			}
			if (!func_181(49)) {
				if (func_179(vParam0, 49)) {
					return 1;
				}
			}
			if (!func_181(50)) {
				if (func_179(vParam0, 50)) {
					return 1;
				}
			}
			if (!func_181(47)) {
				if (func_179(vParam0, 47)) {
					return 1;
				}
				if (!func_181(46)) {
					if (func_179(vParam0, 46)) {
						return 1;
					}
				}
			}
		}
	}
	if (!func_181(53)) {
		if (func_179(vParam0, 53)) {
			return 1;
		}
		if (!func_181(56)) {
			if (func_179(vParam0, 56)) {
				return 1;
			}
			if (!func_181(55)) {
				if (func_179(vParam0, 55)) {
					return 1;
				}
			}
			if (!func_181(54)) {
				if (func_179(vParam0, 54)) {
					return 1;
				}
			}
			if (!func_181(52)) {
				if (func_179(vParam0, 52)) {
					return 1;
				}
			}
		}
	}
	if (!func_181(57)) {
		if (func_179(vParam0, 57)) {
			return 1;
		}
	}
	if (!func_181(62)) {
		if (func_179(vParam0, 62)) {
			return 1;
		}
		if (!func_181(61)) {
			if (func_179(vParam0, 61)) {
				return 1;
			}
			if (!func_181(60)) {
				if (func_179(vParam0, 60)) {
					return 1;
				}
				if (!func_181(59)) {
					if (func_179(vParam0, 59)) {
						return 1;
					}
					if (!func_181(58)) {
						if (func_179(vParam0, 58)) {
							return 1;
						}
					}
				}
			}
		}
	}
	return 0;
}

// Position - 0x9A6D
bool func_179(vector3 vParam0, int iParam3) {
	float fVar0;

	fVar0 = system::vdist2(vParam0, func_180(iParam3));
	if (fVar0 <= 625f) {
		return true;
	}
	return false;
}

// Position - 0x9A95
Vector3 func_180(int iParam0) {
	vector3 vVar0;

	if (iParam0 == 0) {
		vVar0 = {-1604.668f, 5239.1f, 3.01f};
	}
	else if (iParam0 == 1) {
		vVar0 = {-1592.84f, 5214.04f, 3.01f};
	}
	else if (iParam0 == 2) {
		vVar0 = {190.26f, -956.35f, 29.63f};
	}
	else if (iParam0 == 3) {
		vVar0 = {190.26f, -956.35f, 29.63f};
	}
	else if (iParam0 == 4) {
		vVar0 = {414f, -761f, 29f};
	}
	else if (iParam0 == 5) {
		vVar0 = {1199.27f, -1255.63f, 34.23f};
	}
	else if (iParam0 == 6) {
		vVar0 = {-468.9f, -1713.06f, 18.21f};
	}
	else if (iParam0 == 7) {
		vVar0 = {237.65f, -385.41f, 44.4f};
	}
	else if (iParam0 == 8) {
		vVar0 = {-1458.97f, 485.99f, 115.38f};
	}
	else if (iParam0 == 9) {
		vVar0 = {-1622.89f, 4204.87f, 83.3f};
	}
	else if (iParam0 == 10) {
		vVar0 = {242.7f, 362.7f, 104.74f};
	}
	else if (iParam0 == 11) {
		vVar0 = {1835.53f, 4705.86f, 38.1f};
	}
	else if (iParam0 == 12) {
		vVar0 = {1826.13f, 4698.88f, 38.92f};
	}
	else if (iParam0 == 13) {
		vVar0 = {637.02f, 119.7093f, 89.5f};
	}
	else if (iParam0 == 14) {
		vVar0 = {-2892.93f, 3192.37f, 11.66f};
	}
	else if (iParam0 == 15) {
		vVar0 = {524.43f, 3079.82f, 39.48f};
	}
	else if (iParam0 == 16) {
		vVar0 = {-697.75f, 45.38f, 43.03f};
	}
	else if (iParam0 == 17) {
		vVar0 = {-188.22f, 1296.1f, 302.86f};
	}
	else if (iParam0 == 18) {
		vVar0 = {-954.19f, -2760.05f, 14.64f};
	}
	else if (iParam0 == 19) {
		vVar0 = {-63.8f, -809.5f, 321.8f};
	}
	else if (iParam0 == 20) {
		vVar0 = {1731.41f, 96.96f, 170.39f};
	}
	else if (iParam0 == 21) {
		vVar0 = {-1877.82f, -440.649f, 45.05f};
	}
	else if (iParam0 == 22) {
		vVar0 = {809.66f, 1279.76f, 360.49f};
	}
	else if (iParam0 == 23) {
		vVar0 = {-915.6f, 6139.2f, 5.5f};
	}
	else if (iParam0 == 24) {
		vVar0 = {-72.29f, -1260.63f, 28.14f};
	}
	else if (iParam0 == 25) {
		vVar0 = {1804.32f, 3931.33f, 32.82f};
	}
	else if (iParam0 == 26) {
		vVar0 = {-684.17f, 5839.16f, 16.09f};
	}
	else if (iParam0 == 27) {
		vVar0 = {-1104.93f, 291.25f, 64.3f};
	}
	else if (iParam0 == 28) {
		vVar0 = {565.39f, -1772.88f, 29.77f};
	}
	else if (iParam0 == 29) {
		vVar0 = {565.39f, -1772.88f, 29.77f};
	}
	else if (iParam0 == 30) {
		vVar0 = {-1104.93f, 291.25f, 64.3f};
	}
	else if (iParam0 == 31) {
		vVar0 = {2726.1f, 4145f, 44.3f};
	}
	else if (iParam0 == 32) {
		vVar0 = {327.85f, 3405.7f, 35.73f};
	}
	else if (iParam0 == 33) {
		vVar0 = {18f, 4527f, 105f};
	}
	else if (iParam0 == 34) {
		vVar0 = {-303.82f, 6211.29f, 31.05f};
	}
	else if (iParam0 == 35) {
		vVar0 = {1972.59f, 3816.43f, 32.42f};
	}
	else if (iParam0 == 36) {
		vVar0 = {0f, 0f, 0f};
	}
	else if (iParam0 == 37) {
		vVar0 = {-1097.16f, 790.01f, 164.52f};
	}
	else if (iParam0 == 38) {
		vVar0 = {-558.65f, 284.49f, 90.86f};
	}
	else if (iParam0 == 39) {
		vVar0 = {-1034.15f, 366.08f, 80.11f};
	}
	else if (iParam0 == 40) {
		vVar0 = {-623.91f, -266.17f, 37.76f};
	}
	else if (iParam0 == 41) {
		vVar0 = {-1096.85f, 67.68f, 52.95f};
	}
	else if (iParam0 == 42) {
		vVar0 = {-1310.7f, -640.22f, 26.54f};
	}
	else if (iParam0 == 43) {
		vVar0 = {-44.75f, -1288.67f, 28.21f};
	}
	else if (iParam0 == 44) {
		vVar0 = {2468.51f, 3437.39f, 49.9f};
	}
	else if (iParam0 == 45) {
		vVar0 = {2319.44f, 2583.58f, 46.76f};
	}
	else if (iParam0 == 46) {
		vVar0 = {-149.75f, 285.81f, 93.67f};
	}
	else if (iParam0 == 47) {
		vVar0 = {-70.71f, 301.43f, 106.79f};
	}
	else if (iParam0 == 48) {
		vVar0 = {-257.22f, 292.85f, 90.63f};
	}
	else if (iParam0 == 49) {
		vVar0 = {305.52f, 157.19f, 102.94f};
	}
	else if (iParam0 == 50) {
		vVar0 = {1040.96f, -534.42f, 60.17f};
	}
	else if (iParam0 == 51) {
		vVar0 = {-484.2f, 229.68f, 82.21f};
	}
	else if (iParam0 == 52) {
		vVar0 = {908f, 3643.7f, 32.2f};
	}
	else if (iParam0 == 54) {
		vVar0 = {465.1f, -1849.3f, 27.8f};
	}
	else if (iParam0 == 55) {
		vVar0 = {-161f, -1669.7f, 33f};
	}
	else if (iParam0 == 56) {
		vVar0 = {-1298.2f, 2504.14f, 21.09f};
	}
	else if (iParam0 == 53) {
		vVar0 = {1181.5f, -400.1f, 67.5f};
	}
	else if (iParam0 == 57) {
		vVar0 = {-1298.98f, 4640.16f, 105.67f};
	}
	else if (iParam0 == 58 || iParam0 == 59 || iParam0 == 62) {
		vVar0 = {-14.39f, -1472.69f, 29.58f};
	}
	else if (iParam0 == 60) {
		vVar0 = {0f, 0f, 0f};
	}
	else if (iParam0 == 61) {
		vVar0 = {0f, 0f, 0f};
	}
	return vVar0;
}

// Position - 0xA172
int func_181(int iParam0) {
	if (iParam0 == 63 || iParam0 == -1) {
		return 0;
	}
	return gameplay::is_bit_set(Global_101700.f_17533[iParam0 /*6*/], 3);
}

// Position - 0xA1A0
int func_182() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 <= 4 - 1) {
		iVar1 = 0;
		while (iVar1 <= Local_204[iVar0 /*261*/].f_257 - 1) {
			if (gameplay::is_bit_set(Local_204[iVar0 /*261*/].f_258, iVar1)) {
				if (func_184(sLocal_1263)) {
					if (Local_204[iVar0 /*261*/].f_260 == 0) {
						if (func_12()) {
							func_67(21);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 2) {
						if (func_12()) {
							func_67(22);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 1) {
						if (func_12()) {
							func_67(23);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 3) {
						if (func_12()) {
							func_67(20);
						}
					}
					return 1;
				}
				if (func_183(&Local_204[iVar0 /*261*/][iVar1 /*8*/])) {
					if (Local_204[iVar0 /*261*/].f_260 == 0) {
						if (func_12()) {
							func_67(21);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 2) {
						if (func_12()) {
							func_67(22);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 1) {
						if (func_12()) {
							func_67(23);
						}
					}
					else if (Local_204[iVar0 /*261*/].f_260 == 3) {
						if (func_12()) {
							func_67(20);
						}
					}
					return 1;
				}
			}
			iVar1++;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xA2FB
bool func_183(var *uParam0) {
	if (entity::is_entity_in_angled_area(player::player_ped_id(), uParam0->f_1, uParam0->f_4, uParam0->f_7, 0, 1, 0)) {
		return true;
	}
	return false;
}

// Position - 0xA326
bool func_184(char *sParam0) {
	int iVar0;

	if (gameplay::is_string_null_or_empty(sParam0)) {
		return false;
	}
	iVar0 = 0;
	while (iVar0 <= 12) {
		if (!gameplay::is_string_null(sLocal_1249[iVar0])) {
			if (gameplay::are_strings_equal(sLocal_1249[iVar0], sParam0)) {
				return true;
			}
		}
		iVar0++;
	}
	return false;
}

// Position - 0xA372
int func_185(vector3 vParam0) {
	if (vParam0.z < -90f) {
		return 1;
	}
	if (system::vdist2(vParam0, -89.377f, 92.6583f, 71.2349f) <= 400f ||
		system::vdist2(vParam0, -62.0307f, -1839.859f, 25.6787f) <= 400f ||
		system::vdist2(vParam0, -234.7648f, -1150.311f, 21.9224f) <= 400f) {
		func_67(21);
		return 1;
	}
	return 0;
}

// Position - 0xA3FC
int func_186() {
	int iVar0;
	float fVar1;

	iVar0 = func_188(entity::get_entity_coords(player::player_ped_id(), 1), 145, 1);
	fVar1 = system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), Global_86862[iVar0 /*10*/].f_3);
	if (fVar1 <= 10000f) {
		if (func_12()) {
			func_187(iVar0);
		}
		return 1;
	}
	return 0;
}

// Position - 0xA44E
void func_187(int iParam0) {
	if (iParam0 == 0 || iParam0 == 1) {
		func_67(32);
	}
	else if (iParam0 == 5 || iParam0 == 6) {
		func_67(33);
	}
	else if (iParam0 == 2 || iParam0 == 3 || iParam0 == 4) {
		func_67(34);
	}
}

// Position - 0xA4AB
int func_188(vector3 vParam0, int iParam3, int iParam4) {
	int iVar0;
	float fVar1;
	float fVar2;
	int iVar3;

	fVar2 = 1000000f;
	iVar3 = 10;
	iVar0 = 0;
	while (iVar0 <= 10 - 1) {
		if (Global_86862[iVar0 /*10*/].f_7 != 263) {
			if (Global_86862[iVar0 /*10*/].f_9 == iParam3 || iParam3 == 145) {
				if (func_189(iVar0) || iParam4 == 0) {
					fVar1 = gameplay::get_distance_between_coords(vParam0, Global_86862[iVar0 /*10*/].f_3, 1);
					if (fVar1 < fVar2) {
						fVar2 = fVar1;
						iVar3 = iVar0;
					}
				}
			}
		}
		iVar0++;
	}
	return iVar3;
}

// Position - 0xA53A
var func_189(int iParam0) { return gameplay::is_bit_set(Global_101700.f_6188[iParam0], 0); }

// Position - 0xA552
int func_190() {
	if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), 1276.123f, -1723.665f, 53.6551f) <=
		52900f) {
		if (func_12()) {
			func_67(30);
		}
		return 1;
	}
	else if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), 111.8564f, -751.7169f, 44.757f) <=
			 160000f) {
		if (func_12()) {
			func_67(31);
		}
		return 1;
	}
	else if (func_191(200f)) {
		if (func_12()) {
			func_67(19);
		}
		return 1;
	}
	return 0;
}

// Position - 0xA5EA
bool func_191(float fParam0) {
	if (iLocal_42 == 1) {
		if (func_73(player::player_ped_id(), Global_87770[1 /*15*/], fParam0)) {
			return true;
		}
	}
	else if (iLocal_42 == 2) {
		if (func_73(player::player_ped_id(), Global_87770[0 /*15*/], fParam0)) {
			return true;
		}
	}
	else if (iLocal_42 == 0) {
		if (func_73(player::player_ped_id(), Global_87770[3 /*15*/], fParam0)) {
			return true;
		}
	}
	return false;
}

// Position - 0xA659
void func_192(int iParam0, int iParam1) {
	func_4(iParam0);
	if (func_2(func_3(iParam0))) {
		ui::clear_help(1);
		gameplay::set_bit(&iLocal_105, 15);
	}
	if (iParam1 != 46) {
		func_4(iParam1);
		if (func_2(func_3(iParam1))) {
			ui::clear_help(1);
			gameplay::set_bit(&iLocal_105, 15);
		}
	}
}

// Position - 0xA6A8
int func_193() {
	if (Global_88746 != -1) {
		return gameplay::is_bit_set(Global_82612[Global_88746 /*34*/].f_15, 13);
	}
	return 0;
}

// Position - 0xA6CE
void func_194() {
	int iVar0;
	int iVar1;

	if (Global_35781 == 15 && iLocal_38 == 0 && !func_193()) {
		if (!streaming::is_player_switch_in_progress()) {
			if (!gameplay::is_bit_set(iLocal_105, 0)) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					if (!func_206()) {
						if (!gameplay::is_bit_set(iLocal_105, 7)) {
							iVar0 = player::get_players_last_vehicle();
							if (func_82(iVar0)) {
								if (!func_205(iVar0)) {
									if (!decorator::decor_exist_on(iVar0, "Getaway_Winched")) {
										if (func_198(iVar0) && !func_197()) {
											if (!entity::is_entity_a_mission_entity(iVar0)) {
												if (func_68(player::player_ped_id()) == 0) {
													func_67(17);
												}
												else {
													func_67(18);
												}
												iLocal_109 = iVar0;
												if (decorator::decor_set_bool(iLocal_109, "GetawayVehicleValid", 1)) {
												}
												entity::set_entity_as_mission_entity(iLocal_109, 1, 1);
												gameplay::set_bit(&iLocal_105, 0);
												gameplay::set_bit(&iLocal_105, 8);
												gameplay::set_bit(&iLocal_105, 7);
												return;
											}
											else {
												func_19(&iLocal_109);
												gameplay::clear_bit(&iLocal_105, 7);
												gameplay::clear_bit(&iLocal_105, 0);
												return;
											}
										}
									}
									if (decorator::decor_set_bool(iVar0, "GetawayVehicleValid", 0)) {
									}
									gameplay::set_bit(&iLocal_105, 7);
								}
								else if (func_196(iVar0)) {
									iLocal_109 = iVar0;
									entity::set_entity_as_mission_entity(iLocal_109, 1, 1);
									gameplay::set_bit(&iLocal_105, 0);
									gameplay::set_bit(&iLocal_105, 8);
									gameplay::set_bit(&iLocal_105, 7);
									return;
								}
							}
							else {
								func_19(&iLocal_109);
								gameplay::set_bit(&iLocal_105, 7);
								gameplay::clear_bit(&iLocal_105, 0);
							}
						}
						else if (gameplay::is_bit_set(iLocal_105, 0)) {
							if (!func_82(iLocal_109)) {
								func_19(&iLocal_109);
								gameplay::set_bit(&iLocal_105, 0);
								gameplay::set_bit(&iLocal_105, 8);
								gameplay::set_bit(&iLocal_105, 7);
							}
						}
					}
				}
				else if (gameplay::is_bit_set(iLocal_105, 8)) {
					iVar1 = player::get_players_last_vehicle();
					if (func_82(iVar1)) {
						if (func_18(player::player_ped_id(), iVar1, 10f, 1) &&
							!decorator::decor_exist_on(iVar1, "Getaway_Winched")) {
							iLocal_109 = iVar1;
							entity::set_entity_as_mission_entity(iLocal_109, 1, 1);
							gameplay::set_bit(&iLocal_105, 0);
							gameplay::set_bit(&iLocal_105, 7);
						}
					}
				}
				else {
					gameplay::clear_bit(&iLocal_105, 7);
				}
			}
			else if (func_82(iLocal_109)) {
				if (!func_18(player::player_ped_id(), iLocal_109, 80f, 1)) {
					if (!decorator::decor_exist_on(iLocal_109, "Getaway_Winched")) {
						gameplay::set_bit(&uLocal_101[func_5(5)], 5);
						gameplay::set_bit(&iLocal_105, 8);
					}
					else {
						gameplay::clear_bit(&iLocal_105, 8);
					}
					func_19(&iLocal_109);
					gameplay::clear_bit(&iLocal_105, 0);
					gameplay::clear_bit(&iLocal_105, 7);
				}
				else if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					if (ped::get_vehicle_ped_is_in(player::player_ped_id(), 0) != iLocal_109) {
						func_19(&iLocal_109);
						func_192(17, 46);
						func_192(18, 46);
						func_192(14, 46);
						func_163();
					}
					else if (func_206()) {
						func_19(&iLocal_109);
						func_163();
					}
				}
				else if (!func_195(iLocal_109)) {
					if (decorator::decor_set_bool(iLocal_109, "GetawayVehicleValid", 0)) {
					}
					func_192(17, 46);
					func_192(18, 46);
					func_19(&iLocal_109);
					func_163();
				}
			}
			else {
				func_19(&iLocal_109);
				func_163();
			}
		}
	}
}

// Position - 0xA9B4
int func_195(int iParam0) {
	if (entity::get_entity_health(iParam0) < 300 || vehicle::get_vehicle_engine_health(iParam0) < 300f) {
		func_67(6);
		return 0;
	}
	return 1;
}

// Position - 0xA9E5
bool func_196(int iParam0) {
	if (decorator::decor_exist_on(iParam0, "GetawayVehicleValid")) {
		if (decorator::decor_get_bool(iParam0, "GetawayVehicleValid")) {
			return true;
		}
	}
	return false;
}

// Position - 0xAA0A
int func_197() {
	if (ped::is_ped_in_any_taxi(player::player_ped_id())) {
		if (vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 0, 0) ==
				player::player_ped_id() ||
			vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 1, 0) ==
				player::player_ped_id() ||
			vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_in(player::player_ped_id(), 0), 2, 0) ==
				player::player_ped_id()) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xAA6D
int func_198(int iParam0) {
	if (func_204() && func_200(iParam0) && func_199(iParam0)) {
		return 1;
	}
	return 0;
}

// Position - 0xAA97
int func_199(int iParam0) {
	int iVar0;

	iVar0 = vehicle::get_vehicle_max_number_of_passengers(iParam0);
	if (iVar0 >= 3) {
		return 1;
	}
	func_67(15);
	return 0;
}

// Position - 0xAAB8
int func_200(int iParam0) {
	if (func_202(iParam0) && !func_201(iParam0) && func_195(iParam0)) {
		return 1;
	}
	return 0;
}

// Position - 0xAAE5
int func_201(int iParam0) {
	int iVar0;

	iVar0 = func_60(iParam0);
	if (iVar0 == 0) {
		func_67(25);
		return 1;
	}
	if (iVar0 == 1) {
		func_67(26);
		return 1;
	}
	if (iVar0 == 2) {
		func_67(27);
		return 1;
	}
	if (func_35(iParam0)) {
		func_67(14);
		return 1;
	}
	return 0;
}

// Position - 0xAB39
int func_202(int iParam0) {
	int iVar0;

	iVar0 = entity::get_entity_model(iParam0);
	if (!func_203(iVar0)) {
		if (vehicle::get_vehicle_model_acceleration(iVar0) > 0.165f &&
			vehicle::_get_vehicle_model_max_speed(iVar0) > 31f) {
			return 1;
		}
	}
	func_67(14);
	return 0;
}

// Position - 0xAB7E
int func_203(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iLocal_192[iVar0] == iParam0) {
			if (iVar0 == 0 && !func_242(33)) {
				gameplay::set_bit(&iLocal_105, 3);
			}
			else if (iVar0 == 1 && !func_242(34)) {
				gameplay::set_bit(&iLocal_105, 3);
			}
			else {
				gameplay::clear_bit(&iLocal_105, 3);
			}
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xABEA
int func_204() {
	if (ped::is_ped_in_any_boat(player::player_ped_id()) || ped::is_ped_in_flying_vehicle(player::player_ped_id()) ||
		ped::is_ped_on_mount(player::player_ped_id()) || ped::is_ped_in_any_police_vehicle(player::player_ped_id()) ||
		ped::is_ped_in_any_train(player::player_ped_id())) {
		func_67(14);
		return 0;
	}
	return 1;
}

// Position - 0xAC40
int func_205(int iParam0) {
	if (decorator::decor_exist_on(iParam0, "GetawayVehicleValid")) {
		return 1;
	}
	return 0;
}

// Position - 0xAC59
bool func_206() {
	int iVar0;

	if (func_207(&iVar0)) {
		if (!decorator::decor_exist_on(iVar0, "Getaway_Winched")) {
			decorator::decor_set_bool(iVar0, "Getaway_Winched", 1);
			func_67(16);
			return true;
		}
		else if (decorator::decor_get_bool(iVar0, "Getaway_Winched")) {
			return false;
		}
	}
	return false;
}

// Position - 0xACA3
bool func_207(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (func_235(player::player_ped_id()) && ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
		iVar0 = player::get_players_last_vehicle();
		if (func_82(iVar0)) {
			iVar1 = entity::get_entity_model(iVar0);
			if (iVar1 == joaat("cargobob") || iVar1 == joaat("cargobob2") || iVar1 == joaat("cargobob3")) {
				if (vehicle::does_cargobob_have_pick_up_rope(iVar0)) {
					iVar2 = vehicle::get_vehicle_attached_to_cargobob(iVar0);
					if (entity::does_entity_exist(iVar2)) {
						*uParam0 = entity::get_vehicle_index_from_entity_index(iVar2);
						if (func_82(*uParam0)) {
							return true;
						}
					}
				}
			}
		}
	}
	return false;
}

// Position - 0xAD34
void func_208() {
	switch (iLocal_203) {
	case 0:
		if (gameplay::is_bit_set(iLocal_105, 0)) {
			if (gameplay::get_game_timer() - iLocal_1266 > 500) {
				sLocal_1263 = zone::get_name_of_zone(entity::get_entity_coords(player::player_ped_id(), 1));
				iLocal_203 = 1;
			}
			else if (iLocal_1266 == -1) {
				iLocal_1266 = gameplay::get_game_timer();
			}
		}
		break;

	case 1:
		if (gameplay::get_game_timer() - Local_204[iLocal_1265 /*261*/].f_259 > 500) {
			if (!gameplay::is_string_null_or_empty(sLocal_1263) &&
				!gameplay::is_string_null_or_empty(Local_204[iLocal_1265 /*261*/][iLocal_1264 /*8*/])) {
				if (gameplay::are_strings_equal(sLocal_1263, Local_204[iLocal_1265 /*261*/][iLocal_1264 /*8*/])) {
					gameplay::set_bit(&Local_204[iLocal_1265 /*261*/].f_258, iLocal_1264);
				}
				else {
					gameplay::clear_bit(&Local_204[iLocal_1265 /*261*/].f_258, iLocal_1264);
				}
			}
			else {
				sLocal_1263 = zone::get_name_of_zone(entity::get_entity_coords(player::player_ped_id(), 1));
			}
			iLocal_1264++;
			if (iLocal_1264 >= Local_204[iLocal_1265 /*261*/].f_257 - 1) {
				iLocal_1264 = 0;
				Local_204[iLocal_1265 /*261*/].f_259 = gameplay::get_game_timer();
				iLocal_1265++;
				if (iLocal_1265 >= 4) {
					iLocal_1265 = 0;
					iLocal_1266 = gameplay::get_game_timer();
					iLocal_203 = 0;
				}
			}
		}
		break;
	}
}

// Position - 0xAE65
void func_209() {
	int *iVar0;
	int iVar1;

	if (Global_35781 == 15 && iLocal_37 != 3 && gameplay::is_bit_set(iLocal_105, 5) && !func_193() &&
			Global_69699 == -1 && !func_219() && !func_81(9) ||
		func_100(35)) {
		func_218();
		func_216();
		switch (iLocal_39) {
		case 0:
			if (gameplay::is_bit_set(iLocal_105, 17)) {
				iVar0 = -1;
				while (iVar0 < 36 - 1) {
					iVar0++;
					if (iVar0 != 46) {
						func_215(uLocal_101[0], &iVar0);
					}
				}
				gameplay::clear_bit(&iLocal_105, 17);
			}
			else {
				iVar0 = 31;
				while (iVar0 < 46 - 1) {
					iVar0++;
					if (iVar0 != 46) {
						func_215(uLocal_101[1], &iVar0);
					}
				}
				gameplay::set_bit(&iLocal_105, 17);
			}
			break;

		case 1:
		case 2:
		case 3:
		case 4: func_210(iLocal_100, 1); break;
		}
	}
	else if (Global_35781 != 15 || Global_35781 != 0 || Global_35781 != 2 || Global_35781 != 4 || Global_35781 != 17 ||
			 func_193() || Global_69699 == -1 || Global_100755) {
		iVar1 = 0;
		if (func_127()) {
			iVar1 = 1;
		}
		else if (Global_100755) {
			iVar1 = 2;
		}
		if (gameplay::is_bit_set(uLocal_101[func_5(iVar1)], iVar1)) {
			func_210(iVar1, 0);
		}
	}
}

// Position - 0xAFF6
void func_210(int iParam0, int iParam1) {
	switch (iLocal_39) {
	case 1:
		if (!ui::is_help_message_being_displayed() && !func_213(func_86()) && !func_212()) {
			func_211(func_3(iParam0), 15000);
			iLocal_39 = 2;
		}
		break;

	case 2:
		if (func_2(func_3(iParam0))) {
			fLocal_104 = 0f;
			iLocal_39 = 3;
		}
		else {
			fLocal_104 += gameplay::get_frame_time();
			if (fLocal_104 >= 20f) {
				iLocal_39 = 4;
			}
			else if (gameplay::is_bit_set(iLocal_105, 15)) {
				func_4(iParam0);
				gameplay::clear_bit(&iLocal_105, 15);
				iLocal_39 = 4;
			}
		}
		break;

	case 3:
		if (!func_2(func_3(iParam0))) {
			if (fLocal_104 >= 7.5f || gameplay::is_bit_set(iLocal_105, 15)) {
				func_4(iParam0);
				gameplay::clear_bit(&iLocal_105, 15);
				iLocal_39 = 4;
			}
			else if (iParam1) {
				iLocal_39 = 0;
			}
			else {
				iLocal_39 = 1;
				fLocal_104 = 0f;
			}
		}
		else {
			fLocal_104 += gameplay::get_frame_time();
		}
		break;

	case 4:
		fLocal_104 = 0f;
		iLocal_39 = 0;
		break;
	}
}

// Position - 0xB106
void func_211(char *sParam0, int iParam1) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 0, 1, iParam1);
}

// Position - 0xB11D
int func_212() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0xB137
int func_213(int iParam0) {
	int iVar0;

	if (func_54(iParam0)) {
		if (func_214(iParam0)) {
			iVar0 = 0;
			while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
				if (G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_3 == 5) {
					return 1;
				}
				iVar0++;
			}
		}
	}
	return 0;
}

// Position - 0xB181
bool func_214(int iParam0) {
	int iVar0;

	if (!func_54(iParam0)) {
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_136) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates[iVar0 /*15*/].f_2, iParam0)) {
			return true;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_764) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_651[iVar0 /*14*/].f_2, iParam0)) {
			return true;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < G_SomeGlobalState.MessageCallStates.f_866) {
		if (gameplay::is_bit_set(G_SomeGlobalState.MessageCallStates.f_765[iVar0 /*10*/].f_2, iParam0)) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0xB238
void func_215(int iParam0, int *iParam1) {
	int iVar0;

	iVar0 = func_6(*iParam1);
	if (gameplay::is_bit_set(iParam0, iVar0)) {
		if (!gameplay::is_bit_set(iLocal_105, 3)) {
			iLocal_100 = *iParam1;
			iLocal_39 = 1;
			fLocal_104 = 0f;
			func_4(44);
			func_4(45);
			iLocal_1269 = gameplay::get_game_timer();
			*iParam1 = 46;
		}
		else if (14 == iVar0) {
			func_4(iVar0);
			*iParam1 = 46;
		}
		else {
			iLocal_100 = *iParam1;
			iLocal_39 = 1;
			fLocal_104 = 0f;
			*iParam1 = 46;
		}
	}
}

// Position - 0xB2AA
void func_216() {
	if (iLocal_37 == 0 || iLocal_37 == 1) {
		switch (iLocal_38) {
		case 0:
			if (func_217(func_3(3), 0, 0)) {
				gameplay::set_bit(&iLocal_105, 15);
				ui::clear_help(1);
			}
			if (player::get_player_wanted_level(player::player_id()) > 0) {
				if (!func_2(func_3(7)) && !func_2(func_3(8)) && !func_2(func_3(10)) && !func_2(func_3(11)) &&
					!func_2(func_3(12)) && !func_2(func_3(13)) && !func_127() && !Global_100342) {
					gameplay::set_bit(&iLocal_105, 15);
					ui::clear_help(1);
				}
				iLocal_38 = 1;
			}
			break;

		case 1:
			if (gameplay::is_bit_set(iLocal_105, 0)) {
				if (iLocal_42 == 2) {
					if (iLocal_37 == 1) {
						if (func_82(iLocal_109)) {
							func_67(3);
							func_1(3, 1);
						}
					}
					iLocal_38 = 2;
				}
				else {
					if (func_82(iLocal_109)) {
						func_67(3);
						func_1(3, 1);
					}
					iLocal_38 = 2;
				}
			}
			else {
				iLocal_38 = 2;
			}
			break;

		case 2:
			if (player::get_player_wanted_level(player::player_id()) == 0) {
				if (func_2(func_3(3))) {
					gameplay::set_bit(&iLocal_105, 15);
					ui::clear_help(1);
				}
				iLocal_38 = 0;
			}
			break;
		}
	}
}

// Position - 0xB402
bool func_217(char *sParam0, int iParam1, char *sParam2) {
	ui::begin_text_command_is_message_displayed(sParam0);
	if (iParam1 == 1) {
		ui::add_text_component_substring_text_label(sParam2);
	}
	return ui::end_text_command_is_message_displayed();
}

// Position - 0xB420
void func_218() {
	if (!func_100(func_101()) && !func_100(35) && !func_213(func_86()) && !func_212() && !func_112()) {
		if (iLocal_1270 < 2 && gameplay::get_game_timer() - iLocal_1269 > 480000) {
			if (iLocal_42 != 2) {
				func_67(44);
			}
			else {
				func_67(45);
			}
			iLocal_1270++;
		}
	}
}

// Position - 0xB499
int func_219() {
	if (Global_69962) {
		return 1;
	}
	else if (Global_55816 && !Global_55822) {
		return 1;
	}
	return 0;
}

// Position - 0xB4C3
void func_220() {
	if (func_72()) {
		if (gameplay::is_bit_set(iLocal_105, 2)) {
			if (func_82(iLocal_109)) {
				func_20(iLocal_109, vLocal_110, fLocal_113, 25, 1);
				func_19(&iLocal_109);
			}
			gameplay::clear_bit(&iLocal_105, 2);
		}
		func_1(46, 1);
		func_250(0);
	}
}

// Position - 0xB50D
void func_221() {
	if (!func_226()) {
		if (!func_219()) {
			if (cam::is_screen_faded_in()) {
				if (!cam::is_screen_fading_in()) {
					func_223();
				}
			}
		}
	}
	else if (iLocal_37 != 3) {
		func_222();
	}
}

// Position - 0xB54E
void func_222() {
	if (iLocal_37 != 4) {
		if (iLocal_37 != 2) {
			if (ui::is_help_message_being_displayed() && !Global_100342) {
				gameplay::set_bit(&iLocal_105, 15);
				ui::clear_help(1);
			}
			if (gameplay::is_bit_set(iLocal_105, 0)) {
				if (func_82(iLocal_109)) {
					vehicle::_0x02398B627547189C(iLocal_109, 0);
				}
				func_19(&iLocal_109);
				func_163();
				if (iLocal_42 != 2) {
					vLocal_106 = {0f, 0f, 0f};
				}
				gameplay::clear_bit(&iLocal_105, 8);
			}
		}
		else if (gameplay::is_bit_set(iLocal_105, 0)) {
			func_20(iLocal_109, vLocal_110, fLocal_113, 25, 1);
			if (func_82(iLocal_109)) {
				vehicle::_0x02398B627547189C(iLocal_109, 0);
			}
			func_19(&iLocal_109);
			func_163();
		}
		if (ui::has_this_additional_text_loaded("GETAWY", 5)) {
			ui::clear_additional_text(5, 0);
			gameplay::clear_bit(&iLocal_105, 4);
			gameplay::clear_bit(&iLocal_105, 5);
			func_250(0);
			if (func_127()) {
				func_1(1, 1);
			}
			else {
				func_1(0, 1);
			}
		}
		iLocal_37 = 3;
	}
}

// Position - 0xB62D
void func_223() {
	func_225();
	if (gameplay::is_bit_set(iLocal_105, 4)) {
		if (!gameplay::is_bit_set(iLocal_105, 5) && !gameplay::is_bit_set(iLocal_105, 16)) {
			ui::request_additional_text("GETAWY", 5);
			if (ui::has_this_additional_text_loaded("GETAWY", 5)) {
				gameplay::set_bit(&iLocal_105, 5);
			}
			if (gameplay::is_bit_set(iLocal_105, 5)) {
				func_224();
				iLocal_39 = 0;
				gameplay::clear_bit(&iLocal_105, 7);
				gameplay::clear_bit(&iLocal_105, 0);
				gameplay::clear_bit(&iLocal_105, 1);
				if (func_2(func_3(0))) {
					ui::clear_help(1);
				}
				func_4(0);
				iLocal_37 = Global_101700.f_9008.f_128;
			}
		}
	}
}

// Position - 0xB6C2
void func_224() {
	if (!func_100(func_101())) {
		if (!gameplay::is_bit_set(iLocal_105, 12)) {
			if (func_98()) {
				if (iLocal_42 != 2) {
					func_67(44);
				}
				else {
					func_67(45);
				}
				gameplay::set_bit(&iLocal_105, 12);
			}
		}
	}
}

// Position - 0xB706
void func_225() {
	if (!ui::is_streaming_additional_text(5)) {
		gameplay::set_bit(&iLocal_105, 4);
	}
	else {
		gameplay::clear_bit(&iLocal_105, 4);
	}
}

// Position - 0xB728
int func_226() {
	if (iLocal_42 != 2) {
		if (iLocal_42 == 1 && func_86() == 2) {
			if (!gameplay::is_bit_set(iLocal_105, 16)) {
				gameplay::set_bit(&iLocal_105, 16);
			}
			return 1;
		}
		else if (gameplay::is_bit_set(iLocal_105, 16)) {
			gameplay::clear_bit(&iLocal_105, 16);
		}
		if (func_227()) {
			return 0;
		}
	}
	else if (func_100(35)) {
		return 0;
	}
	else if (func_227()) {
		return 0;
	}
	return 1;
}

// Position - 0xB7A0
bool func_227() {
	if (Global_35781 == 15 && !func_193() && Global_69699 == -1 && !func_127() && !func_191(1112014848) &&
		!Global_100755) {
		return true;
	}
	return false;
}

// Position - 0xB7EE
void func_228() {
	if (!gameplay::is_bit_set(iLocal_105, 13)) {
		if (func_229()) {
			gameplay::set_bit(&iLocal_105, 13);
		}
	}
	else if (!func_229()) {
		gameplay::clear_bit(&iLocal_105, 7);
		gameplay::clear_bit(&iLocal_105, 0);
		gameplay::clear_bit(&iLocal_105, 1);
		gameplay::clear_bit(&iLocal_105, 13);
	}
}

// Position - 0xB839
bool func_229() {
	if (func_230(39) || func_230(40) || func_230(41) || func_230(42) || func_230(43) || func_230(44)) {
		return true;
	}
	return false;
}

// Position - 0xB88B
int func_230(int iParam0) { return func_231(iParam0, 6, 1); }

// Position - 0xB89B
int func_231(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		return gameplay::is_bit_set(Global_91543.f_1308[iParam0], iParam1);
	}
	else if (network::network_is_game_in_progress()) {
		if (func_93() == 0) {
			return gameplay::is_bit_set(func_232(func_234(iParam0), -1, 0), iParam1);
		}
	}
	else {
		return gameplay::is_bit_set(Global_101700.f_668[iParam0], iParam1);
	}
	return 0;
}

// Position - 0xB8FB
int func_232(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_233(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0xB92D
int func_233(var uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0;
	if (iVar0 == -1) {
		iVar1 = func_96();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0xB961
int func_234(int iParam0) {
	switch (iParam0) {
	case 0: return 822;

	case 1: return 823;

	case 2: return 824;

	case 3: return 825;

	case 4: return 826;

	case 5: return 827;

	case 6: return 828;

	case 7: return 829;

	case 8: return 830;

	case 9: return 831;

	case 10: return 832;

	case 11: return 833;

	case 12: return 834;

	case 13: return 835;

	case 14: return 836;

	case 15: return 838;

	case 16: return 839;

	case 17: return 840;

	case 18: return 841;

	case 19: return 842;

	case 20: return 843;

	case 21: return 844;

	case 22: return 845;

	case 23: return 846;

	case 24: return 847;

	case 25: return 848;

	case 26: return 849;

	case 27: return 850;

	case 28: return 851;

	case 29: return 852;

	case 30: return 853;

	case 31: return 854;

	case 32: return 855;

	case 33: return 856;

	case 34: return 857;

	case 35: return 858;

	case 36: return 859;

	case 37: return 860;

	case 38: return 861;

	case 39: return 862;

	case 40: return 866;

	case 41: return 867;

	case 42: return 868;

	case 43: return 869;

	case 44: return 5847;

	case 45: return 3780;

	default: break;
	}
	return 6022;
}

// Position - 0xBC28
bool func_235(int iParam0) {
	if (func_83(iParam0)) {
		if (!ped::is_ped_injured(iParam0)) {
			return true;
		}
	}
	return false;
}

// Position - 0xBC48
int func_236(int iParam0) {
	if (iParam0) {
		if (func_237()) {
			return 1;
		}
	}
	if (func_81(14)) {
		return 1;
	}
	return 0;
}

// Position - 0xBC6E
bool func_237() {
	if (Global_100647) {
		return true;
	}
	if (!func_81(14) && script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
		return true;
	}
	return false;
}

// Position - 0xBCA0
void func_238(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_2(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_241(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_240(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_239();
			return;
		}
		iVar0++;
	}
}

// Position - 0xBD4D
void func_239() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0xBE6D
void func_240(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0xBF05
void func_241(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0xC017
bool func_242(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0xC043
void func_243(int iParam0) {
	iLocal_42 = iParam0;
	if (iLocal_42 == 0) {
		sLocal_1272 = "FBIPRAU";
	}
	else if (iLocal_42 == 1) {
		sLocal_1272 = "AHFAUD";
	}
	else if (iLocal_42 == 2) {
		sLocal_1272 = "FHFAUD";
	}
	iLocal_192[0] = joaat("trash");
	iLocal_192[1] = joaat("towtruck");
	iLocal_192[2] = joaat("ambulance");
	iLocal_192[3] = joaat("barracks2");
	iLocal_192[4] = joaat("stretch");
	iLocal_192[5] = joaat("phantom");
	iLocal_192[6] = joaat("packer");
	iLocal_192[7] = joaat("blazer");
	iLocal_192[8] = joaat("blazer2");
	if (iLocal_42 != 0) {
		iLocal_192[9] = joaat("sentinel2");
	}
	else {
		iLocal_192[9] = 0;
	}
	func_246();
	func_244();
	gameplay::set_bit(&iLocal_105, 17);
	iLocal_1269 = gameplay::get_game_timer();
}

// Position - 0xC109
void func_244() {
	sLocal_53[0] = "AM_H_FBIC1A";
	sLocal_53[1] = "AM_H_FBIC1B";
	sLocal_53[2] = "AM_H_FBIC1C";
	sLocal_53[3] = "PRC_WANT";
	sLocal_53[4] = "PRC_DROPOFF";
	sLocal_53[5] = "PRC_INVALVEH";
	sLocal_53[6] = "PRC_HEALTH";
	sLocal_53[7] = func_245(7);
	sLocal_53[8] = func_245(8);
	sLocal_53[9] = "PRC_USEFIRST";
	sLocal_53[10] = func_245(10);
	sLocal_53[11] = func_245(11);
	sLocal_53[13] = func_245(13);
	sLocal_53[12] = func_245(12);
	sLocal_53[14] = "PRC_UNUSE";
	sLocal_53[15] = "PRC_SEATS";
	sLocal_53[16] = "PRC_CBOBVAL";
	sLocal_53[17] = func_245(17);
	sLocal_53[18] = func_245(18);
	sLocal_53[20] = func_245(20);
	sLocal_53[21] = "PRC_PUBAREA";
	sLocal_53[22] = "PRC_LAWAREA";
	sLocal_53[23] = "PRC_RESAREA";
	sLocal_53[24] = "PRC_STOP";
	sLocal_53[25] = "PRC_OWNEDM";
	sLocal_53[26] = "PRC_OWNEDF";
	sLocal_53[27] = "PRC_OWNEDT";
	sLocal_53[28] = "PRC_SECROUTE";
	sLocal_53[29] = "PRC_CLOSELOT";
	sLocal_53[30] = "PRC_CLOSELES";
	sLocal_53[31] = "PRC_CLSAGNT";
	sLocal_53[32] = "PRC_CLOSESAFE_M";
	sLocal_53[33] = "PRC_CLOSESAFE_F";
	sLocal_53[34] = "PRC_CLOSESAFE_T";
	sLocal_53[35] = "PRC_PEDS";
	sLocal_53[36] = "PRC_WATER";
	sLocal_53[37] = "PRC_OBST";
	sLocal_53[38] = "PRC_OBSTVEH";
	sLocal_53[39] = "PRC_UPDWN";
	sLocal_53[40] = "PRC_NEARROAD";
	sLocal_53[41] = "PRC_ONROAD";
	sLocal_53[19] = "PRC_PLAN";
	sLocal_53[42] = "PRC_TOOSTEEP";
	sLocal_53[43] = "PRC_UNEVEN";
	sLocal_53[44] = "PRC_REMIND";
	sLocal_53[45] = "PRC_REMINDA";
}

// Position - 0xC2E6
char *func_245(int iParam0) {
	char *sVar0;

	if (iLocal_42 == 0) {
		if (iParam0 == 17) {
			sVar0 = "PRC_USEFT";
		}
		else if (iParam0 == 18) {
			sVar0 = "PRC_USEM";
		}
		else if (iParam0 == 10) {
			sVar0 = "PRC_PICKCARTF";
		}
		else if (iParam0 == 11) {
			sVar0 = "PRC_PICKCARM";
		}
		else if (iParam0 == 13) {
			sVar0 = "PRC_PICKNEWM";
		}
		else if (iParam0 == 12) {
			sVar0 = "PRC_PICKNEWTF";
		}
		else if (iParam0 == 7) {
			sVar0 = "PRC_LOCSUITFT";
		}
		else if (iParam0 == 8) {
			sVar0 = "PRC_LOCSUITM";
		}
		else if (iParam0 == 20) {
			sVar0 = "PRC_INACC";
		}
	}
	else if (iLocal_42 == 1) {
		if (iParam0 == 17) {
			sVar0 = "PRC_USEFL";
		}
		else if (iParam0 == 18) {
			sVar0 = "PRC_USEML";
		}
		else if (iParam0 == 10) {
			sVar0 = "PRC_PICKCRFL";
		}
		else if (iParam0 == 11) {
			sVar0 = "PRC_PICKCRML";
		}
		else if (iParam0 == 13) {
			sVar0 = "PRC_PICKNEWML";
		}
		else if (iParam0 == 12) {
			sVar0 = "PRC_PICKNEWFL";
		}
		else if (iParam0 == 7) {
			sVar0 = "PRC_LOCSUITFL";
		}
		else if (iParam0 == 8) {
			sVar0 = "PRC_LOCSUITML";
		}
		else if (iParam0 == 20) {
			sVar0 = "PRC_INACCF";
		}
	}
	else if (iLocal_42 == 2) {
		if (iParam0 == 17) {
			sVar0 = "PRC_USEL";
		}
		else if (iParam0 == 18) {
			sVar0 = "PRC_USEL";
		}
		else if (iParam0 == 10) {
			sVar0 = "PRC_PICKCARL";
		}
		else if (iParam0 == 11) {
			sVar0 = "PRC_PICKCARL";
		}
		else if (iParam0 == 13) {
			sVar0 = "PRC_PICKNEWL";
		}
		else if (iParam0 == 12) {
			sVar0 = "PRC_PICKNEWL";
		}
		else if (iParam0 == 7) {
			sVar0 = "PRC_LOCSUITFT";
		}
		else if (iParam0 == 8) {
			sVar0 = "PRC_LOCSUITM";
		}
		else if (iParam0 == 20) {
			sVar0 = "PRC_INACCF";
		}
	}
	return sVar0;
}

// Position - 0xC4AC
void func_246() {
	sLocal_1249[0] = "ARMYB";
	sLocal_1249[1] = "AIRP";
	sLocal_1249[2] = "STAD";
	sLocal_1249[3] = "TERMINA";
	sLocal_1249[4] = "MOVIE";
	sLocal_1249[5] = "JAIL";
	sLocal_1249[6] = "OCEANA";
	sLocal_1249[7] = "GOLF";
	sLocal_1249[8] = "HORS";
	sLocal_1249[9] = "MTCHIL";
	sLocal_1249[10] = "MTGORDO";
	sLocal_1249[11] = "SANCHIA";
	sLocal_1249[12] = "TATAMO";
	Local_204[0 /*261*/][0 /*8*/] = {
		func_247("DELBE", -1615.257f, -952.5944f, 20.01716f, -2160.706f, -423f, -1.28679f, 327.8f)};
	Local_204[0 /*261*/][1 /*8*/] = {
		func_247("DELBE", -1521.716f, -914.5676f, 20.17247f, -1855.715f, -1325.784f, -44.79295f, 254.8f)};
	Local_204[0 /*261*/][2 /*8*/] = {
		func_247("BEACH", -1162.37f, -1815.008f, 15.33822f, -1553.207f, -1098.685f, 0.46467f, 253.91f)};
	Local_204[0 /*261*/][3 /*8*/] = {
		func_247("BEACH", -1464.219f, -1136.783f, 0.32167f, -2241.566f, -358.8849f, 20.32481f, 282.21f)};
	Local_204[0 /*261*/][4 /*8*/] = {
		func_247("PBOX", 156.4109f, -1042.641f, 22.31273f, 238.6382f, -821.1217f, 35.10069f, 176.96f)};
	Local_204[0 /*261*/][5 /*8*/] = {
		func_247("CHIL", 883.1121f, 534.7283f, 115.725f, 559.7425f, 644.602f, 150.5971f, 301.08f)};
	Local_204[0 /*261*/][6 /*8*/] = {
		func_247("EAST_V", 941.4531f, -329.4256f, 60.77003f, 727.7651f, -200.9519f, 75.59085f, 88.89f)};
	Local_204[0 /*261*/][7 /*8*/] = {
		func_247("EAST_V", 689.1177f, -273.1406f, 60.21559f, 834.7326f, -352.1655f, 50.92442f, 81.23f)};
	Local_204[0 /*261*/][8 /*8*/] = {
		func_247("MIRR", 1048.499f, -357.0332f, 60.92149f, 1401.581f, -783.8975f, 75.7477f, 325.93f)};
	Local_204[0 /*261*/][9 /*8*/] = {
		func_247("MIRR", 892.2836f, -461.5752f, 70.86029f, 1161.301f, -829.8299f, 45.90131f, 184.12f)};
	Local_204[0 /*261*/][10 /*8*/] = {
		func_247("VCANA", -1161.361f, -1143.716f, -5.71593f, -864.9714f, -981.1257f, 21.09691f, 328.65f)};
	Local_204[0 /*261*/][11 /*8*/] = {
		func_247("BAYTRE", 251.4011f, 1068.347f, 280.6663f, 189.6012f, 1272.352f, 143.8035f, 160.32f)};
	Local_204[0 /*261*/][13 /*8*/] = {
		func_247("OBSERV", -450.9835f, 1048.408f, 252.945f, -389.564f, 1244.504f, 370.2469f, 199.93f)};
	Local_204[0 /*261*/][14 /*8*/] = {func_247("AIRP", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][15 /*8*/] = {func_247("TERMINA", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][16 /*8*/] = {func_247("STAD", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][17 /*8*/] = {func_247("MOVIE", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][18 /*8*/] = {func_247("GOLF", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][19 /*8*/] = {func_247("HORS", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[0 /*261*/][20 /*8*/] = {
		func_247("PBOX", -28.39781f, -1071.245f, 50.21438f, -49.8352f, -1131.277f, 20.02555f, 55.12f)};
	Local_204[0 /*261*/][21 /*8*/] = {
		func_247("LOSSF", 843.1962f, 25.93548f, 65.16061f, 1138.687f, 363.0587f, 105.4128f, 61.11f)};
	Local_204[0 /*261*/][22 /*8*/] = {
		func_247("ROCKF", -992.5638f, -199.7673f, 30.74956f, -687.9904f, -43.23445f, 80.93306f, 80.53f)};
	Local_204[0 /*261*/][23 /*8*/] = {
		func_247("ROCKF", -251.8548f, -446.2141f, 29.5887f, -362.685f, -434.7425f, 90.931f, 50f)};
	Local_204[0 /*261*/][24 /*8*/] = {
		func_247("ALTA", 180.2637f, -404.9771f, 40.1713f, 289.9432f, -445.1485f, 124.3793f, 100f)};
	Local_204[0 /*261*/][25 /*8*/] = {
		func_247("ALTA", 343.8481f, -323.1273f, 80.7749f, 427.08f, -361.0469f, 45.3411f, 85f)};
	Local_204[0 /*261*/][26 /*8*/] = {
		func_247("RANCHO", 414.5057f, -2092.1f, 19.8533f, 350.8093f, -2158.395f, 12.3916f, 55f)};
	Local_204[0 /*261*/][27 /*8*/] = {
		func_247("RANCHO", 283.7474f, -2103.918f, 12.9242f, 391.8871f, -1983.204f, 33.0042f, 100f)};
	Local_204[0 /*261*/][28 /*8*/] = {
		func_247("PBOX", 85.038f, -670.3274f, 42.8642f, 227.8234f, -722.2458f, 274f, 175f)};
	Local_204[0 /*261*/][29 /*8*/] = {
		func_247("PBOX", -107.2516f, -906.36f, 28.2051f, -49.9007f, -752.925f, 330f, 125f)};
	Local_204[0 /*261*/][30 /*8*/] = {
		func_247("TEXTI", 456.8563f, -683.8335f, 32.2903f, 457.5504f, -819.4669f, 25.9553f, 14.4f)};
	Local_204[0 /*261*/][31 /*8*/] = {
		func_247("ROCKF", -699.7205f, -227.3646f, 67.818f, -645.1068f, -332.5107f, 30.9132f, 127.1f)};
	Local_204[0 /*261*/].f_260 = 0;
	Local_204[0 /*261*/].f_257 = 32;
	Local_204[2 /*261*/][0 /*8*/] = {
		func_247("PBOX", -25.50944f, -932.3846f, 20.41711f, 119.9406f, -523.4398f, 33.07988f, 363.4f)};
	Local_204[2 /*261*/][1 /*8*/] = {
		func_247("DOWNT", -25.50944f, -932.3846f, 20.41711f, 119.9406f, -523.4398f, 33.07988f, 363.4f)};
	Local_204[2 /*261*/][2 /*8*/] = {
		func_247("COSI", 1426.934f, 1225.115f, 90.76305f, 1429.982f, 1006.831f, 120.6643f, 259.89f)};
	Local_204[2 /*261*/][3 /*8*/] = {
		func_247("COSI", 3503.56f, 3546.403f, 20.18748f, 3513.955f, 3875.795f, 72.94806f, 393.78f)};
	Local_204[2 /*261*/][4 /*8*/] = {
		func_247("SKID", 403.5404f, -864.4694f, 20.33799f, 396.3441f, -1127.325f, 35.49262f, 325.93f)};
	Local_204[2 /*261*/][5 /*8*/] = {func_247("JAIL", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[2 /*261*/][6 /*8*/] = {func_247("ARMYB", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[2 /*261*/].f_260 = 2;
	Local_204[2 /*261*/].f_257 = 7;
	Local_204[1 /*261*/][0 /*8*/] = {
		func_247("PALETO", -422.8618f, 6068.399f, 20.34662f, -282.7452f, 6206.324f, 50.46586f, 196.61f)};
	Local_204[1 /*261*/][1 /*8*/] = {
		func_247("ROCKF", -755.2506f, 147.4266f, 75.41048f, -1079.033f, 169.3806f, 50.46801f, 179.12f)};
	Local_204[1 /*261*/][2 /*8*/] = {
		func_247("ROCKF", -752.3674f, 90.76733f, 65.5171f, -938.798f, -15.91457f, 35.48347f, 205.78f)};
	Local_204[1 /*261*/][3 /*8*/] = {
		func_247("ROCKF", -890.4999f, 431.1449f, 90.29848f, -875.3576f, 232.3266f, 60.20724f, 263.82f)};
	Local_204[1 /*261*/][4 /*8*/] = {
		func_247("ROCKF", -752.3674f, 90.76733f, 65.5171f, -938.798f, -15.91457f, 35.48347f, 205.78f)};
	Local_204[1 /*261*/][5 /*8*/] = {
		func_247("ROCKF", -1198.183f, 638.6367f, 115.1066f, -444.509f, 750.9377f, 198.2971f, 473.88f)};
	Local_204[1 /*261*/][6 /*8*/] = {
		func_247("ROCKF", -844.4075f, 400.9413f, 80.433f, -109.5311f, 420.5014f, 120.2088f, 256.03f)};
	Local_204[1 /*261*/][7 /*8*/] = {
		func_247("ROCKF", -518.6213f, 648.8265f, 130.9352f, -64.0709f, 582.4504f, 215.3084f, 162.72f)};
	Local_204[1 /*261*/][8 /*8*/] = {
		func_247("RICHM", -934.9802f, 349.6101f, 85.77298f, -1432.451f, 269.9804f, 50.7303f, 185.03f)};
	Local_204[1 /*261*/][9 /*8*/] = {
		func_247("RICHM", -1633.813f, -69.53224f, 65.10236f, -1446.823f, 69.71544f, 48.23926f, 214.92f)};
	Local_204[1 /*261*/][10 /*8*/] = {
		func_247("RICHM", -1732.258f, 444.1353f, 130.1258f, -2065.69f, 412.2121f, 98.09863f, 175.17f)};
	Local_204[1 /*261*/][11 /*8*/] = {
		func_247("RICHM", -1618.036f, 50.95197f, 70.95364f, -1396.514f, 221.1004f, 50.84464f, 161.61f)};
	Local_204[1 /*261*/][12 /*8*/] = {
		func_247("RICHM", -1801.285f, 106.8786f, 72.12892f, -1541.74f, 263.3738f, 50.44112f, 155.88f)};
	Local_204[1 /*261*/][13 /*8*/] = {
		func_247("PELUFF", -2208.563f, 146.4101f, 150.9325f, -2350.122f, 486.6066f, 200.5952f, 299.18f)};
	Local_204[1 /*261*/][14 /*8*/] = {
		func_247("PELUFF", -1852.326f, 134.4172f, 70.06226f, -1994.387f, 299.6283f, 100.9652f, 182.04f)};
	Local_204[1 /*261*/][15 /*8*/] = {
		func_247("CHIL", -1982.67f, 505.9648f, 100.9364f, -1918.843f, 713.6382f, 150.7395f, 168.9f)};
	Local_204[1 /*261*/][16 /*8*/] = {
		func_247("CHIL", -1455.751f, 887.3351f, 191.9757f, -1663.207f, 767.3684f, 160.8108f, 239.65f)};
	Local_204[1 /*261*/][17 /*8*/] = {
		func_247("CHIL", -1570.222f, 508.2056f, 140.3884f, -808.9532f, 526.4333f, 90.18556f, 238.43f)};
	Local_204[1 /*261*/][18 /*8*/] = {
		func_247("CHIL", 242.6204f, 583.5905f, 159.4043f, 268.0424f, 827.4494f, 201.6953f, 105.09f)};
	Local_204[1 /*261*/][19 /*8*/] = {
		func_247("CHIL", -21.10285f, 706.8648f, 150.7263f, -210.4382f, 1056.276f, 280.3182f, 290.15f)};
	Local_204[1 /*261*/][20 /*8*/] = {
		func_247("RGLEN", -1837.538f, 774.2984f, 120.5629f, -1765.842f, 831.0044f, 160.3584f, 68.09f)};
	Local_204[1 /*261*/][21 /*8*/] = {
		func_247("DIVINE", -372.0849f, 372.7183f, 100.6043f, 390.2198f, 532.5167f, 180.538f, 305.88f)};
	Local_204[1 /*261*/].f_260 = 1;
	Local_204[1 /*261*/].f_257 = 22;
	Local_204[3 /*261*/][0 /*8*/] = {func_247("MTCHIL", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[3 /*261*/][1 /*8*/] = {func_247("MTGORDO", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[3 /*261*/][2 /*8*/] = {func_247("SANCHIA", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[3 /*261*/][3 /*8*/] = {func_247("TATAMO", 0f, 0f, 0f, 0f, 0f, 0f, 0f)};
	Local_204[3 /*261*/][4 /*8*/] = {
		func_247("ELYSIAN", 531.2397f, -3019.267f, 50f, 530.1656f, -3393.623f, -22.4165f, 210f)};
	Local_204[3 /*261*/][5 /*8*/] = {
		func_247("ELYSIAN", 569.1023f, -2913.018f, 15.891f, 420.8226f, -2912.775f, -15.0372f, 25f)};
	Local_204[3 /*261*/][6 /*8*/] = {
		func_247("ELYSIAN", 495.1012f, -2833.175f, 5.164f, 460.1983f, -2813.528f, 0.4269f, 12f)};
	Local_204[3 /*261*/][7 /*8*/] = {
		func_247("ELYSIAN", 675.2973f, -2747.45f, 4.952f, 689.2358f, -2747.396f, 10.9001f, 4.3f)};
	Local_204[3 /*261*/][8 /*8*/] = {
		func_247("CYPRE", 533.437f, -2693.279f, 17.4952f, 588.6345f, -2693.462f, 5.3007f, 15f)};
	Local_204[3 /*261*/][9 /*8*/] = {
		func_247("CYPRE", 534.9656f, -2699.136f, 4.9004f, 560.1779f, -2662.192f, 9.0007f, 15f)};
	Local_204[3 /*261*/][10 /*8*/] = {
		func_247("CYPRE", 583.903f, -2689.207f, 16.9771f, 549.8469f, -2665.318f, 3.9007f, 17.3f)};
	Local_204[3 /*261*/][11 /*8*/] = {
		func_247("CYPRE", 683.428f, -2635.134f, 9.3367f, 694.4725f, -2679.66f, 4.7815f, 10f)};
	Local_204[3 /*261*/][12 /*8*/] = {
		func_247("CYPRE", 695.2171f, -2694.769f, 5.9815f, 695.5035f, -2679.168f, 4.8365f, 10f)};
	Local_204[3 /*261*/][13 /*8*/] = {
		func_247("CYPRE", 731.7991f, -2659.58f, 4.7713f, 732.5307f, -2678.4f, 10.5065f, 25f)};
	Local_204[3 /*261*/][14 /*8*/] = {
		func_247("ELYSIAN", 86.1885f, -2430.696f, -0.1888f, 119.1515f, -2453.121f, 2.8614f, 13f)};
	Local_204[3 /*261*/][15 /*8*/] = {
		func_247("ELYSIAN", 260.3166f, -2426.777f, 21.2819f, 313.7871f, -2433.656f, 6.5609f, 20.5f)};
	Local_204[3 /*261*/][16 /*8*/] = {
		func_247("ELYSIAN", 260.3166f, -2426.777f, 21.2819f, 313.7871f, -2433.656f, 6.5609f, 20.5f)};
	Local_204[3 /*261*/][17 /*8*/] = {
		func_247("ELYSIAN", 283.1514f, -2456.777f, 19.4609f, 290.2325f, -2403.611f, 4.2465f, 20.5f)};
	Local_204[3 /*261*/][18 /*8*/] = {
		func_247("ELYSIAN", 266.0341f, -2446.724f, 19.4623f, 308.3783f, -2414.544f, 4.5423f, 20.5f)};
	Local_204[3 /*261*/][19 /*8*/] = {
		func_247("ELYSIAN", 303.5269f, -2451.446f, 19.4091f, 270.9798f, -2409.452f, 4.4609f, 20.5f)};
	Local_204[3 /*261*/][20 /*8*/] = {
		func_247("RANCHO", 515.026f, -1653.54f, 37.2615f, 582.571f, -1577.825f, 26.3365f, 100f)};
	Local_204[3 /*261*/][21 /*8*/] = {
		func_247("BURTON", -150.7403f, -419.0541f, 28.6163f, -52.8669f, -453.5552f, 39.4051f, 100f)};
	Local_204[3 /*261*/][22 /*8*/] = {
		func_247("SanAnd", 50.2035f, -470.7132f, 36.9003f, 102.0394f, -322.0089f, 115f, 130f)};
	Local_204[3 /*261*/][23 /*8*/] = {
		func_247("ALTA", 499.1769f, -241.2495f, 47.3462f, 393.5317f, -205.7358f, 79.3132f, 120f)};
	Local_204[3 /*261*/][24 /*8*/] = {
		func_247("DTVINE", 422.3247f, 62.118f, 113.2905f, 478.494f, 43.322f, 83.4541f, 80f)};
	Local_204[3 /*261*/][25 /*8*/] = {
		func_247("DTVINE", 385.4908f, 56.1423f, 159.58f, 332.458f, -87.6805f, 63.3657f, 80f)};
	Local_204[3 /*261*/][26 /*8*/] = {
		func_247("DTVINE", 213.6192f, 90.2228f, 98.9357f, 203.3067f, 61.8088f, 86.9197f, 60f)};
	Local_204[3 /*261*/][27 /*8*/] = {
		func_247("DTVINE", 192.813f, -14.9451f, 85.3158f, 149.2689f, 0.6803f, 67.0343f, 40f)};
	Local_204[3 /*261*/][28 /*8*/] = {
		func_247("WVINE", 16.1659f, 61.8685f, 70.8467f, -17.1751f, 74.3771f, 76.88f, 4.5f)};
	Local_204[3 /*261*/][29 /*8*/] = {
		func_247("WVINE", -86.5425f, 84.8701f, 80.2147f, -50.4826f, 67.7335f, 70.297f, 20f)};
	Local_204[3 /*261*/][30 /*8*/] = {
		func_247("ELGORL", 3449.839f, 5173.981f, 0.0662f, 3412.309f, 5166.89f, 14.8342f, 33.7f)};
	Local_204[3 /*261*/].f_260 = 3;
	Local_204[3 /*261*/].f_257 = 31;
	if (func_235(player::player_ped_id())) {
		sLocal_1263 = zone::get_name_of_zone(entity::get_entity_coords(player::player_ped_id(), 1));
	}
}

// Position - 0xD7E6
struct<8> func_247(char *sParam0, vector3 vParam1, vector3 vParam4, float fParam7) {
	struct<8> Var0;

	Var0 = sParam0;
	Var0.f_1 = {vParam1};
	Var0.f_4 = {vParam4};
	Var0.f_7 = fParam7;
	return Var0;
}

//Position - 0xD811
void func_248(int iParam0, int iParam1)
{
	if (func_82(iLocal_109)) {
		func_19(&iLocal_109);
	}
	if (!iParam1) {
		func_249(iParam0);
	}
	script::terminate_this_thread();
}

// Position - 0xD839
int func_249(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
		return 1;
	}
	return 0;
}

// Position - 0xD893
void func_250(int iParam0) {
	char *sVar0;

	if (iParam0) {
		sVar0 = "PRC_MARK";
		if (iLocal_42 == 2) {
			sVar0 = "PRC_MARKVEH";
			func_258(sVar0);
		}
		else if (iLocal_42 == 0) {
			if (func_86() == 0) {
				func_257(sVar0);
				func_256(sVar0);
			}
			else if (func_86() == 1) {
				func_255(sVar0);
			}
			else {
				func_255(sVar0);
			}
		}
		else if (iLocal_42 == 1) {
			if (func_86() == 0) {
				func_257(sVar0);
				func_258(sVar0);
			}
			else if (func_86() == 1) {
				func_255(sVar0);
				func_258(sVar0);
			}
			else {
				func_255(sVar0);
				func_258(sVar0);
			}
		}
		gameplay::set_bit(&iLocal_105, 11);
	}
	else if (gameplay::is_bit_set(iLocal_105, 11)) {
		func_254();
		func_253();
		func_252();
		func_251();
		gameplay::clear_bit(&iLocal_105, 11);
	}
}

// Position - 0xD960
void func_251() { StringCopy(&Global_2151[3 /*16*/].f_8, "CELL_SFUN_NULL", 32); }

// Position - 0xD976
void func_252() { StringCopy(&Global_2151[2 /*16*/].f_8, "CELL_SFUN_NULL", 32); }

// Position - 0xD98C
void func_253() { StringCopy(&Global_2151[1 /*16*/].f_8, "CELL_SFUN_NULL", 32); }

// Position - 0xD9A2
void func_254() { StringCopy(&Global_2151[0 /*16*/].f_8, "CELL_SFUN_NULL", 32); }

// Position - 0xD9B8
void func_255(char *sParam0) { StringCopy(&Global_2151[0 /*16*/].f_8, sParam0, 32); }

// Position - 0xD9CC
void func_256(char *sParam0) { StringCopy(&Global_2151[2 /*16*/].f_8, sParam0, 32); }

// Position - 0xD9E0
void func_257(char *sParam0) { StringCopy(&Global_2151[1 /*16*/].f_8, sParam0, 32); }

// Position - 0xD9F4
void func_258(char *sParam0) { StringCopy(&Global_2151[3 /*16*/].f_8, sParam0, 32); }

// Position - 0xDA08
void func_259(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8) {
	func_260(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0xDA28
void func_260(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_239();
	}
}

// Position - 0xDBFA
bool func_261(var *uParam0, int iParam1) {
	if (iParam1 == -1) {
		return false;
	}
	if (!func_51(&Global_68531.f_555[0 /*21*/], iParam1)) {
		return false;
	}
	else {
		func_58(&Global_101700.f_31389.f_69[Global_68531.f_555[0 /*21*/].f_14 /*78*/], uParam0);
	}
	return true;
}

// Position - 0xDC45
float func_262(int iParam0) {
	if (iParam0 == -1) {
		return 0f;
	}
	if (!func_51(&Global_68531.f_555[0 /*21*/], iParam0)) {
		return 0f;
	}
	return Global_68531.f_555[0 /*21*/].f_3;
}

// Position - 0xDC7B
Vector3 func_263(int iParam0) {
	if (iParam0 == -1) {
		return 0f, 0f, 0f;
	}
	if (!func_51(&Global_68531.f_555[0 /*21*/], iParam0)) {
		return 0f, 0f, 0f;
	}
	return Global_68531.f_555[0 /*21*/];
}

// Position - 0xDCB5
int func_264(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		return 0;
	}
	gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
	return 1;
}

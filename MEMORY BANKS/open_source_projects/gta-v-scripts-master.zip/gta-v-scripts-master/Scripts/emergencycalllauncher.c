#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
int iLocal_28 = 0;
var uLocal_29 = 0;
var uLocal_30 = 0;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
var uLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int iLocal_44 = 0;
var *uLocal_45 = NULL;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 0;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 0;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 0;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 0;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
var uLocal_90 = 0;
var uLocal_91 = 0;
var uLocal_92 = 0;
var uLocal_93 = 0;
var uLocal_94 = 0;
var uLocal_95 = 0;
var uLocal_96 = 0;
var uLocal_97 = 0;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 0;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 0;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 0;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 0;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 0;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 0;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
struct<6> Local_210 = {
  0, 0, 0, 0, 0, 0
};
int iLocal_216 = 0;
int iLocal_217 = 0;
#pragma endregion //}

void __EntryFunction__() {
  bool bVar0;

  iLocal_2 = 1;
  iLocal_3 = 134;
  iLocal_4 = 134;
  iLocal_5 = 1;
  iLocal_6 = 1;
  iLocal_7 = 1;
  iLocal_8 = 134;
  iLocal_9 = 1;
  iLocal_10 = 12;
  iLocal_11 = 12;
  fLocal_14 = 0.001f;
  iLocal_17 = -1;
  sLocal_20 = "NULL";
  fLocal_21 = 0f;
  fLocal_25 = -0.0375f;
  fLocal_26 = 0.17f;
  iLocal_28 = 3;
  fLocal_31 = 80f;
  fLocal_32 = 140f;
  fLocal_33 = 180f;
  iLocal_39 = 1;
  iLocal_40 = 65;
  iLocal_41 = 49;
  iLocal_42 = 64;
  bVar0 = network::network_is_game_in_progress();
  if (!bVar0) {
    if (player::has_force_cleanup_occurred(34)) {
      script::terminate_this_thread();
    }
  }
  else {
    gameplay::network_set_script_is_safe_for_network_game();
  }
  func_33(&uLocal_45, 1, 0, "EMSDispatch", 0, 1);
  func_32();
  while (true) {
    system::wait(0);
    if (bVar0) {
      if (!network::network_is_game_in_progress()) {
        script::terminate_this_thread();
      }
    }
    func_30();
    if (player::is_player_playing(player::player_id())) {
      switch (iLocal_43) {
      case 0:
        func_7();
        func_3();
        break;

      case 1: func_1(); break;
      }
    }
  }
}

// Position - 0xF2
void func_1() {
  if (Global_25420) {
    func_2(0);
  }
  iLocal_43 = 0;
  iLocal_44 = 0;
}

// Position - 0x10B
void func_2(int iParam0) {
  if (iParam0) {
    Global_25420 = 1;
  }
  else {
    Global_25420 = 0;
  }
}

// Position - 0x123
void func_3() {
  if (func_6()) {
    Local_210 = {func_5()};
    if (script::_get_number_of_instances_of_script_with_name_hash(
            gameplay::get_hash_key(&Local_210)) == 0) {
      func_4();
    }
    else {
      Global_25248 = 1;
    }
  }
  else {
    Global_25248 = 0;
  }
}

// Position - 0x15A
void func_4() {
  if (Global_25413) {
    Global_25413 = 0;
    StringCopy(&Global_25414, "NULL", 24);
  }
}

// Position - 0x176
struct<6> func_5() {
  return Global_25414;
}

//Position - 0x183
bool func_6()
{
  return Global_25413;
}

// Position - 0x18E
void func_7() {
  switch (iLocal_44) {
  case 0:
    if (func_29(130) && func_27(player::player_id()) != 192 &&
        func_27(player::player_id()) != 190 &&
        func_27(player::player_id()) != 191) {
      if (Global_25420) {
        iLocal_217 = 11;
      }
      else {
        iLocal_217 = 2;
      }
      if (!Global_25248) {
        if (func_25()) {
          if (func_8(&uLocal_45, 130, "LOCAUD", "LOC_CALLQ", iLocal_217,
                     "CELL_601", "LOC_CALLA", "LOC_CALLF", "LOC_CALLP", 0, 0, 0,
                     0)) {
            if (!func_6()) {
              script::request_script("emergencycall");
              while (!script::has_script_loaded("emergencycall")) {
                system::wait(0);
              }
              system::start_new_script("emergencycall", 512);
            }
            iLocal_44 = 1;
          }
        }
        else if (func_8(&uLocal_45, 130, "LOCAUD", "LOC_CALLQ", iLocal_217,
                        "CELL_601", "LOC_CALLA", "LOC_CALLF", "LOC_CALLP", 0, 0,
                        0, 0)) {
          if (!func_6()) {
            script::request_script("emergencycall");
            while (!script::has_script_loaded("emergencycall")) {
              system::wait(0);
            }
            system::start_new_script("emergencycall", 512);
          }
          iLocal_44 = 1;
        }
      }
    }
    break;

  case 1:
    if (script::_get_number_of_instances_of_script_with_name_hash(
            joaat("emergencycall")) == 0) {
      if (!func_29(130)) {
        iLocal_43 = 1;
      }
    }
    break;
  }
}

// Position - 0x2C7
bool func_8(var *uParam0, int iParam1, char *sParam2, char *sParam3,
            int iParam4, char *sParam5, char *sParam6, char *sParam7,
            char *sParam8, int iParam9, int iParam10, int iParam11,
            int iParam12) {
  func_24(uParam0, iParam1, sParam2, iParam10, iParam11, 0);
  Global_15793 = 0;
  Global_15752 = 1;
  Global_15759 = 0;
  Global_15754 = 0;
  Global_16736 = 0;
  Global_16738 = 0;
  Global_16742 = 0;
  Global_15750 = 0;
  Global_15797 = 1;
  Global_15799 = 1;
  Global_15759 = 0;
  if (iParam9 == 1) {
    Global_15757 = 1;
  }
  else {
    Global_15757 = 0;
  }
  StringCopy(&Global_15851, sParam6, 24);
  StringCopy(&Global_15857, sParam7, 24);
  StringCopy(&Global_15863, sParam8, 24);
  StringCopy(&Global_15893, sParam5, 24);
  Global_2621441 = 1;
  return func_9(sParam3, iParam4, iParam12);
}

// Position - 0x346
int func_9(char *sParam0, int iParam1, bool bParam2) {
  Global_15746 = 0;
  if (Global_15745 == 0 || Global_15747 == 2) {
    if (Global_15745 != 0) {
      if (iParam1 > Global_15747) {
        if (Global_15752 == 0) {
          audio::stop_scripted_conversation(0);
          Global_14443.f_1 = 3;
          Global_15745 = 0;
          Global_15746 = 1;
          Global_15798 = 0;
          Global_15741 = 0;
          Global_15742 = 0;
          Global_15756 = 0;
          Global_15755 = 0;
          Global_14442 = 0;
        }
        else {
          func_23();
          return 0;
        }
      }
      else {
        return 0;
      }
    }
    if (audio::is_scripted_conversation_ongoing()) {
      return 0;
    }
    if (func_22(8, -1)) {
      return 0;
    }
    Global_15821 = {Global_15815};
    func_21();
    Global_15034 = {Global_15199};
    Global_15751 = Global_15752;
    Global_15758 = Global_15759;
    Global_2621442 = Global_2621441;
    Global_15760 = {Global_15776};
    Global_15753 = Global_15754;
    Global_16735 = Global_16736;
    Global_16743 = {Global_16749};
    Global_16737 = Global_16738;
    Global_16739 = Global_16740;
    Global_16741 = Global_16742;
    Global_15364.f_370 = Global_16734;
    Global_15364.f_368 = Global_16732;
    Global_15364.f_369 = Global_16733;
    Global_15741 = Global_15742;
    if (Global_15751) {
      gameplay::clear_bit(&G_SleepModeOnOn25, 20);
      gameplay::clear_bit(&G_SleepModeOffOn11, 17);
      gameplay::clear_bit(&Global_2315, 0);
      if (bParam2) {
        func_14();
        if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
          if (iParam1 == 13) {
          }
          else {
            return 0;
          }
        }
        if (Global_14443.f_1 > 3) {
          return 0;
        }
      }
      if (Global_14409 == 1) {
        return 0;
      }
      if (player::is_player_playing(player::player_id())) {
        if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
          return 0;
        }
        if (func_13()) {
          return 0;
        }
        if (ai::is_ped_sprinting(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_ragdoll(player::player_ped_id())) {
          return 0;
        }
        if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
          return 0;
        }
        if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(),
                                               joaat("gadget_parachute"))) {
          return 0;
        }
        if (!Global_69702) {
          if (entity::is_entity_in_water(player::player_ped_id())) {
            return 0;
          }
          if (player::is_player_climbing(player::player_id())) {
            return 0;
          }
          if (ped::is_ped_planting_bomb(player::player_ped_id())) {
            return 0;
          }
          if (player::is_special_ability_active(player::player_id())) {
            return 0;
          }
        }
      }
      if (func_12()) {
        return 0;
      }
      else {
        switch (Global_14443.f_1) {
        case 7: return 0;

        case 8: return 0;

        case 9: break;

        case 10: break;

        default: break;
        }
        if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
          return 0;
        }
      }
      func_11();
      Global_15755 = bParam2;
    }
    Global_15747 = iParam1;
    StringCopy(&Global_15364, sParam0, 24);
    Global_14611 = 0;
    func_10();
    return 1;
  }
  if (Global_15745 == 5) {
    return 0;
  }
  if (iParam1 < Global_15747 || iParam1 == Global_15747) {
    return 0;
  }
  if (iParam1 == 2) {
  }
  else {
    func_23();
  }
  return 0;
}

// Position - 0x612
void func_10() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 69) {
    StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
    iVar0++;
  }
  audio::stop_scripted_conversation(0);
  Global_15745 = 1;
}

// Position - 0x643
void func_11() {
  Global_15798 = Global_15797;
  Global_15792 = Global_15793;
  Global_15839 = {Global_15827};
  Global_15845 = {Global_15833};
  Global_15800 = Global_15799;
  Global_15869 = {Global_15851};
  Global_15875 = {Global_15857};
  Global_15881 = {Global_15863};
  Global_15887 = {Global_15893};
  Global_1628 = Global_1629;
  Global_1630 = Global_1631;
  Global_15756 = Global_15757;
  Global_15758 = Global_15759;
  Global_15760 = {Global_15776};
  Global_15749 = Global_15750;
  Global_16761 = 0;
  Global_15794 = 0;
  Global_15795 = 0;
  gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x6D8
bool func_12() {
  if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
    return true;
  }
  return false;
}

// Position - 0x6FF
bool func_13() {
  int iVar0;
  int iVar1;

  if (Global_69702) {
    iVar0 = 0;
    weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
    if (player::is_player_playing(player::player_id())) {
      if (iVar1 == joaat("weapon_sniperrifle") ||
          iVar1 == joaat("weapon_heavysniper") ||
          iVar1 == joaat("weapon_remotesniper")) {
        iVar0 = 1;
      }
    }
    if (cam::is_aim_cam_active() && iVar0 == 1) {
      return true;
    }
    else {
      return false;
    }
  }
  if (player::is_player_playing(player::player_id())) {
    if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
      return true;
    }
    else {
      return false;
    }
  }
  return true;
}

// Position - 0x798
void func_14() {
  if (func_20(14)) {
    if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
      if (entity::get_entity_model(player::player_ped_id()) ==
          Global_101700.f_27009[0 /*29*/]) {
        Global_14443 = 0;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[1 /*29*/]) {
        Global_14443 = 1;
      }
      else if (entity::get_entity_model(player::player_ped_id()) ==
               Global_101700.f_27009[2 /*29*/]) {
        Global_14443 = 2;
      }
      else {
        Global_14443 = 0;
      }
    }
  }
  else {
    Global_14443 = func_15();
    if (Global_14443 == 145) {
      Global_14443 = 3;
    }
    if (Global_69702) {
      Global_14443 = 3;
    }
    if (Global_14443 > 3) {
      Global_14443 = 3;
    }
  }
}

// Position - 0x83A
var func_15() {
  func_16();
  return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x853
void func_16() {
  int iVar0;

  if (entity::does_entity_exist(player::player_ped_id())) {
    if (func_19(Global_101700.f_2095.f_539.f_3549) !=
        entity::get_entity_model(player::player_ped_id())) {
      iVar0 = func_18(player::player_ped_id());
      if (func_17(iVar0) && (!func_20(14) || Global_100652)) {
        if (Global_101700.f_2095.f_539.f_3549 != iVar0 &&
            func_17(Global_101700.f_2095.f_539.f_3549)) {
          Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
        }
        Global_101700.f_2095.f_539.f_3551 = iVar0;
        Global_101700.f_2095.f_539.f_3549 = iVar0;
        return;
      }
    }
    else {
      if (Global_101700.f_2095.f_539.f_3549 != 145) {
        Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
      }
      return;
    }
  }
  Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x950
bool func_17(int iParam0) { return iParam0 < 3; }

// Position - 0x95C
int func_18(int iParam0) {
  int iVar0;
  int iVar1;

  if (entity::does_entity_exist(iParam0)) {
    iVar1 = entity::get_entity_model(iParam0);
    iVar0 = 0;
    while (iVar0 <= 2) {
      if (func_19(iVar0) == iVar1) {
        return iVar0;
      }
      iVar0++;
    }
  }
  return 145;
}

// Position - 0x999
int func_19(int iParam0) {
  if (func_17(iParam0)) {
    return Global_101700.f_27009[iParam0 /*29*/];
  }
  else if (iParam0 != 145) {
  }
  return 0;
}

// Position - 0x9C3
bool func_20(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x9D1
void func_21() {
  int iVar0;

  iVar0 = 0;
  while (iVar0 <= 15) {
    Global_15034[iVar0 /*10*/] = 0;
    StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
    Global_15034[iVar0 /*10*/].f_7 = 0;
    Global_15034[iVar0 /*10*/].f_8 = 0;
    iVar0++;
  }
  Global_15034.f_161 = -99;
  Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0xA28
bool func_22(int iParam0, int iParam1) {
  switch (iParam0) {
  case 5:
    if (iParam1 > -1) {
      return Global_1353070.f_203[iParam1];
    }
    break;
  }
  return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0xA63
void func_23() {
  audio::restart_scripted_conversation();
  Global_16756 = 0;
  if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 ||
      Global_14442 == 1) {
    audio::stop_scripted_conversation(0);
    Global_15745 = 6;
    Global_14443.f_1 = 3;
    return;
  }
  if (audio::is_scripted_conversation_ongoing()) {
    audio::stop_scripted_conversation(1);
    Global_15745 = 6;
    return;
  }
}

// Position - 0xABA
void func_24(var *uParam0, var uParam1, char *sParam2, int iParam3, int iParam4,
             int iParam5) {
  Global_15199 = {*uParam0};
  Global_1629 = uParam1;
  StringCopy(&Global_15815, sParam2, 24);
  Global_16734 = iParam5;
  if (iParam3 == 0) {
    Global_16732 = 1;
    Global_16730 = 0;
  }
  else {
    Global_16732 = 0;
    Global_16730 = 1;
  }
  if (iParam4 == 0) {
    Global_16733 = 1;
    Global_16731 = 0;
  }
  else {
    Global_16733 = 0;
    Global_16731 = 1;
  }
}

// Position - 0xB10
bool func_25() {
  if (Global_2621550) {
    if (func_20(0)) {
      if (Global_3145728 || func_26(0)) {
        return true;
      }
    }
  }
  if (Global_2621549) {
    if (func_20(0)) {
      if (Global_3670016 || func_26(0)) {
        return true;
      }
    }
  }
  return false;
}

// Position - 0xB63
int func_26(int iParam0) {
  if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(
                      joaat("benchmark")) > 0) {
    return 1;
  }
  return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0xB8E
int func_27(int iParam0) {
  if (func_28(iParam0, 0)) {
    return Global_1619421[iParam0 /*390*/].f_11.f_32;
  }
  return -1;
}

// Position - 0xBB1
bool func_28(int iParam0, int iParam1) {
  if (Global_1619421[iParam0 /*390*/].f_11.f_32 != -1 ||
      iParam1 && Global_1619421[iParam0 /*390*/].f_11.f_31 != -1) {
    return true;
  }
  return false;
}

// Position - 0xBEC
int func_29(int iParam0) {
  if (Global_16859 || Global_16858 || Global_16860) {
    if (iParam0 == 130) {
    }
    else {
      return 0;
    }
  }
  if (Global_117[iParam0 /*10*/].f_8 != 140) {
    if (Global_14443.f_1 == 10) {
      if (Global_1628 == iParam0) {
        return 1;
      }
      else {
        return 0;
      }
    }
    else {
      return 0;
    }
  }
  return 0;
}

// Position - 0xC50
void func_30() {
  if (iLocal_216) {
    if (func_6()) {
      func_4();
    }
    else {
      func_31();
    }
    iLocal_216 = 0;
  }
}

// Position - 0xC72
void func_31() {
  Global_25413 = 1;
  StringCopy(&Global_25414, script::get_this_script_name(), 24);
}

// Position - 0xC87
void func_32() {}

// Position - 0xC8F
void func_33(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4,
             int iParam5) {
  if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
  }
  (*uParam0)[iParam1 /*10*/] = iParam2;
  StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
  (*uParam0)[iParam1 /*10*/].f_7 = 1;
  (*uParam0)[iParam1 /*10*/].f_8 = iParam4;
  (*uParam0)[iParam1 /*10*/].f_9 = iParam5;
  if (!Global_69702) {
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
        ped::set_ped_can_play_ambient_anims(iParam2, 0);
      }
      else {
        ped::set_ped_can_play_ambient_anims(iParam2, 1);
      }
    }
    if (!ped::is_ped_injured(iParam2)) {
      if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
      }
      else {
        ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
      }
    }
  }
}

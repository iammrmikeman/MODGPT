#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
float fLocal_12 = 0f;
float fLocal_13 = 0f;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
var uLocal_21 = 0;
var uLocal_22 = 0;
float fLocal_23 = 0f;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
var uLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
int iLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 10;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 2;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 8;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 8;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
float fLocal_90 = 0f;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
float fLocal_94 = 0f;
float fLocal_95 = 0f;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
var uLocal_98 = 0;
var uLocal_99 = 0;
var uLocal_100 = 0;
var uLocal_101 = 0;
var uLocal_102 = 0;
var uLocal_103 = 17;
var uLocal_104 = 0;
var uLocal_105 = 0;
var uLocal_106 = 0;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 17;
var uLocal_122 = 0;
var uLocal_123 = 0;
var uLocal_124 = 0;
var uLocal_125 = 0;
var uLocal_126 = 0;
var uLocal_127 = 0;
var uLocal_128 = 0;
var uLocal_129 = 0;
var uLocal_130 = 0;
var uLocal_131 = 0;
var uLocal_132 = 0;
var uLocal_133 = 0;
var uLocal_134 = 0;
var uLocal_135 = 0;
var uLocal_136 = 0;
var uLocal_137 = 0;
var uLocal_138 = 0;
var uLocal_139 = 0;
var uLocal_140 = 0;
var uLocal_141 = 0;
var uLocal_142 = 0;
var uLocal_143 = 0;
var uLocal_144 = 0;
var uLocal_145 = 12;
var uLocal_146 = 0;
var uLocal_147 = 0;
var uLocal_148 = 0;
var uLocal_149 = 0;
var uLocal_150 = 0;
var uLocal_151 = 0;
var uLocal_152 = 0;
var uLocal_153 = 0;
var uLocal_154 = 0;
var uLocal_155 = 0;
var uLocal_156 = 0;
var uLocal_157 = 0;
var uLocal_158 = 12;
var uLocal_159 = 0;
var uLocal_160 = 0;
var uLocal_161 = 0;
var uLocal_162 = 0;
var uLocal_163 = 0;
var uLocal_164 = 0;
var uLocal_165 = 0;
var uLocal_166 = 0;
var uLocal_167 = 0;
var uLocal_168 = 0;
var uLocal_169 = 0;
var uLocal_170 = 0;
var uLocal_171 = 12;
var uLocal_172 = 0;
var uLocal_173 = 0;
var uLocal_174 = 0;
var uLocal_175 = 0;
var uLocal_176 = 0;
var uLocal_177 = 0;
var uLocal_178 = 0;
var uLocal_179 = 0;
var uLocal_180 = 0;
var uLocal_181 = 0;
var uLocal_182 = 0;
var uLocal_183 = 0;
var uLocal_184 = 9;
var uLocal_185 = 0;
var uLocal_186 = 0;
var uLocal_187 = 0;
var uLocal_188 = 0;
var uLocal_189 = 0;
var uLocal_190 = 0;
var uLocal_191 = 0;
var uLocal_192 = 0;
var uLocal_193 = 0;
var uLocal_194 = 9;
var uLocal_195 = 0;
var uLocal_196 = 0;
var uLocal_197 = 0;
var uLocal_198 = 0;
var uLocal_199 = 0;
var uLocal_200 = 0;
var uLocal_201 = 0;
var uLocal_202 = 0;
var uLocal_203 = 0;
var uLocal_204 = 0;
var uLocal_205 = 0;
var uLocal_206 = 0;
var uLocal_207 = 0;
var uLocal_208 = 0;
var uLocal_209 = 0;
var uLocal_210 = 0;
var uLocal_211 = 0;
int iLocal_212 = 0;
int iLocal_213 = 0;
int iLocal_214 = 0;
int iLocal_215 = 0;
var *uLocal_216 = NULL;
var uLocal_217 = 0;
var *uLocal_218 = NULL;
var uLocal_219 = 0;
int *iLocal_220 = NULL;
var *uLocal_221 = NULL;
var uLocal_222 = 0;
int *iLocal_223 = NULL;
int *iLocal_224 = NULL;
int *iLocal_225 = NULL;
int *iLocal_226 = NULL;
int iLocal_227 = 0;
var *uLocal_228 = NULL;
var uLocal_229 = 0;
float *fLocal_230 = NULL;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_23 = 80f;
	fLocal_24 = 140f;
	fLocal_25 = 180f;
	fLocal_28 = 0f;
	fLocal_32 = -0.0375f;
	fLocal_33 = 0.17f;
	iLocal_36 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_90 = 0.05f + 0.275f - 0.01f;
	fLocal_93 = -0.05f;
	fLocal_94 = 0.92f;
	fLocal_95 = 1.94f;
	fLocal_96 = 2.99f;
	fLocal_97 = 3.7f;
	iLocal_212 = 1;
	if (player::has_force_cleanup_occurred(32)) {
		script::terminate_this_thread();
	}
	gameplay::network_set_script_is_safe_for_network_game();
	func_728(func_729());
	func_727(socialclub::_0x8416FE4E4629D7D7("bIgnoreCheaterOverride"));
	func_726(socialclub::_0x8416FE4E4629D7D7("bIgnoreBadSportOverride"));
	Global_2453585[0] = func_725();
	Global_2453585[1] = func_725();
	Global_2453585[2] = func_725();
	Global_2453585[3] = func_725();
	Global_2453585[4] = func_725();
	while (true) {
		if (Global_2449958 == 0) {
			if (network::_network_are_ros_available()) {
				Global_2449957 = network::_0x67A5589628E0CFF6();
				Global_2449958 = 1;
			}
		}
		func_720();
		func_716();
		func_715();
		func_17();
		func_7();
		if (Global_262145.f_118 == 0) {
			if (Global_2452521 == 0) {
				if (unk_0x53C10C8BD774F2C9()) {
					if (func_5()) {
						func_1(1, 0);
					}
					else {
						network::shutdown_and_launch_single_player_game();
					}
				}
			}
		}
		system::wait(0);
	}
}

// Position - 0x178
void func_1(int iParam0, int iParam1) {
	int iVar0;

	func_3(&Global_17071, iParam1);
	graphics::_0x22A249A53034450A(0);
	iVar0 = 1;
	if (iParam0) {
		if (iVar0 == 1) {
			streaming::stop_player_switch();
			func_2(0);
			if (entity::does_entity_exist(Global_1318015)) {
				if (entity::does_entity_belong_to_this_script(Global_1318015, 0)) {
					if (!entity::is_entity_a_mission_entity(Global_1318015)) {
						entity::set_entity_as_mission_entity(Global_1318015, 0, 0);
					}
					ped::delete_ped(&Global_1318015);
				}
			}
		}
	}
}

// Position - 0x1DD
void func_2(int iParam0) {
	if (iParam0 == 0) {
		Global_2454746 = 0;
	}
	Global_1312466.f_18 = iParam0;
}

// Position - 0x1F8
void func_3(var *uParam0, bool bParam1) {
	uParam0->f_15 = 0;
	uParam0->f_16 = 0;
	uParam0->f_17 = 0;
	uParam0->f_18 = 0;
	uParam0->f_19 = 0;
	uParam0->f_20 = 0;
	if (cam::does_cam_exist(uParam0->f_9)) {
		if (cam::is_cam_active(uParam0->f_9)) {
			func_4(0);
		}
		cam::destroy_cam(uParam0->f_9, 0);
	}
	if (!Global_36878) {
		cam::stop_gameplay_cam_shaking(1);
		cam::custom_menu_coordinates(0f);
		cam::_0x0225778816FDC28C(0f);
	}
	Global_2404994.f_574 = 0f;
	if (!bParam1) {
		cam::render_script_cams(0, 0, 0, 1, 0, 0);
	}
}

// Position - 0x270
void func_4(int iParam0) { Global_17149 = iParam0; }

// Position - 0x27D
bool func_5() {
	if (func_6() == 3 || func_6() == 2) {
		return true;
	}
	return false;
}

// Position - 0x29F
int func_6() { return Global_1312466.f_18; }

// Position - 0x2AD
void func_7() {
	if (func_16() == 0) {
		if (func_15(player::player_id())) {
			if (Global_2452457) {
				if (func_12(&uLocal_218, Global_262145.f_15088, 0)) {
					func_9(7, 0);
					Global_2452457 = 0;
					Global_2452458 = 0;
					func_8(&uLocal_218, 0, 0);
				}
			}
			if (Global_2452458) {
				if (func_12(&uLocal_218, Global_262145.f_15089, 0)) {
					if (network::network_is_activity_session()) {
						stats::_0x5688585E6D563CD8(10);
					}
					func_9(10, 0);
					Global_2452458 = 0;
					Global_2452457 = 0;
					func_8(&uLocal_218, 0, 0);
				}
			}
		}
	}
}

// Position - 0x336
void func_8(var *uParam0, int iParam1, int iParam2) {
	if (network::network_is_game_in_progress() && !iParam1) {
		if (!iParam2) {
			*uParam0 = network::get_network_time();
		}
		else {
			*uParam0 = network::_0x89023FBBF9200E9F();
		}
	}
	else {
		*uParam0 = gameplay::get_game_timer();
	}
	uParam0->f_1 = 1;
}

// Position - 0x373
void func_9(int iParam0, int iParam1) {
	int iVar0;

	if (func_11(iParam0, iParam1)) {
		iVar0 = func_10();
		Global_2452429[iVar0] = iParam0;
	}
}

// Position - 0x396
int func_10() {
	int iVar0;
	int iVar1;

	iVar0 = 9;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (Global_2452429[iVar1] == 0) {
			iVar0 = iVar1;
			iVar1 = 10;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x3CB
bool func_11(int iParam0, var uParam1) {
	if (Global_1315221) {
		return false;
	}
	if (iParam0 == 22) {
		return true;
	}
	if (uParam1 || !Global_1315233 || iParam0 == 3 || iParam0 == 10 || iParam0 == 11 || iParam0 == 27 ||
		iParam0 == 28 || iParam0 == 29 || iParam0 == 30) {
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x451
bool func_12(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_14(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			func_13(uParam0);
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		func_13(uParam0);
		return true;
	}
	return false;
}

// Position - 0x4BB
void func_13(var *uParam0) { uParam0->f_1 = 0; }

// Position - 0x4C8
void func_14(var *uParam0, int iParam1, int iParam2) {
	if (uParam0->f_1 == 0) {
		if (network::network_is_game_in_progress() && !iParam1) {
			if (!iParam2) {
				*uParam0 = network::get_network_time();
			}
			else {
				*uParam0 = network::_0x89023FBBF9200E9F();
			}
		}
		else {
			*uParam0 = gameplay::get_game_timer();
		}
		uParam0->f_1 = 1;
	}
}

// Position - 0x50D
bool func_15(int iParam0) {
	if (iParam0 == -1) {
		return false;
	}
	return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_97, 14);
}

// Position - 0x533
int func_16() { return Global_25190; }

// Position - 0x53E
void func_17() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (player::is_player_online()) {
		if (iLocal_215 == 0) {
			func_713();
			iLocal_215 = 1;
		}
		if (iLocal_212) {
			func_712();
			iLocal_212 = 0;
		}
	}
	if (func_711(0) && func_711(1) || func_711(2)) {
		if (Global_1318049 == 0) {
			iVar0 = 0;
			while (iVar0 <= 1) {
				Global_1312729[iVar0] = func_708(384, iVar0, -1);
				iVar0++;
			}
			Global_1312735 = func_707(joaat("mpply_last_mp_char"));
			if (func_705(2)) {
				func_702();
			}
			func_697();
			func_696();
			Global_1318050 = network::network_player_is_cheater();
			Global_1318051 = network::network_player_is_badsport();
			Global_1318049 = 1;
		}
	}
	func_691();
	func_683();
	func_665(&iLocal_225);
	func_657(func_664());
	func_656();
	func_655();
	func_654();
	func_464();
	func_440();
	func_434();
	func_432();
	func_424(&iLocal_226);
	func_422(&iLocal_220, &uLocal_221, &iLocal_223, &iLocal_224);
	if (func_16() == 0) {
		func_420();
	}
	if (func_16() == 0 && !func_419()) {
		func_403(&uLocal_228, &iLocal_227, &fLocal_230);
		func_368(&uLocal_228, iLocal_227);
	}
	else if (func_367(&uLocal_228)) {
		func_13(&uLocal_228);
	}
	func_364();
	func_352();
	func_232(&Global_2443905.f_3255.f_7, &Global_2443905.f_3255.f_12, &Global_2443905.f_3255.f_15);
	if (func_231(player::player_id()) || !func_230()) {
		ui::hide_hud_and_radar_this_frame();
		ui::hide_scripted_hud_component_this_frame(19);
		ui::hide_hud_component_this_frame(18);
	}
	if (Global_2494199.f_4262) {
		if (!func_419()) {
			if (func_229(player::player_id(), 1, 1)) {
				func_213(player::player_id(), 116);
			}
		}
	}
	if (func_367(&Global_1840922) || Global_1840922.f_3) {
		if (Global_1840922.f_2 + 5 < gameplay::get_frame_count() && Global_1840922.f_2 > 0) {
			func_13(&Global_1840922);
			func_13(&Global_1840922.f_49);
			Global_1840922.f_2 = 0;
			func_212(0);
		}
	}
	if (!func_210(player::player_id(), 0)) {
		if (func_209()) {
			if (func_208() == 4) {
				if (func_207()) {
					if (!func_206()) {
					}
					else {
						func_205();
						func_204(0);
						if (func_203()) {
							func_202();
						}
					}
				}
			}
		}
		if (func_201()) {
			iVar1 = func_208();
			if (iVar1 == 4 || iVar1 == 5 || iVar1 == 6 || iVar1 == 7 || iVar1 == 8) {
				if (iVar1 == 4) {
					if (!func_200()) {
						func_199();
						if (!func_198()) {
							func_197(0);
						}
					}
				}
				if (func_196() || func_195() && !func_193(player::player_id()) || func_190(1)) {
					iVar2 = 1;
				}
				iVar1 = func_98(iVar2, 1);
				if (iVar1 == 8) {
					func_197(0);
				}
				else {
					func_197(1);
				}
			}
			else if (iVar1 == 0 || iVar1 == 8) {
				func_97();
			}
		}
		else if (!func_195()) {
			if (!Global_1757074.f_43) {
				iVar3 = func_208();
				if (iVar3 == 4) {
					func_205();
				}
			}
		}
	}
	if (Global_1757074.f_50) {
		func_95();
		func_94(0);
		Global_1757074.f_50 = 0;
	}
	if (Global_1757074.f_51) {
		func_93();
		func_94(0);
		Global_1757074.f_51 = 0;
	}
	if (func_92() && func_91() && Global_2453942) {
		func_28();
		func_94(0);
	}
	func_22();
	func_19();
	if (Global_1354542.f_1) {
		func_18();
	}
}

// Position - 0x8C4
int func_18() {
	char *sVar0;

	sVar0 = "TimersHUD";
	if (script::does_script_exist(sVar0)) {
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("timershud")) <= 0) {
			script::request_script(sVar0);
			if (script::has_script_loaded(sVar0)) {
				system::start_new_script(sVar0, 4600);
				script::set_script_as_no_longer_needed(sVar0);
				return 1;
			}
			return 1;
		}
	}
	return 0;
}

// Position - 0x915
void func_19() {
	bool bVar0;
	int iVar1;

	if (Global_1741482) {
		iVar1 = 0;
		while (iVar1 <= 31) {
			bVar0 = false;
			if (func_21(&Global_1741482.f_34[iVar1 /*8*/]) == 0) {
				if (func_12(&uLocal_216, 4000, 0)) {
					bVar0 = true;
				}
			}
			if (Global_1591201[player::player_id() /*602*/].f_35 || Global_2443905.f_2842.f_41) {
				bVar0 = true;
			}
			if (bVar0) {
				StringCopy(&Global_1741482.f_34[iVar1 /*8*/], "", 32);
				func_20(&Global_1741482.f_356[iVar1], &Global_1741482.f_389[iVar1], &Global_1741482.f_422[iVar1]);
			}
			iVar1++;
		}
	}
}

// Position - 0x9B7
void func_20(int *iParam0, int *iParam1, int *iParam2) {
	if (*iParam0 != -1) {
		if (ui::is_mp_gamer_tag_active(*iParam0)) {
			ui::set_mp_gamer_tag_visibility(*iParam0, 0, 0);
			ui::remove_mp_gamer_tag(*iParam0);
			*iParam1 = 0;
			*iParam2 = 0;
			*iParam0 = -1;
		}
	}
}

// Position - 0x9EC
int func_21(char *sParam0) {
	if (gameplay::is_string_null(sParam0)) {
		return 1;
	}
	else if (gameplay::are_strings_equal(sParam0, "") || gameplay::are_strings_equal(sParam0, "0")) {
		return 1;
	}
	return 0;
}

// Position - 0xA24
void func_22() {
	int iVar0;
	int iVar1;

	if (ui::_0x6E0EB3EB47C8D7AA()) {
		iVar0 = 0;
		if (Global_1741482) {
			iVar1 = 0;
			while (iVar1 <= 31) {
				if (func_21(&Global_1741482.f_34[iVar1 /*8*/]) == 0) {
					iVar0++;
					func_26(&Global_1741482.f_356[iVar1], &Global_1741482.f_389[iVar1], &Global_1741482.f_422[iVar1],
							Global_1741482.f_1[iVar1], -1, &Global_1741482.f_34[iVar1 /*8*/], 10);
					if (!ped::is_ped_injured(Global_1741482.f_1[iVar1])) {
						if (network::network_has_control_of_entity(Global_1741482.f_1[iVar1])) {
							ped::_0x4668D80430D6C299(Global_1741482.f_1[iVar1]);
						}
					}
					func_23(&Global_1741482.f_1[iVar1]);
				}
				iVar1++;
			}
		}
		if (iVar0 == 0) {
			Global_1741482 = 0;
		}
	}
}

// Position - 0xAEF
void func_23(var *uParam0) {
	int iVar0;
	vector3 vVar1;

	if (func_25() == 0) {
		return;
	}
	if (!ped::is_ped_injured(*uParam0)) {
		if (network::network_has_control_of_entity(*uParam0)) {
		}
		if (ped::is_ped_in_any_heli(*uParam0)) {
			iVar0 = ped::get_vehicle_ped_is_in(*uParam0, 0);
			if (func_24(uParam0)) {
				if (network::network_has_control_of_entity(iVar0)) {
					vVar1 = {entity::get_entity_coords(iVar0, 1)};
					if (ai::get_script_task_status(*uParam0, -1273030092) != 1 &&
						ai::get_script_task_status(*uParam0, -1273030092) != 0) {
						ped::set_blocking_of_non_temporary_events(*uParam0, 1);
						ped::set_ped_combat_attributes(*uParam0, 1, 1);
						ai::task_vehicle_mission_coors_target(*uParam0, iVar0, vVar1, 19, 30f, 262144, -1f, -1f, 1);
					}
					ped::set_ped_keep_task(*uParam0, 1);
				}
			}
		}
		else if (ped::is_ped_in_any_plane(*uParam0)) {
		}
	}
}

// Position - 0xBAD
bool func_24(var *uParam0) {
	if (ped::is_ped_in_any_vehicle(*uParam0, 0)) {
		if (vehicle::get_ped_in_vehicle_seat(ped::get_vehicle_ped_is_using(*uParam0), -1, 0) == *uParam0) {
			return true;
		}
	}
	return false;
}

// Position - 0xBD8
int func_25() { return Global_2453811; }

// Position - 0xBE4
int func_26(var *uParam0, int *iParam1, int *iParam2, int iParam3, int iParam4, char *sParam5, int iParam6) {
	if (ped::is_ped_injured(iParam3)) {
		if (*iParam1 == 1) {
			if (ui::is_mp_gamer_tag_active(*uParam0)) {
				ui::set_mp_gamer_tag_visibility(*uParam0, 0, 0);
			}
			*iParam1 = 0;
		}
		return 0;
	}
	if (*iParam2 == 0) {
		*uParam0 = -1;
		*iParam2 = 1;
	}
	if (*uParam0 < 0) {
		if (gameplay::is_string_null(sParam5)) {
			*uParam0 = ui::_create_mp_gamer_tag(iParam3, "", 0, 0, "", 0);
		}
		else {
			*uParam0 = ui::_create_mp_gamer_tag(iParam3, sParam5, 0, 0, "", 0);
		}
	}
	else if (ui::is_mp_gamer_tag_active(*uParam0)) {
		if (!entity::is_entity_occluded(iParam3)) {
			if (*iParam1 == 0) {
				ui::set_mp_gamer_tag_visibility(*uParam0, 0, 1);
				if (iParam4 != -1 && iParam6 == 1) {
					ui::set_mp_gamer_tag_colour(*uParam0, 0, func_27(iParam4));
					ui::set_mp_gamer_tag_colour(*uParam0, 11, func_27(iParam4));
				}
				else {
					ui::set_mp_gamer_tag_colour(*uParam0, 0, iParam6);
					ui::set_mp_gamer_tag_colour(*uParam0, 11, iParam6);
				}
				*iParam1 = 1;
				return 1;
			}
			else {
				return 1;
			}
		}
		else if (*iParam1 == 1) {
			ui::set_mp_gamer_tag_visibility(*uParam0, 0, 0);
			*iParam1 = 0;
			return 1;
		}
		else {
			return 1;
		}
	}
	return 0;
}

// Position - 0xCFA
int func_27(int iParam0) {
	if (iParam0 == 0) {
	}
	return 116;
}

// Position - 0xD0A
void func_28() {
	int iVar0;
	struct<6> Var1;
	int iVar7;

	if (Global_262145.f_8755) {
		if (func_92()) {
			func_94(0);
		}
		return;
	}
	iVar0 = func_88();
	iVar7 = Global_262145.f_8766;
	if (iVar0 >= Global_262145.f_8763) {
		stats::_0xF4FF020A08BC8863(gameplay::get_hash_key(&Var1), 2);
		if (iVar7 == 0 || iVar7 == 2) {
			if (Global_262145.f_8764) {
				func_87(5403, 0, -1, 1, 0);
				func_86();
			}
			else {
				Var1 = {func_85()};
				func_82(gameplay::get_hash_key(&Var1), 1, 0, 0);
				func_75(1);
				func_74(gameplay::get_hash_key(&Var1));
				func_29();
			}
		}
	}
}

// Position - 0xDA7
int func_29() {
	int iVar0;

	if (!func_73()) {
		return 0;
	}
	Global_1751531.f_1752 = 0;
	Global_2443905.f_5878 = 1;
	func_71(22);
	StringCopy(&Global_1614213[player::network_player_id_to_int() /*77*/].f_18, "", 24);
	Global_1614213[player::network_player_id_to_int() /*77*/].f_13 = -1;
	Global_1614213[player::network_player_id_to_int() /*77*/].f_8 = -1;
	Global_1614213[player::network_player_id_to_int() /*77*/].f_10 = 0;
	Global_1614213[player::network_player_id_to_int() /*77*/].f_9 = -1;
	Global_1614213[player::network_player_id_to_int() /*77*/].f_12 = 0;
	Global_1614213[player::network_player_id_to_int() /*77*/].f_74 = 0;
	iVar0 = 0;
	while (iVar0 <= 6) {
		StringCopy(&Global_1614213[player::network_player_id_to_int() /*77*/].f_24[iVar0 /*7*/], "", 24);
		Global_1614213[player::network_player_id_to_int() /*77*/][iVar0] = -1;
		Global_1751531.f_1720[iVar0] = -1;
		iVar0++;
	}
	func_65();
	func_64();
	func_44();
	func_30();
	return 1;
}

// Position - 0xE83
void func_30() {
	int iVar0;
	int iVar1;

	if (!func_42()) {
		return;
	}
	if (func_41() != 10) {
		return;
	}
	iVar0 = func_39(5570, -1, 0);
	iVar1 = func_33(iVar0);
	if (iVar1 != func_32()) {
		return;
	}
	iVar0 = func_31(iVar0);
	func_87(5570, iVar0, -1, 1, 0);
}

// Position - 0xED5
int func_31(int iParam0) {
	int iVar0;

	if (iParam0 == -1) {
		return 0;
	}
	iVar0 = iParam0 + 1;
	if (iVar0 >= 5) {
		iVar0 = 0;
	}
	return iVar0;
}

// Position - 0xEF8
int func_32() { return Global_2404557.f_2; }

// Position - 0xF06
int func_33(int iParam0) {
	switch (iParam0) {
	case 0: return func_38();

	case 1: return func_37();

	case 2: return func_36();

	case 3: return func_35();

	case 4: return func_34();

	default:
	}
	return 0;
}

// Position - 0xF57
var func_34() { return Global_262145.f_7448; }

// Position - 0xF66
var func_35() { return Global_262145.f_7442; }

// Position - 0xF75
var func_36() { return Global_262145.f_7436; }

// Position - 0xF84
var func_37() { return Global_262145.f_7429; }

// Position - 0xF93
var func_38() { return Global_262145.f_7424; }

// Position - 0xFA2
int func_39(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	var uVar1;

	if (iParam2 == 0) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_40(iParam1)];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0xFD4
int func_40(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	if (iVar0 == -1) {
		iVar1 = func_664();
		if (iVar1 > -1) {
			Global_2503539 = 0;
			iVar0 = iVar1;
		}
		else {
			iVar0 = 0;
			Global_2503539 = 1;
		}
	}
	return iVar0;
}

// Position - 0x1008
int func_41() { return Global_2404557; }

// Position - 0x1014
int func_42() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = Global_1363267[func_40(-1)];
	iVar0 = gameplay::is_bit_set(iVar1, 9);
	if (iVar0 != func_43(player::player_id())) {
	}
	return iVar0;
}

// Position - 0x1045
int func_43(var uParam0) {
	int iVar0;

	iVar0 = uParam0;
	if (iVar0 > -1) {
		return gameplay::is_bit_set(Global_1591201[iVar0 /*602*/].f_139, 21);
	}
	return 0;
}

// Position - 0x106C
void func_44() {
	func_60(func_32());
	func_56(func_32());
	func_54();
	func_51(func_32());
	func_49();
	func_46(func_32());
	func_45();
	if (gameplay::is_bit_set(Global_2404954, 24)) {
		gameplay::clear_bit(&Global_2404954, 24);
	}
}

// Position - 0x10B7
void func_45() {
	if (Global_2404954 == Global_2404954.f_1) {
		return;
	}
	func_87(5569, Global_2404954, -1, 1, 0);
	Global_2404954.f_1 = Global_2404954;
}

// Position - 0x10E7
void func_46(int iParam0) {
	if (gameplay::is_bit_set(Global_2404954, 20)) {
		return;
	}
	if (func_48(iParam0)) {
		if (func_47(iParam0, 1) == 0) {
			gameplay::set_bit(&Global_2404954, 20);
			Global_2404967.f_4 = 0;
			Global_2404967.f_5 = 0;
			Global_2404967.f_6 = 0;
		}
		return;
	}
}

// Position - 0x1135
int func_47(int iParam0, int iParam1) {
	int iVar0;

	if (func_39(5477, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5478, -1, 0);
		}
		else {
			iVar0 = func_39(5479, -1, 0);
		}
	}
	else if (func_39(5480, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5481, -1, 0);
		}
		else {
			iVar0 = func_39(5482, -1, 0);
		}
	}
	else if (func_39(5483, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5484, -1, 0);
		}
		else {
			iVar0 = func_39(5485, -1, 0);
		}
	}
	else if (func_39(5486, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5487, -1, 0);
		}
		else {
			iVar0 = func_39(5488, -1, 0);
		}
	}
	else if (func_39(5489, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5490, -1, 0);
		}
		else {
			iVar0 = func_39(5491, -1, 0);
		}
	}
	else if (func_39(5492, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5493, -1, 0);
		}
		else {
			iVar0 = func_39(5494, -1, 0);
		}
	}
	else if (func_39(5495, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5496, -1, 0);
		}
		else {
			iVar0 = func_39(5497, -1, 0);
		}
	}
	else if (func_39(5498, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5499, -1, 0);
		}
		else {
			iVar0 = func_39(5500, -1, 0);
		}
	}
	else if (func_39(5501, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5502, -1, 0);
		}
		else {
			iVar0 = func_39(5503, -1, 0);
		}
	}
	else if (func_39(5504, -1, 0) == iParam0) {
		if (iParam1) {
			iVar0 = func_39(5505, -1, 0);
		}
		else {
			iVar0 = func_39(5506, -1, 0);
		}
	}
	else {
		iVar0 = -1;
	}
	return iVar0;
}

// Position - 0x1318
bool func_48(int iParam0) { return iParam0 == Global_262145.f_7424; }

// Position - 0x132A
void func_49() {
	if (gameplay::is_bit_set(Global_2404954, 19)) {
		Global_2404967.f_2 = 1;
		if (gameplay::is_bit_set(Global_2404954, 27)) {
			Global_2404967.f_3 = gameplay::get_game_timer() + 60000;
		}
		else {
			Global_2404967.f_3 = gameplay::get_game_timer() + 300000;
		}
		return;
	}
	func_50();
}

// Position - 0x137B
void func_50() {
	Global_2404967.f_2 = 0;
	Global_2404967.f_3 = 0;
}

// Position - 0x1391
void func_51(int iParam0) {
	gameplay::clear_bit(&Global_2404954, 19);
	gameplay::clear_bit(&Global_2404954, 26);
	gameplay::clear_bit(&Global_2404954, 27);
	if (func_53(iParam0)) {
		if (func_47(iParam0, 1) == 0) {
			gameplay::set_bit(&Global_2404954, 19);
		}
		return;
	}
	if (func_52(iParam0)) {
		if (func_47(iParam0, 1) == 0) {
			gameplay::set_bit(&Global_2404954, 19);
			gameplay::set_bit(&Global_2404954, 26);
		}
		return;
	}
}

// Position - 0x1409
bool func_52(int iParam0) { return iParam0 == Global_262145.f_7448; }

// Position - 0x141B
bool func_53(int iParam0) { return iParam0 == Global_262145.f_7429; }

// Position - 0x142D
void func_54() {
	if (gameplay::is_bit_set(Global_2404954, 14)) {
		Global_2404974 = 1;
		Global_2404974.f_1 = 1;
		Global_2404974.f_2 = func_38();
		Global_2404974.f_3 = gameplay::get_game_timer() + 120000;
		return;
	}
	if (gameplay::is_bit_set(Global_2404954, 15)) {
		Global_2404974 = 1;
		Global_2404974.f_1 = 1;
		Global_2404974.f_2 = func_37();
		Global_2404974.f_3 = gameplay::get_game_timer() + 120000;
		return;
	}
	if (gameplay::is_bit_set(Global_2404954, 16)) {
		Global_2404974 = 1;
		Global_2404974.f_1 = 1;
		Global_2404974.f_2 = func_36();
		Global_2404974.f_3 = gameplay::get_game_timer() + 120000;
		return;
	}
	if (gameplay::is_bit_set(Global_2404954, 17)) {
		Global_2404974 = 1;
		Global_2404974.f_1 = 1;
		Global_2404974.f_2 = func_35();
		Global_2404974.f_3 = gameplay::get_game_timer() + 120000;
		return;
	}
	if (gameplay::is_bit_set(Global_2404954, 18)) {
		Global_2404974 = 1;
		Global_2404974.f_1 = 1;
		Global_2404974.f_2 = func_34();
		Global_2404974.f_3 = gameplay::get_game_timer() + 120000;
		return;
	}
	func_55();
}

// Position - 0x1542
void func_55() {
	Global_2404974 = 0;
	Global_2404974.f_1 = 0;
	Global_2404974.f_2 = 0;
	Global_2404974.f_3 = gameplay::get_game_timer();
}

// Position - 0x1567
void func_56(int iParam0) {
	func_59();
	if (func_47(iParam0, 1) > 1) {
		return;
	}
	if (func_48(iParam0)) {
		gameplay::set_bit(&Global_2404954, 14);
		return;
	}
	if (func_53(iParam0)) {
		gameplay::set_bit(&Global_2404954, 15);
		return;
	}
	if (func_58(iParam0)) {
		gameplay::set_bit(&Global_2404954, 16);
		return;
	}
	if (func_57(iParam0)) {
		gameplay::set_bit(&Global_2404954, 17);
		return;
	}
	if (func_52(iParam0)) {
		gameplay::set_bit(&Global_2404954, 18);
		return;
	}
}

// Position - 0x15EF
bool func_57(int iParam0) { return iParam0 == Global_262145.f_7442; }

// Position - 0x1601
bool func_58(int iParam0) { return iParam0 == Global_262145.f_7436; }

// Position - 0x1613
void func_59() {
	gameplay::clear_bit(&Global_2404954, 14);
	gameplay::clear_bit(&Global_2404954, 15);
	gameplay::clear_bit(&Global_2404954, 16);
	gameplay::clear_bit(&Global_2404954, 17);
	gameplay::clear_bit(&Global_2404954, 18);
}

// Position - 0x164D
void func_60(int iParam0) {
	bool bVar0;

	bVar0 = false;
	if (iParam0 == Global_262145.f_7424) {
		if (gameplay::is_bit_set(Global_2404954, 0)) {
			return;
		}
		gameplay::set_bit(&Global_2404954, 0);
		bVar0 = true;
	}
	if (iParam0 == Global_262145.f_7429) {
		if (gameplay::is_bit_set(Global_2404954, 3)) {
			return;
		}
		gameplay::set_bit(&Global_2404954, 3);
		func_63(0, 0);
		func_63(0, 1);
		func_62(0);
		bVar0 = true;
	}
	if (iParam0 == Global_262145.f_7436) {
		if (gameplay::is_bit_set(Global_2404954, 5)) {
			return;
		}
		gameplay::set_bit(&Global_2404954, 5);
		func_63(1, 0);
		func_63(1, 1);
		func_62(1);
		bVar0 = true;
	}
	if (iParam0 == Global_262145.f_7442) {
		if (gameplay::is_bit_set(Global_2404954, 7)) {
			return;
		}
		gameplay::set_bit(&Global_2404954, 7);
		func_63(2, 0);
		func_63(2, 1);
		func_62(2);
		bVar0 = true;
	}
	if (iParam0 == Global_262145.f_7448) {
		if (gameplay::is_bit_set(Global_2404954, 9)) {
			return;
		}
		gameplay::set_bit(&Global_2404954, 9);
		func_63(3, 0);
		func_62(3);
		bVar0 = true;
	}
	if (bVar0) {
		func_61();
		Global_2404954.f_2 = 0;
		Global_2404954.f_4 = 120000;
		return;
	}
}

// Position - 0x1778
void func_61() {
	struct<4> Var0;

	Var0 = 5;
	Global_2404960 = {Var0};
}

// Position - 0x1791
void func_62(int iParam0) {
	switch (iParam0) {
	case 0: gameplay::clear_bit(&Global_2404954, 0); return;

	case 1: gameplay::clear_bit(&Global_2404954, 3); return;

	case 2: gameplay::clear_bit(&Global_2404954, 5); return;

	case 3: gameplay::clear_bit(&Global_2404954, 7); return;

	case 4: gameplay::clear_bit(&Global_2404954, 9); return;

	default:
	}
}

// Position - 0x17FB
void func_63(int iParam0, int iParam1) {
	switch (iParam0) {
	case 0:
		if (gameplay::is_bit_set(Global_2404954, 0)) {
			if (iParam1) {
				if (!gameplay::is_bit_set(Global_2404954, 21)) {
					gameplay::set_bit(&Global_2404954, 21);
				}
			}
			else if (!gameplay::is_bit_set(Global_2404954, 2)) {
				gameplay::set_bit(&Global_2404954, 2);
			}
		}
		return;

	case 1:
		if (gameplay::is_bit_set(Global_2404954, 3)) {
			if (iParam1) {
				if (!gameplay::is_bit_set(Global_2404954, 22)) {
					gameplay::set_bit(&Global_2404954, 22);
				}
			}
			else if (!gameplay::is_bit_set(Global_2404954, 4)) {
				gameplay::set_bit(&Global_2404954, 4);
			}
		}
		return;

	case 2:
		if (gameplay::is_bit_set(Global_2404954, 5)) {
			if (iParam1) {
				if (!gameplay::is_bit_set(Global_2404954, 23)) {
					gameplay::set_bit(&Global_2404954, 23);
				}
			}
			else if (!gameplay::is_bit_set(Global_2404954, 6)) {
				gameplay::set_bit(&Global_2404954, 6);
			}
		}
		return;

	case 3:
		if (gameplay::is_bit_set(Global_2404954, 7)) {
			if (iParam1) {
			}
			else if (!gameplay::is_bit_set(Global_2404954, 8)) {
				gameplay::set_bit(&Global_2404954, 8);
			}
		}
		return;

	case 4:
		if (gameplay::is_bit_set(Global_2404954, 9)) {
			if (iParam1) {
			}
			else if (!gameplay::is_bit_set(Global_2404954, 10)) {
				gameplay::set_bit(&Global_2404954, 10);
			}
		}
		return;

	default:
	}
}

// Position - 0x1956
void func_64() {
	struct<13> Var0;
	int iVar13;

	iVar13 = 0;
	while (iVar13 <= 3) {
		Global_2443905.f_5910[iVar13 /*16*/] = {Var0};
		Global_2443905.f_5910[iVar13 /*16*/].f_13 = -1;
		Global_2443905.f_5910[iVar13 /*16*/].f_14 = -1;
		Global_2443905.f_5910[iVar13 /*16*/].f_15 = -1;
		iVar13++;
	}
}

// Position - 0x19AD
void func_65() {
	struct<6> Var0;

	StringCopy(&Var0, ".", 24);
	func_70(Var0);
	func_69(51, ".", -1, 1);
	func_69(52, ".", -1, 1);
	func_69(53, ".", -1, 1);
	func_69(54, ".", -1, 1);
	func_69(55, ".", -1, 1);
	func_69(56, ".", -1, 1);
	func_69(57, ".", -1, 1);
	func_68(2, "0", -1);
	func_68(3, "0", -1);
	func_68(4, "0", -1);
	func_68(5, "0", -1);
	func_68(6, "0", -1);
	func_68(7, "0", -1);
	func_68(8, "0", -1);
	func_68(9, "0", -1);
	func_68(10, "0", -1);
	func_68(11, "0", -1);
	func_68(12, "0", -1);
	func_68(13, "0", -1);
	func_68(14, "0", -1);
	func_68(15, "0", -1);
	func_68(16, "0", -1);
	func_68(17, "0", -1);
	func_68(18, "0", -1);
	func_68(19, "0", -1);
	func_68(20, "0", -1);
	func_68(21, "0", -1);
	func_68(22, "0", -1);
	func_68(23, "0", -1);
	func_68(24, "0", -1);
	func_68(25, "0", -1);
	func_68(26, "0", -1);
	func_68(27, "0", -1);
	func_68(28, "0", -1);
	func_68(29, "0", -1);
	func_68(30, "0", -1);
	func_68(31, "0", -1);
	func_68(32, "0", -1);
	func_68(33, "0", -1);
	func_69(13, "0", -1, 1);
	func_69(14, "0", -1, 1);
	func_69(15, "0", -1, 1);
	func_69(16, "0", -1, 1);
	func_69(17, "0", -1, 1);
	func_69(18, "0", -1, 1);
	func_69(19, "0", -1, 1);
	func_69(20, "0", -1, 1);
	func_69(21, "0", -1, 1);
	func_69(22, "0", -1, 1);
	func_69(23, "0", -1, 1);
	func_69(24, "0", -1, 1);
	func_69(25, "0", -1, 1);
	func_69(26, "0", -1, 1);
	func_69(27, "0", -1, 1);
	func_69(28, "0", -1, 1);
	func_69(29, "0", -1, 1);
	func_69(30, "0", -1, 1);
	func_69(31, "0", -1, 1);
	func_69(32, "0", -1, 1);
	func_69(33, "0", -1, 1);
	func_69(34, "0", -1, 1);
	func_69(35, "0", -1, 1);
	func_69(36, "0", -1, 1);
	func_69(37, "0", -1, 1);
	func_69(38, "0", -1, 1);
	func_69(39, "0", -1, 1);
	func_69(40, "0", -1, 1);
	func_69(41, "0", -1, 1);
	func_69(42, "0", -1, 1);
	func_69(43, "0", -1, 1);
	func_69(44, "0", -1, 1);
	func_87(5405, -1, -1, 1, 0);
	func_87(5406, -1, -1, 1, 0);
	func_87(5407, -1, -1, 1, 0);
	func_87(5408, -1, -1, 1, 0);
	func_87(5409, -1, -1, 1, 0);
	func_87(5410, -1, -1, 1, 0);
	func_87(5411, -1, -1, 1, 0);
	func_87(5412, -1, -1, 1, 0);
	func_87(5565, 0, -1, 1, 0);
	func_87(5561, 0, -1, 1, 0);
	func_87(5562, 0, -1, 1, 0);
	func_87(5563, 0, -1, 1, 0);
	func_87(5564, 0, -1, 1, 0);
	func_87(5403, 0, -1, 1, 0);
	func_87(5566, -1, -1, 1, 0);
	func_87(5609, -1, -1, 1, 0);
	func_66(216, 0, -1, 1);
	func_66(231, 0, -1, 1);
	func_66(220, 0, -1, 1);
}

// Position - 0x1D35
void func_66(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	if (func_67()) {
		iVar0 = Global_2522581[iParam0 /*3*/][func_40(iParam2)];
		if (iVar0 != 0) {
			stats::stat_set_bool(iVar0, iParam1, iParam3);
		}
	}
}

// Position - 0x1D67
bool func_67() {
	return true;
	return false;
}

// Position - 0x1D74
void func_68(int iParam0, char *sParam1, int iParam2) {
	int iVar0;

	if (func_67()) {
		iVar0 = Global_1363016[iParam0 /*3*/][func_40(iParam2)];
		if (iVar0 != 0) {
			stats::stat_set_user_id(iVar0, sParam1, 1);
		}
	}
}

// Position - 0x1DA5
void func_69(int iParam0, char *sParam1, int iParam2, int iParam3) {
	int iVar0;

	if (func_67()) {
		iVar0 = Global_2523488[iParam0 /*3*/][func_40(iParam2)];
		if (iVar0 != 0) {
			stats::stat_set_string(iVar0, sParam1, iParam3);
		}
	}
}

// Position - 0x1DD7
void func_70(char[4] cParam0, char[4] cParam1, char[4] cParam2, char[4] cParam3, char[4] cParam4, char[4] cParam5) {
	StringCopy(&Global_1757074.f_10, "", 24);
	if (gameplay::is_string_null_or_empty(&cParam0) || gameplay::are_strings_equal(&cParam0, ".")) {
		func_87(5404, 0, -1, 1, 0);
		return;
	}
	func_87(5404, gameplay::get_hash_key(&cParam0), -1, 1, 0);
}

// Position - 0x1E20
void func_71(int iParam0) {
	if (iParam0 == 24) {
		Global_1751531.f_2 = Global_1751531;
	}
	func_72(1);
	Global_1751531 = iParam0;
}

// Position - 0x1E44
void func_72(int iParam0) { Global_1751531.f_1782 = iParam0; }

// Position - 0x1E55
int func_73() {
	struct<6> Var0;

	Var0 = {func_85()};
	if (gameplay::are_strings_equal(&Var0, ".") || gameplay::is_string_null_or_empty(&Var0)) {
		return 0;
	}
	return 1;
}

// Position - 0x1E82
void func_74(var uParam0) { Global_2404557.f_2 = uParam0; }

// Position - 0x1E92
void func_75(int iParam0) {
	int iVar0;
	int iVar1;
	bool bVar2;

	if (!iParam0) {
		if (func_80()) {
			iVar0 = 0;
			while (iVar0 < 5) {
				iVar1 = func_33(iVar0);
				if (func_47(iVar1, 1) <= 0) {
					bVar2 = true;
					iVar0 = 5;
				}
				iVar0++;
			}
			if (bVar2) {
				func_79();
				if (func_78()) {
					gameplay::set_bit(&Global_2404954, 19);
					gameplay::clear_bit(&Global_2404954, 26);
					gameplay::set_bit(&Global_2404954, 27);
					func_49();
				}
				Global_2404557.f_18 = func_76(1);
			}
		}
	}
}

// Position - 0x1F0F
int func_76(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = func_39(5570, -1, 0);
	iVar1 = func_33(iVar0);
	iVar2 = 0;
	if (func_48(iVar1)) {
		if (func_47(iVar1, 1) <= 0) {
			iVar2 = 120000;
			if (iParam0) {
			}
			return iVar2;
		}
	}
	if (func_53(iVar1)) {
		if (func_47(iVar1, 1) <= 0) {
			iVar2 = Global_262145.f_4860;
			if (iParam0) {
			}
			if (Global_2404964) {
				if (gameplay::is_bit_set(Global_2404954, 24)) {
					iVar2 = 60000;
					if (iParam0) {
					}
				}
				else {
					iVar2 = Global_262145.f_4860 / 2;
					if (iParam0) {
					}
				}
				if (Global_2404974.f_1 == 0) {
					if (iParam0) {
					}
					func_77();
				}
			}
			return iVar2;
		}
	}
	if (func_48(iVar1) || func_53(iVar1) || func_58(iVar1) || func_57(iVar1) || func_52(iVar1)) {
		if (func_47(iVar1, 1) > 0) {
			iVar2 = Global_262145.f_4862;
			if (iParam0) {
			}
			return iVar2;
		}
		iVar2 = Global_262145.f_4861;
		if (iParam0) {
		}
		if (Global_2404964) {
			if (gameplay::is_bit_set(Global_2404954, 24)) {
				iVar2 = 60000;
				if (iParam0) {
				}
			}
			else {
				iVar2 = Global_262145.f_4861 / 2;
				if (iParam0) {
				}
			}
			if (Global_2404974.f_1 == 0) {
				if (iParam0) {
				}
				func_77();
			}
		}
		return iVar2;
	}
	iVar2 = Global_262145.f_4861;
	if (iParam0) {
	}
	return iVar2;
}

// Position - 0x207C
void func_77() {
	int iVar0;
	int iVar1;

	if (!func_42()) {
		return;
	}
	iVar0 = func_39(5570, -1, 0);
	iVar1 = func_33(iVar0);
	if (func_47(iVar1, 1) > 0) {
		return;
	}
	Global_2404967 = 1;
	Global_2404967.f_1 = gameplay::get_game_timer() + 1000;
}

// Position - 0x20C2
bool func_78() {
	int iVar0;
	int iVar1;

	if (Global_1315193 == 10) {
		if (Global_2404983) {
			Global_2404983 = 0;
		}
		return false;
	}
	if (!func_42()) {
		if (Global_2404983) {
			Global_2404983 = 0;
		}
		return false;
	}
	iVar0 = 0;
	iVar1 = 0;
	iVar0 = 0;
	while (iVar0 < 5) {
		iVar1 = func_33(iVar0);
		if (func_47(iVar1, 1) <= 0) {
			if (Global_2404983) {
				Global_2404983 = 0;
			}
			return false;
		}
		iVar0++;
	}
	if (!Global_2404983) {
		Global_2404983 = 1;
	}
	return true;
}

// Position - 0x2144
void func_79() {
	func_82(Global_262145.f_7424, 1, 0, 1);
	func_82(Global_262145.f_7429, 1, 0, 1);
	func_82(Global_262145.f_7436, 1, 0, 1);
	func_82(Global_262145.f_7442, 1, 0, 1);
	func_82(Global_262145.f_7448, 1, 0, 1);
}

// Position - 0x2192
bool func_80() {
	if (func_81(1) && func_81(2) && func_81(3) && func_81(4) && func_81(5)) {
		return true;
	}
	return false;
}

// Position - 0x21D2
int func_81(int iParam0) {
	var uVar0;
	int iVar1;
	var uVar2;

	uVar0 = Global_1363138[iParam0];
	iVar1 = uVar0;
	if (stats::stat_get_bool(iVar1, &uVar2, -1)) {
		return uVar2;
	}
	return 0;
}

// Position - 0x21FA
void func_82(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (func_39(5477, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5478, -1, 0) <= 0) {
			func_84(0, iParam1, iParam0);
		}
	}
	else if (func_39(5480, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5481, -1, 0) <= 0) {
			func_84(1, iParam1, iParam0);
		}
	}
	else if (func_39(5483, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5484, -1, 0) <= 0) {
			func_84(2, iParam1, iParam0);
		}
	}
	else if (func_39(5486, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5487, -1, 0) <= 0) {
			func_84(3, iParam1, iParam0);
		}
	}
	else if (func_39(5489, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5490, -1, 0) <= 0) {
			func_84(4, iParam1, iParam0);
		}
	}
	else if (func_39(5492, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5493, -1, 0) <= 0) {
			func_84(5, iParam1, iParam0);
		}
	}
	else if (func_39(5495, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5496, -1, 0) <= 0) {
			func_84(6, iParam1, iParam0);
		}
	}
	else if (func_39(5498, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5499, -1, 0) <= 0) {
			func_84(7, iParam1, iParam0);
		}
	}
	else if (func_39(5501, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5502, -1, 0) <= 0) {
			func_84(8, iParam1, iParam0);
		}
	}
	else if (func_39(5504, -1, 0) == iParam0) {
		if (!iParam3 || func_39(5505, -1, 0) <= 0) {
			func_84(9, iParam1, iParam0);
		}
	}
	else if (!iParam2) {
		func_83(iParam0);
		func_82(iParam0, iParam1, 1, 0);
	}
}

// Position - 0x2407
void func_83(int iParam0) {
	if (func_39(5477, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5480, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5483, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5486, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5489, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5492, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5495, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5498, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5501, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5504, -1, 0) == iParam0) {
		return;
	}
	else if (func_39(5477, -1, 0) == 0) {
		func_87(5477, iParam0, -1, 1, 0);
	}
	else if (func_39(5480, -1, 0) == 0) {
		func_87(5480, iParam0, -1, 1, 0);
	}
	else if (func_39(5483, -1, 0) == 0) {
		func_87(5483, iParam0, -1, 1, 0);
	}
	else if (func_39(5486, -1, 0) == 0) {
		func_87(5486, iParam0, -1, 1, 0);
	}
	else if (func_39(5489, -1, 0) == 0) {
		func_87(5489, iParam0, -1, 1, 0);
	}
	else if (func_39(5492, -1, 0) == 0) {
		func_87(5492, iParam0, -1, 1, 0);
	}
	else if (func_39(5495, -1, 0) == 0) {
		func_87(5495, iParam0, -1, 1, 0);
	}
	else if (func_39(5498, -1, 0) == 0) {
		func_87(5498, iParam0, -1, 1, 0);
	}
	else if (func_39(5501, -1, 0) == 0) {
		func_87(5501, iParam0, -1, 1, 0);
	}
	else if (func_39(5504, -1, 0) == 0) {
		func_87(5504, iParam0, -1, 1, 0);
	}
}

// Position - 0x25EF
void func_84(int iParam0, bool bParam1, int iParam2) {
	if (iParam2 == iParam2) {
	}
	switch (iParam0) {
	default: break;

	case 0:
		if (bParam1) {
			func_87(5478, func_39(5478, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5479, func_39(5479, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 1:
		if (bParam1) {
			func_87(5481, func_39(5481, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5482, func_39(5482, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 2:
		if (bParam1) {
			func_87(5484, func_39(5484, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5485, func_39(5485, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 3:
		if (bParam1) {
			func_87(5487, func_39(5487, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5488, func_39(5488, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 4:
		if (bParam1) {
			func_87(5490, func_39(5490, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5491, func_39(5491, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 5:
		if (bParam1) {
			func_87(5493, func_39(5493, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5494, func_39(5494, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 6:
		if (bParam1) {
			func_87(5496, func_39(5496, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5497, func_39(5497, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 7:
		if (bParam1) {
			func_87(5499, func_39(5499, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5500, func_39(5500, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 8:
		if (bParam1) {
			func_87(5502, func_39(5502, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5503, func_39(5503, -1, 0) + 1, -1, 1, 0);
		}
		break;

	case 9:
		if (bParam1) {
			func_87(5505, func_39(5505, -1, 0) + 1, -1, 1, 0);
		}
		else {
			func_87(5506, func_39(5506, -1, 0) + 1, -1, 1, 0);
		}
		break;
	}
}

// Position - 0x2856
struct<6> func_85() {
	struct<6> Var0;
	int iVar6;
	int iVar7;

	if (gameplay::is_string_null_or_empty(&Global_1757074.f_10)) {
		iVar7 = func_39(5404, -1, 0);
		if (iVar7 == 0) {
			StringCopy(&Var0, ".", 24);
		}
		else {
			iVar6 = 0;
			while (iVar6 < 1118) {
				if (Global_794643.f_4[iVar6 /*88*/].f_65 == 0 && Global_794643.f_4[iVar6 /*88*/].f_68 == 1 &&
					gameplay::is_bit_set(Global_794643.f_4[iVar6 /*88*/].f_76, 13)) {
					if (Global_794643.f_98389[iVar6 /*13*/].f_1 == iVar7) {
						Var0 = {Global_794643.f_112937[Global_794643.f_98389[iVar6 /*13*/].f_10 /*6*/]};
						iVar6 = 1118;
					}
				}
				iVar6++;
			}
			if (gameplay::is_string_null_or_empty(&Var0)) {
			}
		}
		Global_1757074.f_10 = {Var0};
		return Var0;
	}
	return Global_1757074.f_10;
}

//Position - 0x2935
void func_86()
{
	func_68(2, "0", -1);
	func_68(3, "0", -1);
	func_68(4, "0", -1);
	func_68(5, "0", -1);
	func_68(6, "0", -1);
	func_68(7, "0", -1);
	func_68(8, "0", -1);
	func_68(9, "0", -1);
	func_68(10, "0", -1);
	func_68(11, "0", -1);
	func_68(12, "0", -1);
	func_68(13, "0", -1);
	func_68(14, "0", -1);
	func_68(15, "0", -1);
	func_68(16, "0", -1);
	func_68(17, "0", -1);
	func_68(18, "0", -1);
	func_68(19, "0", -1);
	func_68(20, "0", -1);
	func_68(21, "0", -1);
	func_68(22, "0", -1);
	func_68(23, "0", -1);
	func_68(24, "0", -1);
	func_68(25, "0", -1);
	func_68(26, "0", -1);
	func_68(27, "0", -1);
	func_68(28, "0", -1);
	func_68(29, "0", -1);
	func_68(30, "0", -1);
	func_68(31, "0", -1);
	func_68(32, "0", -1);
	func_68(33, "0", -1);
	func_69(13, "0", -1, 1);
	func_69(14, "0", -1, 1);
	func_69(15, "0", -1, 1);
	func_69(16, "0", -1, 1);
	func_69(17, "0", -1, 1);
	func_69(18, "0", -1, 1);
	func_69(19, "0", -1, 1);
	func_69(20, "0", -1, 1);
	func_69(21, "0", -1, 1);
	func_69(22, "0", -1, 1);
	func_69(23, "0", -1, 1);
	func_69(24, "0", -1, 1);
	func_69(25, "0", -1, 1);
	func_69(26, "0", -1, 1);
	func_69(27, "0", -1, 1);
	func_69(28, "0", -1, 1);
	func_69(29, "0", -1, 1);
	func_69(30, "0", -1, 1);
	func_69(31, "0", -1, 1);
	func_69(32, "0", -1, 1);
	func_69(33, "0", -1, 1);
	func_69(34, "0", -1, 1);
	func_69(35, "0", -1, 1);
	func_69(36, "0", -1, 1);
	func_69(37, "0", -1, 1);
	func_69(38, "0", -1, 1);
	func_69(39, "0", -1, 1);
	func_69(40, "0", -1, 1);
	func_69(41, "0", -1, 1);
	func_69(42, "0", -1, 1);
	func_69(43, "0", -1, 1);
	func_69(44, "0", -1, 1);
}

// Position - 0x2B9D
void func_87(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam4) {
	}
	iVar0 = Global_2503826[iParam0 /*3*/][func_40(iParam2)];
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, iParam3);
	}
}

// Position - 0x2BCD
int func_88() {
	int iVar0;

	if (func_89(20, -1)) {
		iVar0++;
	}
	if (func_89(21, -1)) {
		iVar0++;
	}
	if (func_89(22, -1)) {
		iVar0++;
	}
	return iVar0;
}

// Position - 0x2C07
bool func_89(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam1 == -1) {
		iParam1 = func_664();
	}
	iVar0 = func_90(iParam1);
	iVar1 = gameplay::get_profile_setting(iVar0);
	return gameplay::is_bit_set(iVar1, iParam0);
}

// Position - 0x2C33
int func_90(int iParam0) {
	int iVar0;

	if (iParam0 == -1) {
		iParam0 = func_664();
	}
	switch (iParam0) {
	case 0: iVar0 = 914; break;

	case 1: iVar0 = 915; break;

	case 2: iVar0 = 916; break;

	case 3: iVar0 = 917; break;

	case 4: iVar0 = 918; break;
	}
	return iVar0;
}

// Position - 0x2C96
int func_91() {
	int iVar0;
	int iVar1;

	iVar0 = 1;
	iVar1 = 0;
	while (iVar1 < 2) {
		if (!gameplay::is_string_null_or_empty(&Global_1633501.f_88939[iVar1 /*6*/])) {
			iVar0 = 0;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x2CCD
bool func_92() { return Global_2443905.f_5884; }

// Position - 0x2CDC
void func_93() {
	int iVar0;
	bool bVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_664();
	iVar2 = func_90(iVar0);
	iVar3 = gameplay::get_profile_setting(iVar2);
	if (gameplay::is_bit_set(iVar3, 20)) {
		gameplay::clear_bit(&iVar3, 20);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 21)) {
		gameplay::clear_bit(&iVar3, 21);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 22)) {
		gameplay::clear_bit(&iVar3, 22);
		bVar1 = true;
	}
	if (bVar1) {
		stats::_0x0D01D20616FC73FB(iVar3, iVar0);
	}
}

// Position - 0x2D49
void func_94(int iParam0) { Global_2443905.f_5884 = iParam0; }

// Position - 0x2D5A
void func_95() {
	int iVar0;
	bool bVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_664();
	iVar2 = func_96(iVar0);
	iVar3 = gameplay::get_profile_setting(iVar2);
	if (gameplay::is_bit_set(iVar3, 12)) {
		gameplay::clear_bit(&iVar3, 12);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 13)) {
		gameplay::clear_bit(&iVar3, 13);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 14)) {
		gameplay::clear_bit(&iVar3, 14);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 15)) {
		gameplay::clear_bit(&iVar3, 15);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 16)) {
		gameplay::clear_bit(&iVar3, 16);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 17)) {
		gameplay::clear_bit(&iVar3, 17);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 18)) {
		gameplay::clear_bit(&iVar3, 18);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 19)) {
		gameplay::clear_bit(&iVar3, 19);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 20)) {
		gameplay::clear_bit(&iVar3, 20);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 21)) {
		gameplay::clear_bit(&iVar3, 21);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 22)) {
		gameplay::clear_bit(&iVar3, 22);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 23)) {
		gameplay::clear_bit(&iVar3, 23);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 24)) {
		gameplay::clear_bit(&iVar3, 24);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 25)) {
		gameplay::clear_bit(&iVar3, 25);
		bVar1 = true;
	}
	if (bVar1) {
		stats::_0x723C1CE13FBFDB67(iVar3, iVar0);
	}
	bVar1 = false;
	iVar2 = func_90(iVar0);
	iVar3 = gameplay::get_profile_setting(iVar2);
	if (gameplay::is_bit_set(iVar3, 8)) {
		gameplay::clear_bit(&iVar3, 8);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 9)) {
		gameplay::clear_bit(&iVar3, 9);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 10)) {
		gameplay::clear_bit(&iVar3, 10);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 11)) {
		gameplay::clear_bit(&iVar3, 11);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 12)) {
		gameplay::clear_bit(&iVar3, 12);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 13)) {
		gameplay::clear_bit(&iVar3, 13);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 14)) {
		gameplay::clear_bit(&iVar3, 14);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 15)) {
		gameplay::clear_bit(&iVar3, 15);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 16)) {
		gameplay::clear_bit(&iVar3, 16);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 17)) {
		gameplay::clear_bit(&iVar3, 17);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 18)) {
		gameplay::clear_bit(&iVar3, 18);
		bVar1 = true;
	}
	if (gameplay::is_bit_set(iVar3, 19)) {
		gameplay::clear_bit(&iVar3, 19);
		bVar1 = true;
	}
	if (bVar1) {
		stats::_0x0D01D20616FC73FB(iVar3, iVar0);
	}
}

// Position - 0x2FE1
int func_96(int iParam0) {
	int iVar0;

	if (iParam0 == -1) {
		iParam0 = func_664();
	}
	switch (iParam0) {
	case 0: iVar0 = 909; break;

	case 1: iVar0 = 910; break;

	case 2: iVar0 = 911; break;

	case 3: iVar0 = 912; break;

	case 4: iVar0 = 913; break;
	}
	return iVar0;
}

// Position - 0x3044
void func_97() { Global_2452972 = 0; }

// Position - 0x3051
var func_98(int iParam0, int iParam1) {
	var uVar0;
	vector3 vVar1;
	vector3 vVar4;
	vector3 vVar7;
	struct<4> Var10[4];
	struct<4> Var27;
	int iVar34;
	int iVar35;
	int iVar36;

	uVar0 = Global_2452970;
	if (vVar4.x != 0f && vVar7.x != 0f) {
	}
	func_187(func_189(player::player_id()), &iVar34, 999);
	vVar1 = {func_189(player::player_id())};
	func_184(iVar34, &Var10, -1);
	vVar4 = {Var10[0 /*4*/]};
	vVar7 = {Global_1049427[iVar34 /*1942*/].f_1742.f_20};
	iVar35 = 0;
	while (iVar35 <= 2) {
		if (Global_1049427[iVar34 /*1942*/].f_38[iVar35 /*27*/].f_26 == 2 ||
			Global_1049427[iVar34 /*1942*/].f_38[iVar35 /*27*/].f_26 == 1) {
			vVar1 = {Global_1049427[iVar34 /*1942*/].f_38[iVar35 /*27*/].f_12};
		}
		iVar35++;
	}
	if (Global_2452982 == -1) {
		iVar36 = gameplay::get_random_int_in_range(0, 100);
		if (iVar36 > 80) {
			Global_2452982 = 4;
		}
		else if (iVar36 > 60) {
			Global_2452982 = 3;
		}
		else if (iVar36 > 40) {
			Global_2452982 = 2;
		}
		else if (iVar36 > 20) {
			Global_2452982 = 1;
		}
		else {
			Global_2452982 = 0;
		}
	}
	func_183(&Var27, Global_1049427[iVar34 /*1942*/].f_35, Global_2452982);
	switch (Global_2452970) {
	case 0:
		func_182();
		func_97();
		if (streaming::is_new_load_scene_active()) {
			streaming::new_load_scene_stop();
		}
		Global_2452545 = {vVar1};
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (streaming::is_entity_focus(player::player_ped_id())) {
				streaming::clear_focus();
			}
		}
		Global_2452970 = 1;
		break;

	case 1:
		if (func_153(0, 0, 0, 0, 1, 0)) {
			Global_2452970 = 2;
		}
		if (func_152()) {
			if (iParam1) {
				ui::set_pause_menu_active(0);
				ui::set_frontend_active(0);
			}
			func_151(&Global_2452977, Var27, Var27.f_3, Var27.f_6);
			if (func_195()) {
				graphics::_start_screen_effect("MenuMGHeistIn", 0, 1);
			}
			else {
				graphics::_start_screen_effect("SwitchOpenNeutralOutHeist", 0, 1);
			}
			Global_2452970 = 2;
		}
		break;

	case 2:
		streaming::stop_player_switch();
		func_2(0);
		streaming::_set_focus_area(Var27, Var27.f_3);
		Global_2452970 = 3;
		break;

	case 3:
		streaming::_set_focus_area(Var27, Var27.f_3);
		func_150();
		func_149();
		graphics::_0x22A249A53034450A(0);
		Global_2452970 = 4;
		break;

	case 4:
		Global_2452981 = 1;
		if (func_148() != 1) {
			if (func_195()) {
				if (func_230()) {
					func_146(0);
				}
			}
		}
		if (Global_2452971) {
			func_182();
			func_146(0);
			streaming::clear_focus();
			if (func_145(Global_1591072)) {
				func_135(&Global_2452975, &Global_2452976, "hei_dlc_apart_high2_new");
			}
			else {
				func_135(&Global_2452975, &Global_2452976, "hei_dlc_apart_high_new");
			}
			Global_2452970 = 5;
		}
		break;

	case 5:
		ui::hide_hud_and_radar_this_frame();
		if (streaming::is_new_load_scene_active() == 0) {
			if (entity::does_entity_exist(player::player_ped_id())) {
				if (streaming::is_entity_focus(player::player_ped_id())) {
					streaming::clear_focus();
				}
			}
			if (streaming::new_load_scene_start_sphere(entity::get_entity_coords(player::player_ped_id(), 0), 60f, 0)) {
				func_13(&Global_2452973);
				Global_2452970 = 6;
			}
		}
		if (Global_2404994.f_2209) {
			func_102();
		}
		break;

	case 6:
		ui::hide_hud_and_radar_this_frame();
		if (func_12(&Global_2452973, 25000, 0)) {
			Global_2452970 = 7;
		}
		else if (streaming::is_new_load_scene_loaded()) {
			Global_2452970 = 7;
		}
		break;

	case 7:
		ui::hide_hud_and_radar_this_frame();
		if (streaming::is_new_load_scene_active()) {
			streaming::new_load_scene_stop();
		}
		if (cam::does_cam_exist(Global_2452977)) {
			if (cam::is_cam_active(Global_2452977)) {
				cam::set_cam_active(Global_2452977, 0);
			}
			cam::destroy_cam(Global_2452977, 1);
			cam::render_script_cams(0, 0, 3000, 1, 1, 0);
		}
		Global_2452982 = -1;
		func_101(0);
		Global_2452970 = 8;
		if (Global_2404994.f_2209) {
			Global_1318163 = 1;
			func_102();
		}
		if (func_198()) {
			func_197(0);
		}
		break;

	case 8:
		ui::hide_hud_and_radar_this_frame();
		if (iParam0) {
		}
		else {
			func_99(0);
		}
		func_182();
		func_97();
		Global_2452970 = 0;
		break;
	}
	return uVar0;
}

// Position - 0x3425
void func_99(int iParam0) {
	if (func_148() == 1 || ui::is_pause_menu_active() || iParam0) {
		func_100(0);
		graphics::_set_frozen_rendering_disabled(1);
		graphics::_set_frozen_rendering_disabled(1);
		graphics::_0xE1C8709406F2C41C();
	}
}

// Position - 0x345B
void func_100(int iParam0) {
	if (Global_1312466.f_20 != iParam0) {
		Global_1312466.f_20 = iParam0;
	}
}

// Position - 0x3476
void func_101(int iParam0) { Global_2454053 = iParam0; }

// Position - 0x3484
void func_102() {
	int iVar0;
	struct<7> Var1;

	iVar0 = 18823;
	if (gameplay::is_bit_set(Global_1590877.f_22, 5) || gameplay::is_bit_set(Global_1590877.f_22, 6) ||
		gameplay::is_bit_set(Global_1590877.f_22, 8) || gameplay::is_bit_set(Global_1590877.f_22, 7) ||
		gameplay::is_bit_set(Global_1590877.f_22, 9) || gameplay::is_bit_set(Global_1590877.f_22, 20) || func_134()) {
		if (!gameplay::is_bit_set(Global_1048576.f_8, 0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("am_mp_property_int")) <= 0 &&
				!network::network_is_script_active("AM_MP_PROPERTY_INT", Global_1048576.f_846, 1, 0)) {
				script::request_script("AM_MP_PROPERTY_INT");
				if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
					system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
					script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
					gameplay::set_bit(&Global_1048576.f_8, 0);
				}
			}
		}
	}
	else if (Global_2404994.f_2209) {
		if (!gameplay::is_bit_set(Global_1048576.f_8, 0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("am_mp_property_int")) <= 0 &&
				!network::network_is_script_active("AM_MP_PROPERTY_INT", Global_1048576.f_846, 1, 0)) {
				script::request_script("AM_MP_PROPERTY_INT");
				if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
					system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
					script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
					gameplay::set_bit(&Global_1048576.f_8, 0);
				}
			}
		}
	}
	else if (Global_1590877.f_19 != 0 && func_133(player::player_id(), 1, 0)) {
		if (!gameplay::is_bit_set(Global_1048576.f_8, 0)) {
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("am_mp_property_int")) <= 0 &&
				!network::network_is_script_active("AM_MP_PROPERTY_INT", Global_1048576.f_846, 1, 0)) {
				script::request_script("AM_MP_PROPERTY_INT");
				if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
					system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
					script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
					gameplay::set_bit(&Global_1048576.f_8, 0);
				}
			}
		}
	}
	else if (Global_2452990) {
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("am_mp_property_int")) <= 0 &&
			!network::network_is_script_active("AM_MP_PROPERTY_INT", Global_1048576.f_846, 1, 0)) {
			script::request_script("AM_MP_PROPERTY_INT");
			if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
				system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
				script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
				gameplay::set_bit(&Global_1048576.f_8, 0);
				Global_2452990 = 0;
			}
		}
	}
	else if (!gameplay::is_bit_set(Global_1048576.f_8, 0) && !gameplay::is_bit_set(Global_2494199.f_357.f_5, 3) &&
			 (!Global_2404993 || Global_2404993 && Global_2443905.f_1.f_2824.f_13 > 0) && !func_132() && !func_127()) {
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("am_mp_property_int")) <= 0 &&
			!network::network_is_script_active("AM_MP_PROPERTY_INT", Global_1048576.f_846, 1, 0)) {
			if (!func_126()) {
				if (func_122()) {
					script::request_script("AM_MP_PROPERTY_INT");
					if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
						system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
						script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
						gameplay::set_bit(&Global_1048576.f_8, 0);
						gameplay::set_bit(&Global_1590877.f_22, 12);
						return;
					}
					return;
				}
			}
			else {
				if (!func_121(Global_1048576.f_845) &&
					gameplay::get_distance_between_coords(func_189(player::player_id()), func_115(Global_1048576.f_845),
														  1) <= 30f) {
					if (func_113(&Global_1049427[Global_1048576.f_845 /*1942*/], 1, 0)) {
						if (!Global_1591201[player::player_id() /*602*/].f_507) {
							script::request_script("AM_MP_PROPERTY_INT");
							if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
								system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
								script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
								gameplay::set_bit(&Global_1048576.f_8, 0);
								gameplay::set_bit(&Global_1590877.f_22, 12);
								return;
							}
							return;
						}
					}
					else {
						Var1 = {func_189(player::player_id())};
					}
				}
				if (gameplay::get_distance_between_coords(func_189(player::player_id()), func_112(2), 1) <= 30f) {
					func_111(&Var1, 2);
					if (entity::is_entity_in_angled_area(player::player_ped_id(), Var1, Var1.f_3, Var1.f_6, 0, 1, 0)) {
						if (!Global_1591201[player::player_id() /*602*/].f_507) {
							script::request_script("AM_MP_PROPERTY_INT");
							if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
								system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
								script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
								gameplay::set_bit(&Global_1048576.f_8, 0);
								gameplay::set_bit(&Global_1590877.f_22, 12);
								return;
							}
							return;
						}
					}
				}
				if (gameplay::get_distance_between_coords(func_189(player::player_id()), func_112(6), 1) <= 30f) {
					func_111(&Var1, 6);
					if (entity::is_entity_in_angled_area(player::player_ped_id(), Var1, Var1.f_3, Var1.f_6, 0, 1, 0)) {
						if (!Global_1591201[player::player_id() /*602*/].f_507) {
							script::request_script("AM_MP_PROPERTY_INT");
							if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
								system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
								script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
								gameplay::set_bit(&Global_1048576.f_8, 0);
								gameplay::set_bit(&Global_1590877.f_22, 12);
								return;
							}
							return;
						}
					}
				}
				if (gameplay::get_distance_between_coords(func_189(player::player_id()), func_112(10), 1) <= 30f) {
					func_111(&Var1, 10);
					if (entity::is_entity_in_angled_area(player::player_ped_id(), Var1, Var1.f_3, Var1.f_6, 0, 1, 0)) {
						if (!Global_1591201[player::player_id() /*602*/].f_507) {
							script::request_script("AM_MP_PROPERTY_INT");
							if (script::has_script_loaded("AM_MP_PROPERTY_INT")) {
								system::start_new_script("AM_MP_PROPERTY_INT", iVar0);
								script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
								gameplay::set_bit(&Global_1048576.f_8, 0);
								gameplay::set_bit(&Global_1590877.f_22, 12);
								return;
							}
							return;
						}
					}
				}
				Global_1048576.f_845++;
				if (Global_1048576.f_845 > 115 || gameplay::is_bit_set(Global_1048576.f_8, 10)) {
					Global_1048576.f_845 = 0;
					Global_1048576.f_847 = 0;
					if (gameplay::is_bit_set(Global_1048576.f_8, 10)) {
						gameplay::clear_bit(&Global_1048576.f_8, 10);
					}
					if (Global_2443905.f_1.f_2824.f_13 != 0) {
						if (!func_110() && !func_196() && !network::network_is_in_transition()) {
							if (!func_109() && !func_108() && !func_195()) {
								if (!func_107() && !func_106() && !func_105()) {
									if (!func_203()) {
										if (!func_104()) {
											if (!Global_2443905.f_2842.f_157) {
												func_103();
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

// Position - 0x3AE3
void func_103() {
	Global_2443905.f_1.f_2824.f_13 = 0;
	Global_2443905.f_1.f_2824 = 0;
	Global_2443905.f_1.f_2824.f_1 = 0;
	Global_2443905.f_1.f_2824.f_2 = 0;
	Global_2443905.f_1.f_2824.f_3 = 0;
	Global_2443905.f_1.f_2824.f_4 = 0;
	Global_2443905.f_1.f_2824.f_5 = 0;
	Global_2443905.f_1.f_2824.f_6 = 0;
	Global_2443905.f_1.f_2824.f_7 = 0;
	Global_2443905.f_1.f_2824.f_8 = 0;
	Global_2443905.f_1.f_2824.f_9 = 0;
	Global_2443905.f_1.f_2824.f_10 = 0;
	Global_2443905.f_1.f_2824.f_11 = 0;
	Global_2443905.f_1.f_2824.f_12 = 0;
}

// Position - 0x3B91
bool func_104() { return Global_2443134.f_626; }

// Position - 0x3BA0
bool func_105() { return gameplay::is_bit_set(Global_2443134, 20); }

// Position - 0x3BB2
bool func_106() { return gameplay::is_bit_set(Global_2443134, 2); }

// Position - 0x3BC3
bool func_107() { return gameplay::is_bit_set(Global_2443134, 1); }

// Position - 0x3BD4
bool func_108() { return Global_1742351.f_3; }

// Position - 0x3BE2
bool func_109() { return Global_2443134.f_618; }

// Position - 0x3BF1
bool func_110() { return Global_2443134.f_571; }

// Position - 0x3C00
struct<8> func_111(var *uParam0, int iParam1) {
	switch (iParam1) {
	case 2:
		*uParam0 = {175.0434f, -998.7965f, -100.2256f};
		uParam0->f_3 = {175.0878f, -1009.004f, -95.99992f};
		uParam0->f_6 = 14f;
		break;

	case 6:
		*uParam0 = {212.9084f, -999.6776f, -99.99996f};
		uParam0->f_3 = {189.6844f, -1000.068f, -95.2507f};
		uParam0->f_6 = 16.75f;
		break;

	case 10:
		*uParam0 = {230.0094f, -1009.124f, -100.6539f};
		uParam0->f_3 = {230.5939f, -964.022f, -94.53618f};
		uParam0->f_6 = 23.5f;
		break;
	}
	return *uParam0;
}

// Position - 0x3CC2
Vector3
func_112(int iParam0) {
	vector3 vVar0;

	switch (iParam0) {
	case 2: vVar0 = {172.7787f, -1003.21f, -99.9999f}; break;

	case 6: vVar0 = {198.6071f, -1000.536f, -100f}; break;

	case 10: vVar0 = {227.8602f, -991.1093f, -99.9999f}; break;
	}
	return vVar0;
}

// Position - 0x3D29
bool func_113(var *uParam0, int iParam1, float fParam2) {
	vector3 vVar0;

	if (iParam1 == 2 && !func_114(uParam0->f_31, -1)) {
		if (gameplay::get_distance_between_coords(func_189(player::player_id()), uParam0->f_1742.f_148, 1) <= 30f) {
			if (object::is_point_in_angled_area(func_189(player::player_id()), uParam0->f_1742.f_151,
												uParam0->f_1742.f_151.f_3, uParam0->f_1742.f_151.f_6, 0, 1)) {
				return true;
			}
		}
	}
	else {
		vVar0 = {func_189(player::player_id())};
		if (gameplay::get_distance_between_coords(func_189(player::player_id()), uParam0->f_146.f_47, 1) <= 40f) {
			if (object::is_point_in_angled_area(func_189(player::player_id()), uParam0->f_146.f_57[0 /*8*/],
												uParam0->f_146.f_57[0 /*8*/].f_3, uParam0->f_146.f_57[0 /*8*/].f_6, 0,
												1) ||
				object::is_point_in_angled_area(func_189(player::player_id()), uParam0->f_146.f_57[1 /*8*/],
												uParam0->f_146.f_57[1 /*8*/].f_3, uParam0->f_146.f_57[1 /*8*/].f_6, 0,
												1) ||
				object::is_point_in_angled_area(func_189(player::player_id()), uParam0->f_146.f_57[2 /*8*/],
												uParam0->f_146.f_57[2 /*8*/].f_3, uParam0->f_146.f_57[2 /*8*/].f_6, 0,
												1)) {
				return true;
			}
			else if (gameplay::get_distance_between_coords(vVar0, uParam0->f_146.f_1592, 1) <
						 uParam0->f_146.f_1595 + fParam2 &&
					 vVar0.z > uParam0->f_146.f_57[2 /*8*/].f_2 && vVar0.z < uParam0->f_146.f_57[2 /*8*/].f_3.f_2) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x3EBF
int func_114(int iParam0, int iParam1) {
	if (iParam1 == -1) {
		switch (iParam0) {
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96:
		case 97:
		case 98:
		case 99:
		case 100:
		case 101:
		case 102: return 1;
		}
	}
	else if (iParam1 == 91) {
		switch (iParam0) {
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96: return 1;
		}
	}
	else if (iParam1 == 97) {
		switch (iParam0) {
		case 97:
		case 98:
		case 99:
		case 100:
		case 101:
		case 102: return 1;
		}
	}
	return 0;
}

// Position - 0x3F9C
Vector3 func_115(int iParam0) {
	vector3 vVar0;
	vector3 vVar6;

	switch (iParam0) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
		func_116(iParam0, 3, &vVar0, -1, 0);
		vVar6 = {vVar0};
		break;

	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 66:
	case 67:
	case 68:
	case 69: vVar6 = {348.132f, -997.2031f, -100.1741f}; break;

	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 70:
	case 71:
	case 72: vVar6 = {264.3808f, -997.7274f, -100.0087f}; break;

	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
		func_116(iParam0, 3, &vVar0, 61, 0);
		vVar6 = {vVar0};
		break;

	case 73:
	case 74:
	case 75:
	case 76:
		func_116(iParam0, 3, &vVar0, 73, 0);
		vVar6 = {vVar0};
		break;

	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
		func_116(iParam0, 3, &vVar0, 77, 0);
		vVar6 = {vVar0};
		break;

	case 83:
	case 84:
	case 85:
		func_116(iParam0, 3, &vVar0, 83, 0);
		vVar6 = {vVar0};
		break;

	case 86:
		func_116(iParam0, 3, &vVar0, 86, 0);
		vVar6 = {vVar0};
		break;

	case 87:
	case 88:
	case 89:
	case 90:
		func_116(iParam0, 3, &vVar0, 88, 0);
		vVar6 = {vVar0};
		break;

	case 91:
	case 92:
	case 93:
	case 94:
	case 95:
	case 96:
		func_116(iParam0, 3, &vVar0, 91, 0);
		vVar6 = {vVar0};
		break;

	case 97:
	case 98:
	case 99:
	case 100:
	case 101:
	case 102:
		func_116(iParam0, 3, &vVar0, 97, 0);
		vVar6 = {vVar0};
		break;
	}
	return vVar6;
}

// Position - 0x42C8
void func_116(int iParam0, int iParam1, var *uParam2, int iParam3, int iParam4) {
	struct<6> Var0[2];
	vector3 vVar13;

	Var0[0 /*6*/] = {func_120(iParam3, iParam4)};
	Var0[1 /*6*/] = {func_120(iParam0, iParam4)};
	*uParam2 = {func_118(iParam1, iParam3)};
	vVar13 = {*uParam2 - Var0[0 /*6*/]};
	vVar13 = {func_117(vVar13, -Var0[0 /*6*/].f_3.f_2)};
	vVar13 = {func_117(vVar13, Var0[1 /*6*/].f_3.f_2)};
	*uParam2 = {object::_get_object_offset_from_coords(Var0[1 /*6*/], 0f, vVar13)};
	switch (iParam1) {
	case 6:
	case 2:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 34:
	case 35:
	case 36:
	case 38:
	case 39:
	case 120:
	case 121:
	case 125:
	case 40:
	case 41:
	case 43:
	case 44:
	case 45:
	case 42:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56:
	case 64:
	case 65:
	case 57:
	case 58:
	case 59:
	case 60:
	case 61:
	case 62:
	case 63:
	case 66:
	case 67:
	case 68:
	case 109:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
	case 83:
	case 85:
	case 84:
	case 89:
	case 90:
	case 91:
	case 92:
	case 94:
	case 95:
	case 96:
	case 97:
	case 98:
	case 93:
	case 99:
	case 100:
	case 106:
	case 107:
	case 108:
	case 119:
	case 122:
	case 123:
	case 124:
	case 138:
	case 139:
	case 140:
	case 130:
	case 128:
	case 141:
	case 142:
	case 143:
	case 144:
	case 145:
	case 146:
	case 147:
	case 148:
	case 153:
	case 154:
	case 155:
	case 157:
	case 234:
	case 174:
	case 175:
	case 176:
	case 177:
	case 178:
	case 179:
	case 180:
	case 235:
	case 149:
	case 150:
	case 151:
	case 152:
	case 172:
	case 187:
	case 173:
	case 201:
	case 188:
	case 189:
	case 190:
	case 191:
	case 192:
	case 193:
	case 194:
	case 195:
	case 196:
	case 197:
	case 198:
	case 199:
	case 200:
	case 284:
	case 285:
	case 286:
	case 287:
	case 202:
	case 203:
	case 204:
	case 205:
	case 206:
	case 207:
	case 208:
	case 209:
	case 210:
	case 211:
	case 212:
	case 213:
	case 214:
	case 216:
	case 217:
	case 182:
	case 183:
	case 181:
	case 156:
	case 236:
	case 237:
	case 238:
	case 239:
	case 240:
	case 241:
	case 242:
	case 243:
	case 244:
	case 245:
	case 246:
	case 247:
	case 248:
	case 249:
	case 250:
	case 251:
	case 252:
	case 253:
	case 254:
	case 255:
	case 256:
	case 257:
	case 258:
	case 259:
	case 260:
	case 261:
	case 262:
	case 263:
	case 264:
	case 265:
	case 266:
	case 267:
	case 268:
	case 269:
	case 270:
	case 271:
	case 272:
	case 273:
	case 274:
	case 275:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
	switch (iParam1) {
	case 278:
	case 279:
	case 280:
	case 281:
	case 282:
	case 283:
	case 300:
	case 301:
	case 302:
	case 303:
	case 304:
	case 306:
	case 305:
	case 308:
	case 309:
	case 312:
	case 313:
	case 314:
	case 315:
	case 316:
	case 317:
	case 318:
	case 319:
	case 320:
	case 321:
	case 322:
	case 323:
	case 324:
	case 325:
	case 326:
	case 327:
	case 328:
	case 329:
	case 307:
	case 331:
	case 332:
	case 333:
	case 334:
	case 310:
	case 335:
	case 336:
	case 337:
	case 338:
	case 339:
	case 311:
	case 340:
	case 435:
	case 436:
	case 437:
	case 470:
	case 477:
	case 504:
	case 507:
	case 510:
	case 513:
	case 528:
	case 531:
	case 534:
	case 537:
	case 540:
	case 547:
	case 445:
	case 446:
	case 447:
	case 448:
	case 449:
	case 450:
	case 471:
	case 472:
	case 478:
	case 479:
	case 505:
	case 506:
	case 508:
	case 509:
	case 511:
	case 512:
	case 514:
	case 515:
	case 529:
	case 530:
	case 532:
	case 533:
	case 535:
	case 536:
	case 538:
	case 539:
	case 541:
	case 542:
	case 548:
	case 549:
	case 432:
	case 433:
	case 434:
	case 451:
	case 452:
	case 453:
	case 454:
	case 455:
	case 456:
	case 459:
	case 460:
	case 461:
	case 462:
	case 463:
	case 464:
	case 560:
	case 546:
	case 587:
	case 588:
	case 589:
	case 590:
	case 591:
	case 592:
	case 501:
	case 502:
	case 500:
	case 616:
	case 615:
	case 612:
	case 629:
	case 630:
	case 631:
	case 714:
	case 633:
	case 634:
	case 635:
	case 636:
	case 637:
	case 638:
	case 639:
	case 640:
	case 643:
	case 644:
	case 641:
	case 642:
	case 646:
	case 645:
	case 647:
	case 648:
	case 649:
	case 650:
	case 666:
	case 667:
	case 668:
	case 669:
	case 670:
	case 671:
	case 673:
	case 674:
	case 675:
	case 676:
	case 677:
	case 689:
	case 690:
	case 691:
	case 692:
	case 693:
	case 694:
	case 695:
	case 696:
	case 697:
	case 698:
	case 699:
	case 700:
	case 701:
	case 702:
	case 703:
	case 704:
	case 705:
	case 706:
	case 707:
	case 708:
	case 709:
	case 710:
	case 711:
	case 712:
	case 713:
	case 632:
	case 738:
	case 739:
	case 740:
	case 741:
	case 742:
	case 743:
	case 744:
	case 745:
	case 746:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
	switch (iParam1) {
	case 715:
	case 716:
	case 717:
	case 718:
	case 719:
	case 720:
	case 721:
	case 722:
	case 723:
	case 724:
	case 725:
	case 726:
	case 727:
	case 728:
	case 729:
	case 730:
	case 731:
	case 732:
	case 733:
	case 734:
	case 735:
	case 736:
	case 737:
	case 747:
	case 748:
	case 749:
	case 750:
	case 751:
	case 752:
	case 753:
	case 754:
	case 755:
	case 756:
	case 757:
	case 758:
	case 759:
	case 760:
	case 761:
	case 762:
	case 763:
	case 764:
	case 765:
	case 766:
	case 767:
	case 768:
	case 769:
	case 770:
	case 771:
	case 772:
	case 773:
	case 774:
	case 775:
	case 776:
	case 777:
	case 778:
	case 779:
	case 780:
	case 781:
	case 782:
	case 783:
	case 784:
	case 785:
	case 786:
	case 787:
	case 788:
	case 789:
	case 790:
	case 791:
	case 792:
	case 793:
	case 794:
	case 795:
	case 796:
	case 797:
	case 798:
	case 799:
	case 800:
	case 802:
	case 801:
	case 803:
	case 804:
	case 805:
	case 806:
	case 807:
	case 808:
	case 809:
	case 678:
	case 679:
	case 680:
	case 681:
	case 682:
	case 683:
	case 684:
	case 685:
	case 810:
	case 811:
	case 812:
	case 813:
	case 814:
	case 815:
	case 817:
	case 816:
	case 819:
	case 818:
	case 820:
	case 821:
	case 822:
	case 823:
	case 824:
	case 825:
	case 826:
	case 827:
	case 828:
	case 829:
	case 830:
	case 831:
	case 832:
	case 833:
	case 834:
	case 835:
	case 836:
	case 837:
	case 838:
	case 839:
	case 840:
	case 841:
	case 842:
	case 843:
	case 844:
	case 845:
	case 846:
	case 847:
	case 848:
	case 849:
	case 850:
	case 851:
	case 852:
	case 853:
	case 854:
	case 855:
	case 856:
	case 686:
	case 687:
	case 688:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
	switch (iParam1) {
	case 857:
	case 858:
	case 859:
	case 860:
	case 861:
	case 862:
	case 863:
	case 864:
	case 865:
	case 866:
	case 867:
	case 868:
	case 869:
	case 870:
	case 871:
	case 872:
	case 873:
	case 874:
	case 875:
	case 876:
	case 877:
	case 878:
	case 879:
	case 880:
	case 881:
	case 882:
	case 883:
	case 884:
	case 888:
	case 889:
	case 890:
	case 891:
	case 651:
	case 652:
	case 653:
	case 654:
	case 655:
	case 656:
	case 657:
	case 658:
	case 659:
	case 660:
	case 661:
	case 662:
	case 663:
	case 664:
	case 665:
	case 887:
	case 894:
	case 895:
	case 896:
	case 897:
	case 898:
	case 899:
	case 900:
	case 901:
	case 902:
	case 903:
	case 904:
	case 905:
	case 906:
	case 907:
	case 908:
	case 911:
	case 913:
	case 914:
	case 915:
	case 916:
	case 917:
	case 918:
	case 919:
	case 920:
	case 921:
	case 922:
	case 923:
	case 924:
	case 925:
	case 926:
	case 927:
	case 928:
	case 929:
	case 930:
	case 931:
	case 932:
	case 954:
	case 955:
	case 956:
	case 957:
	case 958:
	case 959:
	case 968:
	case 969:
	case 970:
	case 971:
	case 972:
	case 973:
	case 974:
	case 975:
	case 976:
	case 977:
	case 978:
	case 979:
	case 980:
	case 981:
	case 982:
	case 983:
	case 984:
	case 985:
	case 986:
	case 987:
	case 988:
	case 989:
	case 990:
	case 1008:
	case 1009:
	case 1010:
	case 991:
	case 992:
	case 993:
	case 994:
	case 995:
	case 996:
	case 997:
	case 998:
	case 999:
	case 960:
	case 961:
	case 962:
	case 963:
	case 964:
	case 965:
	case 966:
	case 967:
	case 1000:
	case 1001:
	case 1002:
	case 1003:
	case 1004:
	case 1005:
	case 1006:
	case 1007:
	case 1011:
	case 1012:
	case 1013:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
}

// Position - 0x578E
Vector3 func_117(vector3 vParam0, float fParam3) {
	vector3 vVar0;
	float fVar3;
	float fVar4;

	fVar3 = system::sin(fParam3);
	fVar4 = system::cos(fParam3);
	vVar0.x = vParam0.x * fVar4 - vParam0.y * fVar3;
	vVar0.y = vParam0.x * fVar3 + vParam0.y * fVar4;
	vVar0.z = vParam0.z;
	return vVar0;
}

// Position - 0x57D2
struct<6> func_118(var uParam0, int iParam1) {
	struct<6> Var0;
	var *uVar6;
	int iVar23;

	iVar23 = 0;
	if (func_119(iParam1, &uVar6)) {
		iVar23 = 1;
	}
	if (iVar23 && gameplay::_0xB335F761606DB47C(&Var0, &Var0.f_3, uParam0, uVar6)) {
		return Var0;
	}
	return Var0;
}

//Position - 0x5814
bool func_119(int iParam0, var* uParam1)
{
	switch (iParam0) {
	case -1:
	case 1:
		*uParam1 = 0;
		StringCopy(&uParam1->f_1, "BaseElementLocationsMap", 64);
		return true;

	case 61:
		*uParam1 = 1;
		StringCopy(&uParam1->f_1, "BaseElementLocationsMap_HighApt", 64);
		return true;

	case 73:
		*uParam1 = 2;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap1", 64);
		return true;

	case 77:
		*uParam1 = 3;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap2", 64);
		return true;

	case 83:
		*uParam1 = 4;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap3", 64);
		return true;

	case 86:
		*uParam1 = 5;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap4", 64);
		return true;

	case 88:
		*uParam1 = 6;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap5", 64);
		return true;

	case 91:
		*uParam1 = 7;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap6", 64);
		return true;

	case 97:
		*uParam1 = 8;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap7", 64);
		return true;

	case 109:
		*uParam1 = 9;
		StringCopy(&uParam1->f_1, "ExtraBaseElementLocMap8", 64);
		return true;
	}
	return false;
}

// Position - 0x5936
struct<6> func_120(int iParam0, int iParam1) {
	struct<6> Var0;

	switch (iParam0) {
	case -1:
		Var0 = {-794.9184f, 339.6266f, 200.4135f};
		Var0.f_3 = {0f, 0f, 180f};
		break;

	case 1:
		Var0 = {-794.9184f, 339.6266f, 200.4135f};
		Var0.f_3 = {0f, 0f, 180f};
		break;

	case 2:
		Var0 = {-761.0982f, 317.6259f, 169.5963f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 3:
		Var0 = {-761.1888f, 317.6295f, 216.0503f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 4:
		Var0 = {-795.3856f, 340.0188f, 152.7941f};
		Var0.f_3 = {0f, 0f, 180f};
		break;

	case 61:
		Var0 = {-778.5056f, 332.3779f, 212.1968f};
		Var0.f_3 = {0f, 0f, 90f};
		break;

	case 5:
		Var0 = {-258.1807f, -950.6853f, 70.0239f};
		Var0.f_3 = {0f, 0f, 70f};
		break;

	case 6:
		Var0 = {-285.0051f, -957.6552f, 85.3035f};
		Var0.f_3 = {0f, 0f, -110f};
		break;

	case 7:
		Var0 = {-1471.882f, -530.7484f, 62.34918f};
		Var0.f_3 = {0f, 0f, -145f};
		break;

	case 34:
		Var0 = {-1471.882f, -530.7484f, 49.72156f};
		Var0.f_3 = {0f, 0f, -145f};
		break;

	case 62:
		Var0 = {-1463.15f, -540.2369f, 74.2439f};
		Var0.f_3 = {0f, 0f, -145f};
		break;

	case 35:
		Var0 = {-885.3702f, -451.4775f, 119.327f};
		Var0.f_3 = {0f, 0f, 27.55617f};
		break;

	case 36:
		Var0 = {-913.0385f, -438.4284f, 114.3997f};
		Var0.f_3 = {0f, 0f, -153.3093f};
		break;

	case 37:
		Var0 = {-892.5499f, -430.4789f, 88.25368f};
		Var0.f_3 = {0f, 0f, 116.9193f};
		break;

	case 38:
		Var0 = {-35.0462f, -576.317f, 82.90739f};
		Var0.f_3 = {0f, 0f, 160f};
		break;

	case 39:
		Var0 = {-10.3788f, -590.7431f, 93.02542f};
		Var0.f_3 = {0f, 0f, 70f};
		break;

	case 65:
		Var0 = {-22.2487f, -589.1461f, 80.2305f};
		Var0.f_3 = {0f, 0f, 69.88f};
		break;

	case 40:
		Var0 = {-900.6311f, -376.7462f, 78.27306f};
		Var0.f_3 = {0f, 0f, 26.92611f};
		break;

	case 41:
		Var0 = {-929.483f, -374.5104f, 102.2329f};
		Var0.f_3 = {0f, 0f, -152.5531f};
		break;

	case 63:
		Var0 = {-914.4202f, -375.8189f, 114.4743f};
		Var0.f_3 = {0f, 0f, -63f};
		break;

	case 42:
		Var0 = {-617.1647f, 64.6042f, 100.8196f};
		Var0.f_3 = {0f, 0f, 180f};
		break;

	case 43:
		Var0 = {-584.2015f, 42.7133f, 86.4187f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 64:
		Var0 = {-609.5665f, 50.2203f, 98.3998f};
		Var0.f_3 = {0f, 0f, -90f};
		break;

	case 73:
		Var0 = {-171.3969f, 494.2671f, 134.4935f};
		Var0.f_3 = {0f, 0f, 11f};
		break;

	case 74:
		Var0 = {339.4982f, 434.0887f, 146.2206f};
		Var0.f_3 = {0f, 0f, -63.5f};
		break;

	case 75:
		Var0 = {-761.3884f, 615.7333f, 140.9805f};
		Var0.f_3 = {0f, 0f, -71.5f};
		break;

	case 76:
		Var0 = {-678.1752f, 591.0076f, 142.2196f};
		Var0.f_3 = {0f, 0f, 40.5f};
		break;

	case 77:
		Var0 = {120.0541f, 553.793f, 181.0943f};
		Var0.f_3 = {0f, 0f, 6f};
		break;

	case 78:
		Var0 = {-571.4039f, 655.2008f, 142.6293f};
		Var0.f_3 = {0f, 0f, -14.5f};
		break;

	case 79:
		Var0 = {-742.2565f, 587.6547f, 143.0577f};
		Var0.f_3 = {0f, 0f, -29f};
		break;

	case 80:
		Var0 = {-857.2222f, 685.051f, 149.6502f};
		Var0.f_3 = {0f, 0f, 4.5f};
		break;

	case 81:
		Var0 = {-1287.65f, 443.2707f, 94.6919f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 82:
		Var0 = {374.2012f, 416.9688f, 142.6977f};
		Var0.f_3 = {0f, 0f, -14f};
		break;

	case 83:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = {0f, 0f, 90f};
		break;

	case 84:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = {0f, 0f, 90f};
		break;

	case 85:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = {0f, 0f, -90f};
		break;

	case 86:
		Var0 = {-1573.098f, -4085.806f, 9.7851f};
		Var0.f_3 = {0f, 0f, 162f};
		break;

	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 66:
	case 67:
	case 68:
	case 69:
		Var0 = {342.8157f, -997.4288f, -100f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 70:
	case 71:
	case 72:
		Var0 = {260.3297f, -997.4288f, -100f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 87:
		Var0 = {-1572.187f, -570.8315f, 109.9879f};
		Var0.f_3 = {0f, 0f, -54f};
		break;

	case 88:
		Var0 = {-1383.954f, -476.7112f, 73.507f};
		Var0.f_3 = {0f, 0f, 8f};
		break;

	case 89:
		Var0 = {-138.0029f, -629.739f, 170.2854f};
		Var0.f_3 = {0f, 0f, -84f};
		break;

	case 90:
		Var0 = {-74.8895f, -817.6883f, 244.8508f};
		Var0.f_3 = {0f, 0f, 70f};
		break;

	case 91:
	case 92:
	case 93:
	case 94:
	case 95:
	case 96:
		Var0 = {1100.764f, -3159.384f, -34.9342f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 97:
	case 98:
	case 99:
	case 100:
	case 101:
	case 102:
		Var0 = {1005.806f, -3157.67f, -36.0897f};
		Var0.f_3 = {0f, 0f, 0f};
		break;

	case 103:
		if (!iParam1) {
			Var0 = {-1576.571f, -569.7595f, 85.5f};
			Var0.f_3 = {0f, 0f, 36.1f};
		}
		else {
			Var0 = {-1578.022f, -576.4251f, 104.2f};
			Var0.f_3 = {0f, 0f, -144.04f};
		}
		break;

	case 104:
		if (!iParam1) {
			Var0 = {-1571.254f, -566.5865f, 85.5f};
			Var0.f_3 = {0f, 0f, -53.9f};
		}
		else {
			Var0 = {-1578.022f, -576.4251f, 104.2f};
			Var0.f_3 = {0f, 0f, -144.04f};
		}
		break;

	case 105:
		if (!iParam1) {
			Var0 = {-1568.098f, -571.9171f, 85.5f};
			Var0.f_3 = {0f, 0f, -143.9f};
		}
		else {
			Var0 = {-1578.022f, -576.4251f, 104.2f};
			Var0.f_3 = {0f, 0f, -144.04f};
		}
		break;

	case 106:
		if (!iParam1) {
			Var0 = {-1384.518f, -475.8657f, 56.1f};
			Var0.f_3 = {0f, 0f, 98.7f};
		}
		else {
			Var0 = {-1391.245f, -473.9638f, 77.2f};
			Var0.f_3 = {0f, 0f, 98.86f};
		}
		break;

	case 107:
		if (!iParam1) {
			Var0 = {-1384.538f, -475.8829f, 48.1f};
			Var0.f_3 = {0f, 0f, 98.7f};
		}
		else {
			Var0 = {-1391.245f, -473.9638f, 77.2f};
			Var0.f_3 = {0f, 0f, 98.86f};
		}
		break;

	case 108:
		if (!iParam1) {
			Var0 = {-1378.994f, -477.2481f, 56.1f};
			Var0.f_3 = {0f, 0f, -81.1f};
		}
		else {
			Var0 = {-1391.245f, -473.9638f, 77.2f};
			Var0.f_3 = {0f, 0f, 98.86f};
		}
		break;

	case 109:
		if (!iParam1) {
			Var0 = {-186.5683f, -576.4624f, 135f};
			Var0.f_3 = {0f, 0f, 96.16f};
		}
		else {
			Var0 = {-146.6167f, -596.6301f, 166f};
			Var0.f_3 = {0f, 0f, -140f};
		}
		break;

	case 110:
		if (!iParam1) {
			Var0 = {-113.886f, -564.3862f, 135f};
			Var0.f_3 = {0f, 0f, 110.96f};
		}
		else {
			Var0 = {-146.6167f, -596.6301f, 166f};
			Var0.f_3 = {0f, 0f, -140f};
		}
		break;

	case 111:
		if (!iParam1) {
			Var0 = {-134.6568f, -635.1774f, 135f};
			Var0.f_3 = {0f, 0f, -9.04f};
		}
		else {
			Var0 = {-146.6167f, -596.6301f, 166f};
			Var0.f_3 = {0f, 0f, -140f};
		}
		break;

	case 112:
		if (!iParam1) {
			Var0 = {-79.0479f, -822.6393f, 221f};
			Var0.f_3 = {0f, 0f, 70f};
		}
		else {
			Var0 = {-73.904f, -821.6204f, 284f};
			Var0.f_3 = {0f, 0f, -110f};
		}
		break;

	case 113:
		if (!iParam1) {
			Var0 = {-70.3086f, -819.5784f, 221f};
			Var0.f_3 = {0f, 0f, 160f};
		}
		else {
			Var0 = {-73.904f, -821.6204f, 284f};
			Var0.f_3 = {0f, 0f, -110f};
		}
		break;

	case 114:
		if (!iParam1) {
			Var0 = {-79.9861f, -818.425f, 221f};
			Var0.f_3 = {0f, 0f, -20f};
		}
		else {
			Var0 = {-73.904f, -821.6204f, 284f};
			Var0.f_3 = {0f, 0f, -110f};
		}
		break;
	}
	return Var0;
}

//Position - 0x64EC
int func_121(int iParam0)
{
	switch (iParam0) {
	case 0: return 0;

	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66:
	case 67:
	case 68:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85:
	case 86:
	case 87:
	case 88:
	case 89:
	case 90:
	case 91:
	case 92:
	case 93:
	case 94:
	case 95:
	case 96:
	case 97:
	case 98:
	case 99:
	case 100:
	case 101:
	case 102: return 0;

	case 24:
	case 25:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 33:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56:
	case 57:
	case 58:
	case 59:
	case 60:
	case 103:
	case 104:
	case 105:
	case 106:
	case 107:
	case 108:
	case 109:
	case 110:
	case 111:
	case 112:
	case 113:
	case 114:
	case 115: return 1;

	default:
	}
	return 0;
}

// Position - 0x67C0
bool func_122() {
	if (func_124(Global_1048576.f_847)) {
		if (gameplay::get_distance_between_coords(func_189(player::player_id()),
												  Global_3934110[Global_1048576.f_847 /*2003*/].f_146.f_47, 1) <= 30f) {
			if (func_123(player::player_id(), 0, 0)) {
				if (!Global_2404994.f_2209 && !Global_2404994.f_2211) {
					return false;
				}
			}
			if (func_113(&Global_3934110[Global_1048576.f_847 /*2003*/], 1, 0)) {
				if (!Global_1591201[player::player_id() /*602*/].f_507) {
					return true;
				}
			}
		}
	}
	Global_1048576.f_847++;
	if (Global_1048576.f_847 >= 36) {
		Global_1048576.f_847 = -1;
	}
	return false;
}

// Position - 0x6881
bool func_123(int iParam0, int iParam1, int iParam2) {
	if (Global_2421664[iParam0 /*358*/].f_225 == 99) {
		if (iParam2 && Global_2421664[iParam0 /*358*/].f_228 == 0 || iParam2 == 0) {
			return false;
		}
	}
	if (iParam1) {
		if (Global_2421664[iParam0 /*358*/].f_225 == 13) {
			return false;
		}
	}
	return true;
}

// Position - 0x68D8
bool func_124(int iParam0) {
	if (func_125(iParam0)) {
		return Global_2501682.f_2[iParam0];
	}
	return false;
}

// Position - 0x68F7
bool func_125(int iParam0) {
	if (iParam0 > -1 && iParam0 < 36) {
		return true;
	}
	return false;
}

// Position - 0x6915
int func_126() {
	if (Global_1048576.f_847 == -1) {
		return 1;
	}
	return 0;
}

// Position - 0x692D
int func_127() {
	if (network::network_is_activity_session() && (func_196() || func_110() || func_195() && func_131() <= 21) &&
		func_128()) {
		return 1;
	}
	return 0;
}

// Position - 0x6973
bool func_128() {
	if (network::network_is_activity_session()) {
		return func_130();
	}
	return func_129(Global_1633501.f_88646);
}

// Position - 0x6997
bool func_129(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return false;
	}
	iVar0 = 0;
	while (iVar0 < 8) {
		if (Global_262145.f_5059[iVar0] == iParam0) {
			return true;
		}
		iVar0++;
	}
	return false;
}

// Position - 0x69D1
var func_130() { return Global_2443134.f_12; }

// Position - 0x69DF
int func_131() { return Global_1591201[player::player_id() /*602*/].f_188; }

// Position - 0x69F4
int func_132() {
	if (Global_2443905.f_5883 && !Global_2452989) {
		return 1;
	}
	return 0;
}

// Position - 0x6A15
int func_133(int iParam0, int iParam1, int iParam2) {
	if (iParam0 == func_725()) {
		return 0;
	}
	if (gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_13, 0)) {
		return 1;
	}
	if (iParam1) {
		if (gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_13, 1)) {
			return 1;
		}
	}
	if (iParam2) {
		if (Global_2421664[iParam0 /*358*/].f_312.f_1 != -1) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x6A7F
var func_134() { return Global_2443905.f_1.f_2838; }

// Position - 0x6A90
void func_135(var *uParam0, var *uParam1, char *sParam2) {
	vector3 vVar0;
	bool bVar6;

	vVar0 = {func_120(Global_1591072, 0)};
	if (Global_1049427[Global_1591072 /*1942*/].f_34 == 1) {
		bVar6 = false;
	}
	else {
		bVar6 = true;
	}
	if (bVar6) {
		if (!interior::is_valid_interior(*uParam0)) {
			if (gameplay::is_string_null_or_empty(sParam2)) {
				*uParam0 = interior::get_interior_at_coords(vVar0);
			}
			else {
				*uParam0 = interior::get_interior_at_coords_with_type(vVar0, sParam2);
			}
			if (interior::is_valid_interior(*uParam0)) {
				interior::_load_interior(*uParam0);
			}
			return;
		}
		else if (interior::is_interior_disabled(*uParam0)) {
			func_138(Global_1591072, 0, 0);
			if (gameplay::is_string_null_or_empty(sParam2)) {
				*uParam0 = interior::get_interior_at_coords(vVar0);
			}
			else {
				*uParam0 = interior::get_interior_at_coords_with_type(vVar0, sParam2);
			}
			if (interior::is_valid_interior(*uParam0)) {
				interior::_load_interior(*uParam0);
			}
			return;
		}
	}
	if (!interior::is_valid_interior(*uParam1)) {
		if (func_136(Global_1591072) == 10) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "hei_dlc_garage_high_new");
		}
		else if (func_136(Global_1591072) == 6) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "v_garagem");
		}
		else if (func_136(Global_1591072) == 2) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "v_garages");
		}
		if (interior::is_valid_interior(*uParam1)) {
			interior::_load_interior(*uParam1);
		}
		return;
	}
	else if (interior::is_interior_disabled(*uParam1)) {
		func_138(Global_1591072, 0, 0);
		if (func_136(Global_1591072) == 10) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "hei_dlc_garage_high_new");
		}
		else if (func_136(Global_1591072) == 6) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "v_garagem");
		}
		else if (func_136(Global_1591072) == 2) {
			*uParam1 = interior::get_interior_at_coords_with_type(Global_1049427[Global_1591072 /*1942*/].f_1742.f_20,
																  "v_garages");
		}
		if (interior::is_valid_interior(*uParam1)) {
			interior::_load_interior(*uParam1);
		}
		return;
	}
}

// Position - 0x6CB0
int func_136(int iParam0) {
	switch (func_137(iParam0)) {
	case 10: return 20;

	case 6:
	case 3: return 10;

	case 5:
	case 2: return 6;

	case 4:
	case 1: return 2;
	}
	return 0;
}

// Position - 0x6D0C
int func_137(int iParam0) {
	switch (iParam0) {
	case 86: return 8;

	case 103:
	case 106:
	case 109:
	case 112:
	case 104:
	case 107:
	case 110:
	case 113:
	case 105:
	case 108:
	case 111:
	case 114: return 10;

	case 87:
	case 88:
	case 89:
	case 90: return 9;

	case 91:
	case 92:
	case 93:
	case 94:
	case 95:
	case 96:
	case 97:
	case 98:
	case 99:
	case 100:
	case 101:
	case 102: return 7;

	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
	case 83:
	case 84:
	case 85: return 6;

	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 66:
	case 67:
	case 68:
	case 69: return 5;

	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 70:
	case 71:
	case 72: return 4;

	case 24:
	case 26:
	case 27:
	case 54:
	case 56:
	case 57: return 3;

	case 25:
	case 28:
	case 32:
	case 33:
	case 50:
	case 52:
	case 53:
	case 55: return 2;

	case 29:
	case 30:
	case 31:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 51:
	case 58:
	case 59:
	case 60: return 1;
	}
	return 0;
}

// Position - 0x7011
void func_138(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = func_137(iParam0);
	switch (iParam0) {
	case 103:
		if (iParam2) {
			func_144(121, iParam1);
			func_144(133, iParam1);
		}
		else {
			func_139(121, iParam1);
			func_139(133, iParam1);
		}
		break;

	case 104:
		if (iParam2) {
			func_144(122, iParam1);
			func_144(133, iParam1);
		}
		else {
			func_139(122, iParam1);
			func_139(133, iParam1);
		}
		break;

	case 105:
		if (iParam2) {
			func_144(123, iParam1);
			func_144(133, iParam1);
		}
		else {
			func_139(123, iParam1);
			func_139(133, iParam1);
		}
		break;

	case 106:
		if (iParam2) {
			func_144(124, iParam1);
			func_144(134, iParam1);
		}
		else {
			func_139(124, iParam1);
			func_139(134, iParam1);
		}
		break;

	case 107:
		if (iParam2) {
			func_144(125, iParam1);
			func_144(134, iParam1);
		}
		else {
			func_139(125, iParam1);
			func_139(134, iParam1);
		}
		break;

	case 108:
		if (iParam2) {
			func_144(126, iParam1);
			func_144(134, iParam1);
		}
		else {
			func_139(126, iParam1);
			func_139(134, iParam1);
		}
		break;

	case 109:
		if (iParam2) {
			func_144(127, iParam1);
			func_144(135, iParam1);
		}
		else {
			func_139(127, iParam1);
			func_139(135, iParam1);
		}
		break;

	case 110:
		if (iParam2) {
			func_144(128, iParam1);
			func_144(135, iParam1);
		}
		else {
			func_139(128, iParam1);
			func_139(135, iParam1);
		}
		break;

	case 111:
		if (iParam2) {
			func_144(129, iParam1);
			func_144(135, iParam1);
		}
		else {
			func_139(129, iParam1);
			func_139(135, iParam1);
		}
		break;

	case 112:
		if (iParam2) {
			func_144(130, iParam1);
			func_144(136, iParam1);
		}
		else {
			func_139(130, iParam1);
			func_139(136, iParam1);
		}
		break;

	case 113:
		if (iParam2) {
			func_144(131, iParam1);
			func_144(136, iParam1);
		}
		else {
			func_139(131, iParam1);
			func_139(136, iParam1);
		}
		break;

	case 114:
		if (iParam2) {
			func_144(132, iParam1);
			func_144(136, iParam1);
		}
		else {
			func_139(132, iParam1);
			func_139(136, iParam1);
		}
		break;
	}
	if (iVar0 == 6) {
		switch (iParam0) {
		case 1:
			if (iParam2) {
				func_144(25, iParam1);
			}
			else {
				func_139(25, iParam1);
			}
			break;

		case 2:
			if (iParam2) {
				func_144(26, iParam1);
			}
			else {
				func_139(26, iParam1);
			}
			break;

		case 3:
			if (iParam2) {
				func_144(27, iParam1);
			}
			else {
				func_139(27, iParam1);
			}
			break;

		case 4:
			if (iParam2) {
				func_144(28, iParam1);
			}
			else {
				func_139(28, iParam1);
			}
			break;

		case 5:
			if (iParam2) {
				func_144(29, iParam1);
			}
			else {
				func_139(29, iParam1);
			}
			break;

		case 6:
			if (iParam2) {
				func_144(30, iParam1);
			}
			else {
				func_139(30, iParam1);
			}
			break;

		case 7:
			if (iParam2) {
				func_144(31, iParam1);
			}
			else {
				func_139(31, iParam1);
			}
			break;

		case 34:
			if (iParam2) {
				func_144(32, iParam1);
			}
			else {
				func_139(32, iParam1);
			}
			break;

		case 35:
			if (iParam2) {
				func_144(33, iParam1);
			}
			else {
				func_139(33, iParam1);
			}
			break;

		case 36:
			if (iParam2) {
				func_144(34, iParam1);
			}
			else {
				func_139(34, iParam1);
			}
			break;

		case 37:
			if (iParam2) {
				func_144(35, iParam1);
			}
			else {
				func_139(35, iParam1);
			}
			break;

		case 38:
			if (iParam2) {
				func_144(36, iParam1);
			}
			else {
				func_139(36, iParam1);
			}
			break;

		case 39:
			if (iParam2) {
				func_144(37, iParam1);
			}
			else {
				func_139(37, iParam1);
			}
			break;

		case 40:
			if (iParam2) {
				func_144(38, iParam1);
			}
			else {
				func_139(38, iParam1);
			}
			break;

		case 41:
			if (iParam2) {
				func_144(39, iParam1);
			}
			else {
				func_139(39, iParam1);
			}
			break;

		case 42:
			if (iParam2) {
				func_144(40, iParam1);
			}
			else {
				func_139(40, iParam1);
			}
			break;

		case 43:
			if (iParam2) {
				func_144(41, iParam1);
			}
			else {
				func_139(41, iParam1);
			}
			break;

		case 73:
			if (iParam2) {
				func_144(49, iParam1);
			}
			else {
				func_139(49, iParam1);
			}
			break;

		case 74:
			if (iParam2) {
				func_144(50, iParam1);
			}
			else {
				func_139(50, iParam1);
			}
			break;

		case 75:
			if (iParam2) {
				func_144(51, iParam1);
			}
			else {
				func_139(51, iParam1);
			}
			break;

		case 76:
			if (iParam2) {
				func_144(52, iParam1);
			}
			else {
				func_139(52, iParam1);
			}
			break;

		case 77:
			if (iParam2) {
				func_144(53, iParam1);
			}
			else {
				func_139(53, iParam1);
			}
			break;

		case 78:
			if (iParam2) {
				func_144(54, iParam1);
			}
			else {
				func_139(54, iParam1);
			}
			break;

		case 79:
			if (iParam2) {
				func_144(55, iParam1);
			}
			else {
				func_139(55, iParam1);
			}
			break;

		case 80:
			if (iParam2) {
				func_144(56, iParam1);
			}
			else {
				func_139(56, iParam1);
			}
			break;

		case 81:
			if (iParam2) {
				func_144(57, iParam1);
			}
			else {
				func_139(57, iParam1);
			}
			break;

		case 82:
			if (iParam2) {
				func_144(58, iParam1);
			}
			else {
				func_139(58, iParam1);
			}
			break;
		}
	}
	else if (iVar0 == 5) {
		if (iParam2) {
			func_144(46, iParam1);
		}
		else {
			func_139(46, iParam1);
		}
	}
	else if (iVar0 == 4) {
	}
	if (Global_1049427[iParam0 /*1942*/].f_33 == 2) {
		if (iParam2) {
			func_144(12, iParam1);
		}
		else {
			func_139(12, iParam1);
		}
	}
	else if (Global_1049427[iParam0 /*1942*/].f_33 == 6) {
		if (iParam2) {
			func_144(13, iParam1);
		}
		else {
			func_139(13, iParam1);
		}
	}
	else if (Global_1049427[iParam0 /*1942*/].f_33 == 10) {
		if (iParam2) {
			func_144(14, iParam1);
		}
		else {
			func_139(14, iParam1);
		}
	}
}

// Position - 0x76A2
void func_139(int iParam0, int iParam1) {
	char *sVar0;
	int iVar1;

	sVar0 = "NULL";
	iVar1 = 0;
	sVar0 = func_142(iParam0, &iVar1);
	if (!gameplay::are_strings_equal("NONE", sVar0) && iVar1 != 0) {
		if (iParam1) {
			if (interior::is_interior_disabled(iVar1)) {
				return;
			}
			if (interior::get_interior_from_entity(player::player_ped_id()) == iVar1) {
				func_144(iParam0, 1);
				return;
			}
		}
		else {
			if (!interior::is_interior_disabled(iVar1)) {
				return;
			}
			if (func_140(iParam0)) {
				func_144(iParam0, 0);
			}
		}
		interior::disable_interior(iVar1, iParam1);
		if (iParam1) {
		}
	}
}

// Position - 0x772D
bool func_140(int iParam0) {
	struct<2> Var0;

	Var0 = {func_141(iParam0)};
	if (gameplay::is_bit_set(Global_31561[Var0.f_1], Var0)) {
		return true;
	}
	return false;
}

// Position - 0x7756
struct<2> func_141(var uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	struct<2> Var3;

	iVar0 = uParam0;
	iVar1 = 0;
	iVar2 = 0;
	Var3 = -1;
	Var3.f_1 = -1;
	while (iVar1 < 5) {
		iVar2 += 32;
		if (iVar0 < iVar2) {
			Var3.f_1 = iVar1;
			Var3 = iVar0 - Var3.f_1 * 32;
			return Var3;
		}
		iVar1++;
	}
	return Var3;
}

//Position - 0x77A8
var func_142(int iParam0, int iParam1)
{
	struct<5> Var0;

	Var0 = {func_143(iParam0)};
	*iParam1 = interior::get_interior_at_coords_with_type(Var0, Var0.f_3);
	return Var0.f_4;
}

// Position - 0x77CD
struct<5> func_143(int iParam0) {
	struct<5> Var0;
	vector3 vVar5;

	switch (iParam0) {
	case 0:
		Var0 = {-447.4833f, 280.3197f, 77.5215f};
		Var0.f_3 = "v_comedy";
		Var0.f_4 = Var0.f_3;
		break;

	case 1:
		Var0 = {-1906.786f, -573.7576f, 19.0773f};
		Var0.f_3 = "v_psycheoffice";
		Var0.f_4 = Var0.f_3;
		break;

	case 2:
		Var0 = {1399.973f, 1148.756f, 113.3336f};
		Var0.f_3 = "v_ranch";
		Var0.f_4 = Var0.f_3;
		break;

	case 3:
		Var0 = {-598.6379f, -1608.399f, 26.0108f};
		Var0.f_3 = "v_recycle";
		Var0.f_4 = Var0.f_3;
		break;

	case 4:
		Var0 = {-556.5089f, 286.3181f, 81.1763f};
		Var0.f_3 = "v_rockclub";
		Var0.f_4 = Var0.f_3;
		break;

	case 5:
		Var0 = {-111.7116f, -11.912f, 69.5196f};
		Var0.f_3 = "v_janitor";
		Var0.f_4 = Var0.f_3;
		break;

	case 6:
		Var0 = {1274.934f, -1714.726f, 53.7715f};
		Var0.f_3 = "v_lesters";
		Var0.f_4 = Var0.f_3;
		break;

	case 7:
		Var0 = {147.433f, -2201.37f, 3.688f};
		Var0.f_3 = "v_torture";
		Var0.f_4 = Var0.f_3;
		break;

	case 8:
		Var0 = {320.9934f, 265.2515f, 82.1221f};
		Var0.f_3 = "v_cinema";
		Var0.f_4 = "v_cinema (Vinewood)";
		break;

	case 9:
		Var0 = {-1425.564f, -244.3f, 15.8053f};
		Var0.f_3 = "v_cinema";
		Var0.f_4 = "v_cinema (Morningwood)";
		break;

	case 10:
		Var0 = {377.153f, -717.567f, 10.0536f};
		Var0.f_3 = "v_cinema";
		Var0.f_4 = "v_cinema (Downtown)";
		break;

	case 11:
		Var0 = {245.1564f, 370.211f, 104.7382f};
		Var0.f_3 = "v_epsilonism";
		Var0.f_4 = Var0.f_3;
		break;

	case 12:
		Var0 = {173.1176f, -1003.279f, -99.9999f};
		Var0.f_3 = "v_garages";
		Var0.f_4 = Var0.f_3;
		break;

	case 13:
		Var0 = {199.9715f, -999.6678f, -100f};
		Var0.f_3 = "v_garagem";
		Var0.f_4 = Var0.f_3;
		break;

	case 14:
		Var0 = {228.6058f, -992.0537f, -99.9999f};
		Var0.f_3 = "v_garagel";
		Var0.f_3 = "hei_dlc_garage_high_new";
		Var0.f_4 = Var0.f_3;
		break;

	case 15:
		Var0 = {1854.254f, 3686.739f, 33.2671f};
		Var0.f_3 = "v_sheriff";
		Var0.f_4 = Var0.f_3;
		break;

	case 16:
		Var0 = {-444.8907f, 6013.587f, 30.7164f};
		Var0.f_3 = "v_sheriff2";
		Var0.f_4 = Var0.f_3;
		break;

	case 17:
		Var0 = {3522.845f, 3707.965f, 19.9918f};
		Var0.f_3 = "v_lab";
		Var0.f_4 = Var0.f_3;
		break;

	case 18:
		Var0 = {717.2994f, -974.4271f, 23.9142f};
		Var0.f_3 = "v_sweat";
		Var0.f_4 = Var0.f_3;
		break;

	case 19:
		Var0 = {717.299f, -974.4271f, 23.9142f};
		Var0.f_3 = "v_sweatempty";
		Var0.f_4 = Var0.f_3;
		break;

	case 20:
		Var0 = {2449.785f, 4983.825f, 45.8106f};
		Var0.f_3 = "v_farmhouse";
		Var0.f_4 = Var0.f_3;
		break;

	case 22:
		Var0 = {1087.195f, -1988.445f, 28.649f};
		Var0.f_3 = "v_foundry";
		Var0.f_4 = Var0.f_3;
		break;

	case 23:
		Var0 = {982.233f, -2160.382f, 28.4761f};
		Var0.f_3 = "v_abattoir";
		Var0.f_4 = Var0.f_3;
		break;

	case 21:
		Var0 = {479.0568f, -1316.825f, 28.2038f};
		Var0.f_3 = "v_chopshop";
		Var0.f_4 = Var0.f_3;
		break;

	case 24:
		Var0 = {-1005.663f, -478.3461f, 49.0265f};
		Var0.f_3 = "v_58_sol_office";
		Var0.f_4 = Var0.f_3;
		break;

	case 25:
		vVar5 = {func_120(1, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (1)";
		break;

	case 26:
		vVar5 = {func_120(2, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (2)";
		break;

	case 27:
		vVar5 = {func_120(3, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (3)";
		break;

	case 28:
		vVar5 = {func_120(4, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (4)";
		break;

	case 29:
		vVar5 = {func_120(5, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (5)";
		break;

	case 30:
		vVar5 = {func_120(6, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (6)";
		break;

	case 31:
		vVar5 = {func_120(7, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (7)";
		break;

	case 32:
		Var0 = {Global_1049427[34 /*1942*/].f_146.f_1517 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (8)";
		break;

	case 33:
		vVar5 = {func_120(35, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (9)";
		break;

	case 34:
		vVar5 = {func_120(36, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (10)";
		break;

	case 35:
		vVar5 = {func_120(37, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (11)";
		break;

	case 36:
		vVar5 = {func_120(38, 0)};
		Var0 = {-20.1f, -580.8f, 91.3f};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (12)";
		break;

	case 37:
		vVar5 = {func_120(39, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (13)";
		break;

	case 38:
		vVar5 = {func_120(40, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (14)";
		break;

	case 39:
		vVar5 = {func_120(41, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (15)";
		break;

	case 40:
		vVar5 = {func_120(42, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (16)";
		break;

	case 41:
		vVar5 = {func_120(43, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (17)";
		break;

	case 42:
		Var0 = {-470.3754f, -698.5207f, 51.5276f};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (18)";
		break;

	case 43:
		Var0 = {-460.6133f, -691.5562f, 69.9067f};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (19)";
		break;

	case 44:
		Var0 = {300.633f, -997.4288f, -99.9727f};
		Var0.f_3 = "hei_dlc_apart_high_new";
		Var0.f_4 = "hei_dlc_apart_high_new (20)";
		break;

	case 49:
		Var0 = {-171.3969f, 494.2671f, 134.4935f};
		Var0.f_3 = "apa_v_mp_stilts_b";
		Var0.f_4 = "apa_v_mp_stilts_b (1)";
		break;

	case 50:
		Var0 = {339.4982f, 434.0887f, 146.2206f};
		Var0.f_3 = "apa_v_mp_stilts_b";
		Var0.f_4 = "apa_v_mp_stilts_b (2)";
		break;

	case 51:
		Var0 = {-761.3884f, 615.7333f, 140.9805f};
		Var0.f_3 = "apa_v_mp_stilts_b";
		Var0.f_4 = "apa_v_mp_stilts_b (3)";
		break;

	case 52:
		Var0 = {-678.1752f, 591.0076f, 142.2196f};
		Var0.f_3 = "apa_v_mp_stilts_b";
		Var0.f_4 = "apa_v_mp_stilts_b (4)";
		break;

	case 53:
		Var0 = {120.0541f, 553.793f, 181.0943f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (5)";
		break;

	case 54:
		Var0 = {-571.4039f, 655.2008f, 142.6293f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (7)";
		break;

	case 55:
		Var0 = {-742.2565f, 587.6547f, 143.0577f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (8)";
		break;

	case 56:
		Var0 = {-857.2222f, 685.051f, 149.6502f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (10)";
		break;

	case 57:
		Var0 = {-1287.65f, 443.2707f, 94.6919f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (12)";
		break;

	case 58:
		Var0 = {374.2012f, 416.9688f, 142.5991f};
		Var0.f_3 = "apa_v_mp_stilts_a";
		Var0.f_4 = "apa_v_mp_stilts_a (13)";
		break;

	case 45:
		Var0 = {-16.29585f, -684.0385f, 33.50832f};
		Var0.f_3 = "dt1_03_carpark";
		Var0.f_4 = "dt1_03_carpark";
		break;

	case 46:
		Var0 = {341.1f, -1000f, -99.2f};
		Var0.f_3 = "v_apart_midspaz";
		Var0.f_4 = "v_apart_midspaz";
		break;

	case 47:
		Var0 = {199.9716f, -1018.954f, -100f};
		Var0.f_3 = "v_garagem_sp";
		Var0.f_4 = Var0.f_3;
		break;

	case 48:
		Var0 = {-1388.001f, -618.4197f, 30.8196f};
		Var0.f_3 = "v_bahama";
		Var0.f_4 = Var0.f_3;
		break;
	}
	switch (iParam0) {
	case 59:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 60:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_02";
		Var0.f_4 = Var0.f_3;
		break;

	case 61:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_03";
		Var0.f_4 = Var0.f_3;
		break;

	case 62:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_04";
		Var0.f_4 = Var0.f_3;
		break;

	case 63:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_05";
		Var0.f_4 = Var0.f_3;
		break;

	case 64:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_06";
		Var0.f_4 = Var0.f_3;
		break;

	case 65:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_07";
		Var0.f_4 = Var0.f_3;
		break;

	case 66:
		Var0 = {-787.7805f, 334.9232f, 215.8384f};
		Var0.f_3 = "apa_v_mp_h_08";
		Var0.f_4 = Var0.f_3;
		break;

	case 67:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 68:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_02";
		Var0.f_4 = Var0.f_3;
		break;

	case 69:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_03";
		Var0.f_4 = Var0.f_3;
		break;

	case 70:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_04";
		Var0.f_4 = Var0.f_3;
		break;

	case 71:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_05";
		Var0.f_4 = Var0.f_3;
		break;

	case 72:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_06";
		Var0.f_4 = Var0.f_3;
		break;

	case 73:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_07";
		Var0.f_4 = Var0.f_3;
		break;

	case 74:
		Var0 = {-773.2258f, 322.8252f, 194.8862f};
		Var0.f_3 = "apa_v_mp_h_08";
		Var0.f_4 = Var0.f_3;
		break;

	case 75:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 76:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_02";
		Var0.f_4 = Var0.f_3;
		break;

	case 77:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_03";
		Var0.f_4 = Var0.f_3;
		break;

	case 78:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_04";
		Var0.f_4 = Var0.f_3;
		break;

	case 79:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_05";
		Var0.f_4 = Var0.f_3;
		break;

	case 80:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_06";
		Var0.f_4 = Var0.f_3;
		break;

	case 81:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_07";
		Var0.f_4 = Var0.f_3;
		break;

	case 82:
		Var0 = {-787.7805f, 334.9232f, 186.1134f};
		Var0.f_3 = "apa_v_mp_h_08";
		Var0.f_4 = Var0.f_3;
		break;

	case 83:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 84:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 85:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 86:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 87:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 88:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 89:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 90:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 91:
		vVar5 = {func_120(87, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 92:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 93:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 94:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 95:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 96:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 97:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 98:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 99:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 100:
		vVar5 = {func_120(88, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 101:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 102:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 103:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 104:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 105:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 106:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 107:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 108:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 109:
		vVar5 = {func_120(89, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 110:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 111:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 112:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_01c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 113:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 114:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 115:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_02c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 116:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03a_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 117:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03b_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 118:
		vVar5 = {func_120(90, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "ex_int_office_03c_dlc";
		Var0.f_4 = Var0.f_3;
		break;

	case 119:
		vVar5 = {func_120(91, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "bkr_biker_dlc_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 120:
		vVar5 = {func_120(97, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "bkr_biker_dlc_int_02";
		Var0.f_4 = Var0.f_3;
		break;

	case 121:
		vVar5 = {func_120(103, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 122:
		vVar5 = {func_120(104, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 123:
		vVar5 = {func_120(105, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 124:
		vVar5 = {func_120(106, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 125:
		vVar5 = {func_120(107, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 126:
		vVar5 = {func_120(108, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 127:
		vVar5 = {func_120(109, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 128:
		vVar5 = {func_120(110, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 129:
		vVar5 = {func_120(111, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 130:
		vVar5 = {func_120(112, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 131:
		vVar5 = {func_120(113, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 132:
		vVar5 = {func_120(114, 0)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_impexp_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 133:
		vVar5 = {func_120(103, 1)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_imptexp_mod_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 134:
		vVar5 = {func_120(106, 1)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_imptexp_mod_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 135:
		vVar5 = {func_120(109, 1)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_imptexp_mod_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	case 136:
		vVar5 = {func_120(112, 1)};
		Var0 = {vVar5 + Vector(1f, 0f, 0f)};
		Var0.f_3 = "imp_imptexp_mod_int_01";
		Var0.f_4 = Var0.f_3;
		break;

	default: break;
	}
	return Var0;
}

//Position - 0x908A
void func_144(int iParam0, int iParam1)
{
	struct<2> Var0;

	Var0 = {func_141(iParam0)};
	if (iParam1) {
		gameplay::set_bit(&Global_31561[Var0.f_1], Var0);
	}
	else {
		gameplay::clear_bit(&Global_31561[Var0.f_1], Var0);
	}
}

// Position - 0x90C2
bool func_145(int iParam0) {
	switch (iParam0) {
	case 61:
	case 62:
	case 63:
	case 64:
	case 65: return true;

	default:
	}
	return false;
}

// Position - 0x90F4
void func_146(int iParam0) {
	func_147();
	if (iParam0 == 0) {
		if (unk::_0xEF7D17BC6C85264C()) {
			return;
		}
	}
	if (func_148() == 0 || ui::is_pause_menu_active()) {
		func_100(1);
		graphics::_set_frozen_rendering_disabled(0);
		graphics::_set_frozen_rendering_disabled(0);
	}
}

// Position - 0x9135
void func_147() { Global_2454055 = 1; }

// Position - 0x9142
int func_148() { return Global_1312466.f_20; }

// Position - 0x9150
void func_149() {
	if (entity::does_entity_exist(Global_2453681)) {
		if (entity::does_entity_belong_to_this_script(Global_2453681, 0)) {
			if (!entity::is_entity_a_mission_entity(Global_2453681)) {
				entity::set_entity_as_mission_entity(Global_2453681, 0, 0);
			}
			ped::delete_ped(&Global_2453681);
		}
	}
}

// Position - 0x9190
void func_150() {
	if (entity::does_entity_exist(Global_1318015)) {
		if (entity::does_entity_belong_to_this_script(Global_1318015, 0)) {
			if (!entity::is_entity_a_mission_entity(Global_1318015)) {
				entity::set_entity_as_mission_entity(Global_1318015, 0, 0);
			}
			ped::delete_ped(&Global_1318015);
		}
	}
}

// Position - 0x91D3
void func_151(var *uParam0, vector3 vParam1, vector3 vParam4, float fParam7) {
	*uParam0 = cam::create_camera(26379945, 1);
	cam::set_cam_params(*uParam0, vParam1, vParam4, fParam7, 0, 1, 1, 2);
	cam::shake_cam(*uParam0, "HAND_SHAKE", 0.25f);
	cam::render_script_cams(1, 0, 3000, 1, 0, 0);
	cam::set_cam_far_clip(*uParam0, 500f);
}

// Position - 0x9225
bool func_152() {
	if (streaming::is_player_switch_in_progress()) {
		if (streaming::get_player_switch_type() != 3) {
			if (streaming::get_player_switch_state() >= 9) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x924A
bool func_153(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	vector3 vVar0;
	int iVar3;
	vector3 vVar4;
	var uVar7;
	var uVar8;
	vector3 vVar9;
	var uVar12;
	var uVar13;

	func_174();
	if (func_173()) {
		func_172(0);
	}
	if (player::is_player_teleport_active()) {
		player::stop_player_teleport();
		return false;
	}
	if (ui::is_pause_menu_active() == 1) {
		if (iParam1) {
			ui::set_frontend_active(0);
		}
		if (iParam3) {
			func_99(0);
		}
	}
	if (dlc2::get_is_loading_screen_active()) {
		if (Global_2453583 == 0) {
			if (streaming::is_player_switch_in_progress()) {
				streaming::stop_player_switch();
				return false;
			}
			if (streaming::is_new_load_scene_active() == 0) {
				if (entity::does_entity_exist(Global_1318015)) {
					if (streaming::is_entity_focus(Global_1318015)) {
						streaming::clear_focus();
					}
				}
				if (entity::does_entity_exist(player::player_ped_id())) {
					if (streaming::is_entity_focus(player::player_ped_id())) {
						streaming::clear_focus();
					}
				}
				if (streaming::new_load_scene_start_sphere(entity::get_entity_coords(player::player_ped_id(), 0), 100f,
														   0)) {
					Global_2453583 = 1;
					return false;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		else {
			if (streaming::is_new_load_scene_active() && streaming::is_new_load_scene_loaded()) {
				Global_2453583 = 0;
				func_2(0);
				return true;
			}
			return false;
		}
	}
	if (!streaming::_0x71E7B2E657449AAD()) {
		func_166();
		return false;
	}
	if (func_6() == 0) {
		return true;
	}
	if (func_6() == 1) {
		func_2(2);
		return false;
	}
	if (ped::is_ped_dead_or_dying(player::player_ped_id(), 1) || ped::is_ped_injured(player::player_ped_id())) {
		func_166();
		return false;
	}
	if (ui::is_pause_menu_active() == 0 || iParam1 == 0) {
		if (!func_230()) {
			if (func_5()) {
				if (func_165()) {
					if (func_164(Global_2452545)) {
						if (iParam3) {
							func_99(0);
						}
						if (streaming::is_player_switch_in_progress() == 0) {
							if (iParam4 == 0) {
								graphics::_stop_all_screen_effects();
							}
							iVar3 = 0;
							if (cam::does_cam_exist(iParam0) || iParam4) {
								vVar0 = {cam::get_cam_coord(iParam0)};
								entity::set_entity_coords(
									Global_1318015, entity::get_entity_coords(player::player_ped_id(), 0), 0, 0, 0, 1);
								if (iParam4 == 0) {
									entity::set_entity_coords(Global_2453681, vVar0, 0, 0, 0, 1);
								}
								else {
									entity::set_entity_coords(Global_2453681, Global_2452545, 0, 0, 0, 1);
								}
								iVar3 = func_162(entity::get_entity_coords(Global_1318015, 0),
												 entity::get_entity_coords(Global_2453681, 0));
								if (iVar3 == 3) {
									iVar3 = 2;
								}
							}
							if (iParam4 == 0) {
								streaming::start_player_switch(Global_1318015, Global_2453681, 1, iVar3);
							}
							else {
								streaming::start_player_switch(Global_1318015, Global_2453681, 8, iVar3);
							}
							if (cam::does_cam_exist(iParam0)) {
								vVar0 = {cam::get_cam_coord(iParam0)};
								vVar4 = {cam::get_cam_rot(iParam0, 2)};
								uVar7 = cam::get_cam_fov(iParam0);
								uVar8 = cam::get_cam_far_clip(iParam0);
								streaming::set_player_switch_outro(vVar0, vVar4, uVar7, uVar8, 2);
							}
							func_2(4);
						}
						else if (streaming::_0x933BBEEB8C61B5F4()) {
							if (cam::does_cam_exist(iParam0)) {
								func_172(0);
								vVar0 = {cam::get_cam_coord(iParam0)};
								vVar9 = {cam::get_cam_rot(iParam0, 2)};
								uVar12 = cam::get_cam_fov(iParam0);
								uVar13 = cam::get_cam_far_clip(iParam0);
								entity::set_entity_coords(player::player_ped_id(), vVar0, 0, 0, 0, 1);
								if (func_161(entity::get_entity_coords(Global_2453681, 0), vVar0, 5f, 0)) {
									streaming::_0xD8295AF639FD9CB8(Global_2453681);
									if (cam::does_cam_exist(iParam0)) {
										streaming::set_player_switch_outro(vVar0, vVar9, uVar12, uVar13, 2);
									}
									func_2(4);
								}
							}
							else {
								func_2(4);
								if (entity::does_entity_exist(player::player_ped_id())) {
									if (streaming::is_entity_focus(player::player_ped_id())) {
										streaming::clear_focus();
									}
								}
								streaming::_0x0811381EF5062FEC(Global_2453681);
								streaming::_0xD8295AF639FD9CB8(Global_2453681);
							}
						}
					}
				}
			}
		}
		if (func_6() == 4) {
			if (streaming::is_player_switch_in_progress()) {
				if (func_131() != 0) {
					if (func_131() < 33) {
						if (func_160()) {
							if (iParam5) {
								if (!graphics::_get_screen_effect_is_active(func_157(0))) {
									graphics::_start_screen_effect(func_157(0), 0, 1);
								}
							}
						}
					}
				}
				if (network::network_is_game_in_progress()) {
					network::set_player_visible_locally(player::player_id(), 0);
				}
				if (streaming::get_player_switch_type() != 3) {
					if (streaming::get_player_switch_state() > 2) {
						if (iParam3) {
							func_154();
						}
						if (ui::is_pause_menu_active() == 1) {
							if (iParam1) {
								ui::set_frontend_active(0);
							}
							if (iParam3) {
								func_99(0);
							}
						}
					}
				}
				else {
					if (iParam3) {
						func_154();
					}
					if (ui::is_pause_menu_active() == 1) {
						if (iParam1) {
							ui::set_frontend_active(0);
						}
						if (iParam3) {
							func_99(0);
						}
					}
				}
			}
			if (streaming::is_player_switch_in_progress() == 0 || iParam2 && streaming::get_player_switch_state() > 8) {
				if (iParam3) {
					func_154();
				}
				if (ui::is_pause_menu_active() == 1) {
					if (iParam1) {
						ui::set_frontend_active(0);
					}
					if (iParam3) {
						func_99(0);
					}
				}
				if (ui::is_pause_menu_active() == 0 || ui::is_social_club_active() && ui::is_warning_message_active() ||
					iParam1 == 0) {
					if (entity::does_entity_exist(Global_1318015)) {
						if (entity::does_entity_belong_to_this_script(Global_1318015, 0)) {
							if (!entity::is_entity_a_mission_entity(Global_1318015)) {
								entity::set_entity_as_mission_entity(Global_1318015, 0, 0);
							}
							ped::delete_ped(&Global_1318015);
						}
					}
					if (func_419() == 0) {
						player::set_player_invincible(player::player_id(), 0);
					}
					graphics::_0x22A249A53034450A(0);
					if (network::network_is_game_in_progress()) {
						network::set_player_visible_locally(player::player_id(), 0);
					}
					Global_2443134.f_608 = 0;
					func_2(0);
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x9710
int func_154() {
	if (cam::is_screen_faded_out()) {
		func_156(0);
		graphics::_0xDE81239437E8C5A8();
		return 1;
	}
	if (func_155() == 3) {
		func_156(2);
		graphics::_transition_from_blurred(250f);
	}
	if (graphics::is_particle_fx_delayed_blink() >= 250f) {
		graphics::_transition_from_blurred(250f);
	}
	if (graphics::_0x7B226C785A52A0A9() == 0) {
		graphics::_transition_from_blurred(250f);
	}
	if (graphics::is_particle_fx_delayed_blink() <= 0f) {
		func_156(0);
		return 1;
	}
	return 0;
}

// Position - 0x977F
int func_155() { return Global_1312466.f_19; }

// Position - 0x978D
void func_156(int iParam0) {
	if (Global_1312466.f_19 != iParam0) {
		Global_1312466.f_19 = iParam0;
	}
}

// Position - 0x97A8
char *func_157(int iParam0) {
	if (iParam0 || func_159(134)) {
		return "MenuMGHeistIn";
	}
	if (func_158()) {
		return "MenuMGTournamentIn";
	}
	return "MenuMGSelectionIn";
}

// Position - 0x97D9
bool func_158() { return gameplay::is_bit_set(Global_2443905.f_1.f_2808, 12); }

// Position - 0x97F0
var func_159(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0 / 32;
	iVar1 = iParam0 % 32;
	if (iVar0 == 0) {
		return gameplay::is_bit_set(Global_2443905.f_1.f_2812, iVar1);
	}
	if (iVar0 == 1) {
		return gameplay::is_bit_set(Global_2443905.f_1.f_2813, iVar1);
	}
	if (iVar0 == 2) {
		return gameplay::is_bit_set(Global_2443905.f_1.f_2814, iVar1);
	}
	if (iVar0 == 3) {
		return gameplay::is_bit_set(Global_2443905.f_1.f_2815, iVar1);
	}
	if (iVar0 == 4) {
		return gameplay::is_bit_set(Global_2443905.f_1.f_2816, iVar1);
	}
	return gameplay::is_bit_set(Global_2443905.f_1.f_2817, iVar1);
}

// Position - 0x989C
bool func_160() {
	if (streaming::is_player_switch_in_progress()) {
		if (streaming::get_player_switch_type() != 3) {
			if (streaming::get_player_switch_state() > 8) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x98C1
bool func_161(vector3 vParam0, vector3 vParam3, float fParam6, int iParam7) {
	if (fParam6 < 0f) {
		fParam6 = 0f;
	}
	if (!iParam7) {
		if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
			if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
				if (gameplay::absf(vParam0.z - vParam3.z) <= fParam6) {
					return true;
				}
			}
		}
	}
	else if (gameplay::absf(vParam0.x - vParam3.x) <= fParam6) {
		if (gameplay::absf(vParam0.y - vParam3.y) <= fParam6) {
			return true;
		}
	}
	return false;
}

// Position - 0x993C
int func_162(vector3 vParam0, vector3 vParam3) {
	if (func_163(vParam0, 99) || func_163(vParam3, 99)) {
		return 3;
	}
	return streaming::get_ideal_player_switch_type(vParam0, vParam3);
}

// Position - 0x9974
int func_163(vector3 vParam0, int iParam3) {
	struct<7> Var0;

	switch (iParam3) {
	case 2:
	case 6:
	case 10:
		func_111(&Var0, iParam3);
		if (object::is_point_in_angled_area(vParam0, Var0, Var0.f_3, Var0.f_6, 0, 1)) {
			return 1;
		}
		break;

	case 99:
		func_111(&Var0, 2);
		if (object::is_point_in_angled_area(vParam0, Var0, Var0.f_3, Var0.f_6, 0, 1)) {
			return 1;
		}
		func_111(&Var0, 6);
		if (object::is_point_in_angled_area(vParam0, Var0, Var0.f_3, Var0.f_6, 0, 1)) {
			return 1;
		}
		func_111(&Var0, 10);
		if (object::is_point_in_angled_area(vParam0, Var0, Var0.f_3, Var0.f_6, 0, 1)) {
			return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x9A5C
bool func_164(vector3 vParam0) {
	if (!entity::does_entity_exist(Global_2453681)) {
		streaming::request_model(joaat("u_m_m_filmdirector"));
		if (streaming::has_model_loaded(joaat("u_m_m_filmdirector"))) {
			Global_2453681 = ped::create_ped(25, joaat("u_m_m_filmdirector"), vParam0, 0f, 0, 0);
			entity::set_entity_as_mission_entity(Global_2453681, 0, 0);
			ai::clear_ped_tasks_immediately(Global_2453681);
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::set_ped_desired_heading(Global_2453681, entity::get_entity_heading(player::player_ped_id()));
			}
			entity::set_entity_collision(Global_2453681, 0, 0);
			entity::set_entity_visible(Global_2453681, 0, 0);
			entity::set_entity_invincible(Global_2453681, 1);
			if (!streaming::is_player_switch_in_progress()) {
				streaming::set_focus_entity(Global_2453681);
			}
			streaming::set_model_as_no_longer_needed(joaat("u_m_m_filmdirector"));
		}
	}
	else {
		if (!ped::is_ped_injured(Global_2453681)) {
			entity::freeze_entity_position(Global_2453681, 1);
			ai::clear_ped_tasks(Global_2453681);
			ped::set_blocking_of_non_temporary_events(Global_2453681, 1);
			if (!streaming::is_player_switch_in_progress()) {
				streaming::set_focus_entity(Global_2453681);
			}
		}
		return true;
	}
	return false;
}

// Position - 0x9B43
bool func_165() {
	if (!entity::does_entity_exist(Global_1318015)) {
		streaming::request_model(joaat("u_m_m_filmdirector"));
		if (streaming::has_model_loaded(joaat("u_m_m_filmdirector"))) {
			Global_1318015 = ped::create_ped(25, joaat("u_m_m_filmdirector"),
											 entity::get_entity_coords(player::player_ped_id(), 0), 0f, 0, 0);
			entity::set_entity_visible(Global_1318015, 0, 0);
			entity::set_entity_invincible(Global_1318015, 1);
			entity::set_entity_as_mission_entity(Global_1318015, 0, 0);
			ai::clear_ped_tasks_immediately(Global_1318015);
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ped::set_ped_desired_heading(Global_1318015, entity::get_entity_heading(player::player_ped_id()));
			}
			entity::set_entity_collision(Global_1318015, 0, 0);
			entity::set_entity_visible(Global_1318015, 0, 0);
			if (!streaming::is_player_switch_in_progress()) {
				streaming::set_focus_entity(Global_1318015);
			}
			streaming::set_model_as_no_longer_needed(joaat("u_m_m_filmdirector"));
			gameplay::set_bit(&Global_1760211[1], 6);
		}
		else {
			gameplay::set_bit(&Global_1760211[1], 7);
		}
	}
	else {
		if (!ped::is_ped_injured(Global_1318015)) {
			entity::set_entity_visible(Global_1318015, 0, 0);
			entity::freeze_entity_position(Global_1318015, 1);
			ai::clear_ped_tasks(Global_1318015);
			ped::set_blocking_of_non_temporary_events(Global_1318015, 1);
			if (!streaming::is_player_switch_in_progress()) {
				streaming::set_focus_entity(Global_1318015);
			}
		}
		return true;
	}
	return false;
}

// Position - 0x9C5B
void func_166() {
	if (ped::is_ped_injured(player::player_ped_id())) {
		if (func_16() == 0) {
			network::network_resurrect_local_player(entity::get_entity_coords(player::player_ped_id(), 0), 0f, 0,
													func_167(player::player_id(), 1), 1);
		}
		else if (ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
			ped::resurrect_ped(player::player_ped_id());
		}
		else {
			ped::revive_injured_ped(player::player_ped_id());
		}
	}
	player::reset_player_arrest_state(player::player_id());
	gameplay::_reset_localplayer_state();
}

// Position - 0x9CBD
int func_167(int iParam0, int iParam1) {
	if (Global_1312447 != 0) {
		return func_171(iParam0) != 0;
	}
	return func_168(iParam0, iParam1);
}

// Position - 0x9CE3
int func_168(int iParam0, bool bParam1) {
	if (bParam1) {
		if (func_169(iParam0)) {
			return 1;
		}
	}
	if (Global_1591201[iParam0 /*602*/] == -1) {
		return 0;
	}
	return 1;
}

// Position - 0x9D0F
bool func_169(int iParam0) { return func_170(iParam0); }

// Position - 0x9D1D
var func_170(int iParam0) { return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_13.f_1, 0); }

// Position - 0x9D37
int func_171(int iParam0) {
	if (func_229(iParam0, 0, 1)) {
		return Global_2421664[iParam0 /*358*/].f_1;
	}
	return 0;
}

// Position - 0x9D59
void func_172(int iParam0) { Global_2433121 = iParam0; }

// Position - 0x9D67
bool func_173() { return Global_2433121; }

// Position - 0x9D73
void func_174() {
	int iVar0;

	ui::hide_hud_and_radar_this_frame();
	func_181();
	ui::hide_hud_component_this_frame(2);
	ui::hide_hud_component_this_frame(1);
	ui::hide_hud_component_this_frame(3);
	ui::hide_hud_component_this_frame(4);
	ui::hide_hud_component_this_frame(13);
	ui::hide_hud_component_this_frame(15);
	ui::hide_hud_component_this_frame(11);
	ui::hide_hud_component_this_frame(12);
	ui::hide_hud_component_this_frame(18);
	iVar0 = 0;
	iVar0 = func_180("HQRHELP");
	if (!iVar0) {
		ui::hide_help_text_this_frame();
	}
	func_175();
	controls::stop_pad_shake(0);
	func_175();
	controls::disable_control_action(2, 199, 1);
}

// Position - 0x9DE1
void func_175() {
	if (Global_14443.f_1 != 1) {
		if (func_179(0)) {
			func_176(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x9E09
void func_176(int iParam0) {
	if (Global_14604) {
		func_178(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_177()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x9E79
int func_177() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x9EA0
void func_178(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_179(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x9F14
bool func_179(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x9F6E
var func_180(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x9F81
void func_181() {
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(9);
}

// Position - 0x9F9F
void func_182() { Global_2452971 = 0; }

// Position - 0x9FAC
void func_183(var *uParam0, int iParam1, int iParam2) {
	switch (iParam1) {
	case 1:
		switch (iParam2) {
		case 0:
			*uParam0 = {-885.9518f, 223.3702f, 88.5406f};
			uParam0->f_3 = {26.6167f, 0f, -45.2182f};
			uParam0->f_6 = 49.3611f;
			break;

		case 1:
			*uParam0 = {-1005.929f, 445.3399f, 143.0898f};
			uParam0->f_3 = {2.6541f, 0.6784f, -131.8131f};
			uParam0->f_6 = 48.691f;
			break;

		case 2:
			*uParam0 = {-680.1154f, 266.1721f, 87.2771f};
			uParam0->f_3 = {37.4194f, 0f, 53.8767f};
			uParam0->f_6 = 54.6037f;
			break;

		case 3:
			*uParam0 = {-779.2855f, 405.9464f, 106.2266f};
			uParam0->f_3 = {45.3313f, 0f, -179.6772f};
			uParam0->f_6 = 44.2609f;
			break;

		case 4:
			*uParam0 = {-894.9058f, 157.4258f, 179.9194f};
			uParam0->f_3 = {1.196f, 0f, -43.6586f};
			uParam0->f_6 = 36.4321f;
			break;
		}
		break;

	case 2:
		switch (iParam2) {
		case 0:
			*uParam0 = {-213.5606f, -1073.008f, 32.9946f};
			uParam0->f_3 = {22.7554f, 0f, 28.5746f};
			uParam0->f_6 = 50.0029f;
			break;

		case 1:
			*uParam0 = {-323.6761f, -938.0006f, 33.1388f};
			uParam0->f_3 = {50.3562f, 0f, -110.0558f};
			uParam0->f_6 = 50.9248f;
			break;

		case 2:
			*uParam0 = {-197.8791f, -1036.019f, 30.8882f};
			uParam0->f_3 = {39.0954f, 0f, 51.9377f};
			uParam0->f_6 = 32.7032f;
			break;

		case 3:
			*uParam0 = {-302.5071f, -1045.572f, 227.9951f};
			uParam0->f_3 = {-54.0979f, 0f, -20.4519f};
			uParam0->f_6 = 35.9315f;
			break;

		case 4:
			*uParam0 = {-282.1573f, -1005.93f, 232.2077f};
			uParam0->f_3 = {-76.6024f, 0f, 8.6575f};
			uParam0->f_6 = 15.9715f;
			break;
		}
		break;

	case 3:
		switch (iParam2) {
		case 0:
			*uParam0 = {-1392.074f, -570.8373f, 31.4774f};
			uParam0->f_3 = {30.5301f, 0f, 64.2307f};
			uParam0->f_6 = 35.9982f;
			break;

		case 1:
			*uParam0 = {-1548.498f, -465.9476f, 62.9037f};
			uParam0->f_3 = {5.9567f, 0f, -121.5631f};
			uParam0->f_6 = 27.5041f;
			break;

		case 2:
			*uParam0 = {-1325.364f, -538.2483f, 31.2659f};
			uParam0->f_3 = {13.3032f, 0f, 83.3714f};
			uParam0->f_6 = 36.7475f;
			break;

		case 3:
			*uParam0 = {-1375.703f, -547.4904f, 29.652f};
			uParam0->f_3 = {26.5662f, 0f, 91.0091f};
			uParam0->f_6 = 40.2773f;
			break;

		case 4:
			*uParam0 = {-1360.223f, -538.6799f, 38.6917f};
			uParam0->f_3 = {10.2413f, -2.8388f, 102.5978f};
			uParam0->f_6 = 53.2355f;
			break;
		}
		break;

	case 4:
		switch (iParam2) {
		case 0:
			*uParam0 = {-961.9043f, -550.012f, 32.5747f};
			uParam0->f_3 = {28.8097f, 0f, -26.8876f};
			uParam0->f_6 = 50f;
			break;

		case 1:
			*uParam0 = {-944.8992f, -589.884f, 114.2766f};
			uParam0->f_3 = {9.8026f, 0f, -28.0001f};
			uParam0->f_6 = 39.3835f;
			break;

		case 2:
			*uParam0 = {-1061.914f, -465.8897f, 111.6679f};
			uParam0->f_3 = {10.0297f, 0f, -95.863f};
			uParam0->f_6 = 37.074f;
			break;

		case 3:
			*uParam0 = {-898.0392f, -399.63f, 39.1545f};
			uParam0->f_3 = {58.7284f, 0.0897f, -179.1522f};
			uParam0->f_6 = 50f;
			break;

		case 4:
			*uParam0 = {-932.1243f, -471.0513f, 193.7404f};
			uParam0->f_3 = {-74.0834f, 0f, -15.0768f};
			uParam0->f_6 = 41.0466f;
			break;
		}
		break;

	case 5:
		switch (iParam2) {
		case 0:
			*uParam0 = {-67.3495f, -513.4921f, 42.6787f};
			uParam0->f_3 = {23.7233f, 0f, -151.7019f};
			uParam0->f_6 = 55.5648f;
			break;

		case 1:
			*uParam0 = {-72.4999f, -582.1418f, 39.1127f};
			uParam0->f_3 = {49.0853f, 0f, -127.3052f};
			uParam0->f_6 = 63.5539f;
			break;

		case 2:
			*uParam0 = {-107.6931f, -603.4216f, 38.2444f};
			uParam0->f_3 = {33.9707f, 0f, -92.9207f};
			uParam0->f_6 = 47.4136f;
			break;

		case 3:
			*uParam0 = {-61.3588f, -680.9072f, 40.2634f};
			uParam0->f_3 = {25.5856f, 0f, 4.5153f};
			uParam0->f_6 = 60.2176f;
			break;

		case 4:
			*uParam0 = {-70.9133f, -561.0882f, 131.3551f};
			uParam0->f_3 = {-58.5274f, 0f, -145.3088f};
			uParam0->f_6 = 44.7537f;
			break;
		}
		break;

	case 6:
		switch (iParam2) {
		case 0:
			*uParam0 = {-960.2891f, -472.7867f, 39.0439f};
			uParam0->f_3 = {24.7986f, 0.0409f, -21.4827f};
			uParam0->f_6 = 52.0185f;
			break;

		case 1:
			*uParam0 = {-948.9227f, -417.8185f, 38.2592f};
			uParam0->f_3 = {40.3772f, 0f, -15.5227f};
			uParam0->f_6 = 67.7998f;
			break;

		case 2:
			*uParam0 = {-892.0462f, -394.0205f, 141.2545f};
			uParam0->f_3 = {-52.4628f, 0f, 60.5147f};
			uParam0->f_6 = 75.2894f;
			break;

		case 3:
			*uParam0 = {-928.1372f, -428.1431f, 124.677f};
			uParam0->f_3 = {-1.9624f, -0.2152f, -14.2648f};
			uParam0->f_6 = 54.9758f;
			break;

		case 4:
			*uParam0 = {-905.6004f, -293.2657f, 41.9486f};
			uParam0->f_3 = {43.2627f, 3.8988f, 175.5304f};
			uParam0->f_6 = 33.937f;
			break;
		}
		break;

	case 7:
		switch (iParam2) {
		case 0:
			*uParam0 = {-667.2404f, -25.1369f, 43.1678f};
			uParam0->f_3 = {21.8261f, 0f, -39.9922f};
			uParam0->f_6 = 48.3545f;
			break;

		case 1:
			*uParam0 = {-667.8553f, -28.9006f, 41.2252f};
			uParam0->f_3 = {22.8893f, 0f, -52.7611f};
			uParam0->f_6 = 54.0359f;
			break;

		case 2:
			*uParam0 = {-610.4257f, 204.0192f, 100.9878f};
			uParam0->f_3 = {-5.2361f, 0f, -165.0898f};
			uParam0->f_6 = 38.4484f;
			break;

		case 3:
			*uParam0 = {-545.654f, -41.3291f, 74.0575f};
			uParam0->f_3 = {2.8113f, 0f, 44.689f};
			uParam0->f_6 = 62.0178f;
			break;

		case 4:
			*uParam0 = {-586.9001f, -92.5411f, 61.7151f};
			uParam0->f_3 = {4.1604f, 0f, 4.4756f};
			uParam0->f_6 = 46.1658f;
			break;
		}
		break;

	case 58:
		switch (iParam2) {
		case 0:
			*uParam0 = {-197.7389f, 510.5206f, 136.3903f};
			uParam0->f_3 = {4.4541f, 0f, -130.5121f};
			uParam0->f_6 = 50.4296f;
			break;

		case 1:
			*uParam0 = {-169.1212f, 527.376f, 142.9745f};
			uParam0->f_3 = {-6.3103f, 0f, 164.9361f};
			uParam0->f_6 = 32.4097f;
			break;

		case 2:
			*uParam0 = {-169.2143f, 518.2604f, 139.0207f};
			uParam0->f_3 = {-4.6553f, 0f, 161.8068f};
			uParam0->f_6 = 47.2748f;
			break;

		case 3:
			*uParam0 = {-207.4332f, 510.9664f, 134.9146f};
			uParam0->f_3 = {5.9677f, 0f, -121.2417f};
			uParam0->f_6 = 33.5913f;
			break;

		case 4:
			*uParam0 = {-168.7606f, 517.1948f, 144.7751f};
			uParam0->f_3 = {-24.9315f, 0f, 159.1448f};
			uParam0->f_6 = 45.9462f;
			break;
		}
		break;

	case 59:
		switch (iParam2) {
		case 0:
			*uParam0 = {349.7426f, 463.4214f, 150.5502f};
			uParam0->f_3 = {-2.7041f, 0f, 161.0581f};
			uParam0->f_6 = 35.5099f;
			break;

		case 1:
			*uParam0 = {369.4083f, 446.0274f, 149.2577f};
			uParam0->f_3 = {-6.2912f, 0f, 118.4015f};
			uParam0->f_6 = 48.7713f;
			break;

		case 2:
			*uParam0 = {369.3146f, 439.4409f, 145.6846f};
			uParam0->f_3 = {5.6182f, 0f, 97.9462f};
			uParam0->f_6 = 43.3638f;
			break;

		case 3:
			*uParam0 = {349.6898f, 458.571f, 148.8095f};
			uParam0->f_3 = {6.2431f, 0f, 169.6303f};
			uParam0->f_6 = 52.1804f;
			break;

		case 4:
			*uParam0 = {364.7197f, 459.9904f, 155.0079f};
			uParam0->f_3 = {-11.3527f, 0f, 142.9213f};
			uParam0->f_6 = 41.522f;
			break;
		}
		break;

	case 60:
		switch (iParam2) {
		case 0:
			*uParam0 = {-728.8906f, 604.4725f, 145.8867f};
			uParam0->f_3 = {-5.1049f, 0f, 58.7266f};
			uParam0->f_6 = 43.6559f;
			break;

		case 1:
			*uParam0 = {-742.6712f, 642.7081f, 147.123f};
			uParam0->f_3 = {-1.8667f, 0f, 143.9352f};
			uParam0->f_6 = 45.2768f;
			break;

		case 2:
			*uParam0 = {-736.4854f, 629.4451f, 151.568f};
			uParam0->f_3 = {-19.0573f, 0f, 118.6126f};
			uParam0->f_6 = 52.8655f;
			break;

		case 3:
			*uParam0 = {-750.1407f, 635.4058f, 143.2065f};
			uParam0->f_3 = {7.281f, 0f, 150.2378f};
			uParam0->f_6 = 56.8287f;
			break;

		case 4:
			*uParam0 = {-741.3972f, 608.1267f, 145.6561f};
			uParam0->f_3 = {-4.0551f, 0f, 65.9835f};
			uParam0->f_6 = 58.8565f;
			break;
		}
		break;

	case 61:
		switch (iParam2) {
		case 0:
			*uParam0 = {-717.0034f, 600.6978f, 147.893f};
			uParam0->f_3 = {-4.9085f, 0f, -98.586f};
			uParam0->f_6 = 32.2276f;
			break;

		case 1:
			*uParam0 = {-701.1855f, 600.7932f, 143.6584f};
			uParam0->f_3 = {7.7196f, 0f, -113.1052f};
			uParam0->f_6 = 49.7649f;
			break;

		case 2:
			*uParam0 = {-701.0754f, 605.7044f, 149.8881f};
			uParam0->f_3 = {-13.0822f, 0f, -127.8861f};
			uParam0->f_6 = 47.8507f;
			break;

		case 3:
			*uParam0 = {-689.851f, 613.3149f, 144.5428f};
			uParam0->f_3 = {2.7851f, 0f, -159.4652f};
			uParam0->f_6 = 36.3593f;
			break;

		case 4:
			*uParam0 = {-684.5708f, 616.9944f, 146.6868f};
			uParam0->f_3 = {-1.7926f, 0f, -174.1436f};
			uParam0->f_6 = 41.2348f;
			break;
		}
		break;

	case 62:
		switch (iParam2) {
		case 0:
			*uParam0 = {130.9311f, 583.0837f, 190.7715f};
			uParam0->f_3 = {-8.6044f, 0f, 169.1267f};
			uParam0->f_6 = 54.4566f;
			break;

		case 1:
			*uParam0 = {111.3322f, 576.2406f, 183.0462f};
			uParam0->f_3 = {13.1423f, 0f, -136.5486f};
			uParam0->f_6 = 44.7519f;
			break;

		case 2:
			*uParam0 = {123.3129f, 580.7582f, 185.1801f};
			uParam0->f_3 = {6.9979f, 0f, -175.0756f};
			uParam0->f_6 = 50.0517f;
			break;

		case 3:
			*uParam0 = {140.2376f, 575.8712f, 183.975f};
			uParam0->f_3 = {7.5347f, 0f, 125.2426f};
			uParam0->f_6 = 45.2281f;
			break;

		case 4:
			*uParam0 = {132.543f, 586.0762f, 189.4462f};
			uParam0->f_3 = {-8.4016f, 0f, 162.3881f};
			uParam0->f_6 = 31.4711f;
			break;
		}
		break;

	case 63:
		switch (iParam2) {
		case 0:
			*uParam0 = {-543.6597f, 674.514f, 147.0296f};
			uParam0->f_3 = {-2.4999f, 0f, 129.3025f};
			uParam0->f_6 = 33.2745f;
			break;

		case 1:
			*uParam0 = {-536.9955f, 669.2134f, 144.4017f};
			uParam0->f_3 = {10.3434f, 0f, 110.239f};
			uParam0->f_6 = 34.9284f;
			break;

		case 2:
			*uParam0 = {-571.9711f, 682.6545f, 150.4516f};
			uParam0->f_3 = {-10.9494f, 0f, -144.6349f};
			uParam0->f_6 = 41.6942f;
			break;

		case 3:
			*uParam0 = {-529.8699f, 672.4476f, 143.8666f};
			uParam0->f_3 = {5.4286f, 0f, 107.2091f};
			uParam0->f_6 = 31.2494f;
			break;

		case 4:
			*uParam0 = {-524.9136f, 665.4783f, 158.24f};
			uParam0->f_3 = {-20.6896f, 0f, 102.291f};
			uParam0->f_6 = 26.0316f;
			break;
		}
		break;

	case 64:
		switch (iParam2) {
		case 0:
			*uParam0 = {-714.4224f, 598.4947f, 144.1234f};
			uParam0->f_3 = {5.9852f, 0f, 94.4228f};
			uParam0->f_6 = 45.565f;
			break;

		case 1:
			*uParam0 = {-738.5571f, 612.7238f, 142.0696f};
			uParam0->f_3 = {14.136f, 0.6588f, 169.283f};
			uParam0->f_6 = 54.2471f;
			break;

		case 2:
			*uParam0 = {-718.2198f, 608.2428f, 152.5514f};
			uParam0->f_3 = {-19.1555f, 0.6588f, 128.9267f};
			uParam0->f_6 = 40.0876f;
			break;

		case 3:
			*uParam0 = {-742.6341f, 622.4393f, 144.8027f};
			uParam0->f_3 = {-0.3429f, 0f, -173.5023f};
			uParam0->f_6 = 41.1613f;
			break;

		case 4:
			*uParam0 = {-737.188f, 616.2004f, 148.5f};
			uParam0->f_3 = {-7.1895f, 0f, -171.5297f};
			uParam0->f_6 = 40.1556f;
			break;
			break;
		}
		break;

	case 65:
		switch (iParam2) {
		case 0:
			*uParam0 = {-846.7444f, 711.5901f, 151.8802f};
			uParam0->f_3 = {-5.2972f, 0f, 145.8721f};
			uParam0->f_6 = 40.4533f;
			break;

		case 1:
			*uParam0 = {-875.7339f, 710.2248f, 152.0264f};
			uParam0->f_3 = {-0.8038f, 0f, -139.0049f};
			uParam0->f_6 = 43.0582f;
			break;

		case 2:
			*uParam0 = {-861.1381f, 718.2349f, 166.3458f};
			uParam0->f_3 = {-34.0003f, 0f, -166.629f};
			uParam0->f_6 = 47.9323f;
			break;

		case 3:
			*uParam0 = {-861.1381f, 718.2349f, 166.3458f};
			uParam0->f_3 = {-34.0003f, 0f, -166.629f};
			uParam0->f_6 = 47.9323f;
			break;

		case 4:
			*uParam0 = {-893.9624f, 715.9857f, 153.2935f};
			uParam0->f_3 = {-4.2714f, 0f, -116.7937f};
			uParam0->f_6 = 28.0439f;
			break;
		}
		break;

	case 66:
		switch (iParam2) {
		case 0:
			*uParam0 = {-1300.027f, 465.0517f, 101.3412f};
			uParam0->f_3 = {-10.5096f, 0f, -152.1912f};
			uParam0->f_6 = 44.4357f;
			break;

		case 1:
			*uParam0 = {-1282.027f, 465.9779f, 95.7958f};
			uParam0->f_3 = {17.283f, 0f, 152.5088f};
			uParam0->f_6 = 53.4171f;
			break;

		case 2:
			*uParam0 = {-1276.731f, 461.4053f, 96.401f};
			uParam0->f_3 = {8.1526f, 0f, 136.4044f};
			uParam0->f_6 = 50f;
			break;

		case 3:
			*uParam0 = {-1273.489f, 460.8777f, 102.1842f};
			uParam0->f_3 = {-24.7807f, 0f, 135.9527f};
			uParam0->f_6 = 50f;
			break;

		case 4:
			*uParam0 = {-1304.728f, 468.4829f, 102.4148f};
			uParam0->f_3 = {-10.122f, 0f, -145.0509f};
			uParam0->f_6 = 39.8609f;
			break;
		}
		break;

	case 67:
		switch (iParam2) {
		case 0:
			*uParam0 = {384.7624f, 440.3207f, 145.0527f};
			uParam0->f_3 = {-1.9896f, 0f, 144.6732f};
			uParam0->f_6 = 48.4143f;
			break;

		case 1:
			*uParam0 = {365.7408f, 443.1193f, 145.9301f};
			uParam0->f_3 = {0.1767f, 0f, -162.6344f};
			uParam0->f_6 = 43.6114f;
			break;

		case 2:
			*uParam0 = {386.8551f, 450.5209f, 148.9287f};
			uParam0->f_3 = {-5.2061f, 0f, 151.8171f};
			uParam0->f_6 = 29.5462f;
			break;

		case 3:
			*uParam0 = {357.9258f, 451.9459f, 145.8073f};
			uParam0->f_3 = {0.652f, 0f, -149.457f};
			uParam0->f_6 = 33.9579f;
			break;

		case 4:
			*uParam0 = {393.1492f, 444.4349f, 151.6931f};
			uParam0->f_3 = {-13.4973f, 0f, 148.1239f};
			uParam0->f_6 = 50f;
			break;
		}
		break;

	case 68:
		switch (iParam2) {
		case 0:
			*uParam0 = {-1584.16f, -627.3773f, 100.8102f};
			uParam0->f_3 = {2.1506f, 0f, 0.071f};
			uParam0->f_6 = 55.535f;
			break;

		case 1:
			*uParam0 = {-1643.292f, -580.6568f, 101.245f};
			uParam0->f_3 = {-3.349f, 0f, -83.8367f};
			uParam0->f_6 = 41.6441f;
			break;

		case 2:
			*uParam0 = {-1662.237f, -576.6899f, 33.5333f};
			uParam0->f_3 = {33.7445f, 0f, -92.6563f};
			uParam0->f_6 = 33.1968f;
			break;

		case 3:
			*uParam0 = {-1623.911f, -675.9907f, 77.093f};
			uParam0->f_3 = {6.6353f, 0f, -26.9933f};
			uParam0->f_6 = 33.1968f;
			break;

		case 4:
			*uParam0 = {-1640.947f, -584.2517f, 123.2783f};
			uParam0->f_3 = {-9.4922f, 0f, -83.882f};
			uParam0->f_6 = 37.9602f;
			break;
		}
		break;

	case 69:
		switch (iParam2) {
		case 0:
			*uParam0 = {-1319.483f, -525.5394f, 59.4223f};
			uParam0->f_3 = {3.8675f, 0f, 52.6338f};
			uParam0->f_6 = 55.5659f;
			break;

		case 1:
			*uParam0 = {-1366.563f, -540.9052f, 41.7059f};
			uParam0->f_3 = {19.1456f, 0f, -0.523f};
			uParam0->f_6 = 62.4535f;
			break;

		case 2:
			*uParam0 = {-1447.018f, -477.3477f, 89.4685f};
			uParam0->f_3 = {-7.8524f, 0f, -90.1828f};
			uParam0->f_6 = 45f;
			break;

		case 3:
			*uParam0 = {-1436.483f, -519.5764f, 46.4599f};
			uParam0->f_3 = {11.9961f, 0f, -49.6801f};
			uParam0->f_6 = 60.6974f;
			break;

		case 4:
			*uParam0 = {-1413.072f, -544.0135f, 50.3749f};
			uParam0->f_3 = {5.7809f, 0f, -29.3278f};
			uParam0->f_6 = 64.5079f;
			break;
		}
		break;

	case 70:
		switch (iParam2) {
		case 0:
			*uParam0 = {-90.5981f, -639.1288f, 43.0304f};
			uParam0->f_3 = {21.7355f, 0f, 23.903f};
			uParam0->f_6 = 50f;
			break;

		case 1:
			*uParam0 = {-209.4408f, -637.1819f, 51.2638f};
			uParam0->f_3 = {28.8177f, 0f, -53.9284f};
			uParam0->f_6 = 69.4782f;
			break;

		case 2:
			*uParam0 = {-291.8475f, -682.1937f, 115.9967f};
			uParam0->f_3 = {-11.4594f, 0f, -59.2777f};
			uParam0->f_6 = 46.6231f;
			break;

		case 3:
			*uParam0 = {-156.8309f, -706.6057f, 43.1322f};
			uParam0->f_3 = {42.7982f, 0f, -9.9844f};
			uParam0->f_6 = 53.0363f;
			break;

		case 4:
			*uParam0 = {-21.7145f, -552.9631f, 178.1255f};
			uParam0->f_3 = {-8.6541f, 0f, 115.174f};
			uParam0->f_6 = 49.6327f;
			break;
		}
		break;

	case 71:
		switch (iParam2) {
		case 0:
			*uParam0 = {-116.9155f, -876.4891f, 299.0441f};
			uParam0->f_3 = {1.171f, 0f, -43.7803f};
			uParam0->f_6 = 50f;
			break;

		case 1:
			*uParam0 = {-23.493f, -698.7332f, 261.5253f};
			uParam0->f_3 = {5.0408f, 0f, 157.9843f};
			uParam0->f_6 = 56.6759f;
			break;

		case 2:
			*uParam0 = {-152.7363f, -747.0823f, 40.5166f};
			uParam0->f_3 = {37.7232f, 0f, -120.7514f};
			uParam0->f_6 = 71.9701f;
			break;

		case 3:
			*uParam0 = {-9.5656f, -784.3034f, 323.6057f};
			uParam0->f_3 = {-18.6225f, 0f, 108.7237f};
			uParam0->f_6 = 52.5694f;
			break;

		case 4:
			*uParam0 = {-109.0389f, -899.1192f, 358.453f};
			uParam0->f_3 = {-35.1415f, 0f, -23.7808f};
			uParam0->f_6 = 38.9297f;
			break;
		}
		break;
	}
}

// Position - 0xB754
void func_184(int iParam0, var *uParam1, int iParam2) {
	struct<4> Var0;

	switch (iParam0) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41:
	case 42:
	case 43:
		func_116(iParam0, 9, &Var0, -1, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, -1, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, -1, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, -1, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 66:
	case 67:
	case 68:
	case 69:
		(*uParam1)[0 /*4*/] = {351.8605f, -995.1919f, -100.203f};
		(*uParam1)[0 /*4*/].f_3 = 177.5208f;
		(*uParam1)[1 /*4*/] = {342.7552f, -1002.421f, -100.2024f};
		(*uParam1)[1 /*4*/].f_3 = 270.6484f;
		(*uParam1)[2 /*4*/] = {339.4581f, -997.6315f, -100.2058f};
		(*uParam1)[2 /*4*/].f_3 = 11.316f;
		(*uParam1)[3 /*4*/] = {341.5853f, -995.2015f, -100.2033f};
		(*uParam1)[3 /*4*/].f_3 = 82.7126f;
		break;

	case 17:
	case 18:
	case 19:
	case 20:
	case 21:
	case 22:
	case 23:
	case 70:
	case 71:
	case 72:
		(*uParam1)[0 /*4*/] = {260.7131f, -1002.99f, -100.0086f};
		(*uParam1)[0 /*4*/].f_3 = 37.9253f;
		(*uParam1)[1 /*4*/] = {260.7037f, -998.3527f, -100.001f};
		(*uParam1)[1 /*4*/].f_3 = 49.2925f;
		(*uParam1)[2 /*4*/] = {261.4858f, -995.5132f, -100.0086f};
		(*uParam1)[2 /*4*/].f_3 = 93.5996f;
		(*uParam1)[3 /*4*/] = {255.5316f, -1000.62f, -100.0086f};
		(*uParam1)[3 /*4*/].f_3 = 272.3036f;
		break;

	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
		func_116(iParam0, 9, &Var0, 61, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 61, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 61, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 61, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 83:
	case 84:
	case 85:
		func_116(iParam0, 9, &Var0, 83, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 83, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 83, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 83, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 73:
	case 74:
	case 75:
	case 76:
		func_116(iParam0, 9, &Var0, 73, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 73, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 73, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 73, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
		func_116(iParam0, 9, &Var0, 77, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 77, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 77, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 77, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 86:
		func_185(iParam2, 9, &Var0, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_185(iParam2, 10, &Var0, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_185(iParam2, 11, &Var0, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_185(iParam2, 12, &Var0, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 87:
	case 88:
	case 89:
	case 90:
		func_116(iParam0, 9, &Var0, 88, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 88, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 88, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 88, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 91:
	case 92:
	case 93:
	case 94:
	case 95:
	case 96:
		func_116(iParam0, 9, &Var0, 91, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 91, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 91, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 91, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;

	case 97:
	case 98:
	case 99:
	case 100:
	case 101:
	case 102:
		func_116(iParam0, 9, &Var0, 97, 0);
		(*uParam1)[0 /*4*/] = {Var0};
		(*uParam1)[0 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 10, &Var0, 97, 0);
		(*uParam1)[1 /*4*/] = {Var0};
		(*uParam1)[1 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 11, &Var0, 97, 0);
		(*uParam1)[2 /*4*/] = {Var0};
		(*uParam1)[2 /*4*/].f_3 = Var0.f_3.f_2;
		func_116(iParam0, 12, &Var0, 97, 0);
		(*uParam1)[3 /*4*/] = {Var0};
		(*uParam1)[3 /*4*/].f_3 = Var0.f_3.f_2;
		break;
	}
}

// Position - 0xBF7E
void func_185(int iParam0, int iParam1, var *uParam2, int iParam3) {
	struct<6> Var0[2];
	vector3 vVar13;

	if (!iParam3) {
		Var0[0 /*6*/] = {func_186(-1)};
	}
	else {
		Var0[0 /*6*/] = {Global_4006219[iParam0 /*45*/].f_4};
		Var0[0 /*6*/].f_3 = {0f, 0f, Global_4006219[iParam0 /*45*/].f_7};
	}
	if (!iParam3) {
		Var0[1 /*6*/] = {func_186(iParam0)};
	}
	else {
		Var0[1 /*6*/] = {Global_4006219[iParam0 /*45*/].f_4};
		Var0[1 /*6*/].f_3 = {0f, 0f, Global_4006219[iParam0 /*45*/].f_7};
	}
	*uParam2 = {func_118(iParam1, 86)};
	vVar13 = {*uParam2 - Var0[0 /*6*/]};
	vVar13 = {func_117(vVar13, -Var0[0 /*6*/].f_3.f_2)};
	vVar13 = {func_117(vVar13, Var0[1 /*6*/].f_3.f_2)};
	*uParam2 = {object::_get_object_offset_from_coords(Var0[1 /*6*/], 0f, vVar13)};
	switch (iParam1) {
	case 6:
	case 2:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 34:
	case 35:
	case 36:
	case 560:
	case 38:
	case 39:
	case 120:
	case 121:
	case 125:
	case 40:
	case 41:
	case 43:
	case 44:
	case 45:
	case 42:
	case 46:
	case 47:
	case 343:
	case 349:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56:
	case 64:
	case 65:
	case 57:
	case 58:
	case 59:
	case 60:
	case 61:
	case 62:
	case 63:
	case 66:
	case 67:
	case 68:
	case 109:
	case 69:
	case 70:
	case 71:
	case 72:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
	case 78:
	case 79:
	case 80:
	case 81:
	case 82:
	case 83:
	case 85:
	case 84:
	case 89:
	case 90:
	case 91:
	case 92:
	case 94:
	case 95:
	case 96:
	case 97:
	case 98:
	case 93:
	case 99:
	case 100:
	case 106:
	case 107:
	case 108:
	case 119:
	case 122:
	case 123:
	case 124:
	case 138:
	case 139:
	case 140:
	case 130:
	case 128:
	case 201:
	case 284:
	case 285:
	case 286:
	case 287:
	case 202:
	case 203:
	case 204:
	case 205:
	case 206:
	case 207:
	case 208:
	case 209:
	case 210:
	case 211:
	case 212:
	case 213:
	case 214:
	case 216:
	case 217:
	case 182:
	case 183:
	case 181:
	case 156:
	case 236:
	case 237:
	case 238:
	case 239:
	case 240:
	case 241:
	case 242:
	case 243:
	case 244:
	case 245:
	case 246:
	case 247:
	case 248:
	case 249:
	case 250:
	case 251:
	case 252:
	case 253:
	case 254:
	case 255:
	case 256:
	case 257:
	case 258:
	case 259:
	case 260:
	case 311:
	case 340:
	case 391:
	case 392:
	case 393:
	case 394:
	case 395:
	case 396:
	case 397:
	case 398:
	case 399:
	case 400:
	case 401:
	case 402:
	case 403:
	case 404:
	case 405:
	case 406:
	case 407:
	case 408:
	case 409:
	case 410:
	case 411:
	case 412:
	case 413:
	case 414:
	case 415:
	case 416:
	case 417:
	case 418:
	case 419:
	case 438:
	case 439:
	case 440:
	case 441:
	case 442:
	case 443:
	case 357:
	case 358:
	case 359:
	case 467:
	case 468:
	case 469:
	case 497:
	case 498:
	case 499:
	case 503:
	case 598:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
	switch (iParam1) {
	case 362:
	case 363:
	case 364:
	case 365:
	case 366:
	case 367:
	case 368:
	case 360:
	case 361:
	case 383:
	case 386:
	case 372:
	case 373:
	case 374:
	case 375:
	case 376:
	case 377:
	case 378:
	case 370:
	case 371:
	case 384:
	case 387:
	case 486:
	case 487:
	case 488:
	case 489:
	case 490:
	case 491:
	case 492:
	case 485:
	case 544:
	case 543:
	case 545:
	case 516:
	case 517:
	case 583:
	case 584:
	case 518:
	case 519:
	case 520:
	case 521:
	case 522:
	case 523:
	case 524:
	case 525:
	case 526:
	case 527:
	case 553:
	case 552:
	case 551:
	case 550:
	case 556:
	case 555:
	case 593:
	case 594:
	case 595:
	case 596:
	case 554:
	case 587:
	case 588:
	case 589:
	case 590:
	case 591:
	case 592:
	case 597:
	case 118:
	case 117:
	case 599:
	case 600:
	case 601:
	case 602:
	case 603:
	case 604:
	case 605:
	case 606:
	case 607:
	case 608:
	case 609:
	case 610:
	case 612:
	case 618:
	case 624:
		while (Var0[0 /*6*/].f_3.f_2 > 180f) {
			Var0[0 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[0 /*6*/].f_3.f_2 < -180f) {
			Var0[0 /*6*/].f_3.f_2 += 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 > 180f) {
			Var0[1 /*6*/].f_3.f_2 -= 360f;
		}
		while (Var0[1 /*6*/].f_3.f_2 < -180f) {
			Var0[1 /*6*/].f_3.f_2 += 360f;
		}
		uParam2->f_3.f_2 += Var0[1 /*6*/].f_3.f_2 - Var0[0 /*6*/].f_3.f_2;
		while (uParam2->f_3.f_2 > 180f) {
			uParam2->f_3.f_2 -= 360f;
		}
		while (uParam2->f_3.f_2 < -180f) {
			uParam2->f_3.f_2 += 360f;
		}
		break;
	}
}

// Position - 0xC8FD
struct<6> func_186(int iParam0) {
	struct<6> Var0;

	switch (iParam0) {
	case -1:
	default:
		Var0 = {-1478.436f, -3753.538f, 9.7027f};
		Var0.f_3 = {0f, 0f, -18f};
		break;

	case 0:
		Var0 = {-3555.115f, 1473.013f, 9.7027f};
		Var0.f_3 = {0f, 0f, 57f};
		break;

	case 1:
		Var0 = {-3147.049f, 2827.088f, 9.7027f};
		Var0.f_3 = {0f, 0f, -88f};
		break;

	case 2:
		Var0 = {-3277.473f, 2159.85f, 9.7027f};
		Var0.f_3 = {0f, 0f, -93f};
		break;

	case 3:
		Var0 = {-2822.419f, 4054.84f, 9.7027f};
		Var0.f_3 = {0f, 0f, 72f};
		break;

	case 4:
		Var0 = {-3249.849f, 3704.681f, 9.7027f};
		Var0.f_3 = {0f, 0f, -98f};
		break;

	case 5:
		Var0 = {-2383.193f, 4685.003f, 9.7027f};
		Var0.f_3 = {0f, 0f, 47f};
		break;

	case 6:
		Var0 = {-3224.686f, -215.9825f, 9.7027f};
		Var0.f_3 = {0f, 0f, -3f};
		break;

	case 7:
		Var0 = {-3447.876f, 291.9275f, 9.7027f};
		Var0.f_3 = {0f, 0f, 97f};
		break;

	case 8:
		Var0 = {-2713.098f, -528.3185f, 9.7027f};
		Var0.f_3 = {0f, 0f, -33f};
		break;

	case 9:
		Var0 = {-1981.618f, -1537.269f, 9.7027f};
		Var0.f_3 = {0f, 0f, 142f};
		break;

	case 10:
		Var0 = {-2100.817f, -2533.233f, 9.7027f};
		Var0.f_3 = {0f, 0f, -143f};
		break;

	case 11:
		Var0 = {-1599.642f, -1891.277f, 9.7027f};
		Var0.f_3 = {0f, 0f, 112f};
		break;

	case 12:
		Var0 = {-733.6151f, -3916.985f, 9.7027f};
		Var0.f_3 = {0f, 0f, -168f};
		break;

	case 13:
		Var0 = {-363.3534f, -3568.56f, 9.7027f};
		Var0.f_3 = {0f, 0f, 57f};
		break;

	case 14:
		Var0 = {-1478.436f, -3753.538f, 9.7027f};
		Var0.f_3 = {0f, 0f, -18f};
		break;

	case 15:
		Var0 = {1535.974f, -3061.877f, 9.7027f};
		Var0.f_3 = {0f, 0f, 62f};
		break;

	case 16:
		Var0 = {2471.418f, -2430.93f, 9.7027f};
		Var0.f_3 = {0f, 0f, 12f};
		break;

	case 17:
		Var0 = {2067.371f, -2813.01f, 9.7027f};
		Var0.f_3 = {0f, 0f, -148f};
		break;

	case 18:
		Var0 = {3021.088f, -1513.602f, 9.7027f};
		Var0.f_3 = {0f, 0f, 72f};
		break;

	case 19:
		Var0 = {3025.956f, -704.3854f, 9.7027f};
		Var0.f_3 = {0f, 0f, -98f};
		break;

	case 20:
		Var0 = {2961.863f, -2007.631f, 9.7027f};
		Var0.f_3 = {0f, 0f, 47f};
		break;

	case 21:
		Var0 = {3398.169f, 1958.521f, 9.7027f};
		Var0.f_3 = {0f, 0f, 77f};
		break;

	case 22:
		Var0 = {3428.681f, 1202.06f, 9.7027f};
		Var0.f_3 = {0f, 0f, -148f};
		break;

	case 23:
		Var0 = {3787.83f, 2567.884f, 9.7027f};
		Var0.f_3 = {0f, 0f, -93f};
		break;

	case 24:
		Var0 = {4235.946f, 4004.252f, 9.7027f};
		Var0.f_3 = {0f, 0f, -118f};
		break;

	case 25:
		Var0 = {4245.151f, 4595.375f, 9.7027f};
		Var0.f_3 = {0f, 0f, -68f};
		break;

	case 26:
		Var0 = {4209.057f, 3392.705f, 9.7027f};
		Var0.f_3 = {0f, 0f, -98f};
		break;

	case 27:
		Var0 = {3738.81f, 5768.252f, 9.7027f};
		Var0.f_3 = {0f, 0f, -43f};
		break;

	case 28:
		Var0 = {3472.966f, 6315.245f, 9.7027f};
		Var0.f_3 = {0f, 0f, -23f};
		break;

	case 29:
		Var0 = {3693.468f, 5194.659f, 9.7027f};
		Var0.f_3 = {0f, 0f, 122f};
		break;

	case 30:
		Var0 = {572.9806f, 7142.138f, 9.7027f};
		Var0.f_3 = {0f, 0f, -58f};
		break;

	case 31:
		Var0 = {2024.036f, 6907.536f, 9.7027f};
		Var0.f_3 = {0f, 0f, -173f};
		break;

	case 32:
		Var0 = {1377.296f, 6863.23f, 9.7027f};
		Var0.f_3 = {0f, 0f, -3f};
		break;

	case 33:
		Var0 = {-1169.36f, 6000.214f, 9.7027f};
		Var0.f_3 = {0f, 0f, -88f};
		break;

	case 34:
		Var0 = {-759.2205f, 6573.955f, 9.7027f};
		Var0.f_3 = {0f, 0f, -153f};
		break;

	case 35:
		Var0 = {-373.8432f, 6964.86f, 9.7027f};
		Var0.f_3 = {0f, 0f, -108f};
		break;
	}
	return Var0;
}

//Position - 0xCEFD
int func_187(vector3 vParam0, int* iParam3, int iParam4)
{
	int iVar0;

	if (iParam4 != 999) {
		if (object::is_point_in_angled_area(vParam0, Global_1049427[iParam4 /*1942*/].f_146.f_57[0 /*8*/],
											Global_1049427[iParam4 /*1942*/].f_146.f_57[0 /*8*/].f_3,
											Global_1049427[iParam4 /*1942*/].f_146.f_57[0 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam4 /*1942*/].f_146.f_57[1 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam4 /*1942*/].f_146.f_57[1 /*8*/],
												Global_1049427[iParam4 /*1942*/].f_146.f_57[1 /*8*/].f_3,
												Global_1049427[iParam4 /*1942*/].f_146.f_57[1 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam4 /*1942*/].f_146.f_57[2 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam4 /*1942*/].f_146.f_57[2 /*8*/],
												Global_1049427[iParam4 /*1942*/].f_146.f_57[2 /*8*/].f_3,
												Global_1049427[iParam4 /*1942*/].f_146.f_57[2 /*8*/].f_6, 0, 1)) {
			return 1;
		}
	}
	else {
		iVar0 = 1;
		while (iVar0 <= 7) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 34;
		while (iVar0 <= 43) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 61;
		while (iVar0 <= 65) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 73;
		while (iVar0 <= 76) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 77;
		while (iVar0 <= 82) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 83;
		while (iVar0 <= 85) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		iVar0 = 87;
		while (iVar0 <= 90) {
			if (func_188(vParam0, iVar0)) {
				*iParam3 = iVar0;
				return 1;
			}
			iVar0++;
		}
		if (func_188(vParam0, 8)) {
			return 1;
		}
		if (func_188(vParam0, 17)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xD162
bool func_188(vector3 vParam0, int iParam3) {
	int iVar0;

	if (iParam3 != 999) {
		if (object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/],
											Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/].f_3,
											Global_1049427[iParam3 /*1942*/].f_146.f_57[0 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/],
												Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_3,
												Global_1049427[iParam3 /*1942*/].f_146.f_57[1 /*8*/].f_6, 0, 1) ||
			Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_6 != 0f &&
				object::is_point_in_angled_area(vParam0, Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/],
												Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_3,
												Global_1049427[iParam3 /*1942*/].f_146.f_57[2 /*8*/].f_6, 0, 1)) {
			return true;
		}
	}
	else {
		iVar0 = 1;
		while (iVar0 <= 7) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 34;
		while (iVar0 <= 43) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 61;
		while (iVar0 <= 65) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 73;
		while (iVar0 <= 76) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 77;
		while (iVar0 <= 82) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 83;
		while (iVar0 <= 85) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		iVar0 = 87;
		while (iVar0 <= 90) {
			if (func_188(vParam0, iVar0)) {
				return true;
			}
			iVar0++;
		}
		if (func_188(vParam0, 8)) {
			return true;
		}
		if (func_188(vParam0, 17)) {
			return true;
		}
	}
	return false;
}

// Position - 0xD3A4
Vector3 func_189(int iParam0) { return entity::get_entity_coords(player::get_player_ped(iParam0), 0); }

// Position - 0xD3B7
int func_190(int iParam0) {
	int iVar0;

	iVar0 = 0;
	switch (func_192()) {
	default: iVar0 = 0; break;

	case 10:
	case 16: iVar0 = 1; break;
	}
	if (iParam0) {
		if (func_191()) {
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0xD3F4
bool func_191() {
	switch (func_192()) {
	default: return false;

	case 12: return true;
	}
}

// Position - 0xD410
int func_192() { return Global_1751531; }

// Position - 0xD41C
int func_193(int iParam0) {
	if (func_194(iParam0) == 36 || func_194(iParam0) == 39 || func_194(iParam0) == 33 || func_194(iParam0) == 34 ||
		func_194(iParam0) == 35) {
		return 1;
	}
	return 0;
}

// Position - 0xD471
int func_194(int iParam0) { return Global_1591201[iParam0 /*602*/].f_188; }

// Position - 0xD484
bool func_195() { return Global_1591201[player::player_id() /*602*/].f_188 != 0; }

// Position - 0xD49B
bool func_196() { return Global_2443134.f_570; }

// Position - 0xD4AA
void func_197(int iParam0) { Global_1757074.f_42 = iParam0; }

// Position - 0xD4BA
bool func_198() { return Global_1757074.f_42; }

// Position - 0xD4C8
void func_199() { Global_2452971 = 1; }

// Position - 0xD4D5
bool func_200() { return Global_2452971; }

// Position - 0xD4E1
bool func_201() { return Global_2452972; }

// Position - 0xD4ED
void func_202() { Global_2443134.f_724 = 0; }

// Position - 0xD4FD
bool func_203() { return Global_2443134.f_724; }

// Position - 0xD50C
void func_204(int iParam0) { Global_1751531.f_1766 = iParam0; }

// Position - 0xD51D
void func_205() { Global_2452972 = 1; }

// Position - 0xD52A
int func_206() {
	switch (func_192()) {
	default: return 0;

	case 4:
	case 5:
	case 10:
	case 11:
	case 12:
	case 13: return 1;
	}
}

// Position - 0xD564
bool func_207() { return Global_2443905.f_5875; }

// Position - 0xD573
int func_208() { return Global_2452970; }

// Position - 0xD57F
bool func_209() { return Global_1751531.f_1766; }

// Position - 0xD58E
bool func_210(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_211(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0xD5D9
int func_211(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_664();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0xD61A
void func_212(int iParam0) {
	ui::_remove_loading_prompt();
	if (iParam0) {
		ui::_0xC65AB383CD91DF98();
	}
}

// Position - 0xD62F
void func_213(int iParam0, int iParam1) {
	struct<295> Var0;
	int iVar360;
	int iVar361;
	struct<2> Var362;
	struct<10> Var364;

	Var0 = 28;
	Var0.f_253 = 5;
	Var0.f_294 = 30;
	iVar360 = 0;
	Var0[0 /*9*/] = 0f;
	Var0[0 /*9*/].f_1 = 0f;
	Var0[0 /*9*/].f_2 = 0.028f;
	Var0[0 /*9*/].f_3 = 0.045f;
	Var0[0 /*9*/].f_4 = 255;
	Var0[0 /*9*/].f_5 = 255;
	Var0[0 /*9*/].f_6 = 255;
	Var0[0 /*9*/].f_7 = 250;
	iVar361 = player::get_player_ped(iParam0);
	graphics::request_streamed_texture_dict("MPInventory", 0);
	if (graphics::has_streamed_texture_dict_loaded("MPInventory")) {
		if (func_224(&Var0, iVar361, iVar360, 0, 0)) {
			Var364 = 0;
			Var364.f_1 = 0.202f;
			Var364.f_2 = 0.276f;
			Var364.f_3 = 255;
			Var364.f_4 = 255;
			Var364.f_5 = 255;
			Var364.f_6 = 255;
			Var364.f_7 = 1;
			Var364.f_9 = 0.872f;
			func_223(&Var364, iParam1);
			Var362 = {func_220(&Var0, iVar361, Var0.f_294[0 /*2*/], 0, 13, 0)};
			func_214(&Var362, &Var364, "V", 0, 1, 1);
			graphics::clear_draw_origin();
		}
	}
}

// Position - 0xD74A
void func_214(var *uParam0, var *uParam1, char *sParam2, char *sParam3, int iParam4, int iParam5) {
	char *sVar0;

	if (!func_21(sParam2)) {
		if (func_218()) {
			func_217(uParam1, 0);
			ui::set_text_justification(iParam5);
			if (func_21(sParam3)) {
				sVar0 = "STRING";
			}
			else {
				sVar0 = sParam3;
			}
			ui::begin_text_command_display_text(sVar0);
			ui::_set_notification_color_next(iParam4);
			ui::add_text_component_substring_player_name(sParam2);
			ui::end_text_command_display_text(func_216(*uParam0), func_215(uParam0->f_1), 0);
		}
	}
}

// Position - 0xD7AC
float func_215(float fParam0) { return fParam0 + fLocal_13; }

// Position - 0xD7B9
float func_216(float fParam0) { return fParam0 + fLocal_12; }

// Position - 0xD7C6
void func_217(var *uParam0, int iParam1) {
	ui::set_text_font(*uParam0);
	if (uParam0->f_8 != 0f || uParam0->f_9 != 0f) {
		ui::set_text_wrap(uParam0->f_8, uParam0->f_9);
	}
	ui::set_text_scale(uParam0->f_1, uParam0->f_2);
	ui::set_text_colour(uParam0->f_3, uParam0->f_4, uParam0->f_5, uParam0->f_6);
	switch (uParam0->f_7) {
	case 0: break;

	case 1:
		ui::set_text_outline();
		ui::set_text_drop_shadow();
		break;

	case 3: ui::set_text_drop_shadow(); break;

	case 2: ui::set_text_outline(); break;
	}
	if (iParam1) {
		graphics::_set_2d_layer(4);
	}
}

// Position - 0xD85F
bool func_218() {
	if (func_219()) {
		return true;
	}
	if (cam::is_screen_faded_out()) {
		return false;
	}
	if (cam::is_screen_fading_out() || cam::is_screen_fading_in()) {
		return false;
	}
	if (gameplay::is_frontend_fading()) {
		return false;
	}
	return true;
}

// Position - 0xD89E
bool func_219() { return Global_1312438; }

// Position - 0xD8AA
struct<2> func_220(float fParam0, int iParam1, struct<2> Param2, int iParam4, int iParam5, int iParam6) {
	struct<2> Var0;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	struct<8> Var7;
	float fVar23;
	float fVar24;
	float fVar25;
	float fVar26;
	float fVar27;
	float fVar28;
	float fVar29;
	float fVar30;
	float fVar31;
	float fVar32;
	float fVar33;
	float fVar34;
	float fVar35;

	Var0 = {Param2};
	fVar2 = Var0;
	fVar3 = Var0.f_1;
	fVar5 = func_222(fParam0, iParam1, 0, 0);
	if (fVar5 == 0f) {
	}
	fVar6 = func_221(player::get_player_name(network::network_get_player_index_from_ped(iParam1)));
	StringCopy(&Var7, player::get_player_name(network::network_get_player_index_from_ped(iParam1)), 64);
	fVar6 += func_221(&Var7);
	fVar23 = gameplay::get_distance_between_coords(func_189(network::network_get_player_index_from_ped(iParam1)),
												   cam::get_gameplay_cam_coord(), 1);
	fVar24 = 0f;
	fVar25 = 0f;
	fVar26 = fVar25 * fVar23;
	fVar26 += fVar24 + 0.031f;
	fVar27 = 0.018f;
	fVar28 = 0.006f;
	fVar29 = -0.016f;
	fVar30 = fVar6 / 5.75f;
	fVar31 = 0f;
	if (iParam6) {
		fVar31 = 0.002f;
	}
	fVar32 = fVar27;
	fVar33 = fVar26;
	fVar34 = fVar28;
	fVar35 = fVar29;
	fVar4 = fVar26 + fVar27 * IntToFloat(iParam4);
	fVar3 += fVar4;
	switch (iParam5) {
	case 10:
		fVar2 += fVar30;
		fVar3 += fVar31;
		break;

	case 13:
		fVar2 += -0.003f;
		fVar3 += -0.043f;
		break;
	}
	Var0 = fVar2;
	Var0.f_1 = fVar3;
	fVar27 = fVar32;
	fVar26 = fVar33;
	fVar28 = fVar34;
	fVar29 = fVar35;
	return Var0;
}

//Position - 0xD9D8
float func_221(char* sParam0)
{
	ui::_begin_text_command_width("STRING");
	ui::add_text_component_substring_player_name(sParam0);
	return ui::_end_text_command_get_width(1);
}

// Position - 0xD9F3
float func_222(var *uParam0, int iParam1, int iParam2, int iParam3) {
	vector3 vVar0;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;

	if (iParam2 != 0) {
		if (vehicle::is_vehicle_driveable(iParam2, 0)) {
			vVar0 = {entity::get_entity_coords(iParam2, 1)};
		}
	}
	else if (iParam3 != 0) {
		if (entity::does_entity_exist(iParam3)) {
			vVar0 = {entity::get_entity_coords(iParam3, 1)};
		}
	}
	else {
		vVar0 = {entity::get_entity_coords(iParam1, 1)};
	}
	fVar3 = gameplay::get_distance_between_coords(cam::get_gameplay_cam_coord(), vVar0, 1);
	if (uParam0->f_356 == 0) {
	}
	fVar4 = 50f;
	fVar5 = 6f;
	fVar6 = cam::get_gameplay_cam_fov() * fVar3 / (fVar4 * fVar5);
	if (fVar6 > 1f) {
		return fVar6;
	}
	return 1f;
}

// Position - 0xDA7F
void func_223(var *uParam0, int iParam1) {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;

	ui::get_hud_colour(iParam1, &uVar0, &uVar1, &uVar2, &uVar3);
	uParam0->f_3 = uVar0;
	uParam0->f_4 = uVar1;
	uParam0->f_5 = uVar2;
}

// Position - 0xDAA7
bool func_224(float fParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	var uVar0;
	var uVar1;
	int iVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	vector3 vVar7;
	var uVar10;
	vector3 vVar13;
	var uVar16;
	vector3 vVar19;
	var uVar22;
	vector3 vVar25;
	vector3 vVar28;

	if (iParam2 != 13 && iParam2 != 14 && iParam2 != 15) {
		fVar4 = entity::get_entity_heading(iParam1);
	}
	else {
		if (iParam2 == 13) {
			if (func_226(func_228(0))) {
				fVar4 = entity::get_entity_heading(func_225());
			}
		}
		if (iParam2 == 14) {
			if (iParam3 != 0) {
				if (vehicle::is_vehicle_driveable(iParam3, 0)) {
					fVar4 = entity::get_entity_heading(iParam3);
				}
			}
		}
		else if (iParam2 == 15) {
			if (iParam4 != 0) {
				if (entity::does_entity_exist(iParam4)) {
					fVar4 = entity::get_entity_heading(iParam4);
				}
			}
		}
	}
	switch (iParam2) {
	case 0:
		fVar3 = 1.2f;
		fVar5 = 0f;
		break;

	case 1:
		fVar3 = 1.24f;
		fVar5 = -0.46f;
		fVar6 = -0.1f;
		break;

	case 2:
		fVar3 = 1.24f;
		fVar5 = 0.46f;
		fVar6 = -0.1f;
		break;

	case 3:
		fVar3 = 1f;
		fVar5 = -0.46f;
		fVar6 = -1f;
		break;

	case 4:
		fVar3 = 1f;
		fVar5 = 0.46f;
		fVar6 = -1f;
		break;

	case 11:
		fVar3 = 1.65f;
		fVar5 = 0f;
		fVar6 = 0f;
		break;

	case 12:
		fVar3 = 1.45f;
		fVar5 = 0f;
		fVar6 = -0.5f;
		break;

	case 13:
		fVar3 = 0.85f;
		fVar5 = 0f;
		fVar6 = 0.75f;
		if (iParam3 != 0) {
			if (func_226(func_228(0))) {
				gameplay::get_model_dimensions(entity::get_entity_model(func_225()), &uVar10, &vVar13);
				fVar6 = vVar13.z + 0.75f;
			}
		}
		break;

	case 14:
		fVar3 = 0.85f;
		fVar5 = 0f;
		fVar6 = 0.75f;
		if (iParam3 != 0) {
			if (vehicle::is_vehicle_driveable(iParam3, 0)) {
				gameplay::get_model_dimensions(entity::get_entity_model(iParam3), &uVar16, &vVar19);
				fVar6 = vVar19.z + 0.105f;
			}
		}
		break;

	case 15:
		fVar3 = 0f;
		fVar5 = 0f;
		fVar6 = 0.5f;
		if (iParam4 != 0) {
			if (entity::does_entity_exist(iParam4)) {
				gameplay::get_model_dimensions(entity::get_entity_model(iParam4), &uVar22, &vVar25);
				fVar6 = vVar25.z + 0.25f;
			}
		}
		break;
	}
	if (iParam2 != 13 && iParam2 != 14 && iParam2 != 15) {
		vVar7 = {entity::get_entity_coords(iParam1, 1)};
	}
	else {
		if (iParam2 == 13) {
			if (func_226(func_228(0))) {
				vVar7 = {entity::get_entity_coords(func_225(), 1)};
			}
		}
		if (iParam2 == 14) {
			if (vehicle::is_vehicle_driveable(iParam3, 0)) {
				vVar7 = {entity::get_entity_coords(iParam3, 1)};
			}
		}
		if (iParam2 == 15) {
			if (entity::does_entity_exist(iParam4)) {
				vVar7 = {entity::get_entity_coords(iParam4, 1)};
			}
		}
	}
	if (iParam2 == 14) {
		vVar28 = {object::_get_object_offset_from_coords(vVar7, fVar4, fVar5, fVar3, fVar6)};
	}
	else if (iParam2 != 15) {
		vVar28 = {object::_get_object_offset_from_coords(vVar7, fVar4, fVar5, fVar6, fVar3)};
	}
	else {
		vVar28 = {vVar7.x, vVar7.y, vVar7.z + fVar6};
	}
	if (graphics::get_screen_coord_from_world_coord(vVar28, &uVar0, &uVar1)) {
		graphics::set_draw_origin(vVar28, 0);
		iVar2 = 0;
		while (iVar2 <= 5) {
			(*fParam0)[iVar2 /*9*/] = 0f;
			(*fParam0)[iVar2 /*9*/].f_1 = 0f;
			fParam0->f_294[iVar2 /*2*/] = 0f;
			fParam0->f_294[iVar2 /*2*/].f_1 = 0f;
			iVar2++;
		}
		return true;
	}
	return false;
}

// Position - 0xDDD3
var func_225() {
	if (gameplay::get_hash_key(script::get_this_script_name()) == joaat("freemode")) {
		if (network::network_does_network_id_exist(Global_2421664[player::player_id() /*358*/].f_48) &&
			network::network_does_entity_exist_with_network_id(Global_2421664[player::player_id() /*358*/].f_48)) {
			return network::net_to_veh(Global_2421664[player::player_id() /*358*/].f_48);
		}
	}
	return Global_2494199.f_275;
}

// Position - 0xDE30
bool func_226(int iParam0) {
	if (network::network_does_network_id_exist(iParam0)) {
		return !func_227(network::net_to_veh(iParam0));
	}
	return false;
}

// Position - 0xDE50
int func_227(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (entity::is_entity_dead(iParam0, 0)) {
			return 1;
		}
		else if (!vehicle::is_vehicle_driveable(iParam0, 0)) {
			return 1;
		}
	}
	else {
		return 1;
	}
	return 0;
}

// Position - 0xDE89
int func_228(int iParam0) {
	if (gameplay::get_hash_key(script::get_this_script_name()) != joaat("freemode")) {
	}
	else if (func_226(Global_2421664[player::player_id() /*358*/].f_48) || iParam0 == 0) {
		return Global_2421664[player::player_id() /*358*/].f_48;
	}
	return 0;
}

// Position - 0xDED3
bool func_229(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0xDF1D
bool func_230() {
	if (func_6() == 0) {
		return true;
	}
	return false;
}

// Position - 0xDF32
int func_231(int iParam0) {
	if (!func_229(iParam0, 0, 1)) {
		return 0;
	}
	return Global_1591201[iParam0 /*602*/].f_35;
}

// Position - 0xDF55
void func_232(var *uParam0, var *uParam1, int *iParam2) {
	bool bVar0;
	int iVar1;

	if (!func_351()) {
		return;
	}
	func_335();
	func_297(uParam0, uParam1, iParam2);
	if (Global_1318036) {
		if (socialclub::_0x3001BEF2FECA3680()) {
			if (socialclub::_0x92DA6E70EF249BD1("scriptDisplay", &iVar1)) {
				if (func_296(iVar1)) {
					if (iVar1 != Global_2443905.f_3255) {
						if (iVar1 != 3) {
							if (!func_294()) {
								if (socialclub::_0xD8122C407663B995()) {
									Global_2443905.f_3255 = iVar1;
								}
								return;
							}
							if (!func_293(joaat("mpply_big_feed_init"))) {
								if (socialclub::_0xD8122C407663B995()) {
									Global_2443905.f_3255 = iVar1;
								}
								return;
							}
						}
						else if (!func_292()) {
							if (socialclub::_0xD8122C407663B995()) {
								Global_2443905.f_3255 = iVar1;
							}
							return;
						}
						Global_2443905.f_3255 = iVar1;
						graphics::_call_scaleform_movie_function_float_params(
							Global_2443905.f_2842.f_85, "SET_NEWS_CONTEXT", system::to_float(iVar1), -1082130432,
							-1082130432, -1082130432, -1082130432);
						if (iVar1 != 3) {
							bVar0 = true;
						}
						else {
							gameplay::set_bit(&Global_2443905.f_3255.f_1, 3);
						}
					}
				}
			}
		}
	}
	func_258(uParam0, *iParam2);
	if (bVar0) {
		switch (iVar1) {
		case 1:
			if (!func_251()) {
				if (socialclub::_0xD8122C407663B995()) {
					Global_2443905.f_3255 = iVar1;
				}
				return;
			}
			break;

		case 2:
			if (!func_233()) {
				if (socialclub::_0xD8122C407663B995()) {
					Global_2443905.f_3255 = iVar1;
				}
				return;
			}
			break;

		case 3: break;
		}
	}
}

// Position - 0xE0CC
int func_233() {
	int iVar0;
	int iVar1;
	struct<4> Var2;
	char cVar6[16];
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	struct<4> Var14[9];
	int iVar51;
	int iVar52;
	int iVar53;
	struct<4> Var54;

	iVar51 = 0;
	iVar0 = 0;
	while (iVar0 <= 9 - 1) {
		iVar12 = iVar0;
		iVar1 = func_250(iVar12);
		if (iVar1 != 145) {
			if (func_238(iVar1)) {
				iVar13 = func_237(iVar1);
				iVar10 = func_707(iVar13);
				iVar13 = func_236(iVar1);
				iVar11 = func_707(iVar13);
				Var14[iVar0 /*4*/] = iVar12;
				Var14[iVar0 /*4*/].f_1 = system::to_float(iVar10) / system::to_float(iVar11);
				Var14[iVar0 /*4*/].f_2 = iVar10;
				Var14[iVar0 /*4*/].f_3 = iVar11;
				if (Var14[iVar0 /*4*/].f_3 == 0) {
					return 0;
				}
				iVar51++;
			}
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 <= iVar51 - 1) {
		iVar52 = iVar0;
		iVar53 = iVar0 + 1;
		while (iVar53 <= iVar51 - 1) {
			if (Var14[iVar53 /*4*/].f_1 < Var14[iVar52 /*4*/].f_1) {
				iVar52 = iVar53;
			}
			iVar53++;
		}
		Var54 = {Var14[iVar0 /*4*/]};
		Var14[iVar0 /*4*/] = {Var14[iVar52 /*4*/]};
		Var14[iVar52 /*4*/] = {Var54};
		iVar1 = func_250(Var14[iVar0 /*4*/]);
		Var2 = {Global_101700.f_27009[iVar1 /*29*/].f_3};
		StringCopy(&cVar6, ui::_get_label_text(&Global_101700.f_27009[iVar1 /*29*/].f_7), 16);
		if (Var14[iVar0 /*4*/].f_2 > Var14[iVar0 /*4*/].f_3) {
			Var14[iVar0 /*4*/].f_2 = Var14[iVar0 /*4*/].f_3;
		}
		func_234(iVar0, Var14[iVar0 /*4*/].f_2, Var14[iVar0 /*4*/].f_3, &Var2, &cVar6);
		iVar0++;
	}
	return 1;
}

// Position - 0xE258
void func_234(int iParam0, int iParam1, int iParam2, char *sParam3, char *sParam4) {
	if (graphics::has_scaleform_movie_loaded(Global_2443905.f_2842.f_85)) {
		graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(iParam0);
		graphics::_push_scaleform_movie_function_parameter_string(sParam4);
		func_235(sParam3);
		graphics::begin_text_command_scaleform_string("PM_UGEN_NUM");
		ui::add_text_component_integer(iParam1);
		ui::add_text_component_integer(iParam2);
		graphics::end_text_command_scaleform_string();
		graphics::_push_scaleform_movie_function_parameter_float(system::to_float(iParam1) / system::to_float(iParam2));
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xE2C1
void func_235(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0xE2D3
int func_236(int iParam0) {
	switch (iParam0) {
	case 12: return joaat("mpply_total_contact_0");

	case 19: return joaat("mpply_total_contact_1");

	case 86: return joaat("mpply_total_contact_2");

	case 20: return joaat("mpply_total_contact_3");

	case 31: return joaat("mpply_total_contact_4");

	case 2: return joaat("mpply_total_contact_5");

	case 18: return joaat("mpply_total_contact_6");

	default:
	}
	return -1;
}

// Position - 0xE345
int func_237(int iParam0) {
	switch (iParam0) {
	case 12: return joaat("mpply_unique_contact_0");

	case 19: return joaat("mpply_unique_contact_1");

	case 86: return joaat("mpply_unique_contact_2");

	case 20: return joaat("mpply_unique_contact_3");

	case 31: return joaat("mpply_unique_contact_4");

	case 2: return joaat("mpply_unique_contact_5");

	case 18: return joaat("mpply_unique_contact_6");

	default:
	}
	return -1;
}

// Position - 0xE3B7
bool func_238(int iParam0) {
	int iVar0;
	int iVar1;

	switch (iParam0) {
	case 86: iVar1 = func_249(); return iVar1;

	case 19: iVar1 = func_249(); return iVar1;

	case 18: iVar1 = func_249(); return iVar1;

	case 12: iVar1 = func_246(); return iVar1;

	case 31:
		iVar0 = func_39(1195, -1, 0);
		iVar1 = gameplay::is_bit_set(iVar0, 6);
		return iVar1;

	case 20: iVar1 = func_239(); return iVar1;

	case 2: iVar1 = func_239(); return iVar1;

	default:
	}
	iVar1 = 0;
	return iVar1;
	return false;
}

// Position - 0xE454
int func_239() {
	int iVar0;

	if (func_243(player::player_id())) {
		return 1;
	}
	iVar0 = Global_1363267[func_40(-1)];
	if (gameplay::is_bit_set(iVar0, 5)) {
		func_240(1);
		return 1;
	}
	return 0;
}

// Position - 0xE48C
void func_240(int iParam0) {
	if (iParam0) {
		if (!gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 26)) {
			gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_139, 26);
			func_241(player::player_id(), 2);
			func_241(player::player_id(), 20);
		}
	}
	else if (gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 26)) {
		gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_139, 26);
	}
}

// Position - 0xE502
void func_241(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_242(iParam1);
	iVar1 = iVar0;
	gameplay::set_bit(&Global_1591201[iParam0 /*602*/].f_491, iVar1);
}

// Position - 0xE528
int func_242(int iParam0) {
	switch (iParam0) {
	case 86: return 0;

	case 19: return 1;

	case 12: return 2;

	case 31: return 3;

	case 20: return 4;

	case 18: return 5;

	case 2: return 6;

	case 76: return 7;

	default:
	}
	return 1;
}

// Position - 0xE588
bool func_243(int iParam0) {
	if (func_245()) {
		return true;
	}
	if (func_244()) {
		return true;
	}
	return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_139, 26);
}

// Position - 0xE5B7
bool func_244() { return Global_1315221; }

// Position - 0xE5C3
bool func_245() { return Global_1315223; }

// Position - 0xE5CF
int func_246() {
	int iVar0;

	if (func_248(player::player_id())) {
		return 1;
	}
	iVar0 = Global_1363267[func_40(-1)];
	if (gameplay::is_bit_set(iVar0, 2)) {
		func_247(1);
		return 1;
	}
	return 0;
}

// Position - 0xE607
void func_247(int iParam0) {
	if (iParam0) {
		if (!gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 25)) {
			func_241(player::player_id(), 12);
			gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_139, 25);
		}
	}
	else if (gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 25)) {
		gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_139, 25);
	}
}

// Position - 0xE674
bool func_248(int iParam0) {
	if (func_245()) {
		return true;
	}
	if (func_244()) {
		return true;
	}
	return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_139, 25);
}

// Position - 0xE6A3
int func_249() {
	int iVar0;

	if (gameplay::is_bit_set(Global_2494199.f_1639, 7)) {
		return 1;
	}
	iVar0 = Global_1363267[func_40(-1)];
	if (gameplay::is_bit_set(iVar0, 6)) {
		gameplay::set_bit(&Global_2494199.f_1639, 7);
		return 1;
	}
	if (func_245()) {
		return 1;
	}
	if (func_244()) {
		return 1;
	}
	return 0;
}

// Position - 0xE6FC
int func_250(int iParam0) {
	switch (iParam0) {
	case 0: return 86;

	case 1: return 19;

	case 2: return 12;

	case 3: return 31;

	case 4: return 20;

	case 5: return 18;

	case 6: return 2;

	case 7: return 76;

	case 8: return 22;

	default:
	}
	return 19;
}

// Position - 0xE76F
int func_251() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	struct<4> Var7[9];
	int iVar44;
	int iVar45;
	int iVar46;
	struct<4> Var47;

	iVar0 = 0;
	while (iVar0 <= 9 - 1) {
		iVar5 = iVar0;
		func_257(iVar5, &iVar1, &iVar2);
		iVar6 = func_256(iVar1, iVar2, 0);
		iVar3 = func_707(iVar6);
		iVar6 = func_256(iVar1, iVar2, 1);
		iVar3 += func_707(iVar6);
		iVar6 = func_255(iVar1, iVar2, 0);
		iVar4 = func_707(iVar6);
		iVar6 = func_255(iVar1, iVar2, 1);
		iVar4 += func_707(iVar6);
		Var7[iVar0 /*4*/] = iVar5;
		Var7[iVar0 /*4*/].f_2 = iVar3;
		Var7[iVar0 /*4*/].f_3 = iVar4;
		Var7[iVar0 /*4*/].f_1 = system::to_float(iVar3) / system::to_float(iVar4);
		if (Var7[iVar0 /*4*/].f_3 == 0) {
			return 0;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 <= 9 - 1) {
		iVar44 = iVar0;
		iVar45 = iVar0 + 1;
		while (iVar45 <= 9 - 1) {
			if (Var7[iVar45 /*4*/].f_1 < Var7[iVar44 /*4*/].f_1) {
				iVar44 = iVar45;
			}
			iVar45++;
		}
		Var47 = {Var7[iVar0 /*4*/]};
		Var7[iVar0 /*4*/] = {Var7[iVar44 /*4*/]};
		Var7[iVar44 /*4*/] = {Var47};
		func_257(Var7[iVar0 /*4*/], &iVar1, &iVar2);
		if (iVar1 == 2) {
			iVar2 = -1;
		}
		func_254(iVar1, iVar2, &iVar46);
		if (Var7[iVar0 /*4*/].f_2 > Var7[iVar0 /*4*/].f_3) {
			Var7[iVar0 /*4*/].f_2 = Var7[iVar0 /*4*/].f_3;
		}
		func_252(iVar0, Var7[iVar0 /*4*/].f_2, Var7[iVar0 /*4*/].f_3, func_253(iVar1, iVar2, 0, 0, 1, 0), iVar46);
		iVar0++;
	}
	return 1;
}

// Position - 0xE90D
void func_252(int iParam0, int iParam1, int iParam2, char *sParam3, int iParam4) {
	if (graphics::has_scaleform_movie_loaded(Global_2443905.f_2842.f_85)) {
		graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(iParam0);
		graphics::_push_scaleform_movie_function_parameter_int(iParam4);
		func_235(sParam3);
		graphics::begin_text_command_scaleform_string("PM_UGEN_NUM");
		ui::add_text_component_integer(iParam1);
		ui::add_text_component_integer(iParam2);
		graphics::end_text_command_scaleform_string();
		graphics::_push_scaleform_movie_function_parameter_float(system::to_float(iParam1) / system::to_float(iParam2));
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xE976
char *func_253(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	if (iParam0 == 1) {
		if (iParam1 == 1) {
			return "FMMC_RSTAR_TDM";
		}
		else if (iParam1 == 2) {
			return "FMMC_RSTAR_VDM";
		}
		else {
			return "FMMC_RSTAR_DM";
		}
	}
	else if (iParam0 == 2) {
		if (iParam1 == 0 || iParam1 == 1) {
			return "FMMC_RSTAR_LR";
		}
		else if (iParam1 == 10 || iParam1 == 11) {
			return "FMMC_RSTAR_OFR";
		}
		else if (iParam1 == 6 || iParam1 == 7) {
			return "FMMC_RSTAR_STR";
		}
		else if (iParam1 == 12 || iParam1 == 13) {
			return "FMMC_RSTAR_BR";
		}
		else if (iParam1 == 2 || iParam1 == 3) {
			return "FMMC_RSTAR_WR";
		}
		else if (iParam1 == 4 || iParam1 == 5) {
			return "FMMC_RSTAR_AR";
		}
		return "FMMC_RSTAR_RA";
	}
	else if (iParam0 == 0 || iParam0 == 9) {
		if (iParam1 == 5) {
			return "FMMC_RSTAR_MLTS";
		}
		else if (iParam1 == 9) {
			return "FMMC_RSTAR_MCP";
		}
		else if (iParam1 == 6) {
			if (gameplay::is_bit_set(iParam2, 20)) {
				return "FMMC_RSTAR_CTNT";
			}
			else if (gameplay::is_bit_set(iParam2, 21)) {
				return "FMMC_RSTAR_GTA";
			}
			else if (gameplay::is_bit_set(iParam2, 22)) {
				return "FMMC_RSTAR_HOLD";
			}
			else if (gameplay::is_bit_set(iParam2, 23)) {
				return "FMMC_RSTAR_RAID";
			}
			else {
				return "FMMC_RSTAR_MCTF";
			}
		}
		else if (iParam1 == 4) {
			if (iParam5 > 0 || iParam3 != 0 || gameplay::is_bit_set(iParam2, 15) || gameplay::is_bit_set(iParam2, 18) ||
				gameplay::is_bit_set(iParam2, 19) || gameplay::is_bit_set(iParam2, 29) ||
				gameplay::is_bit_set(iParam2, 28)) {
				return "FMMC_RSTAR_MAM";
			}
			else {
				return "FMMC_RSTAR_MVS";
			}
		}
		else if (iParam1 == 1) {
			if (iParam4) {
				return "FMMC_RSTAR_HFS";
			}
			else {
				return "FMMC_RSTAR_HF";
			}
		}
		else if (iParam1 == 7) {
			if (iParam4) {
				return "FMMC_RSTAR_HPS";
			}
			else {
				return "FMMC_RSTAR_HP";
			}
		}
	}
	else if (iParam0 == 6) {
		return "FMMC_RSTAR_GA";
	}
	else if (iParam0 == 3) {
		return "FMMC_RSTAR_HM";
	}
	else if (iParam0 == 8) {
		return "FMMC_RSTAR_BJ";
	}
	else if (iParam0 == 7) {
		return "FMMC_RSTAR_MLTS";
	}
	else if (iParam0 == 165) {
		return "FMMC_RSTAR_MCP";
	}
	else if (iParam0 == 134) {
		return "AMTT_BLIP";
	}
	if (iParam4) {
		return "FMMC_RSTAR_OM";
	}
	return "FMMC_RSTAR_MS";
}

// Position - 0xEC17
void func_254(int iParam0, int iParam1, int *iParam2) {
	*iParam2 = iParam0;
	if (*iParam2 == 1) {
		if (iParam1 == 1) {
			*iParam2 = 4;
		}
		else if (iParam1 == 2) {
			*iParam2 = 9;
		}
	}
	else if (*iParam2 == 2) {
		if (iParam1 == 0 || iParam1 == 1) {
			*iParam2 = 10;
		}
		else if (iParam1 == 6 || iParam1 == 7) {
			*iParam2 = 19;
		}
		else if (iParam1 == 10 || iParam1 == 11) {
			*iParam2 = 11;
		}
		else if (iParam1 == 12 || iParam1 == 13) {
			*iParam2 = 12;
		}
		else if (iParam1 == 2 || iParam1 == 3) {
			*iParam2 = 13;
		}
		else if (iParam1 == 4 || iParam1 == 5) {
			*iParam2 = 14;
		}
	}
	else if (*iParam2 == 0 || *iParam2 == 9) {
		if (iParam1 == 5) {
			*iParam2 = 15;
		}
		else if (iParam1 == 6) {
			*iParam2 = 16;
		}
		else if (iParam1 == 1) {
			*iParam2 = 18;
		}
		else if (iParam1 == 7) {
			*iParam2 = 17;
		}
	}
	else if (*iParam2 == 7) {
		*iParam2 = 15;
	}
	else if (*iParam2 == 134) {
		*iParam2 = 22;
	}
}

// Position - 0xED4F
int func_255(int iParam0, int iParam1, int iParam2) {
	switch (iParam0) {
	case 2:
		if (iParam2) {
			return joaat("mpply_available_races_v");
		}
		else {
			return joaat("mpply_available_races");
		}
		break;

	case 1:
		if (iParam2) {
			return joaat("mpply_available_dms_v");
		}
		else {
			return joaat("mpply_available_dms");
		}
		break;

	case 8:
		if (iParam2) {
			return joaat("mpply_available_paras_v");
		}
		else {
			return joaat("mpply_available_paras");
		}
		break;

	case 3:
		if (iParam2) {
			return joaat("mpply_available_survival_v");
		}
		else {
			return joaat("mpply_available_survival");
		}
		break;

	case 0:
		switch (iParam1) {
		case 6:
			if (iParam2) {
				return joaat("mpply_available_ctf_v");
			}
			else {
				return joaat("mpply_available_ctf");
			}
			break;

		case 5:
			if (iParam2) {
				return joaat("mpply_available_lts_v");
			}
			else {
				return joaat("mpply_available_lts");
			}
			break;

		case 4:
			if (iParam2) {
				return joaat("mpply_available_versus_v");
			}
			else {
				return joaat("mpply_available_versus");
			}
			break;

		case 1:
			if (iParam2) {
				return -708118870;
			}
			else {
				return 978181703;
			}
			break;

		case 7:
			if (iParam2) {
				return 348170426;
			}
			else {
				return 937781072;
			}
			break;
		}
		if (iParam2) {
			return joaat("mpply_available_missions_v");
		}
		else {
			return joaat("mpply_available_missions");
		}
		break;
	}
	return -1;
}

// Position - 0xEEB0
int func_256(int iParam0, int iParam1, int iParam2) {
	switch (iParam0) {
	case 2:
		if (iParam2) {
			return joaat("mpply_unique_races_v");
		}
		else {
			return joaat("mpply_unique_races");
		}
		break;

	case 1:
		if (iParam2) {
			return joaat("mpply_unique_dms_v");
		}
		else {
			return joaat("mpply_unique_dms");
		}
		break;

	case 8:
		if (iParam2) {
			return joaat("mpply_unique_paras_v");
		}
		else {
			return joaat("mpply_unique_paras");
		}
		break;

	case 3:
		if (iParam2) {
			return joaat("mpply_unique_survival_v");
		}
		else {
			return joaat("mpply_unique_survival");
		}
		break;

	case 0:
		switch (iParam1) {
		case 6:
			if (iParam2) {
				return joaat("mpply_unique_ctf_v");
			}
			else {
				return joaat("mpply_unique_ctf");
			}
			break;

		case 5:
			if (iParam2) {
				return joaat("mpply_unique_lts_v");
			}
			else {
				return joaat("mpply_unique_lts");
			}
			break;

		case 4:
			if (iParam2) {
				return joaat("mpply_unique_versus_v");
			}
			else {
				return joaat("mpply_unique_versus");
			}
			break;

		case 1:
			if (iParam2) {
				return -548839670;
			}
			else {
				return -1776238337;
			}
			break;

		case 7:
			if (iParam2) {
				return -1054420012;
			}
			else {
				return 280555198;
			}
			break;
		}
		if (iParam2) {
			return joaat("mpply_unique_missions_v");
		}
		else {
			return joaat("mpply_unique_missions");
		}
		break;
	}
	return -1;
}

// Position - 0xF011
void func_257(int iParam0, int *iParam1, int *iParam2) {
	*iParam1 = -1;
	*iParam2 = -1;
	switch (iParam0) {
	case 0:
		*iParam1 = 2;
		*iParam2 = 0;
		break;

	case 1:
		*iParam1 = 1;
		*iParam2 = 0;
		break;

	case 7:
		*iParam1 = 8;
		*iParam2 = 0;
		break;

	case 6:
		*iParam1 = 3;
		*iParam2 = 0;
		break;

	case 2:
		*iParam1 = 0;
		*iParam2 = 0;
		break;

	case 3:
		*iParam1 = 0;
		*iParam2 = 6;
		break;

	case 4:
		*iParam1 = 0;
		*iParam2 = 5;
		break;

	case 5:
		*iParam1 = 0;
		*iParam2 = 4;
		break;

	case 8:
		*iParam1 = 0;
		*iParam2 = 1;
		break;
	}
}

// Position - 0xF0C2
int func_258(var *uParam0, var *uParam1) {
	if (gameplay::is_bit_set(Global_2443905.f_3255.f_1, 4)) {
		func_259(uParam0, &uParam1);
		gameplay::clear_bit(&Global_2443905.f_3255.f_1, 3);
		gameplay::clear_bit(&Global_2443905.f_3255.f_1, 4);
		return 1;
	}
	return 0;
}

// Position - 0xF104
void func_259(var *uParam0, var *uParam1) {
	float fVar0;
	float fVar1;
	int iVar2;
	int iVar3;
	struct<2> Var4;
	int iVar8;
	char *sVar9;
	int iVar10;
	int iVar11;

	if (*uParam1 >= 0) {
		iVar2 = func_271(Global_794643.f_4[*uParam1 /*88*/].f_65, Global_794643.f_4[*uParam1 /*88*/].f_68, 0, 0, 0);
		iVar3 = func_270(Global_794643.f_98389[*uParam1 /*13*/].f_1);
		func_267(iVar2, iVar3, joaat("XP_MULTIPLIER"), &fVar0, 1);
		func_267(iVar2, iVar3, joaat("CASH_MULTIPLIER"), &fVar1, 1);
		if (fVar0 < 1f) {
			fVar0 = 0f;
		}
		if (fVar1 < 1f) {
			fVar1 = 0f;
		}
		if (graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "SET_BIGFEED_BODY_TEXT")) {
			func_264(func_265(Global_794643.f_4[*uParam1 /*88*/].f_54, 500));
			graphics::_pop_scaleform_movie_function_void();
		}
		if (graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "SET_TITLE")) {
			func_235("");
			func_264(&Global_794643.f_4[*uParam1 /*88*/].f_22);
			graphics::_push_scaleform_movie_function_parameter_int(2);
			graphics::_push_scaleform_movie_function_parameter_string(network::texture_download_get_name(*uParam0));
			graphics::_push_scaleform_movie_function_parameter_string(network::texture_download_get_name(*uParam0));
			graphics::_push_scaleform_movie_function_parameter_int(1);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			if (!Global_262145.f_6982) {
				if (fVar0 <= 0f) {
					graphics::_push_scaleform_movie_function_parameter_bool(0);
				}
				else {
					graphics::begin_text_command_scaleform_string("PM_MULTI");
					ui::add_text_component_float(fVar0, 0);
					graphics::end_text_command_scaleform_string();
				}
				if (fVar1 <= 0f) {
					graphics::_push_scaleform_movie_function_parameter_bool(0);
				}
				else {
					graphics::begin_text_command_scaleform_string("PM_MULTI");
					ui::add_text_component_float(fVar1, 0);
					graphics::end_text_command_scaleform_string();
				}
			}
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar8 = 1;
		StringCopy(&Var4, "", 16);
		iVar8 = 9;
		sVar9 = func_263();
		if (Global_794643.f_4[*uParam1 /*88*/].f_73 == -1) {
			func_261(5, 0, 0, "FM_ISC_RAT0", "FMMC_NOTRATE", -1, -1, -1082130432, 0);
		}
		else {
			func_261(1, 0, 0, "FM_ISC_RAT0", "FM_ISC_RAT1", -1, -1,
					 func_260(system::to_float(Global_794643.f_4[*uParam1 /*88*/].f_73) > 0f,
							  system::to_float(Global_794643.f_4[*uParam1 /*88*/].f_73), 0f),
					 0);
		}
		iVar10 = 1;
		func_261(0, iVar10, 0, "FM_ISC_CB", sVar9, -1, -1, -1f, &Var4);
		iVar10++;
		func_261(3, iVar10, 0, "PM_RANK", "NUMBER", Global_794643.f_4[*uParam1 /*88*/].f_70, -1, -1082130432, 0);
		iVar10++;
		if (Global_794643.f_4[*uParam1 /*88*/].f_69 == Global_794643.f_4[*uParam1 /*88*/].f_71) {
			func_261(3, iVar10, 0, "FM_ISC_NO0", "NUMBER", Global_794643.f_4[*uParam1 /*88*/].f_69, -1, -1082130432, 0);
		}
		else {
			func_261(2, iVar10, 0, "FM_ISC_NO0", "FM_ISC_NO1", Global_794643.f_4[*uParam1 /*88*/].f_69,
					 Global_794643.f_4[*uParam1 /*88*/].f_71, -1082130432, 0);
		}
		iVar10++;
		if (Global_794643.f_4[*uParam1 /*88*/].f_65 == 2) {
			func_254(Global_794643.f_4[*uParam1 /*88*/].f_65, Global_794643.f_4[*uParam1 /*88*/].f_68, &iVar11);
		}
		else {
			func_254(Global_794643.f_4[*uParam1 /*88*/].f_65, Global_794643.f_4[*uParam1 /*88*/].f_68, &iVar11);
		}
		func_261(6, iVar10, 0, "PM_TYPE",
				 func_253(Global_794643.f_4[*uParam1 /*88*/].f_65, Global_794643.f_4[*uParam1 /*88*/].f_68,
						  Global_794643.f_4[*uParam1 /*88*/].f_76, Global_794643.f_4[*uParam1 /*88*/].f_77, 0, 0),
				 iVar11, iVar8, -1082130432, 0);
		iVar10++;
		if (Global_794643.f_4[*uParam1 /*88*/].f_65 == 0) {
			if (Global_1633501.f_30 > 1) {
				func_261(3, iVar10, 0, "FM_TEAMS", "NUMBER", Global_794643.f_4[*uParam1 /*88*/].f_72, -1, -1082130432,
						 0);
				iVar10++;
			}
		}
		if (graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "DISPLAY_VIEW")) {
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_pop_scaleform_movie_function_void();
		}
	}
}

// Position - 0xF49D
float func_260(bool bParam0, var uParam1, float fParam2) {
	if (bParam0) {
		return uParam1;
	}
	return fParam2;
}

// Position - 0xF4B4
void func_261(int iParam0, int iParam1, int iParam2, char *sParam3, char *sParam4, int iParam5, int iParam6,
			  float fParam7, char *sParam8) {
	if (graphics::_push_scaleform_movie_function(Global_2443905.f_2842.f_85, "SET_DATA_SLOT")) {
		func_262(iParam0, iParam1, iParam2, sParam3, sParam4, iParam5, iParam6, fParam7, sParam8, 0, 0);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xF4EC
void func_262(int iParam0, int iParam1, int iParam2, char *sParam3, char *sParam4, int iParam5, int iParam6,
			  float fParam7, char *sParam8, int iParam9, int iParam10) {
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_push_scaleform_movie_function_parameter_int(0);
	if (iParam0 == 0) {
		graphics::_push_scaleform_movie_function_parameter_int(3);
	}
	else if (iParam0 == 4) {
		graphics::_push_scaleform_movie_function_parameter_int(4);
	}
	else if (iParam0 == 6) {
		graphics::_push_scaleform_movie_function_parameter_int(2);
	}
	else {
		graphics::_push_scaleform_movie_function_parameter_int(0);
	}
	graphics::_push_scaleform_movie_function_parameter_int(0);
	graphics::_push_scaleform_movie_function_parameter_int(1);
	switch (iParam0) {
	case 5:
		func_235(sParam3);
		func_235(sParam4);
		break;

	case 6:
		func_235(sParam3);
		func_235(sParam4);
		graphics::_push_scaleform_movie_function_parameter_int(iParam5);
		graphics::_push_scaleform_movie_function_parameter_int(iParam6);
		graphics::_push_scaleform_movie_function_parameter_bool(iParam9);
		break;

	case 0:
		if (!gameplay::is_string_null_or_empty(sParam3)) {
			func_235(sParam3);
			func_264(sParam4);
		}
		else {
			func_264(sParam4);
			func_264(" ");
		}
		if (!gameplay::is_string_null(sParam8)) {
			func_264(sParam8);
		}
		else {
			func_235("");
		}
		graphics::_push_scaleform_movie_function_parameter_bool(iParam10);
		break;

	case 3:
		func_235(sParam3);
		graphics::begin_text_command_scaleform_string(sParam4);
		ui::add_text_component_integer(iParam5);
		graphics::end_text_command_scaleform_string();
		break;

	case 1:
		func_235(sParam3);
		graphics::begin_text_command_scaleform_string(sParam4);
		ui::add_text_component_float(fParam7, 2);
		graphics::end_text_command_scaleform_string();
		break;

	case 2:
		func_235(sParam3);
		graphics::begin_text_command_scaleform_string(sParam4);
		ui::add_text_component_integer(iParam5);
		ui::add_text_component_integer(iParam6);
		graphics::end_text_command_scaleform_string();
		break;

	case 4:
		func_264(sParam4);
		func_264(" ");
		break;
	}
}

// Position - 0xF64C
var func_263() { return ui::_get_label_text("CREATOR_RSC"); }

// Position - 0xF65C
void func_264(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0xF66A
char *func_265(int iParam0, int iParam1) {
	if (iParam0 == -1) {
		return func_266();
	}
	return network::_0x40F7E66472DF3E5C(iParam0, iParam1);
}

// Position - 0xF68A
var func_266() { return ui::_get_label_text("CREATOR_NO_T"); }

// Position - 0xF69A
void func_267(int iParam0, int iParam1, int iParam2, var *uParam3, int iParam4) {
	func_268(0, iParam2, uParam3, iParam4);
	if (iParam0 == 0) {
		return;
	}
	switch (iParam0) {
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 26:
	case 20:
	case 21:
	case 22:
	case 23:
	case 24:
	case 25:
		func_268(1, iParam2, uParam3, iParam4);
		if (iParam0 == 1) {
			return;
		}
		switch (iParam0) {
		case 2:
		case 3:
		case 4:
		case 5:
			func_268(2, iParam2, uParam3, iParam4);
			if (iParam0 == 2) {
				return;
			}
			switch (iParam0) {
			case 3:
			case 4:
			case 5: func_268(iParam0, iParam2, uParam3, iParam4); return;

			case 1:
			case 2:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
			case 26:
			case 20:
			case 21:
			case 22:
			case 23:
			case 24:
			case 25: return;

			default:
			}
			return;
			return;

		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 26:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
			func_268(6, iParam2, uParam3, iParam4);
			if (iParam0 == 6) {
				return;
			}
			switch (iParam0) {
			case 7:
			case 16:
			case 17:
			case 18:
			case 19:
			case 26:
			case 24:
				func_268(iParam0, iParam2, uParam3, iParam4);
				if (iParam1 != 27) {
					func_268(iParam1, iParam2, uParam3, iParam4);
				}
				return;

			case 15:
			case 20:
			case 21:
			case 22:
			case 23:
			case 25:
				func_268(15, iParam2, uParam3, iParam4);
				if (iParam0 == 15) {
					if (iParam1 != 27) {
						func_268(iParam1, iParam2, uParam3, iParam4);
					}
					return;
				}
				switch (iParam0) {
				case 20:
				case 21:
				case 22:
				case 23:
				case 25:
					func_268(iParam0, iParam2, uParam3, iParam4);
					if (iParam1 != 27) {
						func_268(iParam1, iParam2, uParam3, iParam4);
					}
					return;

				default:
				}
				return;
				return;

			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
				func_268(8, iParam2, uParam3, iParam4);
				if (iParam0 == 8) {
					if (iParam1 != 27) {
						func_268(iParam1, iParam2, uParam3, iParam4);
					}
					return;
				}
				switch (iParam0) {
				case 9:
				case 10:
				case 11:
				case 12:
				case 13:
				case 14:
					func_268(iParam0, iParam2, uParam3, iParam4);
					if (iParam1 != 27) {
						func_268(iParam1, iParam2, uParam3, iParam4);
					}
					return;

				default:
				}
				return;
				return;

			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
			case 6: return;

			default:
			}
			return;
			return;

		case 1: return;

		default:
		}
		break;
	}
}

// Position - 0xFAB9
void func_268(int iParam0, var uParam1, var *uParam2, bool bParam3) {
	int iVar0;
	var uVar1;

	iVar0 = func_269(iParam0);
	uVar1 = *uParam2;
	if (!network::_network_access_tunable_float_hash(iVar0, uParam1, uParam2)) {
		if (bParam3) {
		}
		return;
		*uParam2 = uVar1;
	}
	else {
		unk_0x1950DAE9848A4739(iVar0, uParam1, uParam2);
	}
	if (bParam3) {
	}
}

// Position - 0xFAFC
int func_269(int iParam0) {
	char cVar0[64];

	if (iParam0 >= 28) {
		StringCopy(&cVar0, "CONTENT_MODIFIER_", 64);
		StringIntConCat(&cVar0, iParam0 - 28, 64);
		return gameplay::get_hash_key(&cVar0);
	}
	switch (iParam0) {
	case 0: return 190769267;

	case 1: return 953070135;

	case 2: return 1398379561;

	case 3: return -295628664;

	case 4: return -1157311665;

	case 5: return 988790432;

	case 6: return 1140746429;

	case 7: return 1882254284;

	case 8: return -1021097824;

	case 9: return 1031194139;

	case 10: return -946481156;

	case 11: return -364624190;

	case 12: return -199795525;

	case 13: return -866645446;

	case 14: return 1144300534;

	case 15: return 539878179;

	case 16: return 571975921;

	case 17: return 818280646;

	case 18: return -183978087;

	case 19: return -52527117;

	case 26: return -395434754;

	case 20: return -1110334219;

	case 21: return -1382306730;

	case 22: return 1453550531;

	case 23: break;

	case 24: return 1744317449;

	case 25: return -1679896800;

	case 27: return 2;

	case 29: StringCopy(&cVar0, "ILLEGAL TUNABLE CONTEXT", 64); break;
	}
	return 0;
}

// Position - 0xFD0E
int func_270(int iParam0) {
	int iVar0;

	iVar0 = network::_get_tunables_content_modifier_id(iParam0);
	if (iVar0 >= 0) {
		return iVar0 + 28;
	}
	return 27;
}

// Position - 0xFD2D
int func_271(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	switch (iParam0) {
	case 0:
		if (func_272(iParam3, iParam4)) {
			return 25;
		}
		else if (iParam1 == 0) {
			return 15;
		}
		else if (iParam1 == 5) {
			return 19;
		}
		else if (iParam1 == 6) {
			return 18;
		}
		else if (iParam1 == 4) {
			return 22;
		}
		else if (iParam1 == 9) {
			return 23;
		}
		else if (iParam1 == 3) {
			return 21;
		}
		else if (iParam1 == 2) {
			return 20;
		}
		break;

	case 129: return 25;

	case 165: return 23;

	case 7: return 19;

	case 4: return 18;

	case 10: return 22;

	case 9: return 20;

	case 1: return 7;

	case 8: return 17;

	case 2:
		switch (iParam1) {
		case 4:
		case 5: return 12;

		case 2:
		case 3: return 13;

		case 8:
		case 9: return 17;

		case 6:
		case 7: return 14;

		case 12:
		case 13:
			if (iParam2) {
				return 11;
			}
			else {
				return 10;
			}
			break;
		}
		return 9;

	case 3: return 16;

	case 6: return 24;
	}
	return 0;
}

// Position - 0xFEAF
bool func_272(int iParam0, int iParam1) {
	if (iParam1 > 0) {
		return true;
	}
	if (func_291(iParam0) || func_290(iParam0) || func_289(iParam0) || func_288(iParam0) || func_287(iParam0) ||
		func_286(iParam0) || func_285(iParam0) || func_284(iParam0) || func_283(iParam0) || func_282(iParam0) ||
		func_281(iParam0) || func_280(iParam0) || func_279(iParam0) || func_278(iParam0) || func_277(iParam0) ||
		func_276(iParam0) || func_275(iParam0) || func_274(iParam0) || func_273(iParam0)) {
		return true;
	}
	return false;
}

// Position - 0xFFA7
int func_273(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8047[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xFFE1
int func_274(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8080[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1001D
int func_275(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8069[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10057
int func_276(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8058[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10091
int func_277(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 11) {
		if (iParam0 == Global_262145.f_8034[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x100CB
int func_278(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8023[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10105
int func_279(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8012[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1013F
int func_280(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_8001[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10179
int func_281(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7904[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x101B3
int func_282(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7926[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x101ED
int func_283(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7915[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10227
int func_284(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7893[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10261
int func_285(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7882[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1029B
int func_286(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 9) {
		if (iParam0 == Global_262145.f_7871[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x102D5
int func_287(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 6) {
		if (iParam0 == Global_262145.f_7837[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1030E
int func_288(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	iVar0 = 0;
	while (iVar0 <= 6) {
		if (iParam0 == Global_262145.f_7845[iVar0]) {
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10347
int func_289(int iParam0) {
	if (iParam0 == Global_262145.f_7832 || iParam0 == Global_262145.f_7833 || iParam0 == Global_262145.f_7834 ||
		iParam0 == Global_262145.f_7835 || iParam0 == Global_262145.f_7836) {
		return 1;
	}
	return 0;
}

// Position - 0x103A1
int func_290(int iParam0) {
	if (iParam0 == Global_262145.f_7827 || iParam0 == Global_262145.f_7828 || iParam0 == Global_262145.f_7829 ||
		iParam0 == Global_262145.f_7830 || iParam0 == Global_262145.f_7831) {
		return 1;
	}
	return 0;
}

// Position - 0x103FB
int func_291(int iParam0) {
	if (iParam0 == Global_262145.f_7820 || iParam0 == Global_262145.f_7821 || iParam0 == Global_262145.f_7822 ||
		iParam0 == Global_262145.f_7823 || iParam0 == Global_262145.f_7824 || iParam0 == Global_262145.f_7825 ||
		iParam0 == Global_262145.f_7826) {
		return 1;
	}
	return 0;
}

// Position - 0x10475
bool func_292() { return Global_2450895.f_6; }

// Position - 0x10483
int func_293(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x104A1
bool func_294() {
	if (func_295() && func_711(0)) {
		return true;
	}
	return false;
}

// Position - 0x104BF
int func_295() { return func_711(func_664() + 1); }

// Position - 0x104D1
bool func_296(int iParam0) {
	if (iParam0 != 3) {
		return true;
	}
	if (func_292()) {
		return true;
	}
	return false;
}

// Position - 0x104EF
void func_297(var *uParam0, var *uParam1, int *iParam2) {
	if (gameplay::is_bit_set(Global_2443905.f_3255.f_1, 3)) {
		func_298(uParam0, uParam1, iParam2);
	}
}

// Position - 0x10513
var func_298(var *uParam0, var *uParam1, int *iParam2) {
	int *iVar0;

	if (!gameplay::is_bit_set(Global_2443905.f_3255.f_1, 4)) {
		if (!gameplay::is_bit_set(Global_2443905.f_3255.f_1, 0)) {
			if (Global_2443905.f_3255.f_16 == -1) {
				Global_2443905.f_3255.f_16 = func_327();
			}
			else if (func_302(Global_2443905.f_3255.f_16, iParam2, &iVar0, -1, 0, 0, 1000, 1, 0, 0)) {
				gameplay::set_bit(&Global_2443905.f_3255.f_1, 0);
			}
		}
		else if (!gameplay::is_bit_set(Global_2443905.f_3255.f_1, 1)) {
			if (!uParam1->f_2) {
				func_301(Global_794643.f_4[*iParam2 /*88*/].f_54, uParam1);
			}
			else {
				gameplay::set_bit(&Global_2443905.f_3255.f_1, 1);
			}
		}
		else if (!gameplay::is_bit_set(Global_2443905.f_3255.f_1, 2)) {
			if (func_299(uParam0, &Global_794643.f_4[*iParam2 /*88*/], Global_794643.f_4[*iParam2 /*88*/].f_66, 200, 1,
						 0)) {
				gameplay::set_bit(&Global_2443905.f_3255.f_1, 2);
			}
		}
		else {
			gameplay::set_bit(&Global_2443905.f_3255.f_1, 4);
		}
	}
	return gameplay::is_bit_set(Global_2443905.f_3255.f_1, 4);
}

// Position - 0x10630
bool func_299(var *uParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	switch (uParam0->f_1) {
	case 0:
		if (iParam4 == -1) {
			return false;
		}
		if (func_300()) {
			return true;
		}
		else {
			if (*uParam0 != 0) {
				network::texture_download_release(*uParam0);
			}
			*uParam0 = 0;
			uParam0->f_1 = 1;
		}
		break;

	case 1:
		if (iParam5 && gameplay::is_string_null_or_empty(sParam1)) {
			return false;
		}
		if (iParam2 == -1) {
			iParam2 = 0;
		}
		*uParam0 = network::_0x308F96458B7087CC(sParam1, iParam4, iParam2, 0, sParam1, 0);
		uParam0->f_1 = 2;
		break;

	case 2:
		switch (network::_0x8BD6C6DEA20E82C6(*uParam0)) {
		case 1: return false;

		case 0: uParam0->f_4 = 1; return true;

		case 2:
			uParam0->f_2++;
			if (uParam0->f_2 > iParam3) {
				if (*uParam0 != 0) {
					network::texture_download_release(*uParam0);
					*uParam0 = 0;
				}
				uParam0->f_4 = 0;
				return true;
			}
			break;
		}
		break;
	}
	return false;
}

// Position - 0x1071B
bool func_300() { return Global_1573272.f_4; }

// Position - 0x10729
int func_301(int iParam0, var *uParam1) {
	if (*uParam1 != iParam0) {
		if (*uParam1 != 0) {
			network::_0x5A34CD9C3C5BEC44(*uParam1);
		}
		uParam1->f_2 = 0;
		*uParam1 = iParam0;
		uParam1->f_1 = 0;
	}
	if (iParam0 == 0) {
		return 1;
	}
	if (uParam1->f_2) {
		return 1;
	}
	else {
		if (iParam0 == -1) {
			uParam1->f_2 = 1;
			return 1;
		}
		if (!network::_0x2D5DC831176D0114(iParam0) && uParam1->f_1 == 0) {
			uParam1->f_1 = network::_0x5E0165278F6339EE(iParam0);
		}
		else if (network::_0xEBFA8D50ADDC54C4(iParam0)) {
			if (network::_0x162C23CA83ED0A62(iParam0)) {
				uParam1->f_2 = 1;
				return 1;
			}
			else {
				uParam1->f_2 = 0;
				return 1;
			}
		}
	}
	return 0;
}

// Position - 0x107C8
bool func_302(int iParam0, int *iParam1, int *iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9) {
	int iVar0;
	int iVar1;
	bool bVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	if (iParam6 < 3) {
		iParam6 = 3;
	}
	if (!iParam7) {
		iParam6 = func_326(iParam6);
	}
	if (iParam0 == 202 || iParam0 == 203 || iParam0 == 204) {
		iVar12 = iParam0;
		iParam0 = 0;
	}
	else if (iParam0 == 7) {
		iVar4 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 4) {
		iVar5 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 10) {
		if (iParam6 < 12) {
			iParam6 = 12;
		}
		iVar6 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 9) {
		iVar8 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 165) {
		iVar11 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 156) {
		iVar10 = 1;
		iParam0 = 0;
	}
	else if (iParam0 == 129) {
		iVar7 = 1;
		if (iParam6 < 12) {
			iParam6 = 12;
		}
		iParam0 = 0;
	}
	else if (iParam0 == 0) {
		iVar9 = 0;
		iVar8 = 1;
	}
	else if (iParam0 == 184) {
		iParam8 = 1;
		iParam9 = 1;
		iParam0 = 2;
	}
	if (iParam8 && iParam9 && iParam0 == 2 && !Global_262145.f_8252) {
		iVar13 = func_325();
		iVar14 = func_323(func_324(iVar13));
		if (iVar14 != -1) {
			if (!gameplay::is_string_null_or_empty(&Global_2443134.f_19) &&
				gameplay::are_strings_equal(&Global_794643.f_4[iVar14 /*88*/], &Global_2443134.f_19)) {
				iVar14++;
				if (iVar14 > func_322()) {
					iVar14 = 0;
				}
			}
			*iParam2 = 1;
			*iParam1 = iVar14;
			return true;
		}
		else {
			iParam9 = 0;
		}
	}
	iVar15 = func_321(iParam0, iParam4, 1, iParam5, iParam6, iVar4, iVar5, iVar6, iVar8, iVar7, iParam8, iVar10, iVar11,
					  iParam9, iVar12);
	iVar16 = func_321(iParam0, iParam4, 0, iParam5, iParam6, iVar4, iVar5, iVar6, iVar8, iVar7, iParam8, iVar10, iVar11,
					  iParam9, iVar12);
	network::_0xF1B84178F8674195(network::_get_posix_time() / Global_262145.f_4835);
	if (iVar15 == 0) {
		if (iVar4 == 1) {
			iVar4 = 0;
		}
		if (iVar5 == 1) {
			iVar5 = 0;
			iVar9 = 1;
		}
		if (iVar12 != 0) {
			iVar12 = 0;
			iVar9 = 1;
		}
		if (iVar6 == 1) {
			iVar6 = 0;
			iVar9 = 1;
		}
		if (iVar7 == 1) {
			iVar6 = 0;
			iVar9 = 1;
		}
		if (iVar10 == 1) {
			iVar10 = 0;
			iVar9 = 1;
		}
		if (iVar11 == 1) {
			iVar11 = 0;
			iVar9 = 1;
		}
		if (iVar8 == 1) {
			iVar8 = 0;
			iVar9 = 1;
		}
		if (iVar9 == 1) {
			iVar9 = 0;
			iVar3 = network::_network_get_random_int_in_range(0, 4);
			if (iVar3 == 0) {
				iVar6 = 1;
			}
			else if (iVar3 == 1) {
				iVar5 = 1;
			}
			else if (iVar3 == 2) {
				iVar4 = 1;
			}
			else {
				iVar8 = 1;
			}
		}
		iVar15 = func_321(iParam0, iParam4, 1, iParam5, iParam6, iVar4, iVar5, iVar6, iVar8, iVar7, iParam8, iVar10,
						  iVar11, iParam9, iVar12);
	}
	*iParam1 = iParam3;
	while (*iParam1 == iParam3 && iVar0 < 10) {
		iVar3 = network::_network_get_random_int_in_range(0, 100);
		if (iParam7) {
			bVar2 = true;
		}
		else if (iVar3 < 66) {
			bVar2 = true;
		}
		else {
			bVar2 = false;
		}
		if (iParam8) {
			bVar2 = true;
		}
		if (iParam0 != 2 && iParam0 != 1 || iVar16 == 0) {
			bVar2 = true;
		}
		if (bVar2) {
			iVar1 = network::_network_get_random_int_in_range(0, iVar15);
			*iParam1 = func_303(*iParam1, iParam0, iVar1, iParam4, 1, iParam5, iParam6, iVar4, iVar5, iVar6, iVar8,
								iVar7, iParam8, iVar10, iVar11, 0, iVar12);
			*iParam2 = 1;
		}
		else {
			iVar1 = network::_network_get_random_int_in_range(0, iVar16);
			*iParam1 = func_303(*iParam1, iParam0, iVar1, iParam4, 0, iParam5, iParam6, iVar4, iVar5, iVar6, iVar8,
								iVar7, iParam8, iVar10, iVar11, 0, iVar12);
			*iParam2 = 0;
		}
		iVar0++;
	}
	if (*iParam1 == iParam3) {
		return false;
	}
	return true;
}

// Position - 0x10B35
int func_303(var uParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, int iParam11, bool bParam12, int iParam13, int iParam14,
			 int iParam15, int iParam16) {
	int iVar0;
	int iVar1;

	if (iParam4) {
		iVar0 = 0;
		while (iVar0 <= 1117) {
			if (gameplay::is_bit_set(Global_794643.f_4[iVar0 /*88*/].f_76, 13) &&
				Global_794643.f_4[iVar0 /*88*/].f_65 == iParam1) {
				if (func_304(iParam4, iParam1, iVar0, iParam5, iParam7, iParam8, iParam9, iParam10, iParam3, iParam6,
							 iParam11, bParam12, iParam13, iParam14, iParam15, iParam16)) {
					if (iVar1 == iParam2) {
						return iVar0;
					}
					iVar1++;
				}
			}
			iVar0++;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 <= 199) {
			if (gameplay::is_bit_set(Global_907640.f_1204[iVar0 /*88*/].f_76, 13) &&
				Global_907640.f_1204[iVar0 /*88*/].f_65 == iParam1) {
				if (func_304(iParam4, iParam1, iVar0, iParam5, iParam7, iParam8, iParam9, iParam10, iParam3, iParam6,
							 iParam11, bParam12, iParam13, iParam14, iParam15, iParam16)) {
					if (iVar1 == iParam2) {
						return iVar0;
					}
					iVar1++;
				}
			}
			iVar0++;
		}
	}
	return uParam0;
}

// Position - 0x10C34
bool func_304(bool bParam0, int iParam1, int iParam2, int iParam3, bool bParam4, bool bParam5, bool bParam6,
			  bool bParam7, int iParam8, int iParam9, bool bParam10, bool bParam11, bool bParam12, bool bParam13,
			  bool bParam14, int iParam15) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;

	iVar0 = func_320(bParam0, iParam1, iParam2, bParam7, bParam7);
	iVar1 = func_319(bParam0, iParam1, iParam2, iParam3);
	iVar2 = func_318(iParam1, bParam0, iParam2, bParam4);
	iVar3 = func_317(iParam1, bParam0, iParam2, bParam5);
	iVar4 = func_316(iParam1, bParam0, iParam2, bParam6, bParam10);
	iVar5 = func_314(iParam1, bParam0, iParam2, bParam10);
	iVar6 = func_313(iParam1, bParam0, iParam2, bParam7);
	iVar7 = 1;
	iVar8 = func_311(iParam1, bParam0, iParam2, bParam11, bParam14);
	iVar9 = func_308(iParam1, bParam0, iParam2, iParam15);
	iVar10 = func_307(iParam1, bParam0, iParam2, bParam12);
	iVar11 = func_306(iParam1, bParam0, iParam2, bParam13);
	if (func_305()) {
		if (bParam0) {
			if (gameplay::are_strings_equal(&Global_794643.f_4[iParam2 /*88*/], &Global_2443134.f_19)) {
				iVar7 = 0;
			}
		}
		else if (gameplay::are_strings_equal(&Global_907640.f_1204[iParam2 /*88*/], &Global_2443134.f_19)) {
			iVar7 = 0;
		}
	}
	if (bParam0) {
		iVar12 = Global_794643.f_4[iParam2 /*88*/].f_71;
		iVar13 = Global_794643.f_4[iParam2 /*88*/].f_70;
	}
	else {
		iVar12 = Global_907640.f_1204[iParam2 /*88*/].f_71;
		iVar13 = Global_907640.f_1204[iParam2 /*88*/].f_70;
	}
	if (iVar12 >= iParam8 && iVar13 <= iParam9 && !iVar0 && iVar1 && iVar2 && iVar3 && iVar4 && iVar6 && iVar5 &&
		iVar7 && iVar8 && iVar9 && iVar10 && iVar11) {
		return true;
	}
	return false;
}

// Position - 0x10DD1
bool func_305() { return Global_2443134.f_10; }

// Position - 0x10DDF
int func_306(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (!bParam1) {
		return 1;
	}
	else if (bParam3) {
		if (Global_794643.f_4[iParam2 /*88*/].f_68 == 9) {
			return 1;
		}
		return 0;
	}
	return 1;
}

// Position - 0x10E1D
int func_307(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (!bParam1) {
		return 1;
	}
	else if (bParam3) {
		if (Global_794643.f_4[iParam2 /*88*/].f_68 == 8) {
			return 1;
		}
		return 0;
	}
	return 1;
}

// Position - 0x10E5B
int func_308(int iParam0, bool bParam1, int iParam2, int iParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (!bParam1) {
		return 1;
	}
	else if (iParam3 != 0) {
		if (func_310(Global_794643.f_98389[iParam2 /*13*/].f_1, 0)) {
			if (iParam3 == func_309(Global_794643.f_98389[iParam2 /*13*/].f_1)) {
				return 1;
			}
		}
		return 0;
	}
	return 1;
}

// Position - 0x10EB8
int func_309(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 7) {
		iVar1 = 0;
		while (iVar1 < 20) {
			if (Global_262145.f_5068[iVar0 /*21*/][iVar1] == iParam0) {
				return Global_262145.f_5375[iVar0];
			}
			iVar1++;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x10F08
bool func_310(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam0 != 0) {
		iVar1 = 0;
		while (iVar1 < 7) {
			if (Global_262145.f_5375[iVar1] == 202 || Global_262145.f_5375[iVar1] == 203 ||
				Global_262145.f_5375[iVar1] == 204 ||
				iParam1 && (Global_262145.f_5375[iVar1] == 224 || Global_262145.f_5375[iVar1] == 223)) {
				iVar0 = 0;
				while (iVar0 < 20) {
					if (iParam0 == Global_262145.f_5068[iVar1 /*21*/][iVar0]) {
						return true;
					}
					iVar0++;
				}
			}
			iVar1++;
		}
	}
	return false;
}

// Position - 0x10FBC
int func_311(int iParam0, bool bParam1, int iParam2, bool bParam3, bool bParam4) {
	if (iParam0 != 2) {
		return 1;
	}
	if (!bParam1) {
		return 1;
	}
	else if (bParam3) {
		if (bParam4) {
			if (func_312(Global_794643.f_98389[iParam2 /*13*/].f_1)) {
				return 1;
			}
			return 0;
		}
		else if (Global_794643.f_4[iParam2 /*88*/].f_68 == 6 || Global_794643.f_4[iParam2 /*88*/].f_68 == 7) {
			return 1;
		}
		return 0;
	}
	return 1;
}

// Position - 0x11034
bool func_312(int iParam0) {
	int iVar0;

	if (iParam0 != 0) {
		iVar0 = 0;
		while (iVar0 < 30) {
			if (iParam0 == Global_262145.f_4926[iVar0]) {
				return true;
			}
			iVar0++;
		}
	}
	return false;
}

// Position - 0x1106A
int func_313(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (bParam1) {
		if (bParam3) {
			if ((gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 1) ||
				 gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 2) ||
				 Global_794643.f_4[iParam2 /*88*/].f_68 == 2 || Global_794643.f_4[iParam2 /*88*/].f_68 == 3) &&
				gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 14) &&
				Global_794643.f_4[iParam2 /*88*/].f_68 != 8) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else {
			return 1;
		}
	}
	else if (bParam3) {
		if ((gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 1) ||
			 gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 2) ||
			 Global_907640.f_1204[iParam2 /*88*/].f_68 == 2 || Global_907640.f_1204[iParam2 /*88*/].f_68 == 3) &&
			gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 14) &&
			Global_794643.f_4[iParam2 /*88*/].f_68 != 8) {
			return 1;
		}
		else {
			return 0;
		}
	}
	else {
		return 1;
	}
	return 1;
}

// Position - 0x111B4
int func_314(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (bParam1) {
		if (bParam3) {
			if (func_315(iParam2)) {
				return 1;
			}
			return 0;
		}
		else {
			return 1;
		}
	}
	return 1;
}

// Position - 0x111EC
bool func_315(int iParam0) {
	if (func_272(Global_794643.f_98389[iParam0 /*13*/].f_1, Global_794643.f_4[iParam0 /*88*/].f_80)) {
		return true;
	}
	return false;
}

// Position - 0x1121B
int func_316(int iParam0, bool bParam1, int iParam2, bool bParam3, bool bParam4) {
	if (iParam0 != 0) {
		return 1;
	}
	if (bParam1) {
		if (bParam3) {
			return gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 3);
		}
		else {
			if (bParam4) {
				if (func_315(iParam2)) {
					return 1;
				}
			}
			return !gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 3);
		}
	}
	else {
		return 1;
	}
	return 1;
}

// Position - 0x1127D
int func_317(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (bParam1) {
		if (bParam3) {
			return gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 10);
		}
		else {
			return !gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 10);
		}
	}
	else if (bParam3) {
		return gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 10);
	}
	else {
		return !gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 10);
	}
	return 1;
}

// Position - 0x11300
int func_318(int iParam0, bool bParam1, int iParam2, bool bParam3) {
	if (iParam0 != 0) {
		return 1;
	}
	if (bParam1) {
		if (bParam3) {
			return gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 7);
		}
		else {
			return !gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 7);
		}
	}
	else {
		return 1;
	}
	return 1;
}

// Position - 0x11350
int func_319(bool bParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam1 != 1) {
		return 1;
	}
	if (iParam3 == 0) {
		return 1;
	}
	if (bParam0) {
		if (Global_794643.f_4[iParam2 /*88*/].f_68 == 1) {
			return 1;
		}
		return 0;
	}
	if (Global_907640.f_1204[iParam2 /*88*/].f_68 == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x1139F
int func_320(bool bParam0, int iParam1, int iParam2, var uParam3, bool bParam4) {
	if (iParam1 != 0) {
		return 0;
	}
	if (bParam0) {
		if (func_129(Global_794643.f_98389[iParam2 /*13*/].f_1)) {
			return 1;
		}
		if (bParam4) {
			if (gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 1) ||
				gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 2) ||
				Global_794643.f_4[iParam2 /*88*/].f_68 == 2 || Global_794643.f_4[iParam2 /*88*/].f_68 == 3) {
				if (gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 14)) {
					return 0;
				}
			}
		}
		if (Global_794643.f_4[iParam2 /*88*/].f_68 == 1 || Global_794643.f_4[iParam2 /*88*/].f_68 == 7 ||
			Global_794643.f_4[iParam2 /*88*/].f_75 != 0 || Global_794643.f_4[iParam2 /*88*/].f_68 == 2 && uParam3 ||
			Global_794643.f_4[iParam2 /*88*/].f_68 == 3 ||
			gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 4) ||
			gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 12) ||
			gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 1) && uParam3 ||
			gameplay::is_bit_set(Global_794643.f_4[iParam2 /*88*/].f_76, 2)) {
			return 1;
		}
		return 0;
	}
	if (Global_907640.f_1204[iParam2 /*88*/].f_68 == 1 || Global_907640.f_1204[iParam2 /*88*/].f_68 == 7 ||
		Global_907640.f_1204[iParam2 /*88*/].f_75 != 0 || Global_907640.f_1204[iParam2 /*88*/].f_68 == 2 && uParam3 ||
		Global_907640.f_1204[iParam2 /*88*/].f_68 == 3 ||
		gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 4) ||
		gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 12) ||
		gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 1) && uParam3 ||
		gameplay::is_bit_set(Global_907640.f_1204[iParam2 /*88*/].f_76, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0x115F1
int func_321(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13, int iParam14) {
	int iVar0;
	int iVar1;

	if (iParam2) {
		iVar1 = 0;
		while (iVar1 <= 1117) {
			if (gameplay::is_bit_set(Global_794643.f_4[iVar1 /*88*/].f_76, 13)) {
				if (Global_794643.f_4[iVar1 /*88*/].f_65 == iParam0) {
					if (func_304(iParam2, iParam0, iVar1, iParam3, iParam5, iParam6, iParam7, iParam8, iParam1, iParam4,
								 iParam9, iParam10, iParam11, iParam12, iParam13, iParam14)) {
						iVar0++;
					}
				}
			}
			iVar1++;
		}
	}
	else {
		iVar1 = 0;
		while (iVar1 <= 199) {
			if (gameplay::is_bit_set(Global_907640.f_1204[iVar1 /*88*/].f_76, 13) &&
				Global_907640.f_1204[iVar1 /*88*/].f_65 == iParam0) {
				if (func_304(iParam2, iParam0, iVar1, iParam3, iParam5, iParam6, iParam7, iParam8, iParam1, iParam4,
							 iParam9, iParam10, iParam11, iParam12, iParam13, iParam14)) {
					iVar0++;
				}
			}
			iVar1++;
		}
	}
	return iVar0;
}

// Position - 0x116D5
int func_322() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 30) {
		if (Global_262145.f_4926[iVar0] == 0) {
			return iVar0;
		}
		iVar0++;
	}
	return iVar0;
}

// Position - 0x11706
int func_323(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 1118) {
		if (iParam0 == Global_794643.f_98389[iVar0 /*13*/].f_1) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x1173C
int func_324(int iParam0) {
	if (iParam0 > 30) {
		iParam0 = 0;
	}
	return Global_262145.f_4926[iParam0];
}

// Position - 0x11759
int func_325() { return network::_get_posix_time() / Global_262145.f_5050 % func_322(); }

// Position - 0x11772
int func_326(int iParam0) {
	if (iParam0 < 50) {
		return 50;
	}
	return 999;
}

// Position - 0x11789
int func_327() {
	int iVar0;
	int iVar1;

	iVar0 = -1;
	while (!func_329(iVar0, 0, 0) && iVar1 < 1000) {
		iVar0 = gameplay::get_random_int_in_range(0, 1000);
		if (iVar0 < 300) {
			iVar0 = gameplay::get_random_int_in_range(0, 1000);
			if (iVar0 < 250) {
				iVar0 = 0;
			}
			else if (iVar0 < 500) {
				iVar0 = 7;
			}
			else if (iVar0 < 750) {
				iVar0 = 4;
			}
			else {
				iVar0 = 10;
			}
		}
		else if (iVar0 < 500 && !func_328()) {
			iVar0 = 1;
		}
		else if (iVar0 < 750) {
			iVar0 = 2;
		}
		else if (iVar0 < 875) {
			iVar0 = 3;
		}
		else {
			iVar0 = 8;
		}
		if (func_329(iVar0, 0, 0)) {
			return iVar0;
		}
		iVar1++;
	}
	return 2;
}

// Position - 0x1184A
bool func_328() { return Global_1315193 == 10; }

// Position - 0x11859
bool func_329(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	if (Global_262145.f_6591 == 1) {
		if (iParam0 == 67) {
			return true;
		}
		if (iParam0 == 74) {
			return true;
		}
		if (func_331(player::player_id(), 85)) {
			if (iParam0 == 64 || iParam0 == 77 || iParam0 == 61 || iParam0 == 81 || iParam0 == 63 || iParam0 == 62) {
				return true;
			}
		}
		if (iParam0 == 66 || iParam0 == 116 || iParam0 == 103 || iParam0 == 104 || iParam0 == 105 || iParam0 == 119 ||
			iParam0 == 88 || iParam0 == 75 || iParam0 == 95 || iParam0 == 65 || iParam0 == 98) {
			return true;
		}
	}
	if (iParam0 < 0) {
		return false;
	}
	if (iParam0 == 31) {
		if (Global_262145.f_4882 == 1) {
			return true;
		}
	}
	if (func_245() || func_244()) {
		return true;
	}
	iVar0 = iParam0;
	iVar1 = iVar0 / 32;
	iVar0 %= 32;
	if (iParam1) {
		if (iParam0 == 3) {
			if (func_330()) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	if (iParam2) {
		return false;
	}
	return gameplay::is_bit_set(Global_1574358[iVar1], iVar0);
}

// Position - 0x119C7
bool func_330() {
	int iVar0;

	if (Global_1312446) {
		return true;
	}
	if (gameplay::is_bit_set(Global_2494199.f_1639, 23)) {
		return true;
	}
	if (func_245()) {
		return true;
	}
	if (func_244()) {
		return true;
	}
	iVar0 = Global_1363267[func_40(-1)];
	if (gameplay::is_bit_set(iVar0, 7)) {
		gameplay::set_bit(&Global_2494199.f_1639, 23);
		return true;
	}
	return false;
}

// Position - 0x11A2D
bool func_331(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (!func_333()) {
		return false;
	}
	if (func_332()) {
		return false;
	}
	if (iParam1 == 86) {
		return true;
	}
	iVar0 = func_242(iParam1);
	iVar1 = iVar0;
	return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_491, iVar1);
}

// Position - 0x11A75
bool func_332() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_143, 3); }

// Position - 0x11A8F
int func_333() {
	if (Global_1312446) {
		return 1;
	}
	if (func_245()) {
		return 1;
	}
	if (func_244()) {
		return 1;
	}
	return func_334(120, -1);
}

// Position - 0x11ABF
int func_334(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2522581[iParam0 /*3*/][func_40(iParam1)];
	if (stats::stat_get_bool(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x11AEB
void func_335() {
	if (Global_2443905.f_3255.f_2 != -1) {
		func_350(Global_2443905.f_3255.f_2, Global_2443905.f_3255.f_2.f_1, 1, Global_2443905.f_3255.f_2.f_3,
				 Global_2443905.f_3255.f_2.f_2);
		func_336(Global_2443905.f_3255.f_2, Global_2443905.f_3255.f_2.f_1, Global_2443905.f_3255.f_2.f_4,
				 Global_2443905.f_3255.f_2.f_3, 1);
		Global_2443905.f_3255.f_2 = -1;
		Global_2443905.f_3255.f_2.f_1 = -1;
		Global_2443905.f_3255.f_2.f_2 = 0;
		Global_2443905.f_3255.f_2.f_3 = -1;
		Global_2443905.f_3255.f_2.f_4 = -1;
	}
}

// Position - 0x11B98
void func_336(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;
	int iVar1;

	if (!iParam4) {
		return;
	}
	if (!func_341(iParam0, iParam1, iParam2, &iVar0, iParam3)) {
		return;
	}
	iVar1 = func_237(iVar0);
	if (iVar1 == -1) {
		return;
	}
	func_337(iVar1, 1);
}

// Position - 0x11BD6
void func_337(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_707(iParam0);
	iVar0 += iParam1;
	if (!func_340(iParam0)) {
		func_339(iParam0, iVar0);
	}
	else {
		func_338(iParam0, iVar0);
	}
}

// Position - 0x11C0A
void func_338(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, 1);
	}
	switch (iParam0) {
	case joaat("mpply_crew_0_id"): Global_1363153 = iParam1; break;

	case joaat("mpply_crew_1_id"): Global_1363155 = iParam1; break;

	case joaat("mpply_crew_2_id"): Global_1363155 = iParam1; break;

	case joaat("mpply_crew_3_id"): Global_1363156 = iParam1; break;

	case joaat("mpply_crew_4_id"): Global_1363157 = iParam1; break;

	case joaat("mpply_crew_local_xp_0"): Global_1363158 = iParam1; break;

	case joaat("mpply_crew_local_xp_1"): Global_1363159 = iParam1; break;

	case joaat("mpply_crew_local_xp_2"): Global_1363160 = iParam1; break;

	case joaat("mpply_crew_local_xp_3"): Global_1363161 = iParam1; break;

	case joaat("mpply_crew_local_xp_4"): Global_1363162 = iParam1; break;

	case joaat("mpply_became_cheater_num"): Global_1363163 = iParam1; break;

	case joaat("mpply_friendly"): Global_1363164 = iParam1; break;

	case joaat("mpply_offensive_language"): Global_1363165 = iParam1; break;

	case joaat("mpply_griefing"): Global_1363166 = iParam1; break;

	case joaat("mpply_helpful"): Global_1363167 = iParam1; break;

	case joaat("mpply_offensive_tagplate"): Global_1363168 = iParam1; break;

	case joaat("mpply_offensive_ugc"): Global_1363169 = iParam1; break;

	default: break;
	}
}

// Position - 0x11D2F
void func_339(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != 0) {
		stats::stat_set_int(iVar0, iParam1, 1);
	}
}

// Position - 0x11D4B
int func_340(int iParam0) {
	if (Global_1363152) {
		switch (iParam0) {
		case joaat("mpply_crew_0_id"):
		case joaat("mpply_crew_1_id"):
		case joaat("mpply_crew_2_id"):
		case joaat("mpply_crew_3_id"):
		case joaat("mpply_crew_4_id"):
		case joaat("mpply_crew_local_xp_0"):
		case joaat("mpply_crew_local_xp_1"):
		case joaat("mpply_crew_local_xp_2"):
		case joaat("mpply_crew_local_xp_3"):
		case joaat("mpply_crew_local_xp_4"):
		case joaat("mpply_became_cheater_num"):
		case joaat("mpply_friendly"):
		case joaat("mpply_offensive_language"):
		case joaat("mpply_griefing"):
		case joaat("mpply_helpful"):
		case joaat("mpply_offensive_tagplate"):
		case joaat("mpply_offensive_ugc"): return 1;
		}
	}
	return 0;
}

// Position - 0x11DCF
int func_341(int iParam0, int iParam1, int iParam2, int *iParam3, int iParam4) {
	int iVar0;

	if (iParam0 != 0) {
		return 0;
	}
	if (iParam1 != 2) {
		return 0;
	}
	if (func_346(player::player_id()) < iParam4) {
		return 0;
	}
	iVar0 = func_342(iParam2);
	*iParam3 = 145;
	if (iVar0 != 0) {
		*iParam3 = iVar0;
	}
	if (*iParam3 == 145) {
		return 0;
	}
	return 1;
}

// Position - 0x11E21
int func_342(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return 0;
	}
	if (iParam0 > 0 && iParam0 <= 200) {
		if (iParam0 > 90) {
			return 0;
		}
		switch (iParam0) {
		case 10: return 12;

		case 17: return 19;

		case 18: return 20;

		case 28: return 31;

		case 75: return 12;

		default:
		}
		return iParam0;
	}
	iVar0 = func_343(iParam0);
	if (iVar0 == 145) {
		return 0;
	}
	return iVar0;
}

// Position - 0x11EA7
int func_343(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 == 0) {
		return 145;
	}
	iVar0 = 0;
	iVar1 = 145;
	iVar0 = 0;
	while (iVar0 < 9) {
		iVar1 = func_345(iVar0);
		if (iParam0 == func_344(iVar1)) {
			return iVar1;
		}
		iVar0++;
	}
	return 145;
}

// Position - 0x11EEE
int func_344(int iParam0) {
	switch (iParam0) {
	case 86: return 131908481;

	case 19: return -366822323;

	case 12: return -1917614010;

	case 31: return -328739832;

	case 20: return -1984782235;

	case 18: return -2105450473;

	case 2: return 657970604;

	case 76: return 612082356;

	case 22: return 676712040;

	case 145: return 0;

	default:
	}
	return 0;
}

// Position - 0x11F86
int func_345(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = func_250(iVar0);
	return iVar1;
}

// Position - 0x11F9C
int func_346(int iParam0) {
	int iVar0;

	iVar0 = func_348(iParam0);
	if (iVar0 < 0) {
		return 0;
	}
	return func_347(iVar0, 0);
}

// Position - 0x11FBD
int func_347(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	float fVar4;

	if (iParam1 == 0) {
	}
	iVar1 = 8000;
	iVar2 = 0;
	iVar3 = (iVar1 - iVar2) / 2;
	iVar0 = 0;
	while (iVar0 <= 100) {
		if (iVar1 == iVar2) {
			iVar0 = 8000;
			if (iVar3 == 0) {
				iVar3 = 1;
			}
			return iVar3;
		}
		if (Global_280048[iVar3] == iParam0) {
			iVar1 = iVar3;
			iVar2 = iVar3;
		}
		else if (Global_280048[iVar3] < iParam0) {
			if (iVar2 == iVar3) {
				iVar2++;
			}
			else {
				iVar2 = iVar3;
			}
		}
		else if (iVar1 == iVar3) {
			iVar1--;
		}
		else {
			iVar1 = iVar3;
		}
		fVar4 = (system::to_float(iVar1) - system::to_float(iVar2)) / 2f + system::to_float(iVar2);
		iVar3 = system::round(fVar4);
		iVar0++;
	}
	return 8000;
}

// Position - 0x1207C
int func_348(int iParam0) {
	if (Global_1312466.f_9 == 0) {
		if (iParam0 > -1) {
			if (iParam0 == player::player_id()) {
				return Global_1363273[func_40(-1)];
			}
			else if (func_349(iParam0)) {
				return Global_1591201[iParam0 /*602*/].f_203.f_1;
			}
		}
	}
	else {
		return Global_1363273[func_40(-1)];
	}
	return 0;
}

// Position - 0x120D9
bool func_349(int iParam0) {
	if (iParam0 == -1) {
		return false;
	}
	else {
		return gameplay::is_bit_set(Global_2433125.f_1, iParam0);
	}
	return true;
}

// Position - 0x120FE
void func_350(int iParam0, int iParam1, int iParam2, int iParam3, bool bParam4) {
	int iVar0;

	if (!func_294()) {
		return;
	}
	if (!iParam2) {
		return;
	}
	if (iParam0 == 0) {
		if (iParam1 != 6 && iParam1 != 5 && iParam1 != 4 && iParam1 != 9) {
			if (func_346(player::player_id()) < iParam3) {
				return;
			}
		}
	}
	else if (iParam0 == 2) {
		if (iParam3 >= 9999) {
			return;
		}
	}
	iVar0 = func_256(iParam0, iParam1, bParam4);
	if (iVar0 == -1) {
		return;
	}
	func_337(iVar0, 1);
}

// Position - 0x12183
bool func_351() { return Global_2450895.f_3; }

// Position - 0x12191
void func_352() {
	switch (Global_2443905.f_2842.f_84) {
	case 0: break;

	case 1:
		if (!graphics::has_scaleform_movie_loaded(Global_2443905.f_2842.f_85)) {
			Global_2443905.f_2842.f_85 = unk_0x67D02A194A2FC2BD("GTAV_ONLINE");
			func_13(&Global_2443905.f_2842.f_148);
			Global_2443905.f_2842.f_84++;
		}
		break;

	case 2:
		if (!func_231(player::player_id())) {
			if (!Global_1318036) {
				func_362(1);
			}
		}
		if (graphics::has_scaleform_movie_loaded(Global_2443905.f_2842.f_85) && cam::is_screen_faded_in()) {
			if (func_419()) {
				if (func_16() != 999 && func_16() != -1) {
					ui::_0xD4438C0564490E63();
				}
				ui::_log_debug_info(1);
				graphics::_0xC6372ECD45D73BCD(1);
			}
			if (func_16() == 999 || func_16() == -1) {
				func_361(&Global_2443905.f_2842.f_85);
			}
			if (Global_1318036 == 1) {
				graphics::draw_scaleform_movie_fullscreen(Global_2443905.f_2842.f_85, 255, 255, 255, 255, 0);
			}
			if (func_357()) {
				if (Global_1318041 == 0) {
					if (func_356()) {
						func_362(0);
						ui::_0xA8FDB297A8D25FBA();
						Global_2453695 = 0;
						Global_1318036 = 1;
						Global_1318041 = 1;
					}
					else if (!func_419()) {
						func_361(&Global_2443905.f_2842.f_85);
					}
				}
				else if (!func_419()) {
					func_361(&Global_2443905.f_2842.f_85);
				}
				if (Global_1318041) {
					if (!func_367(&Global_2443905.f_2842.f_148)) {
						func_14(&Global_2443905.f_2842.f_148, 0, 0);
					}
					else if (func_355(&Global_2443905.f_2842.f_148, 20000, 0)) {
						func_13(&Global_2443905.f_2842.f_148);
					}
				}
			}
		}
		break;

	case 3: func_353(); break;
	}
}

// Position - 0x12358
void func_353() {
	struct<5> Var0;
	vector3 vVar5;

	Global_1318041 = 0;
	Global_1318036 = 0;
	if (graphics::has_scaleform_movie_loaded(Global_2443905.f_2842.f_85)) {
		socialclub::_0x675721C9F644D161();
		graphics::set_scaleform_movie_as_no_longer_needed(&Global_2443905.f_2842.f_85);
	}
	Global_1318041 = 0;
	func_362(0);
	func_13(&Global_2443905.f_2842.f_148);
	ui::_0xA8FDB297A8D25FBA();
	Global_2453695 = 0;
	ui::_0xB695E2CD0A2DA9EE();
	func_354(&Global_2443905.f_3255.f_7, 1, 1);
	if (Global_2443905.f_3255.f_15 != -1) {
		network::_0x5A34CD9C3C5BEC44(Global_794643.f_4[Global_2443905.f_3255.f_15 /*88*/].f_54);
	}
	Global_2443905.f_3255.f_15 = -1;
	Global_2443905.f_3255.f_16 = -1;
	Global_2443905.f_3255.f_1 = 0;
	Global_2443905.f_3255.f_7 = {Var0};
	Global_2443905.f_3255.f_12 = {vVar5};
	Global_2443905.f_2842.f_84 = 0;
	Global_2443905.f_2842.f_152 = 0;
}

// Position - 0x12433
void func_354(var *uParam0, int iParam1, int iParam2) {
	if (*uParam0 != 0) {
		if (iParam2) {
			network::texture_download_release(*uParam0);
		}
	}
	*uParam0 = 0;
	uParam0->f_1 = 0;
	uParam0->f_2 = 0;
	if (iParam1) {
		uParam0->f_3 = 0;
	}
	uParam0->f_4 = 0;
}

// Position - 0x1246B
bool func_355(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 == -1) {
		return true;
	}
	func_14(uParam0, iParam2, 0);
	if (network::network_is_game_in_progress() && !iParam2) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= iParam1) {
			return true;
		}
	}
	else if (gameplay::absi(network::get_time_difference(gameplay::get_game_timer(), *uParam0)) >= iParam1) {
		return true;
	}
	return false;
}

// Position - 0x124C9
bool func_356() {
	if (Global_2443905.f_2842.f_152) {
		if (socialclub::_0xFE4C1D0D3B9CC17E(Global_2443905.f_2842.f_85, 0)) {
			return true;
		}
	}
	else if (socialclub::_0x6BFB12CE158E3DD4(Global_2443905.f_2842.f_85)) {
		return true;
	}
	return false;
}

// Position - 0x1250A
bool func_357() {
	int iVar0;

	if (func_360() == 0) {
		return false;
	}
	if (func_294() && func_358() == 0) {
		return false;
	}
	if (dlc2::get_is_loading_screen_active()) {
		return false;
	}
	if (socialclub::_0x3001BEF2FECA3680()) {
		if (socialclub::_0x92DA6E70EF249BD1("scriptDisplay", &iVar0)) {
			if (iVar0 == 3) {
				if (!func_292()) {
					if (socialclub::_0xD8122C407663B995()) {
					}
					return false;
				}
			}
		}
	}
	return true;
}

// Position - 0x12570
int func_358() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 1) {
		if (func_359(iVar0) == 1) {
			iVar0 = 2;
			return 1;
		}
		iVar0++;
	}
	return 0;
}

// Position - 0x1259C
int func_359(int iParam0) {
	if (func_334(76, iParam0) == 1) {
		return 1;
	}
	return 0;
}

// Position - 0x125B8
int func_360() {
	if (gameplay::is_ps3_version() && network::_0x9614B71F8ADB982B() == 3) {
		return 1;
	}
	if (gameplay::is_xbox360_version() && network::_0x9614B71F8ADB982B() == 3) {
		return 1;
	}
	if (gameplay::is_orbis_version() && network::_0x1353F87E89946207() == 0) {
		return 1;
	}
	if (gameplay::is_durango_version() && network::_0x1353F87E89946207() == 0) {
		return 1;
	}
	if (gameplay::is_pc_version() && network::network_have_online_privileges()) {
		return 1;
	}
	return 0;
}

// Position - 0x1262D
void func_361(var *uParam0) {
	if (graphics::has_scaleform_movie_loaded(*uParam0)) {
		graphics::_push_scaleform_movie_function(*uParam0, "HIDE_ONLINE_LOGO");
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x1264F
void func_362(int iParam0) {
	if (iParam0) {
		if (Global_1315219 == 0) {
			func_363(1);
			Global_1315219 = 1;
		}
	}
	else if (Global_1315219 == 1) {
		func_363(0);
		ui::_0xA8FDB297A8D25FBA();
		Global_2453695 = 0;
		Global_1315219 = 0;
	}
}

// Position - 0x1268C
void func_363(int iParam0) {
	if (iParam0) {
		ui::_0x56C8B608CFD49854();
	}
	else {
		ui::_0xADED7F5748ACAFE6();
	}
}

// Position - 0x126A4
void func_364() {
	if (Global_1318052) {
		switch (Global_1318053) {
		case 0: break;

		case 1:
			if (network::_0x43865688AE10F0D7()) {
				Global_1318053 = 2;
			}
			else {
				Global_1318052 = 0;
				Global_1318053 = 0;
			}
			break;

		case 2:
			if (network::_0x62B9FEC9A11F10EF()) {
				if (network::_0xDC48473142545431()) {
					Global_1318053 = 3;
				}
			}
			break;

		case 3:
			if (network::_0x62B9FEC9A11F10EF()) {
				if (network::_0xA75E2B6733DA5142()) {
					Global_1318053 = 4;
				}
				else {
					Global_2453933++;
					if (Global_2453933 >= 5) {
						Global_2453933 = 0;
						Global_1318053 = 0;
					}
					else {
						Global_2453934 = network::get_network_time();
						Global_1318053 = 5;
					}
				}
			}
			break;

		case 5:
			if (gameplay::absi(network::get_time_difference(Global_2453934, network::get_network_time())) >
				5000 * Global_2453933) {
				Global_1318052 = 1;
				Global_1318053 = 1;
			}
			break;

		case 4:
			if (!func_419() && func_366(-1)) {
				func_365("FB_NEW_CHAR");
				Global_1318052 = 0;
				Global_1318053 = 0;
			}
			break;

		default:
			Global_1318052 = 0;
			Global_1318053 = 0;
			break;
		}
	}
}

// Position - 0x127B6
void func_365(char *sParam0) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		ui::_set_notification_text_entry("FB_TITLE");
		ui::add_text_component_substring_text_label(sParam0);
		ui::_set_notification_message("CHAR_FACEBOOK", "CHAR_FACEBOOK", 1, 0, "", 0);
	}
}

// Position - 0x127E9
int func_366(int iParam0) {
	if (Global_1312446) {
		return 1;
	}
	if (func_245()) {
		return 1;
	}
	if (func_244()) {
		return 0;
	}
	return func_334(119, iParam0);
}

// Position - 0x1281A
bool func_367(var *uParam0) { return uParam0->f_1; }

// Position - 0x12826
void func_368(var *uParam0, int iParam1) {
	switch (Global_1318055) {
	case 0:
		if (network::network_player_is_badsport() && !func_401(func_402(joaat("mpply_became_badsport_dt")))) {
			if (func_355(uParam0, 1000, 0)) {
			}
			Global_1318055 = 1;
		}
		break;

	case 1:
		func_370(iParam1, 500000);
		if (network::network_player_is_badsport()) {
			if (Global_1318056 != func_369(joaat("mpply_overall_badsport"))) {
				func_370(iParam1, -1);
			}
		}
		Global_1318056 = func_369(joaat("mpply_overall_badsport"));
		if (!network::network_player_is_badsport()) {
			Global_1318055 = 0;
		}
		break;
	}
}

// Position - 0x128B8
float func_369(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_float(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0f;
}

// Position - 0x128D6
void func_370(int iParam0, int iParam1) {
	struct<5> Var0;

	if (iParam0 < 28) {
		func_397(func_398(iParam0), &Global_1353070.f_1112, iParam1);
	}
	else {
		func_372(iParam0, &Var0, &Var0.f_1, &Var0.f_2, &Var0.f_3, &Var0.f_4);
		func_371(Var0, Var0.f_1, Var0.f_2, &Global_1353070.f_1112, iParam1);
	}
}

// Position - 0x1292A
void func_371(int iParam0, int iParam1, int iParam2, var *uParam3, int iParam4) {
	if (func_12(uParam3, iParam4, 0)) {
		if (func_229(player::player_id(), 0, 1)) {
			ui::_set_notification_text_entry("HUD_BADSPTIME_L");
			ui::add_text_component_integer(iParam0);
			ui::add_text_component_integer(iParam1);
			ui::add_text_component_integer(iParam2);
			ui::_draw_notification(0, 1);
		}
	}
}

// Position - 0x1296C
void func_372(int iParam0, var uParam1, var *uParam2, var *uParam3, var *uParam4, var *uParam5) {
	int iVar0;
	int iVar1;
	struct<6> Var2;

	iVar0 = func_396();
	iVar1 = func_385(func_402(joaat("mpply_became_badsport_dt")), iParam0);
	func_373(iVar0, iVar1, &Var2.f_5, &Var2.f_4, &Var2.f_3, &Var2.f_2, &Var2.f_1, &Var2);
	*uParam1 = Var2;
	*uParam2 = Var2.f_1;
	*uParam3 = Var2.f_2;
	*uParam4 = Var2.f_3;
	*uParam5 = Var2.f_4;
}

// Position - 0x129CA
void func_373(int iParam0, int iParam1, int *iParam2, int *iParam3, int *iParam4, int *iParam5, int *iParam6,
			  int *iParam7) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	if (func_383(iParam0, iParam1)) {
		iVar0 = func_382(iParam1);
		iVar1 = func_380(iParam0);
		iVar2 = func_380(iParam0) - func_380(iParam1);
		iVar3 = func_382(iParam0) - func_382(iParam1);
		iVar4 = func_379(iParam0) - func_379(iParam1);
		iVar5 = func_378(iParam0) - func_378(iParam1);
		iVar6 = func_377(iParam0) - func_377(iParam1);
		iVar7 = func_376(iParam0) - func_376(iParam1);
	}
	else {
		iVar0 = func_382(iParam0);
		iVar1 = func_380(iParam1);
		iVar2 = func_380(iParam1) - func_380(iParam0);
		iVar3 = func_382(iParam1) - func_382(iParam0);
		iVar4 = func_379(iParam1) - func_379(iParam0);
		iVar5 = func_378(iParam1) - func_378(iParam0);
		iVar6 = func_377(iParam1) - func_377(iParam0);
		iVar7 = func_376(iParam1) - func_376(iParam0);
	}
	while (iVar7 < 0) {
		iVar7 += 60;
		iVar6--;
	}
	while (iVar7 > 59) {
		iVar7 -= 60;
		iVar6++;
	}
	while (iVar6 < 0) {
		iVar6 += 60;
		iVar5--;
	}
	while (iVar6 > 59) {
		iVar6 -= 60;
		iVar5++;
	}
	while (iVar5 < 0) {
		iVar5 += 24;
		iVar4--;
	}
	while (iVar5 > 23) {
		iVar5 -= 24;
		iVar4++;
	}
	while (iVar4 < 0) {
		while (iVar3 < 0) {
			iVar3 += 12;
			iVar2--;
		}
		iVar4 += func_375(iVar0, iVar1);
		iVar3--;
		iVar0 = system::round(func_374(system::to_float(iVar0 + 1), 0f, 12f));
	}
	while (iVar3 < 0) {
		iVar3 += 12;
		iVar2--;
	}
	while (iVar3 > 12) {
		iVar3 -= 12;
		iVar2++;
	}
	*iParam2 = iVar7;
	*iParam3 = iVar6;
	*iParam4 = iVar5;
	*iParam5 = iVar4;
	*iParam6 = iVar3;
	*iParam7 = iVar2;
}

// Position - 0x12BCB
float func_374(float fParam0, float fParam1, float fParam2) {
	float fVar0;

	if (fParam1 == fParam2) {
		return fParam1;
	}
	fVar0 = fParam2 - fParam1;
	fParam0 -= IntToFloat(system::round((fParam0 - fParam1) / fVar0)) * fVar0;
	if (fParam0 < fParam1) {
		fParam0 += fVar0;
	}
	return fParam0;
}

// Position - 0x12C0D
int func_375(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0x12CAF
int func_376(int iParam0) { return system::shift_right(iParam0, 20) & 63; }

// Position - 0x12CC2
int func_377(int iParam0) { return system::shift_right(iParam0, 14) & 63; }

// Position - 0x12CD5
int func_378(int iParam0) { return system::shift_right(iParam0, 9) & 31; }

// Position - 0x12CE8
int func_379(int iParam0) { return system::shift_right(iParam0, 4) & 31; }

// Position - 0x12CFA
int func_380(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_381(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0x12D1F
int func_381(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0x12D36
int func_382(int iParam0) { return iParam0 & 15; }

// Position - 0x12D43
bool func_383(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (!func_384(iParam1) || !func_384(iParam0)) {
		return true;
	}
	iVar0 = func_380(iParam0);
	iVar1 = func_380(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_382(iParam0);
	iVar1 = func_382(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_379(iParam0);
	iVar1 = func_379(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_378(iParam0);
	iVar1 = func_378(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_377(iParam0);
	iVar1 = func_377(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	else if (iVar0 < iVar1) {
		return false;
	}
	iVar0 = func_376(iParam0);
	iVar1 = func_376(iParam1);
	if (iVar0 > iVar1) {
		return true;
	}
	return false;
}

// Position - 0x12E4F
int func_384(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;

	if (iParam0 == -15) {
		return 0;
	}
	iVar0 = func_376(iParam0);
	if (iVar0 < 0 || iVar0 >= 60) {
		return 0;
	}
	iVar1 = func_377(iParam0);
	if (iVar1 < 0 || iVar1 >= 60) {
		return 0;
	}
	iVar2 = func_378(iParam0);
	if (iVar2 < 0 || iVar2 > 23) {
		return 0;
	}
	iVar3 = func_380(iParam0);
	if (iVar3 <= 0 || iVar3 > 2043 || iVar3 < 1979) {
		return 0;
	}
	iVar4 = func_382(iParam0);
	if (iVar4 < 0 || iVar4 > 11) {
		return 0;
	}
	iVar5 = func_379(iParam0);
	if (iVar5 < 1 || iVar5 > func_375(iVar4, iVar3)) {
		return 0;
	}
	return 1;
}

// Position - 0x12F2B
var func_385(struct<7> Param0, int iParam7) {
	var uVar0;
	int *iVar1;
	var uVar2;

	if (func_401(Param0) == 0) {
		uVar0 = func_394(Param0);
		iVar1 = uVar0;
		func_386(&iVar1, 0, 0, 0, iParam7, 0, 0);
		if (iParam7 == 0) {
			iVar1 = uVar0;
		}
		return iVar1;
	}
	return uVar2;
}

// Position - 0x12F6B
void func_386(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = func_380(*iParam0);
	iVar1 = func_382(*iParam0);
	iVar2 = func_379(*iParam0);
	iVar3 = func_378(*iParam0);
	iVar4 = func_377(*iParam0);
	iVar5 = func_376(*iParam0);
	if (iParam6 == 0 && iParam5 == 0 && iParam4 == 0 && iParam3 == 0 && iParam2 == 0 && iParam1 == 0) {
		return;
	}
	if (iParam1 < 0) {
		return;
	}
	if (iParam2 < 0) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam4 < 0) {
		return;
	}
	if (iParam5 < 0) {
		return;
	}
	if (iParam6 < 0) {
		return;
	}
	iVar5 += iParam1;
	while (iVar5 >= 60) {
		iParam2++;
		iVar5 -= 60;
	}
	iVar4 += iParam2;
	while (iVar4 >= 60) {
		iParam3++;
		iVar4 -= 60;
	}
	iVar3 += iParam3;
	while (iVar3 >= 24) {
		iParam4++;
		iVar3 -= 24;
	}
	iVar2 += iParam4;
	iVar6 = func_375(iVar1, iVar0);
	while (iVar2 > iVar6) {
		iVar1++;
		iVar2 -= iVar6;
		if (iVar1 > 11) {
			iVar0++;
			iVar1 -= 12;
		}
		iVar6 = func_375(iVar1, iVar0);
	}
	iVar1 += iParam5;
	while (iVar1 > 11) {
		iParam6++;
		iVar1 -= 12;
	}
	iVar0 += iParam6;
	func_387(iParam0, iVar5, iVar4, iVar3, iVar2, iVar1, iVar0);
}

// Position - 0x130ED
void func_387(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_393(iParam0, iParam1);
	func_392(iParam0, iParam2);
	func_391(iParam0, iParam3);
	func_390(iParam0, iParam5);
	func_389(iParam0, iParam4);
	func_388(iParam0, iParam6);
}

// Position - 0x13125
void func_388(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0x131AB
void func_389(int *iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_382(*iParam0);
	iVar1 = func_380(*iParam0);
	if (iParam1 < 1 || iParam1 > func_375(iVar0, iVar1)) {
		return;
	}
	*iParam0 -= (*iParam0 & 496);
	*iParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0x131FC
void func_390(int *iParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*iParam0 -= (*iParam0 & 15);
	*iParam0 |= iParam1;
}

// Position - 0x1322F
void func_391(int *iParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*iParam0 -= (*iParam0 & 15872);
	*iParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0x13269
void func_392(int *iParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*iParam0 -= (*iParam0 & 1032192);
	*iParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0x132A4
void func_393(int *iParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*iParam0 -= (*iParam0 & 66060288);
	*iParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0x132E0
var func_394(struct<6> Param0, var uParam6) {
	int *iVar0;

	if (Param0 > 0) {
		func_388(&iVar0, Param0);
	}
	if (Param0.f_1 > 0) {
		func_390(&iVar0, func_395(Param0.f_1));
	}
	if (Param0.f_2 > 0) {
		func_389(&iVar0, Param0.f_2);
	}
	if (Param0.f_3 > 0) {
		func_391(&iVar0, Param0.f_3);
	}
	if (Param0.f_4 > 0) {
		func_392(&iVar0, Param0.f_4);
	}
	if (Param0.f_5 > 0) {
		func_393(&iVar0, Param0.f_5);
	}
	return iVar0;
}

// Position - 0x13356
int func_395(int iParam0) {
	if (iParam0 < 1) {
		return 0;
	}
	if (iParam0 > 12) {
		return 0;
	}
	switch (iParam0) {
	case 1: return 0;

	case 2: return 1;

	case 3: return 2;

	case 4: return 3;

	case 5: return 4;

	case 6: return 5;

	case 7: return 6;

	case 8: return 7;

	case 9: return 8;

	case 10: return 9;

	case 11: return 10;

	case 12: return 11;
	}
	return 0;
}

// Position - 0x1341B
var func_396() {
	int *iVar0;
	struct<6> Var1;

	time::get_posix_time(&Var1, &Var1.f_1, &Var1.f_2, &Var1.f_3, &Var1.f_4, &Var1.f_5);
	func_393(&iVar0, Var1.f_5);
	func_392(&iVar0, Var1.f_4);
	func_391(&iVar0, Var1.f_3);
	func_389(&iVar0, Var1.f_2);
	func_390(&iVar0, Var1.f_1 - 1);
	func_388(&iVar0, Var1);
	return iVar0;
}

// Position - 0x1347B
void func_397(int iParam0, var *uParam1, int iParam2) {
	if (func_12(uParam1, iParam2, 0)) {
		if (func_229(player::player_id(), 0, 1)) {
			ui::_set_notification_text_entry("HUD_BADSPTIME");
			ui::add_text_component_substring_time(iParam0, 156);
			ui::_draw_notification(0, 1);
		}
	}
}

// Position - 0x134B3
int func_398(int iParam0) {
	int iVar0;
	struct<7> Var1;
	int iVar8;
	int iVar9;
	struct<7> Var10;

	Var1 = {func_402(joaat("mpply_became_badsport_dt"))};
	iVar8 = func_396();
	iVar9 = func_385(Var1, iParam0);
	func_373(iVar8, iVar9, &Var10.f_5, &Var10.f_4, &Var10.f_3, &Var10.f_2, &Var10.f_1, &Var10);
	iVar0 = func_399(Var10);
	return iVar0;
}

// Position - 0x13504
int func_399(struct<7> Param0) {
	int iVar0;

	if (func_400(Param0)) {
		if (iVar0 + 86400000 * Param0.f_2 > 2147483647) {
			return 2147483647;
		}
		else {
			iVar0 += 86400000 * Param0.f_2;
		}
		if (iVar0 + 3600000 * Param0.f_3 > 2147483647) {
			return 2147483647;
		}
		else {
			iVar0 += 3600000 * Param0.f_3;
		}
		if (iVar0 + 60000 * Param0.f_4 > 2147483647) {
			return 2147483647;
		}
		else {
			iVar0 += 60000 * Param0.f_4;
		}
		if (iVar0 + 1000 * Param0.f_5 > 2147483647) {
			return 2147483647;
		}
		else {
			iVar0 += 1000 * Param0.f_5;
		}
		if (iVar0 + 1 * Param0.f_6 > 2147483647) {
			return 2147483647;
		}
		else {
			iVar0 += 1 * Param0.f_6;
		}
	}
	return iVar0;
}

// Position - 0x135F4
bool func_400(struct<2> Param0, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6) {
	if (Param0 > 0) {
		return false;
	}
	if (Param0.f_1 > 0) {
		return false;
	}
	return true;
}

// Position - 0x13613
int func_401(struct<7> Param0) {
	if (Param0 == 0 && Param0.f_1 == 0 && Param0.f_2 == 0 && Param0.f_3 == 0 && Param0.f_4 == 0 && Param0.f_5 == 0 &&
		Param0.f_6 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x13669
struct<7> func_402(int iParam0) {
	var uVar0;
	struct<7> Var1;
	struct<7> Var8;

	uVar0 = iParam0;
	if (stats::stat_get_date(uVar0, &Var8, 7, -1)) {
		return Var8;
	}
	return Var1;
}

//Position - 0x1368D
void func_403(var* uParam0, var* uParam1, float* fParam2)
{
	int iVar0;
	struct<7> Var1;
	int iVar8;
	float fVar9;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;
	float fVar14;
	float fVar15;

	if (!network::network_player_is_badsport() && !network::network_player_is_cheater()) {
		iVar0 = Global_262145.f_97 * 60000;
		if (func_12(uParam0, iVar0, 1)) {
			if (func_369(joaat("mpply_overall_badsport")) > 0f) {
				func_418(joaat("mpply_overall_badsport"), Global_262145.f_98);
			}
		}
	}
	if (func_369(joaat("mpply_overall_badsport")) > 0f && !func_401(func_402(joaat("mpply_became_badsport_dt")))) {
		if (func_707(joaat("mpply_became_badsport_num")) == 0) {
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 1) {
			*uParam1 = Global_262145.f_138;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 2) {
			*uParam1 = Global_262145.f_139;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 3) {
			*uParam1 = Global_262145.f_140;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 4) {
			*uParam1 = Global_262145.f_141;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 5) {
			*uParam1 = Global_262145.f_142;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 6) {
			*uParam1 = Global_262145.f_143;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 7) {
			*uParam1 = Global_262145.f_144;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 8) {
			*uParam1 = Global_262145.f_145;
		}
		if (func_707(joaat("mpply_became_badsport_num")) == 9) {
			*uParam1 = Global_262145.f_146;
		}
		if (func_707(joaat("mpply_became_badsport_num")) >= 10) {
			*uParam1 = Global_262145.f_147;
		}
		if (func_355(uParam0, 1000, 0)) {
		}
		if (func_707(joaat("mpply_became_badsport_num")) > 0) {
			if (func_401(func_402(joaat("mpply_badsport_end")))) {
				Var1 = {func_417()};
				iVar8 = func_385(Var1, *uParam1);
				Var1 = {func_415(iVar8)};
				func_414(joaat("mpply_badsport_end"), Var1);
			}
			if (func_412(func_402(joaat("mpply_became_badsport_dt")), func_413(), *uParam1)) {
				func_411(joaat("mpply_overall_badsport"), 0f);
			}
		}
	}
	if (Global_1318075 != Global_1363166) {
		fVar9 = system::to_float(Global_1363166) - system::to_float(Global_1318075);
		if (fVar9 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			func_410(joaat("mpply_overall_badsport"), Global_262145.f_9);
		}
		Global_1318075 = Global_1363166;
	}
	if (Global_1318076 != Global_1363165) {
		fVar10 = system::to_float(Global_1363165) - system::to_float(Global_1318076);
		if (fVar10 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			func_410(joaat("mpply_overall_badsport"), Global_262145.f_10);
		}
		Global_1318076 = Global_1363165;
	}
	if (Global_1318077 != Global_1363164) {
		fVar11 = system::to_float(Global_1363164) - system::to_float(Global_1318077);
		if (fVar11 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			if (func_369(joaat("mpply_overall_badsport")) >= Global_262145.f_8) {
				func_418(joaat("mpply_overall_badsport"), Global_262145.f_8);
			}
			else {
				func_411(joaat("mpply_overall_badsport"), 0f);
			}
		}
		Global_1318077 = Global_1363164;
	}
	if (Global_1318078 != Global_1363167) {
		fVar12 = system::to_float(Global_1363167) - system::to_float(Global_1318078);
		if (fVar12 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			if (func_369(joaat("mpply_overall_badsport")) >= Global_262145.f_7) {
				func_418(joaat("mpply_overall_badsport"), Global_262145.f_7);
			}
			else {
				func_411(joaat("mpply_overall_badsport"), 0f);
			}
		}
		Global_1318078 = Global_1363167;
	}
	if (Global_1318079 != Global_1363168) {
		fVar13 = system::to_float(Global_1363168) - system::to_float(Global_1318079);
		if (fVar13 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			func_410(joaat("mpply_overall_badsport"), Global_262145.f_11);
		}
		Global_1318079 = Global_1363168;
	}
	if (Global_1318080 != Global_1363169) {
		fVar14 = system::to_float(Global_1363169) - system::to_float(Global_1318080);
		if (fVar14 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			func_410(joaat("mpply_overall_badsport"), Global_262145.f_12);
		}
		Global_1318080 = Global_1363169;
	}
	if (Global_1318081 != func_707(joaat("mpply_vc_annoyingme"))) {
		fVar15 = system::to_float(func_707(joaat("mpply_vc_annoyingme"))) - system::to_float(Global_1318081);
		if (fVar15 >= IntToFloat(func_707(joaat("mpply_report_strength")))) {
			func_410(joaat("mpply_overall_badsport"), Global_262145.f_13);
		}
		Global_1318081 = func_707(joaat("mpply_vc_annoyingme"));
	}
	if (*fParam2 != func_369(joaat("mpply_overall_badsport")) &&
		!func_401(func_402(joaat("mpply_became_badsport_dt")))) {
		func_404(system::floor(*fParam2));
	}
	*fParam2 = func_369(joaat("mpply_overall_badsport"));
}

// Position - 0x13ACD
void func_404(int iParam0) {
	int iVar0;

	iVar0 = func_707(joaat("mpply_badsport_message"));
	if (iParam0 < 10 && func_369(joaat("mpply_overall_badsport")) >= 10f && gameplay::is_bit_set(iVar0, 0) == 0 ||
		iParam0 < 20 && func_369(joaat("mpply_overall_badsport")) >= 20f && gameplay::is_bit_set(iVar0, 1) == 0 ||
		iParam0 < 30 && func_369(joaat("mpply_overall_badsport")) >= 30f && gameplay::is_bit_set(iVar0, 2) == 0 ||
		iParam0 < 40 && func_369(joaat("mpply_overall_badsport")) >= 40f && gameplay::is_bit_set(iVar0, 3) == 0) {
		if (iParam0 < 10 && func_369(joaat("mpply_overall_badsport")) >= 10f) {
			gameplay::set_bit(&iVar0, 0);
		}
		if (iParam0 < 20 && func_369(joaat("mpply_overall_badsport")) >= 20f) {
			gameplay::set_bit(&iVar0, 1);
		}
		if (iParam0 < 30 && func_369(joaat("mpply_overall_badsport")) >= 30f) {
			gameplay::set_bit(&iVar0, 2);
		}
		if (iParam0 < 40 && func_369(joaat("mpply_overall_badsport")) >= 40f) {
			gameplay::set_bit(&iVar0, 3);
		}
		func_339(joaat("mpply_badsport_message"), iVar0);
		func_405("HUD_BADRISE", 1);
	}
}

// Position - 0x13C32
int func_405(char *sParam0, int iParam1) {
	int iVar0;

	iVar0 = -1;
	ui::_set_notification_text_entry(sParam0);
	iVar0 = ui::_draw_notification(0, 1);
	func_406(0, sParam0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0);
	return iVar0;
}

// Position - 0x13C5E
void func_406(int iParam0, char *sParam1, int iParam2, char *sParam3, int iParam4, int iParam5, int iParam6,
			  int iParam7, int iParam8, char *sParam9, char *sParam10, char *sParam11) {
	int iVar0;

	if (!func_409() || !network::network_is_activity_session() || !func_210(player::player_id(), 0)) {
		return;
	}
	iVar0 = func_407(iParam2);
	if (iVar0 >= 0 && iVar0 < 5) {
		Global_1759864.f_5[iVar0 /*53*/] = iParam0;
		Global_1759864.f_5[iVar0 /*53*/].f_1 = iParam2;
		StringCopy(&Global_1759864.f_5[iVar0 /*53*/].f_8, sParam1, 16);
		Global_1759864.f_5[iVar0 /*53*/].f_2[0] = iParam4;
		Global_1759864.f_5[iVar0 /*53*/].f_2[1] = iParam5;
		Global_1759864.f_5[iVar0 /*53*/].f_2[2] = iParam6;
		Global_1759864.f_5[iVar0 /*53*/].f_7 = iParam7;
		Global_1759864.f_5[iVar0 /*53*/].f_6 = iParam8;
		StringCopy(&Global_1759864.f_5[iVar0 /*53*/].f_12, sParam3, 64);
		StringCopy(&Global_1759864.f_5[iVar0 /*53*/].f_28[0 /*6*/], sParam9, 24);
		StringCopy(&Global_1759864.f_5[iVar0 /*53*/].f_28[1 /*6*/], sParam10, 24);
		StringCopy(&Global_1759864.f_5[iVar0 /*53*/].f_28[2 /*6*/], sParam11, 24);
	}
}

// Position - 0x13D66
int func_407(int iParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= Global_1759864 - 1) {
		if (iParam0 > Global_1759864.f_5[iVar0 /*53*/].f_1) {
			func_408(iVar0);
			return iVar0;
		}
		iVar0++;
	}
	Global_1759864++;
	if (Global_1759864 > 5) {
		Global_1759864 = 5;
		return Global_1759864;
	}
	return Global_1759864 - 1;
}

// Position - 0x13DC8
void func_408(int iParam0) {
	int iVar0;

	iVar0 = 4;
	while (iVar0 >= iParam0 + 1) {
		Global_1759864.f_5[iVar0 /*53*/] = {Global_1759864.f_5[iVar0 - 1 /*53*/]};
		iVar0 += -1;
	}
}

// Position - 0x13E01
bool func_409() { return dlc2::is_dlc_present(-1762644250); }

// Position - 0x13E12
void func_410(int iParam0, float fParam1) {
	float fVar0;

	fVar0 = func_369(iParam0);
	fVar0 += fParam1;
	func_411(iParam0, fVar0);
}

// Position - 0x13E31
void func_411(int iParam0, float fParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != 0) {
		stats::stat_set_float(iVar0, fParam1, 1);
	}
}

// Position - 0x13E4D
bool func_412(struct<7> Param0, struct<7> Param7, int iParam14) {
	int iVar0;
	int iVar1;

	iVar0 = func_394(Param7);
	iVar1 = func_385(Param0, iParam14);
	if (iVar1 == -15) {
		return false;
	}
	if (func_383(iVar0, iVar1) == 1) {
		return true;
	}
	return false;
}

// Position - 0x13E88
struct<7> func_413() {
	struct<7> Var0;

	time::get_posix_time(&Var0, &Var0.f_1, &Var0.f_2, &Var0.f_3, &Var0.f_4, &Var0.f_5);
	return Var0;
}

//Position - 0x13EAE
void func_414(int iParam0, var uParam1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6, var uParam7)
{
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != 0) {
		stats::stat_set_date(iVar0, &uParam1, 7, 1);
	}
}

// Position - 0x13ECB
struct<7> func_415(int iParam0) {
	struct<7> Var0;

	Var0 = func_380(iParam0);
	Var0.f_1 = func_416(func_382(iParam0));
	Var0.f_2 = func_379(iParam0);
	Var0.f_3 = func_378(iParam0);
	Var0.f_4 = func_377(iParam0);
	Var0.f_5 = func_376(iParam0);
	return Var0;
}

//Position - 0x13F15
int func_416(int iParam0)
{
	switch (iParam0) {
	case 0: return 1;

	case 1: return 2;

	case 2: return 3;

	case 3: return 4;

	case 4: return 5;

	case 5: return 6;

	case 6: return 7;

	case 7: return 8;

	case 8: return 9;

	case 9: return 10;

	case 10: return 11;

	case 11: return 12;
	}
	return 1;
}

// Position - 0x13FC6
struct<7> func_417() {
	struct<7> Var0;
	int iVar7;

	iVar7 = func_396();
	Var0 = func_380(iVar7);
	Var0.f_1 = func_416(func_382(iVar7));
	Var0.f_2 = func_379(iVar7);
	Var0.f_3 = func_378(iVar7);
	Var0.f_4 = func_377(iVar7);
	Var0.f_5 = func_376(iVar7);
	return Var0;
}

//Position - 0x14019
void func_418(int iParam0, float fParam1)
{
	float fVar0;

	fVar0 = func_369(iParam0);
	fVar0 -= fParam1;
	func_411(iParam0, fVar0);
}

// Position - 0x14038
int func_419() { return Global_1315233; }

// Position - 0x14044
void func_420() {
	if (func_421()) {
		controls::disable_control_action(0, 49, 1);
		controls::disable_control_action(0, 36, 1);
		if (func_229(player::player_id(), 1, 1)) {
			player::reset_player_stamina(player::player_id());
			ped::set_ped_move_rate_override(player::player_ped_id(), Global_262145.f_9845);
			if (func_367(&Global_2404994.f_2294)) {
				if (func_355(&Global_2404994.f_2294, 500, 0)) {
					if (Global_2404994.f_2296 > 0) {
						decisionevent::remove_shocking_event(Global_2404994.f_2296);
					}
					func_13(&Global_2404994.f_2294);
				}
			}
			else {
				func_14(&Global_2404994.f_2294, 0, 0);
				Global_2404994.f_2296 = decisionevent::add_shocking_event_for_entity(86, player::player_ped_id(), 0f);
			}
		}
	}
}

// Position - 0x140EB
bool func_421() { return Global_2452482; }

// Position - 0x140F7
void func_422(int *iParam0, var *uParam1, int *iParam2, int *iParam3) {
	if (gameplay::is_pc_version() == 0) {
		return;
	}
	if (network::network_is_game_in_progress() == 0) {
		func_423(iParam0, uParam1);
		return;
	}
	if (func_16() != 0) {
		func_423(iParam0, uParam1);
		return;
	}
	if (func_419()) {
		func_423(iParam0, uParam1);
		return;
	}
	if (Global_91543.f_304 > 0) {
		func_423(iParam0, uParam1);
		return;
	}
	if (func_230() == 0) {
		func_423(iParam0, uParam1);
		return;
	}
	switch (*iParam0) {
	case 0:
		if (unk3::_0x3C4487461E9B0DCB()) {
			if (unk3::_0x2B949A1E6AEC8F6A()) {
				*iParam0 = 2;
			}
			else {
				*iParam2 += Global_262145.f_8238;
				*iParam0 = 1;
			}
		}
		break;

	case 2:
		if (func_12(uParam1, 20000, 0)) {
			*iParam0 = 0;
		}
		break;

	case 1:
		if (func_12(uParam1, *iParam2, 0)) {
			if (unk3::_0x2B949A1E6AEC8F6A() == 0) {
				*iParam0 = 3;
			}
			else {
				*iParam0 = 0;
			}
		}
		break;

	case 3:
		unk3::_0x357B152EF96C30B6();
		*iParam3 = 0;
		*iParam0 = 4;
		break;

	case 4:
		unk3::_0xCF38DAFBB49EDE5E(iParam3);
		switch (*iParam3) {
		case 0: *iParam0 = 0; break;

		case 1: break;

		case 3:
			*iParam2 = 0;
			*iParam0 = 0;
			break;

		case 2: *iParam0 = 0; break;

		case 4: *iParam0 = 0; break;

		default: *iParam0 = 0; break;
		}
		break;
	}
}

// Position - 0x1425C
void func_423(int *iParam0, var *uParam1) {
	if (*iParam0 != 0) {
		*iParam0 = 0;
	}
	func_13(uParam1);
}

// Position - 0x14275
void func_424(int *iParam0) {
	switch (*iParam0) {
	case 0:
		if (gameplay::is_orbis_version() == 0) {
			*iParam0 = 4;
		}
		Global_2454037 = 0;
		if (*iParam0 == 0) {
			if (func_431()) {
				func_13(&Global_2454038);
				*iParam0 = 1;
			}
		}
		break;

	case 1:
		if (func_12(&Global_2454038, 10000, 1)) {
			Global_2454037 = 1;
			*iParam0 = 2;
		}
		break;

	case 2: *iParam0 = 3; break;

	case 3:
		func_426();
		if (func_431() == 0) {
			*iParam0 = 0;
		}
		break;

	case 4:
		if (func_431()) {
			func_425();
		}
		break;
	}
}

// Position - 0x14314
void func_425() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 19) {
		Global_2413052[iVar0 /*83*/] = 0;
		StringCopy(&Global_2413052[iVar0 /*83*/].f_1, "", 64);
		Global_2413052[iVar0 /*83*/].f_17 = 0;
		StringCopy(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "", 64);
		StringCopy(&Global_2413052[iVar0 /*83*/].f_18[1 /*16*/], "", 64);
		StringCopy(&Global_2413052[iVar0 /*83*/].f_18[2 /*16*/], "", 64);
		StringCopy(&Global_2413052[iVar0 /*83*/].f_18[3 /*16*/], "", 64);
		iVar0++;
	}
	func_13(&Global_2454038);
}

// Position - 0x143A2
void func_426() {
	int iVar0;
	int iVar1;

	if (gameplay::is_orbis_version() == 0) {
		if (func_431()) {
			func_425();
		}
		return;
	}
	iVar0 = Global_2454036;
	iVar1 = 0;
	if (func_430(Global_2413052[iVar0 /*83*/])) {
		Global_2413052[iVar0 /*83*/] = 0;
	}
	switch (Global_2413052[iVar0 /*83*/]) {
	case 0: break;

	case 2:
		if (func_428(2)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PUBLISHED_JOB", "AF_PUBLISHED_JOB_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDRACE");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 3:
		if (func_428(3)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PUBLISHED_JOB", "AF_PUBLISHED_JOB_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDDM");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 4:
		if (func_428(4)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PUBLISHED_JOB", "AF_PUBLISHED_JOB_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMISS");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 5:
		if (func_428(5)) {
			gameplay::_0x4DCDF92BF64236CD("AF_VERIFIED", "AF_VERIFIED_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDRACE");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 6:
		if (func_428(6)) {
			gameplay::_0x4DCDF92BF64236CD("AF_VERIFIED", "AF_VERIFIED_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDDM");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 7:
		if (func_428(7)) {
			gameplay::_0x4DCDF92BF64236CD("AF_VERIFIED", "AF_VERIFIED_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMISS");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 8:
		if (func_428(8)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLD_FRI_CAP", "AF_PLD_FRI_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDRACE");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 9:
		if (func_428(9)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLD_FRI_CAP", "AF_PLD_FRI_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDDM");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 10:
		if (func_428(10)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLD_FRI_CAP", "AF_PLD_FRI_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMISS");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 11:
		if (func_428(11)) {
			gameplay::_0x4DCDF92BF64236CD("AF_JOINED_CREW", "AF_JOINED_CREW_COMB");
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 12:
		if (func_428(12)) {
			gameplay::_0x4DCDF92BF64236CD("AF_CREATED_CREW", "AF_CREATED_CREW_COMB");
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 13:
		if (func_428(13)) {
			gameplay::_0xBA4B8D83BDC75551("AF_GAMEMODE");
			func_427(iVar0);
		}
		break;

	case 1:
		if (func_428(1)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAYING_GTAO", "AF_PLAYING_GTAO_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 14:
		if (func_428(14)) {
			gameplay::_0x4DCDF92BF64236CD("AF_TATTOO", "AF_MAKEOVER_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 15:
		if (func_428(15)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PROPERTY", "AF_SHUF_PROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 16:
		if (func_428(16)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PROPERTY", "AF_SHUF_PROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 17:
		if (func_428(17)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PROPERTY", "AF_SHUF_PROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 18:
		if (func_428(18)) {
			gameplay::_0x4DCDF92BF64236CD("AF_MOVING", "AF_SHUF_PROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 19:
		if (func_428(19)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_WEAP", "AF_PUR_WEAP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 20:
		if (func_428(20)) {
			gameplay::_0x4DCDF92BF64236CD("AF_MODDED_VEH", "AF_PUR_MOD_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 21:
		if (func_428(21)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_VEH", "AF_PUR_VEH_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 22:
		if (func_428(22)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_CLOT", "AF_MAKEOVER_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 23:
		if (func_428(23)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_HAIR", "AF_MAKEOVER_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 24:
		if (func_428(24)) {
			gameplay::_0x4DCDF92BF64236CD("AF_COMP_JOBS", "AF_COMP_JOB_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDJOB");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 25:
		if (func_428(25)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_HEIST", "AF_PLAY_HEIST_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDHEIST");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 26:
		if (func_428(26)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_GOLF", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 27:
		if (func_428(27)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_ARM", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 28:
		if (func_428(28)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_SHOOT", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 29:
		if (func_428(29)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_DART", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 30:
		if (func_428(30)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_TENN", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 31:
		if (func_428(31)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_PILO", "AF_PLAY_MINI_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDMINI");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 32:
		if (func_428(32)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_LIST", "AF_PLAY_LIST_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDJNPLY");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 33:
		if (func_428(33)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_TOURN", "AF_PLAY_TOURN_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 34:
		if (func_428(34)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_TOURNQ", "AF_PLAY_TOURNQ_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDTOURN");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 35:
		if (func_428(35)) {
			gameplay::_0x4DCDF92BF64236CD("AF_WON_TOURN", "AF_WON_TOURN_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 36:
		if (func_428(36)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_EVET", "AF_PLAY_EVET_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDEVPLY");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 37:
		if (func_428(37)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PLAY_CHPLY", "AF_PLAY_CHPLY_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDPLAY");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 38:
		if (func_428(38)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SET_CHPLY", "AF_PLAY_CHPLY_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDPLAY");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 39:
		if (func_428(39)) {
			gameplay::_0x4DCDF92BF64236CD("AF_WON_CHPLY", "AF_PLAY_CHPLY_COMB");
			gameplay::_0xEBD3205A207939ED(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDPLAY");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 40:
		if (func_428(40)) {
			gameplay::_0x4DCDF92BF64236CD("AF_GANG_ATT", "AF_GANG_ATT_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 41:
		if (func_428(41)) {
			gameplay::_0x4DCDF92BF64236CD("AF_BOUNTY", "AF_BOUNTY_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 42:
		if (func_428(42)) {
			gameplay::_0x4DCDF92BF64236CD("AF_IMPEXPT", "AF_IMPEXPT_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 43:
		if (func_428(43)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HVEH", "AF_IMPEXPT_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 44:
		if (func_428(44)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SECVAN", "AF_SECVAN_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 45:
		if (func_428(45)) {
			gameplay::_0x4DCDF92BF64236CD("AF_CRATEDROP", "AF_CRATEDROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 46:
		if (func_428(46)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SP_CRATEDROP", "AF_CRATEDROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 47:
		if (func_428(47)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HOLDUP", "AF_HOLDUP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 48:
		if (func_428(48)) {
			gameplay::_0x4DCDF92BF64236CD("AF_STUNTJMP", "AF_STUNTJMP_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 49:
		if (func_428(49)) {
			gameplay::_0x4DCDF92BF64236CD("AF_ONO_DM", "AF_ONO_DM_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 50:
		if (func_428(50)) {
			gameplay::_0x4DCDF92BF64236CD("AF_IMPOMTU_RACE", "AF_IMPOMTU_RACE_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 51:
		if (func_428(51)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PHOTOUP_RACE", "AF_PHOTOUP_RACE_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 52:
		if (func_428(52)) {
			gameplay::_0x4DCDF92BF64236CD("AF_BETTING", "AF_BETTING_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 53:
		if (func_428(53)) {
			gameplay::_0x4DCDF92BF64236CD("AF_MET_LESTOR", "AF_MET_CHARS_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 54:
		if (func_428(54)) {
			gameplay::_0x4DCDF92BF64236CD("AF_MET_TREVOR", "AF_MET_CHARS_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 55:
		if (func_428(55)) {
			gameplay::_0x4DCDF92BF64236CD("AF_MET_MARTIN", "AF_MET_CHARS_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 56:
		if (func_428(56)) {
			gameplay::_0x4DCDF92BF64236CD("AF_DONE_HEIST", "AF_DONE_HEIST_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAO");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;
	}
	switch (Global_2413052[iVar0 /*83*/]) {
	case 57:
		if (func_428(57)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIN_PROLG", "AF_FIN_PROLG_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 58:
		if (func_428(58)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIN_LEST1", "AF_FIN_LEST1_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 59:
		if (func_428(59)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIN_FRANK2", "AF_FIN_FRANK2_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 60:
		if (func_428(60)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIN_RANDOM", "AF_FIN_RANDOM_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 61:
		if (func_428(61)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIN_MISSION", "AF_FIN_MISSION_COMB");
			gameplay::_0x31125FD509D9043F(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 62:
		if (func_428(62)) {
			gameplay::_0x4DCDF92BF64236CD("AF_DRIVEN_ALL", "AF_DRIVEN_ALL_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 63:
		if (func_428(63)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SPACESHIP", "AF_SPACESHIP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 64:
		if (func_428(64)) {
			gameplay::_0x4DCDF92BF64236CD("AF_LETTER_SC", "AF_LETTER_SC_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 65:
		if (func_428(65)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SONAR_COLLECT", "AF_SONAR_COLLECT_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 66:
		if (func_428(66)) {
			gameplay::_0x4DCDF92BF64236CD("AF_DRIVEN_500", "AF_DRIVEN_500_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 67:
		if (func_428(67)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FLOWN_500", "AF_FLOWN_500_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 68:
		if (func_428(68)) {
			gameplay::_0x4DCDF92BF64236CD("AF_RAN_50", "AF_RAN_50_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 69:
		if (func_428(69)) {
			gameplay::_0x4DCDF92BF64236CD("AF_BUSTED_10", "AF_BUSTED_10_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 70:
		if (func_428(70)) {
			gameplay::_0x4DCDF92BF64236CD("AF_WASTED_10", "AF_WASTED_10_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 71:
		if (func_428(71)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FIRE_BULL", "AF_FIRE_BULL_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 72:
		if (func_428(72)) {
			gameplay::_0x4DCDF92BF64236CD("AF_EVADE5STAR", "AF_EVADE5STAR_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 73:
		if (func_428(73)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_CAR", "AF_PURCH_CAR_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 74:
		if (func_428(74)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_RHINO", "AF_PURCH_RHINO_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 75:
		if (func_428(75)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_BUZZ", "AF_PURCH_BUZZ_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 76:
		if (func_428(76)) {
			gameplay::_0x4DCDF92BF64236CD("AF_LOSS_STOCKS", "AF_LOSS_STOCKS_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 77:
		if (func_428(77)) {
			gameplay::_0x4DCDF92BF64236CD("AF_INVEST_STOCKS", "AF_INVEST_STOCKS_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 78:
		if (func_428(78)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SP_STUNTJMP", "AF_SP_STUNTJMP_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 79:
		if (func_428(79)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SP_UNDERBRIG", "AF_SP_UNDERBRIG_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 80:
		if (func_428(80)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FOUND_HIGH", "AF_FOUND_HIGH_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 81:
		if (func_428(81)) {
			gameplay::_0x4DCDF92BF64236CD("AF_SP_DRUNK", "AF_SP_DRUNK_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 82:
		if (func_428(82)) {
			gameplay::_0x4DCDF92BF64236CD("AF_PURCH_ALL_PROP", "AF_PURCH_ALL_PROP_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 83:
		if (func_428(83)) {
			gameplay::_0x4DCDF92BF64236CD("AF_EXPLORATION", "AF_EXPLORATION_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 84:
		if (func_428(84)) {
			gameplay::_0x4DCDF92BF64236CD("AF_LOWEST_PNT", "AF_LOWEST_PNT_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 85:
		if (func_428(85)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HIGH_VEHICLE", "AF_HIGH_VEHICLE_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 86:
		if (func_428(86)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HIGH_WEAPON", "AF_HIGH_WEAPON_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 87:
		if (func_428(87)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HIGH_CLOTHES", "AF_HIGH_CLOTHES_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 88:
		if (func_428(88)) {
			gameplay::_0x4DCDF92BF64236CD("AF_HOLE_IN_ONE", "AF_HOLE_IN_ONE_COMB");
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 89:
		if (func_428(89)) {
			gameplay::_0x4DCDF92BF64236CD("AF_DRIVEN_1000", "AF_DRIVEN_1000_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 90:
		if (func_428(90)) {
			gameplay::_0x4DCDF92BF64236CD("AF_FLOWN_1000", "AF_FLOWN_1000_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 91:
		if (func_428(91)) {
			gameplay::_0x4DCDF92BF64236CD("AF_RAN_100", "AF_RAN_100_COMB");
			gameplay::_0x97E7E2C04245115B(Global_2413052[iVar0 /*83*/].f_17);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;

	case 92:
		if (func_428(92)) {
			gameplay::_0x4DCDF92BF64236CD("AF_ANIMAL_PHOTO", "AF_ANIMAL_PHOTO_COMB");
			gameplay::_0x31125FD509D9043F(&Global_2413052[iVar0 /*83*/].f_1);
			gameplay::_0xEB078CA2B5E82ADD(&Global_2413052[iVar0 /*83*/].f_18[0 /*16*/], "AF_FEEDGTAV");
			iVar1 = 1;
			while (iVar1 <= 3) {
				if (!gameplay::is_string_null_or_empty(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/])) {
					gameplay::_0x703CC7F60CBB2B57(&Global_2413052[iVar0 /*83*/].f_18[iVar1 /*16*/]);
				}
				iVar1++;
			}
			gameplay::_0x8951EB9C6906D3C8();
			func_427(iVar0);
		}
		break;
	}
	Global_2454036++;
	if (Global_2454036 == 93) {
		Global_2454036 = 0;
	}
}

// Position - 0x16FDC
void func_427(int iParam0) {
	Global_2413052[iParam0 /*83*/] = 0;
	StringCopy(&Global_2413052[iParam0 /*83*/].f_1, "", 64);
	Global_2413052[iParam0 /*83*/].f_17 = 0;
	StringCopy(&Global_2413052[iParam0 /*83*/].f_18[0 /*16*/], "", 64);
	StringCopy(&Global_2413052[iParam0 /*83*/].f_18[1 /*16*/], "", 64);
	StringCopy(&Global_2413052[iParam0 /*83*/].f_18[2 /*16*/], "", 64);
	StringCopy(&Global_2413052[iParam0 /*83*/].f_18[3 /*16*/], "", 64);
}

// Position - 0x1704F
bool func_428(int iParam0) {
	if (Global_2412957[iParam0] == 0 || func_12(&Global_2412768[iParam0 /*2*/], func_429(iParam0), 0)) {
		Global_2412957[iParam0] = 1;
		func_13(&Global_2412768[iParam0 /*2*/]);
		return true;
	}
	return false;
}

// Position - 0x17097
int func_429(int iParam0) {
	switch (iParam0) {
	case 0: return 60000;

	case 1: return 60000;

	case 2: return 60000;

	case 3: return 60000;

	case 4: return 60000;

	case 5: return 60000;

	case 6: return 60000;

	case 7: return 60000;

	case 8: return 60000;

	case 9: return 60000;

	case 10: return 60000;

	case 11: return 60000;

	case 12: return 60000;

	case 13: return 3600000;

	case 14: return 60000;

	case 15: return 60000;

	case 16: return 60000;

	case 17: return 60000;

	case 18: return 60000;

	case 19: return 60000;

	case 20: return 60000;

	case 21: return 60000;

	case 22: return 60000;

	case 23: return 60000;

	case 24: return 60000;

	case 25: return 60000;

	case 26: return 60000;

	case 27: return 60000;

	case 28: return 60000;

	case 29: return 60000;

	case 30: return 60000;

	case 31: return 60000;

	case 32: return 60000;

	case 33: return 60000;

	case 34: return 60000;

	case 35: return 60000;

	case 36: return 60000;

	case 37: return 60000;

	case 38: return 60000;

	case 39: return 60000;

	case 40: return 60000;

	case 41: return 60000;

	case 42: return 60000;

	case 43: return 60000;

	case 44: return 60000;

	case 45: return 60000;

	case 46: return 60000;

	case 47: return 60000;

	case 48: return 60000;

	case 49: return 60000;

	case 50: return 60000;

	case 51: return 60000;

	case 52: return 60000;

	case 53: return 0;

	case 54: return 0;

	case 55: return 0;

	case 56: return 60000;

	case 57: return 0;

	case 58: return 0;

	case 59: return 0;

	case 60: return 0;

	case 61: return 0;

	case 62: return 0;

	case 63: return 0;

	case 64: return 0;

	case 65: return 0;

	case 66: return 60000;

	case 67: return 60000;

	case 68: return 60000;

	case 69: return 60000;

	case 70: return 60000;

	case 71: return 60000;

	case 72: return 60000;

	case 73: return 60000;

	case 74: return 60000;

	case 75: return 60000;

	case 76: return 60000;

	case 77: return 60000;

	case 78: return 60000;

	case 79: return 60000;

	case 80: return 60000;

	case 81: return 60000;

	case 82: return 60000;

	case 83: return 60000;

	case 84: return 60000;

	case 85: return 60000;

	case 86: return 60000;

	case 87: return 60000;

	case 88: return 60000;

	case 89: return 60000;

	case 90: return 60000;

	case 91: return 60000;

	case 92: return 60000;

	default:
	}
	return 60000;
}

// Position - 0x1753F
bool func_430(int iParam0) {
	switch (iParam0) {
	case 0: return false;

	case 1: return Global_262145.f_3673;

	case 2: return Global_262145.f_3674;

	case 3: return Global_262145.f_3675;

	case 4: return Global_262145.f_3676;

	case 5: return Global_262145.f_3677;

	case 6: return Global_262145.f_3678;

	case 7: return Global_262145.f_3679;

	case 8: return Global_262145.f_3680;

	case 9: return Global_262145.f_3681;

	case 10: return Global_262145.f_3682;

	case 11: return Global_262145.f_3683;

	case 12: return Global_262145.f_3684;

	case 13: return Global_262145.f_3685;

	case 14: return Global_262145.f_3686;

	case 15: return Global_262145.f_3687;

	case 16: return Global_262145.f_3688;

	case 17: return Global_262145.f_3689;

	case 18: return Global_262145.f_3690;

	case 19: return Global_262145.f_3691;

	case 20: return Global_262145.f_3692;

	case 21: return Global_262145.f_3693;

	case 22: return Global_262145.f_3694;

	case 23: return Global_262145.f_3695;

	case 24: return Global_262145.f_3696;

	case 25: return Global_262145.f_3697;

	case 26: return Global_262145.f_3698;

	case 27: return Global_262145.f_3699;

	case 28: return Global_262145.f_3700;

	case 29: return Global_262145.f_3701;

	case 30: return Global_262145.f_3702;

	case 31: return Global_262145.f_3703;

	case 32: return Global_262145.f_3704;

	case 33: return Global_262145.f_3705;

	case 34: return Global_262145.f_3706;

	case 35: return Global_262145.f_3707;

	case 36: return Global_262145.f_3708;

	case 37: return Global_262145.f_3709;

	case 38: return Global_262145.f_3710;

	case 39: return Global_262145.f_3711;

	case 40: return Global_262145.f_3712;

	case 41: return Global_262145.f_3713;

	case 42: return Global_262145.f_3714;

	case 43: return Global_262145.f_3715;

	case 44: return Global_262145.f_3716;

	case 45: return Global_262145.f_3717;

	case 46: return Global_262145.f_3718;

	case 47: return Global_262145.f_3719;

	case 48: return Global_262145.f_3720;

	case 49: return Global_262145.f_3721;

	case 50: return Global_262145.f_3722;

	case 51: return Global_262145.f_3723;

	case 52: return Global_262145.f_3724;

	case 53: return Global_262145.f_3725;

	case 54: return Global_262145.f_3726;

	case 55: return Global_262145.f_3727;

	case 56: return Global_262145.f_3728;

	case 57: return Global_262145.f_3729;

	case 58: return Global_262145.f_3730;

	case 59: return Global_262145.f_3731;

	case 60: return Global_262145.f_3732;

	case 61: return Global_262145.f_3733;

	case 62: return Global_262145.f_3734;

	case 63: return Global_262145.f_3735;

	case 64: return Global_262145.f_3736;

	case 65: return Global_262145.f_3737;

	case 66: return Global_262145.f_3738;

	case 67: return Global_262145.f_3739;

	case 68: return Global_262145.f_3740;

	case 69: return Global_262145.f_3741;

	case 70: return Global_262145.f_3742;

	case 71: return Global_262145.f_3743;

	case 72: return Global_262145.f_3744;

	case 73: return Global_262145.f_3745;

	case 74: return Global_262145.f_3746;

	case 75: return Global_262145.f_3747;

	case 76: return Global_262145.f_3748;

	case 77: return Global_262145.f_3749;

	case 78: return Global_262145.f_3750;

	case 79: return Global_262145.f_3751;

	case 80: return Global_262145.f_3752;

	case 81: return Global_262145.f_3753;

	case 82: return Global_262145.f_3754;

	case 83: return Global_262145.f_3755;

	case 84: return Global_262145.f_3756;

	case 85: return Global_262145.f_3757;

	case 86: return Global_262145.f_3758;

	case 87: return Global_262145.f_3759;

	case 88: return Global_262145.f_3760;

	case 89: return Global_262145.f_3761;

	case 90: return Global_262145.f_3762;

	case 91: return Global_262145.f_3763;

	case 92: return Global_262145.f_3764;

	default:
	}
	return true;
}

// Position - 0x17B19
bool func_431() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	while (iVar1 <= 19) {
		if (Global_2413052[iVar1 /*83*/] != 0) {
			Global_2454036 = iVar1;
			iVar0 = 1;
			iVar1 = 20;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x17B52
void func_432() {
	if (Global_2453717 == 0) {
		if (Global_139177 && network::_0xD313DE83394AF134() == 1 && dlc2::_0xA213B11DFF526300() == 0) {
			if (unk::_0xEF7D17BC6C85264C() == 0 && Global_2454045 == 0 && func_419() == 0) {
				func_433(30, 1, -1);
				Global_2453717 = 1;
			}
		}
	}
}

// Position - 0x17BAB
void func_433(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0 / 32;
	iVar1 = iParam0 % 32;
	if (iParam2 != -2) {
		Global_1312755 = iParam2;
	}
	if (iParam1) {
		gameplay::set_bit(&Global_1312752[iVar0], iVar1);
	}
	else {
		gameplay::clear_bit(&Global_1312752[iVar0], iVar1);
	}
}

// Position - 0x17BF6
void func_434() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = gameplay::get_game_timer() - Global_2454701;
	Global_2454701 = gameplay::get_game_timer();
	if (func_16() == 0) {
		if (func_195()) {
			if (func_438(player::player_id()) || func_131() == 3) {
				if (iVar0 == 0) {
					iVar0 = 2;
				}
			}
			else if (iVar0 == 0) {
				iVar0 = 1;
			}
		}
		if (streaming::is_player_switch_in_progress() && !func_419() && !func_195() && !func_437() && !Global_1574109 &&
			!network::_0x2EAC52B4019E2782()) {
			if (iVar0 == 0) {
				iVar0 = 1;
			}
		}
	}
	if (func_419() && func_436() == 0 && func_435() == 0) {
		if (iVar0 == 0) {
			iVar0 = 3;
		}
	}
	if (func_437() || Global_1574109) {
		if (iVar0 == 0) {
			iVar0 = 4;
		}
	}
	if (func_294()) {
		switch (iVar0) {
		case 0: break;

		case 1: func_337(joaat("mpply_total_time_load_screen"), iVar1); break;

		case 2: func_337(joaat("mpply_total_time_in_lobby"), iVar1); break;

		case 3: func_337(joaat("mpply_total_time_sess_swap"), iVar1); break;

		case 4: func_337(joaat("mpply_total_time_endjob"), iVar1); break;
		}
	}
}

// Position - 0x17D38
int func_435() { return Global_1312423.f_2; }

// Position - 0x17D46
int func_436() { return Global_1312423.f_1; }

// Position - 0x17D54
bool func_437() { return Global_1574275; }

// Position - 0x17D60
int func_438(int iParam0) {
	if (!func_439(iParam0) || func_194(iParam0) == 8) {
		return 0;
	}
	return 1;
}

// Position - 0x17D86
int func_439(int iParam0) {
	switch (func_194(iParam0)) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 6:
	case 5:
	case 7:
	case 38:
	case 33:
	case 36:
	case 39: return 0;

	default:
	}
	return 1;
}

// Position - 0x17DE6
void func_440() {
	int iVar0;

	iVar0 = 0;
	switch (Global_2452442) {
	case 0:
		if (!streaming::is_player_switch_in_progress() && func_463() != 62 && func_463() != 63 && func_463() != 65 &&
			func_463() != 7 && func_463() != 27) {
			if (func_173()) {
				cam::do_screen_fade_out(0);
				func_462();
				Global_2452442 = 1;
			}
			if (func_461()) {
				Global_2452442 = 2;
			}
			if (func_460()) {
				Global_2452442 = 3;
			}
			if (func_459()) {
				Global_2452442 = 4;
			}
			if (func_458()) {
				if (func_457() == 0) {
					Global_2452442 = 5;
				}
			}
			if (func_456()) {
				Global_2452442 = 6;
			}
			if (func_455()) {
				Global_2452442 = 7;
			}
		}
		break;

	case 1:
		if (func_454()) {
			if (cam::is_screen_faded_out()) {
				cam::do_screen_fade_in(0);
			}
		}
		if (func_443(0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 2:
		if (cam::is_screen_faded_out()) {
			cam::do_screen_fade_in(0);
		}
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_443(0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 3:
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_443(1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 4:
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_443(1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 5:
		if (func_454()) {
			func_99(1);
		}
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_443(0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 6:
		if (func_454()) {
			func_99(1);
		}
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_443(0, 0, 0, 1, 1, 0f, 0f, 0f, 0, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		if (!ped::is_ped_injured(player::player_ped_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 1);
		}
		break;

	case 7:
		ui::hide_scripted_hud_component_this_frame(19);
		if (func_442()) {
			iVar0 = 1;
		}
		if (func_443(0, 0, 1, 1, iVar0, 0f, 0f, 0f, 0, 0, 0, 0, 1, 0)) {
			Global_2452442 = 8;
		}
		break;

	case 8:
		if (func_441() == 0) {
			Global_2452442 = 0;
		}
	}
}

// Position - 0x18035
int func_441() {
	if (func_173() || func_461() || func_460() || func_459() || func_458() || func_456() || func_455()) {
		return 1;
	}
	return 0;
}

// Position - 0x18085
bool func_442() { return Global_91543.f_304 > 0; }

// Position - 0x18096
bool func_443(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			  int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13) {
	int iVar0;
	vector3 vVar1;
	int iVar4;
	vector3 vVar5;

	if (player::is_player_teleport_active()) {
		player::stop_player_teleport();
		return false;
	}
	if (!streaming::_0x71E7B2E657449AAD()) {
		func_166();
		gameplay::_0xE3D969D2785FFB5E();
		if (iParam10) {
			func_100(0);
			func_146(0);
		}
		return false;
	}
	if (!func_210(player::player_id(), 0)) {
		if (func_453()) {
			if (func_463() == 57) {
				func_452(1);
			}
			if (func_451()) {
				if (gameplay::is_bit_set(Global_2359301, 3)) {
					gameplay::clear_bit(&Global_2359301, 3);
				}
			}
			return false;
		}
	}
	if (func_6() == 4) {
		if (streaming::is_player_switch_in_progress() == 0) {
			func_2(0);
		}
	}
	if (ped::is_ped_dead_or_dying(player::player_ped_id(), 1) || ped::is_ped_injured(player::player_ped_id())) {
		func_166();
		if (iParam10) {
			func_100(0);
			func_146(0);
		}
		return false;
	}
	func_174();
	func_449();
	if (iParam9 == 0) {
	}
	if (!iParam11) {
		if (!func_448()) {
			func_447();
		}
	}
	if (!func_5()) {
		if (ui::is_pause_menu_active() == 1) {
			if (iParam1) {
				ui::set_frontend_active(0);
			}
		}
		if (ui::_0x6F72CD94F7B5B68C() == 0) {
			if (ui::get_pause_menu_state() == 25) {
				ui::_0xD2B32BE3FC1626C6();
			}
		}
		if (func_210(player::player_id(), 0) && func_16() == 0) {
			entity::set_entity_coords(player::player_ped_id(), cam::_get_gameplay_cam_coords(), 0, 0, 0, 0);
			iParam4 = 1;
		}
		iVar0 = interior::get_interior_from_entity(player::player_ped_id());
		if (iVar0 != 0) {
			iParam4 = 1;
			if (func_446()) {
				iParam2 = 0;
			}
		}
		if (network::network_is_activity_session() && (gameplay::is_bit_set(Global_1633501.f_13, 7) ||
													   Global_1633501.f_41912 == 6 || Global_1633501.f_41912 == 7)) {
			iParam4 = 1;
			func_146(1);
			iParam2 = 0;
		}
		if (ped::is_ped_swimming(player::player_ped_id())) {
			iParam4 = 1;
		}
		if (cutscene::is_cutscene_playing() || cutscene::is_cutscene_active()) {
			iParam4 = 1;
		}
		if (iParam2 && !func_210(player::player_id(), 0)) {
			func_99(1);
		}
		if (func_230() &&
			(ui::is_pause_menu_active() == 0 || iParam1 == 0 ||
			 ui::is_social_club_active() && ui::is_warning_message_active()) &&
			streaming::_0x71E7B2E657449AAD()) {
			if (!streaming::is_player_switch_in_progress()) {
				if (streaming::is_srl_loaded()) {
					streaming::set_model_as_no_longer_needed(joaat("frogger"));
					streaming::end_srl();
				}
			}
			vVar1 = {entity::get_entity_coords(player::player_ped_id(), 0)};
			ui::clear_prints();
			iVar4 = 0;
			if (iParam4) {
				iVar4 = 1;
			}
			vVar5 = {iParam5, iParam6, iParam7};
			if (iParam3 == 3) {
				if (func_445(vVar5)) {
					iParam3 = 1;
				}
				else if (streaming::get_ideal_player_switch_type(vVar1, vVar5) != 3) {
					iParam3 = 1;
				}
			}
			else if (iParam3 == 2) {
				if (func_445(vVar5)) {
					iParam3 = 1;
				}
				else if (streaming::get_ideal_player_switch_type(vVar1, vVar5) != 2 ||
						 streaming::get_ideal_player_switch_type(vVar1, vVar5) != 3) {
					iParam3 = 1;
				}
			}
			graphics::_0x22A249A53034450A(1);
			player::set_player_invincible(player::player_id(), 1);
			if (iParam12) {
				graphics::_stop_all_screen_effects();
			}
			func_150();
			func_149();
			if (iParam0) {
				if (iParam13 || func_446()) {
					streaming::_switch_out_player(player::player_ped_id(), iVar4 | 32 | 128 | 16384, iParam3);
				}
				else {
					streaming::_switch_out_player(player::player_ped_id(), iVar4 | 32 | 128, iParam3);
				}
			}
			else if (iParam13 || func_446()) {
				streaming::_switch_out_player(player::player_ped_id(), iVar4 | 32 | 16384, iParam3);
			}
			else {
				streaming::_switch_out_player(player::player_ped_id(), iVar4 | 32, iParam3);
			}
			StringCopy(&Global_2452474, "", 32);
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
					StringCopy(&Global_2452474, audio::get_player_radio_station_name(), 32);
					audio::set_radio_to_station_name("OFF");
				}
			}
			func_2(1);
			ui::_set_radar_bigmap_enabled(0, 0);
			if (iParam2 && !func_210(player::player_id(), 0)) {
				func_99(1);
			}
		}
		if (func_6() == 1) {
			if (streaming::is_player_switch_in_progress()) {
				if (streaming::get_player_switch_type() != 3) {
					if (streaming::get_player_switch_state() > 2) {
						func_154();
						func_99(0);
						if (func_444() && unk::_0xEF7D17BC6C85264C() == 0 && network::_0x88B588B41FF7868E() == 0 &&
							network::_0x67FC09BC554A75E5() == 0) {
							if (cam::is_screen_faded_out()) {
								cam::do_screen_fade_in(0);
							}
						}
					}
				}
				else if (iParam2) {
					if (iParam8) {
						func_154();
					}
					func_99(0);
				}
			}
			if (streaming::_0x933BBEEB8C61B5F4()) {
				if (iParam8 == 0 || func_154()) {
					if (iParam2) {
						if (iParam8) {
							func_154();
						}
						func_99(0);
					}
					func_2(2);
					return true;
				}
			}
		}
	}
	else {
		return true;
	}
	return false;
}

// Position - 0x184F5
bool func_444() { return Global_1315202; }

// Position - 0x18501
bool func_445(vector3 vParam0) {
	if (vParam0.x == 0f && vParam0.y == 0f && vParam0.z == 0f) {
		return true;
	}
	return false;
}

// Position - 0x1852B
bool func_446() { return Global_1751531.f_1767; }

// Position - 0x1853A
void func_447() {
	if (!gameplay::is_bit_set(Global_2359301, 27)) {
		gameplay::set_bit(&Global_2359301, 27);
	}
}

// Position - 0x1855A
bool func_448() { return gameplay::is_bit_set(Global_2359301, 27); }

// Position - 0x1856C
void func_449() {
	if (func_450()) {
	}
	if (graphics::_get_screen_effect_is_active("MenuMGTrevorIn")) {
		graphics::_stop_screen_effect("MenuMGTrevorIn");
	}
	if (graphics::_get_screen_effect_is_active("MenuMGMichaelIn")) {
		graphics::_stop_screen_effect("MenuMGMichaelIn");
	}
	if (graphics::_get_screen_effect_is_active("MenuMGFranklinIn")) {
		graphics::_stop_screen_effect("MenuMGFranklinIn");
	}
	if (graphics::_get_screen_effect_is_active("MenuMGTrevorOut")) {
		graphics::_stop_screen_effect("MenuMGTrevorOut");
	}
	if (graphics::_get_screen_effect_is_active("MenuMGMichaelOut")) {
		graphics::_stop_screen_effect("MenuMGMichaelOut");
	}
	if (graphics::_get_screen_effect_is_active("MenuMGFranklinOut")) {
		graphics::_stop_screen_effect("MenuMGFranklinOut");
	}
}

// Position - 0x185ED
bool func_450() {
	int iVar0;

	if (graphics::_get_screen_effect_is_active("MenuMGIn")) {
		graphics::_stop_screen_effect("MenuMGIn");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGSelectionIn")) {
		graphics::_stop_screen_effect("MenuMGSelectionIn");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGSelectionTint")) {
		graphics::_stop_screen_effect("MenuMGSelectionTint");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGTournamentIn")) {
		graphics::_stop_screen_effect("MenuMGTournamentIn");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGHeistIn")) {
		graphics::_stop_screen_effect("MenuMGHeistIn");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGHeistTint")) {
		graphics::_stop_screen_effect("MenuMGHeistTint");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGHeistIntro")) {
		graphics::_stop_screen_effect("MenuMGHeistIntro");
		iVar0 = 1;
	}
	if (graphics::_get_screen_effect_is_active("MenuMGTournamentTint")) {
		graphics::_stop_screen_effect("MenuMGTournamentTint");
		iVar0 = 1;
	}
	return iVar0;
}

// Position - 0x186A5
bool func_451() { return Global_2453015; }

// Position - 0x186B1
void func_452(int iParam0) { Global_2453015 = iParam0; }

// Position - 0x186BF
bool func_453() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0x186D0
bool func_454() {
	if (streaming::is_player_switch_in_progress()) {
		if (streaming::get_player_switch_type() != 3) {
			if (streaming::get_player_switch_state() > 2) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x186F4
bool func_455() { return Global_2452465; }

// Position - 0x18700
bool func_456() { return Global_2452464; }

// Position - 0x1870C
int func_457() { return Global_2433125.f_73; }

// Position - 0x1871A
bool func_458() { return Global_2452466; }

// Position - 0x18726
bool func_459() { return Global_2452463; }

// Position - 0x18732
bool func_460() { return Global_2452519; }

// Position - 0x1873E
bool func_461() { return Global_2452462; }

// Position - 0x1874A
void func_462() { Global_2433125.f_655.f_9 = 1; }

// Position - 0x1875C
int func_463() { return Global_1315168; }

// Position - 0x18768
void func_464() {
	switch (Global_1318029) {
	case 0:
		if (ui::is_warning_message_active() == 0) {
			if (func_653(1) || func_653(2) || func_653(3) || func_653(4) || func_653(5) || func_653(6) || func_653(9) ||
				func_653(10) || func_653(11) || func_653(12) || func_653(13) || func_653(14) || func_653(16) ||
				func_653(19) || func_653(20) || func_653(21) || func_653(22) || func_653(31) || func_653(24) ||
				func_653(23) || func_653(17) || func_653(30) || func_653(32) || func_653(33) || func_653(34) ||
				func_653(25) || func_653(27) || func_653(26) || func_653(35) || func_653(36) || func_653(37) ||
				func_653(38) || func_653(39) || func_653(40) || func_653(41) || func_653(18) || func_653(42) ||
				func_653(43) || func_653(44)) {
				if (func_653(13) && Global_1312755 != -2) {
					player::display_system_signin_ui(1);
					func_13(&Global_1318034);
				}
				if (func_653(37)) {
					network::_0x83FE8D7229593017();
				}
				func_449();
				Global_1318032 = 0;
				Global_1318029 = 1;
			}
		}
		break;

	case 1:
		if (func_653(37) == 0) {
			if (dlc2::get_is_loading_screen_active()) {
				script::shutdown_loading_screen();
			}
		}
		else if (dlc2::get_is_loading_screen_active()) {
			func_172(1);
		}
		if (func_653(1)) {
			func_583();
		}
		if (func_653(42)) {
			func_577();
		}
		if (func_653(2)) {
			func_576();
		}
		if (func_653(3)) {
			func_575();
		}
		if (func_653(4)) {
			func_574();
		}
		if (func_653(17)) {
			func_573();
		}
		if (func_653(5)) {
			func_571();
		}
		if (func_653(6)) {
			func_570();
		}
		if (func_653(9)) {
			func_569();
		}
		if (func_653(10)) {
			func_568();
		}
		if (func_653(11)) {
			func_567();
		}
		if (func_653(12)) {
			func_566();
		}
		if (func_653(13)) {
			func_562(0, 1);
		}
		if (func_653(14)) {
			func_559();
		}
		if (func_653(16)) {
			func_553();
		}
		if (func_653(19)) {
			func_552();
		}
		if (func_653(20)) {
			func_551();
		}
		if (func_653(21)) {
			func_550();
		}
		if (func_653(22)) {
			func_549();
		}
		if (func_653(31)) {
			func_548();
		}
		if (func_653(24)) {
			func_547();
		}
		if (func_653(23)) {
			func_543();
		}
		if (func_653(30)) {
			func_541();
		}
		if (func_653(32)) {
			func_540();
		}
		if (func_653(33)) {
			func_539();
		}
		if (func_653(34)) {
			func_538();
		}
		if (func_653(25)) {
			func_537();
		}
		if (func_653(26)) {
			func_536();
		}
		if (func_653(27)) {
			func_535();
		}
		if (func_653(35)) {
			func_534();
		}
		if (func_653(36)) {
			func_530();
		}
		if (func_653(37)) {
			func_529();
		}
		if (func_653(38)) {
			func_528();
		}
		if (func_653(39)) {
			func_527();
		}
		if (func_653(40)) {
			func_526();
		}
		if (func_653(41)) {
			func_525();
		}
		if (func_653(18)) {
			func_516();
		}
		if (func_653(43)) {
			func_472();
		}
		if (func_653(44)) {
			func_465();
		}
		break;
	}
}

// Position - 0x18BD9
int func_465() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(44, 0, -1);
			unk_0x516FC96EB88EEFE5(1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_MODINSTAL";
	sVar2 = "HUD_RETURNSP";
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x18C6E
void func_466() {
	if (ui::is_warning_message_active()) {
		if (cam::is_screen_faded_out()) {
			cam::do_screen_fade_in(0);
		}
	}
	if (dlc2::get_is_loading_screen_active()) {
		script::shutdown_loading_screen();
	}
}

// Position - 0x18C94
bool func_467(int iParam0) {
	if (controls::is_control_just_released(2, iParam0) || controls::is_disabled_control_just_released(2, iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x18CB8
bool func_468(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = iParam0;
	iVar1 = func_471(iVar0);
	iVar2 = func_470(iVar0);
	if (controls::is_control_just_released(2, iParam0) || controls::is_disabled_control_just_released(2, iParam0) ||
		func_469(iParam0, &Global_1353070.f_1027, 1)) {
		if (!gameplay::is_bit_set(Global_1353070.f_1016[iVar1], iVar2)) {
			gameplay::set_bit(&Global_1353070.f_1016[iVar1], iVar2);
			return true;
		}
	}
	else if (gameplay::is_bit_set(Global_1353070.f_1016[iVar1], iVar2)) {
		gameplay::clear_bit(&Global_1353070.f_1016[iVar1], iVar2);
	}
	return false;
}

// Position - 0x18D52
int func_469(int iParam0, var *uParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = controls::get_control_value(2, 195) - 127;
	iVar1 = controls::get_control_value(2, 196) - 127;
	iVar2 = controls::get_control_value(2, 197) - 127;
	switch (iParam0) {
	case 189:
		if (iVar0 < -30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;

	case 190:
		if (iVar0 > 30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;

	case 188:
		if (iVar1 < -30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;

	case 187:
		if (iVar1 > 30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;

	case 194:
		if (iVar2 > 30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;

	case 193:
		if (iVar2 < -30) {
			if (*uParam1 < gameplay::get_game_timer() || iParam2 == 0) {
				*uParam1 = gameplay::get_game_timer() + 250;
				return 1;
			}
		}
		break;
	}
	return 0;
}

// Position - 0x18EB5
int func_470(int iParam0) { return iParam0 % 32; }

// Position - 0x18EC2
int func_471(int iParam0) { return iParam0 / 32; }

// Position - 0x18ECF
int func_472() {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	int iVar3;

	if (network::network_has_pending_invite() == 0) {
		Global_1318029 = 0;
		Global_1312756 = 0;
		func_433(43, 0, -1);
		return 0;
	}
	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 1);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			Global_2443134.f_765 = 1;
			network::_0x62A0296C1BB1CEB3();
			Global_1318029 = 0;
			Global_1312756 = 0;
			func_212(0);
			func_433(43, 0, -1);
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_1312756, 1)) {
		if (func_467(202)) {
			gameplay::clear_bit(&Global_1312756, 1);
			audio::play_sound_frontend(-1, "CANCEL", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			if (!network::network_is_game_in_progress()) {
				func_492(1, 1);
			}
			if (func_210(player::player_id(), 0)) {
				func_491(1);
			}
			func_490();
			func_489();
			func_479();
			func_478();
			Global_1318029 = 0;
			Global_1312756 = 0;
			func_212(0);
			func_433(43, 0, -1);
			if (func_477() || func_476()) {
				func_475();
				func_474();
				func_473();
			}
			return 2;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_BOSSWARN";
	sVar2 = "HUD_CNGBOSS";
	iVar3 = 16392;
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, iVar3, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1902D
void func_473() { Global_2443134.f_607 = 1; }

// Position - 0x1903D
void func_474() { Global_2443134.f_610 = 0; }

// Position - 0x1904D
void func_475() { Global_2443134.f_606 = 0; }

// Position - 0x1905D
var func_476() { return Global_2443134.f_606; }

// Position - 0x1906C
var func_477() { return Global_2443134.f_610; }

// Position - 0x1907B
void func_478() { Global_2443134.f_597 = 1; }

// Position - 0x1908B
void func_479() {
	func_488(0);
	func_487(0, 1);
	Global_1315244 = 0;
	func_486(0);
	func_485(0);
	network::network_session_force_cancel_invite();
	func_484();
	func_482(1);
	func_481();
	func_480(0);
}

// Position - 0x190C3
void func_480(int iParam0) { Global_2454768 = iParam0; }

// Position - 0x190D1
void func_481() {
	Global_2443905.f_1.f_2812 = 0;
	Global_2443905.f_1.f_2813 = 0;
	Global_2443905.f_1.f_2814 = 0;
	Global_2443905.f_1.f_2815 = 0;
	Global_2443905.f_1.f_2816 = 0;
	Global_2443905.f_1.f_2817 = 0;
}

// Position - 0x19115
void func_482(int iParam0) {
	struct<57> Var0;
	int iVar57;

	Global_2443905.f_1.f_2797 = 0;
	Global_2443905.f_1.f_2798 = 0;
	Global_2443905.f_1.f_2820 = 0;
	Global_2443905.f_1.f_2804 = 0;
	Global_2443905.f_1.f_2805 = 0;
	Global_2443905.f_1.f_2808 = 0;
	Global_2443905.f_1.f_2809 = 0;
	Global_2443905.f_1.f_2807 = -1;
	Global_2443905.f_1.f_2810 = -1;
	Global_2443905.f_1.f_2812 = 0;
	Global_2443905.f_1.f_2813 = 0;
	Global_2443905.f_1.f_2814 = 0;
	Global_2443905.f_1.f_2815 = 0;
	Global_2443905.f_1.f_2816 = 0;
	Global_2443905.f_1.f_2817 = 0;
	Global_2443905.f_1.f_2821 = -1;
	if (iParam0) {
		Global_2443905.f_1.f_2818 = -1;
		Global_2443905.f_1.f_2819 = -1;
	}
	Global_2443905.f_1.f_2840 = 0;
	func_483();
	Var0.f_33 = 2;
	Var0.f_36 = 7;
	iVar57 = 0;
	while (iVar57 <= 31) {
		Global_2443905.f_1.f_844[iVar57 /*57*/] = {Var0};
		iVar57++;
	}
	Global_2440075.f_32 = -1;
}

// Position - 0x19225
void func_483() { Global_2440075.f_31 = 0; }

// Position - 0x19234
void func_484() {
	var uVar0;

	Global_2454769 = uVar0;
}

// Position - 0x19242
void func_485(int iParam0) { Global_2452543 = iParam0; }

// Position - 0x19250
void func_486(int iParam0) { Global_1315202 = iParam0; }

// Position - 0x1925E
void func_487(int iParam0, int iParam1) {
	if (iParam0 == 0) {
		if (func_453()) {
			func_452(1);
		}
		if (iParam1 == 1) {
			network::network_set_activity_spectator(0);
		}
	}
	else if (iParam1 == 1) {
		network::network_set_activity_spectator(1);
	}
	Global_1315229 = iParam0;
}

// Position - 0x19297
void func_488(int iParam0) { Global_1315204 = iParam0; }

// Position - 0x192A5
void func_489() { Global_2443905.f_1.f_2819 = -1; }

// Position - 0x192B7
void func_490() { Global_2443905.f_1.f_2818 = -1; }

// Position - 0x192C9
void func_491(int iParam0) { Global_2454770 = iParam0; }

// Position - 0x192D7
void func_492(int iParam0, int iParam1) {
	struct<12> Var0;
	var uVar12;
	struct<13> Var13;
	int iVar26;
	struct<68> Var27;
	int iVar95;

	if (!Global_2450895.f_3) {
		return;
	}
	if (func_515()) {
		func_514();
		network::_0x444C4525ECE0A4B9();
	}
	Global_2443905.f_3373.f_2 = 0;
	Global_2443905.f_3373.f_3 = 0;
	Global_2443905.f_5845 = -1;
	Global_1312416 = 0;
	if (func_515()) {
		func_514();
	}
	Global_1574819 = -1;
	func_513(1, 1);
	func_512(1, 1, 0);
	func_511();
	Global_2450895.f_7 = 0;
	Global_2494199.f_1644 = 0;
	Global_2494199.f_1645 = 0;
	Global_2494199.f_1646 = 0;
	func_509(-1);
	Global_1574812 = 0;
	func_508();
	if (gameplay::is_orbis_version() && iParam1) {
		func_507();
		network::_0x966DD84FB6A46017();
	}
	Global_979731 = 0;
	Global_1751175.f_2 = 0;
	Global_979732 = -1;
	Global_1742376.f_1569 = 0;
	Global_2443905.f_2842 = 0;
	Global_2443134.f_29.f_41 = -1;
	Global_2443134.f_29.f_39 = 0;
	Global_2443134.f_27 = 0;
	Global_2443134.f_606 = 0;
	Global_2443134.f_628 = 0;
	Global_2443134.f_10 = 0;
	Global_2443905.f_3759 = 0;
	Global_2443905.f_3760 = 0;
	Global_2443905.f_3761 = 0;
	Global_2443134.f_762 = 0;
	Global_2443134.f_761 = 0;
	Var0.f_1 = 10;
	Global_2443905.f_6029 = {Var0};
	Global_2443134.f_11 = 0;
	Global_2443134.f_9 = -1;
	Global_2443134.f_8 = -1;
	Global_2443134.f_7 = 0;
	StringCopy(&Global_2443134.f_13, "", 24);
	Global_2443134.f_25 = 0;
	Global_2443134.f_26 = 0;
	Global_2443134.f_754 = 0;
	Global_1751456 = 0;
	Global_1751456.f_1 = 0;
	Global_1751456.f_2 = 0;
	StringCopy(&Global_1751456.f_3, "", 24);
	Global_970912.f_8 = 0;
	Global_2443134.f_6 = -2;
	StringCopy(&Global_1751175.f_10, "", 24);
	Global_2443134.f_722 = 0;
	Global_2443134.f_638 = 0;
	Global_2443134.f_640 = 0;
	Global_2443134.f_639 = 0;
	Global_2443134.f_636 = 0;
	Global_2443134.f_608 = 0;
	Global_2443134.f_638 = 0;
	Global_2443134.f_733 = 0;
	Global_2443134.f_734 = 0;
	Global_2443134.f_735 = 0;
	Global_2443134.f_613 = 0;
	Global_2443134.f_708 = 0;
	Global_2443905.f_1.f_837 = 6;
	Global_2443134.f_634 = 0;
	Global_2443905.f_1.f_2800 = 0;
	Global_2443134.f_720 = 0;
	Global_2443134.f_579 = 0;
	Global_2443134.f_565 = 0;
	Global_2443134.f_566 = 0;
	Global_2443134.f_567 = 0;
	Global_2443134.f_4 = -1;
	Global_2443134.f_662.f_10 = 0;
	Global_2443134.f_662.f_8 = 0;
	Global_2443134.f_662.f_7 = 0;
	Global_2443134.f_573 = 0;
	Global_2443134.f_662.f_11 = 0;
	Global_2443134.f_592 = 0;
	Global_2443134.f_615 = 0;
	Global_2443134.f_617 = 0;
	Global_2443134.f_593 = 0;
	Global_2443134.f_618 = 0;
	Global_2443134.f_723 = 0;
	Global_2443134.f_622 = 0;
	Global_2443134.f_716 = 0;
	Global_2443134.f_727 = 0;
	Global_2443134.f_597 = 0;
	Global_2443134.f_724 = 0;
	Global_2443134.f_610 = 0;
	Global_2443134.f_589 = 0;
	Global_2443134.f_632 = 0;
	Global_2443134.f_598 = 0;
	Global_2443134.f_599 = 0;
	Global_2443134.f_713 = 0;
	Global_2443134.f_714 = 0;
	Global_2443134.f_590 = 0;
	Global_2443134.f_592 = 0;
	Global_2443134.f_591 = 0;
	Global_2443134.f_611 = 0;
	Global_2443134.f_725 = 0;
	Global_2443134.f_583 = 0;
	Global_2443134.f_728 = 0;
	Global_2443134.f_726 = 0;
	Global_2443134.f_755 = 0;
	Global_2443134.f_756 = 0;
	Global_2443134.f_730 = 0;
	Global_2443134.f_631 = 0;
	Global_2443134.f_604 = 0;
	Global_2443134.f_596 = 0;
	Global_2443134.f_709 = 0;
	Global_2443134.f_609 = 0;
	Global_2443134.f_619 = 0;
	Global_2443134.f_743 = -1;
	Global_2443134.f_704 = 0;
	Global_2443134.f_633 = 0;
	Global_2443134.f_635 = 0;
	Global_2443134.f_625 = 0;
	Global_2443134.f_626 = 0;
	Global_2443134.f_760 = 0;
	Global_2443134.f_637 = 0;
	Global_2443134.f_766 = 0;
	Global_2443134.f_763 = 0;
	Global_2443905 = 0;
	Global_2443134.f_765 = 0;
	Global_2443134.f_12 = 0;
	if (iParam0) {
		Global_2443905.f_2842.f_13 = 3;
		Global_2443905.f_2842.f_77 = 1;
		Global_2443905.f_2842.f_4 = 0;
	}
	Global_1315161 = 0;
	Global_1633501.f_66 = {0f, 0f, 0f};
	func_506();
	func_505();
	func_504();
	func_503();
	func_502();
	func_501();
	func_500();
	func_481();
	func_499();
	func_482(1);
	func_500();
	func_498();
	func_497();
	func_496();
	func_494();
	gameplay::clear_bit(&Global_2443134.f_2, 7);
	func_103();
	Global_2443905.f_5875 = 0;
	Global_2443905.f_5877 = 0;
	Global_2443905.f_5872 = 0;
	Global_2443905.f_5873 = 0;
	Global_2443905.f_5874 = 0;
	Global_2443905.f_5875 = 0;
	Global_2443905.f_5876 = 0;
	Global_2443905.f_5877 = 0;
	Global_2443905.f_5878 = 0;
	Global_2443905.f_5879 = 0;
	Global_2443905.f_5880 = 0;
	Global_2443905.f_5882 = 0;
	Global_2443905.f_5891 = -1;
	Global_2443905.f_5892 = -1;
	Global_2443905.f_5894 = 0;
	Global_2443905.f_5895 = -1;
	Global_2443905.f_5883 = 0;
	Global_2443905.f_5884 = 0;
	Global_16 = 0;
	Global_1751531 = -1;
	Global_1753464.f_2768 = -1;
	Global_1753464.f_2769 = 0;
	Global_1760156.f_6 = 0;
	Global_1760156.f_7 = 0;
	Global_1757074.f_3 = 0;
	Global_1751531.f_1 = 0;
	Global_1751531.f_1758 = 0;
	Global_1757074.f_42 = 0;
	Global_1751531.f_1766 = 0;
	Global_2443905.f_5875 = 0;
	Global_1753464.f_3033.f_140 = 0;
	Global_1751531.f_1767 = 0;
	Global_2443134.f_595 = 0;
	Global_1757074.f_45 = 0;
	Global_1751531.f_1770 = 0;
	Global_1751531.f_1771 = 0;
	Global_1751531.f_1772 = 0;
	Global_1751531.f_1773 = 0;
	Global_1751531.f_1774 = 0;
	Global_1751531.f_1775 = 0;
	Global_1757074.f_1336 = 0;
	Global_1757074.f_52 = 0;
	Global_1757074.f_48 = 0;
	Global_1751531.f_1784 = 0;
	StringCopy(&Global_1757074.f_10, "", 24);
	Global_2443905.f_5890 = 0;
	Global_2404966 = 0;
	Global_1751531.f_1717 = 0;
	Global_1757074.f_1 = uVar12;
	Global_1757074 = uVar12;
	Global_1757074.f_2 = uVar12;
	iVar26 = 0;
	while (iVar26 <= 3) {
		Global_2443905.f_5910[iVar26 /*16*/] = {Var13};
		Global_2443905.f_5910[iVar26 /*16*/].f_13 = -1;
		Global_2443905.f_5910[iVar26 /*16*/].f_14 = -1;
		Global_2443905.f_5910[iVar26 /*16*/].f_15 = -1;
		iVar26++;
	}
	func_493();
	Global_2443905.f_5896 = 0;
	Global_2443905.f_5977 = 0;
	if (Global_1760374 != 0 || Global_1760374.f_1 != 0) {
		network::network_set_in_mp_cutscene(0, 0);
		Global_1760374 = 0;
		Global_1760374.f_1 = 0;
		StringCopy(&Global_1760374.f_4, "", 32);
		Global_1760374.f_12 = {0f, 0f, 0f};
		Global_1760374.f_15 = {0f, 0f, 0f};
		Global_1760374.f_18 = 0;
		Global_1760374.f_199 = 0;
		Global_1760374.f_204 = 0;
		Global_1760374.f_200 = 0;
		Global_1760374.f_202 = 0;
		Global_1760374.f_203 = 0;
		Global_1760374.f_201 = 0;
		Global_1760374.f_19 = 0;
	}
	Global_2404993 = 0;
	if (Global_2404557 == 9) {
		Global_2404557 = 6;
	}
	Var27.f_1 = -1;
	Var27.f_2 = -1;
	Var27.f_3.f_53 = -1;
	Var27.f_3.f_55 = -1;
	Var27.f_3.f_56 = -1;
	Var27.f_3.f_57 = -1;
	Var27.f_3.f_58 = -1;
	Var27.f_3.f_59 = -1;
	Var27.f_3.f_60 = -1;
	Var27.f_3.f_62 = 16777215;
	Var27.f_3.f_64 = 2;
	Global_2398116 = {Var27};
	StringCopy(&Global_2398116.f_3, "", 24);
	Global_1311838 = 1;
	Global_2443905.f_1.f_2822 = 0;
	Global_1751465 = 0;
	Global_1751465.f_1 = 0;
	Global_1751465.f_1.f_1 = 0;
	Global_1751465.f_1.f_2 = 0;
	Global_1751465.f_1.f_3 = 0;
	Global_1751465.f_1.f_4 = 0;
	Global_1751465.f_1.f_5 = 0;
	Global_1751465.f_1.f_6 = 0;
	Global_1751465.f_1.f_7 = 0;
	Global_1751465.f_1.f_8 = 0;
	Global_1751465.f_1.f_9 = 0;
	Global_1751465.f_1.f_10 = 0;
	Global_1751465.f_1.f_11 = 0;
	Global_1751465.f_1.f_12 = 0;
	Global_2443134.f_744 = 0;
	Global_2453937 = 0;
	Global_2453940 = 0;
	Global_2443905.f_5975 = -1;
	Global_2443134.f_769 = 1;
	iVar95 = 0;
	iVar95 = 0;
	while (iVar95 < 4) {
		Global_2443905.f_5859[iVar95] = 0;
		Global_2443905.f_5864[iVar95] = 0;
		iVar95++;
	}
}

// Position - 0x19B18
void func_493() { Global_2443134.f_770 = 0; }

// Position - 0x19B28
void func_494() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 2) {
		if (Global_2477027[iVar0 /*5*/].f_1 != -1 || Global_2477027[iVar0 /*5*/].f_2 != -1 ||
			Global_2477027[iVar0 /*5*/].f_3 != -1 || Global_2477027[iVar0 /*5*/].f_4 != -1) {
			func_495(iVar0);
		}
		iVar0++;
	}
}

// Position - 0x19B8D
void func_495(int iParam0) {
	if (iParam0 < 0 || iParam0 >= 2) {
		return;
	}
	if (Global_2477027[iParam0 /*5*/].f_1 == -1 || Global_2477027[iParam0 /*5*/].f_2 == -1 ||
		Global_2477027[iParam0 /*5*/].f_3 == -1 || Global_2477027[iParam0 /*5*/].f_4 == -1) {
		return;
	}
	ui::_set_hud_colour(Global_2477027[iParam0 /*5*/], Global_2477027[iParam0 /*5*/].f_1,
						Global_2477027[iParam0 /*5*/].f_2, Global_2477027[iParam0 /*5*/].f_3,
						Global_2477027[iParam0 /*5*/].f_4);
	Global_2477027[iParam0 /*5*/] = -1;
	Global_2477027[iParam0 /*5*/].f_1 = -1;
	Global_2477027[iParam0 /*5*/].f_2 = -1;
	Global_2477027[iParam0 /*5*/].f_3 = -1;
	Global_2477027[iParam0 /*5*/].f_4 = -1;
}

// Position - 0x19C5A
void func_496() { Global_2443905.f_1.f_839 = 0; }

// Position - 0x19C6C
void func_497() { Global_1742351.f_7 = 0; }

// Position - 0x19C7B
void func_498() {
	Global_2443905.f_1.f_838 = 0;
	Global_2443905.f_1.f_840 = 0;
}

// Position - 0x19C97
void func_499() {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	int iVar5;
	var uVar6;
	int iVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;
	var uVar14;
	var uVar15;
	var uVar16;
	var uVar17;
	struct<13> Var18;
	struct<16> Var31;
	var uVar47;
	var uVar48;
	var uVar49;
	var uVar50;
	var uVar51;
	var uVar52;
	var uVar53;
	int iVar54;
	var uVar55;
	int iVar56;
	int iVar57;

	iVar5 = -1;
	iVar7 = -1;
	iVar54 = -1;
	Global_2443905.f_5553 = {Var18};
	iVar56 = 0;
	while (iVar56 <= 31) {
		Global_2443905.f_1.f_844[iVar56 /*57*/] = {Var18};
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_13 = {Var31};
		StringCopy(&Global_2443905.f_1.f_844[iVar56 /*57*/].f_29, "", 16);
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_44 = uVar49;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_45 = uVar50;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_46 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_47 = uVar51;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_50 = uVar52;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_55 = uVar53;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_48 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_49 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_54 = 0;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_56 = uVar53;
		Global_2443905.f_1.f_844[iVar56 /*57*/].f_53 = uVar55;
		iVar57 = 0;
		while (iVar57 <= 1) {
			Global_2443905.f_1.f_844[iVar56 /*57*/].f_33[iVar57] = uVar47;
			iVar57++;
		}
		iVar57 = 0;
		while (iVar57 <= 6) {
			Global_2443905.f_1.f_844[iVar56 /*57*/].f_36[iVar57] = uVar48;
			iVar57++;
		}
		iVar56++;
	}
	iVar56 = 0;
	while (iVar56 <= 1) {
		Global_2443905.f_1.f_2669[iVar56 /*57*/] = {Var18};
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_13 = {Var31};
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_44 = uVar49;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_45 = uVar50;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_47 = uVar51;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_50 = uVar52;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_55 = uVar53;
		Global_2443905.f_1.f_2669[iVar56 /*57*/].f_56 = uVar53;
		iVar57 = 0;
		while (iVar57 <= 1) {
			Global_2443905.f_1.f_2669[iVar56 /*57*/].f_33[iVar57] = uVar47;
			iVar57++;
		}
		iVar57 = 0;
		while (iVar57 <= 6) {
			Global_2443905.f_1.f_2669[iVar56 /*57*/].f_36[iVar57] = uVar48;
			iVar57++;
		}
		iVar56++;
	}
	Global_2443905.f_1.f_2797 = uVar0;
	Global_2443905.f_1.f_2798 = uVar1;
	Global_2443905.f_1.f_2799 = uVar2;
	Global_2443905.f_1.f_2801 = uVar3;
	Global_2443905.f_1.f_2804 = uVar4;
	Global_2443905.f_1.f_2805 = 0;
	Global_2443905.f_1.f_2807 = iVar5;
	Global_2443905.f_1.f_2808 = uVar6;
	Global_2443905.f_1.f_2809 = uVar6;
	Global_2443905.f_1.f_2810 = iVar7;
	Global_2443905.f_1.f_2811 = uVar8;
	Global_2443905.f_1.f_2812 = uVar9;
	Global_2443905.f_1.f_2813 = uVar10;
	Global_2443905.f_1.f_2814 = uVar11;
	Global_2443905.f_1.f_2815 = uVar12;
	Global_2443905.f_1.f_2816 = uVar13;
	Global_2443905.f_1.f_2817 = uVar14;
	Global_2443905.f_1.f_2821 = iVar54;
	Global_2443905.f_1.f_2818 = uVar15;
	Global_2443905.f_1.f_2819 = uVar16;
	Global_2443905.f_1.f_2820 = uVar17;
	Global_2443134.f_718 = 0;
}

// Position - 0x19FEF
void func_500() {
	Global_2443134 = 0;
	Global_2443134.f_2 = 0;
	Global_2443134.f_3 = 0;
}

// Position - 0x1A00A
void func_501() { Global_2443134.f_572 = 0; }

// Position - 0x1A01A
void func_502() { Global_2443134.f_575 = 0; }

// Position - 0x1A02A
void func_503() { Global_2443134.f_585 = 0; }

// Position - 0x1A03A
void func_504() { Global_2443134.f_570 = 0; }

// Position - 0x1A04A
void func_505() {
	network::network_block_invites(0);
	network::_0x4A9FDE3A5A6D0437(0);
}

// Position - 0x1A05C
void func_506() { Global_2443134.f_577 = 0; }

// Position - 0x1A06C
void func_507() {
	struct<9> Var0;

	Global_1751456 = {Var0};
}

// Position - 0x1A080
void func_508() {
	script::set_script_as_no_longer_needed("freemode");
	script::set_script_as_no_longer_needed("bootycallhandler");
	script::set_script_as_no_longer_needed("emergencycalllauncher");
	script::set_script_as_no_longer_needed("net_cloud_mission_loader");
	script::set_script_as_no_longer_needed("FMMC_Launcher");
	script::set_script_as_no_longer_needed("freemode_init");
	script::set_script_as_no_longer_needed("AM_MP_PROPERTY_INT");
	script::set_script_as_no_longer_needed("am_doors");
}

// Position - 0x1A0C7
void func_509(int iParam0) {
	if (network::network_is_game_in_progress()) {
		if (Global_2443905.f_3377 != 0 && Global_2443905.f_3377.f_1 != 0 && Global_2443905.f_3377.f_2 != 0 &&
			Global_2443905.f_3377.f_3 != 0) {
			stats::_0xC5BE134EC7BA96A0(Global_2443905.f_3377, Global_2443905.f_3377.f_1, Global_2443905.f_3377.f_2,
									   Global_2443905.f_3377.f_3, iParam0);
		}
	}
	func_510();
}

// Position - 0x1A13E
void func_510() {
	Global_2443905.f_3377 = 0;
	Global_2443905.f_3377.f_1 = 0;
	Global_2443905.f_3377.f_2 = 0;
	Global_2443905.f_3377.f_3 = 0;
}

// Position - 0x1A16C
void func_511() {
	struct<12> Var0;

	Var0 = 1;
	Var0.f_1 = -1;
	Var0.f_1.f_1 = -1;
	Global_1760585 = {Var0};
}

// Position - 0x1A197
void func_512(int iParam0, int iParam1, int iParam2) {
	struct<6> Var0;

	Global_2443134.f_548.f_3 = {Var0};
	Global_2443134.f_548 = 0;
	Global_2443134.f_548.f_1 = 0;
	Global_2443134.f_548.f_12 = 0;
	if (iParam0) {
		Global_2443134.f_548.f_2 = 0;
		Global_2443134.f_548.f_13 = 0;
		Global_2443134.f_548.f_14 = 0;
		Global_2394782 = 0;
		if (iParam1) {
			Global_2443134.f_548.f_9 = 0;
			Global_2443134.f_548.f_10 = 0;
			Global_2443134.f_548.f_11 = 0;
			Global_2443134.f_548.f_16 = -1;
		}
		if (iParam2 && !network::network_is_activity_session()) {
			Global_1742376.f_1571 = 0;
			Global_1742376.f_1572 = 0;
		}
		if (player::player_id() != -1) {
			Global_1618300[player::player_id() /*35*/].f_2 = 0;
			Global_1618300[player::player_id() /*35*/] = 0;
		}
	}
}

// Position - 0x1A25E
void func_513(int iParam0, int iParam1) {
	struct<6> Var0;
	int iVar6;

	Global_2443134.f_29 = -1;
	Global_2443134.f_29.f_55 = -1;
	Global_2443134.f_29.f_1 = -1;
	Global_2443134.f_29.f_4 = 0;
	Global_2443134.f_29.f_2 = 0;
	Global_2443134.f_29.f_3 = 0;
	Global_2443134.f_29.f_40 = -1;
	Global_2443134.f_29.f_5 = {Var0};
	Global_2443134.f_29.f_53 = 0;
	Global_2443134.f_29.f_129 = 0;
	Global_2443134.f_29.f_344 = 0;
	Global_2443134.f_29.f_54 = 0;
	Global_2443134.f_29.f_130 = 0;
	Global_2443134.f_29.f_345 = 0;
	Global_2443134.f_29.f_518 = 0;
	iVar6 = 0;
	while (iVar6 <= 13) {
		Global_2443134.f_29.f_476[iVar6] = 0;
		iVar6++;
	}
	Global_2443134.f_29.f_52 = 0;
	iVar6 = 0;
	while (iVar6 <= 9) {
		Global_2443134.f_29.f_56[iVar6] = 0;
		iVar6++;
	}
	Global_2443134.f_29.f_128 = 0;
	iVar6 = 0;
	while (iVar6 <= 29) {
		Global_2443134.f_29.f_131[iVar6] = 0;
		iVar6++;
	}
	Global_2443134.f_29.f_343 = 0;
	iVar6 = 0;
	while (iVar6 <= 13) {
		Global_2443134.f_29.f_346[iVar6] = 0;
		Global_2443134.f_29.f_361[iVar6] = 0;
		Global_2443134.f_29.f_391[iVar6 /*6*/] = {Var0};
		Global_2443134.f_29.f_376[iVar6] = 0;
		iVar6++;
	}
	if (iParam0) {
		iVar6 = 0;
		while (iVar6 < 4) {
			Global_2443134.f_29.f_42[iVar6] = 0;
			iVar6++;
		}
		if (iParam1) {
			Global_2443134.f_29.f_497 = 0;
			Global_2443134.f_29.f_498 = 0;
			iVar6 = 0;
			while (iVar6 < 5) {
				Global_2443134.f_29.f_505[iVar6] = -1;
				Global_2443134.f_29.f_511[iVar6] = -1;
				iVar6++;
			}
			Global_2443134.f_29.f_47 = 0;
			Global_2443134.f_29.f_11 = {Var0};
			Global_2443134.f_29.f_51 = 0;
			Global_2443134.f_29.f_491 = {0f, 0f, 0f};
			Global_2443134.f_29.f_494 = {0f, 0f, 0f};
			Global_2443134.f_29.f_50 = 0;
			Global_2443134.f_29.f_49 = 0;
		}
	}
}

// Position - 0x1A479
void func_514() { Global_2443134.f_662.f_5 = 0; }

// Position - 0x1A48B
bool func_515() { return Global_2443134.f_662.f_5; }

// Position - 0x1A49C
int func_516() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_524();
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			if (func_463() == 15) {
				func_517(62);
			}
			func_479();
			func_212(0);
			func_433(18, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_ST_INVITE";
	sVar2 = "HUD_QURETSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1A57C
void func_517(int iParam0) {
	int iVar0;
	char *sVar1;
	int iVar2;

	iVar0 = func_463();
	if (Global_1315233) {
		sVar1 = func_518(iParam0);
		iVar2 = gameplay::get_hash_key(sVar1);
		func_8(&Global_2454763, 1, 0);
		unk_0xC3BFED92026A2AAD(iVar2, 1, iVar0, iParam0, 0);
	}
	Global_1315168 = iParam0;
}

// Position - 0x1A5BE
char *func_518(int iParam0) {
	switch (iParam0) {
	case 0: return "TRANSITION_STATE_EMPTY";

	case 1: return "TRANSITION_STATE_SP_SWOOP_UP";

	case 2: return "TRANSITION_STATE_MP_SWOOP_UP";

	case 3: return "TRANSITION_STATE_CREATOR_SWOOP_UP";

	case 4: return "TRANSITION_STATE_PRE_HUD_CHECKS";

	case 5: return "TRANSITION_STATE_WAIT_HUD_EXIT";

	case 7: return "TRANSITION_STATE_SP_SWOOP_DOWN";

	case 8: return "TRANSITION_STATE_MP_SWOOP_DOWN";

	case 6: return "TRANSITION_STATE_WAIT_FOR_SUMMON";

	case 9: return "TRANSITION_STATE_CANCEL_JOINING";

	case 15: return "TRANSITION_STATE_WAIT_ON_INVITE";

	case 10: return "TRANSITION_STATE_RETRY_LOADING";

	case 11: return "TRANSITION_STATE_RETRY_LOADING_SLOT_1";

	case 12: return "TRANSITION_STATE_RETRY_LOADING_SLOT_2";

	case 13: return "TRANSITION_STATE_RETRY_LOADING_SLOT_3";

	case 14: return "TRANSITION_STATE_RETRY_LOADING_SLOT_4";

	case 16: return "TRANSITION_STATE_PREJOINING_FM_SESSION_CHECKS";

	case 17: return "TRANSITION_STATE_LOOK_FOR_FRESH_JOIN_FM";

	case 18: return "TRANSITION_STATE_LOOK_TO_JOIN_ANOTHER_SESSION_FM";

	case 19: return "TRANSITION_STATE_CONFIRM_FM_SESSION_JOINING";

	case 21: return "TRANSITION_STATE_CREATION_ENTER_SESSION";

	case 22: return "TRANSITION_STATE_PRE_FM_LAUNCH_SCRIPT";

	case 23: return "TRANSITION_STATE_FM_TEAMFULL_CHECK";

	case 24: return "TRANSITION_STATE_START_FM_LAUNCH_SCRIPT";

	case 25: return "TRANSITION_STATE_FM_TRANSITION_CREATE_PLAYER";

	case 26: return "TRANSITION_STATE_IS_FM_AND_TRANSITION_READY";

	case 27: return "TRANSITION_STATE_FM_SWOOP_DOWN";

	case 28: return "TRANSITION_STATE_FM_FINAL_SETUP_PLAYER";

	case 29: return "TRANSITION_STATE_MOVE_FM_TO_RUNNING_STATE";

	case 30: return "TRANSITION_STATE_FM_HOW_TO_TERMINATE";

	case 20: return "TRANSITION_STATE_WAIT_JOIN_FM_SESSION";

	case 31: return "TRANSITION_STATE_START_CREATOR_PRE_LAUNCH_SCRIPT_CHECK";

	case 32: return "TRANSITION_STATE_START_CREATOR_LAUNCH_SCRIPT";

	case 33: return "TRANSITION_STATE_CREATOR_TRANSITION_CREATE_PLAYER";

	case 34: return "TRANSITION_STATE_IS_CREATOR_AND_TRANSITION_READY";

	case 35: return "TRANSITION_STATE_CREATOR_SWOOP_DOWN";

	case 36: return "TRANSITION_STATE_CREATOR_FINAL_SETUP_PLAYER";

	case 37: return "TRANSITION_STATE_MOVE_CREATOR_TO_RUNNING_STATE";

	case 38: return "TRANSITION_STATE_PREJOINING_TESTBED_SESSION_CHECKS";

	case 39: return "TRANSITION_STATE_LOOK_FOR_FRESH_JOIN_TESTBED";

	case 40: return "TRANSITION_STATE_LOOK_FOR_FRESH_HOST_TESTBED";

	case 41: return "TRANSITION_STATE_LOOK_TO_JOIN_ANOTHER_SESSION_TESTBED";

	case 42: return "TRANSITION_STATE_LOOK_TO_HOST_SESSION_TESTBED";

	case 43: return "TRANSITION_STATE_CONFIRM_TESTBED_SESSION_JOINING";

	case 45: return "TRANSITION_STATE_START_TESTBED_LAUNCH_SCRIPT";

	case 46: return "TRANSITION_STATE_TESTBED_TRANSITION_CREATE_PLAYER";

	case 47: return "TRANSITION_STATE_IS_TESTBED_AND_TRANSITION_READY";

	case 48: return "TRANSITION_STATE_TESTBED_SWOOP_DOWN";

	case 49: return "TRANSITION_STATE_TESTBED_FINAL_SETUP_PLAYER";

	case 50: return "TRANSITION_STATE_MOVE_TESTBED_TO_RUNNING_STATE";

	case 51: return "TRANSITION_STATE_TESTBED_HOW_TO_TERMINATE";

	case 44: return "TRANSITION_STATE_WAIT_JOIN_TESTBED_SESSION";

	case 53: return "TRANSITION_STATE_WAIT_FOR_TRANSITION_SESSION_TO_SETUP";

	case 52: return "TRANSITION_STATE_QUIT_CURRENT_SESSION_PROMPT";

	case 54: return "TRANSITION_STATE_TERMINATE_SP";

	case 55: return "TRANSITION_STATE_WAIT_TERMINATE_SP";

	case 56: return "TRANSITION_STATE_KICK_TERMINATE_SESSION";

	case 57: return "TRANSITION_STATE_TERMINATE_SESSION";

	case 58: return "TRANSITION_STATE_WAIT_TERMINATE_SESSION";

	case 59: return "TRANSITION_STATE_TERMINATE_SESSION_AND_HOLD";

	case 60: return "TRANSITION_STATE_TERMINATE_SESSION_AND_MOVE_INTO_HOLDING_STATE";

	case 61: return "TRANSITION_STATE_TEAM_SWAPPING_CHECKS";

	case 62: return "TRANSITION_STATE_RETURN_TO_SINGLEPLAYER";

	case 63: return "TRANSITION_STATE_WAIT_FOR_SINGLEPLAYER_TO_START";

	case 64: return "TRANSITION_STATE_WAITING_FOR_EXTERNAL_TERMINATION_CALL";

	case 65: return "TRANSITION_STATE_TERMINATE_MAINTRANSITION";

	case 66: return "TRANSITION_STATE_WAIT_FOR_DIRTY_LOAD_CONFIRM";

	default:
	}
	return "";
}

// Position - 0x1A937
void func_519(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	bool bVar1;
	bool bVar2;
	bool bVar3;
	bool bVar4;
	bool bVar5;
	bool bVar6;
	bool bVar7;
	bool bVar8;
	bool bVar9;
	bool bVar10;
	bool bVar11;
	bool bVar12;
	bool bVar13;
	bool bVar14;
	int iVar15;
	int iVar16;
	bool bVar17;
	bool bVar18;
	bool bVar19;
	bool bVar20;
	bool bVar21;
	bool bVar22;
	bool bVar23;
	bool bVar24;
	int iVar25;
	int iVar26;

	if (iParam1) {
		if (script::_get_no_loading_screen()) {
			script::set_no_loading_screen(0);
		}
	}
	if (!network::network_is_game_in_progress()) {
		iVar0 = iParam2;
		player::set_player_control(iParam0, iParam1, iVar0);
	}
	else {
		bVar1 = (iParam2 & 2) != false;
		bVar2 = (iParam2 & 4) != false;
		bVar3 = (iParam2 & 8) != false;
		bVar4 = (iParam2 & 16) != false;
		bVar5 = (iParam2 & 32) != false;
		bVar6 = (iParam2 & 64) != false;
		bVar7 = (iParam2 & 128) != false;
		bVar8 = (iParam2 & 256) != false;
		bVar9 = (iParam2 & 512) != false;
		bVar10 = (iParam2 & 1024) != false;
		bVar11 = (iParam2 & 2048) != false;
		bVar12 = (iParam2 & 4096) != false;
		bVar13 = (iParam2 & 8192) != false;
		bVar14 = (iParam2 & 16384) != false;
		iVar15 = (iParam2 & 32768) != 0;
		iVar16 = (iParam2 & 65536) != 0;
		bVar17 = (iParam2 & 131072) != false;
		bVar18 = (iParam2 & 262144) != false;
		bVar19 = (iParam2 & 524288) != false;
		bVar20 = (iParam2 & 1048576) != false;
		bVar21 = (iParam2 & 2097152) != false;
		bVar22 = (iParam2 & 4194304) != false;
		bVar23 = (iParam2 & 8388608) != false;
		if (!func_230()) {
			bVar24 = false;
			if (iParam1 == 1) {
				bVar24 = true;
			}
			if (iVar15 == 0 && !bVar20) {
				bVar24 = true;
			}
			if (bVar9 == 1) {
				bVar24 = true;
			}
			if (bVar24) {
				return;
			}
		}
		if (bVar17) {
		}
		if (network::network_is_player_active(iParam0) && player::is_player_playing(iParam0)) {
			iVar25 = player::get_player_ped(iParam0);
			if (!bVar19) {
				if (bVar18 && iParam1 == 0 && network::network_is_game_in_progress()) {
					network::fade_out_local_player(1);
				}
				else {
					entity::set_entity_visible(iVar25, !bVar13, 0);
				}
				if (!bVar13) {
					if (network::network_is_game_in_progress() && !bVar18) {
						network::fade_out_local_player(0);
					}
					Global_2421664[iParam0 /*358*/].f_247 = 0;
				}
			}
			if (iParam1) {
				if (!func_523(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, 1, 0);
					}
				}
				if (!entity::is_entity_attached(iVar25)) {
					if (!bVar20) {
						entity::freeze_entity_position(iVar25, 0);
					}
					entity::_set_entity_register(iVar25, 1);
				}
				else if (!bVar20) {
					entity::freeze_entity_position(iVar25, 0);
				}
				ped::set_ped_can_be_targetted(iVar25, 1);
				player::set_player_invincible(iParam0, 0);
				ped::_0x4668D80430D6C299(iVar25);
				ped::set_ped_can_ragdoll(iVar25, 1);
				func_522();
				func_521();
				if (player::is_player_teleport_active()) {
					if (!bVar22) {
					}
				}
				if (streaming::is_new_load_scene_active()) {
				}
				Global_2421664[iParam0 /*358*/].f_248 = 0;
				if (!bVar23) {
					bVar2 = true;
				}
			}
			else {
				if (!func_523(iVar25) && !entity::is_entity_attached_to_any_vehicle(iVar25)) {
					if (!bVar21) {
						entity::set_entity_collision(iVar25, !bVar14, 0);
					}
					if (!entity::is_entity_attached(iVar25)) {
						if (!bVar20) {
							entity::freeze_entity_position(iVar25, iVar15);
						}
						if (!iVar15) {
							entity::_set_entity_register(iVar25, 1);
						}
					}
					if (func_520(Global_1633501.f_107548)) {
						entity::freeze_entity_position(iVar25, 1);
					}
				}
				if (bVar9) {
					player::set_player_invincible(iParam0, 0);
				}
				else {
					player::set_player_invincible(iParam0, 1);
				}
				ped::set_ped_can_be_targetted(iVar25, iVar16);
				if (bVar2) {
					if (!ped::is_ped_fatally_injured(iVar25) && !ped::is_ped_in_any_vehicle(iVar25, 0)) {
						ai::clear_ped_tasks_immediately(iVar25);
					}
				}
			}
			iVar26 = 0;
			if (bVar1) {
				iVar26 |= 2;
			}
			if (bVar2) {
				iVar26 |= 4;
			}
			if (bVar3) {
				iVar26 |= 8;
			}
			if (bVar4) {
				iVar26 |= 16;
			}
			if (bVar5) {
				iVar26 |= 32;
			}
			if (bVar6) {
				iVar26 |= 64;
			}
			if (bVar7) {
				iVar26 |= 128;
			}
			if (bVar8) {
				iVar26 |= 256;
			}
			if (bVar9) {
				iVar26 |= 512;
			}
			if (bVar10) {
				iVar26 |= 1024;
			}
			if (bVar11) {
				iVar26 |= 2048;
			}
			if (bVar12) {
				iVar26 |= 4096;
			}
			player::set_player_control(iParam0, iParam1, iVar26);
		}
	}
}

// Position - 0x1ACEE
bool func_520(int iParam0) { return iParam0 == 17; }

// Position - 0x1ACFB
void func_521() {
	struct<2> Var0;

	Global_2433125.f_731 = 0;
	Global_2433125.f_732 = 0;
	Global_2433125.f_733 = {9999.9f, 9999.9f, 9999.9f};
	Global_2404994.f_2220 = {Var0};
}

// Position - 0x1AD38
void func_522() {
	Global_2404994.f_644 = 0;
	Global_2404994.f_2261 = 0;
	Global_2404994.f_501 = 0;
	Global_2404994.f_576 = 0;
	Global_2421664[player::player_id() /*358*/].f_210 = 0;
}

// Position - 0x1AD6E
int func_523(int iParam0) {
	int iVar0;

	if (ped::is_ped_in_any_vehicle(iParam0, 1)) {
		return 1;
	}
	else {
		iVar0 = ai::get_script_task_status(iParam0, -1794415470);
		if (iVar0 == 0) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1AD9F
void func_524() { Global_2443134.f_620 = 0; }

// Position - 0x1ADAF
int func_525() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(41, 0, -1);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_NOCONNECT";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1AE33
int func_526() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(40, 0, -1);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "PM_LAUNCH";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1AEB7
int func_527() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(39, 0, -1);
			if (func_463() == 15) {
				func_517(62);
			}
			func_479();
			func_212(0);
			Global_1318029 = 0;
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_LOADMAIN";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1AF3F
int func_528() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(38, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_COMPTITLE";
	sVar1 = "HUD_IMPORFIN";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1AFA3
int func_529() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (player::is_system_ui_being_displayed() == 0) {
		if (gameplay::is_bit_set(Global_1312756, 0)) {
			if (func_467(201)) {
				gameplay::clear_bit(&Global_1312756, 0);
				Global_1318029 = 0;
				func_433(25, 0, -1);
				func_433(37, 0, -1);
				return 1;
			}
		}
	}
	if (network::_0x5EA784D197556507() == 1) {
		return 1;
	}
	if (dlc2::get_is_loading_screen_active()) {
		if (func_5()) {
			script::shutdown_loading_screen();
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_PSPLUS";
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	if (player::is_system_ui_being_displayed() == 0) {
		ui::_set_warning_message_2(sVar0, sVar1, 16384, 0, 0, -1, 0, 0, 1);
	}
	else {
		graphics::draw_rect(0f, 0f, 1f, 1f, 0, 0, 0, 255, 0);
	}
	return 0;
}

// Position - 0x1B061
int func_530() {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	int iVar3;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_5()) {
		if (gameplay::is_bit_set(Global_1312756, 0)) {
			if (func_467(201)) {
				gameplay::clear_bit(&Global_1312756, 0);
				Global_1318029 = 0;
				func_433(36, 0, -1);
				if (func_294() == 0) {
					func_533(0);
				}
				func_531(32);
				func_517(62);
				return 1;
			}
		}
	}
	func_443(0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0);
	sVar0 = "HUD_TRANSPEND";
	sVar1 = "HUD_SAVEPROGRES";
	sVar2 = "";
	iVar3 = 2;
	if (!func_5()) {
		iVar3 = 134217728;
	}
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, iVar3, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B122
void func_531(int iParam0) {
	int iVar0;

	iVar0 = func_532();
	Global_1315167 = iParam0;
}

// Position - 0x1B136
int func_532() { return Global_1315167; }

// Position - 0x1B142
void func_533(int iParam0) { Global_2454748 = iParam0; }

// Position - 0x1B150
int func_534() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(35, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_REPLYINVITE";
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B1C7
int func_535() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(27, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_SYSTUPD";
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B23E
int func_536() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(26, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_GAMEUPD";
	if (cam::is_screen_faded_out()) {
		cam::do_screen_fade_in(0);
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B2B5
int func_537() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(25, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_PROFILECHNG";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B320
int func_538() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(34, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "NO_INDIV_SPEC";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B384
int func_539() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_524();
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			network::_network_request_cloud_background_scripts();
			if (func_463() == 15) {
				func_517(62);
			}
			func_479();
			func_212(0);
			func_433(33, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_NOBACKGRN";
	sVar2 = "HUD_SPRETRNFRSH";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B469
int func_540() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_524();
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			if (func_463() == 15) {
				func_517(62);
			}
			func_479();
			func_212(0);
			func_433(32, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_NOTUNE";
	sVar2 = "HUD_SPRETRNFRSH";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1B549
int func_541() {
	char *sVar0;
	char *sVar1;
	bool bVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 1);
	}
	switch (Global_2453716) {
	case 0:
		sVar0 = "HUD_CONNPROB";
		sVar1 = "HUD_COMBATPACK";
		ui::_set_warning_message_2(sVar0, sVar1, 36, 0, 0, -1, 0, 0, 1);
		func_466();
		if (gameplay::is_bit_set(Global_1312756, 0)) {
			if (func_467(201)) {
				gameplay::clear_bit(&Global_1312756, 0);
				gameplay::clear_bit(&Global_1312756, 1);
				script::shutdown_loading_screen();
				network::_0x58C21165F6545892("", "COMPAT_PACKS", 0);
				Global_2453716 = 1;
			}
		}
		if (gameplay::is_bit_set(Global_1312756, 1)) {
			if (func_467(202)) {
				gameplay::clear_bit(&Global_1312756, 1);
				gameplay::clear_bit(&Global_1312756, 0);
				func_542();
				return 2;
			}
		}
		break;

	case 1: Global_2453716 = 2; break;

	case 2:
		if (cam::is_screen_faded_out()) {
			cam::do_screen_fade_in(0);
		}
		if (!network::_0x2EAC52B4019E2782()) {
			gameplay::clear_bit(&Global_1312756, 0);
			gameplay::clear_bit(&Global_1312756, 1);
			Global_2453716 = 3;
		}
		break;

	case 3:
		if (dlc2::_nullify(&bVar2, 0)) {
			Global_2453716 = 0;
			Global_1318029 = 0;
			func_433(30, 0, -1);
			if (dlc2::_0xA213B11DFF526300() == 0) {
				Global_2453717 = 0;
				func_542();
				return 2;
			}
			return 1;
		}
		if (bVar2) {
			gameplay::clear_bit(&Global_1312756, 0);
			gameplay::clear_bit(&Global_1312756, 1);
			Global_2453716 = 4;
		}
		break;

	case 4:
		sVar0 = "HUD_CONNPROB";
		sVar1 = "HUD_COMBATPACKT";
		ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
		if (gameplay::is_bit_set(Global_1312756, 0)) {
			if (func_467(201)) {
				gameplay::clear_bit(&Global_1312756, 0);
				gameplay::clear_bit(&Global_1312756, 1);
				Global_2453716 = 0;
				func_542();
				return 1;
			}
		}
		break;
	}
	return 0;
}

// Position - 0x1B70A
void func_542() {
	Global_1318029 = 0;
	func_524();
	if (network::network_is_game_in_progress()) {
		func_519(player::player_id(), 1, 0);
	}
	else {
		player::set_player_invincible(player::player_id(), 1);
		player::set_player_control(player::player_id(), 1, 0);
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (!entity::is_entity_attached(player::player_ped_id())) {
				entity::set_entity_collision(player::player_ped_id(), 1, 0);
				entity::freeze_entity_position(player::player_ped_id(), 0);
			}
		}
	}
	if (func_463() == 15) {
		func_517(62);
	}
	func_479();
	Global_2453716 = 0;
	func_212(0);
	Global_2453717 = 0;
	func_433(30, 0, -1);
}

// Position - 0x1B797
int func_543() {
	int iVar0;
	var *uVar1;
	int iVar7;
	int iVar8;
	char *sVar9;
	char *sVar10;
	char *sVar11;
	var uVar12;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(23, 0, -1);
			return 1;
		}
	}
	iVar0 = 0;
	if (network::_network_are_ros_available() == 1) {
		iVar8 = 7;
		iVar7 = network::_0xC22912B1D85F26B1(iVar8, &iVar0, &uVar1);
	}
	sVar9 = "HUD_CONNPROB";
	sVar10 = "HUD_SCSBANNED";
	sVar11 = "HUD_RETURNSP";
	if (iVar7 == 0) {
		sVar10 = "HUD_SCSBANPERM";
		ui::_set_warning_message_2(sVar9, sVar10, 16384, sVar11, 0, -1, 0, 0, 1);
	}
	else if (iVar0 == 1) {
		sVar10 = "HUD_SCSBANX";
		MemCopy(&uVar12, {func_544(&uVar1)}, 6);
		ui::_set_warning_message_3(sVar9, sVar10, 16384, "", 0, -1, 1, &uVar12, 0, 1);
	}
	else {
		ui::_set_warning_message_2(sVar9, sVar10, 16384, sVar11, 0, -1, 0, 0, 1);
	}
	func_466();
	return 0;
}

// Position - 0x1B874
struct<8> func_544(var *uParam0) {
	struct<8> Var0;
	struct<8> Var8;

	StringCopy(&Var8, func_546(uParam0->f_1), 32);
	switch (unk::_get_current_language_id()) {
	case 5:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTMONTHCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 9:
		IntToString(&Var0, *uParam0, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTYEARCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		break;

	case 1:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		if (uParam0->f_2 == 1) {
			StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		}
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 2:
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, ". ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 3:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 10:
		IntToString(&Var0, *uParam0, 32);
		StringConCat(&Var0, ui::_get_label_text("POSTYEARCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, ui::_get_label_text("POSTMONTHCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		break;

	case 8:
		IntToString(&Var0, *uParam0, 32);
		StringConCat(&Var0, ui::_get_label_text("POSTYEARCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		break;

	case 11:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTMONTHCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 6:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 7:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTYEARCHAR"), 32);
		break;

	case 4:
		StringCopy(&Var8, func_545(uParam0->f_1), 32);
		IntToString(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTDAYCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, &Var8, 32);
		StringConCat(&Var0, " ", 32);
		StringConCat(&Var0, ui::_get_label_text("POSTMONTHCHAR"), 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	case 0:
		Var0 = {Var8};
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;

	default:
		Var0 = {Var8};
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, uParam0->f_2, 32);
		StringConCat(&Var0, " ", 32);
		StringIntConCat(&Var0, *uParam0, 32);
		break;
	}
	return Var0;
}

//Position - 0x1BC46
var func_545(int iParam0)
{
	char cVar0[16];

	StringCopy(&cVar0, "MONTH_", 16);
	StringIntConCat(&cVar0, iParam0, 16);
	StringConCat(&cVar0, "L", 16);
	return ui::_get_label_text(&cVar0);
}

// Position - 0x1BC6A
var func_546(int iParam0) {
	char cVar0[16];

	StringCopy(&cVar0, "MONTH_", 16);
	StringIntConCat(&cVar0, iParam0, 16);
	return ui::_get_label_text(&cVar0);
}

// Position - 0x1BC86
int func_547() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_433(24, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_PERM";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BCF8
int func_548() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_13(&Global_1318034);
			func_212(0);
			Global_1318029 = 0;
			func_433(31, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "BUD_BAILPOLC";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BD6E
int func_549() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_13(&Global_1318034);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(22, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_J_FL";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BDF3
int func_550() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_13(&Global_1318034);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(21, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_J_FL";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BE78
int func_551() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_13(&Global_1318034);
			func_212(0);
			Global_1318029 = 0;
			func_433(20, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_J_FL";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BEEE
int func_552() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_13(&Global_1318034);
			func_212(0);
			Global_1318029 = 0;
			func_433(19, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_J_FL";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1BF64
int func_553() {
	int iVar0;
	char *sVar1;
	char *sVar2;
	char *sVar3;
	int iVar4;

	if (network::network_has_pending_invite() == 0) {
		Global_1318029 = 0;
		Global_1312756 = 0;
		func_433(16, 0, -1);
		return 0;
	}
	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 1);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			func_558(controls::get_local_player_aim_state());
			if (func_557() == 0 || func_557() == 1) {
				iVar0 = 1;
			}
			else if (func_557() == 2) {
				iVar0 = 2;
			}
			else {
				iVar0 = 3;
			}
			player::set_player_targeting_mode(iVar0);
			if (func_556(func_557())) {
				network::_0x62A0296C1BB1CEB3();
				func_555(1);
				Global_1318029 = 0;
				Global_1312756 = 0;
				func_212(0);
				func_433(16, 0, -1);
				return 1;
			}
			else {
				if (!network::network_is_game_in_progress()) {
					func_492(1, 1);
				}
				func_490();
				func_489();
				func_479();
				if (func_131() != 0) {
					func_478();
				}
				Global_1318029 = 0;
				Global_1312756 = 0;
				func_212(0);
				func_433(16, 0, -1);
				if (func_477() || func_476()) {
					func_475();
					func_474();
					func_473();
				}
				return 2;
			}
		}
	}
	if (gameplay::is_bit_set(Global_1312756, 1)) {
		if (func_467(202)) {
			gameplay::clear_bit(&Global_1312756, 1);
			audio::play_sound_frontend(-1, "CANCEL", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			if (!network::network_is_game_in_progress()) {
				func_492(1, 1);
			}
			if (func_210(player::player_id(), 0)) {
				func_491(1);
			}
			func_490();
			func_489();
			func_479();
			func_478();
			Global_1318029 = 0;
			Global_1312756 = 0;
			func_212(0);
			func_433(16, 0, -1);
			if (func_477() || func_476()) {
				func_475();
				func_474();
				func_473();
			}
			return 2;
		}
	}
	sVar1 = "HUD_CONNPROB";
	sVar2 = "HUD_CNGSETTIN";
	sVar3 = "HUD_RETURNSP";
	if (func_16() == 0 || func_554()) {
		sVar3 = "TRAN_RETNFM";
	}
	iVar4 = 16384;
	sVar3 = "HUD_CNGSET";
	iVar4 = 36;
	func_466();
	ui::_set_warning_message_2(sVar1, sVar2, iVar4, sVar3, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C189
var func_554() { return Global_2433122; }

// Position - 0x1C195
void func_555(int iParam0) { Global_2454684 = iParam0; }

// Position - 0x1C1A3
bool func_556(int iParam0) {
	if (gameplay::is_pc_version() == 0) {
		if (iParam0 == controls::get_local_player_aim_state() ||
			iParam0 < 2 && controls::get_local_player_aim_state() < 2 ||
			iParam0 >= 2 && controls::get_local_player_aim_state() >= 2) {
			return true;
		}
	}
	else if (iParam0 == controls::_0x59B9A7AF4C95133C() || iParam0 < 2 && controls::_0x59B9A7AF4C95133C() < 2 ||
			 iParam0 >= 2 && controls::_0x59B9A7AF4C95133C() >= 2) {
		return true;
	}
	return false;
}

// Position - 0x1C227
int func_557() { return Global_2452489; }

// Position - 0x1C233
void func_558(var uParam0) { Global_2454709 = uParam0; }

// Position - 0x1C241
int func_559() {
	int iVar0;
	int *iVar1;
	char *sVar2;
	char *sVar3;
	char *sVar4;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_212(0);
			network::network_can_access_multiplayer(&iVar0);
			if (iVar0 == 12) {
				network::_network_request_cloud_background_scripts();
			}
			Global_1318029 = 0;
			func_433(14, 0, -1);
			return 1;
		}
	}
	sVar2 = "HUD_CONNPROB";
	sVar3 = func_560(&iVar1);
	sVar4 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar2, sVar3, 2, sVar4, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C2CB
char *func_560(int *iParam0) {
	int iVar0;
	char *sVar1;

	*iParam0 = func_561();
	if (!network::network_can_access_multiplayer(&iVar0)) {
		switch (iVar0) {
		case 1: sVar1 = "PM_LAUNCH"; break;

		case 2: sVar1 = "PM_LAUNCH"; break;

		case 3: sVar1 = "PM_DODLCB"; break;

		case 4: break;

		case 5: sVar1 = "PM_DOPROB"; break;

		case 12: sVar1 = "HUD_NOBACKGRN"; break;

		case 11: sVar1 = "HUD_NOTUNE"; break;

		default: break;
		}
	}
	else if (Global_101700.f_8044.f_330[53 /*6*/] == 0) {
		sVar1 = "PM_DOPROB";
	}
	return sVar1;
}

// Position - 0x1C371
int func_561() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = Global_262145.f_15;
	iVar1 = network::_get_posix_time();
	iVar2 = iVar0 - iVar1;
	if (iVar2 > 0) {
		if (iVar2 / 86400 > 0) {
			iVar3 = iVar2 / 86400;
			iVar2 -= iVar3 * 86400;
		}
	}
	return iVar3;
}

// Position - 0x1C3B6
int func_562(int iParam0, int iParam1) {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (Global_1312755 == -2) {
		iParam1 = 0;
	}
	if (!player::is_system_ui_being_displayed() || iParam1 == 0) {
		if (func_355(&Global_1318034, 3000, 0) || iParam1 == 0) {
			if (iParam0) {
				gameplay::set_game_paused(1);
			}
			if (!network::network_is_signed_online() || iParam1 == 0) {
				if (func_468(201)) {
					gameplay::set_bit(&Global_1312756, 0);
				}
				if (gameplay::is_bit_set(Global_1312756, 0)) {
					if (func_467(201)) {
						gameplay::clear_bit(&Global_1312756, 0);
						Global_1312755 = -1;
						func_212(0);
						func_13(&Global_1318034);
						Global_1318029 = 0;
						func_433(13, 0, -1);
						return 1;
					}
				}
				sVar0 = "HUD_CONNPROB";
				sVar1 = "HUD_CONNT";
				if (gameplay::is_orbis_version()) {
					sVar1 = "HUD_CONNTPS4SI";
				}
				if (gameplay::is_orbis_version() && network::network_is_cable_connected() == 0) {
					sVar1 = "HUD_PLUGPU";
				}
				sVar2 = "HUD_RETURNSP";
				func_466();
				ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
			}
			else if (iParam1) {
				func_565();
				func_564();
				func_563(0);
				func_212(0);
				Global_1312755 = -1;
				Global_1318029 = 0;
				func_433(13, 0, -1);
				return 2;
			}
		}
		else if (iParam0) {
			gameplay::set_game_paused(0);
		}
	}
	return 0;
}

// Position - 0x1C4EE
void func_563(int iParam0) { Global_1312423.f_2 = iParam0; }

// Position - 0x1C4FE
void func_564() { gameplay::set_bit(&Global_1312423, 5); }

// Position - 0x1C50F
void func_565() { gameplay::set_bit(&Global_1312423, 0); }

// Position - 0x1C520
int func_566() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_479();
			func_13(&Global_1318034);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(12, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_BAILSAVEISS";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C5A9
int func_567() {
	char *sVar0;
	char *sVar1;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(11, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_BAILSAME";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, 0, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C626
int func_568() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(10, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "BAIL_SPPRO";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C6AA
int func_569() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			Global_1318029 = 0;
			func_433(9, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "BAIL_NOGTAO";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 2, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1C72E
void func_570() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			if (func_463() == 15) {
				func_517(62);
			}
			Global_1318029 = 0;
			func_433(6, 0, -1);
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_STATFAIL";
	sVar2 = "HUD_RETURNSP";
	if (func_16() == 0) {
		sVar2 = "TRAN_RETNFM";
	}
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
}

// Position - 0x1C809
void func_571() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			func_212(0);
			if (func_463() == 15) {
				func_572(0);
				func_531(3);
				func_517(4);
			}
			Global_1318029 = 0;
			func_433(5, 0, -1);
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "BAIL_CORONAFUL";
	sVar2 = "TRAN_RETNFM";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
}

// Position - 0x1C8E4
void func_572(int iParam0) { Global_25191 = iParam0; }

// Position - 0x1C8F1
void func_573() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			func_212(0);
			if (func_463() == 15) {
				func_517(62);
			}
			Global_1318029 = 0;
			func_433(17, 0, -1);
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_DIRTY";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
}

// Position - 0x1C9C4
void func_574() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_524();
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			func_212(0);
			if (func_463() == 15) {
				func_517(62);
			}
			Global_1318029 = 0;
			func_433(4, 0, -1);
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_NOCHAR";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
}

// Position - 0x1CA9A
void func_575() {
	int iVar0;
	char *sVar1;
	char *sVar2;
	char *sVar3;
	int iVar4;

	iVar0 = 0;
	if (func_16() == 0 || func_554()) {
		iVar0 = 1;
	}
	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (iVar0 == 0 && !func_419()) {
		if (func_468(202)) {
			gameplay::set_bit(&Global_1312756, 1);
		}
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_524();
			Global_1318029 = 0;
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			func_212(0);
			if (iVar0 == 0) {
				func_565();
				func_564();
				func_563(0);
				func_212(0);
				Global_1318029 = 0;
				func_433(3, 0, -1);
			}
			func_433(3, 0, -1);
		}
	}
	if (iVar0 == 0 && !func_419()) {
		if (gameplay::is_bit_set(Global_1312756, 1)) {
			if (func_467(202)) {
				gameplay::clear_bit(&Global_1312756, 1);
				func_524();
				if (network::network_is_game_in_progress()) {
					func_519(player::player_id(), 1, 0);
				}
				else {
					player::set_player_invincible(player::player_id(), 1);
					player::set_player_control(player::player_id(), 1, 0);
					if (!ped::is_ped_injured(player::player_ped_id())) {
						if (!entity::is_entity_attached(player::player_ped_id())) {
							entity::set_entity_collision(player::player_ped_id(), 1, 0);
							entity::freeze_entity_position(player::player_ped_id(), 0);
						}
					}
				}
				func_212(0);
				if (func_463() == 15) {
					func_517(62);
				}
				Global_1318029 = 0;
				func_433(3, 0, -1);
			}
		}
	}
	sVar1 = "HUD_CONNPROB";
	sVar2 = "TRAN_ONTUTOR";
	sVar3 = "HUD_RETURNSP";
	if (iVar0) {
		sVar3 = "TRAN_RETNFM";
	}
	iVar4 = 16384;
	if (iVar0 == 0 && !func_419()) {
		sVar3 = "TRAN_ENTMP";
		iVar4 = 268451840;
	}
	func_466();
	ui::_set_warning_message_2(sVar1, sVar2, iVar4, sVar3, 0, -1, 0, 0, 1);
}

// Position - 0x1CC93
int func_576() {
	char *sVar0;
	char *sVar1;
	char *sVar2;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			Global_1318029 = 0;
			func_524();
			if (network::network_is_game_in_progress()) {
				func_519(player::player_id(), 1, 0);
			}
			else {
				player::set_player_invincible(player::player_id(), 1);
				player::set_player_control(player::player_id(), 1, 0);
				if (!ped::is_ped_injured(player::player_ped_id())) {
					if (!entity::is_entity_attached(player::player_ped_id())) {
						entity::set_entity_collision(player::player_ped_id(), 1, 0);
						entity::freeze_entity_position(player::player_ped_id(), 0);
					}
				}
			}
			if (func_463() == 15) {
				func_517(62);
			}
			func_212(0);
			func_433(2, 0, -1);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "HUD_PERM";
	sVar2 = "HUD_RETURNSP";
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, 16384, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1CD6E
int func_577() {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	int iVar3;

	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 1);
	}
	if (gameplay::is_bit_set(Global_1312756, 0)) {
		if (func_467(201)) {
			gameplay::clear_bit(&Global_1312756, 0);
			func_433(42, 0, -1);
			func_478();
			func_212(0);
			return 1;
		}
	}
	sVar0 = "HUD_CONNPROB";
	sVar1 = "TRAN_JOINFAIL";
	sVar2 = "TRAN_RETNFM";
	if (Global_1312504.f_1 > -1) {
		sVar1 = func_578(Global_1312504.f_1, 9);
	}
	if (Global_1312755 > -1) {
		sVar1 = func_578(Global_1312755, 9);
	}
	if (func_21(sVar1)) {
		sVar1 = "TRAN_JOINFAIL";
	}
	iVar3 = 16384;
	func_466();
	ui::_set_warning_message_2(sVar0, sVar1, iVar3, sVar2, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1CE35
char *func_578(int iParam0, int iParam1) {
	char *sVar0;

	sVar0 = "";
	switch (iParam0) {
	case 0: break;

	case 1: break;

	case 2: break;

	case 3: break;

	case 4: break;

	case 5: sVar0 = "BAIL_BLACKLIST"; break;

	case 6: break;

	case 7: sVar0 = "BAIL_COMPATASSE"; break;

	case 8: sVar0 = "BAIL_SESSIONFUL"; break;

	case 9:
		if (func_210(player::player_id(), 0) || func_582() || func_581()) {
			sVar0 = "BAIL_TEAMFUL5";
		}
		else {
			switch (iParam1) {
			case 9: sVar0 = "BAIL_TEAMFUL4"; break;

			case 8: sVar0 = "BAIL_TEAMFUL5"; break;
			}
		}
		break;

	case 10: sVar0 = "BAIL_WRNGVER"; break;

	case 11: break;

	case 12: sVar0 = "BAIL_BLOCKING"; break;

	case 13: sVar0 = "BAIL_AIMPREF"; break;

	case 14: sVar0 = "BAIL_CHEAT"; break;

	case 15: break;

	case 16: sVar0 = "BAIL_DATA_HASH"; break;

	case 17:
		if (func_579()) {
			sVar0 = "BAIL_CREWLIM";
		}
		else {
			sVar0 = "BAIL_CLOSEDCREW";
		}
		break;

	case 21: sVar0 = "BAIL_SESSGONE"; break;

	case 22: sVar0 = "BAIL_PRIVONLY"; break;

	case 25: sVar0 = "BAIL_FRIENDSONLY"; break;

	case 23: sVar0 = "BAIL_DIFFBUILD"; break;

	case 24: sVar0 = "BAIL_DIFFCONT"; break;

	case 18:
		if (network::network_player_is_cheater()) {
			sVar0 = "BAIL_NORMCHT";
		}
		else {
			sVar0 = "BAIL_NORMBAD";
		}
		break;

	case 19: sVar0 = "BAIL_BADSPONLY"; break;

	case 20: sVar0 = "BAIL_CHEATONLY"; break;

	case 26: sVar0 = "HUD_REPUTATION"; break;

	case 27: sVar0 = "HUD_ESTAB"; break;

	case 28: sVar0 = "TRAN_JOINPRF"; break;
	}
	return sVar0;
}

// Position - 0x1D036
bool func_579() {
	struct<13> Var0;

	Var0 = {func_580()};
	if (player::is_player_online()) {
		if (network::_network_player_is_in_clan() && network::network_clan_player_is_active(&Var0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1D065
struct<13> func_580() {
	struct<13> Var0;

	network::network_get_local_handle(&Var0, 13);
	return Var0;
}

//Position - 0x1D07A
var func_581()
{
	return Global_2453770;
}

// Position - 0x1D086
var func_582() { return Global_1315229; }

// Position - 0x1D092
int func_583() {
	bool bVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	char *sVar5;
	char *sVar6;
	char *sVar7;
	char *sVar8;
	int iVar9;

	bVar0 = false;
	iVar1 = 0;
	if (func_210(player::player_id(), 0) || func_582() || func_581()) {
		iVar1 = 1;
	}
	if (Global_1312755 > -1) {
		if (iVar1 == 0) {
			if (Global_1312755 == 9) {
				bVar0 = true;
			}
		}
	}
	if (Global_262145.f_7405 == 0) {
		if (network::_0x2BF66D2E7414F686()) {
			gameplay::set_bit(&Global_2450892, 2);
		}
	}
	if (Global_262145.f_7107 == 0) {
		if (Global_262145.f_8241 == 1) {
			gameplay::set_bit(&Global_2450892, 1);
		}
	}
	if (gameplay::is_bit_set(Global_2450892, 1) == 0 && gameplay::is_bit_set(Global_2450892, 2) == 0) {
		bVar0 = false;
	}
	iVar2 = 0;
	if (func_468(201)) {
		gameplay::set_bit(&Global_1312756, 0);
	}
	if (func_468(202)) {
		gameplay::set_bit(&Global_1312756, 1);
	}
	if (func_468(203)) {
		gameplay::set_bit(&Global_1312756, 2);
	}
	iVar3 = 0;
	if (bVar0 == 0) {
		if (gameplay::is_bit_set(Global_1312756, 0)) {
			if (func_467(201)) {
				func_652(0);
				audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				func_651(0);
				func_650(0);
				func_479();
				gameplay::clear_bit(&Global_1312756, 0);
				if (!network::network_is_game_in_progress() || Global_1312755 == 9) {
					if (Global_1312755 == 9 && (func_476() || func_477()) && (func_5() || func_649())) {
						func_648(1);
						func_572(0);
						func_563(0);
						func_647(1);
					}
					func_492(1, 1);
				}
				if (func_131() != 0) {
					func_478();
				}
				Global_1318029 = 0;
				Global_1312756 = 0;
				if (func_646()) {
					network::network_bail(41, 0, 0);
				}
				func_645(0);
				if (func_644() || func_643()) {
					ui::set_frontend_active(0);
					iVar2 = 1;
					if (func_644()) {
						func_642(1);
					}
					func_641(1);
					func_640();
					func_639();
					if (func_419() == 0) {
						func_647(1);
						func_172(1);
					}
				}
				if (func_16() == 2) {
					ui::set_frontend_active(0);
					iVar2 = 1;
					func_641(1);
					func_638(2);
					func_563(0);
					if (func_419() == 0) {
						func_647(1);
						func_172(1);
					}
				}
				if (func_16() == -1 || func_16() == 999) {
					func_641(1);
					if (func_419()) {
						func_637(0);
						func_572(0);
						func_517(4);
						func_531(3);
					}
					else {
						ui::set_frontend_active(0);
						iVar2 = 1;
						func_638(-1);
						func_563(0);
						func_647(1);
					}
				}
				iVar4 = 0;
				if (func_16() == 999 && func_463() == 26) {
					ui::set_frontend_active(0);
					iVar2 = 1;
					func_641(1);
					iVar4 = 1;
					func_572(-1);
					func_517(57);
					func_531(32);
				}
				if (func_16() == 0 && func_636()) {
					ui::set_frontend_active(0);
					iVar4 = 1;
					func_641(1);
					func_635(0);
					func_572(-1);
					func_517(57);
					func_531(32);
				}
				if (streaming::is_new_load_scene_active()) {
					streaming::new_load_scene_stop();
				}
				if (!func_230() && func_634()) {
					func_633();
				}
				else if (network::network_is_game_in_progress()) {
					if (!func_632()) {
						if (!func_230() && (func_477() || func_476())) {
							func_633();
						}
						else {
							func_519(player::player_id(), 1, 0);
						}
					}
				}
				else {
					player::set_player_invincible(player::player_id(), 1);
					player::set_player_control(player::player_id(), 1, 0);
					if (!ped::is_ped_injured(player::player_ped_id())) {
						if (!entity::is_entity_attached(player::player_ped_id())) {
							entity::set_entity_collision(player::player_ped_id(), 1, 0);
							entity::freeze_entity_position(player::player_ped_id(), 0);
						}
					}
				}
				if (func_16() == 999 && func_463() == 26) {
					func_572(-1);
				}
				else if (iVar4 == 0) {
					func_572(0);
				}
				if (func_477() || func_476() || iVar3) {
					func_475();
					func_474();
					if (!func_631()) {
						func_473();
						if (!func_230() && !func_632()) {
							func_633();
						}
					}
				}
				if (iVar2 == 1) {
					func_146(1);
				}
				else {
					func_99(1);
				}
				func_629(0);
				Global_2359301.f_68.f_2 = 2;
				func_212(0);
				func_433(1, 0, -1);
				return 1;
			}
		}
	}
	else if (func_619()) {
		if (gameplay::is_bit_set(Global_2450893, 1) == 0) {
			if (gameplay::is_bit_set(Global_2450892, 1) && !gameplay::is_bit_set(Global_2450892, 2)) {
				if (gameplay::is_bit_set(Global_1312756, 0)) {
					if (func_467(201)) {
						gameplay::clear_bit(&Global_1312756, 0);
						audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
						gameplay::set_bit(&Global_2450893, 1);
					}
				}
			}
			else if (gameplay::is_bit_set(Global_2450892, 1) && gameplay::is_bit_set(Global_2450892, 2)) {
				if (gameplay::is_bit_set(Global_1312756, 2)) {
					if (func_467(203)) {
						gameplay::clear_bit(&Global_1312756, 2);
						audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
						gameplay::set_bit(&Global_2450893, 1);
					}
				}
			}
		}
		if (gameplay::is_bit_set(Global_2450893, 2) == 0) {
			if (gameplay::is_bit_set(Global_2450892, 2) && !gameplay::is_bit_set(Global_2450892, 1)) {
				if (gameplay::is_bit_set(Global_1312756, 0)) {
					if (func_467(201)) {
						gameplay::clear_bit(&Global_1312756, 0);
						audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
						gameplay::set_bit(&Global_2450893, 2);
					}
				}
			}
			else if (gameplay::is_bit_set(Global_2450892, 2) && gameplay::is_bit_set(Global_2450892, 1)) {
				if (gameplay::is_bit_set(Global_1312756, 0)) {
					if (func_467(201)) {
						gameplay::clear_bit(&Global_1312756, 0);
						audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
						gameplay::set_bit(&Global_2450893, 2);
					}
				}
			}
		}
		if (gameplay::is_bit_set(Global_2450893, 3) == 0) {
			if (gameplay::is_bit_set(Global_1312756, 1)) {
				if (func_467(202)) {
					gameplay::clear_bit(&Global_1312756, 1);
					audio::play_sound_frontend(-1, "CANCEL", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
					gameplay::set_bit(&Global_2450893, 3);
				}
			}
		}
	}
	else {
		Global_1312756 = 0;
	}
	if (gameplay::is_bit_set(Global_2450893, 2)) {
		if (func_443(0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			if (func_619()) {
				func_652(0);
				network::_0xFA2888E3833C8E96();
				func_637(0);
				func_650(0);
				func_618(1);
				if (!func_419()) {
					func_638(-1);
					func_563(0);
					if (func_419() == 0) {
						func_647(1);
					}
				}
				else {
					func_517(4);
					func_531(3);
					func_638(-1);
					func_563(0);
				}
				if (Global_2453678 != 9) {
					func_652(Global_2453678);
				}
				func_492(1, 1);
				func_651(0);
				func_490();
				func_489();
				func_479();
				func_478();
				Global_1318029 = 0;
				Global_1312756 = 0;
				Global_2450892 = 0;
				Global_2450893 = 0;
				func_212(0);
				func_433(1, 0, -1);
				gameplay::clear_bit(&Global_2450893, 2);
				return 1;
			}
		}
	}
	if (gameplay::is_bit_set(Global_2450893, 1)) {
		if (func_443(0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0)) {
			if (func_619()) {
				gameplay::clear_bit(&Global_1312756, 0);
				func_617(0);
				func_616(0);
				func_637(0);
				func_650(0);
				func_486(1);
				func_487(1, 1);
				func_615(1, -1);
				func_591(0, -1, 0);
				network::_0x600F8CB31C7AAB6E(0);
				Global_2450892 = 0;
				Global_2450893 = 0;
				func_639();
				func_590();
				func_645(0);
				if (func_589() || func_643()) {
					network::_0xFFE1E5B792D92B34();
				}
				else {
					network::_0x59DF79317F85A7E0();
				}
				func_588(1);
				func_616(0);
				func_485(0);
				if (func_644()) {
					func_642(1);
				}
				func_587(1);
				if (func_589()) {
					func_586(1);
					network::_0x49EC8030F5015F8B(4);
				}
				func_651(0);
				func_433(1, 0, -1);
				Global_1318029 = 0;
				Global_1312756 = 0;
				ui::set_frontend_active(0);
				func_146(0);
				func_641(1);
				func_629(0);
				Global_2359301.f_68.f_2 = 2;
				if (!func_419()) {
					func_638(-1);
					func_563(0);
					if (func_419() == 0) {
						func_647(1);
					}
				}
				else {
					func_517(20);
					func_531(32);
				}
				gameplay::clear_bit(&Global_2450893, 1);
				return 1;
			}
		}
	}
	if (gameplay::is_bit_set(Global_2450893, 3)) {
		if (func_443(0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0) && gameplay::is_auto_save_in_progress() == 0 &&
			func_457() == 0 && func_619()) {
			Global_2450892 = 0;
			Global_2450893 = 0;
			func_652(0);
			func_641(1);
			if (func_419()) {
				func_517(57);
				func_531(0);
				func_563(0);
				func_572(0);
				Global_1315187 = 0;
				if (Global_2453678 != 9) {
					func_652(Global_2453678);
				}
			}
			else {
				Global_1315187 = 0;
				func_652(Global_2453678);
				func_585();
				func_565();
				func_563(0);
				func_572(0);
				func_647(1);
			}
			if (!network::network_is_game_in_progress()) {
				func_492(1, 1);
			}
			func_490();
			func_489();
			func_479();
			func_478();
			Global_1318029 = 0;
			Global_1312756 = 0;
			func_212(0);
			func_433(1, 0, -1);
			func_584(0);
			if (func_477() || func_476()) {
				func_475();
				func_474();
				if (!func_631()) {
					func_473();
					if (network::network_is_game_in_progress() && !network::network_is_activity_session()) {
						func_633();
					}
				}
			}
			func_651(0);
			Global_89302.f_44 = 1;
			if (Global_2621440 != 53 && Global_2621440 != 46 && Global_2621440 != 0) {
				if (cam::is_screen_faded_out() || cam::is_screen_fading_out()) {
					cam::do_screen_fade_in(800);
				}
			}
			gameplay::clear_bit(&Global_2450893, 3);
			return 2;
		}
	}
	if (Global_1312755 == 13 || Global_1312755 == 13) {
		if (gameplay::is_bit_set(Global_1312756, 1)) {
			if (func_467(202)) {
				gameplay::clear_bit(&Global_1312756, 1);
				audio::play_sound_frontend(-1, "CANCEL", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
				if (bVar0 && func_419()) {
					func_517(4);
					func_531(3);
					func_638(-1);
					func_563(0);
				}
				if (!network::network_is_game_in_progress()) {
					func_492(1, 1);
				}
				func_490();
				func_489();
				func_479();
				func_478();
				Global_1318029 = 0;
				Global_1312756 = 0;
				func_212(0);
				func_433(1, 0, -1);
				if (func_477() || func_476()) {
					func_475();
					func_474();
					func_473();
					if (network::network_is_game_in_progress() && !network::network_is_activity_session()) {
						func_633();
					}
				}
				return 2;
			}
		}
	}
	sVar5 = "HUD_CONNPROB";
	sVar6 = "TRAN_JOINFAIL";
	sVar7 = "TRAN_RETNFM";
	if (func_16() == 0 || func_554() || func_16() == 2 || func_16() == 999 || func_16() == -1) {
		sVar7 = "TRAN_RETNFM";
	}
	if (func_16() == 999 && func_463() == 26) {
		sVar7 = "HUD_RETURNSP";
	}
	if (Global_1312755 > -1) {
		sVar8 = func_578(Global_1312755, 9);
		if (func_21(sVar8) == 0) {
			sVar6 = sVar8;
		}
	}
	iVar9 = 16384;
	if (Global_1312755 == 13 || Global_1312755 == 13) {
		sVar7 = "HUD_CNGSET";
		iVar9 = 36;
	}
	if (bVar0) {
		if (gameplay::is_bit_set(Global_2450892, 1) && gameplay::is_bit_set(Global_2450892, 2)) {
			sVar7 = "HUD_CNGQUEUSP";
		}
		else if (gameplay::is_bit_set(Global_2450892, 2)) {
			sVar7 = "HUD_CNGQUEU";
		}
		else if (gameplay::is_bit_set(Global_2450892, 1)) {
			sVar7 = "HUD_CNGSPEC";
		}
		if (func_443(0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0) && func_619()) {
			if (gameplay::is_bit_set(Global_2450892, 1) && gameplay::is_bit_set(Global_2450892, 2)) {
				iVar9 = 17825808;
			}
			else if (gameplay::is_bit_set(Global_2450892, 2)) {
				iVar9 = 36;
			}
			else if (gameplay::is_bit_set(Global_2450892, 1)) {
				iVar9 = 36;
			}
		}
		else {
			iVar9 = 134217728;
		}
	}
	func_466();
	ui::_set_warning_message_2(sVar5, sVar6, iVar9, sVar7, 0, -1, 0, 0, 1);
	return 0;
}

// Position - 0x1DC3A
void func_584(int iParam0) { Global_2453680 = iParam0; }

// Position - 0x1DC48
void func_585() { Global_2443134.f_607 = 0; }

// Position - 0x1DC58
void func_586(int iParam0) { Global_2454048 = iParam0; }

// Position - 0x1DC66
void func_587(int iParam0) { Global_2454750 = iParam0; }

// Position - 0x1DC74
void func_588(int iParam0) { Global_2454747 = iParam0; }

// Position - 0x1DC82
bool func_589() { return Global_1312738; }

// Position - 0x1DC8E
void func_590() { gameplay::clear_bit(&Global_2443134, 15); }

// Position - 0x1DCA0
void func_591(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;

	if (func_613() || func_612()) {
	}
	else {
		network::_0xFD75DABC0957BF33(0);
	}
	Global_1315234 = 1;
	network::_0x1153FA02A659051C();
	iVar0 = func_611(func_211(iParam1, 0), iParam0);
	network::_0x49EC8030F5015F8B(iVar0);
	if (iVar0 == 4) {
		func_615(1, iParam1);
		player::set_player_team(player::player_id(), 8);
	}
	switch (iParam0) {
	case 0:
		if (func_349(player::player_id()) && network::network_is_signed_online() && func_294()) {
			func_602(iParam1);
		}
		if (!func_444() && !iParam2 && !func_107()) {
			if (func_601() == 0) {
				func_600(1);
			}
			else if (func_601() == 1) {
				func_600(1);
			}
			else if (func_601() == 2) {
				func_600(1);
			}
		}
		network::_0xCAE55F48D3D7875C(4);
		network::_0xCAE55F48D3D7875C(0);
		iVar3 = func_596();
		if (iVar3 > 0) {
			network::_0x3F52E880AAF6C8CA(iVar3);
		}
		network::_0xF1EEA2DDA9FFA69D(func_594());
		iVar6 = 0;
		iVar7 = iParam1;
		if (iVar7 == -1) {
			iVar7 = func_664();
		}
		unk_0x6BC0ACD0673ACEBE(iVar7, &iVar4, &iVar5);
		if (iVar4 != 0 && iVar5 != 0) {
			iVar6 = 1;
		}
		unk_0x5ECD378EE64450AB(iVar6);
		iVar2 = func_593(9, 0);
		iVar1 = func_593(8, 0);
		if (32 != Global_262145.f_4747) {
			iVar2 = Global_262145.f_4747 - iVar1;
			if (iVar2 < 0) {
				iVar2 = 0;
			}
		}
		network::_network_session_set_max_players(0, iVar2);
		network::_network_session_set_max_players(4, iVar1);
		switch (func_592()) {
		case 3: network::_0xF49ABC20D8552257(2); break;

		case 4: network::_0xF49ABC20D8552257(3); break;

		case 5: network::_0xF49ABC20D8552257(4); break;

		case 2: network::_0xF49ABC20D8552257(1); break;
		}
		break;
	}
}

// Position - 0x1DE4C
int func_592() { return Global_1315192; }

// Position - 0x1DE58
int func_593(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_16();
	if (iParam1 != 999) {
		iVar0 = iParam1;
	}
	switch (iVar0) {
	case 0:
		switch (32) {
		case 16:
			switch (iParam0) {
			case 8: return 0;

			case 9:
			default: return 16;
			}
			break;

		case 18:
			switch (iParam0) {
			case 8: return 2;

			case 9:
			default: return 16;
			}
			break;

		case 24:
			switch (iParam0) {
			case 8: return 2;

			case 9:
			default: return 22;
			}
			break;

		case 26:
			switch (iParam0) {
			case 8: return 2;

			case 9:
			default: return 24;
			}
			break;

		case 32:
			switch (iParam0) {
			case 8: return 2;

			case 9:
			default: return 30;
			}
			break;
		}
		break;
	}
	return 4;
}

// Position - 0x1DF61
var func_594() {
	float fVar0;
	float fVar1;
	float fVar2;
	var uVar3;

	fVar0 = func_595(133, -1);
	fVar1 = 0.07f;
	fVar2 = fVar0 * fVar1;
	uVar3 = system::round(fVar2);
	return uVar3;
}

// Position - 0x1DF8A
float func_595(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2521893[iParam0 /*3*/][func_40(iParam1)];
	if (stats::stat_get_float(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0f;
}

// Position - 0x1DFB6
int func_596() {
	if (Global_2097152[func_599() /*10758*/].f_7546.f_1045 > 0 &&
		func_598(Global_2097152[func_599() /*10758*/].f_7546.f_1045)) {
		return Global_2097152[func_599() /*10758*/].f_7546.f_1045;
	}
	else {
		return func_597(0, -1);
	}
	return 0;
}

// Position - 0x1E00F
int func_597(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam1;
	if (iParam1 == -1) {
		iVar0 = func_664();
	}
	if (iParam0 == 7 && !Global_262145.f_15098) {
		return 0;
	}
	if (iParam0 == 0) {
		return Global_1363279[iVar0];
	}
	else if (iParam0 == 99) {
		return Global_2524348[iVar0];
	}
	else if (iParam0 >= 1) {
		if (iParam0 >= 12) {
			return 0;
		}
		return Global_2524277[iParam0 - 1 /*3*/][iVar0];
	}
	return 0;
}

// Position - 0x1E08B
int func_598(int iParam0) {
	int iVar0;

	if (iParam0 > 0) {
		iVar0 = 0;
		while (iVar0 < 12) {
			if (func_597(iVar0, -1) == iParam0) {
				return 1;
			}
			iVar0++;
		}
		if (iParam0 == func_597(99, -1)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x1E0CD
int func_599() {
	int iVar0;

	iVar0 = 0;
	return iVar0;
}

// Position - 0x1E0DA
void func_600(int iParam0) { Global_2454710 = iParam0; }

// Position - 0x1E0E8
int func_601() { return Global_2454709; }

// Position - 0x1E0F4
void func_602(int iParam0) {
	int iVar0;

	iVar0 = func_347(func_610(iParam0), 1);
	func_87(635, iVar0, iParam0, 1, 0);
	func_87(636, func_609(iVar0 + 1, 0, 1), iParam0, 1, 0);
	func_87(637, func_609(iVar0, 0, 1), iParam0, 1, 0);
	func_339(joaat("mpply_current_crew_rank"), func_603(func_604(player::player_id()), 1));
}

// Position - 0x1E154
int func_603(int iParam0, int iParam1) {
	if (iParam1) {
	}
	return func_347(iParam0, 0);
}

// Position - 0x1E168
int func_604(int iParam0) {
	struct<13> Var0;
	int iVar13;

	Var0 = {func_608(iParam0)};
	iVar13 = func_606(func_607(&Var0));
	return func_605(iVar13);
}

// Position - 0x1E18D
var func_605(int iParam0) {
	switch (iParam0) {
	case 0: return Global_1363158;

	case 1: return Global_1363159;

	case 2: return Global_1363160;

	case 3: return Global_1363161;

	case 4: return Global_1363162;

	default:
	}
	return Global_1363162;
}

// Position - 0x1E1E1
int func_606(int iParam0) {
	if (iParam0 == Global_1363153) {
		return 0;
	}
	else if (iParam0 == Global_1363154) {
		return 1;
	}
	else if (iParam0 == Global_1363155) {
		return 2;
	}
	else if (iParam0 == Global_1363156) {
		return 3;
	}
	else if (iParam0 == Global_1363157) {
		return 4;
	}
	else {
		return -1;
	}
	return -1;
}

// Position - 0x1E23E
int func_607(var *uParam0) {
	if (network::_network_player_is_in_clan()) {
		if (network::network_clan_player_is_active(uParam0)) {
			return Global_2452452;
		}
	}
	return Global_2452452;
}

// Position - 0x1E261
struct<13> func_608(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

//Position - 0x1E278
int func_609(int iParam0, int iParam1, int iParam2)
{
	if (iParam2 == 0) {
	}
	if (iParam1) {
	}
	if (iParam0 >= 8000) {
		iParam0 = 8000;
	}
	return Global_280048[iParam0];
}

// Position - 0x1E2A0
int func_610(var uParam0) { return Global_1363273[func_40(uParam0)]; }

// Position - 0x1E2B4
int func_611(int iParam0, int iParam1) {
	int iVar0;

	switch (iParam1) {
	case 0:
		switch (iParam0) {
		case 8: iVar0 = 4; break;

		default:
			if (func_582() || func_581()) {
				iVar0 = 4;
			}
			else {
				iVar0 = 0;
			}
			break;
		}
		break;
	}
	return iVar0;
}

// Position - 0x1E2FE
bool func_612() { return Global_2453019; }

// Position - 0x1E30A
int func_613() {
	if (!func_614()) {
		return 1;
	}
	return 0;
}

// Position - 0x1E31F
int func_614() {
	if (func_612()) {
		return 0;
	}
	if (network::network_is_cloud_available() == 0) {
		return 0;
	}
	return 1;
}

// Position - 0x1E33F
void func_615(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam1;
	if (iVar0 == -1) {
		iVar0 = func_664();
	}
	Global_1315213[iVar0] = iParam0;
}

// Position - 0x1E361
void func_616(int iParam0) { Global_1312737 = iParam0; }

// Position - 0x1E36F
void func_617(int iParam0) { Global_1315203 = iParam0; }

// Position - 0x1E37D
void func_618(int iParam0) { Global_2454818 = iParam0; }

// Position - 0x1E38B
bool func_619() {
	if (!network::network_is_session_busy()) {
		if (func_463() == 5 || func_463() == 59 || func_463() == 2 || func_419() == 0) {
			if (func_620()) {
				if (func_5() && dlc2::get_is_loading_screen_active() ||
					func_454() && dlc2::get_is_loading_screen_active() == 0) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x1E406
bool func_620() {
	bool bVar0;

	if (!func_351()) {
		if (func_628()) {
			func_627();
		}
		else {
			return false;
		}
	}
	if (!func_626()) {
		if (network::network_is_game_in_progress()) {
			bVar0 = true;
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (entity::is_entity_attached(player::player_ped_id())) {
					bVar0 = false;
				}
			}
			if (bVar0) {
				func_519(player::player_id(), 0, 573444);
			}
			else {
				func_519(player::player_id(), 0, 49152);
			}
			func_625();
		}
		else {
			func_563(0);
			player::set_player_invincible(player::player_id(), 1);
			player::set_player_control(player::player_id(), 0, 0);
			if (!ped::is_ped_injured(player::player_ped_id())) {
				if (!entity::is_entity_attached(player::player_ped_id())) {
					entity::set_entity_collision(player::player_ped_id(), 1, 0);
					entity::freeze_entity_position(player::player_ped_id(), 1);
					entity::_set_entity_register(player::player_ped_id(), 1);
				}
			}
		}
		func_624();
	}
	if (network::network_is_activity_session()) {
		if (network::network_is_session_active()) {
			if (network::network_is_session_busy()) {
				return false;
			}
			else {
				if (!func_623()) {
					func_622();
				}
				if (Global_2443905.f_1.f_2801 == 0) {
					if (network::network_can_session_end()) {
						network::network_session_end(0, 0);
						Global_2443905.f_1.f_2801 = 1;
					}
				}
				return false;
			}
			return false;
		}
	}
	else if (!func_621(0)) {
		return false;
	}
	return true;
}

// Position - 0x1E533
int func_621(int iParam0) {
	if (network::network_is_in_transition() || network::network_is_transition_started() ||
		network::network_is_transition_busy() || network::network_is_transition_matchmaking() ||
		network::_0xC571D0E77D8BBC29()) {
		if (iParam0) {
			network::network_bail_transition(43, 0, 0);
			return 1;
		}
		if (network::network_is_transition_busy() || network::network_is_transition_matchmaking()) {
			return 0;
		}
		else if (network::network_is_transition_started()) {
			if (Global_2443905.f_1.f_2801 == 0) {
				network::network_leave_transition();
				Global_2443905.f_1.f_2801 = 1;
			}
			return 0;
		}
		else {
			return 0;
		}
		return 0;
	}
	return 1;
}

// Position - 0x1E5C6
void func_622() { Global_2443134.f_581 = 1; }

// Position - 0x1E5D6
bool func_623() { return Global_2443134.f_581; }

// Position - 0x1E5E5
void func_624() { gameplay::set_bit(&Global_2443134, 31); }

// Position - 0x1E5F7
void func_625() { Global_2443134.f_606 = 1; }

// Position - 0x1E607
bool func_626() { return gameplay::is_bit_set(Global_2443134, 31); }

// Position - 0x1E619
void func_627() { Global_2450895.f_3 = 1; }

// Position - 0x1E628
bool func_628() {
	script::request_script("UGC_Global_Registration");
	if (script::has_script_loaded("UGC_Global_Registration")) {
		system::start_new_script("UGC_Global_Registration", 128);
		script::set_script_as_no_longer_needed("UGC_Global_Registration");
		return true;
	}
	return false;
}

// Position - 0x1E65B
void func_629(int iParam0) {
	if (Global_2359301.f_68.f_1 != iParam0) {
		if (iParam0 != 2 || func_630()) {
			Global_2359301.f_68.f_1 = iParam0;
			Global_2359301.f_68.f_3 = 0;
			gameplay::clear_bit(&Global_2359301.f_68.f_5, 4);
		}
	}
}

// Position - 0x1E6A1
var func_630() { return func_409(); }

// Position - 0x1E6AD
bool func_631() { return Global_1312367; }

// Position - 0x1E6B9
bool func_632() { return Global_2443134.f_597; }

// Position - 0x1E6C8
void func_633() { Global_2443134.f_611 = 1; }

// Position - 0x1E6D8
var func_634() { return Global_2443134.f_607; }

// Position - 0x1E6E7
void func_635(int iParam0) { Global_1312748 = iParam0; }

// Position - 0x1E6F5
var func_636() { return Global_1312748; }

// Position - 0x1E701
void func_637(int iParam0) { Global_1315195 = iParam0; }

// Position - 0x1E70F
void func_638(int iParam0) { Global_1312423.f_1 = iParam0; }

// Position - 0x1E71F
void func_639() { Global_2443134.f_580 = 0; }

// Position - 0x1E72F
void func_640() { Global_2443134.f_578 = 0; }

// Position - 0x1E73F
void func_641(int iParam0) { Global_1315212 = iParam0; }

// Position - 0x1E74D
void func_642(int iParam0) { Global_1312743 = iParam0; }

// Position - 0x1E75B
var func_643() { return Global_2443134.f_580; }

// Position - 0x1E76A
bool func_644() { return Global_2443134.f_578; }

// Position - 0x1E779
void func_645(int iParam0) { Global_1315235 = iParam0; }

// Position - 0x1E787
bool func_646() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_139, 0); }

// Position - 0x1E7A1
void func_647(int iParam0) { Global_1312367 = iParam0; }

// Position - 0x1E7AF
void func_648(int iParam0) { Global_2452525 = iParam0; }

// Position - 0x1E7BD
int func_649() {
	if (func_6() == 1 || func_6() == 4) {
		return 1;
	}
	return 0;
}

// Position - 0x1E7DF
void func_650(int iParam0) { Global_1312371 = iParam0; }

// Position - 0x1E7ED
void func_651(int iParam0) { Global_1315231 = iParam0; }

// Position - 0x1E7FB
void func_652(int iParam0) { Global_1315192 = iParam0; }

// Position - 0x1E809
bool func_653(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0 / 32;
	iVar1 = iParam0 % 32;
	return gameplay::is_bit_set(Global_1312752[iVar0], iVar1);
}

// Position - 0x1E82D
void func_654() {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	bool bVar6;

	fVar0 = -1f;
	fVar1 = -Global_1354542.f_5760 - 0.0075f;
	fVar2 = -1f;
	fVar3 = -Global_1354542.f_5760 - 0.04f - 0.0075f;
	fVar4 = -1f;
	fVar5 = -Global_1354542.f_5760 - 0.04f - 0.04f - 0.0075f;
	fVar1 += -0.036f * IntToFloat(Global_1354542.f_995);
	fVar3 += -0.036f * IntToFloat(Global_1354542.f_995);
	fVar5 += -0.036f * IntToFloat(Global_1354542.f_995);
	if (ui::_is_loading_prompt_being_displayed()) {
		fVar1 += -0.04f;
		fVar3 += -0.04f;
		fVar5 += -0.04f;
	}
	if (Global_1354542.f_5760 > 0f) {
		bVar6 = true;
	}
	if (Global_1318069 != Global_1354542.f_5760 || Global_2453694 != ui::_is_loading_prompt_being_displayed()) {
		if (Global_1354542.f_5760 > 0f) {
			Global_1318070 = 0;
		}
		else {
			Global_1318070 = 1;
		}
	}
	if (bVar6) {
		if (Global_1318070 == 0) {
			ui::set_hud_component_position(9, fVar0, fVar1);
			ui::set_hud_component_position(6, fVar4, fVar5);
			ui::set_hud_component_position(7, fVar2, fVar3);
			Global_1318070 = 1;
		}
	}
	else if (Global_1318070) {
		ui::reset_hud_component_values(9);
		ui::reset_hud_component_values(6);
		ui::reset_hud_component_values(7);
		func_13(&Global_1315252);
		Global_1318070 = 0;
	}
	Global_1318069 = Global_1354542.f_5760;
	Global_2453694 = ui::_is_loading_prompt_being_displayed();
	Global_1354542.f_5760 = 0f;
}

// Position - 0x1E994
void func_655() {
	float fVar0;
	float fVar1;
	bool bVar2;

	fVar0 = -1f;
	fVar1 = -0.0375f * IntToFloat(Global_1318071);
	if (Global_1318071 > 0) {
		bVar2 = true;
	}
	if (Global_2482407) {
		bVar2 = true;
	}
	if (Global_2454041 != bVar2 || Global_2454042 != Global_1318071) {
		if (bVar2) {
			Global_2454040 = 0;
		}
		else {
			Global_2454040 = 1;
		}
	}
	if (bVar2) {
		if (Global_2454040 == 0) {
			ui::set_hud_component_position(15, fVar0, fVar1);
			Global_2454040 = 1;
		}
	}
	else if (Global_2454040) {
		ui::reset_hud_component_values(15);
		Global_2454040 = 0;
	}
	Global_2454041 = bVar2;
	Global_2454042 = Global_1318071;
	Global_1318071 = 0;
}

// Position - 0x1EA30
void func_656() {
	float fVar0;
	float fVar1;

	fVar0 = 0f;
	fVar1 = -0.0375f;
	fVar1 *= IntToFloat(Global_1318071);
	if (Global_1318061 != Global_1318071 || Global_1318062 != ui::_is_loading_prompt_being_displayed()) {
		func_13(&Global_1315248);
		Global_1318063 = 1;
	}
	if (ui::_is_loading_prompt_being_displayed()) {
		if (Global_1318063) {
			if (func_355(&Global_1315248, 2000, 0) == 0) {
				if (Global_1318071 > 0) {
					ui::set_hud_component_position(17, fVar0, fVar1);
				}
				else {
					ui::reset_hud_component_values(17);
				}
			}
			else {
				Global_1318063 = 0;
			}
		}
	}
	Global_1318062 = ui::_is_loading_prompt_being_displayed();
	Global_1318061 = Global_1318071;
}

// Position - 0x1EAC5
void func_657(int iParam0) {
	if (func_663() == 0) {
		return;
	}
	iParam0++;
	if (func_294()) {
		if (func_711(iParam0) == 0) {
			if (func_662()) {
				if (func_660(iParam0)) {
					func_658(1, iParam0);
				}
			}
		}
	}
}

// Position - 0x1EB06
void func_658(int iParam0, int iParam1) {
	if (iParam0 == 0) {
		func_659();
	}
	Global_1312373[iParam1] = iParam0;
}

// Position - 0x1EB22
void func_659() {
	struct<18> Var0;

	Global_2452492 = {Var0};
	Global_2452510 = 0;
}

// Position - 0x1EB3B
bool func_660(int iParam0) {
	if (iParam0 == 0) {
		return false;
	}
	if (func_463() == 11 || func_463() == 12 || func_463() == 16) {
		return false;
	}
	if (func_661()) {
		return false;
	}
	if (stats::_0x7F2C4CDF2E82DF4C(iParam0)) {
		return false;
	}
	if (stats::stat_load_pending(iParam0) == 0 && stats::stat_slot_is_loaded(iParam0)) {
		return true;
	}
	if (!stats::stat_save_pending() && !stats::stat_load_pending(iParam0) && !stats::stat_save_pending_or_requested()) {
		if (stats::stat_load(iParam0)) {
		}
		else if (func_419()) {
			func_517(5);
			func_531(24);
		}
	}
	return false;
}

// Position - 0x1EBE4
bool func_661() { return Global_2452542; }

// Position - 0x1EBF0
bool func_662() {
	if (player::is_player_online()) {
		if (func_614() == 0) {
			return false;
		}
	}
	else {
		return false;
	}
	if (func_244()) {
		return false;
	}
	return true;
}

// Position - 0x1EC1E
int func_663() { return Global_1318043; }

// Position - 0x1EC2A
int func_664() { return Global_1312735; }

// Position - 0x1EC36
void func_665(int *iParam0) {
	int iVar0;

	switch (*iParam0) {
	case 0:
		Global_1318016 = 0;
		if (func_682()) {
			Global_1318016 = 1;
			*iParam0 = 1;
		}
		break;

	case 1:
		if (func_663() == 0) {
			func_681();
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			func_680(0);
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else if (func_195() == 1) {
			*iParam0 = 2;
		}
		else if (func_196()) {
			func_681();
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			func_680(0);
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else if (func_294() == 0) {
			func_681();
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			func_680(0);
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else if (3 != stats::_0x886913BBEACA68C1(&iVar0)) {
			func_681();
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else if (iVar0 == 1) {
			func_681();
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else {
			*iParam0 = 3;
		}
		break;

	case 2:
		if (func_195() == 0) {
			*iParam0 = 3;
		}
		if (func_679()) {
			func_680(0);
			*iParam0 = 3;
		}
		break;

	case 3:
		func_680(0);
		if (func_294() == 0) {
			func_681();
			Global_1318016 = 0;
			*iParam0 = 0;
		}
		else {
			*iParam0 = 4;
		}
		break;

	case 4:
		if (stats::_0x7F2C4CDF2E82DF4C(0)) {
			*iParam0 = 8;
		}
		if (stats::stat_slot_is_loaded(0) == 0) {
			*iParam0 = 8;
		}
		if (stats::stat_slot_is_loaded(func_664() + 1) == 0) {
			*iParam0 = 8;
		}
		if (Global_2452429[Global_1318017] != 30) {
			if (stats::_0x7F2C4CDF2E82DF4C(1)) {
				*iParam0 = 8;
			}
			if (stats::_0x7F2C4CDF2E82DF4C(2)) {
				*iParam0 = 8;
			}
		}
		if (*iParam0 != 8 && *iParam0 != 0) {
			*iParam0 = 5;
		}
		break;

	case 5:
		if (!stats::stat_save_pending() && !stats::stat_load_pending(-1) && !stats::stat_save_pending_or_requested()) {
			*iParam0 = 6;
		}
		break;

	case 6:
		if (stats::stat_slot_is_loaded(0) == 0) {
			*iParam0 = 4;
			return;
		}
		if (stats::stat_slot_is_loaded(func_664() + 1) == 0) {
			*iParam0 = 4;
			return;
		}
		if (func_663() == 0) {
			*iParam0 = 0;
			return;
		}
		if (func_678(Global_2452429[Global_1318017])) {
			stats::_0x5688585E6D563CD8(Global_2452429[Global_1318017]);
		}
		func_677();
		stats::stat_save(0, 0, Global_2452429[Global_1318017]);
		if (Global_2452429[Global_1318017] == 10 || Global_2452429[Global_1318017] == 27) {
			if (Global_2452457 || Global_2452458) {
				Global_2452457 = 0;
				Global_2452458 = 0;
				func_8(&uLocal_218, 0, 0);
			}
		}
		*iParam0 = 7;
		break;

	case 7:
		if (!stats::stat_save_pending() && !stats::stat_load_pending(-1) && !stats::stat_save_pending_or_requested() ||
			stats::_0x7E6946F68A38B74F(-1)) {
			if (stats::_0x7E6946F68A38B74F(-1)) {
				func_676();
			}
			if (Global_1318017 > -1) {
				Global_2452429[Global_1318017] = 0;
				Global_1318017 = -1;
			}
			if (func_682()) {
				*iParam0 = 1;
			}
			else {
				*iParam0 = 0;
			}
		}
		break;

	case 8:
		if (stats::_0x7F2C4CDF2E82DF4C(0) == 0 && stats::_0x7F2C4CDF2E82DF4C(1) == 0 &&
			stats::_0x7F2C4CDF2E82DF4C(2) == 0 && stats::_0x7F2C4CDF2E82DF4C(3) == 0 &&
			stats::_0x7F2C4CDF2E82DF4C(4) == 0 && stats::stat_slot_is_loaded(0) == 1 && func_295() == 1) {
			if (func_682()) {
				*iParam0 = 1;
			}
			else {
				*iParam0 = 0;
			}
		}
		else {
			*iParam0 = 0;
		}
		break;
	}
	func_666();
}

// Position - 0x1F007
void func_666() {
	if (Global_2453677 == 1 && Global_2453690 == 0) {
		func_675();
	}
	else {
		func_13(&Global_2453696);
	}
	if (streaming::is_player_switch_in_progress()) {
		return;
	}
	if (network::network_is_activity_session()) {
		return;
	}
	if (func_419()) {
		return;
	}
	if (func_195()) {
		return;
	}
	if (!func_419() && func_16() == 0 && !streaming::is_player_switch_in_progress() &&
		!network::network_is_activity_session() && func_674()) {
		if (Global_2453690 == 0 && stats::stat_load_pending(-1) == 0) {
			func_673(stats::_0x7E6946F68A38B74F(-1));
		}
		if (stats::stat_save_pending_or_requested() == 1 && func_672() == 0) {
			return;
		}
		if (func_672()) {
			if (func_671() == 0) {
				if (func_670()) {
					func_669(1);
				}
			}
		}
		else if (func_671()) {
			if (func_667()) {
				func_669(0);
			}
		}
	}
}

// Position - 0x1F0F0
bool func_667() {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	int iVar4;

	iVar4 = 1;
	switch (Global_2453690) {
	case 0:
		Global_2453693 = ui::_0xA9CBFD40B3FA3010();
		ui::_0xA13C11E1B5C06BFC();
		ui::_0xE1CD1E48E025E661();
		ui::_0x80FE4F3AB4E1B62A();
		func_13(&Global_2453691);
		func_668(1);
		break;

	case 1:
		if (func_12(&Global_2453691, 1000, 0)) {
			ui::get_hud_colour(1, &uVar0, &uVar1, &uVar2, &uVar3);
			ui::_set_notification_flash_color(uVar0, uVar1, uVar2, uVar3);
			ui::_0x17AD8C9706BDD88A(iVar4);
			ui::_set_notification_text_entry("SAVESUCCFEED");
			ui::_draw_notification_2(1, 1);
			ui::_0xFDD85225B2DEA55E();
			func_668(2);
		}
		break;

	case 2:
		if (func_12(&Global_2453691, 10000, 0)) {
			func_668(3);
		}
		break;

	case 3:
		if (Global_2453693 == 1) {
			ui::_0xFDB423997FA30340();
			ui::_0x583049884A2EEE3C();
			ui::_0xA8FDB297A8D25FBA();
		}
		ui::_0x80FE4F3AB4E1B62A();
		Global_2453693 = 0;
		func_668(0);
		return true;
	}
	return false;
}

// Position - 0x1F1CA
void func_668(int iParam0) { Global_2453690 = iParam0; }

// Position - 0x1F1D8
void func_669(int iParam0) { Global_2453677 = iParam0; }

// Position - 0x1F1E6
bool func_670() {
	var uVar0;
	var uVar1;
	var uVar2;
	var uVar3;
	int iVar4;

	iVar4 = 1;
	switch (Global_2453690) {
	case 0:
		Global_2453693 = ui::_0xA9CBFD40B3FA3010();
		ui::_0xA13C11E1B5C06BFC();
		ui::_0xE1CD1E48E025E661();
		ui::_0xA8FDB297A8D25FBA();
		func_668(1);
		break;

	case 1:
		if (func_12(&Global_2453691, 1000, 0)) {
			ui::get_hud_colour(1, &uVar0, &uVar1, &uVar2, &uVar3);
			ui::_set_notification_flash_color(uVar0, uVar1, uVar2, uVar3);
			ui::_0x17AD8C9706BDD88A(iVar4);
			ui::_set_notification_text_entry("SAVEFAILEDFEED");
			ui::_draw_notification_2(1, 1);
			ui::_0xFDD85225B2DEA55E();
			func_668(2);
		}
		break;

	case 2:
		if (func_12(&Global_2453691, 10000, 0) || ui::is_warning_message_active()) {
			func_668(3);
		}
		break;

	case 3:
		if (Global_2453693 == 1) {
			ui::_0xFDB423997FA30340();
			ui::_0x583049884A2EEE3C();
		}
		func_668(4);
		break;

	case 4:
		Global_2453693 = 0;
		func_668(0);
		return true;
	}
	return false;
}

// Position - 0x1F2C8
bool func_671() { return Global_2453677; }

// Position - 0x1F2D4
bool func_672() { return Global_2453676; }

// Position - 0x1F2E0
void func_673(var uParam0) { Global_2453676 = uParam0; }

// Position - 0x1F2EE
int func_674() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("freemode")) > 0 && Global_1312500 == 2) {
		return 1;
	}
	return 0;
}

// Position - 0x1F314
void func_675() {
	if (network::network_is_in_mp_cutscene()) {
		func_13(&Global_2453696);
		return;
	}
	if (streaming::is_player_switch_in_progress()) {
		func_13(&Global_2453696);
		return;
	}
	if (Global_1751032) {
		func_13(&Global_2453696);
		return;
	}
	if (func_195()) {
		func_13(&Global_2453696);
		return;
	}
	if (func_16() != 0) {
		func_13(&Global_2453696);
		return;
	}
	if (!cam::is_gameplay_cam_rendering() && !cam::_0xCA9D2AA3E326D720() && !cam::is_cinematic_cam_rendering()) {
		func_13(&Global_2453696);
		return;
	}
	if (func_230() == 0) {
		func_13(&Global_2453696);
		return;
	}
	if (func_148() == 1) {
		func_13(&Global_2453696);
		return;
	}
	if (Global_2453695 == 0) {
		if (func_355(&Global_2453696, 4000, 0)) {
			ui::_0xFDEC055AB549E328();
			ui::_set_notification_text_entry("HUD_SAVDNWARN");
			ui::_draw_notification(1, 1);
			Global_2453695 = 1;
		}
	}
	else {
		func_13(&Global_2453696);
	}
}

// Position - 0x1F3FE
void func_676() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 9) {
		Global_2452429[iVar0] = 0;
		iVar0++;
	}
	Global_1318017 = -1;
}

// Position - 0x1F427
void func_677() {
	int iVar0;

	if (Global_2452429[Global_1318017] == 28 && Global_1318017 + 1 <= 9) {
		iVar0 = Global_1318017 + 1;
		while (iVar0 <= 9) {
			Global_2452429[iVar0] = 0;
			iVar0++;
		}
	}
}

// Position - 0x1F46E
bool func_678(int iParam0) {
	if (network::network_is_activity_session()) {
		if (iParam0 == 27 || iParam0 == 27 || iParam0 == 28 || iParam0 == 29 || iParam0 == 30 || iParam0 == 10 ||
			iParam0 == 11) {
			return true;
		}
	}
	return false;
}

// Position - 0x1F4CC
bool func_679() { return Global_2412535; }

// Position - 0x1F4D8
void func_680(int iParam0) { Global_2412535 = iParam0; }

// Position - 0x1F4E6
void func_681() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 9) {
		Global_2452429[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x1F50A
bool func_682() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	iVar1 = 0;
	while (iVar1 <= 9) {
		if (Global_2452429[iVar1] != 0) {
			Global_1318017 = iVar1;
			iVar0 = 1;
			iVar1 = 10;
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0x1F543
void func_683() {
	int *iVar0;
	bool bVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	Global_1318032 = 0;
	if (func_690() == 0 && network::_0xD313DE83394AF134() == 0) {
		return;
	}
	if (func_690() == 0 && network::_0xD313DE83394AF134() && Global_35781 == 14) {
		if (unk_0xBE3DB208333D9844() == 0) {
			stats::_0x98E2BC1CA26287C3();
		}
	}
	if (func_687(&iVar0) == 0) {
		return;
	}
	bVar1 = true;
	if (bVar1) {
		if (dlc2::_0xA213B11DFF526300() == 0) {
			return;
		}
	}
	if (func_663() == 0) {
		func_696();
		return;
	}
	if (func_16() == 0) {
		return;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4() == 0) {
		return;
	}
	if (func_355(&Global_2454816, 3000, 1) == 0) {
		return;
	}
	if (func_662() == 0) {
		func_696();
		return;
	}
	if (Global_262145.f_7416 == 0) {
		if (Global_2452510 == 0) {
			if (stats::_0x886913BBEACA68C1(&Global_2452492) == 4) {
				return;
			}
			iVar2 = stats::_0xC70DDCE56D0D3A99();
			if (iVar2 == 0 && network::_0xD313DE83394AF134()) {
				func_433(12, 1, -1);
			}
			Global_2452510 = 1;
			return;
		}
		if (stats::_0x886913BBEACA68C1(&Global_2452492) == 4) {
			return;
		}
		if (stats::_0x886913BBEACA68C1(&Global_2452492) != 3) {
			if (!func_653(12) && network::_0xD313DE83394AF134() && stats::_0x886913BBEACA68C1(&Global_2452492) == 1) {
				func_433(12, 1, -1);
			}
			return;
		}
		if (func_653(18) == 0) {
			if (network::_0xD313DE83394AF134() && Global_2452492 == 1) {
				func_433(18, 1, -1);
				network::network_session_force_cancel_invite();
			}
		}
		if (func_653(18) == 0) {
			if (network::_0xD313DE83394AF134() && Global_2452492 == 1) {
				func_433(18, 1, -1);
				network::network_session_force_cancel_invite();
			}
		}
		if (Global_2452492 == 1) {
			return;
		}
		if (Global_2452537) {
			return;
		}
	}
	if (func_463() == 16 || func_463() == 11 || func_463() == 12) {
		return;
	}
	if (func_532() == 6 || func_463() == 19) {
		return;
	}
	if (func_532() == 35) {
		return;
	}
	if (Global_139177 && stats::_0x7F2C4CDF2E82DF4C(0)) {
		func_696();
	}
	if (func_711(0) == 0) {
		Global_1318032 = 1;
		if (func_686()) {
			func_658(1, 0);
			iVar3 = 0;
			if (stats::_0x7F2C4CDF2E82DF4C(0) == 0) {
				iVar3 = func_707(joaat("mpply_last_mp_char"));
			}
			func_685(iVar3);
			func_684(0, 0);
			if (iVar3 == -1) {
				iVar3 = 0;
				func_685(0);
			}
			iVar4 = 0;
			while (iVar4 <= 1) {
				Global_1312729[iVar4] = func_708(384, iVar4, -1);
				iVar4++;
			}
		}
	}
	if (func_711(0)) {
		if (stats::_0x7F2C4CDF2E82DF4C(0)) {
			func_658(0, 0);
		}
		else {
			iVar5 = 0;
			if (stats::_0x7F2C4CDF2E82DF4C(0) == 0) {
				iVar5 = func_707(joaat("mpply_last_mp_char"));
			}
			if (iVar5 == -1) {
				iVar5 = 0;
				func_685(0);
				func_339(joaat("mpply_last_mp_char"), 0);
			}
			iVar5++;
			if (Global_139177 && stats::_0x7F2C4CDF2E82DF4C(iVar5)) {
				func_696();
			}
			if (func_711(iVar5) == 0) {
				Global_1318032 = 1;
				if (func_660(iVar5)) {
					iVar6 = 0;
					while (iVar6 <= 1) {
						Global_1312729[iVar6] = func_708(384, iVar6, -1);
						iVar6++;
					}
					func_658(1, iVar5);
					func_696();
					func_533(1);
				}
			}
		}
	}
}

// Position - 0x1F86D
void func_684(int iParam0, int iParam1) { Global_2453579[iParam0] = iParam1; }

// Position - 0x1F87F
void func_685(int iParam0) {
	Global_69521 = iParam0;
	func_339(joaat("mpply_last_mp_char"), iParam0);
	Global_1312735 = iParam0;
}

// Position - 0x1F89E
bool func_686() {
	int iVar0;

	iVar0 = 0;
	if (func_661()) {
		return false;
	}
	if (stats::_0x7F2C4CDF2E82DF4C(iVar0)) {
		return false;
	}
	if (stats::stat_load_pending(iVar0) == 0 && stats::stat_slot_is_loaded(iVar0)) {
		return true;
	}
	if (!stats::stat_save_pending() && !stats::stat_load_pending(iVar0) && !stats::stat_save_pending_or_requested()) {
		stats::_0x6F361B8889A792A3();
		Global_2453941 = 1;
		if (stats::stat_load(iVar0)) {
		}
		else if (func_419()) {
			func_517(5);
			func_531(24);
		}
	}
	return false;
}

// Position - 0x1F921
int func_687(int *iParam0) {
	bool bVar0;

	if (func_688()) {
		return 0;
	}
	if (dlc2::_nullify(&bVar0, 0)) {
		*iParam0 = 0;
		return 1;
	}
	if (bVar0) {
		*iParam0 = 1;
		return 1;
	}
	return 0;
}

// Position - 0x1F954
bool func_688() {
	if (func_689() != 1 && func_689() != 2 && func_689() != 4 && func_689() != 5 && func_689() != 7 &&
		func_689() != 6 && func_689() != 9 && func_689() != 8 && func_689() != 10 && func_689() != 12 &&
		func_689() != 11 && func_689() != 13 && func_689() != 14 && func_689() != 15 && func_689() != 16 &&
		func_689() != 17 && func_689() != 18 && func_689() != 19 && func_689() != 20 && func_689() != 21) {
		return false;
	}
	return true;
}

// Position - 0x1FA49
int func_689() { return Global_1315195; }

// Position - 0x1FA55
int func_690() { return Global_1318084; }

// Position - 0x1FA61
void func_691() {
	int iVar0;
	int iVar1[12];
	int iVar14;
	int iVar15;
	int iVar16;
	var uVar17;
	struct<13> Var52;

	if (Global_1318010 || func_695())
		&&network::_0xC32EA7A2F6CA7557() && func_694() {
			iVar0 = 0;
			if (func_693(player::player_id(), &Global_1316390, &Global_1316391, &Global_1316392)) {
				Global_1316389 = 1;
			}
			else {
				Global_1316389 = 0;
			}
			iVar0 = 1;
			iVar14 = 1;
			iVar15 = 1;
			while (iVar15 <= 11) {
				iVar16 = iVar15 * 10;
				if (iVar16 > 100) {
					iVar16 = 100;
				}
				network::_0x2B51EDBEFC301339(iVar16, &Global_1316393[iVar15 - 1 /*16*/]);
				iVar1[iVar15] = 1;
				if (func_21(&Global_1316393[iVar15 - 1 /*16*/])) {
					StringCopy(&Global_1316393[iVar15 - 1 /*16*/], ui::_get_label_text("HUD_NOCREWTIT"), 64);
				}
				iVar15++;
			}
			iVar15 = 1;
			while (iVar15 <= 11) {
				if (iVar1[iVar15] == 0) {
					iVar14 = 0;
					iVar15 = 10;
				}
				iVar15++;
			}
			if (iVar0 && iVar14) {
				Global_1318010 = 0;
			}
			else {
				Global_1318010 = 0;
				if (iVar0 == 0) {
				}
				if (iVar14 == 0) {
				}
			}
			if (func_695()) {
				Global_2452428 = func_692();
			}
			if (player::is_player_online()) {
				if (network::_network_player_is_in_clan()) {
					Var52 = {func_608(player::player_id())};
					if (network::network_clan_player_is_active(&Var52)) {
						network::network_clan_player_get_desc(&uVar17, 35, &Var52);
						Global_2452452 = uVar17;
					}
				}
			}
		}
}

// Position - 0x1FBAD
int func_692() { return func_39(1292, -1, 0); }

// Position - 0x1FBBE
bool func_693(int iParam0, var *uParam1, var *uParam2, var *uParam3) {
	struct<35> Var0;
	struct<13> Var35;

	if (player::is_player_online() && network::network_is_signed_online()) {
		Var35 = {func_608(iParam0)};
		if (network::_network_player_is_in_clan() && network::network_clan_player_is_active(&Var35)) {
			network::network_clan_player_get_desc(&Var0, 35, &Var35);
			*uParam1 = Var0.f_32;
			*uParam2 = Var0.f_33;
			*uParam3 = Var0.f_34;
			return true;
		}
	}
	return false;
}

// Position - 0x1FC18
bool func_694() {
	struct<13> Var0;

	if (player::is_player_online()) {
		if (network::network_is_signed_online() && network::network_is_signed_in() && network::_0x67A5589628E0CFF6()) {
			Var0 = {func_580()};
			if (network::_network_player_is_in_clan() && network::network_clan_player_is_active(&Var0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x1FC60
bool func_695() {
	if (Global_2452443) {
		if (func_294()) {
			if (func_692() != Global_2452428) {
				if (func_692() == 1) {
					return true;
				}
			}
		}
	}
	return false;
}

// Position - 0x1FC8E
void func_696() {
	if (Global_139177) {
		Global_139177 = 0;
		network::network_suppress_invite(0);
	}
}

// Position - 0x1FCA7
void func_697() {
	func_701();
	func_698();
	Global_1318077 = Global_1363164;
	Global_1318076 = Global_1363165;
	Global_1318075 = Global_1363166;
	Global_1318078 = Global_1363167;
	Global_1318079 = Global_1363168;
	Global_1318080 = Global_1363169;
	Global_1318081 = func_707(joaat("mpply_vc_annoyingme"));
}

// Position - 0x1FCF4
void func_698() {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar1 = 72;
	iVar2 = 22;
	iVar1 = 86;
	if (!Global_1363152) {
		Global_1363153 = func_700(joaat("mpply_crew_0_id"));
		Global_1363154 = func_700(joaat("mpply_crew_1_id"));
		Global_1363155 = func_700(joaat("mpply_crew_2_id"));
		Global_1363156 = func_700(joaat("mpply_crew_3_id"));
		Global_1363157 = func_700(joaat("mpply_crew_4_id"));
		Global_1363158 = func_700(joaat("mpply_crew_local_xp_0"));
		Global_1363159 = func_700(joaat("mpply_crew_local_xp_1"));
		Global_1363160 = func_700(joaat("mpply_crew_local_xp_2"));
		Global_1363161 = func_700(joaat("mpply_crew_local_xp_3"));
		Global_1363162 = func_700(joaat("mpply_crew_local_xp_4"));
		Global_1363163 = func_700(joaat("mpply_became_cheater_num"));
		Global_1363164 = func_700(joaat("mpply_friendly"));
		Global_1363165 = func_700(joaat("mpply_offensive_language"));
		Global_1363166 = func_700(joaat("mpply_griefing"));
		Global_1363167 = func_700(joaat("mpply_helpful"));
		Global_1363168 = func_700(joaat("mpply_offensive_tagplate"));
		Global_1363169 = func_700(joaat("mpply_offensive_ugc"));
		iVar0 = 0;
		while (iVar0 < 2) {
			Global_1363171[iVar0] = func_699(762, iVar0);
			Global_1363177[iVar0] = func_699(763, iVar0);
			Global_1363183[iVar0] = func_699(764, iVar0);
			Global_1363189[iVar0] = func_699(765, iVar0);
			Global_1363195[iVar0] = func_699(772, iVar0);
			Global_1363201[iVar0] = func_699(773, iVar0);
			Global_1363207[iVar0] = func_699(774, iVar0);
			Global_1363213[iVar0] = func_699(775, iVar0);
			Global_1363219[iVar0] = func_699(782, iVar0);
			Global_1363225[iVar0] = func_699(783, iVar0);
			Global_1363231[iVar0] = func_699(784, iVar0);
			Global_1363237[iVar0] = func_699(785, iVar0);
			Global_1363243[iVar0] = func_699(752, iVar0);
			Global_1363249[iVar0] = func_699(753, iVar0);
			Global_1363255[iVar0] = func_699(754, iVar0);
			Global_1363261[iVar0] = func_699(755, iVar0);
			Global_1363267[iVar0] = func_699(1298, iVar0);
			Global_1363273[iVar0] = func_699(634, iVar0);
			Global_1363279[iVar0] = func_699(1273, iVar0);
			if (Global_1363279[iVar0] > iVar1) {
				Global_1363279[iVar0] = 0;
			}
			else {
				Global_1363279[iVar0] = Global_1363279[iVar0];
			}
			Global_2524277[0 /*3*/][iVar0] = func_699(1870, iVar0);
			if (Global_2524277[0 /*3*/][iVar0] > iVar1) {
				Global_2524277[0 /*3*/][iVar0] = 0;
			}
			else {
				Global_2524277[0 /*3*/][iVar0] = Global_2524277[0 /*3*/][iVar0];
			}
			Global_2524277[1 /*3*/][iVar0] = func_699(2261, iVar0);
			if (Global_2524277[1 /*3*/][iVar0] > iVar1) {
				Global_2524277[1 /*3*/][iVar0] = 0;
			}
			else {
				Global_2524277[1 /*3*/][iVar0] = Global_2524277[1 /*3*/][iVar0];
			}
			Global_2524277[2 /*3*/][iVar0] = func_699(2911, iVar0);
			if (Global_2524277[2 /*3*/][iVar0] > iVar1) {
				Global_2524277[2 /*3*/][iVar0] = 0;
			}
			else {
				Global_2524277[2 /*3*/][iVar0] = Global_2524277[2 /*3*/][iVar0];
			}
			Global_2524277[3 /*3*/][iVar0] = func_699(3040, iVar0);
			if (Global_2524277[3 /*3*/][iVar0] > iVar1) {
				Global_2524277[3 /*3*/][iVar0] = 0;
			}
			else {
				Global_2524277[3 /*3*/][iVar0] = Global_2524277[3 /*3*/][iVar0];
			}
			Global_2524348[iVar0] = func_699(5886, iVar0);
			Global_2524311[0 /*3*/][iVar0] = func_699(3035, iVar0);
			Global_2524311[1 /*3*/][iVar0] = func_699(3036, iVar0);
			Global_2524311[2 /*3*/][iVar0] = func_699(3037, iVar0);
			Global_2524311[3 /*3*/][iVar0] = func_699(3038, iVar0);
			Global_2524311[4 /*3*/][iVar0] = func_699(3039, iVar0);
			Global_2524311[5 /*3*/][iVar0] = func_699(3203, iVar0);
			Global_2524277[4 /*3*/][iVar0] = func_699(3209, iVar0);
			Global_2524311[6 /*3*/][iVar0] = func_699(3211, iVar0);
			Global_2524277[5 /*3*/][iVar0] = func_699(3212, iVar0);
			Global_2524311[7 /*3*/][iVar0] = func_699(3216, iVar0);
			Global_2524277[6 /*3*/][iVar0] = func_699(3214, iVar0);
			Global_2524311[8 /*3*/][iVar0] = func_699(3991, iVar0);
			Global_2524277[7 /*3*/][iVar0] = func_699(3992, iVar0);
			Global_2524311[9 /*3*/][iVar0] = func_699(3994, iVar0);
			Global_2524277[8 /*3*/][iVar0] = func_699(3995, iVar0);
			Global_2524311[10 /*3*/][iVar0] = func_699(3997, iVar0);
			Global_2524277[9 /*3*/][iVar0] = func_699(3998, iVar0);
			Global_2524311[11 /*3*/][iVar0] = func_699(4000, iVar0);
			Global_2524277[10 /*3*/][iVar0] = func_699(4001, iVar0);
			Global_1363285[iVar0] = func_699(759, iVar0);
			Global_1363291[iVar0] = func_699(760, iVar0);
			Global_1363297[iVar0] = func_699(761, iVar0);
			Global_1363303[iVar0] = func_699(1231, iVar0);
			Global_2524351[0 /*3*/][iVar0] = func_699(3618, iVar0);
			if (Global_2524351[0 /*3*/][iVar0] > iVar2) {
				Global_2524351[0 /*3*/][iVar0] = 0;
			}
			Global_2524351[1 /*3*/][iVar0] = func_699(3619, iVar0);
			if (Global_2524351[1 /*3*/][iVar0] > iVar2) {
				Global_2524351[1 /*3*/][iVar0] = 0;
			}
			Global_2524351[2 /*3*/][iVar0] = func_699(3620, iVar0);
			if (Global_2524351[2 /*3*/][iVar0] > iVar2) {
				Global_2524351[2 /*3*/][iVar0] = 0;
			}
			Global_2524351[3 /*3*/][iVar0] = func_699(3621, iVar0);
			if (Global_2524351[3 /*3*/][iVar0] > iVar2) {
				Global_2524351[3 /*3*/][iVar0] = 0;
			}
			Global_2524351[4 /*3*/][iVar0] = func_699(3622, iVar0);
			if (Global_2524351[4 /*3*/][iVar0] > iVar2) {
				Global_2524351[4 /*3*/][iVar0] = 0;
			}
			Global_2524367[0 /*3*/][iVar0] = func_699(3623, iVar0);
			Global_2524367[1 /*3*/][iVar0] = func_699(3624, iVar0);
			Global_2524367[2 /*3*/][iVar0] = func_699(3625, iVar0);
			Global_2524367[3 /*3*/][iVar0] = func_699(3626, iVar0);
			Global_2524367[4 /*3*/][iVar0] = func_699(3627, iVar0);
			Global_2524383[iVar0] = func_699(3645, iVar0);
			Global_2524392[iVar0] = func_699(3646, iVar0);
			Global_2524386[iVar0] = func_699(3647, iVar0);
			Global_2524395[iVar0] = func_699(3648, iVar0);
			Global_2524389[iVar0] = func_699(3649, iVar0);
			Global_2524398[iVar0] = func_699(3650, iVar0);
			Global_2524401[iVar0] = func_699(3671, iVar0);
			iVar0++;
		}
		Global_1363152 = 1;
	}
}

// Position - 0x2043D
int func_699(int iParam0, int iParam1) {
	int iVar0;
	var uVar1;

	iVar0 = Global_2503826[iParam0 /*3*/][iParam1];
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x20465
int func_700(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x20483
void func_701() { Global_1363152 = 0; }

// Position - 0x20490
void func_702() {
	if (!func_89(1, -1)) {
		func_704(1, -1);
	}
	if (func_419() && func_16() == 0) {
	}
	else {
		network::network_block_invites(0);
	}
	if (func_703(1)) {
		network::_0x4A9FDE3A5A6D0437(1);
	}
	else {
		network::_0x4A9FDE3A5A6D0437(0);
	}
	Global_2443134.f_621 = 0;
	if (func_294()) {
		if (!func_334(133, -1)) {
			func_66(133, 1, -1, 1);
		}
	}
}

// Position - 0x204FA
bool func_703(int iParam0) { return Global_1751175.f_16[iParam0 /*44*/].f_3; }

// Position - 0x2050E
void func_704(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam1 == -1) {
		iParam1 = func_664();
	}
	Global_1363152 = 0;
	if (gameplay::_0x5AA3BEFA29F03AD4() == 0) {
		return;
	}
	switch (iParam0) {
	case 0:
		stats::_0x0D01D20616FC73FB(0, iParam1);
		iVar1 = func_90(iParam1);
		iVar0 = gameplay::get_profile_setting(iVar1);
		break;

	default:
		iVar1 = func_90(iParam1);
		iVar0 = gameplay::get_profile_setting(iVar1);
		if (!gameplay::is_bit_set(iVar0, iParam0)) {
			gameplay::set_bit(&iVar0, iParam0);
			stats::_0x0D01D20616FC73FB(iVar0, iParam1);
		}
		break;
	}
	switch (iParam0) {
	case 0:
		func_66(120, 0, iParam1, 1);
		func_66(124, 0, iParam1, 1);
		func_66(115, 0, iParam1, 1);
		func_66(119, 0, iParam1, 1);
		func_66(121, 0, iParam1, 1);
		func_66(122, 0, iParam1, 1);
		func_66(125, 0, iParam1, 1);
		func_87(1298, 0, iParam1, 1, 0);
		break;
	}
}

// Position - 0x205ED
bool func_705(int iParam0) {
	int iVar0;
	int iVar1;

	if (func_245()) {
		return true;
	}
	if (func_244()) {
		return true;
	}
	switch (iParam0) {
	case 1:
	case 2:
	case 23:
	case 12:
	case 13:
	case 11:
	case 14:
	case 15:
	case 30:
	case 8:
	case 32:
	case 0:
	case 3:
	case 4:
	case 5:
	case 6:
	case 20:
	case 27:
	case 29:
	case 19:
	case 31:
	case 59:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 67:
	case 73:
	case 74:
	case 75:
	case 76:
	case 77:
	case 81:
	case 88:
	case 89:
	case 90:
	case 93:
	case 95:
	case 96:
	case 97:
	case 98:
	case 99:
	case 100:
	case 102:
	case 103:
	case 104:
	case 105:
	case 106:
	case 107:
	case 108:
	case 109:
	case 110:
	case 119:
	case 121:
	case 122:
	case 124:
	case 125:
	case 126:
	case 127:
	case 78:
	case 128:
	case 129:
	case 131:
	case 132:
	case 133:
	case 134:
	case 156:
	case 136:
	case 138:
	case 137:
	case 139:
	case 140:
	case 141:
	case 144:
	case 146:
	case 148:
	case 135:
	case 130:
		iVar1 = iParam0;
		iVar1 %= 32;
		iVar0 = func_39(func_706(iParam0), -1, 0);
		if (gameplay::is_bit_set(iVar0, iVar1)) {
			return true;
		}
		break;

	default: return true;
	}
	return false;
}

// Position - 0x2081F
int func_706(int iParam0) {
	int iVar0;

	iVar0 = iParam0 / 32;
	switch (iVar0) {
	case 0: return 1195;

	case 1: return 1196;

	case 2: return 1197;

	case 3: return 1198;

	case 4: return 1199;

	case 5: return 1201;

	case 6: return 3787;

	case 7: return 3990;

	default:
	}
	return 1195;
}

// Position - 0x208B0
int func_707(int iParam0) {
	int iVar0;
	var uVar1;

	iVar0 = iParam0;
	if (stats::stat_get_int(iVar0, &uVar1, -1)) {
		return uVar1;
	}
	return 0;
}

// Position - 0x208CE
int func_708(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam1 == -1) {
		iParam1 = func_664();
	}
	iVar0 = 0;
	iVar1 = func_710(iParam0, iParam1);
	iVar2 = func_709(iParam0);
	if (0 != iVar1) {
		if (!stats::stat_get_masked_int(iVar1, &iVar0, iVar2, 8, iParam2)) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0x20914
int func_709(int iParam0) {
	int iVar0;

	iVar0 = 0;
	if (iParam0 >= 384 && iParam0 < 457) {
		iVar0 = iParam0 - 384 - stats::_0x94F12ABF9C79E339(iParam0 - 384) * 8 * 8;
	}
	else if (iParam0 >= 457 && iParam0 < 513) {
		iVar0 = iParam0 - 457 - stats::_0x94F12ABF9C79E339(iParam0 - 457) * 8 * 8;
	}
	else if (iParam0 >= 1281 && iParam0 < 1305) {
		iVar0 = iParam0 - 1281 - stats::_0x94F12ABF9C79E339(iParam0 - 1281) * 8 * 8;
	}
	else if (iParam0 >= 1305 && iParam0 < 1361) {
		iVar0 = iParam0 - 1305 - stats::_0x94F12ABF9C79E339(iParam0 - 1305) * 8 * 8;
	}
	else if (iParam0 >= 1361 && iParam0 < 1393) {
		iVar0 = iParam0 - 1361 - stats::_0x94F12ABF9C79E339(iParam0 - 1361) * 8 * 8;
	}
	else if (iParam0 >= 1393 && iParam0 < 2919) {
		iVar0 = iParam0 - 1393 - stats::_0x94F12ABF9C79E339(iParam0 - 1393) * 8 * 8;
	}
	else if (iParam0 >= 4143 && iParam0 < 4207) {
		iVar0 = iParam0 - 4143 - stats::_0x94F12ABF9C79E339(iParam0 - 4143) * 8 * 8;
	}
	else if (iParam0 >= 3879 && iParam0 < 4143) {
		iVar0 = iParam0 - 3879 - stats::_0x94F12ABF9C79E339(iParam0 - 3879) * 8 * 8;
	}
	else if (iParam0 >= 4399 && iParam0 < 6028) {
		iVar0 = iParam0 - 4399 - stats::_0x94F12ABF9C79E339(iParam0 - 4399) * 8 * 8;
	}
	else if (iParam0 >= 6413 && iParam0 < 7262) {
		iVar0 = iParam0 - 6413 - stats::_0x94F12ABF9C79E339(iParam0 - 6413) * 8 * 8;
	}
	else if (iParam0 >= 7262 && iParam0 < 7313) {
		iVar0 = iParam0 - 7262 - stats::_0x94F12ABF9C79E339(iParam0 - 7262) * 8 * 8;
	}
	else if (iParam0 >= 7681 && iParam0 < 9361) {
		iVar0 = iParam0 - 7681 - stats::_0x94F12ABF9C79E339(iParam0 - 7681) * 8 * 8;
	}
	else if (iParam0 >= 9553 && iParam0 < 15265) {
		iVar0 = iParam0 - 9553 - stats::_0x94F12ABF9C79E339(iParam0 - 9553) * 8 * 8;
	}
	else if (iParam0 >= 7313 && iParam0 < 7321) {
		iVar0 = iParam0 - 7313 - stats::_0x94F12ABF9C79E339(iParam0 - 7313) * 8 * 8;
	}
	else if (iParam0 >= 7641 && iParam0 < 7681) {
		iVar0 = iParam0 - 7641 - stats::_0x94F12ABF9C79E339(iParam0 - 7641) * 8 * 8;
	}
	return iVar0;
}

// Position - 0x20BD0
int func_710(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 == -1) {
		iParam1 = func_664();
	}
	iVar0 = 0;
	if (iParam0 >= 384 && iParam0 < 457) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 384, 0, 1, iParam1);
	}
	else if (iParam0 >= 457 && iParam0 < 513) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 457, 1, 1, iParam1);
	}
	else if (iParam0 >= 1281 && iParam0 < 1305) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 1281, 0, 0, 0);
	}
	else if (iParam0 >= 1305 && iParam0 < 1361) {
		iVar0 = stats::_get_pstat_int_hash(iParam0 - 1305, 1, 0, 0);
	}
	else if (iParam0 >= 1361 && iParam0 < 1393) {
		iVar0 = stats::_get_tupstat_int_hash(iParam0 - 1361, 0, 0, 0);
	}
	else if (iParam0 >= 1393 && iParam0 < 2919) {
		iVar0 = stats::_get_tupstat_int_hash(iParam0 - 1393, 0, 1, iParam1);
	}
	else if (iParam0 >= 4143 && iParam0 < 4207) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 4143, 0, 0, 0, "_NGPSTAT_INT");
	}
	else if (iParam0 >= 3879 && iParam0 < 4143) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 3879, 0, 1, iParam1, "_NGPSTAT_INT");
	}
	else if (iParam0 >= 4399 && iParam0 < 6028) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 4399, 0, 1, iParam1, "_LRPSTAT_INT");
	}
	else if (iParam0 >= 6413 && iParam0 < 7262) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 6413, 0, 1, iParam1, "_APAPSTAT_INT");
	}
	else if (iParam0 >= 7262 && iParam0 < 7313) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7262, 0, 1, iParam1, "_LR2PSTAT_INT");
	}
	else if (iParam0 >= 7681 && iParam0 < 9361) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7681, 0, 1, iParam1, "_BIKEPSTAT_INT");
	}
	else if (iParam0 >= 9553 && iParam0 < 15265) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 9553, 0, 1, iParam1, "_IMPEXPPSTAT_INT");
	}
	else if (iParam0 >= 7313 && iParam0 < 7321) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7313, 0, 0, 0, "_NGDLCPSTAT_INT");
	}
	else if (iParam0 >= 7641 && iParam0 < 7681) {
		iVar0 = stats::_get_ngstat_int_hash(iParam0 - 7641, 0, 1, iParam1, "_NGDLCPSTAT_INT");
	}
	return iVar0;
}

// Position - 0x20E4E
int func_711(int iParam0) { return Global_1312373[iParam0]; }

// Position - 0x20E5E
void func_712() { Global_1318010 = 1; }

// Position - 0x20E6B
void func_713() {
	struct<13> Var0;

	Var0 = {func_580()};
	if (player::is_player_online()) {
		if (network::_network_player_is_in_clan() && network::network_clan_player_is_active(&Var0)) {
			Global_1315265[player::player_id() /*35*/] = {func_714()};
			if (func_694()) {
				if (func_693(player::player_id(), &Global_1316390, &Global_1316391, &Global_1316392)) {
					Global_1316389 = 1;
				}
				else {
					Global_1316389 = 0;
				}
			}
		}
		else {
			Global_1315265[player::player_id() /*35*/] = -1;
			Global_1316389 = 0;
		}
	}
}

// Position - 0x20EE4
struct<35> func_714() {
	struct<13> Var0;
	struct<35> Var13;

	Var0 = {func_580()};
	if (player::is_player_online()) {
		network::network_clan_player_get_desc(&Var13, 0, &Var0);
	}
	return Var13;
}

//Position - 0x20F0B
void func_715()
{
}

// Position - 0x20F13
void func_716() {
	int iVar0;
	int iVar1;

	if (iLocal_213) {
		if (network::network_is_signed_online() && network::network_is_signed_in() && gameplay::_0x5AA3BEFA29F03AD4()) {
			if (func_719() == 0) {
				if (!func_718()) {
					if (!iLocal_214) {
						if (Global_2454182 > 0f || Global_2454182.f_1 > 0)
							&&!gameplay::is_string_null_or_empty(&Global_2454182.f_19) {
								if (stats::_0x3270F67EED31FBC1(-1386894335, "ps3", &Global_2454182.f_19)) {
									iLocal_214 = 1;
								}
								else {
									func_717(1);
								}
							}
						else if (Global_2454304 > 0f || Global_2454304.f_1 > 0)
							&&!gameplay::is_string_null_or_empty(&Global_2454304.f_19) {
								if (stats::_0x3270F67EED31FBC1(-1386894335, "xbox360", &Global_2454304.f_19)) {
									iLocal_214 = 1;
								}
								else {
									func_717(1);
								}
							}
						else {
							iLocal_213 = 0;
						}
					}
					else {
						switch (stats::_0xCE5AA445ABA8DEE0(&iVar0)) {
						case 0:
						case 1: break;

						case 4:
							func_717(1);
							iLocal_214 = 0;
							iLocal_213 = 0;
							break;

						case 2:
							switch (iVar0) {
							case -1: break;

							case 0: break;

							case 4: break;

							default: break;
							}
							func_717(1);
							iLocal_214 = 0;
							iLocal_213 = 0;
							break;

						case 3:
							func_717(2);
							if (gameplay::_0x5AA3BEFA29F03AD4()) {
								iVar1 = gameplay::get_profile_setting(866);
								gameplay::set_bit(&iVar1, 0);
								stats::_0xDAC073C7901F9E15(iVar1);
							}
							iLocal_214 = 0;
							iLocal_213 = 0;
							break;
						}
					}
				}
				else {
					func_717(2);
					iLocal_214 = 0;
					iLocal_213 = 0;
				}
			}
			else {
				iLocal_214 = 0;
				iLocal_213 = 0;
			}
		}
		else {
			iLocal_214 = 0;
			iLocal_213 = 0;
		}
	}
}

// Position - 0x210A3
void func_717(int iParam0) { Global_139179 = iParam0; }

// Position - 0x210B1
int func_718() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return 1;
			}
		}
	}
	if (Global_139179 == 2) {
		return 1;
	}
	else if (Global_139179 == 3) {
		return 0;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x2116C
int func_719() { return Global_139179; }

// Position - 0x21178
void func_720() {
	bool bVar0;
	int iVar1;

	if (!iLocal_213) {
		bVar0 = false;
		if (func_724() == 0 || func_719() == 0) {
			if (!func_294() && !stats::stat_load_pending(0) && !stats::stat_load_pending(1) &&
				!stats::stat_load_pending(2)) {
				if (func_722(0)) {
					iVar1 = stats::_0xDEAAF77EB3687E97(0, &Global_2454304);
					if (iVar1 == 3) {
						if (func_719() == 0) {
							func_717(1);
						}
						if (func_724() == 0) {
							func_721(1);
						}
					}
					else {
						if (iVar1 == 4) {
							func_721(2);
						}
						if (func_719() == 0) {
							if (Global_2454304 > 0f || Global_2454304.f_1 > 0) {
								iLocal_213 = 1;
								return;
							}
						}
					}
					iVar1 = stats::_0xDEAAF77EB3687E97(2, &Global_2454182);
					if (iVar1 == 3) {
						if (func_719() == 0) {
							func_717(1);
						}
						if (func_724() == 0) {
							func_721(1);
						}
					}
					else {
						if (iVar1 == 4) {
							func_721(2);
						}
						if (func_719() == 0) {
							if (Global_2454182 > 0f || Global_2454182.f_1 > 0) {
								iLocal_213 = 1;
								return;
							}
						}
					}
					if (func_719() == 0) {
						func_717(3);
					}
					if (func_724() == 0) {
						func_721(3);
					}
					return;
				}
			}
			else if (bVar0) {
				if (stats::stat_load_pending(0)) {
				}
				else if (stats::stat_load_pending(1)) {
				}
				else if (stats::stat_load_pending(2)) {
				}
			}
		}
		else if (func_724() == 1) {
		}
	}
}

// Position - 0x212DC
void func_721(int iParam0) { Global_139178 = iParam0; }

// Position - 0x212EA
bool func_722(int iParam0) {
	bool bVar0;

	bVar0 = iParam0;
	if (!network::network_is_signed_online()) {
		if (bVar0) {
		}
		return false;
	}
	if (network::_0x67A5589628E0CFF6() == 0) {
		return false;
	}
	if (network::_network_are_ros_available() == 0) {
		return false;
	}
	if (func_723()) {
		return false;
	}
	if (stats::_0x4C89FE2BDEB3F169() == 1) {
		return true;
	}
	if (stats::_0xC6E0E2616A7576BB()) {
		return true;
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x21349
bool func_723() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (!Global_1312373[0] && !stats::stat_slot_is_loaded(0)) {
		if (!network::network_is_game_in_progress()) {
			iVar0 = stats::_0xDEAAF77EB3687E97(2, &Global_2454182);
			iVar1 = stats::_0xDEAAF77EB3687E97(0, &Global_2454304);
			iVar2 = stats::_0xDEAAF77EB3687E97(1, &Global_2454548);
			iVar3 = stats::_0xDEAAF77EB3687E97(3, &Global_2454426);
			if (iVar0 == 2 || iVar1 == 2 || iVar2 == 2 || iVar3 == 2) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x213C5
int func_724() { return Global_139178; }

// Position - 0x213D1
int func_725() { return -1; }

// Position - 0x213DA
void func_726(var uParam0) { Global_1318044 = uParam0; }

// Position - 0x213E8
void func_727(var uParam0) { Global_1318044 = uParam0; }

// Position - 0x213F6
void func_728(int iParam0) { Global_1318043 = iParam0; }

// Position - 0x21404
int func_729() {
	if (network::network_is_signed_in() == 0) {
		return 0;
	}
	if (network::network_is_signed_online() == 0) {
		return 0;
	}
	if (func_730() == 0) {
		return 0;
	}
	return 1;
}

// Position - 0x21431
int func_730() {
	if (gameplay::is_ps3_version() && network::network_have_online_privileges()) {
		return 1;
	}
	if (gameplay::is_xbox360_version() && network::network_have_online_privileges()) {
		return 1;
	}
	if (gameplay::is_orbis_version() && network::_0x1353F87E89946207() == 0 &&
		network::network_have_online_privileges()) {
		return 1;
	}
	if (gameplay::is_durango_version() && network::network_have_online_privileges()) {
		return 1;
	}
	if (gameplay::is_pc_version() && network::network_have_online_privileges()) {
		return 1;
	}
	return 0;
}

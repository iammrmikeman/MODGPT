#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
int iLocal_36 = 0;
int iLocal_37 = 0;
int iLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int iLocal_44 = 0;
int *iLocal_45 = NULL;
struct<485> Local_46 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 20, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, -1, -1, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 16
};
var uLocal_531 = 0;
var uLocal_532 = 0;
var uLocal_533 = 0;
var uLocal_534 = 0;
var uLocal_535 = 0;
var uLocal_536 = 0;
var uLocal_537 = 0;
var uLocal_538 = 0;
var uLocal_539 = 0;
var uLocal_540 = 0;
var uLocal_541 = 0;
var uLocal_542 = 0;
var uLocal_543 = 0;
var uLocal_544 = 0;
var uLocal_545 = 0;
var uLocal_546 = 0;
var uLocal_547 = 0;
var uLocal_548 = 0;
var uLocal_549 = 0;
var uLocal_550 = 0;
var uLocal_551 = 0;
var uLocal_552 = 0;
var uLocal_553 = 0;
var uLocal_554 = 0;
var uLocal_555 = 0;
var uLocal_556 = 0;
var uLocal_557 = 0;
var uLocal_558 = 0;
var uLocal_559 = 0;
var uLocal_560 = 0;
var uLocal_561 = 0;
var uLocal_562 = 0;
var uLocal_563 = 0;
var uLocal_564 = 0;
var uLocal_565 = 0;
var uLocal_566 = 0;
var uLocal_567 = 0;
var uLocal_568 = 0;
var uLocal_569 = 0;
var uLocal_570 = 0;
var uLocal_571 = 0;
var uLocal_572 = 0;
var uLocal_573 = 0;
var uLocal_574 = 0;
var uLocal_575 = 0;
var uLocal_576 = 0;
var uLocal_577 = 0;
var uLocal_578 = 0;
var uLocal_579 = 0;
var uLocal_580 = 0;
var uLocal_581 = 0;
var uLocal_582 = 0;
var uLocal_583 = 0;
var uLocal_584 = 0;
var uLocal_585 = 0;
var uLocal_586 = 0;
var uLocal_587 = 0;
var uLocal_588 = 0;
var uLocal_589 = 0;
var uLocal_590 = 0;
var uLocal_591 = 0;
var uLocal_592 = 0;
var uLocal_593 = 0;
var uLocal_594 = 0;
var uLocal_595 = 0;
var uLocal_596 = 0;
var uLocal_597 = 0;
var uLocal_598 = 0;
var uLocal_599 = 0;
var uLocal_600 = 0;
var uLocal_601 = 0;
var uLocal_602 = 0;
var uLocal_603 = 0;
var uLocal_604 = 0;
var uLocal_605 = 0;
var uLocal_606 = 0;
var uLocal_607 = 0;
var uLocal_608 = 0;
var uLocal_609 = 0;
var uLocal_610 = 0;
var uLocal_611 = 0;
var uLocal_612 = 0;
var uLocal_613 = 0;
var uLocal_614 = 0;
var uLocal_615 = 0;
var uLocal_616 = 0;
var uLocal_617 = 0;
var uLocal_618 = 0;
var uLocal_619 = 0;
var uLocal_620 = 0;
var uLocal_621 = 0;
var uLocal_622 = 0;
var uLocal_623 = 0;
var uLocal_624 = 0;
var uLocal_625 = 0;
var uLocal_626 = 0;
var uLocal_627 = 0;
var uLocal_628 = 0;
var uLocal_629 = 0;
var uLocal_630 = 0;
var uLocal_631 = 0;
var uLocal_632 = 0;
var uLocal_633 = 0;
var uLocal_634 = 0;
var uLocal_635 = 0;
var uLocal_636 = 0;
var uLocal_637 = 0;
var uLocal_638 = 0;
var uLocal_639 = 0;
var uLocal_640 = 0;
var uLocal_641 = 0;
var uLocal_642 = 0;
var uLocal_643 = 0;
var uLocal_644 = 0;
var uLocal_645 = 0;
var uLocal_646 = 0;
var uLocal_647 = 0;
var uLocal_648 = 0;
var uLocal_649 = 0;
var uLocal_650 = 0;
var uLocal_651 = 0;
var uLocal_652 = 0;
var uLocal_653 = 0;
var uLocal_654 = 0;
var uLocal_655 = 0;
var uLocal_656 = 0;
var uLocal_657 = 0;
var uLocal_658 = 0;
var uLocal_659 = 0;
var uLocal_660 = 0;
var uLocal_661 = 0;
var uLocal_662 = 0;
var uLocal_663 = 0;
var uLocal_664 = 0;
var uLocal_665 = 0;
var uLocal_666 = 0;
var uLocal_667 = 0;
var uLocal_668 = 0;
var uLocal_669 = 0;
var uLocal_670 = 0;
var uLocal_671 = 0;
var uLocal_672 = 0;
var uLocal_673 = 0;
var uLocal_674 = 0;
var uLocal_675 = 0;
var uLocal_676 = 0;
var uLocal_677 = 0;
var uLocal_678 = 0;
var uLocal_679 = 0;
var uLocal_680 = 0;
var uLocal_681 = 0;
var uLocal_682 = 0;
var uLocal_683 = 0;
var uLocal_684 = 0;
var uLocal_685 = 0;
var uLocal_686 = 0;
var uLocal_687 = 0;
var uLocal_688 = 0;
var uLocal_689 = 0;
var uLocal_690 = 0;
var uLocal_691 = 0;
var uLocal_692 = 0;
var uLocal_693 = 0;
var uLocal_694 = 0;
var uLocal_695 = 0;
var uLocal_696 = 0;
var uLocal_697 = 0;
var uLocal_698 = 0;
var uLocal_699 = 0;
var uLocal_700 = 0;
var uLocal_701 = 0;
var uLocal_702 = 0;
var uLocal_703 = 0;
var uLocal_704 = 0;
var uLocal_705 = 0;
var uLocal_706 = 0;
var uLocal_707 = 0;
var uLocal_708 = 0;
var uLocal_709 = 0;
var uLocal_710 = 0;
var uLocal_711 = 0;
var uLocal_712 = 0;
var uLocal_713 = 0;
var uLocal_714 = 0;
var uLocal_715 = 0;
var uLocal_716 = 0;
var uLocal_717 = 0;
var uLocal_718 = 0;
var uLocal_719 = 0;
var uLocal_720 = 0;
var uLocal_721 = 0;
var uLocal_722 = 0;
var uLocal_723 = 0;
var uLocal_724 = 0;
var uLocal_725 = 0;
var uLocal_726 = 0;
var uLocal_727 = 0;
var uLocal_728 = 0;
int iLocal_729 = 0;
int iLocal_730 = 0;
int iLocal_731 = 0;
int iLocal_732 = 0;
int iLocal_733 = 0;
int iLocal_734 = 0;
int iLocal_735 = 0;
int iLocal_736 = 0;
int iLocal_737 = 0;
int iLocal_738 = 0;
int iLocal_739 = 0;
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_36 = 202;
	iLocal_37 = 201;
	iLocal_38 = 24;
	iLocal_39 = 202;
	iLocal_40 = 25;
	iLocal_43 = -1;
	iLocal_45 = -1;
	iLocal_738 = -1;
	if (player::has_force_cleanup_occurred(82)) {
		func_235();
	}
	func_234(3);
	func_223(&Local_46.f_1, func_233(Global_87853[1 /*19*/], Global_87853[2 /*19*/]));
	func_222(&Local_46, 0);
	while (!func_221(4)) {
		if (!G_TextMessageConfig) {
			if (!func_220(86) && !func_219(14)) {
				func_208(&Local_46, 32f, 35f);
			}
			else if (gameplay::is_bit_set(Local_46.f_449, 0)) {
				func_206(&Local_46);
			}
			if (gameplay::is_bit_set(Local_46.f_449, 0)) {
				if (func_205() == 86) {
					while (!func_206(&Local_46)) {
						system::wait(0);
					}
				}
			}
			func_203(&Local_46);
			func_194();
			func_145();
			if (func_143(0) || gameplay::is_bit_set(Local_46.f_449, 2)) {
				func_67(&Local_46);
				func_4(&Local_46);
				func_3(&Local_46);
			}
		}
		if (script::_get_number_of_instances_of_script_with_name_hash(joaat("jewelry_heist")) > 0) {
			func_2();
		}
		system::wait(0);
	}
	func_1(3);
	func_235();
}

// Position - 0x185
int func_1(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
		return 1;
	}
	return 0;
}

// Position - 0x1DF
void func_2() {
	int iVar0;

	if (Global_69962) {
		return;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return;
	}
	iVar0 = system::round(1f + 1000f * system::timestep());
	Global_88044.f_8 += iVar0;
}

// Position - 0x221
void func_3(var *uParam0) {
	if (gameplay::is_bit_set(Global_87832, *uParam0)) {
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			gameplay::set_bit(&uParam0->f_449, 15);
			gameplay::set_bit(&uParam0->f_449, 16);
			gameplay::set_bit(&uParam0->f_449, 14);
			gameplay::clear_bit(&Global_87832, *uParam0);
		}
	}
}

// Position - 0x270
void func_4(var *uParam0) {
	int iVar0;
	int iVar1;

	iVar0 = func_65(func_66(*uParam0));
	if (iVar0 < 0 || iVar0 >= 5) {
		return;
	}
	iVar1 = iVar0;
	if (iVar1 != uParam0->f_464 && !(iVar1 == 2 && uParam0->f_464 == 4) &&
		!(*uParam0 == 1 && iVar1 == 3 && uParam0->f_464 == 4)) {
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			func_5(uParam0, iVar1, 0);
		}
		else {
			uParam0->f_464 = iVar1;
		}
	}
}

// Position - 0x2FE
void func_5(var *uParam0, int iParam1, int iParam2) {
	if (iParam1 != uParam0->f_464) {
		if (uParam0->f_680 == 0) {
			func_64(uParam0);
			uParam0->f_464 = iParam1;
			func_6(uParam0, iParam1, iParam2);
		}
	}
}

// Position - 0x330
void func_6(var *uParam0, int iParam1, int iParam2) {
	switch (iParam1) {
	case 0:
		func_63(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		break;

	case 1:
		func_63(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		uParam0->f_452 = -1;
		break;

	case 2:
		func_35(uParam0, uParam0->f_417, iParam2);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		uParam0->f_457 = gameplay::get_game_timer();
		break;

	case 3:
		func_17(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::clear_bit(&uParam0->f_449, 4);
		gameplay::set_bit(&uParam0->f_449, 9);
		uParam0->f_457 = gameplay::get_game_timer();
		break;

	case 4:
		func_13(&uParam0->f_1.f_108[0 /*4*/], 1);
		func_13(&uParam0->f_1.f_108[1 /*4*/], 1);
		Global_101700.f_1.f_6[*uParam0] = 1;
		ui::clear_help(0);
		func_11(uParam0, 0);
		func_63(uParam0);
		gameplay::set_bit(&uParam0->f_449, 5);
		gameplay::set_bit(&uParam0->f_449, 4);
		uParam0->f_457 = gameplay::get_game_timer();
		break;
	}
	func_7(uParam0);
}

// Position - 0x45D
void func_7(var *uParam0) {
	char *sVar0;
	char *sVar1;
	char *sVar2;
	char *sVar3;
	char *sVar4;
	char *sVar5;
	bool bVar6;

	sVar0 = controls::_0x80C2FD58D720C801(2, 13, 1);
	sVar1 = controls::_0x80C2FD58D720C801(2, 11, 1);
	sVar2 = controls::get_control_instructional_button(0, 32, 1);
	sVar3 = controls::_0x80C2FD58D720C801(0, 1, 1);
	sVar4 = controls::get_control_instructional_button(2, 201, 1);
	sVar5 = controls::get_control_instructional_button(2, 202, 1);
	if (controls::_is_input_disabled(2)) {
		sVar0 = controls::_0x80C2FD58D720C801(2, 6, 1);
		sVar1 = controls::_0x80C2FD58D720C801(2, 7, 1);
		sVar2 = controls::_0x80C2FD58D720C801(0, 29, 1);
	}
	bVar6 = func_10(1, *uParam0);
	graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_MAX_WIDTH");
	graphics::_push_scaleform_movie_function_parameter_float(0.6f);
	graphics::_pop_scaleform_movie_function_void();
	switch (uParam0->f_464) {
	case 0:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			if (bVar6) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar2);
				func_8("PB_H_ZOOM");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_9(sVar2);
				func_8("PB_H_ZOOM");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar5);
				func_8("PB_H_EXIT");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 1:
		graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 2:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
			graphics::_pop_scaleform_movie_function_void();
			if (*uParam0 == 2) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_9(sVar0);
				func_8("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar4);
				func_8("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(3);
				func_9(sVar0);
				func_8("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar5);
				func_8("PB_H_UNDO");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar4);
				func_8("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 3:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			if (gameplay::is_bit_set(uParam0->f_449, 9)) {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar1);
				func_8("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
			}
			else {
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(2);
				func_9(sVar1);
				func_8("PB_H_SELCT");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				func_9(sVar3);
				func_8("PB_H_LOOK");
				graphics::_pop_scaleform_movie_function_void();
				graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(0);
				func_9(sVar4);
				func_8("PB_H_TRIG");
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;

	case 4:
		if (gameplay::is_bit_set(uParam0->f_449, 2)) {
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT_EMPTY");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(3);
			func_9(sVar2);
			func_8("PB_H_ZOOM");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(2);
			func_9(sVar3);
			func_8("PB_H_LOOK");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(1);
			func_9(sVar5);
			func_8("PB_H_UNDO");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			func_9(sVar4);
			func_8("PB_H_CONF");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_414, "DRAW_INSTRUCTIONAL_BUTTONS");
			graphics::_push_scaleform_movie_function_parameter_bool(0);
			graphics::_pop_scaleform_movie_function_void();
		}
		break;
	}
}

// Position - 0x939
void func_8(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x94B
void func_9(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x959
bool func_10(int iParam0, int iParam1) {
	var uVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return false;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return false;
	}
	uVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	return uVar0;
}

// Position - 0x9A6
void func_11(var *uParam0, int iParam1) {
	if (iParam1) {
		gameplay::set_bit(&uParam0->f_449, 18);
		if (!func_12(&uParam0->f_1.f_20[0 /*4*/]) && !func_12(&uParam0->f_1.f_20[1 /*4*/]) &&
			!func_12(&uParam0->f_1.f_108[0 /*4*/]) && !func_12(&uParam0->f_1.f_108[1 /*4*/])) {
			ui::clear_help(0);
		}
	}
	else {
		gameplay::clear_bit(&uParam0->f_449, 18);
	}
}

// Position - 0xA1B
bool func_12(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0xA2E
void func_13(char *sParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (Global_100342 && iParam1) {
		if (func_12(sParam0) && !ui::is_help_message_fading_out()) {
			ui::clear_help(0);
		}
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(sParam0, &Global_101700.f_19369[iVar0 /*16*/])) {
			iVar1 = iVar0;
			while (iVar1 <= Global_101700.f_19369.f_145 - 2) {
				func_16(iVar1, iVar1 + 1);
				iVar1++;
			}
			func_15(Global_101700.f_19369.f_145 - 1);
			Global_101700.f_19369.f_145--;
			func_14();
			return;
		}
		iVar0++;
	}
}

// Position - 0xADB
void func_14() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < 3) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 0)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[0]) {
				Global_101700.f_19369.f_146[0] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 1)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[1]) {
				Global_101700.f_19369.f_146[1] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		if (gameplay::is_bit_set(Global_101700.f_19369[iVar0 /*16*/].f_11, 2)) {
			if (Global_101700.f_19369[iVar0 /*16*/].f_12 > Global_101700.f_19369.f_146[2]) {
				Global_101700.f_19369.f_146[2] = Global_101700.f_19369[iVar0 /*16*/].f_12;
			}
		}
		iVar0++;
	}
}

// Position - 0xBFB
void func_15(int iParam0) {
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/], "", 16);
	StringCopy(&Global_101700.f_19369[iParam0 /*16*/].f_4, "", 16);
	Global_101700.f_19369[iParam0 /*16*/].f_8 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = -1;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = 0;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = 0;
}

// Position - 0xC95
void func_16(int iParam0, int iParam1) {
	Global_101700.f_19369[iParam0 /*16*/] = {Global_101700.f_19369[iParam1 /*16*/]};
	Global_101700.f_19369[iParam0 /*16*/].f_4 = {Global_101700.f_19369[iParam1 /*16*/].f_4};
	Global_101700.f_19369[iParam0 /*16*/].f_8 = Global_101700.f_19369[iParam1 /*16*/].f_8;
	Global_101700.f_19369[iParam0 /*16*/].f_10 = Global_101700.f_19369[iParam1 /*16*/].f_10;
	Global_101700.f_19369[iParam0 /*16*/].f_9 = Global_101700.f_19369[iParam1 /*16*/].f_9;
	Global_101700.f_19369[iParam0 /*16*/].f_11 = Global_101700.f_19369[iParam1 /*16*/].f_11;
	Global_101700.f_19369[iParam0 /*16*/].f_12 = Global_101700.f_19369[iParam1 /*16*/].f_12;
	Global_101700.f_19369[iParam0 /*16*/].f_13 = Global_101700.f_19369[iParam1 /*16*/].f_13;
	Global_101700.f_19369[iParam0 /*16*/].f_14 = Global_101700.f_19369[iParam1 /*16*/].f_14;
	Global_101700.f_19369[iParam0 /*16*/].f_15 = Global_101700.f_19369[iParam1 /*16*/].f_15;
}

// Position - 0xDA5
void func_17(var *uParam0) {
	int iVar0;
	struct<2> Var1;

	func_34(uParam0);
	func_31(uParam0);
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = func_65(func_30(*uParam0));
	if (iVar0 != 0) {
		if (iVar0 == func_29(*uParam0, 0)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(8);
			graphics::_pop_scaleform_movie_function_void();
		}
		else if (iVar0 == func_29(*uParam0, 1)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
		}
	}
	Var1 = uParam0->f_1.f_16 + uParam0->f_1.f_18;
	Var1.f_1 = uParam0->f_1.f_16.f_1 + uParam0->f_1.f_18.f_1;
	func_25(uParam0, &Var1, uParam0->f_1.f_10);
	func_23(uParam0, 1, 1);
	func_11(uParam0, 0);
	func_18(uParam0);
}

// Position - 0xE78
void func_18(var *uParam0) {
	int iVar0;

	if (gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!gameplay::is_bit_set(uParam0->f_449, 18)) {
			switch (uParam0->f_464) {
			case 3:
				if (!Global_101700.f_1[*uParam0]) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_20[0 /*4*/], "")) {
						func_21(&uParam0->f_1.f_20[0 /*4*/], 3, 0, -1, 10000, 7, 0, 0, 0);
					}
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_20[1 /*4*/], "")) {
						func_21(&uParam0->f_1.f_20[1 /*4*/], 3, 1000, -1, 10000, 7, 0, 0, 0);
					}
					Global_101700.f_1[*uParam0] = 1;
				}
				else if (func_20() && !ui::is_help_message_being_displayed()) {
					if (!gameplay::is_bit_set(uParam0->f_449, 11) && !gameplay::is_bit_set(uParam0->f_449, 10) &&
						!func_19() && uParam0->f_483 == 0) {
						ui::begin_text_command_display_help("PB_H_CHOICE");
						ui::end_text_command_display_help(0, 1, 0, -1);
					}
				}
				break;

			case 2:
				if (!Global_101700.f_1.f_6[*uParam0]) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_108[0 /*4*/], "")) {
						func_21(&uParam0->f_1.f_108[0 /*4*/], 3, 0, -1, 10000, 7, 0, 0, 0);
					}
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_108[1 /*4*/], "")) {
						func_21(&uParam0->f_1.f_108[1 /*4*/], 3, 1000, -1, 10000, 7, 0, 0, 0);
					}
					Global_101700.f_1.f_6[*uParam0] = 1;
				}
				else if (func_20() && !ui::is_help_message_being_displayed()) {
					if (!gameplay::is_bit_set(uParam0->f_449, 10)) {
						if (!func_12("PB_H_GUNM") && !func_12("PB_H_HACK") && !func_12("PB_H_DRIV")) {
							iVar0 = func_65(func_30(*uParam0));
							if (uParam0->f_417 < 5) {
								if (!gameplay::is_bit_set(uParam0->f_449, 11) &&
									!gameplay::is_bit_set(uParam0->f_449, 10) && !func_19() && uParam0->f_483 == 0) {
									switch (Global_87853[iVar0 /*19*/].f_1[uParam0->f_417]) {
									case 1:
										ui::begin_text_command_display_help("PB_H_GUNM");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;

									case 2:
										ui::begin_text_command_display_help("PB_H_HACK");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;

									case 3:
										ui::begin_text_command_display_help("PB_H_DRIV");
										ui::end_text_command_display_help(0, 1, 0, -1);
										break;
									}
								}
							}
						}
					}
				}
				break;
			}
		}
	}
}

// Position - 0x10ED
int func_19() {
	if (Global_15745 != 0 || audio::is_scripted_conversation_ongoing()) {
		return 1;
	}
	return 0;
}

// Position - 0x110F
bool func_20() {
	if (Global_101700.f_19369.f_145 > 0) {
		return false;
	}
	return true;
}

// Position - 0x112C
void func_21(char *sParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8) {
	func_22(sParam0, "", iParam1, iParam2, iParam3, iParam4, iParam5, iParam6, iParam7, iParam8);
}

// Position - 0x114D
void func_22(char *sParam0, char *sParam1, var uParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			 int iParam8, var uParam9) {
	int iVar0;

	if (gameplay::are_strings_equal(sParam0, "")) {
		return;
	}
	if (iParam3 < 0) {
		return;
	}
	if (iParam5 < 500 && iParam5 != -1) {
		return;
	}
	if (iParam4 < 0 && iParam4 != -1) {
		return;
	}
	if (iParam6 < 1 || iParam6 > 7) {
		return;
	}
	if (iParam7 == 235) {
		return;
	}
	if (iParam8 == 235) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		if (gameplay::are_strings_equal(&Global_101700.f_19369[iVar0 /*16*/], sParam0)) {
			return;
		}
		iVar0++;
	}
	if (Global_101700.f_19369.f_145 < 9) {
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/], sParam0, 16);
		StringCopy(&Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_4, sParam1, 16);
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_8 = gameplay::get_game_timer() + iParam3;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_9 = iParam5;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_11 = iParam6;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_12 = uParam2;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_13 = iParam7;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_14 = iParam8;
		Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_15 = uParam9;
		if (iParam4 != -1) {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 =
				gameplay::get_game_timer() + iParam3 + iParam4;
		}
		else {
			Global_101700.f_19369[Global_101700.f_19369.f_145 /*16*/].f_10 = -1;
		}
		Global_101700.f_19369.f_145++;
		func_14();
	}
}

// Position - 0x1320
void func_23(var *uParam0, int iParam1, int iParam2) {
	if (!gameplay::is_bit_set(uParam0->f_1.f_303, iParam1)) {
		if (!gameplay::are_strings_equal(&uParam0->f_1.f_280[iParam1 /*2*/], "")) {
			func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_280[iParam1 /*2*/], iParam2);
			gameplay::set_bit(&uParam0->f_1.f_303, iParam1);
		}
	}
}

// Position - 0x137A
void func_24(var *uParam0, struct<2> Param1, struct<2> Param3, int iParam5) {
	if (uParam0->f_483 == 3) {
		return;
	}
	if (!gameplay::is_string_null_or_empty(&Param3)) {
		uParam0->f_467[uParam0->f_483 /*5*/] = {Param1};
		uParam0->f_467[uParam0->f_483 /*5*/].f_2 = {Param3};
		uParam0->f_467[uParam0->f_483 /*5*/].f_4 = iParam5;
		uParam0->f_483++;
	}
}

// Position - 0x13DA
void func_25(var *uParam0, var *uParam1, float fParam2) {
	vector3 vVar0;

	uParam0->f_411 = *uParam1;
	uParam0->f_411.f_1 = uParam1->f_1;
	uParam0->f_454 = gameplay::get_game_timer() + 1000;
	vVar0 = {func_27(uParam0, &uParam0->f_411)};
	func_26(&uParam0->f_649, vVar0, fParam2);
}

// Position - 0x141F
void func_26(var *uParam0, vector3 vParam1, float fParam4) {
	uParam0->f_11 = {vParam1};
	if (fParam4 != -1f) {
		uParam0->f_7 = fParam4;
	}
}

// Position - 0x143E
Vector3 func_27(var *uParam0, var *uParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	vector3 vVar7;
	float fVar10;
	float fVar11;
	float fVar12;
	float fVar13;
	float fVar14;
	float fVar15;
	float fVar16;

	fVar0 = uParam0->f_1.f_4;
	fVar1 = uParam0->f_1.f_5;
	func_28(uParam0, uParam1, &fVar2, &fVar3);
	fVar4 = fVar0 * (fVar2 - 0.5f);
	fVar5 = -fVar1 * (fVar3 - 0.5f);
	fVar6 = uParam0->f_404;
	vVar7 = {uParam0->f_401};
	vVar7 = {vVar7 + Vector(fVar5, fVar4 * system::cos(90f - fVar6), fVar4 * system::sin(90f - fVar6))};
	fVar10 = fVar4;
	fVar11 = gameplay::atan(fVar10 / uParam0->f_1.f_8);
	fVar12 = uParam0->f_401.f_2 - uParam0->f_649.f_1.f_2;
	fVar13 = vVar7.z - uParam0->f_649.f_1.f_2;
	fVar14 = fVar13 - fVar12;
	fVar15 = gameplay::atan(fVar14 / uParam0->f_1.f_8);
	fVar16 = fVar11 * 3f / 18f;
	return fVar15 * 0.95f, fVar16, -fVar11 * 0.85f;
}

// Position - 0x1523
void func_28(var *uParam0, var *uParam1, float *fParam2, float *fParam3) {
	int iVar0;
	int iVar1;

	iVar0 = uParam0->f_1.f_2;
	iVar1 = uParam0->f_1.f_3;
	if (*uParam1 < 0 || *uParam1 > iVar0) {
		return;
	}
	if (uParam1->f_1 < 0 || uParam1->f_1 > iVar1) {
		return;
	}
	*fParam2 = system::to_float(*uParam1) / system::to_float(iVar0);
	*fParam3 = system::to_float(uParam1->f_1) / system::to_float(iVar1);
}

// Position - 0x158E
int func_29(int iParam0, int iParam1) {
	switch (iParam0) {
	case 0:
		switch (iParam1) {
		case 0: return 2;

		case 1: return 1;

		default: break;
		}
		break;

	case 1:
		switch (iParam1) {
		case 0: return 3;

		case 1: return 4;

		default: break;
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return 5;

		default: break;
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: return 6;

		case 1: return 7;

		default: break;
		}
		break;

	case 4:
		switch (iParam1) {
		case 0: return 8;

		case 1: return 9;

		default: break;
		}
		break;
	}
	return 0;
}

// Position - 0x1674
int func_30(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0: iVar0 = 7; break;

	case 1: iVar0 = 8; break;

	case 2: iVar0 = 9; break;

	case 3: iVar0 = 10; break;

	case 4: iVar0 = 11; break;
	}
	return iVar0;
}

// Position - 0x16C5
void func_31(var *uParam0) {
	int iVar0;

	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_push_scaleform_movie_function_parameter_int(1);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_16));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_16.f_1));
	graphics::_pop_scaleform_movie_function_void();
	func_33(uParam0);
	switch (*uParam0) {
	case 0:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(2);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 1:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(3);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(4);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 3:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(6);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(7);
		graphics::_pop_scaleform_movie_function_void();
		break;

	case 4:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(0);
		graphics::_push_scaleform_movie_function_parameter_int(8);
		graphics::_pop_scaleform_movie_function_void();
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_push_scaleform_movie_function_parameter_int(1);
		graphics::_push_scaleform_movie_function_parameter_int(9);
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_push_scaleform_movie_function_parameter_bool(func_32(*uParam0, uParam0->f_1.f_29));
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = func_65(func_30(*uParam0));
	if (iVar0 != 0) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
		graphics::_pop_scaleform_movie_function_void();
		if (iVar0 == func_29(*uParam0, 0)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(8);
			graphics::_pop_scaleform_movie_function_void();
		}
		else if (iVar0 == func_29(*uParam0, 1)) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
		}
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(99);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0x1932
bool func_32(int iParam0, int iParam1) { return gameplay::is_bit_set(Global_101700.f_1.f_120[iParam0], iParam1); }

// Position - 0x194C
void func_33(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_LABELS");
	func_8("H_CRW_NAME");
	func_8("H_CRW_TYPE");
	func_8("H_CRW_SKILLS");
	switch (*uParam0) {
	case 0: func_8("H_LBL_JWL"); break;

	case 1: func_8("H_LBL_DOC"); break;

	case 2: func_8("H_LBL_RUR"); break;

	case 3: func_8("H_LBL_AGN"); break;

	case 4:
		func_8("H_LBL_FA");
		func_8("H_LBL_FB");
		break;
	}
	if (*uParam0 != 1) {
		func_8("H_LBL_CRW");
	}
	func_8("H_LBL_TODO");
	if (*uParam0 != 2) {
		func_8("H_LBL_APP");
	}
	switch (*uParam0) {
	case 0:
		func_8("H_LBL_J1");
		func_8("H_LBL_J2");
		func_8("H_LBL_J3");
		func_8("H_LBL_J4");
		func_8("HC_J_IMPACT");
		func_8("HC_J_STEALTH");
		break;

	case 1:
		func_8("HC_D_BLOW_UP");
		func_8("HC_D_DEEP_SEA");
		break;

	case 2:
		func_8("H_LBL_R1");
		func_8("H_LBL_R2");
		func_8("H_LBL_R3");
		func_8("H_LBL_R4");
		func_8("H_LBL_R5");
		func_8("H_LBL_R6");
		func_8("H_LBL_R7");
		func_8("H_LBL_R8");
		func_8("H_LBL_R9");
		func_8("H_LBL_R10");
		func_8("H_LBL_R11");
		func_8("H_LBL_R12");
		break;

	case 3:
		func_8("H_LBL_A1");
		func_8("H_LBL_A2");
		func_8("H_LBL_A3");
		func_8("H_LBL_A4");
		func_8("H_LBL_A5");
		func_8("HC_A_FIRETRUCK");
		func_8("HC_A_HELICOPTER");
		break;

	case 4:
		func_8("H_LBL_F1");
		func_8("H_LBL_F2");
		func_8("H_LBL_F3");
		func_8("H_LBL_F4");
		func_8("H_LBL_F5");
		func_8("HC_F_TRAFFCONT");
		func_8("HC_F_HELI");
		break;
	}
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1B4E
void func_34(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1B70
void func_35(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam1 < 0 || iParam1 >= uParam0->f_1.f_96) {
		return;
	}
	func_23(uParam0, 2, 1);
	iVar0 = func_65(func_30(*uParam0));
	iVar1 = Global_87853[iVar0 /*19*/].f_1[iParam1];
	switch (iVar1) {
	case 1: func_62(uParam0, iVar0, 1); break;

	case 2: func_62(uParam0, iVar0, 3); break;

	case 3: func_62(uParam0, iVar0, 2); break;
	}
	func_61(uParam0, uParam0->f_417);
	func_36(uParam0, uParam0->f_417);
	uParam0->f_450 = iParam1;
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_bool(1);
	graphics::_pop_scaleform_movie_function_void();
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
	func_25(uParam0, &uParam0->f_1.f_97[iParam1 /*2*/], uParam0->f_1.f_10);
	if (iParam2 != 0) {
		iVar2 = 0;
		while (uParam0->f_418[iVar2] != iParam2) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
			graphics::_push_scaleform_movie_function_parameter_int(9);
			graphics::_pop_scaleform_movie_function_void();
			iVar2++;
			if (iVar2 > 7) {
				return;
			}
		}
	}
	func_11(uParam0, 0);
	func_18(uParam0);
}

// Position - 0x1CA6
void func_36(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;

	iVar0 = func_30(*uParam0);
	iVar1 = func_65(iVar0);
	iVar2 = Global_87853[iVar1 /*19*/].f_1[iParam1];
	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_push_scaleform_movie_function_parameter_int(0);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_97[iParam1 /*2*/]));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_97[iParam1 /*2*/].f_1));
	graphics::_pop_scaleform_movie_function_void();
	func_33(uParam0);
	iVar3 = 0;
	if (Global_101700.f_1.f_12[iVar1 /*6*/][iParam1] != 0) {
		iVar4 = Global_101700.f_1.f_12[iVar1 /*6*/][iParam1];
		func_41(uParam0->f_413, iVar4, iParam1, iVar3, iVar4);
	}
	else {
		iVar5 = 0;
		while (iVar5 < 14) {
			iVar6 = iVar5;
			if (func_40(iVar6) == iVar2) {
				if (func_39(iVar6)) {
					if (!func_38(iVar6)) {
						if (!func_37(uParam0, iVar6)) {
							if (!(iVar6 == 11 && *uParam0 == 3)) {
								func_41(uParam0->f_413, iVar6, iParam1, iVar3, iVar5);
								uParam0->f_418[iVar3] = iVar6;
								iVar3++;
							}
						}
					}
				}
			}
			iVar5++;
		}
	}
	if (Global_101700.f_1.f_12[iVar1 /*6*/][iParam1] != 0) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(iParam1);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	else {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(iParam1);
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1E30
bool func_37(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_65(func_30(*uParam0));
	iVar1 = 0;
	while (iVar1 < uParam0->f_417) {
		if (Global_101700.f_1.f_12[iVar0 /*6*/][iVar1] == iParam1) {
			return true;
		}
		iVar1++;
	}
	return false;
}

// Position - 0x1E75
bool func_38(int iParam0) { return gameplay::is_bit_set(Global_101700.f_1.f_118, iParam0); }

// Position - 0x1E8B
bool func_39(int iParam0) { return gameplay::is_bit_set(Global_101700.f_1.f_116, iParam0); }

// Position - 0x1EA1
int func_40(int iParam0) { return Global_87699[iParam0 /*5*/]; }

// Position - 0x1EB1
void func_41(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	graphics::_push_scaleform_movie_function(iParam0, "SET_DATA_SLOT");
	graphics::_push_scaleform_movie_function_parameter_int(iParam2);
	graphics::_push_scaleform_movie_function_parameter_int(iParam3);
	graphics::_push_scaleform_movie_function_parameter_int(iParam4);
	func_8(func_59(iParam1));
	func_8(func_58(iParam1));
	switch (func_40(iParam1)) {
	case 1:
		func_8(func_57(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_54(iParam1, 0));
		func_8(func_57(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_54(iParam1, 1));
		func_8(func_57(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_54(iParam1, 2));
		func_8(func_57(3));
		graphics::_push_scaleform_movie_function_parameter_int(func_54(iParam1, 3));
		break;

	case 2:
		func_8(func_53(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_50(iParam1, 0));
		func_8(func_53(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_50(iParam1, 1));
		func_8(func_53(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_50(iParam1, 2));
		break;

	case 3:
		func_8(func_48(0));
		graphics::_push_scaleform_movie_function_parameter_int(func_43(iParam1, 0));
		func_8(func_48(1));
		graphics::_push_scaleform_movie_function_parameter_int(func_43(iParam1, 1));
		func_8(func_48(2));
		graphics::_push_scaleform_movie_function_parameter_int(func_43(iParam1, 2));
		break;
	}
	func_8("H_CRW_CUT");
	graphics::_push_scaleform_movie_function_parameter_int(func_42(iParam1));
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x1FED
var func_42(int iParam0) { return Global_87699[iParam0 /*5*/].f_1; }

// Position - 0x1FFF
var func_43(int iParam0, int iParam1) {
	return system::round(system::to_float(func_45(iParam0, iParam1)) / system::to_float(func_44(iParam1)) * 100f);
}

// Position - 0x2028
int func_44(int iParam0) {
	switch (iParam0) {
	case 0: return 100;

	case 1: return 100;

	case 2: return 100;
	}
	return 0;
}

// Position - 0x2062
int func_45(int iParam0, int iParam1) {
	if (func_40(iParam0) != 3) {
		return -1;
	}
	return func_46(iParam0, iParam1);
}

// Position - 0x2080
int func_46(int iParam0, int iParam1) {
	return func_47(iParam1, Global_101700.f_1.f_73[iParam0 /*3*/].f_1, Global_101700.f_1.f_73[iParam0 /*3*/].f_2);
}

// Position - 0x20AA
int func_47(int iParam0, int iParam1, int iParam2) {
	switch (iParam0) {
	case 0:
	case 1: return system::shift_right(iParam1, 15 * iParam0) & 32767;

	case 2:
	case 3: return system::shift_right(iParam2, 15 * (iParam0 - 2)) & 32767;
	}
	return -1;
}

// Position - 0x20FE
char *func_48(int iParam0) { return func_49(3, iParam0); }

// Position - 0x210D
char *func_49(int iParam0, int iParam1) {
	switch (iParam0) {
	case 1:
		switch (iParam1) {
		case 0: return "HC_STA_G1";

		case 1: return "HC_STA_G2";

		case 2: return "HC_STA_G3";

		case 3: return "HC_STA_G4";
		}
		break;

	case 2:
		switch (iParam1) {
		case 0: return "HC_STA_H1";

		case 1: return "HC_STA_H2";

		case 2: return "HC_STA_H3";
		}
		break;

	case 3:
		switch (iParam1) {
		case 0: return "HC_STA_D1";

		case 1: return "HC_STA_D2";

		case 2: return "HC_STA_D3";
		}
		break;
	}
	return "ERROR!";
}

// Position - 0x21F0
var func_50(int iParam0, int iParam1) {
	return system::round(system::to_float(func_52(iParam0, iParam1)) / system::to_float(func_51(iParam1)) * 100f);
}

// Position - 0x2219
int func_51(int iParam0) {
	switch (iParam0) {
	case 0: return 100;

	case 1: return 100;

	case 2: return 100;
	}
	return 0;
}

// Position - 0x2253
int func_52(int iParam0, int iParam1) {
	if (func_40(iParam0) != 2) {
		return -1;
	}
	return func_46(iParam0, iParam1);
}

// Position - 0x2271
char *func_53(int iParam0) { return func_49(2, iParam0); }

// Position - 0x2280
var func_54(int iParam0, int iParam1) {
	return system::round(system::to_float(func_56(iParam0, iParam1)) / system::to_float(func_55(iParam1)) * 100f);
}

// Position - 0x22A9
int func_55(int iParam0) {
	switch (iParam0) {
	case 0: return 1000;

	case 1: return 100;

	case 2: return 100;

	case 3: return 100;
	}
	return 0;
}

// Position - 0x22F2
int func_56(int iParam0, int iParam1) {
	if (func_40(iParam0) != 1) {
		return -1;
	}
	return func_46(iParam0, iParam1);
}

// Position - 0x2310
char *func_57(int iParam0) { return func_49(1, iParam0); }

// Position - 0x231F
char *func_58(int iParam0) {
	switch (Global_87699[iParam0 /*5*/]) {
	case 1: return "HC_TYPE_G";

	case 2: return "HC_TYPE_H";

	case 3: return "HC_TYPE_D";
	}
	return "ERROR!";
}

// Position - 0x2368
char *func_59(int iParam0) { return func_60(iParam0); }

// Position - 0x2376
char *func_60(int iParam0) {
	switch (iParam0) {
	case 1: return "HC_N_GUS";

	case 2: return "HC_N_KAR";

	case 10: return "HC_N_PAC";

	case 11: return "HC_N_CHE";

	case 3: return "HC_N_HUG";

	case 4: return "HC_N_NOR";

	case 5: return "HC_N_DAR";

	case 6: return "HC_N_PAI";

	case 7: return "HC_N_CHR";

	case 12: return "HC_N_RIC";

	case 8: return "HC_N_EDD";

	case 13: return "HC_N_TAL";

	case 9: return "HC_N_KRM";
	}
	return "ERROR!";
}

// Position - 0x2459
void func_61(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(iParam1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0x2478
void func_62(var *uParam0, int iParam1, int iParam2) {
	int iVar0;

	if (!gameplay::is_bit_set(Global_87853[iParam1 /*19*/].f_18, iParam2)) {
		if (!gameplay::are_strings_equal(&Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/], "")) {
			func_24(uParam0, uParam0->f_1.f_276, Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/], 1);
			gameplay::set_bit(&Global_87853[iParam1 /*19*/].f_18, iParam2);
			iVar0 = 0;
			while (iVar0 < 10) {
				if (gameplay::are_strings_equal(&Global_87853[iParam1 /*19*/].f_7[iParam2 /*2*/],
												&Global_87853[iVar0 /*19*/].f_7[iParam2 /*2*/])) {
					gameplay::set_bit(&Global_87853[iVar0 /*19*/].f_18, iParam2);
				}
				iVar0++;
			}
		}
	}
}

// Position - 0x2523
void func_63(var *uParam0) {
	func_25(uParam0, &uParam0->f_1.f_12, 45f);
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(99);
	graphics::_pop_scaleform_movie_function_void();
	func_18(uParam0);
}

// Position - 0x2559
void func_64(var *uParam0) {
	switch (uParam0->f_464) {
	case 1:
	case 2:
	case 3:
		graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(99);
		graphics::_pop_scaleform_movie_function_void();
		break;
	}
	ui::clear_help(0);
}

// Position - 0x259C
int func_65(int iParam0) {
	if (iParam0 == 13 || iParam0 == -1) {
		return 0;
	}
	return Global_101700.f_8044.f_99.f_205[iParam0];
}

// Position - 0x25C9
int func_66(int iParam0) {
	switch (iParam0) {
	case 0: return 2;

	case 1: return 3;

	case 2: return 4;

	case 3: return 5;

	case 4: return 6;
	}
	return -1;
}

// Position - 0x261A
void func_67(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		func_68(uParam0);
	}
}

// Position - 0x2635
void func_68(var *uParam0) {
	bool bVar0;
	vector3 vVar1;
	float fVar4;
	float fVar5;
	float fVar6;
	bool bVar7;

	bVar0 = false;
	if (!gameplay::is_bit_set(uParam0->f_449, 2)) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (!func_142(0)) {
				if (func_133(8)) {
					if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), uParam0->f_401) < 4f) {
						vVar1 = {uParam0->f_401 - entity::get_entity_coords(player::player_ped_id(), 1)};
						fVar4 = gameplay::get_heading_from_vector_2d(vVar1.x, vVar1.y);
						fVar5 = gameplay::absf(uParam0->f_404 - fVar4);
						if (fVar5 <= 70f) {
							bVar0 = true;
						}
						else {
							fVar6 = uParam0->f_404;
							if (fVar6 > 180f) {
								fVar6 -= 360f;
							}
							else if (fVar6 < -180f) {
								fVar6 += 360f;
							}
							if (fVar6 - fVar4 < fVar5) {
								fVar5 = gameplay::absf(fVar6 - fVar4);
							}
							if (fVar5 <= 70f) {
								bVar0 = true;
							}
							else {
								if (fVar4 > 180f) {
									fVar4 -= 360f;
								}
								else if (fVar4 < -180f) {
									fVar4 += 360f;
								}
								if (uParam0->f_404 - fVar4 < fVar5) {
									fVar5 = gameplay::absf(uParam0->f_404 - fVar4);
								}
								if (fVar5 <= 70f) {
									bVar0 = true;
								}
								else {
									if (fVar6 - fVar4 < fVar5) {
										fVar5 = gameplay::absf(fVar6 - fVar4);
									}
									if (fVar5 <= 70f) {
										bVar0 = true;
									}
								}
							}
						}
					}
				}
			}
		}
		if (bVar0) {
			if (uParam0->f_451 == -1) {
				func_132(&uParam0->f_451, 3, "PB_H_ENT", 0, 0, 0, 0);
			}
			else if (func_131(uParam0->f_451, 1)) {
				func_129(&uParam0->f_451);
				func_115(uParam0);
			}
		}
		else if (uParam0->f_451 != -1) {
			func_129(&uParam0->f_451);
		}
	}
	else {
		bVar7 = func_10(1, *uParam0);
		func_77(uParam0);
		if (!bVar7 && uParam0->f_453 > 15 &&
				(controls::is_control_just_pressed(2, iLocal_36) || controls::is_control_just_pressed(2, 238)) ||
			gameplay::is_bit_set(uParam0->f_449, 8)) {
			gameplay::clear_bit(&uParam0->f_449, 8);
			func_69(uParam0, 0);
		}
	}
}

// Position - 0x2854
void func_69(var *uParam0, int iParam1) {
	vector3 vVar0;
	int iVar3;

	uParam0->f_453 = 0;
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		entity::freeze_entity_position(player::player_ped_id(), 0);
		if (!iParam1) {
			vVar0 = {uParam0->f_401};
			vVar0 = {vVar0 +
					 Vector(0f, 1f * system::cos(180f - uParam0->f_404), 1f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
			entity::set_entity_coords(player::player_ped_id(), vVar0, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			cam::set_gameplay_cam_relative_heading(0f);
			cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			ped::force_ped_motion_state(player::player_ped_id(), -1871534317, 0, 0, 0);
			ped::_0x2208438012482A1A(player::player_ped_id(), 1, 0);
		}
	}
	if (player::is_player_playing(player::player_id())) {
		player::set_player_control(player::player_id(), 1, 134);
	}
	ui::display_radar(1);
	func_72(0);
	func_71();
	ui::_0xE1CD1E48E025E661();
	ui::reset_hud_component_values(17);
	graphics::_0xD39D13C9FEBF0511(0);
	func_70(&uParam0->f_649, 0, 1);
	func_13(&uParam0->f_1.f_20[0 /*4*/], 1);
	func_13(&uParam0->f_1.f_20[1 /*4*/], 1);
	func_13(&uParam0->f_1.f_108[0 /*4*/], 1);
	func_13(&uParam0->f_1.f_108[1 /*4*/], 1);
	ui::clear_help(1);
	while (ui::is_help_message_being_displayed()) {
		ui::clear_help(1);
		system::wait(0);
	}
	iVar3 = interior::get_interior_at_coords(uParam0->f_401);
	if (iVar3 != 0) {
		interior::unpin_interior(iVar3);
	}
	audio::unregister_script_with_audio();
	func_64(uParam0);
	gameplay::clear_bit(&uParam0->f_449, 7);
	gameplay::clear_bit(&uParam0->f_449, 2);
	G_DisableMessagesAndCalls3 = 0;
}

// Position - 0x29D8
void func_70(var *uParam0, int iParam1, int iParam2) {
	if (cam::does_cam_exist(*uParam0)) {
		if (iParam2) {
			cam::render_script_cams(0, 0, 3000, 1, iParam1, 0);
		}
		if (cam::is_cam_active(*uParam0)) {
			cam::set_cam_active(*uParam0, 0);
		}
		cam::destroy_cam(*uParam0, iParam1);
	}
	if (uParam0->f_23) {
		ui::unlock_minimap_angle();
		uParam0->f_23 = 0;
	}
	uParam0->f_1 = {0f, 0f, 0f};
	uParam0->f_4 = {0f, 0f, 0f};
	uParam0->f_7 = 0f;
	uParam0->f_20 = 0;
	uParam0->f_21 = 0;
	uParam0->f_22 = 0;
	uParam0->f_8 = {0f, 0f, 0f};
	uParam0->f_11 = {0f, 0f, 0f};
	uParam0->f_14 = {0f, 0f, 0f};
	uParam0->f_17 = 0f;
	uParam0->f_18 = 0f;
}

// Position - 0x2A72
void func_71() { Global_17151.f_5 = 0; }

// Position - 0x2A80
void func_72(int iParam0) {
	if (iParam0) {
		func_76();
		if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
			gameplay::set_bit(&G_SleepModeOffOn11, 16);
		}
		Global_14443.f_1 = 1;
		if (func_142(0)) {
			func_73(0);
		}
	}
	else if (Global_14443.f_1 == 1) {
		if (Global_14443.f_1 != 0) {
			Global_14443.f_1 = 3;
		}
	}
}

// Position - 0x2AE3
void func_73(int iParam0) {
	if (Global_14604) {
		func_75(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_74()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x2B53
bool func_74() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return true;
	}
	return false;
}

// Position - 0x2B7A
void func_75(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_142(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x2BEE
void func_76() {
	if (Global_14443.f_1 == 9 || Global_14443.f_1 == 10) {
		Global_15798 = 0;
		Global_15794 = 1;
	}
}

// Position - 0x2C17
void func_77(var *uParam0) {
	char *sVar0;
	bool bVar1;
	vector3 vVar2;

	sVar0 = controls::_0x80C2FD58D720C801(0, 1, 1);
	if (!gameplay::are_strings_equal(sVar0, uParam0->f_466)) {
		func_7(uParam0);
	}
	uParam0->f_466 = sVar0;
	func_113();
	func_101(uParam0);
	func_85(uParam0);
	if (uParam0->f_464 == 1) {
		func_82(uParam0);
	}
	if (func_20()) {
		func_18(uParam0);
	}
	bVar1 = uParam0->f_454 > gameplay::get_game_timer();
	func_78(&uParam0->f_649, gameplay::is_bit_set(uParam0->f_449, 4), gameplay::is_bit_set(uParam0->f_449, 5) && !bVar1,
			1, 0, 1045220557, 1, 1065353216);
	if (gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!cutscene::is_cutscene_playing() && cam::is_screen_faded_in() && !ui::is_pause_menu_active()) {
			if (uParam0->f_464 != 1) {
				if (uParam0->f_464 == 0 || !gameplay::is_bit_set(uParam0->f_449, 11) &&
											   !gameplay::is_bit_set(uParam0->f_449, 10) && !func_19() &&
											   uParam0->f_483 == 0) {
					if (!gameplay::is_bit_set(uParam0->f_449, 18) || uParam0->f_464 == 2) {
						graphics::draw_scaleform_movie_fullscreen(uParam0->f_414, 255, 255, 255, 0, 0);
					}
				}
			}
		}
	}
	ui::display_radar(0);
	ui::hide_hud_component_this_frame(2);
	ui::hide_hud_component_this_frame(1);
	ui::hide_hud_component_this_frame(8);
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(3);
	ui::_0x25F87B30C382FCA7();
	graphics::_set_screen_draw_position(82, 66);
	ui::set_hud_component_position(17, 0.612f, 0.818f);
	graphics::_screen_draw_position_end();
	if (!cutscene::is_cutscene_playing()) {
		controls::set_input_exclusive(2, 201);
	}
	controls::set_input_exclusive(2, 202);
	controls::set_input_exclusive(2, 188);
	controls::set_input_exclusive(2, 187);
	controls::set_input_exclusive(2, 189);
	controls::set_input_exclusive(2, 190);
	if (!gameplay::is_bit_set(uParam0->f_449, 7)) {
		if (!cutscene::is_cutscene_playing()) {
			vVar2 = {uParam0->f_401};
			vVar2 = {vVar2 + Vector(0.5f, 2.9f * system::cos(180f - uParam0->f_404),
									2.9f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar2, &vVar2.f_2, 0);
			player::set_player_control(player::player_id(), 0, 134);
			ai::clear_ped_tasks_immediately(player::player_ped_id());
			entity::freeze_entity_position(player::player_ped_id(), 1);
			entity::set_entity_coords(player::player_ped_id(), vVar2, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			gameplay::set_bit(&uParam0->f_449, 7);
		}
	}
}

// Position - 0x2E67
void func_78(var *uParam0, bool bParam1, bool bParam2, int iParam3, int iParam4, float fParam5, int iParam6,
			 float fParam7) {
	int iVar0[4];
	float fVar5;
	float fVar6;
	float fVar7;
	float fVar8;
	float fVar9;
	vector3 vVar10;
	int iVar13;
	int iVar14;

	controls::_disable_input_group(2);
	func_81(&iVar0[0], &iVar0[1], &iVar0[2], &iVar0[3], 0, 0);
	if (controls::is_look_inverted()) {
		iVar0[3] *= -1;
	}
	if (controls::_is_input_disabled(2)) {
		fVar5 = controls::_0x5B84D09CEC5209C5(2, 239);
		fVar6 = controls::_0x5B84D09CEC5209C5(2, 240);
		fVar7 = fVar5 - uParam0->f_29;
		fVar8 = fVar6 - uParam0->f_30;
		uParam0->f_29 = fVar5;
		uParam0->f_30 = fVar6;
		if (iParam4) {
			iVar0[2] = -system::round(fVar7 * fParam5 * 127f);
			iVar0[3] = -system::round(fVar8 * fParam5 * 127f);
		}
		else {
			iVar0[2] = system::round(controls::_0x5B84D09CEC5209C5(2, 290) * fParam5 * 127f);
			iVar0[3] = system::round(controls::_0x5B84D09CEC5209C5(2, 291) * fParam5 * 127f);
		}
		iVar0[2] = func_80(iVar0[2] + uParam0->f_24, -127, 127);
		iVar0[3] = func_80(iVar0[3] + uParam0->f_25, -127, 127);
	}
	if (uParam0->f_24 == iVar0[2] && uParam0->f_25 == iVar0[3]) {
		if (uParam0->f_27 < gameplay::get_game_timer()) {
			uParam0->f_24 = 0;
			uParam0->f_25 = 0;
			if (controls::_is_input_disabled(2)) {
				iVar0[2] = 0;
				iVar0[3] = 0;
				uParam0->f_28 = 1;
			}
		}
	}
	else {
		uParam0->f_24 = iVar0[2];
		uParam0->f_25 = iVar0[3];
		uParam0->f_27 = gameplay::get_game_timer() + 4000;
		uParam0->f_28 = 0;
	}
	if (bParam2) {
		uParam0->f_8.f_2 = -(system::to_float(iVar0[2]) / 127f) * IntToFloat(uParam0->f_20);
		uParam0->f_8.f_1 = -uParam0->f_8.f_2 * IntToFloat(uParam0->f_22) / IntToFloat(uParam0->f_20);
		uParam0->f_8 = -(system::to_float(iVar0[3]) / 127f) * IntToFloat(uParam0->f_21);
	}
	else {
		uParam0->f_8 = {0f, 0f, 0f};
		uParam0->f_24 = 0;
		uParam0->f_25 = 0;
	}
	fVar9 = 30f * system::timestep();
	vVar10 = {uParam0->f_8 + uParam0->f_11};
	if (controls::_is_input_disabled(2) && bParam2 && !uParam0->f_28) {
		uParam0->f_14 = vVar10.x;
		uParam0->f_14.f_1 = vVar10.y;
		uParam0->f_14.f_2 = vVar10.z;
	}
	else {
		uParam0->f_14 += func_79((vVar10.x - uParam0->f_14) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_1 += func_79((vVar10.y - uParam0->f_14.f_1) * 0.05f * fVar9 * fParam7, -3f, 3f);
		uParam0->f_14.f_2 += func_79((vVar10.z - uParam0->f_14.f_2) * 0.05f * fVar9 * fParam7, -3f, 3f);
	}
	if (uParam0->f_26) {
		uParam0->f_14 = func_79(uParam0->f_14, system::to_float(-uParam0->f_21), system::to_float(uParam0->f_21));
		uParam0->f_14.f_1 =
			func_79(uParam0->f_14.f_1, system::to_float(-uParam0->f_22), system::to_float(uParam0->f_22));
		uParam0->f_14.f_2 =
			func_79(uParam0->f_14.f_2, system::to_float(-uParam0->f_20), system::to_float(uParam0->f_20));
	}
	if (controls::_is_input_disabled(0) && bParam1) {
		if (uParam0->f_28) {
			uParam0->f_17 = uParam0->f_7;
		}
	}
	else {
		uParam0->f_17 = uParam0->f_7;
	}
	if (bParam1) {
		if (controls::_is_input_disabled(0)) {
			iVar13 = 40;
			iVar14 = 41;
			if (iParam6) {
				iVar13 = 241;
				iVar14 = 242;
			}
			if (controls::is_disabled_control_just_pressed(0, iVar13)) {
				uParam0->f_17 -= 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			else if (controls::is_disabled_control_just_pressed(0, iVar14)) {
				uParam0->f_17 += 5f;
				uParam0->f_27 = gameplay::get_game_timer() + 4000;
				uParam0->f_28 = 0;
			}
			if (iParam3) {
				uParam0->f_17 = func_79(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7);
			}
			else {
				uParam0->f_17 = func_79(uParam0->f_17, uParam0->f_7 - uParam0->f_19, uParam0->f_7 + uParam0->f_19);
			}
		}
		else if (iParam3) {
			if (system::to_float(iVar0[1]) < 0f) {
				uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
			}
		}
		else {
			uParam0->f_17 += IntToFloat(system::round(system::to_float(iVar0[1]) / 128f * uParam0->f_19));
		}
	}
	uParam0->f_18 += (uParam0->f_17 - uParam0->f_18) * 0.06f * fVar9;
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4 + uParam0->f_14, uParam0->f_18, 0, 1, 1, 2);
	if (cam::does_cam_exist(*uParam0)) {
		if (cam::is_cam_active(*uParam0)) {
			if (cam::is_cam_rendering(*uParam0)) {
				unk1::_0xAF66DCEE6609B148();
			}
		}
	}
}

// Position - 0x3319
float func_79(float fParam0, float fParam1, float fParam2) {
	if (fParam0 > fParam2) {
		return fParam2;
	}
	else if (fParam0 < fParam1) {
		return fParam1;
	}
	return fParam0;
}

// Position - 0x3340
int func_80(int iParam0, int iParam1, int iParam2) {
	if (iParam0 > iParam2) {
		return iParam2;
	}
	else if (iParam0 < iParam1) {
		return iParam1;
	}
	return iParam0;
}

// Position - 0x3365
void func_81(var *uParam0, var *uParam1, var *uParam2, int *iParam3, int iParam4, int iParam5) {
	*uParam0 = system::floor(controls::_0x5B84D09CEC5209C5(2, 218) * 127f);
	*uParam1 = system::floor(controls::_0x5B84D09CEC5209C5(2, 219) * 127f);
	*uParam2 = system::floor(controls::_0x5B84D09CEC5209C5(2, 220) * 127f);
	*iParam3 = system::floor(controls::_0x5B84D09CEC5209C5(2, 221) * 127f);
	if (iParam4) {
		if (!controls::is_control_enabled(2, 218)) {
			*uParam0 = system::floor(controls::_0x4F8A26A890FD62FB(2, 218) * 127f);
		}
		if (!controls::is_control_enabled(2, 219)) {
			*uParam1 = system::floor(controls::_0x4F8A26A890FD62FB(2, 219) * 127f);
		}
		if (!controls::is_control_enabled(2, 220)) {
			*uParam2 = system::floor(controls::_0x4F8A26A890FD62FB(2, 220) * 127f);
		}
		if (!controls::is_control_enabled(2, 221)) {
			*iParam3 = system::floor(controls::_0x4F8A26A890FD62FB(2, 221) * 127f);
		}
	}
	if (controls::_is_input_disabled(2)) {
		if (iParam5) {
			if (controls::is_look_inverted()) {
				*iParam3 *= -1;
			}
			if (controls::_0xE1615EC03B3BB4FD()) {
				*iParam3 *= -1;
			}
		}
	}
}

// Position - 0x3469
void func_82(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_10(3, *uParam0)) {
		if (uParam0->f_483 == 0 && uParam0->f_455 > 3) {
			if (uParam0->f_452 == -1) {
				if (gameplay::is_bit_set(uParam0->f_449, 19)) {
					uParam0->f_452 = gameplay::get_game_timer() + 500;
				}
				else {
					uParam0->f_452 = gameplay::get_game_timer();
				}
			}
			else if (gameplay::get_game_timer() > uParam0->f_452) {
				iVar0 = 0;
				iVar1 = 0;
				while (iVar1 < uParam0->f_1.f_369) {
					if (!iVar0) {
						if (!gameplay::is_bit_set(uParam0->f_1.f_303, iVar1 + 4)) {
							func_84(uParam0, iVar1);
							if (gameplay::is_bit_set(uParam0->f_1.f_370, iVar1)) {
								gameplay::set_bit(&uParam0->f_449, 19);
							}
							else {
								gameplay::clear_bit(&uParam0->f_449, 19);
							}
							iVar0 = 1;
						}
					}
					iVar1++;
				}
				if (!iVar0) {
					func_83(3, *uParam0, 1);
				}
			}
		}
	}
}

// Position - 0x3548
void func_83(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	if (iParam0 == 11 || iParam0 == -1) {
		return;
	}
	if (iParam1 < 0 || iParam1 >= 32) {
		return;
	}
	iVar0 = gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	if (iVar0 == iParam2) {
		return;
	}
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iParam0], iParam1);
	}
}

// Position - 0x35CD
void func_84(var *uParam0, int iParam1) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(99);
	graphics::_pop_scaleform_movie_function_void();
	func_25(uParam0, &uParam0->f_1.f_371[iParam1 /*2*/], uParam0->f_1.f_11);
	func_23(uParam0, iParam1 + 4, 1);
	uParam0->f_452 = -1;
}

// Position - 0x3614
void func_85(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!func_19() && cam::is_screen_faded_in() && !cutscene::is_cutscene_playing()) {
		if (uParam0->f_483 > 0) {
			if (!gameplay::is_bit_set(uParam0->f_449, 13)) {
				if (func_86(&uParam0->f_484, &uParam0->f_467[0 /*5*/], &uParam0->f_467[0 /*5*/].f_2, 4, 0, 0, 0)) {
					uParam0->f_455 = 0;
					if (uParam0->f_467[0 /*5*/].f_4) {
						gameplay::clear_bit(&uParam0->f_449, 11);
					}
					else {
						gameplay::set_bit(&uParam0->f_449, 11);
					}
					iVar0 = 0;
					while (iVar0 < 2) {
						uParam0->f_467[iVar0 /*5*/] = {uParam0->f_467[iVar0 + 1 /*5*/]};
						uParam0->f_467[iVar0 /*5*/].f_2 = {uParam0->f_467[iVar0 + 1 /*5*/].f_2};
						uParam0->f_467[iVar0 /*5*/].f_4 = uParam0->f_467[iVar0 + 1 /*5*/].f_4;
						iVar0++;
					}
					uParam0->f_483--;
				}
			}
			else {
				iVar1 = 0;
				while (iVar1 < 2) {
					uParam0->f_467[iVar1 /*5*/] = {uParam0->f_467[iVar1 + 1 /*5*/]};
					uParam0->f_467[iVar1 /*5*/].f_2 = {uParam0->f_467[iVar1 + 1 /*5*/].f_2};
					uParam0->f_467[iVar1 /*5*/].f_4 = uParam0->f_467[iVar1 + 1 /*5*/].f_4;
					iVar1++;
				}
				uParam0->f_483--;
				gameplay::clear_bit(&uParam0->f_449, 13);
				gameplay::clear_bit(&uParam0->f_449, 11);
			}
		}
		else {
			if (gameplay::is_bit_set(uParam0->f_449, 11)) {
				gameplay::clear_bit(&uParam0->f_449, 11);
			}
			if (gameplay::is_bit_set(uParam0->f_449, 13)) {
				gameplay::clear_bit(&uParam0->f_449, 13);
			}
			uParam0->f_455++;
		}
	}
}

// Position - 0x37CB
bool func_86(var *uParam0, char *sParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	func_100(uParam0, 145, sParam1, iParam4, iParam5, iParam6);
	if (iParam3 > 7) {
		if (iParam3 < 12) {
			iParam3 = 7;
		}
	}
	Global_15752 = 0;
	Global_15754 = 0;
	Global_15759 = 0;
	Global_16736 = 0;
	Global_16738 = 0;
	Global_16742 = 0;
	Global_2621441 = 0;
	return func_87(sParam2, iParam3, 0);
}

// Position - 0x3819
int func_87(char *sParam0, int iParam1, int iParam2) {
	Global_15746 = 0;
	if (Global_15745 == 0 || Global_15747 == 2) {
		if (Global_15745 != 0) {
			if (iParam1 > Global_15747) {
				if (Global_15752 == 0) {
					audio::stop_scripted_conversation(0);
					Global_14443.f_1 = 3;
					Global_15745 = 0;
					Global_15746 = 1;
					Global_15798 = 0;
					Global_15741 = 0;
					Global_15742 = 0;
					Global_15756 = 0;
					Global_15755 = 0;
					Global_14442 = 0;
				}
				else {
					func_99();
					return 0;
				}
			}
			else {
				return 0;
			}
		}
		if (audio::is_scripted_conversation_ongoing()) {
			return 0;
		}
		if (func_98(8, -1)) {
			return 0;
		}
		Global_15821 = {Global_15815};
		func_97();
		Global_15034 = {Global_15199};
		Global_15751 = Global_15752;
		Global_15758 = Global_15759;
		Global_2621442 = Global_2621441;
		Global_15760 = {Global_15776};
		Global_15753 = Global_15754;
		Global_16735 = Global_16736;
		Global_16743 = {Global_16749};
		Global_16737 = Global_16738;
		Global_16739 = Global_16740;
		Global_16741 = Global_16742;
		Global_15364.f_370 = Global_16734;
		Global_15364.f_368 = Global_16732;
		Global_15364.f_369 = Global_16733;
		Global_15741 = Global_15742;
		if (Global_15751) {
			gameplay::clear_bit(&G_SleepModeOnOn25, 20);
			gameplay::clear_bit(&G_SleepModeOffOn11, 17);
			gameplay::clear_bit(&Global_2315, 0);
			if (iParam2) {
				func_91();
				if (Global_3118[Global_14443 /*2811*/][0 /*281*/].f_259 == 2) {
					if (iParam1 == 13) {
					}
					else {
						return 0;
					}
				}
				if (Global_14443.f_1 > 3) {
					return 0;
				}
			}
			if (Global_14409 == 1) {
				return 0;
			}
			if (player::is_player_playing(player::player_id())) {
				if (ped::is_ped_in_melee_combat(player::player_ped_id())) {
					return 0;
				}
				if (func_90()) {
					return 0;
				}
				if (ai::is_ped_sprinting(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_ragdoll(player::player_ped_id())) {
					return 0;
				}
				if (ped::is_ped_in_parachute_free_fall(player::player_ped_id())) {
					return 0;
				}
				if (weapon::get_is_ped_gadget_equipped(player::player_ped_id(), joaat("gadget_parachute"))) {
					return 0;
				}
				if (!Global_69702) {
					if (entity::is_entity_in_water(player::player_ped_id())) {
						return 0;
					}
					if (player::is_player_climbing(player::player_id())) {
						return 0;
					}
					if (ped::is_ped_planting_bomb(player::player_ped_id())) {
						return 0;
					}
					if (player::is_special_ability_active(player::player_id())) {
						return 0;
					}
				}
			}
			if (func_74()) {
				return 0;
			}
			else {
				switch (Global_14443.f_1) {
				case 7: return 0;

				case 8: return 0;

				case 9: break;

				case 10: break;

				default: break;
				}
				if (gameplay::is_bit_set(G_SleepModeOnOn25, 9)) {
					return 0;
				}
			}
			func_89();
			Global_15755 = iParam2;
		}
		Global_15747 = iParam1;
		StringCopy(&Global_15364, sParam0, 24);
		Global_14611 = 0;
		func_88();
		return 1;
	}
	if (Global_15745 == 5) {
		return 0;
	}
	if (iParam1 < Global_15747 || iParam1 == Global_15747) {
		return 0;
	}
	if (iParam1 == 2) {
	}
	else {
		func_99();
	}
	return 0;
}

// Position - 0x3AE5
void func_88() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 69) {
		StringCopy(&Global_14613[iVar0 /*6*/], "", 24);
		iVar0++;
	}
	audio::stop_scripted_conversation(0);
	Global_15745 = 1;
}

// Position - 0x3B16
void func_89() {
	Global_15798 = Global_15797;
	Global_15792 = Global_15793;
	Global_15839 = {Global_15827};
	Global_15845 = {Global_15833};
	Global_15800 = Global_15799;
	Global_15869 = {Global_15851};
	Global_15875 = {Global_15857};
	Global_15881 = {Global_15863};
	Global_15887 = {Global_15893};
	Global_1628 = Global_1629;
	Global_1630 = Global_1631;
	Global_15756 = Global_15757;
	Global_15758 = Global_15759;
	Global_15760 = {Global_15776};
	Global_15749 = Global_15750;
	Global_16761 = 0;
	Global_15794 = 0;
	Global_15795 = 0;
	gameplay::clear_bit(&G_SleepModeOffOn11, 16);
}

// Position - 0x3BAB
bool func_90() {
	int iVar0;
	int iVar1;

	if (Global_69702) {
		iVar0 = 0;
		weapon::get_current_ped_weapon(player::player_ped_id(), &iVar1, 1);
		if (player::is_player_playing(player::player_id())) {
			if (iVar1 == joaat("weapon_sniperrifle") || iVar1 == joaat("weapon_heavysniper") ||
				iVar1 == joaat("weapon_remotesniper")) {
				iVar0 = 1;
			}
		}
		if (cam::is_aim_cam_active() && iVar0 == 1) {
			return true;
		}
		else {
			return false;
		}
	}
	if (player::is_player_playing(player::player_id())) {
		if (ped::get_ped_config_flag(player::player_ped_id(), 78, 1)) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x3C44
void func_91() {
	if (func_219(14)) {
		if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
			if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[0 /*29*/]) {
				Global_14443 = 0;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[1 /*29*/]) {
				Global_14443 = 1;
			}
			else if (entity::get_entity_model(player::player_ped_id()) == Global_101700.f_27009[2 /*29*/]) {
				Global_14443 = 2;
			}
			else {
				Global_14443 = 0;
			}
		}
	}
	else {
		Global_14443 = func_92();
		if (Global_14443 == 145) {
			Global_14443 = 3;
		}
		if (Global_69702) {
			Global_14443 = 3;
		}
		if (Global_14443 > 3) {
			Global_14443 = 3;
		}
	}
}

// Position - 0x3CE6
var func_92() {
	func_93();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x3CFF
void func_93() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_96(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_95(player::player_ped_id());
			if (func_94(iVar0) && (!func_219(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_94(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x3DFC
bool func_94(int iParam0) { return iParam0 < 3; }

// Position - 0x3E08
int func_95(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_96(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x3E45
int func_96(int iParam0) {
	if (func_94(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x3E6F
void func_97() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 15) {
		Global_15034[iVar0 /*10*/] = 0;
		StringCopy(&Global_15034[iVar0 /*10*/].f_1, "", 24);
		Global_15034[iVar0 /*10*/].f_7 = 0;
		Global_15034[iVar0 /*10*/].f_8 = 0;
		iVar0++;
	}
	Global_15034.f_161 = -99;
	Global_15034.f_162 = {0f, 0f, 0f};
}

// Position - 0x3EC6
bool func_98(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x3F01
void func_99() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_mobile_phone_call_ongoing() || Global_14443.f_1 == 9 || Global_14442 == 1) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
		Global_14443.f_1 = 3;
		return;
	}
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(1);
		Global_15745 = 6;
		return;
	}
}

// Position - 0x3F58
void func_100(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, var uParam5) {
	Global_15199 = {*uParam0};
	Global_1629 = iParam1;
	StringCopy(&Global_15815, sParam2, 24);
	Global_16734 = uParam5;
	if (iParam3 == 0) {
		Global_16732 = 1;
		Global_16730 = 0;
	}
	else {
		Global_16732 = 0;
		Global_16730 = 1;
	}
	if (iParam4 == 0) {
		Global_16733 = 1;
		Global_16731 = 0;
	}
	else {
		Global_16733 = 0;
		Global_16731 = 1;
	}
}

// Position - 0x3FAE
void func_101(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	uParam0->f_453++;
	if (controls::_0x6CD79468A1E595C6(2)) {
		func_7(uParam0);
	}
	if (!gameplay::is_bit_set(uParam0->f_449, 11)) {
		if (controls::is_control_just_pressed(2, iLocal_37) || controls::is_control_just_pressed(2, iLocal_39) ||
			controls::_is_input_disabled(2) &&
				(controls::is_control_just_pressed(2, iLocal_38) || controls::is_control_just_pressed(2, iLocal_40))) {
			func_111();
			if (gameplay::is_bit_set(uParam0->f_449, 12)) {
				gameplay::set_bit(&uParam0->f_449, 13);
				gameplay::clear_bit(&uParam0->f_449, 11);
				gameplay::clear_bit(&uParam0->f_449, 10);
			}
			gameplay::clear_bit(&uParam0->f_449, 12);
		}
	}
	func_81(&uParam0->f_458[0], &uParam0->f_458[1], &uParam0->f_458[2], &uParam0->f_458[3], 0, 0);
	if (controls::_is_input_disabled(2)) {
		uParam0->f_458[2] /= 10;
		uParam0->f_458[3] /= 10;
		uParam0->f_458[2] = func_80(uParam0->f_458[2] + uParam0->f_649.f_24, -127, 127);
		uParam0->f_458[3] = func_80(uParam0->f_458[3] + uParam0->f_649.f_25, -127, 127);
	}
	uParam0->f_649.f_24 = uParam0->f_458[2];
	uParam0->f_649.f_25 = uParam0->f_458[3];
	if (controls::is_look_inverted()) {
		uParam0->f_458[3] = -uParam0->f_458[3];
	}
	if (uParam0->f_454 > gameplay::get_game_timer()) {
		uParam0->f_458[2] = 0;
		uParam0->f_458[3] = 0;
	}
	if (uParam0->f_464 == 0 || uParam0->f_464 == 4) {
		if (uParam0->f_453 > 15) {
			gameplay::set_bit(&uParam0->f_449, 4);
		}
		else {
			gameplay::clear_bit(&uParam0->f_449, 4);
		}
	}
	if (!gameplay::is_bit_set(uParam0->f_449, 10)) {
		if (!gameplay::is_bit_set(uParam0->f_449, 11)) {
			if (gameplay::get_game_timer() - uParam0->f_456 > 200) {
				if (uParam0->f_464 == 2 || uParam0->f_464 == 3 || uParam0->f_464 == 4) {
					if (gameplay::get_game_timer() - uParam0->f_457 > 25000) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_280[3 /*2*/], 1);
						uParam0->f_457 = gameplay::get_game_timer() + gameplay::get_random_int_in_range(0, 8000);
					}
				}
				if (uParam0->f_464 == 2) {
					if (uParam0->f_458[1] < -85 || uParam0->f_458[0] < -85 || controls::is_control_pressed(2, 188) ||
						controls::is_control_pressed(2, 189) ||
						controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(2, 241)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(8);
						graphics::_pop_scaleform_movie_function_void();
						graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
						uParam0->f_682 = graphics::_pop_scaleform_movie_function();
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
					else if (uParam0->f_458[1] > 85 || uParam0->f_458[0] > 85 || controls::is_control_pressed(2, 187) ||
							 controls::is_control_pressed(2, 190) ||
							 controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 242)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(9);
						graphics::_pop_scaleform_movie_function_void();
						graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
						uParam0->f_682 = graphics::_pop_scaleform_movie_function();
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
				}
				if (uParam0->f_464 == 3) {
					if (uParam0->f_458[1] < -85 || controls::is_control_pressed(2, 188) ||
						controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 40)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(8);
						graphics::_pop_scaleform_movie_function_void();
						if (uParam0->f_416 != 0) {
							audio::play_sound_frontend(-1, "MARKER_ERASE", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
						}
						uParam0->f_416 = 0;
						if (gameplay::is_bit_set(uParam0->f_449, 9)) {
							gameplay::clear_bit(&uParam0->f_449, 9);
							func_7(uParam0);
						}
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
					else if (uParam0->f_458[1] > 85 || controls::is_control_pressed(2, 187) ||
							 controls::_is_input_disabled(2) && controls::is_disabled_control_just_pressed(0, 41)) {
						graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_INPUT_EVENT");
						graphics::_push_scaleform_movie_function_parameter_int(9);
						graphics::_pop_scaleform_movie_function_void();
						if (uParam0->f_416 != 1) {
							audio::play_sound_frontend(-1, "MARKER_ERASE", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
						}
						uParam0->f_416 = 1;
						if (gameplay::is_bit_set(uParam0->f_449, 9)) {
							gameplay::clear_bit(&uParam0->f_449, 9);
							func_7(uParam0);
						}
						uParam0->f_456 = gameplay::get_game_timer();
						uParam0->f_457 = uParam0->f_456;
					}
				}
				if (!func_19() || gameplay::is_bit_set(uParam0->f_449, 13)) {
					if (controls::is_control_just_pressed(2, iLocal_37) ||
						controls::_is_input_disabled(2) && controls::is_control_just_pressed(2, iLocal_38)) {
						switch (uParam0->f_464) {
						case 3:
							if (!func_19()) {
								if (!gameplay::is_bit_set(uParam0->f_449, 9)) {
									uParam0->f_456 = gameplay::get_game_timer();
									iVar0 = func_30(*uParam0);
									if (iVar0 != -1) {
										graphics::_push_scaleform_movie_function(uParam0->f_413,
																				 "GET_CURRENT_SELECTION");
										uParam0->f_680 = graphics::_pop_scaleform_movie_function();
										func_11(uParam0, 1);
										func_13(&uParam0->f_1.f_20[0 /*4*/], 1);
										func_13(&uParam0->f_1.f_20[1 /*4*/], 1);
										Global_101700.f_1[*uParam0] = 1;
										ui::clear_help(0);
									}
								}
							}
							break;

						case 2:
							if (!func_10(4, *uParam0)) {
								iVar0 = func_30(*uParam0);
								iVar1 = func_65(iVar0);
								if (uParam0->f_450 < Global_87853[iVar1 /*19*/]) {
									graphics::_push_scaleform_movie_function(uParam0->f_413, "GET_CURRENT_SELECTION");
									uParam0->f_681 = graphics::_pop_scaleform_movie_function();
									func_11(uParam0, 1);
								}
							}
							break;

						case 4:
							if (*uParam0 != 1) {
								func_83(4, *uParam0, 1);
								if (!func_110(0)) {
									func_108(*uParam0);
								}
							}
							else {
								func_83(5, *uParam0, 1);
							}
							audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
							iVar0 = func_30(*uParam0);
							iVar1 = func_65(iVar0);
							iVar2 = 0;
							while (iVar2 < Global_87853[iVar1 /*19*/]) {
								if (Global_101700.f_1.f_12[iVar1 /*6*/][iVar2] == 0 ||
									func_40(Global_101700.f_1.f_12[iVar1 /*6*/][iVar2]) !=
										Global_87853[iVar1 /*19*/].f_1[iVar2]) {
									iVar4 = 0;
									iVar5 = 0;
									while (iVar5 < 14) {
										if (!iVar4) {
											iVar4 = 1;
											iVar3 = iVar5;
											if (iVar3 != 0) {
												if (Global_87699[iVar3 /*5*/] !=
													Global_87853[iVar1 /*19*/].f_1[iVar2]) {
													iVar4 = 0;
												}
												if (!gameplay::is_bit_set(Global_101700.f_1.f_116, iVar3)) {
													iVar4 = 0;
												}
												if (gameplay::is_bit_set(Global_101700.f_1.f_118, iVar3)) {
													iVar4 = 0;
												}
												if (iVar3 == 11 && *uParam0 == 3) {
													iVar4 = 0;
												}
												if (func_37(uParam0, iVar3)) {
													iVar4 = 0;
												}
											}
											else {
												iVar4 = 0;
											}
										}
										iVar5++;
									}
									Global_101700.f_1.f_12[iVar1 /*6*/][iVar2] = iVar3;
								}
								iVar2++;
							}
							func_11(uParam0, 1);
							func_62(uParam0, iVar1, 4);
							break;
						}
						uParam0->f_427 = 0;
					}
					if (controls::is_control_just_pressed(2, iLocal_39) ||
						controls::_is_input_disabled(2) && controls::is_control_just_pressed(2, iLocal_40)) {
						switch (uParam0->f_464) {
						case 2:
							iVar0 = func_30(*uParam0);
							iVar1 = func_65(iVar0);
							if (uParam0->f_450 > 0) {
								func_11(uParam0, 1);
								uParam0->f_450--;
								uParam0->f_417 = uParam0->f_450;
								iVar6 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
								Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
								uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
								func_35(uParam0, uParam0->f_450, iVar6);
								audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
								uParam0->f_427 = 0;
								uParam0->f_456 = gameplay::get_game_timer();
							}
							else if (!func_221(0)) {
								if (*uParam0 != 2) {
									iVar7 = 0;
									while (iVar7 < uParam0->f_1.f_96) {
										graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
										graphics::_push_scaleform_movie_function_parameter_int(iVar7);
										graphics::_pop_scaleform_movie_function_void();
										graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
										graphics::_push_scaleform_movie_function_parameter_int(iVar7);
										graphics::_push_scaleform_movie_function_parameter_bool(1);
										graphics::_pop_scaleform_movie_function_void();
										iVar7++;
									}
									audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
									iVar7 = 0;
									while (iVar7 < 2) {
										if (uParam0->f_1.f_30[iVar7] != 13) {
											func_107(*uParam0, uParam0->f_1.f_30[iVar7], 0);
										}
										iVar7++;
									}
									uParam0->f_427 = 0;
									func_11(uParam0, 1);
									uParam0->f_456 = gameplay::get_game_timer();
									uParam0->f_465 = 0;
									func_106(0, 1);
								}
							}
							break;

						case 4:
							if (*uParam0 != 1) {
								iVar0 = func_30(*uParam0);
								iVar1 = func_65(iVar0);
								uParam0->f_450--;
								uParam0->f_417 = uParam0->f_450;
								iVar8 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
								Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
								uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
								func_5(uParam0, 2, iVar8);
							}
							else {
								iVar9 = 0;
								while (iVar9 < 2) {
									if (uParam0->f_1.f_30[iVar9] != 13) {
										func_107(*uParam0, uParam0->f_1.f_30[iVar9], 0);
									}
									iVar9++;
								}
								func_105(8, 0);
								func_83(5, 1, 0);
								uParam0->f_427 = 0;
								func_11(uParam0, 1);
								uParam0->f_456 = gameplay::get_game_timer();
								func_5(uParam0, 3, 0);
							}
							audio::play_sound_frontend(-1, "UNDO", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
							break;
						}
					}
				}
			}
		}
	}
	else if (uParam0->f_455 > 5) {
		iVar0 = func_30(*uParam0);
		iVar1 = func_65(iVar0);
		if (uParam0->f_450 >= Global_87853[iVar1 /*19*/] || *uParam0 == 1 && uParam0->f_450 > uParam0->f_415) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
			graphics::_push_scaleform_movie_function_parameter_int(99);
			graphics::_push_scaleform_movie_function_parameter_int(-1);
			graphics::_pop_scaleform_movie_function_void();
			func_23(uParam0, 0, 1);
			func_5(uParam0, 4, 0);
		}
		else {
			if (!gameplay::is_bit_set(uParam0->f_449, 17)) {
				iVar10 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
				Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = 0;
				uParam0->f_465 = Global_87853[iVar1 /*19*/].f_1[uParam0->f_450];
				func_35(uParam0, uParam0->f_450, iVar10);
			}
			gameplay::clear_bit(&uParam0->f_449, 17);
		}
		uParam0->f_457 = gameplay::get_game_timer();
		gameplay::clear_bit(&uParam0->f_449, 10);
	}
	else if (ui::is_help_message_being_displayed()) {
		if (!func_12(&uParam0->f_1.f_108[0 /*4*/]) && !func_12(&uParam0->f_1.f_108[1 /*4*/]) &&
			!func_12(&uParam0->f_1.f_20[0 /*4*/]) && !func_12(&uParam0->f_1.f_20[1 /*4*/])) {
			ui::clear_help(1);
		}
	}
	if (uParam0->f_680 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_680)) {
			iVar11 = graphics::_0x2DE7EFA66B906036(uParam0->f_680);
			iVar1 = func_29(*uParam0, iVar11);
			iVar0 = func_30(*uParam0);
			func_105(iVar0, iVar1);
			if (!func_110(0)) {
				func_104(*uParam0);
			}
			audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
			func_62(uParam0, iVar1, 0);
			if (uParam0->f_1.f_30[iVar11] != 13) {
				func_107(*uParam0, uParam0->f_1.f_30[iVar11], 1);
			}
			iVar12 = 0;
			while (iVar12 < uParam0->f_1.f_96) {
				func_61(uParam0, iVar12);
				if (iVar12 < Global_87853[iVar1 /*19*/]) {
					graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
					graphics::_push_scaleform_movie_function_parameter_int(iVar12);
					graphics::_push_scaleform_movie_function_parameter_bool(1);
					graphics::_pop_scaleform_movie_function_void();
				}
				else {
					graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
					graphics::_push_scaleform_movie_function_parameter_int(iVar12);
					graphics::_push_scaleform_movie_function_parameter_bool(0);
					graphics::_pop_scaleform_movie_function_void();
				}
				iVar12++;
			}
			if (*uParam0 != 1) {
				func_83(5, *uParam0, 1);
			}
			else {
				gameplay::set_bit(&uParam0->f_449, 10);
				uParam0->f_450++;
			}
			ui::clear_help(0);
			uParam0->f_680 = 0;
		}
	}
	if (uParam0->f_681 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_681)) {
			iVar13 = graphics::_0x2DE7EFA66B906036(uParam0->f_681);
			iVar0 = func_30(*uParam0);
			iVar1 = func_65(iVar0);
			Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450] = uParam0->f_418[iVar13];
			iVar14 = Global_101700.f_1.f_12[iVar1 /*6*/][uParam0->f_450];
			graphics::_push_scaleform_movie_function(uParam0->f_413, "UPDATE_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_450);
			graphics::_push_scaleform_movie_function_parameter_int(iVar13);
			graphics::_push_scaleform_movie_function_parameter_int(iVar14);
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(uParam0->f_413, "FOCUS_VIEW");
			graphics::_push_scaleform_movie_function_parameter_int(99);
			graphics::_pop_scaleform_movie_function_void();
			audio::play_sound_frontend(-1, "PERSON_SELECT", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
			gameplay::clear_bit(&uParam0->f_449, 17);
			func_103(uParam0, iVar14);
			uParam0->f_450++;
			uParam0->f_417 = uParam0->f_450;
			uParam0->f_456 = gameplay::get_game_timer();
			uParam0->f_457 = uParam0->f_456;
			gameplay::set_bit(&uParam0->f_449, 10);
			if (!func_12(&uParam0->f_1.f_108[0 /*4*/]) && !func_12(&uParam0->f_1.f_108[1 /*4*/])) {
				ui::clear_help(0);
			}
			uParam0->f_681 = 0;
		}
	}
	if (uParam0->f_682 != 0) {
		if (graphics::_0x768FF8961BA904D6(uParam0->f_682)) {
			iVar15 = graphics::_0x2DE7EFA66B906036(uParam0->f_682);
			if (iVar15 != -1) {
				iVar16 = uParam0->f_418[iVar15];
				if (iVar16 != uParam0->f_427) {
					audio::play_sound_frontend(-1, "PERSON_SCROLL", "HEIST_BULLETIN_BOARD_SOUNDSET", 1);
				}
				uParam0->f_427 = iVar16;
			}
			uParam0->f_682 = 0;
		}
	}
	if (uParam0->f_427 != 0) {
		func_102(uParam0, uParam0->f_427);
	}
}

// Position - 0x4D78
void func_102(var *uParam0, int iParam1) {
	if (!func_19()) {
		if (uParam0->f_483 == 0) {
			switch (iParam1) {
			case 10:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 14)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[14 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_24(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[14 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 13:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 16)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[16 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_24(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[16 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 16);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 12:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 15)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[15 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_24(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[15 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;

			case 11:
				if (gameplay::is_bit_set(Global_101700.f_1.f_119, 17)) {
					if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[17 /*2*/], "")) {
						gameplay::set_bit(&uParam0->f_449, 10);
						gameplay::set_bit(&uParam0->f_449, 17);
						func_24(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[17 /*2*/], 1);
						gameplay::clear_bit(&Global_101700.f_1.f_119, 17);
						gameplay::set_bit(&uParam0->f_449, 12);
						return;
					}
				}
				break;
			}
		}
	}
}

// Position - 0x4F94
void func_103(var *uParam0, int iParam1) {
	if (!gameplay::is_bit_set(uParam0->f_463, iParam1)) {
		if (!gameplay::is_bit_set(Global_101700.f_1.f_119, iParam1)) {
			if (!gameplay::are_strings_equal(&uParam0->f_1.f_304[iParam1 /*2*/], "")) {
				func_24(uParam0, uParam0->f_1.f_278, uParam0->f_1.f_304[iParam1 /*2*/], 1);
				gameplay::set_bit(&Global_101700.f_1.f_119, iParam1);
			}
		}
		else {
			switch (*uParam0) {
			case 2:
				switch (iParam1) {
				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;
				}
				break;

			case 3:
				switch (iParam1) {
				case 12:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 3)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[24 /*2*/], 1);
					}
					break;

				case 9:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 6)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[26 /*2*/], 1);
					}
					break;

				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[21 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[19 /*2*/], 1);
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[21 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[19 /*2*/], 1);
					}
					break;

				case 6:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 4)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 7:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 2)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;

				case 8:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 5)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[18 /*2*/], 1);
					}
					break;
				}
				break;

			case 4:
				switch (iParam1) {
				case 12:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 15)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 3)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[25 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[24 /*2*/], 1);
						}
					}
					break;

				case 7:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 2)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 14)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[30 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[28 /*2*/], 1);
						}
					}
					else if (gameplay::is_bit_set(Global_101700.f_1.f_117, 14)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[29 /*2*/], 1);
					}
					break;

				case 9:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 18)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 6)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[27 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[26 /*2*/], 1);
						}
					}
					break;

				case 4:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 17)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[31 /*2*/], 1);
					}
					break;

				case 5:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 12)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[31 /*2*/], 1);
					}
					break;

				case 1:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 10)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 0)) {
							if (gameplay::is_bit_set(Global_101700.f_1.f_117, 7)) {
								func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[23 /*2*/], 1);
							}
							else {
								func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
							}
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 10:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 11)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 1)) {
							if (gameplay::is_bit_set(Global_101700.f_1.f_117, 8)) {
								func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[23 /*2*/], 1);
							}
							else {
								func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
							}
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 3:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 13)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
					}
					break;

				case 6:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 19)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 4)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 8:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 16)) {
						if (gameplay::is_bit_set(Global_101700.f_1.f_117, 5)) {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[22 /*2*/], 1);
						}
						else {
							func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
						}
					}
					break;

				case 13:
					if (gameplay::is_bit_set(Global_101700.f_1.f_117, 20)) {
						func_24(uParam0, uParam0->f_1.f_276, uParam0->f_1.f_304[20 /*2*/], 1);
					}
					break;
				}
				break;
			}
		}
		gameplay::set_bit(&uParam0->f_463, iParam1);
	}
}

// Position - 0x572B
void func_104(int iParam0) {
	int iVar0;

	switch (iParam0) {
	case 0:
		iVar0 = Global_101700.f_8044.f_99.f_205[7];
		if (iVar0 == 1) {
			stats::stat_set_bool(joaat("sp_heist_chose_jewel_stealth"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_jewel_stealth"), 0, 1);
		}
		break;

	case 1:
		iVar0 = Global_101700.f_8044.f_99.f_205[8];
		if (iVar0 == 3) {
			stats::stat_set_bool(joaat("sp_heist_chose_docks_sink_ship"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_docks_sink_ship"), 0, 1);
		}
		break;

	case 3:
		iVar0 = Global_101700.f_8044.f_99.f_205[10];
		if (iVar0 == 6) {
			stats::stat_set_bool(joaat("sp_heist_chose_bureau_firecrew"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_bureau_firecrew"), 0, 1);
		}
		break;

	case 4:
		iVar0 = Global_101700.f_8044.f_99.f_205[11];
		if (iVar0 == 8) {
			stats::stat_set_bool(joaat("sp_heist_chose_bigs_traffic"), 1, 1);
		}
		else {
			stats::stat_set_bool(joaat("sp_heist_chose_bigs_traffic"), 0, 1);
		}
		break;
	}
}

// Position - 0x5826
void func_105(int iParam0, int iParam1) {
	if (iParam0 == 13 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_205[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_205[iParam0] = iParam1;
}

// Position - 0x586B
void func_106(int iParam0, int iParam1) {
	if (iParam0 == 146 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_58[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_58[iParam0] = iParam1;
}

// Position - 0x58B0
void func_107(int iParam0, int iParam1, int iParam2) {
	if (iParam2) {
		gameplay::set_bit(&Global_101700.f_1.f_120[iParam0], iParam1);
	}
	else {
		gameplay::clear_bit(&Global_101700.f_1.f_120[iParam0], iParam1);
	}
	gameplay::set_bit(&Global_87832, iParam0);
}

// Position - 0x58EE
void func_108(int iParam0) {
	int iVar0;
	int iVar1;

	func_109(iParam0);
	switch (iParam0) {
	case 0:
		iVar1 = Global_101700.f_8044.f_99.f_205[7];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 0); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 1);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 7: gameplay::set_bit(&Global_101700.f_1.f_117, 2); break;

			case 12:
				gameplay::set_bit(&Global_101700.f_1.f_117, 3);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
				break;

			case 6: gameplay::set_bit(&Global_101700.f_1.f_117, 4); break;

			case 8: gameplay::set_bit(&Global_101700.f_1.f_117, 5); break;

			case 9: gameplay::set_bit(&Global_101700.f_1.f_117, 6); break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;

	case 2:
		iVar1 = Global_101700.f_8044.f_99.f_205[9];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 7); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 8);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 11:
				gameplay::set_bit(&Global_101700.f_1.f_117, 9);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 17);
				break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;

	case 3:
		iVar1 = Global_101700.f_8044.f_99.f_205[10];
		iVar0 = 0;
		while (iVar0 < Global_87853[iVar1 /*19*/]) {
			switch (Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]) {
			case 1: gameplay::set_bit(&Global_101700.f_1.f_117, 10); break;

			case 10:
				gameplay::set_bit(&Global_101700.f_1.f_117, 11);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 14);
				break;

			case 5: gameplay::set_bit(&Global_101700.f_1.f_117, 12); break;

			case 3: gameplay::set_bit(&Global_101700.f_1.f_117, 13); break;

			case 4: gameplay::set_bit(&Global_101700.f_1.f_117, 17); break;

			case 7: gameplay::set_bit(&Global_101700.f_1.f_117, 14); break;

			case 12:
				gameplay::set_bit(&Global_101700.f_1.f_117, 15);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 15);
				break;

			case 6: gameplay::set_bit(&Global_101700.f_1.f_117, 19); break;

			case 8: gameplay::set_bit(&Global_101700.f_1.f_117, 16); break;

			case 9: gameplay::set_bit(&Global_101700.f_1.f_117, 18); break;

			case 13:
				gameplay::set_bit(&Global_101700.f_1.f_117, 20);
				gameplay::clear_bit(&Global_101700.f_1.f_119, 16);
				break;
			}
			gameplay::set_bit(&Global_101700.f_1.f_119, Global_101700.f_1.f_12[iVar1 /*6*/][iVar0]);
			iVar0++;
		}
		break;
	}
}

// Position - 0x5C6B
void func_109(int iParam0) {
	switch (iParam0) {
	case 0:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 0);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 1);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 2);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 3);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 4);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 5);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 6);
		break;

	case 2:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 7);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 8);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 9);
		break;

	case 3:
		gameplay::clear_bit(&Global_101700.f_1.f_117, 10);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 11);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 12);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 13);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 14);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 15);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 16);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 17);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 18);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 19);
		gameplay::clear_bit(&Global_101700.f_1.f_117, 20);
		break;
	}
}

// Position - 0x5DB3
bool func_110(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x5DDE
void func_111() {
	Global_14611 = 0;
	func_112();
}

// Position - 0x5DEE
void func_112() {
	audio::restart_scripted_conversation();
	Global_16756 = 0;
	if (audio::is_scripted_conversation_ongoing()) {
		audio::stop_scripted_conversation(0);
		Global_15745 = 6;
	}
}

// Position - 0x5E0F
void func_113() {
	unk1::_0xEB2D525B57F42B40();
	func_114();
}

// Position - 0x5E1F
void func_114() { Global_17151.f_134 = 1; }

// Position - 0x5E2D
void func_115(var *uParam0) {
	vector3 vVar0;
	int iVar3;

	uParam0->f_453 = 0;
	uParam0->f_463 = 0;
	gameplay::set_bit(&uParam0->f_449, 9);
	func_11(uParam0, 0);
	if (!cutscene::is_cutscene_playing()) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (Global_36912 == 1) {
				func_120(player::player_ped_id());
			}
			vVar0 = {uParam0->f_401};
			vVar0 = {vVar0 + Vector(0.5f, 2.9f * system::cos(180f - uParam0->f_404),
									2.9f * system::sin(180f - uParam0->f_404))};
			gameplay::get_ground_z_for_3d_coord(vVar0, &vVar0.f_2, 0);
			player::set_player_control(player::player_id(), 0, 134);
			entity::set_entity_coords(player::player_ped_id(), vVar0, 1, 0, 0, 1);
			entity::set_entity_heading(player::player_ped_id(), uParam0->f_404);
			ai::clear_ped_tasks_immediately(player::player_ped_id());
			entity::freeze_entity_position(player::player_ped_id(), 1);
		}
		gameplay::set_bit(&uParam0->f_449, 7);
	}
	ui::display_radar(0);
	func_72(1);
	func_119();
	ui::_0xFDB423997FA30340();
	gameplay::clear_area(uParam0->f_401, 5f, 1, 1, 0, 0);
	graphics::remove_particle_fx_in_range(uParam0->f_401, 5f);
	graphics::_0xD39D13C9FEBF0511(1);
	graphics::_set_screen_draw_position(82, 66);
	ui::set_hud_component_position(17, 0.612f, 0.818f);
	graphics::_screen_draw_position_end();
	func_118(&uParam0->f_649, uParam0->f_405, uParam0->f_408, 45f, 18, 13, 3, uParam0->f_1.f_9, 0, 0, -1082130432, 0);
	iVar3 = interior::get_interior_at_coords(uParam0->f_401);
	if (iVar3 != 0) {
		interior::_load_interior(iVar3);
	}
	interior::_0xAF348AFCB575A441(&Global_87770[uParam0->f_1.f_1 /*15*/].f_7);
	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		interior::_0x405DC2AEF6AF95B9(interior::get_key_for_entity_in_room(player::player_ped_id()));
	}
	func_117(0);
	func_116();
	audio::register_script_with_audio(0);
	if (gameplay::is_pc_version()) {
		graphics::_push_scaleform_movie_function(uParam0->f_414, "TOGGLE_MOUSE_BUTTONS");
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
	uParam0->f_466 = controls::_0x80C2FD58D720C801(2, 10, 1);
	gameplay::set_bit(&uParam0->f_449, 2);
	G_DisableMessagesAndCalls3 = 1;
	func_6(uParam0, uParam0->f_464, 0);
}

// Position - 0x601E
void func_116() {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < Global_101700.f_19369.f_145) {
		func_15(iVar0);
		iVar0++;
	}
	Global_101700.f_19369.f_145 = 0;
	iVar0 = 0;
	while (iVar0 < 2) {
		Global_101700.f_19369.f_146[iVar0] = 0;
		iVar0++;
	}
	if (ui::is_help_message_being_displayed()) {
		ui::clear_help(1);
	}
}

// Position - 0x607C
void func_117(int iParam0) {
	if (!iParam0) {
		Global_100344 = gameplay::get_game_timer() + 250;
	}
	Global_100341 = iParam0;
}

// Position - 0x609A
void func_118(var *uParam0, vector3 vParam1, vector3 vParam4, float fParam7, int iParam8, int iParam9, int iParam10,
			  var uParam11, int iParam12, int iParam13, float fParam14, int iParam15) {
	uParam0->f_1 = {vParam1};
	uParam0->f_4 = {vParam4};
	uParam0->f_7 = fParam7;
	uParam0->f_20 = iParam8;
	uParam0->f_21 = iParam9;
	uParam0->f_22 = iParam10;
	uParam0->f_8 = {0f, 0f, 0f};
	uParam0->f_11 = {0f, 0f, 0f};
	uParam0->f_14 = {0f, 0f, 0f};
	uParam0->f_17 = fParam7;
	uParam0->f_18 = fParam7;
	uParam0->f_23 = iParam12;
	uParam0->f_19 = uParam11;
	*uParam0 = cam::create_cam("DEFAULT_SCRIPTED_CAMERA", 0);
	cam::set_cam_active(*uParam0, 1);
	cam::set_cam_params(*uParam0, uParam0->f_1, uParam0->f_4, uParam0->f_7, 0, 1, 1, 2);
	if (!iParam15) {
		cam::shake_cam(*uParam0, "HAND_SHAKE", 0.19f);
	}
	cam::render_script_cams(1, 0, 3000, 1, 0, 0);
	if (fParam14 > 0f) {
		cam::set_cam_near_clip(*uParam0, fParam14);
	}
	if (uParam0->f_23) {
		ui::lock_minimap_angle(iParam13);
	}
	uParam0->f_24 = 0;
	uParam0->f_25 = 0;
	uParam0->f_29 = 0f;
	uParam0->f_30 = 0f;
	uParam0->f_26 = 0;
	uParam0->f_28 = 0;
	uParam0->f_27 = 0;
}

// Position - 0x6192
void func_119() { Global_17151.f_5 = 1; }

// Position - 0x61A0
void func_120(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (iParam0 == 0) {
		return;
	}
	if (!entity::does_entity_exist(iParam0)) {
		return;
	}
	iVar0 = func_128(iParam0);
	if (iVar0 != -1) {
		iVar1 = Global_36715[iVar0 /*5*/];
		func_123(1, iVar1, 1);
		return;
	}
	iVar2 = func_122(iParam0);
	if (iVar2 == -1) {
		return;
	}
	func_121(iVar2);
}

// Position - 0x61F9
void func_121(int iParam0) {
	if (iParam0 < 0 || iParam0 >= 5) {
		return;
	}
	if (Global_36689[iParam0 /*5*/].f_1 != 0) {
		if (Global_36689[iParam0 /*5*/].f_1 == player::player_ped_id()) {
			Global_36910 = 0;
		}
	}
	Global_36689[iParam0 /*5*/] = 13;
	Global_36689[iParam0 /*5*/].f_1 = 0;
	Global_36689[iParam0 /*5*/].f_2 = 0;
	Global_36689[iParam0 /*5*/].f_3 = 0;
	Global_36689[iParam0 /*5*/].f_4 = 0;
	Global_36688--;
	if (Global_36688 < 0) {
		Global_36688 = 0;
	}
}

// Position - 0x627C
int func_122(int iParam0) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 5) {
		if (Global_36689[iVar0 /*5*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x62AD
void func_123(int iParam0, int iParam1, int iParam2) { func_124(iParam0, iParam1, iParam2, 0, 0); }

// Position - 0x62C1
void func_124(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam0 == -1) {
		return;
	}
	if (iParam1 == -1) {
		return;
	}
	if (iParam2 == 6) {
		return;
	}
	if (func_126(iParam0, iParam1, iParam2)) {
		return;
	}
	iVar0 = func_125();
	if (iVar0 == -1) {
		return;
	}
	Global_36796[iVar0 /*5*/] = iParam0;
	Global_36796[iVar0 /*5*/].f_1 = iParam1;
	Global_36796[iVar0 /*5*/].f_2 = iParam2;
	Global_36796[iVar0 /*5*/].f_3 = iParam3;
	Global_36796[iVar0 /*5*/].f_4 = iParam4;
}

// Position - 0x6338
int func_125() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36796[iVar0 /*5*/].f_2 == 6) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x6369
bool func_126(int iParam0, int iParam1, int iParam2) {
	if (func_127(iParam0, iParam1, iParam2) == -1) {
		return false;
	}
	return true;
}

// Position - 0x6384
int func_127(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (iParam2 == Global_36796[iVar0 /*5*/].f_2) {
			if (iParam0 == Global_36796[iVar0 /*5*/]) {
				if (iParam1 == Global_36796[iVar0 /*5*/].f_1) {
					return iVar0;
				}
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x63D0
int func_128(int iParam0) {
	int iVar0;

	if (iParam0 == 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 16) {
		if (Global_36715[iVar0 /*5*/] != -1) {
			if (iParam0 == Global_36715[iVar0 /*5*/].f_1) {
				return iVar0;
			}
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x6419
void func_129(int *iParam0) {
	int iVar0;

	if (*iParam0 == -1) {
		return;
	}
	iVar0 = func_130(*iParam0);
	if (iVar0 == -1) {
		*iParam0 = -1;
		return;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/].f_7 = 1;
			*iParam0 = -1;
			return;
		}
	}
	*iParam0 = -1;
}

// Position - 0x6470
int func_130(int iParam0) {
	int iVar0;

	if (iParam0 < 0) {
		return -1;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/].f_1 == iParam0) {
			return iVar0;
		}
		iVar0++;
	}
	return -1;
}

// Position - 0x64AB
bool func_131(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = func_130(iParam0);
	if (iVar0 == -1) {
		return false;
	}
	if (!player::is_player_playing(player::get_player_index())) {
		return false;
	}
	if (func_142(0)) {
		return false;
	}
	if (cutscene::is_cutscene_playing()) {
		return false;
	}
	if (iVar0 > -1 && iVar0 < 6) {
		if (Global_36484[iVar0 /*32*/] == 1 && Global_36484[iVar0 /*32*/].f_4 == 1) {
			if (iParam1) {
				if (Global_36484[iVar0 /*32*/].f_29) {
					return false;
				}
			}
			Global_36484[iVar0 /*32*/].f_5 = 1;
			Global_36484[iVar0 /*32*/].f_29 = 1;
			return true;
		}
		else {
			if (Global_36484[iVar0 /*32*/] == 0) {
			}
			if (Global_36484[iVar0 /*32*/].f_7) {
			}
		}
	}
	return false;
}

// Position - 0x6563
void func_132(var *uParam0, int iParam1, char *sParam2, int iParam3, char *sParam4, int iParam5, int iParam6) {
	int iVar0;

	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("context_controller")) < 1) {
	}
	if (streaming::is_player_switch_in_progress()) {
		if (*uParam0 != -1) {
			func_129(uParam0);
		}
		return;
	}
	if (*uParam0 != -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 6) {
		if (!Global_36484[iVar0 /*32*/]) {
			Global_36484[iVar0 /*32*/] = 1;
			Global_36484[iVar0 /*32*/].f_1 = Global_36685;
			Global_36685++;
			Global_36484[iVar0 /*32*/].f_4 = 0;
			Global_36484[iVar0 /*32*/].f_29 = 0;
			Global_36484[iVar0 /*32*/].f_5 = 0;
			Global_36484[iVar0 /*32*/].f_2 = iParam1;
			StringCopy(&Global_36484[iVar0 /*32*/].f_8, sParam2, 16);
			Global_36484[iVar0 /*32*/].f_6 = iParam3;
			Global_36484[iVar0 /*32*/].f_31 = script::get_id_of_this_thread();
			Global_36484[iVar0 /*32*/].f_7 = 0;
			Global_36484[iVar0 /*32*/].f_3 = iParam5;
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				Global_36484[iVar0 /*32*/].f_12 = 1;
				StringCopy(&Global_36484[iVar0 /*32*/].f_13, sParam4, 64);
				Global_36484[iVar0 /*32*/].f_30 = iParam6;
			}
			else {
				Global_36484[iVar0 /*32*/].f_12 = 0;
				Global_36484[iVar0 /*32*/].f_30 = 0;
			}
			*uParam0 = Global_36484[iVar0 /*32*/].f_1;
			return;
		}
		iVar0++;
	}
}

// Position - 0x668E
bool func_133(int iParam0) {
	int iVar0;

	if (player::is_player_playing(player::player_id())) {
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (!ped::is_ped_injured(player::player_ped_id())) {
				iVar0 = func_92();
				if (!func_94(iVar0)) {
					return false;
				}
				switch (iParam0) {
				case 9:
				case 0:
					if (!player::is_player_ready_for_cutscene(player::player_id()) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_getting_into_a_vehicle(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_141() || Global_100747 ||
						Global_25192 || func_140() || func_98(8, -1) || func_139() || func_138() || func_137() ||
						func_136() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 1:
					if (player::is_player_being_arrested(player::player_id(), 1) || func_141() || Global_25192 ||
						func_140() || func_98(8, -1) || func_137() || func_139() || func_138() || func_136() ||
						G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 2:
					if (!player::is_player_ready_for_cutscene(player::player_id()) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_getting_into_a_vehicle(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_141() || Global_100747 ||
						Global_25192 || func_140() || func_98(8, -1) || func_137() || func_139() || func_138() ||
						func_136() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5 || LastDispatchedMessageOrCall != -1) {
						return false;
					}
					break;

				case 3:
					if (ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						ped::is_ped_in_combat(player::player_ped_id(), 0) || func_141() || Global_100747 ||
						Global_25192 || func_140() || func_98(8, -1) || func_139() || func_138() || func_136() ||
						G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 4:
					if (func_141() || player::get_player_wanted_level(player::player_id()) > 0 || func_98(8, -1) ||
						func_136() || func_135() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 5:
					if (func_98(8, -1) || func_139() || func_138() || func_135() || func_134()) {
						return false;
					}
					if (streaming::is_player_switch_in_progress() && streaming::get_player_switch_type() != 3 &&
						streaming::get_player_switch_state() < 8) {
						return false;
					}
					break;

				case 6:
					if (entity::does_entity_exist(player::player_ped_id())) {
						if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
							player::get_player_wanted_level(player::player_id()) > 0 ||
							entity::is_entity_in_air(player::player_ped_id()) ||
							ped::is_ped_ragdoll(player::player_ped_id()) ||
							ped::is_ped_falling(player::player_ped_id()) ||
							player::is_player_being_arrested(player::player_id(), 1) ||
							player::is_player_climbing(player::player_id()) || func_141() || Global_25192 ||
							func_140() || func_98(8, -1) || func_138() || func_137() || func_136() ||
							G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
							return false;
						}
					}
					break;

				case 7:
					if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
						!player::is_player_control_on(player::player_id()) ||
						!player::is_player_ready_for_cutscene(player::player_id()) || !cam::is_screen_faded_in() ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) || func_141() || func_138() ||
						Global_100747 || Global_25192 || func_140() || Global_36912 || func_98(8, -1) || func_137() ||
						func_135() || func_136() || G_SomeGlobalState.MessageCallStates.f_919[iVar0] == 5) {
						return false;
					}
					break;

				case 8:
					if (ped::is_ped_in_combat(player::player_ped_id(), 0) ||
						!player::is_player_control_on(player::player_id()) ||
						!player::is_player_ready_for_cutscene(player::player_id()) || !cam::is_screen_faded_in() ||
						player::is_player_wanted_level_greater(player::player_id(), 0) ||
						entity::is_entity_in_air(player::player_ped_id()) ||
						ped::is_ped_in_any_vehicle(player::player_ped_id(), 1) ||
						ped::is_ped_ragdoll(player::player_ped_id()) || ped::is_ped_falling(player::player_ped_id()) ||
						ped::is_ped_swimming(player::player_ped_id()) ||
						player::is_player_being_arrested(player::player_id(), 1) ||
						player::is_player_climbing(player::player_id()) || func_141() || Global_100747 ||
						Global_25192 || func_140() || func_98(8, -1) || func_137() || func_135() || func_139() ||
						func_138() || func_136()) {
						return false;
					}
					break;
				}
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	else {
		return false;
	}
	return true;
}

// Position - 0x6DAB
var func_134() { return Global_91530.f_1; }

// Position - 0x6DB9
int func_135() {
	if (Global_88746 != -1) {
		return gameplay::is_bit_set(Global_82612[Global_88746 /*34*/].f_15, 13);
	}
	return 0;
}

// Position - 0x6DDF
int func_136() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("player_timetable_scene")) > 0) {
		return 1;
	}
	return 0;
}

// Position - 0x6DF9
int func_137() {
	if (Global_69962) {
		return 1;
	}
	else if (Global_55816 && !Global_55822) {
		return 1;
	}
	return 0;
}

// Position - 0x6E23
bool func_138() { return Global_91543.f_304 > 0; }

// Position - 0x6E34
bool func_139() { return Global_91543.f_303 > 0; }

// Position - 0x6E45
var func_140() { return Global_1315233; }

// Position - 0x6E51
int func_141() {
	if (!network::network_is_game_in_progress()) {
		return Global_89302.f_44 == 1;
	}
	return 0;
}

// Position - 0x6E6D
bool func_142(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x6EC7
bool func_143(int iParam0) { return func_144(iParam0, Global_35781); }

// Position - 0x6ED8
int func_144(int iParam0, int iParam1) {
	if (iParam1 == 15) {
		return 1;
	}
	if (iParam0 == 15) {
		return 0;
	}
	switch (iParam0) {
	case 16:
		switch (iParam1) {
		case 9:
		case 10:
		case 7:
		case 13:
		case 14: return 0;
		}
		return 1;

	case 0:
		switch (iParam1) {
		case 5:
		case 17: return 1;
		}
		break;

	case 2:
	case 3:
		switch (iParam1) {
		case 5:
		case 6:
		case 8:
		case 17: return 1;
		}
		break;

	case 4:
		if (iParam1 == 17) {
			return 1;
		}
		break;

	case 5: break;

	case 6:
	case 8:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 7:
		if (iParam1 == 6) {
			return 1;
		}
		break;

	case 9:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 10:
		switch (iParam1) {
		case 5:
		case 6:
		case 17: return 1;
		}
		break;

	case 11:
		if (iParam1 == 5) {
			return 1;
		}
		break;

	case 17:
		switch (iParam1) {
		case 17:
		case 12:
		case 5: return 1;
		}
		break;

	case 18:
	case 12:
		switch (iParam1) {
		case 5:
		case 6:
		case 8: return 1;
		}
		break;

	case 13:
		switch (iParam1) {
		case 5: return 1;
		}
		break;

	case 14:
		switch (iParam1) {
		case 5: return 1;
		}
		break;
	}
	return 0;
}

// Position - 0x70B9
void func_145() {
	int iVar0;
	vector3 vVar1;

	if (func_221(17)) {
		if (!gameplay::is_bit_set(iLocal_41, 11)) {
			cutscene::request_cutscene("JH_1_MCS_4P2", 8);
			script::request_script("lesterHandler");
			ui::request_additional_text("JHS1AUD", 6);
			gameplay::set_bit(&iLocal_41, 11);
		}
		else if (cutscene::_0xB56BBBCC2955D9CB()) {
			cutscene::set_cutscene_ped_prop_variation("LESTER", 1, 0, 0, 0);
		}
	}
	if (func_221(18)) {
		if (func_221(17)) {
			if (cutscene::has_this_cutscene_loaded("JH_1_MCS_4P2") && script::has_script_loaded("lesterHandler") &&
				ui::has_additional_text_loaded(6)) {
				if (!entity::is_entity_dead(iLocal_729, 0)) {
					cutscene::register_entity_for_cutscene(iLocal_729, "Lester", 0, joaat("cs_lestercrest"), 0);
				}
				else {
					cutscene::register_entity_for_cutscene(iLocal_729, "Lester", 2, joaat("cs_lestercrest"), 0);
				}
				if (entity::does_entity_exist(iLocal_732)) {
					if (entity::is_entity_attached_to_any_ped(iLocal_732)) {
						entity::detach_entity(iLocal_732, 1, 1);
					}
				}
				if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
					cutscene::register_entity_for_cutscene(player::player_ped_id(), "Michael", 0, joaat("player_zero"),
														   0);
				}
				if (entity::does_entity_exist(iLocal_732)) {
					cutscene::register_entity_for_cutscene(iLocal_732, "WalkingStick_Lester", 1,
														   joaat("prop_cs_walking_stick"), 0);
				}
				else {
					cutscene::register_entity_for_cutscene(iLocal_732, "WalkingStick_Lester", 2,
														   joaat("prop_cs_walking_stick"), 0);
				}
				streaming::request_model(joaat("prop_cs_walking_stick"));
				streaming::request_model(joaat("prop_laptop_lester2"));
				func_72(1);
				func_117(1);
				func_185(1, 1, 1, 0);
				iLocal_43 = -1;
				cutscene::start_cutscene(0);
				if (func_110(0)) {
					cutscene::set_cutscene_fade_values(0, 0, 0, 0);
				}
				func_106(17, 0);
			}
		}
		else if (cutscene::is_cutscene_playing()) {
			func_113();
			if (gameplay::is_bit_set(iLocal_41, 7)) {
				if (entity::does_entity_exist(iLocal_732)) {
					entity::set_entity_visible(iLocal_732, 1, 0);
				}
				if (entity::does_entity_exist(iLocal_730)) {
					entity::set_entity_visible(iLocal_730, 1, 0);
				}
				if (entity::does_entity_exist(iLocal_729)) {
					entity::set_entity_visible(iLocal_729, 1, 0);
				}
				gameplay::clear_bit(&iLocal_41, 7);
			}
			if (cutscene::can_set_exit_state_for_registered_entity("Lester", 0)) {
				if (!ped::is_ped_injured(iLocal_729)) {
					iVar0 = iLocal_729;
					system::start_new_script_with_args("lesterHandler", &iVar0, 1, 1424);
					script::set_script_as_no_longer_needed("lesterHandler");
					iLocal_739 = gameplay::get_game_timer();
					gameplay::set_bit(&iLocal_41, 18);
				}
			}
			if (cutscene::can_set_exit_state_for_registered_entity("Michael", 0)) {
				if (!ped::is_ped_injured(player::player_ped_id())) {
					vVar1 = {709.3766f, -964.2602f, 29.3954f};
					gameplay::get_ground_z_for_3d_coord(vVar1, &vVar1.f_2, 0);
					if (!ped::is_ped_injured(player::player_ped_id())) {
						entity::set_entity_coords(player::player_ped_id(), vVar1, 1, 0, 0, 1);
						entity::set_entity_heading(player::player_ped_id(), 261.7831f);
						if (player::is_player_playing(player::player_id())) {
							player::simulate_player_input_gait(player::player_id(), 1f, 2000, 0, 1, 0);
						}
						ped::force_ped_motion_state(player::player_ped_id(), -668482597, 0, 0, 0);
					}
					ped::_0x2208438012482A1A(player::player_ped_id(), 0, 0);
				}
			}
			if (cutscene::can_set_exit_state_for_camera(0)) {
				cam::set_gameplay_cam_relative_heading(0f);
				cam::set_gameplay_cam_relative_pitch(0f, 1065353216);
			}
		}
		else if (iLocal_43 == -1 && !func_110(0)) {
			iLocal_43 = gameplay::get_game_timer() + 1500;
		}
		else if (gameplay::get_game_timer() > iLocal_43 || func_110(0)) {
			if (func_110(0)) {
				cam::do_screen_fade_out(0);
			}
			else {
				Global_55822 = 0;
				Global_91530 = 0;
				func_184();
			}
			streaming::set_model_as_no_longer_needed(joaat("prop_cs_walking_stick"));
			streaming::set_model_as_no_longer_needed(joaat("prop_laptop_lester2"));
			func_72(0);
			func_185(0, 1, 1, 0);
			func_182(&Global_101700.f_2095.f_539, 86);
			func_154(&Global_101700.f_2095.f_539, 86);
			func_153(&iLocal_45);
			gameplay::clear_bit(&iLocal_41, 1);
			ped::remove_scenario_blocking_area(iLocal_733, 0);
			if (iLocal_738 != -1) {
				if (pathfind::does_navmesh_blocking_object_exist(iLocal_738)) {
					pathfind::remove_navmesh_blocking_object(iLocal_738);
				}
			}
			ped::clear_ped_non_creation_area();
			pathfind::set_ped_paths_in_area(Local_46.f_1.f_394 - Local_46.f_1.f_397,
											Local_46.f_1.f_394 + Local_46.f_1.f_397, 1, 0);
			player::set_max_wanted_level(5);
			func_106(18, 0);
			func_146(0, 0);
		}
	}
	else if (!func_221(17)) {
		if (cutscene::has_this_cutscene_loaded("JH_1_MCS_4P2")) {
			cutscene::remove_cutscene();
		}
	}
	if (gameplay::is_bit_set(iLocal_41, 18)) {
		controls::disable_control_action(0, 26, 1);
		if (gameplay::get_game_timer() > iLocal_739 + 1000) {
			gameplay::clear_bit(&iLocal_41, 18);
		}
	}
}

// Position - 0x74B5
void func_146(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	while (iVar0 < 14) {
		iVar1 = iVar0;
		if (func_39(iVar1) || func_38(iVar1)) {
			if (!(iVar1 == 11 && iParam0 == 3)) {
				switch (iVar1) {
				case 1: func_150(4, 1); break;

				case 4: func_150(8, 1); break;

				case 6: func_150(10, 1); break;

				case 7: func_150(1, 1); break;

				case 8: func_150(3, 1); break;

				case 9: func_150(6, 1); break;

				case 10: func_150(9, 1); break;

				case 12: func_150(11, 1); break;

				case 13: func_150(12, 1); break;

				case 11:
					if (func_149(91)) {
						func_150(0, 1);
					}
					break;

				case 5:
					if (func_149(91)) {
						func_150(2, 1);
					}
					break;

				case 3:
					if (func_149(67)) {
						func_150(5, 1);
					}
					break;

				case 2:
					if (func_149(77)) {
						func_150(7, 1);
					}
					break;
				}
			}
		}
		iVar0++;
	}
	if (!func_39(10) && gameplay::is_bit_set(Global_101700.f_23954.f_8[4], 0)) {
		func_150(9, 1);
	}
	if (!func_39(13) && gameplay::is_bit_set(Global_101700.f_23954.f_8[16], 0)) {
		func_150(12, 1);
	}
	if (!func_39(12)) {
		if (iParam0 == 4) {
			func_150(11, 1);
		}
	}
	if (!iParam1) {
		if (!func_148(69)) {
			func_21("DI_HLP_HST", 2, 0, 20000, 10000, 7, 0, 209, 0);
		}
		func_147("DI_FEED_HST");
	}
}

// Position - 0x7681
void func_147(char *sParam0) {
	ui::_set_notification_text_entry("");
	ui::_set_notification_message_3("CHAR_ACTING_UP", "CHAR_ACTING_UP", 0, 0, "DI_FEED_CHAR", sParam0);
}

// Position - 0x76A5
int func_148(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		return gameplay::is_bit_set(Global_101700.f_19369.f_150[iVar1], iVar0);
	}
	return 0;
}

// Position - 0x76E8
bool func_149(int iParam0) {
	if (iParam0 == 94 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_330[iParam0 /*6*/];
}

// Position - 0x7714
void func_150(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 >= 0 && iVar0 <= 31) {
		if (!func_152(iParam0)) {
			gameplay::set_bit(&Global_101700.f_25393.f_1, iVar0);
			if (!iParam1) {
				func_147(func_151(iParam0));
			}
		}
	}
}

// Position - 0x775D
char *func_151(int iParam0) {
	switch (iParam0) {
	case 0: return "CM_HSTCHE";

	case 1: return "CM_HSTCHR";

	case 2: return "CM_HSTDAR";

	case 3: return "CM_HSTEDD";

	case 4: return "CM_HSTGUS";

	case 5: return "CM_HSTHUG";

	case 6: return "CM_HSTKRM";

	case 7: return "CM_HSTKAR";

	case 8: return "CM_HSTNOR";

	case 9: return "CM_HSTPAC";

	case 10: return "CM_HSTPAI";

	case 11: return "CM_HSTRIC";

	case 12: return "CM_HSTTAL";
	}
	return "ERROR!";
}

// Position - 0x7840
int func_152(int iParam0) {
	if (iParam0 != -1 && iParam0 != 13) {
		return gameplay::is_bit_set(Global_101700.f_25393.f_1, iParam0);
	}
	return 0;
}

// Position - 0x786F
void func_153(int *iParam0) {
	if (*iParam0 == -1) {
		return;
	}
	if (*iParam0 != Global_35743) {
		*iParam0 = -1;
		return;
	}
	*iParam0 = -1;
	Global_35742 = 0;
	Global_35744 = 0;
	Global_35781 = 15;
	Global_55819 = 0;
	Global_55820 = 0;
}

// Position - 0x78AC
void func_154(var *uParam0, int iParam1) {
	switch (iParam1) {
	case 17: func_155(uParam0, 0, 12); break;

	case 19: func_155(uParam0, 1, 13); break;

	case 29: func_155(uParam0, 1, 14); break;

	case 30:
		func_155(uParam0, 2, 15);
		func_155(uParam0, 1, 29);
		break;

	case 32:
		func_155(uParam0, 1, 16);
		func_155(uParam0, 0, 17);
		break;

	case 39:
		func_155(uParam0, 0, 21);
		func_155(uParam0, 1, 20);
		break;

	case 31: func_155(uParam0, 0, 18); break;

	case 20: func_155(uParam0, 2, 22); break;

	case 66: func_155(uParam0, 1, 23); break;

	case 68: func_155(uParam0, 1, 24); break;

	case 70: func_155(uParam0, 1, 67); break;

	case 8:
		func_155(uParam0, 1, 25);
		func_155(uParam0, 2, 26);
		break;

	case 67: func_155(uParam0, 1, 27); break;

	case 9: func_155(uParam0, 2, 28); break;

	case 38:
		func_155(uParam0, 2, 30);
		func_155(uParam0, 1, 19);
		break;

	case 83: func_155(uParam0, 2, 33); break;

	case 45: func_155(uParam0, 1, 35); break;

	case 64:
		func_155(uParam0, 0, 36);
		func_155(uParam0, 1, 37);
		break;

	case 91: func_155(uParam0, 0, 41); break;

	case 42:
		func_155(uParam0, 0, 58);
		Global_90960[0 /*98*/] = 0;
		func_155(uParam0, 2, 59);
		Global_90960[2 /*98*/] = 0;
		break;

	case 41:
		func_155(uParam0, 1, 42);
		func_155(uParam0, 2, 42);
		break;

	case 15:
		func_155(uParam0, 0, 46);
		func_155(uParam0, 1, 47);
		break;

	case 16: func_155(uParam0, 0, 48); break;

	case 48:
		func_155(uParam0, 1, 50);
		func_155(uParam0, 2, 51);
		break;

	case 74:
		func_155(uParam0, 0, 52);
		func_155(uParam0, 1, 66);
		break;

	case 76:
		func_155(uParam0, 1, 53);
		func_155(uParam0, 2, 54);
		func_155(uParam0, 0, 62);
		break;

	case 75:
		func_155(uParam0, 0, 61);
		func_155(uParam0, 1, 31);
		break;

	case 69: func_155(uParam0, 1, 63); break;

	case 84:
		func_155(uParam0, 0, 68);
		func_155(uParam0, 2, 69);
		break;

	case 85:
		func_155(uParam0, 0, 64);
		func_155(uParam0, 2, 65);
		break;

	case 93:
		func_155(uParam0, 1, 38);
		func_155(uParam0, 2, 39);
		break;

	case 11: func_155(uParam0, 2, 55); break;

	case 77:
		func_155(uParam0, 1, 56);
		func_155(uParam0, 2, 57);
		break;

	default: break;
	}
}

// Position - 0x7BF5
int func_155(var *uParam0, int iParam1, int iParam2) {
	int iVar0;
	struct<98> Var1;
	var *uVar99;
	float *fVar102;
	var *uVar103;
	float *fVar106;

	if (!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9)) {
		iVar0 = Global_101700.f_17492[iParam1];
		if (iVar0 == 11) {
			return 0;
		}
		if (iVar0 == 8 || iVar0 == 9 || iVar0 == 10) {
			return 0;
		}
	}
	Global_101700.f_17492[iParam1] = iParam2;
	uParam0->f_1524[iParam1] = func_171();
	if (!func_170(iParam2, &uParam0->f_1528[iParam1 /*3*/], &uParam0->f_1538[iParam1])) {
		return 0;
	}
	if (!func_169(uParam0->f_1528[iParam1 /*3*/], 0f, 0f, 0f, 0)) {
		if (!func_169(Global_Switch_Positions[iParam2 /*3*/], 0f, 0f, 0f, 0)) {
			Var1.f_11 = 12;
			Var1.f_31 = 49;
			Var1.f_81 = 2;
			if (func_156(iParam1, iParam2, &Var1, &uVar99, &fVar102, &uVar103, &fVar106)) {
				Global_90960[iParam1 /*98*/] = {Var1};
			}
		}
	}
	uParam0->f_1542[iParam1] = 0;
	uParam0->f_1546[iParam1 /*3*/] = {0f, 0f, 0f};
	uParam0->f_1556[iParam1] = 0;
	return 1;
}

// Position - 0x7D15
bool func_156(int iParam0, int iParam1, int *iParam2, var *uParam3, float *fParam4, var *uParam5, float *fParam6) {
	iParam2->f_3 = 1000;
	iParam2->f_1 = 0;
	iParam2->f_84 = 255;
	iParam2->f_85 = 255;
	iParam2->f_86 = 255;
	switch (iParam1) {
	case 5:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			if (object::is_point_in_angled_area(Global_91263[iParam0 /*3*/], -829.7478f, 192.117f, 76.73248f,
												-827.1384f, 153.8595f, 59.96172f, 33.25f, 0, 1)) {
				if (Global_91255[iParam0] == 1) {
					*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
					*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
					if (system::vmag2(*uParam3) > 5f * 5f) {
						*uParam3 = {0f, 0f, 0f};
						*fParam4 = 0f;
						return false;
					}
				}
			}
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 6:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 7:
		*iParam2 = {Global_90960[iParam0 /*98*/]};
		if (Global_91255[iParam0] != 2) {
			*uParam3 = {Global_91263[iParam0 /*3*/] - Global_101700.f_2095.f_539.f_1528[iParam0 /*3*/]};
			*fParam4 = Global_91273[iParam0] - Global_101700.f_2095.f_539.f_1538[iParam0];
			if (system::vmag2(*uParam3) < 0.5f * 0.5f) {
				*uParam3 = {*uParam3 * FtoV(1.5f)};
			}
		}
		else {
			*uParam3 = {0f, 0f, 0f};
			*fParam4 = 0f;
		}
		return true;

	case 11:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {37.43f, -23.81f, 0f};
		*fParam4 = 127f;
		return true;

	case 8:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(28.826f, -1277.56f, -90.961f) - Vector(28.3203f, -1324.195f, -90.0089f)};
		*fParam4 = 1.27f - 194.1887f;
		return true;

	case 9: return func_156(iParam0, 8, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 10: return func_156(iParam0, 8, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 13:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 5f, 0f};
		*fParam6 = 5f;
		return true;

	case 14:
		func_158(iParam0, iParam2, 2);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 15:
		iParam2->f_97 = 0;
		*iParam2 = joaat("frogger");
		iParam2->f_5 = 34;
		iParam2->f_6 = 34;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 50f, 0f};
		*fParam6 = 15f;
		return true;

	case 55:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(4.8006f, -2965.499f, 782.1644f) - Vector(4.0205f, -2975.341f, 798.4536f)};
		*fParam4 = 246.1684f - 90f;
		return true;

	case 56:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 20f;
		return true;

	case 57:
		iParam2->f_97 = 0;
		*iParam2 = joaat("penumbra");
		*uParam3 = {Vector(28.764f, -1431.464f, 66.028f) - Vector(28.2954f, -1351.52f, 37.5988f)};
		*fParam4 = 141.28f - 90.0339f;
		return true;

	case 12:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam5 = {0f, 5f, 0f};
		*fParam6 = 5f;
		return true;

	case 16:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 15f, 0f};
		*fParam6 = 5f;
		return true;

	case 17:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 15f;
		return true;

	case 18:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 19:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 15f, 0f};
		*fParam6 = 10f;
		return true;

	case 20:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 23: return func_156(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 24:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 25f;
		return true;

	case 67:
		func_158(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {21.6401f, 38.5601f, 1.9708f};
		*fParam4 = -84f;
		return true;

	case 58:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 59:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 60:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 22:
		iParam2->f_97 = 0;
		*iParam2 = joaat("phantom");
		*uParam5 = {0f, 50f, 0f};
		*fParam6 = 20f;
		return true;

	case 74:
		func_158(iParam0, iParam2, 1);
		iParam2->f_91 = 2;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 10f;
		return true;

	case 38:
		func_158(iParam0, iParam2, 2);
		iParam2->f_91 = 2;
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 15f;
		return true;

	case 41:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-2.72f, 0.45f, 1f};
		*fParam4 = -137f;
		return true;

	case 25:
		iParam2->f_97 = 0;
		*iParam2 = joaat("blista");
		*uParam3 = {Vector(29.17f, -1417.047f, 54.081f) - Vector(28.2915f, -1464.68f, 72.2278f)};
		*fParam4 = 0.72f - 156.8827f;
		return true;

	case 27:
		iParam2->f_97 = 0;
		*iParam2 = joaat("seminole");
		*uParam3 = {Vector(24.9f, -938.8f, 792.3f) - Vector(24.2312f, -906f, 763f)};
		*fParam4 = 2.23f - 7.2736f;
		return true;

	case 26:
		iParam2->f_97 = 0;
		*iParam2 = joaat("peyote");
		*uParam3 = {Vector(28.701f, -1090.07f, 306.036f) - Vector(28.3684f, -1120.786f, 257.9167f)};
		*fParam4 = -1f - 97.2736f;
		return true;

	case 40:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {16.5182f, -8.5576f, -2.3291f};
		*fParam4 = 174.24f;
		return true;

	case 28:
		iParam2->f_97 = 0;
		*iParam2 = joaat("polmav");
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 234:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {16.5182f, -8.5576f, -2.3291f};
		*fParam4 = 174.24f;
		return true;

	case 75:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {2.5f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 76:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {2.5f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 42:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(4.8006f, -2965.499f, 782.1644f) - Vector(4.0205f, -2975.341f, 798.4536f)};
		*fParam4 = 246.1684f - 90f;
		return true;

	case 43:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mesa");
		*uParam3 = {Vector(5.4446f, -2912.043f, 659.5297f) - Vector(5.0589f, -2916.479f, 709.0244f)};
		*fParam4 = 247.4806f - 355.326f;
		return true;

	case 44:
		iParam2->f_97 = 0;
		*iParam2 = joaat("sadler");
		*uParam3 = {Vector(5.1176f, -2936.843f, 656.9753f) - Vector(5.1337f, -2917.325f, 643.5248f)};
		*fParam4 = 253.776f - 334.1068f;
		return true;

	case 45:
		iParam2->f_97 = 0;
		*iParam2 = joaat("mixer");
		*uParam3 = {Vector(5.681f, -2769.795f, 593.033f) - Vector(5.0558f, -2819.085f, 594.4415f)};
		*fParam4 = 2.62f - 299.0519f;
		return true;

	case 47:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cavalcade");
		iParam2->f_5 = 0;
		iParam2->f_6 = 0;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		StringCopy(&iParam2->f_27, "22LJK483", 16);
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {0f, 10f, 0f};
		*fParam6 = 15f;
		return true;

	case 49:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {-1.5f, 35f, 3f};
		*fParam6 = 15f;
		return true;

	case 48:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {3.8721f, -5.9568f, 0f};
		*fParam4 = 164.2466f - 180f;
		return true;

	case 50:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 10f, 0f};
		*fParam6 = 15f;
		return true;

	case 51:
		iParam2->f_97 = 0;
		*iParam2 = joaat("stretch");
		*uParam3 = {Vector(28.1755f, -550.2679f, -1170.72f) - Vector(30.2361f, -526.9999f, -1257.5f)};
		*fParam4 = 310.4708f - 220.9554f;
		return true;

	case 52:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 12.5f;
		return true;

	case 66:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 12.5f;
		return true;

	case 61:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 62:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 25f;
		return true;

	case 63:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-2.9117f, -15.0499f, -0.3468f};
		*fParam4 = -139.9751f;
		return true;

	case 64:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 69:
		iParam2->f_97 = 0;
		*iParam2 = joaat("prairie");
		*uParam3 = {Vector(36.5734f, -85.1799f, -737.1358f) - Vector(54f, 111f, -852f)};
		*fParam4 = 64.1848f - 180f;
		return true;

	case 65:
	case 54:
		iParam2->f_97 = 0;
		*iParam2 = joaat("frogger2");
		iParam2->f_5 = 40;
		iParam2->f_6 = 0;
		iParam2->f_7 = 0;
		iParam2->f_8 = 0;
		iParam2->f_9 = 0;
		iParam2->f_11[0] = 1;
		iParam2->f_11[1] = 1;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 1;
		iParam2->f_11[4] = 1;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		iParam2->f_89 = 1;
		if (iParam1 == 54) {
			*uParam3 = {5.5414f, -6.6035f, 1.0473f};
			*fParam4 = -83.2547f;
		}
		if (iParam1 == 65) {
			*uParam3 = {5.7209f, -12.3958f, 1.0746f};
			*fParam4 = -152.2593f;
		}
		return true;

	case 112:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 113:
		if (func_156(iParam0, 112, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 118:
		iParam2->f_97 = 0;
		*iParam2 = joaat("scorcher");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {1f, 12.5f, 0f};
		*fParam6 = 5f;
		return true;

	case 119:
		if (func_156(iParam0, 118, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {5f, 20f, 0f};
			*fParam6 = 5f;
			return true;
		}
		break;

	case 120:
		if (func_156(iParam0, 118, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 30f, 0f};
			*fParam6 = 8f;
			return true;
		}
		break;

	case 173:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cruiser");
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 114:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {-1.9002f, 1.205f, -0.3537f};
		*fParam4 = -180f;
		return true;

	case 105:
		func_158(iParam0, iParam2, 1);
		*uParam5 = {0f, 0.1f, 0f};
		*fParam6 = 0.5f;
		return true;

	case 106: return func_156(iParam0, 105, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 107: return func_156(iParam0, 105, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 98:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 99:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		*uParam5 = {0f, 0f, 0f};
		*fParam6 = 0f;
		return true;

	case 100: return func_156(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 101: return func_156(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 102: return func_156(iParam0, 99, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 123:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {3.2267f, 1.0966f, -0.354f};
		*fParam4 = -31.73f;
		return true;

	case 125:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-13.7322f, 1.8783f, 1.0593f};
		*fParam4 = 55.3652f;
		return true;

	case 133:
		iParam2->f_97 = 0;
		*iParam2 = joaat("tropic");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0f;
		iParam2->f_11[0] = 0;
		iParam2->f_11[1] = 0;
		iParam2->f_11[2] = 1;
		iParam2->f_11[3] = 0;
		iParam2->f_11[4] = 0;
		iParam2->f_11[5] = 1;
		iParam2->f_11[6] = 1;
		iParam2->f_11[7] = 1;
		iParam2->f_11[8] = 1;
		*uParam5 = {0f, 20f, 0f};
		*fParam6 = 15f;
		return true;

	case 89:
	case 90:
	case 127:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 0f, 0f};
		*fParam6 = 0.1f;
		return true;

	case 91:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {15.4538f, -8.711f, 5.79f};
		*fParam4 = 2.4942f;
		return true;

	case 93:
		if (func_156(iParam0, 91, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-8.1f, -9.01f, 0.4439f};
			*fParam4 = 94.03f;
			return true;
		}
		break;

	case 121:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {18.8468f, 40.7721f, 0f};
		*fParam4 = -116.3936f;
		return true;

	case 115:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(43.517f, -33.7052f, -531.6035f) - Vector(45.6141f, -21.87f, -511.73f)};
		*fParam4 = 177.259f - 180f - 69f;
		return true;

	case 116:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {1.7826f, 12.2098f, -0.6964f};
		*fParam4 = -96.0001f;
		return true;

	case 117:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {11.8705f, -1.4684f, -1.6487f};
		*fParam4 = -125.8331f;
		return true;

	case 94:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-13.1578f, 16.3962f, 0.6396f};
		*fParam4 = -177f;
		return true;

	case 96:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-21.0518f, 0.5037f, 0.4091f};
		*fParam4 = -83.1262f;
		return true;

	case 108:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {10.8971f, 2.0809f, -0.7983f};
		*fParam4 = -150.9417f;
		return true;

	case 109:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {79.9901f, -52.83f, -0.3533f};
		*fParam4 = 44.7231f;
		return true;

	case 135:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 136:
		if (func_156(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 137:
		if (func_156(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 138:
		if (func_156(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {gameplay::get_random_float_in_range(-5f, 5f), gameplay::get_random_float_in_range(-5f, 5f), 0f};
			*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
			return true;
		}
		break;

	case 139:
		if (func_156(iParam0, 135, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {2.4845f, 2.3286f, -0.383f};
			*fParam4 = -31.4884f;
			return true;
		}
		break;

	case 140:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 15f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 141:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 40f, 0f};
			*fParam6 = 12.5f;
			return true;
		}
		break;

	case 142:
		func_158(iParam0, iParam2, 0);
		*uParam5 = {0f, 25f, 0f};
		*fParam6 = 10f;
		return true;

	case 143:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 144:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 145:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 146:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 147:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 15f, 0f};
			*fParam6 = 7.5f;
			return true;
		}
		break;

	case 148:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 149:
		if (func_156(iParam0, 142, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam5 = {0f, 25f, 0f};
			*fParam6 = 10f;
			return true;
		}
		break;

	case 151:
		if (func_156(iParam0, 94, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-13.2213f, 16.331f, 0f};
			*fParam4 = 6f;
			return true;
		}
		break;

	case 162:
		if (func_156(iParam0, 115, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {10.3876f, -10.3585f, -1.2183f};
			*fParam4 = 8.6726f;
			return true;
		}
		break;

	case 158:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {1.0793f, 15.631f, 1.1744f};
		*fParam4 = 2.52f;
		return true;

	case 166: return func_156(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 170:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {0f, 0f, 0f};
		*fParam4 = 0.1f;
		*uParam5 = {0.1f, 0.1f, 0.1f};
		*fParam6 = 0.1f;
		return true;

	case 171: return func_156(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 172: return func_156(iParam0, 98, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 208:
		func_158(iParam0, iParam2, 1);
		*uParam5 = {0f, 0.1f, 0f};
		*fParam6 = 0.5f;
		return true;

	case 209: return func_156(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 210: return func_156(iParam0, 208, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 211:
		func_157(iParam0, iParam2, 2);
		iParam2->f_91 = 2;
		*uParam3 = {-2.19f, -1.23f, 0f};
		*fParam4 = 90f;
		return true;

	case 212:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		iParam2->f_2 = 0f;
		*uParam3 = {-1.3547f, 2.1615f, -0.3723f};
		*fParam4 = 177.8041f;
		return true;

	case 213:
		if (func_156(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-4.2075f, 1.0943f, 0f};
			*fParam4 = 15.82f;
			return true;
		}
		break;

	case 214:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		iParam2->f_2 = 0f;
		*uParam3 = {2.291f, 1.0879f, 0.0635f};
		*fParam4 = 177.798f;
		return true;

	case 215:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {-0.9714f, 1.6112f, -0.2773f};
		*fParam4 = -7.0583f;
		*uParam5 = {Vector(183.8081f, 578.5989f, 174.7651f) - Vector(176.086f, 551.7596f, 10.9694f)};
		*fParam6 = 10f;
		return true;

	case 196:
		iParam2->f_97 = 0;
		*iParam2 = joaat("taxi");
		iParam2->f_2 = 0f;
		iParam2->f_4 = 0;
		iParam2->f_9 = 1;
		*uParam3 = {Vector(29.4846f, -1457.915f, -17.4132f) - Vector(31.1932f, -1441.182f, -14.8689f)};
		*fParam4 = 89.0026f - -1.5f;
		*uParam5 = {Vector(33.6125f, -1563.461f, -147.0307f) - Vector(31.1932f, -1441.182f, -14.8689f)};
		*fParam6 = 10f;
		return true;

	case 221:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(43.5168f, -33.5909f, -531.4f) - Vector(45.2617f, -28.54f, -521.13f)};
		*fParam4 = 357.1407f - 84.96f;
		return true;

	case 216:
		if (func_156(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-2.1752f, -2.3781f, 0f};
			*fParam4 = -68.4f;
			return true;
		}
		break;

	case 217:
		if (func_156(iParam0, 211, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-3.9761f, 0.2542f, 0f};
			*fParam4 = -70.5273f;
			return true;
		}
		break;

	case 232:
	case 233:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {Vector(28.225f, -1015.11f, -70.4456f) - Vector(27.5447f, -1019.235f, -78.4023f)};
		*fParam4 = 162.098f - 109.0206f;
		return true;

	case 192:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.403f, -1531.113f, -1190.017f) - Vector(4.7514f, -1573.632f, -1174.458f)};
		*fParam4 = 302.182f - 105.981f;
		return true;

	case 193:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.403f, -1531.113f, -1190.017f) - Vector(4.3599f, -1573.692f, -1175.298f)};
		*fParam4 = 302.182f - 172.9187f;
		return true;

	case 194:
		if (func_156(iParam0, 193, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {12.74f, 3.26f, 0f};
			*fParam4 = 95.217f;
			return true;
		}
		break;

	case 195:
		if (func_156(iParam0, 193, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-1.34f, 7.684f, 0f};
			*fParam4 = 173.52f;
			return true;
		}
		break;

	case 200:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.4055f, -1607.568f, 44.4802f) - Vector(28.2858f - 0.5f + 1.5f, -1607.286f, 2.8895f)};
		*fParam4 = 318.2674f - (310.879f - 180f);
		return true;

	case 201:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.1773f, -1592.787f, 3.6009f) - Vector(29.2903f, -1607.286f, 2.8895f)};
		*fParam4 = 322.6286f - 130.879f;
		return true;

	case 202:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {91.3579f, 18.1788f, -0.1911f};
		*fParam4 = -90.3475f;
		return true;

	case 222:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {12.5073f, -3.4625f, -0.3702f};
		*fParam4 = 14.3405f;
		return true;

	case 223:
		if (func_156(iParam0, 222, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {21.87f, -10.5f, 0f};
			*fParam4 = -104.76f;
			return true;
		}
		break;

	case 224: return func_156(iParam0, 222, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 226:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.7f, -1356.9f, 24.6f) - Vector(29.3437f, -1351.412f, 28.986f)};
		*fParam4 = 270.1767f - 160f - 180f;
		return true;

	case 227:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-19.8544f, -10.4863f, -0.0334f};
		*fParam4 = -120.12f;
		return true;

	case 228:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {21.5897f, -6.8544f, 0.6015f};
		*fParam4 = -141f;
		return true;

	case 229:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-7.6041f, 0.1369f, 0.5812f};
		*fParam4 = -145.769f;
		return true;

	case 230:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-1.6f, 7.6802f, 0.6947f};
		*fParam4 = -50.99f;
		return true;

	case 238:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {22.322f, -6.2034f, 0f};
		*fParam4 = 73.071f;
		return true;

	case 250:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam3 = {-1.2901f, -5.5798f, -0.0357f};
		*fParam4 = 160.56f;
		return true;

	case 251:
		if (func_156(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-4.0739f, 7.7692f, -0.2984f};
			*fParam4 = -48.9552f;
			return true;
		}
		break;

	case 252:
		if (func_156(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {-5.778f, -4.2397f, 0.9091f};
			*fParam4 = -12.9418f;
			return true;
		}
		break;

	case 253:
		if (func_156(iParam0, 250, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			*uParam3 = {0.6968f, 1.1033f, 0.912f};
			*fParam4 = 90f;
			return true;
		}
		break;

	case 281:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 8f, 0.6f};
		*fParam6 = 15f;
		return true;

	case 282:
		if (func_156(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			return true;
		}
		break;

	case 283:
		if (func_156(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			return true;
		}
		break;

	case 284:
		if (func_156(iParam0, 281, iParam2, uParam3, fParam4, uParam5, fParam6)) {
			iParam2->f_97 = 0;
			*iParam2 = joaat("faggio2");
			iParam2->f_91 = 0;
			return true;
		}
		break;

	case 275:
		func_157(iParam0, iParam2, 1);
		iParam2->f_91 = 1;
		*uParam5 = {0f, 8f, 0.6f};
		*fParam6 = 15f;
		return true;

	case 276: return func_156(iParam0, 275, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 277: return func_156(iParam0, 275, iParam2, uParam3, fParam4, uParam5, fParam6);

	case 280:
		if (!Global_3) {
			iParam2->f_97 = 0;
			*iParam2 = joaat("tropic");
			iParam2->f_11[0] = 0;
			iParam2->f_11[1] = 0;
			iParam2->f_11[2] = 1;
			iParam2->f_11[3] = 0;
			iParam2->f_11[4] = 0;
			iParam2->f_11[5] = 1;
			iParam2->f_11[6] = 1;
			iParam2->f_11[7] = 1;
			iParam2->f_11[8] = 1;
		}
		else {
			iParam2->f_97 = 0;
			*iParam2 = joaat("dinghy");
		}
		*uParam3 = {Vector(-0.6187f, -1440.421f, 2779.759f) - Vector(0.3109f, -1453.731f, 2789.845f)};
		uParam3->f_2 += 0.5f;
		*fParam4 = 340.0835f - 4.44f;
		*uParam3 = {Vector(-0.7f, 16.55f, -3.3962f) + Vector(0.5f, 0.5f, -0.5f)};
		*fParam4 = 23.6441f + 90f;
		*uParam3 = {-4.0164f, 19.9594f, 0f};
		*fParam4 = 113.6465f;
		*uParam3 = {*uParam3 * FtoV(1.1f)};
		return true;

	case 247:
		iParam2->f_97 = 0;
		*iParam2 = joaat("sanchez");
		*uParam3 = {9.8707f, 13.0084f, 0f};
		*fParam4 = -114f - 43f + 133f;
		return true;

	case 288:
		iParam2->f_97 = 0;
		*iParam2 = joaat("speedo");
		*uParam3 = {-7.7078f, 23.9099f, 1.7307f};
		*fParam4 = 24.3187f;
		return true;

	case 309:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-4.5662f, -3.2485f, 0.9455f - 1.7f};
		*fParam4 = -138.6056f;
		return true;

	case 305:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(33.8797f, 3597.047f, 1399.662f) - Vector(37.9419f, 3602.284f, 1394.208f)};
		*fParam4 = 315.9865f - 122.5269f;
		return true;

	case 310:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {10.5999f, 3.3997f, 1.0212f};
		*fParam4 = -50.3062f;
		return true;

	case 255:
		iParam2->f_97 = 0;
		*iParam2 = joaat("romero");
		*uParam3 = {-13.2279f, -7.5348f, 0f};
		*fParam4 = 4.32f;
		return true;

	case 265:
		iParam2->f_97 = 0;
		*iParam2 = joaat("bmx");
		*uParam3 = {11.9596f, 0.345f, -1.0016f};
		*fParam4 = -42.4225f;
		return true;

	case 285:
		iParam2->f_97 = 0;
		*iParam2 = joaat("gburrito");
		*uParam3 = {3.424f, 7.6462f, 0.8227f};
		*fParam4 = -150f;
		return true;

	case 256:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(7.1164f, -1094.205f, -1243.65f) - Vector(7.1f, -1105.15f, -1242.68f)};
		*fParam4 = 14.0848f - 120f;
		return true;

	case 257:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(6.8143f, -930.5448f, -1672.535f) - Vector(6.479f, -974.7168f, -1667.148f)};
		*fParam4 = 144.9416f - 171.253f;
		return true;

	case 258:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.3025f, 6276.12f, -267.5488f) - Vector(30.5054f, 6250.9f, -301.4778f)};
		*fParam4 = 130.9896f - 10.247f;
		return true;

	case 314:
		iParam2->f_97 = 0;
		*iParam2 = joaat("cuban800");
		*uParam5 = {0f, 150f, 20f};
		*fParam6 = 30f;
		return true;
	}
	switch (iParam1) {
	case 110:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(32.5629f, -387.5143f, -147.166f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 341.4322f - 133f;
		return true;

	case 111:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(24.4283f, -689.1462f, -1306.782f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 214.6826f - 33f;
		return true;

	case 153:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.3324f, 254.0631f, -708.9244f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.2022f - -176.25f;
		return true;

	case 154:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.3324f, 254.0631f, -708.9244f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.2022f - -147.192f;
		return true;

	case 165:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(35.0054f, -441.1681f, -1100.878f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 297.5568f - -144.622f;
		return true;

	case 159:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(36.3852f, -199.5354f, -825.3141f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 29.4869f - -62.5f;
		return true;

	case 160:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(36.2086f, -144.1027f, -730.8218f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 28.532f - 119f;
		return true;

	case 167:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(31.7307f, -523.2257f, -1144.174f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 299.2956f - -22.32f;
		return true;

	case 152:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(60.9436f, 314.6989f, -1421.8f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 335.4134f - 72f;
		return true;

	case 157:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.469f, 255.3143f, -706.187f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 117.3069f - 37.27f;
		return true;

	case 225:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.7165f, -1677.734f, 185.4888f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 54.2538f - -83.8f;
		return true;

	case 218:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.3218f, -1405.159f, -17.556f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 91.3098f - -70.4124f;
		return true;

	case 219:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.2611f, -1492.151f, -219.3172f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 139.2572f - -12f;
		return true;

	case 220:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(25.3018f, -1811.693f, -22.6138f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 141.0423f - -117.356f;
		return true;

	case 206:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(208.5337f, 773.6719f, 164.1308f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 136.3104f - -36f;
		return true;

	case 207:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(108.9995f, 396.924f, -263.3745f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 284.4611f - -95.588f;
		return true;

	case 274:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(139.5782f, 2030.446f, -1883.836f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 340.5746f - 9f;
		return true;

	case 312:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.0296f, 6560.557f, -200.684f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 134.5505f - 110.5931f;
		return true;

	case 271:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(6.4647f, -1083.751f, -1278.023f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 115.8919f - 26.3597f;
		return true;

	case 248:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(102.4417f, 164.5124f, 325.8113f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 68.4108f - 10.77f;
		return true;

	case 242:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(56.616f, -122.9896f, -1622.22f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 210.8653f - 13.7207f;
		return true;

	case 254:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(53.0019f, -213.7796f, 172.442f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 250.3032f - -40f;
		return true;

	case 287:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(17.3426f, -836.0328f, -887.9977f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 270.8607f - -81f;
		return true;

	case 286:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(4.8359f, -1182.704f, -1264.218f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 298.4328f - -150f;
		return true;

	case 239:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(104.8218f, 289.0073f, -80.4564f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 247.6446f - -122f;
		return true;

	case 243:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2762f, -1477.282f, 434.9171f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 228.6353f - 18f;
		return true;

	case 244:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2762f, -1477.282f, 434.9171f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 228.6353f - -51f;
		return true;

	case 249:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(103.1881f, 177.7729f, 288.977f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 68.9831f - (138f - 180f);
		return true;

	case 273:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(32.7794f, -432.4635f, -161.4589f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 340.0368f - -153f;
		return true;

	case 92:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(202.1143f, 828.3607f, -806.8813f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 101.1612f - -54.347f;
		return true;

	case 103:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(12.0174f, -1108.081f, -1724.72f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 319.8931f - 143.4931f;
		return true;

	case 109:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.2248f, -628.4899f, -1859.505f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 229.0784f - 99f;
		return true;

	case 81:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(53.1469f, 90.4242f, -1393.442f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 123.1782f - -45f;
		return true;

	case 95:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(101.921f, 186.1865f, 370.5876f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 159.7861f - 70f;
		return true;

	case 97:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(45.9871f, -188.5636f, -1391.156f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 36.5172f - -45f;
		return true;

	case 134:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(46.0567f, 3076.742f, 2001.918f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 328.101f - -33.128f;
		return true;

	case 88:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(60.9442f, 314.7191f, -1421.821f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 336.5938f - -132f;
		return true;

	case 306:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(37.4888f, 5643.726f, -569.3535f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 296.1685f - gameplay::get_heading_from_vector_2d(7.4998f, -7.4995f);
		return true;

	case 307:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(47.4526f, 4717.728f, -1555.593f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 236.223f - gameplay::get_heading_from_vector_2d(-10.6345f, -0.7246f);
		return true;

	case 308:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(22.7549f, 4629.148f, -1553.861f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 332.7842f - gameplay::get_heading_from_vector_2d(3.4271f, 13.6787f);
		return true;

	case 278:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(35.9161f, -1009.745f, 631.8275f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 98.8128f - -33.77f;
		return true;

	case 279:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(234.6825f, 900.8749f, -111.9033f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 6.1087f - 155.68f;
		return true;

	case 240:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(33.5351f, 3636.151f, 1546.323f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 298.4009f - -4.124f;
		return true;

	case 241:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(30.512f, 6439.667f, -179.4242f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 225.5593f - 108f;
		return true;

	case 264:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.2977f, -1390.545f, 486.7419f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 178.298f - -90f;
		return true;

	case 266:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(10.5662f, 143.2342f, -3052.895f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 85.3429f - 68.8227f;
		return true;

	case 267:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(39.9155f, 4934.08f, 2202.375f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 314.2654f - 56.2037f;
		return true;

	case 269:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(28.149f, -782.0952f, 401.2502f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 179.9905f - -106.6605f;
		return true;

	case 246:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(3.3919f, -1534.507f, -1195.256f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 305.8221f - -165f;
		return true;

	case 263:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(12.8792f, -1241.213f, -573.3765f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 316.9941f - -171f;
		return true;

	case 259:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(4.0002f, -1298.539f, -724.429f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 230.5715f - -32.488f;
		return true;

	case 260:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(61.203f, 250.8387f, -1309.114f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 10.7756f - -29.093f;
		return true;

	case 261:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(79.764f, 60.3233f, 917.6678f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = 148.021f - 229.6085f;
		return true;

	case 270:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {Vector(350f, 8588f, 2919f) - Global_Switch_Positions[iParam1 /*3*/]};
		*fParam4 = gameplay::get_random_float_in_range(-180f, 180f);
		return true;

	case 289:
		func_158(iParam0, iParam2, 0);
		*uParam3 = {-48.5171f, 28.4211f, 3.0057f};
		*fParam4 = -1.3831f;
		return true;
	}
	return false;
}

// Position - 0xB44D
void func_157(int iParam0, int *iParam1, int iParam2) {
	int iVar0;

	iParam1->f_88 = 1;
	iParam1->f_84 = 255;
	iParam1->f_85 = 255;
	iParam1->f_86 = 255;
	iParam1->f_97 = 1;
	iParam1->f_3 = 1000;
	iParam1->f_1 = 0;
	switch (iParam0) {
	case 0:
		iVar0 = joaat("tailgater");
		if (Global_101700.f_8044.f_99.f_58[128] && !Global_101700.f_8044.f_99.f_58[131]) {
			iVar0 = joaat("premier");
		}
		switch (iVar0) {
		case joaat("tailgater"):
			*iParam1 = iVar0;
			iParam1->f_2 = 3f;
			iParam1->f_4 = 0;
			iParam1->f_9 = 1;
			iParam1->f_11[0] = 1;
			StringCopy(&iParam1->f_27, "5MDS003", 16);
			break;

		case joaat("premier"):
			*iParam1 = iVar0;
			iParam1->f_2 = 14.9f;
			iParam1->f_5 = 43;
			iParam1->f_6 = 43;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			iParam1->f_9 = 0;
			StringCopy(&iParam1->f_27, "880HS955", 16);
			break;
		}
		break;

	case 2:
		iVar0 = joaat("bodhi2");
		switch (iVar0) {
		case joaat("bodhi2"):
			*iParam1 = iVar0;
			iParam1->f_2 = 14f;
			iParam1->f_5 = 32;
			iParam1->f_6 = 0;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			StringCopy(&iParam1->f_27, "BETTY 32", 16);
			if (Global_101700.f_8044.f_99.f_58[119]) {
				iParam1->f_11[1] = 1;
			}
			break;
		}
		break;

	case 1:
		if (iParam2 == 1) {
			iVar0 = joaat("buffalo2");
		}
		else if (iParam2 == 2) {
			iVar0 = joaat("bagger");
		}
		else if (Global_101700.f_8044.f_99.f_58[118]) {
			iVar0 = joaat("bagger");
		}
		else {
			iVar0 = joaat("buffalo2");
		}
		switch (iVar0) {
		case joaat("bagger"):
			*iParam1 = iVar0;
			iParam1->f_2 = 6f;
			iParam1->f_5 = 53;
			iParam1->f_6 = 0;
			iParam1->f_7 = 59;
			iParam1->f_8 = 156;
			StringCopy(&iParam1->f_27, "FC88", 16);
			break;

		case joaat("buffalo2"):
			*iParam1 = iVar0;
			iParam1->f_2 = 0f;
			iParam1->f_5 = 111;
			iParam1->f_6 = 111;
			iParam1->f_7 = 0;
			iParam1->f_8 = 156;
			iParam1->f_10 = 1;
			StringCopy(&iParam1->f_27, "FC1988", 16);
			iParam1->f_11[0] = 1;
			iParam1->f_11[1] = 1;
			iParam1->f_11[2] = 1;
			iParam1->f_11[3] = 1;
			iParam1->f_11[4] = 1;
			iParam1->f_11[5] = 1;
			iParam1->f_11[6] = 1;
			iParam1->f_11[7] = 1;
			iParam1->f_11[8] = 1;
			break;
		}
		break;

	default: break;
	}
}

// Position - 0xB6A9
int func_158(int iParam0, int *iParam1, int iParam2) {
	if (Global_90960[iParam0 /*98*/] == 0) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("blimp")) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (func_168(iParam0)) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_boat(Global_90960[iParam0 /*98*/])) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_plane(Global_90960[iParam0 /*98*/])) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_heli(Global_90960[iParam0 /*98*/])) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (vehicle::is_this_model_a_train(Global_90960[iParam0 /*98*/])) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (iParam2 == 1) {
		if (!vehicle::is_this_model_a_car(Global_90960[iParam0 /*98*/])) {
			func_157(iParam0, iParam1, iParam2);
			iParam1->f_91 = iParam2;
			return 1;
		}
	}
	else if (iParam2 == 2) {
		if (!vehicle::is_this_model_a_bike(Global_90960[iParam0 /*98*/])) {
			func_157(iParam0, iParam1, iParam2);
			iParam1->f_91 = iParam2;
			return 1;
		}
	}
	if (!func_159(Global_90960[iParam0 /*98*/], 0)) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		return 1;
	}
	if (iParam2 != 0) {
		func_157(iParam0, iParam1, iParam2);
		iParam1->f_91 = iParam2;
		if (Global_90960[iParam0 /*98*/] != *iParam1) {
			*iParam1 = {Global_90960[iParam0 /*98*/]};
			iParam1->f_91 = 0;
			return 0;
		}
	}
	else {
		func_157(iParam0, iParam1, 1);
		iParam1->f_91 = 1;
		if (Global_90960[iParam0 /*98*/] == *iParam1) {
			func_157(iParam0, iParam1, 1);
			iParam1->f_91 = 1;
			return 1;
		}
		func_157(iParam0, iParam1, 2);
		iParam1->f_91 = 2;
		if (Global_90960[iParam0 /*98*/] == *iParam1) {
			func_157(iParam0, iParam1, 2);
			iParam1->f_91 = 2;
			return 1;
		}
		*iParam1 = {Global_90960[iParam0 /*98*/]};
		iParam1->f_91 = 0;
		return 0;
	}
	func_157(iParam0, iParam1, iParam2);
	iParam1->f_91 = iParam2;
	return 1;
}

// Position - 0xB8E0
int func_159(int iParam0, int iParam1) {
	int iVar0;
	struct<2> Var1;

	if (iParam0 == 0) {
		return 0;
	}
	if (!streaming::is_model_a_vehicle(iParam0)) {
		return 0;
	}
	if (iParam0 == joaat("dominator2") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("buffalo3") && !network::network_is_game_in_progress() ||
		iParam0 == joaat("gauntlet2") && !network::network_is_game_in_progress() || iParam0 == joaat("blimp2") ||
		iParam0 == joaat("stalion2") && !network::network_is_game_in_progress() || iParam0 == joaat("blista3")) {
		if (!func_167()) {
			return 0;
		}
	}
	else {
		iVar0 = 0;
		while (iVar0 < dlc1::get_num_dlc_vehicles()) {
			if (dlc1::get_dlc_vehicle_data(iVar0, &Var1)) {
				if (iParam0 == Var1.f_1) {
					if (dlc1::_is_dlc_data_empty(Var1)) {
						return 0;
					}
				}
			}
			iVar0++;
		}
	}
	if (iParam0 == joaat("blimp")) {
		if (!func_166() && !func_165() && !func_164() && !func_163() && !func_167()) {
			return 0;
		}
	}
	if (iParam0 == joaat("hotknife") || iParam0 == joaat("carbonrs") || iParam0 == joaat("khamelion")) {
		if (gameplay::is_durango_version() || gameplay::is_pc_version() || gameplay::is_orbis_version()) {
		}
		else if (!func_164()) {
			return 0;
		}
	}
	if (iParam1) {
		if (!func_162(iParam0)) {
			return 0;
		}
	}
	if (!func_160(iParam0)) {
		return 0;
	}
	return 1;
}

// Position - 0xBA6E
int func_160(int iParam0) {
	int iVar0;
	var uVar1;
	char cVar2[64];

	if (!func_161()) {
		return 1;
	}
	unk3::_0x897433D292B44130(&iVar0, &uVar1);
	if (iVar0 == 4) {
		return 1;
	}
	switch (iParam0) {
	case joaat("dune4"): StringCopy(&cVar2, "VE_DUNE4_t0_v3", 64); break;

	case joaat("voltic2"): StringCopy(&cVar2, "VE_VOLTIC2_t0_v3", 64); break;

	case joaat("ruiner2"): StringCopy(&cVar2, "VE_RUINER2_t0_v3", 64); break;

	case joaat("phantom2"): StringCopy(&cVar2, "VE_PHANTOM2_t0_v3", 64); break;

	case joaat("technical2"): StringCopy(&cVar2, "VE_TECHNICAL2_t0_v3", 64); break;

	case joaat("boxville5"): StringCopy(&cVar2, "VE_BOXVILLE5_t0_v3", 64); break;

	case joaat("wastelander"): StringCopy(&cVar2, "VE_WASTELANDER_t0_v3", 64); break;

	case joaat("blazer5"): StringCopy(&cVar2, "VE_BLAZER5_t0_v3", 64); break;

	default: return 1;
	}
	if (!mobile::_network_shop_is_item_unlocked(&cVar2)) {
		return 0;
	}
	return 1;
}

// Position - 0xBB3A
int func_161() {
	if (gameplay::is_pc_version()) {
		return 1;
	}
	return 0;
}

// Position - 0xBB4E
int func_162(int iParam0) {
	int iVar0;
	int iVar1;

	if (Global_2482093) {
		return 1;
	}
	iVar0 = 1;
	iVar1 = network::_get_posix_time();
	if (iParam0 == joaat("btype3")) {
		if (!Global_262145.f_5506 && !Global_262145.f_11530 && iVar1 < Global_262145.f_11531) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("faction3")) {
		if (!Global_262145.f_12342 && iVar1 < Global_262145.f_12354) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("virgo3") || iParam0 == joaat("virgo2")) {
		if (!Global_262145.f_12338 && iVar1 < Global_262145.f_12350) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sabregt2")) {
		if (!Global_262145.f_12339 && iVar1 < Global_262145.f_12351) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado5")) {
		if (!Global_262145.f_12340 && iVar1 < Global_262145.f_12352) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("minivan2")) {
		if (!Global_262145.f_12341 && iVar1 < Global_262145.f_12353) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("slamvan3")) {
		if (!Global_262145.f_12343 && iVar1 < Global_262145.f_12355) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("prototipo")) {
		if (!Global_262145.f_12344 && iVar1 < Global_262145.f_12347) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("seven70")) {
		if (!Global_262145.f_12345 && iVar1 < Global_262145.f_12348) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("pfister811")) {
		if (!Global_262145.f_12346 && iVar1 < Global_262145.f_12349) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("bf400")) {
		if (!Global_262145.f_14969 && iVar1 < Global_262145.f_14934) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("brioso")) {
		if (!Global_262145.f_14964 && iVar1 < Global_262145.f_14929) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("cliffhanger")) {
		if (!Global_262145.f_14968 && iVar1 < Global_262145.f_14933) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("contender")) {
		if (!Global_262145.f_14967 && iVar1 < Global_262145.f_14932) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("le7b")) {
		if (!Global_262145.f_14961 && iVar1 < Global_262145.f_14926) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("omnis")) {
		if (!Global_262145.f_14962 && iVar1 < Global_262145.f_14927) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck")) {
		if (!Global_262145.f_14965 && iVar1 < Global_262145.f_14930) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("trophytruck2")) {
		if (!Global_262145.f_14966 && iVar1 < Global_262145.f_14931) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tropos")) {
		if (!Global_262145.f_14963 && iVar1 < Global_262145.f_14928) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gargoyle")) {
		if (!Global_262145.f_14971 && iVar1 < Global_262145.f_14936) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("rallytruck")) {
		if (!Global_262145.f_14972 && iVar1 < Global_262145.f_14937) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tampa2")) {
		if (!Global_262145.f_14960 && iVar1 < Global_262145.f_14925) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tyrus")) {
		if (!Global_262145.f_14959 && iVar1 < Global_262145.f_14924) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sheava")) {
		if (!Global_262145.f_14958 && iVar1 < Global_262145.f_14923) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("lynx")) {
		if (!Global_262145.f_14970 && iVar1 < Global_262145.f_14935) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("stalion2")) {
		if (!Global_262145.f_14973 && iVar1 < Global_262145.f_14938) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("gauntlet2")) {
		if (!Global_262145.f_14974 && iVar1 < Global_262145.f_14939) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dominator2")) {
		if (!Global_262145.f_14975 && iVar1 < Global_262145.f_14940) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("buffalo3")) {
		if (!Global_262145.f_14976 && iVar1 < Global_262145.f_14941) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("defiler")) {
		if (!Global_262145.f_15121 && iVar1 < Global_262145.f_15143) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nightblade")) {
		if (!Global_262145.f_15122 && iVar1 < Global_262145.f_15144) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombiea")) {
		if (!Global_262145.f_15123 && iVar1 < Global_262145.f_15145) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("esskey")) {
		if (!Global_262145.f_15124 && iVar1 < Global_262145.f_15146) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("avarus")) {
		if (!Global_262145.f_15125 && iVar1 < Global_262145.f_15147) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("zombieb")) {
		if (!Global_262145.f_15126 && iVar1 < Global_262145.f_15148) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("hakuchou2")) {
		if (!Global_262145.f_15128 && iVar1 < Global_262145.f_15149) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("vortex")) {
		if (!Global_262145.f_15129 && iVar1 < Global_262145.f_15150) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("shotaro")) {
		if (!Global_262145.f_15130 && iVar1 < Global_262145.f_15151) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("chimera")) {
		if (!Global_262145.f_15131 && iVar1 < Global_262145.f_15152) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("raptor")) {
		if (!Global_262145.f_15132 && iVar1 < Global_262145.f_15153) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("daemon2")) {
		if (!Global_262145.f_15133 && iVar1 < Global_262145.f_15154) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer4")) {
		if (!Global_262145.f_15134 && iVar1 < Global_262145.f_15155) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tornado6")) {
		if (!Global_262145.f_15140 && iVar1 < Global_262145.f_15162) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("youga2")) {
		if (!Global_262145.f_15137 && iVar1 < Global_262145.f_15158) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wolfsbane")) {
		if (!Global_262145.f_15138 && iVar1 < Global_262145.f_15159) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio3")) {
		if (!Global_262145.f_15139 && iVar1 < Global_262145.f_15160) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("faggio")) {
		if (!Global_262145.f_15127 && iVar1 < Global_262145.f_15161) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("bagger")) {
		if (!Global_262145.f_15141 && iVar1 < Global_262145.f_15163) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("sanctus")) {
		if (!Global_262145.f_15135 && iVar1 < Global_262145.f_15156) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("manchez")) {
		if (!Global_262145.f_15136 && iVar1 < Global_262145.f_15157) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ratbike")) {
		if (!Global_262145.f_15142 && iVar1 < Global_262145.f_15164) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("voltic2")) {
		if (!Global_262145.f_16770 && iVar1 < Global_262145.f_16811) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruiner2")) {
		if (!Global_262145.f_16771 && iVar1 < Global_262145.f_16812) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune4")) {
		if (!Global_262145.f_16772 && iVar1 < Global_262145.f_16813) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("dune5")) {
		if (!Global_262145.f_16773 && iVar1 < Global_262145.f_16814) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("phantom2")) {
		if (!Global_262145.f_16774 && iVar1 < Global_262145.f_16815) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("technical2")) {
		if (!Global_262145.f_16775 && iVar1 < Global_262145.f_16816) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("boxville5")) {
		if (!Global_262145.f_16776 && iVar1 < Global_262145.f_16817) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("wastelander")) {
		if (!Global_262145.f_16777 && iVar1 < Global_262145.f_16818) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("blazer5")) {
		if (!Global_262145.f_16778 && iVar1 < Global_262145.f_16819) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet2")) {
		if (!Global_262145.f_16779 && iVar1 < Global_262145.f_16820) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("comet3")) {
		if (!Global_262145.f_16780 && iVar1 < Global_262145.f_16821) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous")) {
		if (!Global_262145.f_16781 && iVar1 < Global_262145.f_16822) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("diablous2")) {
		if (!Global_262145.f_16782 && iVar1 < Global_262145.f_16823) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy")) {
		if (!Global_262145.f_16783 && iVar1 < Global_262145.f_16824) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("elegy2")) {
		if (!Global_262145.f_16784 && iVar1 < Global_262145.f_16825) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr")) {
		if (!Global_262145.f_16785 && iVar1 < Global_262145.f_16826) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("fcr2")) {
		if (!Global_262145.f_16786 && iVar1 < Global_262145.f_16827) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb")) {
		if (!Global_262145.f_16787 && iVar1 < Global_262145.f_16828) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("italigtb2")) {
		if (!Global_262145.f_16788 && iVar1 < Global_262145.f_16829) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero")) {
		if (!Global_262145.f_16789 && iVar1 < Global_262145.f_16830) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("nero2")) {
		if (!Global_262145.f_16790 && iVar1 < Global_262145.f_16831) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("penetrator")) {
		if (!Global_262145.f_16791 && iVar1 < Global_262145.f_16832) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter")) {
		if (!Global_262145.f_16792 && iVar1 < Global_262145.f_16833) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("specter2")) {
		if (!Global_262145.f_16793 && iVar1 < Global_262145.f_16834) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("tempesta")) {
		if (!Global_262145.f_16794 && iVar1 < Global_262145.f_16835) {
			iVar0 = 0;
		}
	}
	if (iParam0 == joaat("gp1")) {
		if (!Global_262145.f_17797 && iVar1 < Global_262145.f_17793) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("infernus2")) {
		if (!Global_262145.f_17798 && iVar1 < Global_262145.f_17794) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("ruston")) {
		if (!Global_262145.f_17799 && iVar1 < Global_262145.f_17795) {
			iVar0 = 0;
		}
	}
	else if (iParam0 == joaat("turismo2")) {
		if (!Global_262145.f_17800 && iVar1 < Global_262145.f_17796) {
			iVar0 = 0;
		}
	}
	return iVar0;
}

// Position - 0xC892
int func_163() { return 0; }

// Position - 0xC89B
int func_164() { return 1; }

// Position - 0xC8A4
int func_165() { return 1; }

// Position - 0xC8AD
int func_166() {
	if (dlc2::is_dlc_present(-1226939934)) {
		return 1;
	}
	return 0;
}

// Position - 0xC8C6
int func_167() {
	int iVar0;

	if (network::network_is_signed_in()) {
		if (network::_network_are_ros_available()) {
			if (network::_0x593570C289A77688()) {
				stats::stat_get_int(joaat("sp_unlock_exclus_content"), &iVar0, -1);
				gameplay::set_bit(&iVar0, 2);
				gameplay::set_bit(&iVar0, 4);
				gameplay::set_bit(&iVar0, 6);
				gameplay::set_bit(&Global_25, 2);
				gameplay::set_bit(&Global_25, 4);
				gameplay::set_bit(&Global_25, 6);
				stats::stat_set_int(joaat("sp_unlock_exclus_content"), iVar0, 1);
				if (gameplay::_0x5AA3BEFA29F03AD4()) {
					iVar0 = gameplay::get_profile_setting(866);
					gameplay::set_bit(&iVar0, 0);
					stats::_0xDAC073C7901F9E15(iVar0);
				}
				return 1;
			}
		}
	}
	if (Global_139179 == 2) {
		return 1;
	}
	else if (Global_139179 == 3) {
		return 0;
	}
	if (gameplay::_0x5AA3BEFA29F03AD4()) {
		if (gameplay::is_bit_set(gameplay::get_profile_setting(866), 0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0xC981
bool func_168(int iParam0) {
	if (Global_90960[iParam0 /*98*/] == joaat("blimp") || Global_90960[iParam0 /*98*/] == joaat("blimp2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("submersible") || Global_90960[iParam0 /*98*/] == joaat("submersible2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("freight")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("packer")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("asea2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("burrito2") || Global_90960[iParam0 /*98*/] == joaat("fbi2")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("entityxf") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("cheetah") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("policeb") && !Global_101700.f_8044.f_330[8 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("ztype") && !Global_101700.f_8044.f_330[9 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("polmav") && !Global_101700.f_8044.f_330[9 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("jb700") && !Global_101700.f_8044.f_330[10 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("monroe") && !Global_101700.f_8044.f_330[11 /*6*/]) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("firetruk")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("handler")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("monroe")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("phantom")) {
		return true;
	}
	if (Global_90960[iParam0 /*98*/] == joaat("gauntlet") && !Global_101700.f_8044.f_330[80 /*6*/] &&
		!Global_101700.f_8044.f_330[81 /*6*/] && !Global_101700.f_8044.f_330[82 /*6*/]) {
		return true;
	}
	return false;
}

// Position - 0xCC01
bool func_169(vector3 vParam0, vector3 vParam3, int iParam6) {
	if (iParam6) {
		return vParam0.x == vParam3.x && vParam0.y == vParam3.y;
	}
	return vParam0.x == vParam3.x && vParam0.y == vParam3.y && vParam0.z == vParam3.z;
}

// Position - 0xCC48
int func_170(int iParam0, var *uParam1, float *fParam2) {
	switch (iParam0) {
	case 11:
		*uParam1 = {115.1569f, -1286.684f, 28.2613f};
		*fParam2 = 111f;
		return 1;

	case 8:
		*uParam1 = {-90.0089f, -1324.195f, 28.3203f};
		*fParam2 = 194.1887f;
		return 1;

	case 9: return func_170(8, uParam1, fParam2);

	case 10: return func_170(8, uParam1, fParam2);

	case 13:
		*uParam1 = {-807.2979f, -48.4004f, 36.8173f};
		*fParam2 = 201.6328f;
		return 1;

	case 14:
		*uParam1 = {1432.34f, -1887.383f, 70.5768f};
		*fParam2 = 350.0509f;
		return 1;

	case 15:
		*uParam1 = {1666.204f, 1967.25f, 143.3213f};
		*fParam2 = 0.7896f;
		return 1;

	case 12:
		*uParam1 = {-1440.22f, -127.02f, 50f};
		*fParam2 = 42f;
		return 1;

	case 16:
		*uParam1 = {135.055f, -1759.64f, 27.8957f};
		*fParam2 = -129f;
		return 1;

	case 17:
		*uParam1 = {687.6992f, -1744.03f, 28.3624f};
		*fParam2 = 267.1409f;
		return 1;

	case 18:
		*uParam1 = {56.5117f, -744.6122f, 43.1356f};
		*fParam2 = 340.0526f;
		return 1;

	case 19:
		*uParam1 = {506.485f, -1884.967f, 24.764f};
		*fParam2 = 22.9566f;
		return 1;

	case 20:
		*uParam1 = {1555.958f, 953.6136f, 77.2063f};
		*fParam2 = 152.8118f;
		return 1;

	case 21:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 22:
		*uParam1 = {220.72f, -64.4177f, 68.2922f};
		*fParam2 = 250.4535f - 360f;
		return 1;

	case 74:
		*uParam1 = {2048.07f, 3840.84f, 34.2238f};
		*fParam2 = 119.603f;
		return 1;

	case 23:
		*uParam1 = {-464.22f, -1592.98f, 38.73f};
		*fParam2 = 168f;
		return 1;

	case 24:
		*uParam1 = {744.79f + 0.0186f, -465.86f - 0.0114f, 36.6399f};
		*fParam2 = 51.7279f;
		return 1;

	case 67:
		*uParam1 = {-9f, 508.1f, 173.6278f};
		*fParam2 = 151.2504f;
		return 1;

	case 25:
		*uParam1 = {72.2278f, -1464.68f, 28.2915f};
		*fParam2 = 156.8827f;
		return 1;

	case 27:
		*uParam1 = {763f, -906f, 24.2312f};
		*fParam2 = 7.2736f;
		return 1;

	case 26:
		*uParam1 = {257.9167f, -1120.786f, 28.3684f};
		*fParam2 = 97.2736f;
		return 1;

	case 28:
		*uParam1 = {422.5858f, -978.6332f, 69.7073f};
		*fParam2 = 4f;
		return 1;

	case 29:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 30:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 31:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 32:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 33:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 34:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 35:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 36:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 37:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 58:
		*uParam1 = {294.8521f, 882.9366f, 197.8527f};
		*fParam2 = 162.693f;
		return 1;

	case 59:
		*uParam1 = {-1771.802f, 794.4316f, 138.4211f};
		*fParam2 = 128.9946f;
		return 1;

	case 60:
		*uParam1 = {1495.595f, -1848.821f, 70.2075f};
		*fParam2 = 32.2721f;
		return 1;

	case 38:
		*uParam1 = {2897.554f, 4032.241f, 50.1419f};
		*fParam2 = 192.8091f;
		return 1;

	case 39:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 40:
		*uParam1 = {1973.355f, 3818.204f, 32.005f};
		*fParam2 = 32f;
		return 1;

	case 41:
		*uParam1 = {1397f, 3725.8f, 33.0673f};
		*fParam2 = -3.7534f;
		return 1;

	case 42:
		*uParam1 = {Vector(4.0205f, -2975.341f, 798.4536f) + Vector(1f, 0f, 0f)};
		*fParam2 = 90f;
		return 1;

	case 43:
		*uParam1 = {709.0244f, -2916.479f, 5.0589f};
		*fParam2 = 355.326f;
		return 1;

	case 44:
		*uParam1 = {643.5248f, -2917.325f, 5.1337f};
		*fParam2 = 334.1068f;
		return 1;

	case 45:
		*uParam1 = {595.2742f, -2819.183f, 5.0559f};
		*fParam2 = 46.8853f;
		return 1;

	case 46:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 47:
		*uParam1 = {314.4171f, 965.207f, 208.4024f};
		*fParam2 = 165.9421f;
		return 1;

	case 49:
		*uParam1 = {3321.537f, 4975.455f, 25.9097f};
		*fParam2 = 221.228f;
		return 1;

	case 48:
		*uParam1 = {-111.1318f, 6316.479f, 30.4904f};
		*fParam2 = 42f + 180f;
		return 1;

	case 50:
		*uParam1 = {-731.3261f, 106.68f, 54.7169f};
		*fParam2 = 98.9764f;
		return 1;

	case 51:
		*uParam1 = {-1257.5f, -526.9999f, 30.2361f};
		*fParam2 = 220.9554f;
		return 1;

	case 52:
		*uParam1 = {736.9869f, -2050.678f, 28.2718f};
		*fParam2 = 83.9922f;
		return 1;

	case 66:
		*uParam1 = {262.5499f, -2540.15f, 4.8433f};
		*fParam2 = -64.1366f;
		return 1;

	case 53:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 55:
		*uParam1 = {-315.7789f, 6201.355f, 30.4322f};
		*fParam2 = 127.7547f;
		return 1;

	case 56:
		*uParam1 = {118.0988f, -1264.916f, 32.3637f};
		*fParam2 = -63f;
		return 1;

	case 57:
		*uParam1 = {37.5988f, -1351.52f, 28.2954f};
		*fParam2 = 90.0339f;
		return 1;

	case 61:
		*uParam1 = {-558.2693f, 261.1167f, 82.07f};
		*fParam2 = 84.6231f;
		return 1;

	case 62:
		*uParam1 = {-196.9999f, 507.9999f, 132.477f};
		*fParam2 = 99.6049f;
		return 1;

	case 63:
		*uParam1 = {1312.01f, -1645.87f, 51.2f};
		*fParam2 = 120f;
		return 1;

	case 68:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 69:
		*uParam1 = {-818.7374f, 6.4824f, 41.2432f};
		*fParam2 = 211.8223f;
		return 1;

	case 64:
		*uParam1 = {2091.258f, 4714.852f, 40.1936f};
		*fParam2 = 136.0867f;
		return 1;

	case 54:
		*uParam1 = {1762.59f, 3247.212f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 65:
		*uParam1 = {1764.013f, 3252.902f, 40.735f};
		*fParam2 = 27.0648f;
		return 1;

	case 70:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 71:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 72:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	case 73:
		*uParam1 = {0f, 0f, 0f};
		*fParam2 = 0f;
		return 1;

	default: break;
	}
	return 0;
}

// Position - 0xD5B7
var func_171() {
	int *iVar0;

	func_181(&iVar0, time::get_clock_seconds());
	func_180(&iVar0, time::get_clock_minutes());
	func_179(&iVar0, time::get_clock_hours());
	func_174(&iVar0, time::get_clock_day_of_month());
	func_173(&iVar0, time::get_clock_month());
	func_172(&iVar0, time::get_clock_year());
	return iVar0;
}

// Position - 0xD5FD
void func_172(int *iParam0, int iParam1) {
	if (iParam1 <= 0) {
		return;
	}
	if (iParam1 > 2043 || iParam1 < 1979) {
		return;
	}
	*iParam0 -= (*iParam0 & 2080374784);
	if (iParam1 < 2011) {
		*iParam0 |= system::shift_left(2011 - iParam1, 26);
		*iParam0 |= -2147483648;
	}
	else {
		*iParam0 |= system::shift_left(iParam1 - 2011, 26);
		*iParam0 -= (*iParam0 & -2147483648);
	}
}

// Position - 0xD683
void func_173(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 11) {
		return;
	}
	*uParam0 -= (*uParam0 & 15);
	*uParam0 |= iParam1;
}

// Position - 0xD6B6
void func_174(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar0 = func_178(*uParam0);
	iVar1 = func_176(*uParam0);
	if (iParam1 < 1 || iParam1 > func_175(iVar0, iVar1)) {
		return;
	}
	*uParam0 -= (*uParam0 & 496);
	*uParam0 |= system::shift_left(iParam1, 4);
}

// Position - 0xD707
int func_175(int iParam0, int iParam1) {
	if (iParam1 < 0) {
		iParam1 = 0;
	}
	switch (iParam0) {
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11: return 31;

	case 3:
	case 5:
	case 8:
	case 10: return 30;

	case 1:
		if (iParam1 % 4 == 0) {
			if (iParam1 % 100 != 0) {
				return 29;
			}
			else if (iParam1 % 400 == 0) {
				return 29;
			}
		}
		return 28;
	}
	return 30;
}

// Position - 0xD7A9
var func_176(int iParam0) {
	return (system::shift_right(iParam0, 26) & 31) * func_177(gameplay::is_bit_set(iParam0, 31), -1, 1) + 2011;
}

// Position - 0xD7CE
int func_177(bool bParam0, int iParam1, int iParam2) {
	if (bParam0) {
		return iParam1;
	}
	return iParam2;
}

// Position - 0xD7E5
int func_178(var uParam0) { return uParam0 & 15; }

// Position - 0xD7F2
void func_179(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 > 24) {
		return;
	}
	*uParam0 -= (*uParam0 & 15872);
	*uParam0 |= system::shift_left(iParam1, 9);
}

// Position - 0xD82C
void func_180(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 1032192);
	*uParam0 |= system::shift_left(iParam1, 14);
}

// Position - 0xD867
void func_181(var *uParam0, int iParam1) {
	if (iParam1 < 0 || iParam1 >= 60) {
		return;
	}
	*uParam0 -= (*uParam0 & 66060288);
	*uParam0 |= system::shift_left(iParam1, 20);
}

// Position - 0xD8A3
void func_182(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	vector3 vVar2;
	float *fVar5;

	if (iParam1 == 94) {
		return;
	}
	iVar0 = 0;
	while (iVar0 < 3) {
		iVar1 = Global_101700.f_17492[iVar0];
		if (iVar1 == 8 || iVar1 == 9 || iVar1 == 10 || iVar1 == 11 || iVar1 == 34 || iVar1 == 72 || iVar1 == 73)
			&&!gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[0], 9) {}
		else {
			vVar2 = {0f, 0f, 0f};
			fVar5 = 0f;
			if (!func_170(Global_101700.f_17492[iVar0], &vVar2, &fVar5)) {
				Global_101700.f_17492[iVar0] = 318;
				func_183(&uParam0->f_1524[iVar0]);
				uParam0->f_1528[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1538[iVar0] = 0f;
				uParam0->f_1542[iVar0] = 0;
				uParam0->f_1546[iVar0 /*3*/] = {0f, 0f, 0f};
				uParam0->f_1556[iVar0] = 0;
				Global_89214[iVar0 /*29*/] = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_9 = 0f;
				Global_89214[iVar0 /*29*/].f_12 = 0f;
				Global_89214[iVar0 /*29*/].f_3 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_10 = 0f;
				Global_89214[iVar0 /*29*/].f_13 = 0f;
				Global_89214[iVar0 /*29*/].f_6 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_11 = 0f;
				Global_89214[iVar0 /*29*/].f_14 = 0f;
				Global_89214[iVar0 /*29*/].f_17 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_26 = 0f;
				Global_89214[iVar0 /*29*/].f_20 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_27 = 0f;
				Global_89214[iVar0 /*29*/].f_23 = {0f, 0f, 0f};
				Global_89214[iVar0 /*29*/].f_28 = 0f;
			}
		}
		iVar0++;
	}
}

// Position - 0xDA6C
void func_183(int *iParam0) { *iParam0 = -15; }

// Position - 0xDA7A
int func_184() {
	if (func_110(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0xDAC5
void func_185(int iParam0, int iParam1, int iParam2, int iParam3) {
	if (iParam0) {
		player::special_ability_deactivate_fast(player::player_id());
		player::set_all_random_peds_flee(player::player_id(), 1);
		player::set_police_ignore_player(player::player_id(), 1);
		func_193(1);
		ui::_0xA8FDB297A8D25FBA();
		ui::_0xFDB423997FA30340();
		if (Global_14443.f_1 > 3) {
			if (audio::is_mobile_phone_call_ongoing()) {
				audio::stop_scripted_conversation(0);
			}
			if (!func_74()) {
				Global_14443.f_1 = 3;
			}
			Global_15745 = 5;
		}
		func_192(1, iParam3, iParam2, 0);
		Global_55828 = 1;
		Global_68134 = 1;
		G_DisableMessagesAndCalls1 = 1;
	}
	else {
		func_193(0);
		ui::_0xE1CD1E48E025E661();
		Global_55828 = 0;
		if (iParam1) {
			graphics::_0x03FC694AE06C5A20();
		}
		player::set_all_random_peds_flee(player::player_id(), 0);
		player::set_police_ignore_player(player::player_id(), 0);
		func_192(0, iParam3, iParam2, 0);
		if (network::network_is_game_in_progress()) {
			if (!ped::is_ped_injured(player::player_ped_id()) && !func_190(player::player_id()) &&
				!func_187(player::player_id(), 0) && !func_186()) {
				entity::set_entity_invincible(player::player_ped_id(), 0);
			}
		}
		else if (!ped::is_ped_injured(player::player_ped_id()) && !func_190(player::player_id())) {
			entity::set_entity_invincible(player::player_ped_id(), 0);
		}
		G_DisableMessagesAndCalls1 = 0;
	}
}

// Position - 0xDBDE
bool func_186() { return gameplay::is_bit_set(Global_1591201[player::player_id() /*602*/].f_39.f_18, 14); }

// Position - 0xDBFB
bool func_187(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_188(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0xDC46
int func_188(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_189();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0xDC87
var func_189() { return Global_1312735; }

// Position - 0xDC93
int func_190(int iParam0) {
	if (func_187(iParam0, 0)) {
		return 1;
	}
	if (func_191()) {
		if (iParam0 == player::player_id()) {
			return 1;
		}
	}
	if (gameplay::is_bit_set(Global_2421664[iParam0 /*358*/].f_198, 2)) {
		return 1;
	}
	return 0;
}

// Position - 0xDCD5
bool func_191() { return gameplay::is_bit_set(Global_2359301, 3); }

// Position - 0xDCE6
int func_192(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;

	iVar0 = 0;
	if (gameplay::is_pc_version()) {
		if (cutscene::_0xA0FE76168A189DDB() != iParam0 && iParam2) {
			cutscene::_0x20746F7B1032A3C7(iParam0, iParam1, 1, iParam3);
			iVar0 = 1;
		}
	}
	return iVar0;
}

// Position - 0xDD19
void func_193(int iParam0) {
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 13);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 13);
	}
}

// Position - 0xDD3C
void func_194() {
	interior::_hide_map_object_this_frame(-1747852954);
	if (func_221(16)) {
		if (!func_110(0)) {
			if (!gameplay::is_bit_set(iLocal_41, 10)) {
				cutscene::request_cutscene("JH_1_MCS_4_P1_ALT1", 8);
				func_202();
				func_107(0, 0, 1);
				iLocal_733 = ped::add_scenario_blocking_area(Local_46.f_1.f_394 - Local_46.f_1.f_397,
															 Local_46.f_1.f_394 + Local_46.f_1.f_397, 0, 1, 1, 1);
				iLocal_738 = pathfind::add_navmesh_blocking_object(Local_46.f_1.f_394, Local_46.f_1.f_397 * FtoV(1.5f),
																   0f, 0, 7);
				ped::set_ped_non_creation_area(Local_46.f_1.f_394 - Local_46.f_1.f_397,
											   Local_46.f_1.f_394 + Local_46.f_1.f_397);
				pathfind::set_ped_paths_in_area(Local_46.f_1.f_394 - Local_46.f_1.f_397,
												Local_46.f_1.f_394 + Local_46.f_1.f_397, 0, 0);
				gameplay::set_bit(&iLocal_41, 10);
			}
			else if (cutscene::_0xB56BBBCC2955D9CB()) {
				cutscene::set_cutscene_ped_prop_variation("LESTER", 1, 0, 0, 0);
			}
			if (func_149(86)) {
				if (!gameplay::is_bit_set(iLocal_41, 1)) {
					if (func_143(0)) {
						if (func_199(&iLocal_45, 0, 0, 0, 0) == 1) {
							func_192(1, 0, 1, 0);
							if (player::is_player_playing(player::player_id())) {
								player::clear_player_wanted_level(player::player_id());
								player::set_max_wanted_level(0);
							}
							gameplay::set_bit(&iLocal_41, 1);
							gameplay::set_bit(&iLocal_41, 2);
						}
					}
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 2)) {
				switch (iLocal_42) {
				case 0:
					if (cam::does_cam_exist(iLocal_734)) {
						cam::destroy_cam(iLocal_734, 0);
					}
					if (cam::does_cam_exist(iLocal_735)) {
						cam::destroy_cam(iLocal_735, 0);
					}
					iLocal_734 = cam::create_camera_with_params(26379945, 724.4682f, -992.0684f, 24.25137f, 5.259225f,
																0.000715f, 25.88918f, 44.13121f, 0, 2);
					iLocal_735 = cam::create_camera_with_params(26379945, 724.3727f, -991.3205f, 24.43304f, 31.49925f,
																0.000715f, -4.206256f, 44.13121f, 0, 2);
					if (entity::does_entity_exist(Global_88321.f_9[0])) {
						if (!entity::is_entity_dead(Global_88321.f_9[0], 0)) {
							iLocal_729 = Global_88321.f_9[0];
							entity::set_entity_as_mission_entity(iLocal_729, 0, 1);
						}
					}
					if (entity::does_entity_exist(Global_88321[0])) {
						if (!entity::is_entity_dead(Global_88321[0], 0)) {
							iLocal_731 = Global_88321[0];
						}
					}
					iLocal_42++;
					break;

				case 1:
					func_185(1, 1, 0, 0);
					ui::display_radar(0);
					ui::display_hud(0);
					if (entity::does_entity_exist(iLocal_731)) {
						if (vehicle::is_vehicle_driveable(iLocal_731, 0)) {
							cam::point_cam_at_entity(iLocal_734, iLocal_731, 0f, 0f, 0f, 1);
						}
					}
					cam::set_cam_active_with_interp(iLocal_735, iLocal_734, 5000, 1, 1);
					cam::render_script_cams(1, 0, 3000, 1, 0, 0);
					iLocal_43 = gameplay::get_game_timer();
					iLocal_42++;
					break;

				case 2:
					if (gameplay::get_game_timer() - iLocal_43 > 1200) {
						if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
							if (entity::does_entity_exist(player::player_ped_id())) {
								if (vehicle::is_vehicle_driveable(iLocal_731, 0)) {
									if (ped::is_ped_in_vehicle(player::player_ped_id(), iLocal_731, 0)) {
										ai::open_sequence_task(&iLocal_736);
										ai::task_leave_vehicle(0, iLocal_731, 0);
										ai::task_follow_nav_mesh_to_coord(0, 718.1777f, -976.126f, 23.9148f, 1f, 20000,
																		  1048576000, 0, 1193033728);
										ai::close_sequence_task(iLocal_736);
										ai::clear_ped_tasks(player::player_ped_id());
										ai::task_perform_sequence(player::player_ped_id(), iLocal_736);
									}
								}
							}
						}
						iLocal_42++;
					}
					break;

				case 3:
					if (gameplay::get_game_timer() - iLocal_43 > 2400) {
						if (!entity::is_entity_dead(iLocal_729, 0)) {
							if (entity::does_entity_exist(iLocal_731)) {
								if (vehicle::is_vehicle_driveable(iLocal_731, 0)) {
									if (ped::is_ped_in_vehicle(iLocal_729, iLocal_731, 0)) {
										ai::open_sequence_task(&iLocal_737);
										ai::task_leave_vehicle(0, iLocal_731, 0);
										ai::task_follow_nav_mesh_to_coord(0, 718.1777f, -976.126f, 23.9148f, 1f, 20000,
																		  1048576000, 0, 1193033728);
										ai::close_sequence_task(iLocal_737);
										ai::clear_ped_tasks(iLocal_729);
										ai::task_perform_sequence(iLocal_729, iLocal_737);
									}
								}
							}
						}
						iLocal_42++;
					}
					break;

				case 4:
					if (gameplay::get_game_timer() - iLocal_43 > 5000) {
						gameplay::clear_bit(&iLocal_41, 2);
					}
					break;
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 1) && !gameplay::is_bit_set(iLocal_41, 2)) {
				if (cutscene::has_this_cutscene_loaded("JH_1_MCS_4_P1_ALT1")) {
					if (!cutscene::is_cutscene_playing()) {
						iLocal_730 = player::player_ped_id();
						if (!entity::is_entity_dead(iLocal_730, 0)) {
							cutscene::register_entity_for_cutscene(iLocal_730, "Michael", 0, joaat("player_zero"), 0);
						}
						if (!entity::is_entity_dead(iLocal_729, 0)) {
							cutscene::register_entity_for_cutscene(iLocal_729, "Lester", 2, joaat("ig_lestercrest"), 0);
						}
						gameplay::set_bit(&iLocal_41, 9);
						cutscene::register_entity_for_cutscene(iLocal_732, "WalkingStick_Lester", 2,
															   joaat("prop_cs_walking_stick"), 0);
						gameplay::set_bit(&iLocal_41, 8);
						func_198(&Local_46.f_484, 0, 0, "MICHAEL", 1, 1);
						func_198(&Local_46.f_484, 3, 0, "LESTER", 1, 1);
						func_72(1);
						iLocal_43 = gameplay::get_game_timer();
						cutscene::start_cutscene(2048);
					}
					else {
						func_113();
						if (!gameplay::is_bit_set(iLocal_41, 17)) {
							if (!cam::is_screen_faded_in() && !cam::is_screen_fading_in()) {
								cam::do_screen_fade_in(800);
							}
							gameplay::set_bit(&iLocal_41, 17);
						}
						if (cutscene::was_cutscene_skipped()) {
							gameplay::set_bit(&iLocal_41, 16);
						}
						if (gameplay::is_bit_set(iLocal_41, 16)) {
							if (cam::is_screen_faded_out()) {
								if (!gameplay::is_bit_set(iLocal_41, 12)) {
									func_107(0, 1, 1);
									gameplay::set_bit(&iLocal_41, 12);
								}
								if (!gameplay::is_bit_set(iLocal_41, 13)) {
									func_107(0, 2, 1);
									gameplay::set_bit(&iLocal_41, 13);
								}
								if (!gameplay::is_bit_set(iLocal_41, 14)) {
									func_107(0, 3, 1);
									gameplay::set_bit(&iLocal_41, 14);
								}
								if (!gameplay::is_bit_set(iLocal_41, 15)) {
									func_107(0, 4, 1);
									gameplay::set_bit(&iLocal_41, 15);
								}
								func_196(&Local_46);
								if (!gameplay::is_bit_set(iLocal_41, 0)) {
									func_195();
									gameplay::set_bit(&iLocal_41, 0);
								}
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 5)) {
							if (cam::does_cam_exist(iLocal_734)) {
								cam::set_cam_active(iLocal_734, 0);
							}
							if (cam::does_cam_exist(iLocal_735)) {
								cam::set_cam_active(iLocal_735, 0);
							}
							cam::render_script_cams(0, 0, 3000, 1, 0, 0);
							if (cam::does_cam_exist(iLocal_735)) {
								cam::destroy_cam(iLocal_735, 0);
							}
							if (cam::does_cam_exist(iLocal_735)) {
								cam::destroy_cam(iLocal_735, 0);
							}
							if (entity::does_entity_exist(iLocal_729)) {
								ped::delete_ped(&iLocal_729);
							}
							gameplay::set_bit(&iLocal_41, 5);
						}
						if (!gameplay::is_bit_set(iLocal_41, 6)) {
							if (iLocal_44 > 0) {
								gameplay::set_bit(&iLocal_41, 6);
							}
						}
						if (!gameplay::is_bit_set(iLocal_41, 12)) {
							if (gameplay::get_game_timer() - iLocal_43 > 14058) {
								func_107(0, 1, 1);
								gameplay::set_bit(&iLocal_41, 12);
							}
						}
						else if (!gameplay::is_bit_set(iLocal_41, 13)) {
							if (gameplay::get_game_timer() - iLocal_43 > 22887) {
								func_107(0, 2, 1);
								gameplay::set_bit(&iLocal_41, 13);
							}
						}
						else if (!gameplay::is_bit_set(iLocal_41, 14)) {
							if (gameplay::get_game_timer() - iLocal_43 > 27988) {
								func_107(0, 3, 1);
								func_196(&Local_46);
								gameplay::set_bit(&iLocal_41, 14);
							}
						}
						else if (!gameplay::is_bit_set(iLocal_41, 15)) {
							if (gameplay::get_game_timer() - iLocal_43 > 42084) {
								func_107(0, 4, 1);
								gameplay::set_bit(&iLocal_41, 15);
							}
						}
						if (gameplay::is_bit_set(iLocal_41, 8)) {
							if (entity::does_entity_exist(cutscene::get_entity_index_of_registered_entity(
									"WalkingStick_Lester", joaat("prop_cs_walking_stick")))) {
								iLocal_732 = entity::get_object_index_from_entity_index(
									cutscene::get_entity_index_of_registered_entity("WalkingStick_Lester",
																					joaat("prop_cs_walking_stick")));
								gameplay::clear_bit(&iLocal_41, 8);
							}
						}
						if (gameplay::is_bit_set(iLocal_41, 9)) {
							if (entity::does_entity_exist(cutscene::get_entity_index_of_registered_entity(
									"Lester", joaat("ig_lestercrest")))) {
								iLocal_729 = entity::get_ped_index_from_entity_index(
									cutscene::get_entity_index_of_registered_entity("Lester", joaat("ig_lestercrest")));
								gameplay::clear_bit(&iLocal_41, 9);
							}
						}
						if (cutscene::can_set_exit_state_for_registered_entity("Michael", 0)) {
							if (!entity::is_entity_dead(iLocal_730, 0)) {
								ped::set_blocking_of_non_temporary_events(iLocal_730, 1);
								ped::set_ped_config_flag(iLocal_730, 208, 1);
								ped::set_ped_config_flag(iLocal_730, 118, 0);
								ped::set_ped_config_flag(iLocal_730, 213, 0);
								ai::task_go_straight_to_coord(iLocal_730, 708.8129f, -966.3621f, 29.3956f, 1f, 20000,
															  1193033728, 1056964608);
							}
						}
						if (cutscene::can_set_exit_state_for_registered_entity("Lester", 0)) {
							if (!entity::is_entity_dead(iLocal_729, 0)) {
								if (entity::does_entity_exist(iLocal_732)) {
									entity::attach_entity_to_entity(iLocal_732, iLocal_729,
																	ped::get_ped_bone_index(iLocal_729, 28422), 0f, 0f,
																	0f, 0f, 0f, 0f, 0, 0, 0, 0, 2, 1);
								}
							}
							if (!entity::is_entity_dead(iLocal_729, 0)) {
								ped::set_blocking_of_non_temporary_events(iLocal_729, 1);
								ped::set_ped_config_flag(iLocal_729, 208, 1);
								ped::set_ped_config_flag(iLocal_729, 118, 0);
								ped::set_ped_config_flag(iLocal_729, 213, 0);
								ai::task_go_straight_to_coord(iLocal_729, 708.3643f, -963.9194f, 29.4181f, 1f, 20000,
															  1193033728, 1056964608);
							}
						}
						if (cutscene::can_set_exit_state_for_camera(0)) {
							if (!gameplay::is_bit_set(iLocal_41, 0)) {
								func_195();
								gameplay::set_bit(&iLocal_41, 0);
							}
							if (!gameplay::is_bit_set(iLocal_41, 7)) {
								if (!entity::is_entity_dead(iLocal_730, 0)) {
									entity::set_entity_visible(iLocal_730, 0, 0);
								}
								if (!entity::is_entity_dead(iLocal_729, 0)) {
									entity::set_entity_visible(iLocal_729, 0, 0);
								}
								if (entity::does_entity_exist(iLocal_732)) {
									entity::set_entity_visible(iLocal_732, 0, 0);
								}
								gameplay::set_bit(&iLocal_41, 7);
							}
							func_106(16, 0);
						}
						iLocal_44++;
					}
				}
			}
		}
		else {
			func_198(&Local_46.f_484, 0, 0, "MICHAEL", 1, 1);
			func_198(&Local_46.f_484, 3, 0, "LESTER", 1, 1);
			if (func_143(0)) {
				if (func_199(&iLocal_45, 0, 0, 0, 0) == 1) {
					gameplay::set_bit(&iLocal_41, 1);
				}
			}
			if (gameplay::is_bit_set(iLocal_41, 1)) {
				func_195();
				func_106(16, 0);
			}
		}
	}
	else {
		if (cutscene::has_this_cutscene_loaded("JH_1_MCS_4_P1_ALT1")) {
			cutscene::remove_cutscene();
		}
		if (gameplay::is_bit_set(iLocal_41, 10)) {
			gameplay::clear_bit(&iLocal_41, 10);
		}
	}
}

// Position - 0xE69E
void func_195() {
	func_83(1, 0, 1);
	func_83(2, 0, 1);
	func_203(&Local_46);
	func_67(&Local_46);
}

// Position - 0xE6C0
void func_196(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		if (!cutscene::is_cutscene_playing()) {
			if (gameplay::is_bit_set(uParam0->f_449, 2)) {
				func_69(uParam0, 0);
			}
		}
		func_197(uParam0);
		gameplay::clear_bit(&uParam0->f_449, 1);
		gameplay::clear_bit(&Global_87833, *uParam0);
	}
}

// Position - 0xE70C
void func_197(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_33) {
		if (entity::does_entity_exist(uParam0->f_428[iVar0])) {
			object::delete_object(&uParam0->f_428[iVar0]);
		}
		iVar0++;
	}
}

// Position - 0xE748
void func_198(var *uParam0, int iParam1, int iParam2, char *sParam3, int iParam4, int iParam5) {
	if ((*uParam0)[iParam1 /*10*/].f_7 == 1) {
	}
	(*uParam0)[iParam1 /*10*/] = iParam2;
	StringCopy(&(*uParam0)[iParam1 /*10*/].f_1, sParam3, 24);
	(*uParam0)[iParam1 /*10*/].f_7 = 1;
	(*uParam0)[iParam1 /*10*/].f_8 = iParam4;
	(*uParam0)[iParam1 /*10*/].f_9 = iParam5;
	if (!Global_69702) {
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_8 == 0) {
				ped::set_ped_can_play_ambient_anims(iParam2, 0);
			}
			else {
				ped::set_ped_can_play_ambient_anims(iParam2, 1);
			}
		}
		if (!ped::is_ped_injured(iParam2)) {
			if ((*uParam0)[iParam1 /*10*/].f_9 == 0) {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 0);
			}
			else {
				ped::set_ped_can_use_auto_conversation_lookat(iParam2, 1);
			}
		}
	}
}

// Position - 0xE7E3
int func_199(int *iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	int iVar0;

	if (iParam1 == 7) {
		return 0;
	}
	if (!iParam3) {
		if (Global_89302.f_44 == 1) {
			return 2;
		}
	}
	if (iParam1 == 0) {
		if (func_201(0)) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		player::set_player_invincible(player::get_player_index(), 0);
		Global_17151.f_5 = 0;
		if (iParam2 != 5) {
			player::force_cleanup(8);
		}
		Global_35781 = iParam2;
		Global_35743 = *iParam0;
		Global_35744 = iParam4;
		Global_35742 = 0;
		return 1;
	}
	if (*iParam0 != -1) {
		if (Global_35742 > 0) {
			iVar0 = 0;
			iVar0 = 0;
			while (iVar0 < Global_35742) {
				if (Global_35748[iVar0 /*4*/] == *iParam0) {
					return 2;
				}
				iVar0++;
			}
		}
		else if (Global_35743 == *iParam0) {
			return 1;
		}
		*iParam0 = -1;
	}
	if (*iParam0 == -1) {
		if (!func_143(iParam2)) {
			return 0;
		}
		if (Global_35742 == 8) {
			return 0;
		}
		Global_35745++;
		*iParam0 = Global_35745;
		Global_35748[Global_35742 /*4*/] = Global_35745;
		Global_35748[Global_35742 /*4*/].f_1 = iParam1;
		Global_35748[Global_35742 /*4*/].f_2 = iParam2;
		Global_35748[Global_35742 /*4*/].f_3 = 0;
		Global_35742++;
		if (iParam4 != 0) {
			func_200(iParam0, iParam4);
		}
	}
	return 2;
}

// Position - 0xE91A
void func_200(int *iParam0, int iParam1) {
	int iVar0;

	if (Global_35742 == 0) {
		return;
	}
	if (*iParam0 == -1) {
		return;
	}
	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < Global_35742) {
		if (Global_35748[iVar0 /*4*/] == *iParam0) {
			Global_35748[iVar0 /*4*/].f_3 = iParam1;
		}
		iVar0++;
	}
	*iParam0 = -1;
}

// Position - 0xE969
bool func_201(int iParam0) {
	if (Global_35781 == 15) {
		return false;
	}
	if (func_143(iParam0)) {
		return false;
	}
	return true;
}

// Position - 0xE98B
void func_202() { Global_91530 = 1; }

// Position - 0xE998
void func_203(var *uParam0) {
	if (func_10(2, *uParam0)) {
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			if (gameplay::is_bit_set(uParam0->f_449, 2)) {
				func_69(uParam0, func_204(*uParam0));
				func_83(2, *uParam0, 0);
			}
			else {
				func_115(uParam0);
				func_83(2, *uParam0, 0);
			}
		}
	}
}

// Position - 0xE9ED
int func_204(int iParam0) {
	switch (iParam0) {
	case 0: return func_221(18);

	case 1: return func_221(22);

	case 2: return func_221(40);

	case 3: return func_221(8);

	case 4: return func_221(26);

	default: break;
	}
	return 0;
}

// Position - 0xEA5A
int func_205() { return Global_69964; }

// Position - 0xEA66
int func_206(var *uParam0) {
	if (gameplay::is_bit_set(uParam0->f_449, 1)) {
		func_196(uParam0);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 0)) {
		func_207(uParam0);
	}
	return 1;
}

// Position - 0xEA95
void func_207(var *uParam0) {
	audio::release_named_script_audio_bank("HEIST_BULLETIN_BOARD");
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_01"));
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_02"));
	streaming::set_model_as_no_longer_needed(joaat("prop_ld_planning_pin_03"));
	if (uParam0->f_413 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_413);
	}
	if (uParam0->f_414 != 0) {
		graphics::set_scaleform_movie_as_no_longer_needed(&uParam0->f_414);
	}
	ui::clear_additional_text(5, 0);
	gameplay::clear_bit(&Global_87834, *uParam0);
	gameplay::clear_bit(&uParam0->f_449, 0);
}

// Position - 0xEAFF
void func_208(var *uParam0, float fParam1, float fParam2) {
	float fVar0;

	if (!entity::is_entity_dead(player::player_ped_id(), 0)) {
		fVar0 = system::vdist2(uParam0->f_401, entity::get_entity_coords(player::player_ped_id(), 1));
		if (gameplay::is_bit_set(uParam0->f_449, 1)) {
			func_216(uParam0);
		}
		else if (fVar0 < fParam1 * fParam1 || gameplay::is_bit_set(Global_87833, *uParam0)) {
			if (gameplay::is_bit_set(uParam0->f_449, 0)) {
				if (func_215(uParam0)) {
					if (gameplay::is_bit_set(Global_87833, *uParam0)) {
						if (gameplay::is_bit_set(Global_87835, *uParam0)) {
							func_210(uParam0);
						}
					}
					else {
						func_210(uParam0);
					}
				}
			}
			else {
				func_209(uParam0);
			}
		}
		if (fVar0 > fParam2 * fParam2 && !gameplay::is_bit_set(Global_87833, *uParam0)) {
			if (gameplay::is_bit_set(uParam0->f_449, 0)) {
				if (gameplay::is_bit_set(uParam0->f_449, 1)) {
					func_196(uParam0);
				}
				func_207(uParam0);
			}
		}
	}
}

// Position - 0xEBE8
void func_209(var *uParam0) {
	if (!audio::_0x5B50ABB1FE3746F4()) {
		return;
	}
	ui::request_additional_text(&uParam0->f_1.f_272, 5);
	audio::request_script_audio_bank("HEIST_BULLETIN_BOARD", 0, -1);
	if (*uParam0 != 1) {
		streaming::request_model(joaat("prop_ld_planning_pin_01"));
		streaming::request_model(joaat("prop_ld_planning_pin_02"));
		streaming::request_model(joaat("prop_ld_planning_pin_03"));
	}
	uParam0->f_413 = graphics::request_scaleform_movie_instance(&uParam0->f_1.f_268);
	uParam0->f_414 = graphics::request_scaleform_movie_instance("INSTRUCTIONAL_BUTTONS");
	gameplay::set_bit(&Global_87832, *uParam0);
	gameplay::set_bit(&uParam0->f_449, 0);
}

// Position - 0xEC66
void func_210(var *uParam0) {
	int iVar0;

	if (!gameplay::is_bit_set(uParam0->f_449, 1)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_96) {
			func_36(uParam0, iVar0);
			iVar0++;
		}
		func_33(uParam0);
		func_31(uParam0);
		func_214(uParam0);
		func_213(uParam0);
		func_211(uParam0);
		gameplay::set_bit(&uParam0->f_449, 1);
	}
}

// Position - 0xECC3
void func_211(var *uParam0) {
	int iVar0;
	int iVar1;
	float fVar2;
	float fVar3;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_33) {
		if (func_32(*uParam0, uParam0->f_1.f_75[iVar0])) {
			switch (iVar0 % 3) {
			case 0: iVar1 = joaat("prop_ld_planning_pin_01"); break;

			case 1: iVar1 = joaat("prop_ld_planning_pin_02"); break;

			case 2: iVar1 = joaat("prop_ld_planning_pin_03"); break;
			}
			fVar2 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
			fVar3 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
			vVar4 = {func_212(uParam0, &uParam0->f_1.f_34[iVar0 /*2*/])};
			uParam0->f_428[iVar0] = object::create_object(iVar1, vVar4, 1, 1, 0);
			entity::set_entity_rotation(uParam0->f_428[iVar0], fVar2, 0f, uParam0->f_404 + fVar3, 2, 1);
			entity::set_entity_as_mission_entity(uParam0->f_428[iVar0], 1, 0);
			entity::set_entity_invincible(uParam0->f_428[iVar0], 1);
			entity::set_entity_collision(uParam0->f_428[iVar0], 0, 0);
			entity::set_entity_has_gravity(uParam0->f_428[iVar0], 0);
			entity::freeze_entity_position(uParam0->f_428[iVar0], 1);
		}
		iVar0++;
	}
	gameplay::clear_bit(&Global_87835, *uParam0);
}

// Position - 0xEDF8
Vector3 func_212(var *uParam0, var *uParam1) {
	float fVar0;
	float fVar1;
	float fVar2;
	float fVar3;
	float fVar4;
	float fVar5;
	float fVar6;
	vector3 vVar7;

	fVar0 = uParam0->f_1.f_4;
	fVar1 = uParam0->f_1.f_5;
	func_28(uParam0, uParam1, &fVar2, &fVar3);
	fVar4 = fVar0 * (fVar2 - 0.5f);
	fVar5 = -fVar1 * (fVar3 - 0.5f);
	fVar6 = uParam0->f_404;
	vVar7 = {uParam0->f_401};
	vVar7 = {vVar7 + Vector(fVar5, fVar4 * system::cos(90f - fVar6), fVar4 * system::sin(90f - fVar6))};
	return vVar7;
}

// Position - 0xEE76
void func_213(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar1 = *uParam0;
	iVar0 = 0;
	while (iVar0 < uParam0->f_1.f_117) {
		iVar2 = uParam0->f_1.f_186[iVar0];
		iVar3 = gameplay::is_bit_set(Global_101700.f_1.f_120[iVar1], iVar2);
		if (uParam0->f_1.f_141[iVar0 /*2*/] == 0 && uParam0->f_1.f_141[iVar0 /*2*/].f_1 == 0) {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar3);
			graphics::_pop_scaleform_movie_function_void();
		}
		else {
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar3);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_141[iVar0 /*2*/]));
			graphics::_push_scaleform_movie_function_parameter_float(
				system::to_float(uParam0->f_1.f_141[iVar0 /*2*/].f_1));
			graphics::_pop_scaleform_movie_function_void();
		}
		iVar0++;
	}
}

// Position - 0xEF56
void func_214(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	graphics::_push_scaleform_movie_function(uParam0->f_413, "CREATE_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_push_scaleform_movie_function_parameter_int(2);
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_14));
	graphics::_push_scaleform_movie_function_parameter_float(system::to_float(uParam0->f_1.f_14.f_1));
	graphics::_pop_scaleform_movie_function_void();
	iVar0 = *uParam0;
	iVar1 = 0;
	iVar2 = 0;
	while (iVar2 < uParam0->f_1.f_209) {
		if (func_32(iVar0, uParam0->f_1.f_248[iVar2])) {
			iVar3 = 0;
			if (func_32(iVar0, uParam0->f_1.f_258[iVar2])) {
				iVar3 = 1;
			}
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
			graphics::_push_scaleform_movie_function_parameter_int(iVar1);
			graphics::_push_scaleform_movie_function_parameter_int(iVar3);
			func_8(&uParam0->f_1.f_211[iVar2 /*4*/]);
			graphics::_pop_scaleform_movie_function_void();
			iVar1++;
		}
		iVar2++;
	}
	graphics::_push_scaleform_movie_function(uParam0->f_413, "DISPLAY_VIEW");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_pop_scaleform_movie_function_void();
	if (func_32(*uParam0, uParam0->f_1.f_210)) {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
		graphics::_push_scaleform_movie_function_parameter_bool(1);
		graphics::_pop_scaleform_movie_function_void();
	}
	else {
		graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_VIEW");
		graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
		graphics::_push_scaleform_movie_function_parameter_bool(0);
		graphics::_pop_scaleform_movie_function_void();
	}
}

// Position - 0xF096
bool func_215(var *uParam0) {
	if (!graphics::has_scaleform_movie_loaded(uParam0->f_413)) {
		return false;
	}
	if (!graphics::has_scaleform_movie_loaded(uParam0->f_414)) {
		return false;
	}
	if (!ui::has_additional_text_loaded(5)) {
		return false;
	}
	if (audio::_0x5B50ABB1FE3746F4()) {
		if (!audio::request_script_audio_bank("HEIST_BULLETIN_BOARD", 0, -1)) {
			return false;
		}
	}
	else {
		return false;
	}
	if (*uParam0 != 1) {
		if (!streaming::has_model_loaded(joaat("prop_ld_planning_pin_01")) ||
			!streaming::has_model_loaded(joaat("prop_ld_planning_pin_02")) ||
			!streaming::has_model_loaded(joaat("prop_ld_planning_pin_03"))) {
			return false;
		}
	}
	gameplay::set_bit(&Global_87834, *uParam0);
	return true;
}

// Position - 0xF131
void func_216(var *uParam0) {
	float fVar0;
	float fVar1;

	if (func_32(*uParam0, 0)) {
		func_217(uParam0);
		fVar0 = -uParam0->f_1.f_4 * 0.5f;
		fVar1 = uParam0->f_1.f_5 * 0.5f;
		graphics::draw_scaleform_movie_3d(uParam0->f_413,
										  uParam0->f_401 + Vector(fVar1, fVar0 * system::cos(90f - uParam0->f_404),
																  fVar0 * system::sin(90f - uParam0->f_404)),
										  180f, 0f, uParam0->f_404, 1f, 1f, 1f, uParam0->f_1.f_6, uParam0->f_1.f_7, 1f,
										  2);
	}
}

// Position - 0xF1BA
void func_217(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	float fVar4;
	float fVar5;
	vector3 vVar6;

	if (gameplay::is_bit_set(Global_87832, *uParam0)) {
		gameplay::set_bit(&uParam0->f_449, 16);
		gameplay::set_bit(&uParam0->f_449, 15);
		gameplay::set_bit(&uParam0->f_449, 14);
		gameplay::clear_bit(&Global_87832, *uParam0);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 16)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_117) {
			iVar1 = uParam0->f_1.f_186[iVar0];
			iVar2 = func_32(*uParam0, iVar1);
			graphics::_push_scaleform_movie_function(uParam0->f_413, "SHOW_HEIST_ASSET");
			graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_1.f_118[iVar0]);
			graphics::_push_scaleform_movie_function_parameter_bool(iVar2);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_pop_scaleform_movie_function_void();
			iVar0++;
		}
		gameplay::clear_bit(&uParam0->f_449, 16);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 15)) {
		iVar0 = 0;
		while (iVar0 < uParam0->f_1.f_33) {
			if (func_32(*uParam0, uParam0->f_1.f_75[iVar0])) {
				if (!entity::does_entity_exist(uParam0->f_428[iVar0])) {
					switch (iVar0 % 3) {
					case 0: iVar3 = joaat("prop_ld_planning_pin_01"); break;

					case 1: iVar3 = joaat("prop_ld_planning_pin_02"); break;

					case 2: iVar3 = joaat("prop_ld_planning_pin_03"); break;
					}
					fVar4 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
					fVar5 = system::to_float(gameplay::get_random_int_in_range(0, 65535) - 32767) / 4000f;
					vVar6 = {func_212(uParam0, &uParam0->f_1.f_34[iVar0 /*2*/])};
					uParam0->f_428[iVar0] = object::create_object(iVar3, vVar6, 1, 1, 0);
					entity::set_entity_rotation(uParam0->f_428[iVar0], fVar4, 0f, uParam0->f_404 + fVar5, 2, 1);
					entity::set_entity_as_mission_entity(uParam0->f_428[iVar0], 1, 0);
					entity::set_entity_invincible(uParam0->f_428[iVar0], 1);
					entity::set_entity_collision(uParam0->f_428[iVar0], 0, 0);
					entity::set_entity_has_gravity(uParam0->f_428[iVar0], 0);
					entity::freeze_entity_position(uParam0->f_428[iVar0], 1);
				}
			}
			else if (!entity::does_entity_exist(uParam0->f_428[iVar0])) {
				object::delete_object(&uParam0->f_428[iVar0]);
			}
			iVar0++;
		}
		gameplay::clear_bit(&uParam0->f_449, 15);
	}
	if (gameplay::is_bit_set(uParam0->f_449, 14)) {
		func_218(uParam0);
		func_33(uParam0);
		func_214(uParam0);
		gameplay::clear_bit(&uParam0->f_449, 14);
	}
}

// Position - 0xF406
void func_218(var *uParam0) {
	graphics::_push_scaleform_movie_function(uParam0->f_413, "SET_DATA_SLOT_EMPTY");
	graphics::_push_scaleform_movie_function_parameter_int(uParam0->f_415 + 1);
	graphics::_pop_scaleform_movie_function_void();
}

// Position - 0xF42A
bool func_219(int iParam0) { return Global_35781 == iParam0; }

// Position - 0xF438
int func_220(int iParam0) {
	int iVar0;

	if (iParam0 == 94 || iParam0 == -1) {
		return 0;
	}
	if (Global_85809[iParam0 /*2*/]) {
		return 1;
	}
	iVar0 = 0;
	while (iVar0 < Global_82576) {
		if (Global_82576[iVar0 /*5*/] != -1) {
			if (G_TextMessageConfig.f_109[Global_82576[iVar0 /*5*/] /*4*/] == iParam0) {
				return 1;
			}
		}
		iVar0++;
	}
	return 0;
}

// Position - 0xF4A0
bool func_221(int iParam0) {
	if (iParam0 == 146 || iParam0 == -1) {
		return false;
	}
	return Global_101700.f_8044.f_99.f_58[iParam0];
}

// Position - 0xF4CD
void func_222(var *uParam0, int iParam1) {
	vector3 vVar0;
	float fVar3;

	*uParam0 = iParam1;
	vVar0 = {Global_87770[uParam0->f_1.f_1 /*15*/].f_3};
	fVar3 = Global_87770[uParam0->f_1.f_1 /*15*/].f_6;
	uParam0->f_401 = {vVar0};
	uParam0->f_404 = fVar3;
	uParam0->f_405 = {vVar0 + Vector(0f, -uParam0->f_1.f_8 * system::cos(360f - fVar3),
									 -uParam0->f_1.f_8 * system::sin(360f - fVar3))};
	uParam0->f_408 = {-0.85f, 0f, fVar3};
	gameplay::set_bit(&uParam0->f_449, 4);
	uParam0->f_415 = uParam0->f_1.f_96;
	uParam0->f_416 = -1;
	gameplay::clear_bit(&uParam0->f_449, 0);
	gameplay::clear_bit(&uParam0->f_449, 1);
	gameplay::clear_bit(&uParam0->f_449, 2);
	uParam0->f_464 = 0;
	uParam0->f_451 = -1;
}

// Position - 0xF599
void func_223(var *uParam0, int iParam1) {
	func_232(uParam0, 1, "HEIST_JEWELLERY", "BOARD0", "JHFAUD", "CRWAUD", 2, 2, 7, 8, iParam1, 708.9957f, -965.256f,
			 31.39533f, 5.5f, 6.25f, 4f);
	func_231(uParam0, 750, 540, 2.1f, 1.47f, 3.6f, 2.05f, 2f, 375, 250, 116, 420, 248, 425, 380, 425, 510, 430, 0, 0,
			 650, 300, 0, 70, 684, 106);
	func_230(uParam0, 20f, 22f, 28f);
	func_229(uParam0, "BRD_H_01", "BRD_H_02", "BRD_H_03", "BRD_H_04", "JHFP1", "JHFP4", "JHP11", "JHHUR");
	func_228(uParam0, 1, "CRW_GM", "");
	func_228(uParam0, 4, "CRW_NR", "");
	func_228(uParam0, 6, "CRW_PH", "");
	func_228(uParam0, 7, "CRW_CF", "");
	func_228(uParam0, 8, "CRW_ET", "");
	func_228(uParam0, 9, "CRW_KD", "");
	func_228(uParam0, 10, "CRW_PM", "CRM_PM");
	func_228(uParam0, 12, "CRW_RL", "CRM_RL");
	func_227(uParam0, 0, 0, 0, 0);
	func_227(uParam0, 6, 0, 0, 0);
	func_227(uParam0, 1, 0, 0, 0);
	func_227(uParam0, 3, 1, 0, 0);
	func_227(uParam0, 11, 2, 0, 0);
	func_227(uParam0, 5, 3, 0, 0);
	func_227(uParam0, 9, 3, 0, 0);
	func_227(uParam0, 2, 4, 0, 0);
	func_227(uParam0, 7, 9, 0, 0);
	func_227(uParam0, 10, 10, 0, 0);
	func_226(uParam0, 2, 2, "H_TD_SEC");
	func_226(uParam0, 2, 2, "H_TD_PHOTO");
	func_226(uParam0, 2, 5, "H_TD_PLAN");
	func_226(uParam0, 2, 6, "H_TD_CREW");
	func_226(uParam0, 7, 11, "H_TD_CARB");
	func_226(uParam0, 8, 9, "H_TD_BUGS");
	func_226(uParam0, 8, 10, "H_TD_GAS");
	func_225(uParam0, 0, 203, 74);
	func_225(uParam0, 1, 368, 181);
	func_225(uParam0, 1, 556, 189);
	func_225(uParam0, 2, 690, 63);
	func_225(uParam0, 2, 673, 308);
	func_225(uParam0, 2, 671, 406);
	func_225(uParam0, 3, 245, 244);
	func_225(uParam0, 4, 70, 68);
	func_224(uParam0, 0, "JHP12", 214, 165, 1);
	func_224(uParam0, 0, "JHP13", 254, 46, 1);
	func_224(uParam0, 0, "JHP14", 70, 97, 1);
	func_224(uParam0, 0, "JHP15", 254, 275, 1);
	func_224(uParam0, 0, "JHP16", 457, 165, 1);
}

// Position - 0xF83F
void func_224(var *uParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5) {
	struct<2> Var0;

	if (uParam0->f_369 < 7) {
		StringCopy(&Var0, sParam2, 8);
		uParam0->f_386[uParam0->f_369] = iParam1;
		uParam0->f_371[uParam0->f_369 /*2*/] = iParam3;
		uParam0->f_371[uParam0->f_369 /*2*/].f_1 = iParam4;
		uParam0->f_280[uParam0->f_369 + 4 /*2*/] = {Var0};
		if (iParam5) {
			gameplay::set_bit(&uParam0->f_370, uParam0->f_369);
		}
		uParam0->f_369++;
	}
}

// Position - 0xF8B8
void func_225(var *uParam0, int iParam1, int iParam2, int iParam3) {
	if (uParam0->f_33 < 20) {
		uParam0->f_75[uParam0->f_33] = iParam1;
		uParam0->f_34[uParam0->f_33 /*2*/] = iParam2;
		uParam0->f_34[uParam0->f_33 /*2*/].f_1 = iParam3;
		uParam0->f_33++;
	}
}

// Position - 0xF8FC
void func_226(var *uParam0, int iParam1, int iParam2, char *sParam3) {
	struct<8> Var0;

	if (uParam0->f_209 < 9) {
		StringCopy(&Var0, sParam3, 32);
		uParam0->f_248[uParam0->f_209] = iParam1;
		uParam0->f_258[uParam0->f_209] = iParam2;
		MemCopy(&uParam0->f_211[uParam0->f_209 /*4*/], {Var0}, 4);
		uParam0->f_209++;
	}
}

// Position - 0xF94C
void func_227(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (uParam0->f_117 < 22) {
		uParam0->f_118[uParam0->f_117] = iParam1;
		uParam0->f_186[uParam0->f_117] = iParam2;
		uParam0->f_141[uParam0->f_117 /*2*/] = iParam3;
		uParam0->f_141[uParam0->f_117 /*2*/].f_1 = iParam4;
		uParam0->f_117++;
	}
}

// Position - 0xF99C
void func_228(var *uParam0, int iParam1, char *sParam2, char *sParam3) {
	struct<2> Var0;
	struct<2> Var2;

	StringCopy(&Var0, sParam2, 8);
	StringCopy(&Var2, sParam3, 8);
	uParam0->f_304[iParam1 /*2*/] = {Var0};
	if (!gameplay::are_strings_equal(sParam3, "")) {
		switch (iParam1) {
		case 10: uParam0->f_304[14 /*2*/] = {Var2}; break;

		case 13: uParam0->f_304[16 /*2*/] = {Var2}; break;

		case 12: uParam0->f_304[15 /*2*/] = {Var2}; break;

		case 11: uParam0->f_304[17 /*2*/] = {Var2}; break;

		default: break;
		}
	}
}

// Position - 0xFA36
void func_229(var *uParam0, char *sParam1, char *sParam2, char *sParam3, char *sParam4, char *sParam5, char *sParam6,
			  char *sParam7, char *sParam8) {
	struct<4> Var0;
	struct<4> Var4;
	struct<4> Var8;
	struct<4> Var12;
	struct<2> Var16;
	struct<2> Var18;
	struct<2> Var20;
	struct<2> Var22;

	StringCopy(&Var0, sParam1, 16);
	StringCopy(&Var4, sParam2, 16);
	StringCopy(&Var8, sParam3, 16);
	StringCopy(&Var12, sParam4, 16);
	StringCopy(&Var16, sParam5, 8);
	StringCopy(&Var18, sParam6, 8);
	StringCopy(&Var20, sParam7, 8);
	StringCopy(&Var22, sParam8, 8);
	uParam0->f_20[0 /*4*/] = {Var0};
	uParam0->f_20[1 /*4*/] = {Var4};
	uParam0->f_108[0 /*4*/] = {Var8};
	uParam0->f_108[1 /*4*/] = {Var12};
	uParam0->f_280[1 /*2*/] = {Var16};
	uParam0->f_280[2 /*2*/] = {Var18};
	uParam0->f_280[0 /*2*/] = {Var20};
	uParam0->f_280[3 /*2*/] = {Var22};
}

// Position - 0xFADA
void func_230(var *uParam0, float fParam1, float fParam2, float fParam3) {
	uParam0->f_9 = fParam1;
	uParam0->f_10 = fParam2;
	uParam0->f_11 = fParam3;
}

// Position - 0xFAF4
void func_231(var *uParam0, int iParam1, int iParam2, float fParam3, float fParam4, float fParam5, float fParam6,
			  float fParam7, int iParam8, int iParam9, int iParam10, int iParam11, int iParam12, int iParam13,
			  int iParam14, int iParam15, int iParam16, int iParam17, int iParam18, int iParam19, int iParam20,
			  int iParam21, int iParam22, int iParam23, int iParam24, int iParam25) {
	uParam0->f_2 = iParam1;
	uParam0->f_3 = iParam2;
	uParam0->f_4 = fParam3;
	uParam0->f_5 = fParam4;
	uParam0->f_6 = fParam5;
	uParam0->f_7 = fParam6;
	uParam0->f_8 = fParam7;
	uParam0->f_12 = iParam8;
	uParam0->f_12.f_1 = iParam9;
	uParam0->f_97[0 /*2*/] = iParam10;
	uParam0->f_97[0 /*2*/].f_1 = iParam11;
	uParam0->f_97[1 /*2*/] = iParam12;
	uParam0->f_97[1 /*2*/].f_1 = iParam13;
	uParam0->f_97[2 /*2*/] = iParam14;
	uParam0->f_97[2 /*2*/].f_1 = iParam15;
	uParam0->f_97[3 /*2*/] = iParam16;
	uParam0->f_97[3 /*2*/].f_1 = iParam17;
	uParam0->f_97[4 /*2*/] = iParam18;
	uParam0->f_97[4 /*2*/].f_1 = iParam19;
	uParam0->f_16 = iParam20;
	uParam0->f_16.f_1 = iParam21;
	uParam0->f_18 = iParam22;
	uParam0->f_18.f_1 = iParam23;
	uParam0->f_14 = iParam24;
	uParam0->f_14.f_1 = iParam25;
}

// Position - 0xFBC2
void func_232(var *uParam0, int iParam1, char *sParam2, char *sParam3, char *sParam4, char *sParam5, int iParam6,
			  int iParam7, int iParam8, int iParam9, var uParam10, vector3 vParam11, vector3 vParam14) {
	uParam0->f_1 = iParam1;
	StringCopy(&uParam0->f_268, sParam2, 16);
	StringCopy(&uParam0->f_272, sParam3, 16);
	StringCopy(&uParam0->f_276, sParam4, 8);
	StringCopy(&uParam0->f_278, sParam5, 8);
	uParam0->f_29 = iParam6;
	uParam0->f_30[0] = iParam8;
	uParam0->f_30[1] = iParam9;
	uParam0->f_210 = iParam7;
	uParam0->f_96 = uParam10;
	uParam0->f_394 = {vParam11};
	uParam0->f_397 = {vParam14};
}

// Position - 0xFC2E
int func_233(int iParam0, int iParam1) {
	if (iParam0 > iParam1) {
		return iParam0;
	}
	return iParam1;
}

// Position - 0xFC44
int func_234(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		return 0;
	}
	gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
	return 1;
}

// Position - 0xFC9E
void func_235() {
	if (cutscene::has_this_cutscene_loaded("JH_1_MCS_4P2") ||
		cutscene::has_this_cutscene_loaded("JH_1_MCS_4_P1_ALT1")) {
		cutscene::remove_cutscene();
	}
	func_106(16, 0);
	func_106(17, 0);
	func_106(18, 0);
	func_83(1, 0, 0);
	func_83(2, 0, 0);
	ped::remove_scenario_blocking_area(iLocal_733, 0);
	if (iLocal_738 != -1) {
		if (pathfind::does_navmesh_blocking_object_exist(iLocal_738)) {
			pathfind::remove_navmesh_blocking_object(iLocal_738);
		}
	}
	ped::clear_ped_non_creation_area();
	pathfind::set_ped_paths_in_area(Local_46.f_1.f_394 - Local_46.f_1.f_397, Local_46.f_1.f_394 + Local_46.f_1.f_397, 1,
									0);
	player::set_max_wanted_level(5);
	if (iLocal_45 != -1) {
		func_153(&iLocal_45);
	}
	while (!func_206(&Local_46)) {
		system::wait(0);
	}
	script::terminate_this_thread();
}

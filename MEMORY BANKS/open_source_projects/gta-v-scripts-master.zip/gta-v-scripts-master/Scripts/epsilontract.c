#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
var uLocal_18 = 0;
var uLocal_19 = 0;
char *sLocal_20 = NULL;
float fLocal_21 = 0f;
var uLocal_22 = 0;
var uLocal_23 = 0;
var uLocal_24 = 0;
float fLocal_25 = 0f;
float fLocal_26 = 0f;
var uLocal_27 = 0;
var uLocal_28 = 0;
var uLocal_29 = 0;
float fLocal_30 = 0f;
float fLocal_31 = 0f;
float fLocal_32 = 0f;
var uLocal_33 = 0;
var uLocal_34 = 0;
int iLocal_35 = 0;
var uLocal_36 = 0;
int iLocal_37 = 0;
int iLocal_38 = 0;
int iLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
int *iLocal_44 = NULL;
int *iLocal_45 = NULL;
int *iLocal_46 = NULL;
int *iLocal_47 = NULL;
var *uLocal_48 = NULL;
struct<11> Local_49[10];
char *sLocal_160[10] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
#pragma endregion //}

void __EntryFunction__() {
	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_20 = "NULL";
	fLocal_21 = 0f;
	fLocal_25 = -0.0375f;
	fLocal_26 = 0.17f;
	fLocal_30 = 80f;
	fLocal_31 = 140f;
	fLocal_32 = 180f;
	iLocal_35 = 3;
	iLocal_37 = 1;
	iLocal_38 = 1;
	iLocal_40 = joaat("prop_time_capsule_01");
	if (player::has_force_cleanup_occurred(210)) {
		func_49();
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("epsilontract")) > 1) {
		script::terminate_this_thread();
	}
	func_48(9);
	while (true) {
		system::wait(0);
		switch (iLocal_39) {
		case 0: func_47(); break;

		case 1: func_1(); break;

		case 2: func_49(); break;
		}
	}
}

// Position - 0xCE
void func_1() {
	int iVar0;
	int iVar1;

	if (func_46(player::player_ped_id()) && !func_45(14) && !cam::is_screen_faded_out()) {
		if (iLocal_41 < 10) {
			if (iLocal_41 == 0) {
				if (!func_44(36) && gameplay::get_game_timer() - iLocal_42 > iLocal_43) {
					func_43(0, 60, sLocal_160[0], 1, 0, 0, 0, 0, 1);
					func_42(36);
					iLocal_42 = -1;
				}
			}
			else if (iLocal_41 < 10) {
				if (iLocal_42 != -1) {
					if (gameplay::get_game_timer() - iLocal_42 > 15000) {
						func_43(0, 60, sLocal_160[iLocal_41], 1, 0, 0, 0, 0, 1);
						iLocal_42 = -1;
					}
				}
			}
			if (Local_49[iLocal_41 /*11*/].f_10) {
				if (object::has_pickup_been_collected(Local_49[iLocal_41 /*11*/].f_1) ||
					func_41(Local_49[iLocal_41 /*11*/].f_1)) {
					if (entity::does_entity_exist(player::player_ped_id())) {
						ai::task_clear_look_at(player::player_ped_id());
					}
					func_40(&Local_49[iLocal_41 /*11*/].f_1);
					Local_49[iLocal_41 /*11*/].f_10 = 0;
					controls::set_pad_shake(0, 200, 250);
					iVar0 = 805 + iLocal_41;
					func_39(iVar0, 1, -1, 1);
					stats::stat_increment(joaat("num_hidden_packages_2"), 1f);
					iLocal_46 = 1;
					if (iLocal_41 < 10) {
						iLocal_41++;
						iLocal_42 = gameplay::get_game_timer();
						func_38(1, 0);
						func_36();
					}
				}
				else if (object::does_pickup_exist(Local_49[iLocal_41 /*11*/].f_1)) {
					func_34(Local_49[iLocal_41 /*11*/].f_3);
					func_33(&Local_49[iLocal_41 /*11*/].f_1, &Local_49[iLocal_41 /*11*/].f_10);
				}
			}
			else {
				while (func_32(4, iVar1) && iVar1 < 10) {
					iVar1++;
				}
				if (iVar1 == iLocal_41) {
					func_30(&Local_49[iLocal_41 /*11*/], iLocal_40, joaat("pickup_custom_script"), 0, 0, 2);
				}
			}
		}
		else if (!iLocal_47 && !iLocal_46) {
			func_13();
		}
		func_2(&iLocal_46, &iLocal_47, &uLocal_48, 4, &iLocal_44, &iLocal_45, "TRACT_TITLE", "TRACT_COLLECT");
	}
}

// Position - 0x2A0
void func_2(int *iParam0, int *iParam1, var *uParam2, int iParam3, int *iParam4, int *iParam5, char *sParam6,
			char *sParam7) {
	int iVar0;

	func_12(0);
	if (*iParam0) {
		switch (*iParam4) {
		case 0:
			*iParam5 = unk_0x67D02A194A2FC2BD("MIDSIZED_MESSAGE");
			if (graphics::has_scaleform_movie_loaded(*iParam5)) {
				iVar0 = audio::get_sound_id();
				if (iParam3 == 6) {
					audio::play_sound_frontend(iVar0, "PEYOTE_COMPLETED", "HUD_AWARDS", 1);
				}
				else {
					audio::play_sound_frontend(iVar0, "COLLECTED", "HUD_AWARDS", 1);
				}
				*iParam4++;
			}
			break;

		case 1:
			graphics::_push_scaleform_movie_function(*iParam5, "SHOW_SHARD_MIDSIZED_MESSAGE");
			graphics::begin_text_command_scaleform_string(sParam6);
			graphics::end_text_command_scaleform_string();
			graphics::begin_text_command_scaleform_string(sParam7);
			ui::add_text_component_integer(func_4(iParam3));
			graphics::end_text_command_scaleform_string();
			graphics::_pop_scaleform_movie_function_void();
			*uParam2 = gameplay::get_game_timer();
			*iParam4++;
			break;

		case 2:
			if (gameplay::get_game_timer() - *uParam2 > 7000) {
				graphics::_push_scaleform_movie_function(*iParam5, "SHARD_ANIM_OUT");
				graphics::_push_scaleform_movie_function_parameter_int(1);
				graphics::_push_scaleform_movie_function_parameter_float(0.33f);
				graphics::_pop_scaleform_movie_function_void();
				*iParam4++;
			}
			else if (!func_3()) {
				if (graphics::has_scaleform_movie_loaded(*iParam5)) {
					func_12(1);
					graphics::draw_scaleform_movie_fullscreen(*iParam5, 100, 100, 100, 255, 0);
				}
			}
			break;

		case 3:
			if (gameplay::get_game_timer() - *uParam2 > 7500) {
				*iParam4++;
			}
			else if (!func_3()) {
				if (graphics::has_scaleform_movie_loaded(*iParam5)) {
					func_12(1);
					graphics::draw_scaleform_movie_fullscreen(*iParam5, 100, 100, 100, 255, 0);
				}
			}
			break;

		case 4:
			if (graphics::has_scaleform_movie_loaded(*iParam5)) {
				graphics::set_scaleform_movie_as_no_longer_needed(iParam5);
			}
			func_12(0);
			*iParam1 = 0;
			*iParam0 = 0;
			*iParam4 = 0;
			break;
		}
	}
}

// Position - 0x423
int func_3() {
	if (Global_69962) {
		return 1;
	}
	else if (Global_55816 && !Global_55822) {
		return 1;
	}
	return 0;
}

// Position - 0x44D
int func_4(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	iVar1 = 0;
	if (iParam0 == 2) {
		iVar1 = 0;
		while (iVar1 < func_11(iParam0)) {
			if (gameplay::is_bit_set(Global_101700.f_9008.f_108, func_10(func_11(iParam0), iVar1))) {
				iVar0++;
			}
			iVar1++;
		}
	}
	else if (iParam0 == 6) {
		stats::stat_get_int(joaat("num_hidden_packages_5"), &iVar0, -1);
	}
	else if (iParam0 == 7) {
		stats::stat_get_int(joaat("num_hidden_packages_7"), &iVar0, -1);
	}
	else if (iParam0 == 8) {
		stats::stat_get_int(joaat("num_hidden_packages_6"), &iVar0, -1);
	}
	else {
		iVar1 = 0;
		while (iVar1 < func_11(iParam0)) {
			iVar2 = func_9(iParam0) + iVar1;
			if (func_5(iVar2, -1, -1)) {
				iVar0++;
			}
			iVar1++;
		}
	}
	return iVar0;
}

// Position - 0x515
bool func_5(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	if (iParam1 == -1) {
		iParam1 = func_8();
	}
	iVar1 = func_7(iParam0, iParam1);
	iVar2 = func_6(iParam0);
	if (0 != iVar1) {
		iVar0 = stats::stat_get_bool_masked(iVar1, iVar2, iParam2);
	}
	return iVar0;
}

// Position - 0x552
int func_6(int iParam0) {
	int iVar0;

	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		iVar0 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		iVar0 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		iVar0 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		iVar0 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		iVar0 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		iVar0 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		iVar0 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		iVar0 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		iVar0 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		iVar0 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		iVar0 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		iVar0 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
	}
	return iVar0;
}

// Position - 0x762
int func_7(int iParam0, int iParam1) {
	int iVar0;

	if (iParam1 == -1) {
		iParam1 = func_8();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		iVar0 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam1);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		iVar0 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam1);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		iVar0 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		iVar0 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		iVar0 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		iVar0 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam1);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam1, "_NGPSTAT_BOOL");
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam1, "_NGTATPSTAT_BOOL");
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam1, "_NGDLCPSTAT_BOOL");
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		iVar0 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam1, "_DLCBIKEPSTAT_BOOL");
	}
	return iVar0;
}

// Position - 0x952
var func_8() { return Global_1312735; }

// Position - 0x95E
int func_9(int iParam0) {
	if (iParam0 == 3) {
		return 815;
	}
	if (iParam0 == 5) {
		return 845;
	}
	if (iParam0 == 1) {
		return 705;
	}
	if (iParam0 == 0) {
		return 755;
	}
	return 805;
}

// Position - 0x9A5
int func_10(int iParam0, int iParam1) {
	if (iParam1 < 32) {
		return iParam1;
	}
	return iParam0 - iParam1;
}

// Position - 0x9C1
int func_11(int iParam0) {
	if (iParam0 == 3) {
		return 30;
	}
	if (iParam0 == 1) {
		return 50;
	}
	if (iParam0 == 0) {
		return 50;
	}
	if (iParam0 == 4) {
		return 10;
	}
	if (iParam0 == 5) {
		return 30;
	}
	return 15;
}

// Position - 0xA11
void func_12(int iParam0) {
	if (Global_69969 != iParam0) {
		Global_69969 = iParam0;
	}
}

// Position - 0xA2B
void func_13() {
	func_29(95, 1);
	func_15(27, 84, 0);
	func_14(9);
	iLocal_39 = 2;
}

// Position - 0xA4D
int func_14(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		gameplay::clear_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
		return 1;
	}
	return 0;
}

// Position - 0xAA7
int func_15(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = func_27(iParam0, 1);
	if (iVar0 == -1) {
		return 0;
	}
	if (Global_46225[iVar0 /*203*/].f_9 == 4) {
		return 0;
	}
	Global_46225[iVar0 /*203*/].f_2 = iParam0;
	Global_46225[iVar0 /*203*/].f_10[Global_46225[iVar0 /*203*/].f_9 /*48*/] = iParam1;
	Global_46225[iVar0 /*203*/].f_10[Global_46225[iVar0 /*203*/].f_9 /*48*/].f_1 = 0;
	Global_46225[iVar0 /*203*/].f_10[Global_46225[iVar0 /*203*/].f_9 /*48*/].f_6 = 0;
	Global_46225[iVar0 /*203*/].f_9++;
	iVar1 = 0;
	iVar2 = -1;
	iVar1 = 0;
	while (iVar1 < Global_46225[iVar0 /*203*/].f_3) {
		if (iVar2 == -1) {
			if (Global_46225[iVar0 /*203*/].f_4[iVar1] == Global_36925[iParam1 /*12*/].f_3) {
				iVar2 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar2 == -1) {
		if (Global_46225[iVar0 /*203*/].f_3 == 4) {
			return 0;
		}
		else {
			Global_46225[iVar0 /*203*/].f_4[Global_46225[iVar0 /*203*/].f_3] = Global_36925[iParam1 /*12*/].f_3;
			Global_46225[iVar0 /*203*/].f_3++;
		}
	}
	iVar1 = 0;
	iVar2 = -1;
	iVar1 = 0;
	while (iVar1 < Global_46225[iVar0 /*203*/].f_3) {
		if (iVar2 == -1) {
			if (Global_46225[iVar0 /*203*/].f_4[iVar1] == Global_36925[iParam1 /*12*/].f_2) {
				iVar2 = iVar1;
			}
		}
		iVar1++;
	}
	if (iVar2 == -1) {
		if (Global_46225[iVar0 /*203*/].f_3 == 4) {
			return 0;
		}
		else {
			Global_46225[iVar0 /*203*/].f_4[Global_46225[iVar0 /*203*/].f_3] = Global_36925[iParam1 /*12*/].f_2;
			Global_46225[iVar0 /*203*/].f_3++;
		}
	}
	iVar1 = 0;
	iVar1 = 0;
	while (iVar1 < Global_46225[iVar0 /*203*/].f_3) {
		iVar3 = Global_46225[iVar0 /*203*/].f_4[iVar1];
		if (iVar3 < 3) {
			func_16(Global_46225[iVar0 /*203*/].f_4[iVar1], Global_46225[iVar0 /*203*/].f_1, 1, iParam2, 0);
		}
		iVar1++;
	}
	return 1;
}

// Position - 0xCA3
void func_16(int iParam0, int iParam1, int iParam2, bool bParam3, int iParam4) {
	int iVar0;
	int iVar1;
	int iVar2;
	struct<16> Var3;
	int iVar19;
	int iVar20;
	bool bVar21;
	bool bVar22;
	int iVar23;
	int iVar24;
	int iVar25;
	int iVar26;

	if (iParam0 >= 3) {
		return;
	}
	iVar0 = -1;
	StringCopy(&Var3, "UNSET", 64);
	if (!iParam2) {
		iVar19 = Global_40250[iParam1 /*46*/].f_42 - 1;
		if (iVar19 < 0) {
			return;
		}
		iVar20 = Global_40250[iParam1 /*46*/].f_32[iVar19];
		iVar2 = iVar20;
		Var3 = {func_26(Global_36925[iVar20 /*12*/].f_1)};
		if (Global_36925[iVar20 /*12*/].f_2 == iParam0 && Global_36925[iVar20 /*12*/].f_3 != iParam0) {
			return;
		}
		iVar1 = Global_36925[iVar20 /*12*/].f_2;
		iVar0 = Global_45863[iParam0 /*120*/];
		bVar21 = false;
		while (iVar0 >= 16) {
			iVar0 -= 16;
			bVar21 = true;
		}
		if (bVar21) {
			if (!Global_45863[iParam0 /*120*/].f_69[iVar0]) {
				switch (iParam0) {
				case 0:
					Global_36917--;
					if (Global_36917 < 0) {
						Global_36917 = 0;
					}
					break;

				case 1:
					Global_36918--;
					if (Global_36918 < 0) {
						Global_36918 = 0;
					}
					break;

				case 2:
					Global_36919--;
					if (Global_36919 < 0) {
						Global_36919 = 0;
					}
					break;
				}
			}
		}
		Global_45863[iParam0 /*120*/].f_18[iVar0] = iParam1;
		Global_45863[iParam0 /*120*/].f_1[iVar0] = iVar19;
		Global_45863[iParam0 /*120*/].f_35[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_86[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_69[iVar0] = 0;
		Global_45863[iParam0 /*120*/]++;
	}
	else {
		iVar0 = Global_45863[iParam0 /*120*/];
		bVar22 = false;
		while (iVar0 >= 16) {
			iVar0 -= 16;
			bVar22 = true;
		}
		if (bVar22) {
			if (!Global_45863[iParam0 /*120*/].f_69[iVar0]) {
				switch (iParam0) {
				case 0:
					Global_36917--;
					if (Global_36917 < 0) {
						Global_36917 = 0;
					}
					break;

				case 1:
					Global_36918--;
					if (Global_36918 < 0) {
						Global_36918 = 0;
					}
					break;

				case 2:
					Global_36919--;
					if (Global_36919 < 0) {
						Global_36919 = 0;
					}
					break;
				}
			}
		}
		iVar23 = -1;
		iVar24 = 0;
		iVar24 = 0;
		while (iVar24 < 7) {
			if (Global_46225[iVar24 /*203*/].f_1 == iParam1 && Global_46225[iVar24 /*203*/].f_9 > 0) {
				iVar23 = iVar24;
			}
			iVar24++;
		}
		if (iVar23 == -1) {
			return;
		}
		Global_45863[iParam0 /*120*/].f_18[iVar0] = Global_46225[iVar23 /*203*/].f_1;
		Global_45863[iParam0 /*120*/].f_1[iVar0] = Global_46225[iVar23 /*203*/].f_9 - 1;
		Global_45863[iParam0 /*120*/].f_35[iVar0] = 0;
		Global_45863[iParam0 /*120*/].f_86[iVar0] = 1;
		Global_45863[iParam0 /*120*/].f_69[iVar0] = 0;
		Global_45863[iParam0 /*120*/]++;
		iVar25 = Global_45863[iParam0 /*120*/].f_1[iVar0];
		iVar26 = Global_46225[iVar23 /*203*/].f_10[iVar25 /*48*/];
		iVar2 = iVar26;
		iVar1 = Global_36925[iVar26 /*12*/].f_2;
		if (Global_46225[iVar23 /*203*/].f_10[Global_46225[iVar23 /*203*/].f_9 - 1 /*48*/].f_1) {
			MemCopy(&Var3, {Global_46225[iVar23 /*203*/].f_10[Global_46225[iVar23 /*203*/].f_9 - 1 /*48*/].f_2}, 16);
		}
		else {
			Var3 = {func_26(Global_36925[iVar26 /*12*/].f_1)};
		}
	}
	if (!iParam4) {
		if (!Global_45863[iParam0 /*120*/].f_69[iVar0] && !bParam3) {
			switch (iParam0) {
			case 0: func_17(0, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); break;

			case 1:
				if (iVar2 == 249) {
					func_17(1, iVar1, iVar2, "PW_FEED_EM_1", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
				}
				else {
					func_17(1, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
				}
				break;

			case 2: func_17(2, iVar1, iVar2, &Var3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0); break;
			}
		}
	}
}

// Position - 0x1076
void func_17(int iParam0, int iParam1, int iParam2, char *sParam3, char *sParam4, char *sParam5, char *sParam6,
			 char *sParam7, char *sParam8, char *sParam9, char *sParam10, char *sParam11, char *sParam12,
			 char *sParam13) {
	int iVar0;
	bool bVar1;
	char cVar2[64];

	if (cutscene::is_cutscene_playing()) {
		return;
	}
	iVar0 = func_21();
	bVar1 = false;
	StringCopy(&cVar2, func_20(iParam1, &bVar1), 64);
	if (iVar0 == iParam0) {
		switch (iParam2) {
		case 72: ui::_set_notification_text_entry("PROPR_INCEMAIL1"); break;

		case 73: ui::_set_notification_text_entry("PROPR_INCEMAIL3"); break;

		case 74: ui::_set_notification_text_entry("PROPR_INCEMAIL2"); break;

		default:
			ui::_set_notification_text_entry(sParam3);
			if (!gameplay::is_string_null_or_empty(sParam4)) {
				ui::add_text_component_substring_text_label(sParam4);
			}
			if (!gameplay::is_string_null_or_empty(sParam5)) {
				ui::add_text_component_substring_text_label(sParam5);
			}
			if (!gameplay::is_string_null_or_empty(sParam6)) {
				ui::add_text_component_substring_text_label(sParam6);
			}
			if (!gameplay::is_string_null_or_empty(sParam7)) {
				ui::add_text_component_substring_text_label(sParam7);
			}
			if (!gameplay::is_string_null_or_empty(sParam8)) {
				ui::add_text_component_substring_text_label(sParam8);
			}
			if (!gameplay::is_string_null_or_empty(sParam9)) {
				ui::add_text_component_substring_text_label(sParam9);
			}
			if (!gameplay::is_string_null_or_empty(sParam10)) {
				ui::add_text_component_substring_text_label(sParam10);
			}
			if (!gameplay::is_string_null_or_empty(sParam11)) {
				ui::add_text_component_substring_text_label(sParam11);
			}
			if (!gameplay::is_string_null_or_empty(sParam12)) {
				ui::add_text_component_substring_text_label(sParam12);
			}
			if (!gameplay::is_string_null_or_empty(sParam13)) {
				ui::add_text_component_substring_text_label(sParam13);
			}
			break;
		}
		if (bVar1) {
			func_18(ui::_set_notification_message(&cVar2, &cVar2, 0, 2, ui::_get_label_text(func_19(iParam1)), 0));
		}
		else {
			func_18(ui::_set_notification_message("CHAR_DEFAULT", "CHAR_DEFAULT", 0, 2,
												  ui::_get_label_text(func_19(iParam1)), 0));
		}
		switch (Global_14443) {
		case 0:
			StringCopy(&Global_14432, "Phone_SoundSet_Michael", 24);
			Global_36917++;
			if (Global_36917 > 16) {
				Global_36917 = 16;
			}
			break;

		case 2:
			StringCopy(&Global_14432, "Phone_SoundSet_Trevor", 24);
			Global_36919++;
			if (Global_36919 > 16) {
				Global_36919 = 16;
			}
			break;

		case 1:
			StringCopy(&Global_14432, "Phone_SoundSet_Franklin", 24);
			Global_36918++;
			if (Global_36918 > 16) {
				Global_36918 = 16;
			}
			break;

		default: StringCopy(&Global_14432, "Phone_SoundSet_Default", 24); break;
		}
		audio::play_sound_frontend(-1, "Notification", &Global_14432, 1);
	}
}

// Position - 0x125B
void func_18(var uParam0) {
	Global_36920[Global_36924] = uParam0;
	Global_16803 = 1;
	Global_16802 = uParam0;
	Global_36924++;
	if (Global_36924 == 3) {
		Global_36924 = 0;
	}
}

// Position - 0x1289
char *func_19(int iParam0) {
	switch (iParam0) {
	case 0: return "EMSTR_0";

	case 3: return "EMSTR_3";

	case 1: return "EMSTR_6";

	case 2: return "EMSTR_9";

	case 4: return "EMSTR_12";

	case 5: return "EMSTR_29";

	case 6: return "EMSTR_36";

	case 7: return "EMSTR_39";

	case 8: return "EMSTR_52";

	case 9: return "EMSTR_55";

	case 10: return "EMSTR_58";

	case 11: return "EMSTR_78";

	case 12: return "EMSTR_81";

	case 13: return "EMSTR_84";

	case 14: return "EMSTR_87";

	case 15: return "EMSTR_106";

	case 16: return "EMSTR_114";

	case 17: return "EMSTR_142";

	case 18: return "EMSTR_145";

	case 19: return "EMSTR_152";

	case 20: return "EMSTR_157";

	case 21: return "EMSTR_163";

	case 22: return "EMSTR_182";

	case 23: return "EMSTR_187";

	case 24: return "EMSTR_190";

	case 25: return "EMSTR_206";

	case 26: return "EMSTR_219";

	case 27: return "EMSTR_226";

	case 28: return "EMSTR_233";

	case 29: return "EMSTR_242";

	case 30: return "EMSTR_249";

	case 31: return "EMSTR_262";

	case 32: return "EMSTR_269";

	case 33: return "EMSTR_319";

	case 34: return "EMSTR_340";

	case 35: return "EMSTR_348";

	case 36: return "EMSTR_182";

	case 37: return "EMSTR_357";

	case 38: return "EMSTR_360";

	case 39: return "EMSTR_369";

	case 40: return "EMSTR_376";

	case 41: return "EMSTR_379";

	case 42: return "EMSTR_382";

	case 43: return "EMSTR_384";

	case 44: return "EMSTR_387";

	case 45: return "EMSTR_390";

	case 46: return "EMSTR_393";

	case 47: return "EMSTR_396";

	case 48: return "EMSTR_399";

	case 49: return "EMSTR_402";

	case 50: return "EMSTR_405";

	case 51: return "EMSTR_408";

	case 52: return "EMSTR_411";

	case 53: return "EMSTR_414";

	case 54: return "EMSTR_465";

	case 55: return "EMSTR_468";

	case 56: return "EMSTR_489";

	case 57: return "EMSTR_492";

	case 58: return "EMSTR_495";

	case 59: return "EMSTR_498";

	case 60: return "EMSTR_501";

	case 61: return "EMSTR_504";

	case 62: return "EMSTR_507";

	case 63: return "EMSTR_640";

	case 64: return "EMSTR_643";

	case 65: return "EMSTR_652";

	default:
	}
	return "NULL";
}

// Position - 0x15F4
char *func_20(int iParam0, int *iParam1) {
	*iParam1 = 1;
	switch (iParam0) {
	case 0: return ui::_get_label_text(&Global_101700.f_27009[0 /*29*/].f_7);

	case 1: return ui::_get_label_text(&Global_101700.f_27009[1 /*29*/].f_7);

	case 2: return ui::_get_label_text(&Global_101700.f_27009[2 /*29*/].f_7);

	case 7: return ui::_get_label_text(&Global_101700.f_27009[12 /*29*/].f_7);

	case 4: return ui::_get_label_text(&Global_101700.f_27009[60 /*29*/].f_7);

	case 6: return ui::_get_label_text(&Global_101700.f_27009[62 /*29*/].f_7);

	case 3: return ui::_get_label_text(&Global_101700.f_27009[14 /*29*/].f_7);

	case 16: return ui::_get_label_text(&Global_101700.f_27009[97 /*29*/].f_7);

	case 19: return ui::_get_label_text(&Global_101700.f_27009[99 /*29*/].f_7);

	case 15: return ui::_get_label_text(&Global_101700.f_27009[96 /*29*/].f_7);

	case 63: return "CHAR_CARSITE2";

	case 64: return "CHAR_BOATSITE";

	case 8: return "CHAR_BANK_MAZE";

	case 9: return "CHAR_BANK_FLEECA";

	case 10: return "CHAR_BANK_BOL";

	case 21: return "CHAR_MINOTAUR";

	case 25: return ui::_get_label_text(&Global_101700.f_27009[15 /*29*/].f_7);

	case 26: return ui::_get_label_text(&Global_101700.f_27009[30 /*29*/].f_7);

	case 27: return ui::_get_label_text(&Global_101700.f_27009[17 /*29*/].f_7);

	case 29: return ui::_get_label_text(&Global_101700.f_27009[20 /*29*/].f_7);

	case 30: return ui::_get_label_text(&Global_101700.f_27009[43 /*29*/].f_7);

	case 31: return ui::_get_label_text(&Global_101700.f_27009[44 /*29*/].f_7);

	case 32: return ui::_get_label_text(&Global_101700.f_27009[19 /*29*/].f_7);

	case 34: return ui::_get_label_text(&Global_101700.f_27009[40 /*29*/].f_7);

	case 36: return ui::_get_label_text("CELL_E_381");

	case 38: return ui::_get_label_text(&Global_101700.f_27009[64 /*29*/].f_7);

	case 5: return "CHAR_EPSILON";

	case 13: return "CHAR_MILSITE";

	case 11: return "CHAR_CARSITE";

	case 14: return "CHAR_BOATSITE";

	case 12: return "CHAR_PLANESITE";

	case 24: return "CHAR_DR_FRIEDLANDER";

	case 55: return "CHAR_CARSITE2";

	case 54: return "CHAR_BIKESITE";

	case 39: return ui::_get_label_text(&Global_101700.f_27009[122 /*29*/].f_7);

	case 40: return ui::_get_label_text(&Global_101700.f_27009[125 /*29*/].f_7);

	case 41: return ui::_get_label_text(&Global_101700.f_27009[113 /*29*/].f_7);

	case 42: return ui::_get_label_text(&Global_101700.f_27009[126 /*29*/].f_7);

	case 43: return ui::_get_label_text(&Global_101700.f_27009[127 /*29*/].f_7);

	case 44: return ui::_get_label_text(&Global_101700.f_27009[124 /*29*/].f_7);

	case 45: return ui::_get_label_text(&Global_101700.f_27009[114 /*29*/].f_7);

	case 46: return ui::_get_label_text(&Global_101700.f_27009[115 /*29*/].f_7);

	case 47: return ui::_get_label_text(&Global_101700.f_27009[116 /*29*/].f_7);

	case 48: return ui::_get_label_text(&Global_101700.f_27009[123 /*29*/].f_7);

	case 49: return ui::_get_label_text(&Global_101700.f_27009[117 /*29*/].f_7);

	case 50: return ui::_get_label_text(&Global_101700.f_27009[118 /*29*/].f_7);

	case 51: return ui::_get_label_text(&Global_101700.f_27009[119 /*29*/].f_7);

	case 52: return ui::_get_label_text(&Global_101700.f_27009[120 /*29*/].f_7);

	case 53: return ui::_get_label_text(&Global_101700.f_27009[121 /*29*/].f_7);

	default:
	}
	*iParam1 = 0;
	return "ERROR!";
}

// Position - 0x1A47
var func_21() {
	func_22();
	return Global_101700.f_2095.f_539.f_3549;
}

// Position - 0x1A60
void func_22() {
	int iVar0;

	if (entity::does_entity_exist(player::player_ped_id())) {
		if (func_25(Global_101700.f_2095.f_539.f_3549) != entity::get_entity_model(player::player_ped_id())) {
			iVar0 = func_24(player::player_ped_id());
			if (func_23(iVar0) && (!func_45(14) || Global_100652)) {
				if (Global_101700.f_2095.f_539.f_3549 != iVar0 && func_23(Global_101700.f_2095.f_539.f_3549)) {
					Global_101700.f_2095.f_539.f_3550 = Global_101700.f_2095.f_539.f_3549;
				}
				Global_101700.f_2095.f_539.f_3551 = iVar0;
				Global_101700.f_2095.f_539.f_3549 = iVar0;
				return;
			}
		}
		else {
			if (Global_101700.f_2095.f_539.f_3549 != 145) {
				Global_101700.f_2095.f_539.f_3551 = Global_101700.f_2095.f_539.f_3549;
			}
			return;
		}
	}
	Global_101700.f_2095.f_539.f_3549 = 145;
}

// Position - 0x1B5D
bool func_23(int iParam0) { return iParam0 < 3; }

// Position - 0x1B69
int func_24(int iParam0) {
	int iVar0;
	int iVar1;

	if (entity::does_entity_exist(iParam0)) {
		iVar1 = entity::get_entity_model(iParam0);
		iVar0 = 0;
		while (iVar0 <= 2) {
			if (func_25(iVar0) == iVar1) {
				return iVar0;
			}
			iVar0++;
		}
	}
	return 145;
}

// Position - 0x1BA6
int func_25(int iParam0) {
	if (func_23(iParam0)) {
		return Global_101700.f_27009[iParam0 /*29*/];
	}
	else if (iParam0 != 145) {
	}
	return 0;
}

// Position - 0x1BD0
struct<16> func_26(int iParam0) {
	struct<16> Var0;
	struct<16> Var16;

	if (iParam0 > -1) {
		StringCopy(&Var0, "EMSTR_", 64);
		StringIntConCat(&Var0, iParam0, 64);
		return Var0;
	}
	StringCopy(&Var16, "FAIL", 64);
	return Var16;
}

//Position - 0x1C01
int func_27(int iParam0, int iParam1)
{
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;

	iVar0 = func_28(iParam0);
	if (iVar0 > -1) {
		if (Global_46225[iVar0 /*203*/].f_9 < 4) {
			return iVar0;
		}
	}
	iVar1 = 0;
	iVar2 = 0;
	iVar1 = 0;
	while (iVar1 < 7) {
		if (Global_46225[iVar1 /*203*/] == 0) {
			iVar2 = 1;
		}
		iVar1++;
	}
	if (!iVar2) {
		return -1;
	}
	iVar3 = 1;
	iVar1 = 0;
	iVar4 = -1;
	iVar5 = -1;
	iVar1 = 0;
	while (iVar1 < 7) {
		if (Global_46225[iVar1 /*203*/] == 0) {
			if (iVar3) {
				iVar4 = iVar1;
				iVar5 = Global_46225[iVar1 /*203*/].f_1;
				iVar3 = 0;
			}
			else if (iVar5 > Global_46225[iVar1 /*203*/].f_1) {
				iVar4 = iVar1;
				iVar5 = Global_46225[iVar1 /*203*/].f_1;
			}
		}
		iVar1++;
	}
	if (Global_46225[iVar4 /*203*/].f_9 > 0) {
		iVar1 = 0;
		iVar1 = 0;
		while (iVar1 < Global_46225[iVar4 /*203*/].f_9) {
			iVar6 = 0;
			iVar6 = 0;
			while (iVar6 < 3) {
				iVar7 = Global_45863[iVar6 /*120*/];
				if (iVar7 > 16) {
					iVar7 = 16;
				}
				iVar8 = 0;
				iVar8 = 0;
				while (iVar8 < iVar7) {
					if (Global_45863[iVar6 /*120*/].f_86[iVar8]) {
						if (!Global_45863[iVar6 /*120*/].f_69[iVar8]) {
							if (Global_45863[iVar6 /*120*/].f_18[iVar8] == Global_46225[iVar4 /*203*/].f_1) {
								if (Global_45863[iVar6 /*120*/].f_1[iVar8] == iVar1) {
									switch (iVar6) {
									case 0: Global_36917--; break;

									case 1: Global_36918--; break;

									case 2: Global_36919--; break;
									}
								}
							}
						}
					}
					iVar8++;
				}
				iVar6++;
			}
			iVar1++;
		}
	}
	Global_46225[iVar4 /*203*/].f_2 = iParam0;
	Global_46225[iVar4 /*203*/].f_3 = 0;
	if (!iParam1) {
		Global_46225[iVar4 /*203*/] = 1;
	}
	Global_101700.f_19996.f_310++;
	if (Global_101700.f_19996.f_310 == 0) {
		Global_101700.f_19996.f_310 = 1;
	}
	Global_46225[iVar4 /*203*/].f_1 = Global_101700.f_19996.f_310;
	Global_46225[iVar4 /*203*/].f_9 = 0;
	return iVar4;
}

// Position - 0x1E19
int func_28(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;

	iVar0 = 0;
	iVar1 = -1;
	iVar2 = -1;
	iVar0 = 0;
	while (iVar0 < 7) {
		if (Global_46225[iVar0 /*203*/].f_2 == iParam0) {
			if (Global_46225[iVar0 /*203*/].f_1 > iVar2) {
				iVar2 = Global_46225[iVar0 /*203*/].f_1;
				iVar1 = iVar0;
			}
		}
		iVar0++;
	}
	if (iVar1 != -1 && iVar2 != -1) {
		return iVar1;
	}
	return -1;
}

// Position - 0x1E7D
void func_29(int iParam0, int iParam1) {
	if (iParam0 == 146 || iParam0 == -1) {
		return;
	}
	if (Global_101700.f_8044.f_99.f_58[iParam0] == iParam1) {
		return;
	}
	Global_101700.f_8044.f_99.f_58[iParam0] = iParam1;
}

// Position - 0x1EC2
void func_30(var *uParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;

	if (!uParam0->f_10) {
		if (!ped::is_ped_injured(player::player_ped_id())) {
			if (!func_45(13) && !func_45(14)) {
				if (!object::does_pickup_exist(uParam0->f_1)) {
					if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1), uParam0->f_3) <=
						50f * 50f) {
						streaming::request_model(iParam1);
						while (!streaming::has_model_loaded(iParam1)) {
							streaming::request_model(iParam1);
							system::wait(0);
						}
						if (iParam3) {
							func_31(uParam0->f_3);
						}
						gameplay::clear_area(uParam0->f_3, 2.5f, 0, 0, 0, 0);
						if (iParam4) {
							gameplay::set_bit(&iVar0, 1);
							uParam0->f_1 = object::create_pickup_rotate(joaat("pickup_custom_script"), uParam0->f_3,
																		uParam0->f_6, iVar0, -1, iParam5, 1, iParam1);
						}
						else {
							gameplay::set_bit(&iVar0, 3);
							gameplay::set_bit(&iVar0, 4);
							gameplay::set_bit(&iVar0, 8);
							gameplay::set_bit(&iVar0, 1);
							uParam0->f_1 = object::create_pickup(iParam2, uParam0->f_3, iVar0, -1, 1, iParam1);
						}
						streaming::set_model_as_no_longer_needed(iParam1);
					}
				}
			}
			if (object::does_pickup_exist(uParam0->f_1)) {
				uParam0->f_10 = 1;
			}
		}
	}
}

// Position - 0x1FDB
void func_31(vector3 vParam0) {
	int iVar0;

	iVar0 = interior::get_interior_at_coords(vParam0);
	if (interior::is_valid_interior(iVar0)) {
		interior::_load_interior(iVar0);
		while (!interior::is_interior_ready(iVar0)) {
			system::wait(0);
		}
		system::wait(0);
		interior::unpin_interior(iVar0);
	}
}

// Position - 0x2019
bool func_32(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	if (iParam0 == 1) {
		iVar1 = 705;
	}
	else if (iParam0 == 0) {
		iVar1 = 755;
	}
	else if (iParam0 == 3) {
		iVar1 = 815;
	}
	else if (iParam0 == 4) {
		iVar1 = 805;
	}
	else if (iParam0 == 5) {
		iVar1 = 845;
	}
	iVar0 = iVar1 + iParam1;
	return func_5(iVar0, -1, -1);
}

// Position - 0x2073
void func_33(int *iParam0, int *iParam1) {
	if (!ped::is_ped_injured(player::player_ped_id())) {
		if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
												  object::get_pickup_coords(*iParam0), 1) >= 60f) {
			func_40(iParam0);
			*iParam0 = 0;
			*iParam1 = 0;
		}
	}
}

// Position - 0x20B3
void func_34(vector3 vParam0) {
	if (func_35(player::player_ped_id(), vParam0, 7f)) {
		ai::task_look_at_coord(player::player_ped_id(), vParam0, 100, 2048, 1);
	}
}

// Position - 0x20DD
bool func_35(int iParam0, vector3 vParam1, float fParam4) {
	return system::vdist2(entity::get_entity_coords(iParam0, 1), vParam1) <= fParam4 * fParam4;
}

// Position - 0x20FA
int func_36() {
	if (func_37(0)) {
		return 0;
	}
	if (Global_91530.f_8) {
		if (Global_91530.f_10 > 0) {
			return 0;
		}
	}
	else if (Global_91530.f_10 > 1) {
		return 0;
	}
	Global_91530.f_10++;
	return 1;
}

// Position - 0x2145
bool func_37(int iParam0) {
	if (!iParam0 && script::_get_number_of_instances_of_script_with_name_hash(joaat("benchmark")) > 0) {
		return true;
	}
	return gameplay::is_bit_set(Global_69950, 0);
}

// Position - 0x2170
void func_38(int iParam0, int iParam1) {
	Global_91530.f_7 = iParam0;
	Global_91530.f_8 = iParam1;
}

// Position - 0x2188
int func_39(int iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;
	var uVar2;
	var uVar3;
	var uVar4;
	var uVar5;
	var uVar6;
	var uVar7;
	var uVar8;
	var uVar9;
	var uVar10;
	var uVar11;
	var uVar12;
	var uVar13;

	if (iParam2 == -1) {
		iParam2 = func_8();
	}
	iVar0 = 0;
	if (iParam0 >= 0 && iParam0 < 192) {
		uVar2 = stats::_get_pstat_bool_hash(iParam0 - 0, 0, 1, iParam2);
		iVar1 = iParam0 - 0 - stats::_0xF4D8E7AC2A27758C(iParam0 - 0) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar2, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 192 && iParam0 < 384) {
		uVar3 = stats::_get_pstat_bool_hash(iParam0 - 192, 1, 1, iParam2);
		iVar1 = iParam0 - 192 - stats::_0xF4D8E7AC2A27758C(iParam0 - 192) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar3, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 513 && iParam0 < 705) {
		uVar4 = stats::_get_pstat_bool_hash(iParam0 - 513, 0, 0, 0);
		iVar1 = iParam0 - 513 - stats::_0xF4D8E7AC2A27758C(iParam0 - 513) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar4, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 705 && iParam0 < 1281) {
		uVar5 = stats::_get_pstat_bool_hash(iParam0 - 705, 1, 0, 0);
		iVar1 = iParam0 - 705 - stats::_0xF4D8E7AC2A27758C(iParam0 - 705) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar5, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 3111 && iParam0 < 3879) {
		uVar6 = stats::_get_tupstat_bool_hash(iParam0 - 3111, 0, 1, iParam2);
		iVar1 = iParam0 - 3111 - stats::_0xF4D8E7AC2A27758C(iParam0 - 3111) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar6, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 2919 && iParam0 < 3111) {
		uVar7 = stats::_get_tupstat_bool_hash(iParam0 - 2919, 0, 0, 0);
		iVar1 = iParam0 - 2919 - stats::_0xF4D8E7AC2A27758C(iParam0 - 2919) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar7, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4207 && iParam0 < 4335) {
		uVar8 = stats::_get_ngstat_bool_hash(iParam0 - 4207, 0, 1, iParam2, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4207 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4207) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar8, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 4335 && iParam0 < 4399) {
		uVar9 = stats::_get_ngstat_bool_hash(iParam0 - 4335, 0, 0, 0, "_NGPSTAT_BOOL");
		iVar1 = iParam0 - 4335 - stats::_0xF4D8E7AC2A27758C(iParam0 - 4335) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar9, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 6029 && iParam0 < 6413) {
		uVar10 = stats::_get_ngstat_bool_hash(iParam0 - 6029, 0, 1, iParam2, "_NGTATPSTAT_BOOL");
		iVar1 = iParam0 - 6029 - stats::_0xF4D8E7AC2A27758C(iParam0 - 6029) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar10, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7385 && iParam0 < 7641) {
		uVar11 = stats::_get_ngstat_bool_hash(iParam0 - 7385, 0, 1, iParam2, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7385 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7385) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar11, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 7321 && iParam0 < 7385) {
		uVar12 = stats::_get_ngstat_bool_hash(iParam0 - 7321, 0, 0, 0, "_NGDLCPSTAT_BOOL");
		iVar1 = iParam0 - 7321 - stats::_0xF4D8E7AC2A27758C(iParam0 - 7321) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar12, iParam1, iVar1, iParam3);
	}
	else if (iParam0 >= 9361 && iParam0 < 9553) {
		uVar13 = stats::_get_ngstat_bool_hash(iParam0 - 9361, 0, 1, iParam2, "_DLCBIKEPSTAT_BOOL");
		iVar1 = iParam0 - 9361 - stats::_0xF4D8E7AC2A27758C(iParam0 - 9361) * 64;
		iVar0 = stats::stat_set_bool_masked(uVar13, iParam1, iVar1, iParam3);
	}
	return iVar0;
}

// Position - 0x2516
void func_40(var *uParam0) {
	if (object::does_pickup_exist(*uParam0)) {
		object::remove_pickup(*uParam0);
	}
}

// Position - 0x252F
int func_41(var *uParam0) {
	int iVar0;
	int iVar1;

	if (!object::does_pickup_exist(uParam0)) {
		return 0;
	}
	if (func_46(player::player_ped_id())) {
		if (ped::is_ped_in_any_vehicle(player::player_ped_id(), 0)) {
			iVar0 = ped::get_vehicle_ped_is_in(player::player_ped_id(), 0);
			iVar1 = entity::get_entity_model(iVar0);
			if (iVar1 == joaat("submersible") || iVar1 == joaat("submersible2")) {
				if (system::vdist2(entity::get_entity_coords(player::player_ped_id(), 1),
								   object::get_pickup_coords(uParam0)) < 5f * 5f ||
					entity::is_entity_touching_entity(player::player_ped_id(), object::get_pickup_object(uParam0))) {
					return 1;
				}
			}
		}
	}
	return 0;
}

// Position - 0x25BB
void func_42(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		gameplay::set_bit(&Global_101700.f_19369.f_150[iVar1], iVar0);
	}
}

// Position - 0x25FD
int func_43(int iParam0, int iParam1, char *sParam2, int iParam3, int iParam4, int iParam5, int iParam6, int iParam7,
			int iParam8) {
	int iVar0;

	switch (iParam0) {
	case 0: iVar0 = 21; break;

	case 1: iVar0 = 22; break;

	case 2: iVar0 = 23; break;

	default: return 0;
	}
	StringCopy(&Global_101700.f_13100[iVar0 /*104*/], sParam2, 64);
	Global_101700.f_13100[iVar0 /*104*/].f_17 = iParam1;
	if (iParam3 == 0) {
		return 0;
	}
	else {
		Global_101700.f_13100[iVar0 /*104*/].f_24 = iParam3;
	}
	Global_101700.f_13100[iVar0 /*104*/].f_25 = iParam4;
	Global_101700.f_13100[iVar0 /*104*/].f_26 = iParam5;
	Global_101700.f_13100[iVar0 /*104*/].f_29 = iParam6;
	Global_101700.f_13100[iVar0 /*104*/].f_30 = iParam8;
	Global_101700.f_13100[iVar0 /*104*/].f_31 = iParam7;
	Global_101700.f_13100[iVar0 /*104*/].f_28 = 0;
	return 1;
}

// Position - 0x26CE
int func_44(int iParam0) {
	int iVar0;
	int iVar1;

	iVar0 = iParam0;
	iVar1 = 0;
	while (iVar0 > 31) {
		iVar0 -= 32;
		iVar1++;
	}
	if (iVar1 < 3) {
		return gameplay::is_bit_set(Global_101700.f_19369.f_150[iVar1], iVar0);
	}
	return 0;
}

// Position - 0x2711
bool func_45(int iParam0) { return Global_35781 == iParam0; }

// Position - 0x271F
bool func_46(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x2740
void func_47() {
	int iVar0;
	int iVar1;

	iVar0 = 0;
	if (Global_101700.f_17533.f_388) {
		sLocal_160[0] = "TRACT_HINT1B";
		iLocal_43 = 300000;
	}
	else {
		sLocal_160[0] = "TRACT_HINT1";
		iLocal_43 = 16000;
	}
	Local_49[0 /*11*/].f_3 = {501.9415f, 5604.429f, 796.9146f};
	Local_49[1 /*11*/].f_3 = {2658.18f, -1361.14f, -21.63f};
	sLocal_160[1] = "TRACT_HINT2";
	Local_49[2 /*11*/].f_3 = {24.7139f, 7644.334f, 18.0792f};
	sLocal_160[2] = "TRACT_HINT3";
	Local_49[3 /*11*/].f_3 = {-263.55f, 4729.6f, 137.37f};
	sLocal_160[3] = "TRACT_HINT4";
	Local_49[4 /*11*/].f_3 = {-771.98f, -685.22f, 28.86f};
	sLocal_160[4] = "TRACT_HINT5";
	Local_49[5 /*11*/].f_3 = {-1605.03f, 5256.55f, 1.08f};
	sLocal_160[5] = "TRACT_HINT6";
	Local_49[6 /*11*/].f_3 = {-1804.546f, 403.9298f, 112.1966f};
	sLocal_160[6] = "TRACT_HINT7";
	Local_49[7 /*11*/].f_3 = {484.2701f, 5617.175f, 787.4708f};
	sLocal_160[7] = "TRACT_HINT8";
	Local_49[8 /*11*/].f_3 = {-75.1004f, -819.0673f, 325.3656f};
	sLocal_160[8] = "TRACT_HINT9";
	Local_49[9 /*11*/].f_3 = {-1725.34f, -189.95f, 57.52f};
	sLocal_160[9] = "TRACT_HINT10";
	iLocal_42 = gameplay::get_game_timer();
	iVar0 = 0;
	while (iVar0 < 10) {
		iVar1 = 805 + iVar0;
		if (func_5(iVar1, -1, -1)) {
			iLocal_41++;
		}
		iVar0++;
	}
	iLocal_39 = 1;
}

// Position - 0x28F2
int func_48(int iParam0) {
	int iVar0;
	int iVar1;

	if (iParam0 <= 31) {
		iVar0 = 9;
		iVar1 = iParam0;
	}
	else {
		iVar0 = 10;
		iVar1 = iParam0 - 32;
	}
	if (gameplay::is_bit_set(Global_101700.f_8044.f_99.f_219[iVar0], iVar1)) {
		return 0;
	}
	gameplay::set_bit(&Global_101700.f_8044.f_99.f_219[iVar0], iVar1);
	return 1;
}

// Position - 0x294C
void func_49() {
	int iVar0;

	iVar0 = 0;
	iVar0 = 0;
	while (iVar0 < 10) {
		func_40(&Local_49[iVar0 /*11*/].f_1);
		iVar0++;
	}
	script::terminate_this_thread();
}

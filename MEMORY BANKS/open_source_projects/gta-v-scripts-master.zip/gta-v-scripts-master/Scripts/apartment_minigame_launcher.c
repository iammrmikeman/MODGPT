#pragma region Local Var //{
var uLocal_0 = 0;
var uLocal_1 = 0;
int iLocal_2 = 0;
int iLocal_3 = 0;
int iLocal_4 = 0;
int iLocal_5 = 0;
int iLocal_6 = 0;
int iLocal_7 = 0;
int iLocal_8 = 0;
int iLocal_9 = 0;
int iLocal_10 = 0;
int iLocal_11 = 0;
var uLocal_12 = 0;
var uLocal_13 = 0;
float fLocal_14 = 0f;
var uLocal_15 = 0;
var uLocal_16 = 0;
int iLocal_17 = 0;
char *sLocal_18 = NULL;
var uLocal_19 = 0;
var uLocal_20 = 0;
var uLocal_21 = 0;
var uLocal_22 = 0;
float fLocal_23 = 0f;
float fLocal_24 = 0f;
float fLocal_25 = 0f;
var uLocal_26 = 0;
var uLocal_27 = 0;
float fLocal_28 = 0f;
var uLocal_29 = 0;
var uLocal_30 = 0;
var uLocal_31 = 0;
float fLocal_32 = 0f;
float fLocal_33 = 0f;
var uLocal_34 = 0;
var uLocal_35 = 0;
int iLocal_36 = 0;
var uLocal_37 = 0;
var uLocal_38 = 0;
var uLocal_39 = 0;
int iLocal_40 = 0;
int iLocal_41 = 0;
int iLocal_42 = 0;
int iLocal_43 = 0;
var uLocal_44 = 0;
var uLocal_45 = 0;
var uLocal_46 = 0;
var uLocal_47 = 0;
var uLocal_48 = 0;
var uLocal_49 = 0;
var uLocal_50 = 0;
var uLocal_51 = 0;
var uLocal_52 = 0;
var uLocal_53 = 0;
var uLocal_54 = 0;
var uLocal_55 = 0;
var uLocal_56 = 10;
var uLocal_57 = 0;
var uLocal_58 = 0;
var uLocal_59 = 0;
var uLocal_60 = 0;
var uLocal_61 = 0;
var uLocal_62 = 0;
var uLocal_63 = 0;
var uLocal_64 = 0;
var uLocal_65 = 0;
var uLocal_66 = 0;
var uLocal_67 = 2;
var uLocal_68 = 0;
var uLocal_69 = 0;
var uLocal_70 = 8;
var uLocal_71 = 0;
var uLocal_72 = 0;
var uLocal_73 = 0;
var uLocal_74 = 0;
var uLocal_75 = 0;
var uLocal_76 = 0;
var uLocal_77 = 0;
var uLocal_78 = 0;
var uLocal_79 = 8;
var uLocal_80 = 0;
var uLocal_81 = 0;
var uLocal_82 = 0;
var uLocal_83 = 0;
var uLocal_84 = 0;
var uLocal_85 = 0;
var uLocal_86 = 0;
var uLocal_87 = 0;
var uLocal_88 = 0;
var uLocal_89 = 0;
float fLocal_90 = 0f;
var uLocal_91 = 0;
var uLocal_92 = 0;
float fLocal_93 = 0f;
float fLocal_94 = 0f;
float fLocal_95 = 0f;
float fLocal_96 = 0f;
float fLocal_97 = 0f;
var uLocal_98 = 0;
int iLocal_99 = 0;
int iLocal_100 = 0;
int iLocal_101 = 0;
bool bLocal_102 = 0;
int iLocal_103 = 0;
int iLocal_104 = 0;
int iLocal_105 = 0;
var *uLocal_106 = NULL;
var uLocal_107 = 0;
var uLocal_108 = 0;
var uLocal_109 = 0;
var uLocal_110 = 0;
var uLocal_111 = 0;
var uLocal_112 = 0;
var uLocal_113 = 0;
var uLocal_114 = 0;
var uLocal_115 = 0;
var uLocal_116 = 0;
var uLocal_117 = 0;
var uLocal_118 = 0;
var uLocal_119 = 0;
var uLocal_120 = 0;
var uLocal_121 = 0;
var uLocal_122 = 0;
struct<5> Local_123 = {
	0, 0, 0, 0, 0
};
var uLocal_128 = 0;
struct<60> Local_129 = {
	4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
int *iLocal_189 = NULL;
var uLocal_190 = 0;
var uLocal_191 = 0;
int *iLocal_192 = NULL;
var uLocal_193 = 0;
var uLocal_194 = 0;
int *iLocal_195 = NULL;
var uLocal_196 = 0;
var uLocal_197 = 0;
int *iLocal_198 = NULL;
var uLocal_199 = 0;
var uLocal_200 = 0;
int *iLocal_201 = NULL;
var uLocal_202 = 0;
var uLocal_203 = 0;
int *iLocal_204 = NULL;
var uLocal_205 = 0;
var uLocal_206 = 0;
struct<9> Local_207 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0
};
int *iLocal_216 = NULL;
int iLocal_217 = 0;
int iLocal_218 = 0;
var *uLocal_219 = NULL;
var uLocal_220 = 0;
var uLocal_221 = 0;
var uLocal_222 = 0;
var *uLocal_223[5] = {NULL, NULL, NULL, NULL, NULL};
vector3 vLocal_229[1] = {{0f, 0f, 0f}};
struct<7> Local_233 = {
	0, 0, -1, 0, 0, 0, -1
};
struct<14> Local_240 = {
	0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0
};
var uLocal_254 = 0;
var *uLocal_255 = NULL;
var uLocal_256 = 0;
var uLocal_257 = 0;
var uLocal_258 = 0;
var uLocal_259 = 0;
var uLocal_260 = 0;
var uLocal_261 = 0;
struct<9> Local_262 = {
	0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_271 = 0;
struct<13> Local_272 = {
	4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
var uLocal_285 = 0;
var uLocal_286 = 0;
var uLocal_287 = 0;
var uLocal_288 = 0;
var uLocal_289 = 0;
var uLocal_290 = 0;
var uLocal_291 = 0;
var uLocal_292 = 0;
var uLocal_293 = 0;
var uLocal_294 = 0;
var uLocal_295 = 0;
var uLocal_296 = 0;
var uLocal_297 = 0;
var uLocal_298 = 0;
var uLocal_299 = 0;
var uLocal_300 = 0;
var uLocal_301 = 0;
var uLocal_302 = 0;
var uLocal_303 = 0;
var uLocal_304 = 0;
var uLocal_305 = 0;
var uLocal_306 = 0;
var uLocal_307 = 0;
var uLocal_308 = 0;
var uLocal_309 = 0;
var uLocal_310 = 0;
var uLocal_311 = 0;
var uLocal_312 = 0;
var uLocal_313 = 0;
var uLocal_314 = 0;
var uLocal_315 = 0;
var uLocal_316 = 0;
var uLocal_317 = 0;
var uLocal_318 = 0;
var uLocal_319 = 0;
var uLocal_320 = 0;
var uLocal_321 = 0;
var uLocal_322 = 0;
var uLocal_323 = 0;
var uLocal_324 = 0;
var uLocal_325 = 0;
var uLocal_326 = 0;
var uLocal_327 = 0;
var uLocal_328 = 0;
var uLocal_329 = 0;
var uLocal_330 = 0;
var uLocal_331 = 0;
int iLocal_332 = 0;
int *iLocal_333 = NULL;
var uLocal_334 = 0;
var uLocal_335 = 0;
int *iLocal_336 = NULL;
var uLocal_337 = 0;
var uLocal_338 = 0;
int *iLocal_339 = NULL;
var uLocal_340 = 0;
var uLocal_341 = 0;
struct<21> Local_342[2];
int iLocal_385[2] = {0, 0};
struct<5> Local_388[32];
#pragma endregion //}

void __EntryFunction__() {
	int iVar0;
	int iVar1;
	bool bVar2;
	int iVar3;

	iLocal_2 = 1;
	iLocal_3 = 134;
	iLocal_4 = 134;
	iLocal_5 = 1;
	iLocal_6 = 1;
	iLocal_7 = 1;
	iLocal_8 = 134;
	iLocal_9 = 1;
	iLocal_10 = 12;
	iLocal_11 = 12;
	fLocal_14 = 0.001f;
	iLocal_17 = -1;
	sLocal_18 = "NULL";
	fLocal_23 = 80f;
	fLocal_24 = 140f;
	fLocal_25 = 180f;
	fLocal_28 = 0f;
	fLocal_32 = -0.0375f;
	fLocal_33 = 0.17f;
	iLocal_36 = 3;
	iLocal_40 = 1;
	iLocal_41 = 65;
	iLocal_42 = 49;
	iLocal_43 = 64;
	fLocal_90 = 0.05f + 0.275f - 0.01f;
	fLocal_93 = -0.05f;
	fLocal_94 = 0.92f;
	fLocal_95 = 1.94f;
	fLocal_96 = 2.99f;
	fLocal_97 = 3.7f;
	if (!func_164(&iLocal_198)) {
		func_163(&iLocal_198);
	}
	bVar2 = false;
	while (!iVar0) {
		system::wait(0);
		if (gameplay::get_game_timer() % 1000 > 50) {
			bVar2 = true;
		}
		else {
			bVar2 = false;
		}
		if (!func_162(player::get_player_index()) && func_156(player::get_player_index(), 0, 0, 0, 0)) {
			if (func_155(player::get_player_index())) {
				if (Global_1591201[player::player_id() /*602*/].f_258.f_15 != -1) {
					iVar1 = Global_1591201[player::player_id() /*602*/].f_258.f_15;
					iVar0 = 1;
					func_154(&iLocal_198);
				}
				else if (bVar2) {
				}
			}
			else if (bVar2) {
			}
		}
		if (!iVar0 && func_153(&iLocal_198) >= 25f) {
			func_150();
		}
	}
	if (network::network_is_game_in_progress()) {
		func_143();
	}
	else {
		func_150();
	}
	iLocal_218 = network::participant_id_to_int();
	Local_233.f_6 = Global_1591201[player::player_id() /*602*/].f_258.f_16;
	func_141(&Local_233.f_5);
	func_140(&Local_233.f_5);
	func_139(&uLocal_106);
	func_137(0, -1, 0);
	func_136(&vLocal_229);
	iLocal_101 = 0;
	func_135(&uLocal_219, &uLocal_223);
	Local_240.f_13 = Global_1591201[player::player_id() /*602*/].f_258.f_16;
	if (func_134(iVar1, 91)) {
		iLocal_332 = 0;
	}
	else if (func_134(iVar1, 97)) {
		iLocal_332 = 1;
	}
	func_131(&Local_342, iLocal_332);
	func_130(&uLocal_106, &Local_342);
	Global_1633501.f_89247 = 1;
	Global_1633501.f_89248 = uLocal_223[iLocal_217];
	iVar3 = 0;
	while (iVar3 <= 1) {
		if (!gameplay::is_bit_set(Local_233.f_5, iVar3)) {
			func_129(&uLocal_106, iVar3, 3f);
		}
		iVar3++;
	}
	while (true) {
		system::wait(0);
		if (func_119()) {
			func_150();
		}
		if (!func_162(player::get_player_index())) {
			if (!func_156(player::get_player_index(), 0, 0, 0, 0) && !func_155(player::get_player_index()) &&
				!network::is_player_in_cutscene(player::get_player_index()) &&
				Local_388[network::participant_id_to_int() /*5*/].f_4 < 6) {
				if (func_118(&Local_388[network::participant_id_to_int() /*5*/], 6)) {
					if (gameplay::get_game_timer() % 3000 > 50) {
					}
				}
			}
		}
		switch (Local_388[network::participant_id_to_int() /*5*/].f_2) {
		case 0:
			if (func_117() == 1) {
				Local_388[network::participant_id_to_int() /*5*/].f_2 = 1;
			}
			else if (func_117() == 4) {
				Local_388[network::participant_id_to_int() /*5*/].f_2 = 3;
			}
			break;

		case 1:
			if (func_117() == 1) {
				func_25(&Local_240, &uLocal_255, &uLocal_106);
			}
			else if (func_117() == 4) {
				Local_388[network::participant_id_to_int() /*5*/].f_2 = 3;
			}
			break;

		case 3:
			if (func_24(&Local_262.f_8)) {
				Local_388[network::participant_id_to_int() /*5*/].f_2 = 4;
			}
			break;

		case 2: Local_388[network::participant_id_to_int() /*5*/].f_2 = 4;

		case 4: func_150(); break;
		}
		if (network::network_is_host_of_this_script()) {
			switch (func_117()) {
			case 0: Local_262.f_4 = 1; break;

			case 1:
				func_2();
				if (func_1()) {
					Local_262.f_4 = 4;
				}
				break;

			case 4: break;
			}
		}
	}
}

// Position - 0x3BE
bool func_1() { return false; }

// Position - 0x3C7
void func_2() {
	func_3();
	switch (Local_262.f_7) {
	case 0: break;

	case 4: break;

	case 6: break;
	}
}

// Position - 0x3F8
void func_3() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	var uVar13;
	int iVar14;
	int iVar15;
	int iVar16;

	iVar0 = -1;
	iVar1 = -1;
	iVar2 = 0;
	iVar2 = 0;
	while (iVar2 < script::get_number_of_events(1)) {
		switch (script::get_event_at_index(1, iVar2)) {
		case 171:
			Local_123 = 2;
			if (func_23(iVar2, &Local_123, 1)) {
				switch (Local_123) {
				case 569:
					iVar0 = Local_123.f_3;
					iVar1 = Local_123.f_4;
					break;

				case 573:
					if (func_22(Local_123.f_2, 1)) {
						if (iLocal_385[Local_123.f_3] <= Local_342[Local_123.f_3 /*21*/].f_11) {
							func_21(Local_123.f_4, Local_123.f_3, 1);
						}
						else {
							func_21(Local_123.f_4, Local_123.f_3, 0);
						}
					}
					break;
				}
			}
			break;
		}
		iVar2++;
	}
	iVar4 = 0;
	iVar4 = 0;
	while (iVar4 < 2) {
		iLocal_385[iVar4] = func_20(&Local_388, iVar4);
		iVar6 = 0;
		iVar7 = 0;
		iVar3 = 0;
		while (iVar3 < network::_network_get_num_participants_host()) {
			iVar5 = player::int_to_participantindex(iVar3);
			if (network::network_is_participant_active(iVar5)) {
				if (func_19(&Local_388[iVar3 /*5*/], 1) && func_19(&Local_388[iVar3 /*5*/], 7) &&
					Local_388[iVar3 /*5*/].f_1 == iVar4) {
					iVar7 = 1;
				}
				if (iLocal_385[iVar4] > Local_342[iVar4 /*21*/].f_11) {
					if (!iVar6) {
						if (Local_388[iVar3 /*5*/].f_1 == iVar4 && func_19(&Local_388[iVar3 /*5*/], 1)) {
							func_18(575, network::network_get_player_index(iVar5), iVar4);
							iVar6 = 1;
						}
					}
				}
			}
			iVar3++;
		}
		func_17(&Local_262.f_3, iVar4, iVar7);
		func_17(&Local_262.f_1, iVar4, iLocal_385[iVar4] < Local_342[iVar4 /*21*/].f_11);
		func_17(&Local_262.f_2, iVar4, iLocal_385[iVar4] >= Local_342[iVar4 /*21*/].f_10);
		if (iLocal_385[iVar4] > 0) {
			if (!func_164(&iLocal_339)) {
				func_16(&iLocal_339, 1f);
			}
			else if (func_14(&iLocal_339) >= 1f) {
				func_11(&iLocal_339);
				iVar8 = -1;
				iVar9 = 0;
				iVar3 = 0;
				while (iVar3 < network::_network_get_num_participants_host()) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar3))) {
						if (Local_388[iVar3 /*5*/].f_1 == iVar4 && func_19(&Local_388[iVar3 /*5*/], 1)) {
							iVar8 = iVar3;
							if (func_19(&Local_388[iVar3 /*5*/], 0)) {
								iVar9 = 1;
							}
						}
						else {
							switch (iVar4) {
							case 0:
								if (gameplay::is_bit_set(Local_262.f_5, iVar3)) {
									gameplay::clear_bit(&Local_262.f_5, iVar3);
								}
								break;

							case 1:
								if (gameplay::is_bit_set(Local_262.f_6, iVar3)) {
									gameplay::clear_bit(&Local_262.f_6, iVar3);
								}
								break;
							}
						}
					}
					iVar3++;
				}
				if (!iVar9) {
					if (!func_10(iVar4, &Local_262, iVar8)) {
					}
				}
			}
		}
		if (iVar4 == iVar0) {
			if (iLocal_385[iVar4] >= Local_342[iVar4 /*21*/].f_10) {
				func_9(&Local_129, iLocal_332, iVar4);
				iVar10 = func_7(&Local_388, Local_129, iVar4);
				iVar11 = 0;
				iVar12 = Local_342[iVar4 /*21*/].f_11;
				uVar13 = gameplay::get_random_int_in_range(0, 65535);
				iVar3 = 0;
				while (iVar3 < network::_network_get_num_participants_host()) {
					if (network::network_is_participant_active(player::int_to_participantindex(iVar3))) {
						iVar14 = network::network_get_player_index(player::int_to_participantindex(iVar3));
						if (func_19(&Local_388[iVar3 /*5*/], 1) && Local_388[iVar3 /*5*/].f_1 == iVar4) {
							if (iVar11 <= iVar12) {
								iVar15 = 0;
								if (iVar14 == iVar1) {
									iVar15 = 1;
									if (iVar10 == -1) {
										iVar10 = iVar14;
									}
								}
								iVar16 = 0;
								if (iVar10 == iVar14) {
									iVar16 = 1;
								}
								func_4(uVar13, iVar14, iVar4, 0, iVar15, iVar16);
								iVar11++;
							}
						}
					}
					iVar3++;
				}
			}
		}
		iVar4++;
	}
}

// Position - 0x794
void func_4(var uParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	struct<6> Var0;

	Var0 = 570;
	func_6(&Var0.f_2, 4, iParam3);
	func_6(&Var0.f_2, 2, iParam4);
	func_6(&Var0.f_2, 5, iParam5);
	Var0.f_4 = iParam1;
	Var0.f_3 = iParam2;
	Var0.f_5 = uParam0;
	script::trigger_script_event(1, &Var0, 6, func_5(iParam1));
}

// Position - 0x7E2
var func_5(int iParam0) {
	var uVar0;

	gameplay::set_bit(&uVar0, iParam0);
	return uVar0;
}

// Position - 0x7F4
void func_6(int *iParam0, int iParam1, int iParam2) {
	bool bVar0;

	bVar0 = gameplay::is_bit_set(*iParam0, iParam1);
	if (iParam2) {
		if (!bVar0) {
			gameplay::set_bit(iParam0, iParam1);
		}
	}
	else if (bVar0) {
		gameplay::clear_bit(iParam0, iParam1);
	}
}

// Position - 0x82A
int func_7(var *uParam0, struct<13>[] Param1, var uParam2, var uParam3, var uParam4, var uParam5, var uParam6,
		   var uParam7, var uParam8, var uParam9, var uParam10, var uParam11, var uParam12, var uParam13, var uParam14,
		   var uParam15, var uParam16, var uParam17, var uParam18, var uParam19, var uParam20, var uParam21,
		   var uParam22, var uParam23, var uParam24, var uParam25, var uParam26, var uParam27, var uParam28,
		   var uParam29, var uParam30, var uParam31, var uParam32, var uParam33, var uParam34, var uParam35,
		   var uParam36, var uParam37, var uParam38, var uParam39, var uParam40, var uParam41, var uParam42,
		   var uParam43, var uParam44, var uParam45, var uParam46, var uParam47, var uParam48, var uParam49,
		   var uParam50, var uParam51, var uParam52, var uParam53, var uParam54, var uParam55, var uParam56,
		   var uParam57, var uParam58, var uParam59, var uParam60, int iParam61) {
	int iVar0;
	float fVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	float fVar6;

	iVar0 = -1;
	fVar1 = 0f;
	iVar4 = 0;
	while (iVar4 < network::_network_get_num_participants_host()) {
		iVar5 = player::int_to_participantindex(iVar4);
		if (network::network_is_participant_active(iVar5)) {
			iVar2 = network::network_get_player_index(player::int_to_participantindex(iVar4));
			if (*uParam0)
				[iVar4 /*5*/].f_1 == iParam61 &&func_19(&(*uParam0)[iVar4 /*5*/], 1) {
					iVar3 = player::get_player_ped(iVar2);
					if (func_8(iVar3)) {
						if (func_8(iVar3)) {
							if (iVar0 == -1) {
								iVar0 = iVar4;
								fVar1 = gameplay::get_distance_between_coords(entity::get_entity_coords(iVar3, 1),
																			  Param1[0 /*13*/], 1);
							}
							else {
								fVar6 = gameplay::get_distance_between_coords(entity::get_entity_coords(iVar3, 1),
																			  Param1[0 /*13*/], 1);
								if (fVar6 < fVar1) {
									fVar1 = fVar6;
									iVar0 = iVar4;
								}
							}
						}
					}
				}
		}
		iVar4++;
	}
	if (iVar0 >= 0) {
		iVar2 = network::network_get_player_index(player::int_to_participantindex(iVar0));
	}
	return iVar2;
}

// Position - 0x900
bool func_8(int iParam0) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_dead(iParam0, 0)) {
			return true;
		}
	}
	return false;
}

// Position - 0x921
void func_9(var *uParam0, int iParam1, int iParam2) {
	switch (iParam1) {
	case 0:
		switch (iParam2) {
		case 0:
			uParam0->f_59 = 1;
			uParam0->f_53 = {1119.064f, -3156.995f, -36.56f};
			uParam0->f_56 = {0.8f, 0.8f, 0.8f};
			(*uParam0)[0 /*13*/] = {1117.34f, -3156.68f, -37.0669f};
			(*uParam0)[0 /*13*/].f_4 = {1119.88f, -3157.026f, -36.3397f};
			(*uParam0)[0 /*13*/].f_7 = {1f, 1f, 1f};
			(*uParam0)[0 /*13*/].f_10 = "";
			(*uParam0)[0 /*13*/].f_11 = "darts_ig_idle_guy1";
			(*uParam0)[0 /*13*/].f_12 = "";
			(*uParam0)[1 /*13*/] = {1117.34f, -3157.38f, -38.0669f};
			(*uParam0)[1 /*13*/].f_4 = {1119.88f, -3157.026f, -36.3397f};
			(*uParam0)[1 /*13*/].f_4 = {1f, 1f, 1f};
			(*uParam0)[1 /*13*/].f_10 = "";
			(*uParam0)[1 /*13*/].f_11 = "darts_ig_idle_guy1";
			(*uParam0)[1 /*13*/].f_12 = "";
			break;

		case 1:
			uParam0->f_59 = 2;
			uParam0->f_53 = {1116.5f, -3153.27f, -36.56f};
			uParam0->f_56 = {1.2f, 1.2f, 1.2f};
			(*uParam0)[0 /*13*/] = {1115.92f, -3153.15f, -37.036f};
			(*uParam0)[0 /*13*/].f_4 = {1116.51f, -3153.28f, -37.569f};
			(*uParam0)[0 /*13*/].f_7 = {0.5f, 0.5f, 1f};
			(*uParam0)[0 /*13*/].f_10 = "";
			(*uParam0)[0 /*13*/].f_11 = "base";
			(*uParam0)[0 /*13*/].f_12 = "";
			(*uParam0)[1 /*13*/] = {1117.11f, -3153.4f, -37.036f};
			(*uParam0)[1 /*13*/].f_4 = {1116.51f, -3153.28f, -37.569f};
			(*uParam0)[1 /*13*/].f_7 = {0.5f, 0.5f, 1f};
			(*uParam0)[1 /*13*/].f_10 = "";
			(*uParam0)[1 /*13*/].f_11 = "base";
			(*uParam0)[1 /*13*/].f_12 = "";
			break;
		}
		break;

	case 1:
		switch (iParam2) {
		case 0:
			uParam0->f_59 = 1;
			uParam0->f_53 = {1000.851f, -3163.978f, -34.0646f};
			uParam0->f_56 = {0.8f, 0.8f, 0.8f};
			(*uParam0)[0 /*13*/] = {1000.59f, -3165.35f, -35.054f};
			(*uParam0)[0 /*13*/].f_4 = {1000.93f, -3162.82f, -33.4827f};
			(*uParam0)[0 /*13*/].f_7 = {1f, 1f, 1f};
			(*uParam0)[0 /*13*/].f_10 = "";
			(*uParam0)[0 /*13*/].f_11 = "darts_ig_idle_guy1";
			(*uParam0)[0 /*13*/].f_12 = "";
			(*uParam0)[1 /*13*/] = {1001.28f, -3165.35f, -35.054f};
			(*uParam0)[1 /*13*/].f_4 = {1000.93f, -3162.82f, -33.4827f};
			(*uParam0)[1 /*13*/].f_10 = "";
			(*uParam0)[1 /*13*/].f_11 = "darts_ig_idle_guy1";
			(*uParam0)[1 /*13*/].f_12 = "";
			break;

		case 1:
			uParam0->f_59 = 2;
			uParam0->f_53 = {1003.23f, -3165.73f, -34.0646f};
			uParam0->f_56 = {1.2f, 1.2f, 1.2f};
			(*uParam0)[0 /*13*/] = {1003.35f, -3165.14f, -34.0646f};
			(*uParam0)[0 /*13*/].f_4 = {1003.23f, -3165.74f, -34.5976f};
			(*uParam0)[0 /*13*/].f_7 = {0.5f, 0.5f, 1f};
			(*uParam0)[0 /*13*/].f_10 = "";
			(*uParam0)[0 /*13*/].f_11 = "base";
			(*uParam0)[0 /*13*/].f_12 = "";
			(*uParam0)[1 /*13*/] = {1003.11f, -3166.33f, -34.0646f};
			(*uParam0)[1 /*13*/].f_4 = {1003.23f, -3165.74f, -34.5976f};
			(*uParam0)[1 /*13*/].f_7 = {0.5f, 0.5f, 1f};
			(*uParam0)[1 /*13*/].f_10 = "";
			(*uParam0)[1 /*13*/].f_11 = "base";
			(*uParam0)[1 /*13*/].f_12 = "";
			break;
		}
		break;
	}
}

// Position - 0xCF0
int func_10(int iParam0, var *uParam1, int iParam2) {
	switch (iParam0) {
	case 0:
		if (func_17(&uParam1->f_5, iParam2, 1)) {
			return 1;
		}
		break;

	case 1:
		if (func_17(&uParam1->f_6, iParam2, 1)) {
			return 1;
		}
		break;
	}
	return 0;
}

// Position - 0xD36
void func_11(int *iParam0) { func_12(iParam0, 0f); }

// Position - 0xD45
void func_12(int *iParam0, float fParam1) {
	uParam0->f_1 = func_13(gameplay::is_bit_set(*uParam0, 4)) - fParam1;
	gameplay::set_bit(uParam0, 1);
	gameplay::clear_bit(iParam0, 2);
	iParam0->f_2 = 0f;
}

// Position - 0xD73
float func_13(bool bParam0) {
	float fVar0;
	float fVar1;
	int iVar2;
	float fVar3;
	float fVar4;

	if (bParam0) {
		fVar0 = system::to_float(gameplay::get_game_timer());
		fVar1 = fVar0 / 1000f;
		return fVar1;
	}
	if (network::network_is_game_in_progress()) {
		iVar2 = network::get_network_time();
		fVar3 = system::to_float(iVar2);
		fVar4 = fVar3 / 1000f;
		return fVar4;
	}
	return system::to_float(gameplay::get_game_timer()) / 1000f;
}

// Position - 0xDCB
float func_14(int *iParam0) {
	if (func_164(iParam0)) {
		if (func_15(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_13(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return iParam0->f_1;
}

// Position - 0xE0A
bool func_15(var *uParam0) { return gameplay::is_bit_set(*uParam0, 2); }

// Position - 0xE1A
void func_16(int *iParam0, float fParam1) {
	if (!func_164(iParam0)) {
		func_12(iParam0, fParam1);
	}
}

// Position - 0xE34
bool func_17(int *iParam0, int iParam1, int iParam2) {
	bool bVar0;

	bVar0 = gameplay::is_bit_set(*iParam0, iParam1);
	if (iParam2) {
		if (!bVar0) {
			gameplay::set_bit(iParam0, iParam1);
			return true;
		}
	}
	else if (bVar0) {
		gameplay::clear_bit(iParam0, iParam1);
		return true;
	}
	return false;
}

// Position - 0xE73
void func_18(int iParam0, int iParam1, int iParam2) {
	struct<5> Var0;

	Var0 = iParam0;
	Var0.f_4 = iParam1;
	Var0.f_3 = iParam2;
	script::trigger_script_event(1, &Var0, 6, func_5(iParam1));
}

// Position - 0xE99
bool func_19(var *uParam0, int iParam1) { return gameplay::is_bit_set(uParam0->f_3, iParam1); }

// Position - 0xEAB
int func_20(var *uParam0, int iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = 0;
	iVar1 = 0;
	iVar1 = 0;
	while (iVar1 < network::_network_get_num_participants_host()) {
		iVar2 = player::int_to_participantindex(iVar1);
		if (network::network_is_participant_active(iVar2)) {
			iVar3 = network::network_get_player_index(iVar2);
			if (network::network_is_player_active(iVar3)) {
				if (iParam1 >= 0 && iParam1 <= 1) {
					if (iParam1 == (*uParam0)[iVar1 /*5*/].f_1) {
						if (func_19(&(*uParam0)[iVar1 /*5*/], 1)) {
							iVar0++;
						}
					}
				}
			}
		}
		iVar1++;
	}
	return iVar0;
}

// Position - 0xF23
void func_21(int iParam0, var uParam1, int iParam2) {
	struct<5> Var0;

	Var0 = 574;
	func_6(&Var0.f_2, 0, iParam2);
	func_6(&Var0.f_2, 3, 0);
	Var0.f_4 = iParam0;
	Var0.f_3 = uParam1;
	script::trigger_script_event(1, &Var0, 6, func_5(iParam0));
}

// Position - 0xF5F
bool func_22(int iParam0, int iParam1) { return gameplay::is_bit_set(iParam0, iParam1); }

// Position - 0xF6F
bool func_23(int iParam0, int iParam1, int iParam2) {
	if (script::get_event_data(1, iParam0, iParam1, 6)) {
		if (func_22(iParam1->f_2, 3) == iParam2) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0xF9E
bool func_24(var *uParam0) {
	if (uParam0->f_1) {
		if (gameplay::absi(network::get_time_difference(network::get_network_time(), *uParam0)) >= 1000) {
			return true;
		}
	}
	return false;
}

// Position - 0xFC7
void func_25(var *uParam0, var *uParam1, var *uParam2) {
	if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
		if (func_116(player::get_player_index())) {
			func_118(&Local_388[network::participant_id_to_int() /*5*/], 5);
		}
	}
	func_115(&Local_388, &Local_233, uParam2, &Local_342);
	func_112(uParam2);
	switch (Local_388[network::participant_id_to_int() /*5*/].f_4) {
	case 0:
		if (!gameplay::is_bit_set(Local_388[network::participant_id_to_int() /*5*/].f_3, 2)) {
			func_44(uParam1, uParam0, &Local_233);
		}
		if (func_43(&Local_388[network::participant_id_to_int() /*5*/].f_3, 8)) {
			if (!func_164(&iLocal_204)) {
				func_163(&iLocal_204);
			}
			else if (func_14(&iLocal_204) >= 4f) {
				func_42(&Local_388[network::participant_id_to_int() /*5*/], 8, 0);
				func_42(&Local_388[network::participant_id_to_int() /*5*/], 2, 0);
				func_42(&Local_388[network::participant_id_to_int() /*5*/], 7, 0);
				func_41(&Local_388[network::participant_id_to_int() /*5*/], -1);
				func_40(&Local_388[network::participant_id_to_int() /*5*/]);
				func_118(&Local_388[network::participant_id_to_int() /*5*/], 0);
				func_39(&Local_233, 0);
				func_36(&iLocal_216);
				func_11(&iLocal_189);
				func_154(&iLocal_204);
			}
		}
		break;

	case 1:
		if (Local_388[network::participant_id_to_int() /*5*/].f_1 >= 0) {
			if (!gameplay::is_string_null_or_empty(Local_233.f_3)) {
				if (script::has_script_loaded(Local_233.f_3)) {
					func_118(&Local_388[network::participant_id_to_int() /*5*/], 2);
				}
				else if (script::does_script_exist(Local_233.f_3)) {
					script::request_script(Local_233.f_3);
				}
			}
		}
		else {
			if (func_164(&iLocal_204)) {
				func_154(&iLocal_204);
			}
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 8, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 2, 0);
			func_118(&Local_388[network::participant_id_to_int() /*5*/], 0);
		}
		break;

	case 2:
		if (!func_164(&iLocal_195)) {
			func_163(&iLocal_195);
		}
		if (func_164(&iLocal_204)) {
			func_154(&iLocal_204);
		}
		func_42(&Local_388[network::participant_id_to_int() /*5*/], 8, 0);
		func_42(&Local_388[network::participant_id_to_int() /*5*/], 7, 1);
		iLocal_105 = 1;
		if (!func_19(&Local_388[network::participant_id_to_int() /*5*/], 0) &&
			!network::network_is_script_active(Local_233.f_3, Local_233.f_6, 0, 0)) {
			iLocal_105 = 0;
			if (func_14(&iLocal_195) >= 30f) {
				func_118(&Local_388[network::participant_id_to_int() /*5*/], 4);
			}
		}
		if (iLocal_105) {
			if (Local_388[network::participant_id_to_int() /*5*/].f_1 == 0) {
			}
			if (func_33(Local_233.f_3, 8344, Local_233.f_6, 0,
						func_19(&Local_388[network::participant_id_to_int() /*5*/], 0),
						func_19(&Local_388[network::participant_id_to_int() /*5*/], 5))) {
				func_154(&iLocal_189);
				func_154(&iLocal_201);
				iLocal_104 = 0;
				func_42(&Local_388[network::participant_id_to_int() /*5*/], 3, 0);
				func_42(&Local_388[network::participant_id_to_int() /*5*/], 6, 0);
				func_17(&iLocal_216, 2, 0);
				iLocal_105 = 0;
				func_118(&Local_388[network::participant_id_to_int() /*5*/], 3);
			}
		}
		break;

	case 3:
		if (!func_164(&iLocal_201)) {
			func_163(&iLocal_201);
			iLocal_104 = 0;
		}
		else if (func_14(&iLocal_201) >= 30f) {
			iLocal_104 = 1;
		}
		if (!gameplay::is_string_null_or_empty(Local_233.f_3)) {
			if (network::network_is_script_active(Local_233.f_3, Local_233.f_6, 1, 0)) {
				iLocal_104 = 1;
			}
		}
		else if (gameplay::get_game_timer() % 1000 > 100) {
		}
		if (iLocal_104) {
			iLocal_104 = 0;
			func_154(&iLocal_201);
			func_118(&Local_388[network::participant_id_to_int() /*5*/], 4);
		}
		break;

	case 4:
		if (!network::network_is_script_active(Local_233.f_3, Local_233.f_6, 1, 0) ||
			script::_get_number_of_instances_of_script_with_name_hash(-1424690702) == 0 && Local_233.f_2 == 0 ||
			script::_get_number_of_instances_of_script_with_name_hash(1774039768) == 0 && Local_233.f_2 == 1) {
			func_36(&iLocal_216);
			func_40(&Local_388[network::participant_id_to_int() /*5*/]);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 7, 0);
			func_41(&Local_388[network::participant_id_to_int() /*5*/], -1);
			func_11(&iLocal_189);
			func_39(&Local_233, 0);
			func_118(&Local_388[network::participant_id_to_int() /*5*/], 0);
		}
		break;

	case 5:
		if (!iLocal_99) {
			iLocal_99 = 1;
			ui::clear_help(1);
			func_32(0);
		}
		break;

	case 6: func_150(); break;
	}
	func_141(&Local_233.f_5);
	func_26(&iLocal_216);
}

// Position - 0x13FA
void func_26(int *iParam0) {
	int iVar0;

	if (gameplay::is_bit_set(*iParam0, 2)) {
		ui::disable_frontend_this_frame();
	}
	if (func_43(iParam0, 0)) {
		cam::_0xF4F2C0D4EE209E20();
	}
	iVar0 = gameplay::is_bit_set(*iParam0, 3);
	if (iVar0 != gameplay::is_bit_set(*iParam0, 4)) {
		if (func_8(player::player_ped_id())) {
			ped::set_ped_config_flag(player::player_ped_id(), 185, iVar0);
			ped::set_ped_config_flag(player::player_ped_id(), 108, iVar0);
		}
		func_17(iParam0, 4, iVar0);
	}
	if (gameplay::is_bit_set(*iParam0, 1)) {
		func_27();
	}
	if (gameplay::is_bit_set(*iParam0, 5)) {
		controls::disable_control_action(0, 30, 1);
		controls::disable_control_action(0, 31, 1);
	}
	else {
		controls::enable_control_action(0, 30, 1);
		controls::enable_control_action(0, 31, 1);
	}
	if (gameplay::is_bit_set(*iParam0, 7) != gameplay::is_bit_set(*iParam0, 8)) {
		if (gameplay::is_bit_set(*iParam0, 7)) {
			controls::disable_control_action(0, 37, 1);
			controls::disable_control_action(0, 12, 1);
			controls::disable_control_action(0, 13, 1);
		}
		else {
			controls::enable_control_action(0, 37, 1);
			controls::enable_control_action(0, 12, 1);
			controls::enable_control_action(0, 13, 1);
		}
		func_17(iParam0, 8, gameplay::is_bit_set(*iParam0, 7));
	}
	if (gameplay::is_bit_set(*iParam0, 9)) {
		ui::hide_hud_component_this_frame(5);
		ui::hide_hud_component_this_frame(18);
		ui::hide_hud_component_this_frame(10);
	}
}

// Position - 0x1520
void func_27() {
	if (Global_14443.f_1 != 1) {
		if (func_31(0)) {
			func_28(0);
		}
		gameplay::set_bit(&G_SleepModeOffOn11, 2);
	}
}

// Position - 0x1548
void func_28(int iParam0) {
	if (Global_14604) {
		func_30(0, 0);
	}
	if (Global_14443.f_1 == 10 || Global_14443.f_1 == 9) {
		gameplay::set_bit(&G_SleepModeOffOn11, 16);
	}
	if (audio::is_mobile_phone_call_ongoing()) {
		audio::stop_scripted_conversation(0);
	}
	Global_15745 = 5;
	if (iParam0 == 1) {
		gameplay::set_bit(&G_SleepModeOnOn25, 30);
	}
	else {
		gameplay::clear_bit(&G_SleepModeOnOn25, 30);
	}
	if (!func_29()) {
		Global_14443.f_1 = 3;
	}
}

// Position - 0x15B8
int func_29() {
	if (Global_14443.f_1 == 1 || Global_14443.f_1 == 0) {
		return 1;
	}
	return 0;
}

// Position - 0x15DF
void func_30(int iParam0, int iParam1) {
	if (iParam0) {
		if (func_31(0)) {
			Global_14604 = 1;
			if (iParam1) {
				mobile::get_mobile_phone_position(&Global_14380);
			}
			Global_14371 = {Global_14389[Global_14388 /*3*/]};
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
	else if (Global_14604 == 1) {
		Global_14604 = 0;
		Global_14371 = {Global_14396[Global_14388 /*3*/]};
		if (iParam1) {
			mobile::set_mobile_phone_position(Global_14380);
		}
		else {
			mobile::set_mobile_phone_position(Global_14371);
		}
	}
}

// Position - 0x1653
bool func_31(int iParam0) {
	if (iParam0 == 1) {
		if (Global_14443.f_1 > 3) {
			if (gameplay::is_bit_set(G_SleepModeOnOn25, 14)) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	}
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	if (Global_14443.f_1 > 3) {
		return true;
	}
	return false;
}

// Position - 0x16AD
void func_32(int iParam0) {
	int iVar0;
	int iVar1;
	float fVar2;

	iVar0 = 0;
	while (iVar0 < 256) {
		StringCopy(&Global_17290.f_73[iVar0 /*6*/], "", 24);
		iVar1 = 0;
		while (iVar1 < 4) {
			Global_17290.f_2124[iVar0 /*5*/][iVar1] = 0;
			iVar1++;
		}
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 32) {
		StringCopy(&Global_2453058[iVar0 /*16*/], "", 64);
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 256) {
		Global_17290.f_3918[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4175[iVar0] = 0f;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4433[iVar0] = 0;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 128) {
		Global_17290.f_4959[iVar0] = 0;
		Global_17290.f_5097[iVar0] = 0;
		Global_17290.f_5226[iVar0] = 0;
		Global_17290.f_5746[iVar0] = 0f;
		Global_17290.f_5355[iVar0] = 0;
		Global_17290.f_5612[iVar0] = 0f;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 5) {
		Global_17290.f_4926[iVar0] = 0;
		Global_17290.f_4938[iVar0] = 0f;
		Global_17290.f_4932[iVar0] = -1f;
		Global_17290.f_4945[iVar0] = 0;
		Global_17290.f_4953[iVar0] = 1;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 12) {
		StringCopy(&Global_17290.f_4834[iVar0 /*4*/], "", 16);
		Global_17290.f_4883[iVar0] = -1;
		Global_17290.f_4896[iVar0] = 353;
		Global_17290.f_4909[iVar0] = 32;
		iVar0++;
	}
	iVar0 = 0;
	while (iVar0 < 51) {
		StringCopy(&Global_17290.f_5886[iVar0 /*16*/], "", 64);
		StringCopy(&Global_17290.f_6703[iVar0 /*16*/], "", 64);
		iVar0++;
	}
	StringCopy(&Global_2593974.f_16, "", 16);
	Global_2593974.f_20 = -1;
	Global_17290 = 0;
	Global_17290.f_5088 = 0;
	Global_17290.f_5089 = 0;
	Global_17290.f_5090 = 0;
	Global_17290.f_5092 = 0;
	Global_17290.f_5093 = 0;
	Global_17290.f_5094 = 0;
	Global_17290.f_5091 = 0;
	Global_17290.f_5741 = 0;
	Global_17290.f_5606 = 0;
	Global_17290.f_5605 = 0;
	Global_17290.f_5607 = 0;
	StringCopy(&Global_17290.f_4562, "", 16);
	Global_17290.f_4632 = 0;
	Global_17290.f_4633 = 0;
	Global_17290.f_4634 = 0;
	Global_17290.f_4635 = 0;
	Global_17290.f_4636 = 0;
	Global_17290.f_4637 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_4566[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_4638 = 0;
	StringCopy(&Global_2593974.f_21, "", 16);
	Global_2593974.f_61 = 0;
	Global_2593974.f_62 = 0;
	Global_2593974.f_63 = 0;
	Global_2593974.f_64 = 0;
	Global_2593974.f_65 = 0;
	Global_2593974.f_66 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_2593974.f_25[iVar0] = 0;
		iVar0++;
	}
	Global_2593974.f_67 = 0;
	StringCopy(&Global_17290.f_1, "", 16);
	Global_17290.f_4944 = 0f;
	Global_17290.f_68 = 0;
	Global_17290.f_69 = 0;
	Global_17290.f_70 = 0;
	Global_17290.f_71 = 0;
	Global_17290.f_72 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_5[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_5611 = 0;
	Global_17290.f_5610 = 0;
	Global_17290.f_5608 = 0;
	Global_17290.f_5609 = 0;
	Global_17290.f_4639 = 0;
	Global_17290.f_4640 = 0;
	Global_17290.f_5095 = 10;
	Global_17290.f_5096 = 0;
	Global_17290.f_5743 = 0f;
	Global_17290.f_5744 = 0f;
	Global_17290.f_5598 = 0;
	Global_17290.f_5599 = 0;
	Global_17290.f_5600 = 0f;
	Global_17290.f_5601 = 0;
	Global_17290.f_5603 = 0;
	Global_17290.f_5602 = 0;
	Global_17290.f_5604 = 0;
	Global_17290.f_7895 = 0;
	iVar0 = 0;
	while (iVar0 < 2) {
		Global_17290.f_5875[iVar0] = -1;
		Global_17290.f_5878[iVar0] = -1;
		iVar0++;
	}
	Global_17290.f_4951 = 0f;
	Global_17290.f_4922 = 0;
	Global_17290.f_4952 = 0;
	iVar0 = 0;
	while (iVar0 < Global_17290.f_5881) {
		Global_17290.f_5881[iVar0] = 0;
		iVar0++;
	}
	Global_17290.f_7874 = 0;
	Global_17290.f_7869 = 0;
	Global_17290.f_7879 = 0;
	Global_17290.f_7884 = 0;
	Global_17290.f_7889 = 0;
	Global_17290.f_7891 = 0;
	Global_17290.f_7897 = 0;
	Global_17287 = 0.05f;
	Global_17288 = 0.05f;
	Global_17289 = 0.225f;
	fVar2 = graphics::_get_aspect_ratio(0);
	if (iParam0) {
		Global_17289 = 0.225f * 16f / 9f / fVar2;
	}
	else if (fVar2 < 1.77777f) {
		Global_17289 = 0.225f * 16f / 9f / fVar2;
	}
	else {
		Global_17289 = 0.225f;
	}
}

// Position - 0x1B59
bool func_33(char *sParam0, int iParam1, var uParam2, int iParam3, bool bParam4, bool bParam5) {
	struct<20> Var0;

	Var0.f_1 = -1;
	Var0.f_2 = -1;
	Var0.f_9 = -1;
	Var0.f_16 = -1;
	Var0.f_19 = -1;
	if (iParam3) {
		gameplay::set_bit(&Var0.f_18, 1);
	}
	if (bParam4) {
		gameplay::set_bit(&Var0.f_18, 2);
	}
	if (bParam5) {
		gameplay::set_bit(&Var0.f_18, 3);
	}
	else {
		gameplay::clear_bit(&Var0.f_18, 3);
	}
	Var0.f_16 = uParam2;
	if (!network::network_is_script_active(sParam0, Var0.f_16, 1, 0)) {
		Global_1591201[player::get_player_index() /*602*/] = -1;
		if (func_34(sParam0, iParam1, Var0, 0, 0, 1, 1, 1)) {
			return true;
		}
	}
	return false;
}

// Position - 0x1BFF
bool func_34(char *sParam0, int iParam1, struct<17> Param2, var uParam19, var uParam20, var uParam21, int iParam22,
			 int iParam23, int iParam24, int iParam25, int iParam26) {
	if (script::does_script_exist(sParam0)) {
		if (iParam23 && Param2.f_16 != -1) {
			gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 4);
			Global_1591201[player::player_id() /*602*/].f_1 = Param2.f_16;
			player::set_player_control(player::player_id(), 0, 256);
			if (iParam26) {
				ui::hide_hud_and_radar_this_frame();
			}
		}
		if (iParam22) {
			ui::set_frontend_active(0);
			if (!cam::is_screen_faded_out() && !cam::is_screen_fading_out()) {
				cam::do_screen_fade_out(1000);
			}
			if (!ped::is_ped_injured(player::player_ped_id())) {
				entity::set_entity_invincible(player::player_ped_id(), 1);
			}
		}
		script::request_script(sParam0);
		if (script::has_script_loaded(sParam0)) {
			if (iParam22) {
				if (!cam::is_screen_faded_out()) {
					return false;
				}
			}
			if (iParam1 <= 0) {
				iParam1 = 512;
			}
			system::start_new_script_with_args(sParam0, &Param2, 20, iParam1);
			script::set_script_as_no_longer_needed(sParam0);
			if (!iParam25) {
				gameplay::set_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 0);
			}
			gameplay::clear_bit(&Global_1591201[player::player_id() /*602*/].f_39.f_18, 4);
			if (iParam24) {
				if (player::get_player_wanted_level(player::player_id()) > 0) {
					func_35();
					player::clear_player_wanted_level(player::player_id());
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0x1D23
void func_35() {
	if (Global_2494199.f_3825 != 0) {
		Global_2494199.f_3825 = 5;
	}
}

// Position - 0x1D3E
void func_36(int *iParam0) {
	gameplay::clear_bit(iParam0, 2);
	gameplay::clear_bit(iParam0, 3);
	gameplay::set_bit(iParam0, 4);
	gameplay::clear_bit(iParam0, 1);
	gameplay::clear_bit(iParam0, 5);
	gameplay::clear_bit(iParam0, 7);
	gameplay::set_bit(iParam0, 8);
	gameplay::clear_bit(iParam0, 9);
	func_37(iParam0, 0);
	func_26(iParam0);
}

// Position - 0x1D8D
void func_37(int *iParam0, int iParam1) { func_38(iParam0, iParam1); }

// Position - 0x1D9D
void func_38(int *iParam0, var uParam1) { *iParam0 -= (*iParam0 & uParam1); }

// Position - 0x1DB2
void func_39(bool bParam0, int iParam1) { bParam0->f_4 = iParam1; }

// Position - 0x1DC0
void func_40(var *uParam0) {
	func_42(uParam0, 0, 0);
	func_42(uParam0, 1, 0);
	func_42(uParam0, 2, 0);
	func_42(uParam0, 5, 0);
}

// Position - 0x1DEC
int func_41(var *uParam0, int iParam1) {
	if (uParam0->f_1 != iParam1) {
		uParam0->f_1 = iParam1;
		return 1;
	}
	return 0;
}

// Position - 0x1E08
bool func_42(var *uParam0, int iParam1, int iParam2) {
	bool bVar0;

	bVar0 = func_19(uParam0, iParam1);
	if (iParam2) {
		if (!bVar0) {
			gameplay::set_bit(&uParam0->f_3, iParam1);
			return true;
		}
	}
	else if (bVar0) {
		gameplay::clear_bit(&uParam0->f_3, iParam1);
		return true;
	}
	return false;
}

// Position - 0x1E4A
bool func_43(var *uParam0, int iParam1) { return gameplay::is_bit_set(*uParam0, iParam1); }

// Position - 0x1E5B
void func_44(var *uParam0, var *uParam1, bool bParam2) {
	int iVar0;

	func_109(uParam1);
	if (entity::does_entity_exist(player::player_ped_id())) {
		if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
			if (Local_388[network::participant_id_to_int() /*5*/].f_1 == -1) {
				if (func_107(&iLocal_189)) {
					func_105(uParam0, uParam1);
				}
				iVar0 = 0;
				while (iVar0 <= 1) {
					if (Local_388[network::participant_id_to_int() /*5*/].f_1 == -1) {
						if (!gameplay::is_bit_set(bParam2->f_5, iVar0)) {
							func_45(Local_342[iVar0 /*21*/], uParam1->f_12);
						}
					}
					iVar0++;
				}
			}
			else if (!gameplay::is_bit_set(bParam2->f_5, Local_388[network::participant_id_to_int() /*5*/].f_1)) {
				func_45(Local_342[uParam1->f_10 /*21*/], uParam1->f_12);
			}
			else {
				func_39(bParam2, 8);
				func_45(Local_342[Local_388[network::participant_id_to_int() /*5*/].f_1 /*21*/], 1);
			}
		}
	}
	else if (gameplay::get_game_timer() % 1000 < 50) {
		if (func_164(&iLocal_189)) {
		}
	}
}

// Position - 0x1F4C
void func_45(struct<21> Param0, int iParam21) {
	int iVar0;
	int iVar1;
	int iVar2;
	bool bVar3;
	vector3 vVar4;
	float fVar7;
	float fVar8;
	int iVar9;

	func_104(&Local_207);
	if (!gameplay::is_bit_set(Local_388[network::participant_id_to_int() /*5*/].f_3, 2)) {
		if (entity::does_entity_exist(player::player_ped_id())) {
			if (gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1), Param0.f_3,
													  1) < 2f) {
				func_9(&Local_272, iLocal_332, Param0.f_2);
				Local_207.f_3 = 1;
				if (entity::is_entity_at_coord(player::player_ped_id(), Local_272.f_53, Local_272.f_56, 0, 1, 0)) {
					Local_207.f_2 = 1;
					if (Param0 == 1) {
						iVar0 = 0;
						while (iVar0 < Local_272.f_59) {
							if (entity::is_entity_at_coord(player::player_ped_id(), Local_272[iVar0 /*13*/],
														   Local_272[iVar0 /*13*/].f_7, 0, 1, 0)) {
								Local_207.f_4 = 1;
								Local_207.f_8 = iVar0;
							}
							iVar0++;
						}
						iVar1 = 0;
						while (iVar1 < network::_network_get_num_participants_host()) {
							iVar2 = player::int_to_participantindex(iVar1);
							if (iVar1 != network::participant_id_to_int()) {
								if (network::network_is_participant_active(iVar2)) {
									if (Local_388[iVar1 /*5*/].f_1 == Param0 &&
										gameplay::is_bit_set(Local_388[iVar1 /*5*/].f_3, 6) &&
										gameplay::is_bit_set(Local_388[iVar1 /*5*/].f_3, 1)) {
										Local_207.f_5 = 1;
										if (Local_207.f_8 >= 0) {
											if (Local_207.f_8 == 0 &&
												gameplay::is_bit_set(Local_388[iVar1 /*5*/].f_3, 5)) {
												Local_207.f_6 = 1;
											}
											else if (Local_207.f_8 == 1 &&
													 !gameplay::is_bit_set(Local_388[iVar1 /*5*/].f_3, 5)) {
												Local_207.f_6 = 1;
											}
										}
									}
								}
							}
							iVar1++;
						}
						if (Local_207.f_4) {
							if (!Local_207.f_6) {
								Local_207.f_7 = 1;
								if (Local_207.f_8 == 0) {
									func_42(&Local_388[network::participant_id_to_int() /*5*/], 5, 1);
								}
							}
							else {
								func_42(&Local_388[network::participant_id_to_int() /*5*/], 5, 0);
								func_42(&Local_388[network::participant_id_to_int() /*5*/], 6, 0);
							}
						}
						if (Local_233.f_4 == 0) {
							if (!Local_207.f_4 && Local_207.f_5 || Local_207.f_4 && Local_207.f_6)
								&&gameplay::is_bit_set(Local_262.f_1, Param0) { func_101("ARMW_A_SIDE", 1); }
							else {
								func_101("ARMW_A_SIDE", 0);
							}
						}
					}
					else {
						Local_207.f_7 = 1;
						Local_207.f_4 = 1;
					}
				}
				else if (Param0 == 1) {
					func_101("ARMW_A_SIDE", 0);
				}
			}
		}
	}
	if (iParam21) {
		switch (Local_233.f_4) {
		case 0:
			if (Local_207.f_4 && Local_207.f_7) {
				Local_207 = false;
				func_41(&Local_388[network::participant_id_to_int() /*5*/], Param0);
				if (gameplay::is_bit_set(Local_262.f_3, Param0)) {
					func_101(func_100(Param0, 6), 0);
					func_101(func_100(Param0, 7), 0);
					if (!func_19(&Local_388[iLocal_218 /*5*/], 1)) {
						func_101(func_100(Param0, 0), 1);
					}
				}
				else if (!gameplay::is_bit_set(Local_262.f_1, Param0)) {
					func_101(func_100(Param0, 6), 0);
					func_101(func_100(Param0, 7), 1);
				}
				else {
					func_101(func_100(Param0, 0), 0);
					if (controls::is_control_just_pressed(2, 51)) {
						func_99(player::get_player_index(), Param0, 1);
						func_42(&Local_388[network::participant_id_to_int() /*5*/], 1, 1);
						func_42(&Local_388[network::participant_id_to_int() /*5*/], 6, 1);
						func_17(&iLocal_216, 1, 1);
						func_17(&iLocal_216, 2, 1);
						func_17(&iLocal_216, 3, 0);
						func_17(&iLocal_216, 5, 1);
						func_17(&iLocal_216, 7, 1);
						Local_207 = true;
						if (!func_164(&iLocal_195)) {
							func_163(&iLocal_195);
						}
						else {
							func_11(&iLocal_195);
						}
						func_39(&Local_233, 1);
					}
					else {
						func_101(func_100(Param0, 7), 0);
						func_101(func_100(Param0, 6), 1);
					}
				}
			}
			if (!Local_207.f_4) {
				func_101(func_100(Param0, 6), 0);
				if (Local_388[network::participant_id_to_int() /*5*/].f_1 == Param0) {
					func_41(&Local_388[network::participant_id_to_int() /*5*/], -1);
					Local_207 = true;
				}
			}
			break;

		case 1:
			bVar3 = false;
			if (Local_233.f_1 == 1) {
				Local_233.f_1 = 0;
				bVar3 = true;
				if (Local_233) {
					if (Param0 == 0) {
						func_39(&Local_233, 6);
					}
					else {
						func_39(&Local_233, 2);
					}
				}
				else {
					func_39(&Local_233, 8);
				}
			}
			if (!func_164(&iLocal_195)) {
				func_163(&iLocal_195);
			}
			else if (func_14(&iLocal_195) >= 3f) {
				bVar3 = true;
				func_39(&Local_233, 8);
			}
			if (bVar3) {
				if (func_164(&iLocal_195)) {
					func_154(&iLocal_195);
				}
			}
			break;

		case 2:
			fVar7 = gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
														  Local_272[0 /*13*/], 1);
			fVar8 = gameplay::get_distance_between_coords(entity::get_entity_coords(player::player_ped_id(), 1),
														  Local_272[1 /*13*/], 1);
			if (fVar7 < fVar8) {
				vVar4 = {Local_272[0 /*13*/]};
			}
			else {
				vVar4 = {Local_272[1 /*13*/]};
			}
			iVar9 = func_98(vVar4, Local_272[0 /*13*/].f_4);
			if (!ped::is_ped_injured(player::player_ped_id())) {
				ai::task_go_straight_to_coord(player::player_ped_id(), vVar4, 1f, 300, iVar9, 0.05f);
			}
			func_39(&Local_233, 6);
			break;

		case 6:
			if (func_164(&iLocal_333)) {
				func_154(&iLocal_333);
			}
			if (!func_164(&iLocal_336)) {
				func_16(&iLocal_336, 1f);
			}
			else if (func_14(&iLocal_336) >= 1f || !func_19(&Local_388[network::participant_id_to_int() /*5*/], 3)) {
				func_11(&iLocal_336);
				if (func_97(Param0, &Local_262)) {
					if (func_42(&Local_388[network::participant_id_to_int() /*5*/], 0, 1)) {
						func_42(&Local_388[network::participant_id_to_int() /*5*/], 3, 1);
					}
				}
				else if (func_42(&Local_388[network::participant_id_to_int() /*5*/], 0, 0)) {
				}
			}
			if (!func_164(&iLocal_192)) {
				func_163(&iLocal_192);
			}
			else if (func_14(&iLocal_192) >= 1f) {
				if (!func_19(&Local_388[network::participant_id_to_int() /*5*/], 3)) {
					func_42(&Local_388[network::participant_id_to_int() /*5*/], 3, 1);
				}
			}
			if ((controls::is_control_just_pressed(2, func_96(0)) || gameplay::is_bit_set(Local_262.f_3, Param0)) &&
				!bLocal_102) {
				func_39(&Local_233, 8);
			}
			func_17(&iLocal_216, 0, 1);
			func_17(&iLocal_216, 1, 0);
			func_17(&iLocal_216, 2, 1);
			func_17(&iLocal_216, 3, 1);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 1, 1);
			if (func_19(&Local_388[network::participant_id_to_int() /*5*/], 3)) {
				if (func_19(&Local_388[network::participant_id_to_int() /*5*/], 0)) {
					if (controls::is_control_just_pressed(2, 201) && gameplay::is_bit_set(Local_262.f_2, Param0) &&
						!bLocal_102) {
						func_39(&Local_233, 7);
					}
					if (Param0.f_2 == 0) {
						Local_207.f_1 = 1;
						if (func_137(0, -1, 0)) {
							func_94();
							func_82(Param0);
							func_49(1, -1, 1, 0, 1, -1082130432, 0, 0);
						}
					}
					func_101(func_100(Param0, 5), 0);
					if (gameplay::is_bit_set(Local_262.f_2, Param0)) {
						if (Local_207.f_1) {
							func_101(func_100(Param0, 1), 0);
							func_101(func_100(Param0, 2), 0);
						}
						else if (gameplay::is_bit_set(Local_262.f_1, Param0)) {
							func_101(func_100(Param0, 1), 1);
						}
						else {
							func_101(func_100(Param0, 2), 1);
						}
					}
					else {
						func_101(func_100(Param0, 1), 0);
						func_101(func_100(Param0, 2), 0);
						if (!Local_207.f_1) {
							func_101(func_100(Param0, 5), 0);
							func_101(func_100(Param0, 4), 1);
						}
					}
				}
				else {
					if (gameplay::is_bit_set(Local_262.f_1, Local_388[network::participant_id_to_int() /*5*/].f_1)) {
						func_42(&Local_388[network::participant_id_to_int() /*5*/], 1, 1);
					}
					if (func_19(&Local_388[network::participant_id_to_int() /*5*/], 1)) {
						func_101(func_100(Param0, 5), 1);
					}
					else {
						func_101(func_100(Param0, 5), 0);
					}
				}
			}
			break;

		case 7:
			func_46(player::get_player_index(), Param0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 8, 1);
			func_17(&iLocal_216, 1, 1);
			func_17(&iLocal_216, 9, 1);
			func_17(&iLocal_216, 2, 1);
			func_11(&iLocal_189);
			func_154(&iLocal_192);
			func_154(&iLocal_336);
			func_39(&Local_233, 0);
			break;

		case 8:
			iLocal_103 = 0;
			Local_207 = true;
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 1, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 0, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 3, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 6, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 5, 0);
			func_42(&Local_388[network::participant_id_to_int() /*5*/], 7, 0);
			func_36(&iLocal_216);
			func_154(&iLocal_192);
			func_154(&iLocal_336);
			func_41(&Local_388[network::participant_id_to_int() /*5*/], -1);
			func_11(&iLocal_189);
			func_104(&Local_207);
			ui::clear_help(1);
			func_39(&Local_233, 0);
			break;
		}
	}
	if (!Local_207.f_4 && Local_233.f_4 == 0) {
		if (iLocal_103) {
			iLocal_103 = 0;
		}
		func_36(&iLocal_216);
	}
	if (!Local_207.f_4 && !Local_207.f_3) {
		func_42(&Local_388[network::participant_id_to_int() /*5*/], 5, 0);
		if (Local_233.f_4 > 0 && Local_233.f_4 != 8) {
			func_39(&Local_233, 8);
		}
	}
	if (Local_207) {
		func_101(func_100(Param0, 7), 0);
		func_101(func_100(Param0, 0), 0);
		func_101(func_100(Param0, 1), 0);
		func_101(func_100(Param0, 2), 0);
		func_101(func_100(Param0, 4), 0);
		func_101(func_100(Param0, 5), 0);
		func_101(func_100(Param0, 6), 0);
		func_101("ARMW_A_SIDE", 0);
	}
}

// Position - 0x28EE
void func_46(var uParam0, var uParam1) {
	struct<5> Var0;

	Var0 = 569;
	Var0.f_3 = uParam1;
	Var0.f_4 = uParam0;
	func_6(&Var0.f_2, 3, 1);
	script::trigger_script_event(1, &Var0, 6, func_47());
}

// Position - 0x291D
var func_47() {
	var uVar0;
	int iVar1;
	int iVar2;

	iVar1 = network::network_get_host_of_this_script();
	if (network::network_is_participant_active(iVar1)) {
		iVar2 = network::network_get_player_index(iVar1);
		if (func_48(iVar2, 0, 0)) {
			gameplay::set_bit(&uVar0, iVar2);
		}
	}
	return uVar0;
}

// Position - 0x2951
bool func_48(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = iParam0;
	if (iVar0 != -1) {
		if (network::network_is_player_active(iParam0)) {
			if (iParam1) {
				if (!player::is_player_playing(iParam0)) {
					return false;
				}
			}
			if (iParam2) {
				if (!Global_2433125.f_3[iVar0]) {
					return false;
				}
			}
			return true;
		}
	}
	return false;
}

// Position - 0x299B
void func_49(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, float fParam5, int iParam6, int iParam7) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;
	int iVar4;
	int iVar5;
	int iVar6;
	int iVar7;
	int iVar8;
	int iVar9;
	int iVar10;
	int iVar11;
	int iVar12;
	int iVar13;
	int iVar14;
	int iVar15;
	int iVar16;
	int iVar17;
	int iVar18;
	int iVar19;
	int iVar20;
	int iVar21;
	int iVar22;
	int iVar23;
	int iVar24;
	int iVar25;
	int iVar26;
	int iVar27;
	int iVar28;
	int iVar29;
	int iVar30;
	bool bVar31;
	bool bVar32;
	float fVar33;
	float fVar34;
	float fVar35;
	float *fVar36;
	vector3 vVar37;
	bool bVar40;
	float fVar41;
	float fVar42;
	float fVar43;
	float fVar44;
	float fVar45;
	int *iVar46;
	int *iVar47;
	int *iVar48;
	float fVar49;
	int iVar50;
	int iVar51;
	bool bVar52;
	int iVar53;
	int iVar54;
	float fVar55;
	float fVar56;
	float fVar57;
	float fVar58;
	int iVar59;
	int iVar60;
	float fVar61;
	float fVar62;
	float fVar63;
	char cVar64[64];
	char cVar80[64];
	float fVar96;
	int iVar97;
	float fVar98;
	float fVar99;
	int iVar100;
	int iVar101;
	int iVar102;
	int iVar103;
	int iVar104;

	if (!func_81(&iVar0, 0, iParam1)) {
		return;
	}
	if (iVar0 == -1) {
	}
	if (!func_78(0, iParam6)) {
		return;
	}
	graphics::_set_screen_draw_position(76, 84);
	graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
	fVar56 = 0f;
	fVar57 = 0f;
	if (Global_17290) {
		if (func_76(29, 1, 1, &fVar35, &fVar36, iParam7)) {
			fVar56 = fVar36;
			fVar57 = fVar35;
			fVar56 += 0f;
		}
		else {
			Global_17290 = 0;
		}
	}
	if (gameplay::get_hash_key(&Global_17290.f_1) == gameplay::get_hash_key("HIDE")) {
		fVar58 = Global_17288;
	}
	else {
		fVar58 = Global_17288 + fVar56 + 0.034722f + 0f;
	}
	if (fParam5 == -1f) {
		fParam5 = Global_17289;
	}
	fVar61 = 1f;
	if (iParam7) {
		graphics::_get_active_screen_resolution(&iVar59, &iVar60);
		fVar62 = graphics::_get_aspect_ratio(0);
		if (func_75()) {
			iVar59 = system::round(system::to_float(iVar60) * fVar62);
		}
		fVar63 = system::to_float(iVar59) / system::to_float(iVar60);
		fVar61 = fVar63 / fVar62;
		if (func_75()) {
			fVar61 = 1f;
		}
		iVar59 = system::round(system::to_float(iVar59) / fVar61);
		iVar60 = system::round(system::to_float(iVar60) / fVar61);
	}
	else {
		graphics::get_screen_resolution(&iVar59, &iVar60);
	}
	iVar5 = 0;
	while (iVar5 < 2) {
		if (iVar5 == 1 && Global_17290.f_5598) {
			if (gameplay::get_hash_key(&Global_17290.f_1) == gameplay::get_hash_key("HIDE")) {
				fVar49 = Global_17288;
			}
			else {
				if (Global_17290) {
					StringCopy(&cVar64, func_74(29), 64);
					StringCopy(&cVar80, func_71(29, 1), 64);
					if (gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
						func_70(Global_17287, Global_17288, fParam5, fVar56 - 0f, 0, 0, 0, 255);
						graphics::draw_sprite(&cVar64, &cVar80, Global_17287 + fParam5 * 0.5f,
											  Global_17288 + (fVar56 - 0f) * 0.5f, fVar57, fVar56 - 0f, 0f, 255, 255,
											  255, 255, 0);
					}
					else {
						graphics::draw_sprite(&cVar64, &cVar80, Global_17287 + fParam5 * 0.5f,
											  Global_17288 + (fVar56 - 0f) * 0.5f, fParam5, fVar56 - 0f, 0f, 255, 255,
											  255, 255, 0);
					}
				}
				if (Global_17290.f_7869) {
					iVar1 = Global_17290.f_7865;
					iVar2 = Global_17290.f_7866;
					iVar3 = Global_17290.f_7867;
					iVar4 = Global_17290.f_7868;
				}
				else {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 255;
				}
				func_70(Global_17287, Global_17288 + fVar56, fParam5, 0.034722f, iVar1, iVar2, iVar3, iVar4);
				fVar49 = Global_17288 + fVar56 + 0.034722f + 0f;
				if (gameplay::get_hash_key(&Global_17290.f_1) != 0) {
					func_69();
					ui::begin_text_command_display_text(&Global_17290.f_1);
					iVar15 = 0;
					iVar16 = 0;
					iVar17 = 0;
					iVar18 = 0;
					iVar14 = 0;
					while (iVar14 < Global_17290.f_68) {
						if (Global_17290.f_5[iVar14] == 2) {
							ui::add_text_component_integer(Global_17290.f_10[iVar15]);
							iVar15++;
						}
						else if (Global_17290.f_5[iVar14] == 3) {
							ui::add_text_component_float(Global_17290.f_14[iVar16], Global_17290.f_18[iVar16]);
							iVar16++;
						}
						else if (Global_17290.f_5[iVar14] == 1) {
							ui::add_text_component_substring_text_label(&Global_17290.f_22[iVar17 /*4*/]);
							iVar17++;
						}
						else if (Global_17290.f_5[iVar14] == 8) {
							ui::add_text_component_substring_text_label(&Global_17290.f_22[iVar17 /*4*/]);
							iVar17++;
						}
						else if (Global_17290.f_5[iVar14] == 5) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 6) {
							ui::add_text_component_substring_text_label(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 7) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						else if (Global_17290.f_5[iVar14] == 9) {
							ui::add_text_component_substring_player_name(&Global_17290.f_35[iVar18 /*16*/]);
							iVar18++;
						}
						iVar14++;
					}
					ui::end_text_command_display_text(Global_17287 + 0.00390625f, Global_17288 + fVar56 + 0.00416664f,
													  0);
				}
				if (Global_17290.f_5601 > Global_17290.f_5095) {
					if (Global_17290.f_5604 != 0) {
						func_69();
						func_67(Global_17287 + fParam5 - 0.00390625f -
									func_68("CM_ITEM_COUNT", Global_17290.f_5604, Global_17290.f_5603),
								Global_17288 + fVar56 + 0.00416664f, "CM_ITEM_COUNT", Global_17290.f_5604,
								Global_17290.f_5603);
					}
				}
			}
			iVar6 = Global_17290.f_5605;
			iVar9 = 0;
			fVar96 = fVar49;
			if (Global_17290.f_7879) {
				iVar1 = Global_17290.f_7875;
				iVar2 = Global_17290.f_7876;
				iVar3 = Global_17290.f_7877;
				iVar4 = Global_17290.f_7878;
			}
			else {
				ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
			}
			while (iVar9 < Global_17290.f_5095 && iVar6 <= Global_17290.f_5088) {
				if (iVar6 >= 0) {
					if (Global_17290.f_5355[iVar6]) {
						if (Global_17290.f_5226[iVar6] && iVar6 != Global_17290.f_5605) {
							fVar49 += 0.00277776f;
						}
						fVar55 = 0.034722f;
						if (Global_17290.f_5612[iVar6] != 0f) {
							fVar55 = Global_17290.f_5612[iVar6];
						}
						fVar49 += fVar55;
						iVar9++;
					}
				}
				iVar6++;
			}
			if (iParam3) {
				if (iVar9 <= 1) {
					fVar55 = 0.034722f;
					fVar49 += fVar55;
					iVar9++;
					if (Global_17290.f_5088 <= 1) {
						Global_17290.f_5088++;
					}
					iVar53 = 1;
				}
			}
			graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
								  fVar96 + (fVar49 - fVar96) * 0.5f - 0.00138888f, fParam5, fVar49 - fVar96, 0f, 255,
								  255, 255, 255, 0);
			if (Global_17290.f_5601 > Global_17290.f_5095) {
				if (Global_17290.f_7884) {
					iVar1 = Global_17290.f_7880;
					iVar2 = Global_17290.f_7881;
					iVar3 = Global_17290.f_7882;
					iVar4 = Global_17290.f_7883;
				}
				else {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 204;
				}
				func_70(Global_17287, fVar49 + 0f, fParam5, 0.034722f, iVar1, iVar2, iVar3, iVar4);
				vVar37 = {graphics::get_texture_resolution("CommonMenu", "shop_arrows_upANDdown")};
				vVar37.x *= 0.5f / fVar61;
				vVar37.y *= 0.5f / fVar61;
				if (Global_17290.f_7897) {
					iVar1 = 0;
					iVar2 = 0;
					iVar3 = 0;
					iVar4 = 255;
				}
				else {
					ui::get_hud_colour(1, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "shop_arrows_upANDdown", Global_17287 + fParam5 * 0.5f,
									  fVar49 + 0f + 0.034722f * 0.5f, vVar37.x / 1280f * fVar61,
									  vVar37.y / 720f * fVar61, 0f, iVar1, iVar2, iVar3, iVar4, 0);
				fVar49 += 0f + 0.034722f;
			}
			if (gameplay::get_hash_key(&Global_17290.f_4562) != 0 && Global_17290.f_4636 != -1) {
				fVar49 += 0.00277776f * 2f;
				fVar41 = Global_17287 + 0.0046875f;
				if (Global_17290.f_4638 != 0) {
					func_76(Global_17290.f_4638, 1, 1, &fVar35, &fVar36, iParam7);
					fVar41 = Global_17287 + fVar35 + 0.00078125f * 4f - 0.00078125f * 1f;
				}
				func_66(fVar41);
				ui::_begin_text_command_line_count(&Global_17290.f_4562);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_17290.f_4632) {
					if (Global_17290.f_4566[iVar14] == 2) {
						ui::add_text_component_integer(Global_17290.f_4571[iVar15]);
						iVar15++;
					}
					else if (Global_17290.f_4566[iVar14] == 3) {
						ui::add_text_component_float(Global_17290.f_4575[iVar16], Global_17290.f_4579[iVar16]);
						iVar16++;
					}
					else if (Global_17290.f_4566[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					iVar14++;
				}
				iVar6 = ui::_end_text_command_get_line_count(fVar41, fVar49 + 0.00277776f);
				ui::get_hud_colour(2, &iVar1, &iVar2, &iVar3, &iVar4);
				func_70(Global_17287, fVar49 - 0.00277776f, fParam5, 0.00277776f, iVar1, iVar2, iVar3, iVar4);
				if (Global_17290.f_7889) {
					iVar1 = Global_17290.f_7885;
					iVar2 = Global_17290.f_7886;
					iVar3 = Global_17290.f_7887;
					iVar4 = Global_17290.f_7888;
				}
				else {
					ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
									  fVar49 +
										  (ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) +
										   0.00138888f * 13f + 0.00138888f * 5f * IntToFloat(iVar6 - 1)) *
											  0.5f -
										  0.00138888f,
									  fParam5,
									  ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
										  0.00138888f * 5f * IntToFloat(iVar6 - 1),
									  0f, iVar1, iVar2, iVar3, iVar4, 0);
				func_66(fVar41);
				ui::begin_text_command_display_text(&Global_17290.f_4562);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_17290.f_4632) {
					if (Global_17290.f_4566[iVar14] == 2) {
						ui::add_text_component_integer(Global_17290.f_4571[iVar15]);
						iVar15++;
					}
					else if (Global_17290.f_4566[iVar14] == 3) {
						ui::add_text_component_float(Global_17290.f_4575[iVar16], Global_17290.f_4579[iVar16]);
						iVar16++;
					}
					else if (Global_17290.f_4566[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					else if (Global_17290.f_4566[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_17290.f_4583[iVar17 /*16*/]);
						iVar17++;
					}
					iVar14++;
				}
				ui::end_text_command_display_text(fVar41, fVar49 + 0.00277776f, 0);
				if (Global_17290.f_4638 != 0) {
					func_76(Global_17290.f_4638, 1, 1, &fVar35, &fVar36, iParam7);
					func_65(Global_17290.f_4638, 1, &iVar46, &iVar47, &iVar48);
					graphics::draw_sprite(func_74(Global_17290.f_4638), func_71(Global_17290.f_4638, 1),
										  Global_17287 + fVar35 * 0.5f + 0.00078125f * 2f,
										  fVar49 + fVar36 * 0.5f - 0.00138888f * 4f, fVar35, fVar36, 0f, iVar46, iVar47,
										  iVar48, 255, 0);
				}
				fVar49 += ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
						  0.00138888f * 5f * IntToFloat(iVar6 - 1);
				if (Global_17290.f_4636 > 0) {
					if (gameplay::get_game_timer() - Global_17290.f_4637 > Global_17290.f_4636) {
						StringCopy(&Global_17290.f_4562, "", 16);
						Global_17290.f_4636 = -1;
					}
				}
			}
			if (gameplay::get_hash_key(&Global_2593974.f_21) != 0 && Global_2593974.f_65 != -1) {
				fVar49 += 0.00277776f * 2f;
				fVar41 = Global_17287 + 0.0046875f;
				if (Global_2593974.f_67 != 0) {
					func_76(Global_2593974.f_67, 1, 1, &fVar35, &fVar36, iParam7);
					fVar41 = Global_17287 + fVar35 + 0.00078125f * 4f - 0.00078125f * 1f;
				}
				func_66(fVar41);
				ui::_begin_text_command_line_count(&Global_2593974.f_21);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_2593974.f_61) {
					if (Global_2593974.f_25[iVar14] == 2) {
						ui::add_text_component_integer(Global_2593974.f_30[iVar15]);
						iVar15++;
					}
					else if (Global_2593974.f_25[iVar14] == 3) {
						ui::add_text_component_float(Global_2593974.f_34[iVar16], Global_2593974.f_38[iVar16]);
						iVar16++;
					}
					else if (Global_2593974.f_25[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					iVar14++;
				}
				iVar6 = ui::_end_text_command_get_line_count(fVar41, fVar49 + 0.00277776f);
				ui::get_hud_colour(2, &iVar1, &iVar2, &iVar3, &iVar4);
				func_70(Global_17287, fVar49 - 0.00277776f, fParam5, 0.00277776f, iVar1, iVar2, iVar3, iVar4);
				if (Global_17290.f_7889) {
					iVar1 = Global_17290.f_7885;
					iVar2 = Global_17290.f_7886;
					iVar3 = Global_17290.f_7887;
					iVar4 = Global_17290.f_7888;
				}
				else {
					ui::get_hud_colour(140, &iVar1, &iVar2, &iVar3, &iVar4);
				}
				graphics::draw_sprite("CommonMenu", "Gradient_Bgd", Global_17287 + fParam5 * 0.5f,
									  fVar49 +
										  (ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) +
										   0.00138888f * 13f + 0.00138888f * 5f * IntToFloat(iVar6 - 1)) *
											  0.5f -
										  0.00138888f,
									  fParam5,
									  ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
										  0.00138888f * 5f * IntToFloat(iVar6 - 1),
									  0f, iVar1, iVar2, iVar3, iVar4, 0);
				func_66(fVar41);
				ui::begin_text_command_display_text(&Global_2593974.f_21);
				iVar15 = 0;
				iVar16 = 0;
				iVar17 = 0;
				iVar14 = 0;
				while (iVar14 < Global_2593974.f_61) {
					if (Global_2593974.f_25[iVar14] == 2) {
						ui::add_text_component_integer(Global_2593974.f_30[iVar15]);
						iVar15++;
					}
					else if (Global_2593974.f_25[iVar14] == 3) {
						ui::add_text_component_float(Global_2593974.f_34[iVar16], Global_2593974.f_38[iVar16]);
						iVar16++;
					}
					else if (Global_2593974.f_25[iVar14] == 1) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 8) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 5) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 6) {
						ui::add_text_component_substring_text_label(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 7) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					else if (Global_2593974.f_25[iVar14] == 9) {
						ui::add_text_component_substring_player_name(&Global_2593974.f_42[iVar17 /*6*/]);
						iVar17++;
					}
					iVar14++;
				}
				ui::end_text_command_display_text(fVar41, fVar49 + 0.00277776f, 0);
				if (Global_2593974.f_67 != 0) {
					func_76(Global_2593974.f_67, 1, 1, &fVar35, &fVar36, iParam7);
					func_65(Global_2593974.f_67, 1, &iVar46, &iVar47, &iVar48);
					graphics::draw_sprite(func_74(Global_2593974.f_67), func_71(Global_2593974.f_67, 1),
										  Global_17287 + fVar35 * 0.5f + 0.00078125f * 2f,
										  fVar49 + fVar36 * 0.5f - 0.00138888f * 4f, fVar35, fVar36, 0f, iVar46, iVar47,
										  iVar48, 255, 0);
				}
				fVar49 += ui::_get_text_scale_height(0.35f, 0) * IntToFloat(iVar6) + 0.00138888f * 13f +
						  0.00138888f * 5f * IntToFloat(iVar6 - 1);
				if (Global_2593974.f_65 > 0) {
					if (gameplay::get_game_timer() - Global_2593974.f_66 > Global_2593974.f_65) {
						StringCopy(&Global_2593974.f_21, "", 16);
						Global_2593974.f_65 = -1;
					}
				}
			}
			func_57(iVar59, iParam1, 0, 0, 0, 0, iParam4, 1, 0);
			graphics::_set_screen_draw_position(76, 84);
			graphics::_screen_draw_position_ratio(-0.05f, -0.05f, 0f, 0f);
		}
		if (iVar5 == 1 || !Global_17290.f_5598) {
			iVar19 = 0;
			iVar23 = 0;
			iVar20 = 0;
			iVar21 = 0;
			iVar22 = 0;
			iVar9 = 0;
			iVar10 = 0;
			iVar11 = 0;
			iVar12 = 0;
			iVar13 = 0;
			iVar97 = Global_17290.f_5088;
			if (Global_17290.f_5599) {
				iVar97 = Global_17290.f_5602 - 1;
			}
			fVar98 = 0f;
			fVar99 = 0f;
			iVar7 = 0;
			while (iVar7 <= iVar97) {
				fVar55 = 0.034722f;
				if (Global_17290.f_5612[iVar6] != 0f) {
					fVar55 = Global_17290.f_5612[iVar6];
				}
				if (Global_17290.f_5599) {
					iVar6 = Global_17290.f_7520[iVar7];
				}
				else {
					iVar6 = iVar7;
				}
				iVar12 = iVar13;
				bVar32 = false;
				if (iVar6 >= Global_17290.f_5605 && iVar9 < Global_17290.f_5095) {
					bVar32 = true;
					if (Global_17290.f_5606 == iVar6) {
						fVar99 = fVar98;
					}
					if (Global_17290.f_5226[iVar6]) {
						iVar12++;
					}
					fVar34 = fVar58 + fVar98 + 0.00277776f * IntToFloat(iVar12) + 0.00277776f;
				}
				Global_17290.f_5746[iVar6] = fVar34;
				fVar33 = Global_17287 + 0.0046875f;
				bVar40 = false;
				bVar31 = Global_17290.f_5606 == iVar6;
				if (bVar31 && iVar5 == 1 && bVar32) {
					iVar100 = 255;
					iVar101 = 255;
					iVar102 = 255;
					iVar103 = 255;
					if (Global_17290.f_7891) {
						ui::get_hud_colour(Global_17290.f_7890, &iVar100, &iVar101, &iVar102, &iVar103);
					}
					else {
						ui::get_hud_colour(1, &iVar100, &iVar101, &iVar102, &iVar103);
					}
					graphics::draw_sprite("CommonMenu", "Gradient_Nav", Global_17287 + fParam5 * 0.5f,
										  fVar58 + fVar99 + 0.00277776f * IntToFloat(iVar12) + fVar55 * 0.5f, fParam5,
										  fVar55, 0f, iVar100, iVar101, iVar102, iVar103, 0);
					Global_17290.f_5744 = fVar34;
				}
				if (iVar53 && iVar7 == iVar97) {
					func_55(bVar31, 1, 0, 0, 0, 0, 0);
					ui::begin_text_command_display_text("DFLT_MNU_OPT");
					ui::end_text_command_display_text(fVar33, fVar34, 0);
					bVar40 = true;
				}
				else {
					iVar8 = 0;
					while (iVar8 < Global_17290.f_5096) {
						if (gameplay::is_bit_set(Global_17290.f_4959[iVar6], iVar8) ||
							Global_17290.f_4926[iVar8] == 5) {
							if (Global_17290.f_5599) {
								iVar19 = Global_17290.f_7536[iVar9 * Global_17290.f_5096 + iVar8];
								iVar20 = Global_17290.f_7577[iVar9 * Global_17290.f_5096 + iVar8];
								iVar21 = Global_17290.f_7618[iVar9 * Global_17290.f_5096 + iVar8];
								iVar22 = Global_17290.f_7659[iVar9 * Global_17290.f_5096 + iVar8];
								iVar23 = Global_17290.f_7700[iVar9 * Global_17290.f_5096 + iVar8];
							}
							else {
								Global_17290.f_7536[iVar9 * Global_17290.f_5096 + iVar8] = iVar19;
								Global_17290.f_7577[iVar9 * Global_17290.f_5096 + iVar8] = iVar20;
								Global_17290.f_7618[iVar9 * Global_17290.f_5096 + iVar8] = iVar21;
								Global_17290.f_7659[iVar9 * Global_17290.f_5096 + iVar8] = iVar22;
								Global_17290.f_7700[iVar9 * Global_17290.f_5096 + iVar8] = iVar23;
							}
							iVar104 = 0;
							iVar54 = 0;
							if (Global_17290.f_5878[0] != -1) {
								if (iVar6 * 5 + iVar8 == Global_17290.f_5875[0]) {
									iVar54 = 1;
									iVar104 = 0;
								}
							}
							if (Global_17290.f_5878[1] != -1) {
								if (iVar6 * 5 + iVar8 == Global_17290.f_5875[1]) {
									iVar54 = 1;
									iVar104 = 1;
								}
							}
							if (Global_17290.f_4932[iVar8] != -1f) {
								fVar33 = Global_17287 + 0.0046875f + Global_17290.f_4932[iVar8];
							}
							if (iVar8 < 4 && Global_17290.f_4932[iVar8 + 1] != -1f &&
								fVar33 < Global_17290.f_4932[iVar8 + 1]) {
								fVar45 = Global_17290.f_4932[iVar8 + 1] - fVar33;
							}
							else {
								fVar45 = Global_17287 + Global_17289 - 0.0046875f - fVar33;
							}
							if (Global_17290.f_4945[iVar8] && Global_17290.f_5741 && bVar31) {
								bVar52 = true;
							}
							else {
								bVar52 = false;
							}
							switch (Global_17290.f_4926[iVar8]) {
							case 0: break;

							case 1:
								iVar24 = iVar19;
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										fVar42 = 0f;
										fVar43 = 0f;
										iVar25 = 0;
										iVar26 = 0;
										iVar27 = 0;
										iVar28 = 0;
										iVar29 = 0;
										if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
											iVar50 = 0;
											iVar51 = 0;
											iVar14 = 0;
											while (iVar14 < 4) {
												if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5 ||
													Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
													iVar51 = 1;
												}
												else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
													iVar50 = 1;
												}
												iVar14++;
											}
											func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
													iVar54, iVar104, iVar51, iVar50);
											ui::_begin_text_command_width(&Global_17290.f_73[iVar24 /*6*/]);
										}
										iVar14 = 0;
										while (iVar14 < 4) {
											if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
												iVar25++;
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
												}
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
												iVar25++;
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
												}
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_text_label(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_substring_player_name(
														&Global_2453058[iVar23 + iVar29 /*16*/]);
												}
												iVar29++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_integer(
														Global_17290.f_3918[iVar20 + iVar26]);
												}
												iVar26++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
												if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
													ui::add_text_component_float(Global_17290.f_4175[iVar21 + iVar27],
																				 Global_17290.f_4304[iVar21 + iVar27]);
												}
												iVar27++;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
												iVar28++;
											}
											iVar14++;
										}
										if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
											fVar42 = ui::_end_text_command_get_width(1);
										}
										if (iVar28 > 0) {
											iVar14 = 0;
											while (iVar14 < iVar28) {
												if (func_76(Global_17290.f_4433[iVar22 + iVar14], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar43 += fVar35;
													if (iVar14 > 0) {
														fVar43 -= 0.00078125f * 4f;
													}
													if (Global_17290.f_4433[iVar22 + iVar14] == 2 ||
														Global_17290.f_4433[iVar22 + iVar14] == 48) {
														fVar43 -= 0.00078125f * 5f;
													}
												}
												iVar14++;
											}
										}
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - (fVar42 + fVar43) + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - (fVar42 + fVar43) * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
										Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8] = fVar43;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
										fVar43 = Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_76(26, 1, 0, &fVar35, &fVar36, iParam7)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_76(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(26), func_71(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_76(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_76(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(27), func_71(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									iVar25 = 0;
									iVar26 = 0;
									iVar27 = 0;
									iVar28 = 0;
									iVar29 = 0;
									iVar30 = 0;
									if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
										iVar50 = 0;
										iVar51 = 0;
										iVar14 = 0;
										while (iVar14 < 4) {
											if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5 ||
												Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
												iVar51 = 1;
											}
											else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
												iVar50 = 1;
											}
											iVar14++;
										}
										func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												iVar54, 0, iVar51, iVar50);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_54(bVar31);
										}
										ui::begin_text_command_display_text(&Global_17290.f_73[iVar24 /*6*/]);
									}
									iVar14 = 0;
									while (iVar14 < 4) {
										if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
											iVar25++;
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
											}
											iVar30 = 1;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
											iVar25++;
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_17290.f_73[iVar24 + iVar25 /*6*/]);
											}
											iVar30 = 8;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 5;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_text_label(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 6;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 7;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_substring_player_name(
													&Global_2453058[iVar23 + iVar29 /*16*/]);
											}
											iVar29++;
											iVar30 = 9;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_integer(Global_17290.f_3918[iVar20 + iVar26]);
											}
											iVar26++;
											iVar30 = 2;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
											if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
												ui::add_text_component_float(Global_17290.f_4175[iVar21 + iVar27],
																			 Global_17290.f_4304[iVar21 + iVar27]);
											}
											iVar27++;
											iVar30 = 3;
										}
										else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
											if (Global_17290.f_4433[iVar22 + iVar28] == 2 ||
												Global_17290.f_4433[iVar22 + iVar28] == 48) {
												if (func_76(Global_17290.f_4433[iVar22 + iVar28], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar41 += fVar35 * 0.5f;
													if (func_76(Global_17290.f_4433[iVar22 + iVar28], bVar31, 1,
																&fVar35, &fVar36, iParam7)) {
														func_65(Global_17290.f_4433[iVar22 + iVar28], bVar31, &iVar46,
																&iVar47, &iVar48);
														if (Global_17290.f_4953[iVar8] == 2) {
															graphics::draw_sprite(
																func_74(Global_17290.f_4433[iVar22 + iVar28]),
																func_71(Global_17290.f_4433[iVar22 + iVar28], bVar31),
																fVar33 + fVar41 - 0.00078125f * 8f + 0.00078125f * 4f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else {
															graphics::draw_sprite(
																func_74(Global_17290.f_4433[iVar22 + iVar28]),
																func_71(Global_17290.f_4433[iVar22 + iVar28], bVar31),
																fVar33 + fVar41 - 0.00078125f * 8f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														fVar41 += 0.00078125f * 3f;
													}
												}
											}
											iVar28++;
											iVar30 = 4;
										}
										iVar14++;
									}
									if (gameplay::get_hash_key(&Global_17290.f_73[iVar24 /*6*/]) != 0) {
										if (iVar30 == 4 && Global_17290.f_4953[iVar8] == 2) {
											ui::end_text_command_display_text(fVar33 + fVar41 + 0.00078125f * 7f,
																			  fVar34, 0);
										}
										else {
											ui::end_text_command_display_text(fVar33 + fVar41, fVar34, 0);
										}
									}
									if (iVar28 > 0) {
										fVar41 += 6f * 0.00078125f;
										iVar14 = 0;
										while (iVar14 < iVar28) {
											if (Global_17290.f_4433[iVar22 + iVar14] != 2 &&
												Global_17290.f_4433[iVar22 + iVar14] != 48) {
												if (func_76(Global_17290.f_4433[iVar22 + iVar14], bVar31, 0, &fVar35,
															&fVar36, iParam7)) {
													fVar41 += fVar35 * 0.5f;
													if (func_76(Global_17290.f_4433[iVar22 + iVar14], bVar31, 1,
																&fVar35, &fVar36, iParam7)) {
														func_65(Global_17290.f_4433[iVar22 + iVar14], bVar31, &iVar46,
																&iVar47, &iVar48);
														if (Global_17290.f_4433[iVar22 + iVar14] == 30) {
															graphics::draw_sprite(
																func_74(Global_17290.f_4433[iVar22 + iVar14]),
																func_71(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																Global_17287 + fVar35 * 0.5f,
																fVar34 + 0.00277776f + fVar36 * 0.5f -
																	0.00078125f * 11f,
																fVar35, fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else if (Global_17290.f_4953[iVar8] == 2) {
															graphics::draw_sprite(
																func_74(Global_17290.f_4433[iVar22 + iVar14]),
																func_71(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																fVar33 + fVar41 + fVar42 - 0.00078125f * 8f +
																	0.00078125f * 4f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
														else {
															graphics::draw_sprite(
																func_74(Global_17290.f_4433[iVar22 + iVar14]),
																func_71(Global_17290.f_4433[iVar22 + iVar14], bVar31),
																fVar33 + fVar41 + fVar42 - 0.00078125f * 12f,
																fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35, fVar36,
																0f, iVar46, iVar47, iVar48, 255, 0);
														}
													}
													fVar41 += 12f * 0.00078125f;
												}
											}
											iVar14++;
										}
									}
								}
								bVar40 = true;
								iVar19++;
								iVar14 = 0;
								while (iVar14 < 4) {
									if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 1) {
										iVar19++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 8) {
										iVar19++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 2) {
										iVar20++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 3) {
										iVar21++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 4) {
										iVar22++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 5) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 6) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 7) {
										iVar23++;
									}
									else if (Global_17290.f_2124[iVar24 /*5*/][iVar14] == 9) {
										iVar23++;
									}
									iVar14++;
								}
								break;

							case 2:
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												iVar54, 0, 0, 0);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_54(bVar31);
										}
										ui::_begin_text_command_width("NUMBER");
										ui::add_text_component_integer(Global_17290.f_3918[iVar20]);
										fVar42 = ui::_end_text_command_get_width(1);
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - fVar42 + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - fVar42 * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_76(26, 1, 0, &fVar35, &fVar36, iParam7)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_76(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(26), func_71(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_76(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_76(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(27), func_71(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24], iVar54, 0,
											0, 0);
									func_53(fVar33 + fVar41, fVar34, "NUMBER", Global_17290.f_3918[iVar20], 0);
								}
								bVar40 = true;
								iVar20++;
								break;

							case 3:
								if (iVar5 == 1 && bVar32) {
									if (!Global_17290.f_5599) {
										func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24],
												iVar54, 0, 0, 0);
										if (Global_17290.f_7895 && Global_17290.f_7896 == iVar6) {
											func_54(bVar31);
										}
										ui::_begin_text_command_width("NUMBER");
										ui::add_text_component_float(Global_17290.f_4175[iVar21],
																	 Global_17290.f_4304[iVar21]);
										fVar42 = ui::_end_text_command_get_width(1);
										fVar41 = 0f;
										if (Global_17290.f_4953[iVar8] == 2) {
											fVar41 += fVar45 - fVar42 + 0.00078125f * 1f;
										}
										else if (Global_17290.f_4953[iVar8] == 0) {
											fVar41 += (fVar45 - fVar33) * 0.5f - fVar42 * 0.5f;
										}
										Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
										Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8] = fVar42;
									}
									else {
										fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
										fVar42 = Global_17290.f_7782[iVar9 * Global_17290.f_5096 + iVar8];
									}
									if (bVar52) {
										if (func_76(26, 1, 0, &fVar35, &fVar36, 0)) {
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 -= fVar35 * 2f;
											}
											fVar44 = fVar35 * 0.5f;
											if (func_76(26, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(26, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(26), func_71(26, 1),
																	  fVar33 + fVar41 + fVar44,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
										if (func_76(27, 1, 0, &fVar35, &fVar36, iParam7)) {
											fVar41 += fVar35;
											fVar44 = fVar35 * 0.5f;
											if (func_76(27, 1, 1, &fVar35, &fVar36, iParam7)) {
												func_65(27, 1, &iVar46, &iVar47, &iVar48);
												graphics::draw_sprite(func_74(27), func_71(27, 1),
																	  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																	  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																	  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
											}
										}
									}
									func_55(bVar31, Global_17290.f_1610[iVar24], Global_17290.f_1867[iVar24], iVar54, 0,
											0, 0);
									func_52(fVar33 + fVar41, fVar34, "NUMBER", Global_17290.f_4175[iVar21],
											Global_17290.f_4304[iVar21]);
								}
								bVar40 = true;
								iVar21++;
								break;

							case 4:
								if (iVar5 == 1 && bVar32) {
									if (func_76(Global_17290.f_4433[iVar22], bVar31, 0, &fVar35, &fVar36, iParam7)) {
										if (!Global_17290.f_5599) {
											fVar43 = fVar35;
											fVar41 = 0f;
											if (Global_17290.f_4953[iVar8] == 2) {
												fVar41 += fVar45 - fVar43 + 0.00078125f * 1f;
											}
											else if (Global_17290.f_4953[iVar8] == 0) {
												fVar41 += (fVar45 - fVar33) * 0.5f - fVar43 * 0.5f;
											}
											Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8] = fVar41;
											Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8] = fVar43;
										}
										else {
											fVar41 = Global_17290.f_7741[iVar9 * Global_17290.f_5096 + iVar8];
											fVar43 = Global_17290.f_7823[iVar9 * Global_17290.f_5096 + iVar8];
										}
										if (bVar52) {
											if (func_76(26, 1, 0, &fVar35, &fVar36, iParam7)) {
												if (Global_17290.f_4953[iVar8] == 2) {
													fVar41 -= fVar35 * 2f;
												}
												fVar44 = fVar35 * 0.5f;
												if (func_76(26, 1, 1, &fVar35, &fVar36, iParam7)) {
													func_65(26, 1, &iVar46, &iVar47, &iVar48);
													graphics::draw_sprite(func_74(26), func_71(26, 1),
																		  fVar33 + fVar41 + fVar44,
																		  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																		  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
												}
											}
											if (func_76(27, 1, 0, &fVar35, &fVar36, iParam7)) {
												fVar41 += fVar35;
												fVar44 = fVar35 * 0.5f;
												if (func_76(27, 1, 1, &fVar35, &fVar36, iParam7)) {
													func_65(27, 1, &iVar46, &iVar47, &iVar48);
													graphics::draw_sprite(func_74(27), func_71(27, 1),
																		  fVar33 + fVar41 + fVar44 + fVar42 + fVar43,
																		  fVar34 - 0.00277776f + fVar55 * 0.5f, fVar35,
																		  fVar36, 0f, iVar46, iVar47, iVar48, 255, 0);
												}
											}
										}
										if (func_76(Global_17290.f_4433[iVar22], bVar31, 1, &fVar35, &fVar36,
													iParam7)) {
											func_65(Global_17290.f_4433[iVar22], bVar31, &iVar46, &iVar47, &iVar48);
											graphics::draw_sprite(func_74(Global_17290.f_4433[iVar22]),
																  func_71(Global_17290.f_4433[iVar22], bVar31),
																  fVar33 + fVar41 + fVar35 * 0.5f,
																  fVar34 - 0.00277776f + fVar55 * 0.5f,
																  fVar35 * func_51(Global_17290.f_4433[iVar22]),
																  fVar36 * func_51(Global_17290.f_4433[iVar22]), 0f,
																  iVar46, iVar47, iVar48, 255, 0);
										}
									}
								}
								bVar40 = true;
								iVar22++;
								break;

							case 5: bVar40 = true; break;
							}
							if (Global_17290.f_4926[iVar8] == 5) {
								if (Global_17290.f_4938[iVar8] > 0.05f) {
									fVar33 += Global_17290.f_4938[iVar8];
								}
								else {
									fVar33 += 0.05f;
								}
							}
							else {
								fVar33 += Global_17290.f_4938[iVar8];
								if (Global_17290.f_4945[iVar8]) {
									if (func_76(26, 1, 1, &fVar35, &fVar36, iParam7)) {
										fVar33 -= fVar35;
									}
								}
							}
						}
						else {
							fVar33 += Global_17290.f_4938[iVar8];
						}
						iVar8++;
					}
				}
				if (bVar40) {
					if (bVar32) {
						Global_17290.f_7520[iVar9] = iVar6;
						Global_17290.f_5607 = iVar6;
						iVar9++;
						if (Global_17290.f_5226[iVar6]) {
							iVar13++;
						}
						if (Global_17290.f_5612[iVar6] != 0f) {
							fVar98 += Global_17290.f_5612[iVar6];
						}
						else {
							fVar98 += 0.034722f;
						}
					}
					if (!Global_17290.f_5598) {
						Global_17290.f_5355[iVar6] = 1;
						if (Global_17290.f_5097[iVar6]) {
							if (bVar31) {
								Global_17290.f_5604 = 0;
							}
						}
						else {
							iVar11++;
							if (bVar31) {
								Global_17290.f_5604 = iVar11;
							}
						}
						iVar10++;
					}
				}
				iVar7++;
			}
			if (!Global_17290.f_5598) {
				Global_17290.f_5600 = fVar58 + fVar98 + 0.00277776f * IntToFloat(iVar12);
				Global_17290.f_5603 = iVar11;
				Global_17290.f_5601 = iVar10;
				Global_17290.f_5598 = 1;
			}
		}
		iVar5++;
	}
	if (!Global_17290.f_5599) {
		Global_17290.f_5602 = iVar9;
		Global_17290.f_5599 = 1;
	}
	Global_17290.f_5743 = fVar49;
	Global_17290.f_5745 = gameplay::get_game_timer();
	ui::_0x55598D21339CB998(Global_17290.f_5743);
	if (!Global_17290.f_7864) {
		func_27();
	}
	Global_17290.f_7864 = 0;
	if (iParam2) {
		ui::hide_hud_component_this_frame(10);
	}
	ui::hide_hud_component_this_frame(6);
	ui::hide_hud_component_this_frame(7);
	ui::hide_hud_component_this_frame(9);
	ui::hide_hud_component_this_frame(8);
	if (iParam0) {
		func_50(1);
	}
	graphics::_screen_draw_position_end();
}

// Position - 0x54E9
void func_50(int iParam0) { Global_1354542.f_995 = iParam0; }

// Position - 0x54FA
float func_51(int iParam0) {
	switch (iParam0) {
	case 35:
	case 34:
	case 47:
	case 46:
	case 42:
	case 36:
	case 37:
	case 39:
	case 40:
	case 38:
	case 50:
	case 43:
	case 44:
	case 45: return 0.85f;
	}
	return 1f;
}

// Position - 0x5569
void func_52(float fParam0, float fParam1, char *sParam2, float fParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_float(fParam3, iParam4);
	ui::end_text_command_display_text(fParam0, fParam1, 0);
}

// Position - 0x5588
void func_53(float fParam0, float fParam1, char *sParam2, int iParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_integer(iParam3);
	ui::end_text_command_display_text(fParam0, fParam1, iParam4);
}

// Position - 0x55A6
void func_54(int iParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	var uVar3;

	if (iParam0) {
		ui::get_hud_colour(Global_17290.f_7892[0], &iVar0, &iVar1, &iVar2, &uVar3);
	}
	else {
		ui::get_hud_colour(Global_17290.f_7892[1], &iVar0, &iVar1, &iVar2, &uVar3);
	}
	ui::set_text_colour(iVar0, iVar1, iVar2, 255);
}

// Position - 0x55EC
void func_55(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, int iParam6) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	if (iParam2) {
		if (iParam3) {
			func_56(Global_17290.f_5878[iParam4], &iVar0, &iVar1, &iVar2);
			if (iVar0 < 20 && iVar1 < 20 && iVar2 < 20) {
				if (iParam0 == 0) {
					ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
				}
			}
			else if (iVar0 > 230 && iVar1 > 230 && iVar2 > 230) {
				if (iParam0) {
					iVar0 = 0;
					iVar1 = 0;
					iVar2 = 0;
				}
			}
			ui::set_text_colour(iVar0, iVar1, iVar2, 255);
		}
		else if (iParam1) {
			if (iParam0) {
				ui::get_hud_colour(14, &iVar0, &iVar1, &iVar2, &iVar3);
				ui::set_text_colour(iVar0, iVar1, iVar2, 255);
			}
			else {
				ui::get_hud_colour(12, &iVar0, &iVar1, &iVar2, &iVar3);
				ui::set_text_colour(iVar0, iVar1, iVar2, 255);
			}
		}
		else if (iParam0) {
			ui::set_text_colour(155, 155, 155, 255);
		}
		else {
			ui::set_text_colour(155, 155, 155, 255);
		}
	}
	else if (iParam1) {
		if (iParam0) {
			ui::set_text_colour(0, 0, 0, system::floor(255f * 0.8f));
		}
		else {
			ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
			ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
		}
	}
	else if (iParam0) {
		ui::set_text_colour(155, 155, 155, 255);
	}
	else {
		ui::set_text_colour(155, 155, 155, 255);
	}
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_justification(1);
	if (iParam5) {
		ui::set_text_scale(0f, 0.425f);
		ui::set_text_font(4);
	}
	else if (iParam6) {
		ui::set_text_scale(0f, 0.425f);
		ui::set_text_font(6);
	}
	else {
		ui::set_text_font(0);
	}
	ui::set_text_wrap(0f, 1f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x579A
void func_56(int iParam0, int *iParam1, int *iParam2, int *iParam3) {
	switch (iParam0) {
	case 0:
		*iParam1 = 8;
		*iParam2 = 8;
		*iParam3 = 8;
		break;

	case 1:
		*iParam1 = 37;
		*iParam2 = 37;
		*iParam3 = 39;
		break;

	case 22:
		*iParam1 = 140;
		*iParam2 = 146;
		*iParam3 = 154;
		break;

	case 23:
		*iParam1 = 91;
		*iParam2 = 93;
		*iParam3 = 94;
		break;

	case 6:
		*iParam1 = 81;
		*iParam2 = 84;
		*iParam3 = 89;
		break;

	case 111:
		*iParam1 = 240;
		*iParam2 = 240;
		*iParam3 = 240;
		break;

	case 28:
		*iParam1 = 150;
		*iParam2 = 8;
		*iParam3 = 0;
		break;

	case 34:
		*iParam1 = 38;
		*iParam2 = 3;
		*iParam3 = 6;
		break;

	case 88:
		*iParam1 = 245;
		*iParam2 = 137;
		*iParam3 = 15;
		break;

	case 45:
		*iParam1 = 74;
		*iParam2 = 22;
		*iParam3 = 7;
		break;

	case 56:
		*iParam1 = 45;
		*iParam2 = 58;
		*iParam3 = 53;
		break;

	case 58:
		*iParam1 = 71;
		*iParam2 = 120;
		*iParam3 = 60;
		break;

	case 54:
		*iParam1 = 77;
		*iParam2 = 98;
		*iParam3 = 104;
		break;

	case 73:
		*iParam1 = 14;
		*iParam2 = 49;
		*iParam3 = 109;
		break;

	case 68:
		*iParam1 = 22;
		*iParam2 = 34;
		*iParam3 = 72;
		break;

	case 140:
		*iParam1 = 0;
		*iParam2 = 174;
		*iParam3 = 239;
		break;

	case 131:
		*iParam1 = 255;
		*iParam2 = 183;
		*iParam3 = 0;
		break;

	case 90:
		*iParam1 = 142;
		*iParam2 = 140;
		*iParam3 = 70;
		break;

	case 97:
		*iParam1 = 156;
		*iParam2 = 141;
		*iParam3 = 113;
		break;

	case 89:
		*iParam1 = 145;
		*iParam2 = 115;
		*iParam3 = 71;
		break;

	case 105:
		*iParam1 = 98;
		*iParam2 = 68;
		*iParam3 = 40;
		break;

	case 100:
		*iParam1 = 124;
		*iParam2 = 27;
		*iParam3 = 68;
		break;

	case 99:
		*iParam1 = 114;
		*iParam2 = 42;
		*iParam3 = 63;
		break;

	case 136:
		*iParam1 = 246;
		*iParam2 = 151;
		*iParam3 = 153;
		break;

	case 49:
		*iParam1 = 32;
		*iParam2 = 32;
		*iParam3 = 44;
		break;

	case 146:
		*iParam1 = 26;
		*iParam2 = 1;
		*iParam3 = 23;
		break;

	default:
		*iParam1 = 255;
		*iParam2 = 255;
		*iParam3 = 255;
		break;
	}
}

// Position - 0x5A24
void func_57(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4, int iParam5, bool bParam6, int iParam7,
			 int iParam8) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_81(&iVar0, 0, iParam1)) {
		return;
	}
	iParam0 = iParam0;
	if (iParam3 && !func_78(iParam4, iParam8)) {
		return;
	}
	if (func_63()) {
		return;
	}
	if (network::_network_is_text_chat_active()) {
		return;
	}
	if (iParam7 == 0) {
		if (func_60(player::player_id(), 0)) {
			return;
		}
	}
	if (gameplay::is_pc_version()) {
		if (gameplay::update_onscreen_keyboard() == 0 || network::_network_is_text_chat_active()) {
			return;
		}
	}
	if (Global_17290.f_4639 != 0) {
		if (controls::_0x6CD79468A1E595C6(2)) {
			iVar1 = 0;
			while (iVar1 < Global_17290.f_4639) {
				if (Global_17290.f_4896[iVar1] != 353) {
					StringCopy(&Global_17290.f_4641[iVar1 /*16*/],
							   controls::get_control_instructional_button(2, Global_17290.f_4896[iVar1], 1), 64);
				}
				else if (Global_17290.f_4909[iVar1] != 32) {
					StringCopy(&Global_17290.f_4641[iVar1 /*16*/],
							   controls::_0x80C2FD58D720C801(2, Global_17290.f_4909[iVar1], 1), 64);
				}
				iVar1++;
			}
			Global_17290.f_4640 = 0;
		}
		if (!Global_17290.f_4640) {
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "CLEAR_ALL");
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_MAX_WIDTH");
			graphics::_push_scaleform_movie_function_parameter_float(1f - Global_17290.f_4951 / 100f);
			graphics::_pop_scaleform_movie_function_void();
			if (gameplay::is_pc_version()) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "TOGGLE_MOUSE_BUTTONS");
				graphics::_push_scaleform_movie_function_parameter_bool(1);
				graphics::_pop_scaleform_movie_function_void();
			}
			iVar1 = 0;
			while (iVar1 < Global_17290.f_4639) {
				if (gameplay::get_hash_key(&Global_17290.f_4834[iVar1 /*4*/]) != gameplay::get_hash_key("PREV")) {
					graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_DATA_SLOT");
					graphics::_push_scaleform_movie_function_parameter_int(iVar1);
					func_59(&Global_17290.f_4641[iVar1 /*16*/]);
					iVar2 = iVar1 + 1;
					while (iVar2 < 12 && gameplay::get_hash_key(&Global_17290.f_4834[iVar2 /*4*/]) ==
											 gameplay::get_hash_key("PREV")) {
						func_59(&Global_17290.f_4641[iVar2 /*16*/]);
						iVar2++;
					}
					if (Global_17290.f_4883[iVar1] == -1) {
						func_58(&Global_17290.f_4834[iVar1 /*4*/]);
					}
					else {
						graphics::begin_text_command_scaleform_string(&Global_17290.f_4834[iVar1 /*4*/]);
						if (iParam5) {
							ui::add_text_component_substring_time(iParam2, 70);
						}
						else {
							ui::add_text_component_integer(iParam2);
						}
						graphics::end_text_command_scaleform_string();
					}
					if (gameplay::is_pc_version()) {
						if (Global_17290.f_4896[iVar1] != 353 && gameplay::is_bit_set(Global_17290.f_4922, iVar1)) {
							graphics::_push_scaleform_movie_function_parameter_bool(1);
							graphics::_push_scaleform_movie_function_parameter_int(Global_17290.f_4896[iVar1]);
						}
						else {
							graphics::_push_scaleform_movie_function_parameter_bool(0);
							graphics::_push_scaleform_movie_function_parameter_int(353);
						}
					}
					graphics::_pop_scaleform_movie_function_void();
				}
				iVar1++;
			}
			if (gameplay::get_hash_key(&Global_2593974.f_16) != gameplay::get_hash_key("")) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_DATA_SLOT");
				graphics::_push_scaleform_movie_function_parameter_int(Global_17290.f_4639);
				func_59(&Global_2593974);
				if (Global_2593974.f_20 == -1) {
					func_58(&Global_2593974.f_16);
				}
				else {
					graphics::begin_text_command_scaleform_string(&Global_2593974.f_16);
					if (iParam5) {
						ui::add_text_component_substring_time(iParam2, 70);
					}
					else {
						ui::add_text_component_integer(iParam2);
					}
					graphics::end_text_command_scaleform_string();
				}
				graphics::_pop_scaleform_movie_function_void();
			}
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "SET_BACKGROUND_COLOUR");
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(0);
			graphics::_push_scaleform_movie_function_parameter_int(80);
			graphics::_pop_scaleform_movie_function_void();
			graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "DRAW_INSTRUCTIONAL_BUTTONS");
			if (Global_17290.f_4952) {
				graphics::_push_scaleform_movie_function_parameter_int(1);
			}
			else {
				graphics::_push_scaleform_movie_function_parameter_int(0);
			}
			graphics::_pop_scaleform_movie_function_void();
			Global_17290.f_4640 = 1;
		}
		iVar1 = 0;
		while (iVar1 < Global_17290.f_4639) {
			if (Global_17290.f_4883[iVar1] != -1) {
				if (iParam2 > 0) {
					graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/],
															 "OVERRIDE_RESPAWN_TEXT");
					graphics::_push_scaleform_movie_function_parameter_int(iVar1);
					graphics::begin_text_command_scaleform_string(&Global_17290.f_4834[iVar1 /*4*/]);
					if (iParam5) {
						ui::add_text_component_substring_time(iParam2, 70);
					}
					else {
						ui::add_text_component_integer(iParam2);
					}
					graphics::end_text_command_scaleform_string();
					graphics::_pop_scaleform_movie_function_void();
				}
			}
			iVar1++;
		}
		if (Global_2593974.f_20 != -1) {
			if (iParam2 > 0) {
				graphics::_push_scaleform_movie_function(Global_17290.f_5530[iVar0 /*10*/], "OVERRIDE_RESPAWN_TEXT");
				graphics::_push_scaleform_movie_function_parameter_int(iVar1);
				graphics::begin_text_command_scaleform_string(&Global_2593974.f_16);
				if (iParam5) {
					ui::add_text_component_substring_time(iParam2, 70);
				}
				else {
					ui::add_text_component_integer(iParam2);
				}
				graphics::end_text_command_scaleform_string();
				graphics::_pop_scaleform_movie_function_void();
			}
		}
		graphics::_set_screen_draw_position(76, 66);
		graphics::_screen_draw_position_ratio(0f, 0f, 0f, 0f);
		if (bParam6) {
			if (!Global_17290.f_7899) {
				ui::set_hud_component_position(15, 0f, -0.0375f);
				Global_17290.f_7899 = 1;
			}
		}
		else if (Global_17290.f_7899) {
			ui::reset_hud_component_values(15);
			Global_17290.f_7899 = 0;
		}
		graphics::_screen_draw_position_end();
		if (Global_17290.f_4925) {
			graphics::_set_screen_draw_position(82, 66);
			graphics::_screen_draw_position_ratio(0f, 0f, 0f, 0f);
			graphics::draw_scaleform_movie(Global_17290.f_5530[iVar0 /*10*/], Global_17290.f_4923, Global_17290.f_4924,
										   1f, 1f, 255, 255, 255, 255, 0);
			graphics::_screen_draw_position_end();
		}
		else {
			graphics::draw_scaleform_movie_fullscreen(Global_17290.f_5530[iVar0 /*10*/], 255, 255, 255, 255, 0);
		}
	}
}

// Position - 0x5EF3
void func_58(char *sParam0) {
	graphics::begin_text_command_scaleform_string(sParam0);
	graphics::end_text_command_scaleform_string();
}

// Position - 0x5F05
void func_59(char *sParam0) { graphics::_0xE83A3E3557A56640(sParam0); }

// Position - 0x5F13
bool func_60(int iParam0, int iParam1) {
	bool bVar0;

	if (iParam0 == player::player_id()) {
		bVar0 = func_61(-1, 0) == 8;
	}
	else {
		bVar0 = Global_1591201[iParam0 /*602*/].f_203 == 8;
	}
	if (iParam1 == 1) {
		if (network::network_is_player_active(iParam0)) {
			bVar0 = player::get_player_team(iParam0) == 8;
		}
	}
	return bVar0;
}

// Position - 0x5F5E
int func_61(int iParam0, int iParam1) {
	int iVar0;
	int iVar1;

	iVar1 = iParam0;
	if (iVar1 == -1) {
		iVar1 = func_62();
	}
	if (Global_1315213[iVar1] == 1) {
		if (iParam1) {
		}
		iVar0 = 8;
	}
	else {
		iVar0 = Global_1312729[iVar1];
		if (iParam1) {
		}
	}
	return iVar0;
}

// Position - 0x5F9F
var func_62() { return Global_1312735; }

// Position - 0x5FAB
bool func_63() {
	vector3 vVar0;

	if (Global_14443.f_1 > 3) {
		return true;
	}
	if (func_64()) {
		vVar0 = {0f, -500f, 0f};
		mobile::get_mobile_phone_position(&vVar0);
		if (Global_14388 == 0) {
			if (vVar0.y > -119f) {
				return true;
			}
			else {
				return false;
			}
		}
		else if (vVar0.y > -101f) {
			return true;
		}
		else {
			return false;
		}
	}
	return false;
}

// Position - 0x6019
bool func_64() {
	if (script::_get_number_of_instances_of_script_with_name_hash(joaat("cellphone_flashhand")) > 0) {
		return true;
	}
	return false;
}

// Position - 0x6033
void func_65(int iParam0, int iParam1, int *iParam2, int *iParam3, int *iParam4) {
	var uVar0;

	ui::get_hud_colour(1, iParam2, iParam3, iParam4, &uVar0);
	switch (iParam0) {
	case 28:
		*iParam2 = 194;
		*iParam3 = 80;
		*iParam4 = 80;
		break;

	case 15:
	case 4:
	case 16:
	case 26:
	case 27:
	case 35:
	case 34:
	case 47:
	case 46:
	case 42:
	case 36:
	case 37:
	case 50:
	case 39:
	case 40:
	case 38:
	case 43:
	case 44:
	case 45:
	case 49:
		if (iParam1) {
			*iParam2 = 0;
			*iParam3 = 0;
			*iParam4 = 0;
		}
		break;
	}
}

// Position - 0x60F3
void func_66(float fParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
	ui::set_text_font(0);
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_leading(2);
	ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
	ui::set_text_wrap(fParam0, Global_17287 + Global_17289 - 0.0046875f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x6152
void func_67(float fParam0, float fParam1, char *sParam2, int iParam3, int iParam4) {
	ui::begin_text_command_display_text(sParam2);
	ui::add_text_component_integer(iParam3);
	ui::add_text_component_integer(iParam4);
	ui::end_text_command_display_text(fParam0, fParam1, 0);
}

// Position - 0x6175
float func_68(char *sParam0, int iParam1, int iParam2) {
	if (!gameplay::is_string_null(sParam0)) {
		if (gameplay::get_hash_key(sParam0) == 0) {
			return 0f;
		}
	}
	else {
		return 0f;
	}
	func_69();
	ui::_begin_text_command_width(sParam0);
	ui::add_text_component_integer(iParam1);
	ui::add_text_component_integer(iParam2);
	return ui::_end_text_command_get_width(1);
}

// Position - 0x61B7
void func_69() {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	ui::get_hud_colour(1, &iVar0, &iVar1, &iVar2, &iVar3);
	if (Global_17290.f_7874) {
		iVar0 = Global_17290.f_7870;
		iVar1 = Global_17290.f_7871;
		iVar2 = Global_17290.f_7872;
		iVar3 = Global_17290.f_7873;
	}
	ui::set_text_font(0);
	ui::set_text_scale(0f, 0.35f);
	ui::set_text_colour(iVar0, iVar1, iVar2, iVar3);
	ui::set_text_wrap(Global_17287 + 0.0046875f, Global_17287 + Global_17289 - 0.0046875f);
	ui::set_text_centre(0);
	ui::set_text_dropshadow(0, 0, 0, 0, 0);
	ui::set_text_edge(0, 0, 0, 0, 0);
}

// Position - 0x6241
void func_70(float fParam0, float fParam1, float fParam2, float fParam3, int iParam4, int iParam5, int iParam6,
			 int iParam7) {
	graphics::draw_rect(fParam0 + fParam2 * 0.5f, fParam1 + fParam3 * 0.5f, fParam2, fParam3, iParam4, iParam5, iParam6,
						iParam7, 0);
}

// Position - 0x6270
var func_71(int iParam0, int iParam1) {
	char *sVar0[2];
	var uVar3;
	struct<13> Var19;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_6703[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_6703[iParam0 /*16*/]) == -1487683087) {
			Var19 = {func_73(player::player_id())};
			if (network::_0x5835D9CD92E83184(&Var19, &uVar3)) {
				return func_72(&uVar3);
			}
		}
		else {
			return func_72(&Global_17290.f_6703[iParam0 /*16*/]);
		}
	}
	switch (iParam0) {
	case 3:
		sVar0[0] = "MP_hostCrown";
		sVar0[1] = "MP_hostCrown";
		break;

	case 21:
		sVar0[0] = "MP_SpecItem_Coke";
		sVar0[1] = "MP_SpecItem_Coke";
		break;

	case 22:
		sVar0[0] = "MP_SpecItem_Heroin";
		sVar0[1] = "MP_SpecItem_Heroin";
		break;

	case 23:
		sVar0[0] = "MP_SpecItem_Weed";
		sVar0[1] = "MP_SpecItem_Weed";
		break;

	case 24:
		sVar0[0] = "MP_SpecItem_Meth";
		sVar0[1] = "MP_SpecItem_Meth";
		break;

	case 25:
		sVar0[0] = "MP_SpecItem_Cash";
		sVar0[1] = "MP_SpecItem_Cash";
		break;

	case 1:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 2:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 4:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 6:
		sVar0[0] = "Shop_Box_CrossB";
		sVar0[1] = "Shop_Box_Cross";
		break;

	case 7:
		sVar0[0] = "Shop_Box_BlankB";
		sVar0[1] = "Shop_Box_Blank";
		break;

	case 5:
		sVar0[0] = "Shop_Box_TickB";
		sVar0[1] = "Shop_Box_Tick";
		break;

	case 8:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 9:
		sVar0[0] = "Shop_Clothing_Icon_B";
		sVar0[1] = "Shop_Clothing_Icon_A";
		break;

	case 10:
		sVar0[0] = "Shop_GunClub_Icon_B";
		sVar0[1] = "Shop_GunClub_Icon_A";
		break;

	case 17:
		sVar0[0] = "Shop_Ammo_Icon_B";
		sVar0[1] = "Shop_Ammo_Icon_A";
		break;

	case 18:
		sVar0[0] = "Shop_Armour_Icon_B";
		sVar0[1] = "Shop_Armour_Icon_A";
		break;

	case 19:
		sVar0[0] = "Shop_Health_Icon_B";
		sVar0[1] = "Shop_Health_Icon_A";
		break;

	case 20:
		sVar0[0] = "Shop_MakeUp_Icon_B";
		sVar0[1] = "Shop_MakeUp_Icon_A";
		break;

	case 11:
		sVar0[0] = "Shop_Tattoos_Icon_B";
		sVar0[1] = "Shop_Tattoos_Icon_A";
		break;

	case 12:
		sVar0[0] = "Shop_Garage_Icon_B";
		sVar0[1] = "Shop_Garage_Icon_A";
		break;

	case 13:
		sVar0[0] = "Shop_Garage_Bike_Icon_B";
		sVar0[1] = "Shop_Garage_Bike_Icon_A";
		break;

	case 14:
		sVar0[0] = "Shop_Barber_Icon_B";
		sVar0[1] = "Shop_Barber_Icon_A";
		break;

	case 15:
		sVar0[0] = "shop_Lock";
		sVar0[1] = "shop_Lock";
		break;

	case 16:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 26:
		sVar0[0] = "arrowleft";
		sVar0[1] = "arrowleft";
		break;

	case 27:
		sVar0[0] = "arrowright";
		sVar0[1] = "arrowright";
		break;

	case 28:
		sVar0[0] = "MP_AlertTriangle";
		sVar0[1] = "MP_AlertTriangle";
		break;

	case 29:
		sVar0[0] = "shop_NEW_Star";
		sVar0[1] = "shop_NEW_Star";
		break;

	case 31:
		sVar0[0] = "Shop_Michael_Icon_B";
		sVar0[1] = "Shop_Michael_Icon_A";
		break;

	case 32:
		sVar0[0] = "Shop_Franklin_Icon_B";
		sVar0[1] = "Shop_Franklin_Icon_A";
		break;

	case 33:
		sVar0[0] = "Shop_Trevor_Icon_B";
		sVar0[1] = "Shop_Trevor_Icon_A";
		break;

	case 48:
		sVar0[0] = "SaleIcon";
		sVar0[1] = "SaleIcon";
		break;

	case 49:
		sVar0[0] = "Shop_Tick_Icon";
		sVar0[1] = "Shop_Tick_Icon";
		break;

	case 0:
		sVar0[0] = "";
		sVar0[1] = "";
		break;
	}
	if (iParam1) {
		return sVar0[0];
	}
	return sVar0[1];
}

// Position - 0x66A3
var func_72(var uParam0) { return uParam0; }

// Position - 0x66AD
struct<13> func_73(int iParam0) {
	struct<13> Var0;

	network::network_handle_from_player(iParam0, &Var0, 13);
	return Var0;
}

// Position - 0x66C4
char *
func_74(int iParam0) {
	var uVar0;
	struct<13> Var16;

	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5886[iParam0 /*16*/])) {
		if (gameplay::get_hash_key(&Global_17290.f_5886[iParam0 /*16*/]) == -1487683087) {
			Var16 = {func_73(player::player_id())};
			network::_0x5835D9CD92E83184(&Var16, &uVar0);
			return func_72(&uVar0);
		}
		else {
			return func_72(&Global_17290.f_5886[iParam0 /*16*/]);
		}
	}
	if (iParam0 == 48) {
		return "MPShopSale";
	}
	return "CommonMenu";
}

// Position - 0x6738
bool func_75() {
	int iVar0;
	int iVar1;
	float fVar2;

	graphics::_get_active_screen_resolution(&iVar0, &iVar1);
	fVar2 = system::to_float(iVar0) / system::to_float(iVar1);
	if (fVar2 > 3.5f) {
		return true;
	}
	return false;
}

// Position - 0x676A
bool func_76(int iParam0, int iParam1, int iParam2, float fParam3, float *fParam4, int iParam5) {
	char cVar0[64];
	char cVar16[64];
	int iVar32;
	int iVar33;
	float fVar34;
	float fVar35;
	float fVar36;
	vector3 vVar37;

	StringCopy(&cVar0, func_74(iParam0), 64);
	StringCopy(&cVar16, func_71(iParam0, iParam1), 64);
	if (gameplay::get_hash_key(&cVar16) != 0) {
		fVar34 = 1f;
		if (iParam5) {
			graphics::_get_active_screen_resolution(&iVar32, &iVar33);
			fVar35 = graphics::_get_aspect_ratio(0);
			if (func_75()) {
				iVar32 = system::round(system::to_float(iVar33) * fVar35);
			}
			fVar36 = system::to_float(iVar32) / system::to_float(iVar33);
			fVar34 = fVar36 / fVar35;
			if (func_75()) {
				fVar34 = 1f;
			}
			if (script::_get_number_of_instances_of_script_with_name_hash(joaat("director_mode")) > 0) {
				graphics::get_screen_resolution(&iVar32, &iVar33);
			}
			iVar32 = system::round(system::to_float(iVar32) / fVar34);
			iVar33 = system::round(system::to_float(iVar33) / fVar34);
		}
		else {
			graphics::get_screen_resolution(&iVar32, &iVar33);
		}
		vVar37 = {graphics::get_texture_resolution(&cVar0, &cVar16)};
		vVar37.x *= func_77(iParam0) / fVar34;
		vVar37.y *= func_77(iParam0) / fVar34;
		if (!iParam2) {
			vVar37.x -= 2f;
			vVar37.y -= 2f;
		}
		if (iParam0 == 30) {
			vVar37.x = 288f;
			vVar37.y = 106f;
		}
		if (iParam0 == 29 && gameplay::get_hash_key(&Global_17290.f_6703[29 /*16*/]) == -1487683087) {
			vVar37.x = 106f;
			vVar37.y = 106f;
		}
		*fParam3 = vVar37.x / IntToFloat(iVar32) * IntToFloat(iVar32 / iVar33);
		*fParam4 = vVar37.y / IntToFloat(iVar33) / (vVar37.x / IntToFloat(iVar32)) * *fParam3;
		if (!iParam5) {
			if (!graphics::get_is_widescreen() && iParam0 != 30) {
				*fParam3 *= 1.33f;
			}
		}
		if (iParam0 == 29) {
			if (*fParam3 > Global_17289) {
				*fParam4 *= Global_17289 / *fParam3;
				*fParam3 = Global_17289;
			}
		}
		return true;
	}
	return false;
}

// Position - 0x691B
float func_77(int iParam0) {
	switch (iParam0) {
	case 33:
	case 4:
	case 11:
	case 31:
	case 20:
	case 15:
	case 10:
	case 12:
	case 13:
	case 32:
	case 9:
	case 5:
	case 6:
	case 7:
	case 14:
	case 18:
	case 19:
	case 17:
	case 28:
	case 26:
	case 27:
	case 49: return 0.5f;
	}
	return 1f;
}

// Position - 0x69BA
int func_78(int iParam0, bool bParam1) {
	if (Global_2433125.f_1385.f_688 != 0) {
		return 1;
	}
	if (!cam::is_screen_faded_in() || func_80(8, -1) && func_79() != 64 ||
		ui::get_pause_menu_state() != 0 && !bParam1 || streaming::is_player_switch_in_progress() && !iParam0 ||
		network::_0x2EAC52B4019E2782() || Global_69962 || Global_17290.f_7898 || ui::is_warning_message_active() ||
		Global_91543.f_1361) {
		return 0;
	}
	return 1;
}

// Position - 0x6A57
int func_79() { return Global_1315168; }

// Position - 0x6A63
var func_80(int iParam0, int iParam1) {
	switch (iParam0) {
	case 5:
		if (iParam1 > -1) {
			return Global_1353070.f_203[iParam1];
		}
		break;
	}
	return gameplay::is_bit_set(Global_1353070.f_1015, iParam0);
}

// Position - 0x6A9E
int func_81(int *iParam0, int iParam1, int iParam2) {
	char cVar0[64];
	int iVar16;
	int iVar17;
	int iVar18;

	if (iParam2 == -1) {
		if (network::network_is_game_in_progress() && network::network_get_this_script_is_network_script()) {
			iParam2 = network::_0x638A3A81733086DB();
		}
	}
	StringCopy(&cVar0, script::get_this_script_name(), 64);
	StringIntConCat(&cVar0, iParam2, 64);
	iVar16 = gameplay::get_hash_key(&cVar0);
	iVar18 = -1;
	iVar17 = 0;
	while (iVar17 < 6) {
		if (Global_17290.f_5591[iVar17] == iVar16) {
			*iParam0 = iVar17;
			return 1;
		}
		else if (Global_17290.f_5591[iVar17] == 0) {
			iVar18 = iVar17;
		}
		iVar17++;
	}
	if (iParam1) {
		if (iVar18 != -1) {
			Global_17290.f_5591[iVar18] = iVar16;
			*iParam0 = iVar18;
			return 1;
		}
	}
	return 0;
}

// Position - 0x6B3B
void func_82(struct<21> Param0) {
	struct<2> Var0;
	int iVar4;

	func_32(0);
	func_93(1, 1, 0, 0, 0);
	func_92(1, 2, 1, 1, 1);
	func_91("DART_A_SET");
	func_87(0, vLocal_229[0 /*3*/], 0, 1, 0, 0);
	StringCopy(&Var0, "DART_A_S", 16);
	StringIntConCat(&Var0, iLocal_217, 16);
	func_87(0, &Var0, 0, 1, 0, 0);
	if (gameplay::is_bit_set(Local_262.f_1, Local_388[network::participant_id_to_int() /*5*/].f_1)) {
		func_86(201, func_100(Param0, 1), -1, 0);
	}
	else {
		func_86(201, func_100(Param0, 2), -1, 0);
	}
	if (controls::_is_input_disabled(2)) {
		iVar4 = 225;
	}
	else {
		iVar4 = 202;
	}
	func_86(iVar4, "DART_A_MENU_C", -1, 0);
	func_85(0, 1, 0, 0, 0);
	func_84(iLocal_101, 1, 1);
	func_83("DART_A_GNT", 0, 0);
}

// Position - 0x6BFF
void func_83(char *sParam0, int iParam1, int iParam2) {
	int iVar0;

	StringCopy(&Global_17290.f_4562, sParam0, 16);
	Global_17290.f_4632 = 0;
	Global_17290.f_4633 = 0;
	Global_17290.f_4634 = 0;
	Global_17290.f_4635 = 0;
	Global_17290.f_4636 = iParam1;
	Global_17290.f_4637 = gameplay::get_game_timer();
	Global_17290.f_4638 = iParam2;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_4566[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x6C64
void func_84(int iParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;

	Global_17290.f_5606 = iParam0;
	Global_17290.f_5741 = iParam2;
	if (Global_17290.f_5606 < Global_17290.f_5605) {
		Global_17290.f_5605 = Global_17290.f_5606;
	}
	else if (Global_17290.f_5599 && Global_17290.f_5606 > Global_17290.f_5607 ||
			 !Global_17290.f_5599 && Global_17290.f_5606 >= Global_17290.f_5605 + Global_17290.f_5095) {
		iVar0 = Global_17290.f_5605;
		while (iVar0 <= Global_17290.f_5606) {
			if (iVar0 >= 0 && iVar0 < 127) {
				if (Global_17290.f_4959[iVar0] != 0) {
					iVar1++;
				}
			}
			iVar0++;
		}
		while (iVar1 > Global_17290.f_5095 && Global_17290.f_5605 < 128) {
			Global_17290.f_5605++;
			iVar1 = 0;
			iVar0 = Global_17290.f_5605;
			while (iVar0 <= Global_17290.f_5606) {
				if (iVar0 >= 0 && iVar0 < 127) {
					if (Global_17290.f_4959[iVar0] != 0) {
						iVar1++;
					}
				}
				iVar0++;
			}
		}
	}
	Global_17290.f_5598 = 0;
	Global_17290.f_5599 = 0;
	if (iParam1) {
		StringCopy(&Global_17290.f_4562, "", 16);
		StringCopy(&Global_2593974.f_21, "", 16);
	}
}

// Position - 0x6DB2
void func_85(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4945[0] = iParam0;
	Global_17290.f_4945[1] = iParam1;
	Global_17290.f_4945[2] = iParam2;
	Global_17290.f_4945[3] = iParam3;
	Global_17290.f_4945[4] = iParam4;
}

// Position - 0x6DF1
void func_86(int iParam0, char *sParam1, int iParam2, int iParam3) {
	char *sVar0;

	sVar0 = controls::get_control_instructional_button(2, iParam0, 1);
	if (Global_17290.f_4639 >= 12) {
		StringCopy(&Global_2593974, sVar0, 64);
		StringCopy(&Global_2593974.f_16, sParam1, 16);
		Global_2593974.f_20 = iParam2;
		return;
		return;
	}
	if (!iParam3) {
		gameplay::set_bit(&Global_17290.f_4922, Global_17290.f_4639);
	}
	StringCopy(&Global_17290.f_4641[Global_17290.f_4639 /*16*/], sVar0, 64);
	StringCopy(&Global_17290.f_4834[Global_17290.f_4639 /*4*/], sParam1, 16);
	Global_17290.f_4883[Global_17290.f_4639] = iParam2;
	Global_17290.f_4896[Global_17290.f_4639] = iParam0;
	Global_17290.f_4909[Global_17290.f_4639] = 32;
	Global_17290.f_4639++;
}

// Position - 0x6EA6
void func_87(int iParam0, char *sParam1, int iParam2, int iParam3, int iParam4, int iParam5) {
	int iVar0;
	float fVar1;
	float fVar2;
	float *fVar3;
	float fVar4;

	if (Global_17290.f_5088 > iParam0) {
		return;
	}
	if (Global_17290.f_5088 >= 128) {
		return;
	}
	if (Global_17290.f_5090 >= 256) {
		return;
	}
	if (Global_17290.f_5610 < Global_17290.f_5608) {
		return;
	}
	if (Global_17290.f_5088 != iParam0) {
		Global_17290.f_5088 = iParam0;
		Global_17290.f_5089 = 0;
	}
	iVar0 = Global_17290.f_4926[Global_17290.f_5089];
	if (iVar0 != 1) {
		while (Global_17290.f_5089 < 4 && iVar0 != 1) {
			Global_17290.f_5089++;
			iVar0 = Global_17290.f_4926[Global_17290.f_5089];
		}
		if (iVar0 != 1) {
			return;
		}
	}
	StringCopy(&Global_17290.f_73[Global_17290.f_5090 /*6*/], sParam1, 24);
	if (!gameplay::is_string_null_or_empty(sParam1) && !ui::does_text_label_exist(sParam1)) {
	}
	Global_17290.f_1610[Global_17290.f_5090] = iParam3;
	Global_17290.f_1867[Global_17290.f_5090] = iParam4;
	Global_17290.f_5090++;
	if (!iParam3) {
		func_90(Global_17290.f_5088, 1);
	}
	else {
		func_90(Global_17290.f_5088, 0);
	}
	if (iParam2 == 0) {
		fVar1 = func_89(&Global_17290.f_73[Global_17290.f_5090 /*6*/]);
		if (Global_17290.f_4945[Global_17290.f_5089]) {
			func_76(26, 1, 0, &fVar2, &fVar3, 0);
			fVar1 += fVar2 * 2f;
		}
		if (fVar1 > Global_17290.f_4938[Global_17290.f_5089]) {
			Global_17290.f_4938[Global_17290.f_5089] = fVar1;
		}
	}
	if (iParam5) {
		if (iParam2 == 0) {
			fVar4 = func_88(&Global_17290.f_73[Global_17290.f_5090 /*6*/]);
			if (fVar4 > Global_17290.f_5612[iParam0]) {
				Global_17290.f_5612[iParam0] = fVar4;
			}
		}
	}
	gameplay::set_bit(&Global_17290.f_4959[iParam0], Global_17290.f_5089);
	Global_17290.f_5089++;
	Global_17290.f_5611 = 1;
	Global_17290.f_5609 = Global_17290.f_5090 - 1;
	Global_17290.f_5610 = 0;
	Global_17290.f_5608 = iParam2;
}

// Position - 0x70B2
var func_88(char *sParam0) {
	if (!ui::does_text_label_exist(sParam0)) {
	}
	return ui::_get_text_scale_height(0.35f, 0);
}

// Position - 0x70CE
float func_89(char *sParam0) {
	if (!gameplay::is_string_null(sParam0)) {
		if (gameplay::get_hash_key(sParam0) == 0) {
			return 0f;
		}
	}
	else {
		return 0f;
	}
	func_55(0, 1, 0, 0, 0, 0, 0);
	ui::_begin_text_command_width(sParam0);
	return ui::_end_text_command_get_width(1);
}

// Position - 0x710B
void func_90(int iParam0, int iParam1) {
	int iVar0;

	iVar0 = system::floor(system::to_float(iParam0) / 32f);
	if (iParam1) {
		gameplay::set_bit(&Global_17290.f_5881[iVar0], iParam0 - iVar0 * 32);
	}
	else {
		gameplay::clear_bit(&Global_17290.f_5881[iVar0], iParam0 - iVar0 * 32);
	}
}

// Position - 0x7157
void func_91(char *sParam0) {
	int iVar0;

	StringCopy(&Global_17290.f_1, sParam0, 16);
	Global_17290.f_68 = 0;
	Global_17290.f_69 = 0;
	Global_17290.f_70 = 0;
	Global_17290.f_71 = 0;
	Global_17290.f_72 = 0;
	iVar0 = 0;
	while (iVar0 < 4) {
		Global_17290.f_5[iVar0] = 0;
		iVar0++;
	}
}

// Position - 0x71A2
void func_92(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4953[0] = iParam0;
	Global_17290.f_4953[1] = iParam1;
	Global_17290.f_4953[2] = iParam2;
	Global_17290.f_4953[3] = iParam3;
	Global_17290.f_4953[4] = iParam4;
}

// Position - 0x71E1
void func_93(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	Global_17290.f_4926[0] = iParam0;
	Global_17290.f_4926[1] = iParam1;
	Global_17290.f_4926[2] = iParam2;
	Global_17290.f_4926[3] = iParam3;
	Global_17290.f_4926[4] = iParam4;
	Global_17290.f_5096 = 0;
	if (iParam0 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam1 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam2 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam3 != 0) {
		Global_17290.f_5096++;
	}
	if (iParam4 != 0) {
		Global_17290.f_5096++;
	}
}

// Position - 0x728B
void func_94() {
	int iVar0;

	if (!iLocal_103) {
		audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
		iLocal_103 = 1;
	}
	if (controls::is_control_just_pressed(2, 201)) {
		audio::play_sound_frontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
	}
	if (controls::_is_input_disabled(2)) {
		iVar0 = 225;
	}
	else {
		iVar0 = 202;
	}
	if (controls::is_control_just_pressed(2, iVar0)) {
		audio::play_sound_frontend(-1, "CANCEL", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
	}
	if (controls::is_control_just_pressed(2, 174)) {
		audio::play_sound_frontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
		func_95(&iLocal_217, 5, 0, 1);
		iLocal_100 = 1;
	}
	if (controls::is_control_just_pressed(2, 175)) {
		audio::play_sound_frontend(-1, "NAV_LEFT_RIGHT", "HUD_FRONTEND_DEFAULT_SOUNDSET", 1);
		func_95(&iLocal_217, 5, 1, 1);
		iLocal_100 = 1;
	}
	if (iLocal_100) {
		Global_1633501.f_89247 = 1;
		Global_1633501.f_89248 = uLocal_223[iLocal_217];
		iLocal_100 = 0;
	}
}

// Position - 0x7358
void func_95(int *iParam0, int iParam1, int iParam2, int iParam3) {
	int iVar0;
	int iVar1;

	if (iParam3) {
		iVar0 = iParam1 - 1;
	}
	else {
		iVar0 = iParam1;
	}
	iVar1 = 0;
	if (*iParam0 < iVar1) {
		*iParam0 = iVar1;
	}
	switch (iParam2) {
	case 1:
		if (*iParam0 < iVar0) {
			*iParam0++;
		}
		else if (*iParam0 >= iVar0) {
			*iParam0 = iVar1;
		}
		break;

	case 0:
		if (*iParam0 > iVar1) {
			*iParam0--;
		}
		else if (*iParam0 <= iVar0) {
			*iParam0 = iVar0;
		}
		break;
	}
}

// Position - 0x73DB
int func_96(int iParam0) {
	switch (iParam0) {
	case 0:
		if (controls::_is_input_disabled(2)) {
			return 225;
		}
		else {
			return 202;
		}
		break;
	}
	return 202;
}

// Position - 0x740A
bool func_97(int iParam0, var *uParam1) {
	switch (iParam0) {
	case 0:
		if (gameplay::is_bit_set(uParam1->f_5, network::participant_id_to_int())) {
			return true;
		}
		break;

	case 1:
		if (gameplay::is_bit_set(uParam1->f_6, network::participant_id_to_int())) {
			return true;
		}
		break;
	}
	return false;
}

// Position - 0x7452
var func_98(struct<2> Param0, var uParam2, struct<2> Param3, var uParam5) {
	return gameplay::get_heading_from_vector_2d(Param3 - Param0, Param3.f_1 - Param0.f_1);
}

// Position - 0x746C
void func_99(var uParam0, var uParam1, int iParam2) {
	struct<5> Var0;

	Var0 = 573;
	Var0.f_3 = uParam1;
	Var0.f_4 = uParam0;
	func_6(&Var0.f_2, 1, iParam2);
	func_6(&Var0.f_2, 3, 1);
	script::trigger_script_event(1, &Var0, 6, func_47());
}

// Position - 0x74A6
char *func_100(struct<13> Param0, var uParam13, var uParam14, var uParam15, var uParam16, var uParam17, var uParam18,
			   var uParam19, var uParam20, int iParam21) {
	if (controls::_is_input_disabled(2)) {
		switch (iParam21) {
		case 5:
			if (Param0 == 0) {
				return "DART_A_LWAITPC";
			}
			else {
				return "ARMW_A_LWAITPC";
			}
			break;

		case 2:
			if (Param0 == 0) {
				return "DART_A_TWO";
			}
			else {
				return "ARMW_A_TWOPC";
			}
			break;

		case 4:
			if (Param0 == 0) {
				return "";
			}
			else {
				return "ARMW_A_PWAITPC";
			}
			break;
		}
	}
	return Param0.f_12[iParam21];
}

// Position - 0x7523
void func_101(char *sParam0, int iParam1) {
	if (!gameplay::is_string_null_or_empty(sParam0)) {
		if (iParam1) {
			if (!func_103(sParam0)) {
				func_102(sParam0);
			}
		}
		else if (func_103(sParam0)) {
			ui::clear_help(1);
		}
	}
}

// Position - 0x755B
void func_102(char *sParam0) {
	ui::begin_text_command_display_help(sParam0);
	ui::end_text_command_display_help(0, 1, 1, -1);
}

// Position - 0x7571
bool func_103(char *sParam0) {
	ui::begin_text_command_is_this_help_message_being_displayed(sParam0);
	return ui::end_text_command_is_this_help_message_being_displayed(0);
}

// Position - 0x7584
void func_104(int iParam0) {
	*iParam0 = 0;
	iParam0->f_1 = 0;
	iParam0->f_2 = 0;
	iParam0->f_3 = 0;
	iParam0->f_5 = 0;
	iParam0->f_6 = 0;
	iParam0->f_7 = 0;
	iParam0->f_4 = 0;
	iParam0->f_8 = 0;
}

// Position - 0x75B8
void func_105(var *uParam0, var *uParam1) {
	struct<21> Var0;
	int iVar21;
	int iVar22;
	int iVar23;

	Var0 = {Local_342[uParam0->f_4 /*21*/]};
	iVar21 = 1;
	if (bLocal_102) {
		iVar21 = 0;
		func_106(uParam0, 4);
	}
	if (ui::is_help_message_being_displayed() && !func_103(func_100(Var0, 3)) || Global_2452551 > -1) {
		iVar21 = 0;
		func_106(uParam0, 4);
	}
	if (uParam1->f_10 >= 0) {
		iVar21 = 0;
	}
	if (!uParam1->f_1[uParam0->f_4] && *uParam0 >= 1 && *uParam0 <= 3 ||
		gameplay::is_bit_set(Local_262.f_3, uParam0->f_4)) {
		iVar21 = 0;
		func_106(uParam0, 4);
	}
	switch (*uParam0) {
	case 0:
		func_154(&uParam0->f_1);
		iVar22 = 1;
		iVar23 = 0;
		while (iVar23 <= 1) {
			if (iVar23 != uParam0->f_4 && uParam1->f_1[iVar23] && !gameplay::is_bit_set(Local_262.f_3, iVar23)) {
				uParam0->f_4 = iVar23;
				uParam1->f_14 = 4f;
				func_106(uParam0, 1);
				break;
			}
			else if (uParam1->f_1[uParam0->f_4]) {
				iVar22 = 0;
			}
			iVar23++;
		}
		if (!iVar22) {
			uParam1->f_14 = 9f;
			uParam0->f_5 = 2;
			func_106(uParam0, 1);
		}
		break;

	case 1:
		if (!uParam0->f_6) {
			func_101(func_100(Var0, 3), 1);
			uParam0->f_6 = 1;
		}
		if (!func_164(&uParam0->f_1)) {
			func_163(&uParam0->f_1);
		}
		else if (func_14(&uParam0->f_1) >= uParam1->f_14) {
			uParam0->f_5++;
			func_101(func_100(Var0, 3), 0);
			uParam0->f_6 = 0;
			func_11(&uParam0->f_1);
			func_106(uParam0, 2);
		}
		break;

	case 2:
		if (!func_164(&uParam0->f_1)) {
			func_163(&uParam0->f_1);
		}
		else if (func_14(&uParam0->f_1) >= 2f) {
			if (uParam0->f_5 >= 2) {
				func_11(&uParam0->f_1);
				func_106(uParam0, 3);
			}
			else {
				func_106(uParam0, 0);
			}
		}
		break;

	case 3:
		if (!func_164(&uParam0->f_1)) {
			func_163(&uParam0->f_1);
		}
		else if (func_14(&uParam0->f_1) >= 9f) {
			uParam0->f_5 = 0;
			func_106(uParam0, 0);
		}
		break;

	case 4:
		if (func_164(&uParam0->f_1)) {
			func_154(&uParam0->f_1);
		}
		if (!iVar21) {
			if (uParam0->f_6) {
				func_101(func_100(Var0, 3), 0);
				uParam0->f_6 = 0;
			}
		}
		else {
			uParam0->f_5 = 0;
			func_106(uParam0, 0);
		}
		break;
	}
}

// Position - 0x7847
void func_106(var *uParam0, int iParam1) { *uParam0 = iParam1; }

// Position - 0x7854
bool func_107(int *iParam0) {
	if (func_164(iParam0)) {
		if (func_14(iParam0) >= 1f) {
			func_108(iParam0);
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}

// Position - 0x7885
void func_108(int *iParam0) {
	if (func_164(iParam0)) {
		if (!func_15(iParam0)) {
			iParam0->f_2 = func_13(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
			gameplay::set_bit(iParam0, 2);
		}
	}
}

// Position - 0x78BF
void func_109(var *uParam0) {
	int iVar0;
	int iVar1;
	int iVar2;
	int iVar3;

	iVar0 = 1;
	iVar1 = 1;
	if (func_31(0) || ui::is_pause_menu_active() || func_111() || func_110()) {
		iVar0 = 0;
		bLocal_102 = true;
	}
	else if (bLocal_102) {
		func_11(&iLocal_189);
		bLocal_102 = false;
	}
	if (entity::does_entity_exist(player::player_ped_id())) {
		if (!ped::is_ped_dead_or_dying(player::player_ped_id(), 1)) {
			iVar1 = !ai::is_ped_running(player::player_ped_id());
		}
	}
	uParam0->f_12 = 1;
	if (!func_107(&iLocal_189) || !iVar0 || !iVar1) {
		uParam0->f_12 = 0;
	}
	uParam0->f_11 = iVar1;
	uParam0->f_10 = Local_388[network::participant_id_to_int() /*5*/].f_1;
	iVar2 = 0;
	while (iVar2 <= 1) {
		uParam0->f_4[iVar2] = network::network_is_script_active(Local_342[iVar2 /*21*/].f_1, uParam0->f_13, 0, 0);
		uParam0->f_7[iVar2] = network::network_is_script_active(Local_342[iVar2 /*21*/].f_1, uParam0->f_13, 1, 0);
		iVar3 = 0;
		if (gameplay::is_bit_set(Local_262.f_1, iVar2) &&
			!network::network_is_script_active(Local_342[iVar2 /*21*/].f_1, uParam0->f_13, 0, 0) &&
			func_20(&Local_388, iVar2) > 0) {
			iVar3 = 1;
		}
		uParam0->f_1[iVar2] = iVar3;
		iVar2++;
	}
}

// Position - 0x79F7
var func_110() { return G_DisableMessagesAndCalls2; }

// Position - 0x7A03
int func_111() {
	if (Global_2433125.f_655.f_5 == -1) {
		return 0;
	}
	return 1;
}

// Position - 0x7A1D
void func_112(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 1) {
		if ((*uParam0)[iVar0 /*8*/].f_2) {
			func_113(&(*uParam0)[iVar0 /*8*/]);
		}
		iVar0++;
	}
}

// Position - 0x7A4C
void func_113(var *uParam0) {
	struct<20> Var0;

	if (!func_164(&uParam0->f_4) && uParam0->f_2) {
	}
	if (func_164(&uParam0->f_4)) {
		if (func_14(&uParam0->f_4) < uParam0->f_7 && uParam0->f_2 &&
			!network::network_is_script_active(uParam0->f_1, uParam0->f_3, 1, 0)) {
			Var0.f_1 = -1;
			Var0.f_2 = -1;
			Var0.f_9 = -1;
			Var0.f_16 = -1;
			Var0.f_19 = -1;
			Var0.f_16 = uParam0->f_3;
			gameplay::set_bit(&Var0.f_18, 1);
			if (func_114()) {
				if (network::network_is_script_active(uParam0->f_1, uParam0->f_3, 0, 0) &&
					!network::network_is_script_active(uParam0->f_1, uParam0->f_3, 1, 0)) {
					if (func_34(uParam0->f_1, 8344, Var0, 0, 0, 1, 1, 1)) {
						uParam0->f_2 = 0;
					}
				}
			}
		}
		else {
			func_154(&uParam0->f_4);
			uParam0->f_2 = 0;
		}
	}
}

// Position - 0x7B31
bool func_114() {
	if (!func_162(player::get_player_index())) {
		if (!func_156(player::get_player_index(), 0, 0, 0, 0) && !func_155(player::get_player_index()) &&
			!network::is_player_in_cutscene(player::get_player_index())) {
			return false;
		}
	}
	return true;
}

// Position - 0x7B76
void func_115(var *uParam0, var *uParam1, var *uParam2, var *uParam3) {
	struct<5> Var0;
	struct<5> Var5;
	int iVar11;

	Var0.f_3 = -1;
	Var0.f_4 = -1;
	iVar11 = 0;
	iVar11 = 0;
	while (iVar11 < script::get_number_of_events(1)) {
		switch (script::get_event_at_index(1, iVar11)) {
		case 171:
			if (func_23(iVar11, &Var5, 0) && (*uParam0)[network::participant_id_to_int() /*5*/].f_4 == 0) {
				switch (Var5) {
				case 574:
					if (Var5.f_3 == (*uParam0)[network::participant_id_to_int() /*5*/].f_1 &&
						Var5.f_4 == player::get_player_index()) {
						uParam1->f_1 = 1;
						uParam1->f_2 = Var5.f_3;
						uParam1->f_3 = (*uParam3)[uParam1->f_2 /*21*/].f_1;
						*uParam1 = func_22(Var5.f_2, 0);
					}
					break;

				case 575:
					if (Var5.f_3 == (*uParam0)[network::participant_id_to_int() /*5*/].f_1 &&
						Var5.f_4 == player::get_player_index()) {
						uParam1->f_2 = Var5.f_3;
						uParam1->f_3 = (*uParam3)[uParam1->f_2 /*21*/].f_1;
						func_39(uParam1, 8);
					}
					break;

				case 570:
					if (Var5.f_4 == player::get_player_index()) {
						if (Var5.f_3 >= 0 && Var5.f_3 <= 1) {
							if (!gameplay::is_bit_set(uParam1->f_5, Var5.f_3)) {
								if (!func_22(Var5.f_2, 4)) {
									uParam1->f_2 = Var5.f_3;
									uParam1->f_3 = (*uParam3)[uParam1->f_2 /*21*/].f_1;
									func_42(&(*uParam0)[network::participant_id_to_int() /*5*/], 2, 1);
									if (func_42(&(*uParam0)[network::participant_id_to_int() /*5*/
									],
												0, func_22(Var5.f_2, 2)) &&
										Var5.f_3 == (*uParam0)[network::participant_id_to_int() /*5*/
									]
														.f_1) {
									}
									func_42(&(*uParam0)[network::participant_id_to_int() /*5*/], 5,
											func_22(Var5.f_2, 5));
									func_118(&(*uParam0)[network::participant_id_to_int() /*5*/], 1);
								}
							}
						}
					}
					break;
				}
			}
			if (script::get_event_data(1, iVar11, &Var0, 5)) {
				switch (Var0) {
				case 576:
					if (Var0.f_3 == uParam1->f_6 && Var0.f_2 != player::player_id()) {
						if (!(func_19(&(*uParam0)[network::participant_id_to_int() /*5*/], 2) &&
							  (*uParam0)[network::participant_id_to_int() /*5*/].f_1 == Var0.f_4)) {
							if (func_114()) {
								func_129(uParam2, Var0.f_4, 1092616192);
							}
						}
					}
					break;
				}
			}
			break;
		}
		iVar11++;
	}
}

// Position - 0x7DB3
bool func_116(int iParam0) { return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_13, 14); }

// Position - 0x7DCF
int func_117() { return Local_262.f_4; }

// Position - 0x7DDC
bool func_118(var *uParam0, int iParam1) {
	if (uParam0->f_4 != iParam1) {
		uParam0->f_4 = iParam1;
		return true;
	}
	return false;
}

// Position - 0x7DF8
bool func_119() {
	bool bVar0;
	int *iVar1;

	func_126(&bVar0, &iVar1);
	if (bVar0) {
		return true;
	}
	if (Global_1315210 == 0) {
		if (!network::network_is_game_in_progress()) {
			return true;
		}
	}
	if (func_125()) {
		return true;
	}
	if (Global_2454747) {
		return true;
	}
	if (func_124()) {
		return true;
	}
	if (func_123(157)) {
		if (!func_122()) {
			return true;
		}
	}
	if (func_123(155)) {
		return true;
	}
	if (!network::network_is_signed_online()) {
		return true;
	}
	if (func_120() != 0) {
		if (script::_get_number_of_instances_of_script_with_name_hash(func_120()) == 0) {
			return true;
		}
	}
	return false;
}

// Position - 0x7E8D
int func_120() {
	switch (func_121()) {
	case 0: return joaat("freemode");

	case 2: return joaat("creator");
	}
	return 0;
}

// Position - 0x7EC1
int func_121() { return Global_25190; }

// Position - 0x7ECC
bool func_122() { return Global_2443134.f_577; }

// Position - 0x7EDB
bool func_123(int iParam0) {
	if (script::get_event_exists(1, iParam0)) {
		return true;
	}
	return false;
}

// Position - 0x7EF2
bool func_124() { return Global_2452525; }

// Position - 0x7EFE
bool func_125() { return Global_2443134.f_572; }

// Position - 0x7F0D
void func_126(int *iParam0, int *iParam1) {
	int iVar0;
	int iVar1;
	int iVar2;
	vector3 vVar4;

	iVar0 = 0;
	while (iVar0 < script::get_number_of_events(1)) {
		iVar1 = script::get_event_at_index(1, iVar0);
		if (iVar1 == 171) {
			script::get_event_data(1, iVar0, &iVar2, 2);
			switch (iVar2) {
			case 381: func_127(iVar0); break;

			case 2:
				script::get_event_data(1, iVar0, &vVar4, 3);
				if (vVar4.z == 55) {
					*iParam0 = 1;
				}
				else if (vVar4.z == 32) {
					*iParam1 = 1;
				}
				break;
			}
		}
		iVar0++;
	}
}

// Position - 0x7F8D
void func_127(int iParam0) {
	vector3 vVar0;
	int iVar3;
	int iVar4;
	bool bVar5;

	if (script::get_event_data(1, iParam0, &vVar0, 3)) {
		if (func_48(vVar0.y, 1, 1)) {
			iVar3 = player::get_player_ped(vVar0.y);
			if (entity::does_entity_exist(iVar3)) {
				if (ped::is_ped_in_any_vehicle(iVar3, 0)) {
					iVar4 = ped::get_vehicle_ped_is_in(iVar3, 0);
					if (vehicle::is_vehicle_window_intact(iVar4, vVar0.z) &&
						network::network_get_this_script_is_network_script()) {
						if (func_128(iVar4, &bVar5)) {
							vehicle::remove_vehicle_window(iVar4, vVar0.z);
						}
						if (bVar5) {
							entity::set_vehicle_as_no_longer_needed(&iVar4);
						}
					}
				}
			}
		}
	}
}

// Position - 0x800F
bool func_128(int iParam0, int *iParam1) {
	if (entity::does_entity_exist(iParam0)) {
		if (!entity::is_entity_a_mission_entity(iParam0)) {
			if (network::network_get_entity_is_local(iParam0)) {
				if (!vehicle::is_this_model_a_train(entity::get_entity_model(iParam0))) {
					entity::set_entity_as_mission_entity(iParam0, 0, 1);
					*iParam1 = 1;
				}
			}
		}
		if (entity::does_entity_belong_to_this_script(iParam0, 0)) {
			if (network::network_has_control_of_entity(iParam0)) {
				return true;
			}
		}
	}
	return false;
}

// Position - 0x806E
void func_129(var *uParam0, int iParam1, float fParam2) {
	(*uParam0)[iParam1 /*8*/].f_7 = fParam2;
	(*uParam0)[iParam1 /*8*/].f_2 = 1;
	if (!func_164(&(*uParam0)[iParam1 /*8*/].f_4)) {
		func_163(&(*uParam0)[iParam1 /*8*/].f_4);
	}
	else {
		func_11(&(*uParam0)[iParam1 /*8*/].f_4);
	}
}

// Position - 0x80B4
void func_130(var *uParam0, var *uParam1) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 1) {
		(*uParam0)[iVar0 /*8*/].f_1 = (*uParam1)[iVar0 /*21*/].f_1;
		(*uParam0)[iVar0 /*8*/].f_7 = 10f;
		(*uParam0)[iVar0 /*8*/].f_3 = Global_1591201[player::player_id() /*602*/].f_258.f_16;
		iVar0++;
	}
}

// Position - 0x8103
void func_131(var *uParam0, int iParam1) {
	struct<21> Var0;

	Var0.f_12 = 8;
	Var0 = 0;
	Var0.f_1 = "AM_Darts_Apartment";
	Var0.f_2 = 0;
	Var0.f_3 = {func_133(iParam1)};
	Var0.f_6 = {1f, 1f, 1f};
	Var0.f_9 = 0;
	Var0.f_10 = 1;
	Var0.f_11 = 2;
	Var0.f_12[0] = "DART_A_PROG";
	Var0.f_12[1] = "DART_A_ONE";
	Var0.f_12[2] = "DART_A_TWO";
	Var0.f_12[3] = "DART_A_JOIN";
	Var0.f_12[4] = "";
	Var0.f_12[5] = "DART_A_LWAIT";
	Var0.f_12[6] = "DART_A_PREP";
	Var0.f_12[7] = "DART_A_MANY";
	(*uParam0)[0 /*21*/] = {Var0};
	Var0 = 1;
	Var0.f_1 = "AM_Armwrestling_Apartment";
	Var0.f_2 = 1;
	Var0.f_3 = {func_132(iParam1)};
	Var0.f_6 = {1f, 1f, 1f};
	Var0.f_9 = 0;
	Var0.f_10 = 2;
	Var0.f_11 = 2;
	Var0.f_12[0] = "ARMW_A_PROG";
	Var0.f_12[1] = "";
	Var0.f_12[2] = "ARMW_A_TWO";
	Var0.f_12[3] = "ARMW_A_JOIN";
	Var0.f_12[4] = "ARMW_A_PWAIT";
	Var0.f_12[5] = "ARMW_A_LWAIT";
	Var0.f_12[6] = "ARMW_A_PREP";
	Var0.f_12[7] = "ARMW_A_MANY";
	(*uParam0)[1 /*21*/] = {Var0};
}

// Position - 0x8243
Vector3 func_132(int iParam0) {
	switch (iParam0) {
	case 0: return 1116.5f, -3153.2f, -37.5f;

	case 1: return 1003.1f, -3165.7f, -33.6f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x8285
Vector3 func_133(int iParam0) {
	switch (iParam0) {
	case 0: return 1118.489f, -3157.188f, -37.5628f;

	case 1: return 1001f, -3164.3f, -33.6f;

	default:
	}
	return 0f, 0f, 0f;
}

// Position - 0x82C7
bool func_134(int iParam0, int iParam1) {
	if (iParam1 == -1) {
		switch (iParam0) {
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96:
		case 97:
		case 98:
		case 99:
		case 100:
		case 101:
		case 102: return true;
		}
	}
	else if (iParam1 == 91) {
		switch (iParam0) {
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96: return true;
		}
	}
	else if (iParam1 == 97) {
		switch (iParam0) {
		case 97:
		case 98:
		case 99:
		case 100:
		case 101:
		case 102: return true;
		}
	}
	return false;
}

// Position - 0x83A4
void func_135(var *uParam0, var *uParam1) {
	(*uParam0)[0] = 0;
	(*uParam0)[1] = 1;
	(*uParam0)[2] = 2;
	(*uParam1)[0] = 1;
	(*uParam1)[1] = 2;
	(*uParam1)[2] = 3;
	(*uParam1)[3] = 4;
	(*uParam1)[4] = 5;
}

// Position - 0x83DC
void func_136(var *uParam0) {
	(*uParam0)[0 /*3*/] = "DART_A_GN";
	(*uParam0)[0 /*3*/].f_1 = 5;
	(*uParam0)[0 /*3*/].f_2 = 0;
}

// Position - 0x83FD
bool func_137(char *sParam0, int iParam1, int iParam2) {
	int iVar0;
	int iVar1;
	int iVar2;

	if (!func_81(&iVar0, 1, iParam1)) {
		return false;
	}
	iVar1 = 1;
	StringCopy(&Global_17290.f_5505[iVar0 /*4*/], sParam0, 16);
	if (!gameplay::is_string_null_or_empty(&Global_17290.f_5505[iVar0 /*4*/])) {
		ui::request_additional_text(&Global_17290.f_5505[iVar0 /*4*/], 9);
		Global_17290.f_5498[iVar0] = 1;
		if (!ui::has_this_additional_text_loaded(&Global_17290.f_5505[iVar0 /*4*/], 9)) {
			iVar1 = 0;
		}
	}
	graphics::request_streamed_texture_dict("CommonMenu", 0);
	Global_17290.f_5484[iVar0] = 1;
	if (!graphics::has_streamed_texture_dict_loaded("CommonMenu")) {
		iVar1 = 0;
	}
	if (iParam2) {
		graphics::request_streamed_texture_dict("MPShopSale", 0);
		Global_17290.f_5491[iVar0] = 1;
		if (!graphics::has_streamed_texture_dict_loaded("MPShopSale")) {
			iVar1 = 0;
		}
	}
	iVar2 = 0;
	StringCopy(&Global_17290.f_5530[iVar0 /*10*/].f_1, "instructional_buttons", 24);
	iVar2 = func_138(&Global_17290.f_5530[iVar0 /*10*/]);
	if (!iVar1 || !iVar2) {
	}
	return iVar1 & iVar2;
}

// Position - 0x84F1
bool func_138(var *uParam0) {
	switch (uParam0->f_9) {
	case 0:
		if (!graphics::has_scaleform_movie_loaded(*uParam0)) {
			*uParam0 = unk_0x67D02A194A2FC2BD(&uParam0->f_1);
			uParam0->f_9 = 1;
			if (uParam0->f_7) {
				if (graphics::has_scaleform_movie_loaded(*uParam0)) {
					uParam0->f_8 = gameplay::get_game_timer();
					uParam0->f_9 = 2;
				}
			}
		}
		else {
			uParam0->f_8 = gameplay::get_game_timer();
			uParam0->f_9 = 2;
		}
		break;

	case 1:
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			uParam0->f_8 = gameplay::get_game_timer();
			uParam0->f_9 = 2;
		}
		break;

	case 2:
		if (!graphics::has_scaleform_movie_loaded(*uParam0)) {
			uParam0->f_9 = 0;
		}
		break;
	}
	return uParam0->f_9 == 2;
}

// Position - 0x8593
void func_139(var *uParam0) {
	int iVar0;

	iVar0 = 0;
	while (iVar0 <= 1) {
		(*uParam0)[iVar0 /*8*/].f_2 = 0;
		(*uParam0)[iVar0 /*8*/].f_7 = 10f;
		func_154(&(*uParam0)[iVar0 /*8*/].f_4);
		iVar0++;
	}
}

// Position - 0x85CF
void func_140(var uParam0) {}

// Position - 0x85D7
void func_141(int *iParam0) {
	func_142(iParam0, 0, Global_262145.f_15837);
	func_142(iParam0, 1, Global_262145.f_15838);
	if (network::network_is_activity_session()) {
		func_142(iParam0, 0, 1);
		func_142(iParam0, 1, 1);
	}
}

// Position - 0x8612
void func_142(int *iParam0, int iParam1, int iParam2) {
	if (gameplay::is_bit_set(*iParam0, iParam1) != iParam2) {
		func_17(iParam0, iParam1, iParam2);
	}
}

// Position - 0x8633
void func_143() {
	struct<20> Var0;

	Var0.f_1 = -1;
	Var0.f_2 = -1;
	Var0.f_9 = -1;
	Var0.f_16 = -1;
	Var0.f_19 = -1;
	Var0.f_16 = Global_1591201[player::player_id() /*602*/].f_258.f_16;
	if (Var0 != 12) {
		Var0 = 12;
	}
	func_148(func_149(Var0), Var0);
	func_145(0, -1, 0);
	network::network_register_host_broadcast_variables(&Local_262, 10);
	network::network_register_player_broadcast_variables(&Local_388, 161);
	if (!func_144()) {
		func_150();
	}
	if (network::network_is_game_in_progress()) {
		gameplay::set_this_script_can_be_paused(0);
		Local_388[network::participant_id_to_int() /*5*/].f_2 = 0;
	}
	else {
		func_150();
	}
}

// Position - 0x86D1
int func_144() {
	int iVar0;

	iVar0 = 0;
	while (true) {
		iVar0++;
		if (!network::network_is_game_in_progress()) {
			return 0;
		}
		if (network::_0x5D10B3795F3FC886()) {
			return 1;
		}
		if (func_125()) {
			return 0;
		}
		if (func_123(155)) {
			return 0;
		}
		if (iVar0 >= 3600) {
			return 0;
		}
		system::wait(0);
	}
	return 0;
}

// Position - 0x872A
int func_145(int iParam0, int iParam1, int iParam2) {
	int iVar0;

	iVar0 = network::network_get_script_status();
	while (iVar0 != 2) {
		if (iVar0 == 3 || iVar0 == 4 || iVar0 == 5 || iVar0 == 6) {
			if (!iParam2) {
				func_147();
			}
			else {
				return 0;
			}
		}
		if (!func_146()) {
			if (iParam0 == 0) {
				if (!network::network_is_game_in_progress()) {
					if (!iParam2) {
						func_147();
					}
					else {
						return 0;
					}
				}
				if (func_125()) {
					if (!iParam2) {
						func_147();
					}
					else {
						return 0;
					}
				}
				if (func_123(155)) {
					if (!iParam2) {
						func_147();
					}
					else {
						return 0;
					}
				}
			}
			else if (!network::network_is_in_session()) {
				if (!iParam2) {
					func_147();
				}
				else {
					return 0;
				}
			}
		}
		system::wait(0);
		iVar0 = network::network_get_script_status();
	}
	if (iParam1 > -1) {
		Global_1312500 = iVar0;
	}
	if (iParam0 == 0) {
		if (!network::network_is_game_in_progress()) {
			if (!iParam2) {
				func_147();
			}
			else {
				return 0;
			}
		}
	}
	else if (!network::network_is_in_session()) {
		if (!iParam2) {
			func_147();
		}
		else {
			return 0;
		}
	}
	return 1;
}

// Position - 0x883F
bool func_146() { return Global_1315210; }

// Position - 0x884B
void func_147() { script::terminate_this_thread(); }

// Position - 0x8857
void func_148(int iParam0, struct<17> Param1, var uParam18, var uParam19, var uParam20) {
	if (!network::network_is_game_in_progress()) {
		func_147();
	}
	network::network_set_this_script_is_network_script(iParam0, 0, Param1.f_16);
}

// Position - 0x8876
int func_149(int iParam0) {
	switch (iParam0) {
	case 3: return 2;

	case 1: return 32;

	case 2: return 32;

	case 32: return 32;

	case 33: return 32;

	case 34: return 32;

	case 35: return 32;

	case 36: return 32;

	case 37: return 32;

	case 38: return 32;

	case 39: return 32;

	case 40: return 32;

	case 41: return 32;

	case 42: return 32;

	case 43: return 32;

	case 44: return 32;

	case 45: return 32;

	case 46: return 32;

	case 47: return 32;

	case 48: return 32;

	case 49: return 32;

	case 50: return 4;

	case 51: return 32;

	case 52: return 32;

	case 53: return 32;

	case 54: return 32;

	case 55: return 32;

	case 56: return 32;

	case 57: return 32;

	case 58: return 32;

	case 59: return 32;

	case 60: return 32;

	case 61: return 32;

	case 62: return 32;

	case 63: return 32;

	case 64: return 4;

	case 65: return 32;

	case 66: return 4;

	case 67: return 4;

	case 68: return 32;

	case 69: return 32;

	case 70: return 4;

	case 71: return 32;

	case 72: return 32;

	case 73:
	case 74: return 4;

	case 75: return 32;

	case 76: return 32;

	case 77: return 32;

	case 78: return 32;

	case 79: return 32;

	case 80: return 32;

	case 81: return 32;

	case 82: return 32;

	case 84: return 32;

	case 83: return 32;

	case 85: return 32;

	case 86: return 32;

	case 87: return 32;

	case 88: return 32;

	case 89: return 32;

	case 90: return 8;

	case 91: return 32;

	case 92: return 8;

	case 93: return 8;

	case 101: return 8;

	case 94: return 8;

	case 95: return 32;

	case 96: return 32;

	case 97: return 32;

	case 98: return 8;

	case 99: return 32;

	case 100: return 32;

	case 102: return 32;

	case 103: return 32;

	case 104: return 32;

	case 105: return 8;

	case 12: return 32;

	case 4: return 16;

	case 13: return 32;

	case 5: return 16;

	case 6: return 2;

	case 8: return 2;

	case 9: return 2;

	case 7: return 16;

	case 10: return 2;

	case 11: return 4;

	case 15: return 32;

	case 16: return 32;

	case 27: return 2;

	case 25: return 2;

	case 26: return 2;

	case 18: return 32;

	case 28: return 32;

	case 29: return 2;

	case 30: return 32;

	case 31: return 32;

	case 17: return 2;

	case 106: return 32;

	case 107: return 32;

	case 19: return 32;

	case 22: return 32;

	case 23: return 32;

	case 24: return 32;

	case 20: return 2;

	case 0: return 0;

	case 21: return 32;

	case 118: return 32;

	case 119: return 32;

	case 108: return 32;

	case 109: return 32;

	case 113: return 32;

	case 111: return 32;

	case 112: return 32;

	case 116: return 32;

	case 117: return 32;

	case 114: return 32;

	case 115: return 32;

	case 120: return 32;

	case 121: return 32;

	case 122: return 32;

	case 123: return 32;

	case 124: return 2;

	case 129: return 1;

	case 125: return 2;

	case 126: return 4;

	case 127: return 2;

	case 128: return 2;

	case 110: return 1;

	case 130: return 2;

	case 131:
	case 132:
	case 133:
	case 134:
	case 135:
	case 136: return 0;

	case 140: return 1;

	case 137: return 4;

	case 138: return 16;

	case 139: return 32;

	default:
	}
	return 0;
}

// Position - 0x8E51
void func_150() {
	func_32(0);
	func_151(1, -1);
	func_36(&iLocal_216);
	func_147();
}

// Position - 0x8E6E
void func_151(int iParam0, int iParam1) {
	int iVar0;

	if (!func_81(&iVar0, 0, iParam1)) {
		return;
	}
	if (Global_17290.f_7899) {
		ui::reset_hud_component_values(15);
		Global_17290.f_7899 = 0;
	}
	ui::_0x55598D21339CB998(0f);
	if (Global_17290.f_5498[iVar0]) {
		ui::clear_additional_text(9, 0);
		Global_17290.f_5498[iVar0] = 0;
	}
	if (Global_17290.f_5484[iVar0]) {
		graphics::set_streamed_texture_dict_as_no_longer_needed("CommonMenu");
		Global_17290.f_5484[iVar0] = 0;
	}
	if (Global_17290.f_5491[iVar0]) {
		graphics::set_streamed_texture_dict_as_no_longer_needed("MPShopSale");
		Global_17290.f_5491[iVar0] = 0;
	}
	if (iParam0) {
		func_152(&Global_17290.f_5530[iVar0 /*10*/]);
		Global_17290.f_5591[iVar0] = 0;
	}
	else {
		Global_17290.f_5591[iVar0] = 0;
	}
}

// Position - 0x8F2B
void func_152(int *iParam0) {
	if (uParam0->f_9 != 0) {
		if (graphics::has_scaleform_movie_loaded(*uParam0)) {
			graphics::set_scaleform_movie_as_no_longer_needed(uParam0);
		}
		*iParam0 = 0;
		iParam0->f_9 = 0;
	}
}

// Position - 0x8F54
float func_153(int *iParam0) {
	if (func_164(iParam0)) {
		if (func_15(iParam0)) {
			return iParam0->f_2;
		}
		else {
			return func_13(gameplay::is_bit_set(*iParam0, 4)) - iParam0->f_1;
		}
	}
	return 0f;
}

// Position - 0x8F90
void func_154(int *iParam0) {
	iParam0->f_1 = 0f;
	iParam0->f_2 = 0f;
	*iParam0 = 0;
}

// Position - 0x8FA6
bool func_155(int iParam0) {
	if (func_134(Global_1591201[iParam0 /*602*/].f_258.f_15, -1)) {
		return true;
	}
	return false;
}

// Position - 0x8FC9
int func_156(int iParam0, int iParam1, int iParam2, int iParam3, int iParam4) {
	if (Global_1591201[iParam0 /*602*/].f_258.f_15 > 0) {
		if (iParam1) {
			if (gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_13, 0)) {
				return 1;
			}
		}
		else {
			return 1;
		}
	}
	if (!iParam2) {
		if (func_161(iParam0)) {
			return 1;
		}
	}
	if (!iParam3) {
		if (func_160(iParam0)) {
			return 1;
		}
	}
	if (!iParam4) {
		if (func_157(iParam0)) {
			return 1;
		}
	}
	return 0;
}

// Position - 0x9043
bool func_157(int iParam0) {
	if (iParam0 != func_159()) {
		if (func_48(iParam0, 1, 1)) {
			if (Global_2421664[iParam0 /*358*/].f_312.f_1 != -1) {
				return func_158(Global_2421664[iParam0 /*358*/].f_312.f_1) == 1;
			}
		}
	}
	return false;
}

// Position - 0x9089
int func_158(int iParam0) {
	switch (iParam0) {
	case 0:
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:
	case 6:
	case 7:
	case 8:
	case 9:
	case 10:
	case 11:
	case 12:
	case 13:
	case 14:
	case 15:
	case 16:
	case 17:
	case 18:
	case 19:
	case 20:
	case 21: return 0;

	case 57:
	case 58:
	case 59:
	case 60:
	case 61:
	case 62:
	case 63:
	case 64:
	case 65:
	case 66: return 1;

	case 22:
	case 23:
	case 24:
	case 25:
	case 26:
	case 27:
	case 28:
	case 29:
	case 30:
	case 31:
	case 32:
	case 33:
	case 34:
	case 35:
	case 36:
	case 37:
	case 38:
	case 39:
	case 40:
	case 41: return 2;

	case 43:
	case 42:
	case 44:
	case 45:
	case 46:
	case 47:
	case 48:
	case 49:
	case 50:
	case 51:
	case 52:
	case 53:
	case 54:
	case 55:
	case 56: return 3;
	}
	return -1;
}

// Position - 0x9247
int func_159() { return -1; }

// Position - 0x9250
bool func_160(int iParam0) {
	if (iParam0 != func_159()) {
		if (func_48(iParam0, 1, 1)) {
			if (Global_2421664[iParam0 /*358*/].f_312.f_1 != -1) {
				return func_158(Global_2421664[iParam0 /*358*/].f_312.f_1) == 2;
			}
		}
	}
	return false;
}

// Position - 0x9296
bool func_161(int iParam0) {
	if (iParam0 != func_159()) {
		if (func_48(iParam0, 1, 1)) {
			if (Global_2421664[iParam0 /*358*/].f_312.f_1 != -1) {
				return func_158(Global_2421664[iParam0 /*358*/].f_312.f_1) == 0;
			}
		}
	}
	return false;
}

// Position - 0x92DC
bool func_162(int iParam0) { return gameplay::is_bit_set(Global_1591201[iParam0 /*602*/].f_258.f_13, 11); }

// Position - 0x92F8
void func_163(int *iParam0) {
	if (!func_164(iParam0)) {
		func_11(iParam0);
	}
}

// Position - 0x9310
bool func_164(int *iParam0) { return gameplay::is_bit_set(*iParam0, 1); }

Open 'project/HeadShotV.sln' in Visual Studio. Build Release|x64. .asi will appear in /compiled.

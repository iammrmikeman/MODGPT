Open 'project/HeadShotV.sln' in Visual Studio. Build with Release|x64. Output to /compiled.

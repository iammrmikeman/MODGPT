
#include "inc/natives.h"
#include "inc/types.h"
#include <windows.h>
#include <iostream>

void main()
{
    while (true)
    {
        WAIT(0);
    }
}

void ScriptMain()
{
    main();
}

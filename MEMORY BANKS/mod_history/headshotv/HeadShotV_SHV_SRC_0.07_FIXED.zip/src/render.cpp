// Auto-generated render.cpp
void dummy() {}
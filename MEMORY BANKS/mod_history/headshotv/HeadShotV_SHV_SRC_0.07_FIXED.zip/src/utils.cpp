// Auto-generated utils.cpp
void dummy() {}
// Auto-generated natives.cpp
void dummy() {}
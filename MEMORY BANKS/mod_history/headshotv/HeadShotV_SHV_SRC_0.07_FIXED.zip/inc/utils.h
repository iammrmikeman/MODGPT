// Auto-generated utils.h
#pragma once
// Auto-generated natives.h
#pragma once
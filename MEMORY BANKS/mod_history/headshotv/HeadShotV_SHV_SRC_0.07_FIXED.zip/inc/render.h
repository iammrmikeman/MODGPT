// Auto-generated render.h
#pragma once
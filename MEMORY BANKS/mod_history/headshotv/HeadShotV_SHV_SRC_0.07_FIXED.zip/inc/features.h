// Auto-generated features.h
#pragma once
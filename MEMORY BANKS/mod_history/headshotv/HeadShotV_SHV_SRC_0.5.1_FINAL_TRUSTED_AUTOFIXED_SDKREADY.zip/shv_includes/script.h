#pragma once

#include <windows.h>
#include <string>

void WAIT(DWORD time);
void ScriptMain();

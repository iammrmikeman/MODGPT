#pragma once
#include <windows.h>

#define WAIT(x) Sleep(x)
void ScriptMain();

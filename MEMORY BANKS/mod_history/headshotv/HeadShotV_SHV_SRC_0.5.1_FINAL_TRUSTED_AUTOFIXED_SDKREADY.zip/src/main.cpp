#include "script.h"
#include "inc/types.h"

void ScriptMain()
{
    while (true)
    {
        if (IS_PED_SHOOTING(PLAYER::PLAYER_PED_ID()))
        {
            Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
            Hash model = GAMEPLAY::GET_HASH_KEY("headburst");
            STREAMING::REQUEST_MODEL(model);
            if (STREAMING::HAS_MODEL_LOADED(model))
            {
                Object obj = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, true, true, false);
                ENTITY::ATTACH_ENTITY_TO_ENTITY(obj, PLAYER::PLAYER_PED_ID(), PED::GET_PED_BONE_INDEX(PLAYER::PLAYER_PED_ID(), 31086), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, true, true, false, true, 1, true);
            }
        }
        WAIT(0);
    }
}

#pragma once
// Simulated GTA V native function mapping
typedef int Ped;
typedef int Player;
typedef int Hash;
typedef int Object;
typedef int Entity;

struct Vector3 {
    float x, y, z;
};

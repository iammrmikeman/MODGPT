#pragma once
void LogMessage(const char* message);
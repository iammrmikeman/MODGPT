// Type definitions for HeadShotV SHV
typedef unsigned int uint;
typedef int Hash;
typedef int Ped;
typedef int Object;

struct Vector3 {
    float x;
    float y;
    float z;
};

#pragma once
#include "types.h"
#include "utils.h"
#include "natives.h"
#include "features.h"
#include "render.h"

void ScriptMain();
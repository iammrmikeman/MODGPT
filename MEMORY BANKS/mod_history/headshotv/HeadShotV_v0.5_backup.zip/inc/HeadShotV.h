// Header file for HeadShotV v0.5

#include "script.h"

void ScriptMain()
{
    while (true)
    {
        WAIT(1000); // ScriptHookV native-compatible wait loop
    }
}

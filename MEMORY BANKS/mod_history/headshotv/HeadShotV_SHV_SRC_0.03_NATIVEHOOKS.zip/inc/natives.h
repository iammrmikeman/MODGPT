#pragma once
#include "script.h"

// Add SHV-compatible native wrappers here

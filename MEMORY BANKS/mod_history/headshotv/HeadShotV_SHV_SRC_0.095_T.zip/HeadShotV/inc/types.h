
#pragma once

typedef int BOOL;

struct Vector3
{
    float x, y, z;
    Vector3() : x(0), y(0), z(0) {}
    Vector3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
};

typedef unsigned int Hash;
typedef int Ped;
typedef int Player;
typedef int Entity;
typedef int Vehicle;
typedef int Object;
typedef int Blip;
typedef int Camera;

#pragma once
void DrawTextAboveRadar(const char* text);
chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: "index.html" });
});
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: "index.html" });
});
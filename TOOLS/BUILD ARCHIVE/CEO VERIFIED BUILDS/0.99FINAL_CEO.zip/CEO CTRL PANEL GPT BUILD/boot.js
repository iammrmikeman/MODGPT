window.onload = () => {
  setTimeout(() => {
    document.getElementById("boot-logo").classList.add("fade-in");
  }, 500);
  setTimeout(() => {
    document.getElementById("legal-text").classList.add("fade-in");
  }, 2000);
  setTimeout(() => {
    document.getElementById("main-ui").classList.remove("hidden");
  }, 4000);

  tsParticles.load("tsparticles", {
    particles: {
      number: { value: 75 },
      size: { value: 2 },
      move: { enable: true, speed: 1 },
      opacity: { value: 0.7 },
      color: { value: "#00cfff" },
    }
  });

  document.getElementById("theme-btn").onclick = () => {
    alert("Theme button clicked!");
  };
};

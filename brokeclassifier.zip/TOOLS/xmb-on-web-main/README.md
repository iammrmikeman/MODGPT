# xmb-on-web
A recreation of the PS3's Cross Media Bar (XMB) interface using Vanilla JS and SCSS. 

This project is a work in progress.

https://menonparik.github.io/xmb-on-web/



![xmb2](https://user-images.githubusercontent.com/87072411/206355433-e52f3cc6-86d2-4900-bace-f2d6f16ef9ab.gif)

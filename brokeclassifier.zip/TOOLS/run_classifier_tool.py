import json
import os
from datetime import datetime

print("🧠 Running MODGPT Classifier Tool...")

index_path = "system/file_intelligence_index.json"
classified_path = "system/classified_file_index.json"
log_path = "system/classifier_log__military_audit.md"
timestamp = datetime.utcnow().isoformat() + "Z"

EXTENSION_TAGS = {
    ".cpp": "mod_logic",
    ".py": "tooling",
    ".md": "doctrine",
    ".bat": "automation",
    ".ahk": "automation",
    ".json": "memory_data",
    ".zip": "archive",
    ".txt": "log_or_note",
    ".swarm": "swarm_logic"
}

KEYWORDS_TAGS = {
    "gore": ["gore", "fx"],
    "blood": ["gore", "fx"],
    "headshot": ["ai", "reaction"],
    "npc": ["ai", "mod_logic"],
    "patch": ["swarm", "runtime"],
    "update": ["swarm", "runtime"],
    "bootstrap": ["doctrine", "core"],
    "seal": ["doctrine", "auth"],
    "mapper": ["memory", "tools"]
}

def classify_path(path):
    ext = os.path.splitext(path)[1].lower()
    name = os.path.basename(path).lower()
    tags = []

    if ext in EXTENSION_TAGS:
        tags.append(EXTENSION_TAGS[ext])
    for kw in KEYWORDS_TAGS:
        if kw in name:
            tags.extend(KEYWORDS_TAGS[kw])

    tags = list(set(tags)) or ["unknown"]
    confidence = min(100, 30 + 10 * len(tags))
    return {
        "type": tags[0],
        "tags": tags,
        "confidence": confidence
    }

if not os.path.exists(index_path):
    print("❌ Error: system/file_intelligence_index.json not found.")
    input("Press ENTER to close...")
    exit(1)

with open(index_path, "r", encoding="utf-8") as f:
    data = json.load(f)

results = {}
logs = []

for entry in data:
    path = entry.get("path", "")
    if not path:
        continue
    r = classify_path(path)
    results[path] = r
    logs.append(f"[{timestamp}] {path} → {r['type']} ({r['confidence']}%)")

os.makedirs("system", exist_ok=True)
with open(classified_path, "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)
with open(log_path, "w", encoding="utf-8") as f:
    f.write("\n".join(logs))

print("✅ Classification complete.")
print("→ system/classified_file_index.json")
print("→ system/classifier_log__military_audit.md")
input("Press ENTER to close...")

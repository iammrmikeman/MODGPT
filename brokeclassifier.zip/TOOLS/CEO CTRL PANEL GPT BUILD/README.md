# MODGPT Control Panel v1.0 XMBFUSION
Drag legal-screen.html into your browser to start the boot sequence.
Tested on Firefox.
## Build v1.0 XMBFUSION_STAGE1 ✅
- [x] Legal Screen
- [x] Boot Logo
- [x] tsParticles Background
- [x] Sidebar Nav Renamed
- [x] Clicks Functional
- [x] Works in Firefox
- [ ] No audio yet
- [ ] No theme selector yet